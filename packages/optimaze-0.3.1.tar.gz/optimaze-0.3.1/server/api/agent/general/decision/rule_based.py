"""Rule-based decision component: maps analysis results to ordered fix lists."""

from dataclasses import dataclass
from typing import Callable, ClassVar

from server.api.agent.general.analysis.base import AnalysisResult


@dataclass
class DecisionRule:
    """A single decision rule mapping an analysis result to fix names."""

    analyzer_name: str                          # which analyzer this rule fires on
    condition: Callable[[AnalysisResult], bool]  # True → rule fires
    fix_names: list[str]                        # ordered: highest priority first


class RuleBasedDecision:
    """
    Maps analysis results to an ordered list of fixes to try.

    Rules are evaluated in order; duplicates are removed (first occurrence wins).
    `solver_params` is always appended as a fallback if not already in the list.
    """

    RULES: ClassVar[list[DecisionRule]] = [
        # --- Coefficient range / Big-M ---
        DecisionRule(
            "coeff_range",
            lambda r: r.details.get("ratio", 0) > 1e6,
            ["big_m", "rescale", "constraint_tightening"],
        ),
        DecisionRule(
            "coeff_range",
            lambda r: 1e4 < r.details.get("ratio", 0) <= 1e6,
            ["rescale", "constraint_tightening"],
        ),
        # --- Variable / constraint scale ---
        DecisionRule(
            "variable_count",
            lambda r: r.details.get("count", 0) > 10_000,
            ["new_variables"],
        ),
        DecisionRule(
            "constraint_count",
            lambda r: r.details.get("count", 0) > 5_000,
            ["benders", "lazy_constraints"],
        ),
        # --- B&B node count ---
        DecisionRule(
            "node_count",
            lambda r: r.details.get("count", 0) > 10_000,
            ["symmetry_breaking", "valid_inequalities", "branching_priorities", "solver_params"],
        ),
        DecisionRule(
            "node_count",
            lambda r: 1_000 < r.details.get("count", 0) <= 10_000,
            ["branching_priorities", "valid_inequalities", "solver_params"],
        ),
        # --- MIP gap ---
        DecisionRule(
            "mip_gap",
            lambda r: r.details.get("gap", 0) > 10.0,
            ["constraint_tightening", "valid_inequalities", "warm_starting"],
        ),
        DecisionRule(
            "mip_gap",
            lambda r: 5.0 < r.details.get("gap", 0) <= 10.0,
            ["constraint_tightening", "warm_starting"],
        ),
        # --- Symmetry ---
        DecisionRule(
            "symmetry",
            lambda r: r.details.get("has_symmetry", False),
            ["symmetry_breaking", "branching_priorities"],
        ),
        DecisionRule(
            "symmetry",
            lambda r: (not r.details.get("has_symmetry", False))
                      and r.details.get("binary_ratio", 0) >= 0.5,
            ["symmetry_breaking"],
        ),
        # --- Slow root LP ---
        DecisionRule(
            "slow_root_lp",
            lambda r: r.details.get("runtime", 0) > 10.0
                      and r.details.get("nodes", 999) <= 100,
            ["new_variables", "rescale", "solver_params"],
        ),
        # --- Dense matrix ---
        DecisionRule(
            "density",
            lambda r: r.details.get("density", 0) > 0.2,
            ["new_variables", "lazy_constraints"],
        ),
        DecisionRule(
            "density",
            lambda r: 0.1 < r.details.get("density", 0) <= 0.2,
            ["lazy_constraints"],
        ),
    ]

    def decide(self, analysis_results: list[AnalysisResult]) -> list[str]:
        """
        Return an ordered list of fix names to try (deduplicated, highest-priority first).

        Args:
            analysis_results: Results from all analyzers.

        Returns:
            Ordered list of fix names. Always includes 'solver_params' as a fallback.
        """
        seen: set[str] = set()
        fixes: list[str] = []

        for result in analysis_results:
            if not result.is_problem:
                continue
            for rule in self.RULES:
                if rule.analyzer_name == result.analyzer_name and rule.condition(result):
                    for fix_name in rule.fix_names:
                        if fix_name not in seen:
                            fixes.append(fix_name)
                            seen.add(fix_name)

        # Always append solver_params as a fallback
        if "solver_params" not in seen:
            fixes.append("solver_params")

        return fixes
