"""
CodeModifier: Applies and reverts source code modifications.

Handles three kinds of modifications:
1. Parameter insertion — add model.setParam() calls before optimize()
2. Timing hook — inject benchmarking code that writes runtime/status to JSON
3. MPS export hook — inject model.write() to export model for profiling

All modifications use line-based insertion to preserve formatting.
"""

from pathlib import Path

from server.api.agent.general.repo_types import CodeModification, GurobiCallSite

# Filename conventions for injected artifacts
BENCHMARK_JSON = "__agent_benchmark__.json"
MODEL_MPS = "__agent_model__.mps"
GUROBI_LOG = "__agent_gurobi__.log"


class CodeModifier:
    """Applies and reverts source code modifications."""

    def __init__(self, verbose: bool = False):
        self.verbose = verbose

    def log(self, msg: str):
        if self.verbose:
            print(f"[CodeModifier] {msg}")

    def apply_params(
        self,
        call_site: GurobiCallSite,
        params: dict,
    ) -> CodeModification:
        """
        Insert model.setParam() calls before the optimize() line.

        Args:
            call_site: Where to insert parameters.
            params: Dict of Gurobi parameter name -> value.

        Returns:
            CodeModification with original content saved for revert.
        """
        file_path = call_site.file_path
        original = Path(file_path).read_text(encoding="utf-8")
        lines = original.splitlines(keepends=True)

        # Build insertion block
        indent = call_site.indent
        mv = call_site.model_var_name
        insert_lines = [f"{indent}# Gurobi params (auto-tuned by GurobiAgent)\n"]
        for param_name, value in params.items():
            if isinstance(value, str):
                insert_lines.append(f'{indent}{mv}.setParam("{param_name}", "{value}")\n')
            else:
                insert_lines.append(f'{indent}{mv}.setParam("{param_name}", {value})\n')

        # Insert before the optimize() line (0-indexed)
        insert_idx = call_site.optimize_line - 1
        new_lines = lines[:insert_idx] + insert_lines + lines[insert_idx:]
        modified = "".join(new_lines)

        Path(file_path).write_text(modified, encoding="utf-8")

        self.log(f"Inserted {len(params)} params in {file_path}:{call_site.optimize_line}")

        return CodeModification(
            file_path=file_path,
            original_content=original,
            modified_content=modified,
            params_inserted=params,
            description=f"setParam: {params}",
        )

    def apply_timing_hook(self, call_site: GurobiCallSite) -> CodeModification:
        """
        Inject timing + benchmark capture code around optimize().

        Replaces the optimize() call with:
          1. Enable Gurobi output logging to file
          2. Record start time
          3. model.optimize()
          4. Record end time
          5. Write benchmark JSON with runtime, status, obj_val, node_count
          6. Write Gurobi log to file

        Returns:
            CodeModification for revert.
        """
        file_path = call_site.file_path
        original = Path(file_path).read_text(encoding="utf-8")
        lines = original.splitlines(keepends=True)

        indent = call_site.indent
        mv = call_site.model_var_name
        opt_idx = call_site.optimize_line - 1  # 0-indexed

        # The original optimize line
        original_opt_line = lines[opt_idx]

        # Build replacement block
        replacement = []
        replacement.append(f"{indent}# === GurobiAgent timing hook ===\n")
        replacement.append(f"{indent}import time as __agent_time__\n")
        replacement.append(f"{indent}import json as __agent_json__\n")
        replacement.append(f"{indent}import os as __agent_os__\n")
        replacement.append(f"{indent}{mv}.Params.OutputFlag = 1\n")
        replacement.append(f'{indent}{mv}.Params.LogFile = "{GUROBI_LOG}"\n')
        replacement.append(f"{indent}__agent_t0__ = __agent_time__.time()\n")
        replacement.append(original_opt_line)  # Keep original optimize() call
        replacement.append(f"{indent}__agent_t1__ = __agent_time__.time()\n")
        replacement.append(f"{indent}__agent_bench__ = {{\n")
        replacement.append(f'{indent}    "runtime": __agent_t1__ - __agent_t0__,\n')
        replacement.append(f'{indent}    "status": {mv}.Status,\n')
        replacement.append(f'{indent}    "obj_value": {mv}.ObjVal if {mv}.Status == 2 else None,\n')
        replacement.append(f'{indent}    "node_count": int({mv}.NodeCount) if hasattr({mv}, "NodeCount") else 0,\n')
        replacement.append(f"{indent}}}\n")
        replacement.append(
            f'{indent}with open("{BENCHMARK_JSON}", "w") as __agent_f__:\n'
        )
        replacement.append(f"{indent}    __agent_json__.dump(__agent_bench__, __agent_f__)\n")
        replacement.append(f"{indent}# Read Gurobi log and append to benchmark\n")
        replacement.append(f'{indent}if __agent_os__.path.exists("{GUROBI_LOG}"):\n')
        replacement.append(f'{indent}    with open("{GUROBI_LOG}") as __agent_lf__:\n')
        replacement.append(f"{indent}        __agent_bench__[\"gurobi_log\"] = __agent_lf__.read()\n")
        replacement.append(
            f'{indent}    with open("{BENCHMARK_JSON}", "w") as __agent_f__:\n'
        )
        replacement.append(f"{indent}        __agent_json__.dump(__agent_bench__, __agent_f__)\n")
        replacement.append(f"{indent}# === End timing hook ===\n")

        new_lines = lines[:opt_idx] + replacement + lines[opt_idx + 1:]
        modified = "".join(new_lines)

        Path(file_path).write_text(modified, encoding="utf-8")
        self.log(f"Injected timing hook in {file_path}:{call_site.optimize_line}")

        return CodeModification(
            file_path=file_path,
            original_content=original,
            modified_content=modified,
            description="timing hook",
        )

    def apply_mps_export(self, call_site: GurobiCallSite) -> CodeModification:
        """
        Inject model.write("__agent_model__.mps") before optimize().

        This captures the model at solve time so we can profile it in our process.

        Returns:
            CodeModification for revert.
        """
        file_path = call_site.file_path
        original = Path(file_path).read_text(encoding="utf-8")
        lines = original.splitlines(keepends=True)

        indent = call_site.indent
        mv = call_site.model_var_name
        opt_idx = call_site.optimize_line - 1

        export_line = f'{indent}{mv}.write("{MODEL_MPS}")  # GurobiAgent: export model\n'
        new_lines = lines[:opt_idx] + [export_line] + lines[opt_idx:]
        modified = "".join(new_lines)

        Path(file_path).write_text(modified, encoding="utf-8")
        self.log(f"Injected MPS export in {file_path}:{call_site.optimize_line}")

        return CodeModification(
            file_path=file_path,
            original_content=original,
            modified_content=modified,
            description="MPS export",
        )

    def apply_timing_hook_to_current(
        self,
        call_site: GurobiCallSite,
    ) -> CodeModification | None:
        """
        Apply a timing hook to the file as it currently exists on disk.

        Unlike apply_timing_hook(), this method finds the optimize() call by
        pattern search rather than the stored line number, so it works correctly
        even when a prior fix has inserted or removed lines before optimize().

        Returns:
            CodeModification whose original_content is the pre-hook (post-fix)
            file content, or None if the optimize() call could not be found.
        """
        file_path = call_site.file_path
        current = Path(file_path).read_text(encoding="utf-8")
        lines = current.splitlines(keepends=True)

        # Find optimize() by scanning (robust to shifted line numbers)
        pattern = f"{call_site.model_var_name}.optimize("
        opt_idx = None
        for i, line in enumerate(lines):
            if pattern in line:
                opt_idx = i
                break

        if opt_idx is None:
            self.log(f"Could not find {pattern} in {file_path}, skipping timing hook")
            return None

        original_opt_line = lines[opt_idx]
        # Detect indent from the found line
        indent = original_opt_line[: len(original_opt_line) - len(original_opt_line.lstrip())]
        mv = call_site.model_var_name

        replacement = []
        replacement.append(f"{indent}# === GurobiAgent timing hook ===\n")
        replacement.append(f"{indent}import time as __agent_time__\n")
        replacement.append(f"{indent}import json as __agent_json__\n")
        replacement.append(f"{indent}import os as __agent_os__\n")
        replacement.append(f"{indent}{mv}.Params.OutputFlag = 1\n")
        replacement.append(f'{indent}{mv}.Params.LogFile = "{GUROBI_LOG}"\n')
        replacement.append(f"{indent}__agent_t0__ = __agent_time__.time()\n")
        replacement.append(original_opt_line)
        replacement.append(f"{indent}__agent_t1__ = __agent_time__.time()\n")
        replacement.append(f"{indent}__agent_bench__ = {{\n")
        replacement.append(f'{indent}    "runtime": __agent_t1__ - __agent_t0__,\n')
        replacement.append(f'{indent}    "status": {mv}.Status,\n')
        replacement.append(f'{indent}    "obj_value": {mv}.ObjVal if {mv}.Status == 2 else None,\n')
        replacement.append(f'{indent}    "node_count": int({mv}.NodeCount) if hasattr({mv}, "NodeCount") else 0,\n')
        replacement.append(f"{indent}}}\n")
        replacement.append(f'{indent}if __agent_os__.path.exists("{GUROBI_LOG}"):\n')
        replacement.append(f'{indent}    with open("{GUROBI_LOG}") as __agent_lf__:\n')
        replacement.append(f"{indent}        __agent_bench__[\"gurobi_log\"] = __agent_lf__.read()\n")
        replacement.append(
            f'{indent}with open("{BENCHMARK_JSON}", "w") as __agent_f__:\n'
        )
        replacement.append(f"{indent}    __agent_json__.dump(__agent_bench__, __agent_f__)\n")
        replacement.append(f"{indent}# === End timing hook ===\n")

        new_lines = lines[:opt_idx] + replacement + lines[opt_idx + 1:]
        modified = "".join(new_lines)

        Path(file_path).write_text(modified, encoding="utf-8")
        self.log(f"Injected timing hook (current) in {file_path} (found at line {opt_idx + 1})")

        return CodeModification(
            file_path=file_path,
            original_content=current,   # pre-hook, post-fix state
            modified_content=modified,
            description="timing hook",
        )

    def revert(self, modification: CodeModification) -> None:
        """Restore a file to its original content."""
        Path(modification.file_path).write_text(
            modification.original_content, encoding="utf-8"
        )
        self.log(f"Reverted {modification.file_path} ({modification.description})")

    def apply_combined_hook(self, call_site: GurobiCallSite) -> CodeModification:
        """
        Inject both MPS export and timing hook in a single modification.

        This is the common case: export the model for profiling, then time the solve,
        and capture the Gurobi log for log-guided improvement selection.

        Returns:
            CodeModification for revert.
        """
        file_path = call_site.file_path
        original = Path(file_path).read_text(encoding="utf-8")
        lines = original.splitlines(keepends=True)

        indent = call_site.indent
        mv = call_site.model_var_name
        opt_idx = call_site.optimize_line - 1
        original_opt_line = lines[opt_idx]

        replacement = []
        replacement.append(f"{indent}# === GurobiAgent combined hook ===\n")
        replacement.append(f"{indent}import time as __agent_time__\n")
        replacement.append(f"{indent}import json as __agent_json__\n")
        replacement.append(f"{indent}import os as __agent_os__\n")
        # Export MPS before solve
        replacement.append(f'{indent}{mv}.write("{MODEL_MPS}")  # Export for profiling\n')
        # Enable logging
        replacement.append(f"{indent}{mv}.Params.OutputFlag = 1\n")
        replacement.append(f'{indent}{mv}.Params.LogFile = "{GUROBI_LOG}"\n')
        # Time the solve
        replacement.append(f"{indent}__agent_t0__ = __agent_time__.time()\n")
        replacement.append(original_opt_line)
        replacement.append(f"{indent}__agent_t1__ = __agent_time__.time()\n")
        # Write benchmark results
        replacement.append(f"{indent}__agent_bench__ = {{\n")
        replacement.append(f'{indent}    "runtime": __agent_t1__ - __agent_t0__,\n')
        replacement.append(f'{indent}    "status": {mv}.Status,\n')
        replacement.append(f'{indent}    "obj_value": {mv}.ObjVal if {mv}.Status == 2 else None,\n')
        replacement.append(f'{indent}    "node_count": int({mv}.NodeCount) if hasattr({mv}, "NodeCount") else 0,\n')
        replacement.append(f"{indent}}}\n")
        # Read Gurobi log and include in benchmark JSON
        replacement.append(f'{indent}if __agent_os__.path.exists("{GUROBI_LOG}"):\n')
        replacement.append(f'{indent}    with open("{GUROBI_LOG}") as __agent_lf__:\n')
        replacement.append(f"{indent}        __agent_bench__[\"gurobi_log\"] = __agent_lf__.read()\n")
        replacement.append(
            f'{indent}with open("{BENCHMARK_JSON}", "w") as __agent_f__:\n'
        )
        replacement.append(f"{indent}    __agent_json__.dump(__agent_bench__, __agent_f__)\n")
        replacement.append(f"{indent}# === End combined hook ===\n")

        new_lines = lines[:opt_idx] + replacement + lines[opt_idx + 1:]
        modified = "".join(new_lines)

        Path(file_path).write_text(modified, encoding="utf-8")
        self.log(f"Injected combined hook in {file_path}:{call_site.optimize_line}")

        return CodeModification(
            file_path=file_path,
            original_content=original,
            modified_content=modified,
            description="combined MPS export + timing + log capture",
        )
