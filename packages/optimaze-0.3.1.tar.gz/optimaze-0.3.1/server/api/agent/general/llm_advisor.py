"""
LLMAdvisor: Uses Claude to suggest formulation-level code improvements for Gurobi models.

Analyzes source code + Gurobi log + model profile to suggest targeted code diffs
that tighten LP relaxations, break symmetry, add valid inequalities, etc.
Suggestions are validated (anchor matching + AST syntax check) before sandbox testing.
Retries once on validation failure with targeted error feedback.
"""

import ast
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from server.api.agent.general.repo_types import (
    CodeModification,
    GurobiCallSite,
    LLMCodeChange,
    LLMCodeImprovement,
)
from server.api.agent.general.types import ProblemProfile


@dataclass
class LLMAdvisorConfig:
    """Configuration for the LLM advisor."""

    api_key: str = ""  # Falls back to ANTHROPIC_API_KEY
    model: str = "claude-sonnet-4-20250514"
    temperature: float = 1.0  # Required for extended thinking


SYSTEM_PROMPT = """\
You are an expert Operations Research engineer specializing in Gurobi optimization.
Your task is to analyze Gurobi model source code and suggest formulation-level code \
improvements that will reduce solve time while preserving solution correctness.

# Improvement Categories with Examples

## 1. Big-M Tightening
Replace overly large M values with problem-specific tight bounds.

BAD:
```python
model.addConstr(x[i] <= 100000 * y[i])  # M = 100000 is way too large
```
GOOD:
```python
model.addConstr(x[i] <= demand[i] * y[i])  # M = demand[i] is the tightest valid bound
```
Why: Tight big-M values dramatically strengthen the LP relaxation. Loose big-M creates \
a huge gap between the LP bound and the integer optimum, causing excessive branching.

## 2. Symmetry Breaking
Add ordering constraints on interchangeable (symmetric) variables.

BAD:
```python
# Facilities f1, f2, f3 are identical — solver wastes time exploring permutations
y = model.addVars(n_facilities, vtype=GRB.BINARY, name="open")
```
GOOD:
```python
y = model.addVars(n_facilities, vtype=GRB.BINARY, name="open")
# Break symmetry: if facilities are identical, force lexicographic ordering
for i in range(n_facilities - 1):
    model.addConstr(y[i] >= y[i+1], name=f"sym_break_{i}")
```
Why: Symmetric variables cause the B&B tree to have many equivalent nodes. Ordering \
constraints prune symmetric subtrees without cutting off any optimal solution.

## 3. Valid Inequalities
Add constraints that tighten the LP relaxation without cutting off integer solutions.

Example — cover inequality for knapsack:
```python
# If items {1,2,3} together exceed capacity, at most 2 can be selected
model.addConstr(x[1] + x[2] + x[3] <= 2, name="cover_cut")
```

Example — clique constraint from conflict structure:
```python
# If jobs i,j,k conflict (can't run simultaneously), add clique cut
model.addConstr(y[i] + y[j] + y[k] <= 1, name="clique_cut")
```
Why: Valid inequalities tighten the LP relaxation, reducing the gap and the B&B tree size.

## 4. Branching Priorities
Tell Gurobi to branch on the most important variables first.

```python
# Set high priority on facility opening decisions (drive the structure)
for i in range(n_facilities):
    y[i].BranchPriority = 10
# Assignment variables get default priority (0)
```
Why: Good branching order can cut node count by 50%+ by resolving key decisions early.

## 5. Warm Starting
Provide a feasible starting solution from a greedy heuristic.

```python
# Greedy: open the cheapest facilities until demand is met
opened = greedy_solution(costs, demands)
for i in range(n_facilities):
    y[i].Start = 1.0 if i in opened else 0.0
for i, j in assignments:
    x[i, j].Start = 1.0 if j == assigned_to[i] else 0.0
```
Why: A good MIP start gives Gurobi an upper bound immediately, enabling aggressive pruning.

## 6. Lazy Constraints
Convert rarely-binding constraints to lazy constraints.

```python
# Subtour elimination constraints: most won't be active in optimal solution
model.addConstr(gp.quicksum(x[i,j] for i,j in edges_in_S) <= len(S) - 1,
                name=f"subtour_{S}", lazy=1)
```
Why: Lazy constraints are only checked when an integer solution is found, reducing LP size.

# Bottleneck → Action Mapping

Use the solver log metrics to choose what to suggest:
- **High node count (>1000)**: symmetry breaking, valid inequalities, branching priorities
- **Large root gap (>5%)**: constraint tightening, bound tightening, big-M improvement
- **Slow root LP**: presolve hints, variable reformulation
- **Large coefficient range (>1e6)**: big-M tightening — the #1 priority

# old_code Precision Rules (CRITICAL)

Your `old_code` field must be an EXACT substring of the source file, including:
- Exact whitespace and indentation (spaces vs tabs matter)
- No trailing whitespace that doesn't exist in the source
- Matched line endings

Best practices for `old_code`:
- Keep anchors SHORT but UNIQUE — 1-3 lines is ideal
- Pick lines with distinctive variable names or string literals
- Do NOT include blank lines or comment-only lines in anchors (they may appear elsewhere)
- Test uniqueness: does this exact string appear only once in the file?

BAD anchor (too generic):
```
model.addConstr(x <= M * y)
```
GOOD anchor (unique context):
```
model.addConstr(x[i] <= BIG_M * y[i], name=f"link_{i}")
```

# General Guidelines
- Suggest ONLY changes that preserve the mathematical correctness of the model
- Each suggestion must be a precise code diff (old_code → new_code)
- Prefer small, targeted changes over large rewrites
- Focus on changes with the highest expected speedup based on the bottleneck analysis
- If the model is already well-formulated, suggest fewer or no changes
"""

SUGGEST_IMPROVEMENT_TOOL = {
    "name": "suggest_improvement",
    "description": (
        "Suggest a formulation-level code improvement for a Gurobi model. "
        "Call this tool once per suggestion."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "name": {
                "type": "string",
                "description": "Short identifier, e.g. 'symmetry_breaking' or 'tighten_big_m'",
            },
            "category": {
                "type": "string",
                "enum": [
                    "constraint_tightening",
                    "symmetry_breaking",
                    "valid_inequalities",
                    "bound_tightening",
                    "big_m_improvement",
                    "warm_starting",
                    "variable_reformulation",
                    "branching_priorities",
                    "lazy_constraints",
                    "decomposition_hints",
                ],
                "description": "Category of the improvement",
            },
            "description": {
                "type": "string",
                "description": "One-line description of what this change does",
            },
            "reasoning": {
                "type": "string",
                "description": (
                    "Detailed analysis of why this change should help. "
                    "Reference specific model characteristics and log metrics."
                ),
            },
            "changes": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "old_code": {
                            "type": "string",
                            "description": "Exact code substring to find in the source file",
                        },
                        "new_code": {
                            "type": "string",
                            "description": "Replacement code",
                        },
                        "description": {
                            "type": "string",
                            "description": "What this specific change does",
                        },
                    },
                    "required": ["old_code", "new_code"],
                },
                "description": "List of code replacements to apply",
            },
            "risk_level": {
                "type": "string",
                "enum": ["low", "medium", "high"],
                "description": "Risk of breaking the model or worsening performance",
            },
            "expected_impact": {
                "type": "string",
                "description": "Expected performance impact, e.g. '10-30% speedup on MIP gap closure'",
            },
            "preserves_semantics": {
                "type": "boolean",
                "description": (
                    "Whether this change preserves the optimal solution. "
                    "False for heuristic/approximation changes."
                ),
            },
        },
        "required": [
            "name",
            "category",
            "description",
            "reasoning",
            "changes",
            "risk_level",
            "preserves_semantics",
        ],
    },
}


class LLMAdvisor:
    """Uses Claude to suggest formulation-level code improvements for Gurobi models."""

    def __init__(self, config: LLMAdvisorConfig | None = None, verbose: bool = False):
        self.config = config or LLMAdvisorConfig()
        self.verbose = verbose
        self._client = None

    def log(self, msg: str):
        if self.verbose:
            print(f"[LLMAdvisor] {msg}")

    @property
    def client(self):
        """Lazily initialize the Anthropic client."""
        if self._client is None:
            import anthropic

            api_key = self.config.api_key or os.environ.get("ANTHROPIC_API_KEY", "")
            self._client = anthropic.Anthropic(api_key=api_key)
        return self._client

    def suggest_improvements(
        self,
        source_code: str,
        call_site: GurobiCallSite,
        profile: ProblemProfile,
        gurobi_log: str = "",
        focus_category: Optional[str] = None,
    ) -> list[LLMCodeImprovement]:
        """
        Ask the LLM to suggest formulation-level code improvements.

        Args:
            source_code: Full source code of the file containing the model.
            call_site: The optimize() call site metadata.
            profile: Model profile from the profiler.
            gurobi_log: Captured Gurobi solver log (truncated if needed).
            focus_category: If set, restricts suggestions to this category
                (e.g. "big_m_improvement", "decomposition_hints").

        Returns:
            List of validated LLMCodeImprovement objects.
        """
        user_prompt = self._build_user_prompt(
            source_code, call_site, profile, gurobi_log, focus_category=focus_category
        )

        improvements = self._call_llm(user_prompt)

        # Validate each suggestion (anchor match + AST syntax check)
        validated = []
        failed = []
        for imp in improvements:
            ok, error = self._validate_improvement(imp, source_code)
            if ok:
                validated.append(imp)
                self.log(f"  Validated: {imp.name} ({imp.category})")
            else:
                failed.append((imp, error))
                self.log(f"  Rejected: {imp.name} — {error}")

        # Step 3: Retry failed suggestions once with error feedback
        if failed:
            retried = self._retry_failed(failed, source_code, user_prompt)
            validated.extend(retried)

        return validated

    def _call_llm(self, user_prompt: str) -> list[LLMCodeImprovement]:
        """Make the API call with extended thinking and parse results."""
        self.log(f"Requesting suggestions from {self.config.model}...")

        try:
            response = self.client.messages.create(
                model=self.config.model,
                max_tokens=16000,
                temperature=self.config.temperature,
                thinking={
                    "type": "enabled",
                    "budget_tokens": 10000,
                },
                system=SYSTEM_PROMPT,
                tools=[SUGGEST_IMPROVEMENT_TOOL],
                messages=[{"role": "user", "content": user_prompt}],
            )
        except Exception as e:
            self.log(f"API call failed: {e}")
            return []

        # Parse tool calls into improvements
        improvements = []
        for block in response.content:
            if block.type == "tool_use" and block.name == "suggest_improvement":
                imp = self._parse_tool_call(block.input)
                if imp is not None:
                    improvements.append(imp)

        self.log(f"Received {len(improvements)} suggestion(s)")
        return improvements

    def apply_improvement(
        self,
        improvement: LLMCodeImprovement,
        call_site: GurobiCallSite,
    ) -> CodeModification:
        """
        Apply an LLM code improvement to the source file.

        Args:
            improvement: The LLM suggestion to apply.
            call_site: The call site (used for file path).

        Returns:
            CodeModification with original content for revert.
        """
        file_path = call_site.file_path
        original = Path(file_path).read_text(encoding="utf-8")

        modified = original
        for change in improvement.changes:
            modified = modified.replace(change.old_code, change.new_code, 1)

        Path(file_path).write_text(modified, encoding="utf-8")
        self.log(f"Applied LLM improvement '{improvement.name}' to {file_path}")

        return CodeModification(
            file_path=file_path,
            original_content=original,
            modified_content=modified,
            description=f"LLM: {improvement.name}",
        )

    def apply_improvement_with_timing_hook(
        self,
        improvement: LLMCodeImprovement,
        call_site: GurobiCallSite,
        code_modifier,
    ) -> CodeModification:
        """
        Apply LLM changes and then inject the timing hook.

        The timing hook needs to find the optimize() line, which may have shifted
        due to LLM code changes. This method:
        1. Saves the true original
        2. Applies LLM changes
        3. Finds the new optimize() line position
        4. Applies the timing hook on the adjusted call site

        Returns:
            CodeModification that reverts to the true original (before LLM changes).
        """
        file_path = call_site.file_path
        true_original = Path(file_path).read_text(encoding="utf-8")

        # Apply LLM changes
        modified = true_original
        for change in improvement.changes:
            modified = modified.replace(change.old_code, change.new_code, 1)
        Path(file_path).write_text(modified, encoding="utf-8")

        # Find the new optimize() line position
        adjusted_site = self._find_adjusted_call_site(modified, call_site)

        # Apply timing hook on the adjusted site
        timing_mod = code_modifier.apply_timing_hook(adjusted_site)

        # Return a modification that reverts to the true original
        return CodeModification(
            file_path=file_path,
            original_content=true_original,
            modified_content=timing_mod.modified_content,
            description=f"LLM: {improvement.name} + timing hook",
        )

    def _build_user_prompt(
        self,
        source_code: str,
        call_site: GurobiCallSite,
        profile: ProblemProfile,
        gurobi_log: str,
        focus_category: Optional[str] = None,
    ) -> str:
        """Build the user prompt with source code, profile, and log."""
        parts = []

        parts.append("## Source Code\n")
        parts.append(f"File: {os.path.basename(call_site.file_path)}")
        parts.append(f"Model variable: `{call_site.model_var_name}`")
        parts.append(f"optimize() call at line {call_site.optimize_line}\n")
        parts.append("```python")
        parts.append(source_code)
        parts.append("```\n")

        parts.append("## Model Profile\n")
        parts.append(f"- Problem type: {profile.problem_type.name}")
        parts.append(f"- Variables: {profile.n_vars} ({profile.n_binary} binary, "
                      f"{profile.n_integer} integer, {profile.n_continuous} continuous)")
        parts.append(f"- Constraints: {profile.n_constrs} ({profile.n_linear} linear, "
                      f"{profile.n_quadratic} quadratic)")
        parts.append(f"- Nonzeros: {profile.n_nonzeros}")
        parts.append(f"- Density: {profile.density:.4f}")
        parts.append(f"- Coefficient range ratio: {profile.coef_range_ratio:.1f}")
        parts.append(f"- Objective: {profile.obj_sense}")

        if profile.detected_structures:
            structs = ", ".join(s.name for s in profile.detected_structures)
            parts.append(f"- Detected structures: {structs}")
        if profile.has_symmetry:
            parts.append(f"- Symmetry detected: {profile.symmetry_groups} groups")
        if profile.n_components > 1:
            parts.append(f"- Block structure: {profile.n_components} components "
                          f"(largest: {profile.largest_component_pct:.0%})")

        if profile.log_nodes > 0 or profile.log_runtime > 0:
            parts.append("\n## Solver Log Metrics\n")
            parts.append(f"- Nodes explored: {profile.log_nodes}")
            parts.append(f"- Runtime: {profile.log_runtime:.1f}s")
            parts.append(f"- MIP gap: {profile.log_gap:.2f}%")
            if profile.log_presolve_removed_rows > 0:
                parts.append(f"- Presolve removed: {profile.log_presolve_removed_rows} rows, "
                              f"{profile.log_presolve_removed_cols} cols")

        # Step 5: Profile interpretation layer
        interpretation = self._interpret_profile(profile)
        if interpretation:
            parts.append("\n## Bottleneck Analysis\n")
            for line in interpretation:
                parts.append(f"- {line}")

        # Step 6: Smart log truncation
        if gurobi_log:
            truncated = self._truncate_log(gurobi_log)
            parts.append("\n## Gurobi Solver Log\n")
            parts.append("```")
            parts.append(truncated)
            parts.append("```")

        if focus_category:
            parts.append(
                f"\nFocus only on `{focus_category}` improvements. "
                "Suggest as many formulation-level code improvements of this type as you can "
                "identify using the suggest_improvement tool. Only suggest changes you are "
                "confident about."
            )
        else:
            parts.append(
                "\nSuggest the best formulation-level code improvements you can identify "
                "using the suggest_improvement tool. We will benchmark each one. "
                "Focus on the highest-impact changes based on the bottleneck analysis "
                "and solver log. Only suggest changes you are confident about."
            )

        return "\n".join(parts)

    def _parse_tool_call(self, tool_input: dict) -> Optional[LLMCodeImprovement]:
        """Parse a tool call response into an LLMCodeImprovement."""
        try:
            changes = [
                LLMCodeChange(
                    old_code=c["old_code"],
                    new_code=c["new_code"],
                    description=c.get("description", ""),
                )
                for c in tool_input.get("changes", [])
            ]

            return LLMCodeImprovement(
                name=tool_input["name"],
                category=tool_input["category"],
                description=tool_input["description"],
                reasoning=tool_input["reasoning"],
                changes=changes,
                risk_level=tool_input.get("risk_level", "medium"),
                expected_impact=tool_input.get("expected_impact", ""),
                preserves_semantics=tool_input.get("preserves_semantics", True),
            )
        except (KeyError, TypeError) as e:
            self.log(f"Failed to parse tool call: {e}")
            return None

    def _validate_improvement(
        self,
        improvement: LLMCodeImprovement,
        source_code: str,
    ) -> tuple[bool, str]:
        """
        Validate anchors exist and modified code parses as valid Python.

        Returns (True, "") on success, or (False, error_message) on failure.
        """
        if not improvement.changes:
            return False, "No changes in suggestion"

        # Check anchors exist
        working_copy = source_code
        for i, change in enumerate(improvement.changes):
            if change.old_code not in working_copy:
                return False, (
                    f"old_code anchor #{i+1} not found in source: "
                    f"{change.old_code[:80]!r}..."
                )
            working_copy = working_copy.replace(change.old_code, change.new_code, 1)

        # AST syntax validation on the modified source
        try:
            ast.parse(working_copy)
        except SyntaxError as e:
            return False, f"Modified code has syntax error: {e.msg} (line {e.lineno})"

        return True, ""

    def _retry_failed(
        self,
        failed: list[tuple[LLMCodeImprovement, str]],
        source_code: str,
        original_prompt: str,
    ) -> list[LLMCodeImprovement]:
        """
        Retry failed suggestions once with targeted error feedback.

        Sends the LLM a follow-up showing exactly what went wrong and
        the relevant source lines, asking it to fix the anchors.
        """
        self.log(f"Retrying {len(failed)} failed suggestion(s) with error feedback...")

        # Build error report
        error_parts = [
            "Your previous suggestions had validation errors. "
            "Please fix them and resubmit using the suggest_improvement tool.\n"
        ]

        for imp, error in failed:
            error_parts.append(f"## Failed: {imp.name}")
            error_parts.append(f"Error: {error}\n")
            for i, change in enumerate(imp.changes):
                error_parts.append(f"Change #{i+1} old_code was:")
                error_parts.append(f"```\n{change.old_code}\n```")
                error_parts.append(f"Change #{i+1} new_code was:")
                error_parts.append(f"```\n{change.new_code}\n```\n")

        # Show relevant source context
        error_parts.append("## Current Source Code (for reference)\n")
        error_parts.append("```python")
        error_parts.append(source_code)
        error_parts.append("```\n")
        error_parts.append(
            "Fix the old_code anchors to be exact substrings of the source. "
            "Resubmit corrected suggestions using the suggest_improvement tool."
        )

        error_prompt = "\n".join(error_parts)

        try:
            response = self.client.messages.create(
                model=self.config.model,
                max_tokens=16000,
                temperature=self.config.temperature,
                thinking={
                    "type": "enabled",
                    "budget_tokens": 10000,
                },
                system=SYSTEM_PROMPT,
                tools=[SUGGEST_IMPROVEMENT_TOOL],
                messages=[
                    {"role": "user", "content": original_prompt},
                    # Simulate the failed attempt as assistant response
                    {"role": "assistant", "content": "I'll fix the anchors based on your feedback."},
                    {"role": "user", "content": error_prompt},
                ],
            )
        except Exception as e:
            self.log(f"Retry API call failed: {e}")
            return []

        # Parse and validate retry results
        retried = []
        for block in response.content:
            if block.type == "tool_use" and block.name == "suggest_improvement":
                imp = self._parse_tool_call(block.input)
                if imp is not None:
                    ok, error = self._validate_improvement(imp, source_code)
                    if ok:
                        retried.append(imp)
                        self.log(f"  Retry validated: {imp.name} ({imp.category})")
                    else:
                        self.log(f"  Retry still failed: {imp.name} — {error}")

        self.log(f"Retry recovered {len(retried)} suggestion(s)")
        return retried

    def _interpret_profile(self, profile: ProblemProfile) -> list[str]:
        """
        Translate raw profile metrics into actionable bottleneck descriptions.

        Tells the LLM *what to focus on* rather than dumping raw numbers.
        """
        insights = []

        # Coefficient range → big-M detection
        if profile.coef_range_ratio > 1e6:
            insights.append(
                f"Large coefficient range ({profile.coef_range_ratio:.0e}) suggests big-M "
                f"constraints that could be tightened — this is the #1 priority"
            )
        elif profile.coef_range_ratio > 1e3:
            insights.append(
                f"Moderate coefficient range ({profile.coef_range_ratio:.0e}) — "
                f"check for improvable big-M values"
            )

        # Node count → LP relaxation quality
        if profile.log_nodes > 10000:
            insights.append(
                f"Very high node count ({profile.log_nodes:,}) indicates a weak LP "
                f"relaxation — symmetry breaking, valid inequalities, or branching "
                f"priorities are strongly recommended"
            )
        elif profile.log_nodes > 1000:
            insights.append(
                f"High node count ({profile.log_nodes:,}) — consider symmetry breaking, "
                f"valid inequalities, or branching priorities"
            )

        # MIP gap
        if profile.log_gap > 10:
            insights.append(
                f"Large MIP gap ({profile.log_gap:.1f}%) at termination — "
                f"bound tightening or cutting planes may help significantly"
            )
        elif profile.log_gap > 5:
            insights.append(
                f"Moderate MIP gap ({profile.log_gap:.1f}%) — constraint or "
                f"bound tightening may help"
            )

        # Binary variable ratio → symmetry opportunities
        if profile.n_vars > 0:
            binary_ratio = profile.n_binary / profile.n_vars
            if binary_ratio > 0.5 and profile.n_binary > 20:
                insights.append(
                    f"High binary variable ratio ({binary_ratio:.0%}, {profile.n_binary} "
                    f"binary vars) — check for symmetry opportunities"
                )

        # Symmetry detection
        if profile.has_symmetry:
            insights.append(
                f"Symmetry detected ({profile.symmetry_groups} groups) — "
                f"add ordering constraints or use branching priorities"
            )

        # Block structure → decomposition
        if profile.n_components > 1:
            insights.append(
                f"Block-diagonal structure ({profile.n_components} components) — "
                f"decomposition hints may help Gurobi exploit this"
            )

        # Slow runtime without many nodes → root LP is the bottleneck
        if profile.log_runtime > 10 and profile.log_nodes < 100:
            insights.append(
                f"Long runtime ({profile.log_runtime:.1f}s) with few nodes ({profile.log_nodes}) "
                f"suggests the root LP is the bottleneck — presolve hints or reformulation "
                f"may help"
            )

        if not insights:
            insights.append(
                "No obvious bottlenecks detected — model may already be well-formulated. "
                "Focus on the most impactful structural changes if any are apparent."
            )

        return insights

    @staticmethod
    def _truncate_log(gurobi_log: str, max_len: int = 3000) -> str:
        """
        Smart log truncation that keeps the most informative parts.

        Always preserves:
        - First ~1500 chars: presolve info, root relaxation
        - Last ~1500 chars: final solution, summary statistics
        """
        if len(gurobi_log) <= max_len:
            return gurobi_log

        head_len = max_len // 2
        tail_len = max_len // 2

        head = gurobi_log[:head_len]
        tail = gurobi_log[-tail_len:]

        # Cut at line boundaries to avoid partial lines
        head_end = head.rfind("\n")
        if head_end > 0:
            head = head[:head_end]

        tail_start = tail.find("\n")
        if tail_start >= 0:
            tail = tail[tail_start + 1:]

        skipped = len(gurobi_log) - len(head) - len(tail)
        return f"{head}\n\n... [{skipped} chars of B&B log skipped] ...\n\n{tail}"

    def _find_adjusted_call_site(
        self,
        modified_source: str,
        original_site: GurobiCallSite,
    ) -> GurobiCallSite:
        """
        Re-scan the modified source with the scanner to find the optimize() call.

        Uses AST parsing (same as the original scan) so it reliably handles
        any call form: model.optimize(), self.model.optimize(callback=cb), etc.
        """
        from server.api.agent.general.scanner import RepoScanner

        scanner = RepoScanner(verbose=False)
        try:
            tree = ast.parse(modified_source, filename=original_site.file_path)
            file_info = scanner._analyze_file(
                original_site.file_path, modified_source, tree
            )
            for cs in file_info["call_sites"]:
                if cs.model_var_name == original_site.model_var_name:
                    self.log(f"Re-scanned: optimize() now at line {cs.optimize_line}")
                    return cs
        except SyntaxError as e:
            self.log(f"Warning: modified source has syntax error: {e}")

        self.log("Warning: could not find optimize() in modified source, using original line")
        return original_site
