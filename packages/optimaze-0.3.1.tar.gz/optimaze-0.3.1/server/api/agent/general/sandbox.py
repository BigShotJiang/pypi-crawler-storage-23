"""
SandboxRunner: Isolated execution environment for target repos.

Creates a virtual environment, installs dependencies, and runs scripts
in a subprocess to isolate the target repo's code from ours.

Captures Gurobi logs from the benchmark JSON written by the timing hook.
"""

import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

from server.api.agent.general.code_modifier import BENCHMARK_JSON, GUROBI_LOG, MODEL_MPS
from server.api.agent.general.repo_types import SandboxRunResult


class SandboxRunner:
    """Runs target repo scripts in an isolated virtual environment."""

    def __init__(
        self,
        repo_dir: str,
        work_dir: str = "",
        verbose: bool = False,
    ):
        self.repo_dir = repo_dir
        self.work_dir = work_dir or os.path.join(repo_dir, ".gurobi_agent_work")
        self.venv_dir = os.path.join(self.work_dir, "venv")
        self.verbose = verbose
        self._setup_done = False

    def log(self, msg: str):
        if self.verbose:
            print(f"[Sandbox] {msg}")

    @property
    def python_path(self) -> str:
        """Path to the venv's Python executable."""
        if platform.system() == "Windows":
            return os.path.join(self.venv_dir, "Scripts", "python.exe")
        return os.path.join(self.venv_dir, "bin", "python")

    @property
    def pip_path(self) -> str:
        """Path to the venv's pip executable."""
        if platform.system() == "Windows":
            return os.path.join(self.venv_dir, "Scripts", "pip.exe")
        return os.path.join(self.venv_dir, "bin", "pip")

    def setup(self, timeout: float = 300.0) -> bool:
        """
        Create venv and install dependencies.

        Args:
            timeout: Max seconds for setup (default 5 min).

        Returns:
            True if setup succeeded.
        """
        os.makedirs(self.work_dir, exist_ok=True)

        # Create venv
        self.log("Creating virtual environment...")
        result = subprocess.run(
            [sys.executable, "-m", "venv", self.venv_dir],
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode != 0:
            self.log(f"Failed to create venv: {result.stderr}")
            return False

        # Upgrade pip
        self._run_pip(["install", "--upgrade", "pip"], timeout=60)

        # Install dependencies
        installed = self._install_dependencies(timeout)
        if not installed:
            self.log("Warning: Some dependencies may have failed to install")

        self._setup_done = True
        self.log("Sandbox setup complete")
        return True

    def _install_dependencies(self, timeout: float) -> bool:
        """Detect and install the repo's dependencies."""
        # Try requirements.txt first
        req_file = os.path.join(self.repo_dir, "requirements.txt")
        if os.path.isfile(req_file):
            self.log("Installing from requirements.txt...")
            return self._run_pip(
                ["install", "-r", req_file], timeout=timeout
            )

        # Try pyproject.toml (pip install .)
        pyproject = os.path.join(self.repo_dir, "pyproject.toml")
        if os.path.isfile(pyproject):
            self.log("Installing from pyproject.toml...")
            return self._run_pip(
                ["install", "-e", self.repo_dir], timeout=timeout
            )

        # Try setup.py
        setup_py = os.path.join(self.repo_dir, "setup.py")
        if os.path.isfile(setup_py):
            self.log("Installing from setup.py...")
            return self._run_pip(
                ["install", "-e", self.repo_dir], timeout=timeout
            )

        # No dependency file found — just install gurobipy
        self.log("No dependency file found, installing gurobipy only...")
        return self._run_pip(["install", "gurobipy"], timeout=60)

    def _run_pip(self, args: list[str], timeout: float = 120) -> bool:
        """Run pip in the venv."""
        try:
            result = subprocess.run(
                [self.pip_path, *args],
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=self.repo_dir,
            )
            if result.returncode != 0:
                self.log(f"pip {' '.join(args[:2])} failed: {result.stderr[:500]}")
                return False
            return True
        except subprocess.TimeoutExpired:
            self.log(f"pip timed out after {timeout}s")
            return False

    def run_script(
        self,
        script_path: str,
        timeout: float = 120.0,
    ) -> SandboxRunResult:
        """
        Run a Python script in the sandbox venv.

        The script should have been modified by CodeModifier to write
        __agent_benchmark__.json and __agent_gurobi__.log.

        Args:
            script_path: Absolute path to the .py file to run.
            timeout: Max seconds for execution.

        Returns:
            SandboxRunResult with captured outputs and parsed benchmark data.
        """
        if not self._setup_done:
            raise RuntimeError("Call setup() before run_script()")

        # Run the script from its own directory (for relative imports)
        script_dir = os.path.dirname(script_path) or self.repo_dir
        self._last_script_dir = script_dir  # Store for get_mps_path()

        # Clean up any previous artifacts (check both repo_dir and script_dir)
        for artifact in (BENCHMARK_JSON, MODEL_MPS, GUROBI_LOG):
            for search_dir in (self.repo_dir, script_dir):
                artifact_path = os.path.join(search_dir, artifact)
                if os.path.exists(artifact_path):
                    os.remove(artifact_path)

        self.log(f"Running {os.path.basename(script_path)}...")
        try:
            proc = subprocess.run(
                [self.python_path, script_path],
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=script_dir,
                env=self._get_env(),
            )
        except subprocess.TimeoutExpired:
            return SandboxRunResult(
                returncode=-1,
                stdout="",
                stderr=f"Script timed out after {timeout}s",
            )

        result = SandboxRunResult(
            returncode=proc.returncode,
            stdout=proc.stdout,
            stderr=proc.stderr,
        )

        # Parse benchmark JSON if it was written (check script_dir first, then repo_dir)
        bench_path = None
        for search_dir in (script_dir, self.repo_dir):
            candidate = os.path.join(search_dir, BENCHMARK_JSON)
            if os.path.isfile(candidate):
                bench_path = candidate
                break

        if bench_path:
            try:
                with open(bench_path) as f:
                    bench = json.load(f)
                result.runtime = bench.get("runtime")
                result.solver_status = self._status_code_to_str(bench.get("status"))
                result.obj_value = bench.get("obj_value")
                result.node_count = bench.get("node_count")
                result.gurobi_log = bench.get("gurobi_log", "")
            except (json.JSONDecodeError, KeyError) as e:
                self.log(f"Failed to parse benchmark JSON: {e}")

        # Also try reading log file directly if not in JSON
        if not result.gurobi_log:
            for search_dir in (script_dir, self.repo_dir):
                log_path = os.path.join(search_dir, GUROBI_LOG)
                if os.path.isfile(log_path):
                    result.gurobi_log = Path(log_path).read_text(
                        encoding="utf-8", errors="replace"
                    )
                    break

        if result.runtime is not None:
            self.log(
                f"  Result: {result.runtime:.3f}s, "
                f"status={result.solver_status}, "
                f"nodes={result.node_count}"
            )

        return result

    def get_mps_path(self) -> str | None:
        """Get path to exported MPS file, if it exists."""
        # Check script directory first (where artifacts are written), then repo_dir
        search_dirs = [self.repo_dir]
        if hasattr(self, '_last_script_dir'):
            search_dirs.insert(0, self._last_script_dir)

        for search_dir in search_dirs:
            mps_path = os.path.join(search_dir, MODEL_MPS)
            if os.path.isfile(mps_path):
                return mps_path
        return None

    def cleanup(self) -> None:
        """Remove sandbox artifacts (but not the venv)."""
        for artifact in (BENCHMARK_JSON, MODEL_MPS, GUROBI_LOG):
            path = os.path.join(self.repo_dir, artifact)
            if os.path.exists(path):
                os.remove(path)

    def cleanup_all(self) -> None:
        """Remove entire work directory including venv."""
        if os.path.exists(self.work_dir):
            shutil.rmtree(self.work_dir, ignore_errors=True)

    def _get_env(self) -> dict:
        """Get environment variables for subprocess, ensuring venv is used."""
        env = os.environ.copy()
        # Prepend venv bin to PATH
        if platform.system() == "Windows":
            venv_bin = os.path.join(self.venv_dir, "Scripts")
        else:
            venv_bin = os.path.join(self.venv_dir, "bin")

        env["PATH"] = venv_bin + os.pathsep + env.get("PATH", "")
        env["VIRTUAL_ENV"] = self.venv_dir
        # Remove any PYTHONHOME that might interfere
        env.pop("PYTHONHOME", None)
        return env

    @staticmethod
    def _status_code_to_str(status_code) -> str:
        """Convert Gurobi status code to string."""
        if status_code is None:
            return "UNKNOWN"
        status_map = {
            1: "LOADED",
            2: "OPTIMAL",
            3: "INFEASIBLE",
            4: "INF_OR_UNBD",
            5: "UNBOUNDED",
            6: "CUTOFF",
            7: "ITERATION_LIMIT",
            8: "NODE_LIMIT",
            9: "TIME_LIMIT",
            10: "SOLUTION_LIMIT",
            11: "INTERRUPTED",
            12: "NUMERIC",
            13: "SUBOPTIMAL",
            14: "INPROGRESS",
            15: "USER_OBJ_LIMIT",
            16: "WORK_LIMIT",
            17: "MEM_LIMIT",
        }
        return status_map.get(int(status_code), f"STATUS_{status_code}")
