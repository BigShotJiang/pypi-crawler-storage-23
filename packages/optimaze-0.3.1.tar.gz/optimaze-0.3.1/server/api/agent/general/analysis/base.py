"""Base types for the analysis layer."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import ClassVar

from server.api.agent.general.types import ProblemProfile


@dataclass
class AnalysisResult:
    """Result from a single analyzer."""

    analyzer_name: str      # e.g. "coeff_range"
    is_problem: bool
    context: str            # human-readable, e.g. "Coefficient range 1.2e+08 — likely Big-M"
    severity: float         # 0.0–1.0
    details: dict = field(default_factory=dict)  # raw metrics for decision logic


class BaseAnalyzer(ABC):
    """Abstract base class for all analyzers."""

    name: ClassVar[str]  # must be set in subclass

    @abstractmethod
    def analyze(self, log: str, profile: ProblemProfile) -> AnalysisResult:
        """
        Analyze the model log and profile for a specific problem type.

        Args:
            log: Raw Gurobi solver log string.
            profile: ProblemProfile built from MPS + log.

        Returns:
            AnalysisResult describing whether a problem was detected.
        """
        ...
