"""Analyzer: detects high B&B node counts from the solver log."""

from typing import ClassVar

from server.api.agent.general.analysis.base import AnalysisResult, BaseAnalyzer
from server.api.agent.general.types import ProblemProfile


class NodeCountAnalyzer(BaseAnalyzer):
    """
    Detects high branch-and-bound node counts indicating a weak LP relaxation.

    High node counts suggest the LP relaxation bound is far from the integer
    optimum, and solver parameter tuning (cuts, heuristics, presolve) may help.
    """

    name: ClassVar[str] = "node_count"

    # Configurable threshold (lowered for testing)
    threshold: ClassVar[int] = 10

    def analyze(self, log: str, profile: ProblemProfile) -> AnalysisResult:
        count = profile.log_nodes
        log_gap = profile.log_gap

        is_problem = count > self.threshold

        if count > 100_000:
            context = (
                f"Very high node count ({count:,}, gap={log_gap:.1f}%) — "
                f"LP relaxation is extremely weak; solver parameter tuning is critical"
            )
            severity = 1.0
        elif count > 10_000:
            context = (
                f"High node count ({count:,}, gap={log_gap:.1f}%) — "
                f"solver parameter tuning strongly recommended"
            )
            severity = 0.8
        elif count > 1_000:
            context = (
                f"Elevated node count ({count:,}, gap={log_gap:.1f}%) — "
                f"solver parameter tuning may improve performance"
            )
            severity = 0.5
        else:
            context = f"Node count ({count:,}) within normal range"
            severity = 0.0

        return AnalysisResult(
            analyzer_name=self.name,
            is_problem=is_problem,
            context=context,
            severity=severity,
            details={
                "count": count,
                "log_gap": log_gap,
            },
        )
