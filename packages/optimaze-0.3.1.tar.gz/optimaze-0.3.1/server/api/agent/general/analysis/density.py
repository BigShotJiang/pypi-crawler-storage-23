"""Analyzer: detects high matrix density that can slow LP solves."""

from typing import ClassVar

from server.api.agent.general.analysis.base import AnalysisResult, BaseAnalyzer
from server.api.agent.general.types import ProblemProfile


class DensityAnalyzer(BaseAnalyzer):
    """
    Detects dense constraint matrices.

    High density (many nonzeros per variable/constraint) makes LP solves
    more expensive and can be alleviated by variable aggregation, column
    generation, or constraint reformulation.
    """

    name: ClassVar[str] = "density"

    # density = nonzeros / (n_vars * n_constrs); > 0.1 is considered dense
    threshold: ClassVar[float] = 0.1

    def analyze(self, log: str, profile: ProblemProfile) -> AnalysisResult:
        density = profile.density
        avg_vars_per_constr = profile.avg_vars_per_constr

        is_problem = density > self.threshold

        if density > 0.5:
            context = (
                f"Very dense constraint matrix (density={density:.3f}, "
                f"avg {avg_vars_per_constr:.1f} vars/constraint) — "
                f"LP solves are expensive; variable aggregation or reformulation may help"
            )
            severity = 0.9
        elif density > 0.2:
            context = (
                f"Dense constraint matrix (density={density:.3f}, "
                f"avg {avg_vars_per_constr:.1f} vars/constraint) — "
                f"consider variable elimination or reformulation"
            )
            severity = 0.6
        elif density > 0.1:
            context = (
                f"Moderately dense matrix (density={density:.3f}) — "
                f"minor reformulation may improve LP solve speed"
            )
            severity = 0.3
        else:
            context = (
                f"Sparse constraint matrix (density={density:.4f}) — LP structure is efficient"
            )
            severity = 0.0

        return AnalysisResult(
            analyzer_name=self.name,
            is_problem=is_problem,
            context=context,
            severity=severity,
            details={
                "density": density,
                "avg_vars_per_constr": avg_vars_per_constr,
                "n_nonzeros": profile.n_nonzeros,
            },
        )
