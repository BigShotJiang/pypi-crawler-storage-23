"""Analyzer: detects models with high constraint counts."""

from typing import ClassVar

from server.api.agent.general.analysis.base import AnalysisResult, BaseAnalyzer
from server.api.agent.general.types import ProblemProfile


class ConstraintCountAnalyzer(BaseAnalyzer):
    """
    Detects models with a large number of constraints.

    Very large constraint counts may benefit from decomposition approaches
    such as Benders' decomposition or Lagrangian relaxation.
    """

    name: ClassVar[str] = "constraint_count"

    # Configurable threshold
    threshold: ClassVar[int] = 5_000

    def analyze(self, log: str, profile: ProblemProfile) -> AnalysisResult:
        count = profile.n_constrs

        is_problem = count > self.threshold

        if count > 50_000:
            context = (
                f"Very large constraint count ({count:,}) — "
                f"Benders' decomposition or column generation strongly recommended"
            )
            severity = 1.0
        elif count > 5_000:
            context = (
                f"Large constraint count ({count:,}) — "
                f"consider decomposition strategies"
            )
            severity = 0.6
        else:
            context = f"Constraint count ({count:,}) within normal range"
            severity = 0.0

        return AnalysisResult(
            analyzer_name=self.name,
            is_problem=is_problem,
            context=context,
            severity=severity,
            details={"count": count},
        )
