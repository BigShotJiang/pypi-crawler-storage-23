"""Analyzer: detects large coefficient ranges that indicate Big-M issues."""

from typing import ClassVar

from server.api.agent.general.analysis.base import AnalysisResult, BaseAnalyzer
from server.api.agent.general.types import ProblemProfile


class CoeffRangeAnalyzer(BaseAnalyzer):
    """
    Detects large coefficient range ratios that typically indicate Big-M constraints.

    A large ratio (coef_max / coef_min) weakens the LP relaxation, causing
    excessive branching and poor solver performance.
    """

    name: ClassVar[str] = "coeff_range"

    # Configurable threshold
    threshold: ClassVar[float] = 1e4

    def analyze(self, log: str, profile: ProblemProfile) -> AnalysisResult:
        ratio = profile.coef_range_ratio
        coef_min = profile.coef_min
        coef_max = profile.coef_max

        is_problem = ratio > self.threshold

        if ratio > 1e6:
            context = (
                f"Coefficient range {ratio:.1e} (min={coef_min:.2g}, max={coef_max:.2g}) "
                f"— very likely Big-M constraints, high priority for tightening"
            )
            severity = 1.0
        elif ratio > 1e4:
            context = (
                f"Coefficient range {ratio:.1e} (min={coef_min:.2g}, max={coef_max:.2g}) "
                f"— possible Big-M constraints, consider rescaling"
            )
            severity = 0.6
        else:
            context = (
                f"Coefficient range {ratio:.1e} — within acceptable range"
            )
            severity = 0.0

        return AnalysisResult(
            analyzer_name=self.name,
            is_problem=is_problem,
            context=context,
            severity=severity,
            details={
                "ratio": ratio,
                "coef_min": coef_min,
                "coef_max": coef_max,
            },
        )
