"""Analyzer: detects large final MIP gap indicating poor bound tightening."""

from typing import ClassVar

from server.api.agent.general.analysis.base import AnalysisResult, BaseAnalyzer
from server.api.agent.general.types import ProblemProfile


class MIPGapAnalyzer(BaseAnalyzer):
    """
    Detects a large final MIP gap at solver termination.

    A high gap means the LP relaxation bound is far from the integer optimum,
    suggesting constraint tightening, cutting planes, or bound improvements.
    """

    name: ClassVar[str] = "mip_gap"

    threshold: ClassVar[float] = 0.1  # percent (lowered for testing)

    def analyze(self, log: str, profile: ProblemProfile) -> AnalysisResult:
        gap = profile.log_gap

        is_problem = gap > self.threshold

        if gap > 20.0:
            context = (
                f"Very large MIP gap ({gap:.1f}%) at termination — "
                f"bound tightening, valid inequalities, or cutting planes are critical"
            )
            severity = 1.0
        elif gap > 10.0:
            context = (
                f"Large MIP gap ({gap:.1f}%) — constraint tightening strongly recommended"
            )
            severity = 0.8
        elif gap > 5.0:
            context = (
                f"Moderate MIP gap ({gap:.1f}%) — bound or constraint tightening may help"
            )
            severity = 0.5
        else:
            context = f"MIP gap ({gap:.1f}%) within acceptable range"
            severity = 0.0

        return AnalysisResult(
            analyzer_name=self.name,
            is_problem=is_problem,
            context=context,
            severity=severity,
            details={"gap": gap},
        )
