"""Analysis package: detects problems in Gurobi model logs and profiles."""

from server.api.agent.general.analysis.base import AnalysisResult, BaseAnalyzer
from server.api.agent.general.analysis.coeff_range import CoeffRangeAnalyzer
from server.api.agent.general.analysis.constraint_count import ConstraintCountAnalyzer
from server.api.agent.general.analysis.density import DensityAnalyzer
from server.api.agent.general.analysis.mip_gap import MIPGapAnalyzer
from server.api.agent.general.analysis.node_count import NodeCountAnalyzer
from server.api.agent.general.analysis.slow_root_lp import SlowRootLPAnalyzer
from server.api.agent.general.analysis.symmetry import SymmetryAnalyzer
from server.api.agent.general.analysis.variable_count import VariableCountAnalyzer

__all__ = [
    "AnalysisResult",
    "BaseAnalyzer",
    "CoeffRangeAnalyzer",
    "VariableCountAnalyzer",
    "ConstraintCountAnalyzer",
    "NodeCountAnalyzer",
    "MIPGapAnalyzer",
    "SymmetryAnalyzer",
    "SlowRootLPAnalyzer",
    "DensityAnalyzer",
]
