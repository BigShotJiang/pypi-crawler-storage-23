"""
Core data types for the General Gurobi Agent.
"""

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Optional


class ProblemType(Enum):
    """High-level problem classification."""
    LP = auto()          # Pure linear program
    MILP = auto()        # Mixed-integer linear program
    QP = auto()          # Quadratic program
    MIQP = auto()        # Mixed-integer quadratic program
    QCP = auto()         # Quadratically constrained program
    MIQCP = auto()       # Mixed-integer QCP


class ProblemStructure(Enum):
    """Detected special structure in the model."""
    GENERAL = auto()           # No special structure detected
    NETWORK = auto()           # Network flow structure
    KNAPSACK = auto()          # Knapsack constraints
    SET_COVER = auto()         # Set covering/packing
    SCHEDULING = auto()        # Job shop / scheduling
    ASSIGNMENT = auto()        # Assignment problem
    FACILITY_LOCATION = auto() # Facility location
    VEHICLE_ROUTING = auto()   # VRP structure
    BIN_PACKING = auto()       # Bin packing


class ImprovementCategory(Enum):
    """Category of improvement."""
    SOLVER_PARAM = auto()      # Gurobi parameter tuning
    BOUND_TIGHTENING = auto()  # Variable bound improvements
    CONSTRAINT_MOD = auto()    # Constraint modifications
    SYMMETRY = auto()          # Symmetry breaking
    CUTS = auto()              # Valid inequalities / cuts
    DECOMPOSITION = auto()     # Benders, Dantzig-Wolfe, etc.
    REFORMULATION = auto()     # Model reformulation


@dataclass
class ProblemProfile:
    """Complete profile of a Gurobi model."""

    # Basic stats
    n_vars: int = 0
    n_constrs: int = 0
    n_nonzeros: int = 0

    # Variable breakdown
    n_continuous: int = 0
    n_binary: int = 0
    n_integer: int = 0
    n_semicont: int = 0

    # Constraint breakdown
    n_linear: int = 0
    n_quadratic: int = 0
    n_sos: int = 0
    n_indicator: int = 0
    n_general: int = 0

    # Objective info
    obj_sense: str = "minimize"  # or "maximize"
    obj_is_linear: bool = True
    obj_is_quadratic: bool = False

    # Coefficient analysis
    coef_min: float = 0.0
    coef_max: float = 0.0
    coef_range_ratio: float = 1.0  # max/min - large = potential big-M
    rhs_min: float = 0.0
    rhs_max: float = 0.0

    # Sparsity
    density: float = 0.0  # nonzeros / (n_vars * n_constrs)
    avg_constrs_per_var: float = 0.0
    avg_vars_per_constr: float = 0.0

    # Structure detection
    problem_type: ProblemType = ProblemType.LP
    detected_structures: list[ProblemStructure] = field(default_factory=list)

    # Symmetry analysis
    has_symmetry: bool = False
    symmetry_groups: int = 0

    # Constraint graph analysis
    is_block_diagonal: bool = False
    n_components: int = 1  # Connected components in constraint graph
    largest_component_pct: float = 1.0

    # Bottleneck indicators (from log if available)
    log_nodes: int = 0
    log_runtime: float = 0.0
    log_gap: float = 0.0
    log_presolve_removed_rows: int = 0
    log_presolve_removed_cols: int = 0


@dataclass
class Improvement:
    """A single improvement to try."""

    name: str
    category: ImprovementCategory
    description: str

    # How to apply it
    apply_fn: Optional[Any] = None  # Callable that modifies model
    gurobi_params: dict = field(default_factory=dict)  # Params to set

    # Metadata
    confidence: float = 0.5  # 0-1, how likely to help
    risk: float = 0.1  # 0-1, how likely to hurt
    complexity: str = "low"  # low, medium, high

    # Conditions for when to try
    requires_binary: bool = False
    requires_integer: bool = False
    requires_quadratic: bool = False
    min_vars: int = 0
    min_constrs: int = 0


@dataclass
class BenchmarkResult:
    """Result from benchmarking an improvement."""

    improvement_name: str
    runtime_seconds: float
    nodes_explored: int
    status: str
    objective_value: Optional[float] = None

    # Comparison to baseline
    speedup_pct: float = 0.0  # Positive = faster
    is_winner: bool = False


@dataclass
class AgentResult:
    """Final result from the agent."""

    # Baseline
    baseline_runtime: float
    baseline_nodes: int
    baseline_status: str

    # Profile
    profile: ProblemProfile

    # All results
    improvements_tested: list[BenchmarkResult] = field(default_factory=list)
    improvements_skipped: list[str] = field(default_factory=list)

    # Best result
    best_improvement: Optional[str] = None
    best_speedup: float = 0.0
    best_params: dict = field(default_factory=dict)

    # Recommendations
    recommendations: list[str] = field(default_factory=list)
