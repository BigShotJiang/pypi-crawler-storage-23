"""
FormulationAgent: Analyzes Gurobi logs and improves model formulation for faster solving.

This agent:
1. Runs the optimization model
2. Analyzes Gurobi performance metrics (runtime, nodes, presolve, MIP gap)
3. Identifies bottlenecks in the formulation
4. Suggests and implements formulation improvements
5. Validates improvements by re-running
6. Creates PR if runtime improved
"""

import re
from dataclasses import dataclass
from typing import Optional

import gurobipy as gp


@dataclass
class GurobiMetrics:
    """Parsed metrics from Gurobi solve."""

    runtime_seconds: float = 0.0
    nodes_explored: int = 0
    simplex_iterations: int = 0
    mip_gap: float = 0.0
    presolve_removed_rows: int = 0
    presolve_removed_cols: int = 0
    presolve_time: float = 0.0
    root_relaxation_time: float = 0.0
    status: str = ""
    objective_value: Optional[float] = None

    # Model size
    n_rows: int = 0
    n_cols: int = 0
    n_nonzeros: int = 0
    n_binary: int = 0
    n_integer: int = 0
    n_continuous: int = 0

    # Bottleneck indicators
    is_node_heavy: bool = False  # Many nodes explored
    is_presolve_heavy: bool = False  # Large presolve reduction
    has_symmetry: bool = False  # Potential symmetry issues
    has_big_m: bool = False  # Potential big-M issues
    has_weak_bounds: bool = False  # Weak LP relaxation


@dataclass
class FormulationFix:
    """A suggested fix to improve formulation."""

    name: str
    description: str
    code_change: str  # Description of what code to change
    expected_improvement: str
    confidence: float  # 0-1
    category: str  # "bounds", "cuts", "symmetry", "presolve", "reformulation"


@dataclass
class FormulationAnalysis:
    """Analysis of a formulation's performance."""

    metrics: GurobiMetrics
    bottlenecks: list[str]
    suggested_fixes: list[FormulationFix]
    summary: str


@dataclass
class ImprovementResult:
    """Result of applying a formulation improvement."""

    fix_applied: FormulationFix
    before_runtime: float
    after_runtime: float
    speedup_ratio: float
    success: bool
    notes: str = ""


class GurobiLogParser:
    """Parses Gurobi output log to extract performance metrics."""

    def parse(self, log: str) -> GurobiMetrics:
        """Parse Gurobi log string into metrics."""
        metrics = GurobiMetrics()

        # Runtime
        runtime_match = re.search(r"in ([\d.]+) seconds", log)
        if runtime_match:
            metrics.runtime_seconds = float(runtime_match.group(1))

        # Nodes explored
        nodes_match = re.search(r"Explored (\d+) nodes", log)
        if nodes_match:
            metrics.nodes_explored = int(nodes_match.group(1))

        # Simplex iterations
        iter_match = re.search(r"\((\d+) simplex iterations\)", log)
        if iter_match:
            metrics.simplex_iterations = int(iter_match.group(1))

        # MIP gap
        gap_match = re.search(r"gap ([\d.]+)%", log)
        if gap_match:
            metrics.mip_gap = float(gap_match.group(1))

        # Presolve
        presolve_match = re.search(r"Presolve removed (\d+) rows and (\d+) columns", log)
        if presolve_match:
            metrics.presolve_removed_rows = int(presolve_match.group(1))
            metrics.presolve_removed_cols = int(presolve_match.group(2))

        presolve_time_match = re.search(r"Presolve time: ([\d.]+)s", log)
        if presolve_time_match:
            metrics.presolve_time = float(presolve_time_match.group(1))

        # Model size
        model_match = re.search(r"with (\d+) rows, (\d+) columns and (\d+) nonzeros", log)
        if model_match:
            metrics.n_rows = int(model_match.group(1))
            metrics.n_cols = int(model_match.group(2))
            metrics.n_nonzeros = int(model_match.group(3))

        # Variable types
        var_match = re.search(r"(\d+) continuous, (\d+) integer \((\d+) binary\)", log)
        if var_match:
            metrics.n_continuous = int(var_match.group(1))
            metrics.n_integer = int(var_match.group(2))
            metrics.n_binary = int(var_match.group(3))

        # Status
        if "Optimal solution found" in log:
            metrics.status = "OPTIMAL"
        elif "infeasible" in log.lower():
            metrics.status = "INFEASIBLE"
        elif "Time limit" in log:
            metrics.status = "TIME_LIMIT"

        # Objective
        obj_match = re.search(r"Best objective ([-\d.e+]+)", log)
        if obj_match:
            metrics.objective_value = float(obj_match.group(1))

        # Identify bottlenecks
        metrics.is_node_heavy = metrics.nodes_explored > 1000
        metrics.is_presolve_heavy = (
            metrics.presolve_removed_rows > metrics.n_rows * 0.5
            if metrics.n_rows > 0
            else False
        )

        # Check for big-M indicators (large coefficient range)
        coef_match = re.search(r"Matrix range\s+\[([\d.e+-]+),\s*([\d.e+-]+)\]", log)
        if coef_match:
            min_coef = float(coef_match.group(1))
            max_coef = float(coef_match.group(2))
            if max_coef / max(min_coef, 1e-10) > 1e6:
                metrics.has_big_m = True

        return metrics


class FormulationAnalyzer:
    """Analyzes formulation performance and suggests improvements."""

    def __init__(self):
        self.parser = GurobiLogParser()

    def analyze(self, log: str, model: Optional[gp.Model] = None) -> FormulationAnalysis:
        """Analyze Gurobi log and suggest formulation improvements."""
        metrics = self.parser.parse(log)
        bottlenecks = []
        fixes = []

        # Analyze bottlenecks and suggest fixes

        # 1. Node-heavy solving (weak LP relaxation)
        if metrics.is_node_heavy:
            bottlenecks.append(
                f"High node count ({metrics.nodes_explored:,}) suggests weak LP relaxation"
            )
            fixes.append(
                FormulationFix(
                    name="tighten_bounds",
                    description="Tighten variable bounds to strengthen LP relaxation",
                    code_change="Add tighter lb/ub on continuous variables based on problem structure",
                    expected_improvement="Reduce nodes by 20-50%",
                    confidence=0.7,
                    category="bounds",
                )
            )
            fixes.append(
                FormulationFix(
                    name="add_valid_inequalities",
                    description="Add cutting planes / valid inequalities",
                    code_change="Add constraints that cut off fractional solutions without removing integer solutions",
                    expected_improvement="Reduce nodes by 30-60%",
                    confidence=0.6,
                    category="cuts",
                )
            )

        # 2. Big-M formulations
        if metrics.has_big_m:
            bottlenecks.append("Large coefficient range detected (potential big-M)")
            fixes.append(
                FormulationFix(
                    name="reduce_big_m",
                    description="Replace big-M constraints with tighter formulations",
                    code_change="Use indicator constraints or compute tighter M values from problem data",
                    expected_improvement="Reduce runtime by 30-70%",
                    confidence=0.8,
                    category="reformulation",
                )
            )

        # 3. Heavy presolve suggests redundant constraints
        if metrics.is_presolve_heavy:
            bottlenecks.append(
                f"Presolve removed {metrics.presolve_removed_rows} rows - model may have redundant constraints"
            )
            fixes.append(
                FormulationFix(
                    name="remove_redundant",
                    description="Remove redundant constraints at model build time",
                    code_change="Identify and skip constraints that are dominated by others",
                    expected_improvement="Reduce build time, cleaner model",
                    confidence=0.5,
                    category="presolve",
                )
            )

        # 4. Many binary variables (potential symmetry)
        if metrics.n_binary > 100:
            bottlenecks.append(
                f"Many binary variables ({metrics.n_binary}) - check for symmetry"
            )
            fixes.append(
                FormulationFix(
                    name="symmetry_breaking",
                    description="Add symmetry-breaking constraints",
                    code_change="Add ordering constraints on symmetric binary variables",
                    expected_improvement="Reduce nodes by 40-80% if symmetry present",
                    confidence=0.5,
                    category="symmetry",
                )
            )

        # 5. Slow runtime but few nodes (LP is bottleneck)
        if metrics.runtime_seconds > 10 and metrics.nodes_explored < 100:
            bottlenecks.append("LP solving is the bottleneck, not branching")
            fixes.append(
                FormulationFix(
                    name="simplify_constraints",
                    description="Simplify or aggregate constraints",
                    code_change="Combine similar constraints, use sparse formulations",
                    expected_improvement="Reduce LP solve time",
                    confidence=0.6,
                    category="reformulation",
                )
            )

        # 6. General: Check if model is too large
        if metrics.n_rows > 10000:
            bottlenecks.append(f"Large model ({metrics.n_rows:,} rows)")
            fixes.append(
                FormulationFix(
                    name="aggregate_entities",
                    description="Aggregate individuals into groups",
                    code_change="Use representative agents or group-level constraints instead of individual",
                    expected_improvement="Reduce model size by 10-100x",
                    confidence=0.7,
                    category="reformulation",
                )
            )

        # Build summary
        if not bottlenecks:
            summary = f"Model solved efficiently in {metrics.runtime_seconds:.2f}s with {metrics.nodes_explored} nodes."
        else:
            summary = f"Model solved in {metrics.runtime_seconds:.2f}s. Identified {len(bottlenecks)} potential bottlenecks."

        return FormulationAnalysis(
            metrics=metrics,
            bottlenecks=bottlenecks,
            suggested_fixes=fixes,
            summary=summary,
        )


class FormulationAgent:
    """
    Agent that iteratively improves model formulation for faster solving.

    Workflow:
    1. Run baseline model, capture Gurobi log
    2. Analyze log for bottlenecks
    3. Apply suggested improvements to formulation
    4. Re-run and measure improvement
    5. If faster, prepare PR with changes
    """

    def __init__(self, verbose: bool = True):
        self.verbose = verbose
        self.analyzer = FormulationAnalyzer()
        self.improvements: list[ImprovementResult] = []
        self.baseline_metrics: Optional[GurobiMetrics] = None

    def log(self, msg: str):
        if self.verbose:
            print(f"[FormulationAgent] {msg}")

    def run_and_analyze(
        self,
        build_model_fn,  # Function that builds and returns (model, solve_fn)
        max_iterations: int = 5,
    ) -> dict:
        """
        Run the formulation improvement loop.

        Args:
            build_model_fn: Function that returns (gp.Model, solve_callback)
            max_iterations: Maximum improvement iterations

        Returns:
            Summary of improvements made
        """
        self.log("Starting formulation analysis...")

        # Step 1: Run baseline
        self.log("\n=== BASELINE RUN ===")
        model, log_output = self._run_model(build_model_fn)
        baseline_analysis = self.analyzer.analyze(log_output, model)
        self.baseline_metrics = baseline_analysis.metrics

        self.log(f"Baseline runtime: {baseline_analysis.metrics.runtime_seconds:.3f}s")
        self.log(f"Nodes explored: {baseline_analysis.metrics.nodes_explored}")
        self.log(f"Status: {baseline_analysis.metrics.status}")

        if baseline_analysis.bottlenecks:
            self.log("\nBottlenecks identified:")
            for b in baseline_analysis.bottlenecks:
                self.log(f"  - {b}")
        else:
            self.log("\nNo obvious bottlenecks. Model is already efficient!")

        if baseline_analysis.suggested_fixes:
            self.log("\nSuggested improvements:")
            for fix in baseline_analysis.suggested_fixes:
                self.log(f"  [{fix.confidence:.0%}] {fix.name}: {fix.description}")

        return {
            "baseline_runtime": baseline_analysis.metrics.runtime_seconds,
            "baseline_nodes": baseline_analysis.metrics.nodes_explored,
            "bottlenecks": baseline_analysis.bottlenecks,
            "suggested_fixes": [
                {
                    "name": f.name,
                    "description": f.description,
                    "code_change": f.code_change,
                    "category": f.category,
                    "confidence": f.confidence,
                }
                for f in baseline_analysis.suggested_fixes
            ],
            "analysis_summary": baseline_analysis.summary,
        }

    def _run_model(self, build_model_fn) -> tuple[gp.Model, str]:
        """Run model and capture log output."""
        import io
        import sys

        # Capture stdout for Gurobi log
        old_stdout = sys.stdout
        sys.stdout = captured = io.StringIO()

        try:
            model = build_model_fn()
            model.Params.OutputFlag = 1  # Enable logging
            model.optimize()
        finally:
            sys.stdout = old_stdout

        log_output = captured.getvalue()
        return model, log_output

    def generate_improvement_report(self) -> str:
        """Generate a report of suggested improvements for PR."""
        if not self.baseline_metrics:
            return "No analysis run yet."

        lines = [
            "# Formulation Improvement Analysis",
            "",
            "## Baseline Performance",
            f"- Runtime: {self.baseline_metrics.runtime_seconds:.3f}s",
            f"- Nodes explored: {self.baseline_metrics.nodes_explored:,}",
            f"- Model size: {self.baseline_metrics.n_rows:,} rows, {self.baseline_metrics.n_cols:,} cols",
            f"- Variables: {self.baseline_metrics.n_binary} binary, {self.baseline_metrics.n_continuous} continuous",
            "",
        ]

        self.analyzer.analyze("")  # Just for structure
        # We'd need to store the analysis from run_and_analyze

        lines.extend([
            "## Recommendations",
            "",
            "Based on the Gurobi log analysis, the following improvements are suggested:",
            "",
        ])

        return "\n".join(lines)
