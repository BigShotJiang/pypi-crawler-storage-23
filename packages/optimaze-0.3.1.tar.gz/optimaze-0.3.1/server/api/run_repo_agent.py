"""
Run the repo-based Gurobi improvement agent on a GitHub repository.

Usage:
    python run_repo_agent.py https://github.com/user/repo
    python run_repo_agent.py https://github.com/user/repo --no-pr
    python run_repo_agent.py https://github.com/user/repo --clone-dir /tmp/myrepo
"""

import argparse
import sys

from dotenv import load_dotenv

load_dotenv()

from server.api.agent.general.repo_agent import RepoAgent  # noqa: E402
from server.api.agent.general.repo_types import RepoAgentConfig  # noqa: E402


def main():
    parser = argparse.ArgumentParser(
        description="Optimize Gurobi solver params in a GitHub repository"
    )
    parser.add_argument(
        "github_url",
        help="GitHub repository URL (e.g. https://github.com/user/repo)",
    )
    parser.add_argument(
        "--no-pr",
        action="store_true",
        help="Don't create a pull request (just print results)",
    )
    parser.add_argument(
        "--clone-dir",
        default="",
        help="Directory to clone into (default: temp dir)",
    )
    parser.add_argument(
        "--max-improvements",
        type=int,
        default=8,
        help="Max improvements to test per call site (default: 8)",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=120.0,
        help="Timeout per script run in seconds (default: 120)",
    )
    parser.add_argument(
        "--entry-point",
        default="",
        help="Path to the script that runs the optimization model (relative to repo root)",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Reduce output verbosity",
    )

    args = parser.parse_args()

    config = RepoAgentConfig(
        clone_dir=args.clone_dir,
        create_pr=not args.no_pr,
        max_improvements_to_test=args.max_improvements,
        script_timeout=args.timeout,
        entry_point=args.entry_point,
        verbose=not args.quiet,
    )

    agent = RepoAgent(config=config)
    result = agent.improve(args.github_url)

    # Exit code
    if result.success:
        if result.pr_url:
            print(f"\nPR: {result.pr_url}")
        sys.exit(0)
    else:
        print(f"\nFailed: {result.error}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
