"""
Quick test script for the API.
Run the API first: uvicorn platform.api.main:app --reload
Then run this: python platform/test_api.py
"""

from pathlib import Path

import requests

API_URL = "http://localhost:8000"

def test_health():
    """Test health endpoint."""
    r = requests.get(f"{API_URL}/health")
    print(f"Health: {r.json()}")
    assert r.status_code == 200

def test_optimize():
    """Test optimization endpoint with a sample model."""
    # Find a test model
    test_models = list(Path(".").glob("**/*.mps")) + list(Path(".").glob("**/*.lp"))

    if not test_models:
        print("No .mps or .lp files found for testing")
        return

    model_path = test_models[0]
    print(f"\nTesting with: {model_path}")

    with open(model_path, 'rb') as f:
        r = requests.post(
            f"{API_URL}/optimize",
            files={"model_file": (model_path.name, f)},
            headers={"X-License-Key": "test-key-123"},
        )

    print(f"Status: {r.status_code}")
    result = r.json()

    if result.get("success"):
        print(f"Baseline: {result.get('baseline_runtime'):.3f}s")
        print(f"Best improvement: {result.get('best_improvement')}")
        print(f"Speedup: {result.get('best_speedup'):.1f}%")
        print(f"Params: {result.get('best_params')}")
    else:
        print(f"Error: {result.get('error')}")

def test_invalid_key():
    """Test that invalid keys are rejected."""
    r = requests.post(
        f"{API_URL}/optimize",
        files={"model_file": ("test.mps", b"dummy")},
        headers={"X-License-Key": "bad-key"},
    )
    print(f"\nInvalid key test: {r.status_code} (expected 401)")
    assert r.status_code == 401

if __name__ == "__main__":
    test_health()
    test_invalid_key()
    test_optimize()
    print("\n✅ All tests passed!")
