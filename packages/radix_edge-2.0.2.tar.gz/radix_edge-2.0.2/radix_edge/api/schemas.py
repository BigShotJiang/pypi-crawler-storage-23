"""Pydantic request/response schemas for API endpoints."""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field


class JobSubmitRequest(BaseModel):
    """Request body for POST /v1/jobs."""
    image: str = Field(..., min_length=1, max_length=512, description="Docker image to run")
    command: Optional[list[str]] = Field(None, max_length=50, description="Container command")
    args: Optional[list[str]] = Field(None, max_length=100, description="Command arguments")
    env: Optional[dict[str, str]] = Field(None, description="Environment variables")
    name: Optional[str] = Field(None, max_length=255, description="Human-readable job name")
    job_type: str = Field("generic", max_length=64, description="Job type for scheduling model")
    priority: int = Field(5, ge=1, le=10, description="Priority (1=lowest, 10=highest)")
    num_gpus: int = Field(1, ge=0, le=16, description="Number of GPUs required (0 for CPU-only)")
    gpu_mem_required_mb: int = Field(0, ge=0, description="Minimum GPU memory required (MB)")
    user_id: str = Field("default", max_length=128, description="User ID for quota enforcement")
    timeout_seconds: int = Field(3600, ge=60, le=86400, description="Job timeout in seconds")
    metadata: Optional[dict] = Field(None, description="Arbitrary metadata")


class JobResponse(BaseModel):
    """Response body for job endpoints."""
    job_id: str
    status: str
    message: Optional[str] = None
