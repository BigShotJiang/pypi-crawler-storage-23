"""Entry point for running the edge agent server."""

import uvicorn

from radix_edge.config import get_config


def main():
    config = get_config()
    uvicorn.run(
        "radix_edge.api.app:create_app",
        factory=True,
        host=config.host,
        port=config.port,
        log_level=config.log_level.lower(),
    )


if __name__ == "__main__":
    main()
