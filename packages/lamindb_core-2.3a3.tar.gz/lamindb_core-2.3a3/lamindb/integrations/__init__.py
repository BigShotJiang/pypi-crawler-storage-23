"""Integrations.

Modules
-------

.. autosummary::
   :toctree: .

   lightning

Functions
---------

.. autofunction:: save_vitessce_config
.. autofunction:: save_tiledbsoma_experiment
.. autofunction:: curate_from_croissant

"""

from ._croissant import curate_from_croissant
from ._vitessce import save_vitessce_config

__all__ = [
    "lightning",
    "save_tiledbsoma_experiment",
    "curate_from_croissant",
    "save_vitessce_config",
]


def __getattr__(name: str):
    """Lazy-import save_tiledbsoma_experiment to avoid loading storage at package import."""
    if name == "save_tiledbsoma_experiment":
        from lamindb.core.storage import save_tiledbsoma_experiment

        return save_tiledbsoma_experiment
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
