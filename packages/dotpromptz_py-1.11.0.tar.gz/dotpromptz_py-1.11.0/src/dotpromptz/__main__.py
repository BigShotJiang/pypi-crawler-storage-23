"""Allow running ``python -m dotpromptz``."""

from dotpromptz.cli import cli

cli()
