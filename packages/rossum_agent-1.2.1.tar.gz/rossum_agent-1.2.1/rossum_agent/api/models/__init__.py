"""Pydantic models for API requests and responses."""
