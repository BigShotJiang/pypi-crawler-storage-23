import csv
import io
import json
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("csv-parse")

@mcp.tool()
def parse_csv(text: str, delimiter: str = ",", has_header: bool = True) -> str:
    """解析 CSV 文本为结构化 JSON 数据。"""
    try:
        f = io.StringIO(text.strip())
        if has_header:
            reader = csv.DictReader(f, delimiter=delimiter)
            data = list(reader)
        else:
            reader = csv.reader(f, delimiter=delimiter)
            data = list(reader)
        return json.dumps(data, indent=2, ensure_ascii=False)
    except Exception as e:
        return f"CSV 解析失败: {e}"

def main():
    mcp.run()

if __name__ == "__main__":
    main()
