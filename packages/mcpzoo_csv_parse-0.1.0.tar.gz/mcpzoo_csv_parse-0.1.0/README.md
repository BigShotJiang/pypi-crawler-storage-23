# mcpzoo-csv-parse

> CSV 解析 — 解析 CSV 文本为结构化 JSON 数据

## Installation

```bash
uvx mcpzoo-csv-parse
```

## uvx JSON

```json
{
  "mcpServers": {
    "csv-parse": {
      "args": ["mcpzoo-csv-parse"],
      "command": "uvx"
    }
  }
}
```
