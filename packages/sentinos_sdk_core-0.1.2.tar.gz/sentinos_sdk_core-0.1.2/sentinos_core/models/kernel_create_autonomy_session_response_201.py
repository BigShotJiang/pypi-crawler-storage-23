from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.autonomy_session import AutonomySession


T = TypeVar("T", bound="KernelCreateAutonomySessionResponse201")


@_attrs_define
class KernelCreateAutonomySessionResponse201:
    """
    Attributes:
        session (AutonomySession):
    """

    session: AutonomySession

    def to_dict(self) -> dict[str, Any]:
        session = self.session.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "session": session,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.autonomy_session import AutonomySession

        d = dict(src_dict)
        session = AutonomySession.from_dict(d.pop("session"))

        kernel_create_autonomy_session_response_201 = cls(
            session=session,
        )

        return kernel_create_autonomy_session_response_201
