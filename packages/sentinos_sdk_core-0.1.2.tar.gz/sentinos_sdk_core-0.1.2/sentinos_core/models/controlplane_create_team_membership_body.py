from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define

from ..models.controlplane_create_team_membership_body_provisioned_by import (
    ControlplaneCreateTeamMembershipBodyProvisionedBy,
)
from ..models.controlplane_create_team_membership_body_team_role import ControlplaneCreateTeamMembershipBodyTeamRole
from ..types import UNSET, Unset

T = TypeVar("T", bound="ControlplaneCreateTeamMembershipBody")


@_attrs_define
class ControlplaneCreateTeamMembershipBody:
    """
    Attributes:
        membership_id (UUID):
        team_role (ControlplaneCreateTeamMembershipBodyTeamRole | Unset):
        provisioned_by (ControlplaneCreateTeamMembershipBodyProvisionedBy | Unset):
        provisioned_by_id (UUID | Unset):
    """

    membership_id: UUID
    team_role: ControlplaneCreateTeamMembershipBodyTeamRole | Unset = UNSET
    provisioned_by: ControlplaneCreateTeamMembershipBodyProvisionedBy | Unset = UNSET
    provisioned_by_id: UUID | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        membership_id = str(self.membership_id)

        team_role: str | Unset = UNSET
        if not isinstance(self.team_role, Unset):
            team_role = self.team_role.value

        provisioned_by: str | Unset = UNSET
        if not isinstance(self.provisioned_by, Unset):
            provisioned_by = self.provisioned_by.value

        provisioned_by_id: str | Unset = UNSET
        if not isinstance(self.provisioned_by_id, Unset):
            provisioned_by_id = str(self.provisioned_by_id)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "membership_id": membership_id,
            }
        )
        if team_role is not UNSET:
            field_dict["team_role"] = team_role
        if provisioned_by is not UNSET:
            field_dict["provisioned_by"] = provisioned_by
        if provisioned_by_id is not UNSET:
            field_dict["provisioned_by_id"] = provisioned_by_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        membership_id = UUID(d.pop("membership_id"))

        _team_role = d.pop("team_role", UNSET)
        team_role: ControlplaneCreateTeamMembershipBodyTeamRole | Unset
        if isinstance(_team_role, Unset):
            team_role = UNSET
        else:
            team_role = ControlplaneCreateTeamMembershipBodyTeamRole(_team_role)

        _provisioned_by = d.pop("provisioned_by", UNSET)
        provisioned_by: ControlplaneCreateTeamMembershipBodyProvisionedBy | Unset
        if isinstance(_provisioned_by, Unset):
            provisioned_by = UNSET
        else:
            provisioned_by = ControlplaneCreateTeamMembershipBodyProvisionedBy(_provisioned_by)

        _provisioned_by_id = d.pop("provisioned_by_id", UNSET)
        provisioned_by_id: UUID | Unset
        if isinstance(_provisioned_by_id, Unset):
            provisioned_by_id = UNSET
        else:
            provisioned_by_id = UUID(_provisioned_by_id)

        controlplane_create_team_membership_body = cls(
            membership_id=membership_id,
            team_role=team_role,
            provisioned_by=provisioned_by,
            provisioned_by_id=provisioned_by_id,
        )

        return controlplane_create_team_membership_body
