from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.auth_tokens import AuthTokens
    from ..models.membership import Membership
    from ..models.organization import Organization


T = TypeVar("T", bound="ControlplaneAuthBundle")


@_attrs_define
class ControlplaneAuthBundle:
    """
    Attributes:
        tokens (AuthTokens):
        organization (Organization):
        membership (Membership):
    """

    tokens: AuthTokens
    organization: Organization
    membership: Membership

    def to_dict(self) -> dict[str, Any]:
        tokens = self.tokens.to_dict()

        organization = self.organization.to_dict()

        membership = self.membership.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "tokens": tokens,
                "organization": organization,
                "membership": membership,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.auth_tokens import AuthTokens
        from ..models.membership import Membership
        from ..models.organization import Organization

        d = dict(src_dict)
        tokens = AuthTokens.from_dict(d.pop("tokens"))

        organization = Organization.from_dict(d.pop("organization"))

        membership = Membership.from_dict(d.pop("membership"))

        controlplane_auth_bundle = cls(
            tokens=tokens,
            organization=organization,
            membership=membership,
        )

        return controlplane_auth_bundle
