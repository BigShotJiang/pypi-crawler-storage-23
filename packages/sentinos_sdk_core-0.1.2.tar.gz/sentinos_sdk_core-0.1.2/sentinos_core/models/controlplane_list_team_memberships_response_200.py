from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.team_membership_record import TeamMembershipRecord


T = TypeVar("T", bound="ControlplaneListTeamMembershipsResponse200")


@_attrs_define
class ControlplaneListTeamMembershipsResponse200:
    """
    Attributes:
        memberships (list[TeamMembershipRecord]):
    """

    memberships: list[TeamMembershipRecord]

    def to_dict(self) -> dict[str, Any]:
        memberships = []
        for memberships_item_data in self.memberships:
            memberships_item = memberships_item_data.to_dict()
            memberships.append(memberships_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "memberships": memberships,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.team_membership_record import TeamMembershipRecord

        d = dict(src_dict)
        memberships = []
        _memberships = d.pop("memberships")
        for memberships_item_data in _memberships:
            memberships_item = TeamMembershipRecord.from_dict(memberships_item_data)

            memberships.append(memberships_item)

        controlplane_list_team_memberships_response_200 = cls(
            memberships=memberships,
        )

        return controlplane_list_team_memberships_response_200
