from enum import Enum


class CreateNotificationChannelBodyKind(str, Enum):
    DATADOG = "DATADOG"
    EMAIL = "EMAIL"
    PAGERDUTY = "PAGERDUTY"
    SLACK = "SLACK"
    WEBHOOK = "WEBHOOK"

    def __str__(self) -> str:
        return str(self.value)
