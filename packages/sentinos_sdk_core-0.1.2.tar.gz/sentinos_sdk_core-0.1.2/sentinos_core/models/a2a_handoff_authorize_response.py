from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.a2a_handoff_receipt import A2AHandoffReceipt


T = TypeVar("T", bound="A2AHandoffAuthorizeResponse")


@_attrs_define
class A2AHandoffAuthorizeResponse:
    """
    Attributes:
        handoff_id (str):
        decision (str):
        receipt (A2AHandoffReceipt):
        reason (str | Unset):
    """

    handoff_id: str
    decision: str
    receipt: A2AHandoffReceipt
    reason: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        handoff_id = self.handoff_id

        decision = self.decision

        receipt = self.receipt.to_dict()

        reason = self.reason

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "handoff_id": handoff_id,
                "decision": decision,
                "receipt": receipt,
            }
        )
        if reason is not UNSET:
            field_dict["reason"] = reason

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.a2a_handoff_receipt import A2AHandoffReceipt

        d = dict(src_dict)
        handoff_id = d.pop("handoff_id")

        decision = d.pop("decision")

        receipt = A2AHandoffReceipt.from_dict(d.pop("receipt"))

        reason = d.pop("reason", UNSET)

        a2a_handoff_authorize_response = cls(
            handoff_id=handoff_id,
            decision=decision,
            receipt=receipt,
            reason=reason,
        )

        return a2a_handoff_authorize_response
