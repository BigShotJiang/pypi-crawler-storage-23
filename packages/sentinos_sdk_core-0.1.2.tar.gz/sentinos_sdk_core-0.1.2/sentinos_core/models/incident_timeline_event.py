from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.incident_timeline_event_details import IncidentTimelineEventDetails


T = TypeVar("T", bound="IncidentTimelineEvent")


@_attrs_define
class IncidentTimelineEvent:
    """
    Attributes:
        event_id (UUID):
        incident_id (UUID):
        tenant_id (str):
        event_type (str):
        created_at (datetime.datetime):
        actor (str | Unset):
        details (IncidentTimelineEventDetails | Unset):
    """

    event_id: UUID
    incident_id: UUID
    tenant_id: str
    event_type: str
    created_at: datetime.datetime
    actor: str | Unset = UNSET
    details: IncidentTimelineEventDetails | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        event_id = str(self.event_id)

        incident_id = str(self.incident_id)

        tenant_id = self.tenant_id

        event_type = self.event_type

        created_at = self.created_at.isoformat()

        actor = self.actor

        details: dict[str, Any] | Unset = UNSET
        if not isinstance(self.details, Unset):
            details = self.details.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "event_id": event_id,
                "incident_id": incident_id,
                "tenant_id": tenant_id,
                "event_type": event_type,
                "created_at": created_at,
            }
        )
        if actor is not UNSET:
            field_dict["actor"] = actor
        if details is not UNSET:
            field_dict["details"] = details

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.incident_timeline_event_details import IncidentTimelineEventDetails

        d = dict(src_dict)
        event_id = UUID(d.pop("event_id"))

        incident_id = UUID(d.pop("incident_id"))

        tenant_id = d.pop("tenant_id")

        event_type = d.pop("event_type")

        created_at = isoparse(d.pop("created_at"))

        actor = d.pop("actor", UNSET)

        _details = d.pop("details", UNSET)
        details: IncidentTimelineEventDetails | Unset
        if isinstance(_details, Unset):
            details = UNSET
        else:
            details = IncidentTimelineEventDetails.from_dict(_details)

        incident_timeline_event = cls(
            event_id=event_id,
            incident_id=incident_id,
            tenant_id=tenant_id,
            event_type=event_type,
            created_at=created_at,
            actor=actor,
            details=details,
        )

        incident_timeline_event.additional_properties = d
        return incident_timeline_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
