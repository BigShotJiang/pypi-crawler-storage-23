from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.org_login_methods import OrgLoginMethods


T = TypeVar("T", bound="ControlplaneDeleteUserLoginMethodOverrideResponse200")


@_attrs_define
class ControlplaneDeleteUserLoginMethodOverrideResponse200:
    """
    Attributes:
        ok (bool):
        effective (OrgLoginMethods):
    """

    ok: bool
    effective: OrgLoginMethods

    def to_dict(self) -> dict[str, Any]:
        ok = self.ok

        effective = self.effective.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "ok": ok,
                "effective": effective,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.org_login_methods import OrgLoginMethods

        d = dict(src_dict)
        ok = d.pop("ok")

        effective = OrgLoginMethods.from_dict(d.pop("effective"))

        controlplane_delete_user_login_method_override_response_200 = cls(
            ok=ok,
            effective=effective,
        )

        return controlplane_delete_user_login_method_override_response_200
