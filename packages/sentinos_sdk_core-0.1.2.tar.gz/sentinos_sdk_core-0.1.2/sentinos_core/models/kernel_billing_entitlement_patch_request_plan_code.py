from enum import Enum


class KernelBillingEntitlementPatchRequestPlanCode(str, Enum):
    CONTEXT = "CONTEXT"
    CORE = "CORE"
    ENTERPRISE = "ENTERPRISE"
    FREE = "FREE"

    def __str__(self) -> str:
        return str(self.value)
