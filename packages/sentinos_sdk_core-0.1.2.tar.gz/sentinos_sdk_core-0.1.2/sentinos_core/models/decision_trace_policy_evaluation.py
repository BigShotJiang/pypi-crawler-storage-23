from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

from ..models.decision_trace_policy_evaluation_decision import DecisionTracePolicyEvaluationDecision
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.decision_trace_policy_evaluation_evidence_item import DecisionTracePolicyEvaluationEvidenceItem
    from ..models.decision_trace_policy_evaluation_explain_plan import DecisionTracePolicyEvaluationExplainPlan


T = TypeVar("T", bound="DecisionTracePolicyEvaluation")


@_attrs_define
class DecisionTracePolicyEvaluation:
    """
    Attributes:
        policy_id (str):
        decision (DecisionTracePolicyEvaluationDecision):
        policy_version (str | Unset):
        reason (str | Unset):
        evidence (list[DecisionTracePolicyEvaluationEvidenceItem] | Unset):
        explain_plan (DecisionTracePolicyEvaluationExplainPlan | Unset):
    """

    policy_id: str
    decision: DecisionTracePolicyEvaluationDecision
    policy_version: str | Unset = UNSET
    reason: str | Unset = UNSET
    evidence: list[DecisionTracePolicyEvaluationEvidenceItem] | Unset = UNSET
    explain_plan: DecisionTracePolicyEvaluationExplainPlan | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        policy_id = self.policy_id

        decision = self.decision.value

        policy_version = self.policy_version

        reason = self.reason

        evidence: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.evidence, Unset):
            evidence = []
            for evidence_item_data in self.evidence:
                evidence_item = evidence_item_data.to_dict()
                evidence.append(evidence_item)

        explain_plan: dict[str, Any] | Unset = UNSET
        if not isinstance(self.explain_plan, Unset):
            explain_plan = self.explain_plan.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "policy_id": policy_id,
                "decision": decision,
            }
        )
        if policy_version is not UNSET:
            field_dict["policy_version"] = policy_version
        if reason is not UNSET:
            field_dict["reason"] = reason
        if evidence is not UNSET:
            field_dict["evidence"] = evidence
        if explain_plan is not UNSET:
            field_dict["explain_plan"] = explain_plan

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.decision_trace_policy_evaluation_evidence_item import DecisionTracePolicyEvaluationEvidenceItem
        from ..models.decision_trace_policy_evaluation_explain_plan import DecisionTracePolicyEvaluationExplainPlan

        d = dict(src_dict)
        policy_id = d.pop("policy_id")

        decision = DecisionTracePolicyEvaluationDecision(d.pop("decision"))

        policy_version = d.pop("policy_version", UNSET)

        reason = d.pop("reason", UNSET)

        _evidence = d.pop("evidence", UNSET)
        evidence: list[DecisionTracePolicyEvaluationEvidenceItem] | Unset = UNSET
        if _evidence is not UNSET:
            evidence = []
            for evidence_item_data in _evidence:
                evidence_item = DecisionTracePolicyEvaluationEvidenceItem.from_dict(evidence_item_data)

                evidence.append(evidence_item)

        _explain_plan = d.pop("explain_plan", UNSET)
        explain_plan: DecisionTracePolicyEvaluationExplainPlan | Unset
        if isinstance(_explain_plan, Unset):
            explain_plan = UNSET
        else:
            explain_plan = DecisionTracePolicyEvaluationExplainPlan.from_dict(_explain_plan)

        decision_trace_policy_evaluation = cls(
            policy_id=policy_id,
            decision=decision,
            policy_version=policy_version,
            reason=reason,
            evidence=evidence,
            explain_plan=explain_plan,
        )

        return decision_trace_policy_evaluation
