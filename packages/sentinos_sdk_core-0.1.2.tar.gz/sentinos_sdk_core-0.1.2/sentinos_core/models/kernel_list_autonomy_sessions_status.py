from enum import Enum


class KernelListAutonomySessionsStatus(str, Enum):
    ACTIVE = "ACTIVE"
    PAUSED = "PAUSED"
    TERMINATED = "TERMINATED"

    def __str__(self) -> str:
        return str(self.value)
