from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..models.decision_trace_schema_data_class import DecisionTraceSchemaDataClass
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.decision_trace_intent import DecisionTraceIntent
    from ..models.decision_trace_schema_context_snapshot import DecisionTraceSchemaContextSnapshot
    from ..models.decision_trace_schema_organizational_context import DecisionTraceSchemaOrganizationalContext
    from ..models.decision_trace_schema_outcome import DecisionTraceSchemaOutcome
    from ..models.decision_trace_schema_policy_evaluation import DecisionTraceSchemaPolicyEvaluation
    from ..models.decision_trace_schema_privacy import DecisionTraceSchemaPrivacy
    from ..models.decision_trace_schema_provenance_item import DecisionTraceSchemaProvenanceItem
    from ..models.decision_trace_schema_reasoning import DecisionTraceSchemaReasoning
    from ..models.decision_trace_schema_signatures import DecisionTraceSchemaSignatures


T = TypeVar("T", bound="DecisionTraceSchema")


@_attrs_define
class DecisionTraceSchema:
    """
    Attributes:
        schema_version (Literal['decision-trace.v1']):
        trace_id (UUID):
        timestamp (datetime.datetime):
        tenant_id (str):
        intent (DecisionTraceIntent):
        policy_evaluation (DecisionTraceSchemaPolicyEvaluation):
        data_class (DecisionTraceSchemaDataClass | Unset):
        agent_id (str | Unset):
        session_id (str | Unset):
        tool_call (DecisionTraceIntent | Unset):
        context_snapshot_id (None | str | Unset):
        context_snapshot (DecisionTraceSchemaContextSnapshot | Unset):
        outcome (DecisionTraceSchemaOutcome | Unset):
        provenance (list[DecisionTraceSchemaProvenanceItem] | Unset):
        signatures (DecisionTraceSchemaSignatures | Unset):
        privacy (DecisionTraceSchemaPrivacy | Unset):
        reasoning (DecisionTraceSchemaReasoning | Unset):
        organizational_context (DecisionTraceSchemaOrganizationalContext | Unset):
    """

    schema_version: Literal["decision-trace.v1"]
    trace_id: UUID
    timestamp: datetime.datetime
    tenant_id: str
    intent: DecisionTraceIntent
    policy_evaluation: DecisionTraceSchemaPolicyEvaluation
    data_class: DecisionTraceSchemaDataClass | Unset = UNSET
    agent_id: str | Unset = UNSET
    session_id: str | Unset = UNSET
    tool_call: DecisionTraceIntent | Unset = UNSET
    context_snapshot_id: None | str | Unset = UNSET
    context_snapshot: DecisionTraceSchemaContextSnapshot | Unset = UNSET
    outcome: DecisionTraceSchemaOutcome | Unset = UNSET
    provenance: list[DecisionTraceSchemaProvenanceItem] | Unset = UNSET
    signatures: DecisionTraceSchemaSignatures | Unset = UNSET
    privacy: DecisionTraceSchemaPrivacy | Unset = UNSET
    reasoning: DecisionTraceSchemaReasoning | Unset = UNSET
    organizational_context: DecisionTraceSchemaOrganizationalContext | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        schema_version = self.schema_version

        trace_id = str(self.trace_id)

        timestamp = self.timestamp.isoformat()

        tenant_id = self.tenant_id

        intent = self.intent.to_dict()

        policy_evaluation = self.policy_evaluation.to_dict()

        data_class: str | Unset = UNSET
        if not isinstance(self.data_class, Unset):
            data_class = self.data_class.value

        agent_id = self.agent_id

        session_id = self.session_id

        tool_call: dict[str, Any] | Unset = UNSET
        if not isinstance(self.tool_call, Unset):
            tool_call = self.tool_call.to_dict()

        context_snapshot_id: None | str | Unset
        if isinstance(self.context_snapshot_id, Unset):
            context_snapshot_id = UNSET
        else:
            context_snapshot_id = self.context_snapshot_id

        context_snapshot: dict[str, Any] | Unset = UNSET
        if not isinstance(self.context_snapshot, Unset):
            context_snapshot = self.context_snapshot.to_dict()

        outcome: dict[str, Any] | Unset = UNSET
        if not isinstance(self.outcome, Unset):
            outcome = self.outcome.to_dict()

        provenance: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.provenance, Unset):
            provenance = []
            for provenance_item_data in self.provenance:
                provenance_item = provenance_item_data.to_dict()
                provenance.append(provenance_item)

        signatures: dict[str, Any] | Unset = UNSET
        if not isinstance(self.signatures, Unset):
            signatures = self.signatures.to_dict()

        privacy: dict[str, Any] | Unset = UNSET
        if not isinstance(self.privacy, Unset):
            privacy = self.privacy.to_dict()

        reasoning: dict[str, Any] | Unset = UNSET
        if not isinstance(self.reasoning, Unset):
            reasoning = self.reasoning.to_dict()

        organizational_context: dict[str, Any] | Unset = UNSET
        if not isinstance(self.organizational_context, Unset):
            organizational_context = self.organizational_context.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "schema_version": schema_version,
                "trace_id": trace_id,
                "timestamp": timestamp,
                "tenant_id": tenant_id,
                "intent": intent,
                "policy_evaluation": policy_evaluation,
            }
        )
        if data_class is not UNSET:
            field_dict["data_class"] = data_class
        if agent_id is not UNSET:
            field_dict["agent_id"] = agent_id
        if session_id is not UNSET:
            field_dict["session_id"] = session_id
        if tool_call is not UNSET:
            field_dict["tool_call"] = tool_call
        if context_snapshot_id is not UNSET:
            field_dict["context_snapshot_id"] = context_snapshot_id
        if context_snapshot is not UNSET:
            field_dict["context_snapshot"] = context_snapshot
        if outcome is not UNSET:
            field_dict["outcome"] = outcome
        if provenance is not UNSET:
            field_dict["provenance"] = provenance
        if signatures is not UNSET:
            field_dict["signatures"] = signatures
        if privacy is not UNSET:
            field_dict["privacy"] = privacy
        if reasoning is not UNSET:
            field_dict["reasoning"] = reasoning
        if organizational_context is not UNSET:
            field_dict["organizational_context"] = organizational_context

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.decision_trace_intent import DecisionTraceIntent
        from ..models.decision_trace_schema_context_snapshot import DecisionTraceSchemaContextSnapshot
        from ..models.decision_trace_schema_organizational_context import DecisionTraceSchemaOrganizationalContext
        from ..models.decision_trace_schema_outcome import DecisionTraceSchemaOutcome
        from ..models.decision_trace_schema_policy_evaluation import DecisionTraceSchemaPolicyEvaluation
        from ..models.decision_trace_schema_privacy import DecisionTraceSchemaPrivacy
        from ..models.decision_trace_schema_provenance_item import DecisionTraceSchemaProvenanceItem
        from ..models.decision_trace_schema_reasoning import DecisionTraceSchemaReasoning
        from ..models.decision_trace_schema_signatures import DecisionTraceSchemaSignatures

        d = dict(src_dict)
        schema_version = cast(Literal["decision-trace.v1"], d.pop("schema_version"))
        if schema_version != "decision-trace.v1":
            raise ValueError(f"schema_version must match const 'decision-trace.v1', got '{schema_version}'")

        trace_id = UUID(d.pop("trace_id"))

        timestamp = isoparse(d.pop("timestamp"))

        tenant_id = d.pop("tenant_id")

        intent = DecisionTraceIntent.from_dict(d.pop("intent"))

        policy_evaluation = DecisionTraceSchemaPolicyEvaluation.from_dict(d.pop("policy_evaluation"))

        _data_class = d.pop("data_class", UNSET)
        data_class: DecisionTraceSchemaDataClass | Unset
        if isinstance(_data_class, Unset):
            data_class = UNSET
        else:
            data_class = DecisionTraceSchemaDataClass(_data_class)

        agent_id = d.pop("agent_id", UNSET)

        session_id = d.pop("session_id", UNSET)

        _tool_call = d.pop("tool_call", UNSET)
        tool_call: DecisionTraceIntent | Unset
        if isinstance(_tool_call, Unset):
            tool_call = UNSET
        else:
            tool_call = DecisionTraceIntent.from_dict(_tool_call)

        def _parse_context_snapshot_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        context_snapshot_id = _parse_context_snapshot_id(d.pop("context_snapshot_id", UNSET))

        _context_snapshot = d.pop("context_snapshot", UNSET)
        context_snapshot: DecisionTraceSchemaContextSnapshot | Unset
        if isinstance(_context_snapshot, Unset):
            context_snapshot = UNSET
        else:
            context_snapshot = DecisionTraceSchemaContextSnapshot.from_dict(_context_snapshot)

        _outcome = d.pop("outcome", UNSET)
        outcome: DecisionTraceSchemaOutcome | Unset
        if isinstance(_outcome, Unset):
            outcome = UNSET
        else:
            outcome = DecisionTraceSchemaOutcome.from_dict(_outcome)

        _provenance = d.pop("provenance", UNSET)
        provenance: list[DecisionTraceSchemaProvenanceItem] | Unset = UNSET
        if _provenance is not UNSET:
            provenance = []
            for provenance_item_data in _provenance:
                provenance_item = DecisionTraceSchemaProvenanceItem.from_dict(provenance_item_data)

                provenance.append(provenance_item)

        _signatures = d.pop("signatures", UNSET)
        signatures: DecisionTraceSchemaSignatures | Unset
        if isinstance(_signatures, Unset):
            signatures = UNSET
        else:
            signatures = DecisionTraceSchemaSignatures.from_dict(_signatures)

        _privacy = d.pop("privacy", UNSET)
        privacy: DecisionTraceSchemaPrivacy | Unset
        if isinstance(_privacy, Unset):
            privacy = UNSET
        else:
            privacy = DecisionTraceSchemaPrivacy.from_dict(_privacy)

        _reasoning = d.pop("reasoning", UNSET)
        reasoning: DecisionTraceSchemaReasoning | Unset
        if isinstance(_reasoning, Unset):
            reasoning = UNSET
        else:
            reasoning = DecisionTraceSchemaReasoning.from_dict(_reasoning)

        _organizational_context = d.pop("organizational_context", UNSET)
        organizational_context: DecisionTraceSchemaOrganizationalContext | Unset
        if isinstance(_organizational_context, Unset):
            organizational_context = UNSET
        else:
            organizational_context = DecisionTraceSchemaOrganizationalContext.from_dict(_organizational_context)

        decision_trace_schema = cls(
            schema_version=schema_version,
            trace_id=trace_id,
            timestamp=timestamp,
            tenant_id=tenant_id,
            intent=intent,
            policy_evaluation=policy_evaluation,
            data_class=data_class,
            agent_id=agent_id,
            session_id=session_id,
            tool_call=tool_call,
            context_snapshot_id=context_snapshot_id,
            context_snapshot=context_snapshot,
            outcome=outcome,
            provenance=provenance,
            signatures=signatures,
            privacy=privacy,
            reasoning=reasoning,
            organizational_context=organizational_context,
        )

        return decision_trace_schema
