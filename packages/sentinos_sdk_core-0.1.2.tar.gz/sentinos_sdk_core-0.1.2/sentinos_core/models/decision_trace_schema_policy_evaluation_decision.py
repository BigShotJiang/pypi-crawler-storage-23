from enum import Enum


class DecisionTraceSchemaPolicyEvaluationDecision(str, Enum):
    ALLOW = "ALLOW"
    DENY = "DENY"
    ESCALATE = "ESCALATE"
    SHADOW = "SHADOW"

    def __str__(self) -> str:
        return str(self.value)
