from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..models.auth_session_record_auth_method import AuthSessionRecordAuthMethod
from ..types import UNSET, Unset

T = TypeVar("T", bound="AuthSessionRecord")


@_attrs_define
class AuthSessionRecord:
    """
    Attributes:
        session_id (UUID):
        user_id (UUID):
        org_id (UUID):
        auth_method (AuthSessionRecordAuthMethod):
        issued_at (datetime.datetime):
        expires_at (datetime.datetime):
        idle_expires_at (datetime.datetime):
        revoked_at (datetime.datetime | Unset):
        ip (str | Unset):
        user_agent (str | Unset):
    """

    session_id: UUID
    user_id: UUID
    org_id: UUID
    auth_method: AuthSessionRecordAuthMethod
    issued_at: datetime.datetime
    expires_at: datetime.datetime
    idle_expires_at: datetime.datetime
    revoked_at: datetime.datetime | Unset = UNSET
    ip: str | Unset = UNSET
    user_agent: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        session_id = str(self.session_id)

        user_id = str(self.user_id)

        org_id = str(self.org_id)

        auth_method = self.auth_method.value

        issued_at = self.issued_at.isoformat()

        expires_at = self.expires_at.isoformat()

        idle_expires_at = self.idle_expires_at.isoformat()

        revoked_at: str | Unset = UNSET
        if not isinstance(self.revoked_at, Unset):
            revoked_at = self.revoked_at.isoformat()

        ip = self.ip

        user_agent = self.user_agent

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "session_id": session_id,
                "user_id": user_id,
                "org_id": org_id,
                "auth_method": auth_method,
                "issued_at": issued_at,
                "expires_at": expires_at,
                "idle_expires_at": idle_expires_at,
            }
        )
        if revoked_at is not UNSET:
            field_dict["revoked_at"] = revoked_at
        if ip is not UNSET:
            field_dict["ip"] = ip
        if user_agent is not UNSET:
            field_dict["user_agent"] = user_agent

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        session_id = UUID(d.pop("session_id"))

        user_id = UUID(d.pop("user_id"))

        org_id = UUID(d.pop("org_id"))

        auth_method = AuthSessionRecordAuthMethod(d.pop("auth_method"))

        issued_at = isoparse(d.pop("issued_at"))

        expires_at = isoparse(d.pop("expires_at"))

        idle_expires_at = isoparse(d.pop("idle_expires_at"))

        _revoked_at = d.pop("revoked_at", UNSET)
        revoked_at: datetime.datetime | Unset
        if isinstance(_revoked_at, Unset):
            revoked_at = UNSET
        else:
            revoked_at = isoparse(_revoked_at)

        ip = d.pop("ip", UNSET)

        user_agent = d.pop("user_agent", UNSET)

        auth_session_record = cls(
            session_id=session_id,
            user_id=user_id,
            org_id=org_id,
            auth_method=auth_method,
            issued_at=issued_at,
            expires_at=expires_at,
            idle_expires_at=idle_expires_at,
            revoked_at=revoked_at,
            ip=ip,
            user_agent=user_agent,
        )

        return auth_session_record
