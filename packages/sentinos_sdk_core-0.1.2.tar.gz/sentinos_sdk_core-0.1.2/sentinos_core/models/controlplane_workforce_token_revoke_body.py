from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="ControlplaneWorkforceTokenRevokeBody")


@_attrs_define
class ControlplaneWorkforceTokenRevokeBody:
    """
    Attributes:
        session_id (UUID | Unset):
    """

    session_id: UUID | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        session_id: str | Unset = UNSET
        if not isinstance(self.session_id, Unset):
            session_id = str(self.session_id)

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if session_id is not UNSET:
            field_dict["session_id"] = session_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _session_id = d.pop("session_id", UNSET)
        session_id: UUID | Unset
        if isinstance(_session_id, Unset):
            session_id = UNSET
        else:
            session_id = UUID(_session_id)

        controlplane_workforce_token_revoke_body = cls(
            session_id=session_id,
        )

        return controlplane_workforce_token_revoke_body
