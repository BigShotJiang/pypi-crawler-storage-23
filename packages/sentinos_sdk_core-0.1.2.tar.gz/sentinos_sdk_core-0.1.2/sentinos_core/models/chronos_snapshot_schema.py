from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.chronos_snapshot_schema_status import ChronosSnapshotSchemaStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.chronos_snapshot_schema_anchor import ChronosSnapshotSchemaAnchor
    from ..models.chronos_snapshot_schema_confidence_map import ChronosSnapshotSchemaConfidenceMap
    from ..models.chronos_snapshot_schema_decision_traces_item import ChronosSnapshotSchemaDecisionTracesItem
    from ..models.chronos_snapshot_schema_edges_item import ChronosSnapshotSchemaEdgesItem
    from ..models.chronos_snapshot_schema_metadata import ChronosSnapshotSchemaMetadata
    from ..models.chronos_snapshot_schema_nodes_item import ChronosSnapshotSchemaNodesItem


T = TypeVar("T", bound="ChronosSnapshotSchema")


@_attrs_define
class ChronosSnapshotSchema:
    """
    Attributes:
        snapshot_id (str):
        status (ChronosSnapshotSchemaStatus | Unset):
        generated_at (datetime.datetime | Unset):
        retrieval_time (datetime.datetime | Unset):
        anchor (ChronosSnapshotSchemaAnchor | Unset):
        anchors (list[str] | Unset):
        depth (int | Unset):
        valid_time (datetime.datetime | Unset):
        estimated_nodes (int | Unset):
        nodes (list[ChronosSnapshotSchemaNodesItem] | Unset):
        edges (list[ChronosSnapshotSchemaEdgesItem] | Unset):
        confidence_map (ChronosSnapshotSchemaConfidenceMap | Unset):
        metadata (ChronosSnapshotSchemaMetadata | Unset):
        decision_traces (list[ChronosSnapshotSchemaDecisionTracesItem] | Unset):
    """

    snapshot_id: str
    status: ChronosSnapshotSchemaStatus | Unset = UNSET
    generated_at: datetime.datetime | Unset = UNSET
    retrieval_time: datetime.datetime | Unset = UNSET
    anchor: ChronosSnapshotSchemaAnchor | Unset = UNSET
    anchors: list[str] | Unset = UNSET
    depth: int | Unset = UNSET
    valid_time: datetime.datetime | Unset = UNSET
    estimated_nodes: int | Unset = UNSET
    nodes: list[ChronosSnapshotSchemaNodesItem] | Unset = UNSET
    edges: list[ChronosSnapshotSchemaEdgesItem] | Unset = UNSET
    confidence_map: ChronosSnapshotSchemaConfidenceMap | Unset = UNSET
    metadata: ChronosSnapshotSchemaMetadata | Unset = UNSET
    decision_traces: list[ChronosSnapshotSchemaDecisionTracesItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        snapshot_id = self.snapshot_id

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        generated_at: str | Unset = UNSET
        if not isinstance(self.generated_at, Unset):
            generated_at = self.generated_at.isoformat()

        retrieval_time: str | Unset = UNSET
        if not isinstance(self.retrieval_time, Unset):
            retrieval_time = self.retrieval_time.isoformat()

        anchor: dict[str, Any] | Unset = UNSET
        if not isinstance(self.anchor, Unset):
            anchor = self.anchor.to_dict()

        anchors: list[str] | Unset = UNSET
        if not isinstance(self.anchors, Unset):
            anchors = self.anchors

        depth = self.depth

        valid_time: str | Unset = UNSET
        if not isinstance(self.valid_time, Unset):
            valid_time = self.valid_time.isoformat()

        estimated_nodes = self.estimated_nodes

        nodes: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.nodes, Unset):
            nodes = []
            for nodes_item_data in self.nodes:
                nodes_item = nodes_item_data.to_dict()
                nodes.append(nodes_item)

        edges: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.edges, Unset):
            edges = []
            for edges_item_data in self.edges:
                edges_item = edges_item_data.to_dict()
                edges.append(edges_item)

        confidence_map: dict[str, Any] | Unset = UNSET
        if not isinstance(self.confidence_map, Unset):
            confidence_map = self.confidence_map.to_dict()

        metadata: dict[str, Any] | Unset = UNSET
        if not isinstance(self.metadata, Unset):
            metadata = self.metadata.to_dict()

        decision_traces: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.decision_traces, Unset):
            decision_traces = []
            for decision_traces_item_data in self.decision_traces:
                decision_traces_item = decision_traces_item_data.to_dict()
                decision_traces.append(decision_traces_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "snapshot_id": snapshot_id,
            }
        )
        if status is not UNSET:
            field_dict["status"] = status
        if generated_at is not UNSET:
            field_dict["generated_at"] = generated_at
        if retrieval_time is not UNSET:
            field_dict["retrieval_time"] = retrieval_time
        if anchor is not UNSET:
            field_dict["anchor"] = anchor
        if anchors is not UNSET:
            field_dict["anchors"] = anchors
        if depth is not UNSET:
            field_dict["depth"] = depth
        if valid_time is not UNSET:
            field_dict["valid_time"] = valid_time
        if estimated_nodes is not UNSET:
            field_dict["estimated_nodes"] = estimated_nodes
        if nodes is not UNSET:
            field_dict["nodes"] = nodes
        if edges is not UNSET:
            field_dict["edges"] = edges
        if confidence_map is not UNSET:
            field_dict["confidence_map"] = confidence_map
        if metadata is not UNSET:
            field_dict["metadata"] = metadata
        if decision_traces is not UNSET:
            field_dict["decision_traces"] = decision_traces

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chronos_snapshot_schema_anchor import ChronosSnapshotSchemaAnchor
        from ..models.chronos_snapshot_schema_confidence_map import ChronosSnapshotSchemaConfidenceMap
        from ..models.chronos_snapshot_schema_decision_traces_item import ChronosSnapshotSchemaDecisionTracesItem
        from ..models.chronos_snapshot_schema_edges_item import ChronosSnapshotSchemaEdgesItem
        from ..models.chronos_snapshot_schema_metadata import ChronosSnapshotSchemaMetadata
        from ..models.chronos_snapshot_schema_nodes_item import ChronosSnapshotSchemaNodesItem

        d = dict(src_dict)
        snapshot_id = d.pop("snapshot_id")

        _status = d.pop("status", UNSET)
        status: ChronosSnapshotSchemaStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = ChronosSnapshotSchemaStatus(_status)

        _generated_at = d.pop("generated_at", UNSET)
        generated_at: datetime.datetime | Unset
        if isinstance(_generated_at, Unset):
            generated_at = UNSET
        else:
            generated_at = isoparse(_generated_at)

        _retrieval_time = d.pop("retrieval_time", UNSET)
        retrieval_time: datetime.datetime | Unset
        if isinstance(_retrieval_time, Unset):
            retrieval_time = UNSET
        else:
            retrieval_time = isoparse(_retrieval_time)

        _anchor = d.pop("anchor", UNSET)
        anchor: ChronosSnapshotSchemaAnchor | Unset
        if isinstance(_anchor, Unset):
            anchor = UNSET
        else:
            anchor = ChronosSnapshotSchemaAnchor.from_dict(_anchor)

        anchors = cast(list[str], d.pop("anchors", UNSET))

        depth = d.pop("depth", UNSET)

        _valid_time = d.pop("valid_time", UNSET)
        valid_time: datetime.datetime | Unset
        if isinstance(_valid_time, Unset):
            valid_time = UNSET
        else:
            valid_time = isoparse(_valid_time)

        estimated_nodes = d.pop("estimated_nodes", UNSET)

        _nodes = d.pop("nodes", UNSET)
        nodes: list[ChronosSnapshotSchemaNodesItem] | Unset = UNSET
        if _nodes is not UNSET:
            nodes = []
            for nodes_item_data in _nodes:
                nodes_item = ChronosSnapshotSchemaNodesItem.from_dict(nodes_item_data)

                nodes.append(nodes_item)

        _edges = d.pop("edges", UNSET)
        edges: list[ChronosSnapshotSchemaEdgesItem] | Unset = UNSET
        if _edges is not UNSET:
            edges = []
            for edges_item_data in _edges:
                edges_item = ChronosSnapshotSchemaEdgesItem.from_dict(edges_item_data)

                edges.append(edges_item)

        _confidence_map = d.pop("confidence_map", UNSET)
        confidence_map: ChronosSnapshotSchemaConfidenceMap | Unset
        if isinstance(_confidence_map, Unset):
            confidence_map = UNSET
        else:
            confidence_map = ChronosSnapshotSchemaConfidenceMap.from_dict(_confidence_map)

        _metadata = d.pop("metadata", UNSET)
        metadata: ChronosSnapshotSchemaMetadata | Unset
        if isinstance(_metadata, Unset):
            metadata = UNSET
        else:
            metadata = ChronosSnapshotSchemaMetadata.from_dict(_metadata)

        _decision_traces = d.pop("decision_traces", UNSET)
        decision_traces: list[ChronosSnapshotSchemaDecisionTracesItem] | Unset = UNSET
        if _decision_traces is not UNSET:
            decision_traces = []
            for decision_traces_item_data in _decision_traces:
                decision_traces_item = ChronosSnapshotSchemaDecisionTracesItem.from_dict(decision_traces_item_data)

                decision_traces.append(decision_traces_item)

        chronos_snapshot_schema = cls(
            snapshot_id=snapshot_id,
            status=status,
            generated_at=generated_at,
            retrieval_time=retrieval_time,
            anchor=anchor,
            anchors=anchors,
            depth=depth,
            valid_time=valid_time,
            estimated_nodes=estimated_nodes,
            nodes=nodes,
            edges=edges,
            confidence_map=confidence_map,
            metadata=metadata,
            decision_traces=decision_traces,
        )

        chronos_snapshot_schema.additional_properties = d
        return chronos_snapshot_schema

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
