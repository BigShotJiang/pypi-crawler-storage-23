from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

from ..models.arbiter_promote_policy_body_status import ArbiterPromotePolicyBodyStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="ArbiterPromotePolicyBody")


@_attrs_define
class ArbiterPromotePolicyBody:
    """
    Attributes:
        version (str):
        status (ArbiterPromotePolicyBodyStatus):
        simulation_job_id (str | Unset):
    """

    version: str
    status: ArbiterPromotePolicyBodyStatus
    simulation_job_id: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        version = self.version

        status = self.status.value

        simulation_job_id = self.simulation_job_id

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "version": version,
                "status": status,
            }
        )
        if simulation_job_id is not UNSET:
            field_dict["simulation_job_id"] = simulation_job_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        version = d.pop("version")

        status = ArbiterPromotePolicyBodyStatus(d.pop("status"))

        simulation_job_id = d.pop("simulation_job_id", UNSET)

        arbiter_promote_policy_body = cls(
            version=version,
            status=status,
            simulation_job_id=simulation_job_id,
        )

        return arbiter_promote_policy_body
