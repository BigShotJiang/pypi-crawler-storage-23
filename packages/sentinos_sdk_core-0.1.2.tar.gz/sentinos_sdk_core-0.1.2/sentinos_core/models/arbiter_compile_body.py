from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="ArbiterCompileBody")


@_attrs_define
class ArbiterCompileBody:
    """
    Attributes:
        nl_text (str | Unset):
        rego (str | Unset):
        policy_id (str | Unset):
        target_tools (list[str] | Unset):
        owner (str | Unset):
        severity (str | Unset):
        tags (list[str] | Unset):
        template_id (str | Unset):
    """

    nl_text: str | Unset = UNSET
    rego: str | Unset = UNSET
    policy_id: str | Unset = UNSET
    target_tools: list[str] | Unset = UNSET
    owner: str | Unset = UNSET
    severity: str | Unset = UNSET
    tags: list[str] | Unset = UNSET
    template_id: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        nl_text = self.nl_text

        rego = self.rego

        policy_id = self.policy_id

        target_tools: list[str] | Unset = UNSET
        if not isinstance(self.target_tools, Unset):
            target_tools = self.target_tools

        owner = self.owner

        severity = self.severity

        tags: list[str] | Unset = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags

        template_id = self.template_id

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if nl_text is not UNSET:
            field_dict["nl_text"] = nl_text
        if rego is not UNSET:
            field_dict["rego"] = rego
        if policy_id is not UNSET:
            field_dict["policy_id"] = policy_id
        if target_tools is not UNSET:
            field_dict["target_tools"] = target_tools
        if owner is not UNSET:
            field_dict["owner"] = owner
        if severity is not UNSET:
            field_dict["severity"] = severity
        if tags is not UNSET:
            field_dict["tags"] = tags
        if template_id is not UNSET:
            field_dict["template_id"] = template_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        nl_text = d.pop("nl_text", UNSET)

        rego = d.pop("rego", UNSET)

        policy_id = d.pop("policy_id", UNSET)

        target_tools = cast(list[str], d.pop("target_tools", UNSET))

        owner = d.pop("owner", UNSET)

        severity = d.pop("severity", UNSET)

        tags = cast(list[str], d.pop("tags", UNSET))

        template_id = d.pop("template_id", UNSET)

        arbiter_compile_body = cls(
            nl_text=nl_text,
            rego=rego,
            policy_id=policy_id,
            target_tools=target_tools,
            owner=owner,
            severity=severity,
            tags=tags,
            template_id=template_id,
        )

        return arbiter_compile_body
