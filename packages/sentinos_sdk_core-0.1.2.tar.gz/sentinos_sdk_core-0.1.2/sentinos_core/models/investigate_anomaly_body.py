from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="InvestigateAnomalyBody")


@_attrs_define
class InvestigateAnomalyBody:
    """
    Attributes:
        notes (str | Unset):
        false_positive (bool | Unset):
    """

    notes: str | Unset = UNSET
    false_positive: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        notes = self.notes

        false_positive = self.false_positive

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if notes is not UNSET:
            field_dict["notes"] = notes
        if false_positive is not UNSET:
            field_dict["false_positive"] = false_positive

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        notes = d.pop("notes", UNSET)

        false_positive = d.pop("false_positive", UNSET)

        investigate_anomaly_body = cls(
            notes=notes,
            false_positive=false_positive,
        )

        investigate_anomaly_body.additional_properties = d
        return investigate_anomaly_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
