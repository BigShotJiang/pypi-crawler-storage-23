from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.integration_channel_health_status import IntegrationChannelHealthStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="IntegrationChannelHealth")


@_attrs_define
class IntegrationChannelHealth:
    """
    Attributes:
        channel_id (UUID | Unset):
        kind (str | Unset):
        name (str | Unset):
        enabled (bool | Unset):
        status (IntegrationChannelHealthStatus | Unset):
        error (str | Unset):
    """

    channel_id: UUID | Unset = UNSET
    kind: str | Unset = UNSET
    name: str | Unset = UNSET
    enabled: bool | Unset = UNSET
    status: IntegrationChannelHealthStatus | Unset = UNSET
    error: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        channel_id: str | Unset = UNSET
        if not isinstance(self.channel_id, Unset):
            channel_id = str(self.channel_id)

        kind = self.kind

        name = self.name

        enabled = self.enabled

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        error = self.error

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if channel_id is not UNSET:
            field_dict["channel_id"] = channel_id
        if kind is not UNSET:
            field_dict["kind"] = kind
        if name is not UNSET:
            field_dict["name"] = name
        if enabled is not UNSET:
            field_dict["enabled"] = enabled
        if status is not UNSET:
            field_dict["status"] = status
        if error is not UNSET:
            field_dict["error"] = error

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _channel_id = d.pop("channel_id", UNSET)
        channel_id: UUID | Unset
        if isinstance(_channel_id, Unset):
            channel_id = UNSET
        else:
            channel_id = UUID(_channel_id)

        kind = d.pop("kind", UNSET)

        name = d.pop("name", UNSET)

        enabled = d.pop("enabled", UNSET)

        _status = d.pop("status", UNSET)
        status: IntegrationChannelHealthStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = IntegrationChannelHealthStatus(_status)

        error = d.pop("error", UNSET)

        integration_channel_health = cls(
            channel_id=channel_id,
            kind=kind,
            name=name,
            enabled=enabled,
            status=status,
            error=error,
        )

        integration_channel_health.additional_properties = d
        return integration_channel_health

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
