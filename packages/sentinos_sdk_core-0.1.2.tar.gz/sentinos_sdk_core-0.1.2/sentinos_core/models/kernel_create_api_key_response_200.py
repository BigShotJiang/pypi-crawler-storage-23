from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.api_key_record import ApiKeyRecord


T = TypeVar("T", bound="KernelCreateApiKeyResponse200")


@_attrs_define
class KernelCreateApiKeyResponse200:
    """
    Attributes:
        key (ApiKeyRecord):
        secret (str):
    """

    key: ApiKeyRecord
    secret: str

    def to_dict(self) -> dict[str, Any]:
        key = self.key.to_dict()

        secret = self.secret

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "key": key,
                "secret": secret,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.api_key_record import ApiKeyRecord

        d = dict(src_dict)
        key = ApiKeyRecord.from_dict(d.pop("key"))

        secret = d.pop("secret")

        kernel_create_api_key_response_200 = cls(
            key=key,
            secret=secret,
        )

        return kernel_create_api_key_response_200
