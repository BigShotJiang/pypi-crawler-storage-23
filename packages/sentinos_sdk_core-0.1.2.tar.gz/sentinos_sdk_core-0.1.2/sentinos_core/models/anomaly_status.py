from enum import Enum


class AnomalyStatus(str, Enum):
    CLOSED = "CLOSED"
    FALSE_POSITIVE = "FALSE_POSITIVE"
    INVESTIGATING = "INVESTIGATING"
    OPEN = "OPEN"

    def __str__(self) -> str:
        return str(self.value)
