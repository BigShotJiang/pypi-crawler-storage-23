from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

from ..models.decision import Decision
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.arbiter_evaluate_response_explain_plan import ArbiterEvaluateResponseExplainPlan


T = TypeVar("T", bound="ArbiterEvaluateResponse")


@_attrs_define
class ArbiterEvaluateResponse:
    """
    Attributes:
        decision (Decision):
        policy_version (str | Unset):
        reason (str | Unset):
        evidence (list[Any] | Unset):
        explain_plan (ArbiterEvaluateResponseExplainPlan | Unset):
    """

    decision: Decision
    policy_version: str | Unset = UNSET
    reason: str | Unset = UNSET
    evidence: list[Any] | Unset = UNSET
    explain_plan: ArbiterEvaluateResponseExplainPlan | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        decision = self.decision.value

        policy_version = self.policy_version

        reason = self.reason

        evidence: list[Any] | Unset = UNSET
        if not isinstance(self.evidence, Unset):
            evidence = self.evidence

        explain_plan: dict[str, Any] | Unset = UNSET
        if not isinstance(self.explain_plan, Unset):
            explain_plan = self.explain_plan.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "decision": decision,
            }
        )
        if policy_version is not UNSET:
            field_dict["policy_version"] = policy_version
        if reason is not UNSET:
            field_dict["reason"] = reason
        if evidence is not UNSET:
            field_dict["evidence"] = evidence
        if explain_plan is not UNSET:
            field_dict["explain_plan"] = explain_plan

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.arbiter_evaluate_response_explain_plan import ArbiterEvaluateResponseExplainPlan

        d = dict(src_dict)
        decision = Decision(d.pop("decision"))

        policy_version = d.pop("policy_version", UNSET)

        reason = d.pop("reason", UNSET)

        evidence = cast(list[Any], d.pop("evidence", UNSET))

        _explain_plan = d.pop("explain_plan", UNSET)
        explain_plan: ArbiterEvaluateResponseExplainPlan | Unset
        if isinstance(_explain_plan, Unset):
            explain_plan = UNSET
        else:
            explain_plan = ArbiterEvaluateResponseExplainPlan.from_dict(_explain_plan)

        arbiter_evaluate_response = cls(
            decision=decision,
            policy_version=policy_version,
            reason=reason,
            evidence=evidence,
            explain_plan=explain_plan,
        )

        return arbiter_evaluate_response
