from enum import Enum


class AlertRuleRuleType(str, Enum):
    ANOMALY = "ANOMALY"
    COMPLIANCE = "COMPLIANCE"
    PATTERN = "PATTERN"
    THRESHOLD = "THRESHOLD"

    def __str__(self) -> str:
        return str(self.value)
