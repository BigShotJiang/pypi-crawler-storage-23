from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ExportDatadogBody")


@_attrs_define
class ExportDatadogBody:
    """
    Attributes:
        api_key (str):
        api_base_url (str | Unset):
        site (str | Unset):
        app_key (str | Unset):
        metric_prefix (str | Unset):
        include_events (bool | Unset):
        limit (int | Unset):
    """

    api_key: str
    api_base_url: str | Unset = UNSET
    site: str | Unset = UNSET
    app_key: str | Unset = UNSET
    metric_prefix: str | Unset = UNSET
    include_events: bool | Unset = UNSET
    limit: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        api_key = self.api_key

        api_base_url = self.api_base_url

        site = self.site

        app_key = self.app_key

        metric_prefix = self.metric_prefix

        include_events = self.include_events

        limit = self.limit

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "api_key": api_key,
            }
        )
        if api_base_url is not UNSET:
            field_dict["api_base_url"] = api_base_url
        if site is not UNSET:
            field_dict["site"] = site
        if app_key is not UNSET:
            field_dict["app_key"] = app_key
        if metric_prefix is not UNSET:
            field_dict["metric_prefix"] = metric_prefix
        if include_events is not UNSET:
            field_dict["include_events"] = include_events
        if limit is not UNSET:
            field_dict["limit"] = limit

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        api_key = d.pop("api_key")

        api_base_url = d.pop("api_base_url", UNSET)

        site = d.pop("site", UNSET)

        app_key = d.pop("app_key", UNSET)

        metric_prefix = d.pop("metric_prefix", UNSET)

        include_events = d.pop("include_events", UNSET)

        limit = d.pop("limit", UNSET)

        export_datadog_body = cls(
            api_key=api_key,
            api_base_url=api_base_url,
            site=site,
            app_key=app_key,
            metric_prefix=metric_prefix,
            include_events=include_events,
            limit=limit,
        )

        export_datadog_body.additional_properties = d
        return export_datadog_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
