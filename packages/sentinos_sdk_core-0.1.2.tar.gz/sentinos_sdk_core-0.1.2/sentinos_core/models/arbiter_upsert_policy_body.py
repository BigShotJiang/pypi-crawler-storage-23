from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

from ..models.arbiter_upsert_policy_body_status import ArbiterUpsertPolicyBodyStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.policy_metadata_schema import PolicyMetadataSchema


T = TypeVar("T", bound="ArbiterUpsertPolicyBody")


@_attrs_define
class ArbiterUpsertPolicyBody:
    """
    Attributes:
        metadata (PolicyMetadataSchema):
        rego (str):
        status (ArbiterUpsertPolicyBodyStatus | Unset):
    """

    metadata: PolicyMetadataSchema
    rego: str
    status: ArbiterUpsertPolicyBodyStatus | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        metadata = self.metadata.to_dict()

        rego = self.rego

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "metadata": metadata,
                "rego": rego,
            }
        )
        if status is not UNSET:
            field_dict["status"] = status

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.policy_metadata_schema import PolicyMetadataSchema

        d = dict(src_dict)
        metadata = PolicyMetadataSchema.from_dict(d.pop("metadata"))

        rego = d.pop("rego")

        _status = d.pop("status", UNSET)
        status: ArbiterUpsertPolicyBodyStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = ArbiterUpsertPolicyBodyStatus(_status)

        arbiter_upsert_policy_body = cls(
            metadata=metadata,
            rego=rego,
            status=status,
        )

        return arbiter_upsert_policy_body
