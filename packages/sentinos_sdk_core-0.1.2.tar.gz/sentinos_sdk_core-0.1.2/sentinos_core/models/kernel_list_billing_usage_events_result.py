from enum import Enum


class KernelListBillingUsageEventsResult(str, Enum):
    CONSUMED = "CONSUMED"
    REJECTED = "REJECTED"

    def __str__(self) -> str:
        return str(self.value)
