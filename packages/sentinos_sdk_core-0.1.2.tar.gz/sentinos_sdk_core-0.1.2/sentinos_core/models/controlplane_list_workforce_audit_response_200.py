from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.controlplane_list_workforce_audit_response_200_audit_item import (
        ControlplaneListWorkforceAuditResponse200AuditItem,
    )


T = TypeVar("T", bound="ControlplaneListWorkforceAuditResponse200")


@_attrs_define
class ControlplaneListWorkforceAuditResponse200:
    """
    Attributes:
        audit (list[ControlplaneListWorkforceAuditResponse200AuditItem]):
    """

    audit: list[ControlplaneListWorkforceAuditResponse200AuditItem]

    def to_dict(self) -> dict[str, Any]:
        audit = []
        for audit_item_data in self.audit:
            audit_item = audit_item_data.to_dict()
            audit.append(audit_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "audit": audit,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.controlplane_list_workforce_audit_response_200_audit_item import (
            ControlplaneListWorkforceAuditResponse200AuditItem,
        )

        d = dict(src_dict)
        audit = []
        _audit = d.pop("audit")
        for audit_item_data in _audit:
            audit_item = ControlplaneListWorkforceAuditResponse200AuditItem.from_dict(audit_item_data)

            audit.append(audit_item)

        controlplane_list_workforce_audit_response_200 = cls(
            audit=audit,
        )

        return controlplane_list_workforce_audit_response_200
