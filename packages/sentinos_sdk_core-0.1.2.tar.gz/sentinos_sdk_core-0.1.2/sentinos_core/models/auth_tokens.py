from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from dateutil.parser import isoparse

T = TypeVar("T", bound="AuthTokens")


@_attrs_define
class AuthTokens:
    """
    Attributes:
        access_token (str):
        refresh_token (str):
        expires_at (datetime.datetime):
        refresh_expires_at (datetime.datetime):
        session_id (UUID):
        org_id (UUID):
        tenant_id (UUID):
        membership_id (UUID):
        permissions (list[str]):
        roles (list[str]):
    """

    access_token: str
    refresh_token: str
    expires_at: datetime.datetime
    refresh_expires_at: datetime.datetime
    session_id: UUID
    org_id: UUID
    tenant_id: UUID
    membership_id: UUID
    permissions: list[str]
    roles: list[str]

    def to_dict(self) -> dict[str, Any]:
        access_token = self.access_token

        refresh_token = self.refresh_token

        expires_at = self.expires_at.isoformat()

        refresh_expires_at = self.refresh_expires_at.isoformat()

        session_id = str(self.session_id)

        org_id = str(self.org_id)

        tenant_id = str(self.tenant_id)

        membership_id = str(self.membership_id)

        permissions = self.permissions

        roles = self.roles

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "access_token": access_token,
                "refresh_token": refresh_token,
                "expires_at": expires_at,
                "refresh_expires_at": refresh_expires_at,
                "session_id": session_id,
                "org_id": org_id,
                "tenant_id": tenant_id,
                "membership_id": membership_id,
                "permissions": permissions,
                "roles": roles,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        access_token = d.pop("access_token")

        refresh_token = d.pop("refresh_token")

        expires_at = isoparse(d.pop("expires_at"))

        refresh_expires_at = isoparse(d.pop("refresh_expires_at"))

        session_id = UUID(d.pop("session_id"))

        org_id = UUID(d.pop("org_id"))

        tenant_id = UUID(d.pop("tenant_id"))

        membership_id = UUID(d.pop("membership_id"))

        permissions = cast(list[str], d.pop("permissions"))

        roles = cast(list[str], d.pop("roles"))

        auth_tokens = cls(
            access_token=access_token,
            refresh_token=refresh_token,
            expires_at=expires_at,
            refresh_expires_at=refresh_expires_at,
            session_id=session_id,
            org_id=org_id,
            tenant_id=tenant_id,
            membership_id=membership_id,
            permissions=permissions,
            roles=roles,
        )

        return auth_tokens
