from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.api_key_record import ApiKeyRecord


T = TypeVar("T", bound="KernelListApiKeysResponse200")


@_attrs_define
class KernelListApiKeysResponse200:
    """
    Attributes:
        keys (list[ApiKeyRecord]):
    """

    keys: list[ApiKeyRecord]

    def to_dict(self) -> dict[str, Any]:
        keys = []
        for keys_item_data in self.keys:
            keys_item = keys_item_data.to_dict()
            keys.append(keys_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "keys": keys,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.api_key_record import ApiKeyRecord

        d = dict(src_dict)
        keys = []
        _keys = d.pop("keys")
        for keys_item_data in _keys:
            keys_item = ApiKeyRecord.from_dict(keys_item_data)

            keys.append(keys_item)

        kernel_list_api_keys_response_200 = cls(
            keys=keys,
        )

        return kernel_list_api_keys_response_200
