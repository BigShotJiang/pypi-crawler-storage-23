from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.policy_list_item import PolicyListItem


T = TypeVar("T", bound="ArbiterListPoliciesResponse200")


@_attrs_define
class ArbiterListPoliciesResponse200:
    """
    Attributes:
        policies (list[PolicyListItem]):
    """

    policies: list[PolicyListItem]

    def to_dict(self) -> dict[str, Any]:
        policies = []
        for policies_item_data in self.policies:
            policies_item = policies_item_data.to_dict()
            policies.append(policies_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "policies": policies,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.policy_list_item import PolicyListItem

        d = dict(src_dict)
        policies = []
        _policies = d.pop("policies")
        for policies_item_data in _policies:
            policies_item = PolicyListItem.from_dict(policies_item_data)

            policies.append(policies_item)

        arbiter_list_policies_response_200 = cls(
            policies=policies,
        )

        return arbiter_list_policies_response_200
