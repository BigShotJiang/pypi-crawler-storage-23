from enum import Enum


class ConditionAstType(str, Enum):
    AND = "and"
    CMP = "cmp"
    NOT = "not"
    OR = "or"

    def __str__(self) -> str:
        return str(self.value)
