from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="JSONRPCRequest")


@_attrs_define
class JSONRPCRequest:
    """
    Attributes:
        method (str):
        jsonrpc (str | Unset):
        id (Any | Unset):
        params (Any | Unset):
    """

    method: str
    jsonrpc: str | Unset = UNSET
    id: Any | Unset = UNSET
    params: Any | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        method = self.method

        jsonrpc = self.jsonrpc

        id = self.id

        params = self.params

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "method": method,
            }
        )
        if jsonrpc is not UNSET:
            field_dict["jsonrpc"] = jsonrpc
        if id is not UNSET:
            field_dict["id"] = id
        if params is not UNSET:
            field_dict["params"] = params

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        method = d.pop("method")

        jsonrpc = d.pop("jsonrpc", UNSET)

        id = d.pop("id", UNSET)

        params = d.pop("params", UNSET)

        jsonrpc_request = cls(
            method=method,
            jsonrpc=jsonrpc,
            id=id,
            params=params,
        )

        jsonrpc_request.additional_properties = d
        return jsonrpc_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
