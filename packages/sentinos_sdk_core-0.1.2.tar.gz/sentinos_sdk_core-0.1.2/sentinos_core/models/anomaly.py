from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.anomaly_status import AnomalyStatus
from ..models.anomaly_type import AnomalyType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.anomaly_context import AnomalyContext


T = TypeVar("T", bound="Anomaly")


@_attrs_define
class Anomaly:
    """
    Attributes:
        anomaly_id (UUID):
        tenant_id (str):
        type_ (AnomalyType):
        status (AnomalyStatus):
        false_positive (bool):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        rule_id (UUID | Unset):
        metric_key (str | Unset):
        observed_value (float | Unset):
        expected_value (float | Unset):
        z_score (float | Unset):
        confidence (float | Unset):
        investigation_notes (str | Unset):
        investigated_by (str | Unset):
        investigated_at (datetime.datetime | Unset):
        linked_alert_id (UUID | Unset):
        context (AnomalyContext | Unset):
    """

    anomaly_id: UUID
    tenant_id: str
    type_: AnomalyType
    status: AnomalyStatus
    false_positive: bool
    created_at: datetime.datetime
    updated_at: datetime.datetime
    rule_id: UUID | Unset = UNSET
    metric_key: str | Unset = UNSET
    observed_value: float | Unset = UNSET
    expected_value: float | Unset = UNSET
    z_score: float | Unset = UNSET
    confidence: float | Unset = UNSET
    investigation_notes: str | Unset = UNSET
    investigated_by: str | Unset = UNSET
    investigated_at: datetime.datetime | Unset = UNSET
    linked_alert_id: UUID | Unset = UNSET
    context: AnomalyContext | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        anomaly_id = str(self.anomaly_id)

        tenant_id = self.tenant_id

        type_ = self.type_.value

        status = self.status.value

        false_positive = self.false_positive

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        rule_id: str | Unset = UNSET
        if not isinstance(self.rule_id, Unset):
            rule_id = str(self.rule_id)

        metric_key = self.metric_key

        observed_value = self.observed_value

        expected_value = self.expected_value

        z_score = self.z_score

        confidence = self.confidence

        investigation_notes = self.investigation_notes

        investigated_by = self.investigated_by

        investigated_at: str | Unset = UNSET
        if not isinstance(self.investigated_at, Unset):
            investigated_at = self.investigated_at.isoformat()

        linked_alert_id: str | Unset = UNSET
        if not isinstance(self.linked_alert_id, Unset):
            linked_alert_id = str(self.linked_alert_id)

        context: dict[str, Any] | Unset = UNSET
        if not isinstance(self.context, Unset):
            context = self.context.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "anomaly_id": anomaly_id,
                "tenant_id": tenant_id,
                "type": type_,
                "status": status,
                "false_positive": false_positive,
                "created_at": created_at,
                "updated_at": updated_at,
            }
        )
        if rule_id is not UNSET:
            field_dict["rule_id"] = rule_id
        if metric_key is not UNSET:
            field_dict["metric_key"] = metric_key
        if observed_value is not UNSET:
            field_dict["observed_value"] = observed_value
        if expected_value is not UNSET:
            field_dict["expected_value"] = expected_value
        if z_score is not UNSET:
            field_dict["z_score"] = z_score
        if confidence is not UNSET:
            field_dict["confidence"] = confidence
        if investigation_notes is not UNSET:
            field_dict["investigation_notes"] = investigation_notes
        if investigated_by is not UNSET:
            field_dict["investigated_by"] = investigated_by
        if investigated_at is not UNSET:
            field_dict["investigated_at"] = investigated_at
        if linked_alert_id is not UNSET:
            field_dict["linked_alert_id"] = linked_alert_id
        if context is not UNSET:
            field_dict["context"] = context

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.anomaly_context import AnomalyContext

        d = dict(src_dict)
        anomaly_id = UUID(d.pop("anomaly_id"))

        tenant_id = d.pop("tenant_id")

        type_ = AnomalyType(d.pop("type"))

        status = AnomalyStatus(d.pop("status"))

        false_positive = d.pop("false_positive")

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        _rule_id = d.pop("rule_id", UNSET)
        rule_id: UUID | Unset
        if isinstance(_rule_id, Unset):
            rule_id = UNSET
        else:
            rule_id = UUID(_rule_id)

        metric_key = d.pop("metric_key", UNSET)

        observed_value = d.pop("observed_value", UNSET)

        expected_value = d.pop("expected_value", UNSET)

        z_score = d.pop("z_score", UNSET)

        confidence = d.pop("confidence", UNSET)

        investigation_notes = d.pop("investigation_notes", UNSET)

        investigated_by = d.pop("investigated_by", UNSET)

        _investigated_at = d.pop("investigated_at", UNSET)
        investigated_at: datetime.datetime | Unset
        if isinstance(_investigated_at, Unset):
            investigated_at = UNSET
        else:
            investigated_at = isoparse(_investigated_at)

        _linked_alert_id = d.pop("linked_alert_id", UNSET)
        linked_alert_id: UUID | Unset
        if isinstance(_linked_alert_id, Unset):
            linked_alert_id = UNSET
        else:
            linked_alert_id = UUID(_linked_alert_id)

        _context = d.pop("context", UNSET)
        context: AnomalyContext | Unset
        if isinstance(_context, Unset):
            context = UNSET
        else:
            context = AnomalyContext.from_dict(_context)

        anomaly = cls(
            anomaly_id=anomaly_id,
            tenant_id=tenant_id,
            type_=type_,
            status=status,
            false_positive=false_positive,
            created_at=created_at,
            updated_at=updated_at,
            rule_id=rule_id,
            metric_key=metric_key,
            observed_value=observed_value,
            expected_value=expected_value,
            z_score=z_score,
            confidence=confidence,
            investigation_notes=investigation_notes,
            investigated_by=investigated_by,
            investigated_at=investigated_at,
            linked_alert_id=linked_alert_id,
            context=context,
        )

        anomaly.additional_properties = d
        return anomaly

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
