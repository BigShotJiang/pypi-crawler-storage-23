from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="IntegrationDeliveryResult")


@_attrs_define
class IntegrationDeliveryResult:
    """
    Attributes:
        channel_id (UUID | Unset):
        kind (str | Unset):
        name (str | Unset):
        success (bool | Unset):
        attempts (int | Unset):
        error (str | Unset):
        delivered_at (datetime.datetime | Unset):
        latency_ms (int | Unset):
    """

    channel_id: UUID | Unset = UNSET
    kind: str | Unset = UNSET
    name: str | Unset = UNSET
    success: bool | Unset = UNSET
    attempts: int | Unset = UNSET
    error: str | Unset = UNSET
    delivered_at: datetime.datetime | Unset = UNSET
    latency_ms: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        channel_id: str | Unset = UNSET
        if not isinstance(self.channel_id, Unset):
            channel_id = str(self.channel_id)

        kind = self.kind

        name = self.name

        success = self.success

        attempts = self.attempts

        error = self.error

        delivered_at: str | Unset = UNSET
        if not isinstance(self.delivered_at, Unset):
            delivered_at = self.delivered_at.isoformat()

        latency_ms = self.latency_ms

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if channel_id is not UNSET:
            field_dict["channel_id"] = channel_id
        if kind is not UNSET:
            field_dict["kind"] = kind
        if name is not UNSET:
            field_dict["name"] = name
        if success is not UNSET:
            field_dict["success"] = success
        if attempts is not UNSET:
            field_dict["attempts"] = attempts
        if error is not UNSET:
            field_dict["error"] = error
        if delivered_at is not UNSET:
            field_dict["delivered_at"] = delivered_at
        if latency_ms is not UNSET:
            field_dict["latency_ms"] = latency_ms

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _channel_id = d.pop("channel_id", UNSET)
        channel_id: UUID | Unset
        if isinstance(_channel_id, Unset):
            channel_id = UNSET
        else:
            channel_id = UUID(_channel_id)

        kind = d.pop("kind", UNSET)

        name = d.pop("name", UNSET)

        success = d.pop("success", UNSET)

        attempts = d.pop("attempts", UNSET)

        error = d.pop("error", UNSET)

        _delivered_at = d.pop("delivered_at", UNSET)
        delivered_at: datetime.datetime | Unset
        if isinstance(_delivered_at, Unset):
            delivered_at = UNSET
        else:
            delivered_at = isoparse(_delivered_at)

        latency_ms = d.pop("latency_ms", UNSET)

        integration_delivery_result = cls(
            channel_id=channel_id,
            kind=kind,
            name=name,
            success=success,
            attempts=attempts,
            error=error,
            delivered_at=delivered_at,
            latency_ms=latency_ms,
        )

        integration_delivery_result.additional_properties = d
        return integration_delivery_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
