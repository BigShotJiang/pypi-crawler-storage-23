from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="ChronosReprocessTracesBody")


@_attrs_define
class ChronosReprocessTracesBody:
    """
    Attributes:
        tenant_id (str | Unset):
        trace_ids (list[UUID] | Unset):
        tool (str | Unset):
        from_ (datetime.datetime | Unset):
        to (datetime.datetime | Unset):
        limit (int | Unset):
        dry_run (bool | Unset):
    """

    tenant_id: str | Unset = UNSET
    trace_ids: list[UUID] | Unset = UNSET
    tool: str | Unset = UNSET
    from_: datetime.datetime | Unset = UNSET
    to: datetime.datetime | Unset = UNSET
    limit: int | Unset = UNSET
    dry_run: bool | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        tenant_id = self.tenant_id

        trace_ids: list[str] | Unset = UNSET
        if not isinstance(self.trace_ids, Unset):
            trace_ids = []
            for trace_ids_item_data in self.trace_ids:
                trace_ids_item = str(trace_ids_item_data)
                trace_ids.append(trace_ids_item)

        tool = self.tool

        from_: str | Unset = UNSET
        if not isinstance(self.from_, Unset):
            from_ = self.from_.isoformat()

        to: str | Unset = UNSET
        if not isinstance(self.to, Unset):
            to = self.to.isoformat()

        limit = self.limit

        dry_run = self.dry_run

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if tenant_id is not UNSET:
            field_dict["tenant_id"] = tenant_id
        if trace_ids is not UNSET:
            field_dict["trace_ids"] = trace_ids
        if tool is not UNSET:
            field_dict["tool"] = tool
        if from_ is not UNSET:
            field_dict["from"] = from_
        if to is not UNSET:
            field_dict["to"] = to
        if limit is not UNSET:
            field_dict["limit"] = limit
        if dry_run is not UNSET:
            field_dict["dry_run"] = dry_run

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        tenant_id = d.pop("tenant_id", UNSET)

        _trace_ids = d.pop("trace_ids", UNSET)
        trace_ids: list[UUID] | Unset = UNSET
        if _trace_ids is not UNSET:
            trace_ids = []
            for trace_ids_item_data in _trace_ids:
                trace_ids_item = UUID(trace_ids_item_data)

                trace_ids.append(trace_ids_item)

        tool = d.pop("tool", UNSET)

        _from_ = d.pop("from", UNSET)
        from_: datetime.datetime | Unset
        if isinstance(_from_, Unset):
            from_ = UNSET
        else:
            from_ = isoparse(_from_)

        _to = d.pop("to", UNSET)
        to: datetime.datetime | Unset
        if isinstance(_to, Unset):
            to = UNSET
        else:
            to = isoparse(_to)

        limit = d.pop("limit", UNSET)

        dry_run = d.pop("dry_run", UNSET)

        chronos_reprocess_traces_body = cls(
            tenant_id=tenant_id,
            trace_ids=trace_ids,
            tool=tool,
            from_=from_,
            to=to,
            limit=limit,
            dry_run=dry_run,
        )

        return chronos_reprocess_traces_body
