from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="DecisionTraceOrganizationalContext")


@_attrs_define
class DecisionTraceOrganizationalContext:
    """
    Attributes:
        system_state (str | Unset):
        variation_type (str | Unset):
        external_factors (list[str] | Unset):
    """

    system_state: str | Unset = UNSET
    variation_type: str | Unset = UNSET
    external_factors: list[str] | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        system_state = self.system_state

        variation_type = self.variation_type

        external_factors: list[str] | Unset = UNSET
        if not isinstance(self.external_factors, Unset):
            external_factors = self.external_factors

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if system_state is not UNSET:
            field_dict["system_state"] = system_state
        if variation_type is not UNSET:
            field_dict["variation_type"] = variation_type
        if external_factors is not UNSET:
            field_dict["external_factors"] = external_factors

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        system_state = d.pop("system_state", UNSET)

        variation_type = d.pop("variation_type", UNSET)

        external_factors = cast(list[str], d.pop("external_factors", UNSET))

        decision_trace_organizational_context = cls(
            system_state=system_state,
            variation_type=variation_type,
            external_factors=external_factors,
        )

        return decision_trace_organizational_context
