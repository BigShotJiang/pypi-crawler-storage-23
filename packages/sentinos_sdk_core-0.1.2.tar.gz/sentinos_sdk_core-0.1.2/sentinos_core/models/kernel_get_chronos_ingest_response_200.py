from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.chronos_ingest_record import ChronosIngestRecord


T = TypeVar("T", bound="KernelGetChronosIngestResponse200")


@_attrs_define
class KernelGetChronosIngestResponse200:
    """
    Attributes:
        ingest (ChronosIngestRecord):
    """

    ingest: ChronosIngestRecord

    def to_dict(self) -> dict[str, Any]:
        ingest = self.ingest.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "ingest": ingest,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chronos_ingest_record import ChronosIngestRecord

        d = dict(src_dict)
        ingest = ChronosIngestRecord.from_dict(d.pop("ingest"))

        kernel_get_chronos_ingest_response_200 = cls(
            ingest=ingest,
        )

        return kernel_get_chronos_ingest_response_200
