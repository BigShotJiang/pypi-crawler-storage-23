from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

T = TypeVar("T", bound="ControlplaneWorkforceTokenRefreshBody")


@_attrs_define
class ControlplaneWorkforceTokenRefreshBody:
    """
    Attributes:
        refresh_token (str):
    """

    refresh_token: str

    def to_dict(self) -> dict[str, Any]:
        refresh_token = self.refresh_token

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "refresh_token": refresh_token,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        refresh_token = d.pop("refresh_token")

        controlplane_workforce_token_refresh_body = cls(
            refresh_token=refresh_token,
        )

        return controlplane_workforce_token_refresh_body
