from enum import Enum


class ChronosIngestAcceptedResponseStatus(str, Enum):
    ACCEPTED = "accepted"

    def __str__(self) -> str:
        return str(self.value)
