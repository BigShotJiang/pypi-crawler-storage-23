from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.chronos_snapshot_schema_decision_traces_item_policy_eval_summary import (
        ChronosSnapshotSchemaDecisionTracesItemPolicyEvalSummary,
    )
    from ..models.chronos_snapshot_schema_decision_traces_item_signature import (
        ChronosSnapshotSchemaDecisionTracesItemSignature,
    )


T = TypeVar("T", bound="ChronosSnapshotSchemaDecisionTracesItem")


@_attrs_define
class ChronosSnapshotSchemaDecisionTracesItem:
    """
    Attributes:
        trace_id (UUID):
        policy_eval_summary (ChronosSnapshotSchemaDecisionTracesItemPolicyEvalSummary | Unset):
        signature (ChronosSnapshotSchemaDecisionTracesItemSignature | Unset):
        payload_link (str | Unset):
    """

    trace_id: UUID
    policy_eval_summary: ChronosSnapshotSchemaDecisionTracesItemPolicyEvalSummary | Unset = UNSET
    signature: ChronosSnapshotSchemaDecisionTracesItemSignature | Unset = UNSET
    payload_link: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        trace_id = str(self.trace_id)

        policy_eval_summary: dict[str, Any] | Unset = UNSET
        if not isinstance(self.policy_eval_summary, Unset):
            policy_eval_summary = self.policy_eval_summary.to_dict()

        signature: dict[str, Any] | Unset = UNSET
        if not isinstance(self.signature, Unset):
            signature = self.signature.to_dict()

        payload_link = self.payload_link

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "trace_id": trace_id,
            }
        )
        if policy_eval_summary is not UNSET:
            field_dict["policy_eval_summary"] = policy_eval_summary
        if signature is not UNSET:
            field_dict["signature"] = signature
        if payload_link is not UNSET:
            field_dict["payload_link"] = payload_link

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chronos_snapshot_schema_decision_traces_item_policy_eval_summary import (
            ChronosSnapshotSchemaDecisionTracesItemPolicyEvalSummary,
        )
        from ..models.chronos_snapshot_schema_decision_traces_item_signature import (
            ChronosSnapshotSchemaDecisionTracesItemSignature,
        )

        d = dict(src_dict)
        trace_id = UUID(d.pop("trace_id"))

        _policy_eval_summary = d.pop("policy_eval_summary", UNSET)
        policy_eval_summary: ChronosSnapshotSchemaDecisionTracesItemPolicyEvalSummary | Unset
        if isinstance(_policy_eval_summary, Unset):
            policy_eval_summary = UNSET
        else:
            policy_eval_summary = ChronosSnapshotSchemaDecisionTracesItemPolicyEvalSummary.from_dict(
                _policy_eval_summary
            )

        _signature = d.pop("signature", UNSET)
        signature: ChronosSnapshotSchemaDecisionTracesItemSignature | Unset
        if isinstance(_signature, Unset):
            signature = UNSET
        else:
            signature = ChronosSnapshotSchemaDecisionTracesItemSignature.from_dict(_signature)

        payload_link = d.pop("payload_link", UNSET)

        chronos_snapshot_schema_decision_traces_item = cls(
            trace_id=trace_id,
            policy_eval_summary=policy_eval_summary,
            signature=signature,
            payload_link=payload_link,
        )

        chronos_snapshot_schema_decision_traces_item.additional_properties = d
        return chronos_snapshot_schema_decision_traces_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
