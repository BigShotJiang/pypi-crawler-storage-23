from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.workforce_group_mapping import WorkforceGroupMapping


T = TypeVar("T", bound="ControlplaneListWorkforceMappingsResponse200")


@_attrs_define
class ControlplaneListWorkforceMappingsResponse200:
    """
    Attributes:
        mappings (list[WorkforceGroupMapping]):
    """

    mappings: list[WorkforceGroupMapping]

    def to_dict(self) -> dict[str, Any]:
        mappings = []
        for mappings_item_data in self.mappings:
            mappings_item = mappings_item_data.to_dict()
            mappings.append(mappings_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "mappings": mappings,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.workforce_group_mapping import WorkforceGroupMapping

        d = dict(src_dict)
        mappings = []
        _mappings = d.pop("mappings")
        for mappings_item_data in _mappings:
            mappings_item = WorkforceGroupMapping.from_dict(mappings_item_data)

            mappings.append(mappings_item)

        controlplane_list_workforce_mappings_response_200 = cls(
            mappings=mappings,
        )

        return controlplane_list_workforce_mappings_response_200
