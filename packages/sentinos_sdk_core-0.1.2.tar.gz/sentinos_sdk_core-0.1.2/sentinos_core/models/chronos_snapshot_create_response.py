from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..models.chronos_snapshot_create_response_status import ChronosSnapshotCreateResponseStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="ChronosSnapshotCreateResponse")


@_attrs_define
class ChronosSnapshotCreateResponse:
    """
    Attributes:
        snapshot_id (str):
        status (ChronosSnapshotCreateResponseStatus):
        estimated_nodes (int | Unset):
        generated_at (datetime.datetime | Unset):
    """

    snapshot_id: str
    status: ChronosSnapshotCreateResponseStatus
    estimated_nodes: int | Unset = UNSET
    generated_at: datetime.datetime | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        snapshot_id = self.snapshot_id

        status = self.status.value

        estimated_nodes = self.estimated_nodes

        generated_at: str | Unset = UNSET
        if not isinstance(self.generated_at, Unset):
            generated_at = self.generated_at.isoformat()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "snapshot_id": snapshot_id,
                "status": status,
            }
        )
        if estimated_nodes is not UNSET:
            field_dict["estimated_nodes"] = estimated_nodes
        if generated_at is not UNSET:
            field_dict["generated_at"] = generated_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        snapshot_id = d.pop("snapshot_id")

        status = ChronosSnapshotCreateResponseStatus(d.pop("status"))

        estimated_nodes = d.pop("estimated_nodes", UNSET)

        _generated_at = d.pop("generated_at", UNSET)
        generated_at: datetime.datetime | Unset
        if isinstance(_generated_at, Unset):
            generated_at = UNSET
        else:
            generated_at = isoparse(_generated_at)

        chronos_snapshot_create_response = cls(
            snapshot_id=snapshot_id,
            status=status,
            estimated_nodes=estimated_nodes,
            generated_at=generated_at,
        )

        return chronos_snapshot_create_response
