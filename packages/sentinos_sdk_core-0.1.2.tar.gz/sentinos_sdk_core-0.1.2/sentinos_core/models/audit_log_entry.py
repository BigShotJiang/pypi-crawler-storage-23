from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.audit_log_entry_details import AuditLogEntryDetails


T = TypeVar("T", bound="AuditLogEntry")


@_attrs_define
class AuditLogEntry:
    """
    Attributes:
        audit_id (UUID | Unset):
        tenant_id (str | Unset):
        actor (str | Unset):
        action (str | Unset):
        resource_type (str | Unset):
        resource_id (str | Unset):
        details (AuditLogEntryDetails | Unset):
        created_at (datetime.datetime | Unset):
    """

    audit_id: UUID | Unset = UNSET
    tenant_id: str | Unset = UNSET
    actor: str | Unset = UNSET
    action: str | Unset = UNSET
    resource_type: str | Unset = UNSET
    resource_id: str | Unset = UNSET
    details: AuditLogEntryDetails | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        audit_id: str | Unset = UNSET
        if not isinstance(self.audit_id, Unset):
            audit_id = str(self.audit_id)

        tenant_id = self.tenant_id

        actor = self.actor

        action = self.action

        resource_type = self.resource_type

        resource_id = self.resource_id

        details: dict[str, Any] | Unset = UNSET
        if not isinstance(self.details, Unset):
            details = self.details.to_dict()

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if audit_id is not UNSET:
            field_dict["audit_id"] = audit_id
        if tenant_id is not UNSET:
            field_dict["tenant_id"] = tenant_id
        if actor is not UNSET:
            field_dict["actor"] = actor
        if action is not UNSET:
            field_dict["action"] = action
        if resource_type is not UNSET:
            field_dict["resource_type"] = resource_type
        if resource_id is not UNSET:
            field_dict["resource_id"] = resource_id
        if details is not UNSET:
            field_dict["details"] = details
        if created_at is not UNSET:
            field_dict["created_at"] = created_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.audit_log_entry_details import AuditLogEntryDetails

        d = dict(src_dict)
        _audit_id = d.pop("audit_id", UNSET)
        audit_id: UUID | Unset
        if isinstance(_audit_id, Unset):
            audit_id = UNSET
        else:
            audit_id = UUID(_audit_id)

        tenant_id = d.pop("tenant_id", UNSET)

        actor = d.pop("actor", UNSET)

        action = d.pop("action", UNSET)

        resource_type = d.pop("resource_type", UNSET)

        resource_id = d.pop("resource_id", UNSET)

        _details = d.pop("details", UNSET)
        details: AuditLogEntryDetails | Unset
        if isinstance(_details, Unset):
            details = UNSET
        else:
            details = AuditLogEntryDetails.from_dict(_details)

        _created_at = d.pop("created_at", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        audit_log_entry = cls(
            audit_id=audit_id,
            tenant_id=tenant_id,
            actor=actor,
            action=action,
            resource_type=resource_type,
            resource_id=resource_id,
            details=details,
            created_at=created_at,
        )

        audit_log_entry.additional_properties = d
        return audit_log_entry

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
