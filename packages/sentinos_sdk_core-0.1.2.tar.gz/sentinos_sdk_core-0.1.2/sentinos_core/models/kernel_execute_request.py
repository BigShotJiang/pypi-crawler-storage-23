from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.decision_trace_intent import DecisionTraceIntent
    from ..models.kernel_execute_request_metadata import KernelExecuteRequestMetadata


T = TypeVar("T", bound="KernelExecuteRequest")


@_attrs_define
class KernelExecuteRequest:
    """
    Attributes:
        tenant_id (str):
        agent_id (str):
        session_id (str):
        intent (DecisionTraceIntent):
        metadata (KernelExecuteRequestMetadata | Unset): Optional execution metadata.
            Supported keys include:
            - `skip_connector` (boolean): evaluate policy + persist decision trace without invoking Kernel connector
            execution.
              Use this for external LLM/provider calls that are executed by your application after Sentinos authorization.
    """

    tenant_id: str
    agent_id: str
    session_id: str
    intent: DecisionTraceIntent
    metadata: KernelExecuteRequestMetadata | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        tenant_id = self.tenant_id

        agent_id = self.agent_id

        session_id = self.session_id

        intent = self.intent.to_dict()

        metadata: dict[str, Any] | Unset = UNSET
        if not isinstance(self.metadata, Unset):
            metadata = self.metadata.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "tenant_id": tenant_id,
                "agent_id": agent_id,
                "session_id": session_id,
                "intent": intent,
            }
        )
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.decision_trace_intent import DecisionTraceIntent
        from ..models.kernel_execute_request_metadata import KernelExecuteRequestMetadata

        d = dict(src_dict)
        tenant_id = d.pop("tenant_id")

        agent_id = d.pop("agent_id")

        session_id = d.pop("session_id")

        intent = DecisionTraceIntent.from_dict(d.pop("intent"))

        _metadata = d.pop("metadata", UNSET)
        metadata: KernelExecuteRequestMetadata | Unset
        if isinstance(_metadata, Unset):
            metadata = UNSET
        else:
            metadata = KernelExecuteRequestMetadata.from_dict(_metadata)

        kernel_execute_request = cls(
            tenant_id=tenant_id,
            agent_id=agent_id,
            session_id=session_id,
            intent=intent,
            metadata=metadata,
        )

        return kernel_execute_request
