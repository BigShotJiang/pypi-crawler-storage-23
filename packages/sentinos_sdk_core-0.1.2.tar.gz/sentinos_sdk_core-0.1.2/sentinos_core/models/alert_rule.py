from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.alert_rule_comparator import AlertRuleComparator
from ..models.alert_rule_rule_type import AlertRuleRuleType
from ..models.alert_rule_severity import AlertRuleSeverity
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.alert_rule_metadata import AlertRuleMetadata


T = TypeVar("T", bound="AlertRule")


@_attrs_define
class AlertRule:
    """
    Attributes:
        name (str):
        rule_type (AlertRuleRuleType):
        severity (AlertRuleSeverity):
        rule_id (UUID | Unset):
        tenant_id (str | Unset):
        description (str | Unset):
        enabled (bool | Unset):
        metric_key (str | Unset):
        comparator (AlertRuleComparator | Unset):
        threshold_value (float | Unset):
        pattern (str | Unset):
        compliance_control (str | Unset):
        evaluation_window_sec (int | Unset):
        cooldown_sec (int | Unset):
        notification_channels (list[str] | Unset):
        metadata (AlertRuleMetadata | Unset):
        created_by (str | Unset):
        updated_by (str | Unset):
        created_at (datetime.datetime | Unset):
        updated_at (datetime.datetime | Unset):
    """

    name: str
    rule_type: AlertRuleRuleType
    severity: AlertRuleSeverity
    rule_id: UUID | Unset = UNSET
    tenant_id: str | Unset = UNSET
    description: str | Unset = UNSET
    enabled: bool | Unset = UNSET
    metric_key: str | Unset = UNSET
    comparator: AlertRuleComparator | Unset = UNSET
    threshold_value: float | Unset = UNSET
    pattern: str | Unset = UNSET
    compliance_control: str | Unset = UNSET
    evaluation_window_sec: int | Unset = UNSET
    cooldown_sec: int | Unset = UNSET
    notification_channels: list[str] | Unset = UNSET
    metadata: AlertRuleMetadata | Unset = UNSET
    created_by: str | Unset = UNSET
    updated_by: str | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        rule_type = self.rule_type.value

        severity = self.severity.value

        rule_id: str | Unset = UNSET
        if not isinstance(self.rule_id, Unset):
            rule_id = str(self.rule_id)

        tenant_id = self.tenant_id

        description = self.description

        enabled = self.enabled

        metric_key = self.metric_key

        comparator: str | Unset = UNSET
        if not isinstance(self.comparator, Unset):
            comparator = self.comparator.value

        threshold_value = self.threshold_value

        pattern = self.pattern

        compliance_control = self.compliance_control

        evaluation_window_sec = self.evaluation_window_sec

        cooldown_sec = self.cooldown_sec

        notification_channels: list[str] | Unset = UNSET
        if not isinstance(self.notification_channels, Unset):
            notification_channels = self.notification_channels

        metadata: dict[str, Any] | Unset = UNSET
        if not isinstance(self.metadata, Unset):
            metadata = self.metadata.to_dict()

        created_by = self.created_by

        updated_by = self.updated_by

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "rule_type": rule_type,
                "severity": severity,
            }
        )
        if rule_id is not UNSET:
            field_dict["rule_id"] = rule_id
        if tenant_id is not UNSET:
            field_dict["tenant_id"] = tenant_id
        if description is not UNSET:
            field_dict["description"] = description
        if enabled is not UNSET:
            field_dict["enabled"] = enabled
        if metric_key is not UNSET:
            field_dict["metric_key"] = metric_key
        if comparator is not UNSET:
            field_dict["comparator"] = comparator
        if threshold_value is not UNSET:
            field_dict["threshold_value"] = threshold_value
        if pattern is not UNSET:
            field_dict["pattern"] = pattern
        if compliance_control is not UNSET:
            field_dict["compliance_control"] = compliance_control
        if evaluation_window_sec is not UNSET:
            field_dict["evaluation_window_sec"] = evaluation_window_sec
        if cooldown_sec is not UNSET:
            field_dict["cooldown_sec"] = cooldown_sec
        if notification_channels is not UNSET:
            field_dict["notification_channels"] = notification_channels
        if metadata is not UNSET:
            field_dict["metadata"] = metadata
        if created_by is not UNSET:
            field_dict["created_by"] = created_by
        if updated_by is not UNSET:
            field_dict["updated_by"] = updated_by
        if created_at is not UNSET:
            field_dict["created_at"] = created_at
        if updated_at is not UNSET:
            field_dict["updated_at"] = updated_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.alert_rule_metadata import AlertRuleMetadata

        d = dict(src_dict)
        name = d.pop("name")

        rule_type = AlertRuleRuleType(d.pop("rule_type"))

        severity = AlertRuleSeverity(d.pop("severity"))

        _rule_id = d.pop("rule_id", UNSET)
        rule_id: UUID | Unset
        if isinstance(_rule_id, Unset):
            rule_id = UNSET
        else:
            rule_id = UUID(_rule_id)

        tenant_id = d.pop("tenant_id", UNSET)

        description = d.pop("description", UNSET)

        enabled = d.pop("enabled", UNSET)

        metric_key = d.pop("metric_key", UNSET)

        _comparator = d.pop("comparator", UNSET)
        comparator: AlertRuleComparator | Unset
        if isinstance(_comparator, Unset):
            comparator = UNSET
        else:
            comparator = AlertRuleComparator(_comparator)

        threshold_value = d.pop("threshold_value", UNSET)

        pattern = d.pop("pattern", UNSET)

        compliance_control = d.pop("compliance_control", UNSET)

        evaluation_window_sec = d.pop("evaluation_window_sec", UNSET)

        cooldown_sec = d.pop("cooldown_sec", UNSET)

        notification_channels = cast(list[str], d.pop("notification_channels", UNSET))

        _metadata = d.pop("metadata", UNSET)
        metadata: AlertRuleMetadata | Unset
        if isinstance(_metadata, Unset):
            metadata = UNSET
        else:
            metadata = AlertRuleMetadata.from_dict(_metadata)

        created_by = d.pop("created_by", UNSET)

        updated_by = d.pop("updated_by", UNSET)

        _created_at = d.pop("created_at", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        _updated_at = d.pop("updated_at", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        alert_rule = cls(
            name=name,
            rule_type=rule_type,
            severity=severity,
            rule_id=rule_id,
            tenant_id=tenant_id,
            description=description,
            enabled=enabled,
            metric_key=metric_key,
            comparator=comparator,
            threshold_value=threshold_value,
            pattern=pattern,
            compliance_control=compliance_control,
            evaluation_window_sec=evaluation_window_sec,
            cooldown_sec=cooldown_sec,
            notification_channels=notification_channels,
            metadata=metadata,
            created_by=created_by,
            updated_by=updated_by,
            created_at=created_at,
            updated_at=updated_at,
        )

        alert_rule.additional_properties = d
        return alert_rule

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
