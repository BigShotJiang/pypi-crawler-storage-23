from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

T = TypeVar("T", bound="ControlplaneRefreshTokenBody")


@_attrs_define
class ControlplaneRefreshTokenBody:
    """
    Attributes:
        refresh_token (str):
    """

    refresh_token: str

    def to_dict(self) -> dict[str, Any]:
        refresh_token = self.refresh_token

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "refresh_token": refresh_token,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        refresh_token = d.pop("refresh_token")

        controlplane_refresh_token_body = cls(
            refresh_token=refresh_token,
        )

        return controlplane_refresh_token_body
