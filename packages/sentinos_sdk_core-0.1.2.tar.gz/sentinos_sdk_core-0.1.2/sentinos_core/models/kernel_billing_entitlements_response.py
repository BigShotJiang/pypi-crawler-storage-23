from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.tenant_entitlement import TenantEntitlement
    from ..models.tenant_usage_summary import TenantUsageSummary


T = TypeVar("T", bound="KernelBillingEntitlementsResponse")


@_attrs_define
class KernelBillingEntitlementsResponse:
    """
    Attributes:
        entitlement (TenantEntitlement):
        usage (TenantUsageSummary):
    """

    entitlement: TenantEntitlement
    usage: TenantUsageSummary

    def to_dict(self) -> dict[str, Any]:
        entitlement = self.entitlement.to_dict()

        usage = self.usage.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "entitlement": entitlement,
                "usage": usage,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.tenant_entitlement import TenantEntitlement
        from ..models.tenant_usage_summary import TenantUsageSummary

        d = dict(src_dict)
        entitlement = TenantEntitlement.from_dict(d.pop("entitlement"))

        usage = TenantUsageSummary.from_dict(d.pop("usage"))

        kernel_billing_entitlements_response = cls(
            entitlement=entitlement,
            usage=usage,
        )

        return kernel_billing_entitlements_response
