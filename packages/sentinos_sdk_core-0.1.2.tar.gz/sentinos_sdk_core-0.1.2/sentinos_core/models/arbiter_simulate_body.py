from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="ArbiterSimulateBody")


@_attrs_define
class ArbiterSimulateBody:
    """
    Attributes:
        tenant_id (str):
        candidate_rego (str):
        trace_limit (int | Unset):
        policy_id (str | Unset):
        version (str | Unset):
    """

    tenant_id: str
    candidate_rego: str
    trace_limit: int | Unset = UNSET
    policy_id: str | Unset = UNSET
    version: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        tenant_id = self.tenant_id

        candidate_rego = self.candidate_rego

        trace_limit = self.trace_limit

        policy_id = self.policy_id

        version = self.version

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "tenant_id": tenant_id,
                "candidate_rego": candidate_rego,
            }
        )
        if trace_limit is not UNSET:
            field_dict["trace_limit"] = trace_limit
        if policy_id is not UNSET:
            field_dict["policy_id"] = policy_id
        if version is not UNSET:
            field_dict["version"] = version

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        tenant_id = d.pop("tenant_id")

        candidate_rego = d.pop("candidate_rego")

        trace_limit = d.pop("trace_limit", UNSET)

        policy_id = d.pop("policy_id", UNSET)

        version = d.pop("version", UNSET)

        arbiter_simulate_body = cls(
            tenant_id=tenant_id,
            candidate_rego=candidate_rego,
            trace_limit=trace_limit,
            policy_id=policy_id,
            version=version,
        )

        return arbiter_simulate_body
