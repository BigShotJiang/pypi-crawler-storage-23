from enum import Enum


class ArbiterPromotePolicyBodyStatus(str, Enum):
    PROD = "prod"
    STAGING = "staging"

    def __str__(self) -> str:
        return str(self.value)
