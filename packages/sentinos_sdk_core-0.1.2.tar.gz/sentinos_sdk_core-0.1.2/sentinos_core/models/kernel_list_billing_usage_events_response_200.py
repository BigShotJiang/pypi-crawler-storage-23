from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.usage_event import UsageEvent


T = TypeVar("T", bound="KernelListBillingUsageEventsResponse200")


@_attrs_define
class KernelListBillingUsageEventsResponse200:
    """
    Attributes:
        events (list[UsageEvent]):
    """

    events: list[UsageEvent]

    def to_dict(self) -> dict[str, Any]:
        events = []
        for events_item_data in self.events:
            events_item = events_item_data.to_dict()
            events.append(events_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "events": events,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.usage_event import UsageEvent

        d = dict(src_dict)
        events = []
        _events = d.pop("events")
        for events_item_data in _events:
            events_item = UsageEvent.from_dict(events_item_data)

            events.append(events_item)

        kernel_list_billing_usage_events_response_200 = cls(
            events=events,
        )

        return kernel_list_billing_usage_events_response_200
