from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.schemas_chronos_ingest_record import SchemasChronosIngestRecord


T = TypeVar("T", bound="ChronosGetIngestStatusResponse200")


@_attrs_define
class ChronosGetIngestStatusResponse200:
    """
    Attributes:
        ingest (SchemasChronosIngestRecord):
    """

    ingest: SchemasChronosIngestRecord

    def to_dict(self) -> dict[str, Any]:
        ingest = self.ingest.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "ingest": ingest,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.schemas_chronos_ingest_record import SchemasChronosIngestRecord

        d = dict(src_dict)
        ingest = SchemasChronosIngestRecord.from_dict(d.pop("ingest"))

        chronos_get_ingest_status_response_200 = cls(
            ingest=ingest,
        )

        return chronos_get_ingest_status_response_200
