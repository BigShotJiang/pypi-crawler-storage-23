from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

from ..models.kernel_billing_entitlement_patch_request_plan_code import KernelBillingEntitlementPatchRequestPlanCode
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.kernel_billing_entitlement_patch_request_metadata import KernelBillingEntitlementPatchRequestMetadata


T = TypeVar("T", bound="KernelBillingEntitlementPatchRequest")


@_attrs_define
class KernelBillingEntitlementPatchRequest:
    """
    Attributes:
        plan_code (KernelBillingEntitlementPatchRequestPlanCode | Unset):
        execute_monthly_limit (int | Unset):
        trace_export_monthly_limit (int | Unset):
        trace_replay_monthly_limit (int | Unset):
        hard_enforce (bool | Unset):
        metadata (KernelBillingEntitlementPatchRequestMetadata | Unset):
    """

    plan_code: KernelBillingEntitlementPatchRequestPlanCode | Unset = UNSET
    execute_monthly_limit: int | Unset = UNSET
    trace_export_monthly_limit: int | Unset = UNSET
    trace_replay_monthly_limit: int | Unset = UNSET
    hard_enforce: bool | Unset = UNSET
    metadata: KernelBillingEntitlementPatchRequestMetadata | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        plan_code: str | Unset = UNSET
        if not isinstance(self.plan_code, Unset):
            plan_code = self.plan_code.value

        execute_monthly_limit = self.execute_monthly_limit

        trace_export_monthly_limit = self.trace_export_monthly_limit

        trace_replay_monthly_limit = self.trace_replay_monthly_limit

        hard_enforce = self.hard_enforce

        metadata: dict[str, Any] | Unset = UNSET
        if not isinstance(self.metadata, Unset):
            metadata = self.metadata.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if plan_code is not UNSET:
            field_dict["plan_code"] = plan_code
        if execute_monthly_limit is not UNSET:
            field_dict["execute_monthly_limit"] = execute_monthly_limit
        if trace_export_monthly_limit is not UNSET:
            field_dict["trace_export_monthly_limit"] = trace_export_monthly_limit
        if trace_replay_monthly_limit is not UNSET:
            field_dict["trace_replay_monthly_limit"] = trace_replay_monthly_limit
        if hard_enforce is not UNSET:
            field_dict["hard_enforce"] = hard_enforce
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.kernel_billing_entitlement_patch_request_metadata import (
            KernelBillingEntitlementPatchRequestMetadata,
        )

        d = dict(src_dict)
        _plan_code = d.pop("plan_code", UNSET)
        plan_code: KernelBillingEntitlementPatchRequestPlanCode | Unset
        if isinstance(_plan_code, Unset):
            plan_code = UNSET
        else:
            plan_code = KernelBillingEntitlementPatchRequestPlanCode(_plan_code)

        execute_monthly_limit = d.pop("execute_monthly_limit", UNSET)

        trace_export_monthly_limit = d.pop("trace_export_monthly_limit", UNSET)

        trace_replay_monthly_limit = d.pop("trace_replay_monthly_limit", UNSET)

        hard_enforce = d.pop("hard_enforce", UNSET)

        _metadata = d.pop("metadata", UNSET)
        metadata: KernelBillingEntitlementPatchRequestMetadata | Unset
        if isinstance(_metadata, Unset):
            metadata = UNSET
        else:
            metadata = KernelBillingEntitlementPatchRequestMetadata.from_dict(_metadata)

        kernel_billing_entitlement_patch_request = cls(
            plan_code=plan_code,
            execute_monthly_limit=execute_monthly_limit,
            trace_export_monthly_limit=trace_export_monthly_limit,
            trace_replay_monthly_limit=trace_replay_monthly_limit,
            hard_enforce=hard_enforce,
            metadata=metadata,
        )

        return kernel_billing_entitlement_patch_request
