from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="DistributedTraceSummary")


@_attrs_define
class DistributedTraceSummary:
    """
    Attributes:
        trace_id (UUID):
        tenant_id (str):
        distributed_trace_id (str):
        created_at (datetime.datetime):
        agent_id (str | Unset):
        policy_id (str | Unset):
        decision (str | Unset):
        distributed_span_id (str | Unset):
    """

    trace_id: UUID
    tenant_id: str
    distributed_trace_id: str
    created_at: datetime.datetime
    agent_id: str | Unset = UNSET
    policy_id: str | Unset = UNSET
    decision: str | Unset = UNSET
    distributed_span_id: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        trace_id = str(self.trace_id)

        tenant_id = self.tenant_id

        distributed_trace_id = self.distributed_trace_id

        created_at = self.created_at.isoformat()

        agent_id = self.agent_id

        policy_id = self.policy_id

        decision = self.decision

        distributed_span_id = self.distributed_span_id

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "trace_id": trace_id,
                "tenant_id": tenant_id,
                "distributed_trace_id": distributed_trace_id,
                "created_at": created_at,
            }
        )
        if agent_id is not UNSET:
            field_dict["agent_id"] = agent_id
        if policy_id is not UNSET:
            field_dict["policy_id"] = policy_id
        if decision is not UNSET:
            field_dict["decision"] = decision
        if distributed_span_id is not UNSET:
            field_dict["distributed_span_id"] = distributed_span_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        trace_id = UUID(d.pop("trace_id"))

        tenant_id = d.pop("tenant_id")

        distributed_trace_id = d.pop("distributed_trace_id")

        created_at = isoparse(d.pop("created_at"))

        agent_id = d.pop("agent_id", UNSET)

        policy_id = d.pop("policy_id", UNSET)

        decision = d.pop("decision", UNSET)

        distributed_span_id = d.pop("distributed_span_id", UNSET)

        distributed_trace_summary = cls(
            trace_id=trace_id,
            tenant_id=tenant_id,
            distributed_trace_id=distributed_trace_id,
            created_at=created_at,
            agent_id=agent_id,
            policy_id=policy_id,
            decision=decision,
            distributed_span_id=distributed_span_id,
        )

        return distributed_trace_summary
