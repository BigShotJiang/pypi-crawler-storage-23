from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.input_for_policy import InputForPolicy


T = TypeVar("T", bound="ArbiterEvaluateRequest")


@_attrs_define
class ArbiterEvaluateRequest:
    """
    Attributes:
        tenant_id (str):
        policy_keys (list[str]):
        input_ (InputForPolicy):
    """

    tenant_id: str
    policy_keys: list[str]
    input_: InputForPolicy

    def to_dict(self) -> dict[str, Any]:
        tenant_id = self.tenant_id

        policy_keys = self.policy_keys

        input_ = self.input_.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "tenant_id": tenant_id,
                "policy_keys": policy_keys,
                "input": input_,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.input_for_policy import InputForPolicy

        d = dict(src_dict)
        tenant_id = d.pop("tenant_id")

        policy_keys = cast(list[str], d.pop("policy_keys"))

        input_ = InputForPolicy.from_dict(d.pop("input"))

        arbiter_evaluate_request = cls(
            tenant_id=tenant_id,
            policy_keys=policy_keys,
            input_=input_,
        )

        return arbiter_evaluate_request
