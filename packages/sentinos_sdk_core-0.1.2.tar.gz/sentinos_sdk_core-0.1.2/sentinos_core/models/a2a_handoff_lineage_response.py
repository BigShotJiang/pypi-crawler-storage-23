from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.a2a_handoff_lineage_entry import A2AHandoffLineageEntry


T = TypeVar("T", bound="A2AHandoffLineageResponse")


@_attrs_define
class A2AHandoffLineageResponse:
    """
    Attributes:
        handoff_id (str):
        lineage (list[A2AHandoffLineageEntry]):
    """

    handoff_id: str
    lineage: list[A2AHandoffLineageEntry]

    def to_dict(self) -> dict[str, Any]:
        handoff_id = self.handoff_id

        lineage = []
        for lineage_item_data in self.lineage:
            lineage_item = lineage_item_data.to_dict()
            lineage.append(lineage_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "handoff_id": handoff_id,
                "lineage": lineage,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.a2a_handoff_lineage_entry import A2AHandoffLineageEntry

        d = dict(src_dict)
        handoff_id = d.pop("handoff_id")

        lineage = []
        _lineage = d.pop("lineage")
        for lineage_item_data in _lineage:
            lineage_item = A2AHandoffLineageEntry.from_dict(lineage_item_data)

            lineage.append(lineage_item)

        a2a_handoff_lineage_response = cls(
            handoff_id=handoff_id,
            lineage=lineage,
        )

        return a2a_handoff_lineage_response
