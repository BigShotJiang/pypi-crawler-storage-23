from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define

from ..models.auth_me_principal_type import AuthMePrincipalType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.membership import Membership


T = TypeVar("T", bound="AuthMe")


@_attrs_define
class AuthMe:
    """
    Attributes:
        user_id (UUID):
        email (str):
        principal_type (AuthMePrincipalType):
        org_id (UUID):
        membership_id (UUID):
        session_id (UUID):
        roles (list[str]):
        permissions (list[str]):
        memberships (list[Membership]):
        display_name (str | Unset):
    """

    user_id: UUID
    email: str
    principal_type: AuthMePrincipalType
    org_id: UUID
    membership_id: UUID
    session_id: UUID
    roles: list[str]
    permissions: list[str]
    memberships: list[Membership]
    display_name: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        user_id = str(self.user_id)

        email = self.email

        principal_type = self.principal_type.value

        org_id = str(self.org_id)

        membership_id = str(self.membership_id)

        session_id = str(self.session_id)

        roles = self.roles

        permissions = self.permissions

        memberships = []
        for memberships_item_data in self.memberships:
            memberships_item = memberships_item_data.to_dict()
            memberships.append(memberships_item)

        display_name = self.display_name

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "user_id": user_id,
                "email": email,
                "principal_type": principal_type,
                "org_id": org_id,
                "membership_id": membership_id,
                "session_id": session_id,
                "roles": roles,
                "permissions": permissions,
                "memberships": memberships,
            }
        )
        if display_name is not UNSET:
            field_dict["display_name"] = display_name

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.membership import Membership

        d = dict(src_dict)
        user_id = UUID(d.pop("user_id"))

        email = d.pop("email")

        principal_type = AuthMePrincipalType(d.pop("principal_type"))

        org_id = UUID(d.pop("org_id"))

        membership_id = UUID(d.pop("membership_id"))

        session_id = UUID(d.pop("session_id"))

        roles = cast(list[str], d.pop("roles"))

        permissions = cast(list[str], d.pop("permissions"))

        memberships = []
        _memberships = d.pop("memberships")
        for memberships_item_data in _memberships:
            memberships_item = Membership.from_dict(memberships_item_data)

            memberships.append(memberships_item)

        display_name = d.pop("display_name", UNSET)

        auth_me = cls(
            user_id=user_id,
            email=email,
            principal_type=principal_type,
            org_id=org_id,
            membership_id=membership_id,
            session_id=session_id,
            roles=roles,
            permissions=permissions,
            memberships=memberships,
            display_name=display_name,
        )

        return auth_me
