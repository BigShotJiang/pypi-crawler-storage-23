from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.auth_tokens import AuthTokens


T = TypeVar("T", bound="ControlplaneLoginPasswordResponse200")


@_attrs_define
class ControlplaneLoginPasswordResponse200:
    """
    Attributes:
        tokens (AuthTokens):
    """

    tokens: AuthTokens

    def to_dict(self) -> dict[str, Any]:
        tokens = self.tokens.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "tokens": tokens,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.auth_tokens import AuthTokens

        d = dict(src_dict)
        tokens = AuthTokens.from_dict(d.pop("tokens"))

        controlplane_login_password_response_200 = cls(
            tokens=tokens,
        )

        return controlplane_login_password_response_200
