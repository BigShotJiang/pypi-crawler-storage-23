from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define

T = TypeVar("T", bound="ArbiterActivePoliciesResponse200")


@_attrs_define
class ArbiterActivePoliciesResponse200:
    """
    Attributes:
        policy_keys (list[str]):
    """

    policy_keys: list[str]

    def to_dict(self) -> dict[str, Any]:
        policy_keys = self.policy_keys

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "policy_keys": policy_keys,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        policy_keys = cast(list[str], d.pop("policy_keys"))

        arbiter_active_policies_response_200 = cls(
            policy_keys=policy_keys,
        )

        return arbiter_active_policies_response_200
