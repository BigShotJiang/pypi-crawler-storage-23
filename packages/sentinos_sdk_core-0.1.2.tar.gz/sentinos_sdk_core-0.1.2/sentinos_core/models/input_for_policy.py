from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.input_for_policy_graph_context import InputForPolicyGraphContext
    from ..models.input_for_policy_input import InputForPolicyInput
    from ..models.input_for_policy_state import InputForPolicyState


T = TypeVar("T", bound="InputForPolicy")


@_attrs_define
class InputForPolicy:
    """
    Attributes:
        action (str | Unset):
        input_ (InputForPolicyInput | Unset):
        state (InputForPolicyState | Unset):
        graph_context (InputForPolicyGraphContext | Unset):
    """

    action: str | Unset = UNSET
    input_: InputForPolicyInput | Unset = UNSET
    state: InputForPolicyState | Unset = UNSET
    graph_context: InputForPolicyGraphContext | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        action = self.action

        input_: dict[str, Any] | Unset = UNSET
        if not isinstance(self.input_, Unset):
            input_ = self.input_.to_dict()

        state: dict[str, Any] | Unset = UNSET
        if not isinstance(self.state, Unset):
            state = self.state.to_dict()

        graph_context: dict[str, Any] | Unset = UNSET
        if not isinstance(self.graph_context, Unset):
            graph_context = self.graph_context.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if action is not UNSET:
            field_dict["action"] = action
        if input_ is not UNSET:
            field_dict["input"] = input_
        if state is not UNSET:
            field_dict["state"] = state
        if graph_context is not UNSET:
            field_dict["graph_context"] = graph_context

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.input_for_policy_graph_context import InputForPolicyGraphContext
        from ..models.input_for_policy_input import InputForPolicyInput
        from ..models.input_for_policy_state import InputForPolicyState

        d = dict(src_dict)
        action = d.pop("action", UNSET)

        _input_ = d.pop("input", UNSET)
        input_: InputForPolicyInput | Unset
        if isinstance(_input_, Unset):
            input_ = UNSET
        else:
            input_ = InputForPolicyInput.from_dict(_input_)

        _state = d.pop("state", UNSET)
        state: InputForPolicyState | Unset
        if isinstance(_state, Unset):
            state = UNSET
        else:
            state = InputForPolicyState.from_dict(_state)

        _graph_context = d.pop("graph_context", UNSET)
        graph_context: InputForPolicyGraphContext | Unset
        if isinstance(_graph_context, Unset):
            graph_context = UNSET
        else:
            graph_context = InputForPolicyGraphContext.from_dict(_graph_context)

        input_for_policy = cls(
            action=action,
            input_=input_,
            state=state,
            graph_context=graph_context,
        )

        input_for_policy.additional_properties = d
        return input_for_policy

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
