from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.chronos_connector_ingest_request_payload import ChronosConnectorIngestRequestPayload


T = TypeVar("T", bound="ChronosConnectorIngestRequest")


@_attrs_define
class ChronosConnectorIngestRequest:
    """
    Attributes:
        payload (ChronosConnectorIngestRequestPayload):
        event_id (str | Unset):
        occurred_at (datetime.datetime | Unset):
        entity_id (str | Unset):
    """

    payload: ChronosConnectorIngestRequestPayload
    event_id: str | Unset = UNSET
    occurred_at: datetime.datetime | Unset = UNSET
    entity_id: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        payload = self.payload.to_dict()

        event_id = self.event_id

        occurred_at: str | Unset = UNSET
        if not isinstance(self.occurred_at, Unset):
            occurred_at = self.occurred_at.isoformat()

        entity_id = self.entity_id

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "payload": payload,
            }
        )
        if event_id is not UNSET:
            field_dict["event_id"] = event_id
        if occurred_at is not UNSET:
            field_dict["occurred_at"] = occurred_at
        if entity_id is not UNSET:
            field_dict["entity_id"] = entity_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chronos_connector_ingest_request_payload import ChronosConnectorIngestRequestPayload

        d = dict(src_dict)
        payload = ChronosConnectorIngestRequestPayload.from_dict(d.pop("payload"))

        event_id = d.pop("event_id", UNSET)

        _occurred_at = d.pop("occurred_at", UNSET)
        occurred_at: datetime.datetime | Unset
        if isinstance(_occurred_at, Unset):
            occurred_at = UNSET
        else:
            occurred_at = isoparse(_occurred_at)

        entity_id = d.pop("entity_id", UNSET)

        chronos_connector_ingest_request = cls(
            payload=payload,
            event_id=event_id,
            occurred_at=occurred_at,
            entity_id=entity_id,
        )

        return chronos_connector_ingest_request
