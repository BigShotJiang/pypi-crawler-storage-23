from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="DecisionTraceSignatures")


@_attrs_define
class DecisionTraceSignatures:
    """
    Attributes:
        signed_by (str | Unset):
        key_id (str | Unset):
        alg (str | Unset):
        sig (str | Unset):
    """

    signed_by: str | Unset = UNSET
    key_id: str | Unset = UNSET
    alg: str | Unset = UNSET
    sig: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        signed_by = self.signed_by

        key_id = self.key_id

        alg = self.alg

        sig = self.sig

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if signed_by is not UNSET:
            field_dict["signed_by"] = signed_by
        if key_id is not UNSET:
            field_dict["key_id"] = key_id
        if alg is not UNSET:
            field_dict["alg"] = alg
        if sig is not UNSET:
            field_dict["sig"] = sig

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        signed_by = d.pop("signed_by", UNSET)

        key_id = d.pop("key_id", UNSET)

        alg = d.pop("alg", UNSET)

        sig = d.pop("sig", UNSET)

        decision_trace_signatures = cls(
            signed_by=signed_by,
            key_id=key_id,
            alg=alg,
            sig=sig,
        )

        decision_trace_signatures.additional_properties = d
        return decision_trace_signatures

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
