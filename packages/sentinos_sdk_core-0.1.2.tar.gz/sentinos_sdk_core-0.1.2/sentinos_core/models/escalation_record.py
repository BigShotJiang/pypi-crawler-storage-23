from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.escalation_record_evidence import EscalationRecordEvidence


T = TypeVar("T", bound="EscalationRecord")


@_attrs_define
class EscalationRecord:
    """
    Attributes:
        escalation_id (UUID):
        tenant_id (str):
        trace_id (UUID):
        status (str):
        created_at (datetime.datetime):
        session_id (str | Unset):
        tool (str | Unset):
        policy_id (str | Unset):
        policy_version (str | Unset):
        reason (str | Unset):
        evidence (EscalationRecordEvidence | Unset):
        resolved_at (datetime.datetime | Unset):
    """

    escalation_id: UUID
    tenant_id: str
    trace_id: UUID
    status: str
    created_at: datetime.datetime
    session_id: str | Unset = UNSET
    tool: str | Unset = UNSET
    policy_id: str | Unset = UNSET
    policy_version: str | Unset = UNSET
    reason: str | Unset = UNSET
    evidence: EscalationRecordEvidence | Unset = UNSET
    resolved_at: datetime.datetime | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        escalation_id = str(self.escalation_id)

        tenant_id = self.tenant_id

        trace_id = str(self.trace_id)

        status = self.status

        created_at = self.created_at.isoformat()

        session_id = self.session_id

        tool = self.tool

        policy_id = self.policy_id

        policy_version = self.policy_version

        reason = self.reason

        evidence: dict[str, Any] | Unset = UNSET
        if not isinstance(self.evidence, Unset):
            evidence = self.evidence.to_dict()

        resolved_at: str | Unset = UNSET
        if not isinstance(self.resolved_at, Unset):
            resolved_at = self.resolved_at.isoformat()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "escalation_id": escalation_id,
                "tenant_id": tenant_id,
                "trace_id": trace_id,
                "status": status,
                "created_at": created_at,
            }
        )
        if session_id is not UNSET:
            field_dict["session_id"] = session_id
        if tool is not UNSET:
            field_dict["tool"] = tool
        if policy_id is not UNSET:
            field_dict["policy_id"] = policy_id
        if policy_version is not UNSET:
            field_dict["policy_version"] = policy_version
        if reason is not UNSET:
            field_dict["reason"] = reason
        if evidence is not UNSET:
            field_dict["evidence"] = evidence
        if resolved_at is not UNSET:
            field_dict["resolved_at"] = resolved_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.escalation_record_evidence import EscalationRecordEvidence

        d = dict(src_dict)
        escalation_id = UUID(d.pop("escalation_id"))

        tenant_id = d.pop("tenant_id")

        trace_id = UUID(d.pop("trace_id"))

        status = d.pop("status")

        created_at = isoparse(d.pop("created_at"))

        session_id = d.pop("session_id", UNSET)

        tool = d.pop("tool", UNSET)

        policy_id = d.pop("policy_id", UNSET)

        policy_version = d.pop("policy_version", UNSET)

        reason = d.pop("reason", UNSET)

        _evidence = d.pop("evidence", UNSET)
        evidence: EscalationRecordEvidence | Unset
        if isinstance(_evidence, Unset):
            evidence = UNSET
        else:
            evidence = EscalationRecordEvidence.from_dict(_evidence)

        _resolved_at = d.pop("resolved_at", UNSET)
        resolved_at: datetime.datetime | Unset
        if isinstance(_resolved_at, Unset):
            resolved_at = UNSET
        else:
            resolved_at = isoparse(_resolved_at)

        escalation_record = cls(
            escalation_id=escalation_id,
            tenant_id=tenant_id,
            trace_id=trace_id,
            status=status,
            created_at=created_at,
            session_id=session_id,
            tool=tool,
            policy_id=policy_id,
            policy_version=policy_version,
            reason=reason,
            evidence=evidence,
            resolved_at=resolved_at,
        )

        return escalation_record
