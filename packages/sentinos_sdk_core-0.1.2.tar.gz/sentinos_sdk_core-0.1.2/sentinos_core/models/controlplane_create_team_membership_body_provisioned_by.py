from enum import Enum


class ControlplaneCreateTeamMembershipBodyProvisionedBy(str, Enum):
    SAML_MAPPING = "SAML_MAPPING"
    SCIM = "SCIM"
    SERVICE_ACCOUNT = "SERVICE_ACCOUNT"
    USER = "USER"

    def __str__(self) -> str:
        return str(self.value)
