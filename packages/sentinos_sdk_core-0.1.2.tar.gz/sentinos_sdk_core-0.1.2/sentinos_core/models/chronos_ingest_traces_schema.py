from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.decision_trace_schema import DecisionTraceSchema


T = TypeVar("T", bound="ChronosIngestTracesSchema")


@_attrs_define
class ChronosIngestTracesSchema:
    """
    Attributes:
        tenant_id (str):
        ingest_id (UUID):
        traces (list[DecisionTraceSchema]):
    """

    tenant_id: str
    ingest_id: UUID
    traces: list[DecisionTraceSchema]

    def to_dict(self) -> dict[str, Any]:
        tenant_id = self.tenant_id

        ingest_id = str(self.ingest_id)

        traces = []
        for traces_item_data in self.traces:
            traces_item = traces_item_data.to_dict()
            traces.append(traces_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "tenant_id": tenant_id,
                "ingest_id": ingest_id,
                "traces": traces,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.decision_trace_schema import DecisionTraceSchema

        d = dict(src_dict)
        tenant_id = d.pop("tenant_id")

        ingest_id = UUID(d.pop("ingest_id"))

        traces = []
        _traces = d.pop("traces")
        for traces_item_data in _traces:
            traces_item = DecisionTraceSchema.from_dict(traces_item_data)

            traces.append(traces_item)

        chronos_ingest_traces_schema = cls(
            tenant_id=tenant_id,
            ingest_id=ingest_id,
            traces=traces,
        )

        return chronos_ingest_traces_schema
