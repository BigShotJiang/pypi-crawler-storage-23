from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="ControlplaneRegisterRequest")


@_attrs_define
class ControlplaneRegisterRequest:
    """
    Attributes:
        email (str):
        password (str):
        display_name (str | Unset):
        invitation_token (str | Unset):
    """

    email: str
    password: str
    display_name: str | Unset = UNSET
    invitation_token: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        email = self.email

        password = self.password

        display_name = self.display_name

        invitation_token = self.invitation_token

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "email": email,
                "password": password,
            }
        )
        if display_name is not UNSET:
            field_dict["display_name"] = display_name
        if invitation_token is not UNSET:
            field_dict["invitation_token"] = invitation_token

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        email = d.pop("email")

        password = d.pop("password")

        display_name = d.pop("display_name", UNSET)

        invitation_token = d.pop("invitation_token", UNSET)

        controlplane_register_request = cls(
            email=email,
            password=password,
            display_name=display_name,
            invitation_token=invitation_token,
        )

        return controlplane_register_request
