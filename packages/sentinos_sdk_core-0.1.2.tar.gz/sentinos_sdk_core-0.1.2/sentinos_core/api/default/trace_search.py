import datetime
from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.decision import Decision
from ...models.trace_data_class import TraceDataClass
from ...models.trace_search_response_200 import TraceSearchResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    tenant_id: str | Unset = UNSET,
    agent_id: str | Unset = UNSET,
    policy_id: str | Unset = UNSET,
    decision: Decision | Unset = UNSET,
    data_class: TraceDataClass | Unset = UNSET,
    from_: datetime.datetime | Unset = UNSET,
    to: datetime.datetime | Unset = UNSET,
    limit: int | Unset = 50,
    cursor: str | Unset = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["tenant_id"] = tenant_id

    params["agent_id"] = agent_id

    params["policy_id"] = policy_id

    json_decision: str | Unset = UNSET
    if not isinstance(decision, Unset):
        json_decision = decision.value

    params["decision"] = json_decision

    json_data_class: str | Unset = UNSET
    if not isinstance(data_class, Unset):
        json_data_class = data_class.value

    params["data_class"] = json_data_class

    json_from_: str | Unset = UNSET
    if not isinstance(from_, Unset):
        json_from_ = from_.isoformat()
    params["from"] = json_from_

    json_to: str | Unset = UNSET
    if not isinstance(to, Unset):
        json_to = to.isoformat()
    params["to"] = json_to

    params["limit"] = limit

    params["cursor"] = cursor

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/trace/search",
        "params": params,
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> TraceSearchResponse200 | None:
    if response.status_code == 200:
        response_200 = TraceSearchResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[TraceSearchResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    tenant_id: str | Unset = UNSET,
    agent_id: str | Unset = UNSET,
    policy_id: str | Unset = UNSET,
    decision: Decision | Unset = UNSET,
    data_class: TraceDataClass | Unset = UNSET,
    from_: datetime.datetime | Unset = UNSET,
    to: datetime.datetime | Unset = UNSET,
    limit: int | Unset = 50,
    cursor: str | Unset = UNSET,
) -> Response[TraceSearchResponse200]:
    """Search decision traces

    Args:
        tenant_id (str | Unset):
        agent_id (str | Unset):
        policy_id (str | Unset):
        decision (Decision | Unset):
        data_class (TraceDataClass | Unset):
        from_ (datetime.datetime | Unset):
        to (datetime.datetime | Unset):
        limit (int | Unset):  Default: 50.
        cursor (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[TraceSearchResponse200]
    """

    kwargs = _get_kwargs(
        tenant_id=tenant_id,
        agent_id=agent_id,
        policy_id=policy_id,
        decision=decision,
        data_class=data_class,
        from_=from_,
        to=to,
        limit=limit,
        cursor=cursor,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    tenant_id: str | Unset = UNSET,
    agent_id: str | Unset = UNSET,
    policy_id: str | Unset = UNSET,
    decision: Decision | Unset = UNSET,
    data_class: TraceDataClass | Unset = UNSET,
    from_: datetime.datetime | Unset = UNSET,
    to: datetime.datetime | Unset = UNSET,
    limit: int | Unset = 50,
    cursor: str | Unset = UNSET,
) -> TraceSearchResponse200 | None:
    """Search decision traces

    Args:
        tenant_id (str | Unset):
        agent_id (str | Unset):
        policy_id (str | Unset):
        decision (Decision | Unset):
        data_class (TraceDataClass | Unset):
        from_ (datetime.datetime | Unset):
        to (datetime.datetime | Unset):
        limit (int | Unset):  Default: 50.
        cursor (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        TraceSearchResponse200
    """

    return sync_detailed(
        client=client,
        tenant_id=tenant_id,
        agent_id=agent_id,
        policy_id=policy_id,
        decision=decision,
        data_class=data_class,
        from_=from_,
        to=to,
        limit=limit,
        cursor=cursor,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    tenant_id: str | Unset = UNSET,
    agent_id: str | Unset = UNSET,
    policy_id: str | Unset = UNSET,
    decision: Decision | Unset = UNSET,
    data_class: TraceDataClass | Unset = UNSET,
    from_: datetime.datetime | Unset = UNSET,
    to: datetime.datetime | Unset = UNSET,
    limit: int | Unset = 50,
    cursor: str | Unset = UNSET,
) -> Response[TraceSearchResponse200]:
    """Search decision traces

    Args:
        tenant_id (str | Unset):
        agent_id (str | Unset):
        policy_id (str | Unset):
        decision (Decision | Unset):
        data_class (TraceDataClass | Unset):
        from_ (datetime.datetime | Unset):
        to (datetime.datetime | Unset):
        limit (int | Unset):  Default: 50.
        cursor (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[TraceSearchResponse200]
    """

    kwargs = _get_kwargs(
        tenant_id=tenant_id,
        agent_id=agent_id,
        policy_id=policy_id,
        decision=decision,
        data_class=data_class,
        from_=from_,
        to=to,
        limit=limit,
        cursor=cursor,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    tenant_id: str | Unset = UNSET,
    agent_id: str | Unset = UNSET,
    policy_id: str | Unset = UNSET,
    decision: Decision | Unset = UNSET,
    data_class: TraceDataClass | Unset = UNSET,
    from_: datetime.datetime | Unset = UNSET,
    to: datetime.datetime | Unset = UNSET,
    limit: int | Unset = 50,
    cursor: str | Unset = UNSET,
) -> TraceSearchResponse200 | None:
    """Search decision traces

    Args:
        tenant_id (str | Unset):
        agent_id (str | Unset):
        policy_id (str | Unset):
        decision (Decision | Unset):
        data_class (TraceDataClass | Unset):
        from_ (datetime.datetime | Unset):
        to (datetime.datetime | Unset):
        limit (int | Unset):  Default: 50.
        cursor (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        TraceSearchResponse200
    """

    return (
        await asyncio_detailed(
            client=client,
            tenant_id=tenant_id,
            agent_id=agent_id,
            policy_id=policy_id,
            decision=decision,
            data_class=data_class,
            from_=from_,
            to=to,
            limit=limit,
            cursor=cursor,
        )
    ).parsed
