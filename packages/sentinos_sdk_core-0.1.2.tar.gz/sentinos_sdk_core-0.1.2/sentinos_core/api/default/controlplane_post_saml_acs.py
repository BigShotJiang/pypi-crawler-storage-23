from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.controlplane_post_saml_acs_data_body import ControlplanePostSamlAcsDataBody
from ...models.controlplane_post_saml_acs_json_body import ControlplanePostSamlAcsJsonBody
from ...models.controlplane_post_saml_acs_response_200 import ControlplanePostSamlAcsResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    org_id: UUID,
    *,
    body: ControlplanePostSamlAcsJsonBody | ControlplanePostSamlAcsDataBody | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/orgs/{org_id}/saml/acs".format(
            org_id=quote(str(org_id), safe=""),
        ),
    }

    if isinstance(body, ControlplanePostSamlAcsJsonBody):
        if not isinstance(body, Unset):
            _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, ControlplanePostSamlAcsDataBody):
        if not isinstance(body, Unset):
            _kwargs["data"] = body.to_dict()

        headers["Content-Type"] = "application/x-www-form-urlencoded"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ControlplanePostSamlAcsResponse200 | None:
    if response.status_code == 200:
        response_200 = ControlplanePostSamlAcsResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ControlplanePostSamlAcsResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: ControlplanePostSamlAcsJsonBody | ControlplanePostSamlAcsDataBody | Unset = UNSET,
) -> Response[ControlplanePostSamlAcsResponse200]:
    """SAML assertion consumer endpoint

    Args:
        org_id (UUID):
        body (ControlplanePostSamlAcsJsonBody | Unset):
        body (ControlplanePostSamlAcsDataBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ControlplanePostSamlAcsResponse200]
    """

    kwargs = _get_kwargs(
        org_id=org_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    org_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: ControlplanePostSamlAcsJsonBody | ControlplanePostSamlAcsDataBody | Unset = UNSET,
) -> ControlplanePostSamlAcsResponse200 | None:
    """SAML assertion consumer endpoint

    Args:
        org_id (UUID):
        body (ControlplanePostSamlAcsJsonBody | Unset):
        body (ControlplanePostSamlAcsDataBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ControlplanePostSamlAcsResponse200
    """

    return sync_detailed(
        org_id=org_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    org_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: ControlplanePostSamlAcsJsonBody | ControlplanePostSamlAcsDataBody | Unset = UNSET,
) -> Response[ControlplanePostSamlAcsResponse200]:
    """SAML assertion consumer endpoint

    Args:
        org_id (UUID):
        body (ControlplanePostSamlAcsJsonBody | Unset):
        body (ControlplanePostSamlAcsDataBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ControlplanePostSamlAcsResponse200]
    """

    kwargs = _get_kwargs(
        org_id=org_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    org_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: ControlplanePostSamlAcsJsonBody | ControlplanePostSamlAcsDataBody | Unset = UNSET,
) -> ControlplanePostSamlAcsResponse200 | None:
    """SAML assertion consumer endpoint

    Args:
        org_id (UUID):
        body (ControlplanePostSamlAcsJsonBody | Unset):
        body (ControlplanePostSamlAcsDataBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ControlplanePostSamlAcsResponse200
    """

    return (
        await asyncio_detailed(
            org_id=org_id,
            client=client,
            body=body,
        )
    ).parsed
