from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_notification_channels_kind import ListNotificationChannelsKind
from ...models.list_notification_channels_response_200 import ListNotificationChannelsResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    kind: ListNotificationChannelsKind | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    json_kind: str | Unset = UNSET
    if not isinstance(kind, Unset):
        json_kind = kind.value

    params["kind"] = json_kind

    params["limit"] = limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/integrations/channels",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ListNotificationChannelsResponse200 | None:
    if response.status_code == 200:
        response_200 = ListNotificationChannelsResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ListNotificationChannelsResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    kind: ListNotificationChannelsKind | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> Response[ListNotificationChannelsResponse200]:
    """List notification channels

    Args:
        kind (ListNotificationChannelsKind | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListNotificationChannelsResponse200]
    """

    kwargs = _get_kwargs(
        kind=kind,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    kind: ListNotificationChannelsKind | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> ListNotificationChannelsResponse200 | None:
    """List notification channels

    Args:
        kind (ListNotificationChannelsKind | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListNotificationChannelsResponse200
    """

    return sync_detailed(
        client=client,
        kind=kind,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    kind: ListNotificationChannelsKind | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> Response[ListNotificationChannelsResponse200]:
    """List notification channels

    Args:
        kind (ListNotificationChannelsKind | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListNotificationChannelsResponse200]
    """

    kwargs = _get_kwargs(
        kind=kind,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    kind: ListNotificationChannelsKind | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> ListNotificationChannelsResponse200 | None:
    """List notification channels

    Args:
        kind (ListNotificationChannelsKind | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListNotificationChannelsResponse200
    """

    return (
        await asyncio_detailed(
            client=client,
            kind=kind,
            limit=limit,
        )
    ).parsed
