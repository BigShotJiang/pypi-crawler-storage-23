from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.chronos_get_ingest_status_response_200 import ChronosGetIngestStatusResponse200
from ...types import Response


def _get_kwargs(
    ingest_id: UUID,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/chronos/ingest/{ingest_id}".format(
            ingest_id=quote(str(ingest_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ChronosGetIngestStatusResponse200 | None:
    if response.status_code == 200:
        response_200 = ChronosGetIngestStatusResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ChronosGetIngestStatusResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    ingest_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[ChronosGetIngestStatusResponse200]:
    """Get ingest status by ingest_id

    Args:
        ingest_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ChronosGetIngestStatusResponse200]
    """

    kwargs = _get_kwargs(
        ingest_id=ingest_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    ingest_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> ChronosGetIngestStatusResponse200 | None:
    """Get ingest status by ingest_id

    Args:
        ingest_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ChronosGetIngestStatusResponse200
    """

    return sync_detailed(
        ingest_id=ingest_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    ingest_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[ChronosGetIngestStatusResponse200]:
    """Get ingest status by ingest_id

    Args:
        ingest_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ChronosGetIngestStatusResponse200]
    """

    kwargs = _get_kwargs(
        ingest_id=ingest_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    ingest_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> ChronosGetIngestStatusResponse200 | None:
    """Get ingest status by ingest_id

    Args:
        ingest_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ChronosGetIngestStatusResponse200
    """

    return (
        await asyncio_detailed(
            ingest_id=ingest_id,
            client=client,
        )
    ).parsed
