---
name: Feature request
about: Suggest an enhancement
labels: enhancement
---

## Problem statement

## Proposed solution

## Alternatives considered

## Additional context
