# Releasing `sentinos-sdk-core`

This package is published to PyPI as `sentinos-sdk-core`.

Release order when paired with the wrapper SDK:

1. `sentinos-sdk-core`
2. `sentinos`

## Publishing model

This repo uses GitHub Actions + PyPI Trusted Publishing (OIDC).

- Workflow: `.github/workflows/publish.yml`
- Trigger: push tag `v*` (for example `v0.1.1`)
- No long-lived PyPI API token is required.

## Preflight

```bash
python3 -m venv .venv && source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -U build twine ruff
python -m pip install -e .
python -m ruff check sentinos_core
rm -rf dist
python -m build
python -m twine check dist/*
```

## Release

1. Bump `version` in `pyproject.toml`.
2. Commit and push to `main`.
3. Create and push tag:

```bash
git tag -a vX.Y.Z -m "Release vX.Y.Z"
git push origin vX.Y.Z
```

4. Verify GitHub workflow success.
5. Verify package on PyPI:

```bash
python -m pip install -U sentinos-sdk-core
```

## Optional fallback (manual upload)

Use only if GitHub Actions is unavailable:

```bash
python -m twine upload dist/*
```
