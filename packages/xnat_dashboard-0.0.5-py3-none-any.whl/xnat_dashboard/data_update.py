import asyncio
from datetime import datetime, timezone
from contextlib import suppress

import humanize
import pandas as pd
from humanize import naturaldate, naturaltime
from loguru import logger
from nicegui import ui

from xnat_dashboard.data_types import Charts, DashboardData, Modalities, SpecialModalities


async def update_charts(charts: Charts, data: DashboardData, project_id: str) -> None:
    logger.debug(f'Updating project "{project_id}" charts')

    with suppress(AttributeError):
        await asyncio.gather(
            subjects(charts.subjects, data, project_id),
            subjects_heatmap(charts.subjects_heatmap, data, project_id),
            experiments(charts.experiments, data, project_id),
            experiments_heatmap(charts.experiments_heatmap, data, project_id)
        )


async def subjects(chart: ui.echart, data: DashboardData, project_id: str) -> None:
    df = data.subjects
    df = df[df['project'] == project_id]

    df = df[['project', 'insert_date']].sort_values(by='insert_date').drop_duplicates()
    df_onehot = pd.get_dummies(df, columns=['project'], prefix='PROJECT').drop(columns=['insert_date'])
    df = pd.concat([df[['insert_date']], df_onehot.cumsum()], axis=1, join='inner')
    df['insert_date'] = df['insert_date'].dt.strftime('%Y-%m-%d %H:%M:%S')

    chart.options['legend']['data'] = [project_id]
    chart.options['series'][0]['name'] = project_id

    subjects_data = [df.columns.tolist()] + df.to_numpy().tolist()

    chart.options['series'][0]['data'] = subjects_data
    chart.options['series'][0]['endLabel'] = {'show': True}

    chart.update()


async def subjects_heatmap(
        chart: ui.echart,
        data: DashboardData,
        selected_project: str) -> None:
    df = data.subjects
    df = df[df['project'] == selected_project]
    df = df[['project', 'insert_date']].sort_values(by='insert_date').drop_duplicates()
    # noinspection PyTypeChecker
    df['insert_date'] = df['insert_date'].dt.date

    begin = df['insert_date'].min().strftime('%Y-%m-%d')
    end = df['insert_date'].max().strftime('%Y-%m-%d')

    frequency = df.groupby(['insert_date']).size().reset_index(name='frequency')
    heatmap_data = []
    for _, row in frequency.iterrows():
        heatmap_data.append((row['insert_date'].strftime('%Y-%m-%d'), row['frequency']))

    max_frequency = frequency['frequency'].max()

    chart.options['visualMap']['max'] = max_frequency
    chart.options['calendar']['range'] = [begin, end]
    chart.options['series'] = [{
        'type': 'heatmap',
        'coordinateSystem': 'calendar',
        'data': heatmap_data,
    }]


async def experiments(chart: ui.echart, data: DashboardData, project_id: str) -> None:
    exp_df = pd.DataFrame()
    for modality in Modalities:
        df = data.experiments[modality]
        df = df[df['project'] == project_id]
        df = df[['insert_date']].copy()
        df['modality'] = modality.name
        if len(df) > 0:
            exp_df = pd.concat([exp_df, df])

    for special_modality in SpecialModalities:
        df = data.experiments[special_modality]
        df = df[df['project'] == project_id]
        df = df[['insert_date']].copy()
        df['modality'] = special_modality.name
        if len(df) > 0:
            exp_df = pd.concat([exp_df, df])

    exp_df = exp_df.sort_values(by='insert_date').reset_index(drop=True)

    modalities = exp_df['modality'].unique()
    if len(modalities) == 0:
        logger.debug(f'No modalities in {project_id}')
        return

    resample_threshold = 1_000

    try:
        df_onehot = pd.get_dummies(exp_df, columns=['modality'], prefix='MODALITY')
        if exp_df.shape[0] <= resample_threshold:
            df = pd.concat([exp_df[['insert_date']],
                            df_onehot.drop(columns=['insert_date']).cumsum()], axis=1, join='inner')
        else:
            # Compute day totals (resample, sum) and remove days with 0 experiments (mincount=1, dropna).
            # Also compute cumulative count (cumsum)
            logger.debug(f'Number of rows ({exp_df.shape[0]}) exceeds threshold ({resample_threshold}). Resampling to days.')
            df = df_onehot.resample('D', on='insert_date').sum(min_count=1).dropna().cumsum().reset_index()
        df['insert_date'] = df['insert_date'].dt.strftime('%Y-%m-%d %H:%M:%S')
    except pd.errors.InvalidIndexError as e:
        logger.error(f'{project_id=}: {e}')
        return

    series = []
    for modality in modalities:
        mod_df = df[['insert_date', f'MODALITY_{modality}']]

        series_data = [mod_df.columns.tolist()] + mod_df.to_numpy().tolist()

        series.append({
            'type': 'line',
            'step': 'start',
            'name': modality,
            'showSymbol': False,
            'data': series_data,
            'endLabel': {'show': True},
        })

    chart.options['series'] = series
    chart.options['legend']['data'] = modalities
    chart.update()


async def experiments_heatmap(chart: ui.echart, data: DashboardData, project_id: str) -> None:
    exp_df = pd.DataFrame()
    for modality in Modalities:
        mod_df = data.experiments[modality]
        mod_df = mod_df[mod_df['project'] == project_id]
        if len(mod_df) == 0:
            continue
        mod_df = mod_df[['project', 'insert_date']].sort_values(by='insert_date').drop_duplicates()
        mod_df['modality'] = modality.name
        # noinspection PyTypeChecker
        mod_df['insert_date'] = mod_df['insert_date'].dt.date
        exp_df = pd.concat([exp_df, mod_df])

    for special_modality in SpecialModalities:
        mod_df = data.experiments[special_modality]
        mod_df = mod_df[mod_df['project'] == project_id]
        if len(mod_df) == 0:
            continue
        mod_df = mod_df[['project', 'insert_date']].sort_values(by='insert_date').drop_duplicates()
        mod_df['modality'] = special_modality.name
        # noinspection PyTypeChecker
        mod_df['insert_date'] = mod_df['insert_date'].dt.date
        exp_df = pd.concat([exp_df, mod_df])

    exp_df = exp_df.sort_values(by='insert_date').reset_index(drop=True)

    begin = exp_df['insert_date'].min().strftime('%Y-%m-%d')
    end = exp_df['insert_date'].max().strftime('%Y-%m-%d')

    frequency = exp_df.groupby(['insert_date']).size().reset_index(name='frequency')
    heatmap_data = []
    for _, row in frequency.iterrows():
        heatmap_data.append((row['insert_date'].strftime('%Y-%m-%d'), row['frequency']))

    max_frequency = frequency['frequency'].max()

    chart.options['visualMap']['max'] = max_frequency
    chart.options['calendar']['range'] = [begin, end]
    chart.options['series'] = [{
        'type': 'heatmap',
        'coordinateSystem': 'calendar',
        'data': heatmap_data,
    }]


async def users(table: ui.table, data: DashboardData, project_id: str) -> None:
    project = data.projects[project_id]

    rows = []
    for val in sorted(project.users, key=lambda x: x.login):
        if val.role is None:
            continue
        rows.append({'login': val.login, 'first_name': val.firstname, 'last_name': val.lastname, 'role': val.role})

    table.rows = rows


async def project_info(table: ui.table, data: DashboardData, project_id: str) -> None:
    project = data.projects[project_id]

    table.rows = [
        {'key': 'Description', 'value': project.description},
        {'key': 'Subjects', 'value': humanize.intcomma(project.subject_count)},
        {'key': 'Experiments', 'value': humanize.intcomma(project.experiments_count)},
        {'key': 'Keywords', 'value': ', '.join(x for x in project.keywords)},
    ]

    if project.created is not None:
        table.rows.append({
            'key': 'Creation', 'value':
            f'{naturaltime(datetime.now(timezone.utc) - project.created)} ({naturaldate(project.created)})'
        })
