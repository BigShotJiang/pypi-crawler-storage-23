import os

from dotenv import load_dotenv
from nicegui import app, ui
from loguru import logger

from xnat_dashboard.main import _format_data_age, get_data

load_dotenv()

FAVICON = ('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsTAAALEwEAmpwY'
           'AAAA7UlEQVR4nO2YTQ6CMBBGuYV01dbTQLiO1otIzyU9AnABgb2GxJ9YFqTNOCX6vWS2k+8lbTPTLAMAgE2yO7kqN64Xxt'
           '1CKj+6LjdN6ffb19dK10Ov7XgLKWWHTtpp0W+VOUho+JeEaVq/3xwkNLx+Syz6rRIb/ll+v9jw+lEQEBAYIRAEBH7tGZV2'
           'KmMklB1aeZ6K5ALsCAgkRkDgu9MtuwD1dMsuwH4kBQQ+gUAo1JeOX8A0ZYzEHD4/XIrkAtRAIDUQCIX6J41dQBGvgOwCmn'
           'gJh0AoEPCAwN8JKOJnlH2llMQ/adTTLQAAZJvgDjMIzITsihWCAAAAAElFTkSuQmCC')


async def on_startup() -> None:
    await get_data()
    logger.info('Dashboard started')


def main() -> None:
    app.on_startup(on_startup)
    app.timer(5, _format_data_age)

    ui.run(
        host=os.getenv('HOST', 'localhost'),
        port=int(os.getenv('PORT', '8088')),
        title=os.getenv('PAGE_TITLE', f'XNAT Dashboard {os.getenv("SERVER", "")}'),
        favicon=FAVICON,
        show=False,
        reload=False,
        storage_secret='SUPER_SECRET',  # noqa: S106
        show_welcome_message=False,
    )


if __name__ in {"__main__", "__mp_main__"}:
    main()
