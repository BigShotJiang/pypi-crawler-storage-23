""" Several data types/classes and pydantic models. """
import datetime
import contextlib
import enum
import re
from dataclasses import dataclass, field
from typing import Any

import pandas as pd
from nicegui import ui
from pydantic import BaseModel, Field, field_validator


class Modalities(enum.Enum):
    """ Image modalities. """
    CR = 'cr'
    CT = 'ct'
    DX = 'dx'
    MG = 'mg'
    MR = 'mr'
    NM = 'nm'
    PET = 'pet'
    US = 'us'
    XA = 'xa'


class SpecialModalities(enum.Enum):
    RTSTRUCT = 'rt-struct'
    SEG = 'seg'


class XnatUser(BaseModel):
    """ XNAT user info. """
    login: str
    firstname: str
    lastname: str
    email: str
    role: str | None = Field(default=None, validation_alias='displayname')


# noinspection PyDataclass
class XnatProject(BaseModel):
    """ Project info. """
    id: str = Field(validation_alias='ID')
    description: str = ''
    name: str
    secondary_ID: str  # noqa: N815
    experiments_count: int = 0
    subject_count: int = 0
    created: datetime.datetime | None = None
    keywords: list[str] = Field(default_factory=list)
    users: list[XnatUser] = Field(default_factory=list)

    @field_validator('keywords', mode='before')
    @classmethod
    def _keywords(cls, value: Any) -> list[str]:  # noqa: ANN401
        if len(str(value).strip()) == 0:
            return []

        keyword_list = [kw.strip() for kw in re.split(r'[.,;: ]', str(value))]

        # Filter out all empty strings, then return list
        return list(filter(None, keyword_list))


@dataclass
class XnatServerDetails:
    version: str
    uptime: datetime.timedelta
    build_info: dict
    projects: int
    subjects: int
    experiments: int
    users: int


@dataclass
class DashboardData:
    experiments: dict[Modalities | SpecialModalities, pd.DataFrame] = field(default_factory=dict)
    subjects: pd.DataFrame = field(default_factory=pd.DataFrame)
    projects: dict[str, XnatProject] = field(default_factory=dict)
    users: list[XnatUser] = field(default_factory=list)
    update_timestamp: datetime.datetime = datetime.datetime(1970, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)


@dataclass
class Charts:
    subjects: ui.echart
    subjects_heatmap: ui.echart
    experiments: ui.echart
    experiments_heatmap: ui.echart

    async def loading(self, *, show: bool) -> None:
        with contextlib.suppress(TimeoutError):
            await self.experiments.run_chart_method('showLoading' if show else 'hideLoading')
            await self.experiments_heatmap.run_chart_method('showLoading' if show else 'hideLoading')
            await self.subjects.run_chart_method('showLoading' if show else 'hideLoading')
            await self.subjects_heatmap.run_chart_method('showLoading' if show else 'hideLoading')
