import asyncio
import datetime
import os
import pickle
from collections.abc import Container
from typing import Final

import fastapi
import humanize
import nicegui
import pandas as pd
import uvicorn
import xnat
import xnat_dashboard.queries
from dotenv import load_dotenv
from loguru import logger
from nicegui import app, background_tasks, run, ui
from xnat_dashboard.charts import create_chart, create_heatmap, experiments_chart, subjects_chart
from xnat_dashboard.data_types import Charts, DashboardData, XnatProject, XnatUser
from xnat_dashboard.data_update import update_charts, users, project_info
from xnat_dashboard.queries import DB_PATH, xnat_server_details

load_dotenv()

UPDATE_INTERVAL: Final[datetime.timedelta] = datetime.timedelta(hours=int(os.environ.get('UPDATE_INTERVAL', '4')))
PRIMARY_COLOR = os.getenv('PRIMARY_COLOR', '#3874c8')
SECONDARY_COLOR = os.getenv('SECONDARY_COLOR', '#6fa5d8')
BACKGROUND_COLOR = os.getenv('BACKGROUND_COLOR', '#6fa5d8')

_data_lock = asyncio.Lock()
_data_age: str = 'No data available.'  # pylint: disable=invalid-name
_last_update_time: str = ''  # pylint: disable=invalid-name
_refreshing_data: bool = False  # pylint: disable=invalid-name

data: DashboardData | None = None  # pylint: disable=invalid-name


def _get_project_ids() -> dict[str, str]:
    assert data
    try:
        lut = {x.id: x.name for x in data.projects.values()}

        return {x: lut[x] for x in sorted(data.subjects['project'].unique())}
    except KeyError:
        pass

    return {}


def _format_data_age() -> None:
    global _data_age  # noqa: PLW0603  # pylint: disable=global-statement

    if data is None:
        _data_age = 'Refreshing data.' if _refreshing_data else 'No data available'
        return

    data_age = humanize.precisedelta(
        data.update_timestamp - datetime.datetime.now(tz=datetime.timezone.utc),
        minimum_unit="minutes",
        format="%0.0f"
    )
    _data_age = f'Data is {data_age} old.'


async def get_data(*, refresh: bool = False) -> None:
    global _last_update_time, data, _refreshing_data  # noqa: PLW0603  # pylint: disable=global-statement

    async with _data_lock:
        if data is None and DB_PATH.exists() and refresh is False:
            logger.debug(f'Loading cached data ({DB_PATH.absolute()})')
            with DB_PATH.open('rb') as f:  # noqa: ASYNC230
                try:
                    data = pickle.load(f)  # noqa: S301
                    _last_update_time = data.update_timestamp.astimezone().strftime('%A %d %B %Y, %H:%M:%S')
                except AttributeError as e:
                    logger.debug(f'Error loading cache: {e}')
                    data = None

        now = datetime.datetime.now(tz=datetime.timezone.utc)
        if refresh is True or data is None or now - data.update_timestamp > UPDATE_INTERVAL:
            logger.debug(f'{"Stale" if data is not None else "No cached data"}, reload')
            data = None

            _refreshing_data = True
            data = await background_tasks.create(run.io_bound(xnat_dashboard.queries.search))
            _refreshing_data = False

            if data is None:
                _last_update_time = 'No update time available.'
                return

            _last_update_time = data.update_timestamp.astimezone().strftime('%A %d %B %Y, %H:%M:%S')


app.timer(5 * 60, get_data)  # Check data every 5 minutes to see if it needs refreshing.


def header(label: str, links: list[tuple[str, str]]) -> None:
    with (ui.header(elevated=True).style(f'background-color: {PRIMARY_COLOR}').classes('items-center justify-between')):
        logo_icon = os.getenv('LOGO')
        if logo_icon is not None:
            ui.image(logo_icon).classes('w-8 h-8 m-auto')
        for (name, link) in links:
            ui.link(name, link).classes(replace='text-lg')
        ui.space()
        ui.label(label).classes('text-2xl font-bold')
        ui.space()
        ui.markdown(os.getenv('TITLE', 'XNAT Dashboard'))
        ui.spinner('pie', size='lg', color='red') \
            .bind_visibility_from(globals(), '_refreshing_data') \
            .classes('no-wrap justify-start items-stretch content-start')
        with ui.button(icon='update').on_click(lambda _: get_data(refresh=True)) \
                .bind_visibility_from(globals(), '_refreshing_data', backward=lambda vis: not vis):
            ui.tooltip('Refresh data from XNAT.')
        with ui.button(icon='info').on_click(lambda _: ui.navigate.to('/about')):
            ui.tooltip('About.')


def footer() -> None:
    with ui.footer().style(f'background-color: {PRIMARY_COLOR}'):
        ui.label(f'© LKEB / LUMC {datetime.date.today().year}')  # noqa: DTZ011
        ui.space()
        with ui.label().bind_text_from(globals(), '_data_age'):
            ui.tooltip().bind_text_from(globals(), '_last_update_time')


@ui.page('/projects')
async def page_projects() -> None:
    header(label='XNAT Projects',
           links=[('Users', '/users'), ('Subjects', '/subjects'), ('Experiments', '/experiments')])
    footer()

    if _data_lock.locked() or data is None:
        return

    columns = [
        {'name': 'id', 'label': 'Id', 'field': 'id', 'align': 'right', 'sortable': True},
        {'name': 'name', 'label': 'Name', 'field': 'name', 'sortable': True, 'style': 'text-wrap: wrap'},
        {'name': 'description', 'label': 'Description', 'field': 'description', 'sortable': True,
         'style': 'text-wrap: wrap'},
        {'name': 'subject_count', 'label': 'Subjects', 'field': 'subject_count', 'align': 'right',
         'sortable': True},
        {'name': 'experiments_count', 'label': 'Experiments', 'field': 'experiments_count', 'align': 'right',
         'sortable': True},
    ]

    rows = [x.model_dump() for x in sorted(data.projects.values(), key=lambda x: x.name.casefold())]

    ui.query('body').style(f'background-color: {BACKGROUND_COLOR}')

    with (ui.table(
            columns=columns,
            rows=rows,
            row_key='login',
            column_defaults={'align': 'left', 'headerClasses': 'uppercase text-secondary text-italic'}
    ) as table, table.add_slot('body-cell-id'), table.cell('id')):
        ui.button().props(':label=props.value flat').on(
            'click',
            js_handler='() => emit(props.value)',
            handler=lambda x: ui.navigate.to(f'/project/{x.args}'),
        )


@ui.page('/users')
async def page_users() -> None:
    header(label='XNAT Users',
           links=[('Projects', '/projects'), ('Subjects', '/subjects'), ('Experiments', '/experiments')])
    footer()

    if _data_lock.locked() or data is None:
        return

    ui.query('body').style(f'background-color: {BACKGROUND_COLOR}')

    columns = [
        {'name': 'login', 'label': 'Login', 'field': 'login', 'required': True, 'align': 'right', 'sortable': True},
        {'name': 'firstname', 'label': 'First Name', 'field': 'firstname', 'required': True, 'align': 'center',
         'sortable': True},
        {'name': 'lastname', 'label': 'Last Name', 'field': 'lastname', 'required': True, 'align': 'center',
         'sortable': True},
    ]

    rows = [x.model_dump() for x in sorted(data.users, key=lambda x: x.login.casefold())]

    with (ui.table(
            columns=columns,
            rows=rows,
            row_key='login',
            column_defaults={'align': 'left', 'headerClasses': 'uppercase text-secondary text-italic'},
            pagination=18
    ) as table, table.add_slot('body-cell-login'), table.cell('login')):
        ui.button().props(':label=props.value flat').on(
            'click',
            js_handler='() => emit(props.value)',
            handler=lambda x: ui.navigate.to(f'/user/{x.args}'),
        )


@ui.page('/project/{project_id}')
async def page_project(project_id: str) -> None:
    header(label=project_id,
           links=[('Users', '/users'),
                  ('Projects', '/projects'),
                  ('Subjects', '/subjects'),
                  ('Experiments', '/experiments')])
    footer()

    if _data_lock.locked() or data is None:
        return

    ui.query('body').style(f'background-color: {BACKGROUND_COLOR}')

    with ui.tabs().classes('w-full') as tabs:
        info_tab = ui.tab('information')
        exp_tab = ui.tab('experiments')
        sub_tab = ui.tab('subjects')

    with ui.tab_panels(tabs, value=info_tab).classes('w-full').style(f'background-color: {BACKGROUND_COLOR}'):
        with ui.tab_panel(info_tab), ui.grid(columns='1fr 1fr').classes('w-full'):
            project_table = ui.table(columns=[
                {'name': 'key', 'label': 'Key', 'field': 'key', 'required': True, 'align': 'right'},
                {'name': 'value', 'label': 'Value', 'field': 'value', 'required': True, 'align': 'left',
                 'style': 'text-wrap: wrap'}],
                rows=[],
                row_key='key',
                title='General info',
                selection=None,
                column_defaults={'align': 'left', 'headerClasses': 'uppercase text-secondary text-italic'}
            ).props('table-header-class=hidden')

            table_columns = [
                {'name': 'login', 'label': 'Login', 'field': 'login', 'align': 'right', 'sortable': True},
                {'name': 'first_name', 'label': 'First Name', 'field': 'first_name', 'align': 'center',
                 'sortable': True},
                {'name': 'last_name', 'label': 'Last Name', 'field': 'last_name', 'align': 'center', 'sortable': True},
                {'name': 'role', 'label': 'Role', 'field': 'role', 'align': 'center', 'sortable': True}
            ]

            with ui.table(
                    columns=table_columns,
                    rows=[],
                    row_key='login',
                    title='Users',
                    selection=None,
                    column_defaults={'align': 'left', 'headerClasses': 'uppercase text-secondary text-italic'}
            ) as table, table.add_slot('body-cell-login'), table.cell('login'):
                ui.button().props(':label=props.value flat').on(
                    'click',
                    js_handler='() => emit(props.value)',
                    handler=lambda x: ui.navigate.to(f'/user/{x.args}'),
                )

        with ui.tab_panel(sub_tab):
            sub_hm = create_heatmap()
            sub_chart = create_chart()
        with ui.tab_panel(exp_tab):
            exp_hm = create_heatmap()
            exp_chart = create_chart()

    await project_info(project_table, data, project_id)
    await users(table, data, project_id)
    await update_charts(Charts(sub_chart, sub_hm, exp_chart, exp_hm), data, project_id)


@ui.page('/user/{user_id}')
async def page_user(user_id: str) -> None:
    def _user() -> XnatUser:
        assert data
        result = next((x for x in data.users if x.login == user_id), None)  # ty: ignore[possibly-missing-attribute]
        if result is None:
            result = XnatUser(login='', firstname='', lastname='', email='', role=None)

        return result

    def _user_role(proj: XnatProject) -> str | None:
        """ User role in the project. """
        return next((usr.role for usr in proj.users if usr.login == user_id), None)

    def _projects_for_user(_projects: Container[XnatProject]) -> list[XnatProject]:
        """ All projects that 'user_id' is a member of. """
        assert data
        return sorted((proj for proj in data.projects.values()  # ty: ignore[possibly-missing-attribute]
                       if user_id in (x.login for x in proj.users)), key=lambda x: x.id.casefold())

    user = _user()

    header(label=f'{user.firstname} {user.lastname}',
           links=[('Users', '/users'),
                  ('Projects', '/projects'),
                  ('Subjects', '/subjects'),
                  ('Experiments', '/experiments')])
    footer()

    if _data_lock.locked() or data is None:
        return

    ui.query('body').style(f'background-color: {BACKGROUND_COLOR}')

    cols = [
        {'name': 'name', 'label': 'Project Name', 'field': 'name', 'required': True, 'align': 'right', 'sortable': True},
        {'name': 'role', 'label': 'Role', 'field': 'role', 'sortable': True},
        {'name': 'description', 'label': 'Description', 'field': 'description', 'sortable': True}
    ]
    projects = _projects_for_user(data.projects.values())
    rows = [
        {'name': proj.name, 'description': proj.description, 'role': _user_role(proj)} for proj in projects
    ]
    col_defaults = {'align': 'left', 'headerClasses': 'uppercase text-secondary text-italic'}

    with (ui.table(columns=cols, rows=rows, row_key='key', title='Projects', selection=None, column_defaults=col_defaults)
          as table, table.add_slot('body-cell-name'), table.cell('name')):
        ui.button().props(':label=props.value flat').on(
            'click',
            js_handler='() => emit(props.value)',
            handler=lambda x: ui.navigate.to(f'/project/{x.args}'))


@ui.page('/subjects')
async def page_subjects() -> None:
    header(label='XNAT Subjects',
           links=[('Users', '/users'), ('Projects', '/projects'), ('Experiments', '/experiments')])
    footer()

    if _data_lock.locked() or data is None:
        return

    ui.query('body').style(f'background-color: {BACKGROUND_COLOR}')

    await subjects_chart(data)


@ui.page('/experiments')
async def page_experiments() -> None:
    header(label='XNAT Experiments',
           links=[('Users', '/users'), ('Projects', '/projects'), ('Subjects', '/subjects')])
    footer()

    if _data_lock.locked() or data is None:
        return

    ui.query('body').style(f'background-color: {BACKGROUND_COLOR}')

    await experiments_chart(data)


@ui.page('/about')
async def page_about() -> None:
    header(label='About',
           links=[
               ('Users', '/users'),
               ('Projects', '/projects'),
               ('Subjects', '/subjects'),
               ('Experiments', '/experiments')
           ])
    footer()

    with (ui.grid(columns='1fr').classes('w-full')):
        xnat_server_data = xnat_server_details()

        with ui.row():
            with ui.card():
                ui.label('XNAT Server details').classes('text-2xl font-bold')

                rows = [{'key': 'Up time', 'value': humanize.precisedelta(xnat_server_data.uptime,
                                                                          suppress=['minutes', 'seconds'], format='%0.0f')},
                        {'key': 'Version', 'value': xnat_server_data.version},
                        {'key': 'Host name', 'value': xnat_server_data.build_info['hostName']},
                        {'key': '# Projects', 'value': xnat_server_data.projects},
                        {'key': '# Users', 'value': xnat_server_data.users},
                        {'key': '# Subjects', 'value': xnat_server_data.subjects},
                        {'key': '# Experiments', 'value': xnat_server_data.experiments},
                        ]
                ui.table(
                    columns=[
                        {'name': 'key', 'label': 'Name', 'field': 'key', 'required': True, 'align': 'right'},
                        {'name': 'value', 'label': 'Value', 'field': 'value', 'required': True, 'align': 'left',
                         'style': 'text-wrap: wrap'}
                    ],
                    rows=rows,
                ).props('flat hide-header hide-footer')

            with ui.card():
                ui.label('Python environment').classes('text-2xl font-bold')
                ui.table(
                    columns=[
                        {'name': 'key', 'label': 'Python Package', 'field': 'key', 'required': True, 'align': 'right'},
                        {'name': 'value', 'label': 'Version', 'field': 'value', 'required': True, 'align': 'left',
                         'style': 'text-wrap: wrap'}
                    ],
                    rows=[
                        {'key': 'XNAT', 'value': xnat.__version__},
                        {'key': 'NiceGUI', 'value': nicegui.__version__},
                        {'key': 'Pandas', 'value': pd.__version__},
                        {'key': 'Uvicorn', 'value': uvicorn.__version__},
                        {'key': 'FastAPI', 'value': fastapi.__version__},
                    ]).props('flat hide-header hide-footer')

    with ui.row().classes('items-center'):
        ui.button('Close').on_click(lambda: ui.navigate.back())


@ui.page('/')
async def main_page() -> None:
    ui.navigate.to(os.getenv('DEFAULT_ROUTE', '/users'))
