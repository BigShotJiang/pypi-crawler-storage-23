# pylint: skip-file
MODALITIES_QUERY = """<?xml version="1.0" encoding="UTF-8"?>
<xdat:bundle ID=""
             xmlns:xdat="http://nrg.wustl.edu/security"
             xmlns:xnat="http://nrg.wustl.edu/xnat"
>
    <xdat:root_element_name>xnat:${modality}SessionData</xdat:root_element_name>
    <xdat:search_field>
        <xdat:element_name>xnat:${modality}SessionData</xdat:element_name>
        <xdat:field_ID>SUBJECT_LABEL</xdat:field_ID>
        <xdat:sequence>1</xdat:sequence>
        <xdat:type>string</xdat:type>
        <xdat:header>Subject</xdat:header>
    </xdat:search_field>
    <xdat:search_field>
        <xdat:element_name>xnat:${modality}SessionData</xdat:element_name>
        <xdat:field_ID>LABEL</xdat:field_ID>
        <xdat:sequence>2</xdat:sequence>
        <xdat:type>string</xdat:type>
        <xdat:header>Label</xdat:header>
    </xdat:search_field>
    <xdat:search_field>
        <xdat:element_name>xnat:${modality}SessionData</xdat:element_name>
        <xdat:field_ID>INSERT_USER</xdat:field_ID>
        <xdat:sequence>3</xdat:sequence>
        <xdat:type>string</xdat:type>
        <xdat:header>Creator</xdat:header>
    </xdat:search_field>
    <xdat:search_field>
        <xdat:element_name>xnat:${modality}SessionData</xdat:element_name>
        <xdat:field_ID>PROJECT</xdat:field_ID>
        <xdat:sequence>4</xdat:sequence>
        <xdat:type>string</xdat:type>
        <xdat:header>Project</xdat:header>
    </xdat:search_field>
    <xdat:search_field>
        <xdat:element_name>xnat:${modality}SessionData</xdat:element_name>
        <xdat:field_ID>INSERT_DATE</xdat:field_ID>
        <xdat:sequence>5</xdat:sequence>
        <xdat:type>string</xdat:type>
        <xdat:header>Inserted</xdat:header>
    </xdat:search_field>
</xdat:bundle>"""

SUBJECTS_QUERY = """<?xml version="1.0" encoding="UTF-8"?>
<xdat:bundle ID=""
             xmlns:xdat="http://nrg.wustl.edu/security"
             xmlns:xnat="http://nrg.wustl.edu/xnat"
>
    <xdat:root_element_name>xnat:subjectData</xdat:root_element_name>
    <xdat:search_field>
        <xdat:element_name>xnat:subjectData</xdat:element_name>
        <xdat:field_ID>SUBJECT_LABEL</xdat:field_ID>
        <xdat:sequence>1</xdat:sequence>
        <xdat:type>string</xdat:type>
        <xdat:header>Subject</xdat:header>
    </xdat:search_field>
    <xdat:search_field>
        <xdat:element_name>xnat:subjectData</xdat:element_name>
        <xdat:field_ID>PROJECTS</xdat:field_ID>
        <xdat:sequence>2</xdat:sequence>
        <xdat:type>string</xdat:type>
        <xdat:header>Projects</xdat:header>
    </xdat:search_field>
    <xdat:search_field>
        <xdat:element_name>xnat:subjectData</xdat:element_name>
        <xdat:field_ID>PROJECT</xdat:field_ID>
        <xdat:sequence>3</xdat:sequence>
        <xdat:type>string</xdat:type>
        <xdat:header>Project</xdat:header>
    </xdat:search_field>
    <xdat:search_field>
        <xdat:element_name>xnat:subjectData</xdat:element_name>
        <xdat:field_ID>INSERT_DATE</xdat:field_ID>
        <xdat:sequence>4</xdat:sequence>
        <xdat:type>date</xdat:type>
        <xdat:header>Inserted</xdat:header>
    </xdat:search_field>
</xdat:bundle>"""

ROI_COLLECTION_QUERY = """<?xml version="1.0" encoding="UTF-8"?><xdat:bundle ID="" xmlns:arc="http://nrg.wustl.edu/arc" xmlns:cat="http://nrg.wustl.edu/catalog" xmlns:pipe="http://nrg.wustl.edu/pipe" xmlns:prov="http://www.nbirn.net/prov" xmlns:scr="http://nrg.wustl.edu/scr" xmlns:val="http://nrg.wustl.edu/val" xmlns:wrk="http://nrg.wustl.edu/workflow" xmlns:xdat="http://nrg.wustl.edu/security" xmlns:xnat="http://nrg.wustl.edu/xnat" xmlns:xnat_a="http://nrg.wustl.edu/xnat_assessments" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><xdat:root_element_name>icr:roiCollectionData</xdat:root_element_name><xdat:search_field>
<xdat:element_name>icr:roiCollectionData</xdat:element_name>
<xdat:field_ID>LABEL</xdat:field_ID>
<xdat:sequence>1</xdat:sequence>
<xdat:type>string</xdat:type>
<xdat:header>Label</xdat:header></xdat:search_field><xdat:search_field>
<xdat:element_name>icr:roiCollectionData</xdat:element_name>
<xdat:field_ID>COLLECTIONTYPE</xdat:field_ID>
<xdat:sequence>2</xdat:sequence>
<xdat:type>string</xdat:type>
<xdat:header>collectionType</xdat:header></xdat:search_field><xdat:search_field>
<xdat:element_name>icr:roiCollectionData</xdat:element_name>
<xdat:field_ID>INSERT_DATE</xdat:field_ID>
<xdat:sequence>3</xdat:sequence>
<xdat:type>string</xdat:type>
<xdat:header>Inserted</xdat:header></xdat:search_field></xdat:bundle>
"""  # noqa: E501
