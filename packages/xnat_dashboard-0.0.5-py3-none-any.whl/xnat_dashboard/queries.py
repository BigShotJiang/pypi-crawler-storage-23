""" Run queries on a XNAT server and provide functions to access the results. """
import datetime
import io
import os
import pickle
import string
from functools import cache
from multiprocessing import Pool
from pathlib import Path
from typing import Final

import pandas as pd
import xnat
from dotenv import load_dotenv
from loguru import logger
from xnat.mixin import ProjectData

from xnat_dashboard.searches import SUBJECTS_QUERY, MODALITIES_QUERY, ROI_COLLECTION_QUERY
from xnat_dashboard.data_types import SpecialModalities, XnatServerDetails, XnatUser, XnatProject, Modalities, DashboardData

load_dotenv()
SERVER = os.environ.get('SERVER')
DB_PATH: Final[Path] = Path(os.getenv('DB_PATH', 'dashboard_data.pkl'))


def _convert(_xnat: ProjectData) -> XnatProject:
    """ Convert from XNAT ProjectData object to (local) Project object. """
    proj = XnatProject(**_xnat.data)  # ty: ignore[invalid-argument-type]
    proj.experiments_count = len(_xnat.experiments)
    proj.subject_count = len(_xnat.subjects)
    proj.created = _xnat.insert_date  # type: ignore
    for user in _xnat.users.values():
        proj.users.append(XnatUser(**user.data))  # pylint: disable=no-member
    return proj


def _query_modality(modality: Modalities) -> pd.DataFrame:
    """ Replace the modality keyword in the search document and run the query. """
    return _query(string.Template(MODALITIES_QUERY).substitute({'modality': modality.value}))


def _query_roi_collections() -> dict[SpecialModalities, pd.DataFrame]:
    df = _query(ROI_COLLECTION_QUERY)

    return {
        SpecialModalities.RTSTRUCT: df[df['collectiontype'] == 'RTSTRUCT'],
        SpecialModalities.SEG: df[df['collectiontype'] == 'SEG'],
    }


def _query(query_xml: str) -> pd.DataFrame:
    """ Run the query on XNAT. """
    with xnat.connect(SERVER) as session:
        result = session.post(path='/data/search?format=csv', data=query_xml)
    return pd.read_csv(io.StringIO(result.text), sep=',', dtype=pd.StringDtype(), parse_dates=['insert_date'])


@cache
def xnat_server_details() -> XnatServerDetails:
    with xnat.connect(SERVER) as session:
        return XnatServerDetails(
            version=session.xnat_version,
            uptime=datetime.timedelta(**{k: float(v)for k, v in session.xnat_uptime.items()}),
            build_info=session.xnat_build_info,
            projects=len(session.projects),
            subjects=len(session.subjects),
            experiments=len(session.experiments),
            users=len(session.users),
        )


def search() -> DashboardData:
    """ Query all experiments and subjects within XNAT. """
    data = DashboardData()
    logger.debug('Collecting project/subject/user data.')
    with xnat.connect(SERVER) as session:
        data.projects = {xnat_project.id: _convert(xnat_project) for xnat_project in session.projects.values()}
        data.users = [XnatUser(**user.data) for user in session.users.values()]
        result = session.post(path='/data/search?format=csv', data=SUBJECTS_QUERY)
        data.subjects = pd.read_csv(io.StringIO(result.text), sep=',', dtype=pd.StringDtype(), parse_dates=['insert_date'])

    logger.debug('Collecting experiment data.')
    with Pool() as pool:
        results = pool.map(_query_modality, Modalities)
        pool.close()
        pool.join()

    data.experiments = dict(zip(Modalities, results, strict=False))

    logger.debug('Collecting ROI collection data.')
    data.experiments.update(_query_roi_collections())  # type: ignore[arg-type]

    data.update_timestamp = datetime.datetime.now(tz=datetime.timezone.utc)

    with DB_PATH.open('wb') as f:  # noqa: ASYNC230
        logger.debug(f'Saving data to cache ({DB_PATH.absolute()})')
        # noinspection PyTypeChecker
        pickle.dump(data, f)

    return data


def get_users() -> list[XnatUser]:
    """ Get all users. """
    with xnat.connect(SERVER) as session:
        return [XnatUser(**user.data) for user in session.users.values()]
