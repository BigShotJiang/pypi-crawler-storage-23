from .morris import morris_sampling
from .saltelli import saltelli_sampling


__all__ = ["morris_sampling", "saltelli_sampling"]
