# Changelog Entry Template

## Format

```markdown
## [Version] - YYYY-MM-DD

### Added
- [Feature name]: [Brief description]

### Changed
- [Any changes to existing behavior]

### Fixed
- [Any bugs fixed during implementation]
```
