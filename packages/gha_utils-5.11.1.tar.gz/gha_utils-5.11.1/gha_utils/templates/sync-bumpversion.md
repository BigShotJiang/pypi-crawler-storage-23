---
title: Sync `bump-my-version` config
---

### Description

Initializes the `[tool.bumpversion]` configuration in `pyproject.toml` from the bundled template. See the [`sync-bumpversion` job documentation](https://github.com/kdeldycke/workflows?tab=readme-ov-file#githubworkflowsautofixyaml-jobs) for details.
