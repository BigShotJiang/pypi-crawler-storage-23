---
title: Format JSON
---

### Description

Auto-formats JSON files with [Biome](https://biomejs.dev/). See the [`format-json` job documentation](https://github.com/kdeldycke/workflows?tab=readme-ov-file#githubworkflowsautofixyaml-jobs) for details.
