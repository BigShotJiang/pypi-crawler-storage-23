Pindakaas
=========

**Encoding propositional and Pseudo Boolean constraints into CNF**

This documentation describes the Python interface to the Pindakaas Rust library.
See the `Rust documentation <https://crates.io/crates/pindakaas>`_ for more in-depth information.

*Acknowledgements.* This research was partially funded by the Australian Government through the Australian Research Council Industrial Transformation Training Centre in Optimisation Technologies, Integrated Methodologies, and Applications (OPTIMA), Project ID IC200100009.

*Citation.* If you want to cite Pindakaas please use our general software citation, in addition to any citation to a specific version or paper:

.. code-block:: bibtex

   @software{Pindakaas,
   author = {Bierlee, Hendrik and Dekker, Jip J.},
   license = {MPL-2.0},
   title = {{Pindakaas}},
   url = {https://doi.org/10.5281/zenodo.10851855},
   doi = {10.5281/zenodo.10851855},
   }

Note that you might have to use ``misc`` instead of ``software``, if your system does not support ``software`` as a type.

.. The full API is described in the following section.

.. toctree::
   :maxdepth: 2

   getting_started
   api
