"""Filesystem backend resolver for local runner construction.

Maps SDK-level filesystem settings (`bool | FilesystemConfig`) to values
accepted by `aip_agents.agent.langgraph_react_agent.LangGraphReactAgent`.

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
"""

from __future__ import annotations

from importlib import import_module
from typing import Any

from glaip_sdk.models.filesystem import FilesystemConfig, InMemoryConfig, LocalDiskConfig


def _build_backend(module_path: str, class_name: str, **kwargs: Any) -> object:
    """Build an optional backend instance from module/class names.

    Args:
        module_path: Python module path containing backend class.
        class_name: Backend class name in the module.
        **kwargs: Keyword args passed to backend constructor.

    Returns:
        object: Backend instance.

    Raises:
        ModuleNotFoundError: If optional local backend modules are not installed.
    """
    try:
        backend_cls = getattr(import_module(module_path), class_name)
        return backend_cls(**kwargs)
    except ModuleNotFoundError as exc:
        raise ModuleNotFoundError(
            'Filesystem local backends are unavailable. Install local extras with `pip install "glaip-sdk[local]"`.'
        ) from exc


def resolve_filesystem_backend(filesystem: bool | FilesystemConfig) -> bool | object:
    """Resolve SDK filesystem setting to a LangGraphReactAgent-compatible value.

    Args:
        filesystem: Top-level filesystem setting from `Agent(filesystem=...)`.

    Returns:
        bool | object: A backend-compatible value for `LangGraphReactAgent`.

    Raises:
        ValueError: If filesystem type or subtype is unsupported.
    """
    match filesystem:
        case False:
            return False

        case True:
            return _build_backend(
                "aip_agents.middleware.backends.local_disk",
                "LocalDiskBackend",
            )

        case InMemoryConfig():
            return _build_backend(
                "aip_agents.middleware.backends.in_memory",
                "InMemoryBackend",
            )

        case LocalDiskConfig(base_directory=base_directory):
            return _build_backend(
                "aip_agents.middleware.backends.local_disk",
                "LocalDiskBackend",
                base_directory=base_directory,
            )

        case FilesystemConfig():
            raise ValueError(f"Unsupported FilesystemConfig subtype: {type(filesystem).__name__}")

        case _:
            raise ValueError("filesystem must be bool or FilesystemConfig")


__all__ = ["resolve_filesystem_backend"]
