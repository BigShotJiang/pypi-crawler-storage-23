"""Shared typing aliases for agent API inputs.

Authors:
    Saul Sayers (saul.sayers@gdplabs.id)
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any, Protocol


class SupportsSkillSource(Protocol):
    """Protocol for skill-like objects accepted by remote skill normalization."""

    source: str | None


SkillInputEntry = str | Mapping[str, Any] | SupportsSkillSource
SkillsInput = SkillInputEntry | Sequence[SkillInputEntry] | None
