"""Import resolution and categorization for tool bundling.

This module provides the ImportResolver class for handling Python import
analysis and resolution during tool bundling operations.

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
"""

from __future__ import annotations

import ast
import importlib
from pathlib import Path

from glaip_sdk.utils.tool_detection import is_tool_plugin_decorator

INIT_FILE = "__init__.py"


class ImportResolver:
    """Resolves and categorizes Python imports for tool bundling.

    This class handles the complex logic of determining which imports
    are local (and need to be inlined) versus external (and need to
    be preserved as import statements).

    Attributes:
        tool_dir: The directory containing the tool file being bundled.

    Example:
        >>> resolver = ImportResolver(Path("/path/to/tool/dir"))
        >>> local, external = resolver.categorize_imports(ast_tree)
    """

    # Modules to exclude from bundled code (only needed locally)
    EXCLUDED_MODULES: set[str] = {
        "glaip_sdk.agents",
        "glaip_sdk.tools",
        "glaip_sdk.mcps",
    }

    def __init__(self, tool_dir: Path) -> None:
        """Initialize the ImportResolver.

        Args:
            tool_dir: Directory containing the tool file being processed.
        """
        self.tool_dir = tool_dir
        self._processed_modules: set[str] = set()
        self._package_root: Path = self._find_package_root(tool_dir)

    def _find_package_root(self, start_path: Path) -> Path:
        """Find package root using standard project markers.

        Searches upward from start_path for common Python project markers:
        - pyproject.toml (modern Python standard)
        - setup.py (legacy setuptools)
        - .git (version control root)

        Falls back to start_path.parent if no markers found.

        Args:
            start_path: Starting directory to search from.

        Returns:
            Path to the identified package root.
        """
        # Check current directory and all parents
        for parent in [start_path, *start_path.parents]:
            if (parent / "pyproject.toml").exists():
                return parent
            if (parent / "setup.py").exists():
                return parent
            if (parent / ".git").exists():
                return parent

        # Fallback: return parent of start_path
        # This maintains backward compatibility with original behavior
        return start_path.parent

    def categorize_imports(self, tree: ast.AST) -> tuple[list, list]:
        """Categorize imports into local and external.

        Args:
            tree: AST tree of the source file.

        Returns:
            Tuple of (local_imports, external_imports) where local_imports
            contains tuples of (module_name, file_path, import_node).
        """
        local_imports = []
        external_imports = []

        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                if self.is_local_import(node):
                    module_file = self._resolve_import_path(node)
                    local_imports.append((node.module, module_file, node))
                else:
                    external_imports.append(node)
            elif isinstance(node, ast.Import):
                external_imports.append(node)

        return local_imports, external_imports

    def _resolve_import_path(self, node: ast.ImportFrom) -> Path:
        """Resolve import node to file path.

        Handles both absolute and relative imports.

        Args:
            node: ImportFrom AST node.

        Returns:
            Path to the module file.
        """
        if node.level > 0:
            return self.resolve_relative_import_path(node)

        if not node.module:
            return self.tool_dir / INIT_FILE

        return self.resolve_module_path(node.module)

    def is_local_import(self, node: ast.ImportFrom) -> bool:
        """Check if import is local to the tool directory.

        Args:
            node: Import node to check.

        Returns:
            True if import is local.
        """
        # Handle relative imports (level > 0)
        if node.level > 0:
            return self._is_local_relative_import(node)

        # Handle absolute imports with no module name
        if not node.module:
            return False

        # Handle dotted package imports
        if "." in node.module:
            return self._is_local_package_import(node.module)

        # Handle simple module imports
        # First, check if it's the package root (matched via project markers)
        if self._is_package_root_import(node.module):
            return True

        # Then check for local file in tool_dir
        potential_file = self.tool_dir / f"{node.module}.py"
        return potential_file.exists()

    def _is_package_root_import(self, module_name: str) -> bool:
        """Check if a simple module name is a package root in the ancestor chain.

        Args:
            module_name: Simple module name (no dots).

        Returns:
            True if the module name matches any parent directory that could be a package.
        """
        # Check all ancestors for a matching directory name
        current = self.tool_dir
        while current != current.parent:
            if module_name == current.name:
                return True
            current = current.parent
        return False

    def _is_local_relative_import(self, node: ast.ImportFrom) -> bool:
        """Check if a relative import is local.

        Args:
            node: ImportFrom node with node.level > 0.

        Returns:
            True if the relative import resolves to a local file.
        """
        if node.level == 0:
            return False

        base_dir = self._calculate_relative_base_dir(node.level)
        if not base_dir:
            return False

        if node.module is None:
            return self._is_init_file_present(base_dir)

        return self._check_module_exists(base_dir, node.module)

    def _calculate_relative_base_dir(self, level: int) -> Path | None:
        """Calculate base directory for relative import.

        Args:
            level: Relative import level (1=current, 2=parent, etc.).

        Returns:
            Base directory path or None if exceeds filesystem root.
        """
        base_dir = self.tool_dir
        for _ in range(level - 1):
            if base_dir == base_dir.parent:
                return None
            base_dir = base_dir.parent
        return base_dir

    def _is_init_file_present(self, base_dir: Path) -> bool:
        """Check if __init__.py exists in directory.

        Args:
            base_dir: Directory to check.

        Returns:
            True if __init__.py exists.
        """
        return (base_dir / INIT_FILE).exists()

    def _check_module_exists(self, base_dir: Path, module: str) -> bool:
        """Check if module exists in base directory.

        Args:
            base_dir: Base directory to search from.
            module: Module name (dotted or simple).

        Returns:
            True if module file or package exists.
        """
        parts = module.split(".")
        return self._module_parts_exist(base_dir, parts)

    def _is_local_package_import(self, module: str) -> bool:
        """Check if a dotted module path is local.

        Args:
            module: Module path like 'tools.config' or 'sub.module'.

        Returns:
            True if the module is local to tool_dir.
        """
        parts = module.split(".")

        if self._check_module_in_tool_dir(parts):
            return True

        if self._check_module_in_subdirectory(parts):
            return True

        if self._check_module_in_ancestor_packages(parts):
            return True

        return False

    def _check_module_in_tool_dir(self, parts: list[str]) -> bool:
        """Check if module is in the current tool directory (Case 1).

        Args:
            parts: Module path split into components.

        Returns:
            True if module is found in tool_dir.
        """
        if parts[0] != self.tool_dir.name:
            return False

        remaining_parts = parts[1:]
        if not remaining_parts:
            return False

        return self._module_parts_exist(self.tool_dir, remaining_parts)

    def _check_module_in_subdirectory(self, parts: list[str]) -> bool:
        """Check if module is in a subdirectory of tool_dir (Case 2).

        Args:
            parts: Module path split into components.

        Returns:
            True if module is found in a subdirectory.
        """
        package_dir = self.tool_dir / parts[0]
        if not package_dir.is_dir():
            return False

        return self._module_parts_exist(self.tool_dir, parts)

    def _check_module_in_ancestor_packages(self, parts: list[str]) -> bool:
        """Check if module is in the package root.

        Uses the discovered package root (via project markers) to resolve
        imports from the package root. Also falls back to directory name
        matching for backward compatibility.

        Args:
            parts: Module path split into components.

        Returns:
            True if module is found in the package root.
        """
        # Strategy 1: Check if package root contains the module
        if self._check_module_in_package_root(parts):
            return True

        # Strategy 2: Fallback to directory name matching (backward compatibility)
        return self._check_module_by_directory_name(parts)

    def _check_module_in_package_root(self, parts: list[str]) -> bool:
        """Check if module exists in the discovered package root.

        Args:
            parts: Module path split into components.

        Returns:
            True if module exists in package root.
        """
        # Resolve module from package root
        module_path = self._resolve_from_package_root_path(self._package_root, parts)
        return module_path.exists()

    def _check_module_by_directory_name(self, parts: list[str]) -> bool:
        """Check module by matching directory names (legacy fallback).

        Args:
            parts: Module path split into components.

        Returns:
            True if module found by directory name matching.
        """
        current = self.tool_dir

        while current != current.parent:
            if parts[0] == current.name:
                return self._resolve_from_package_root(current, parts)
            current = current.parent

        return False

    def _resolve_from_package_root(self, package_root: Path, parts: list[str]) -> bool:
        """Resolve module from a found package root directory.

        Args:
            package_root: The identified package root directory.
            parts: Module path split into components.

        Returns:
            True if module exists in the package root.
        """
        remaining_parts = parts[1:]

        if not remaining_parts:
            return (package_root / INIT_FILE).exists()

        return self._module_parts_exist(package_root, remaining_parts)

    def _module_parts_exist(self, base_dir: Path, parts: list[str]) -> bool:
        """Check if module parts exist as a file or package.

        Args:
            base_dir: Base directory to search from.
            parts: Remaining module path components.

        Returns:
            True if module file or package exists.
        """
        if len(parts) == 1:
            module_file = base_dir / f"{parts[0]}.py"
            if module_file.exists():
                return True

        if len(parts) > 1:
            module_file = base_dir / "/".join(parts[:-1]) / f"{parts[-1]}.py"
            if module_file.exists():
                return True

        init_file = base_dir / "/".join(parts) / INIT_FILE
        return init_file.exists()

    def resolve_module_path(self, module_name: str) -> Path:
        """Resolve module name to file path.

        Args:
            module_name: Module name (e.g., 'config' or 'tools.config').

        Returns:
            Path to the module file.
        """
        if "." in module_name:
            return self._resolve_dotted_module_path(module_name)

        # For simple module names, check if it's a file in tool_dir or an ancestor package
        potential_file = self.tool_dir / f"{module_name}.py"
        if potential_file.exists():
            return potential_file

        # Check if it's an ancestor package (directory with __init__.py)
        current = self.tool_dir
        while current != current.parent:
            potential_package_init = current / module_name / INIT_FILE
            if potential_package_init.exists():
                return potential_package_init
            current = current.parent

        # Fallback to the file path (will fail later if not found)
        return potential_file

    def resolve_relative_import_path(self, node: ast.ImportFrom) -> Path:
        """Resolve relative import to file path.

        Args:
            node: ImportFrom node with node.level > 0.

        Returns:
            Path to the module file.

        Raises:
            ValueError: If relative import level exceeds directory depth.
        """
        base_dir = self._calculate_relative_base_dir(node.level)
        if base_dir is None:
            raise ValueError(f"Invalid relative import: level {node.level} exceeds directory depth")

        if node.module is None:
            return base_dir / INIT_FILE

        return self._resolve_dotted_module_path_from_base(base_dir, node.module)

    def _resolve_dotted_module_path_from_base(self, base_dir: Path, module_name: str) -> Path:
        """Resolve dotted module path from a specific base directory.

        Args:
            base_dir: Base directory to resolve from.
            module_name: Dotted module path (e.g., 'package.module').

        Returns:
            Path to the module file.
        """
        parts = module_name.split(".")
        return self._build_module_path(base_dir, parts)

    def _resolve_dotted_module_path(self, module_name: str) -> Path:
        """Resolve a dotted module path to a file path.

        Args:
            module_name: Dotted module path like 'tools.config'.

        Returns:
            Path to the module file.
        """
        parts = module_name.split(".")

        module_path = self._resolve_from_tool_dir(parts)
        if module_path and module_path.exists():
            return module_path

        module_path = self._resolve_from_subdir(parts)
        if module_path.exists():
            return module_path

        module_path = self._resolve_from_ancestor_packages(parts)
        if module_path and module_path.exists():
            return module_path

        return self.tool_dir / "/".join(parts) / INIT_FILE

    def _resolve_from_tool_dir(self, parts: list[str]) -> Path | None:
        """Resolve module from current tool directory.

        Args:
            parts: Module path split into components.

        Returns:
            Path to potential module file, or None if not applicable.
        """
        if parts[0] != self.tool_dir.name:
            return None

        remaining_parts = parts[1:]
        if not remaining_parts:
            return self.tool_dir / INIT_FILE

        return self._build_module_path(self.tool_dir, remaining_parts)

    def _resolve_from_subdir(self, parts: list[str]) -> Path:
        """Resolve module from a subdirectory.

        Args:
            parts: Module path split into components.

        Returns:
            Path to potential module file.
        """
        return self._build_module_path(self.tool_dir, parts)

    def _resolve_from_ancestor_packages(self, parts: list[str]) -> Path | None:
        """Resolve module from an ancestor directory (Package Root Traversal).

        Traverses up the directory tree looking for a matching package root.

        Args:
            parts: Module path split into components.

        Returns:
            Path to module if found in ancestor, None otherwise.
        """
        current = self.tool_dir

        while current != current.parent:
            if parts[0] == current.name:
                return self._resolve_from_package_root_path(current, parts)
            current = current.parent

        return None

    def _resolve_from_package_root_path(self, package_root: Path, parts: list[str]) -> Path:
        """Build module path from a found package root.

        Args:
            package_root: The identified package root directory.
            parts: Module path split into components.

        Returns:
            Path to potential module file.
        """
        if not parts:
            return package_root / INIT_FILE

        candidates: list[Path] = []

        if package_root.name == parts[0]:
            remaining_parts = parts[1:]
            if not remaining_parts:
                candidates.append(package_root / INIT_FILE)
            else:
                candidates.append(self._build_module_path(package_root, remaining_parts))

        candidates.append(self._build_module_path(package_root, parts))

        for candidate in candidates:
            if candidate.exists():
                return candidate

        return candidates[0]

    def _build_module_path(self, base_dir: Path, parts: list[str]) -> Path:
        """Build potential module file path from parts.

        Args:
            base_dir: Base directory to search from.
            parts: Module path components.

        Returns:
            Path to potential module file.
        """
        if len(parts) == 1:
            module_path = base_dir / f"{parts[0]}.py"
            if module_path.exists():
                return module_path

        if len(parts) > 1:
            module_path = base_dir / "/".join(parts[:-1]) / f"{parts[-1]}.py"
            if module_path.exists():
                return module_path

        return base_dir / "/".join(parts) / INIT_FILE

    def format_external_imports(self, external_imports: list) -> list[str]:
        """Format external imports as code strings.

        __future__ imports are placed first, then other imports.
        Excluded modules are filtered out.

        Args:
            external_imports: List of external import nodes.

        Returns:
            Formatted import statements.
        """
        future_imports, regular_imports = self._categorize_by_future(external_imports)
        return self._build_import_strings(future_imports, regular_imports)

    def _categorize_by_future(self, external_imports: list) -> tuple[list, list]:
        """Separate imports into __future__ and regular imports.

        Args:
            external_imports: List of import nodes.

        Returns:
            Tuple of (future_imports, regular_imports).
        """
        future_imports = []
        regular_imports = []

        for node in external_imports:
            if self._should_skip_import(node):
                continue

            if isinstance(node, ast.ImportFrom) and node.module == "__future__":
                future_imports.append(node)
            else:
                regular_imports.append(node)

        return future_imports, regular_imports

    def _should_skip_import(self, node: ast.Import | ast.ImportFrom) -> bool:
        """Check if import should be skipped (excluded modules).

        Args:
            node: Import node to check.

        Returns:
            True if import should be skipped.
        """
        if isinstance(node, ast.ImportFrom):
            return self._should_skip_import_from(node)
        if isinstance(node, ast.Import):
            return self._should_skip_regular_import(node)
        return False

    def _should_skip_import_from(self, node: ast.ImportFrom) -> bool:
        """Check if ImportFrom node should be skipped.

        Args:
            node: ImportFrom node to check.

        Returns:
            True if import should be skipped.
        """
        if not node.module:
            return False
        return self._is_module_excluded(node.module)

    def _should_skip_regular_import(self, node: ast.Import) -> bool:
        """Check if Import node should be skipped.

        Args:
            node: Import node to check.

        Returns:
            True if any alias should be skipped.
        """
        return any(self._is_module_excluded(alias.name) for alias in node.names)

    def _is_module_excluded(self, module_name: str) -> bool:
        """Check if a module name should be excluded.

        Args:
            module_name: Module name to check.

        Returns:
            True if module is excluded.
        """
        # Exact match for glaip_sdk or match excluded submodules with boundary
        if module_name == "glaip_sdk":
            return True
        return any(module_name == m or module_name.startswith(m + ".") for m in self.EXCLUDED_MODULES)

    @staticmethod
    def _build_import_strings(future_imports: list, regular_imports: list) -> list[str]:
        """Build formatted import strings from import nodes.

        Args:
            future_imports: List of __future__ import nodes.
            regular_imports: List of regular import nodes.

        Returns:
            Formatted import statements.
        """
        result = []

        if future_imports:
            result.append("# Future imports\n")
            for node in future_imports:
                result.append(ast.unparse(node) + "\n")
            result.append("\n")

        if regular_imports:
            result.append("# External imports\n")
            for node in regular_imports:
                result.append(ast.unparse(node) + "\n")
            result.append("\n")

        return result

    def inline_local_imports(
        self,
        local_imports: list,
        processed_modules: set[str] | None = None,
    ) -> tuple[list[str], list]:
        """Inline local imports into bundled code and collect their external imports.

        Recursively inlines nested local imports.

        Args:
            local_imports: List of (module_name, file_path, import_node) tuples.
            processed_modules: Set of already processed module paths to avoid duplicates.

        Returns:
            Tuple of (inlined_code_strings, collected_external_imports).
        """
        if not local_imports:
            return [], []

        if processed_modules is None:
            processed_modules = set()

        result = ["# Inlined local imports\n"]
        all_external_imports = []

        for module_name, file_path, _ in local_imports:
            if str(file_path) in processed_modules:
                continue
            processed_modules.add(str(file_path))

            # Recursively inline nested local imports
            nested_resolver = ImportResolver(file_path.parent)
            with open(file_path, encoding="utf-8") as f:
                source = f.read()
            tree = ast.parse(source)
            nested_local_imports, nested_external_imports = nested_resolver.categorize_imports(tree)

            if nested_local_imports:
                nested_code, nested_ext_imports = nested_resolver.inline_local_imports(
                    nested_local_imports, processed_modules
                )
                result.extend(nested_code)
                all_external_imports.extend(nested_ext_imports)

            # Inline this module's code
            result.append(f"# --- Inlined from {module_name}.py ---\n")
            code_lines, external_imports = self._extract_module_code(file_path, collect_imports=True)
            result.extend(code_lines)
            all_external_imports.extend(external_imports)
            all_external_imports.extend(nested_external_imports)
            result.append(f"# --- End of {module_name}.py ---\n\n")

        return result, all_external_imports

    def _extract_module_code(
        self,
        file_path: Path,
        *,
        collect_imports: bool = False,
    ) -> tuple[list[str], list] | list[str]:
        """Extract code from module, excluding imports and docstrings.

        Args:
            file_path: Path to the module file.
            collect_imports: If True, also return external imports.

        Returns:
            If collect_imports is True: tuple of (code_lines, external_import_nodes)
            Otherwise: list of code lines.
        """
        with open(file_path, encoding="utf-8") as f:
            local_source = f.read()

        local_tree = ast.parse(local_source)
        tool_dir = file_path.parent

        result, external_imports = self._process_module_nodes(local_tree, tool_dir, collect_imports)

        if collect_imports:
            return result, external_imports
        return result

    def _process_module_nodes(
        self,
        tree: ast.AST,
        tool_dir: Path,
        collect_imports: bool,
    ) -> tuple[list[str], list]:
        """Process AST nodes from a module.

        Args:
            tree: AST tree of the module.
            tool_dir: Directory containing the module.
            collect_imports: Whether to collect external imports.

        Returns:
            Tuple of (code_lines, external_imports).
        """
        result = []
        external_imports = []

        for local_node in tree.body:
            if isinstance(local_node, (ast.Import, ast.ImportFrom)):
                if collect_imports:
                    ext_import = self._get_external_import(local_node, tool_dir)
                    if ext_import:
                        external_imports.append(ext_import)
                continue

            if self._is_docstring(local_node):
                continue

            if isinstance(local_node, ast.ClassDef):
                local_node = self._remove_tool_plugin_decorator(local_node)

            result.append(ast.unparse(local_node) + "\n")

        return result, external_imports

    def _get_external_import(
        self,
        node: ast.Import | ast.ImportFrom,
        tool_dir: Path,
    ) -> ast.Import | ast.ImportFrom | None:
        """Get external import node if not local.

        Args:
            node: Import node to check.
            tool_dir: Directory containing the tool.

        Returns:
            The node if external, None if local.
        """
        if isinstance(node, ast.ImportFrom):
            if node.level > 0:
                return None
            temp_resolver = ImportResolver(tool_dir)
            if temp_resolver.is_local_import(node):
                return None
            return node
        if isinstance(node, ast.Import):
            return node
        return None

    @staticmethod
    def _is_docstring(node: ast.stmt) -> bool:
        """Check if AST node is a docstring.

        Args:
            node: AST statement node.

        Returns:
            True if node is a docstring.
        """
        return isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant)

    @staticmethod
    def _remove_tool_plugin_decorator(node: ast.ClassDef) -> ast.ClassDef:
        """Remove @tool_plugin decorator and BaseTool inheritance from a class node.

        Args:
            node: AST ClassDef node.

        Returns:
            Modified ClassDef node with decorator and base class removed.
        """
        node.decorator_list = ImportResolver._filter_decorators(node.decorator_list)
        node.bases = ImportResolver._filter_bases(node.bases)
        return node

    @staticmethod
    def _filter_decorators(decorator_list: list) -> list:
        """Filter out @tool_plugin decorators.

        Args:
            decorator_list: List of decorator nodes.

        Returns:
            Filtered decorator list.
        """
        filtered = []
        for decorator in decorator_list:
            if ImportResolver._is_tool_plugin_decorator(decorator):
                continue
            filtered.append(decorator)
        return filtered

    @staticmethod
    def _is_tool_plugin_decorator(decorator: ast.expr) -> bool:
        """Check if decorator is @tool_plugin.

        Args:
            decorator: Decorator AST node.

        Returns:
            True if decorator is @tool_plugin.
        """
        return is_tool_plugin_decorator(decorator)

    @staticmethod
    def _filter_bases(bases: list) -> list:
        """Filter out BaseTool from base classes.

        Args:
            bases: List of base class nodes.

        Returns:
            Filtered base class list.
        """
        filtered = []
        for base in bases:
            is_base_tool = isinstance(base, ast.Name) and base.id == "BaseTool"
            if not is_base_tool:
                filtered.append(base)
        return filtered if filtered else []


def load_class(import_path: str) -> type:
    """Dynamically load a class from its import path.

    Args:
        import_path: Python import path (e.g., 'package.module.ClassName').

    Returns:
        The loaded class.

    Raises:
        ImportError: If the module or class cannot be imported.
    """
    try:
        module_path, class_name = import_path.rsplit(".", 1)
        module = importlib.import_module(module_path)
        return getattr(module, class_name)
    except (ValueError, ImportError, AttributeError) as e:
        raise ImportError(f"Failed to load class from '{import_path}': {e}") from e
