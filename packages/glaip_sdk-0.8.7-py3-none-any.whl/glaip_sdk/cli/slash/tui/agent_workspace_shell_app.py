"""Textual agent workspace shell with split-pane layout (PR-C gated path)."""

from __future__ import annotations

import asyncio
import inspect
import os
import re
import shlex
import shutil
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from textwrap import wrap
from typing import TYPE_CHECKING, Literal, cast

from rich.markup import escape as _escape_markup

from glaip_sdk._version import __version__ as SDK_VERSION
from glaip_sdk.cli.slash.tui.agent_workspace_foundation import (
    AGENT_WORKSPACE_LOGO_TEXT,
    AGENT_WORKSPACE_THEME,
    MODEL_LABEL_PLACEHOLDER,
    format_summary_rows,
    format_utc_timestamp,
    workspace_label,
)

try:  # pragma: no cover - optional dependency guard
    from glaip_sdk.cli.slash.tui.indicators import PulseIndicator as _PulseIndicator
except Exception:  # pragma: no cover - textual unavailable
    _PulseIndicator = None

try:  # pragma: no cover - optional dependency guard
    from glaip_sdk.cli.slash.tui.keybind_shortcuts import close_shortcuts as _close_shortcuts
except Exception:  # pragma: no cover - textual unavailable
    _close_shortcuts = None

if TYPE_CHECKING:  # pragma: no cover - typing only
    from textual.app import App, ComposeResult
    from textual.binding import Binding
    from textual.containers import Container, Vertical
    from textual.widgets import Input, Static
else:  # pragma: no cover - optional dependency guard
    try:
        from textual.app import App, ComposeResult
        from textual.binding import Binding
        from textual.containers import Container, Vertical
        from textual.widgets import Input, Static
    except Exception:  # pragma: no cover - textual unavailable
        App = None  # type: ignore[assignment]
        ComposeResult = None  # type: ignore[assignment]
        Binding = None  # type: ignore[assignment]
        Container = None  # type: ignore[assignment]
        Vertical = None  # type: ignore[assignment]
        Input = None  # type: ignore[assignment]
        Static = None  # type: ignore[assignment]


TEXTUAL_SUPPORTED = App is not None and Input is not None and Static is not None

APP_QUIT_ACTION = "app.quit"
COMPOSER_ID = "workspace-composer"
TRANSCRIPT_ID = "messages"
DETAILS_ID = "agent-info"
SIDEBAR_ID = "right-sidebar"
LEFT_COLUMN_ID = "left-column"
AGENT_CONTEXT_NAME_ID = "agent-context-name"
AGENT_CONTEXT_ACCOUNT_ID = "agent-context-account"
HEADER_ROW_ID = "header-row"
CONTEXT_BLOCK_ID = "context-block"
TRANSCRIPT_SCROLL_ID = "messages-scroll"
KEYBAR_ROW_ID = "keybar-row"
KEYBAR_LEFT_ID = "keybar-left"
KEYBAR_RIGHT_ID = "keybar-right"
COMMAND_LOADING_ID = "command-loading"
TRANSCRIPT_MAX_LINES = 500

WorkspaceEventKind = Literal["message", "command", "exit"]
StatusSummaryProvider = Callable[[], list[str]] | Callable[[list[str]], list[str]]
TranscriptSink = Callable[[list[str]], None]
MessageRunProvider = Callable[[str], str | tuple[str, list[str]] | None]

WORKSPACE_THEME = AGENT_WORKSPACE_THEME
WORKSPACE_CAPTURE_PATH_ENV = "AIP_TUI_CAPTURE_SCREENSHOT_PATH"
WORKSPACE_CAPTURE_DELAY_ENV = "AIP_TUI_CAPTURE_SCREENSHOT_DELAY"
COMMAND_TRANSITION_DELAY_SECONDS = 0.35
_ANSI_RE = re.compile(r"\x1B\[[0-?]*[ -/]*[@-~]")
_MD_INLINE_CODE_RE = re.compile(r"`([^`\n]+)`")
_MD_BOLD_RE = re.compile(r"\*\*([^*\n]+)\*\*")
_MD_ITALIC_RE = re.compile(r"(?<!\*)\*([^*\n]+)\*(?!\*)")
_WORKSPACE_ALLOWED_SLASH_COMMANDS = frozenset(
    {
        "/details",
        "/prompt",
        "/runs",
        "/schedules",
        "/status",
        "/help",
        "/?",
        "/export",
        "/transcripts",
    }
)

_TRANSCRIPT_USER_FG = "#d9e4f2"
_TRANSCRIPT_USER_BG = "#1a2431"
_TRANSCRIPT_COMMAND_FG = "#f2d7a7"
_TRANSCRIPT_COMMAND_BG = "#2a2118"
_TRANSCRIPT_STATUS_FG = "#c7d8ca"
_TRANSCRIPT_STATUS_BG = "#1c2a21"
_TRANSCRIPT_SYSTEM_FG = "#c7d0dc"
_TRANSCRIPT_SYSTEM_BG = "#1f2733"
_TRANSCRIPT_AGENT_FG = "#d7e3f4"
_TRANSCRIPT_AGENT_BG = "#1b2532"
_TRANSCRIPT_AGENT_CODE_FG = "#b9d7ff"
_TRANSCRIPT_AGENT_CODE_BG = "#152336"
_TRANSCRIPT_USER_LABEL = "USER>"
_TRANSCRIPT_AGENT_LABEL = "AGENT>"
_RUN_FAILED_PREFIX = "run failed:"

WORKSPACE_TIP_TEXT = "Tip: type / for commands. Ctrl+B toggles details."


def _workspace_css() -> str:
    """Build workspace CSS from shared demo theme tokens."""
    ui = WORKSPACE_THEME
    return f"""
    Screen {{
        background: {ui["screen"]};
        color: #d2dbea;
    }}

    #root {{
        layout: horizontal;
        width: 100%;
        height: 100%;
    }}

    #left-column {{
        layout: vertical;
        width: 1fr;
        height: 100%;
        padding: 1;
    }}

    #header-row {{
        layout: horizontal;
        width: 100%;
        height: 2;
        margin-bottom: 1;
    }}

    #workspace {{
        color: {ui["workspace"]};
        width: 1fr;
        height: auto;
        margin: 0;
    }}

    #context-block {{
        layout: vertical;
        width: 48;
        min-width: 48;
        height: auto;
    }}

    #agent-context-name {{
        color: {ui["heading"]};
        text-style: bold;
        height: auto;
        content-align: right middle;
    }}

    #agent-context-account {{
        color: {ui["muted"]};
        height: auto;
        content-align: right middle;
    }}

    #center-wrapper {{
        display: block;
        width: 100%;
        height: auto;
        align: center middle;
        margin-top: 2;
    }}

    #center-wrapper.-has-turns {{
        height: 1fr;
        align: center top;
        margin-top: 0;
    }}

    #chat-column {{
        width: 100%;
        height: auto;
        layout: vertical;
        padding-right: 0;
    }}

    #chat-column.-has-turns {{
        height: 100%;
    }}

    #messages-scroll {{
        display: none;
        border: none;
        background: transparent;
        color: {ui["text"]};
        height: auto;
    }}

    #messages-scroll.-has-turns {{
        display: block;
        border: round {ui["border"]};
        background: {ui["panel_alt"]};
        height: 1fr;
        overflow-y: auto;
        scrollbar-size: 1 1;
        scrollbar-color: {ui["accent"]};
    }}

    #messages {{
        display: block;
        border: none;
        background: transparent;
        color: {ui["text"]};
        padding: 1;
        height: auto;
        content-align: left top;
    }}

    #messages.-has-turns {{
        display: block;
    }}

    #title {{
        color: {ui["brand"]};
        text-style: bold;
        content-align: center middle;
        height: auto;
        margin-bottom: 0;
    }}

    #hints-row {{
        width: 100%;
        height: auto;
        align-horizontal: left;
        margin-top: 0;
        layout: vertical;
    }}

    #command-loading {{
        display: none;
        width: auto;
        max-width: 1fr;
        height: 1;
        margin-right: 1;
        border: none;
        padding: 0;
        color: #d2dbea;
        background: transparent;
        content-align: left middle;
    }}

    #command-loading.-active {{
        display: block;
    }}

    #tip {{
        color: {ui["accent"]};
        margin-top: 0;
        content-align: left middle;
    }}

    #prompt-row {{
        width: 100%;
        height: auto;
        align-horizontal: center;
        margin-top: 1;
    }}

    #composer-box {{
        width: 100%;
        border: round #4d5f75;
        background: #161f2c;
        padding: 0 1;
        height: 3;
    }}

    #workspace-composer {{
        border: none;
        background: transparent;
        color: {ui["text"]};
    }}

    #right-sidebar {{
        width: 32%;
        min-width: 30;
        height: 100%;
        border-left: tall {ui["border"]};
        background: {ui["panel_alt"]};
        padding: 2 2 1 2;
        layout: vertical;
    }}

    #right-sidebar.-hidden {{
        display: none;
        width: 0;
    }}

    .-hidden {{
        display: none;
    }}

    #sidebar-header {{
        color: {ui["heading"]};
        text-style: bold;
        margin-bottom: 1;
        height: auto;
    }}

    #agent-info {{
        color: {ui["text"]};
        margin-top: 1;
        height: 1fr;
    }}

    #footer-row {{
        dock: bottom;
        layout: horizontal;
        align-vertical: middle;
        height: 1;
        width: 100%;
        margin-top: 1;
        margin-bottom: 0;
    }}

    #footer-version {{
        color: {ui["text"]};
        width: 1fr;
        content-align: right middle;
        text-style: bold;
    }}

    #keybar-row {{
        dock: bottom;
        layout: horizontal;
        width: 100%;
        height: 1;
        background: #2b3541;
        color: #e2e8f0;
        padding: 0 1;
    }}

    #keybar-left {{
        width: 1fr;
    }}

    #keybar-right {{
        width: auto;
        content-align: right middle;
        color: #c4cede;
    }}
    """


def _get_workspace_label() -> str:
    return workspace_label()


@dataclass(frozen=True)
class AgentWorkspaceDetails:
    """Resolved agent metadata shown in workspace shell."""

    id: str
    name: str
    account_id: str = ""
    description: str = ""
    type: str = ""
    framework: str = ""
    version: str = ""
    model_label: str = ""
    tools_summary: str = "0"
    mcps_summary: str = "0"
    tool_names: tuple[str, ...] = ()
    mcp_names: tuple[str, ...] = ()
    updated_at: str = ""


@dataclass(frozen=True)
class AgentWorkspaceEvent:
    """Result emitted by the workspace shell."""

    kind: WorkspaceEventKind
    value: str = ""


def _wrap_multiline(value: str, *, width: int, break_on_hyphens: bool = True) -> str:
    if not value:
        return "-"
    lines = wrap(value, width=width, break_long_words=True, break_on_hyphens=break_on_hyphens)
    return "\n".join(lines) if lines else value


def _summary_count(value: str) -> str:
    token = (value or "").strip().split(" ", 1)[0]
    return token if token.isdigit() else value.strip() or "0"


def _format_named_list(*, title: str, items: tuple[str, ...], color: str, muted: str) -> str:
    header = f"[bold {color}]{title}[/]"
    if not items:
        return f"{header}\n[{muted}]- none[/]"

    max_items = 5
    rendered = [f"[{color}]•[/] {_escape_markup(name)}" for name in items[:max_items]]
    extra = len(items) - max_items
    if extra > 0:
        rendered.append(f"[{muted}]• +{extra} more[/]")
    return "\n".join([header, *rendered])


def _format_details(details: AgentWorkspaceDetails) -> str:
    muted = WORKSPACE_THEME["muted"]
    model_label = _escape_markup(details.model_label or MODEL_LABEL_PLACEHOLDER)
    meta = format_summary_rows(
        [
            ("account", details.account_id or "-"),
            ("description", _escape_markup(details.description or "-")),
            ("type", details.type or "config"),
            ("framework", details.framework or "-"),
            ("version", details.version or "-"),
            ("model", model_label),
            ("updated", format_utc_timestamp(details.updated_at)),
        ],
        muted_color=muted,
    )

    tools = _format_named_list(
        title=f"Tools ({_summary_count(details.tools_summary)})",
        items=details.tool_names,
        color=WORKSPACE_THEME["tools"],
        muted=muted,
    )
    mcps = _format_named_list(
        title=f"MCPs ({_summary_count(details.mcps_summary)})",
        items=details.mcp_names,
        color=WORKSPACE_THEME["mcps"],
        muted=muted,
    )
    return "\n\n".join([meta, tools, mcps])


def _format_sidebar_header(details: AgentWorkspaceDetails) -> str:
    name = _escape_markup(details.name or "-")
    id_val = _wrap_multiline(_escape_markup(details.id or "-"), width=44)
    muted = WORKSPACE_THEME["muted"]
    heading = WORKSPACE_THEME["heading"]
    return f"[bold {heading}]{name}[/]\n[{muted}]{id_val}[/]"


def _format_agent_context_name(details: AgentWorkspaceDetails) -> str:
    return _escape_markup(details.name or "-")


def _format_agent_context_account(details: AgentWorkspaceDetails) -> str:
    return f"account {_escape_markup(details.account_id or '-')}"


def _format_transcript(lines: list[str]) -> str:
    if not lines:
        return ""
    normalized: list[str] = []
    for raw in lines:
        normalized.append(_format_transcript_line(raw))
    return "\n".join(normalized)


def _format_transcript_line(raw: str) -> str:
    cleaned = _ANSI_RE.sub("", str(raw))
    stripped = cleaned.strip()
    if not stripped:
        return ""

    if stripped.startswith("You:"):
        body = _escape_markup(stripped[4:].strip())
        return (
            f"[bold {_TRANSCRIPT_USER_FG} on {_TRANSCRIPT_USER_BG}]{_TRANSCRIPT_USER_LABEL}[/]"
            f"[{_TRANSCRIPT_USER_FG} on {_TRANSCRIPT_USER_BG}] {body}[/]"
        )

    if stripped.startswith("Cmd:"):
        body_raw = stripped[4:].strip()
        body = _escape_markup(body_raw)
        return (
            f"[bold {_TRANSCRIPT_COMMAND_FG} on {_TRANSCRIPT_COMMAND_BG}]Cmd:[/]"
            f"[bold {_TRANSCRIPT_COMMAND_FG} on {_TRANSCRIPT_COMMAND_BG}] {body}[/]"
        )

    if stripped.startswith("System:"):
        body_raw = stripped[7:].strip()
        body = _escape_markup(body_raw)
        if body_raw.startswith("/"):
            return (
                f"[bold {_TRANSCRIPT_COMMAND_FG} on {_TRANSCRIPT_COMMAND_BG}]Cmd:[/]"
                f"[bold {_TRANSCRIPT_COMMAND_FG} on {_TRANSCRIPT_COMMAND_BG}] {body}[/]"
            )
        return (
            f"[bold {_TRANSCRIPT_SYSTEM_FG} on {_TRANSCRIPT_SYSTEM_BG}]System:[/]"
            f"[{_TRANSCRIPT_SYSTEM_FG} on {_TRANSCRIPT_SYSTEM_BG}] {body}[/]"
        )

    if stripped.startswith("Agent:"):
        body = _render_agent_markdown_inline(stripped[6:].strip())
        return (
            f"[bold {_TRANSCRIPT_AGENT_FG} on {_TRANSCRIPT_AGENT_BG}]{_TRANSCRIPT_AGENT_LABEL}[/]"
            f"[{_TRANSCRIPT_AGENT_FG} on {_TRANSCRIPT_AGENT_BG}] {body}[/]"
        )

    if stripped.startswith("Status:"):
        raw_body = stripped[7:].strip()
        body = _escape_markup(_render_status_body(raw_body))
        return (
            f"[bold {_TRANSCRIPT_STATUS_FG} on {_TRANSCRIPT_STATUS_BG}]Status:[/]"
            f"[{_TRANSCRIPT_STATUS_FG} on {_TRANSCRIPT_STATUS_BG}] {body}[/]"
        )

    if stripped.startswith("-"):
        body = stripped.lstrip("- ").strip()
        if body.lower().startswith("step:"):
            body = body[5:].strip()
        normalized = _render_step_bullet(body)
        return f"[{_TRANSCRIPT_STATUS_FG}]  {_escape_markup(normalized)}[/]"

    return _escape_markup(stripped)


def _render_agent_markdown_inline(text: str) -> str:
    """Render safe inline markdown subset in agent rows."""
    raw = str(text or "").strip()
    if not raw:
        return "-"

    code_spans: list[str] = []

    def _capture_code(match: re.Match[str]) -> str:
        index = len(code_spans)
        code_spans.append(_escape_markup(match.group(1).strip()))
        return f"\u0000CODE{index}\u0000"

    without_code = _MD_INLINE_CODE_RE.sub(_capture_code, raw)
    escaped = _escape_markup(without_code)
    escaped = _MD_BOLD_RE.sub(lambda m: f"[bold]{m.group(1)}[/]", escaped)
    escaped = _MD_ITALIC_RE.sub(lambda m: f"[italic]{m.group(1)}[/]", escaped)

    for index, code in enumerate(code_spans):
        token = f"\u0000CODE{index}\u0000"
        escaped = escaped.replace(token, f"[{_TRANSCRIPT_AGENT_CODE_FG} on {_TRANSCRIPT_AGENT_CODE_BG}] {code} [/]")

    return escaped


def _render_status_body(raw_body: str) -> str:
    """Render status body with concise semantic markers."""
    body = str(raw_body or "").strip()
    lowered = body.lower()
    if lowered == "running":
        return "[~] running"
    if lowered.startswith("completed in "):
        return f"[ok] {body}"
    if lowered.startswith(_RUN_FAILED_PREFIX):
        return f"[x] {body}"
    return body


def _render_step_bullet(body: str) -> str:
    """Render compact step rows with lightweight symbolic markers."""
    cleaned = str(body or "").strip()
    lowered = cleaned.lower()
    if lowered.startswith("tool:"):
        detail = cleaned[5:].strip()
        return f"- [*] {detail}" if detail else "- [*]"
    if lowered.startswith("action:"):
        detail = cleaned[7:].strip()
        return f"- [>] {detail}" if detail else "- [>]"
    return f"- {cleaned}" if cleaned else "-"


if TEXTUAL_SUPPORTED:
    WORKSPACE_CSS = _workspace_css()

    class AgentWorkspaceShellApp(App[AgentWorkspaceEvent | None]):
        """Gated workspace shell for agent context with split-pane layout."""

        CSS = WORKSPACE_CSS

        # Disable Textual built-in command palette for this shell.
        ENABLE_COMMAND_PALETTE = False
        COMMAND_PALETTE_BINDING = ""

        BINDINGS = [
            *(
                _close_shortcuts(escape_action=APP_QUIT_ACTION, quit_action=APP_QUIT_ACTION)
                if _close_shortcuts is not None
                else (
                    Binding("escape", APP_QUIT_ACTION, "Close", priority=True, show=True),
                    Binding("q", APP_QUIT_ACTION, "Close", priority=True, show=False),
                )
            ),
            Binding("ctrl+c", APP_QUIT_ACTION, "Quit", show=False),
            Binding("enter", "submit_composer", "Send", show=True),
            Binding("ctrl+b", "toggle_sidebar", "Sidebar", show=True, priority=True, key_display="ctrl+b"),
            Binding("pageup", "transcript_page_up", "Scroll Up", show=False),
            Binding("pagedown", "transcript_page_down", "Scroll Down", show=False),
            Binding("ctrl+p", "noop", "Palette", show=False, priority=True),
            Binding("ctrl+t", "transcript_hint", "Transcript", show=False),
        ]

        CSS_NAME = ""

        def __init__(
            self,
            *,
            details: AgentWorkspaceDetails,
            transcript_lines: list[str] | None = None,
            composer_placeholder: str,
            status_summary_provider: StatusSummaryProvider | None = None,
            transcript_sink: TranscriptSink | None = None,
            message_run_provider: MessageRunProvider | None = None,
        ) -> None:
            """Initialize app state for a single workspace interaction turn."""
            super().__init__()
            self._details = details
            self._transcript_lines = list(transcript_lines or [])[-TRANSCRIPT_MAX_LINES:]
            self._composer_placeholder = composer_placeholder
            self._status_summary_provider = status_summary_provider
            self._transcript_sink = transcript_sink
            self._message_run_provider = message_run_provider
            self._sidebar_visible = False
            self._workspace_label = _get_workspace_label()
            self._pending_command_event: AgentWorkspaceEvent | None = None
            self._inline_status_running = False
            self._inline_message_running = False

        def compose(self) -> ComposeResult:
            """Render docked workspace mirroring demo_agent_context layout."""
            has_turns = bool(self._transcript_lines)
            with Container(id="root"):
                with Vertical(id=LEFT_COLUMN_ID):
                    with Container(id=HEADER_ROW_ID):
                        yield Static(f"{self._workspace_label}:agent", id="workspace")
                        with Vertical(id=CONTEXT_BLOCK_ID, classes="-hidden" if self._sidebar_visible else ""):
                            yield Static(_format_agent_context_name(self._details), id=AGENT_CONTEXT_NAME_ID)
                            yield Static(_format_agent_context_account(self._details), id=AGENT_CONTEXT_ACCOUNT_ID)

                    with Container(id="center-wrapper", classes="-has-turns" if has_turns else ""):
                        with Vertical(id="chat-column", classes="-has-turns" if has_turns else ""):
                            if not has_turns:
                                yield Static(AGENT_WORKSPACE_LOGO_TEXT, id="title")
                            with Container(id=TRANSCRIPT_SCROLL_ID, classes="-has-turns" if has_turns else ""):
                                yield Static(
                                    _format_transcript(self._transcript_lines),
                                    id=TRANSCRIPT_ID,
                                    classes="-has-turns" if has_turns else "",
                                )

                    with Container(id="prompt-row"):
                        with Container(id="composer-box"):
                            yield Input(
                                placeholder=self._composer_placeholder,
                                id=COMPOSER_ID,
                            )

                    with Container(id="hints-row"):
                        yield Static(WORKSPACE_TIP_TEXT, id="tip")

                    with Container(id="footer-row"):
                        if _PulseIndicator is not None:
                            yield _PulseIndicator(
                                "Ready",
                                id=COMMAND_LOADING_ID,
                                variant="info",
                                width=30,
                                speed_ms=80,
                                low_motion=False,
                                pause_at_edges=True,
                                classes="-hidden",
                            )
                        else:
                            yield Static("Ready", id=COMMAND_LOADING_ID, classes="-hidden")
                        yield Static(f"GL AIP SDK v{SDK_VERSION}", id="footer-version")

                with Vertical(id=SIDEBAR_ID, classes="" if self._sidebar_visible else "-hidden"):
                    yield Static(_format_sidebar_header(self._details), id="sidebar-header")
                    yield Static(_format_details(self._details), id=DETAILS_ID)

            with Container(id=KEYBAR_ROW_ID, classes="-hidden"):
                yield Static("[bold #f2b266]esc[/] Close   [bold #f2b266]ctrl+b[/] Sidebar", id=KEYBAR_LEFT_ID)
                yield Static("", id=KEYBAR_RIGHT_ID)

        def on_mount(self) -> None:
            """Focus composer input when the workspace opens."""
            self.query_one(f"#{COMPOSER_ID}", Input).focus()
            self._refresh_transcript_widget()
            self._refresh_chrome_visibility()
            self._schedule_optional_capture()

        def _schedule_optional_capture(self) -> None:
            """Capture a real Textual screenshot when env opts in."""
            path_raw = os.getenv(WORKSPACE_CAPTURE_PATH_ENV, "").strip()
            if not path_raw:
                return

            delay_raw = os.getenv(WORKSPACE_CAPTURE_DELAY_ENV, "0.45").strip()
            try:
                delay = max(0.0, float(delay_raw))
            except ValueError:
                delay = 0.45

            self.set_timer(delay, lambda: self._capture_workspace_screenshot(path_raw))

        def _capture_workspace_screenshot(self, destination: str) -> None:
            """Best-effort capture to destination path."""
            path = Path(destination)
            path.parent.mkdir(parents=True, exist_ok=True)

            if self._try_save_screenshot(path):
                return
            self._try_export_screenshot(path)

        def _try_save_screenshot(self, path: Path) -> bool:
            """Try Textual save_screenshot API and normalize output path."""
            save_method = getattr(self, "save_screenshot", None)
            if not callable(save_method):
                return False

            try:
                result = save_method(str(path))
            except Exception:
                return False

            if path.exists():
                return True

            if isinstance(result, (str, Path)):
                result_path = Path(result)
                if result_path.exists():
                    if result_path != path:
                        shutil.copy2(result_path, path)
                    return True
            return False

        def _try_export_screenshot(self, path: Path) -> bool:
            """Try Textual export_screenshot API and write SVG output."""
            export_method = getattr(self, "export_screenshot", None)
            if not callable(export_method):
                return False

            try:
                svg = export_method()
            except Exception:
                return False

            if isinstance(svg, str) and svg.strip():
                path.write_text(svg, encoding="utf-8")
                return True
            return False

        def action_toggle_sidebar(self) -> None:
            """Toggle right sidebar visibility."""
            self._sidebar_visible = not self._sidebar_visible
            sidebar = self.query_one(f"#{SIDEBAR_ID}", Vertical)
            context_block = self.query_one(f"#{CONTEXT_BLOCK_ID}", Vertical)
            if self._sidebar_visible:
                sidebar.remove_class("-hidden")
                context_block.add_class("-hidden")
            else:
                sidebar.add_class("-hidden")
                context_block.remove_class("-hidden")
            self._refresh_chrome_visibility()

        def action_transcript_page_up(self) -> None:
            """Scroll transcript viewport upward by one page."""
            transcript_scroll = self.query_one(f"#{TRANSCRIPT_SCROLL_ID}")
            scroll_page_up = getattr(transcript_scroll, "scroll_page_up", None)
            if callable(scroll_page_up):
                scroll_page_up(animate=False)

        def action_transcript_page_down(self) -> None:
            """Scroll transcript viewport downward by one page."""
            transcript_scroll = self.query_one(f"#{TRANSCRIPT_SCROLL_ID}")
            scroll_page_down = getattr(transcript_scroll, "scroll_page_down", None)
            if callable(scroll_page_down):
                scroll_page_down(animate=False)

        def action_submit_composer(self) -> None:
            """Emit message/command/exit event from composer input."""
            if self._pending_command_event is not None or self._inline_status_running or self._inline_message_running:
                return

            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            value = (composer.value or "").strip()
            if not value:
                return

            if value in {"/exit", "/back", "/q"}:
                self.exit(AgentWorkspaceEvent(kind="exit", value=value))
                return

            if value.startswith("/"):
                command = value.split(maxsplit=1)[0].lower()
                if command == "/status" and self._status_summary_provider is not None:
                    self._run_inline_status(value)
                    return
                if command not in _WORKSPACE_ALLOWED_SLASH_COMMANDS:
                    self._reject_workspace_command(value)
                    return
                self._queue_command_transition(value)
                return

            if self._message_run_provider is not None:
                self._run_inline_message(value)
                return

            self.exit(AgentWorkspaceEvent(kind="message", value=value))

        def _run_inline_message(self, message_text: str) -> None:
            """Execute agent message run while keeping users on workspace surface."""
            self._append_user_entry(message_text)
            self._append_transcript_line("Status: running")

            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.value = ""
            composer.disabled = True

            loading = self.query_one(f"#{COMMAND_LOADING_ID}", Static)
            update_message = getattr(loading, "update_message", None)
            if callable(update_message):
                update_message("Running...")
            else:
                loading.update("Running...")
            loading.remove_class("-hidden")
            loading.add_class("-active")
            start = getattr(loading, "start", None)
            if callable(start):
                start()

            tip = self.query_one("#tip", Static)
            tip.add_class("-hidden")

            self._inline_message_running = True
            self.run_worker(
                self._run_inline_message_task(message_text),
                name="workspace-inline-message",
                group="workspace-inline",
                exclusive=True,
            )

        async def _run_inline_message_task(self, message_text: str) -> None:
            """Run inline message provider in a Textual worker."""
            try:
                reply, status_lines = await asyncio.to_thread(self._run_inline_message_provider, message_text)
                self._finalize_inline_message(reply, status_lines)
            except Exception as exc:  # pragma: no cover - defensive runtime guard
                self._finalize_inline_message(None, [f"{_RUN_FAILED_PREFIX} {exc}"])

        def _run_inline_message_provider(self, message_text: str) -> tuple[str | None, list[str]]:
            """Execute message provider and normalize reply/status lines."""
            provider = self._message_run_provider
            if provider is None:
                return None, []

            result = provider(message_text)
            return self._parse_message_run_result(result)

        @staticmethod
        def _parse_message_run_result(result: str | tuple[str, list[str]] | None) -> tuple[str | None, list[str]]:
            """Normalize message provider return shape."""
            if result is None:
                return None, []
            if isinstance(result, tuple) and len(result) == 2:
                reply, status_lines = result
                return str(reply or "").strip() or None, [str(line) for line in status_lines if str(line).strip()]
            return str(result or "").strip() or None, []

        def _finalize_inline_message(self, reply: str | None, status_lines: list[str]) -> None:
            """Restore workspace controls and append final agent run summary lines."""
            failure_line = self._derive_inline_failure_status(reply, status_lines)
            if failure_line is not None:
                self._append_transcript_line(f"Status: {failure_line}")

            completion_line, detail_lines = self._split_inline_status_lines(status_lines, failure_line=failure_line)

            for detail_line in detail_lines:
                self._append_transcript_line(f"  - {detail_line}")

            if completion_line is not None:
                self._append_transcript_line(f"Status: {completion_line}")

            self._append_inline_reply_line(reply, failure_line=failure_line)
            self._inline_message_running = False
            self._finalize_inline_status()

        def _split_inline_status_lines(
            self,
            status_lines: list[str],
            *,
            failure_line: str | None,
        ) -> tuple[str | None, list[str]]:
            """Return completion label and non-noise detail rows from status lines."""
            completion_line: str | None = None
            detail_lines: list[str] = []

            for raw_line in status_lines:
                cleaned = str(raw_line).strip()
                if not cleaned:
                    continue
                if self._should_skip_inline_status_line(cleaned, failure_line=failure_line):
                    continue

                normalized_completion = self._normalize_inline_completion_line(cleaned)
                if normalized_completion is not None:
                    completion_line = normalized_completion
                    continue

                detail_lines.append(cleaned)

            return completion_line, detail_lines

        def _should_skip_inline_status_line(self, status_line: str, *, failure_line: str | None) -> bool:
            """Return True for status rows that should not be shown as detail bullets."""
            if self._is_noisy_inline_status_line(status_line):
                return True
            if failure_line is not None and self._is_failure_status_line(status_line):
                return True
            return False

        def _append_inline_reply_line(self, reply: str | None, *, failure_line: str | None) -> None:
            """Append terminal reply line after status rows are rendered."""
            if reply:
                self._append_transcript_line(f"Agent: {reply}")
                return
            if failure_line is None:
                self._append_transcript_line("Agent: Run finished.")

        @staticmethod
        def _is_noisy_inline_status_line(status_line: str) -> bool:
            """Return True for noisy run-id rows that add little user value."""
            lowered = status_line.lower().strip()
            return bool(re.match(r"^run\s+[a-z0-9_-]+\s+(completed|finished|done)$", lowered))

        @staticmethod
        def _normalize_inline_completion_line(status_line: str) -> str | None:
            """Map duration/completion metadata rows into one canonical completion label."""
            lowered = status_line.lower().strip()
            if lowered.startswith("completed in "):
                return status_line.strip()
            if lowered.startswith("duration:"):
                duration = status_line.split(":", 1)[1].strip()
                if duration:
                    return f"completed in {duration}"
            return None

        @staticmethod
        def _derive_inline_failure_status(reply: str | None, status_lines: list[str]) -> str | None:
            """Return a concise failure status row when inline run completed without a response."""
            text = (reply or "").strip()
            lowered = text.lower()

            if lowered.startswith(_RUN_FAILED_PREFIX):
                reason = text.split(":", 1)[1].strip() if ":" in text else ""
                return f"{_RUN_FAILED_PREFIX} {reason or 'unknown error'}"

            failure_detail = next(
                (line.strip() for line in status_lines if AgentWorkspaceShellApp._is_failure_status_line(line)),
                None,
            )
            if failure_detail is not None:
                return AgentWorkspaceShellApp._normalize_failure_status_line(failure_detail)

            if "no agent response received" in lowered or "no final response available" in lowered:
                return f"{_RUN_FAILED_PREFIX} no final response available"

            return None

        @staticmethod
        def _is_failure_status_line(status_line: str) -> bool:
            """Return True when a status line denotes a failed/aborted run."""
            lowered = status_line.lower().strip()
            return lowered.startswith(_RUN_FAILED_PREFIX) or lowered.startswith("error:") or lowered.startswith("abort")

        @staticmethod
        def _normalize_failure_status_line(status_line: str) -> str:
            """Convert a failure-like status row into canonical run-failed form."""
            cleaned = status_line.strip()
            lowered = cleaned.lower()

            if lowered.startswith(_RUN_FAILED_PREFIX):
                reason = cleaned.split(":", 1)[1].strip() if ":" in cleaned else ""
                return f"{_RUN_FAILED_PREFIX} {reason or 'unknown error'}"

            return f"{_RUN_FAILED_PREFIX} {cleaned}"

        def _reject_workspace_command(self, command_text: str) -> None:
            """Keep unsupported slash commands in-place with a concise inline hint."""
            self._append_command_entry(command_text)
            self._append_transcript_line("Status: command unavailable in this workspace.")
            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.value = ""
            composer.disabled = False
            composer.focus()

        def _queue_command_transition(self, command_text: str) -> None:
            """Show in-page pulse before leaving to execute slash command."""
            self._append_command_entry(command_text)
            self._pending_command_event = AgentWorkspaceEvent(kind="command", value=command_text)

            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.disabled = True

            loading = self.query_one(f"#{COMMAND_LOADING_ID}", Static)
            update_message = getattr(loading, "update_message", None)
            if callable(update_message):
                update_message(f"Opening {command_text}...")
            else:
                loading.update(f"Opening {command_text}...")
            loading.remove_class("-hidden")
            loading.add_class("-active")
            start = getattr(loading, "start", None)
            if callable(start):
                start()

            tip = self.query_one("#tip", Static)
            tip.add_class("-hidden")

            self.set_timer(COMMAND_TRANSITION_DELAY_SECONDS, self._flush_pending_command)

        def _flush_pending_command(self) -> None:
            """Exit app with pending slash command event after pulse delay."""
            if self._pending_command_event is None:
                return
            event = self._pending_command_event
            self._pending_command_event = None
            self.exit(event)

        def _run_inline_status(self, command_text: str) -> None:
            """Execute /status and keep users on the current workspace surface."""
            self._inline_status_running = True
            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.disabled = True

            loading = self.query_one(f"#{COMMAND_LOADING_ID}", Static)
            update_message = getattr(loading, "update_message", None)
            if callable(update_message):
                update_message(f"Checking {command_text}...")
            else:
                loading.update(f"Checking {command_text}...")
            loading.remove_class("-hidden")
            loading.add_class("-active")
            start = getattr(loading, "start", None)
            if callable(start):
                start()

            tip = self.query_one("#tip", Static)
            tip.add_class("-hidden")

            self.set_timer(0.05, lambda: self._complete_inline_status(command_text))

        def _complete_inline_status(self, command_text: str) -> None:
            """Finish inline /status execution and refresh transcript content."""
            lines: list[str]
            try:
                provider = self._status_summary_provider
                lines = self._collect_inline_status_lines(provider, command_text)
            except Exception as exc:  # pragma: no cover - defensive
                lines = [f"Status unavailable: {exc}"]

            self._append_command_entry(command_text)
            if lines:
                self._append_transcript_line("Status:")
                for line in lines:
                    self._append_transcript_line(f"  - {line}")
            else:
                self._append_transcript_line("Status: unavailable")

            self._finalize_inline_status()

        @staticmethod
        def _collect_inline_status_lines(provider: StatusSummaryProvider | None, command_text: str) -> list[str]:
            """Collect inline status lines while preserving command arguments when supported."""
            if not callable(provider):
                return []

            if AgentWorkspaceShellApp._status_provider_accepts_args(provider):
                provider_with_args = cast(Callable[[list[str]], list[str]], provider)
                return list(provider_with_args(AgentWorkspaceShellApp._status_command_args(command_text)))

            provider_no_args = cast(Callable[[], list[str]], provider)
            return list(provider_no_args())

        @staticmethod
        def _status_provider_accepts_args(provider: StatusSummaryProvider) -> bool:
            """Return True when provider signature accepts one or more parameters."""
            try:
                return bool(inspect.signature(provider).parameters)
            except (TypeError, ValueError):
                return False

        @staticmethod
        def _status_command_args(command_text: str) -> list[str]:
            """Parse slash command text and return only argument tokens."""
            try:
                tokens = shlex.split(command_text)
            except ValueError:
                return []

            if len(tokens) <= 1:
                return []
            return list(tokens[1:])

        def _append_transcript_line(self, line: str) -> None:
            """Append one line and refresh transcript widget/state classes."""
            self._transcript_lines.append(line)
            if len(self._transcript_lines) > TRANSCRIPT_MAX_LINES:
                self._transcript_lines = self._transcript_lines[-TRANSCRIPT_MAX_LINES:]
            transcript_sink = self._transcript_sink
            if callable(transcript_sink):
                transcript_sink(list(self._transcript_lines))

            messages = self.query_one(f"#{TRANSCRIPT_ID}", Static)
            messages.update(_format_transcript(self._transcript_lines))
            messages.add_class("-has-turns")
            transcript_scroll = self.query_one(f"#{TRANSCRIPT_SCROLL_ID}")
            transcript_scroll.add_class("-has-turns")
            scroll_end = getattr(transcript_scroll, "scroll_end", None)
            if callable(scroll_end):
                scroll_end(animate=False)

            chat = self.query_one("#chat-column", Vertical)
            chat.add_class("-has-turns")

            wrapper = self.query_one("#center-wrapper", Container)
            wrapper.add_class("-has-turns")

            title_nodes = list(self.query("#title"))
            for node in title_nodes:
                node.remove()

            self._refresh_chrome_visibility()

        def _refresh_transcript_widget(self) -> None:
            """Refresh transcript rendering and keep focus on the latest entries."""
            try:
                messages = self.query_one(f"#{TRANSCRIPT_ID}", Static)
            except Exception:
                return
            messages.update(_format_transcript(self._transcript_lines))
            if self._transcript_lines:
                messages.add_class("-has-turns")
            else:
                messages.remove_class("-has-turns")
            transcript_scroll = self.query_one(f"#{TRANSCRIPT_SCROLL_ID}")
            if self._transcript_lines:
                transcript_scroll.add_class("-has-turns")
            else:
                transcript_scroll.remove_class("-has-turns")
            scroll_end = getattr(transcript_scroll, "scroll_end", None)
            if callable(scroll_end):
                scroll_end(animate=False)

        def _transcript_overflows_viewport(self) -> bool:
            """Return True when transcript lines likely exceed visible viewport."""
            if not self._transcript_lines:
                return False

            try:
                transcript_scroll = self.query_one(f"#{TRANSCRIPT_SCROLL_ID}")
                region_height = int(getattr(transcript_scroll.region, "height", 0) or 0)
                virtual_height = int(getattr(getattr(transcript_scroll, "virtual_size", None), "height", 0) or 0)
                if region_height <= 2 or virtual_height <= 0:
                    return len(self._transcript_lines) > 12
                return virtual_height > region_height
            except Exception:
                return len(self._transcript_lines) > 12

        def _refresh_chrome_visibility(self) -> None:
            """Show tip/keybar only when contextually useful."""
            has_turns = bool(self._transcript_lines)
            tip = self.query_one("#tip", Static)
            if has_turns:
                tip.add_class("-hidden")
            else:
                tip.remove_class("-hidden")

            keybar_row = self.query_one(f"#{KEYBAR_ROW_ID}", Container)
            keybar_right = self.query_one(f"#{KEYBAR_RIGHT_ID}", Static)
            overflow = self._transcript_overflows_viewport()
            keybar_row.remove_class("-hidden")

            if overflow:
                keybar_right.update("[#c4cede]pgup/pgdn scroll[/]")
            else:
                keybar_right.update("")

        def _append_command_entry(self, command_text: str) -> None:
            """Append a command line with spacing separation from prior entries."""
            if self._transcript_lines and str(self._transcript_lines[-1]).strip():
                self._append_transcript_line("")
            self._append_transcript_line(f"Cmd: {command_text}")

        def _append_user_entry(self, message_text: str) -> None:
            """Append a user message line with spacing separation from prior entries."""
            if self._transcript_lines and str(self._transcript_lines[-1]).strip():
                self._append_transcript_line("")
            self._append_transcript_line(f"You: {message_text}")

        def _finalize_inline_status(self) -> None:
            """Restore workspace controls after inline /status completes."""
            loading = self.query_one(f"#{COMMAND_LOADING_ID}", Static)
            stop = getattr(loading, "stop", None)
            if callable(stop):
                stop()
            loading.remove_class("-active")
            loading.add_class("-hidden")

            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.value = ""
            composer.disabled = False
            composer.focus()

            self._inline_status_running = False
            self._refresh_chrome_visibility()

        def on_input_submitted(self, event: Input.Submitted) -> None:
            """Submit workspace composer when Enter is pressed inside the input."""
            if event.input.id != COMPOSER_ID:
                return
            event.stop()
            self.action_submit_composer()

        def action_noop(self) -> None:
            """No-op action used to shadow disabled shortcuts."""

        def action_command_palette(self) -> None:
            """Disable Textual built-in command palette in this shell."""

        def action_transcript_hint(self) -> None:
            """Show transcript shortcut hint in the chat help area."""
            tip = self.query_one("#tip", Static)
            tip.update("Use Ctrl+T in prompt mode to open transcript viewer.")
            tip.remove_class("-hidden")


def run_agent_workspace_shell(
    *,
    details: AgentWorkspaceDetails,
    transcript_lines: list[str] | None,
    composer_placeholder: str,
    status_summary_provider: StatusSummaryProvider | None = None,
    transcript_sink: TranscriptSink | None = None,
    message_run_provider: MessageRunProvider | None = None,
) -> AgentWorkspaceEvent | None:
    """Run workspace shell and return selected event.

    Returns None when Textual support is unavailable.
    """
    if not TEXTUAL_SUPPORTED:  # pragma: no cover - optional dependency
        return None

    app = AgentWorkspaceShellApp(
        details=details,
        transcript_lines=transcript_lines,
        composer_placeholder=composer_placeholder,
        status_summary_provider=status_summary_provider,
        transcript_sink=transcript_sink,
        message_run_provider=message_run_provider,
    )
    return app.run()
