"""Overlay layer foundation for true floating z-layers in TUI.

This module provides the overlay layer infrastructure for Textual-based TUI
components. It enables true floating z-layers that render above existing
workspace content without reflow, with proper focus management.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
from collections.abc import Callable

from textual import events
from textual.app import ComposeResult
from textual.containers import Container
from textual.reactive import reactive
from textual.widget import Widget
from textual.widgets import Static


class OverlayLayer(IntEnum):
    """Z-index layers for overlay stacking.

    Higher values render on top of lower values.
    """

    BASE = 0
    MODAL = 100
    DROPDOWN = 200
    TOOLTIP = 300
    NOTIFICATION = 400


@dataclass
class OverlayState:
    """State for a single overlay instance.

    Attributes:
        widget: The overlay widget being displayed.
        layer: The z-index layer for stacking order.
        trap_focus: Whether to trap keyboard focus within the overlay.
        close_on_escape: Whether to close when Escape is pressed.
        on_close: Optional callback when overlay closes.
    """

    widget: Widget
    layer: OverlayLayer = OverlayLayer.MODAL
    trap_focus: bool = True
    close_on_escape: bool = True
    on_close: Callable[[], None] | None = None


class OverlayHost(Container):
    """Container that hosts overlays without reflowing underlying content.

    This container maintains a base content area and an overlay layer that
    renders above it. Opening/closing overlays does not reflow the base
    content, preserving scroll positions and layout stability.

    Example:
        ```python
        host = OverlayHost()
        host.mount_base(my_main_content)

        # Open overlay - base content stays stable
        host.open_overlay(my_palette, layer=OverlayLayer.MODAL)
        ```
    """

    overlays: reactive[list[OverlayState]] = reactive(list)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._base_content: Widget | None = None
        self._overlay_container = Container(classes="overlay-layer")

    def compose(self) -> ComposeResult:
        """Compose the overlay host structure."""
        # Base content container
        self._base = Container(id="overlay-base")
        yield self._base

        # Overlay layer container (always on top)
        yield self._overlay_container

    def mount_base(self, widget: Widget) -> None:
        """Mount the base content widget.

        Args:
            widget: The main content widget to display.
        """
        self._base_content = widget
        self._base.mount(widget)

    def open_overlay(
        self,
        widget: Widget,
        *,
        layer: OverlayLayer = OverlayLayer.MODAL,
        trap_focus: bool = True,
        close_on_escape: bool = True,
        on_close: Callable[[], None] | None = None,
    ) -> None:
        """Open a widget as an overlay.

        The overlay renders above all base content without causing reflow.
        Multiple overlays can stack with proper z-index ordering.

        Args:
            widget: The widget to display as overlay.
            layer: Z-index layer for stacking order.
            trap_focus: Whether to trap keyboard focus.
            close_on_escape: Whether Escape closes this overlay.
            on_close: Callback invoked when overlay closes.
        """
        state = OverlayState(
            widget=widget,
            layer=layer,
            trap_focus=trap_focus,
            close_on_escape=close_on_escape,
            on_close=on_close,
        )

        # Sort by layer to maintain z-order
        self.overlays.append(state)
        self.overlays.sort(key=lambda s: s.layer)

        # Mount with layer-based CSS class
        widget.add_class(f"overlay-layer-{layer.name.lower()}")
        self._overlay_container.mount(widget)

        if trap_focus:
            widget.focus()

    def close_top_overlay(self) -> bool:
        """Close the top-most overlay.

        Returns:
            True if an overlay was closed, False if no overlays open.
        """
        if not self.overlays:
            return False

        # Remove top-most (highest layer, last in sorted list)
        state = self.overlays.pop()

        if state.on_close:
            state.on_close()

        state.widget.remove()

        # Restore focus to previous overlay or base content
        if self.overlays:
            if self.overlays[-1].trap_focus:
                self.overlays[-1].widget.focus()
        elif self._base_content:
            self._base_content.focus()

        return True

    def close_all_overlays(self) -> None:
        """Close all open overlays."""
        while self.overlays:
            self.close_top_overlay()

    def has_overlays(self) -> bool:
        """Check if any overlays are currently open.

        Returns:
            True if at least one overlay is open.
        """
        return len(self.overlays) > 0

    def on_key(self, event: events.Key) -> None:
        """Handle keyboard events for overlay management.

        Args:
            event: The key event.
        """
        if event.key == "escape" and self.overlays:
            # Only close top-most overlay if it's escapable
            top = self.overlays[-1]
            if top.close_on_escape:
                self.close_top_overlay()
                event.stop()


class OverlayModal(Static):
    """Base class for modal overlay content.

    Provides common modal styling and behavior:
    - Centered positioning
    - Dimmed backdrop
    - Escape-to-close support

    Override `compose_content()` to define the modal's content.
    """

    DEFAULT_CSS = """
    OverlayModal {
        width: auto;
        height: auto;
        max-width: 80%;
        max-height: 80%;
        background: $surface;
        border: solid $primary;
        padding: 1 2;
    }
    """

    def __init__(self, title: str = "", *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.title = title

    def compose(self):
        """Compose the modal structure."""
        if self.title:
            yield Static(self.title, classes="modal-title")
        yield from self.compose_content()

    def compose_content(self):
        """Override to provide modal content widgets.

        Yields:
            Widgets to display inside the modal.
        """
        yield from ()


class OverlayDropdown(Container):
    """Base class for dropdown-style overlays.

    Provides dropdown positioning relative to an anchor widget.
    """

    DEFAULT_CSS = """
    OverlayDropdown {
        width: auto;
        height: auto;
        max-height: 50%;
        background: $surface;
        border: solid $primary;
    }
    """

    def __init__(self, anchor_widget: Widget | None = None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._anchor_widget = anchor_widget
