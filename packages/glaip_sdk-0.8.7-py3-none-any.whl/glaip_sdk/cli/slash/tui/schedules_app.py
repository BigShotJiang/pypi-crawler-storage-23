# pyright: reportGeneralTypeIssues=false
"""Textual UI for the /schedules command.

Provides a Harlequin-style schedule browser scoped to the active agent, with
CRUD actions, run history modal, and Rich fallback for non-TTY environments.
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any, cast

from glaip_sdk.cli.slash.tui.background_tasks import BackgroundTaskMixin
from glaip_sdk.cli.slash.tui.clipboard import ClipboardAdapter
from glaip_sdk.cli.slash.tui.context import TUIContext
from glaip_sdk.cli.slash.tui.keybind_registry import KeybindRegistry
from glaip_sdk.cli.slash.tui.keybind_shortcuts import close_shortcuts
from glaip_sdk.cli.slash.tui.layouts.harlequin import HarlequinScreen
from glaip_sdk.cli.slash.tui.loading import hide_loading_indicator, show_loading_indicator
from glaip_sdk.cli.slash.tui.terminal import TerminalCapabilities
from glaip_sdk.cli.slash.tui.theme.catalog import _BUILTIN_THEMES
from glaip_sdk.models.schedule import ScheduleConfig, ScheduleRunResult

try:  # pragma: no cover - optional dependency
    from glaip_sdk.cli.slash.tui.toast import ClipboardToastMixin, Toast, ToastBus, ToastHandlerMixin
except Exception:  # pragma: no cover - optional dependency missing
    ClipboardToastMixin = object  # type: ignore[assignment, misc]
    Toast = None  # type: ignore[assignment]
    ToastBus = None  # type: ignore[assignment]
    ToastHandlerMixin = object  # type: ignore[assignment, misc]

if TYPE_CHECKING:  # pragma: no cover - type checking only
    from textual.app import App, ComposeResult
    from textual.binding import Binding
    from textual.containers import Container, Horizontal, Vertical
    from textual.theme import Theme
    from textual.widgets import Button, DataTable, Footer, Input, LoadingIndicator, Static
else:
    try:  # pragma: no cover - optional dependency
        from textual.app import App, ComposeResult
        from textual.binding import Binding
        from textual.containers import Container, Horizontal, Vertical
        from textual.widgets import Button, DataTable, Footer, Input, LoadingIndicator, Static

        try:  # pragma: no cover - optional dependency
            from textual.theme import Theme
        except Exception:  # pragma: no cover - optional dependency
            Theme = None  # type: ignore[assignment]
    except Exception:  # pragma: no cover - optional dependency
        App = None  # type: ignore[assignment]
        ComposeResult = None  # type: ignore[assignment]
        Binding = None  # type: ignore[assignment]
        Container = None  # type: ignore[assignment]
        Horizontal = None  # type: ignore[assignment]
        Vertical = None  # type: ignore[assignment]
        Button = None  # type: ignore[assignment]
        DataTable = None  # type: ignore[assignment]
        Footer = None  # type: ignore[assignment]
        Input = None  # type: ignore[assignment]
        LoadingIndicator = None  # type: ignore[assignment]
        Static = None  # type: ignore[assignment]
        Theme = None  # type: ignore[assignment]

from glaip_sdk.cli.slash.tui.confirm_delete_schedule import ConfirmDeleteScheduleModal
from glaip_sdk.cli.slash.tui.remote_runs_app import (
    RemoteRunsTUICallbacks,
    RunsHarlequinScreen,
)
from glaip_sdk.cli.slash.tui.schedule_form import (
    ScheduleFormModal,
    ScheduleFormResult,
    schedule_config_to_human_readable,
)

logger = logging.getLogger(__name__)

TEXTUAL_SUPPORTED = (
    App is not None
    and DataTable is not None
    and Static is not None
    and Input is not None
    and Button is not None
    and Footer is not None
)

DataTableType = cast(Any, DataTable)
InputType = cast(Any, Input)
StaticType = cast(Any, Static)

if TEXTUAL_SUPPORTED:
    _AppBase = App  # type: ignore[assignment]
else:
    _AppBase = object  # pragma: no cover

SCHEDULES_TABLE_ID = "#schedules-table"
FILTER_INPUT_ID = "#schedules-filter"
STATUS_ID = "#status"
SCHEDULES_LOADING_ID = "#schedules-loading"

DETAIL_ID = "#schedule-detail"
DETAIL_CRON_ID = "#schedule-detail-cron"
DETAIL_NEXT_ID = "#schedule-detail-next"
DETAIL_INPUT_ID = "#schedule-detail-input"

CSS_FILE_NAME = "schedules.tcss"
SCHEDULES_HINT_TEXT = "Keys: n New | e Edit | d Delete | r Runs | / Filter | q/Esc Close"
LOADING_SCHEDULES_MESSAGE = "Loading schedules..."

KEYBIND_SCOPE = "schedules"
KEYBIND_CATEGORY = "Schedules"


@dataclass(frozen=True)
class KeybindDef:
    """Definition for a keyboard shortcut."""

    action: str
    key: str
    description: str


KEYBIND_DEFINITIONS: tuple[KeybindDef, ...] = (
    KeybindDef("switch_row", "enter", "Select"),
    KeybindDef("focus_filter", "/", "Filter"),
    KeybindDef("new_schedule", "n", "New"),
    KeybindDef("edit_schedule", "e", "Edit"),
    KeybindDef("delete_schedule", "d", "Delete"),
    KeybindDef("view_runs", "r", "Runs"),
    KeybindDef("page_left", "left", "Prev Page"),
    KeybindDef("page_right", "right", "Next Page"),
    KeybindDef("page_left", "[", "Prev Page"),
    KeybindDef("page_right", "]", "Next Page"),
    KeybindDef("clear_or_exit", "escape", "Close"),
    KeybindDef("app_exit", "q", "Close"),
)


def _build_schedules_bindings(*, primary_visible: bool) -> list[Any]:
    """Build schedules key bindings for Harlequin and app shells."""
    if not Binding:
        return []

    return [
        Binding("enter", "switch_row", "Select", show=primary_visible),
        Binding("/", "focus_filter", "Filter", show=primary_visible),
        Binding("n", "new_schedule", "New", show=primary_visible),
        Binding("e", "edit_schedule", "Edit", show=primary_visible),
        Binding("d", "delete_schedule", "Delete", show=primary_visible),
        Binding("r", "view_runs", "Runs", show=primary_visible),
        Binding("left", "page_left", "Prev", show=False, priority=True),
        Binding("right", "page_right", "Next", show=False, priority=True),
        Binding("[", "page_left", "Prev", show=False, priority=True),
        Binding("]", "page_right", "Next", show=False, priority=True),
        *close_shortcuts(escape_action="clear_or_exit", quit_action="app_exit"),
    ]


@dataclass
class SchedulesTUICallbacks:
    """Callbacks for schedule operations."""

    fetch_page: Callable[[int, int], Any | None]
    fetch_detail: Callable[[str], Any | None]
    create_schedule: Callable[[str, Any], Any | None]
    update_schedule: Callable[[str, str | None, Any | None], Any | None]
    delete_schedule: Callable[[str], bool]
    list_runs: Callable[[str, int, int], Any | None]
    fetch_run_detail: Callable[[str], ScheduleRunResult | None] | None = None


@dataclass
class ScheduleRow:
    """Represents a single row in the schedules table."""

    schedule: Any
    label: str
    list_when: str
    cron: str
    has_failure: bool = False


class _ScheduleRunsHarlequinScreen(RunsHarlequinScreen):
    """RunsHarlequinScreen that returns to schedules on quit."""

    def __init__(
        self,
        initial_page: Any,
        cursor_idx: int,
        callbacks: RemoteRunsTUICallbacks,
        *,
        agent_name: str | None = None,
        agent_id: str | None = None,
        ctx: TUIContext | None = None,
        title: str | None = None,
    ) -> None:
        super().__init__(
            initial_page,
            cursor_idx,
            callbacks,
            agent_name=agent_name,
            agent_id=agent_id,
            ctx=ctx,
        )
        self._schedule_runs_title = title
        self._parent_app: Any | None = None

    def on_mount(self) -> None:  # type: ignore[override]
        # Defensive: avoid double-mounting widgets if Mount is delivered twice.
        if getattr(self, "_schedule_runs_did_mount", False):
            return
        self._schedule_runs_did_mount = True

        super().on_mount()

        self._update_schedule_runs_title()

    def _render_page(self) -> None:  # type: ignore[override]
        """Keep schedule scope visible after page/filter updates."""
        super()._render_page()
        self._update_schedule_runs_title()

    def _update_schedule_runs_title(self) -> None:
        """Render a persistent title that keeps schedule filter context visible."""
        if not self._schedule_runs_title or not hasattr(self, "_page_title"):
            return
        try:
            current_page = getattr(self, "current_page", None)
            total = int(getattr(current_page, "total", 0) or 0)
            limit = int(getattr(current_page, "limit", 20) or 20)
            page = int(getattr(current_page, "page", 1) or 1)
            total_pages = max(1, (total + limit - 1) // limit)
            filter_text = str(getattr(self, "_filter_text", "") or "")
            filter_suffix = f" | Filter: '{filter_text}'" if filter_text else ""
            page_title = f"{self._schedule_runs_title} (Page {page}/{total_pages} | Page size={limit}{filter_suffix})"
            self._page_title.update(page_title)
        except Exception:
            pass

    def action_app_exit(self) -> None:  # type: ignore[override]
        """Return to schedules instead of exiting the entire app."""
        app = None
        try:
            app = cast(Any, self).app
        except Exception:
            pass
        if app is None:
            app = self._parent_app
        if app is not None:
            try:
                app.pop_screen()
                return
            except Exception:
                pass
        super().action_app_exit()


def run_schedules_textual(
    initial_page: Any,
    cursor_idx: int,
    callbacks: SchedulesTUICallbacks,
    *,
    agent_name: str | None = None,
    agent_id: str | None = None,
    ctx: TUIContext | None = None,
    open_create: bool = False,
    bootstrap_load: bool = False,
) -> tuple[int, int, int]:
    """Run the Textual TUI for schedules.

    Args:
        initial_page: The initial page of schedule results.
        cursor_idx: The initial cursor index.
        callbacks: Callbacks for data operations.
        agent_name: Name of the agent.
        agent_id: ID of the agent.
        ctx: Shared TUI context.
        open_create: Whether to open the create modal immediately.
        bootstrap_load: When True, fetch the first page after screen mount.

    Returns:
        Tuple of (page, limit, cursor_index) state.
    """
    if not TEXTUAL_SUPPORTED:
        return 1, 1, 0
    app = SchedulesTextualApp(
        initial_page,
        cursor_idx,
        callbacks,
        agent_name=agent_name,
        agent_id=agent_id,
        ctx=ctx,
        open_create=open_create,
        bootstrap_load=bootstrap_load,
    )
    app.run()
    current_page = getattr(app, "current_page", initial_page)
    page = getattr(current_page, "page", 1) or 1
    limit = getattr(current_page, "limit", 20) or 20
    return page, limit, app.cursor_index


class SchedulesHarlequinScreen(ToastHandlerMixin, ClipboardToastMixin, BackgroundTaskMixin, HarlequinScreen):  # type: ignore[misc]
    """Harlequin layout screen for schedule management."""

    CSS_PATH = CSS_FILE_NAME

    # HarlequinScreen base class sets a 25/75 split via `#left-pane` / `#right-pane`.
    # Define a subclass CSS override (mirrors RunsHarlequinScreen approach) so the
    # left pane width isn't "locked" at 25%.
    CSS = """
    #left-pane {
        width: 40%;
        min-width: 38;
    }

    #right-pane {
        width: 60%;
    }
    """

    BINDINGS = _build_schedules_bindings(primary_visible=True)

    def __init__(
        self,
        schedules_page: Any,
        cursor_idx: int,
        callbacks: SchedulesTUICallbacks,
        *,
        agent_name: str | None = None,
        agent_id: str | None = None,
        ctx: TUIContext | None = None,
        open_create: bool = False,
        bootstrap_load: bool = False,
    ) -> None:
        """Initialize the Harlequin screen.

        Args:
            schedules_page: Initial page of data.
            cursor_idx: Initial cursor position.
            callbacks: Data operation callbacks.
            agent_name: Name of the agent.
            agent_id: ID of the agent.
            ctx: Shared TUI context.
            open_create: Whether to open the create modal.
            bootstrap_load: Whether to fetch first page immediately after mount.
        """
        super().__init__(ctx=ctx)
        self._data_callbacks = callbacks
        self._agent_name = agent_name
        self._agent_id = agent_id
        self._current_page = schedules_page
        self.cursor_index = cursor_idx
        self._rows: list[Any] = []
        self._filter_text = ""
        self._selected_schedule: Any | None = None
        self._schedule_detail_cache: dict[str, dict[str, Any]] = {}  # Cache for schedule details
        self._toast_bus: Any | None = None
        self._clipboard: Any | None = None
        self._keybinds: Any | None = None
        self._open_create = open_create
        self._bootstrap_load = bootstrap_load
        self._initialize_context_services()

    def _initialize_context_services(self) -> None:
        """Initialize context-dependent services (keybinds, toasts, clipboard)."""

        def _notify(message: Any) -> None:
            self.post_message(message)

        ctx = self.ctx if hasattr(self, "ctx") else getattr(self, "_ctx", None)
        if ctx:
            if ctx.keybinds is None:
                ctx.keybinds = KeybindRegistry()
            if ctx.toasts is None and ToastBus is not None:
                ctx.toasts = ToastBus(on_change=_notify)
            if ctx.clipboard is None:
                ctx.clipboard = ClipboardAdapter(terminal=ctx.terminal)
            self._keybinds = ctx.keybinds
            self._toast_bus = ctx.toasts
            self._clipboard = ctx.clipboard
        else:
            terminal = TerminalCapabilities(
                tty=True, ansi=True, osc52=False, osc11_bg=None, mouse=False, truecolor=False
            )
            self._clipboard = ClipboardAdapter(terminal=terminal)
            if ToastBus is not None:
                self._toast_bus = ToastBus(on_change=_notify)

    def _apply_theme(self) -> None:
        """Apply theme from context."""
        ctx = self.ctx if hasattr(self, "ctx") else getattr(self, "_ctx", None)
        if not ctx or not ctx.theme or Theme is None:
            return
        app = self.app
        if app is None:
            return
        for name, tokens in _BUILTIN_THEMES.items():
            app.register_theme(
                Theme(
                    name=name,
                    primary=tokens.primary,
                    secondary=tokens.secondary,
                    accent=tokens.accent,
                    warning=tokens.warning,
                    error=tokens.error,
                    success=tokens.success,
                )
            )
        app.theme = ctx.theme.theme_name

    def _prepare_toasts(self) -> None:
        """Clear existing toasts."""
        if self._toast_bus:
            self._toast_bus.clear()

    def _register_keybinds(self) -> None:
        """Register screen-specific keybinds."""
        if not self._keybinds:
            return
        for keybind_def in KEYBIND_DEFINITIONS:
            scoped_action = f"{KEYBIND_SCOPE}.{keybind_def.action}"
            if self._keybinds.get(scoped_action):
                continue
            try:
                self._keybinds.register(
                    action=scoped_action,
                    key=keybind_def.key,
                    description=keybind_def.description,
                    category=KEYBIND_CATEGORY,
                )
            except ValueError as exc:
                logger.debug("Skipping duplicate keybind registration: %s", scoped_action, exc_info=exc)

    def compose(self) -> ComposeResult:  # type: ignore[override]
        """Compose the Harlequin screen UI."""
        if not TEXTUAL_SUPPORTED:
            return  # type: ignore[return-value]
        horizontal = cast(Any, Horizontal)
        vertical = cast(Any, Vertical)
        container = cast(Any, Container)
        static_widget = cast(Any, Static)
        input_widget = cast(Any, Input)
        table_widget = cast(Any, DataTable)
        button_widget = cast(Any, Button)
        loading_widget = cast(Any, LoadingIndicator)

        with horizontal(id="harlequin-container"):
            with vertical(id="left-pane"):
                yield static_widget("Scheduled Tasks", id="left-pane-title")
                agent_label = self._agent_name or self._agent_id or "Active agent"
                yield static_widget(f"Agent: {agent_label}", id="left-pane-meta")
                yield input_widget(placeholder="Filter...", id=FILTER_INPUT_ID.lstrip("#"))
                yield table_widget(id=SCHEDULES_TABLE_ID.lstrip("#"))

                # Left Pane Footer (New + Help)
                with vertical(id="left-footer"):
                    yield button_widget("New Task (n)", id="action-new", variant="success")
                    yield static_widget(
                        "↑↓ Navigate | ←/→ or bracket keys Page | q/Esc Close",
                        id="help-text",
                    )

            with vertical(id="right-pane"):
                yield static_widget("Task Details", id="right-pane-title")
                yield static_widget("Select a task to inspect details", id="right-pane-meta")

                # Scrollable Content Area
                with vertical(id="detail-scroll-area"):
                    # Input Box (Prominent)
                    yield static_widget("Instruction:", id="detail-input-label")
                    yield static_widget("", id=DETAIL_INPUT_ID.lstrip("#"))

                    # Meta Data Grid
                    with container(id="detail-meta-grid"):
                        yield static_widget("Schedule:", classes="meta-label")
                        yield static_widget("", id=DETAIL_CRON_ID.lstrip("#"), classes="meta-value")

                        yield static_widget("Next Run:", classes="meta-label")
                        yield static_widget("", id=DETAIL_NEXT_ID.lstrip("#"), classes="meta-value")

                        yield static_widget("ID:", classes="meta-label")
                        yield static_widget("", id=DETAIL_ID.lstrip("#"), classes="meta-value")

                # Docked Footer
                with vertical(id="detail-footer"):
                    with horizontal(id="schedule-actions"):
                        yield button_widget("Edit (e)", id="action-edit", variant="primary")
                        yield button_widget("Runs (r)", id="action-runs", variant="warning")
                        yield button_widget("Delete (d)", id="action-delete", variant="error")
        yield horizontal(
            loading_widget(id=SCHEDULES_LOADING_ID.lstrip("#")),
            static_widget("", id=STATUS_ID.lstrip("#")),
            id="status-bar",
        )
        if Toast is not None:
            yield container(Toast(), id="toast-container")

    def on_mount(self) -> None:
        """Initialize screen state on mount."""
        if not TEXTUAL_SUPPORTED:
            return
        self._apply_theme()
        self._prepare_toasts()
        self._register_keybinds()
        table = self.query_one(SCHEDULES_TABLE_ID, DataTableType)
        table.add_column("Task", width=48, key="task")
        table.add_column("Next Run (UTC)", width=16, key="updated")
        table.cursor_type = "row"
        table.zebra_stripes = True
        if self._bootstrap_load:
            self._render_bootstrap_state()
            target_page = max(1, int(getattr(self._current_page, "page", 1) or 1))
            self._queue_page_load(target_page)
        else:
            self._render_page(self._current_page)
            self._update_detail_pane()
        table.focus()
        if self._open_create:
            self.action_new_schedule()

    def _render_bootstrap_state(self) -> None:
        """Render a visible loading state before first schedule page fetch resolves."""
        table = self.query_one(SCHEDULES_TABLE_ID, DataTableType)
        table.clear()
        table.add_row(LOADING_SCHEDULES_MESSAGE, "Please wait")
        self._selected_schedule = None
        self._set_detail_text("", LOADING_SCHEDULES_MESSAGE, "", "")
        self._set_status(LOADING_SCHEDULES_MESSAGE)

    def _render_page(self, schedules_page: Any) -> None:
        """Render the schedules page."""
        if not TEXTUAL_SUPPORTED:
            return
        table = self.query_one(SCHEDULES_TABLE_ID, DataTableType)
        table.clear()
        self._rows = _build_rows(schedules_page.items)
        visible_rows = self._visible_rows()
        for row in visible_rows:
            table.add_row(row.label, row.list_when)
        if visible_rows:
            self.cursor_index = max(0, min(self.cursor_index, len(visible_rows) - 1))
            table.cursor_coordinate = (self.cursor_index, 0)
            self._selected_schedule = visible_rows[self.cursor_index].schedule
        self._current_page = schedules_page
        if self.app is not None:
            self.app.current_page = schedules_page
            self.app.cursor_index = self.cursor_index
        self._set_status("")

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:  # type: ignore[override]
        """Handle row selection."""
        if not TEXTUAL_SUPPORTED:
            return
        table = self.query_one(SCHEDULES_TABLE_ID, DataTableType)
        try:
            table.cursor_coordinate = (event.cursor_row, 0)
        except Exception:
            return
        visible_rows = self._visible_rows()
        if event.cursor_row < 0 or event.cursor_row >= len(visible_rows):
            return
        self.cursor_index = event.cursor_row
        self._selected_schedule = visible_rows[event.cursor_row].schedule
        if self.app is not None:
            self.app.cursor_index = self.cursor_index
        self._update_detail_pane()

    def on_data_table_cell_selected(self, event: DataTable.CellSelected) -> None:  # type: ignore[override]
        """Handle cell click selection."""
        if not TEXTUAL_SUPPORTED:
            return
        table = self.query_one(SCHEDULES_TABLE_ID, DataTableType)
        try:
            table.cursor_coordinate = (event.coordinate.row, 0)
        except Exception:
            return
        visible_rows = self._visible_rows()
        row_index = event.coordinate.row
        if row_index < 0 or row_index >= len(visible_rows):
            return
        self.cursor_index = row_index
        self._selected_schedule = visible_rows[row_index].schedule
        if self.app is not None:
            self.app.cursor_index = self.cursor_index
        self._update_detail_pane()

    def on_data_table_row_highlighted(self, event: Any) -> None:  # type: ignore[override]
        """Update detail pane when cursor moves (keyboard navigation)."""
        if not TEXTUAL_SUPPORTED:
            return
        # Verify this event is for our table
        try:
            if getattr(event, "data_table", None) is None:
                return
            if event.data_table.id != SCHEDULES_TABLE_ID.lstrip("#"):
                return
        except Exception:
            return
        cursor_row = getattr(event, "cursor_row", None)
        if cursor_row is None:
            return
        visible_rows = self._visible_rows()
        if cursor_row < 0 or cursor_row >= len(visible_rows):
            return
        self.cursor_index = cursor_row
        self._selected_schedule = visible_rows[cursor_row].schedule
        if self.app is not None:
            self.app.cursor_index = self.cursor_index
        self._update_detail_pane()

    def on_data_table_cursor_row_changed(self, event: Any) -> None:  # type: ignore[override]
        """Handle row selection changes."""
        if not TEXTUAL_SUPPORTED:
            return
        cursor_row = getattr(event, "cursor_row", None)
        if cursor_row is None:
            return
        visible_rows = self._visible_rows()
        if cursor_row >= len(visible_rows):
            return
        self.cursor_index = cursor_row
        self._selected_schedule = visible_rows[cursor_row].schedule
        if self.app is not None:
            self.app.cursor_index = self.cursor_index
        self._update_detail_pane()

    def on_input_changed(self, event: Input.Changed) -> None:
        """Handle filter input changes."""
        if not TEXTUAL_SUPPORTED:
            return
        if event.input.id == FILTER_INPUT_ID.lstrip("#"):
            self._filter_text = (event.value or "").strip()
            self._reload_list()

    def on_key(self, event: Any) -> None:
        """Keep left/right as page navigation when filter is not focused."""
        if not TEXTUAL_SUPPORTED:
            return

        key = getattr(event, "key", "")
        if key not in {"left", "right"}:
            return

        filter_input = self.query_one(FILTER_INPUT_ID, InputType)
        if getattr(filter_input, "has_focus", False):
            return

        if key == "left":
            self.action_page_left()
        else:
            self.action_page_right()

        stop = getattr(event, "stop", None)
        if callable(stop):
            stop()

    def action_focus_filter(self) -> None:
        """Focus the filter input."""
        if not TEXTUAL_SUPPORTED:
            return
        filter_input = self.query_one(FILTER_INPUT_ID, InputType)
        filter_input.value = self._filter_text
        filter_input.focus()

    def action_switch_row(self) -> None:
        """Handle row selection (Enter key)."""
        self._update_detail_pane()

    def action_page_left(self) -> None:
        """Go to the previous page."""
        if not self._current_page or not getattr(self._current_page, "has_prev", False):
            self._set_status("Already at the first page.")
            return
        self._queue_page_load(self._current_page.page - 1)

    def action_page_right(self) -> None:
        """Go to the next page."""
        if not self._current_page or not getattr(self._current_page, "has_next", False):
            self._set_status("This is the last page.")
            return
        self._queue_page_load(self._current_page.page + 1)

    def action_new_schedule(self) -> None:
        """Open the create schedule modal."""
        modal = ScheduleFormModal(
            mode="create",
            agent_name=self._agent_name,
            agent_id=self._agent_id,
            existing=None,
        )
        self.app.push_screen(modal, self._on_form_result)

    def action_edit_schedule(self) -> None:
        """Open the edit schedule modal."""
        schedule = self._selected_or_first()
        if not schedule:
            self._set_status("Select a schedule to edit.")
            return
        modal = ScheduleFormModal(
            mode="edit",
            agent_name=self._agent_name,
            agent_id=self._agent_id,
            existing=schedule,
        )
        self.app.push_screen(modal, self._on_form_result)

    def action_delete_schedule(self) -> None:
        """Open the delete confirmation modal."""
        schedule = self._selected_or_first()
        if not schedule:
            self._set_status("Select a schedule to delete.")
            return
        self.app.push_screen(
            ConfirmDeleteScheduleModal(schedule, agent_label=self._agent_name or self._agent_id),
            self._on_delete_result,
        )

    def action_view_runs(self) -> None:
        """Open schedule runs using the /runs Harlequin UI."""
        schedule = self._selected_or_first()
        if not schedule:
            self._set_status("Select a schedule to view runs.")
            return

        schedule_id = str(schedule.id)

        def fetch_page(page: int, limit: int) -> Any | None:
            result = self._data_callbacks.list_runs(schedule_id, limit, page)
            if result is None:
                return None
            return ScheduleRunsPageAdapter(result)

        def fetch_detail(run_id: str) -> Any | None:
            fn = getattr(self._data_callbacks, "fetch_run_detail", None)
            if callable(fn):
                detail = fn(run_id)
                if detail:
                    return ScheduleRunDetailAdapter(detail)
            return None

        def export_run(_run_id: str, _detail: Any | None) -> bool:
            # Schedule runs export isn't implemented; keep the button harmless.
            return False

        callbacks = RemoteRunsTUICallbacks(fetch_page=fetch_page, fetch_detail=fetch_detail, export_run=export_run)

        initial = fetch_page(1, 20)
        if initial is None:
            self._set_status("Unable to load schedule runs.")
            return

        screen = _ScheduleRunsHarlequinScreen(
            initial,
            0,
            callbacks,
            agent_name=self._agent_name,
            agent_id=self._agent_id,
            ctx=self._ctx,
            title=f"Run History (Filtered by Schedule: {schedule_id})",
        )
        screen._parent_app = self.app
        self.app.push_screen(screen)

    def action_clear_or_exit(self) -> None:
        """Clear filter or exit the screen."""
        if self._filter_text:
            self._filter_text = ""
            self._reload_list()
            return
        self.app.exit()

    def action_app_exit(self) -> None:
        """Exit the application."""
        self.app.exit()

    def on_button_pressed(self, event: Button.Pressed) -> None:  # type: ignore[override]
        """Handle button clicks."""
        btn_id = event.button.id or ""
        if btn_id == "action-new":
            self.action_new_schedule()
        elif btn_id == "action-edit":
            self.action_edit_schedule()
        elif btn_id == "action-delete":
            self.action_delete_schedule()
        elif btn_id == "action-runs":
            self.action_view_runs()

    def _queue_page_load(self, target_page: int) -> None:
        if not TEXTUAL_SUPPORTED:
            return
        current_limit = getattr(self._current_page, "limit", 20) or 20
        show_loading_indicator(
            self,
            SCHEDULES_LOADING_ID,
            message=LOADING_SCHEDULES_MESSAGE,
            set_status=self._set_status,
        )

        def _load() -> None:
            page = self._data_callbacks.fetch_page(target_page, current_limit)
            if page is None:
                self._set_status("Failed to load schedules.")
                hide_loading_indicator(self, SCHEDULES_LOADING_ID)
                return
            self.cursor_index = 0
            self._render_page(page)
            hide_loading_indicator(self, SCHEDULES_LOADING_ID)

        self.track_task(asyncio.to_thread(_load), logger=logger)

    def _reload_list(self) -> None:
        if not TEXTUAL_SUPPORTED:
            return
        filtered = self._visible_rows()
        table = self.query_one(SCHEDULES_TABLE_ID, DataTableType)
        table.clear()
        for row in filtered:
            table.add_row(row.label, row.list_when)
        if filtered:
            self.cursor_index = max(0, min(self.cursor_index, len(filtered) - 1))
            table.cursor_coordinate = (self.cursor_index, 0)
            self._selected_schedule = filtered[self.cursor_index].schedule
            if self.app is not None:
                self.app.cursor_index = self.cursor_index

    def _selected_or_first(self) -> Any | None:
        if self._selected_schedule:
            return self._selected_schedule
        visible_rows = self._visible_rows()
        if visible_rows:
            return visible_rows[0].schedule
        return None

    def _update_detail_pane(self) -> None:
        schedule = self._selected_or_first()
        if schedule is None:
            self._set_detail_text("", "", "", "")
            return
        # Label is still used for table but not for title detail anymore
        label = _schedule_label(schedule)
        cron = _schedule_cron(schedule)

        # Format human readable string
        config = getattr(schedule, "schedule_config", None)
        human_readable = ""
        if isinstance(config, ScheduleConfig):
            human_readable = schedule_config_to_human_readable(config)
        elif isinstance(config, dict):
            human_readable = schedule_config_to_human_readable(ScheduleConfig(**config))

        next_run = _format_next_run(schedule.time_until_next_run or schedule.next_run_time)
        input_text = schedule.input or "—"

        # Display human readable prominent, cron in parens or dim
        cron_display = f"{human_readable}\n[dim]{cron}[/dim]" if human_readable else cron
        self._set_detail_text(label, cron_display, next_run, input_text)

    def _set_detail_text(self, _title: str, cron: str, next_run: str, input_text: str) -> None:
        try:
            # Input Box
            self.query_one(DETAIL_INPUT_ID, StaticType).update(input_text)

            # Meta Grid
            self.query_one(DETAIL_CRON_ID, StaticType).update(cron)
            self.query_one(DETAIL_NEXT_ID, StaticType).update(next_run)
            self.query_one(DETAIL_ID, StaticType).update(getattr(self._selected_or_first(), "id", ""))

            # Runs removed from detail pane
        except Exception:
            pass

    def _visible_rows(self) -> list[ScheduleRow]:
        return _filter_rows(self._rows, self._filter_text)

    def _on_form_result(self, result: ScheduleFormResult | None) -> None:
        if result is None:
            return
        schedule_id = result.schedule_id
        if schedule_id:
            self._set_status("Saving schedule changes...")
            updated = self._data_callbacks.update_schedule(schedule_id, result.input_text, result.schedule_config)
            if updated is None:
                self._set_status("Failed to update schedule.")
                return
            if self._refresh_current_page():
                self._set_status("Schedule updated.")
        else:
            self._set_status("Creating schedule...")
            created = self._data_callbacks.create_schedule(result.input_text, result.schedule_config)
            if created is None:
                self._set_status("Failed to create schedule.")
                return
            if self._refresh_current_page():
                self._set_status("Schedule created.")

    def _on_delete_result(self, confirmed: bool | None) -> None:
        if not confirmed:
            return
        schedule = self._selected_or_first()
        if not schedule:
            return
        self._set_status("Deleting schedule...")
        if not self._data_callbacks.delete_schedule(str(schedule.id)):
            self._set_status("Failed to delete schedule.")
            return
        self._selected_schedule = None
        self.cursor_index = 0
        if self._refresh_current_page():
            self._set_status("Schedule deleted.")

    def _refresh_current_page(self) -> bool:
        current_page = getattr(self._current_page, "page", 1) or 1
        current_limit = getattr(self._current_page, "limit", 20) or 20
        page = self._data_callbacks.fetch_page(current_page, current_limit)
        if page is None:
            self._set_status("Failed to refresh schedules.")
            return False
        self._render_page(page)
        self._update_detail_pane()
        return True

    def _set_status(self, message: str) -> None:
        if not message:
            message = SCHEDULES_HINT_TEXT
        try:
            self.query_one(STATUS_ID, StaticType).update(message)
        except Exception:
            pass


class SchedulesTextualApp(ToastHandlerMixin, ClipboardToastMixin, BackgroundTaskMixin, _AppBase):  # type: ignore[misc]
    """Textual application wrapper for schedule management."""

    CSS_PATH = CSS_FILE_NAME
    BINDINGS = _build_schedules_bindings(primary_visible=False)

    def __init__(self, schedules_page: Any, cursor_idx: int, callbacks: SchedulesTUICallbacks, **options: Any) -> None:
        """Initialize the schedules app wrapper.

        Accepted options:
            agent_name, agent_id, ctx, open_create
        """
        agent_name = cast(str | None, options.pop("agent_name", None))
        agent_id = cast(str | None, options.pop("agent_id", None))
        ctx = cast(TUIContext | None, options.pop("ctx", None))
        open_create = bool(options.pop("open_create", False))
        bootstrap_load = bool(options.pop("bootstrap_load", False))
        if options:
            unexpected = ", ".join(sorted(options.keys()))
            raise TypeError(f"Unexpected schedules app option(s): {unexpected}")

        super().__init__()
        self._data_callbacks = callbacks
        self._agent_name = agent_name
        self._agent_id = agent_id
        self._ctx = ctx
        self._open_create = open_create
        self._bootstrap_load = bootstrap_load
        self.current_page = schedules_page
        self.cursor_index = cursor_idx

    def compose(self) -> ComposeResult:  # type: ignore[override]
        """Compose the app UI."""
        if not TEXTUAL_SUPPORTED or Footer is None:
            return  # type: ignore[return-value]
        yield Footer()

    def on_mount(self) -> None:
        """Push the Harlequin screen on mount."""
        screen = SchedulesHarlequinScreen(
            self.current_page,
            self.cursor_index,
            self._data_callbacks,
            agent_name=self._agent_name,
            agent_id=self._agent_id,
            ctx=self._ctx,
            open_create=self._open_create,
            bootstrap_load=self._bootstrap_load,
        )
        self.push_screen(screen)

    def _delegate_to_screen(self, action: str) -> None:
        screen = self.screen
        handler = getattr(screen, f"action_{action}", None)
        if callable(handler):
            handler()

    def action_switch_row(self) -> None:
        """Delegate switch row action."""
        self._delegate_to_screen("switch_row")

    def action_focus_filter(self) -> None:
        """Delegate focus filter action."""
        self._delegate_to_screen("focus_filter")

    def action_new_schedule(self) -> None:
        """Delegate new schedule action."""
        self._delegate_to_screen("new_schedule")

    def action_edit_schedule(self) -> None:
        """Delegate edit schedule action."""
        self._delegate_to_screen("edit_schedule")

    def action_delete_schedule(self) -> None:
        """Delegate delete schedule action."""
        self._delegate_to_screen("delete_schedule")

    def action_view_runs(self) -> None:
        """Delegate view runs action."""
        self._delegate_to_screen("view_runs")

    def action_page_left(self) -> None:
        """Delegate page left action."""
        self._delegate_to_screen("page_left")

    def action_page_right(self) -> None:
        """Delegate page right action."""
        self._delegate_to_screen("page_right")

    def action_clear_or_exit(self) -> None:
        """Delegate clear/exit action."""
        self._delegate_to_screen("clear_or_exit")

    def action_app_exit(self) -> None:
        """Delegate close behavior to the active screen."""
        try:
            screen = self.screen
        except Exception:
            screen = None
        handler = getattr(screen, "action_app_exit", None)
        if callable(handler):
            handler()
            return
        self.exit()


class ScheduleRunAdapter:
    """Adapter for schedule run objects to handle optional attributes."""

    def __init__(self, run: Any) -> None:
        """Initialize the adapter."""
        self._run = run

    def __getattr__(self, name: str) -> Any:
        """Proxy attribute access to the underlying run object."""
        return getattr(self._run, name)

    def duration_formatted(self) -> str:
        """Format run duration."""
        started_at = getattr(self._run, "started_at", None)
        completed_at = getattr(self._run, "completed_at", None)
        if not started_at or not completed_at:
            return "—"
        duration = completed_at - started_at
        total_seconds = int(duration.total_seconds())
        hours, remainder = divmod(total_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

    def input_preview(self, max_length: int = 120) -> str:
        """Generate a truncated input preview."""
        input_text = getattr(self._run, "input", None)
        if not input_text:
            return "—"
        preview = " ".join(str(input_text).split())
        if len(preview) > max_length:
            return preview[:max_length] + "…"
        return preview


class ScheduleRunDetailAdapter(ScheduleRunAdapter):
    """Adapter for detailed run view."""

    def model_dump(self, *args: Any, **kwargs: Any) -> Any:
        """Dump the model to a dictionary."""
        if hasattr(self._run, "model_dump"):
            return self._run.model_dump(*args, **kwargs)
        if hasattr(self._run, "dict"):
            return self._run.dict(*args, **kwargs)
        return getattr(self._run, "__dict__", {})


class ScheduleRunsPageAdapter:
    """Adapter for paginated run results."""

    def __init__(self, result: Any) -> None:
        """Initialize the page adapter."""
        self.data = [ScheduleRunAdapter(run) for run in result.items]
        self.total = result.total or len(self.data)
        self.page = result.page or 1
        self.limit = result.limit or max(1, len(self.data))
        self.has_next = bool(result.has_next)
        self.has_prev = bool(result.has_prev)


def _build_rows(schedules: list[Any]) -> list[ScheduleRow]:
    rows: list[ScheduleRow] = []
    for schedule in schedules:
        label = _schedule_label(schedule)
        list_when = _format_list_when(schedule)
        cron = _schedule_cron(schedule)
        rows.append(ScheduleRow(schedule=schedule, label=label, list_when=list_when, cron=cron))
    return rows


def _format_list_when(schedule: Any) -> str:
    """Format a compact 'next run' timestamp for list display.

    Shows when the schedule will run next, since the API does not return
    updated_at/created_at timestamps for the list endpoint.
    """
    next_run = getattr(schedule, "next_run_time", None)
    if not next_run:
        return "—"

    try:
        parsed = _parse_schedule_datetime(str(next_run))
        if parsed is not None:
            return parsed.astimezone(UTC).strftime("%b %d %H:%M")
    except Exception:
        pass

    return str(next_run)[:16] if len(str(next_run)) > 16 else str(next_run)


def _filter_rows(rows: list[ScheduleRow], query: str) -> list[ScheduleRow]:
    if not query:
        return rows
    lowered = query.lower()
    return [row for row in rows if lowered in row.label.lower()]


def _schedule_label(schedule: Any) -> str:
    text = " ".join((schedule.input or "").split())
    if not text:
        return str(schedule.id)
    # Higher limit to take advantage of wide left pane.
    if len(text) > 140:
        return text[:140] + "…"
    return text


def _schedule_cron(schedule: Any) -> str:
    config = getattr(schedule, "schedule_config", None)
    if config is None:
        return "—"
    if isinstance(config, ScheduleConfig):
        return config.to_cron_string()
    if isinstance(config, dict):
        return ScheduleConfig(**config).to_cron_string()
    return str(config)


def _format_datetime(value: datetime) -> str:
    try:
        if value.tzinfo is None:
            value = value.replace(tzinfo=UTC)
        value = value.astimezone(UTC)
        return value.strftime("%b %d %H:%M UTC")
    except Exception:
        return "—"


def _parse_schedule_datetime(value: str) -> datetime | None:
    parts = value.split(" ")
    if len(parts) < 2:
        return None

    # Validate timezone token if present - only UTC is supported
    if len(parts) >= 3:
        tz_token = parts[2].upper()
        if tz_token != "UTC":
            # Non-UTC timezone detected (e.g., legacy "WIB" data)
            # Return None to signal that this needs proper handling
            return None

    parsed = datetime.strptime(f"{parts[0]} {parts[1]}", "%Y-%m-%d %H:%M:%S")
    return parsed.replace(tzinfo=UTC)


def _format_timedelta(value: timedelta) -> str:
    total_seconds = int(value.total_seconds())
    days = total_seconds // 86400
    hours = (total_seconds % 86400) // 3600
    if days > 0:
        return f"{days}d {hours}h"
    minutes = (total_seconds % 3600) // 60
    return f"{hours}h {minutes}m"


def _format_natural_delta(s_val: str) -> str | None:
    if not any(tok in s_val for tok in ("day", "hour", "minute")):
        return None

    parts = [p.strip() for p in s_val.split(",")]
    short: list[str] = []
    for p in parts:
        if "day" in p:
            short.append(p.split()[0] + "d")
        elif "hour" in p:
            short.append(p.split()[0] + "h")
        elif "minute" in p:
            n = p.split()[0]
            if n != "0":
                short.append(n + "m")
    if short:
        return " ".join(short[:2])
    return None


def _format_next_run(value: Any) -> str:
    if value is None:
        return "—"
    if isinstance(value, datetime):
        return _format_datetime(value)
    if isinstance(value, timedelta):
        return _format_timedelta(value)

    s_val = str(value)
    result = _format_natural_delta(s_val)
    if result:
        return result

    try:
        parsed = _parse_schedule_datetime(s_val)
        if parsed is not None:
            return _format_datetime(parsed)
    except Exception:
        pass

    return s_val
