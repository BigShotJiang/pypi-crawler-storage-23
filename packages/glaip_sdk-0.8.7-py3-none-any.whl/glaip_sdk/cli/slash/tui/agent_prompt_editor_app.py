"""Textual UI for editing an agent instruction inside the slash palette.

Powers the in-agent `/prompt` command:

    aip -> /agents -> select agent -> (agent context) /prompt

Save paths:

- Save & close: returns to agent prompt
- Save & keep editing: stays in the editor

The UI returns the last saved agent object (or None when nothing was saved).
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from difflib import unified_diff
from typing import Any

from rich.syntax import Syntax
from rich.text import Text

TEXTUAL_SUPPORTED = True
try:  # pragma: no cover - defensive import guard
    from textual.app import App, ComposeResult
    from textual.containers import Horizontal, Vertical
    from textual.screen import Screen
    from textual.widgets import Button, Static, TextArea
except Exception:  # pragma: no cover
    TEXTUAL_SUPPORTED = False

    App = object  # type: ignore[assignment]
    ComposeResult = object  # type: ignore[assignment]
    Horizontal = object  # type: ignore[assignment]
    Vertical = object  # type: ignore[assignment]
    Screen = object  # type: ignore[assignment]
    Button = object  # type: ignore[assignment]
    Static = object  # type: ignore[assignment]
    TextArea = object  # type: ignore[assignment]


PRIMARY = "#005CB8"
HIGHLIGHT = "#40B4E5"

# Widget IDs and selectors to avoid literal duplication (Sonar compliance)
_CURRENT_ID = "current"
_CURRENT_SELECTOR = "#current"
_EDITED_ID = "edited"
_EDITED_SELECTOR = "#edited"

_AppBase = App[None] if TEXTUAL_SUPPORTED else object


@dataclass(frozen=True)
class AgentPromptEditorInput:
    """Input payload for the prompt editor."""

    agent_id: str
    agent_name: str
    instruction: str


def _build_unified_diff(old: str, new: str) -> str:
    diff_lines = unified_diff(
        old.splitlines(True),
        new.splitlines(True),
        fromfile=_CURRENT_ID,
        tofile=_EDITED_ID,
    )
    text = "".join(diff_lines)
    return text or "(no changes)\n"


class _DiffScreen(Screen):  # pragma: no cover - interactive
    BINDINGS = [("escape", "app.pop_screen", "Back")]

    def __init__(self, diff_text: str, *, title: str) -> None:
        super().__init__()
        self._diff_text = diff_text
        self._title = title

    def compose(self) -> ComposeResult:
        yield Static(Text(self._title, style=f"bold {HIGHLIGHT}"), id="modal_title")
        yield Static(Syntax(self._diff_text, "diff", word_wrap=True), id="diff")
        yield Static("Esc: back", id="modal_footer")


class _ConfirmSaveScreen(Screen):  # pragma: no cover - interactive
    BINDINGS = [("escape", "cancel", "Cancel")]

    def __init__(self, diff_text: str) -> None:
        super().__init__()
        self._diff_text = diff_text

    def compose(self) -> ComposeResult:
        yield Static(Text("Confirm changes", style=f"bold {HIGHLIGHT}"), id="modal_title")
        yield Static(Syntax(self._diff_text, "diff", word_wrap=True), id="diff")
        with Horizontal(id="modal_buttons"):
            yield Button("Save & close", variant="success", id="save_close")
            yield Button("Save & keep editing", variant="primary", id="save_keep")
            yield Button("Cancel", variant="default", id="cancel")
        yield Static("Choose how to continue  ·  Esc: cancel", id="modal_footer")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_id = event.button.id or ""
        if btn_id in {"save_close", "save_keep"}:
            close_after = btn_id == "save_close"
            apply_fn = getattr(self.app, "_apply_save", None)
            if callable(apply_fn):
                apply_fn(close_after=close_after)
            # If the app is exiting (save & close), avoid popping the screen.
            if not close_after:
                self.app.pop_screen()
            return
        self.app.pop_screen()

    def action_cancel(self) -> None:
        self.app.pop_screen()


class _ConfirmDiscardScreen(Screen):  # pragma: no cover - interactive
    BINDINGS = [("escape", "keep", "Keep editing")]

    def compose(self) -> ComposeResult:
        yield Static(Text("Discard changes?", style=f"bold {HIGHLIGHT}"), id="modal_title")
        yield Static(
            "You have unsaved edits in the right box.",
            id="modal_footer",
        )
        with Horizontal(id="modal_buttons"):
            yield Button("Keep editing", variant="primary", id="keep")
            yield Button("Discard", variant="warning", id="discard")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_id = event.button.id or ""
        if btn_id == "discard":
            discard_fn = getattr(self.app, "_discard_and_exit", None)
            if callable(discard_fn):
                discard_fn()
            return
        self.app.pop_screen()

    def action_keep(self) -> None:
        self.app.pop_screen()


class AgentPromptEditorApp(_AppBase):  # pragma: no cover - interactive
    """Interactive app for editing an agent instruction."""

    CSS = f"""
    Screen {{ background: #000000; }}

    #header {{ height: 3; padding: 1 2; color: white; }}
    #panes {{ height: 1fr; padding: 0 2; }}
    #footerbar {{ height: 3; padding: 0 2; }}
    #footer {{ height: 1; color: #A0A0A0; }}

    Button {{ margin-left: 1; }}
    .label {{ padding: 0 0 1 0; color: #A0A0A0; }}
    .label-current {{ color: #808080; }}
    .label-edited {{ color: #40B4E5; }}

    #current-container {{ background: #0d0d0d; border: tall #555555; padding: 1; }}
    #edited-container {{ background: #1f1f1f; border: tall {PRIMARY}; padding: 1; }}

    {_CURRENT_SELECTOR} {{ border: none; background: transparent; color: #a0a0a0; }}
    {_EDITED_SELECTOR} {{ border: none; background: transparent; }}

    .separator {{ height: 1; background: #444444; margin: 0 0 1 0; }}

    #diff {{ border: tall {HIGHLIGHT}; padding: 1 2; margin: 1 2; height: 1fr; }}

    #modal_title {{ padding: 1 2 0 2; color: white; }}
    #modal_footer {{ padding: 0 2 1 2; color: #A0A0A0; }}
    #modal_buttons {{ padding: 0 2 1 2; height: auto; }}
    """

    BINDINGS = [
        ("ctrl+g", "diff", "Diff"),
        ("ctrl+s", "save", "Save"),
        ("escape", "cancel", "Cancel"),
    ]

    def __init__(self, payload: AgentPromptEditorInput, *, save_callback: Callable[[str], Any]) -> None:
        super().__init__()
        self._payload = payload
        self._current_instruction = payload.instruction or ""
        self._save_callback = save_callback
        self._dirty = False
        self._last_saved_agent: Any | None = None
        self.result_agent: Any | None = None

    def compose(self) -> ComposeResult:
        yield Static(id="header")
        with Horizontal(id="panes"):
            with Vertical(id="current-container"):
                yield Static("🔒 Current (read-only)", classes="label label-current")
                yield Static("", classes="separator")
                yield TextArea(self._current_instruction, id=_CURRENT_ID, read_only=True)
            with Vertical(id="edited-container"):
                yield Static("✏️  Editable (type here)", classes="label label-edited", id="edited-label")
                yield Static("", classes="separator")
                yield TextArea(self._current_instruction, id=_EDITED_ID)
        with Horizontal(id="footerbar"):
            yield Static(id="footer")
            yield Button("Diff (Ctrl+G)", id="diff_btn")
            yield Button("Save (Ctrl+S)", id="save_btn", variant="success")
            yield Button("Cancel (Esc)", id="cancel_btn")

    def on_mount(self) -> None:
        self._render_header()
        self._render_footer()
        self.query_one(_EDITED_SELECTOR, TextArea).focus()

    def _render_header(self) -> None:
        text = Text()
        text.append("Prompt Editor", style=f"bold {HIGHLIGHT}")
        text.append("  ")
        text.append(self._payload.agent_name or self._payload.agent_id, style="bold white")
        text.append("  ")
        text.append(f"({self._payload.agent_id})", style="dim")
        if self._dirty:
            text.append("  ")
            text.append("(unsaved)", style="yellow")
        self.query_one("#header", Static).update(text)

    def _render_footer(self) -> None:
        self.query_one("#footer", Static).update("Diff: Ctrl+G  ·  Save: Ctrl+S  ·  Cancel: Esc")

    def _update_modified_indicator(self) -> None:
        """Update the modified indicator in the edited pane header."""
        try:
            label = self.query_one("#edited-label", Static)
            if self._dirty:
                text = Text("✏️  Editable (type here) ")
                text.append("●", style="#00ff00")
                label.update(text)
            else:
                label.update("✏️  Editable (type here)")
        except Exception:
            pass

    def on_text_area_changed(self, event: TextArea.Changed) -> None:
        if (event.text_area.id or "") != _EDITED_ID:
            return
        edited = self.query_one(_EDITED_SELECTOR, TextArea).text
        dirty_now = edited != self._current_instruction
        if dirty_now != self._dirty:
            self._dirty = dirty_now
            self._render_header()
            self._update_modified_indicator()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_id = event.button.id or ""
        if btn_id == "diff_btn":
            self.action_diff()
            return
        if btn_id == "save_btn":
            self.action_save()
            return
        if btn_id == "cancel_btn":
            self.action_cancel()

    def action_diff(self) -> None:
        edited = self.query_one(_EDITED_SELECTOR, TextArea).text
        diff_text = _build_unified_diff(self._current_instruction, edited)
        self.push_screen(_DiffScreen(diff_text, title="Diff preview"))

    def action_save(self) -> None:
        edited = self.query_one(_EDITED_SELECTOR, TextArea).text
        if edited == self._current_instruction:
            self.notify("No changes to save.", timeout=2)
            return
        diff_text = _build_unified_diff(self._current_instruction, edited)
        self.push_screen(_ConfirmSaveScreen(diff_text))

    def action_cancel(self) -> None:
        edited = self.query_one(_EDITED_SELECTOR, TextArea).text
        if edited != self._current_instruction:
            self.push_screen(_ConfirmDiscardScreen())
            return
        self._discard_and_exit()

    def _discard_and_exit(self) -> None:
        """Exit the editor, discarding unsaved changes."""
        if self._last_saved_agent is not None:
            self.result_agent = self._last_saved_agent
        self.exit()

    def _apply_save(self, *, close_after: bool) -> None:
        edited = self.query_one(_EDITED_SELECTOR, TextArea).text
        try:
            updated_agent = self._save_callback(edited)
        except Exception as exc:
            self.notify(f"Save failed: {exc}", timeout=4)
            return

        self._last_saved_agent = updated_agent

        saved_text = getattr(updated_agent, "instruction", None)
        if isinstance(saved_text, str) and saved_text:
            self._current_instruction = saved_text
        else:
            self._current_instruction = edited

        self.query_one(_CURRENT_SELECTOR, TextArea).text = self._current_instruction
        self.query_one(_EDITED_SELECTOR, TextArea).text = self._current_instruction
        self._dirty = False
        self._render_header()
        self._update_modified_indicator()

        if close_after:
            self.result_agent = updated_agent
            self.exit()
            return

        self.notify("Saved.", timeout=2)


def run_agent_prompt_editor_textual(
    payload: AgentPromptEditorInput,
    save_callback: Callable[[str], Any],
    *,
    ctx: Any | None = None,
) -> Any | None:
    """Run the editor UI and return the last saved agent."""
    if not TEXTUAL_SUPPORTED:
        return None
    app = AgentPromptEditorApp(payload, save_callback=save_callback)
    theme_name = getattr(getattr(ctx, "theme", None), "theme_name", None)
    if theme_name:
        try:
            app.theme = theme_name
        except Exception:
            pass
    app.run(mouse=True)
    return getattr(app, "result_agent", None)


__all__ = [
    "AgentPromptEditorInput",
    "TEXTUAL_SUPPORTED",
    "run_agent_prompt_editor_textual",
]
