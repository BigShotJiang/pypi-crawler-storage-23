"""Reusable design primitives for `/agents` workspace surfaces.

This module centralizes shared style primitives used by the gated workspace
shell and future `/agents` TUI pages. Keeping these helpers outside the app
class avoids copy/paste drift across roadmap PRs.
"""

from __future__ import annotations

import os
from collections.abc import Sequence
from datetime import UTC, datetime

from glaip_sdk.branding import AIPBranding, INFO, PRIMARY, SECONDARY_DARK, SECONDARY_LIGHT, SUCCESS, WARNING


def _workspace_logo_text() -> str:
    logo_lines = AIPBranding.AIP_LOGO.splitlines()
    return "\n".join(logo_lines[:6])


AGENT_WORKSPACE_THEME = {
    "screen": "#060a10",
    "panel": "#101923",
    "panel_alt": "#0d141d",
    "border": SECONDARY_DARK,
    "text": "#d9e4f2",
    "muted": "#8fa4ba",
    "accent": SECONDARY_LIGHT,
    "heading": WARNING,
    "success": SUCCESS,
    "info": INFO,
    "tools": SUCCESS,
    "mcps": INFO,
    "workspace": "#a5b5c9",
    "brand": PRIMARY,
}

AGENT_WORKSPACE_LOGO_TEXT = _workspace_logo_text()

MODEL_LABEL_PLACEHOLDER = "Resolution pending"


def workspace_label(*, cwd: str | None = None, home: str | None = None) -> str:
    """Return workspace label with home collapsed to `~` when possible."""
    cwd_value = cwd if cwd is not None else os.getcwd()
    home_value = home if home is not None else os.path.expanduser("~")
    if cwd_value.startswith(home_value):
        return "~" + cwd_value[len(home_value) :]
    return os.path.basename(cwd_value) or cwd_value


def format_summary_rows(rows: Sequence[tuple[str, str]], *, muted_color: str) -> str:
    """Format summary key/value rows using shared muted-key styling."""
    return "\n".join(f"[{muted_color}]{key}:[/] {value}" for key, value in rows)


def format_utc_timestamp(raw: str) -> str:
    """Normalize an ISO-like timestamp into `YYYY-MM-DD HH:MM:SS UTC`."""
    value = (raw or "").strip()
    if not value:
        return "-"

    normalized = value.replace("Z", "+00:00")
    try:
        dt = datetime.fromisoformat(normalized)
    except ValueError:
        return value

    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    else:
        dt = dt.astimezone(UTC)
    return dt.strftime("%Y-%m-%d %H:%M:%S UTC")
