"""Agent-specific interaction loop for the command palette.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

import json
import os
import re
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any, cast

import click

from glaip_sdk.branding import ERROR_STYLE, HINT_PREFIX_STYLE
from glaip_sdk.cli.commands.agents import get as agents_get_command
from glaip_sdk.cli.commands.agents import run as agents_run_command
from glaip_sdk.cli.constants import DEFAULT_AGENT_INSTRUCTION_PREVIEW_LIMIT
from glaip_sdk.cli.core.context import bind_slash_session_context, get_client
from glaip_sdk.cli.hints import format_command_hint
from glaip_sdk.cli.slash.prompt import _HAS_PROMPT_TOOLKIT, FormattedText
from glaip_sdk.cli.slash.tui.agent_prompt_editor_app import (
    TEXTUAL_SUPPORTED as _TEXTUAL_SUPPORTED,
)
from glaip_sdk.cli.slash.tui.agent_prompt_editor_app import (
    AgentPromptEditorInput,
    run_agent_prompt_editor_textual,
)
from glaip_sdk.cli.slash.tui.agent_workspace_shell_app import (
    TEXTUAL_SUPPORTED as _WORKSPACE_TEXTUAL_SUPPORTED,
)
from glaip_sdk.cli.slash.tui.agent_workspace_shell_app import (
    AgentWorkspaceDetails,
    run_agent_workspace_shell,
)
from glaip_sdk.cli.transcript import store_transcript_for_session
from glaip_sdk.utils.rendering.renderer import make_silent_renderer

if TYPE_CHECKING:  # pragma: no cover - type checking only
    from glaip_sdk.cli.slash.session import SlashSession


class AgentRunSession:
    """Per-agent execution context for the command palette."""

    RETURN_TO_PALETTE_HELP = "Return to the command palette."
    _ANSI_RE = re.compile(r"\x1B\[[0-?]*[ -/]*[@-~]")
    _STATUS_HEADER_LINE = "gl aip status"
    _STATUS_FETCHING_TOKEN = "fetching"
    _STATUS_BULLET_PREFIX = "• "
    _STATUS_ACCOUNT_PREFIX = "Account:"
    _STATUS_API_PREFIX = "API URL:"
    _STATUS_BASE_PREFIX = "Base URL:"
    _STATUS_ENDPOINT_PREFIX = "Endpoint:"
    _STATUS_SAVED_TRANSCRIPTS_PREFIX = "Saved transcripts:"
    _STATUS_TRANSCRIPTS_PREFIX = "Transcripts:"
    _STATUS_CACHE_DIR_PREFIX = "Cache dir:"
    _STATUS_RESOURCES_PREFIX = "Resources:"

    def __init__(self, session: SlashSession, agent: Any) -> None:
        """Initialize the agent run session.

        Args:
            session: The slash session context
            agent: The agent to interact with
        """
        self.session = session
        self.agent = agent
        self.console = session.console
        self._agent_id = str(getattr(agent, "id", ""))
        self._agent_name = getattr(agent, "name", "") or self._agent_id
        self._prompt_placeholder: str = (
            "Chat with this agent here; use / for shortcuts. "
            "Alt+Enter inserts a newline. Ctrl+T opens the last transcript."
        )
        self._contextual_completion_help: dict[str, str] = {
            "details": "Show this agent's configuration (+ expands prompt).",
            "prompt": "Edit this agent's prompt (instruction).",
            "status": "Display connection status without leaving this context.",
            "help": "Display this context-aware menu.",
            "runs": "Browse remote run history for this agent.",
            "schedules": "Manage recurring schedules for this agent.",
            "export": "Export the latest transcript as JSONL.",
            "exit": self.RETURN_TO_PALETTE_HELP,
            "back": self.RETURN_TO_PALETTE_HELP,
            "q": self.RETURN_TO_PALETTE_HELP,
        }
        self._instruction_preview_limit = DEFAULT_AGENT_INSTRUCTION_PREVIEW_LIMIT
        self._workspace_history: list[str] = []
        self._in_workspace_command = False

    def run(self) -> None:
        """Run the interactive agent session loop."""
        self.session.set_contextual_commands(self._contextual_completion_help, include_global=False)
        previous_agent = getattr(self.session, "_current_agent", None)
        self.session._current_agent = self.agent
        clear_ready = getattr(self.session, "clear_agent_transcript_ready", None)
        if callable(clear_ready):
            clear_ready(self._agent_id)
        try:
            self._display_agent_info()
            if self._use_workspace_shell():
                self._run_agent_workspace_loop()
            else:
                self._run_agent_loop()
        finally:
            self.session.set_contextual_commands(None)
            self.session._current_agent = previous_agent

    def _use_workspace_shell(self) -> bool:
        """Return True when the gated workspace shell should be used."""
        enabled = os.getenv("AIP_TUI_AGENT_WORKSPACE", "").strip().lower() in {"1", "true", "yes", "on"}
        return bool(enabled and _WORKSPACE_TEXTUAL_SUPPORTED and self._is_tty_available())

    def _is_tty_available(self) -> bool:
        """Detect interactive terminal support for workspace shell usage."""
        ctx_obj = getattr(self.session.ctx, "obj", None)
        if isinstance(ctx_obj, dict) and "tty" in ctx_obj:
            try:
                return bool(ctx_obj.get("tty"))
            except Exception:
                pass
        return bool(getattr(self.console, "is_terminal", False))

    def _run_agent_workspace_loop(self) -> None:
        """Run interaction loop via Textual workspace shell."""
        while True:
            event = self._next_workspace_event()
            if event is None:
                return

            if not self._process_workspace_event(event):
                return

    def _next_workspace_event(self) -> Any | None:
        """Request next event from workspace shell."""
        event = run_agent_workspace_shell(
            details=self._workspace_details(),
            transcript_lines=self._workspace_history,
            composer_placeholder=self._prompt_placeholder or "Type / for commands, or enter a message.",
            status_summary_provider=self._collect_status_summary_lines,
            transcript_sink=self._set_workspace_history,
            message_run_provider=self._run_workspace_message,
        )
        if self._prompt_placeholder:
            self._prompt_placeholder = ""
        if event is None or event.kind == "exit":
            return None
        return event

    def _set_workspace_history(self, lines: list[str]) -> None:
        """Persist workspace transcript updates emitted from inline status flow."""
        self._workspace_history = list(lines)

    def _run_workspace_message(self, message: str) -> str | tuple[str, list[str]] | None:
        """Execute agent run callback while workspace shell remains active."""
        return self._run_agent(self._agent_id, message)

    def _process_workspace_event(self, event: Any) -> bool:
        """Process a single workspace event and return continue-session signal."""
        value = (event.value or "").strip()
        if not value:
            return True

        if event.kind == "command":
            return self._process_workspace_command(value)

        if self._workspace_history and self._workspace_history[-1].strip():
            self._workspace_history.append("")
        self._workspace_history.append(f"You: {value}")
        reply = self._run_agent(self._agent_id, value)
        if isinstance(reply, tuple) and len(reply) == 2:
            reply_text, status_lines = reply
            for line in status_lines:
                self._workspace_history.append(f"  - {line}")
            self._workspace_history.append(f"Agent: {reply_text or 'Run finished.'}")
        elif isinstance(reply, str) and reply.strip():
            self._workspace_history.append(f"Agent: {reply}")
        else:
            self._workspace_history.append("Agent: Run finished. Press Ctrl+T in prompt mode to inspect transcript.")
        return True

    def _process_workspace_command(self, value: str) -> bool:
        """Process a workspace slash command event."""
        if self._should_clear_terminal_before_workspace_route(value):
            self._clear_terminal_before_workspace_route()

        self._in_workspace_command = True
        try:
            return bool(self._handle_slash_command(value, self._agent_id))
        finally:
            self._in_workspace_command = False

    @staticmethod
    def _should_clear_terminal_before_workspace_route(value: str) -> bool:
        """Return True for routed workspace commands that launch separate TUI apps."""
        command = (str(value or "").strip().split(maxsplit=1)[0] or "").lower()
        return command in {"/runs", "/schedules", "/prompt"}

    def _clear_terminal_before_workspace_route(self) -> None:
        """Clear terminal buffer to avoid stale non-TUI flashes between TUI app lifecycles."""
        try:
            if getattr(self.console, "is_terminal", False):
                self.console.clear()
        except Exception:
            pass

    def _workspace_details(self) -> AgentWorkspaceDetails:
        """Build details payload for workspace shell render."""
        tools = self._coerce_items(getattr(self.agent, "tools", None))
        mcps = self._coerce_items(getattr(self.agent, "mcps", None))
        account_id = str(getattr(self.agent, "account_id", "") or "").strip()
        if not account_id:
            account_id = self._resolve_active_account_name()

        return AgentWorkspaceDetails(
            id=self._agent_id,
            name=self._agent_name,
            account_id=account_id,
            description=str(getattr(self.agent, "description", "") or ""),
            type=str(getattr(self.agent, "type", "") or ""),
            framework=str(getattr(self.agent, "framework", "") or ""),
            version=str(getattr(self.agent, "version", "") or ""),
            model_label=self._extract_model_label(getattr(self.agent, "agent_config", None)),
            tools_summary=str(len(tools)),
            mcps_summary=str(len(mcps)),
            tool_names=tuple(
                self._extract_item_name(item, fallback_prefix="tool", index=idx) for idx, item in enumerate(tools, 1)
            ),
            mcp_names=tuple(
                self._extract_item_name(item, fallback_prefix="mcp", index=idx) for idx, item in enumerate(mcps, 1)
            ),
            updated_at=str(getattr(self.agent, "updated_at", "") or ""),
        )

    @staticmethod
    def _coerce_items(values: Any) -> list[Any]:
        return values if isinstance(values, list) else []

    @staticmethod
    def _extract_item_name(item: Any, *, fallback_prefix: str, index: int) -> str:
        if isinstance(item, str):
            candidate = item
        elif isinstance(item, dict):
            candidate = item.get("name")
        else:
            candidate = getattr(item, "name", None)

        text = str(candidate or "").strip()
        if text:
            return text
        return f"{fallback_prefix}-{index}"

    def _resolve_active_account_name(self) -> str:
        getter = getattr(self.session, "_get_account_context", None)
        if not callable(getter):
            return ""
        try:
            account_context = getter()
        except Exception:
            return ""
        if not isinstance(account_context, tuple) or len(account_context) < 1:
            return ""
        active_name = account_context[0]
        return str(active_name or "").strip()

    @staticmethod
    def _extract_model_label(agent_config: Any) -> str:
        if isinstance(agent_config, dict):
            provider = str(agent_config.get("lm_provider") or "").strip()
            model = str(agent_config.get("lm_name") or "").strip()
        else:
            provider = str(getattr(agent_config, "lm_provider", "") or "").strip()
            model = str(getattr(agent_config, "lm_name", "") or "").strip()

        if not model:
            return ""
        if provider:
            return f"{provider}/{model}"
        return model

    @staticmethod
    def _compact_status_lines(rendered: str, *, max_lines: int = 6) -> list[str]:
        """Extract compact status lines suitable for workspace transcript history."""
        lines: list[str] = []
        for raw_line in rendered.splitlines():
            without_ansi = AgentRunSession._ANSI_RE.sub("", raw_line)
            line = " ".join(without_ansi.strip().split())
            if not line:
                continue
            if line.lower().startswith("next actions"):
                continue
            if line.startswith("/") or line.startswith("›"):
                continue
            if line.lower().startswith("hint:"):
                continue
            if not any(ch.isalnum() for ch in line):
                continue
            lines.append(line)
            if len(lines) >= max_lines:
                break
        return lines

    @staticmethod
    def _workspace_status_lines(compact_lines: list[str]) -> list[str]:
        """Normalize compact status lines for readable workspace transcript display."""
        normalized: list[str] = []
        home_dir = os.path.expanduser("~")
        endpoint_url = ""
        endpoint_note = ""

        for raw in compact_lines:
            line = AgentRunSession._normalize_workspace_status_line(raw)
            if line is None or AgentRunSession._should_skip_workspace_status_line(line):
                continue

            handled, endpoint_url, endpoint_note, parsed_lines = AgentRunSession._handle_workspace_status_body_line(
                line=line,
                home_dir=home_dir,
                endpoint_url=endpoint_url,
                endpoint_note=endpoint_note,
            )
            if handled:
                normalized.extend(parsed_lines)
                continue

            normalized.append(AgentRunSession._normalize_workspace_resources_line(line))

        AgentRunSession._insert_workspace_endpoint_line(
            normalized=normalized,
            endpoint_url=endpoint_url,
            endpoint_note=endpoint_note,
        )

        return AgentRunSession._dedupe_workspace_status_lines(normalized)

    @staticmethod
    def _handle_workspace_status_body_line(
        *,
        line: str,
        home_dir: str,
        endpoint_url: str,
        endpoint_note: str,
    ) -> tuple[bool, str, str, list[str]]:
        account_line, account_endpoint = AgentRunSession._parse_workspace_account_line(line)
        if account_line is not None:
            next_endpoint = endpoint_url
            next_note = endpoint_note
            if account_endpoint:
                next_endpoint = account_endpoint
                next_note = ""
            return True, next_endpoint, next_note, [account_line]

        api_endpoint = AgentRunSession._parse_workspace_api_line(line)
        if api_endpoint is not None:
            return True, api_endpoint, "", []

        base_endpoint, base_note, has_base_line = AgentRunSession._parse_workspace_base_line(line)
        if has_base_line:
            if endpoint_url and base_endpoint == endpoint_url:
                return True, endpoint_url, base_note, []
            if base_endpoint:
                endpoint_line = AgentRunSession._build_workspace_endpoint_line(base_endpoint, base_note)
                return True, endpoint_url, endpoint_note, [endpoint_line]
            return True, endpoint_url, endpoint_note, []

        transcript_lines = AgentRunSession._parse_workspace_saved_transcripts_line(line, home_dir)
        if transcript_lines is not None:
            return True, endpoint_url, endpoint_note, transcript_lines

        return False, endpoint_url, endpoint_note, []

    @staticmethod
    def _insert_workspace_endpoint_line(*, normalized: list[str], endpoint_url: str, endpoint_note: str) -> None:
        if not endpoint_url:
            return

        endpoint_line = AgentRunSession._build_workspace_endpoint_line(endpoint_url, endpoint_note)
        insert_at = 1 if normalized and normalized[0].startswith(AgentRunSession._STATUS_ACCOUNT_PREFIX) else 0
        normalized.insert(insert_at, endpoint_line)

    @staticmethod
    def _normalize_workspace_status_line(raw: str) -> str | None:
        line = raw.strip()
        if not line:
            return None
        if line.startswith(AgentRunSession._STATUS_BULLET_PREFIX):
            return line[len(AgentRunSession._STATUS_BULLET_PREFIX) :]
        return line

    @staticmethod
    def _should_skip_workspace_status_line(line: str) -> bool:
        lower = line.lower()
        return lower == AgentRunSession._STATUS_HEADER_LINE or AgentRunSession._STATUS_FETCHING_TOKEN in lower

    @staticmethod
    def _parse_workspace_account_line(line: str) -> tuple[str | None, str]:
        if not line.startswith(AgentRunSession._STATUS_ACCOUNT_PREFIX):
            return None, ""
        account_part, sep, api_part = line.partition(" · API URL: ")
        return account_part, api_part.strip() if sep and api_part else ""

    @staticmethod
    def _parse_workspace_api_line(line: str) -> str | None:
        if not line.startswith(AgentRunSession._STATUS_API_PREFIX):
            return None
        return line.replace(AgentRunSession._STATUS_API_PREFIX, "", 1).strip()

    @staticmethod
    def _parse_workspace_base_line(line: str) -> tuple[str, str, bool]:
        if not line.startswith(AgentRunSession._STATUS_BASE_PREFIX):
            return "", "", False

        base_body = line.replace(AgentRunSession._STATUS_BASE_PREFIX, "", 1).strip()
        if " (" in base_body and base_body.endswith(")"):
            base_url, _, suffix = base_body.partition(" (")
            return base_url.strip(), suffix[:-1].strip(), True
        return base_body.strip(), "", True

    @staticmethod
    def _parse_workspace_saved_transcripts_line(line: str, home_dir: str) -> list[str] | None:
        prefix = AgentRunSession._STATUS_SAVED_TRANSCRIPTS_PREFIX
        if not line.startswith(prefix):
            return None

        summary_part, sep, path_part = line.rpartition(" · ")
        summary = summary_part if sep else line
        normalized_summary = summary.replace(prefix, AgentRunSession._STATUS_TRANSCRIPTS_PREFIX, 1)

        if not sep:
            return [normalized_summary]

        cache_path = AgentRunSession._normalize_workspace_cache_path(path_part, home_dir)
        return [normalized_summary, f"{AgentRunSession._STATUS_CACHE_DIR_PREFIX} {cache_path}"]

    @staticmethod
    def _normalize_workspace_cache_path(path: str, home_dir: str) -> str:
        cache_path = path
        if cache_path.startswith(home_dir):
            return f"~{cache_path[len(home_dir) :]}"
        return cache_path

    @staticmethod
    def _normalize_workspace_resources_line(line: str) -> str:
        if line.startswith(AgentRunSession._STATUS_RESOURCES_PREFIX):
            return line.replace(",", " ·")
        return line

    @staticmethod
    def _build_workspace_endpoint_line(endpoint_url: str, endpoint_note: str) -> str:
        endpoint_line = f"{AgentRunSession._STATUS_ENDPOINT_PREFIX} {endpoint_url}"
        if endpoint_note:
            return f"{endpoint_line} ({endpoint_note})"
        return endpoint_line

    @staticmethod
    def _dedupe_workspace_status_lines(lines: list[str], *, limit: int = 8) -> list[str]:
        # Preserve order while removing duplicates and limiting line count.
        deduped: list[str] = []
        for line in lines:
            if line in deduped:
                continue
            deduped.append(line)
            if len(deduped) >= limit:
                break
        return deduped

    def _display_agent_info(self) -> None:
        """Display agent information and summary."""
        self.session._render_header(self.agent, focus_agent=True)

    def _run_agent_loop(self) -> None:
        """Run the main agent interaction loop."""
        while True:
            raw = self._get_user_input()
            if raw is None:
                return

            raw = raw.strip()
            if not raw:
                continue

            if raw.startswith("/"):
                if not self._handle_slash_command(raw, self._agent_id):
                    return
                continue

            self._run_agent(self._agent_id, raw)

    def _get_user_input(self) -> str | None:
        """Get user input with proper error handling."""
        try:

            def _prompt_message() -> Any:
                """Get formatted prompt message for agent session."""
                prompt_prefix = f"{self._agent_name} ({self._agent_id}) "

                # Use FormattedText if prompt_toolkit is available, otherwise use simple string
                if _HAS_PROMPT_TOOLKIT and FormattedText is not None:
                    segments = [
                        ("class:prompt", prompt_prefix),
                        ("class:prompt", "\n› "),
                    ]
                    return FormattedText(segments)

                return f"{prompt_prefix}\n› "

            raw = self.session._prompt(
                _prompt_message,
                placeholder=self._prompt_placeholder,
            )
            if self._prompt_placeholder:
                # Show the guidance once, then fall back to a clean prompt.
                self._prompt_placeholder = ""
            return raw
        except EOFError:
            self.console.print("\nExiting agent context.")
            return None
        except KeyboardInterrupt:
            self.console.print("")
            return ""

    def _handle_slash_command(self, raw: str, agent_id: str) -> bool:
        """Handle slash commands in agent context. Returns False if should exit."""
        # Handle simple commands first
        if raw == "/":
            return self._handle_help_command()

        verb, args = self.session._parse(raw)
        if verb in {"exit", "back", "q"}:
            return self._handle_exit_command()

        if verb == "details":
            return self._handle_details_command(agent_id)

        if verb == "prompt":
            return self._handle_prompt_command(agent_id)

        if verb == "runs":
            return self._handle_runs_command(args)

        if verb == "schedules":
            return self._handle_schedules_command(args)

        if verb == "status":
            return self._handle_status_command(args)

        if verb == "export":
            return self._handle_export_command(args)

        if verb in {"help", "?"}:
            return self._handle_help_command()

        if verb == "login":
            return bool(self.session._cmd_login(args, True))
        if verb == "accounts":
            return bool(self.session._cmd_accounts(args, True))
        if verb == "transcripts":
            return bool(self.session._cmd_transcripts(args, True))
        if verb == "agents":
            return bool(self.session._cmd_agents(args, True))
        if verb == "update":
            return bool(self.session._cmd_update(args, True))

        # Handle other commands through the main session
        return self._handle_other_command(raw)

    def _handle_help_command(self) -> bool:
        """Handle help command."""
        self.session._cmd_help([], True)
        return True

    def _handle_exit_command(self) -> bool:
        """Handle exit command."""
        self.console.print("[dim]Returning to the main prompt.[/dim]")
        return False

    def _handle_details_command(self, agent_id: str) -> bool:
        """Handle details command."""
        self._show_details(agent_id)
        return True

    def _handle_prompt_command(self, agent_id: str) -> bool:
        """Open the prompt editor for this agent."""
        try:
            updated = self._edit_agent_instruction(agent_id)
            if updated is not None:
                self.agent = updated
                self.session._current_agent = updated
                # Refresh header after save when running in prompt mode.
                # Workspace-mode flow restores its own TUI surface immediately.
                if not self._in_workspace_command:
                    try:
                        if getattr(self.session.console, "is_terminal", False):
                            self.session.console.clear()
                    except Exception:
                        pass
                    try:
                        self.session._render_header(updated, focus_agent=True)
                    except Exception:
                        pass
        except click.ClickException as exc:
            self.console.print(f"[{ERROR_STYLE}]{exc}[/]")
        except Exception as exc:  # pragma: no cover - defensive
            self.console.print(f"[{ERROR_STYLE}]Failed to edit prompt: {exc}[/]")
        return True

    def _handle_runs_command(self, args: list[str]) -> bool:
        """Handle /runs command with explicit agent-context routing."""
        return bool(self.session._cmd_runs(args, True))

    def _handle_schedules_command(self, args: list[str]) -> bool:
        """Handle /schedules command with explicit agent-context routing."""
        return bool(self.session._cmd_schedules(args, True))

    def _handle_status_command(self, args: list[str]) -> bool:
        """Handle /status command with explicit agent-context routing."""
        if not self._in_workspace_command:
            return bool(self.session._cmd_status(args, True))
        status_lines = self._collect_status_summary_lines(args)
        if status_lines:
            self._workspace_history.append("Cmd: /status")
            self._workspace_history.extend(f"Status: {line}" for line in status_lines)
        return True

    def _collect_status_summary_lines(self, args: list[str] | None = None) -> list[str]:
        """Collect compact status lines without printing raw output to terminal."""
        status_args = args if args is not None else []
        with self.session.console.capture() as capture:
            self.session._cmd_status(status_args, True)
        compact_lines = self._compact_status_lines(capture.get())
        return self._workspace_status_lines(compact_lines)

    def _handle_export_command(self, args: list[str]) -> bool:
        """Handle /export command with explicit agent-context routing."""
        return bool(self.session._cmd_export(args, True))

    def _edit_agent_instruction(self, agent_id: str) -> Any | None:
        """Launch TUI editor and update the agent instruction if saved.

        Returns:
            Updated agent object when saved, otherwise None.
        """
        client = get_client(self.session.ctx)
        agent_obj = client.get_agent_by_id(agent_id)
        if agent_obj is None:
            raise click.ClickException(f"Agent '{agent_id}' not found")

        resolved_agent_id: str = str(getattr(agent_obj, "id", agent_id) or agent_id)
        current = getattr(agent_obj, "instruction", "") or ""

        def save_instruction(new_instruction: str) -> Any:
            return client.agents.update_agent(resolved_agent_id, instruction=new_instruction)

        if not _TEXTUAL_SUPPORTED or not getattr(self.console, "is_terminal", False):
            return self._edit_agent_instruction_with_editor(current, save_instruction)

        payload = AgentPromptEditorInput(
            agent_id=resolved_agent_id,
            agent_name=str(getattr(agent_obj, "name", "") or resolved_agent_id),
            instruction=current,
        )
        tui_ctx = getattr(self.session, "tui_ctx", None)
        updated = run_agent_prompt_editor_textual(payload, save_instruction, ctx=tui_ctx)
        if updated is None:
            return None
        self.console.print(f"[{HINT_PREFIX_STYLE}]Saved:[/] Updated agent prompt.")
        return updated

    def _edit_agent_instruction_with_editor(self, current: str, save_instruction: Any) -> Any | None:
        """Fallback editor loop for non-TTY environments.

        Args:
            current: Current instruction text.
            save_instruction: Callable that persists new instruction text.

        Returns:
            Updated agent object when saved, otherwise None.
        """
        updated_agent: Any | None = None
        while True:
            edited = click.edit(current)
            if edited is None:
                return updated_agent
            if isinstance(edited, bytes):
                edited_text = edited.decode("utf-8", errors="replace")
            else:
                edited_text = str(edited)
            if edited_text == current:
                self.console.print("[dim]No changes to save.[/dim]")
                return updated_agent
            if not click.confirm("Apply changes to this agent prompt?", default=False):
                self.console.print("[dim]Cancelled.[/dim]")
                return updated_agent
            updated_agent = save_instruction(edited_text)
            current = getattr(updated_agent, "instruction", edited_text) or edited_text
            self.console.print(f"[{HINT_PREFIX_STYLE}]Saved:[/] Updated agent prompt.")
            if not click.confirm("Keep editing?", default=False):
                return updated_agent

    def _handle_other_command(self, raw: str) -> bool:
        """Handle other commands through the main session."""
        self.session.handle_command(raw, invoked_from_agent=True)
        return not self.session._should_exit

    def _show_details(self, agent_id: str, *, enable_prompt: bool = True) -> None:
        """Render the agent's configuration export inside the command palette."""
        try:
            self.session.ctx.invoke(
                agents_get_command,
                agent_ref=agent_id,
                instruction_preview=self._instruction_preview_limit,
            )
            if enable_prompt:
                self._prompt_instruction_view_toggle(agent_id)
                self.console.print(
                    f"[{HINT_PREFIX_STYLE}]Tip:[/] Continue the conversation in this prompt, or use "
                    f"{format_command_hint('/help') or '/help'} for shortcuts."
                )
        except click.ClickException as exc:
            self.console.print(f"[{ERROR_STYLE}]{exc}[/]")

    def _prompt_instruction_view_toggle(self, agent_id: str) -> None:
        """Offer a prompt to expand or collapse the instruction preview after details."""
        if not getattr(self.console, "is_terminal", False):
            return

        while True:
            mode = "expanded" if self._instruction_preview_limit == 0 else "trimmed"
            self.console.print(
                f"[dim]Instruction view is {mode}. Press t (or Ctrl+T) to toggle, Enter to continue.[/dim]"
            )
            try:
                ch = click.getchar()
            except (EOFError, KeyboardInterrupt):  # pragma: no cover - defensive guard
                return

            if not self._handle_instruction_toggle_input(agent_id, ch):
                break

        if self._instruction_preview_limit == 0:
            self._instruction_preview_limit = DEFAULT_AGENT_INSTRUCTION_PREVIEW_LIMIT
        self.console.print("")

    def _handle_instruction_toggle_input(self, agent_id: str, ch: str) -> bool:
        """Process a single toggle keypress; return False when the loop should exit."""
        if ch in {"\r", "\n"}:
            return False

        lowered = ch.lower()
        if lowered == "t" or ch == "\x14":  # support literal 't' or Ctrl+T
            self._instruction_preview_limit = (
                DEFAULT_AGENT_INSTRUCTION_PREVIEW_LIMIT if self._instruction_preview_limit == 0 else 0
            )
            self._show_details(agent_id, enable_prompt=False)
            return True

        # Ignore other keys and continue prompting.
        return True

    def _after_agent_run(self) -> None:
        """Handle transcript viewer behaviour after a successful run."""
        payload, manifest = self.session._get_last_transcript()
        if not self._transcript_matches(payload, manifest):
            return
        assert isinstance(manifest, dict)
        run_id = str(manifest.get("run_id") or "")
        mark_ready = getattr(self.session, "mark_agent_transcript_ready", None)
        if callable(mark_ready):
            mark_ready(self._agent_id, run_id)
        if self._open_transcript_viewer():
            return
        self.console.print("[dim]Transcript viewer is unavailable in this environment.[/dim]")

    def _transcript_matches(self, payload: Any, manifest: Any) -> bool:
        """Return True when the latest transcript belongs to this agent."""
        if not payload or not isinstance(manifest, dict):
            return False
        manifest_dict = cast(dict[str, Any], manifest)
        if not manifest_dict.get("run_id"):
            return False
        return manifest_dict.get("agent_id") == self._agent_id

    def _open_transcript_viewer(self) -> bool:
        """Launch the transcript viewer when terminal support is available."""
        if not getattr(self.console, "is_terminal", False):
            return False
        try:
            current_agent = getattr(self.session, "_current_agent", None)
            self.session.open_transcript_viewer(announce=True)
            if getattr(self.session.console, "is_terminal", False):
                try:
                    self.session.console.clear()
                except Exception:  # pragma: no cover - defensive cleanup
                    pass
                if current_agent is not None:  # pragma: no cover - UI refresh best effort
                    try:
                        self.session._render_header(current_agent, focus_agent=True)
                    except Exception:  # pragma: no cover - defensive cleanup
                        pass
            return True
        except Exception:  # pragma: no cover - defensive cleanup
            return False

    @contextmanager
    def _bind_session_context(self) -> Any:
        """Temporarily attach this slash session to the Click context."""
        with bind_slash_session_context(self.session.ctx, self.session):
            yield

    def _run_agent(self, agent_id: str, message: str) -> str | tuple[str, list[str]] | None:
        """Execute the agents run command for the active agent."""
        if not message:
            return None

        try:
            self.session.notify_agent_run_started()
            if self._use_workspace_shell():
                reply = self._run_agent_workspace_inline(agent_id, message)
                self.session.last_run_input = message
                return reply

            with self._bind_session_context():
                self.session.ctx.invoke(
                    agents_run_command,
                    agent_ref=agent_id,
                    input_text=message,
                    verbose=False,
                )
            self.session.last_run_input = message
            self._after_agent_run()
            return None
        except click.ClickException as exc:
            self.console.print(f"[{ERROR_STYLE}]{exc}[/]")
            return None
        finally:
            try:
                self.session.notify_agent_run_finished()
            except Exception:
                pass

    def _run_agent_workspace_inline(self, agent_id: str, message: str) -> tuple[str, list[str]]:
        """Run agent with a silent renderer so workspace stays in Textual surface."""
        with self._bind_session_context():
            client = get_client(self.session.ctx)
            renderer = make_silent_renderer()
            result = client.agents.run_agent(
                agent_id=agent_id,
                message=message,
                files=[],
                agent_name=self._agent_name,
                tty=False,
                renderer=renderer,
            )

            store_transcript_for_session(
                self.session.ctx,
                renderer,
                final_result=result,
                agent_id=agent_id or None,
                agent_name=self._agent_name,
                model=self._extract_model_label(getattr(self.agent, "agent_config", None)) or None,
                source="slash",
            )

        self._mark_workspace_transcript_ready()
        return self._format_workspace_agent_reply(result), self._collect_workspace_run_status_lines(
            user_message=message
        )

    def _mark_workspace_transcript_ready(self) -> None:
        """Mark latest transcript as ready for this agent without launching viewer."""
        payload, manifest = self.session._get_last_transcript()
        if not self._transcript_matches(payload, manifest):
            return
        assert isinstance(manifest, dict)
        run_id = str(manifest.get("run_id") or "")
        mark_ready = getattr(self.session, "mark_agent_transcript_ready", None)
        if callable(mark_ready):
            mark_ready(self._agent_id, run_id)

    @staticmethod
    def _format_workspace_agent_reply(result: Any) -> str:
        """Normalize run output into workspace transcript text without truncation."""
        if result is None:
            return "Run finished."

        if isinstance(result, str):
            text = result
        else:
            try:
                text = json.dumps(result, ensure_ascii=False)
            except Exception:
                text = str(result)

        normalized = str(text).replace("\r\n", "\n").replace("\r", "\n").strip()
        if not normalized:
            return "Run finished."
        return normalized

    def _collect_workspace_run_status_lines(self, *, user_message: str | None = None) -> list[str]:
        """Extract compact post-run status lines for workspace transcript."""
        payload, manifest = self.session._get_last_transcript()
        if payload is None or not isinstance(manifest, dict):
            return []

        lines: list[str] = []

        meta = getattr(payload, "meta", None)
        if isinstance(meta, dict):
            raw_steps = meta.get("transcript_step_lines")
            lines.extend(self._workspace_step_summary_lines(raw_steps, user_message=user_message))

            duration = meta.get("final_duration_seconds")
            try:
                if isinstance(duration, (int, float)) and float(duration) > 0:
                    lines.append(f"completed in {float(duration):.1f}s")
            except Exception:
                pass

        return lines[:5]

    @staticmethod
    def _workspace_step_summary_lines(
        raw_steps: Any,
        *,
        limit: int = 3,
        user_message: str | None = None,
    ) -> list[str]:
        """Normalize transcript step rows into concise, user-facing step summaries."""
        if not isinstance(raw_steps, list):
            return []

        rows: list[str] = []
        normalized_user_message = " ".join(str(user_message or "").split()).strip().lower()
        for item in raw_steps:
            normalized = AgentRunSession._normalize_workspace_step_line(item)
            if normalized is None:
                continue
            if normalized_user_message and AgentRunSession._is_user_echo_step(normalized, normalized_user_message):
                continue
            rows.append(normalized)
            if len(rows) >= limit:
                break
        return rows

    @staticmethod
    def _is_user_echo_step(step_line: str, user_message: str) -> bool:
        """Detect low-signal step rows that only repeat the user prompt text."""
        lowered = step_line.lower().strip()
        for prefix in ("step:", "action:"):
            if lowered.startswith(prefix):
                detail = lowered[len(prefix) :].strip()
                return detail == user_message
        return False

    @staticmethod
    def _normalize_workspace_step_line(raw_step: Any) -> str | None:
        """Drop noisy step rows and keep concise action-oriented lines."""
        text = " ".join(str(raw_step).split()).strip()
        if not text:
            return None

        text = AgentRunSession._trim_workspace_step_prefix(text)
        text = AgentRunSession._trim_workspace_step_suffix(text)
        if not text:
            return None

        if AgentRunSession._is_workspace_step_noise(text):
            return None

        tool_row = AgentRunSession._normalize_workspace_tool_row(text)
        if tool_row is not None:
            return tool_row

        if AgentRunSession._is_low_signal_workspace_step_text(text):
            return None

        if AgentRunSession._has_workspace_step_prefix(text):
            return text[:140]

        compact = AgentRunSession._truncate_workspace_step_text(text)
        return f"step: {compact}"

    @staticmethod
    def _workspace_step_payload_prefixes() -> tuple[str, ...]:
        return ("request:", "payload:", "args:", "arguments:", "input:", "output:", "response:")

    @staticmethod
    def _truncate_workspace_step_text(text: str, *, limit: int = 132) -> str:
        if len(text) <= limit:
            return text
        return f"{text[: limit - 3]}..."

    @staticmethod
    def _is_workspace_step_noise(text: str) -> bool:
        lowered = text.lower()
        if text.startswith("🤖"):
            return True
        if re.search(r"\([0-9a-f]{8}-[0-9a-f-]{27,}\)", lowered):
            return True
        if lowered.startswith(("run ", "duration:")):
            return True
        return lowered.startswith(AgentRunSession._workspace_step_payload_prefixes())

    @staticmethod
    def _normalize_workspace_tool_row(text: str) -> str | None:
        if not text.startswith("🔧"):
            return None
        tool_detail = text[1:].strip()
        if not tool_detail:
            return None
        if tool_detail.lower().startswith(AgentRunSession._workspace_step_payload_prefixes()):
            return None
        return f"tool: {AgentRunSession._truncate_workspace_step_text(tool_detail)}"

    @staticmethod
    def _is_low_signal_workspace_step_text(text: str) -> bool:
        token_count = len(text.split())
        return token_count < 3 and not any(ch in text for ch in (":", "/", "-"))

    @staticmethod
    def _has_workspace_step_prefix(text: str) -> bool:
        return text.lower().startswith(("step:", "tool:", "call:", "action:"))

    @staticmethod
    def _trim_workspace_step_prefix(text: str) -> str:
        """Trim leading tree/indent glyphs from step rows without regex."""
        cleaned = str(text).lstrip()
        while cleaned and (cleaned[0] == "-" or 0x2500 <= ord(cleaned[0]) <= 0x257F):
            cleaned = cleaned[1:].lstrip()
        return cleaned

    @staticmethod
    def _trim_workspace_step_suffix(text: str) -> str:
        """Trim trailing checkmark glyphs and surrounding spaces from step rows."""
        cleaned = str(text).rstrip()
        while cleaned and cleaned[-1] in ("✓", "✔"):
            cleaned = cleaned[:-1].rstrip()
        return cleaned
