"""
FortyTwo API Client - Main package exports.

This module exports the primary user-facing components:
- Client: Synchronous API client
- AsyncClient: Asynchronous API client
- Config: Configuration class

Submodules:
- core: Shared domain logic, models, configuration
- resources: API resource definitions & managers
- exceptions: Exception classes
"""

from fortytwo.core import Config
from fortytwo.core.client import AsyncClient, Client


__all__ = [
    "AsyncClient",
    "Client",
    "Config",
]
