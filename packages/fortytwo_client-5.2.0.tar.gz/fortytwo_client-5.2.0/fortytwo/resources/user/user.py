"""
This module provides resources for getting users from the 42 API.
"""

from __future__ import annotations

from datetime import datetime

from pydantic import AliasPath, Field

from fortytwo.resources.campus.campus import Campus
from fortytwo.resources.campus_user.campus_user import CampusUser
from fortytwo.resources.model import Model


class UserImage(Model):
    """
    Represents a user's profile image with different versions.
    """

    link: str | None = Field(
        default=None,
        description="The URL of the original profile image.",
    )
    large: str | None = Field(
        default=None,
        validation_alias=AliasPath("versions", "large"),
        description="The URL of the large version of the profile image.",
    )
    medium: str | None = Field(
        default=None,
        validation_alias=AliasPath("versions", "medium"),
        description="The URL of the medium version of the profile image.",
    )
    small: str | None = Field(
        default=None,
        validation_alias=AliasPath("versions", "small"),
        description="The URL of the small version of the profile image.",
    )
    micro: str | None = Field(
        default=None,
        validation_alias=AliasPath("versions", "micro"),
        description="The URL of the micro version of the profile image.",
    )

    def __repr__(self) -> str:
        return f"<UserImage {self.link}>"

    def __str__(self) -> str:
        return self.link


class User(Model):
    """
    This class provides a representation of a 42 user.
    """

    id: int = Field(
        description="The unique identifier of the user.",
    )
    email: str = Field(
        description="The email address of the user.",
    )
    login: str = Field(
        description="The login (username) of the user.",
    )
    first_name: str = Field(
        description="The first name of the user.",
    )
    last_name: str = Field(
        description="The last name of the user.",
    )
    usual_full_name: str = Field(
        description="The user's usual full name.",
    )
    usual_first_name: str | None = Field(
        default=None,
        description="The user's usual first name.",
    )
    url: str = Field(
        description="The API URL of the user.",
    )
    phone: str = Field(
        description="The phone number of the user.",
    )
    displayname: str = Field(
        description="The display name of the user.",
    )

    kind: str = Field(
        description="The kind of user account.",
    )
    image: UserImage = Field(
        description="The user's profile image.",
    )
    staff: bool = Field(
        validation_alias="staff?",
        description="Whether the user is a staff member.",
    )
    correction_point: int = Field(
        description="The number of correction points the user has.",
    )
    pool_month: str | None = Field(
        default=None,
        description="The month of the user's piscine.",
    )
    pool_year: str | None = Field(
        default=None,
        description="The year of the user's piscine.",
    )
    location: str | None = Field(
        default=None,
        description="The current workstation of the user.",
    )
    wallet: int = Field(
        description="The user's wallet balance.",
    )

    anonymize_date: datetime | None = Field(
        default=None,
        description="The date the user will be anonymized.",
    )
    data_erasure_date: datetime | None = Field(
        default=None,
        description="The date the user's data will be erased.",
    )
    created_at: datetime = Field(
        description="The date and time the user account was created.",
    )
    updated_at: datetime = Field(
        description="The date and time the user account was last updated.",
    )
    alumnized_at: datetime | None = Field(
        default=None,
        description="The date the user was alumnized.",
    )

    alumni: bool = Field(
        validation_alias="alumni?",
        description="Whether the user is an alumni.",
    )
    active: bool = Field(
        validation_alias="active?",
        description="Whether the user account is active.",
    )

    projects_users: list[ProjectUser] = Field(
        default=[],
        description="The user's project enrollments.",
    )
    cursus_users: list[CursusUser] = Field(
        default=[],
        description="The user's cursus enrollments.",
    )
    campus: list[Campus] = Field(
        default=[],
        description="The campuses the user is associated with.",
    )
    campus_users: list[CampusUser] = Field(
        default=[],
        description="The user's campus associations.",
    )

    def __repr__(self) -> str:
        return f"<User {self.login}>"

    def __str__(self) -> str:
        return self.login


from fortytwo.resources.cursus_user.cursus_user import CursusUser
from fortytwo.resources.project_user.project_user import ProjectUser

User.model_rebuild()
