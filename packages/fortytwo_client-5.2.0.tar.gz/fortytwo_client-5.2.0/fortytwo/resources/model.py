"""
This module provides a base class for 42 API resource models.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class Model(BaseModel):
    """
    Base class for all 42 API resource models.
    """

    model_config = ConfigDict(
        arbitrary_types_allowed=True,
        populate_by_name=True,
    )


__all__ = [
    "Model",
]
