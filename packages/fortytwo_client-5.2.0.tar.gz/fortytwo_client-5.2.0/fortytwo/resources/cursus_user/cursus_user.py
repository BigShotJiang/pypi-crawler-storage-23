"""
This module provides resources for cursus user data from the 42 API.
"""

from __future__ import annotations

from datetime import datetime

from pydantic import Field

from fortytwo.resources.cursus.cursus import Cursus
from fortytwo.resources.model import Model


class CursusUser(Model):
    """
    This class provides a representation of a 42 cursus user.
    Represents a user's enrollment and progress in a specific cursus.
    """

    id: int = Field(
        description="The unique identifier of the cursus user record.",
    )
    begin_at: datetime = Field(
        description="The date and time the user began the cursus.",
    )
    end_at: datetime | None = Field(
        default=None,
        description="The date and time the user ended the cursus.",
    )
    grade: str | None = Field(
        default=None,
        description="The user's grade in the cursus.",
    )
    level: float = Field(
        description="The user's level in the cursus.",
    )
    cursus_id: int = Field(
        description="The ID of the cursus.",
    )
    has_coalition: bool = Field(
        description="Whether the user has a coalition in this cursus.",
    )
    blackholed_at: datetime | None = Field(
        default=None,
        description="The date and time the user was blackholed.",
    )
    created_at: datetime = Field(
        description="The date and time the record was created.",
    )
    updated_at: datetime = Field(
        description="The date and time the record was last updated.",
    )

    user: User = Field(
        description="The user enrolled in the cursus.",
    )
    cursus: Cursus = Field(
        description="The cursus the user is enrolled in.",
    )

    def __repr__(self) -> str:
        return f"<CursusUser {self.user.login} in {self.cursus.name}>"

    def __str__(self) -> str:
        return f"{self.user.login} - {self.cursus.name}"


# Deferred import to avoid circular dependency
from fortytwo.resources.user.user import User

CursusUser.model_rebuild()
