"""
This module provides resources for location of users from the 42 API.
"""

from __future__ import annotations

from datetime import datetime

from pydantic import Field

from fortytwo.resources.model import Model


class Location(Model):
    """
    This class provides a representation of a 42 location.

    Represents a location/session record tracking when and where
    a user logged into a campus workstation.
    """

    id: int = Field(
        description="The unique identifier of the location record.",
    )
    begin_at: datetime = Field(
        description="The date and time the session began.",
    )
    end_at: datetime | None = Field(
        default=None,
        description="The date and time the session ended.",
    )
    primary: bool = Field(
        description="Whether this is the user's primary session.",
    )
    floor: str | None = Field(
        default=None,
        description="The floor of the workstation.",
    )
    row: str | None = Field(
        default=None,
        description="The row of the workstation.",
    )
    post: str | None = Field(
        default=None,
        description="The post (seat) of the workstation.",
    )
    host: str = Field(
        description="The hostname of the workstation.",
    )
    campus_id: int = Field(
        description="The ID of the campus where the session took place.",
    )

    user: User = Field(
        description="The user who logged into the workstation.",
    )

    def __repr__(self) -> str:
        return f"<Location {self.id}>"

    def __str__(self) -> str:
        return str(self.id)


from fortytwo.resources.user.user import User

Location.model_rebuild()
