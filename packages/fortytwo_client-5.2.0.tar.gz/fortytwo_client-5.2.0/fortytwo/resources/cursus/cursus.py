"""
This module provides resources for cursus data from the 42 API.
"""

from __future__ import annotations

from datetime import datetime

from pydantic import Field

from fortytwo.resources.model import Model


class Cursus(Model):
    """
    This class provides a representation of a 42 cursus.
    """

    id: int = Field(
        description="The unique identifier of the cursus.",
    )
    created_at: datetime = Field(
        description="The date and time the cursus was created.",
    )
    name: str = Field(
        description="The name of the cursus.",
    )
    slug: str = Field(
        description="The URL-friendly slug of the cursus.",
    )
    kind: str = Field(
        description="The kind of cursus.",
    )

    def __repr__(self) -> str:
        return f"<Cursus {self.name}>"

    def __str__(self) -> str:
        return self.name
