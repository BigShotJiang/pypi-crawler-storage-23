from __future__ import annotations

from typing import TYPE_CHECKING

from fortytwo.parameter import Parameter, with_pagination
from fortytwo.resources.cursus.parameter import CursusParameters
from fortytwo.resources.cursus.resource import GetCursusById, GetCursuses


if TYPE_CHECKING:
    from fortytwo.core import ApiListResponse, ApiResponse, AsyncClient
    from fortytwo.resources.cursus.cursus import Cursus


class AsyncCursusManager:
    """
    Asynchronous manager for cursus-related API operations.
    """

    parameters = CursusParameters

    def __init__(self, client: AsyncClient) -> None:
        self.__client = client

    async def get_by_id(self, cursus_id: int, *params: Parameter) -> ApiResponse[Cursus]:
        """
        Get a cursus by ID.

        Args:
            cursus_id: The cursus ID to fetch
            *params: Additional request parameters

        Returns:
            Cursus object

        Raises:
            FortyTwoNotFoundException: If cursus is not found
            FortyTwoRequestException: If the request fails
        """
        return await self.__client.request(GetCursusById(cursus_id), *params)

    @with_pagination
    async def get_all(
        self,
        *params: Parameter,
        page: int | None = None,
        page_size: int | None = None,
    ) -> ApiListResponse[Cursus]:
        """
        Get all cursuses.

        Args:
            *params: Additional request parameters
            page: Page number to fetch (1-indexed)
            page_size: Number of items per page (1-100)

        Returns:
            List of Cursus objects

        Raises:
            FortyTwoRequestException: If the request fails
        """
        return await self.__client.request(GetCursuses(), *params)
