"""
This module provides a base class for 42 API resources.
"""
