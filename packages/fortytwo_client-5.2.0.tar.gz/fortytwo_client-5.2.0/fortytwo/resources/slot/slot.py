"""
This module provides resources for slot data from the 42 API.
"""

from __future__ import annotations

from datetime import datetime

from pydantic import Field

from fortytwo.resources.model import Model
from fortytwo.resources.user.user import User


class Slot(Model):
    """
    This class provides a representation of a 42 slot.
    """

    id: int = Field(
        description="The unique identifier of the slot.",
    )
    begin_at: datetime = Field(
        description="The date and time the slot begins.",
    )
    end_at: datetime = Field(
        description="The date and time the slot ends.",
    )
    scale_team: dict | None = Field(
        default=None,
        description="The scale team associated with the slot.",
    )
    user: User | str | None = Field(
        default=None,
        description="The user associated with the slot.",
    )

    def __repr__(self) -> str:
        return f"<Slot {self.id}>"

    def __str__(self) -> str:
        return str(self.id)
