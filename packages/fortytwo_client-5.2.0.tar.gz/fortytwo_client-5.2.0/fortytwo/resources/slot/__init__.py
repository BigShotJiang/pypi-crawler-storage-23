"""
Slot resource for the FortyTwo API.
"""

from fortytwo.resources.slot.manager import AsyncSlotManager, SyncSlotManager
from fortytwo.resources.slot.slot import Slot

__all__ = [
    "AsyncSlotManager",
    "Slot",
    "SyncSlotManager",
]
