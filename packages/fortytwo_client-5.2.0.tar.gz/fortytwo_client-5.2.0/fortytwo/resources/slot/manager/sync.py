from __future__ import annotations

from typing import TYPE_CHECKING

from fortytwo.parameter import Parameter, with_pagination
from fortytwo.resources.slot.parameter import SlotParameters
from fortytwo.resources.slot.resource import (
    GetMySlots,
    GetSlots,
    GetSlotsByProjectId,
    GetSlotsByUserId,
)

if TYPE_CHECKING:
    from fortytwo.core import ApiListResponse, Client
    from fortytwo.resources.slot.slot import Slot


class SyncSlotManager:
    """
    Synchronous manager for slot-related API operations.
    """

    parameters = SlotParameters

    def __init__(self, client: Client) -> None:
        self.__client = client

    @with_pagination
    def get_all(
        self,
        *params: Parameter,
        page: int | None = None,
        page_size: int | None = None,
    ) -> ApiListResponse[Slot]:
        """
        Get all slots.

        Args:
            *params: Additional request parameters
            page: Page number to fetch (1-indexed)
            page_size: Number of items per page (1-100)

        Returns:
            List of Slot objects

        Raises:
            FortyTwoRequestException: If the request fails
        """
        return self.__client.request(GetSlots(), *params)

    @with_pagination
    def get_by_project_id(
        self,
        project_id: int,
        *params: Parameter,
        page: int | None = None,
        page_size: int | None = None,
    ) -> ApiListResponse[Slot]:
        """
        Get all slots for a given project.

        Args:
            project_id: The project ID to fetch slots for
            *params: Additional request parameters
            page: Page number to fetch (1-indexed)
            page_size: Number of items per page (1-100)

        Returns:
            List of Slot objects

        Raises:
            FortyTwoRequestException: If the request fails
        """
        return self.__client.request(GetSlotsByProjectId(project_id), *params)

    @with_pagination
    def get_by_user_id(
        self,
        user_id: int,
        *params: Parameter,
        page: int | None = None,
        page_size: int | None = None,
    ) -> ApiListResponse[Slot]:
        """
        Get all slots for a given user.

        Args:
            user_id: The user ID to fetch slots for
            *params: Additional request parameters
            page: Page number to fetch (1-indexed)
            page_size: Number of items per page (1-100)

        Returns:
            List of Slot objects

        Raises:
            FortyTwoRequestException: If the request fails
        """
        return self.__client.request(GetSlotsByUserId(user_id), *params)

    @with_pagination
    def get_my_slots(
        self,
        *params: Parameter,
        page: int | None = None,
        page_size: int | None = None,
    ) -> ApiListResponse[Slot]:
        """
        Get the authenticated user's slots.

        Args:
            *params: Additional request parameters
            page: Page number to fetch (1-indexed)
            page_size: Number of items per page (1-100)

        Returns:
            List of Slot objects

        Raises:
            FortyTwoRequestException: If the request fails
        """
        return self.__client.request(GetMySlots(), *params)
