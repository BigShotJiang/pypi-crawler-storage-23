"""
Resources for fetching slot data from the 42 API.
"""

from typing import Any, Self

from fortytwo.resources.resource import ListResource, ResourceTemplate
from fortytwo.resources.slot.slot import Slot


class GetSlots(ListResource[Slot]):
    """Resource for fetching all slots.

    Returns a list of slots from the /slots endpoint.
    Supports filtering, sorting, ranging, and pagination via parameters.
    """

    method: str = "GET"
    __url: str = "/slots"

    @property
    def url(self: Self) -> str:
        return self.config.request_endpoint + self.__url

    def parse_response(self: Self, response_data: Any) -> ResourceTemplate:
        return [Slot.model_validate(slot) for slot in response_data]


class GetSlotsByProjectId(ListResource[Slot]):
    """Resource for fetching slots associated with a specific project.

    Returns a list of slots from the /projects/{project_id}/slots endpoint.

    Args:
        project_id: The ID of the project to fetch slots for.
    """

    method: str = "GET"
    __url: str = "/projects/%s/slots"

    def __init__(self: Self, project_id: int) -> None:
        self.project_id = project_id

    @property
    def url(self: Self) -> str:
        return self.config.request_endpoint + self.__url % self.project_id

    def parse_response(self: Self, response_data: Any) -> ResourceTemplate:
        return [Slot.model_validate(slot) for slot in response_data]


class GetSlotsByUserId(ListResource[Slot]):
    """Resource for fetching slots associated with a specific user.

    Returns a list of slots from the /users/{user_id}/slots endpoint.

    Args:
        user_id: The ID of the user to fetch slots for.
    """

    method: str = "GET"
    __url: str = "/users/%s/slots"

    def __init__(self: Self, user_id: int) -> None:
        self.user_id = user_id

    @property
    def url(self: Self) -> str:
        return self.config.request_endpoint + self.__url % self.user_id

    def parse_response(self: Self, response_data: Any) -> ResourceTemplate:
        return [Slot.model_validate(slot) for slot in response_data]


class GetMySlots(ListResource[Slot]):
    """Resource for fetching the authenticated user's slots.

    Returns a list of slots from the /me/slots endpoint.
    Supports filtering, sorting, ranging, and pagination via parameters.
    """

    method: str = "GET"
    __url: str = "/me/slots"

    @property
    def url(self: Self) -> str:
        return self.config.request_endpoint + self.__url

    def parse_response(self: Self, response_data: Any) -> ResourceTemplate:
        return [Slot.model_validate(slot) for slot in response_data]
