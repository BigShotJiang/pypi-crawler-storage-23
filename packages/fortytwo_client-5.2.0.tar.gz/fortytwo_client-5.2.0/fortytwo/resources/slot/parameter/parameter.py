from fortytwo.parameter import Parameter


class SlotParameter:
    """
    Parameter class specifically for slot resources with all supported 42 API query parameters.
    """

    @staticmethod
    def project_id(project_id: str | int) -> Parameter:
        """
        Filter slots by project ID.

        Args:
            project_id (Union[str, int]): The project ID to filter by.
        """
        return Parameter("project_id", project_id)

    @staticmethod
    def user_id(user_id: str | int) -> Parameter:
        """
        Filter slots by user ID.

        Args:
            user_id (Union[str, int]): The user ID to filter by.
        """
        return Parameter("user_id", user_id)
