from datetime import datetime

from fortytwo.parameter import Filter


class SlotFilter:
    """
    Filter class specifically for slot resources with all supported 42 API filters.
    """

    @staticmethod
    def by_id(slot_id: str | int) -> Filter:
        """
        Filter slots by ID.

        Args:
            slot_id (Union[str, int]): The slot ID to filter by.
        """
        return Filter("id", [slot_id])

    @staticmethod
    def by_begin_at(begin_at: str | datetime) -> Filter:
        """
        Filter slots by begin date.

        Args:
            begin_at (Union[str, datetime]): The begin date to filter by (ISO format string or datetime object).
        """
        return Filter("begin_at", [begin_at])

    @staticmethod
    def by_end_at(end_at: str | datetime) -> Filter:
        """
        Filter slots by end date.

        Args:
            end_at (Union[str, datetime]): The end date to filter by (ISO format string or datetime object).
        """
        return Filter("end_at", [end_at])

    @staticmethod
    def by_created_at(created_at: str | datetime) -> Filter:
        """
        Filter slots by creation date.

        Args:
            created_at (Union[str, datetime]): The creation date to filter by (ISO format string or datetime object).
        """
        return Filter("created_at", [created_at])

    @staticmethod
    def by_campus_id(campus_id: str | int) -> Filter:
        """
        Filter slots by campus ID.

        Args:
            campus_id (Union[str, int]): The campus ID to filter by.
        """
        return Filter("campus_id", [campus_id])

    @staticmethod
    def by_future(future: str | bool) -> Filter:
        """
        Filter slots by future status.

        Args:
            future (Union[str, bool]): Whether to filter for future slots only.
        """
        return Filter("future", [str(future).lower() if isinstance(future, bool) else future])

    @staticmethod
    def by_end(end: str | bool) -> Filter:
        """
        Filter slots by end status.

        Args:
            end (Union[str, bool]): Whether to filter for ended slots only.
        """
        return Filter("end", [str(end).lower() if isinstance(end, bool) else end])
