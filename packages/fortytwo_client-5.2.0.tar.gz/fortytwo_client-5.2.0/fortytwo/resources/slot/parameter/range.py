from datetime import datetime

from fortytwo.parameter import Range


class SlotRange:
    """
    Range class specifically for slot resources with all supported 42 API range fields.
    """

    @staticmethod
    def id_range(min_id: str | int | None = None, max_id: str | int | None = None) -> Range:
        """
        Filter slots by ID range.

        Args:
            min_id (Union[str, int], optional): Minimum ID value.
            max_id (Union[str, int], optional): Maximum ID value.
        """
        return Range("id", [min_id, max_id])

    @staticmethod
    def begin_at_range(
        start_date: str | datetime | None = None,
        end_date: str | datetime | None = None,
    ) -> Range:
        """
        Filter slots by begin date range.

        Args:
            start_date (Union[str, datetime], optional): Start date (ISO format string or datetime object).
            end_date (Union[str, datetime], optional): End date (ISO format string or datetime object).
        """
        return Range("begin_at", [start_date, end_date])

    @staticmethod
    def end_at_range(
        start_date: str | datetime | None = None,
        end_date: str | datetime | None = None,
    ) -> Range:
        """
        Filter slots by end date range.

        Args:
            start_date (Union[str, datetime], optional): Start date (ISO format string or datetime object).
            end_date (Union[str, datetime], optional): End date (ISO format string or datetime object).
        """
        return Range("end_at", [start_date, end_date])

    @staticmethod
    def created_at_range(
        start_date: str | datetime | None = None,
        end_date: str | datetime | None = None,
    ) -> Range:
        """
        Filter slots by created date range.

        Args:
            start_date (Union[str, datetime], optional): Start date (ISO format string or datetime object).
            end_date (Union[str, datetime], optional): End date (ISO format string or datetime object).
        """
        return Range("created_at", [start_date, end_date])
