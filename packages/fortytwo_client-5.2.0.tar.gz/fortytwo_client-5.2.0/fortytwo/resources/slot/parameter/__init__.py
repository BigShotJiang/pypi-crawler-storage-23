"""
Slot-specific query parameters for the FortyTwo API.
"""

from fortytwo.resources.slot.parameter.filter import SlotFilter
from fortytwo.resources.slot.parameter.parameter import SlotParameter
from fortytwo.resources.slot.parameter.range import SlotRange
from fortytwo.resources.slot.parameter.sort import SlotSort


class SlotParameters:
    filter = SlotFilter
    sort = SlotSort
    range = SlotRange
    parameter = SlotParameter
