"""
Project-specific query parameters for the FortyTwo API.

This module provides a namespace class for project filtering, sorting, and range parameters.
"""

from fortytwo.resources.project.parameter.filter import ProjectFilter
from fortytwo.resources.project.parameter.parameter import ProjectParameter
from fortytwo.resources.project.parameter.range import ProjectRange
from fortytwo.resources.project.parameter.sort import ProjectSort


class ProjectParameters:
    """
    Namespace for project-specific query parameters.
    """

    filter = ProjectFilter
    sort = ProjectSort
    range = ProjectRange
    parameter = ProjectParameter
