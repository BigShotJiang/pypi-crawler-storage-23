"""
Project resource for the FortyTwo API.

This module provides the Project model and ProjectManager for interacting
with project data.
"""

from fortytwo.resources.project.manager import AsyncProjectManager, SyncProjectManager
from fortytwo.resources.project.project import Project, ProjectReference


__all__ = [
    "AsyncProjectManager",
    "Project",
    "ProjectReference",
    "SyncProjectManager",
]
