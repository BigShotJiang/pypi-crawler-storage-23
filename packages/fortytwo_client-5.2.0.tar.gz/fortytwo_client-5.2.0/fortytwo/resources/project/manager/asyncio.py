from __future__ import annotations

from typing import TYPE_CHECKING

from fortytwo.parameter import Parameter, with_pagination
from fortytwo.resources.project.parameter import ProjectParameters
from fortytwo.resources.project.resource import (
    GetProjects,
    GetProjectsByCursusId,
    GetProjectsById,
    GetProjectsByProjectId,
)


if TYPE_CHECKING:
    from fortytwo.core import ApiListResponse, ApiResponse, AsyncClient
    from fortytwo.resources.project.project import Project


class AsyncProjectManager:
    """
    Asynchronous manager for project-related API operations.
    """

    parameters = ProjectParameters

    def __init__(self, client: AsyncClient) -> None:
        self.__client = client

    @with_pagination
    async def get_all(
        self,
        *params: Parameter,
        page: int | None = None,
        page_size: int | None = None,
    ) -> ApiListResponse[Project]:
        """
        Get all projects.

        Args:
            *params: Additional request parameters
            page: Page number to fetch (1-indexed)
            page_size: Number of items per page (1-100)

        Returns:
            List of Project objects

        Raises:
            FortyTwoRequestException: If the request fails
        """
        return await self.__client.request(GetProjects(), *params)

    @with_pagination
    async def get_by_cursus_id(
        self,
        cursus_id: int,
        *params: Parameter,
        page: int | None = None,
        page_size: int | None = None,
    ) -> ApiListResponse[Project]:
        """
        Get all projects for a specific cursus ID.

        Args:
            cursus_id: The cursus ID to fetch projects for
            *params: Additional request parameters
            page: Page number to fetch (1-indexed)
            page_size: Number of items per page (1-100)

        Returns:
            List of Project objects

        Raises:
            FortyTwoRequestException: If the request fails
        """
        return await self.__client.request(GetProjectsByCursusId(cursus_id), *params)

    async def get_by_id(self, project_id: int, *params: Parameter) -> ApiResponse[Project]:
        """
        Get a project by ID.

        Args:
            project_id: The project ID to fetch
            *params: Additional request parameters

        Returns:
            Project object

        Raises:
            FortyTwoNotFoundException: If project is not found
            FortyTwoRequestException: If the request fails
        """
        return await self.__client.request(GetProjectsById(project_id), *params)

    @with_pagination
    async def get_by_project_id(
        self,
        project_id: int,
        *params: Parameter,
        page: int | None = None,
        page_size: int | None = None,
    ) -> ApiListResponse[Project]:
        """
        Get all sub-projects for a specific parent project ID.

        Args:
            project_id: The parent project ID to fetch sub-projects for
            *params: Additional request parameters
            page: Page number to fetch (1-indexed)
            page_size: Number of items per page (1-100)

        Returns:
            List of Project objects

        Raises:
            FortyTwoRequestException: If the request fails
        """
        return await self.__client.request(GetProjectsByProjectId(project_id), *params)
