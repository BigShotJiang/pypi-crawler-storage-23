"""
This module provides resources for getting project users from the 42 API.
"""

from __future__ import annotations

from datetime import datetime

from pydantic import Field

from fortytwo.resources.model import Model
from fortytwo.resources.project.project import ProjectReference


class ProjectUser(Model):
    """
    This class provides a representation of a 42 project user.
    """

    id: int = Field(
        description="The unique identifier of the project user record.",
    )
    occurrence: int = Field(
        description="The occurrence number of the project attempt.",
    )
    final_mark: int | None = Field(
        default=None,
        description="The final mark for the project.",
    )
    status: str = Field(
        description="The status of the project attempt.",
    )
    validated: bool | None = Field(
        default=None,
        validation_alias="validated?",
        description="Whether the project was validated.",
    )
    current_team_id: int | None = Field(
        default=None,
        description="The ID of the current team.",
    )

    project: ProjectReference = Field(
        description="The project reference.",
    )
    user: User | None = Field(
        default=None,
        description="The user associated with the project.",
    )
    teams: list[Team] = Field(
        default=[],
        description="The teams for this project attempt.",
    )
    cursus_ids: list[int] = Field(
        default=[],
        description="The IDs of the cursus this project belongs to.",
    )

    marked_at: datetime | None = Field(
        default=None,
        description="The date and time the project was marked.",
    )
    marked: bool = Field(
        description="Whether the project has been marked.",
    )
    retriable_at: datetime | None = Field(
        default=None,
        description="The date and time the project becomes retriable.",
    )
    created_at: datetime = Field(
        description="The date and time the record was created.",
    )
    updated_at: datetime = Field(
        description="The date and time the record was last updated.",
    )

    def __repr__(self) -> str:
        return f"<ProjectUser {self.user.login if self.user else 'Unknown'} - {self.project.name}>"

    def __str__(self) -> str:
        return f"{self.user.login if self.user else 'Unknown'} - {self.project.name}"


from fortytwo.resources.team.team import Team
from fortytwo.resources.user.user import User

ProjectUser.model_rebuild()
