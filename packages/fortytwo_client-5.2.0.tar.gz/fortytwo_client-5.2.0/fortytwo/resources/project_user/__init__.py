"""
ProjectUser resource for the FortyTwo API.

This module provides the ProjectUser model and ProjectUserManager for interacting
with project-user relationship data.
"""

from fortytwo.resources.project_user.manager import AsyncProjectUserManager, SyncProjectUserManager
from fortytwo.resources.project_user.project_user import ProjectUser


__all__ = [
    "AsyncProjectUserManager",
    "ProjectUser",
    "SyncProjectUserManager",
]
