"""
Scale team-specific query parameters for the FortyTwo API.
"""

from fortytwo.resources.scale_team.parameter.filter import ScaleTeamFilter
from fortytwo.resources.scale_team.parameter.parameter import ScaleTeamParameter
from fortytwo.resources.scale_team.parameter.range import ScaleTeamRange
from fortytwo.resources.scale_team.parameter.sort import ScaleTeamSort


class ScaleTeamParameters:
    filter = ScaleTeamFilter
    sort = ScaleTeamSort
    range = ScaleTeamRange
    parameter = ScaleTeamParameter
