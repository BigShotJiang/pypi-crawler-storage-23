from datetime import datetime

from fortytwo.parameter import Filter


class ScaleTeamFilter:
    """
    Filter class specifically for scale team resources with all supported 42 API filters.
    """

    @staticmethod
    def by_id(scale_team_id: str | int) -> Filter:
        """
        Filter scale teams by ID.

        Args:
            scale_team_id (Union[str, int]): The scale team ID to filter by.
        """
        return Filter("id", [scale_team_id])

    @staticmethod
    def by_user_id(user_id: str | int) -> Filter:
        """
        Filter scale teams by user ID.

        Args:
            user_id (Union[str, int]): The user ID to filter by.
        """
        return Filter("user_id", [user_id])

    @staticmethod
    def by_begin_at(begin_at: str | datetime) -> Filter:
        """
        Filter scale teams by begin date.

        Args:
            begin_at (Union[str, datetime]): The begin date to filter by.
        """
        return Filter("begin_at", [begin_at])

    @staticmethod
    def by_created_at(created_at: str | datetime) -> Filter:
        """
        Filter scale teams by creation date.

        Args:
            created_at (Union[str, datetime]): The creation date to filter by.
        """
        return Filter("created_at", [created_at])

    @staticmethod
    def by_updated_at(updated_at: str | datetime) -> Filter:
        """
        Filter scale teams by update date.

        Args:
            updated_at (Union[str, datetime]): The update date to filter by.
        """
        return Filter("updated_at", [updated_at])

    @staticmethod
    def by_scale_id(scale_id: str | int) -> Filter:
        """
        Filter scale teams by scale ID.

        Args:
            scale_id (Union[str, int]): The scale ID to filter by.
        """
        return Filter("scale_id", [scale_id])

    @staticmethod
    def by_team_id(team_id: str | int) -> Filter:
        """
        Filter scale teams by team ID.

        Args:
            team_id (Union[str, int]): The team ID to filter by.
        """
        return Filter("team_id", [team_id])

    @staticmethod
    def by_comment(comment: str) -> Filter:
        """
        Filter scale teams by comment.

        Args:
            comment (str): The comment to filter by.
        """
        return Filter("comment", [comment])

    @staticmethod
    def by_old_feedback(old_feedback: str) -> Filter:
        """
        Filter scale teams by old feedback.

        Args:
            old_feedback (str): The old feedback to filter by.
        """
        return Filter("old_feedback", [old_feedback])

    @staticmethod
    def by_feedback_rating(feedback_rating: str | int) -> Filter:
        """
        Filter scale teams by feedback rating.

        Args:
            feedback_rating (Union[str, int]): The feedback rating to filter by.
        """
        return Filter("feedback_rating", [feedback_rating])

    @staticmethod
    def by_final_mark(final_mark: str | int) -> Filter:
        """
        Filter scale teams by final mark.

        Args:
            final_mark (Union[str, int]): The final mark to filter by.
        """
        return Filter("final_mark", [final_mark])

    @staticmethod
    def by_truant_id(truant_id: str | int) -> Filter:
        """
        Filter scale teams by truant ID.

        Args:
            truant_id (Union[str, int]): The truant ID to filter by.
        """
        return Filter("truant_id", [truant_id])

    @staticmethod
    def by_flag_id(flag_id: str | int) -> Filter:
        """
        Filter scale teams by flag ID.

        Args:
            flag_id (Union[str, int]): The flag ID to filter by.
        """
        return Filter("flag_id", [flag_id])

    @staticmethod
    def by_token(token: str) -> Filter:
        """
        Filter scale teams by token.

        Args:
            token (str): The token to filter by.
        """
        return Filter("token", [token])

    @staticmethod
    def by_ip(ip: str) -> Filter:
        """
        Filter scale teams by IP address.

        Args:
            ip (str): The IP address to filter by.
        """
        return Filter("ip", [ip])

    @staticmethod
    def by_internship_id(internship_id: str | int) -> Filter:
        """
        Filter scale teams by internship ID.

        Args:
            internship_id (Union[str, int]): The internship ID to filter by.
        """
        return Filter("internship_id", [internship_id])

    @staticmethod
    def by_filled_at(filled_at: str | datetime) -> Filter:
        """
        Filter scale teams by filled date.

        Args:
            filled_at (Union[str, datetime]): The filled date to filter by.
        """
        return Filter("filled_at", [filled_at])

    @staticmethod
    def by_campus_id(campus_id: str | int) -> Filter:
        """
        Filter scale teams by campus ID.

        Args:
            campus_id (Union[str, int]): The campus ID to filter by.
        """
        return Filter("campus_id", [campus_id])

    @staticmethod
    def by_cursus_id(cursus_id: str | int) -> Filter:
        """
        Filter scale teams by cursus ID.

        Args:
            cursus_id (Union[str, int]): The cursus ID to filter by.
        """
        return Filter("cursus_id", [cursus_id])

    @staticmethod
    def by_future(future: str | bool) -> Filter:
        """
        Filter scale teams by future status.

        Args:
            future (Union[str, bool]): Whether to filter for future scale teams only.
        """
        return Filter("future", [str(future).lower() if isinstance(future, bool) else future])

    @staticmethod
    def by_filled(filled: str | bool) -> Filter:
        """
        Filter scale teams by filled status.

        Args:
            filled (Union[str, bool]): Whether to filter for filled scale teams only.
        """
        return Filter("filled", [str(filled).lower() if isinstance(filled, bool) else filled])
