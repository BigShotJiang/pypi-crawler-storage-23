from fortytwo.parameter import Sort, SortDirection


class ScaleTeamSort:
    """
    Sort class specifically for scale team resources with all supported 42 API sort fields.
    """

    @staticmethod
    def by_id(direction: SortDirection = SortDirection.DESCENDING) -> Sort:
        """
        Sort by ID (default descending).

        Args:
            direction (SortDirection): Sort direction.
        """
        return Sort([("id", direction)])

    @staticmethod
    def by_user_id(direction: SortDirection = SortDirection.ASCENDING) -> Sort:
        """
        Sort by user ID.

        Args:
            direction (SortDirection): Sort direction.
        """
        return Sort([("user_id", direction)])

    @staticmethod
    def by_begin_at(direction: SortDirection = SortDirection.DESCENDING) -> Sort:
        """
        Sort by begin date.

        Args:
            direction (SortDirection): Sort direction.
        """
        return Sort([("begin_at", direction)])

    @staticmethod
    def by_created_at(direction: SortDirection = SortDirection.DESCENDING) -> Sort:
        """
        Sort by created date.

        Args:
            direction (SortDirection): Sort direction.
        """
        return Sort([("created_at", direction)])

    @staticmethod
    def by_updated_at(direction: SortDirection = SortDirection.DESCENDING) -> Sort:
        """
        Sort by updated date.

        Args:
            direction (SortDirection): Sort direction.
        """
        return Sort([("updated_at", direction)])

    @staticmethod
    def by_scale_id(direction: SortDirection = SortDirection.ASCENDING) -> Sort:
        """
        Sort by scale ID.

        Args:
            direction (SortDirection): Sort direction.
        """
        return Sort([("scale_id", direction)])

    @staticmethod
    def by_team_id(direction: SortDirection = SortDirection.ASCENDING) -> Sort:
        """
        Sort by team ID.

        Args:
            direction (SortDirection): Sort direction.
        """
        return Sort([("team_id", direction)])

    @staticmethod
    def by_comment(direction: SortDirection = SortDirection.ASCENDING) -> Sort:
        """
        Sort by comment.

        Args:
            direction (SortDirection): Sort direction.
        """
        return Sort([("comment", direction)])

    @staticmethod
    def by_old_feedback(direction: SortDirection = SortDirection.ASCENDING) -> Sort:
        """
        Sort by old feedback.

        Args:
            direction (SortDirection): Sort direction.
        """
        return Sort([("old_feedback", direction)])

    @staticmethod
    def by_feedback_rating(direction: SortDirection = SortDirection.ASCENDING) -> Sort:
        """
        Sort by feedback rating.

        Args:
            direction (SortDirection): Sort direction.
        """
        return Sort([("feedback_rating", direction)])

    @staticmethod
    def by_final_mark(direction: SortDirection = SortDirection.DESCENDING) -> Sort:
        """
        Sort by final mark.

        Args:
            direction (SortDirection): Sort direction.
        """
        return Sort([("final_mark", direction)])

    @staticmethod
    def by_truant_id(direction: SortDirection = SortDirection.ASCENDING) -> Sort:
        """
        Sort by truant ID.

        Args:
            direction (SortDirection): Sort direction.
        """
        return Sort([("truant_id", direction)])

    @staticmethod
    def by_flag_id(direction: SortDirection = SortDirection.ASCENDING) -> Sort:
        """
        Sort by flag ID.

        Args:
            direction (SortDirection): Sort direction.
        """
        return Sort([("flag_id", direction)])

    @staticmethod
    def by_token(direction: SortDirection = SortDirection.ASCENDING) -> Sort:
        """
        Sort by token.

        Args:
            direction (SortDirection): Sort direction.
        """
        return Sort([("token", direction)])

    @staticmethod
    def by_ip(direction: SortDirection = SortDirection.ASCENDING) -> Sort:
        """
        Sort by IP address.

        Args:
            direction (SortDirection): Sort direction.
        """
        return Sort([("ip", direction)])

    @staticmethod
    def by_internship_id(direction: SortDirection = SortDirection.ASCENDING) -> Sort:
        """
        Sort by internship ID.

        Args:
            direction (SortDirection): Sort direction.
        """
        return Sort([("internship_id", direction)])

    @staticmethod
    def by_filled_at(direction: SortDirection = SortDirection.DESCENDING) -> Sort:
        """
        Sort by filled date.

        Args:
            direction (SortDirection): Sort direction.
        """
        return Sort([("filled_at", direction)])
