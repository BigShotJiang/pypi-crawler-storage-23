from fortytwo.parameter import Parameter


class ScaleTeamParameter:
    """
    Parameter class specifically for scale team resources with all supported 42 API query parameters.
    """

    @staticmethod
    def project_session_id(project_session_id: str | int) -> Parameter:
        """
        Filter scale teams by project session ID.

        Args:
            project_session_id (Union[str, int]): The project session ID to filter by.
        """
        return Parameter("project_session_id", project_session_id)

    @staticmethod
    def project_id(project_id: str | int) -> Parameter:
        """
        Filter scale teams by project ID.

        Args:
            project_id (Union[str, int]): The project ID to filter by.
        """
        return Parameter("project_id", project_id)

    @staticmethod
    def user_id(user_id: str | int) -> Parameter:
        """
        Filter scale teams by user ID.

        Args:
            user_id (Union[str, int]): The user ID to filter by.
        """
        return Parameter("user_id", user_id)
