from datetime import datetime

from fortytwo.parameter import Range


class ScaleTeamRange:
    """
    Range class specifically for scale team resources with all supported 42 API range fields.
    """

    @staticmethod
    def id_range(min_id: str | int | None = None, max_id: str | int | None = None) -> Range:
        """
        Filter scale teams by ID range.

        Args:
            min_id (Union[str, int], optional): Minimum ID value.
            max_id (Union[str, int], optional): Maximum ID value.
        """
        return Range("id", [min_id, max_id])

    @staticmethod
    def user_id_range(min_id: str | int | None = None, max_id: str | int | None = None) -> Range:
        """
        Filter scale teams by user ID range.

        Args:
            min_id (Union[str, int], optional): Minimum user ID value.
            max_id (Union[str, int], optional): Maximum user ID value.
        """
        return Range("user_id", [min_id, max_id])

    @staticmethod
    def begin_at_range(
        start_date: str | datetime | None = None,
        end_date: str | datetime | None = None,
    ) -> Range:
        """
        Filter scale teams by begin date range.

        Args:
            start_date (Union[str, datetime], optional): Start date (ISO format string or datetime object).
            end_date (Union[str, datetime], optional): End date (ISO format string or datetime object).
        """
        return Range("begin_at", [start_date, end_date])

    @staticmethod
    def created_at_range(
        start_date: str | datetime | None = None,
        end_date: str | datetime | None = None,
    ) -> Range:
        """
        Filter scale teams by created date range.

        Args:
            start_date (Union[str, datetime], optional): Start date (ISO format string or datetime object).
            end_date (Union[str, datetime], optional): End date (ISO format string or datetime object).
        """
        return Range("created_at", [start_date, end_date])

    @staticmethod
    def updated_at_range(
        start_date: str | datetime | None = None,
        end_date: str | datetime | None = None,
    ) -> Range:
        """
        Filter scale teams by updated date range.

        Args:
            start_date (Union[str, datetime], optional): Start date (ISO format string or datetime object).
            end_date (Union[str, datetime], optional): End date (ISO format string or datetime object).
        """
        return Range("updated_at", [start_date, end_date])

    @staticmethod
    def scale_id_range(min_id: str | int | None = None, max_id: str | int | None = None) -> Range:
        """
        Filter scale teams by scale ID range.

        Args:
            min_id (Union[str, int], optional): Minimum scale ID value.
            max_id (Union[str, int], optional): Maximum scale ID value.
        """
        return Range("scale_id", [min_id, max_id])

    @staticmethod
    def team_id_range(min_id: str | int | None = None, max_id: str | int | None = None) -> Range:
        """
        Filter scale teams by team ID range.

        Args:
            min_id (Union[str, int], optional): Minimum team ID value.
            max_id (Union[str, int], optional): Maximum team ID value.
        """
        return Range("team_id", [min_id, max_id])

    @staticmethod
    def feedback_rating_range(
        min_rating: str | int | None = None, max_rating: str | int | None = None
    ) -> Range:
        """
        Filter scale teams by feedback rating range.

        Args:
            min_rating (Union[str, int], optional): Minimum feedback rating value.
            max_rating (Union[str, int], optional): Maximum feedback rating value.
        """
        return Range("feedback_rating", [min_rating, max_rating])

    @staticmethod
    def final_mark_range(
        min_mark: str | int | None = None, max_mark: str | int | None = None
    ) -> Range:
        """
        Filter scale teams by final mark range.

        Args:
            min_mark (Union[str, int], optional): Minimum final mark value.
            max_mark (Union[str, int], optional): Maximum final mark value.
        """
        return Range("final_mark", [min_mark, max_mark])

    @staticmethod
    def filled_at_range(
        start_date: str | datetime | None = None,
        end_date: str | datetime | None = None,
    ) -> Range:
        """
        Filter scale teams by filled date range.

        Args:
            start_date (Union[str, datetime], optional): Start date (ISO format string or datetime object).
            end_date (Union[str, datetime], optional): End date (ISO format string or datetime object).
        """
        return Range("filled_at", [start_date, end_date])
