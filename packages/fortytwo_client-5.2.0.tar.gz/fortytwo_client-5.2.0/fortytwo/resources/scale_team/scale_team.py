"""
This module provides resources for scale team data from the 42 API.
"""

from __future__ import annotations

from datetime import datetime

from pydantic import Field

from fortytwo.resources.model import Model


class ScaleTeam(Model):
    """
    This class provides a representation of a 42 scale team.
    """

    id: int = Field(
        description="The unique identifier of the scale team.",
    )
    scale_id: int = Field(
        description="The ID of the scale used for this evaluation.",
    )
    comment: str | None = Field(
        default=None,
        description="The corrector's comment.",
    )
    created_at: datetime = Field(
        description="The date and time the scale team was created.",
    )
    updated_at: datetime = Field(
        description="The date and time the scale team was last updated.",
    )
    feedback: str | None = Field(
        default=None,
        description="The feedback left by the corrected.",
    )
    feedback_rating: int | None = Field(
        default=None,
        description="The rating of the feedback.",
    )
    final_mark: int | None = Field(
        default=None,
        description="The final mark given by the corrector.",
    )
    flag: dict | None = Field(
        default=None,
        description="The flag associated with the scale team.",
    )
    begin_at: datetime | None = Field(
        default=None,
        description="The date and time the evaluation begins.",
    )
    correcteds: list | str | None = Field(
        default=None,
        description="The corrected users or 'invisible' if hidden.",
    )
    corrector: dict | str | None = Field(
        default=None,
        description="The corrector user or 'invisible' if hidden.",
    )
    truant: dict | None = Field(
        default=None,
        description="The truant information.",
    )
    filled_at: datetime | None = Field(
        default=None,
        description="The date and time the evaluation was filled.",
    )
    scale: dict | None = Field(
        default=None,
        description="The scale details used for this evaluation.",
    )
    feedbacks: list | None = Field(
        default=None,
        description="The list of feedbacks.",
    )

    def __repr__(self) -> str:
        return f"<ScaleTeam {self.id}>"

    def __str__(self) -> str:
        return str(self.id)
