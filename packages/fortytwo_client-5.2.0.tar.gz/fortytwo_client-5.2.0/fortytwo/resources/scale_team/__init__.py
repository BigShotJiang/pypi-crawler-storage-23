"""
Scale team resource for the FortyTwo API.
"""

from fortytwo.resources.scale_team.manager import (
    AsyncScaleTeamManager,
    SyncScaleTeamManager,
)
from fortytwo.resources.scale_team.scale_team import ScaleTeam

__all__ = [
    "AsyncScaleTeamManager",
    "ScaleTeam",
    "SyncScaleTeamManager",
]
