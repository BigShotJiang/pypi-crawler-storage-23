"""
Resources for fetching scale team data from the 42 API.
"""

from typing import Any, Self

from fortytwo.resources.resource import ListResource, Resource, ResourceTemplate
from fortytwo.resources.scale_team.scale_team import ScaleTeam


class GetScaleTeams(ListResource[ScaleTeam]):
    """Resource for fetching all scale teams.

    Returns a list of scale teams from the /scale_teams endpoint.
    Supports filtering, sorting, ranging, and pagination via parameters.
    """

    method: str = "GET"
    __url: str = "/scale_teams"

    @property
    def url(self: Self) -> str:
        return self.config.request_endpoint + self.__url

    def parse_response(self: Self, response_data: Any) -> ResourceTemplate:
        return [ScaleTeam.model_validate(st) for st in response_data]


class GetScaleTeamById(Resource[ScaleTeam]):
    """Resource for fetching a specific scale team by ID.

    Args:
        scale_team_id: The ID of the scale team to fetch.
    """

    method: str = "GET"
    __url: str = "/scale_teams/%s"

    def __init__(self: Self, scale_team_id: int) -> None:
        self.scale_team_id = scale_team_id

    @property
    def url(self: Self) -> str:
        return self.config.request_endpoint + self.__url % self.scale_team_id

    def parse_response(self: Self, response_data: Any) -> ResourceTemplate:
        return ScaleTeam.model_validate(response_data)


class GetScaleTeamsByProjectSessionId(ListResource[ScaleTeam]):
    """Resource for fetching scale teams for a specific project session.

    Returns a list of scale teams from the
    /project_sessions/{project_session_id}/scale_teams endpoint.

    Args:
        project_session_id: The ID of the project session to fetch scale teams for.
    """

    method: str = "GET"
    __url: str = "/project_sessions/%s/scale_teams"

    def __init__(self: Self, project_session_id: int) -> None:
        self.project_session_id = project_session_id

    @property
    def url(self: Self) -> str:
        return self.config.request_endpoint + self.__url % self.project_session_id

    def parse_response(self: Self, response_data: Any) -> ResourceTemplate:
        return [ScaleTeam.model_validate(st) for st in response_data]


class GetScaleTeamByProjectSessionIdAndId(Resource[ScaleTeam]):
    """Resource for fetching a specific scale team by ID within a project session.

    Args:
        project_session_id: The ID of the project session.
        scale_team_id: The ID of the scale team to fetch.
    """

    method: str = "GET"
    __url: str = "/project_sessions/%s/scale_teams/%s"

    def __init__(self: Self, project_session_id: int, scale_team_id: int) -> None:
        self.project_session_id = project_session_id
        self.scale_team_id = scale_team_id

    @property
    def url(self: Self) -> str:
        return self.config.request_endpoint + self.__url % (
            self.project_session_id,
            self.scale_team_id,
        )

    def parse_response(self: Self, response_data: Any) -> ResourceTemplate:
        return ScaleTeam.model_validate(response_data)


class GetScaleTeamsByProjectId(ListResource[ScaleTeam]):
    """Resource for fetching scale teams for a specific project.

    Returns a list of scale teams from the /projects/{project_id}/scale_teams endpoint.

    Args:
        project_id: The ID of the project to fetch scale teams for.
    """

    method: str = "GET"
    __url: str = "/projects/%s/scale_teams"

    def __init__(self: Self, project_id: int) -> None:
        self.project_id = project_id

    @property
    def url(self: Self) -> str:
        return self.config.request_endpoint + self.__url % self.project_id

    def parse_response(self: Self, response_data: Any) -> ResourceTemplate:
        return [ScaleTeam.model_validate(st) for st in response_data]


class GetScaleTeamsByUserId(ListResource[ScaleTeam]):
    """Resource for fetching all scale teams for a specific user.

    Returns a list of scale teams from the /users/{user_id}/scale_teams endpoint.

    Args:
        user_id: The ID of the user to fetch scale teams for.
    """

    method: str = "GET"
    __url: str = "/users/%s/scale_teams"

    def __init__(self: Self, user_id: int) -> None:
        self.user_id = user_id

    @property
    def url(self: Self) -> str:
        return self.config.request_endpoint + self.__url % self.user_id

    def parse_response(self: Self, response_data: Any) -> ResourceTemplate:
        return [ScaleTeam.model_validate(st) for st in response_data]


class GetScaleTeamsByUserIdAsCorrector(ListResource[ScaleTeam]):
    """Resource for fetching scale teams where a user is the corrector.

    Returns a list of scale teams from the
    /users/{user_id}/scale_teams/as_corrector endpoint.

    Args:
        user_id: The ID of the user to fetch corrector scale teams for.
    """

    method: str = "GET"
    __url: str = "/users/%s/scale_teams/as_corrector"

    def __init__(self: Self, user_id: int) -> None:
        self.user_id = user_id

    @property
    def url(self: Self) -> str:
        return self.config.request_endpoint + self.__url % self.user_id

    def parse_response(self: Self, response_data: Any) -> ResourceTemplate:
        return [ScaleTeam.model_validate(st) for st in response_data]


class GetScaleTeamsByUserIdAsCorrected(ListResource[ScaleTeam]):
    """Resource for fetching scale teams where a user is corrected.

    Returns a list of scale teams from the
    /users/{user_id}/scale_teams/as_corrected endpoint.

    Args:
        user_id: The ID of the user to fetch corrected scale teams for.
    """

    method: str = "GET"
    __url: str = "/users/%s/scale_teams/as_corrected"

    def __init__(self: Self, user_id: int) -> None:
        self.user_id = user_id

    @property
    def url(self: Self) -> str:
        return self.config.request_endpoint + self.__url % self.user_id

    def parse_response(self: Self, response_data: Any) -> ResourceTemplate:
        return [ScaleTeam.model_validate(st) for st in response_data]


class GetMyScaleTeams(ListResource[ScaleTeam]):
    """Resource for fetching the authenticated user's scale teams.

    Returns a list of scale teams from the /me/scale_teams endpoint.
    Supports filtering, sorting, ranging, and pagination via parameters.
    """

    method: str = "GET"
    __url: str = "/me/scale_teams"

    @property
    def url(self: Self) -> str:
        return self.config.request_endpoint + self.__url

    def parse_response(self: Self, response_data: Any) -> ResourceTemplate:
        return [ScaleTeam.model_validate(st) for st in response_data]


class GetMyScaleTeamsAsCorrector(ListResource[ScaleTeam]):
    """Resource for fetching the authenticated user's scale teams as corrector.

    Returns a list of scale teams from the /me/scale_teams/as_corrector endpoint.
    """

    method: str = "GET"
    __url: str = "/me/scale_teams/as_corrector"

    @property
    def url(self: Self) -> str:
        return self.config.request_endpoint + self.__url

    def parse_response(self: Self, response_data: Any) -> ResourceTemplate:
        return [ScaleTeam.model_validate(st) for st in response_data]


class GetMyScaleTeamsAsCorrected(ListResource[ScaleTeam]):
    """Resource for fetching the authenticated user's scale teams as corrected.

    Returns a list of scale teams from the /me/scale_teams/as_corrected endpoint.
    """

    method: str = "GET"
    __url: str = "/me/scale_teams/as_corrected"

    @property
    def url(self: Self) -> str:
        return self.config.request_endpoint + self.__url

    def parse_response(self: Self, response_data: Any) -> ResourceTemplate:
        return [ScaleTeam.model_validate(st) for st in response_data]
