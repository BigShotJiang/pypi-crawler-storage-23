from fortytwo.resources.campus.manager.asyncio import AsyncCampusManager
from fortytwo.resources.campus.manager.sync import SyncCampusManager


__all__ = [
    "AsyncCampusManager",
    "SyncCampusManager",
]
