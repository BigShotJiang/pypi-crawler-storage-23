"""
This module provides resources for campus data from the 42 API.
"""

from __future__ import annotations

from pydantic import Field

from fortytwo.resources.model import Model


class CampusLanguage(Model):
    """
    Represents a campus language.
    """

    id: int = Field(
        description="The unique identifier of the language.",
    )
    name: str = Field(
        description="The name of the language.",
    )
    identifier: str = Field(
        description="The language identifier code.",
    )


class Campus(Model):
    """
    This class provides a representation of a 42 campus.
    """

    id: int = Field(
        description="The unique identifier of the campus.",
    )
    name: str = Field(
        description="The name of the campus.",
    )
    time_zone: str = Field(
        description="The time zone of the campus.",
    )
    language: CampusLanguage = Field(
        description="The primary language of the campus.",
    )
    users_count: int = Field(
        description="The number of users at the campus.",
    )
    vogsphere_id: int | None = Field(
        default=None,
        description="The Vogsphere ID of the campus.",
    )
    country: str = Field(
        description="The country where the campus is located.",
    )
    address: str = Field(
        description="The street address of the campus.",
    )
    zip: str = Field(
        description="The postal code of the campus.",
    )
    city: str = Field(
        description="The city where the campus is located.",
    )
    website: str = Field(
        description="The website URL of the campus.",
    )
    facebook: str = Field(
        description="The Facebook page URL of the campus.",
    )
    twitter: str = Field(
        description="The Twitter handle of the campus.",
    )
    active: bool = Field(
        description="Whether the campus is currently active.",
    )
    public: bool = Field(
        description="Whether the campus is publicly visible.",
    )
    email_extension: str | None = Field(
        default=None,
        description="The email domain extension for the campus.",
    )
    default_hidden_phone: bool = Field(
        description="Whether phone numbers are hidden by default.",
    )

    def __repr__(self) -> str:
        return f"<Campus {self.name}>"

    def __str__(self) -> str:
        return self.name
