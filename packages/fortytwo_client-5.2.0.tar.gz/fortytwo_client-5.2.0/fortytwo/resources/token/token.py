"""
This module provides resources for getting token information.
"""

from __future__ import annotations

from pydantic import AliasPath, Field

from fortytwo.resources.model import Model


class Token(Model):
    """
    This class provides a representation of a token.
    """

    owner: int | None = Field(
        default=None,
        validation_alias="resource_owner_id",
        description="The resource owner ID associated with the token.",
    )
    scopes: list[str] = Field(
        description="The list of scopes granted to the token.",
    )
    expires: int = Field(
        validation_alias="expires_in_seconds",
        description="The number of seconds until the token expires.",
    )
    uid: str = Field(
        validation_alias=AliasPath("application", "uid"),
        description="The application UID associated with the token.",
    )

    def __repr__(self) -> str:
        return f"<Token {self.uid}>"

    def __str__(self) -> str:
        return self.uid
