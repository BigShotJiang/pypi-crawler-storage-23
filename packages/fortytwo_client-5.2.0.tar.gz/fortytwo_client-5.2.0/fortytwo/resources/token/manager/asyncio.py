from __future__ import annotations

from typing import TYPE_CHECKING

from fortytwo.resources.token.resource import GetToken


if TYPE_CHECKING:
    from fortytwo.core import AsyncClient, ApiResponse
    from fortytwo.parameter import Parameter
    from fortytwo.resources.token.token import Token


class AsyncTokenManager:
    """
    Asynchronous manager for token-related API operations.
    """

    def __init__(self, client: AsyncClient) -> None:
        self.__client = client

    async def get(self, *params: Parameter) -> ApiResponse[Token]:
        """
        Get token information.

        Args:
            *params: Additional request parameters

        Returns:
            Token object

        Raises:
            FortyTwoRequestException: If the request fails
        """
        return await self.__client.request(GetToken(), *params)
