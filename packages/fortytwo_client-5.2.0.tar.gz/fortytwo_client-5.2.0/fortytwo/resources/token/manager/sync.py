from __future__ import annotations

from typing import TYPE_CHECKING

from fortytwo.resources.token.resource import GetToken


if TYPE_CHECKING:
    from fortytwo.core import Client, ApiResponse
    from fortytwo.parameter import Parameter
    from fortytwo.resources.token.token import Token


class SyncTokenManager:
    """
    Synchronous manager for token-related API operations.
    """

    def __init__(self, client: Client) -> None:
        self.__client = client

    def get(self, *params: Parameter) -> ApiResponse[Token]:
        """
        Get token information.

        Args:
            *params: Additional request parameters

        Returns:
            Token object

        Raises:
            FortyTwoRequestException: If the request fails
        """
        return self.__client.request(GetToken(), *params)
