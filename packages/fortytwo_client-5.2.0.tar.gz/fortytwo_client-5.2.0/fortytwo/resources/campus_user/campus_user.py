"""
This module provides resources for campus user data from the 42 API.
"""

from __future__ import annotations

from datetime import datetime

from pydantic import Field

from fortytwo.resources.model import Model


class CampusUser(Model):
    """
    This class provides a representation of a 42 campus user.
    Represents a user's association with a specific campus.
    """

    id: int = Field(
        description="The unique identifier of the campus user record.",
    )
    user_id: int = Field(
        description="The ID of the user.",
    )
    campus_id: int = Field(
        description="The ID of the campus.",
    )
    is_primary: bool = Field(
        description="Whether this is the user's primary campus.",
    )
    created_at: datetime = Field(
        description="The date and time the record was created.",
    )
    updated_at: datetime = Field(
        description="The date and time the record was last updated.",
    )

    def __repr__(self) -> str:
        return f"<CampusUser {self.user_id} at campus {self.campus_id}>"

    def __str__(self) -> str:
        primary_status = "primary" if self.is_primary else "secondary"
        return f"User {self.user_id} - Campus {self.campus_id} ({primary_status})"
