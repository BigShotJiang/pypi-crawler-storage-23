"""
Team resource for the FortyTwo API.

This module provides the Team and TeamUser models and TeamManager for interacting
with team data.
"""

from fortytwo.resources.team.manager import AsyncTeamManager, SyncTeamManager
from fortytwo.resources.team.team import Team, TeamUser


__all__ = [
    "AsyncTeamManager",
    "SyncTeamManager",
    "Team",
    "TeamUser",
]
