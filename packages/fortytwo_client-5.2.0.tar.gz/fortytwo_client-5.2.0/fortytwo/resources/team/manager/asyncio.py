from __future__ import annotations

from typing import TYPE_CHECKING

from fortytwo.parameter import Parameter, with_pagination
from fortytwo.resources.team.parameter import TeamParameters
from fortytwo.resources.team.resource import (
    GetTeams,
    GetTeamsByCursusId,
    GetTeamsByProjectId,
    GetTeamsByUserId,
    GetTeamsByUserIdAndProjectId,
)


if TYPE_CHECKING:
    from fortytwo.core import ApiListResponse, AsyncClient
    from fortytwo.resources.team.team import Team


class AsyncTeamManager:
    """
    Asynchronous manager for team-related API operations.
    """

    parameters = TeamParameters

    def __init__(self, client: AsyncClient) -> None:
        self.__client = client

    @with_pagination
    async def get_all(
        self,
        *params: Parameter,
        page: int | None = None,
        page_size: int | None = None,
    ) -> ApiListResponse[Team]:
        """
        Get all teams.

        Args:
            *params: Additional request parameters
            page: Page number to fetch (1-indexed)
            page_size: Number of items per page (1-100)

        Returns:
            List of Team objects

        Raises:
            FortyTwoRequestException: If the request fails
        """
        return await self.__client.request(GetTeams(), *params)

    @with_pagination
    async def get_by_cursus_id(
        self,
        cursus_id: int,
        *params: Parameter,
        page: int | None = None,
        page_size: int | None = None,
    ) -> ApiListResponse[Team]:
        """
        Get all teams for a specific cursus ID.

        Args:
            cursus_id: The cursus ID to fetch teams for
            *params: Additional request parameters
            page: Page number to fetch (1-indexed)
            page_size: Number of items per page (1-100)

        Returns:
            List of Team objects

        Raises:
            FortyTwoRequestException: If the request fails
        """
        return await self.__client.request(GetTeamsByCursusId(cursus_id), *params)

    @with_pagination
    async def get_by_user_id(
        self,
        user_id: int,
        *params: Parameter,
        page: int | None = None,
        page_size: int | None = None,
    ) -> ApiListResponse[Team]:
        """
        Get all teams for a specific user ID.

        Args:
            user_id: The user ID to fetch teams for
            *params: Additional request parameters
            page: Page number to fetch (1-indexed)
            page_size: Number of items per page (1-100)

        Returns:
            List of Team objects

        Raises:
            FortyTwoRequestException: If the request fails
        """
        return await self.__client.request(GetTeamsByUserId(user_id), *params)

    @with_pagination
    async def get_by_project_id(
        self,
        project_id: int,
        *params: Parameter,
        page: int | None = None,
        page_size: int | None = None,
    ) -> ApiListResponse[Team]:
        """
        Get all teams for a specific project ID.

        Args:
            project_id: The project ID to fetch teams for
            *params: Additional request parameters
            page: Page number to fetch (1-indexed)
            page_size: Number of items per page (1-100)

        Returns:
            List of Team objects

        Raises:
            FortyTwoRequestException: If the request fails
        """
        return await self.__client.request(GetTeamsByProjectId(project_id), *params)

    @with_pagination
    async def get_by_user_id_and_project_id(
        self,
        user_id: int,
        project_id: int,
        *params: Parameter,
        page: int | None = None,
        page_size: int | None = None,
    ) -> ApiListResponse[Team]:
        """
        Get all teams for a specific user and project.

        Args:
            user_id: The user ID to fetch teams for
            project_id: The project ID to fetch teams for
            *params: Additional request parameters
            page: Page number to fetch (1-indexed)
            page_size: Number of items per page (1-100)

        Returns:
            List of Team objects

        Raises:
            FortyTwoRequestException: If the request fails
        """
        return await self.__client.request(
            GetTeamsByUserIdAndProjectId(user_id, project_id), *params
        )
