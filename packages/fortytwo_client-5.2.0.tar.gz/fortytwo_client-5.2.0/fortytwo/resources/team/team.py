"""
This module provides resources for team data from the 42 API.
"""

from __future__ import annotations

from datetime import datetime

from pydantic import Field

from fortytwo.resources.model import Model


class TeamUser(Model):
    """
    Lightweight representation of a user within a team.
    """

    id: int = Field(
        description="The unique identifier of the user.",
    )
    login: str = Field(
        description="The login (username) of the user.",
    )
    url: str = Field(
        description="The API URL of the user.",
    )
    leader: bool = Field(
        description="Whether this user is the team leader.",
    )
    occurrence: int = Field(
        description="The occurrence number of the user's attempt.",
    )
    validated: bool = Field(
        description="Whether the user's attempt was validated.",
    )
    projects_user_id: int = Field(
        description="The ID of the associated project user record.",
    )

    def __repr__(self) -> str:
        leader_badge = " (leader)" if self.leader else ""
        return f"<TeamUser {self.login}{leader_badge}>"

    def __str__(self) -> str:
        return self.login


class Team(Model):
    """
    This class provides a representation of a 42 team.
    """

    id: int = Field(
        description="The unique identifier of the team.",
    )
    name: str = Field(
        description="The name of the team.",
    )
    url: str = Field(
        description="The API URL of the team.",
    )
    final_mark: int | None = Field(
        default=None,
        description="The final mark for the team.",
    )
    project_id: int = Field(
        description="The ID of the project this team is for.",
    )

    created_at: datetime = Field(
        description="The date and time the team was created.",
    )
    updated_at: datetime = Field(
        description="The date and time the team was last updated.",
    )

    status: str = Field(
        description="The status of the team.",
    )
    terminating_at: datetime | None = Field(
        default=None,
        description="The date and time the team is terminating.",
    )

    users: list[TeamUser] = Field(
        default=[],
        description="The users in the team.",
    )

    locked: bool = Field(
        validation_alias="locked?",
        description="Whether the team is locked.",
    )
    validated: bool | None = Field(
        default=None,
        validation_alias="validated?",
        description="Whether the team was validated.",
    )
    closed: bool = Field(
        validation_alias="closed?",
        description="Whether the team is closed.",
    )

    repo_url: str | None = Field(
        default=None,
        description="The URL of the team's repository.",
    )
    repo_uuid: str = Field(
        description="The UUID of the team's repository.",
    )

    locked_at: datetime | None = Field(
        default=None,
        description="The date and time the team was locked.",
    )
    closed_at: datetime | None = Field(
        default=None,
        description="The date and time the team was closed.",
    )

    project_session_id: int = Field(
        description="The ID of the project session.",
    )

    def __repr__(self) -> str:
        return f"<Team {self.name}>"

    def __str__(self) -> str:
        return self.name
