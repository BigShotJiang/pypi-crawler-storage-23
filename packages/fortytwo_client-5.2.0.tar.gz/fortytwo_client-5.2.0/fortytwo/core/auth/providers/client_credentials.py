"""
Client Credentials grant the standard server-to-server OAuth2 flow.
"""

from __future__ import annotations

from fortytwo.core.auth.providers.provider import AuthProvider, TokenRequest


class ClientCredentialsProvider(AuthProvider):
    """
    Builds token request payloads for the OAuth2 **client_credentials** grant.

    Args:
        client_id: The 42 API application UID.
        client_secret: The 42 API application secret.
        scopes: OAuth scopes to request.  Defaults to ``["public"]``.
    """

    def __init__(
        self,
        client_id: str,
        client_secret: str,
        scopes: list[str] | None = None,
    ) -> None:
        self.__client_id = client_id
        self.__client_secret = client_secret
        self.__scopes = scopes or ["public"]

    def build_token_request(self) -> TokenRequest:
        return TokenRequest(
            data={
                "grant_type": "client_credentials",
                "client_id": self.__client_id,
                "client_secret": self.__client_secret,
                "scope": " ".join(self.__scopes),
            },
        )

    def build_refresh_request(self, refresh_token: str) -> TokenRequest:
        return TokenRequest(
            data={
                "grant_type": "refresh_token",
                "client_id": self.__client_id,
                "client_secret": self.__client_secret,
                "refresh_token": refresh_token,
            },
        )
