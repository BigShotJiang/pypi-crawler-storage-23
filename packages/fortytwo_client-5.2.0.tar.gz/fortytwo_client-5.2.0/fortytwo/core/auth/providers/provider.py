"""
Auth provider protocol, the strategy for building OAuth2 token requests.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass(frozen=True)
class TokenRequest:
    """
    Payload for an OAuth2 token endpoint `POST`.

    Attributes:
        data: Form-encoded key/value pairs sent in the request body.
    """

    data: dict[str, str]


class AuthProvider(ABC):
    """
    Strategy that knows how to build OAuth2 token request payloads.
    """

    @abstractmethod
    def build_token_request(self) -> TokenRequest:
        """
        Build the POST data for initial token acquisition.
        """

    @abstractmethod
    def build_refresh_request(self, refresh_token: str) -> TokenRequest:
        """
        Build the POST data for refreshing an existing token.
        """
