"""
Asynchronous HTTP transport using httpx.AsyncClient.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from fortytwo.core.request.transport.base import BaseTransport


if TYPE_CHECKING:
    import httpx

    from fortytwo.core.auth.tokens import Tokens
    from fortytwo.parameter import Parameter
    from fortytwo.resources.resource import Resource


class AsyncTransport(BaseTransport):
    """
    Sends an asynchronous HTTP request via `httpx.AsyncClient`.
    """

    def __init__(self, client: httpx.AsyncClient) -> None:
        super().__init__()
        self.__client = client

    async def send(
        self,
        resource: Resource,
        params: list[Parameter],
        tokens: Tokens,
        timeout: int | None = None,
    ) -> httpx.Response:
        """
        Execute an asynchronous HTTP request.

        Args:
            resource: The API resource (provides method, url).
            params: Query parameters for the request.
            tokens: Authentication tokens.
            timeout: Request timeout in seconds.

        Returns:
            The HTTP response.

        Raises:
            httpx.HTTPStatusError: If the HTTP request returns a bad status.
        """
        kwargs = self._build_request_kwargs(resource, params, tokens, timeout)

        self._log_request(resource, params)
        response = await self.__client.request(**kwargs)
        self._log_response(response)

        response.raise_for_status()
        return response
