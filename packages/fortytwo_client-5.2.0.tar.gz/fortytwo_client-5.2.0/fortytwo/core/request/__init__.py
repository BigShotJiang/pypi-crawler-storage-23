"""
Request handling module for the FortyTwo API client.
"""

from fortytwo.core.request.response import ApiListResponse, ApiResponse


__all__ = [
    "ApiListResponse",
    "ApiResponse",
]
