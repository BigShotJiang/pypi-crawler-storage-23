"""
Client module, user-facing sync and async API clients.
"""

from fortytwo.core.client.asyncio import AsyncClient
from fortytwo.core.client.sync import SyncClient as Client


__all__ = [
    "AsyncClient",
    "Client",
]
