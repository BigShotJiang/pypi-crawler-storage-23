from __future__ import annotations

from typing import TYPE_CHECKING, Self

import httpx

from fortytwo.core.auth import (
    AsyncAuthenticator,
    AuthProvider,
    ClientCredentialsProvider,
)
from fortytwo.core.config import Config
from fortytwo.core.request.handler import AsyncRequestHandler
from fortytwo.resources.campus.manager.asyncio import AsyncCampusManager
from fortytwo.resources.campus_user.manager.asyncio import AsyncCampusUserManager
from fortytwo.resources.cursus.manager.asyncio import AsyncCursusManager
from fortytwo.resources.cursus_user.manager.asyncio import AsyncCursusUserManager
from fortytwo.resources.location.manager.asyncio import AsyncLocationManager
from fortytwo.resources.project.manager.asyncio import AsyncProjectManager
from fortytwo.resources.project_user.manager.asyncio import AsyncProjectUserManager
from fortytwo.resources.scale_team.manager.asyncio import AsyncScaleTeamManager
from fortytwo.resources.slot.manager.asyncio import AsyncSlotManager
from fortytwo.resources.team.manager.asyncio import AsyncTeamManager
from fortytwo.resources.token.manager.asyncio import AsyncTokenManager
from fortytwo.resources.user.manager.asyncio import AsyncUserManager


if TYPE_CHECKING:
    from fortytwo.core.request.response import ApiListResponse, ApiResponse
    from fortytwo.parameter import Parameter
    from fortytwo.resources.resource import Resource, ResourceTemplate


class AsyncClient:
    """
    Asynchronous client for the 42 School API.

    Usage::

        async with AsyncClient(client_id, client_secret) as client:
            users = await client.users.get_all()

    Or without the context manager::

        client = AsyncClient(client_id, client_secret)
        users = await client.users.get_all()
        await client.close()
    """

    def __init__(
        self,
        client_id: str | None = None,
        client_secret: str | None = None,
        client_scopes: list[str] | None = None,
        *,
        provider: AuthProvider | None = None,
        config: Config | None = None,
    ) -> None:
        """
        Initialize the AsyncClient with authentication and configuration.

        Either supply ``client_id`` / ``client_secret`` (uses the default
        client-credentials grant), or pass a custom ``provider`` for other
        OAuth2 flows.

        Args:
            client_id: The client ID for authentication.
            client_secret: The client secret for authentication.
            client_scopes: Optional list of OAuth scopes. Defaults to ``["public"]``.
            provider: Custom :class:`AuthProvider` instance.
            config: Optional configuration object.
        """
        self.__config = config or Config()
        self.__http_client = httpx.AsyncClient()

        if provider is None:
            provider = ClientCredentialsProvider(
                client_id=client_id,
                client_secret=client_secret,
                scopes=client_scopes,
            )

        self.__authenticator = AsyncAuthenticator(
            self.__config,
            provider,
            self.__http_client,
        )

        self.__request_handler = AsyncRequestHandler(
            self.__config,
            self.__authenticator,
            self.__http_client,
        )

        # fmt: off
        self.campuses       = AsyncCampusManager(self)
        self.campus_users   = AsyncCampusUserManager(self)
        self.cursuses       = AsyncCursusManager(self)
        self.cursus_users   = AsyncCursusUserManager(self)
        self.users          = AsyncUserManager(self)
        self.locations      = AsyncLocationManager(self)
        self.projects       = AsyncProjectManager(self)
        self.project_users  = AsyncProjectUserManager(self)
        self.scale_teams    = AsyncScaleTeamManager(self)
        self.slots          = AsyncSlotManager(self)
        self.teams          = AsyncTeamManager(self)
        self.tokens         = AsyncTokenManager(self)
        # fmt: on

    @property
    def config(self) -> Config:
        """
        The client's configuration settings.
        """
        return self.__config

    @config.setter
    def config(self, config: Config) -> None:
        """
        Update the client's configuration settings.

        Args:
            config: The new configuration to apply.
        """
        self.__config = config
        self.__authenticator.config = config
        self.__request_handler.config = config

    @property
    def authenticator(self) -> AsyncAuthenticator:
        """
        The token lifecycle manager.
        """
        return self.__authenticator

    async def request(
        self,
        resource: Resource[ResourceTemplate],
        *params: Parameter,
    ) -> ApiResponse[ResourceTemplate] | ApiListResponse[ResourceTemplate]:
        """
        Send an asynchronous request to the API and return the response.

        Args:
            resource: The resource to fetch.
            *params: The parameters for the request.

        Returns:
            An ApiResponse wrapping the parsed data and response metadata.

        Raises:
            FortyTwoNotFoundException: If the resource is not found (404).
            FortyTwoAuthException: If authentication fails.
            FortyTwoRequestException: If the request fails for other reasons.
        """
        return await self.__request_handler.request(resource, *params)

    async def close(self) -> None:
        """
        Close the underlying HTTP client and release resources.
        """
        await self.__http_client.aclose()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
