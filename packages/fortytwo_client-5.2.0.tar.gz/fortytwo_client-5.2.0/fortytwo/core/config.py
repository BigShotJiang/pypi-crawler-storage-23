from pydantic import BaseModel, ConfigDict, Field


# fmt: off
FORTYTWO_REQUEST_TIMEOUT                = 120  # seconds
FORTYTWO_REQUEST_ENDPOINT               = "https://api.intra.42.fr/v2"
FORTYTWO_REQUEST_ENDPOINT_OAUTH         = "https://api.intra.42.fr/oauth/token"
FORTYTWO_REQUEST_ENDPOINT_AUTHORIZE     = "https://api.intra.42.fr/oauth/authorize"

FORTYTWO_REQUEST_PER_SECOND             = 2
FORTYTWO_REQUEST_PER_SECOND_RETRIES     = 5
FORTYTWO_REQUEST_PER_SECOND_RETRY_DELAY = 1 # seconds

FORTYTWO_REQUEST_PER_HOUR               = 1200
FORTYTWO_REQUEST_PER_HOUR_MARGIN        = 0
# fmt: on


class Config(BaseModel):
    """
    Configuration for the 42 API Client.
    """

    model_config = ConfigDict(validate_by_name=True)

    request_timeout: int = Field(
        default=FORTYTWO_REQUEST_TIMEOUT,
        description="Request timeout in seconds.",
        examples=[30, 60, 120],
    )
    request_endpoint: str = Field(
        default=FORTYTWO_REQUEST_ENDPOINT,
        description="Base API endpoint URL.",
        examples=["https://api.intra.42.fr/v2/"],
    )
    request_endpoint_oauth: str = Field(
        default=FORTYTWO_REQUEST_ENDPOINT_OAUTH,
        description="OAuth token endpoint URL.",
        examples=["https://api.intra.42.fr/oauth/token"],
    )
    request_endpoint_authorize: str = Field(
        default=FORTYTWO_REQUEST_ENDPOINT_AUTHORIZE,
        description="OAuth authorization endpoint URL.",
        examples=["https://api.intra.42.fr/oauth/authorize"],
    )
    requests_per_second: int = Field(
        default=FORTYTWO_REQUEST_PER_SECOND,
        description="Maximum number of requests per second.",
        examples=[1, 2, 5],
    )
    requests_per_second_retries: int = Field(
        default=FORTYTWO_REQUEST_PER_SECOND_RETRIES,
        description="Number of retries when rate limited per second.",
        examples=[3, 5, 10],
    )
    requests_per_second_retry_delay: int = Field(
        default=FORTYTWO_REQUEST_PER_SECOND_RETRY_DELAY,
        description="Delay between retries when rate limited per second in seconds.",
        examples=[1, 2, 5],
    )
    requests_per_hour_margin: int = Field(
        default=FORTYTWO_REQUEST_PER_HOUR_MARGIN,
        description="Margin to avoid hitting the hourly rate limit.",
        examples=[0, 10, 20],
    )
