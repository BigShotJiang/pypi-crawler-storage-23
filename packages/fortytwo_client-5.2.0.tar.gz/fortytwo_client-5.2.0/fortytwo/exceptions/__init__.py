"""
Exceptions module for the fortytwo package.
"""

from fortytwo.exceptions.exceptions import (
    FortyTwoAuthException,
    FortyTwoClientException,
    FortyTwoConfigurationException,
    FortyTwoNetworkException,
    FortyTwoNotFoundException,
    FortyTwoParsingException,
    FortyTwoRateLimitException,
    FortyTwoRequestException,
    FortyTwoServerException,
    FortyTwoUnauthorizedException,
)


__all__ = [
    "FortyTwoAuthException",
    "FortyTwoClientException",
    "FortyTwoConfigurationException",
    "FortyTwoNetworkException",
    "FortyTwoNotFoundException",
    "FortyTwoParsingException",
    "FortyTwoRateLimitException",
    "FortyTwoRequestException",
    "FortyTwoServerException",
    "FortyTwoUnauthorizedException",
]
