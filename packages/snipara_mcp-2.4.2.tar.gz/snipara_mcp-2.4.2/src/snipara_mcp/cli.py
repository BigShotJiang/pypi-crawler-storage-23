#!/usr/bin/env python3
"""
Snipara CLI - Project initialization and management.

This module provides CLI commands for setting up Snipara in a project.

Usage:
    snipara-init           # Initialize Snipara in current directory
    snipara-init --help    # Show help
"""

import asyncio
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Optional

import httpx

from .auth import get_api_url, get_auth_header, load_tokens, TOKEN_FILE


# ANSI colors for terminal output
class Colors:
    BLUE = "\033[94m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    RED = "\033[91m"
    BOLD = "\033[1m"
    END = "\033[0m"


def color(text: str, c: str) -> str:
    """Wrap text in ANSI color codes."""
    # Disable colors if not a TTY
    if not sys.stdout.isatty():
        return text
    return f"{c}{text}{Colors.END}"


def detect_project_type() -> dict:
    """
    Detect the project type based on config files in current directory.

    Returns:
        dict with keys: type, framework, language
    """
    cwd = Path.cwd()

    # Check for various project files
    if (cwd / "package.json").exists():
        pkg = json.loads((cwd / "package.json").read_text())
        deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}

        if "next" in deps:
            return {"type": "node", "framework": "Next.js", "language": "TypeScript" if (cwd / "tsconfig.json").exists() else "JavaScript"}
        elif "react" in deps:
            return {"type": "node", "framework": "React", "language": "TypeScript" if (cwd / "tsconfig.json").exists() else "JavaScript"}
        elif "vue" in deps:
            return {"type": "node", "framework": "Vue", "language": "TypeScript" if (cwd / "tsconfig.json").exists() else "JavaScript"}
        elif "svelte" in deps:
            return {"type": "node", "framework": "Svelte", "language": "TypeScript" if (cwd / "tsconfig.json").exists() else "JavaScript"}
        else:
            return {"type": "node", "framework": "Node.js", "language": "TypeScript" if (cwd / "tsconfig.json").exists() else "JavaScript"}

    elif (cwd / "pyproject.toml").exists() or (cwd / "setup.py").exists():
        return {"type": "python", "framework": "Python", "language": "Python"}

    elif (cwd / "go.mod").exists():
        return {"type": "go", "framework": "Go", "language": "Go"}

    elif (cwd / "Cargo.toml").exists():
        return {"type": "rust", "framework": "Rust", "language": "Rust"}

    elif (cwd / "pom.xml").exists() or (cwd / "build.gradle").exists():
        return {"type": "java", "framework": "Java/Kotlin", "language": "Java"}

    else:
        return {"type": "unknown", "framework": "Unknown", "language": "Unknown"}


def get_git_remote() -> Optional[str]:
    """
    Get the git remote URL for the current repository.

    Returns:
        Remote URL or None if not a git repo
    """
    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            capture_output=True,
            text=True,
            cwd=Path.cwd(),
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    return None


def slugify(name: str) -> str:
    """
    Convert a name to a URL-safe slug.

    Examples:
        "My Project" -> "my-project"
        "github.com/user/my-repo" -> "my-repo"
        "my_project.git" -> "my-project"
    """
    # Extract repo name from git URL
    if "/" in name:
        name = name.split("/")[-1]

    # Remove .git suffix
    if name.endswith(".git"):
        name = name[:-4]

    # Lowercase and replace non-alphanumeric with hyphens
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower())

    # Remove leading/trailing hyphens
    slug = slug.strip("-")

    return slug or "my-project"


def generate_mcp_json(slug: str, api_url: str = "https://api.snipara.com", api_key: str | None = None) -> dict:
    """Generate .mcp.json content for the project.

    Args:
        slug: Project slug for the MCP endpoint
        api_url: API base URL
        api_key: If provided, uses actual key; otherwise uses ${SNIPARA_API_KEY} placeholder
    """
    return {
        "mcpServers": {
            "snipara": {
                "type": "http",
                "url": f"{api_url}/mcp/{slug}",
                "headers": {
                    "X-API-Key": api_key if api_key else "${SNIPARA_API_KEY}"
                }
            }
        }
    }


def write_mcp_json(slug: str, dry_run: bool = False, api_key: str | None = None) -> bool:
    """
    Write .mcp.json file to current directory.

    Args:
        slug: Project slug for the MCP endpoint
        dry_run: If True, only preview changes
        api_key: If provided, uses actual key instead of env var placeholder

    Returns:
        True if file was created/updated, False if skipped
    """
    mcp_path = Path.cwd() / ".mcp.json"
    content = generate_mcp_json(slug, api_key=api_key)

    if dry_run:
        print(f"  Would create: {mcp_path}")
        print(f"  Content: {json.dumps(content, indent=2)[:100]}...")
        return True

    # Check if file exists
    if mcp_path.exists():
        existing = json.loads(mcp_path.read_text())
        if "snipara" in existing.get("mcpServers", {}):
            # Check if we should update the API key
            current_key = existing["mcpServers"]["snipara"].get("headers", {}).get("X-API-Key", "")
            new_key = content["mcpServers"]["snipara"]["headers"]["X-API-Key"]

            # Update if: new key is actual (not placeholder) AND different from current
            if api_key and current_key != new_key:
                existing["mcpServers"]["snipara"]["headers"]["X-API-Key"] = new_key
                mcp_path.write_text(json.dumps(existing, indent=2) + "\n")
                print(f"  {color('Updated:', Colors.GREEN)} .mcp.json (new API key: {new_key[:12]}...)")
                return True
            else:
                print(f"  {color('Exists:', Colors.YELLOW)} .mcp.json (snipara already configured)")
                return False
        # Merge with existing (snipara not yet configured)
        existing.setdefault("mcpServers", {})
        existing["mcpServers"]["snipara"] = content["mcpServers"]["snipara"]
        content = existing

    mcp_path.write_text(json.dumps(content, indent=2) + "\n")
    if api_key:
        print(f"  {color('Created:', Colors.GREEN)} .mcp.json (with API key: {api_key[:12]}...)")
    else:
        print(f"  {color('Created:', Colors.GREEN)} .mcp.json (uses ${{SNIPARA_API_KEY}} env var)")
    return True


def update_env_example(dry_run: bool = False) -> bool:
    """
    Add SNIPARA_API_KEY to .env.example if not present.

    Returns:
        True if file was updated, False if skipped
    """
    env_path = Path.cwd() / ".env.example"
    env_local_path = Path.cwd() / ".env.local.example"

    # Try .env.example first, then .env.local.example
    target_path = env_path if env_path.exists() else env_local_path if env_local_path.exists() else env_path

    line_to_add = "SNIPARA_API_KEY=rlm_your_api_key_here\n"

    if dry_run:
        print(f"  Would update: {target_path}")
        print(f"  Add line: SNIPARA_API_KEY=...")
        return True

    # Check if already present
    if target_path.exists():
        content = target_path.read_text()
        if "SNIPARA_API_KEY" in content:
            print(f"  {color('Exists:', Colors.YELLOW)} {target_path.name} (SNIPARA_API_KEY already present)")
            return False
        # Append to existing file
        with open(target_path, "a") as f:
            if not content.endswith("\n"):
                f.write("\n")
            f.write("\n# Snipara API Key (get from https://snipara.com/dashboard)\n")
            f.write(line_to_add)
    else:
        # Create new file
        with open(target_path, "w") as f:
            f.write("# Environment Variables\n\n")
            f.write("# Snipara API Key (get from https://snipara.com/dashboard)\n")
            f.write(line_to_add)

    print(f"  {color('Updated:', Colors.GREEN)} {target_path.name}")
    return True


async def upload_document(
    api_url: str,
    slug: str,
    path: str,
    content: str,
    auth_header: str,
) -> bool:
    """
    Upload a document to Snipara.

    Returns:
        True if successful, False otherwise
    """
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            # Use the MCP tool endpoint
            response = await client.post(
                f"{api_url}/mcp/{slug}",
                headers={
                    "Content-Type": "application/json",
                    **({"Authorization": auth_header} if auth_header.startswith("Bearer") else {"X-API-Key": auth_header}),
                },
                json={
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "tools/call",
                    "params": {
                        "name": "rlm_upload_document",
                        "arguments": {
                            "path": path,
                            "content": content,
                        }
                    }
                }
            )

            if response.status_code == 200:
                result = response.json()
                if "result" in result:
                    return True
                elif "error" in result:
                    print(f"    {color('Error:', Colors.RED)} {result['error'].get('message', 'Unknown error')}")
            else:
                print(f"    {color('Error:', Colors.RED)} HTTP {response.status_code}")

    except Exception as e:
        print(f"    {color('Error:', Colors.RED)} {e}")

    return False


async def test_connection(api_url: str, slug: str, auth_header: str) -> bool:
    """
    Test connection to Snipara API.

    Returns:
        True if connection successful, False otherwise
    """
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(
                f"{api_url}/mcp/{slug}",
                headers={
                    "Content-Type": "application/json",
                    **({"Authorization": auth_header} if auth_header.startswith("Bearer") else {"X-API-Key": auth_header}),
                },
                json={
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "tools/call",
                    "params": {
                        "name": "rlm_stats",
                        "arguments": {}
                    }
                }
            )

            if response.status_code == 200:
                result = response.json()
                if "result" in result:
                    return True

    except Exception:
        pass

    return False


async def init_async(
    slug: Optional[str] = None,
    upload_docs: bool = True,
    dry_run: bool = False,
    skip_test: bool = False,
) -> int:
    """
    Initialize Snipara in the current directory.

    Returns:
        Exit code (0 = success, 1 = error)
    """
    cwd = Path.cwd()
    api_url = os.environ.get("SNIPARA_API_URL", "https://api.snipara.com")

    print()
    print(color("Snipara Init", Colors.BOLD))
    print("=" * 40)
    print()

    # Step 1: Detect project
    print(color("1. Detecting project...", Colors.BLUE))
    project = detect_project_type()
    git_remote = get_git_remote()

    print(f"   Type: {project['framework']} ({project['language']})")
    if git_remote:
        print(f"   Git: {git_remote}")

    # Determine slug
    if not slug:
        if git_remote:
            slug = slugify(git_remote)
        else:
            slug = slugify(cwd.name)
    print(f"   Slug: {color(slug, Colors.GREEN)}")
    print()

    # Step 2: Check for auth FIRST (needed for .mcp.json generation)
    auth_header = None
    api_key = os.environ.get("SNIPARA_API_KEY")
    oauth_api_key = None  # API key from OAuth flow (for .mcp.json)

    print(color("2. Authentication", Colors.BLUE))
    if api_key:
        auth_header = api_key
        print(f"   Using SNIPARA_API_KEY from environment")
    else:
        # Check for OAuth tokens
        tokens = load_tokens()
        if tokens:
            # Try to find matching token by slug
            matching_token = None
            for project_id, token_data in tokens.items():
                if token_data.get("project_slug") == slug:
                    matching_token = token_data
                    break
            # Fall back to first available token
            if not matching_token:
                matching_token = next(iter(tokens.values()))

            if matching_token.get("access_token"):
                auth_header = f"Bearer {matching_token['access_token']}"
                oauth_api_key = matching_token.get("api_key")  # Get stored API key
                print(f"   Using OAuth token from {TOKEN_FILE}")
                if oauth_api_key:
                    print(f"   API key available for .mcp.json: {oauth_api_key[:12]}...")
                else:
                    print(f"   {color('Note:', Colors.YELLOW)} No API key in token. Re-run snipara-mcp-login to get one.")
    if not auth_header:
        print(f"   {color('Not authenticated', Colors.YELLOW)} - will use placeholder in .mcp.json")
    print()

    # Step 3: Generate config files (now with API key if available)
    print(color("3. Creating configuration...", Colors.BLUE))
    # Use OAuth API key if available, otherwise use env var or placeholder
    mcp_api_key = api_key or oauth_api_key
    write_mcp_json(slug, dry_run, api_key=mcp_api_key)
    update_env_example(dry_run)
    print()

    # Step 4: Upload docs (if authenticated)
    if auth_header and upload_docs and not dry_run:
        print(color("4. Uploading initial docs...", Colors.BLUE))

        docs_to_upload = []

        # Check for CLAUDE.md
        if (cwd / "CLAUDE.md").exists():
            docs_to_upload.append(("CLAUDE.md", (cwd / "CLAUDE.md").read_text()))

        # Check for README.md
        if (cwd / "README.md").exists():
            docs_to_upload.append(("README.md", (cwd / "README.md").read_text()))

        # Check for docs/ directory
        docs_dir = cwd / "docs"
        if docs_dir.exists() and docs_dir.is_dir():
            for md_file in docs_dir.rglob("*.md"):
                rel_path = str(md_file.relative_to(cwd))
                try:
                    content = md_file.read_text()
                    docs_to_upload.append((rel_path, content))
                except Exception:
                    pass

        if docs_to_upload:
            uploaded = 0
            total_tokens = 0

            for path, content in docs_to_upload:
                # Rough token estimate (1 token ~ 4 chars)
                tokens = len(content) // 4
                total_tokens += tokens

                success = await upload_document(api_url, slug, path, content, auth_header)
                if success:
                    uploaded += 1
                    print(f"   {color('Uploaded:', Colors.GREEN)} {path} (~{tokens:,} tokens)")
                else:
                    print(f"   {color('Failed:', Colors.RED)} {path}")

            print(f"\n   Total: {uploaded}/{len(docs_to_upload)} files (~{total_tokens:,} tokens)")
        else:
            print("   No docs found (CLAUDE.md, README.md, or docs/)")
        print()
    elif not auth_header:
        print(color("4. Uploading docs... SKIPPED", Colors.YELLOW))
        print("   No API key found. Set SNIPARA_API_KEY or run snipara-mcp-login")
        print()

    # Step 5: Test connection
    if auth_header and not skip_test and not dry_run:
        print(color("5. Testing connection...", Colors.BLUE))
        if await test_connection(api_url, slug, auth_header):
            print(f"   {color('Success!', Colors.GREEN)} Connected to Snipara API")
        else:
            print(f"   {color('Warning:', Colors.YELLOW)} Could not connect. Check your API key.")
        print()

    # Step 6: Print next steps
    print(color("Setup Complete!", Colors.GREEN + Colors.BOLD))
    print("=" * 40)
    print()
    print(f"  MCP endpoint: {color(f'{api_url}/mcp/{slug}', Colors.BLUE)}")
    print(f"  Dashboard:    {color(f'https://snipara.com/projects/{slug}', Colors.BLUE)}")
    print()

    if not auth_header:
        print(color("Next steps:", Colors.BOLD))
        print("  1. Run 'snipara-mcp-login' to authenticate (recommended)")
        print("     OR set SNIPARA_API_KEY from https://snipara.com/dashboard")
        print("  2. Run 'snipara-init' again to update .mcp.json with your key")
        print("  3. Restart Claude Code / Cursor to load MCP config")
        print()
    elif mcp_api_key:
        print(color("Next steps:", Colors.BOLD))
        print("  1. Restart Claude Code / Cursor to load MCP config")
        print("  2. Try: rlm_context_query(\"how does this project work?\")")
        print()
    else:
        # OAuth but no API key in token - need to re-login
        print(color("Next steps:", Colors.BOLD))
        print("  1. Re-run 'snipara-mcp-login' to get an API key")
        print("  2. Re-run 'snipara-init' to update .mcp.json")
        print("  3. Restart Claude Code / Cursor to load MCP config")
        print()

    return 0


def init_cli() -> None:
    """CLI entry point for snipara-init."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Initialize Snipara in the current directory",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  snipara-init                    # Auto-detect and initialize
  snipara-init --slug my-project  # Use specific slug
  snipara-init --dry-run          # Preview what would be done
  snipara-init --no-upload        # Skip doc upload
        """,
    )
    parser.add_argument(
        "--slug",
        "-s",
        type=str,
        help="Project slug (default: auto-detect from git remote or directory name)",
    )
    parser.add_argument(
        "--no-upload",
        action="store_true",
        help="Skip uploading CLAUDE.md and docs/",
    )
    parser.add_argument(
        "--dry-run",
        "-n",
        action="store_true",
        help="Show what would be done without making changes",
    )
    parser.add_argument(
        "--skip-test",
        action="store_true",
        help="Skip connection test",
    )

    args = parser.parse_args()

    try:
        exit_code = asyncio.run(init_async(
            slug=args.slug,
            upload_docs=not args.no_upload,
            dry_run=args.dry_run,
            skip_test=args.skip_test,
        ))
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n\nCancelled.")
        sys.exit(1)
    except Exception as e:
        print(f"\n{color('Error:', Colors.RED)} {e}")
        sys.exit(1)


if __name__ == "__main__":
    init_cli()
