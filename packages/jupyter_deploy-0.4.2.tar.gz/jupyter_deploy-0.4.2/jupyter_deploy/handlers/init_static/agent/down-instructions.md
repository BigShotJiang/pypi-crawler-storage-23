**IMPORTANT:** You must always ask the user before running the `down` command.

```bash
jd down
```