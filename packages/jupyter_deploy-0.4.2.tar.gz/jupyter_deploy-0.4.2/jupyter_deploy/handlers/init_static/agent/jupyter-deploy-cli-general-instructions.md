Verify that `jupyter-deploy` and its `jd` command are available.
You may need to activate your Python virtual environment.

```bash
jd --help
```

For more details, refer to [jupyter-deploy](https://github.com/jupyter-infra/jupyter-deploy/tree/main/libs/jupyter-deploy)
