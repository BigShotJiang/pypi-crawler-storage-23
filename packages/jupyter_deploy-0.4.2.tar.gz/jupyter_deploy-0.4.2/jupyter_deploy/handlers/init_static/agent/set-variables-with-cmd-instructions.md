Set variables via command
```bash
# Set the value of specific variables via command line
jd config --VAR-NAME-1 VARVALUE1 --VAR-NAME-2 VARVALUE2

# Find details of the variables available for this template
jd config --help
```
