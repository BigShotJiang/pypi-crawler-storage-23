
```bash
# display general information about the template
jd show --info

# or display more targeted information
jd show --template-name
jd show --template-version
jd show --template-engine
```
