```bash
# Prepare for deployment
# It will prompt interactively for required variables if not set
jd config

# Apply the configuration by mutating (create/update/delete) the resources 
jd up
```