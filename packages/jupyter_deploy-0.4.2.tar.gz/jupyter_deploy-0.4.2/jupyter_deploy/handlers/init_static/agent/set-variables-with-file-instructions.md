You may set variables by editing the `./variables.yaml` file.

Do NOT modify the `defaults:` section.
