```bash
# verify that your host and containers are running
jd host status
jd server status

# open the application
jd open
```
