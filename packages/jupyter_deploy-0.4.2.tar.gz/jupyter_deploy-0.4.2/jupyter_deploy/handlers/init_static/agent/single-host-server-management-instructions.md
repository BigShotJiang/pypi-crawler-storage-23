```bash
# Check server status
jd server status

# Start all services on the host
jd server start

# Stop all services on the host
jd server stop

# Restart all services on the host
jd server restart
```
