```bash
# Check host status
jd host status

# To stop your instance
jd host stop

# To start it again
jd host start

# Restart the instance
jd host restart
```
