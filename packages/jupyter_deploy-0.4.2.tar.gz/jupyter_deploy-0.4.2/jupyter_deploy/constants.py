MANIFEST_FILENAME = "manifest.yaml"
VARIABLES_FILENAME = "variables.yaml"
HISTORY_DIR = ".jd-history"
