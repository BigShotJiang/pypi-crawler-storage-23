import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from jupyter_deploy.engine.enum import EngineType
from jupyter_deploy.engine.supervised_execution import NullDisplay
from jupyter_deploy.engine.terraform.tf_enums import TerraformSequenceId
from jupyter_deploy.engine.terraform.tf_plan_metadata import TerraformPlanMetadata
from jupyter_deploy.engine.terraform.tf_up import TerraformUpHandler
from jupyter_deploy.exceptions import LogCleanupError, SupervisedExecutionError


class TestTerraformUpHandler(unittest.TestCase):
    """Test cases for the TerraformUpHandler class."""

    def test_init_sets_attributes(self) -> None:
        project_path = Path("/mock/project")
        mock_manifest = Mock()
        mock_history_handler = Mock()
        handler = TerraformUpHandler(
            project_path=project_path,
            project_manifest=mock_manifest,
            command_history_handler=mock_history_handler,
            display_manager=NullDisplay(),
        )

        self.assertEqual(handler.project_path, project_path)
        self.assertEqual(handler.engine, EngineType.TERRAFORM)

    def test_get_default_config_filename_returns_terraform_default(self) -> None:
        project_path = Path("/mock/project")
        mock_manifest = Mock()
        mock_history_handler = Mock()
        handler = TerraformUpHandler(
            project_path=project_path,
            project_manifest=mock_manifest,
            command_history_handler=mock_history_handler,
            display_manager=NullDisplay(),
        )

        result = handler.get_default_config_filename()

        self.assertEqual(result, "jdout-tfplan")

    @patch("jupyter_deploy.engine.terraform.tf_up.tf_supervised_executor_factory.create_terraform_executor")
    def test_apply_success(self, mock_create_executor: Mock) -> None:
        """Test successful terraform apply."""
        path = Path("/mock/path")
        project_path = Path("/mock/project")
        mock_manifest = Mock()
        mock_history_handler = Mock()
        mock_history_handler.create_log_file.return_value = Path("/mock/log.log")

        handler = TerraformUpHandler(
            project_path=project_path,
            project_manifest=mock_manifest,
            command_history_handler=mock_history_handler,
            display_manager=NullDisplay(),
        )

        # Mock the executor
        mock_executor = Mock()
        mock_executor.execute.return_value = 0
        mock_create_executor.return_value = mock_executor

        handler.apply(path)

        # Verify executor was called
        mock_executor.execute.assert_called_once()

    @patch("jupyter_deploy.engine.terraform.tf_up.tf_supervised_executor_factory.create_terraform_executor")
    def test_apply_handles_error(self, mock_create_executor: Mock) -> None:
        """Test terraform apply failure."""
        path = Path("/mock/path")
        project_path = Path("/mock/project")
        mock_manifest = Mock()
        mock_history_handler = Mock()
        mock_history_handler.create_log_file.return_value = Path("/mock/log.log")

        handler = TerraformUpHandler(
            project_path=project_path,
            project_manifest=mock_manifest,
            command_history_handler=mock_history_handler,
            display_manager=NullDisplay(),
        )

        # Mock the executor to return error
        mock_executor = Mock()
        mock_executor.execute.return_value = 1
        mock_create_executor.return_value = mock_executor

        with self.assertRaises(SupervisedExecutionError) as context:
            handler.apply(path)

        self.assertEqual(context.exception.retcode, 1)
        self.assertEqual(context.exception.command, "up")

    @patch("jupyter_deploy.engine.terraform.tf_up.tf_supervised_executor_factory.create_terraform_executor")
    def test_apply_with_auto_approve(self, mock_create_executor: Mock) -> None:
        """Test that auto_approve flag is properly passed to terraform command."""
        path = Path("/mock/path")
        project_path = Path("/mock/project")
        mock_manifest = Mock()
        mock_history_handler = Mock()
        mock_history_handler.create_log_file.return_value = Path("/mock/log.log")

        handler = TerraformUpHandler(
            project_path=project_path,
            project_manifest=mock_manifest,
            command_history_handler=mock_history_handler,
            display_manager=NullDisplay(),
        )

        # Mock the executor
        mock_executor = Mock()
        mock_executor.execute.return_value = 0
        mock_create_executor.return_value = mock_executor

        handler.apply(path, auto_approve=True)

        # Verify the command passed to executor includes -auto-approve
        mock_executor.execute.assert_called_once()
        cmd_args = mock_executor.execute.call_args[0][0]
        self.assertIn("-auto-approve", cmd_args)

    @patch("jupyter_deploy.engine.terraform.tf_up.TerraformSupervisedExecutionCallback")
    @patch("jupyter_deploy.engine.terraform.tf_up.tf_supervised_executor_factory.create_terraform_executor")
    def test_apply_with_display_manager_uses_supervised_callback(
        self, mock_create_executor: Mock, mock_callback_cls: Mock
    ) -> None:
        """Test that apply with display_manager uses TerraformSupervisedExecutionCallback."""
        path = Path("/mock/path")
        project_path = Path("/mock/project")
        mock_manifest = Mock()
        mock_history_handler = Mock()
        mock_history_handler.create_log_file.return_value = Path("/mock/log.log")

        # Mock executor - success
        mock_executor = Mock()
        mock_executor.execute.return_value = 0
        mock_create_executor.return_value = mock_executor

        # Mock callback
        mock_callback = Mock()
        mock_callback_cls.return_value = mock_callback

        # Create handler WITH display_manager
        mock_display_manager = Mock()
        mock_display_manager.is_pass_through.return_value = False  # Use supervised callbacks
        handler = TerraformUpHandler(
            project_path=project_path,
            project_manifest=mock_manifest,
            command_history_handler=mock_history_handler,
            display_manager=mock_display_manager,
        )

        # Act
        handler.apply(path)

        # Assert
        # Verify TerraformSupervisedExecutionCallback was created
        mock_callback_cls.assert_called_once_with(
            display_manager=mock_display_manager,
            sequence_id=TerraformSequenceId.up_apply,
        )

        # Verify executor was created with the supervised callback
        mock_create_executor.assert_called_once()
        self.assertEqual(mock_create_executor.call_args.kwargs["execution_callback"], mock_callback)

    @patch("jupyter_deploy.engine.terraform.tf_up.TerraformSupervisedExecutionCallback")
    @patch("jupyter_deploy.engine.terraform.tf_up.tf_supervised_executor_factory.create_terraform_executor")
    def test_apply_with_display_manager_handles_error(
        self, mock_create_executor: Mock, mock_callback_cls: Mock
    ) -> None:
        """Test that apply with display_manager properly raises ExecutionError on failure."""
        path = Path("/mock/path")
        project_path = Path("/mock/project")
        mock_manifest = Mock()
        mock_history_handler = Mock()
        mock_history_handler.create_log_file.return_value = Path("/mock/log.log")

        # Mock executor - failure
        mock_executor = Mock()
        mock_executor.execute.return_value = 1
        mock_create_executor.return_value = mock_executor

        # Mock callback
        mock_callback = Mock()
        mock_callback_cls.return_value = mock_callback

        # Create handler WITH display_manager
        mock_display_manager = Mock()
        mock_display_manager.is_pass_through.return_value = False  # Use supervised callbacks
        handler = TerraformUpHandler(
            project_path=project_path,
            project_manifest=mock_manifest,
            command_history_handler=mock_history_handler,
            display_manager=mock_display_manager,
        )

        # Act & Assert
        with self.assertRaises(SupervisedExecutionError) as context:
            handler.apply(path)

        self.assertEqual(context.exception.retcode, 1)
        self.assertEqual(context.exception.command, "up")

        # Verify TerraformSupervisedExecutionCallback was created
        mock_callback_cls.assert_called_once_with(
            display_manager=mock_display_manager,
            sequence_id=TerraformSequenceId.up_apply,
        )

        # Verify executor was created and executed
        mock_create_executor.assert_called_once()
        mock_executor.execute.assert_called_once()

    @patch("jupyter_deploy.engine.terraform.tf_up.tf_supervised_executor_factory.create_terraform_executor")
    def test_apply_clears_old_logs_on_success(self, mock_create_executor: Mock) -> None:
        """Test that apply calls clear_logs on successful execution."""
        path = Path("/mock/path")
        project_path = Path("/mock/project")
        mock_manifest = Mock()
        mock_history_handler = Mock()
        mock_history_handler.create_log_file.return_value = Path("/mock/log.log")
        mock_history_handler.clear_logs.return_value = Mock()

        # Mock executor - success
        mock_executor = Mock()
        mock_executor.execute.return_value = 0
        mock_create_executor.return_value = mock_executor

        handler = TerraformUpHandler(
            project_path=project_path,
            project_manifest=mock_manifest,
            command_history_handler=mock_history_handler,
            display_manager=NullDisplay(),
        )

        # Act
        handler.apply(path)

        # Assert - clear_logs should be called after successful execution
        mock_history_handler.clear_logs.assert_called_once_with("up")

    @patch("jupyter_deploy.engine.terraform.tf_up.tf_supervised_executor_factory.create_terraform_executor")
    def test_apply_does_not_clear_logs_on_failure(self, mock_create_executor: Mock) -> None:
        """Test that apply does NOT call clear_logs when execution fails."""
        path = Path("/mock/path")
        project_path = Path("/mock/project")
        mock_manifest = Mock()
        mock_history_handler = Mock()
        mock_history_handler.create_log_file.return_value = Path("/mock/log.log")
        mock_history_handler.clear_logs.return_value = Mock()

        # Mock executor - failure
        mock_executor = Mock()
        mock_executor.execute.return_value = 1
        mock_create_executor.return_value = mock_executor

        handler = TerraformUpHandler(
            project_path=project_path,
            project_manifest=mock_manifest,
            command_history_handler=mock_history_handler,
            display_manager=NullDisplay(),
        )

        # Act & Assert - should raise ExecutionError
        with self.assertRaises(SupervisedExecutionError):
            handler.apply(path)

        # Assert - clear_logs should NOT be called on failure
        mock_history_handler.clear_logs.assert_not_called()

    @patch("jupyter_deploy.engine.terraform.tf_up.tf_supervised_executor_factory.create_terraform_executor")
    def test_apply_bubbles_up_clear_logs_exception(self, mock_create_executor: Mock) -> None:
        """Test that apply bubbles up LogCleanupError from clear_logs."""
        path = Path("/mock/path")
        project_path = Path("/mock/project")
        mock_manifest = Mock()
        mock_history_handler = Mock()
        mock_history_handler.create_log_file.return_value = Path("/mock/log.log")
        mock_history_handler.clear_logs.side_effect = LogCleanupError("Failed to delete 2 log file(s)")

        # Mock executor - success
        mock_executor = Mock()
        mock_executor.execute.return_value = 0
        mock_create_executor.return_value = mock_executor

        handler = TerraformUpHandler(
            project_path=project_path,
            project_manifest=mock_manifest,
            command_history_handler=mock_history_handler,
            display_manager=NullDisplay(),
        )

        # Act & Assert - should raise LogCleanupError from clear_logs
        with self.assertRaises(LogCleanupError) as context:
            handler.apply(path)

        self.assertEqual(str(context.exception), "Failed to delete 2 log file(s)")
        mock_history_handler.clear_logs.assert_called_once_with("up")

    @patch("jupyter_deploy.engine.terraform.tf_up.tf_plan_metadata.load_plan_metadata")
    @patch("jupyter_deploy.engine.terraform.tf_up.tf_supervised_executor_factory.create_terraform_executor")
    def test_apply_loads_and_passes_plan_metadata(self, mock_create_executor: Mock, mock_load_metadata: Mock) -> None:
        """Test that apply loads plan metadata and passes it to executor factory."""
        path = Path("/mock/path")
        project_path = Path("/mock/project")
        mock_manifest = Mock()
        mock_history_handler = Mock()
        mock_history_handler.create_log_file.return_value = Path("/mock/log.log")

        # Mock the plan metadata
        mock_metadata = TerraformPlanMetadata(to_add=2, to_change=3, to_destroy=1)
        mock_load_metadata.return_value = mock_metadata

        # Mock executor - success
        mock_executor = Mock()
        mock_executor.execute.return_value = 0
        mock_create_executor.return_value = mock_executor

        handler = TerraformUpHandler(
            project_path=project_path,
            project_manifest=mock_manifest,
            command_history_handler=mock_history_handler,
            display_manager=NullDisplay(),
        )

        # Act
        handler.apply(path)

        # Assert - verify load_plan_metadata was called with correct path
        expected_metadata_path = project_path / "engine" / "jdout-tfplan.meta.json"
        mock_load_metadata.assert_called_once_with(expected_metadata_path)

        # Assert - verify plan_metadata was passed to create_terraform_executor
        mock_create_executor.assert_called_once()
        call_kwargs = mock_create_executor.call_args.kwargs
        self.assertEqual(call_kwargs["plan_metadata"], mock_metadata)

    @patch("jupyter_deploy.engine.terraform.tf_up.tf_plan_metadata.load_plan_metadata")
    @patch("jupyter_deploy.engine.terraform.tf_up.tf_supervised_executor_factory.create_terraform_executor")
    def test_apply_passes_none_when_plan_metadata_missing(
        self, mock_create_executor: Mock, mock_load_metadata: Mock
    ) -> None:
        """Test that apply passes None to executor when plan metadata file is missing."""
        path = Path("/mock/path")
        project_path = Path("/mock/project")
        mock_manifest = Mock()
        mock_history_handler = Mock()
        mock_history_handler.create_log_file.return_value = Path("/mock/log.log")

        # Mock load_plan_metadata to return None (file doesn't exist or is invalid)
        mock_load_metadata.return_value = None

        # Mock executor - success
        mock_executor = Mock()
        mock_executor.execute.return_value = 0
        mock_create_executor.return_value = mock_executor

        handler = TerraformUpHandler(
            project_path=project_path,
            project_manifest=mock_manifest,
            command_history_handler=mock_history_handler,
            display_manager=NullDisplay(),
        )

        # Act
        handler.apply(path)

        # Assert - verify load_plan_metadata was called
        expected_metadata_path = project_path / "engine" / "jdout-tfplan.meta.json"
        mock_load_metadata.assert_called_once_with(expected_metadata_path)

        # Assert - verify None was passed to create_terraform_executor
        mock_create_executor.assert_called_once()
        call_kwargs = mock_create_executor.call_args.kwargs
        self.assertIsNone(call_kwargs["plan_metadata"])
