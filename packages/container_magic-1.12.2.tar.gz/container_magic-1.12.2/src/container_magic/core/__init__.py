"""Core functionality for container-magic."""
