"""CLI module for container-magic."""
