import pytest

import optiroulette_keras.backend as backend


def test_backend_guard_rejects_non_torch(monkeypatch):
    monkeypatch.setattr(backend, "get_backend_name", lambda: "tensorflow")

    with pytest.raises(RuntimeError, match="PyTorch backend"):
        backend.ensure_torch_backend()
