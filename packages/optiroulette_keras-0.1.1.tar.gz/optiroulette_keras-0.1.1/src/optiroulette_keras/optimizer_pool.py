"""Optimizer pool manager for active/backup swapping."""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
import logging
from typing import Any, Dict, List, Optional

from .compatibility import OptimizerCompatibility


@dataclass
class OptimizerStats:
    """Statistics tracked for one optimizer in the pool."""

    name: str
    total_epochs_used: int = 0
    consecutive_failures: int = 0
    catastrophic_failures: int = 0
    instability_events: int = 0
    average_reward: float = 0.0
    reward_history: deque = field(default_factory=lambda: deque(maxlen=20))
    last_val_acc: float = 0.0
    best_val_acc: float = 0.0
    swap_count: int = 0
    is_active: bool = True
    is_blacklisted: bool = False
    epochs_since_activation: int = 0
    in_grace_period: bool = True


@dataclass
class PoolConfig:
    """Configuration for active/backup optimizer pool behavior."""

    num_active: int = 3
    num_backup: int = 2
    enable_failure_swaps: bool = True
    failure_threshold: float = -0.2
    consecutive_failure_limit: int = 3
    catastrophic_drop: float = 0.2
    catastrophic_failure_limit: int = 1
    blacklist_threshold: int = 3
    swap_recovery: Dict[str, Any] = field(default_factory=dict)
    compatibility_groups: Dict[str, Any] = field(default_factory=dict)
    compatibility_rules: Dict[str, Any] = field(default_factory=dict)
    group_interactions: Dict[str, Any] = field(default_factory=dict)
    lr_scaling_rules: Dict[str, Any] = field(default_factory=dict)


class OptimizerPoolManager:
    """Maintain active and backup optimizers with optional hot-swapping."""

    def __init__(
        self,
        all_optimizers: Dict[str, Any],
        active_names: List[str],
        backup_names: List[str],
        config: PoolConfig,
        logger: Optional[logging.Logger] = None,
    ):
        if len(active_names) != config.num_active:
            raise ValueError("Active optimizer count mismatch with pool config.")
        if len(backup_names) < config.num_backup:
            raise ValueError("Not enough backup optimizers for configured pool.")

        self.all_optimizers = all_optimizers
        self.config = config
        self.logger = logger or logging.getLogger(__name__)
        self.swap_cfg = config.swap_recovery
        self.compatibility: Optional[OptimizerCompatibility] = None

        if (
            config.compatibility_groups
            or config.compatibility_rules
            or config.group_interactions
            or config.lr_scaling_rules
        ):
            self.compatibility = OptimizerCompatibility(
                {
                    "groups": config.compatibility_groups,
                    "rules": config.compatibility_rules,
                    "group_interactions": config.group_interactions,
                    "lr_scaling_rules": config.lr_scaling_rules,
                }
            )

        self.active_pool = active_names.copy()
        self.backup_pool = backup_names[: config.num_backup]
        self.reserve_pool = backup_names[config.num_backup :]

        self.stats: Dict[str, OptimizerStats] = {
            name: OptimizerStats(name=name, is_active=(name in self.active_pool))
            for name in all_optimizers
        }

    def get_active_names(self) -> List[str]:
        """Return currently active optimizer names."""
        return self.active_pool.copy()

    def record_performance(
        self,
        name: str,
        reward: float,
        val_acc: float,
        global_best_val_acc: Optional[float] = None,
    ) -> Optional[str]:
        """Update optimizer stats and swap in backup when thresholds trigger."""
        stats = self.stats[name]
        stats.total_epochs_used += 1
        stats.reward_history.append(float(reward))
        stats.average_reward = sum(stats.reward_history) / len(stats.reward_history)
        stats.last_val_acc = float(val_acc)

        if stats.instability_events > 0:
            stats.instability_events = max(0, stats.instability_events - 1)

        grace_epochs = int(self.swap_cfg.get("grace_period_epochs", 0) or 0)
        if stats.in_grace_period and stats.epochs_since_activation >= grace_epochs:
            stats.in_grace_period = False

        failure_threshold = float(self.config.failure_threshold)
        if stats.in_grace_period:
            failure_threshold *= float(self.swap_cfg.get("relaxed_threshold_factor", 1.0))

        if reward < failure_threshold:
            stats.consecutive_failures += 1
        else:
            stats.consecutive_failures = 0

        reference_best = (
            float(global_best_val_acc)
            if global_best_val_acc is not None
            else float(stats.best_val_acc)
        )
        catastrophic = reference_best - float(val_acc) > float(self.config.catastrophic_drop)
        if catastrophic:
            stats.catastrophic_failures += 1
        else:
            stats.catastrophic_failures = 0

        stats.best_val_acc = max(float(stats.best_val_acc), float(val_acc))

        if not self.config.enable_failure_swaps:
            return None

        is_failure = stats.consecutive_failures >= int(self.config.consecutive_failure_limit)
        catastrophic_limit = (
            stats.catastrophic_failures >= int(self.config.catastrophic_failure_limit)
        )
        if (not stats.in_grace_period and is_failure) or catastrophic_limit:
            new_name = self._swap_optimizer(name)
            if new_name and catastrophic_limit:
                stats.catastrophic_failures = 0
            return new_name
        return None

    def increment_epochs(self) -> None:
        """Increment activation-age counters for active optimizers."""
        grace_epochs = int(self.swap_cfg.get("grace_period_epochs", 0) or 0)
        for name in self.active_pool:
            stats = self.stats[name]
            stats.epochs_since_activation += 1
            if stats.in_grace_period and stats.epochs_since_activation >= grace_epochs:
                stats.in_grace_period = False

    def _get_compatible_candidates(self, failed_name: str) -> List[str]:
        return [
            name
            for name in self.all_optimizers
            if name not in self.active_pool
            and name != failed_name
            and not self.stats[name].is_blacklisted
        ]

    def _swap_optimizer(self, failed_name: str) -> Optional[str]:
        backup_candidates = [
            name for name in self.backup_pool if not self.stats[name].is_blacklisted
        ]
        reserve_candidates = [
            name for name in self.reserve_pool if not self.stats[name].is_blacklisted
        ]

        candidates = backup_candidates
        if self.compatibility:
            candidates = backup_candidates + reserve_candidates

        if not candidates:
            candidates = self._get_compatible_candidates(failed_name)
        if not candidates:
            self.logger.warning("No compatible optimizers available for swap.")
            return None

        new_name = (
            self.compatibility.get_compatible_backup(failed_name, candidates)
            if self.compatibility
            else candidates[0]
        )
        if not new_name:
            self.logger.warning("No compatible optimizer selected for swap.")
            return None

        if new_name in self.backup_pool:
            self.backup_pool.remove(new_name)
        if new_name in self.reserve_pool:
            self.reserve_pool.remove(new_name)

        self.active_pool.remove(failed_name)
        self.active_pool.append(new_name)

        failed_stats = self.stats[failed_name]
        failed_stats.is_active = False
        failed_stats.catastrophic_failures = 0
        failed_stats.instability_events = 0
        failed_stats.swap_count += 1
        if failed_stats.swap_count >= int(self.config.blacklist_threshold):
            failed_stats.is_blacklisted = True
        else:
            self.reserve_pool.append(failed_name)

        new_stats = self.stats[new_name]
        new_stats.is_active = True
        new_stats.consecutive_failures = 0
        new_stats.catastrophic_failures = 0
        new_stats.instability_events = 0
        new_stats.total_epochs_used = 0
        new_stats.epochs_since_activation = 0
        new_stats.in_grace_period = True

        return new_name
