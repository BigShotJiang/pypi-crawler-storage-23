"""Keras optimizer adapter for external torch optimizer classes."""
from __future__ import annotations

from typing import Any, Dict

import torch

from .backend import ensure_torch_backend

ensure_torch_backend()
import keras  # noqa: E402


def _to_float(value: Any, default: float = 0.0) -> float:
    if value is None:
        return float(default)
    if isinstance(value, (int, float)):
        return float(value)
    if hasattr(value, "numpy"):
        try:
            return float(value.numpy())
        except Exception:
            pass
    if hasattr(value, "item"):
        try:
            return float(value.item())
        except Exception:
            pass
    try:
        return float(value)
    except Exception:
        return float(default)


def _normalize_torch_cfg(cfg: Dict[str, Any]) -> Dict[str, Any]:
    normalized = dict(cfg or {})
    if "betas" in normalized and isinstance(normalized["betas"], list):
        normalized["betas"] = tuple(normalized["betas"])
    if "nus" in normalized and isinstance(normalized["nus"], list):
        normalized["nus"] = tuple(normalized["nus"])
    if "learning_rate" in normalized and "lr" not in normalized:
        normalized["lr"] = normalized.pop("learning_rate")
    if "beta_1" in normalized and "beta_2" in normalized and "betas" not in normalized:
        normalized["betas"] = (normalized.pop("beta_1"), normalized.pop("beta_2"))
    if "rho" in normalized and "alpha" not in normalized:
        normalized["alpha"] = normalized["rho"]
    if "N_sma_threshold" in normalized and "n_sma_threshold" not in normalized:
        normalized["n_sma_threshold"] = normalized.pop("N_sma_threshold")
    return normalized


class TorchExternalOptimizer(keras.optimizers.Optimizer):
    """Keras ``Optimizer`` wrapper that delegates updates to torch optimizer."""

    def __init__(
        self,
        optimizer_cls: type,
        *,
        optimizer_name: str,
        optimizer_cfg: Dict[str, Any] | None = None,
        learning_rate: float | None = None,
        name: str | None = None,
        **kwargs: Any,
    ) -> None:
        cfg = _normalize_torch_cfg(dict(optimizer_cfg or {}))
        if learning_rate is None:
            learning_rate = cfg.get("lr", cfg.get("learning_rate", 1e-3))
        super().__init__(
            learning_rate=learning_rate,
            name=name or str(optimizer_name).lower(),
            **kwargs,
        )
        self.optimizer_cls = optimizer_cls
        self.optimizer_name = str(optimizer_name)
        self.optimizer_cfg = cfg
        self._torch_optimizer: torch.optim.Optimizer | None = None

    def build(self, variables):
        super().build(variables)
        if self._torch_optimizer is not None:
            return
        params = [variable.value for variable in variables]
        cfg = _normalize_torch_cfg(self.optimizer_cfg)
        cfg.setdefault("lr", _to_float(self.learning_rate, default=1e-3))
        self._torch_optimizer = self.optimizer_cls(params, **cfg)

    def update_step(self, gradient, variable, learning_rate):
        del gradient, variable, learning_rate
        # Per-variable update path is bypassed by `_backend_apply_gradients`.
        return

    @torch.no_grad()
    def _backend_apply_gradients(self, grads, trainable_variables):
        if self._torch_optimizer is None:
            self.build(trainable_variables)
        assert self._torch_optimizer is not None

        current_lr = _to_float(self.learning_rate, default=1e-3)
        for group in self._torch_optimizer.param_groups:
            group["lr"] = current_lr

        self._torch_optimizer.zero_grad(set_to_none=True)
        for grad, variable in zip(grads, trainable_variables):
            if grad is None:
                continue
            tensor = grad.value if hasattr(grad, "value") else grad
            parameter = variable.value
            if not torch.is_tensor(tensor):
                tensor = torch.as_tensor(
                    tensor,
                    device=parameter.device,
                    dtype=parameter.dtype,
                )
            tensor = tensor.detach()
            if tensor.dtype != parameter.dtype:
                tensor = tensor.to(parameter.dtype)
            if parameter.grad is None:
                parameter.grad = tensor.clone()
            else:
                parameter.grad.copy_(tensor)

        self._torch_optimizer.step()
        self.iterations.assign_add(1)

    def get_config(self) -> Dict[str, Any]:
        config = super().get_config()
        config.update(
            {
                "optimizer_name": self.optimizer_name,
                "optimizer_cfg": dict(self.optimizer_cfg),
            }
        )
        return config
