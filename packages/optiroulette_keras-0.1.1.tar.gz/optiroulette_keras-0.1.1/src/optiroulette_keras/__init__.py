"""OptiRoulette Keras package public API."""

from .backend import ensure_torch_backend, get_backend_name
from .defaults import (
    get_default_config,
    get_default_seed,
    get_default_lr_scaling_rules,
    get_default_optimizer_specs,
    get_default_pool_setup,
    get_default_roulette_config,
)
from .fit import (
    OptiRouletteCallback,
    OptiRouletteFitCallback,
    create_fit_callback,
    create_roulette_callback,
)
from .opti_roulette import OptiRoulette, OptiRouletteOptimizer
from .optimizer_pool import PoolConfig

__all__ = [
    "OptiRoulette",
    "OptiRouletteOptimizer",
    "OptiRouletteCallback",
    "OptiRouletteFitCallback",
    "create_roulette_callback",
    "create_fit_callback",
    "PoolConfig",
    "ensure_torch_backend",
    "get_backend_name",
    "get_default_config",
    "get_default_seed",
    "get_default_lr_scaling_rules",
    "get_default_optimizer_specs",
    "get_default_pool_setup",
    "get_default_roulette_config",
]
