from __future__ import annotations

import typing
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from aep_parser.enums import GetSettingsFormat, LogType, RQItemStatus

from ..settings import (
    RenderSettings,
    settings_to_number,
    settings_to_string,
)

if typing.TYPE_CHECKING:
    from typing import Iterator

    from ..items.composition import CompItem
    from .output_module import OutputModule


@dataclass
class RenderQueueItem:
    """
    The `RenderQueueItem` object represents an individual item in the render
    queue. It provides access to the specific settings for an item to be
    rendered.

    Example:
        ```python
        import aep_parser

        app = aep_parser.parse("project.aep")
        rq_item = app.project.render_queue.items[0]
        print(rq_item.status)
        for output_module in rq_item:
            ...
        ```

    See: https://ae-scripting.docsforadobe.dev/renderqueue/renderqueueitem/
    """

    comment: str
    """A comment that describes the render queue item. This shows in the Render Queue panel."""

    comp: CompItem = field(repr=False)
    """The composition that will be rendered by this render-queue item."""

    elapsed_seconds: int
    """
    The number of seconds that have elapsed in rendering this item.
    """

    log_type: LogType
    """
    A log type for this item, indicating which events should be logged
    while this item is being rendered.
    """

    name: str
    """The name of the render settings template used for this item."""

    output_modules: list[OutputModule]
    """The list of Output Modules for the item."""

    queue_item_notify: bool
    """
    When `True`, a user notification is enabled for this render queue
    item, signaling the user upon render completion.
    """

    render: bool
    """When `True`, the item will be rendered when the render queue is started."""

    settings: RenderSettings
    """
    [RenderSettings][aep_parser.models.settings.RenderSettings] dict
    with ExtendScript-compatible keys matching getSettings() output.
    Contains quality, resolution, motion blur, frame blending, and other
    rendering options.
    """

    skip_frames: int
    """
    The number of frames to skip when rendering this item. Use this to do
    rendering tests that are faster than a full render. A value of 0 skip no
    frames, and results in regular rendering of all frames. A value of 1 skips
    every other frame. This is equivalent to "rendering on twos." Higher
    values skip a larger number of frames. The total length of time remains
    unchanged. For example, if skip has a value of 1, a sequence output would
    have half the number of frames and in movie output, each frame would be
    double the duration.
    """

    start_time: datetime | None
    """
    The date and time when rendering of this item started, or `None` if
    the item has not started rendering.
    """

    status: RQItemStatus
    """The current render status of the item."""

    time_span_duration_frames: int
    """
    The duration in frames of the composition to be rendered. The duration
    is determined by subtracting the start time from the end time.
    """

    time_span_start_frames: int
    """
    The time in the composition, in frames, at which rendering will begin.
    """

    templates: list[str] = field(default_factory=list)  # TODO
    """
    The names of all render-item templates available in the local installation
    of After Effects.
    """

    @property
    def time_span_start(self) -> float:
        """
        The time in the composition, in seconds, at which rendering will
        begin.
        """
        return float(self.settings["Time Span Start"])

    @property
    def time_span_duration(self) -> float:
        """
        The duration in seconds of the composition to be rendered. The
        duration is determined by subtracting the start time from the end
        time.
        """
        return float(self.settings["Time Span Duration"])

    @property
    def time_span_end(self) -> float:
        """
        The time in the composition, in seconds, at which rendering will end.
        """
        return self.time_span_start + self.time_span_duration

    @property
    def time_span_end_frames(self) -> int:
        """
        The time in the composition, in frames, at which rendering will end.
        """
        return self.time_span_start_frames + self.time_span_duration_frames

    @property
    def comp_name(self) -> str:
        """The name of the composition being rendered."""
        return self.comp.name

    def __iter__(self) -> Iterator[OutputModule]:
        """Allow iteration over Output Modules."""
        return iter(self.output_modules)

    def get_settings(
        self,
        format: GetSettingsFormat = GetSettingsFormat.STRING,
    ) -> dict[str, Any]:
        """Return render settings in the specified format.

        Args:
            format: The output format.
                ``GetSettingsFormat.NUMBER`` returns numeric values (enums unwrapped to ints).
                ``GetSettingsFormat.STRING`` returns all values as strings
        """
        if format == GetSettingsFormat.STRING:
            return settings_to_string(self.settings)
        if format == GetSettingsFormat.NUMBER:
            return settings_to_number(self.settings)
        raise ValueError(f"Unsupported format: {format!r}")

    def get_setting(
        self,
        key: str,
        format: GetSettingsFormat = GetSettingsFormat.STRING,
    ) -> Any:
        """Return a single render setting in the specified format.

        Args:
            key: The setting key (e.g. ``"Quality"``, ``"Frame Rate"``).
            format: The output format.
        """
        return self.get_settings(format)[key]
