"""After Effects enumerations.

These enums match the values used in After Effects ExtendScript.

Submodules:
- [general][aep_parser.enums.general]: Core layer, footage, project, viewer
  and mask enums.
- [property][aep_parser.enums.property]: Property system enums
  (control type, value type, keyframe interpolation).
- [render_settings][aep_parser.enums.render_settings]: Render settings enums
  (quality, field render, motion blur, effects, etc.).
- [render_queue][aep_parser.enums.render_queue]: Render queue item enums
  (status, log type, settings format).
- [output_module][aep_parser.enums.output_module]: Output module enums
  (channels, depth, color mode, format, audio settings, post-render action).
- [format_options][aep_parser.enums.format_options]: Format-specific option
  enums (Cineon, JPEG, PNG, OpenEXR, audio/video codecs).
- [text_document][aep_parser.enums.text_document]: Text document enums
  (justification, baseline, kerning, font caps, etc.).
- [font_object][aep_parser.enums.font_object]: Font object enums
  (technology, type, script).
"""

from __future__ import annotations

from .font_object import CTFontTechnology, CTFontType, CTScript
from .format_options import (
    AudioCodec,
    CineonFileFormat,
    Hdr10ColorPrimaries,
    JpegFormatType,
    MPEGAudioFormat,
    MPEGMultiplexer,
    MPEGMuxStreamCompatibility,
    OpenExrCompression,
    PngCompression,
    VideoCodec,
)
from .general import (
    AlphaMode,
    AutoOrientType,
    BitsPerChannel,
    BlendingMode,
    ChannelType,
    CloseOptions,
    ColorManagementSystem,
    FastPreviewType,
    FeetFramesFilmType,
    FieldSeparationType,
    FillLightingCorrectionType,
    FillMethodType,
    FillOutputDepthType,
    FillRangeType,
    FootageTimecodeDisplayStartType,
    FrameBlendingType,
    FramesCountType,
    GpuAccelType,
    ImportAsType,
    Label,
    Language,
    LayerQuality,
    LayerSamplingQuality,
    LightType,
    LoopMode,
    LutInterpolationMethod,
    MaskFeatherFalloff,
    MaskMode,
    MaskMotionBlur,
    PlayMode,
    PREFType,
    ProjectThread,
    PropertyType,
    PulldownMethod,
    PulldownPhase,
    PurgeTarget,
    ResolveType,
    TimeDisplayType,
    ToolType,
    TrackMatteType,
    ViewerType,
)
from .output_module import (
    AudioBitDepth,
    AudioChannels,
    AudioSampleRate,
    ConvertToLinearLight,
    OutputAudio,
    OutputChannels,
    OutputColorDepth,
    OutputColorMode,
    OutputFormat,
    PostRenderAction,
    ResizeQuality,
)
from .property import (
    KeyframeInterpolationType,
    PropertyControlType,
    PropertyValueType,
)
from .render_queue import (
    GetSettingsFormat,
    LogType,
    RQItemStatus,
)
from .render_settings import (
    ColorDepthSetting,
    DiskCacheSetting,
    EffectsSetting,
    FieldRender,
    FrameBlendingSetting,
    FrameRateSetting,
    GuideLayers,
    MotionBlurSetting,
    ProxyUseSetting,
    PulldownSetting,
    RenderQuality,
    SoloSwitchesSetting,
    TimeSpanSource,
)
from .text_document import (
    AutoKernType,
    BaselineDirection,
    BoxAutoFitPolicy,
    BoxFirstBaselineAlignment,
    BoxVerticalAlignment,
    ComposerEngine,
    DigitSet,
    FontBaselineOption,
    FontCapsOption,
    LeadingType,
    LineJoinType,
    LineOrientation,
    ParagraphDirection,
    ParagraphJustification,
)

__all__ = [
    # font_object
    "CTFontTechnology",
    "CTFontType",
    "CTScript",
    # format_options
    "AudioCodec",
    "CineonFileFormat",
    "Hdr10ColorPrimaries",
    "JpegFormatType",
    "MPEGAudioFormat",
    "MPEGMultiplexer",
    "MPEGMuxStreamCompatibility",
    "OpenExrCompression",
    "PngCompression",
    "VideoCodec",
    # general
    "AlphaMode",
    "AutoOrientType",
    "BitsPerChannel",
    "BlendingMode",
    "ChannelType",
    "CloseOptions",
    "ColorManagementSystem",
    "FastPreviewType",
    "FeetFramesFilmType",
    "FieldSeparationType",
    "FillLightingCorrectionType",
    "FillMethodType",
    "FillOutputDepthType",
    "FillRangeType",
    "FootageTimecodeDisplayStartType",
    "FrameBlendingType",
    "FramesCountType",
    "GpuAccelType",
    "ImportAsType",
    "Label",
    "Language",
    "LayerQuality",
    "LayerSamplingQuality",
    "LightType",
    "LoopMode",
    "LutInterpolationMethod",
    "MaskFeatherFalloff",
    "MaskMode",
    "MaskMotionBlur",
    "PlayMode",
    "PREFType",
    "ProjectThread",
    "PropertyType",
    "PulldownMethod",
    "PulldownPhase",
    "PurgeTarget",
    "ResolveType",
    "TimeDisplayType",
    "ToolType",
    "TrackMatteType",
    "ViewerType",
    # output_module
    "AudioBitDepth",
    "AudioChannels",
    "AudioSampleRate",
    "ConvertToLinearLight",
    "OutputAudio",
    "OutputChannels",
    "OutputColorDepth",
    "OutputColorMode",
    "OutputFormat",
    "ResizeQuality",
    # property
    "KeyframeInterpolationType",
    "PropertyControlType",
    "PropertyValueType",
    # render_queue
    "GetSettingsFormat",
    "LogType",
    "PostRenderAction",
    "RQItemStatus",
    # render_settings
    "ColorDepthSetting",
    "DiskCacheSetting",
    "EffectsSetting",
    "FieldRender",
    "FrameBlendingSetting",
    "FrameRateSetting",
    "GuideLayers",
    "MotionBlurSetting",
    "ProxyUseSetting",
    "PulldownSetting",
    "RenderQuality",
    "SoloSwitchesSetting",
    "TimeSpanSource",
    # text_document
    "AutoKernType",
    "BaselineDirection",
    "BoxAutoFitPolicy",
    "BoxFirstBaselineAlignment",
    "BoxVerticalAlignment",
    "ComposerEngine",
    "DigitSet",
    "FontBaselineOption",
    "FontCapsOption",
    "LeadingType",
    "LineJoinType",
    "LineOrientation",
    "ParagraphDirection",
    "ParagraphJustification",
]
