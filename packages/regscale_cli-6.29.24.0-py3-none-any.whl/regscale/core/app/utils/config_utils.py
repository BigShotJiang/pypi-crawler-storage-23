#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Shared utilities for reading integration configuration from init.yaml.

Supports both the legacy flat-key format (e.g. ``axoniusHost``) and the
modern nested-section format (e.g. ``axonius.host``).  Flat keys always
take priority so existing deployments are not silently broken.
"""

from typing import Any, Dict


def _camel_to_snake(name: str) -> str:
    """Convert a camelCase string to snake_case.

    Each uppercase letter (after position 0) is prefixed with ``_`` and
    lowercased.  The first character is lowercased without a prefix.

    :param str name: camelCase input (first char already lowercased by caller).
    :return: snake_case string.
    :rtype: str

    Examples::

        "siteId"    -> "site_id"
        "verifySsl" -> "verify_ssl"
        "pageSize"  -> "page_size"
        "timeout"   -> "timeout"
    """
    result = []
    for i, ch in enumerate(name):
        if ch.isupper() and i > 0:
            result.append("_")
        result.append(ch.lower())
    return "".join(result)


def get_integration_config(
    config: Dict[str, Any],
    section: str,
    snake_case: bool = False,
) -> Dict[str, Any]:
    """Return the config dict for an integration, honoring legacy flat keys.

    Checks for top-level keys that start with *section* (but are not equal to
    *section* itself).  When any such flat keys are found they take priority
    over the nested ``config[section]`` block.

    Flat key names are converted to nested key names by stripping the *section*
    prefix and lowercasing the first character of the remainder.  When
    *snake_case* is ``True``, every remaining uppercase letter is also replaced
    with ``_<lower>``::

        snake_case=False  "axoniusApiKey"        -> "apiKey"
        snake_case=True   "sentineloneSiteId"    -> "site_id"
        snake_case=True   "sentineloneVerifySsl" -> "verify_ssl"
        snake_case=True   "sentinelonePageSize"  -> "page_size"

    When no flat keys exist the nested block ``config.get(section, {})`` is
    returned unchanged.

    :param dict config: The full application config (``app.config``).
    :param str section: Integration name used as both the nested block key and
        the flat-key prefix (e.g. ``"axonius"`` or ``"sentinelone"``).
    :param bool snake_case: When ``True``, derived key names are converted to
        snake_case.  Defaults to ``False`` (camelCase preserved).
    :return: Config dict with nested-style key names.
    :rtype: dict

    Example::

        cfg = get_integration_config(app.config, "axonius")
        # {"axoniusHost": "h"} -> {"host": "h"}

        cfg = get_integration_config(app.config, "sentinelone", snake_case=True)
        # {"sentineloneSiteId": "s1"} -> {"site_id": "s1"}
    """
    prefix_len = len(section)
    flat: Dict[str, Any] = {}
    for key, value in config.items():
        if key.startswith(section) and key != section and len(key) > prefix_len:
            remainder = key[prefix_len:]
            nested_key = remainder[0].lower() + remainder[1:]
            if snake_case:
                nested_key = _camel_to_snake(nested_key)
            flat[nested_key] = value
    if flat:
        return flat
    return config.get(section, {})
