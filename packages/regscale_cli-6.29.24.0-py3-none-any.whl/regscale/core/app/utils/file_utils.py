"""
Utility functions for working with files and folders.
"""

import os
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Iterator, List, Optional, TextIO, Union

from botocore.exceptions import ClientError

if TYPE_CHECKING:
    import boto3


class S3FileDownloadError(Exception):
    """
    Exception raised when an error occurs during S3 file downloadß
    """

    pass


def is_s3_path(path: Union[str, Path]) -> bool:
    """
    Check if the given path is an S3 URI.

    :param Union[str, Path] path: The path to check
    :return: True if the path is an S3 URI, False otherwise
    :rtype: bool
    """
    return isinstance(path, str) and path.startswith("s3://")


def read_file(file_path: Union[str, Path]) -> str:
    """
    Read a file from local filesystem or S3.

    :param Union[str, Path] file_path: Path to the file or S3 URI
    :return: Content of the file
    :rtype: str
    """
    import smart_open  # type: ignore # Optimize import performance

    encodings = ["utf-8", "latin-1", "cp1252", "iso-8859-1"]

    for encoding in encodings:
        try:
            with smart_open.open(str(file_path), "r", encoding=encoding) as f:
                return f.read()
        except UnicodeDecodeError:
            continue

    # Fallback to utf-8 with error replacement
    with smart_open.open(str(file_path), "r", encoding="utf-8", errors="replace") as f:
        return f.read()


def find_files(path: Union[str, Path], pattern: str) -> List[Union[Path, str]]:
    """
    Find all files matching the pattern in the given path, including S3.

    :param Union[str, Path] path: Path to a file, a folder, or an S3 URI
    :param str pattern: File pattern to match (e.g., "*.nessus")
    :return: List of Path objects for matching files or S3 URIs
    :rtype: List[Union[Path, str]]
    """
    import boto3  # type: ignore # Optimize import performance

    if is_s3_path(path):
        s3_parts = path[5:].split("/", 1)
        bucket = s3_parts[0]
        prefix = s3_parts[1] if len(s3_parts) > 1 else ""

        s3 = boto3.client("s3")
        paginator = s3.get_paginator("list_objects_v2")

        files: List[Union[Path, str]] = []
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
            for obj in page.get("Contents", []):
                if obj["Key"].endswith(pattern.lstrip("*")):
                    files.append(f"s3://{bucket}/{obj['Key']}")
        return files

    file_path = Path(path)
    if file_path.is_file():
        return [file_path] if file_path.match(pattern) else []
    return list(file_path.glob(pattern))


def move_file(src: Union[str, Path], dst: Union[str, Path], expected_bucket_owner: Optional[str] = None) -> None:
    """
    Move a file from src to dst. Works with local files and S3.

    :param Union[str, Path] src: Source file path or S3 URI
    :param Union[str, Path] dst: Destination file path or S3 URI
    :param Optional[str] expected_bucket_owner: AWS account ID to verify S3 bucket ownership
    """
    import smart_open  # type: ignore # Optimize import performance

    owner_kwargs = {"ExpectedBucketOwner": expected_bucket_owner} if expected_bucket_owner else {}

    if is_s3_path(src):
        import boto3  # type: ignore # Optimize import performance

        # S3 to S3 move
        if is_s3_path(dst):
            s3 = boto3.client("s3")
            src_parts = src[5:].split("/", 1)
            dst_parts = dst[5:].split("/", 1)
            s3.copy_object(
                CopySource={"Bucket": src_parts[0], "Key": src_parts[1]},
                Bucket=dst_parts[0],
                Key=dst_parts[1],
                **owner_kwargs,
            )
            s3.delete_object(Bucket=src_parts[0], Key=src_parts[1], **owner_kwargs)
        else:
            # S3 to local
            with (
                smart_open.open(src, "rb") as s_file,
                smart_open.open(dst, "wb") as d_file,
            ):
                d_file.write(s_file.read())
            s3 = boto3.client("s3")
            src_parts = src[5:].split("/", 1)
            s3.delete_object(Bucket=src_parts[0], Key=src_parts[1], **owner_kwargs)
    else:
        # Local to local or local to S3
        with smart_open.open(src, "rb") as s_file, smart_open.open(dst, "wb") as d_file:
            d_file.write(s_file.read())
        if not isinstance(dst, str) or not dst.startswith("s3://"):
            os.remove(src)


def iterate_files(
    file_collection: List[Union[Path, str]],
) -> Iterator[Union[Path, str]]:
    """
    Iterate over a collection of files, yielding each file path.

    :param List[Union[Path, str]] file_collection: List of file paths or S3 URIs
    :yield: Each file path or S3 URI
    :rtype: Iterator[Union[Path, str]]
    """
    for file in file_collection:
        yield file


def get_processed_file_path(file_path: Union[str, Path], processed_folder: str = "processed") -> Union[str, Path]:
    """
    Generate a path for the processed file, handling both local and S3 paths.

    :param Union[str, Path] file_path: Original file path or S3 URI
    :param str processed_folder: Name of the folder for processed files (default: "processed")
    :return: Path or S3 URI for the processed file
    :rtype: Union[str, Path]
    """
    date_folder = datetime.now().strftime("%Y-%m-%d")
    if is_s3_path(file_path):
        s3_parts = file_path[5:].split("/")  # type: ignore  # is_s3_path ensures string
        bucket = s3_parts[0]
        key = "/".join(s3_parts[1:])
        new_key = f"{processed_folder}/{date_folder}/{os.path.basename(key)}"
        return f"s3://{bucket}/{new_key}"
    else:
        file_path = Path(file_path)
        new_path = file_path.parent / processed_folder / date_folder / file_path.name
        if not new_path.parent.exists():
            os.makedirs(new_path.parent, exist_ok=True)
        return new_path


def _should_include_file(
    file_path: str,
    file_name: str,
    exclude_non_scan_files: bool,
    file_excludes: list[str],
    directory_excludes: list[str],
) -> bool:
    """
    Determine whether a file should be included based on exclusion rules.

    :param str file_path: Full path to the file
    :param str file_name: Name of the file
    :param bool exclude_non_scan_files: Whether to apply file exclusion rules
    :param list[str] file_excludes: File extensions/patterns to exclude
    :param list[str] directory_excludes: Directory patterns to exclude
    :return: True if the file should be included
    :rtype: bool
    """
    if any(exclude_str in file_path for exclude_str in directory_excludes):
        return False
    if exclude_non_scan_files and any(exclude_str in file_name for exclude_str in file_excludes):
        return False
    if os.path.getsize(file_path) == 0:
        return False
    return True


def get_files_by_folder(
    import_folder: Union[str, Path],
    exclude_non_scan_files: bool,
    file_excludes: Optional[list[str]] = None,
    directory_excludes: Optional[list[str]] = None,
) -> List[str]:
    """
    Retrieves a list of file paths from a specified folder, excluding empty files or files that match the excludes list.

    :param Union[str, Path] import_folder: The path to the folder from which to retrieve file paths.
    :param bool exclude_non_scan_files: exclude files that are not scan files
    :param Optional[List[str]] file_excludes: List of file extensions to exclude from the list of files
    :param Optional[List[str]] directory_excludes: List of directories to exclude from the list of files
    :return: A list of file paths for all non-empty files in the specified folder and subsequent subfolders.
    :rtype: List[str]
    """
    if file_excludes is None:
        file_excludes = []
    if directory_excludes is None:
        directory_excludes = []
    file_path_list = []
    if not os.path.isdir(import_folder):
        from regscale.core.app.logz import create_logger

        logger = create_logger()
        logger.error(f"Folder '{import_folder}' does not exist.")
        return file_path_list
    for root, _dirs, files in os.walk(import_folder):
        for file in files:
            file_path = os.path.join(root, file)
            if _should_include_file(file_path, file, exclude_non_scan_files, file_excludes, directory_excludes):
                file_path_list.append(file_path)
    return file_path_list


def get_file_stream(path: str, expected_bucket_owner: Optional[str] = None) -> TextIO:
    """
    Get a file stream for either a local file or an S3 object.

    :param str path: The path to the file (local path or S3 URI in format s3://bucket/prefix)
    :param Optional[str] expected_bucket_owner: AWS account ID to verify S3 bucket ownership
    :return: A text file stream object
    :rtype: TextIO
    :raises ValueError: If the S3 path format is invalid
    :raises FileNotFoundError: If local file doesn't exist
    :raises Exception: For S3 access errors
    """
    import io

    from regscale.core.app.application import Application

    app = Application()
    config = app.config

    if is_s3_path(path):
        import boto3

        # Parse S3 path
        s3_parts = path[5:].split("/", 1)
        if len(s3_parts) != 2:
            raise ValueError(f"Invalid S3 path format: {path}. Expected s3://bucket/key")

        bucket, key = s3_parts
        owner_kwargs = {"ExpectedBucketOwner": expected_bucket_owner} if expected_bucket_owner else {}

        # Create a session
        session = boto3.Session(
            aws_access_key_id=config["awsAccessKey"],
            aws_secret_access_key=config["awsSecretKey"],
            region_name=config["awsRegion"],
        )

        # Create S3 client
        s3 = session.client("s3")

        try:
            # Get object from S3
            response = s3.get_object(Bucket=bucket, Key=key, **owner_kwargs)
            # Wrap the binary stream in a text wrapper
            return io.TextIOWrapper(response["Body"], encoding="utf-8")
        except ClientError as e:
            raise OSError(f"Error accessing S3 object {path}: {str(e)}")
    else:
        # Local file
        if not os.path.exists(path):
            raise FileNotFoundError(f"Local file not found: {path}")

        return open(path, "r", encoding="utf-8")


def _create_s3_session(
    aws_access_key_id: Optional[str] = None,
    aws_secret_access_key: Optional[str] = None,
    aws_session_token: Optional[str] = None,
    aws_profile: Optional[str] = None,
) -> "boto3.Session":
    """
    Create a boto3 session with the best available credentials.

    Priority: direct credentials > aws_profile > init.yaml config credentials.

    :param Optional[str] aws_access_key_id: AWS access key ID
    :param Optional[str] aws_secret_access_key: AWS secret access key
    :param Optional[str] aws_session_token: AWS session token for temporary credentials
    :param Optional[str] aws_profile: AWS profile name
    :return: A configured boto3 Session
    :rtype: boto3.Session
    """
    import boto3

    from regscale.core.app.application import Application

    config = Application().config

    if aws_access_key_id and aws_secret_access_key:
        return boto3.Session(
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
            aws_session_token=aws_session_token,
            region_name=config.get("awsRegion", "us-east-1"),
        )
    if aws_profile and aws_profile not in ("none", ""):
        return boto3.Session(profile_name=aws_profile)
    return boto3.Session(
        aws_access_key_id=config.get("awsAccessKey"),
        aws_secret_access_key=config.get("awsSecretKey"),
        region_name=config.get("awsRegion", "us-east-1"),
    )


def download_from_s3(
    bucket: str,
    prefix: str,
    local_path: Union[str, os.PathLike],
    aws_profile: Optional[str] = None,
    expected_bucket_owner: Optional[str] = None,
    aws_access_key_id: Optional[str] = None,
    aws_secret_access_key: Optional[str] = None,
    aws_session_token: Optional[str] = None,
) -> None:
    """
    Downloads files from an S3 bucket to a local directory.

    Credential priority: direct credentials > aws_profile > init.yaml config credentials.

    :param str bucket: Name of the S3 bucket
    :param str prefix: Prefix (folder path) within the bucket
    :param Union[str, PathLike] local_path: Local directory to download files to
    :param Optional[str] aws_profile: AWS profile to use for S3 access
    :param Optional[str] expected_bucket_owner: AWS account ID to verify S3 bucket ownership
    :param Optional[str] aws_access_key_id: AWS access key ID (overrides profile and config)
    :param Optional[str] aws_secret_access_key: AWS secret access key (overrides profile and config)
    :param Optional[str] aws_session_token: AWS session token for temporary credentials
    :rtype: None
    """
    import logging

    from botocore.exceptions import ClientError

    logger = logging.getLogger(__name__)
    session = _create_s3_session(aws_access_key_id, aws_secret_access_key, aws_session_token, aws_profile)
    s3_client = session.client("s3")
    owner_kwargs = {"ExpectedBucketOwner": expected_bucket_owner} if expected_bucket_owner else {}
    extra_args = {"ExpectedBucketOwner": expected_bucket_owner} if expected_bucket_owner else None

    try:
        local_dir = Path(local_path)
        local_dir.mkdir(parents=True, exist_ok=True)
        paginator = s3_client.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix, **owner_kwargs):
            for obj in page.get("Contents", []):
                if obj["Key"].endswith("/"):
                    continue
                filename = Path(obj["Key"]).name
                dest = str(local_dir / filename)
                logger.info("Downloading %s to %s", obj["Key"], dest)
                s3_client.download_file(bucket, obj["Key"], dest, ExtraArgs=extra_args)
    except ClientError as e:
        logger.error(f"Error downloading from S3: {str(e)}")
        raise S3FileDownloadError(f"Failed to download files from S3: {str(e)}")
