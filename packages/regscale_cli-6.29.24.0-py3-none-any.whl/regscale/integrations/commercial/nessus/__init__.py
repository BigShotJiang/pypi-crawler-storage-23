import warnings

# Suppress SyntaxWarning from nessus_file_reader's unescaped regex patterns.
# The upstream package (v0.8.0) has not fixed these; Python 3.12+ emits SyntaxWarning
# and Python 3.14+ will raise SyntaxError for invalid escape sequences.
warnings.filterwarnings("ignore", category=SyntaxWarning, module="nessus_file_reader")
