#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Tanium API Client for RegScale Integration.

This module provides a Python client for interacting with the Tanium platform via REST API
(on-premises) or GraphQL API Gateway (Tanium Cloud).

It supports authentication via session tokens and provides methods for retrieving endpoints,
vulnerabilities, and compliance findings from both deployment models.

Tanium API Documentation: https://developer.tanium.com/
"""

import logging
import urllib.parse
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

logger = logging.getLogger("regscale")

# Constants to avoid literal duplication
CONTENT_TYPE_JSON = "application/json"
ERROR_UNEXPECTED_RESPONSE = "Unexpected response type: %s"
API_VULNERABILITIES_ENDPOINT = "/api/v2/comply/vulnerabilities"

# Tanium Cloud constants
CLOUD_DOMAIN_SUFFIX = ".cloud.tanium.com"
GRAPHQL_ENDPOINT = "/plugin/products/gateway/graphql"

# API type constants
API_TYPE_AUTO = "auto"
API_TYPE_REST = "rest"
API_TYPE_GATEWAY = "gateway"

# GraphQL queries
GRAPHQL_CONNECTION_TEST_QUERY = "{ now }"

GRAPHQL_ENDPOINTS_QUERY = """
query getEndpoints($first: Int, $after: Cursor) {
  endpoints(first: $first, after: $after, source: {tds: {}}) {
    totalRecords
    edges {
      node {
        id
        computerID
        systemUUID
        name
        domainName
        serialNumber
        manufacturer
        model
        ipAddress
        macAddresses
        isVirtual
        chassisType
        lastLoggedInUser
        eidFirstSeen
        eidLastSeen
        os { name platform generation }
        processor { cpu }
      }
    }
    pageInfo { hasNextPage endCursor }
  }
}
"""

GRAPHQL_VULNERABILITIES_QUERY = """
query getVulnerabilities($first: Int, $after: Cursor) {
  endpoints(first: $first, after: $after, source: {tds: {}}) {
    totalRecords
    edges {
      node {
        name
        computerID
        ipAddress
        compliance {
          cveFindings {
            cveId
            cvssScore
            severity
            status
            firstFoundDate
            cveYear
            summary
          }
        }
      }
    }
    pageInfo { hasNextPage endCursor }
  }
}
"""

GRAPHQL_COMPLIANCE_QUERY = """
query getCompliance($first: Int, $after: Cursor) {
  endpoints(first: $first, after: $after, source: {tds: {}}) {
    totalRecords
    edges {
      node {
        name
        computerID
        ipAddress
        compliance {
          complianceFindings {
            standard
            standardVersion
            state
            id
            ruleId
          }
        }
      }
    }
    pageInfo { hasNextPage endCursor }
  }
}
"""


class TaniumAPIException(Exception):
    """Exception raised for Tanium API errors."""

    pass


class TaniumAPIClient:
    """
    Python client for Tanium REST API (on-prem) and GraphQL API Gateway (Cloud).

    Handles authentication, query execution, and result retrieval from Tanium.
    Uses session token authentication for API access. Automatically detects
    Cloud vs on-prem deployment when api_type is set to "auto".

    Example usage:
        >>> client = TaniumAPIClient(
        ...     base_url="https://tanium.example.com",
        ...     api_token="token-12345678-1234-1234-1234-123456789012"
        ... )
        >>> endpoints = client.get_endpoints()
    """

    # Default timeout for requests (30 seconds)
    DEFAULT_TIMEOUT = 30

    # Default page size for pagination
    DEFAULT_PAGE_SIZE = 100

    # Default page size for GraphQL cursor pagination
    DEFAULT_GRAPHQL_PAGE_SIZE = 500

    def __init__(
        self,
        base_url: str,
        api_token: str,
        verify_ssl: bool = True,
        timeout: int = DEFAULT_TIMEOUT,
        max_retries: int = 3,
        protocols: str = "https",
        api_type: str = API_TYPE_AUTO,
    ):
        """
        Initialize Tanium API client.

        Args:
            base_url: Tanium instance base URL (e.g., "https://tanium.example.com")
            api_token: Tanium API token for session authentication
            verify_ssl: Whether to verify SSL certificates
            timeout: Request timeout in seconds
            max_retries: Maximum number of retry attempts for failed requests
            protocols: Comma-separated list of allowed protocols (e.g., "https" or "https,http")
            api_type: API type - "auto" (detect from URL), "rest" (on-prem), "gateway" (Cloud GraphQL)
        """
        # Validate base_url
        if not base_url or not base_url.strip():
            raise TaniumAPIException("Tanium base URL is required. Please configure 'taniumUrl' in init.yaml")

        parsed = urllib.parse.urlparse(base_url.strip())
        if parsed.scheme not in ("http", "https"):
            raise TaniumAPIException("Tanium base URL must use http or https scheme. Got: '%s'" % base_url)

        self.base_url = base_url.rstrip("/")
        self.api_token = api_token
        self.verify_ssl = verify_ssl
        self.timeout = timeout
        self.protocols = [p.strip() for p in protocols.split(",")]

        # Detect and set API type
        self.api_type = self._resolve_api_type(api_type)

        # Validate Cloud URL if using gateway API
        if self.api_type == API_TYPE_GATEWAY:
            self._validate_cloud_url()

        # Create session with retry capability
        self.session = self._create_session(max_retries)

        # Set authentication and content type headers
        self.session.headers.update(
            {
                "session": self.api_token,
                "Content-Type": CONTENT_TYPE_JSON,
                "Accept": CONTENT_TYPE_JSON,
            }
        )

        logger.info("Tanium API client initialized for %s (api_type=%s)", self.base_url, self.api_type)

    @property
    def is_cloud(self) -> bool:
        """Check if client is configured for Tanium Cloud (Gateway API)."""
        return self.api_type == API_TYPE_GATEWAY

    def _resolve_api_type(self, api_type: str) -> str:
        """
        Resolve the API type to use.

        Args:
            api_type: Configured API type ("auto", "rest", "gateway")

        Returns:
            Resolved API type ("rest" or "gateway")
        """
        api_type_lower = api_type.lower().strip()

        if api_type_lower == API_TYPE_REST:
            return API_TYPE_REST
        if api_type_lower == API_TYPE_GATEWAY:
            return API_TYPE_GATEWAY
        if api_type_lower == API_TYPE_AUTO:
            return self._detect_api_type()

        logger.warning("Unknown taniumApiType '%s', falling back to auto-detection", api_type)
        return self._detect_api_type()

    def _detect_api_type(self) -> str:
        """
        Detect API type from the base URL.

        Returns:
            "gateway" if URL matches Tanium Cloud pattern, "rest" otherwise
        """
        parsed = urllib.parse.urlparse(self.base_url)
        hostname = parsed.hostname or ""

        if hostname.endswith(CLOUD_DOMAIN_SUFFIX):
            logger.info("Detected Tanium Cloud URL, using GraphQL API Gateway")
            return API_TYPE_GATEWAY

        return API_TYPE_REST

    def _validate_cloud_url(self) -> None:
        """
        Validate Cloud URL and warn about common misconfigurations.

        Tanium Cloud API Gateway requires the -api subdomain
        (e.g., customer-api.cloud.tanium.com, not customer.cloud.tanium.com).
        """
        parsed = urllib.parse.urlparse(self.base_url)
        hostname = parsed.hostname or ""

        if not hostname.endswith(CLOUD_DOMAIN_SUFFIX):
            return

        # Extract the subdomain part before .cloud.tanium.com
        subdomain = hostname[: -len(CLOUD_DOMAIN_SUFFIX)]

        if not subdomain.endswith("-api"):
            logger.warning(
                "Tanium Cloud URL '%s' does not use the -api subdomain. "
                "The Cloud API Gateway typically requires the -api subdomain "
                "(e.g., '%s-api%s'). If you experience connection issues, "
                "update 'taniumUrl' in init.yaml to use the -api URL.",
                self.base_url,
                subdomain,
                CLOUD_DOMAIN_SUFFIX,
            )

    def _create_session(self, max_retries: int) -> requests.Session:
        """
        Create a requests session with retry capability.

        Args:
            max_retries: Maximum number of retry attempts

        Returns:
            Configured requests.Session object
        """
        session = requests.Session()

        # Configure retry strategy for transient errors
        retry_strategy = Retry(
            total=max_retries,
            backoff_factor=0.5,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "POST", "PUT", "DELETE"],
        )

        adapter = HTTPAdapter(max_retries=retry_strategy)

        # Mount adapters only for configured protocols
        for protocol in self.protocols:
            protocol_lower = protocol.lower()
            if protocol_lower in ["http", "https"]:
                session.mount("%s://" % protocol_lower, adapter)
                logger.debug("Mounted adapter for protocol: %s", protocol_lower)
            else:
                logger.warning("Ignoring unsupported protocol: %s", protocol)

        if not self.verify_ssl:
            # Disable SSL warnings if verification is disabled
            import urllib3

            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            logger.warning("SSL verification is disabled - not recommended for production")

        return session

    # -------------------------------------------------------------------------
    # REST API methods (on-premises Tanium)
    # -------------------------------------------------------------------------

    def _make_request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Union[Dict[str, Any], str]:
        """
        Make an HTTP request to the Tanium API.

        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint path
            params: Query parameters
            data: Request body data
            headers: Additional headers (overrides session headers)

        Returns:
            Response data (JSON dict or text)

        Raises:
            TaniumAPIException: If the request fails
        """
        url = urllib.parse.urljoin(self.base_url + "/", endpoint.lstrip("/"))

        # Merge additional headers with session headers
        request_headers = dict(self.session.headers)
        if headers:
            request_headers.update(headers)

        try:
            response = self.session.request(
                method=method,
                url=url,
                params=params,
                json=data,
                headers=request_headers,
                timeout=self.timeout,
                verify=self.verify_ssl,
            )

            # Check for HTTP errors
            response.raise_for_status()

            # Return JSON if content-type is JSON, otherwise handle non-JSON
            content_type = response.headers.get("Content-Type", "")
            if CONTENT_TYPE_JSON in content_type:
                return response.json()

            # Detect HTML responses (common misconfiguration: using UI URL instead of API URL)
            if "text/html" in content_type:
                raise TaniumAPIException(
                    "Received HTML response instead of JSON. This usually means the URL is pointing "
                    "to the Tanium web UI instead of the API. For Tanium Cloud, use the -api subdomain "
                    "(e.g., 'https://customer-api.cloud.tanium.com'). "
                    "For on-prem, verify the URL is the Tanium server, not a load balancer or proxy."
                )

            return response.text

        except requests.exceptions.HTTPError as e:
            error_text = e.response.text if e.response is not None else "No response body"
            status_code = e.response.status_code if e.response is not None else "Unknown"
            error_msg = "HTTP %s: %s" % (status_code, error_text)

            # Provide helpful hint for Cloud-specific errors
            if "Invalid object route" in error_text:
                error_msg += (
                    " — This error typically occurs when using Tanium Cloud with REST API v2 endpoints. "
                    "Tanium Cloud requires the GraphQL API Gateway. "
                    "Set 'taniumApiType: gateway' in init.yaml or use an -api subdomain URL."
                )

            logger.error("Tanium API request failed: %s", error_msg)
            raise TaniumAPIException(error_msg) from e

        except requests.exceptions.RequestException as e:
            logger.error("Tanium API request failed: %s", str(e))
            raise TaniumAPIException("Request failed: %s" % str(e)) from e

    # -------------------------------------------------------------------------
    # GraphQL API Gateway methods (Tanium Cloud)
    # -------------------------------------------------------------------------

    def _make_graphql_request(
        self,
        query: str,
        variables: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Make a GraphQL request to the Tanium Cloud API Gateway.

        Args:
            query: GraphQL query string
            variables: GraphQL query variables

        Returns:
            GraphQL response data dictionary

        Raises:
            TaniumAPIException: If the request fails or returns GraphQL errors
        """
        payload: Dict[str, Any] = {"query": query}
        if variables:
            payload["variables"] = variables

        response = self._make_request("POST", GRAPHQL_ENDPOINT, data=payload)

        if not isinstance(response, dict):
            raise TaniumAPIException(
                "GraphQL request returned non-JSON response. "
                "Verify the Tanium Cloud URL is correct and uses the -api subdomain."
            )

        # Check for GraphQL errors
        errors = response.get("errors")
        if errors:
            error_messages = "; ".join(e.get("message", "Unknown error") for e in errors)
            raise TaniumAPIException("GraphQL errors: %s" % error_messages)

        return response.get("data", {})

    def _paginate_graphql(
        self,
        query: str,
        extract_fn: Callable[[Dict[str, Any]], Tuple[List[Dict[str, Any]], bool, Optional[str]]],
        page_size: int = DEFAULT_GRAPHQL_PAGE_SIZE,
    ) -> List[Dict[str, Any]]:
        """
        Generic cursor-based pagination for GraphQL queries.

        Args:
            query: GraphQL query with $first and $after variables
            extract_fn: Function that extracts (items, has_next_page, end_cursor) from response data
            page_size: Number of results per page

        Returns:
            List of all result items
        """
        all_items: List[Dict[str, Any]] = []
        cursor: Optional[str] = None

        while True:
            variables: Dict[str, Any] = {"first": page_size}
            if cursor:
                variables["after"] = cursor

            data = self._make_graphql_request(query, variables)
            items, has_next_page, end_cursor = extract_fn(data)

            all_items.extend(items)

            if not has_next_page or not items:
                break

            cursor = end_cursor
            logger.debug("GraphQL pagination: fetched %s items so far...", len(all_items))

        return all_items

    def _graphql_test_connection(self) -> bool:
        """
        Test connection to Tanium Cloud via GraphQL API Gateway.

        Returns:
            True if connection is successful

        Raises:
            TaniumAPIException: If connection test fails
        """
        data = self._make_graphql_request(GRAPHQL_CONNECTION_TEST_QUERY)
        now_value = data.get("now")
        if now_value:
            logger.info("Successfully connected to Tanium Cloud (server time: %s)", now_value)
        else:
            logger.info("Successfully connected to Tanium Cloud API Gateway")
        return True

    def _graphql_get_all_endpoints(self, page_size: int = DEFAULT_GRAPHQL_PAGE_SIZE) -> List[Dict[str, Any]]:
        """
        Fetch all endpoints via GraphQL API Gateway and normalize to REST format.

        Args:
            page_size: Number of results per page

        Returns:
            List of endpoint records in REST-compatible format
        """

        def extract_endpoints(data: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], bool, Optional[str]]:
            endpoints_data = data.get("endpoints", {})
            edges = endpoints_data.get("edges", [])
            page_info = endpoints_data.get("pageInfo", {})
            items = [self._normalize_graphql_endpoint(edge["node"]) for edge in edges if edge.get("node")]
            return items, page_info.get("hasNextPage", False), page_info.get("endCursor")

        endpoints = self._paginate_graphql(GRAPHQL_ENDPOINTS_QUERY, extract_endpoints, page_size)
        logger.info("Retrieved total of %s endpoints via GraphQL", len(endpoints))
        return endpoints

    def _graphql_get_all_vulnerabilities(self, page_size: int = DEFAULT_GRAPHQL_PAGE_SIZE) -> List[Dict[str, Any]]:
        """
        Fetch all CVE findings via GraphQL API Gateway and normalize to REST format.

        In Tanium Cloud's GraphQL API, CVE findings are nested under endpoints.
        This method flattens them into individual vulnerability records.

        Args:
            page_size: Number of results per page

        Returns:
            List of vulnerability records in REST-compatible format
        """

        def extract_vulnerabilities(data: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], bool, Optional[str]]:
            endpoints_data = data.get("endpoints", {})
            edges = endpoints_data.get("edges", [])
            page_info = endpoints_data.get("pageInfo", {})

            items: List[Dict[str, Any]] = []
            for edge in edges:
                node = edge.get("node")
                if not node:
                    continue
                compliance = node.get("compliance") or {}
                cve_findings = compliance.get("cveFindings") or []
                for cve in cve_findings:
                    items.append(self._normalize_graphql_cve_finding(cve, node))

            return items, page_info.get("hasNextPage", False), page_info.get("endCursor")

        vulns = self._paginate_graphql(GRAPHQL_VULNERABILITIES_QUERY, extract_vulnerabilities, page_size)
        logger.info("Retrieved total of %s vulnerability findings via GraphQL", len(vulns))
        return vulns

    def _graphql_get_compliance_findings(
        self,
        page_size: int = DEFAULT_GRAPHQL_PAGE_SIZE,
        status: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Fetch compliance findings via GraphQL API Gateway and normalize to REST format.

        Args:
            page_size: Number of results per page
            status: Optional status filter (e.g., "Fail")

        Returns:
            List of compliance finding records in REST-compatible format
        """

        def extract_compliance(data: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], bool, Optional[str]]:
            endpoints_data = data.get("endpoints", {})
            edges = endpoints_data.get("edges", [])
            page_info = endpoints_data.get("pageInfo", {})

            items: List[Dict[str, Any]] = []
            for edge in edges:
                node = edge.get("node")
                if not node:
                    continue
                compliance = node.get("compliance") or {}
                findings = compliance.get("complianceFindings") or []
                for finding in findings:
                    normalized = self._normalize_graphql_compliance_finding(finding, node)
                    # Apply status filter if specified
                    if status and normalized.get("status", "").lower() != status.lower():
                        continue
                    items.append(normalized)

            return items, page_info.get("hasNextPage", False), page_info.get("endCursor")

        findings = self._paginate_graphql(GRAPHQL_COMPLIANCE_QUERY, extract_compliance, page_size)
        logger.info("Retrieved total of %s compliance findings via GraphQL", len(findings))
        return findings

    # -------------------------------------------------------------------------
    # GraphQL response normalization (Cloud → REST-compatible format)
    # -------------------------------------------------------------------------

    @staticmethod
    def _normalize_graphql_endpoint(node: Dict[str, Any]) -> Dict[str, Any]:
        """
        Normalize a GraphQL endpoint node to REST API format.

        Args:
            node: GraphQL endpoint node

        Returns:
            Dictionary in REST API endpoint format for TaniumEndpoint.from_tanium_data()
        """
        os_data = node.get("os") or {}
        processor_data = node.get("processor") or {}
        mac_addresses = node.get("macAddresses") or []

        # Build OS name from components
        os_name = os_data.get("name", "")
        os_version = os_data.get("generation", "")

        return {
            "id": node.get("id", 0),
            "computerName": node.get("name", ""),
            "computerID": node.get("computerID"),
            "domainName": node.get("domainName"),
            "ipAddress": node.get("ipAddress"),
            "ipAddresses": [],
            "macAddress": mac_addresses[0] if mac_addresses else None,
            "manufacturer": node.get("manufacturer"),
            "model": node.get("model"),
            "osName": os_name,
            "osVersion": os_version,
            "serialNumber": node.get("serialNumber"),
            "lastLoggedInUser": node.get("lastLoggedInUser"),
            "lastSeen": node.get("eidLastSeen"),
            "firstSeen": node.get("eidFirstSeen"),
            "isVirtual": node.get("isVirtual", False),
            "chassisType": node.get("chassisType"),
            "cpuModel": processor_data.get("cpu"),
            "tags": [],
        }

    @staticmethod
    def _normalize_graphql_cve_finding(
        cve_finding: Dict[str, Any],
        endpoint_node: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Normalize a GraphQL CVE finding to REST API vulnerability format.

        Args:
            cve_finding: GraphQL CVE finding data
            endpoint_node: Parent endpoint node (for endpoint context)

        Returns:
            Dictionary in REST API vulnerability format for TaniumVulnerability.from_tanium_data()
        """
        cve_id = cve_finding.get("cveId", "")
        return {
            "id": cve_id,
            "cveId": cve_id,
            "title": cve_id,
            "description": cve_finding.get("summary", ""),
            "severity": cve_finding.get("severity"),
            "cvssScore": cve_finding.get("cvssScore"),
            "firstDetected": cve_finding.get("firstFoundDate"),
            "affectedEndpointCount": 1,
            "affectedEndpoints": [
                {
                    "id": endpoint_node.get("computerID"),
                    "computerName": endpoint_node.get("name"),
                    "ipAddress": endpoint_node.get("ipAddress"),
                }
            ],
        }

    @staticmethod
    def _normalize_graphql_compliance_finding(
        finding: Dict[str, Any],
        endpoint_node: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Normalize a GraphQL compliance finding to REST API format.

        Args:
            finding: GraphQL compliance finding data
            endpoint_node: Parent endpoint node (for endpoint context)

        Returns:
            Dictionary in REST API compliance format for TaniumComplianceFinding.from_tanium_data()
        """
        # Map GraphQL "state" values to REST-compatible status values
        state = finding.get("state", "Unknown")
        status_map = {
            "pass": "Pass",
            "fail": "Fail",
            "error": "Error",
            "notapplicable": "NotApplicable",
            "na": "NotApplicable",
        }
        status = status_map.get(state.lower(), state) if state else "Unknown"

        computer_id = endpoint_node.get("computerID")

        return {
            "id": finding.get("id", ""),
            "ruleId": finding.get("ruleId", ""),
            "benchmark": finding.get("standard"),
            "benchmarkVersion": finding.get("standardVersion"),
            "status": status,
            "endpointId": int(computer_id) if computer_id else None,
            "endpointName": endpoint_node.get("name"),
        }

    # -------------------------------------------------------------------------
    # Public API methods (dispatch between REST and GraphQL)
    # -------------------------------------------------------------------------

    def test_connection(self) -> bool:
        """
        Test the connection to Tanium API.

        Returns:
            True if connection is successful

        Raises:
            TaniumAPIException: If connection test fails
        """
        if self.is_cloud:
            try:
                return self._graphql_test_connection()
            except TaniumAPIException as exc:
                logger.error("Connection test failed: %s", str(exc))
                raise

        try:
            response = self._make_request("GET", "/api/v2/session/info")

            if isinstance(response, dict):
                user_name = response.get("data", {}).get("userName", "Unknown")
                logger.info("Successfully connected to Tanium as user: %s", user_name)

            return True
        except TaniumAPIException as exc:
            logger.error("Connection test failed: %s", str(exc))
            raise

    def get_server_info(self) -> Dict[str, Any]:
        """
        Get Tanium server information.

        Returns:
            Server info dictionary

        Raises:
            TaniumAPIException: If request fails
        """
        if self.is_cloud:
            # GraphQL doesn't have a direct server info equivalent; return basic info
            data = self._make_graphql_request(GRAPHQL_CONNECTION_TEST_QUERY)
            return {"serverTime": data.get("now"), "deployment": "cloud", "apiType": "gateway"}

        response = self._make_request("GET", "/api/v2/session/info")

        if not isinstance(response, dict):
            raise TaniumAPIException(ERROR_UNEXPECTED_RESPONSE % type(response).__name__)

        return response.get("data", {})

    def get_endpoints(
        self,
        limit: int = DEFAULT_PAGE_SIZE,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """
        Fetch endpoints/assets from Tanium.

        Args:
            limit: Maximum number of results to return
            offset: Offset for pagination

        Returns:
            List of endpoint records

        Raises:
            TaniumAPIException: If request fails
        """
        if self.is_cloud:
            # GraphQL uses cursor pagination; fetch a page of size=limit
            all_endpoints = self._graphql_get_all_endpoints(page_size=limit)
            return all_endpoints[:limit]

        params = {"limit": limit, "offset": offset}
        response = self._make_request("GET", "/api/v2/endpoints", params=params)

        if not isinstance(response, dict):
            raise TaniumAPIException(ERROR_UNEXPECTED_RESPONSE % type(response).__name__)

        return response.get("data", [])

    def get_endpoint_by_id(self, endpoint_id: int) -> Dict[str, Any]:
        """
        Fetch a single endpoint by ID.

        Args:
            endpoint_id: The endpoint ID

        Returns:
            Endpoint record

        Raises:
            TaniumAPIException: If request fails
        """
        if self.is_cloud:
            # GraphQL doesn't have a single-endpoint query; search all and filter
            logger.warning("get_endpoint_by_id is not natively supported on Tanium Cloud GraphQL API")
            all_endpoints = self._graphql_get_all_endpoints()
            for ep in all_endpoints:
                if str(ep.get("id")) == str(endpoint_id) or str(ep.get("computerID")) == str(endpoint_id):
                    return ep
            raise TaniumAPIException("Endpoint with ID %s not found" % endpoint_id)

        response = self._make_request("GET", "/api/v2/endpoints/%s" % endpoint_id)

        if not isinstance(response, dict):
            raise TaniumAPIException(ERROR_UNEXPECTED_RESPONSE % type(response).__name__)

        return response.get("data", {})

    def get_all_endpoints(self, page_size: int = DEFAULT_PAGE_SIZE) -> List[Dict[str, Any]]:
        """
        Fetch all endpoints with pagination support.

        Args:
            page_size: Number of results per page

        Returns:
            List of all endpoint records

        Raises:
            TaniumAPIException: If request fails
        """
        if self.is_cloud:
            return self._graphql_get_all_endpoints(page_size=page_size)

        all_endpoints: List[Dict[str, Any]] = []
        offset = 0

        while True:
            params = {"limit": page_size, "offset": offset}
            response = self._make_request("GET", "/api/v2/endpoints", params=params)

            if not isinstance(response, dict):
                raise TaniumAPIException(ERROR_UNEXPECTED_RESPONSE % type(response).__name__)

            data = response.get("data", [])
            all_endpoints.extend(data)

            # Check if there are more results
            pagination = response.get("pagination", {})
            has_more = pagination.get("hasMore", False)

            if not has_more or not data:
                break

            offset += page_size
            logger.debug("Fetched %s endpoints, continuing pagination...", len(all_endpoints))

        logger.info("Retrieved total of %s endpoints", len(all_endpoints))
        return all_endpoints

    def get_vulnerabilities(
        self,
        limit: int = DEFAULT_PAGE_SIZE,
        offset: int = 0,
        severity: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Fetch vulnerabilities from Tanium Comply module.

        Args:
            limit: Maximum number of results to return
            offset: Offset for pagination
            severity: Filter by severity (Critical, High, Medium, Low)

        Returns:
            List of vulnerability records

        Raises:
            TaniumAPIException: If request fails
        """
        if self.is_cloud:
            vulns = self._graphql_get_all_vulnerabilities(page_size=limit)
            if severity:
                vulns = [v for v in vulns if (v.get("severity") or "").lower() == severity.lower()]
            return vulns[:limit]

        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        if severity:
            params["severity"] = severity

        response = self._make_request("GET", API_VULNERABILITIES_ENDPOINT, params=params)

        if not isinstance(response, dict):
            raise TaniumAPIException(ERROR_UNEXPECTED_RESPONSE % type(response).__name__)

        return response.get("data", [])

    def get_vulnerabilities_for_endpoint(
        self,
        endpoint_id: int,
        limit: int = DEFAULT_PAGE_SIZE,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """
        Fetch vulnerabilities for a specific endpoint.

        Args:
            endpoint_id: The endpoint ID
            limit: Maximum number of results to return
            offset: Offset for pagination

        Returns:
            List of vulnerability records for the endpoint

        Raises:
            TaniumAPIException: If request fails
        """
        if self.is_cloud:
            all_vulns = self._graphql_get_all_vulnerabilities()
            filtered = [
                v
                for v in all_vulns
                if any(str(ep.get("id")) == str(endpoint_id) for ep in v.get("affectedEndpoints", []))
            ]
            return filtered[:limit]

        params = {"limit": limit, "offset": offset, "endpointId": endpoint_id}
        response = self._make_request("GET", API_VULNERABILITIES_ENDPOINT, params=params)

        if not isinstance(response, dict):
            raise TaniumAPIException(ERROR_UNEXPECTED_RESPONSE % type(response).__name__)

        return response.get("data", [])

    def get_all_vulnerabilities(self, page_size: int = DEFAULT_PAGE_SIZE) -> List[Dict[str, Any]]:
        """
        Fetch all vulnerabilities with pagination support.

        Args:
            page_size: Number of results per page

        Returns:
            List of all vulnerability records

        Raises:
            TaniumAPIException: If request fails
        """
        if self.is_cloud:
            return self._graphql_get_all_vulnerabilities(page_size=page_size)

        all_vulns: List[Dict[str, Any]] = []
        offset = 0

        while True:
            params = {"limit": page_size, "offset": offset}
            response = self._make_request("GET", API_VULNERABILITIES_ENDPOINT, params=params)

            if not isinstance(response, dict):
                raise TaniumAPIException(ERROR_UNEXPECTED_RESPONSE % type(response).__name__)

            data = response.get("data", [])
            all_vulns.extend(data)

            # Check if there are more results
            pagination = response.get("pagination", {})
            has_more = pagination.get("hasMore", False)

            if not has_more or not data:
                break

            offset += page_size
            logger.debug("Fetched %s vulnerabilities, continuing pagination...", len(all_vulns))

        logger.info("Retrieved total of %s vulnerabilities", len(all_vulns))
        return all_vulns

    def get_compliance_findings(
        self,
        limit: int = DEFAULT_PAGE_SIZE,
        offset: int = 0,
        status: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Fetch compliance findings from Tanium Comply module.

        Args:
            limit: Maximum number of results to return
            offset: Offset for pagination
            status: Filter by status (Pass, Fail, Error, NotApplicable)

        Returns:
            List of compliance finding records

        Raises:
            TaniumAPIException: If request fails
        """
        if self.is_cloud:
            return self._graphql_get_compliance_findings(page_size=limit, status=status)

        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        if status:
            params["status"] = status

        response = self._make_request("GET", "/api/v2/comply/findings", params=params)

        if not isinstance(response, dict):
            raise TaniumAPIException(ERROR_UNEXPECTED_RESPONSE % type(response).__name__)

        return response.get("data", [])

    def get_compliance_findings_for_endpoint(
        self,
        endpoint_id: int,
        limit: int = DEFAULT_PAGE_SIZE,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """
        Fetch compliance findings for a specific endpoint.

        Args:
            endpoint_id: The endpoint ID
            limit: Maximum number of results to return
            offset: Offset for pagination

        Returns:
            List of compliance finding records for the endpoint

        Raises:
            TaniumAPIException: If request fails
        """
        if self.is_cloud:
            all_findings = self._graphql_get_compliance_findings()
            return [f for f in all_findings if str(f.get("endpointId")) == str(endpoint_id)][:limit]

        params = {"limit": limit, "offset": offset, "endpointId": endpoint_id}
        response = self._make_request("GET", "/api/v2/comply/findings", params=params)

        if not isinstance(response, dict):
            raise TaniumAPIException(ERROR_UNEXPECTED_RESPONSE % type(response).__name__)

        return response.get("data", [])

    def get_compliance_benchmarks(self) -> List[Dict[str, Any]]:
        """
        Fetch available compliance benchmarks.

        Returns:
            List of compliance benchmark records

        Raises:
            TaniumAPIException: If request fails
        """
        if self.is_cloud:
            logger.warning(
                "Compliance benchmarks listing is not available via Tanium Cloud GraphQL API. "
                "Returning empty list. Use sync_findings to get compliance data."
            )
            return []

        response = self._make_request("GET", "/api/v2/comply/benchmarks")

        if not isinstance(response, dict):
            raise TaniumAPIException(ERROR_UNEXPECTED_RESPONSE % type(response).__name__)

        return response.get("data", [])
