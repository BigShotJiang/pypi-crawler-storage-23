#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Integrates CSAM into RegScale"""

# standard python imports
import logging
from typing import List, Tuple

from rich.console import Console
from rich.progress import track

from regscale.core.app.application import Application
from regscale.core.app.config import get_configured_values
from regscale.core.app.utils.api_handler import APIInsertionError, APIUpdateError
from regscale.core.app.utils.app_utils import error_and_exit, filter_list
from regscale.core.app.utils.parser_utils import safe_date_str
from regscale.integrations.public.csam.csam_common import (
    CSAM_FIELD_NAME,
    SSP_BASIC_TAB,
    clean_rich_text,
    csam_user_to_regscale_map,
    fix_form_field_value,
    retrieve_from_csam,
    retrieve_ssps_custom_form_map,
    trim_ssp_list,
)
from regscale.models.regscale_models import Issue, Milestone
from regscale.models.regscale_models.form_field_value import FormFieldValue
from regscale.models.regscale_models.regscale_model import RegScaleModel

logger = logging.getLogger("regscale")
console = Console()

####################################################################################################
#
# IMPORT SSP / POAM FROM DoJ's CSAM GRC
# CSAM API Docs: https://csam.dhs.gov/CSAM/api/docs/index.html (required PIV)
#
####################################################################################################

SEVERITY_NOT_ASSIGNED = "IV - Not Assigned"
CUSTOM_FIELDS_BASIC_LIST = ["User Identified Criticality"]


def import_csam_poams():
    """
    Import the POA&Ms from CSAM
    """

    # Grab the data from CSAM
    app = Application()
    # Get only configured (non-placeholder) filter values
    csam_filter = get_configured_values(app.config.get("csamFilter"))

    logger.info("Retrieving systems from CSAM...")
    results = retrieve_from_csam(
        csam_endpoint="/CSAM/api/v1/systems",
    )

    if not results:
        error_and_exit("Failure to retrieve plans from CSAM")
    else:
        logger.info("Retrieved plans from CSAM, parsing results...")

    results = filter_list(results, csam_filter)
    if not results:
        error_and_exit(
            "No results match filter in CSAM. \
                       Please check your CSAM configuration."
        )

    # Get existing ssps by CSAM Id
    custom_fields_basic_map = FormFieldValue.check_custom_fields([CSAM_FIELD_NAME], "securityplans", SSP_BASIC_TAB)

    # Get a map of existing custom forms
    ssp_map = retrieve_ssps_custom_form_map(
        tab_name=SSP_BASIC_TAB, field_form_id=custom_fields_basic_map[CSAM_FIELD_NAME]
    )

    # Trim the ssp_map to just the CSAM ids in results
    ssp_map = trim_ssp_list(results=results, ssp_map=ssp_map)

    plans = list(ssp_map.keys())

    issue_fields_map = FormFieldValue.check_custom_fields(CUSTOM_FIELDS_BASIC_LIST, "issues", "Basic Info")

    all_issues = []
    all_custom = []
    logger.info(f"Retrieving POA&Ms for {len(plans)} SSPs...")
    for regscale_ssp_id in plans:
        results = []
        system_id = ssp_map.get(regscale_ssp_id)

        results = retrieve_from_csam(
            csam_endpoint=f"/CSAM/api/v1/systems/{system_id}/poams",
        )

        if not results:
            logger.warning(f"No POA&MS found for CSAM id: {system_id}, RegScale id: {regscale_ssp_id}")
            continue

        issues, custom_fields = process_poam(
            results=results, regscale_id=regscale_ssp_id, csam_id=system_id, issue_fields_map=issue_fields_map
        )

        all_issues.extend(issues)
        all_custom.extend(custom_fields)

    new_issues = create_issues(poam_list=all_issues, ssp_map=ssp_map)
    add_custom_fields(issues_map=new_issues, custom_fields=all_custom)


def process_poam(results: list, regscale_id: int, csam_id: int, issue_fields_map: dict) -> Tuple[List, List]:
    """
    Process the results from the CSAM query
    per CSAM system

    :param results: results from CSAM
    :param regscale_id: id of RegScale SSP
    :param csam_id: id of the CSAM Record
    :param issue_fields_map: map of custom field name to id
    :return: list of RegScale Issues
    :return: list of custom fields
    :return_type: Tuple[List,List]
    """
    severity_map = {
        "Critical": "0 - Critical - Must be Fixed",
        "High": "I - High - Significant Deficiency",
        "Medium": "II - Moderate - Reportable Condition",
        "Low": "III - Low - Other Weakness",
        "N/A": SEVERITY_NOT_ASSIGNED,
        "None": SEVERITY_NOT_ASSIGNED,
    }
    status_map = {
        "Cancelled": "Cancelled",
        "Completed": "Closed",
        "In Progress": "Open",
        "Not Started": "Open",
        "Delayed": "Delayed",
        "Planned/Pending": "Open",
    }

    field_values = []

    # Parse the results
    poam_list = []
    for index in track(
        range(len(results)),
        description=f"Building {len(results)} POA&Ms for SSP {regscale_id}...",
    ):
        result = results[index]

        # Get the affected controls
        controls = get_poam_controls(poam_id=result.get("poamId"), csam_id=csam_id)

        # Check if the POAM exists:
        existing_issue = Issue.find_by_other_identifier(result.get("poamId"))
        if existing_issue:
            new_issue = existing_issue[0]
        else:
            new_issue = Issue()

        # Update the issue
        new_issue.isPoam = True
        new_issue.parentId = regscale_id
        new_issue.parentModule = "securityplans"
        new_issue.otherIdentifier = result.get("poamId")
        new_issue.title = result.get("title")
        new_issue.securityPlanId = regscale_id
        new_issue.identification = "Other"
        new_issue.costEstimate = result.get("cost")
        new_issue.description = clean_rich_text(result.get("description"))
        new_issue.sourceReport = "Imported from CSAM"
        new_issue.dueDate = safe_date_str(result.get("plannedFinishDate"))
        new_issue.dateCompleted = (
            safe_date_str(result.get("actualFinishDate")) if result.get("actualFinishDate") else ""
        )
        new_issue.affectedControls = controls
        new_issue.poamComments = result.get("delayReason")
        # Update with IssueSeverity String
        severity = severity_map.get(result.get("csamDerivedSeverity"))
        if not severity:
            severity = SEVERITY_NOT_ASSIGNED
        new_issue.severityLevel = severity
        # Update with IssueStatus String
        new_issue.status = status_map.get(result.get("status"))
        if not new_issue.status:
            new_issue.status = "Open"
        # Handle when the issue is open, or pending, or delayed and still has as "date closed"
        if new_issue.status != "Closed":
            new_issue.dateCompleted = None

        poam_list.append(new_issue)

        # Setup custom fields
        user_severity = severity_map.get(result.get("userIdentifiedCriticality"))
        if not user_severity:
            user_severity = SEVERITY_NOT_ASSIGNED
        field_values.append(
            {
                "record_id": result.get("poamId"),  # Use the poam id for now
                "record_module": "issues",
                "form_field_id": issue_fields_map.get("User Identified Criticality"),
                "field_value": user_severity,
            }
        )

    return poam_list, field_values


def get_poam_controls(poam_id: int, csam_id: int) -> str:
    controls = []

    results = retrieve_from_csam(csam_endpoint=f"/CSAM/api/v1/systems/{csam_id}/poams/{poam_id}/controls")

    if len(results) == 0:
        return ""

    for result in results:
        if result.get("controlSet") == "NIST 800-53 Rev5":
            controls.append(result.get("controlId"))

    affected_controls = ", ".join(controls)

    return affected_controls


def create_issues(poam_list: list, ssp_map: dict) -> dict:
    """
    Create the RegScale Poams from a list
    of RegScale Issues

    :param poam_list: list of RegScale issues
    :param ssp_map: dict map of ssp_id to csam_id
    :return: map of new issues
    :rtype: dict
    """
    user_map = csam_user_to_regscale_map()
    issue_map = {}
    for index in track(
        range(len(poam_list)),
        description=f"Updating RegScale with {len(poam_list)} POA&Ms...",
    ):
        poam = poam_list[index]
        if poam.id == 0:
            try:
                new_poam = poam.create()
            except APIInsertionError:
                continue
            else:
                poam.id = new_poam.id
        else:
            try:
                poam.save()
            except APIUpdateError:
                continue

        # Get the milestones
        csam_id = ssp_map.get(poam.parentId)
        get_poam_milestones(
            csam_id=csam_id,
            poam_id=poam.otherIdentifier,
            issue_id=poam.id,
            user_map=user_map,
        )
        issue_map[poam.otherIdentifier] = poam.id

    logger.info(f"Added or updated {len(poam_list)} POA&Ms in RegScale")
    return issue_map


def get_poam_milestones(csam_id: int, poam_id: int, issue_id: int, user_map: dict):
    """
    Retrieve milestones from CSAM
    Update RegScale issues/POA&Ms with milestones

    :param casm_id: id of the CSAM system
    :param poam_id: id of the CSAM Milestone
    :param issue_id: id of the RegScale Issue
    :param user_map: dictionary of CSAM to RegScale users
    """

    # Get the milestones from CSAM
    milestones = retrieve_from_csam(csam_endpoint=f"/CSAM/api/v1/systems/{csam_id}/poams/{poam_id}/milestones")

    # Get the milestones from RegScale
    reg_milestones = []
    reg_milestones = Milestone.get_all_by_parent(parent_id=issue_id, parent_module="issues")
    milestones_map = {ms.title: ms.id for ms in reg_milestones}

    for milestone in milestones:
        # Check if exists
        ms_id = milestones_map.get(milestone.get("description")) or 0

        reg_milestone = Milestone(
            id=ms_id,
            title=clean_rich_text(milestone.get("description")),
            responsiblePersonId=user_map.get(milestone.get("assignedToPocId")) or RegScaleModel.get_user_id(),
            predecessorStepId=None,
            completed=True if milestone.get("status") == "Completed" else False,
            dateCompleted=milestone.get("actualFinishDate"),
            notes=str(milestone.get("addiData")),
            parentID=issue_id,
            parentModule="issues",
        )
        if not ms_id:
            reg_milestone.create()
        else:
            reg_milestone.save()


def add_custom_fields(issues_map: dict, custom_fields: list):
    """
    Parses and uploads the custom fields to RegScale
    Updates the formfieldvalue list with the issue id

    :param issues_map: dict map of poam_id: issues.id
    :param custom_fields: list of all custom fields to be added
    :return: None
    """
    logger.info("Uploading custom field values")

    for custom_field in custom_fields:
        # Find the RegScale issue id
        issue_id = issues_map.get(custom_field.get("record_id"))

        # Update the record
        custom_field["record_id"] = issue_id

    # Save them all
    custom_fields = fix_form_field_value(custom_fields)
    FormFieldValue.save_custom_fields(custom_fields)
