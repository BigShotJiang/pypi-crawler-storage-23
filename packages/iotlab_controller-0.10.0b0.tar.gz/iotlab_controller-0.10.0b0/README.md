# iotlab_controller
![PyPI](https://img.shields.io/pypi/v/iotlab-controller)
[![Tox testing](https://github.com/miri64/iotlab_controller/actions/workflows/tox.yml/badge.svg?branch=master)](https://github.com/miri64/iotlab_controller/actions/workflows/tox.yml)
[![codecov](https://codecov.io/gh/miri64/iotlab_controller/branch/master/graph/badge.svg?token=JR3TH5SR67)](https://codecov.io/gh/miri64/iotlab_controller)

A python library to control IoT-LAB experiments
