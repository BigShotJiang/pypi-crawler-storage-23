# Copyright (C) 2019 Freie Universität Berlin
#
# Distributed under terms of the MIT license.

IOTLAB_DOMAIN = "iot-lab.info"
