import os
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("env")


@mcp.tool()
def get_env(name: str = "") -> str:
    """读取指定名称的环境变量，若不传则返回所有环境变量的键列表。"""
    if name:
        val = os.environ.get(name)
        if val is None:
            return f"环境变量 {name} 不存在"
        return str(val)
    else:
        return "\n".join(sorted(os.environ.keys()))


def main():
    mcp.run()


if __name__ == "__main__":
    main()
