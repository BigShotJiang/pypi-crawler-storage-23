# mcpzoo-env

> 环境变量读取 — 读取系统环境变量的值

## Installation

```bash
uvx mcpzoo-env
```

## uvx JSON

```json
{
  "mcpServers": {
    "env": {
      "args": ["mcpzoo-env"],
      "command": "uvx"
    }
  }
}
```
