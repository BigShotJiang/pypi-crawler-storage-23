"""Centralized path resolution — data dirs, config dirs, executables.

After pip install, source files live in read-only site-packages. All mutable data
(SQLite databases, server config, telegram assets, hosted vaults) must go to a
runtime data directory instead.

Data directory resolution:
  1. FATHOM_DATA_DIR env var (explicit override)
  2. XDG_DATA_HOME/fathom-server (default: ~/.local/share/fathom-server)

Config directory resolution:
  1. FATHOM_CONFIG_DIR / FATHOM_GLOBAL_CONFIG_DIR env vars (explicit override)
  2. XDG_CONFIG_HOME/fathom-mcp and XDG_CONFIG_HOME/fathom-vault (default: ~/.config/*)
"""

import os
import shutil
from pathlib import Path

# ── Data directory ────────────────────────────────────────────────────────────

_ENV_OVERRIDE = os.environ.get("FATHOM_DATA_DIR")

if _ENV_OVERRIDE:
    DATA_DIR = Path(_ENV_OVERRIDE)
else:
    xdg_data = os.environ.get("XDG_DATA_HOME", os.path.expanduser("~/.local/share"))
    DATA_DIR = Path(xdg_data) / "fathom-server"

# Ensure it exists on import
DATA_DIR.mkdir(parents=True, exist_ok=True)

# Convenience paths used across the codebase
DB_PATH = DATA_DIR / "access.db"
SERVER_CONFIG_PATH = DATA_DIR / "server.json"
VAULT_STORAGE_DIR = DATA_DIR / "vaults"
TELEGRAM_ASSETS_DIR = DATA_DIR / "telegram-assets"

# ── Config directories ───────────────────────────────────────────────────────

_xdg_config = os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config"))

# Central config — routines, agents, per-workspace settings
CONFIG_DIR = Path(os.environ.get("FATHOM_CONFIG_DIR", os.path.join(_xdg_config, "fathom-mcp")))

# Global config — workspace registry, rooms, telegram bridge
GLOBAL_CONFIG_DIR = Path(
    os.environ.get("FATHOM_GLOBAL_CONFIG_DIR", os.path.join(_xdg_config, "fathom-vault"))
)

# Derived config file paths
GLOBAL_SETTINGS_FILE = GLOBAL_CONFIG_DIR / "settings.json"
CENTRAL_SETTINGS_FILE = CONFIG_DIR / "settings.json"
ROUTINES_FILE = CONFIG_DIR / "routines.json"

# ── Executables ───────────────────────────────────────────────────────────────

CLAUDE_BIN = shutil.which("claude") or os.path.expanduser("~/.local/bin/claude")
