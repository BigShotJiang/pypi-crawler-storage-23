"""Shared constants and path configuration for Fathom Server."""

import json
import os

from fathom_server.paths import GLOBAL_SETTINGS_FILE

_SETTINGS_FILE = str(GLOBAL_SETTINGS_FILE)
_DEFAULT_VAULT_DIR = os.environ.get("FATHOM_VAULT_DIR", "")


def _read_setting(*keys, default=None):
    """Read a nested setting from the global settings file."""
    try:
        with open(_SETTINGS_FILE) as f:
            data = json.load(f)
        for k in keys:
            data = data[k]
        return data
    except (FileNotFoundError, json.JSONDecodeError, KeyError, TypeError):
        return default


def get_workspace_path(workspace=None):
    """Resolve project root directory for a workspace name.

    Returns (path, None) on success, (None, error_dict) on failure.
    If workspace is None, returns the default workspace path.
    Empty or missing path returns (None, error_dict) — not a crash.
    """
    workspaces = _read_setting("workspaces", default={})
    default_ws = _read_setting("default_workspace", default=None)

    if not workspace:
        if default_ws and workspaces.get(default_ws):
            entry = workspaces[default_ws]
            ws_path = entry["path"] if isinstance(entry, dict) else entry
            if not ws_path:
                return None, {"error": f'Workspace "{default_ws}" has no local path configured'}
            return ws_path, None
        # Legacy fallback — derive from terminal.vault_dir or default
        vault_dir = _read_setting("terminal", "vault_dir", default=_DEFAULT_VAULT_DIR)
        return os.path.dirname(vault_dir), None

    ws_entry = workspaces.get(workspace)
    if not ws_entry:
        available = list(workspaces.keys()) if workspaces else []
        return None, {
            "error": f'Unknown workspace: "{workspace}"',
            "available_workspaces": available,
        }
    # Entry can be a string (legacy) or dict (current)
    ws_path = ws_entry["path"] if isinstance(ws_entry, dict) else ws_entry
    if not ws_path:
        return None, {"error": f'Workspace "{workspace}" has no local path configured'}
    return ws_path, None


def get_vault_path(workspace=None):
    """Resolve vault directory for a workspace name.

    Vault path = workspace project root + vault subdir (from settings, default "vault").
    Returns (path, None) on success, (None, error_dict) on failure.
    """
    ws_path, err = get_workspace_path(workspace)
    if err:
        return None, err

    # Read vault subdir from workspace entry
    workspaces = _read_setting("workspaces", default={})
    default_ws = _read_setting("default_workspace", default=None)
    ws_name = workspace or default_ws
    ws_entry = workspaces.get(ws_name, {})
    vault_subdir = ws_entry.get("vault", "vault") if isinstance(ws_entry, dict) else "vault"

    vault_dir = os.path.join(ws_path, vault_subdir) if vault_subdir != "." else ws_path
    return vault_dir, None


def get_workspace_settings_path(workspace=None):
    """Resolve per-workspace settings file path.

    Returns (<project_root>/.fathom/settings.json, None) on success.
    """
    ws_path, err = get_workspace_path(workspace)
    if err:
        return None, err
    return os.path.join(ws_path, ".fathom", "settings.json"), None


def get_workspaces():
    """Return dict of all configured workspaces {name: project_root_path}."""
    return _read_setting("workspaces", default={})


def get_default_workspace():
    """Return the default workspace name."""
    return _read_setting("default_workspace", default=None)


# Legacy constant — pre-migration reads terminal.vault_dir, post-migration falls back to default.
# Used by services/indexer.py (until Phase 3 makes it workspace-aware).
VAULT_DIR = _read_setting("terminal", "vault_dir", default=_DEFAULT_VAULT_DIR)
FRONTEND_DIR = os.path.join(os.path.dirname(__file__), "static")
IMAGE_EXTENSIONS = (".png", ".jpg", ".jpeg", ".gif", ".webp")
HOST = os.environ.get("FATHOM_HOST", "0.0.0.0")
PORT = int(os.environ.get("FATHOM_PORT", 4243))

# Server-side vault storage — hosted vault files live here, keyed by workspace.
from fathom_server.paths import VAULT_STORAGE_DIR as _VAULT_STORAGE_PATH  # noqa: E402

VAULT_STORAGE_DIR = str(_VAULT_STORAGE_PATH)


def get_vault_storage_path(workspace: str) -> str:
    """Return the server-side vault storage directory for a workspace."""
    return os.path.join(VAULT_STORAGE_DIR, workspace)


def get_vault_dir_for_dashboard(workspace=None):
    """Resolve vault directory for dashboard endpoints, respecting vault mode.

    Vault mode is stored as 'type' on the workspace entry:
      - "local"  → local filesystem vault (get_vault_path)
      - "synced" / "hosted" → server storage (data/vaults/{workspace}/)
      - "none"   → vault not configured

    Returns (path, None) on success, (None, error_dict) on failure.
    """
    workspaces = _read_setting("workspaces", default={})
    default_ws = _read_setting("default_workspace", default=None)
    ws_name = workspace or default_ws

    # Unknown workspace — fall through to get_vault_path for standard error handling
    ws_entry = workspaces.get(ws_name)
    if not ws_entry:
        return get_vault_path(workspace)

    vault_mode = ws_entry.get("type", "local") if isinstance(ws_entry, dict) else "local"

    if vault_mode == "none":
        return None, {"error": "Vault not configured", "vault_mode": "none"}

    if vault_mode in ("synced", "hosted"):
        storage_path = get_vault_storage_path(ws_name)
        os.makedirs(storage_path, exist_ok=True)
        return storage_path, None

    # Default: local filesystem
    return get_vault_path(workspace)
