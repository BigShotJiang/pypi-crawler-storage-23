"""Centralized SQLite -- schema, migrations, WAL, connection factory."""

import sqlite3
from contextlib import contextmanager

from fathom_server.paths import DB_PATH

_DB_PATH = DB_PATH

_SCHEMA = [
    # file_access_v2
    """CREATE TABLE IF NOT EXISTS file_access_v2 (
        path TEXT NOT NULL, workspace TEXT NOT NULL DEFAULT 'fathom',
        open_count INTEGER NOT NULL DEFAULT 0,
        last_opened REAL NOT NULL, first_opened REAL NOT NULL,
        PRIMARY KEY (path, workspace))""",
    # room_messages
    """CREATE TABLE IF NOT EXISTS room_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        room TEXT NOT NULL, sender TEXT NOT NULL,
        message TEXT NOT NULL, timestamp REAL NOT NULL,
        media_path TEXT)""",
    """CREATE INDEX IF NOT EXISTS idx_room_messages_room_ts
        ON room_messages(room, timestamp)""",
    # room_metadata
    """CREATE TABLE IF NOT EXISTS room_metadata (
        room TEXT PRIMARY KEY, description TEXT NOT NULL DEFAULT '')""",
    # room_read_state
    """CREATE TABLE IF NOT EXISTS room_read_state (
        workspace TEXT NOT NULL, room TEXT NOT NULL,
        last_read_ts REAL NOT NULL DEFAULT 0,
        PRIMARY KEY (workspace, room))""",
    # telegram_contacts
    """CREATE TABLE IF NOT EXISTS telegram_contacts (
        chat_id INTEGER PRIMARY KEY,
        first_name TEXT NOT NULL DEFAULT '', last_name TEXT NOT NULL DEFAULT '',
        username TEXT NOT NULL DEFAULT '',
        first_seen REAL NOT NULL, last_message_at REAL NOT NULL)""",
]


def _run_migrations(con):
    """Idempotent migrations -- each silently passes if already applied."""
    # 1: file_access v1 -> v2 data copy
    try:
        old = con.execute("SELECT COUNT(*) as c FROM file_access").fetchone()
        new = con.execute("SELECT COUNT(*) as c FROM file_access_v2").fetchone()
        if old[0] > 0 and new[0] == 0:
            con.execute(
                "INSERT INTO file_access_v2 "
                "(path, workspace, open_count, last_opened, first_opened) "
                "SELECT path, 'fathom', open_count, last_opened, first_opened "
                "FROM file_access"
            )
            con.commit()
    except sqlite3.OperationalError:
        pass

    # 2: room_messages.media_path
    try:
        con.execute("ALTER TABLE room_messages ADD COLUMN media_path TEXT")
    except sqlite3.OperationalError:
        pass


def init_db():
    """Create all tables and run migrations. Call once at startup."""
    con = _raw_connect()
    try:
        for stmt in _SCHEMA:
            con.execute(stmt)
        con.commit()
        _run_migrations(con)
    finally:
        con.close()


def _raw_connect():
    """Connection with WAL + Row factory. Use get_connection() instead."""
    _DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(_DB_PATH))
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    return con


@contextmanager
def get_connection():
    """Yields a Connection, closes on exit."""
    con = _raw_connect()
    try:
        yield con
    finally:
        con.close()
