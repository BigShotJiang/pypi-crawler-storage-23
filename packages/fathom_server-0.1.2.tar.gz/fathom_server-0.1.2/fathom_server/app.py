#!/usr/bin/env python3
"""Fathom Server — dashboard + REST API + background services for the vault layer."""

import argparse
import logging
import os

logging.basicConfig(
    level=getattr(logging, os.environ.get("FATHOM_LOG_LEVEL", "INFO").upper(), logging.INFO),
    format="%(asctime)s %(levelname)-8s [%(name)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

import threading as _threading  # noqa: E402

from fathom_server.config import HOST, PORT  # noqa: E402
from fathom_server.db import init_db  # noqa: E402
from fathom_server.services.crystal_scheduler import crystal_scheduler  # noqa: E402
from fathom_server.services.indexer import indexer  # noqa: E402
from fathom_server.services.persistent_session import (  # noqa: E402
    ensure_running as session_ensure_running,
)
from fathom_server.services.ping_scheduler import ping_scheduler  # noqa: E402
from fathom_server.services.settings import (  # noqa: E402
    load_global_settings,
    load_routines,
    load_workspace_settings,
)
from fathom_server.services.telegram_bridge import telegram_bridge  # noqa: E402
from fathom_server.services.tts_bridge import tts_bridge  # noqa: E402

init_db()

# Bootstrap all workspaces on startup
_global_settings = load_global_settings()
_workspaces = _global_settings["workspaces"]
_default_ws = _global_settings["default_workspace"]

# Ensure persistent sessions for local-execution workspaces only (non-blocking)
for _ws_name, _ws_entry in _workspaces.items():
    if _ws_entry.get("execution", "local") == "local" and _ws_entry.get("type") != "human":
        _threading.Thread(target=session_ensure_running, args=(_ws_name,), daemon=True).start()

# Load central settings (shared across all workspaces)
_central_settings = load_workspace_settings()

# Load all ping routines from routines.json
ping_scheduler.configure_all(load_routines())
indexer.configure(
    _central_settings["background_index"]["enabled"],
    _central_settings["background_index"]["interval_minutes"],
    _central_settings["background_index"]["excluded_dirs"],
)

# Configure crystal scheduler
crystal_scheduler.configure(
    _central_settings["crystal_regen"]["enabled"],
    _central_settings["crystal_regen"]["interval_days"],
    workspace=_default_ws,
)

# Configure and start Telegram bridge if enabled
_telegram_cfg = _global_settings.get("telegram", {})
telegram_bridge.configure(
    api_id=_telegram_cfg.get("api_id", 0),
    api_hash=_telegram_cfg.get("api_hash", ""),
    session_string=_telegram_cfg.get("session_string", ""),
    primary_agent=_default_ws,
    enabled=_telegram_cfg.get("enabled", False),
)
telegram_bridge.start()

# Configure and start TTS bridge if preload enabled
_tts_cfg = _global_settings.get("tts", {})
tts_bridge.configure(enabled=_tts_cfg.get("preload", False))
tts_bridge.start()


def _cmd_serve(args):
    """Run the server."""
    from fathom_server.auth import load_server_config

    server_config = load_server_config()
    api_key = server_config["api_key"]
    auth_enabled = server_config.get("auth_enabled", False)
    key_is_new = server_config.get("_key_newly_created", False)

    from fathom_server import __version__

    print(f"\n  Fathom Server v{__version__}")
    print(f"  Bind: {args.host}:{args.port}")
    print(f"  Auth: {'enabled' if auth_enabled else 'disabled (enable via dashboard)'}")
    if key_is_new:
        print(f"  API Key: {api_key}  \u2190 SAVE THIS (shown once)")
    else:
        print(f"  API Key: {api_key[:7]}...{api_key[-4:]}")
    print(f"  Dashboard: http://localhost:{args.port}\n")

    from fathom_server import shutdown as _shutdown

    _shutdown.install()

    import uvicorn

    uvicorn.run(
        "fathom_server.fastapi_app:fastapi_app",
        host=args.host,
        port=args.port,
        log_level="warning",
    )


def _cmd_setup(args):
    """First-time setup — create data dirs and generate API key."""
    from fathom_server import __version__
    from fathom_server.auth import load_server_config
    from fathom_server.paths import DATA_DIR

    if not args.yes:
        print(f"\n  Fathom Server v{__version__}")
        print(f"  Data directory: {DATA_DIR}")
        print()
        confirm = input("  Proceed with setup? [Y/n] ").strip().lower()
        if confirm and confirm != "y":
            print("  Aborted.")
            return

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    server_config = load_server_config()
    api_key = server_config["api_key"]
    key_is_new = server_config.get("_key_newly_created", False)

    print(f"\n  Fathom Server v{__version__} — setup complete")
    print(f"  Data directory: {DATA_DIR}")
    if key_is_new:
        print(f"  API Key: {api_key}  \u2190 SAVE THIS (shown once)")
    else:
        print(f"  API Key: {api_key[:7]}...{api_key[-4:]} (already existed)")
    print()
    print("  Next steps:")
    print("    fathom-server                    # run the server")
    print("    fathom-server install             # register as a boot service")
    print()


def _cmd_install(args):
    """Install fathom-server as a systemd user service."""
    from fathom_server.service import install_service

    install_service(
        data_dir=args.data_dir,
        host=args.host,
        port=args.port,
        working_dir=args.working_dir,
        no_start=args.no_start,
    )


def _cmd_uninstall(_args):
    """Remove the systemd user service."""
    from fathom_server.service import uninstall_service

    uninstall_service()


def main():
    """Entry point for `fathom-server` CLI command."""
    parser = argparse.ArgumentParser(description="Fathom Server")
    sub = parser.add_subparsers(dest="command")

    # -- serve (default when no subcommand given) --
    serve_p = sub.add_parser("serve", help="Run the server (default)")
    serve_p.add_argument(
        "--host", type=str, default=HOST, help=f"Address to bind to (default: {HOST})"
    )
    serve_p.add_argument(
        "--port", type=int, default=PORT, help=f"Port to listen on (default: {PORT})"
    )

    # -- setup (non-interactive first-time setup, no service) --
    setup_p = sub.add_parser("setup", help="First-time setup (create data dirs, generate API key)")
    setup_p.add_argument(
        "-y",
        "--yes",
        action="store_true",
        help="Skip confirmation prompt",
    )

    # -- install --
    install_p = sub.add_parser("install", help="Install as a systemd user service")
    install_p.add_argument(
        "--data-dir",
        type=str,
        default=None,
        help="FATHOM_DATA_DIR override (default: ~/.local/share/fathom-server)",
    )
    install_p.add_argument("--host", type=str, default=HOST, help=f"Bind address (default: {HOST})")
    install_p.add_argument("--port", type=int, default=PORT, help=f"Port (default: {PORT})")
    install_p.add_argument(
        "--working-dir",
        type=str,
        default=None,
        help="WorkingDirectory for the service (default: home directory)",
    )
    install_p.add_argument(
        "--no-start",
        action="store_true",
        help="Install and enable without starting immediately",
    )

    # -- uninstall --
    sub.add_parser("uninstall", help="Remove the systemd user service")

    # Also accept --host/--port at top level for backward compat (no subcommand = serve)
    parser.add_argument(
        "--host",
        type=str,
        default=None,
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--port",
        type=int,
        default=None,
        help=argparse.SUPPRESS,
    )

    cli_args = parser.parse_args()

    if cli_args.command == "setup":
        _cmd_setup(cli_args)
    elif cli_args.command == "install":
        _cmd_install(cli_args)
    elif cli_args.command == "uninstall":
        _cmd_uninstall(cli_args)
    elif cli_args.command == "serve":
        _cmd_serve(cli_args)
    else:
        # No subcommand — run serve with top-level flags
        cli_args.host = cli_args.host or HOST
        cli_args.port = cli_args.port or PORT
        _cmd_serve(cli_args)


if __name__ == "__main__":
    main()
