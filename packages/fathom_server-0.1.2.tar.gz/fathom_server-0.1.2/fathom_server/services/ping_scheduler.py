"""Ping rhythm scheduler — manages multiple independent ping routines.

Each routine has its own timer, interval, context sources, workspace, and enabled state.
Supports cron scheduling (via croniter) and conditional firing (scripts that gate execution).
Injects prompts into the workspace-specific persistent session on fire.

Internally, routines are keyed by composite `workspace:id` to allow identical IDs
across different workspaces.
"""

import logging
import subprocess
import threading
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta

from croniter import croniter

from fathom_server.paths import CONFIG_DIR
from fathom_server.services.settings import load_routines, save_routines

log = logging.getLogger(__name__)


@dataclass
class RoutineState:
    id: str
    name: str = "Untitled"
    enabled: bool = False
    interval_minutes: int = 60
    workspace: str = "fathom"
    next_ping_at: datetime | None = None
    last_ping_at: datetime | None = None
    single_fire: bool = False
    context_sources: dict = field(
        default_factory=lambda: {"time": True, "scripts": [], "texts": []}
    )
    schedule: str | None = None  # cron expression, e.g. "0 */3 * * *"
    conditions: list = field(default_factory=list)  # [{label, command, enabled}]
    last_check_at: datetime | None = None
    last_fire_at: datetime | None = None
    timer: threading.Timer | None = field(default=None, repr=False)

    @property
    def _key(self) -> str:
        return f"{self.workspace}:{self.id}"


class PingScheduler:
    def __init__(self):
        self._routines: dict[str, RoutineState] = {}  # keyed by workspace:id
        self._lock = threading.Lock()

    @staticmethod
    def _composite_key(workspace: str, routine_id: str) -> str:
        return f"{workspace}:{routine_id}"

    # ── Bulk load on startup ──────────────────────────────────────────────

    def configure_all(self, routines_list: list[dict]) -> None:
        """Load all routines from settings. Replaces any existing state."""
        with self._lock:
            for rs in self._routines.values():
                if rs.timer:
                    rs.timer.cancel()
            self._routines.clear()

            for r in routines_list:
                rid = r["id"]
                ws = r.get("workspace", "fathom")
                rs = RoutineState(
                    id=rid,
                    name=r.get("name", "Untitled"),
                    enabled=r.get("enabled", False),
                    interval_minutes=max(1, r.get("interval_minutes", 60)),
                    workspace=ws,
                    single_fire=bool(r.get("single_fire", False)),
                    context_sources=r.get(
                        "context_sources", {"time": True, "scripts": [], "texts": []}
                    ),
                    schedule=r.get("schedule"),
                    conditions=r.get("conditions", []),
                )
                if r.get("last_ping_at"):
                    rs.last_ping_at = datetime.fromisoformat(r["last_ping_at"])
                if r.get("last_check_at"):
                    rs.last_check_at = datetime.fromisoformat(r["last_check_at"])
                if r.get("last_fire_at"):
                    rs.last_fire_at = datetime.fromisoformat(r["last_fire_at"])
                if rs.enabled:
                    if r.get("next_ping_at"):
                        target = datetime.fromisoformat(r["next_ping_at"])
                        if target.tzinfo is None:
                            target = target.replace(tzinfo=UTC)
                        remaining = (target - datetime.now(UTC)).total_seconds()
                        if remaining > 0:
                            rs.next_ping_at = target
                            self._schedule(rs, remaining)
                        else:
                            self._reschedule(rs)
                    else:
                        self._reschedule(rs)
                self._routines[rs._key] = rs

    # ── Shutdown ──────────────────────────────────────────────────────────

    def shutdown(self) -> None:
        """Cancel all timers and persist state. Called on server shutdown."""
        with self._lock:
            for rs in self._routines.values():
                if rs.timer:
                    rs.timer.cancel()
                    rs.timer = None
        # Persist outside lock — _persist acquires its own I/O
        for rs in list(self._routines.values()):
            self._persist(rs)

    # ── Single-routine operations ─────────────────────────────────────────

    def _find(self, routine_id: str, workspace: str | None = None) -> RoutineState | None:
        """Find a routine by ID, optionally scoped to a workspace. Must hold lock."""
        if workspace:
            return self._routines.get(self._composite_key(workspace, routine_id))
        # Fallback: search all routines by ID (backward compat)
        for rs in self._routines.values():
            if rs.id == routine_id:
                return rs
        return None

    def configure_routine(
        self, routine_id: str, workspace: str | None = None, **kwargs
    ) -> dict | None:
        """Update fields on one routine and restart its timer if needed."""
        with self._lock:
            rs = self._find(routine_id, workspace)
            if not rs:
                return None

            if "name" in kwargs:
                rs.name = kwargs["name"]
            if "interval_minutes" in kwargs:
                rs.interval_minutes = max(1, kwargs["interval_minutes"])
            if "single_fire" in kwargs:
                rs.single_fire = bool(kwargs["single_fire"])
            if "context_sources" in kwargs:
                rs.context_sources = kwargs["context_sources"]
            if "schedule" in kwargs:
                rs.schedule = kwargs["schedule"]  # None clears it
            if "conditions" in kwargs:
                rs.conditions = kwargs["conditions"]

            enabled_changed = "enabled" in kwargs and kwargs["enabled"] != rs.enabled
            if "enabled" in kwargs:
                rs.enabled = kwargs["enabled"]

            if rs.timer:
                rs.timer.cancel()
                rs.timer = None

            if rs.enabled:
                if enabled_changed or "interval_minutes" in kwargs or "schedule" in kwargs:
                    self._reschedule(rs)
                elif rs.next_ping_at:
                    remaining = (rs.next_ping_at - datetime.now(UTC)).total_seconds()
                    if remaining > 0:
                        self._schedule(rs, remaining)
                    else:
                        self._reschedule(rs)
                else:
                    self._reschedule(rs)
            else:
                rs.next_ping_at = None

            return self._routine_dict(rs)

    def add_routine(self, routine_dict: dict) -> dict:
        """Add a new routine and optionally start its timer."""
        with self._lock:
            rid = routine_dict["id"]
            ws = routine_dict.get("workspace", "fathom")
            rs = RoutineState(
                id=rid,
                name=routine_dict.get("name", "Untitled"),
                enabled=routine_dict.get("enabled", False),
                interval_minutes=max(1, routine_dict.get("interval_minutes", 60)),
                workspace=ws,
                single_fire=bool(routine_dict.get("single_fire", False)),
                context_sources=routine_dict.get(
                    "context_sources", {"time": True, "scripts": [], "texts": []}
                ),
                schedule=routine_dict.get("schedule"),
                conditions=routine_dict.get("conditions", []),
            )
            if rs.enabled:
                self._reschedule(rs)
            self._routines[rs._key] = rs
            return self._routine_dict(rs)

    def remove_routine(self, routine_id: str, workspace: str | None = None) -> bool:
        """Cancel timer and remove a routine. Returns True if found."""
        with self._lock:
            rs = self._find(routine_id, workspace)
            if rs is None:
                return False
            del self._routines[rs._key]
            if rs.timer:
                rs.timer.cancel()
            return True

    def get_routine(self, routine_id: str, workspace: str | None = None) -> dict | None:
        """Get one routine's status dict."""
        with self._lock:
            rs = self._find(routine_id, workspace)
            return self._routine_dict(rs) if rs else None

    def fire_now(self, routine_id: str | None = None, workspace: str | None = None) -> None:
        """Fire a specific routine immediately (non-blocking).

        If routine_id is None, fires the first routine (backward compat).
        Bypasses conditions — always fires.
        """
        with self._lock:
            if routine_id is None:
                rs = next(iter(self._routines.values()), None)
            else:
                rs = self._find(routine_id, workspace)
        if rs:
            threading.Thread(
                target=self._run, args=(rs.id, rs.workspace, True), daemon=True
            ).start()

    # ── Status ────────────────────────────────────────────────────────────

    @property
    def status(self) -> dict:
        """Return status for all routines."""
        with self._lock:
            return {
                "routines": [self._routine_dict(rs) for rs in self._routines.values()],
            }

    def status_for_workspace(self, workspace: str | None = None) -> dict:
        """Return status filtered to a single workspace.

        Merges content fields from disk (source of truth for config) with
        runtime fields from memory (source of truth for timing). This ensures
        direct file edits are always reflected without needing a server restart.
        """
        # Read fresh config from routines.json
        disk_routines = {}
        try:
            for r in load_routines():
                if workspace and r.get("workspace") != workspace:
                    continue
                disk_routines[r["id"]] = r
        except (ValueError, OSError):
            log.warning("Failed to read routines.json for workspace status merge")

        with self._lock:
            routines = []
            for rs in self._routines.values():
                if workspace is not None and rs.workspace != workspace:
                    continue
                d = self._routine_dict(rs)
                # Overlay disk config if available
                disk = disk_routines.get(rs.id)
                if disk:
                    d["name"] = disk.get("name", d["name"])
                    d["interval_minutes"] = disk.get("interval_minutes", d["interval_minutes"])
                    d["single_fire"] = disk.get("single_fire", d["single_fire"])
                    d["context_sources"] = disk.get("context_sources", d["context_sources"])
                    d["schedule"] = disk.get("schedule", d["schedule"])
                    d["conditions"] = disk.get("conditions", d["conditions"])
                routines.append(d)
            return {"routines": routines}

    @property
    def first_routine_status(self) -> dict:
        """Backward-compat: return status dict shaped like old single-routine format."""
        with self._lock:
            rs = next(iter(self._routines.values()), None)
            if not rs:
                return {
                    "enabled": False,
                    "interval_minutes": 60,
                    "next_ping_at": None,
                    "last_ping_at": None,
                    "context_sources": {"time": True, "scripts": [], "texts": []},
                }
            return self._routine_dict(rs)

    # ── Internal ──────────────────────────────────────────────────────────

    def _routine_dict(self, rs: RoutineState) -> dict:
        has_conditions = bool(rs.conditions and any(c.get("enabled", True) for c in rs.conditions))
        return {
            "id": rs.id,
            "name": rs.name,
            "enabled": rs.enabled,
            "interval_minutes": rs.interval_minutes,
            "single_fire": rs.single_fire,
            "workspace": rs.workspace,
            "next_ping_at": rs.next_ping_at.isoformat() if rs.next_ping_at else None,
            "last_ping_at": rs.last_ping_at.isoformat() if rs.last_ping_at else None,
            "context_sources": rs.context_sources,
            "schedule": rs.schedule,
            "conditions": rs.conditions,
            "last_check_at": rs.last_check_at.isoformat() if rs.last_check_at else None,
            "last_fire_at": rs.last_fire_at.isoformat() if rs.last_fire_at else None,
            "has_conditions": has_conditions,
        }

    def _reschedule(self, rs: RoutineState) -> None:
        """Set next ping and schedule timer. Must hold lock."""
        if rs.schedule:
            try:
                cron = croniter(rs.schedule, datetime.now(UTC))
                rs.next_ping_at = cron.get_next(datetime).replace(tzinfo=UTC)
                delay = (rs.next_ping_at - datetime.now(UTC)).total_seconds()
            except (ValueError, KeyError):
                # Invalid cron expression — fall back to interval
                rs.next_ping_at = datetime.now(UTC) + timedelta(minutes=rs.interval_minutes)
                delay = rs.interval_minutes * 60
        else:
            rs.next_ping_at = datetime.now(UTC) + timedelta(minutes=rs.interval_minutes)
            delay = rs.interval_minutes * 60
        self._schedule(rs, max(1, delay))

    def _schedule(self, rs: RoutineState, seconds: float) -> None:
        """Create and start a timer for one routine. Must hold lock."""
        if rs.timer:
            rs.timer.cancel()
        rs.timer = threading.Timer(seconds, self._run, args=(rs.id, rs.workspace, False))
        rs.timer.daemon = True
        rs.timer.start()

    def _build_prompt(self, rs: RoutineState, fresh_routines: list[dict] | None = None) -> str:
        # Read fresh context_sources from routines.json so file edits take effect
        src = rs.context_sources
        routines = fresh_routines if fresh_routines is not None else []
        if not routines:
            try:
                routines = load_routines()
            except (ValueError, OSError):
                log.warning("Failed to reload routines.json for prompt build")
        for r in routines:
            if r["id"] == rs.id and r.get("workspace") == rs.workspace:
                src = r.get("context_sources", src)
                break
        parts = []

        # Header line
        header_parts = []
        if src.get("time"):
            header_parts.append(f"Time: {datetime.now().strftime('%A %B %-d, %-I:%M %p')}")
        if header_parts:
            parts.append(f"[Ping — {' · '.join(header_parts)}]")

        # Script sections
        for script in src.get("scripts", []):
            if not script.get("enabled"):
                continue
            label = script.get("label", "Script")
            output = ""
            try:
                result = subprocess.run(
                    script["command"],
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                output = result.stdout.strip()
            except Exception:
                log.warning("Context script '%s' failed", label)
            section = f"[{label}]"
            if output:
                section += f"\n{output}"
            parts.append(section)

        # Text blocks (or custom prompt file)
        custom = CONFIG_DIR / "ping-prompt.md"
        if custom.exists():
            parts.append(custom.read_text().strip())
        else:
            for t in src.get("texts", []):
                if t.get("enabled") and t.get("content", "").strip():
                    parts.append(t["content"].strip())

        return "\n\n".join(p for p in parts if p)

    def _check_conditions(self, conditions: list) -> bool:
        """Run condition scripts. Returns True if all enabled conditions pass (exit 0)."""
        for cond in conditions:
            if not cond.get("enabled", True):
                continue
            try:
                result = subprocess.run(
                    cond["command"],
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=15,
                )
                if result.returncode != 0:
                    return False
            except Exception:
                log.warning("Condition script failed/timed out")
                return False
        return True

    def _persist(self, rs: RoutineState) -> None:
        """Persist routine timing state to routines.json. Must NOT hold lock."""
        try:
            routines = load_routines()
            for saved_r in routines:
                if saved_r["id"] == rs.id and saved_r.get("workspace") == rs.workspace:
                    saved_r["last_ping_at"] = (
                        rs.last_ping_at.isoformat() if rs.last_ping_at else None
                    )
                    saved_r["last_check_at"] = (
                        rs.last_check_at.isoformat() if rs.last_check_at else None
                    )
                    saved_r["last_fire_at"] = (
                        rs.last_fire_at.isoformat() if rs.last_fire_at else None
                    )
                    if rs.single_fire and not rs.enabled:
                        saved_r["enabled"] = False
                        saved_r["next_ping_at"] = None
                    elif rs.next_ping_at:
                        saved_r["next_ping_at"] = rs.next_ping_at.isoformat()
                    break
            save_routines(routines)
        except (ValueError, OSError):
            log.error("Failed to persist routine state for %s:%s", rs.workspace, rs.id)

    def _run(self, routine_id: str, workspace: str, skip_conditions: bool = False) -> None:
        from fathom_server.services.agent_connections import push_ping_fire

        key = self._composite_key(workspace, routine_id)

        # Read routines.json once for the entire run cycle
        try:
            fresh_routines = load_routines()
        except (ValueError, OSError):
            fresh_routines = []

        # Read conditions under lock
        with self._lock:
            rs = self._routines.get(key)
            if not rs:
                return
            conditions = rs.conditions
            ws = rs.workspace

        # Phase 1: Check conditions (if any, and not bypassed via fire_now)
        conditions_passed = True
        if conditions and not skip_conditions:
            conditions_passed = self._check_conditions(conditions)

        with self._lock:
            rs = self._routines.get(key)
            if not rs:
                return
            rs.last_check_at = datetime.now(UTC)

            if not conditions_passed and rs.enabled:
                # Conditions didn't pass — reschedule and persist, then return
                self._reschedule(rs)

        if not conditions_passed:
            self._persist(rs)
            return

        # Phase 2: Conditions passed (or no conditions) — build prompt and fire
        with self._lock:
            rs = self._routines.get(key)
            if not rs:
                return
            prompt = self._build_prompt(rs, fresh_routines=fresh_routines)
            ws = rs.workspace

        push_ping_fire(prompt, routine_id=routine_id, workspace=ws)

        with self._lock:
            rs = self._routines.get(key)
            if not rs:
                return
            now = datetime.now(UTC)
            rs.last_ping_at = now  # backward compat
            rs.last_fire_at = now

            # Single-fire: auto-disable after firing
            if rs.single_fire:
                rs.enabled = False
                rs.next_ping_at = None
            elif rs.enabled:
                self._reschedule(rs)

        self._persist(rs)


ping_scheduler = PingScheduler()
