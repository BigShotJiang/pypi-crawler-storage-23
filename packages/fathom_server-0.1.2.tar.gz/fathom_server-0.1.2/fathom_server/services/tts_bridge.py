"""TTS bridge — manages the Kokoro bridge subprocess.

Starts/stops the kokoro-bridge.py daemon process which preloads the TTS model
and listens on a Unix socket for requests.
"""

import logging
import os
import signal
import subprocess
import threading

log = logging.getLogger("tts-bridge")

SOCKET_PATH = "/tmp/fathom-kokoro.sock"
_SCRIPTS_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "fathom-mcp", "scripts")
_VENV_PYTHON = os.path.join(_SCRIPTS_DIR, ".kokoro-venv", "bin", "python")
_BRIDGE_SCRIPT = os.path.join(_SCRIPTS_DIR, "kokoro-bridge.py")


class TTSBridge:
    """Manages the Kokoro bridge subprocess lifecycle."""

    def __init__(self):
        self._process: subprocess.Popen | None = None
        self._enabled: bool = False
        self._ready: bool = False
        self._lock = threading.Lock()

    def configure(self, enabled: bool = False) -> None:
        self._enabled = enabled

    @property
    def status(self) -> dict:
        running = self._process is not None and self._process.poll() is None
        return {
            "enabled": self._enabled,
            "running": running,
            "ready": self._ready and running,
            "socket": SOCKET_PATH,
        }

    def start(self) -> None:
        """Start the bridge subprocess if enabled and not already running."""
        with self._lock:
            if not self._enabled:
                log.info("TTS bridge disabled, not starting")
                return
            if self._process is not None and self._process.poll() is None:
                log.info("TTS bridge already running (pid=%d)", self._process.pid)
                return
            if not os.path.isfile(_VENV_PYTHON):
                log.warning("Kokoro venv not found at %s, not starting", _VENV_PYTHON)
                return

            self._ready = False
            log.info("Starting Kokoro bridge...")

            self._process = subprocess.Popen(
                [_VENV_PYTHON, _BRIDGE_SCRIPT],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                preexec_fn=os.setsid,
            )

            # Wait for READY signal in a background thread
            def _wait_ready():
                try:
                    while self._process and self._process.poll() is None:
                        line = self._process.stdout.readline().decode().strip()
                        if line == "READY":
                            self._ready = True
                            log.info("Kokoro bridge ready (pid=%d)", self._process.pid)
                            break
                        elif line:
                            log.debug("Bridge startup: %s", line)
                except Exception:
                    log.exception("Error waiting for bridge ready")

                # Drain stderr in background for logging
                def _drain_stderr():
                    try:
                        for line in self._process.stderr:
                            log.debug("kokoro-bridge: %s", line.decode().strip())
                    except Exception:
                        pass

                threading.Thread(target=_drain_stderr, daemon=True).start()

            threading.Thread(target=_wait_ready, daemon=True).start()

    def stop(self) -> None:
        """Stop the bridge subprocess."""
        with self._lock:
            if self._process is None:
                return
            if self._process.poll() is not None:
                self._process = None
                self._ready = False
                return

            pid = self._process.pid
            log.info("Stopping Kokoro bridge (pid=%d)...", pid)
            try:
                os.killpg(os.getpgid(pid), signal.SIGTERM)
                self._process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                log.warning("Bridge didn't stop gracefully, killing")
                os.killpg(os.getpgid(pid), signal.SIGKILL)
                self._process.wait(timeout=5)
            except Exception:
                log.exception("Error stopping bridge")

            self._process = None
            self._ready = False

    @property
    def is_ready(self) -> bool:
        return self._ready and self._process is not None and self._process.poll() is None


# Module-level singleton
tts_bridge = TTSBridge()
