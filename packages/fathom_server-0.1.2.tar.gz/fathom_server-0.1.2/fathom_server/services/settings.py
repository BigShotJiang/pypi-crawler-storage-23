"""Settings persistence — global + central split.

Global settings (~/.config/fathom-vault/settings.json):
    workspaces dict + default_workspace only.

Central settings (~/.config/fathom-mcp/settings.json):
    All operational config (indexing, MCP, activity, crystal, ping).
    Shared across all workspaces — ping routines have a workspace field.
"""

import json
import logging
import os
import re
import uuid

from fathom_server import paths as _paths

log = logging.getLogger(__name__)

_SETTINGS_DIR = str(_paths.GLOBAL_CONFIG_DIR)
_SETTINGS_FILE = str(_paths.GLOBAL_SETTINGS_FILE)

_CENTRAL_DIR = str(_paths.CONFIG_DIR)
_CENTRAL_FILE = str(_paths.CENTRAL_SETTINGS_FILE)
_ROUTINES_FILE = str(_paths.ROUTINES_FILE)

_DEFAULT_ROUTINE = {
    "id": "default",
    "name": "Default",
    "enabled": False,
    "interval_minutes": 60,
    "single_fire": False,
    "next_ping_at": None,
    "last_ping_at": None,
    "schedule": None,
    "conditions": [],
    "last_check_at": None,
    "last_fire_at": None,
    "context_sources": {
        "time": True,
        "scripts": [
            {
                "label": "Weather",
                "command": "ping-weather 63101",
                "enabled": False,
            }
        ],
        "texts": [
            {
                "label": "Three phases",
                "content": (
                    "You are running the standard ping routine. Three phases:\n\n"
                    "Phase 1 — Orient (5 min): Load MCP tools. Check Memento active_work + skip_list.\n"
                    "Check Telegram for unread messages. Quick news scan (respect skip list).\n\n"
                    "Phase 2 — Go Deep: Pick ONE thing from active_work and tunnel in. Produce something\n"
                    "that didn't exist before this ping.\n\n"
                    'Phase 3 — Eagle Eye (15-20 min): Zoom out. Browse. Look for the "oh!" moment.\n\n'
                    "Write Back: Update Memento items. Write a heartbeat to vault/daily/."
                ),
                "enabled": True,
            }
        ],
    },
}

_WORKSPACE_DEFAULTS = {
    "background_index": {
        "enabled": True,
        "interval_minutes": 15,
        "excluded_dirs": [],
    },
    "mcp": {
        "query_timeout_seconds": 120,
        "search_results": 10,
        "search_mode": "hybrid",
    },
    "activity": {
        "decay_halflife_days": 7,
        "recency_window_hours": 48,
        "max_access_boost": 2.0,
        "activity_sort_default": False,
        "show_heat_indicator": True,
        "excluded_from_scoring": ["daily"],
    },
    "crystal_regen": {
        "enabled": False,
        "interval_days": 7,
    },
}


def _migrate_ping(saved_ping: dict) -> dict:
    """Migrate old flat ping config to routines[] format."""
    if "routines" in saved_ping:
        return saved_ping
    routine = {
        "id": "default",
        "name": "Default",
        "enabled": saved_ping.get("enabled", False),
        "interval_minutes": saved_ping.get("interval_minutes", 60),
        "next_ping_at": saved_ping.get("next_ping_at"),
        "last_ping_at": saved_ping.get("last_ping_at"),
        "context_sources": saved_ping.get("context_sources", _DEFAULT_ROUTINE["context_sources"]),
    }
    return {"routines": [routine]}


def new_routine_id() -> str:
    """Generate a short unique ID for a new routine."""
    return uuid.uuid4().hex[:8]


# ── Workspace entry normalization ─────────────────────────────────────────────


def _normalize_workspace_entry(entry) -> dict:
    """Normalize a workspace entry to dict format.

    Handles both string entries ("path") and rich dict entries
    ({"path": ..., "vault": ..., "description": ..., "agents": [...]}).

    Two independent axes:
      - type (vault mode): agent-declarable — hosted/synced/local/none
      - execution: admin-granted — local (with valid path), remote, or none
    """
    if isinstance(entry, str):
        return {
            "path": entry,
            "vault": "vault",
            "description": "",
            "agents": [],
            "type": "local",
            "execution": "local",
        }
    if isinstance(entry, dict):
        ws_type = entry.get("type", "local")
        # Default execution: "none" for human workspaces, "local" for everything else
        default_exec = "none" if ws_type == "human" else "local"
        return {
            "path": entry.get("path", ""),
            "vault": entry.get("vault", "vault"),
            "description": entry.get("description", ""),
            "agents": entry.get("agents", []),
            "type": ws_type,
            "execution": entry.get("execution", default_exec),
        }
    return {
        "path": str(entry),
        "vault": "vault",
        "description": "",
        "agents": [],
        "type": "local",
        "execution": "local",
    }


def _sanitize_description(text: str) -> str:
    """Strip HTML tags, whitespace, and truncate to 200 chars."""
    if not text:
        return ""
    cleaned = re.sub(r"<[^>]+>", "", str(text)).strip()
    return cleaned[:200]


# ── Global settings ──────────────────────────────────────────────────────────


_ROOMS_DEFAULTS = {"retention_days": 7}

_TELEGRAM_DEFAULTS = {
    "enabled": False,
    "api_id": 0,
    "api_hash": "",
    "session_string": "",
}

_TTS_DEFAULTS = {
    "preload": False,
}


def _validate_retention_days(val):
    """Validate and normalize retention_days: int 1-60 or None for unlimited."""
    if val is None:
        return None
    if isinstance(val, int) and 1 <= val <= 60:
        return val
    return _ROOMS_DEFAULTS["retention_days"]


def load_global_settings() -> dict:
    """Load ~/.config/fathom-vault/settings.json — workspaces + rooms config."""
    try:
        with open(_SETTINGS_FILE) as f:
            saved = json.load(f)
    except FileNotFoundError:
        log.debug("Global settings file not found, using defaults")
        saved = {}
    except json.JSONDecodeError:
        log.warning("Global settings file corrupt, using defaults")
        saved = {}

    workspaces = saved.get("workspaces", {})
    default_ws = saved.get("default_workspace")

    if not workspaces or not isinstance(workspaces, dict):
        workspaces = {}
        default_ws = None
    else:
        # Normalize all entries to dict format on load
        workspaces = {name: _normalize_workspace_entry(entry) for name, entry in workspaces.items()}
        if not default_ws or default_ws not in workspaces:
            default_ws = next(iter(workspaces))

    # Rooms config — global, cross-workspace
    saved_rooms = saved.get("rooms", {})
    if not isinstance(saved_rooms, dict):
        saved_rooms = {}
    rooms = {
        "retention_days": _validate_retention_days(
            saved_rooms.get("retention_days", _ROOMS_DEFAULTS["retention_days"])
        ),
    }

    # Telegram config — global
    saved_telegram = saved.get("telegram", {})
    if not isinstance(saved_telegram, dict):
        saved_telegram = {}
    telegram = {**_TELEGRAM_DEFAULTS, **saved_telegram}

    # TTS config — global
    saved_tts = saved.get("tts", {})
    if not isinstance(saved_tts, dict):
        saved_tts = {}
    tts = {**_TTS_DEFAULTS, **saved_tts}

    return {
        "workspaces": workspaces,
        "default_workspace": default_ws,
        "rooms": rooms,
        "telegram": telegram,
        "tts": tts,
    }


def save_global_settings(settings: dict) -> None:
    """Save global settings — workspaces, default, rooms, telegram."""
    os.makedirs(_SETTINGS_DIR, exist_ok=True)
    data = {
        "workspaces": settings.get("workspaces", {}),
        "default_workspace": settings.get("default_workspace"),
    }
    if "rooms" in settings:
        data["rooms"] = settings["rooms"]
    if "telegram" in settings:
        data["telegram"] = settings["telegram"]
    if "tts" in settings:
        data["tts"] = settings["tts"]
    with open(_SETTINGS_FILE, "w") as f:
        json.dump(data, f, indent=2)


# ── Routines (~/.config/fathom-mcp/routines.json) ─────────────────────────────────


def load_routines() -> list[dict]:
    """Load routines from ~/.config/fathom-mcp/routines.json."""
    try:
        with open(_ROUTINES_FILE) as f:
            data = json.load(f)
    except FileNotFoundError:
        log.debug("Routines file not found, using defaults")
        data = {}
    except json.JSONDecodeError:
        log.warning("Routines file corrupt, using defaults")
        data = {}

    routines = data.get("routines", [])
    if not routines:
        # Migrate from old settings.json if routines.json doesn't exist yet
        try:
            with open(_CENTRAL_FILE) as f:
                saved = json.load(f)
            old_ping = saved.get("ping", {})
            if old_ping:
                migrated = _migrate_ping(old_ping)
                routines = migrated.get("routines", [])
                if routines:
                    save_routines(routines)
        except FileNotFoundError:
            log.debug("Central settings file not found, skipping routine migration")
        except json.JSONDecodeError:
            log.warning("Central settings file corrupt, skipping routine migration")

    return routines if routines else [dict(_DEFAULT_ROUTINE)]


def save_routines(routines: list[dict]) -> None:
    """Save routines to ~/.config/fathom-mcp/routines.json."""
    os.makedirs(_CENTRAL_DIR, exist_ok=True)
    with open(_ROUTINES_FILE, "w") as f:
        json.dump({"routines": routines}, f, indent=2)


# ── Central settings (~/.config/fathom-mcp/settings.json) ────────────────────────


def load_workspace_settings(workspace: str = None) -> dict:
    """Load central settings from ~/.config/fathom-mcp/settings.json, merged with defaults.

    All workspaces share the same vault/search/activity config.
    Routines are in a separate file — use load_routines() directly.
    """
    try:
        with open(_CENTRAL_FILE) as f:
            saved = json.load(f)
    except FileNotFoundError:
        log.debug("Central settings file not found, using defaults")
        saved = {}
    except json.JSONDecodeError:
        log.warning("Central settings file corrupt, using defaults")
        saved = {}

    settings = {}
    for key, default_val in _WORKSPACE_DEFAULTS.items():
        if isinstance(default_val, dict):
            settings[key] = {**default_val, **saved.get(key, {})}
        else:
            settings[key] = saved.get(key, default_val)

    return settings


def save_workspace_settings(workspace: str, settings: dict) -> None:
    """Save to central ~/.config/fathom-mcp/settings.json."""
    os.makedirs(_CENTRAL_DIR, exist_ok=True)

    data = {}
    for key in _WORKSPACE_DEFAULTS:
        if key in settings:
            data[key] = settings[key]
    with open(_CENTRAL_FILE, "w") as f:
        json.dump(data, f, indent=2)


# ── One-time migration (legacy — kept for path normalization only) ──────────

_MIGRATED = False


def _migrate_to_split_settings() -> None:
    """One-time migration: normalize workspace paths in global settings.

    Strips /vault suffix from workspace paths if present. Operational config
    now lives centrally at ~/.config/fathom-mcp/settings.json — this migration
    only handles legacy path normalization.
    """
    global _MIGRATED
    if _MIGRATED:
        return
    _MIGRATED = True

    try:
        with open(_SETTINGS_FILE) as f:
            saved = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return

    workspaces = saved.get("workspaces", {})
    if not workspaces:
        return

    def _entry_path(entry):
        return entry["path"] if isinstance(entry, dict) else entry

    needs_path_migration = any(_entry_path(p).endswith("/vault") for p in workspaces.values())
    if not needs_path_migration:
        return

    new_workspaces = {}
    for name, entry in workspaces.items():
        ws_path = _entry_path(entry)
        if ws_path.endswith("/vault"):
            project_root = ws_path[:-6]
            if os.path.isdir(project_root):
                new_workspaces[name] = project_root
            else:
                new_workspaces[name] = ws_path
        else:
            new_workspaces[name] = ws_path

    global_data = {
        "workspaces": new_workspaces,
        "default_workspace": saved.get("default_workspace", next(iter(new_workspaces))),
    }
    os.makedirs(_SETTINGS_DIR, exist_ok=True)
    with open(_SETTINGS_FILE, "w") as f:
        json.dump(global_data, f, indent=2)


# ── Backward-compatible wrappers ─────────────────────────────────────────────


def load_settings(workspace: str = None) -> dict:
    """Load merged settings: global (workspaces) + central (operational).

    Triggers one-time path migration on first call.
    """
    _migrate_to_split_settings()

    gs = load_global_settings()
    ws_s = load_workspace_settings()

    # Merge: central config + global fields
    merged = {**ws_s}
    merged["workspaces"] = gs["workspaces"]
    merged["default_workspace"] = gs["default_workspace"]
    merged["rooms"] = gs["rooms"]
    merged["telegram"] = gs["telegram"]
    merged["tts"] = gs["tts"]
    return merged


def save_settings(settings: dict, workspace: str = None) -> None:
    """Save settings, routing global and central fields to correct files."""
    gs = load_global_settings()

    # Route global fields
    changed_global = False
    if "workspaces" in settings:
        gs["workspaces"] = settings["workspaces"]
        changed_global = True
    if "default_workspace" in settings:
        gs["default_workspace"] = settings["default_workspace"]
        changed_global = True
    if "rooms" in settings:
        gs["rooms"] = settings["rooms"]
        changed_global = True
    if "telegram" in settings:
        gs["telegram"] = settings["telegram"]
        changed_global = True
    if "tts" in settings:
        gs["tts"] = settings["tts"]
        changed_global = True
    if changed_global:
        save_global_settings(gs)

    # Route central operational fields
    ws_keys = set(_WORKSPACE_DEFAULTS.keys())
    ws_data = {k: v for k, v in settings.items() if k in ws_keys}
    if ws_data:
        current = load_workspace_settings()
        current.update(ws_data)
        save_workspace_settings(workspace, current)


# ── Workspace CRUD ───────────────────────────────────────────────────────────


def add_workspace(
    name: str,
    project_path: str,
    vault: str = "vault",
    description: str = "",
    agents: list | None = None,
    type: str = "local",
    execution: str | None = None,
) -> tuple[bool, str]:
    """Add or update a workspace. Path is the project root (must contain vault/ subdir).

    Idempotent: same name + same path = update metadata (vault, description).
    Same name + different path = reject with error.

    Two independent axes:
      - type (vault mode): agent-declarable — hosted/synced/local/none
      - execution: admin-granted — "local" requires valid path, "remote" or "none" don't

    Creates .fathom/ directory with default settings if missing.
    Returns (ok, error_message).
    """
    if not name or not isinstance(name, str):
        return False, "Workspace name is required"

    # Validate execution mode
    valid_exec = ("local", "remote", "none")
    if execution is not None and execution not in valid_exec:
        return False, f"execution must be one of: {', '.join(valid_exec)}"

    # execution: "local" requires a valid path
    if execution == "local" or (execution is None and type != "human"):
        if not project_path or not isinstance(project_path, str):
            return False, "Project path is required for local execution"
        if not os.path.isdir(project_path):
            return False, f"Path does not exist: {project_path}"

    # Remote/none execution — path is optional
    if not project_path:
        project_path = ""

    vault_subdir = vault or "vault"
    # Hosted and none modes don't require a local vault directory
    if type not in ("hosted", "none") and project_path:
        vault_dir = os.path.join(project_path, vault_subdir)
        if not os.path.isdir(vault_dir):
            return False, f"No {vault_subdir}/ subdirectory found at: {vault_dir}"

    agents_list = agents or []

    gs = load_global_settings()
    existing = gs["workspaces"].get(name)
    if existing:
        existing_path = existing["path"]
        if (
            project_path
            and existing_path
            and os.path.realpath(existing_path) != os.path.realpath(project_path)
        ):
            return False, f'Workspace "{name}" already exists at a different path'
        # Idempotent upsert — merge new metadata into existing entry
        if vault:
            existing["vault"] = vault_subdir
        if description:
            existing["description"] = _sanitize_description(description)
        if agents_list:
            existing["agents"] = agents_list
        if type:
            existing["type"] = type
        if execution is not None:
            existing["execution"] = execution
        if project_path:
            existing["path"] = project_path
        gs["workspaces"][name] = existing
    else:
        ws_entry = {
            "path": project_path,
            "vault": vault_subdir,
            "description": _sanitize_description(description),
            "agents": agents_list,
            "type": type,
        }
        if execution is not None:
            ws_entry["execution"] = execution
        gs["workspaces"][name] = ws_entry

    save_global_settings(gs)
    return True, ""


def remove_workspace(name: str) -> tuple[bool, str]:
    """Remove a workspace. Cannot remove the default. Returns (ok, error_message)."""
    gs = load_global_settings()

    if name not in gs["workspaces"]:
        return False, f'Workspace "{name}" not found'
    if name == gs["default_workspace"]:
        return False, "Cannot remove the default workspace"

    del gs["workspaces"][name]
    save_global_settings(gs)
    return True, ""


def set_default_workspace(name: str) -> tuple[bool, str]:
    """Set a workspace as default. Returns (ok, error_message)."""
    gs = load_global_settings()

    if name not in gs["workspaces"]:
        return False, f'Workspace "{name}" not found'

    gs["default_workspace"] = name
    save_global_settings(gs)
    return True, ""
