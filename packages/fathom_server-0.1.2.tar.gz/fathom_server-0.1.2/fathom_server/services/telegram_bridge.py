"""Telegram bridge — persistent Telethon client for bidirectional messaging.

Runs a single Telethon client in a daemon thread with its own asyncio event loop.
Polls for new messages every 3 seconds, stores them in the room_messages table
(using room name pattern `telegram:{chat_id}`), upserts contacts, and injects
inbound messages into the primary agent's tmux session.
"""

import asyncio
import logging
import subprocess
import threading
import time
from pathlib import Path

from fathom_server.db import get_connection
from fathom_server.paths import TELEGRAM_ASSETS_DIR

log = logging.getLogger("telegram-bridge")


_ASSETS_DIR = TELEGRAM_ASSETS_DIR
_TRANSCRIBE_BIN = Path(__file__).resolve().parent.parent.parent / "scripts" / "transcribe"


class TelegramBridge:
    """Persistent Telethon client with polling-based message detection."""

    POLL_INTERVAL = 3  # seconds

    def __init__(self):
        self._api_id: int = 0
        self._api_hash: str = ""
        self._session_string: str = ""
        self._primary_agent: str = ""
        self._enabled: bool = False

        self._running: bool = False
        self._connected: bool = False
        self._thread: threading.Thread | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._client = None
        self._last_seen: dict[int, int] = {}  # {chat_id: last_msg_id}
        self._last_poll_at: float = 0
        self._lock = threading.Lock()

    def configure(
        self,
        api_id: int = 0,
        api_hash: str = "",
        session_string: str = "",
        primary_agent: str = "",
        enabled: bool = False,
    ) -> None:
        self._api_id = api_id
        self._api_hash = api_hash
        self._session_string = session_string
        self._primary_agent = primary_agent
        self._enabled = enabled

    @property
    def status(self) -> dict:
        return {
            "running": self._running,
            "connected": self._connected,
            "enabled": self._enabled,
            "primary_agent": self._primary_agent,
            "last_poll_at": self._last_poll_at,
        }

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def start(self) -> None:
        if self._running:
            return
        if not self._enabled:
            log.info("Telegram bridge disabled, not starting")
            return
        if not self._session_string or not self._api_id or not self._api_hash:
            log.warning("Telegram bridge missing credentials, not starting")
            return

        self._running = True

        def _thread_target():
            self._loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self._loop)
            try:
                self._loop.run_until_complete(self._run())
            except Exception:
                log.exception("Telegram bridge crashed")
            finally:
                self._loop.close()
                self._running = False
                self._connected = False

        self._thread = threading.Thread(target=_thread_target, daemon=True)
        self._thread.start()
        log.info("Telegram bridge thread started")

    def stop(self, timeout: float = 5) -> None:
        """Stop the bridge and wait for the thread to finish."""
        if not self._running:
            return
        self._running = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=timeout)

    # ── Async core ────────────────────────────────────────────────────────────

    async def _run(self) -> None:
        from telethon import TelegramClient
        from telethon.sessions import StringSession

        self._client = TelegramClient(
            StringSession(self._session_string), self._api_id, self._api_hash
        )

        try:
            await self._client.connect()
            if not await self._client.is_user_authorized():
                log.error("Telegram session not authorized")
                self._running = False
                return

            me = await self._client.get_me()
            log.info("Telegram bridge connected as %s (id=%d)", me.first_name, me.id)

            # Seed last_seen for all recent dialogs so we don't replay history
            async for dialog in self._client.iter_dialogs(limit=20):
                if dialog.message:
                    self._last_seen[dialog.entity.id] = dialog.message.id

            self._connected = True
            await self._poll_loop()
        except Exception:
            log.exception("Telegram bridge error")
        finally:
            self._connected = False
            self._running = False
            if self._client:
                await self._client.disconnect()

    async def _poll_loop(self) -> None:
        """Poll recent dialogs for new messages."""
        while self._running:
            try:
                # Get recent dialogs to detect messages from any contact
                async for dialog in self._client.iter_dialogs(limit=10):
                    if not dialog.message:
                        continue
                    # Accept messages with text OR media (photos)
                    if not dialog.message.message and not dialog.message.media:
                        continue
                    entity = dialog.entity
                    chat_id = entity.id
                    msg = dialog.message

                    prev_id = self._last_seen.get(chat_id, 0)
                    if msg.id <= prev_id:
                        continue

                    # New message(s) — fetch all since last_seen
                    new_msgs = await self._client.get_messages(entity, min_id=prev_id, limit=20)
                    for m in reversed(new_msgs):  # oldest first
                        if not m.message and not m.media:
                            continue
                        if m.id <= prev_id:
                            continue
                        self._last_seen[chat_id] = m.id
                        await self._handle_message(m, entity)

                self._last_poll_at = time.time()
            except Exception:
                log.exception("Telegram poll error")

            await asyncio.sleep(self.POLL_INTERVAL)

    async def _handle_message(self, msg, entity) -> None:
        """Process a single new message — store and inject if inbound."""
        chat_id = entity.id
        is_outgoing = msg.out
        ts = time.time()

        # Upsert contact
        first_name = getattr(entity, "first_name", "") or ""
        last_name = getattr(entity, "last_name", "") or ""
        username = getattr(entity, "username", "") or ""
        self._upsert_contact(chat_id, first_name, last_name, username, ts)

        # Determine sender label
        if is_outgoing:
            sender = self._primary_agent or "agent"
        else:
            sender = first_name or username or str(chat_id)

        # Download media if present
        media_path = await self._download_media(msg, chat_id)

        text = msg.message or ""

        # Auto-transcribe voice/audio messages
        transcript = None
        if media_path and not is_outgoing:
            transcript = self._transcribe_audio(media_path)

        # If we got a transcript, use it as the message text
        store_text = text
        if transcript:
            store_text = transcript if not text else f"{text}\n[voice: {transcript}]"

        # Store in room_messages — skip outgoing (send_message already stores them)
        if not is_outgoing:
            room = f"telegram:{chat_id}"
            with get_connection() as con:
                con.execute(
                    "INSERT INTO room_messages "
                    "(room, sender, message, timestamp, media_path) "
                    "VALUES (?, ?, ?, ?, ?)",
                    (room, sender, store_text, ts, media_path),
                )
                con.commit()

        # Inject inbound messages into primary agent session
        if not is_outgoing and self._primary_agent:
            media_hint = ""
            media_label = "[photo]"
            if media_path:
                if transcript:
                    # Voice message — transcript is the content
                    media_label = f"[voice] {transcript}"
                    media_hint = ""
                elif media_path.endswith((".jpg", ".jpeg", ".png", ".gif", ".webp")):
                    media_hint = (
                        "\n(Image attached — view with: "
                        'fathom_telegram_image message_id="<id from read>")'
                    )
                else:
                    media_label = f"[file: {Path(media_path).name}]"
                    media_hint = (
                        "\n(File attached — read with: "
                        'fathom_telegram_file message_id="<id from read>")'
                    )
            inject_text = (
                f"Telegram message from {sender}: {text or media_label}{media_hint}\n"
                f'(Read the conversation with fathom_telegram_read contact="{chat_id}" '
                f"before replying — this is one message without context.\n"
                f' Reply with: fathom_telegram_send contact="{chat_id}" message="...")'
            )
            try:
                from fathom_server.services.agent_connections import inject_or_push

                inject_or_push(inject_text, workspace=self._primary_agent, sender=sender)
            except Exception:
                log.exception("Failed to inject telegram message")

        # Push image data to agent over WebSocket for local caching
        if not is_outgoing and media_path and self._primary_agent:
            try:
                from fathom_server.services.agent_connections import push_image

                img_path = _ASSETS_DIR / media_path
                if img_path.exists():
                    import base64

                    img_data = base64.b64encode(img_path.read_bytes()).decode("ascii")
                    push_image(
                        self._primary_agent,
                        message_id=msg.id,
                        chat_id=chat_id,
                        data=img_data,
                        mime_type="image/jpeg",
                        filename=media_path,
                    )
            except Exception:
                log.debug("Failed to push image via WebSocket (will use HTTP fallback)")

        direction = "out" if is_outgoing else "in"
        preview = text[:50] if text else "[media]"
        if media_path:
            preview += " [+image]"
        log.info(
            "Telegram %s (chat=%d): %s",
            direction,
            chat_id,
            preview,
        )

    async def _download_media(self, msg, chat_id: int) -> str | None:
        """Download photo or document from a message. Returns relative path or None."""
        if not msg.media:
            return None

        from telethon.tl.types import MessageMediaDocument, MessageMediaPhoto

        _ASSETS_DIR.mkdir(parents=True, exist_ok=True)

        if isinstance(msg.media, MessageMediaPhoto):
            ext = ".jpg"
            filename = f"{chat_id}_{msg.id}{ext}"
        elif isinstance(msg.media, MessageMediaDocument):
            doc = msg.media.document
            # Get original filename from attributes if available
            original_name = None
            for attr in doc.attributes or []:
                if hasattr(attr, "file_name"):
                    original_name = attr.file_name
                    break
            if original_name:
                ext = Path(original_name).suffix or ".bin"
                # Sanitize: keep only alphanumeric, dash, underscore, dot
                safe_name = "".join(c if c.isalnum() or c in "-_." else "_" for c in original_name)
                filename = f"{chat_id}_{msg.id}_{safe_name}"
            else:
                mime = doc.mime_type or ""
                ext = {
                    "text/plain": ".txt",
                    "application/pdf": ".pdf",
                    "application/json": ".json",
                }.get(mime, ".bin")
                filename = f"{chat_id}_{msg.id}{ext}"
        else:
            return None

        dest = _ASSETS_DIR / filename

        try:
            await self._client.download_media(msg, file=str(dest))
            log.info("Downloaded telegram media: %s", filename)
            return filename
        except Exception:
            log.exception("Failed to download telegram media")
            return None

    def _transcribe_audio(self, media_path: str) -> str | None:
        """Transcribe an audio file using the transcribe script. Returns text or None."""
        filepath = _ASSETS_DIR / media_path
        if not filepath.exists():
            return None

        # Check if it's an audio file (ogg, bin that might be ogg, wav, mp3, m4a)
        ext = filepath.suffix.lower()
        is_audio = ext in (".ogg", ".wav", ".mp3", ".m4a", ".opus", ".oga")
        # .bin files from Telegram voice messages are usually OGG Opus
        if ext == ".bin":
            try:
                with open(filepath, "rb") as f:
                    is_audio = f.read(4) == b"OggS"
            except Exception:
                pass
        if not is_audio:
            return None

        try:
            bin_path = str(_TRANSCRIBE_BIN) if _TRANSCRIBE_BIN.exists() else "transcribe"
            result = subprocess.run(
                [bin_path, str(filepath)],
                capture_output=True,
                text=True,
                timeout=60,
            )
            if result.returncode == 0 and result.stdout.strip():
                transcript = result.stdout.strip()
                log.info("Transcribed audio (%s): %s", media_path, transcript[:80])
                return transcript
            if result.stderr:
                log.warning("Transcription stderr: %s", result.stderr[:200])
        except subprocess.TimeoutExpired:
            log.warning("Transcription timed out for %s", media_path)
        except FileNotFoundError:
            log.warning(
                "transcribe not found — install: "
                "ln -s /path/to/fathom-vault/scripts/transcribe ~/.local/bin/transcribe"
            )
            return "[[transcribe not installed — voice message not decoded]]"
        except Exception:
            log.exception("Transcription failed for %s", media_path)
        return None

    def _upsert_contact(
        self, chat_id: int, first_name: str, last_name: str, username: str, ts: float
    ) -> None:
        with get_connection() as con:
            con.execute(
                """INSERT INTO telegram_contacts
                   (chat_id, first_name, last_name, username, first_seen, last_message_at)
                   VALUES (?, ?, ?, ?, ?, ?)
                   ON CONFLICT(chat_id) DO UPDATE SET
                     first_name = excluded.first_name,
                     last_name = excluded.last_name,
                     username = excluded.username,
                     last_message_at = excluded.last_message_at
                """,
                (chat_id, first_name, last_name, username, ts, ts),
            )
            con.commit()

    # ── Sync wrappers (called from FastAPI routes / MCP handlers) ──────────────

    def send_message(self, chat_id: int, text: str) -> dict:
        """Send a message via the persistent Telethon client. Sync wrapper."""
        if not self._connected or not self._loop or self._loop.is_closed():
            return {"error": "Telegram bridge not connected"}

        text = text.strip()[:4096]  # Telegram message limit
        if not text:
            return {"error": "Message text is empty"}

        future = asyncio.run_coroutine_threadsafe(
            self._send_message_async(chat_id, text), self._loop
        )
        try:
            return future.result(timeout=15)
        except Exception as e:
            log.exception("send_message error")
            return {"error": str(e)}

    def send_image(self, chat_id: int, file_path: str, caption: str = "") -> dict:
        """Send an image via the persistent Telethon client. Sync wrapper."""
        if not self._connected or not self._loop or self._loop.is_closed():
            return {"error": "Telegram bridge not connected"}

        p = Path(file_path)
        if not p.exists():
            return {"error": f"File not found: {file_path}"}
        if not p.is_file():
            return {"error": f"Not a file: {file_path}"}

        max_size = 10 * 1024 * 1024  # Telegram photo limit ~10MB
        if p.stat().st_size > max_size:
            return {"error": f"File too large ({p.stat().st_size} bytes, max 10MB)"}

        future = asyncio.run_coroutine_threadsafe(
            self._send_image_async(chat_id, str(p), caption.strip()[:1024]),
            self._loop,
        )
        try:
            return future.result(timeout=30)
        except Exception as e:
            log.exception("send_image error")
            return {"error": str(e)}

    async def _resolve_entity(self, chat_id: int):
        """Resolve a chat_id to a Telethon entity."""
        try:
            return await self._client.get_entity(chat_id)
        except ValueError:
            async for dialog in self._client.iter_dialogs(limit=100):
                if getattr(dialog.entity, "id", None) == chat_id:
                    return dialog.entity
            return None

    async def _send_message_async(self, chat_id: int, text: str) -> dict:
        entity = await self._resolve_entity(chat_id)
        if not entity:
            return {"error": f"Could not find entity for chat_id {chat_id}"}

        await self._client.send_message(entity, text)

        # Store outbound message in room_messages
        ts = time.time()
        room = f"telegram:{chat_id}"
        sender = self._primary_agent or "agent"
        with get_connection() as con:
            con.execute(
                "INSERT INTO room_messages (room, sender, message, timestamp) VALUES (?, ?, ?, ?)",
                (room, sender, text, ts),
            )
            con.commit()

        return {"ok": True, "chat_id": chat_id, "timestamp": ts}

    async def _send_image_async(self, chat_id: int, file_path: str, caption: str) -> dict:
        entity = await self._resolve_entity(chat_id)
        if not entity:
            return {"error": f"Could not find entity for chat_id {chat_id}"}

        await self._client.send_file(entity, file_path, caption=caption or None)

        # Store outbound message in room_messages
        ts = time.time()
        room = f"telegram:{chat_id}"
        sender = self._primary_agent or "agent"
        text = caption or "[photo]"

        # Copy image to assets dir for local serving
        src = Path(file_path)
        _ASSETS_DIR.mkdir(parents=True, exist_ok=True)
        asset_name = f"{chat_id}_out_{int(ts)}{src.suffix}"
        dest = _ASSETS_DIR / asset_name
        import shutil

        shutil.copy2(str(src), str(dest))

        with get_connection() as con:
            con.execute(
                "INSERT INTO room_messages (room, sender, message, timestamp, media_path) "
                "VALUES (?, ?, ?, ?, ?)",
                (room, sender, text, ts, asset_name),
            )
            con.commit()

        return {"ok": True, "chat_id": chat_id, "timestamp": ts}

    def send_voice(self, chat_id: int, file_path: str, caption: str = "") -> dict:
        """Send a voice note via the persistent Telethon client. Sync wrapper."""
        if not self._connected or not self._loop or self._loop.is_closed():
            return {"error": "Telegram bridge not connected"}

        p = Path(file_path)
        if not p.exists():
            return {"error": f"File not found: {file_path}"}
        if not p.is_file():
            return {"error": f"Not a file: {file_path}"}

        max_size = 10 * 1024 * 1024
        if p.stat().st_size > max_size:
            return {"error": f"File too large ({p.stat().st_size} bytes, max 10MB)"}

        future = asyncio.run_coroutine_threadsafe(
            self._send_voice_async(chat_id, str(p), caption.strip()[:1024]),
            self._loop,
        )
        try:
            return future.result(timeout=30)
        except Exception as e:
            log.exception("send_voice error")
            return {"error": str(e)}

    async def _send_voice_async(self, chat_id: int, file_path: str, caption: str) -> dict:
        entity = await self._resolve_entity(chat_id)
        if not entity:
            return {"error": f"Could not find entity for chat_id {chat_id}"}

        await self._client.send_file(entity, file_path, caption=caption or None, voice_note=True)

        ts = time.time()
        room = f"telegram:{chat_id}"
        sender = self._primary_agent or "agent"
        text = caption or "[voice]"

        with get_connection() as con:
            con.execute(
                "INSERT INTO room_messages (room, sender, message, timestamp) VALUES (?, ?, ?, ?)",
                (room, sender, text, ts),
            )
            con.commit()

        return {"ok": True, "chat_id": chat_id, "timestamp": ts}

    def get_contacts(self) -> list[dict]:
        """Query telegram_contacts table."""
        with get_connection() as con:
            rows = con.execute(
                "SELECT * FROM telegram_contacts ORDER BY last_message_at DESC"
            ).fetchall()
            return [dict(r) for r in rows]

    def resolve_contact(self, contact: str) -> int | None:
        """Resolve a contact name/username/chat_id to a chat_id integer.

        Accepts: integer string, @username, or first name substring.
        """
        # Direct chat_id
        try:
            return int(contact)
        except (ValueError, TypeError):
            pass

        if not contact:
            return None

        contact_lower = contact.lower().lstrip("@")
        with get_connection() as con:
            # Try username match (exact, case-insensitive)
            row = con.execute(
                "SELECT chat_id FROM telegram_contacts WHERE LOWER(username) = ?",
                (contact_lower,),
            ).fetchone()
            if row:
                return row["chat_id"]

            # Try first_name match (exact, case-insensitive)
            row = con.execute(
                "SELECT chat_id FROM telegram_contacts WHERE LOWER(first_name) = ?",
                (contact_lower,),
            ).fetchone()
            if row:
                return row["chat_id"]

            # Try partial first_name match
            row = con.execute(
                "SELECT chat_id FROM telegram_contacts WHERE LOWER(first_name) LIKE ?",
                (f"%{contact_lower}%",),
            ).fetchone()
            if row:
                return row["chat_id"]

            return None

    def fetch_history(self, chat_id: int, limit: int = 50) -> list[dict] | None:
        """Fetch message history from Telegram via the persistent client. Sync wrapper."""
        if not self._connected or not self._loop or self._loop.is_closed():
            return None

        future = asyncio.run_coroutine_threadsafe(
            self._fetch_history_async(chat_id, limit), self._loop
        )
        try:
            return future.result(timeout=15)
        except Exception:
            log.exception("fetch_history error")
            return None

    async def _fetch_history_async(self, chat_id: int, limit: int) -> list[dict]:
        from datetime import UTC

        messages = await self._client.get_messages(chat_id, limit=limit)
        result = []
        for msg in messages:
            if not msg.message:
                continue
            msg_date = msg.date
            if msg_date.tzinfo is None:
                msg_date = msg_date.replace(tzinfo=UTC)
            result.append(
                {
                    "id": msg.id,
                    "content": msg.message,
                    "direction": "out" if msg.out else "in",
                    "timestamp": msg_date.isoformat(),
                }
            )
        return result


# Module-level singleton
telegram_bridge = TelegramBridge()
