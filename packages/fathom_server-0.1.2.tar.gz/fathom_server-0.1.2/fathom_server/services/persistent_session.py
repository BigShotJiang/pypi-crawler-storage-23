"""Persistent workspace session manager.

Manages workspace-scoped sessions running AI agents (Claude Code, Codex, Gemini, etc.).
Interactive agents run in tmux: {workspace}_fathom-session.
Headless agents (claude-sdk) spawn a fresh `claude -p` per prompt (per-invocation model).
"""

import logging
import os
import signal
import subprocess
import threading
import time
from pathlib import Path

from fathom_server.config import get_workspace_path
from fathom_server.paths import CLAUDE_BIN, CONFIG_DIR
from fathom_server.services.settings import load_global_settings

log = logging.getLogger(__name__)

_CLAUDE = CLAUDE_BIN
_FATHOM_CONFIG_DIR = CONFIG_DIR

# Bare command names → full paths (for systemd environments without user PATH)
_CMD_PATHS = {"claude": _CLAUDE}


def resolve_cmd(cmd_string: str) -> list[str]:
    """Split a command string and resolve bare executable names to full paths."""
    parts = cmd_string.split()
    if parts:
        parts[0] = _CMD_PATHS.get(parts[0], parts[0])
    return parts


def load_agent_entry(workspace: str = None) -> dict:
    """Load agent entry from central registry (~/.config/fathom-mcp/agents.json)."""
    import json

    registry_path = _FATHOM_CONFIG_DIR / "agents.json"
    try:
        registry = json.loads(registry_path.read_text())
        return registry.get("agents", {}).get(workspace or "fathom", {})
    except (OSError, json.JSONDecodeError):
        return {}


def is_headless_workspace(workspace: str = None) -> bool:
    """Return True if the workspace uses headless (per-invocation) execution."""
    entry = load_agent_entry(workspace)
    return entry.get("executionMode") == "headless"


def is_human_workspace(workspace: str = None) -> bool:
    """Return True if the workspace type is 'human'."""
    settings = load_global_settings()
    ws_entry = settings.get("workspaces", {}).get(workspace or "fathom", {})
    return ws_entry.get("type", "local") == "human"


def _get_execution_mode(workspace: str = None) -> str:
    """Return the execution mode for a workspace: 'local', 'remote', or 'none'."""
    settings = load_global_settings()
    ws_entry = settings.get("workspaces", {}).get(workspace or "fathom", {})
    ws_type = ws_entry.get("type", "local")
    default_exec = "none" if ws_type == "human" else "local"
    return ws_entry.get("execution", default_exec)


def _inbox_path(workspace: str = None) -> Path:
    """Return the inbox log file path for a human workspace."""
    ws = workspace or "fathom"
    return _FATHOM_CONFIG_DIR / f"{ws}-inbox.log"


_lock = threading.Lock()

# Explicit socket avoids "no current client" in systemd services
_TMUX_SOCKET = f"/tmp/tmux-{os.getuid()}/default"


def _tmux_cmd(*args: str) -> list[str]:
    """Build a tmux command with explicit socket path."""
    return ["tmux", "-S", _TMUX_SOCKET, *args]


def _tmux_send_keys(pane: str, text: str) -> bool:
    """Send literal text to a tmux pane. Retries once with delay on failure."""
    for attempt in range(2):
        r = subprocess.run(
            _tmux_cmd("send-keys", "-t", pane, "-l", text),
            capture_output=True,
            text=True,
        )
        if r.returncode == 0:
            return True
        if attempt == 0:
            log.warning(
                "tmux send-keys text failed (rc=%d, attempt 1): %s", r.returncode, r.stderr.strip()
            )
            time.sleep(1)
    log.error("tmux send-keys text failed after retry (rc=%d): %s", r.returncode, r.stderr.strip())
    return False


def _tmux_send_enter(pane: str) -> bool:
    """Press Enter in a tmux pane."""
    r = subprocess.run(
        _tmux_cmd("send-keys", "-t", pane, "", "Enter"),
        capture_output=True,
        text=True,
    )
    if r.returncode != 0:
        log.error("tmux send-keys Enter failed (rc=%d): %s", r.returncode, r.stderr.strip())
        return False
    return True


def session_name(workspace: str = None) -> str:
    """Return the tmux session name for a workspace."""
    ws = workspace or "fathom"
    return f"{ws}_fathom-session"


def _pane_id_file(workspace: str = None) -> Path:
    """Return the pane-id file path for a workspace."""
    ws = workspace or "fathom"
    return _FATHOM_CONFIG_DIR / f"{ws}-pane-id"


def work_dir(workspace: str = None) -> str:
    """Return the working directory for a workspace."""
    ws_path, _err = get_workspace_path(workspace)
    return ws_path or str(Path.home())


def _save_pane_id(workspace: str = None) -> None:
    """Query tmux for the session's pane ID and write it to the pane-id file."""
    session = session_name(workspace)
    result = subprocess.run(
        _tmux_cmd("list-panes", "-t", session, "-F", "#{pane_id}"),
        capture_output=True,
        text=True,
    )
    if result.returncode == 0 and result.stdout.strip():
        pane_id = result.stdout.strip().split("\n")[0]
        pane_file = _pane_id_file(workspace)
        pane_file.parent.mkdir(parents=True, exist_ok=True)
        pane_file.write_text(pane_id)


def _main_pane(workspace: str = None) -> str:
    """Return the tmux target for a workspace's main pane.

    Reads the workspace-specific pane-id file if it exists.
    Falls back to session-level target.
    """
    pane_file = _pane_id_file(workspace)
    try:
        pane_id = pane_file.read_text().strip()
        if pane_id:
            return pane_id
    except OSError:
        pass
    return session_name(workspace)


def _tmux_has_session(workspace: str = None) -> bool:
    """Return True if the workspace's tmux session exists."""
    session = session_name(workspace)
    result = subprocess.run(
        _tmux_cmd("has-session", "-t", session),
        capture_output=True,
    )
    return result.returncode == 0


def _headless_is_running(workspace: str = None) -> bool:
    """Return True if any per-invocation headless processes are alive."""
    pids_dir = Path(work_dir(workspace)) / ".fathom" / "pids"
    if not pids_dir.is_dir():
        return False
    for pid_file in pids_dir.iterdir():
        try:
            pid = int(pid_file.name)
            os.kill(pid, 0)  # existence check
            return True
        except (ValueError, OSError):
            # Stale file or dead process — clean up
            try:
                pid_file.unlink()
            except OSError:
                pass
    return False


def is_running(workspace: str = None) -> bool:
    """Return True if the workspace's agent session is alive."""
    if is_headless_workspace(workspace):
        return _headless_is_running(workspace)
    return _tmux_has_session(workspace)


def _clean_env() -> dict:
    """Return a copy of os.environ without CLAUDECODE."""
    env = os.environ.copy()
    env.pop("CLAUDECODE", None)
    return env


def _build_headless_cmd(workspace: str) -> list[str]:
    """Build the command parts for a headless agent invocation."""
    entry = load_agent_entry(workspace)
    cmd = entry.get("command", "")
    if cmd:
        return resolve_cmd(cmd)
    # Bare minimum fallback
    return [_CLAUDE, "-p", "--model", "opus"]


def _wait_and_cleanup(proc: subprocess.Popen, pid_file: Path) -> None:
    """Wait for process to finish, then remove its PID file."""
    proc.wait()
    try:
        pid_file.unlink()
    except OSError:
        pass


def _start_tmux(workspace: str, entry: dict, cwd: str) -> bool:
    """Spawn an interactive agent inside a tmux session."""
    session = session_name(workspace)
    env = _clean_env()

    # Registry command already includes --continue, --permission-mode, etc.
    cmd_parts = resolve_cmd(entry.get("command", "claude --continue"))
    cmd = _tmux_cmd("new-session", "-d", "-s", session, *cmd_parts)

    subprocess.Popen(cmd, env=env, cwd=cwd)
    time.sleep(2)
    if _tmux_has_session(workspace):
        _save_pane_id(workspace)
        return True
    return False


def ensure_running(workspace: str = None) -> bool:
    """Start workspace session if not running. Returns True if session is up.

    Only launches sessions for execution: "local" workspaces.
    """
    execution = _get_execution_mode(workspace)
    if execution != "local":
        log.debug("ensure_running(%s): skipped — execution=%s", workspace, execution)
        return False

    with _lock:
        if is_running(workspace):
            return True
        cwd = work_dir(workspace)
        env = _clean_env()

        # Human workspaces get bash + tail -f on inbox — no AI agent
        if is_human_workspace(workspace):
            session = session_name(workspace)
            inbox = _inbox_path(workspace)
            inbox.parent.mkdir(parents=True, exist_ok=True)
            inbox.touch()
            try:
                subprocess.Popen(
                    _tmux_cmd("new-session", "-d", "-s", session, "bash"),
                    env=env,
                    cwd=cwd,
                )
                time.sleep(1)
                if _tmux_has_session(workspace):
                    _save_pane_id(workspace)
                    pane = _main_pane(workspace)
                    subprocess.run(
                        _tmux_cmd("send-keys", "-t", pane, f"tail -f {inbox}", "Enter"),
                        capture_output=True,
                        env=env,
                    )
                    return True
                return False
            except Exception:
                log.exception("Failed to start human workspace session for %s", workspace)
                return False

        entry = load_agent_entry(workspace)

        if is_headless_workspace(workspace):
            # Headless agents are per-invocation — always "ready", no persistent process
            return True

        try:
            return _start_tmux(workspace, entry, cwd)
        except Exception:
            log.exception("Failed to start tmux session for %s", workspace)
            return False


def _inject_headless(workspace: str, text: str) -> bool:
    """Spawn a fresh claude -p process for this prompt."""
    ws = workspace or "fathom"
    cwd = work_dir(workspace)
    pids_dir = Path(cwd) / ".fathom" / "pids"
    pids_dir.mkdir(parents=True, exist_ok=True)
    log_file = Path(cwd) / ".fathom" / "agent.log"

    cmd = _build_headless_cmd(ws)
    env = _clean_env()

    with open(log_file, "a") as log_fh:
        proc = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=log_fh,
            stderr=subprocess.STDOUT,
            cwd=cwd,
            env=env,
            start_new_session=True,
        )

    # Write prompt and close stdin — EOF triggers processing
    proc.stdin.write(text.encode())
    proc.stdin.close()

    # Track PID
    pid_file = pids_dir / str(proc.pid)
    pid_file.write_text(str(proc.pid))

    log.info("Spawned headless invocation for %s: PID %d", ws, proc.pid)

    # Fire-and-forget cleanup thread
    threading.Thread(target=_wait_and_cleanup, args=(proc, pid_file), daemon=True).start()

    return True


def _inject_tmux(text: str, workspace: str = None) -> bool:
    """Send text to a tmux pane and press Enter."""
    pane = _main_pane(workspace)
    try:
        if not _tmux_send_keys(pane, text):
            return False
        time.sleep(1)
        return _tmux_send_enter(pane)
    except Exception:
        log.exception("_inject_tmux() exception for workspace=%s", workspace)
        return False


def inject(text: str, workspace: str = None, sender: str = None) -> bool:
    """Send text to a workspace's session as a new user message, then press Enter.

    For human workspaces, appends to the inbox log file instead of sending
    keystrokes to tmux. For headless agents (claude-sdk), writes to stdin.
    The ``sender`` parameter is optional and adds a "from: <sender>" tag to
    the inbox entry.

    Returns True if the send succeeded. Does not wait for or capture the response.
    Only works for execution: "local" (or human) workspaces.
    """
    execution = _get_execution_mode(workspace)
    # "none" is allowed here because human workspaces have execution: "none"
    # but use inbox files — is_human_workspace() handles that path below
    if execution not in ("local", "none") and not is_human_workspace(workspace):
        log.warning("inject(%s): cannot inject — execution=%s", workspace, execution)
        return False

    # Human workspaces — append to inbox file (tail -f picks it up live)
    if is_human_workspace(workspace):
        inbox = _inbox_path(workspace)
        inbox.parent.mkdir(parents=True, exist_ok=True)
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        header = f"--- {timestamp}"
        if sender:
            header += f" | from: {sender}"
        header += " ---"
        try:
            with open(inbox, "a") as f:
                f.write(f"\n{header}\n{text}\n")
            return True
        except Exception:
            log.exception("Failed to write to inbox for %s", workspace)
            return False

    # Route to headless or tmux injection
    if is_headless_workspace(workspace):
        # Headless agents spawn per-invocation — no need to check is_running
        return _inject_headless(workspace, text)

    if not is_running(workspace):
        started = ensure_running(workspace)
        if not started:
            return False
        time.sleep(10)

    return _inject_tmux(text, workspace)


def _stop_headless(workspace: str = None) -> bool:
    """Kill all tracked headless PIDs."""
    cwd = Path(work_dir(workspace)) / ".fathom"
    pids_dir = cwd / "pids"
    killed = False
    if pids_dir.is_dir():
        for pid_file in pids_dir.iterdir():
            try:
                pid = int(pid_file.name)
                os.kill(pid, signal.SIGTERM)
                killed = True
            except (ValueError, OSError):
                pass
            try:
                pid_file.unlink()
            except OSError:
                pass
    # Clean up legacy files
    for name in ("agent.pid", "agent-keeper.pid", "agent.pipe"):
        try:
            (cwd / name).unlink()
        except OSError:
            pass
    return killed or not _headless_is_running(workspace)


def stop(workspace: str = None) -> bool:
    """Kill a workspace's session. Returns True if session was killed.

    No execution guard — if there's a session to kill, kill it.
    Used when revoking local execution.
    """
    with _lock:
        if not is_running(workspace):
            return False

        if is_headless_workspace(workspace):
            return _stop_headless(workspace)

        session = session_name(workspace)
        subprocess.run(
            _tmux_cmd("kill-session", "-t", session),
            capture_output=True,
        )
        time.sleep(1)
        return not _tmux_has_session(workspace)


def log_path(workspace: str = None) -> str:
    """Return the agent.log path for a workspace (may not exist yet)."""
    cwd = work_dir(workspace)
    return str(Path(cwd) / ".fathom" / "agent.log")


def status(workspace: str = None) -> dict:
    execution = _get_execution_mode(workspace)
    headless = is_headless_workspace(workspace)
    result = {
        "session": session_name(workspace),
        "pane": _main_pane(workspace),
        "running": is_running(workspace),
        "execution": execution,
        "headless": headless,
    }
    result["log_path"] = log_path(workspace)
    return result
