"""Agent WebSocket connection registry — push channel from server to MCP clients.

Thread-safe registry of active WebSocket connections. Provides inject_or_push()
as a drop-in replacement for persistent_session.inject() — tries WebSocket push
first, falls back to tmux injection for local workspaces.

Also absorbs heartbeat tracking from routes/settings.py — a connected WebSocket
counts as a live heartbeat.

Supports both sync and async callers: sync threads (ping scheduler, room
injection) use asyncio.run_coroutine_threadsafe() to bridge into the event loop.
"""

import asyncio
import json
import logging
import threading
import time

log = logging.getLogger("agent-connections")

HEARTBEAT_STALE_SECONDS = 90  # 3 missed 30s intervals = stale

_lock = threading.Lock()

# {workspace: {"ws": <WebSocket>, "agent": str, "vault_mode": str, "connected_at": float, "loop": <EventLoop>}}
_connections: dict[str, dict] = {}

# {workspace: {"timestamp": float, "agent": str, "vault_mode": str | None}}
_heartbeats: dict[str, dict] = {}


# ── Connection management ────────────────────────────────────────────────────


def register(workspace: str, ws_conn, agent: str = "", vault_mode: str = "", loop=None) -> None:
    """Register a WebSocket connection for a workspace."""
    with _lock:
        old = _connections.get(workspace)
        if old and old["ws"] is not ws_conn:
            try:
                old_loop = old.get("loop")
                if old_loop:
                    asyncio.run_coroutine_threadsafe(old["ws"].close(), old_loop)
                else:
                    old["ws"].close()
            except Exception:
                pass
        _connections[workspace] = {
            "ws": ws_conn,
            "agent": agent,
            "vault_mode": vault_mode,
            "connected_at": time.time(),
            "loop": loop,
        }
        # WebSocket connection counts as heartbeat
        _heartbeats[workspace] = {
            "timestamp": time.time(),
            "agent": agent,
            "vault_mode": vault_mode,
        }
    log.info("Agent connected: workspace=%s agent=%s", workspace, agent)


def unregister(workspace: str) -> None:
    """Remove a WebSocket connection for a workspace."""
    with _lock:
        _connections.pop(workspace, None)
    log.info("Agent disconnected: workspace=%s", workspace)


def is_connected(workspace: str) -> bool:
    """Check if a workspace has an active WebSocket connection."""
    with _lock:
        return workspace in _connections


# ── Heartbeat tracking (absorbed from settings.py) ───────────────────────────


def record_heartbeat(workspace: str, agent: str = "unknown", vault_mode: str | None = None) -> None:
    """Record an HTTP heartbeat from a workspace's MCP client."""
    with _lock:
        _heartbeats[workspace] = {
            "timestamp": time.time(),
            "agent": agent,
            "vault_mode": vault_mode,
        }


def get_heartbeat(workspace: str) -> dict | None:
    """Get the most recent heartbeat for a workspace (from WS or HTTP)."""
    with _lock:
        return _heartbeats.get(workspace)


def is_heartbeat_fresh(workspace: str) -> bool:
    """Check if a workspace's heartbeat is within the staleness threshold."""
    with _lock:
        hb = _heartbeats.get(workspace)
        if hb is None:
            return False
        return (time.time() - hb["timestamp"]) < HEARTBEAT_STALE_SECONDS


def touch_heartbeat(workspace: str) -> None:
    """Update the heartbeat timestamp for a workspace (e.g. on WS pong)."""
    with _lock:
        hb = _heartbeats.get(workspace)
        if hb:
            hb["timestamp"] = time.time()
        else:
            _heartbeats[workspace] = {
                "timestamp": time.time(),
                "agent": "unknown",
                "vault_mode": None,
            }


# ── Push messaging ───────────────────────────────────────────────────────────


def send_to_agent(workspace: str, msg_type: str, payload: dict) -> bool:
    """Send a typed JSON message over WebSocket to a workspace's MCP client.

    Bridges sync callers to async WebSocket via run_coroutine_threadsafe.
    Returns True if the message was sent successfully, False otherwise.
    """
    with _lock:
        conn = _connections.get(workspace)
        if not conn:
            return False
        ws = conn["ws"]
        loop = conn.get("loop")

    msg = json.dumps({"type": msg_type, **payload})
    try:
        if loop:
            future = asyncio.run_coroutine_threadsafe(ws.send_text(msg), loop)
            future.result(timeout=5)
        else:
            ws.send(msg)
        return True
    except Exception:
        log.warning("WebSocket send failed for workspace=%s, removing connection", workspace)
        unregister(workspace)
        return False


def inject_or_push(text: str, workspace: str = None, sender: str = None) -> bool:
    """Drop-in replacement for persistent_session.inject().

    Tries WebSocket push first. If no connection or send fails, falls back
    to tmux injection via persistent_session.inject().
    Headless agents bypass WebSocket — server spawns the process directly.

    Signature matches persistent_session.inject() for compatibility.
    """
    from fathom_server.services.persistent_session import inject as ps_inject

    # Headless agents have no persistent WebSocket client — go straight to spawn
    if workspace and _is_headless(workspace):
        return ps_inject(text, workspace=workspace, sender=sender)

    if workspace and is_connected(workspace):
        payload = {"text": text}
        if sender:
            payload["sender"] = sender
        if send_to_agent(workspace, "inject", payload):
            log.debug("Pushed inject via WebSocket to workspace=%s", workspace)
            return True
        # WebSocket send failed — fall through to tmux

    # Fallback: tmux injection
    return ps_inject(text, workspace=workspace, sender=sender)


def push_ping_fire(text: str, routine_id: str, workspace: str) -> bool:
    """Push a ping routine fire to the agent, falling back to tmux inject.

    Uses the 'ping_fire' message type so the client can distinguish routine
    fires from other injections (e.g. for logging or special handling).
    Headless agents bypass WebSocket — server spawns the process directly.
    """
    from fathom_server.services.persistent_session import inject as ps_inject

    # Headless agents have no persistent WebSocket client — go straight to spawn
    if _is_headless(workspace):
        return ps_inject(text, workspace=workspace)

    if is_connected(workspace):
        payload = {"text": text, "routine_id": routine_id}
        if send_to_agent(workspace, "ping_fire", payload):
            log.debug("Pushed ping_fire via WebSocket to workspace=%s", workspace)
            return True

    return ps_inject(text, workspace=workspace)


def push_image(
    workspace: str, message_id: int, chat_id: int, data: str, mime_type: str, filename: str
) -> bool:
    """Push a telegram image to the agent for local caching.

    Returns True if pushed via WebSocket, False otherwise (agent will
    fall back to HTTP fetch on demand).
    """
    if not is_connected(workspace):
        return False

    payload = {
        "message_id": message_id,
        "chat_id": chat_id,
        "data": data,
        "mimeType": mime_type,
        "filename": filename,
    }
    return send_to_agent(workspace, "image", payload)


def shutdown() -> None:
    """Close all WebSocket connections."""
    with _lock:
        for _workspace, conn in list(_connections.items()):
            try:
                loop = conn.get("loop")
                if loop:
                    asyncio.run_coroutine_threadsafe(conn["ws"].close(), loop)
                else:
                    conn["ws"].close()
            except Exception:
                pass
        _connections.clear()


def _is_headless(workspace: str) -> bool:
    """Check if a workspace uses headless (per-invocation) execution."""
    from fathom_server.services.persistent_session import is_headless_workspace

    return is_headless_workspace(workspace)
