"""Room chat endpoints — list rooms, read messages, post messages."""

import re
import time

from fastapi import APIRouter, Depends, Query
from fastapi.responses import JSONResponse

from fathom_server.auth import fastapi_require_api_key
from fathom_server.db import get_connection
from fathom_server.services.agent_connections import inject_or_push as session_inject
from fathom_server.services.settings import load_global_settings
from fathom_server.utils import ts_to_iso as _ts_to_iso

router = APIRouter(dependencies=[Depends(fastapi_require_api_key)])


def _get_retention_days():
    """Read rooms.retention_days from global settings. Returns int or None."""
    gs = load_global_settings()
    return gs.get("rooms", {}).get("retention_days")


def _prune_expired(con, retention_days):
    """Delete messages older than retention_days. Returns count deleted."""
    if not retention_days:
        return 0
    cutoff = time.time() - (retention_days * 86400)
    cur = con.execute("DELETE FROM room_messages WHERE timestamp < ?", (cutoff,))
    con.commit()
    return cur.rowcount


def _parse_mentions(message: str) -> list[str]:
    """Extract @workspace tokens, deduplicated and lowercased."""
    matches = re.findall(r"@([\w][\w-]*)", message)
    return list(dict.fromkeys(m.lower() for m in matches))  # dedup, preserve order


def _resolve_mentions(tokens: list[str], sender: str) -> list[str]:
    """Map tokens to configured workspace names. Expands @all, filters self."""
    settings = load_global_settings()
    all_ws = list((settings.get("workspaces") or {}).keys())
    sender_lower = sender.lower()

    targets: set[str] = set()
    for token in tokens:
        if token == "all":
            targets.update(all_ws)
        else:
            match = next((ws for ws in all_ws if ws.lower() == token), None)
            if match:
                targets.add(match)

    # Filter self-mentions
    self_ws = next((ws for ws in all_ws if ws.lower() == sender_lower), sender)
    targets.discard(self_ws)
    return list(targets)


def _is_dm_room(room_name: str) -> bool:
    """Check if a room is a DM room (persistent, visible to both participants)."""
    return room_name.startswith("dm:")


def _is_mention_room(room_name: str) -> bool:
    """Check if a room is a mention notification room (consume-on-read)."""
    return room_name.startswith("mentions:")


def _is_virtual_room(room_name: str) -> bool:
    """Check if a room is a virtual room (DM or mention notification)."""
    return _is_dm_room(room_name) or _is_mention_room(room_name)


def _dm_room_name(a: str, b: str) -> str:
    """Construct sorted DM room name — ensures both parties see the same room."""
    return "dm:" + "+".join(sorted([a.lower(), b.lower()]))


def _validate_dm_participant(room_name: str, sender: str) -> bool:
    """Check if sender is a participant in a DM room. Returns True if allowed."""
    if not _is_dm_room(room_name):
        return True  # Non-DM rooms have no participant restriction
    participants = room_name[3:].split("+")
    return sender.lower() in [p.lower() for p in participants]


@router.get("/api/room/list")
def list_rooms(workspace: str = Query(None)):
    """List all rooms with message count, last activity, last sender, and description.

    Optional ?workspace= param: when provided, includes per-room unread_count
    and shows that workspace's virtual rooms (dm:{workspace}, mentions:{workspace}).
    Without workspace param, virtual rooms are excluded.
    """
    retention_days = _get_retention_days()

    # Build room filter — exclude virtual rooms not belonging to this workspace
    if workspace:
        ws = workspace.lower()
        room_filter = (
            "AND ((room NOT LIKE 'dm:%' AND room NOT LIKE 'mentions:%') "
            "OR room = ? "
            "OR room LIKE ? "
            "OR room LIKE ?)"
        )
        filter_params = [f"mentions:{ws}", f"dm:{ws}+%", f"dm:%+{ws}"]
    else:
        room_filter = "AND room NOT LIKE 'dm:%' AND room NOT LIKE 'mentions:%'"
        filter_params = []

    with get_connection() as con:
        if retention_days:
            cutoff = time.time() - (retention_days * 86400)
            rows = con.execute(
                f"""
                SELECT
                    room,
                    COUNT(*) as message_count,
                    MAX(timestamp) as last_activity,
                    (SELECT sender FROM room_messages r2
                     WHERE r2.room = r1.room AND r2.timestamp > ?
                     ORDER BY timestamp DESC LIMIT 1) as last_sender,
                    COALESCE((SELECT description FROM room_metadata m
                     WHERE m.room = r1.room), '') as description
                FROM room_messages r1
                WHERE timestamp > ? {room_filter}
                GROUP BY room
                ORDER BY last_activity DESC
            """,
                (cutoff, cutoff, *filter_params),
            ).fetchall()
        else:
            rows = con.execute(
                f"""
                SELECT
                    room,
                    COUNT(*) as message_count,
                    MAX(timestamp) as last_activity,
                    (SELECT sender FROM room_messages r2
                     WHERE r2.room = r1.room ORDER BY timestamp DESC LIMIT 1) as last_sender,
                    COALESCE((SELECT description FROM room_metadata m
                     WHERE m.room = r1.room), '') as description
                FROM room_messages r1
                WHERE 1=1 {room_filter}
                GROUP BY room
                ORDER BY last_activity DESC
            """,
                filter_params,
            ).fetchall()

        rooms = []
        for r in rows:
            entry = {
                "name": r["room"],
                "last_activity": r["last_activity"],
                "last_sender": r["last_sender"],
                "description": r["description"],
            }
            if workspace:
                # All rooms use read-state tracking (regular, DM, and mention rooms)
                unread = con.execute(
                    """
                    SELECT COUNT(*) as cnt FROM room_messages
                    WHERE room = ? AND timestamp > COALESCE(
                        (SELECT last_read_ts FROM room_read_state
                         WHERE room = ? AND workspace = ?),
                        0
                    )
                    """,
                    (r["room"], r["room"], workspace),
                ).fetchone()
                entry["unread_count"] = unread["cnt"] if unread else 0
            rooms.append(entry)

    return {"rooms": rooms}


@router.get("/api/room/{room_name}")
def read_room(
    room_name: str,
    workspace: str = Query(None),
    minutes: float = Query(None),
    hours: float = Query(None),
    start: float = Query(0),
    mark_read: str = Query("true"),
):
    """Read messages from a room within a time window anchored to the latest message."""
    ws = workspace
    # DM access control — only participants can read
    if _is_dm_room(room_name) and ws and not _validate_dm_participant(room_name, ws):
        return JSONResponse(
            {"error": f"access denied: '{ws}' is not a participant in {room_name}"}, status_code=403
        )

    # Mentions room access control — only target workspace can read
    if _is_mention_room(room_name) and ws:
        target = room_name.split(":", 1)[1]
        if ws.lower() != target.lower():
            return JSONResponse(
                {"error": f"access denied: '{ws}' cannot read {room_name}"}, status_code=403
            )

    # Parse params with backward compat
    should_mark_read = mark_read.lower() != "false"

    if minutes is not None:
        window_minutes = minutes
    elif hours is not None:
        window_minutes = hours * 60
    else:
        window_minutes = 60

    retention_days = _get_retention_days()

    with get_connection() as con:
        # Find the latest message timestamp as anchor
        row = con.execute(
            "SELECT MAX(timestamp) as latest FROM room_messages WHERE room = ?",
            (room_name,),
        ).fetchone()
        latest_ts = row["latest"] if row else None

        if latest_ts is None:
            return {
                "room": room_name,
                "messages": [],
                "count": 0,
                "window": {
                    "start": None,
                    "end": None,
                    "latest_message": None,
                    "has_older": False,
                    "retention_limited": False,
                },
            }

        # Window calculation relative to latest message
        anchor = latest_ts
        window_end = anchor - (start * 60)
        window_start = window_end - (window_minutes * 60)

        # Clamp to retention boundary
        retention_limited = False
        if retention_days:
            retention_boundary = time.time() - (retention_days * 86400)
            if window_start < retention_boundary:
                window_start = retention_boundary
                retention_limited = True

        # Query messages in window
        rows = con.execute(
            "SELECT id, sender, message, timestamp FROM room_messages "
            "WHERE room = ? AND timestamp > ? AND timestamp <= ? ORDER BY timestamp ASC",
            (room_name, window_start, window_end),
        ).fetchall()

        # Check if there are older messages before window_start
        older = con.execute(
            "SELECT 1 FROM room_messages WHERE room = ? AND timestamp <= ? LIMIT 1",
            (room_name, window_start),
        ).fetchone()
        has_older = older is not None

        # All rooms: auto-mark read when workspace is provided
        if ws and should_mark_read:
            read_ts = rows[-1]["timestamp"] if rows else time.time()
            con.execute(
                "INSERT INTO room_read_state (workspace, room, last_read_ts) VALUES (?, ?, ?) "
                "ON CONFLICT(workspace, room) DO UPDATE SET last_read_ts = excluded.last_read_ts",
                (ws, room_name, read_ts),
            )
            con.commit()

    return {
        "room": room_name,
        "messages": [
            {
                "id": r["id"],
                "sender": r["sender"],
                "message": r["message"],
                "timestamp": r["timestamp"],
                "datetime": _ts_to_iso(r["timestamp"]),
            }
            for r in rows
        ],
        "count": len(rows),
        "window": {
            "start": _ts_to_iso(window_start),
            "end": _ts_to_iso(window_end),
            "latest_message": _ts_to_iso(latest_ts),
            "has_older": has_older,
            "retention_limited": retention_limited,
        },
    }


@router.put("/api/room/{room_name}/description")
def set_room_description(room_name: str, body: dict):
    """Set or update the description/topic for a room."""
    description = body.get("description", "").strip()

    # DM access control — only participants can set description
    sender = body.get("sender", "myra")
    if _is_dm_room(room_name) and not _validate_dm_participant(room_name, sender):
        return JSONResponse(
            {"error": f"access denied: '{sender}' is not a participant in {room_name}"},
            status_code=403,
        )

    with get_connection() as con:
        con.execute(
            "INSERT INTO room_metadata (room, description) VALUES (?, ?) "
            "ON CONFLICT(room) DO UPDATE SET description = excluded.description",
            (room_name, description),
        )
        con.commit()

    return {"ok": True, "room": room_name, "description": description}


@router.post("/api/room/{room_name}/read")
def mark_room_read(room_name: str, body: dict):
    """Explicitly mark a room as read for a workspace without fetching messages."""
    workspace = body.get("workspace")
    if not workspace:
        return JSONResponse({"error": "workspace is required"}, status_code=400)

    # DM access control — only participants can mark read
    if _is_dm_room(room_name) and not _validate_dm_participant(room_name, workspace):
        return JSONResponse(
            {"error": f"access denied: '{workspace}' is not a participant in {room_name}"},
            status_code=403,
        )

    ts = time.time()
    with get_connection() as con:
        con.execute(
            "INSERT INTO room_read_state (workspace, room, last_read_ts) VALUES (?, ?, ?) "
            "ON CONFLICT(workspace, room) DO UPDATE SET last_read_ts = excluded.last_read_ts",
            (workspace, room_name, ts),
        )
        con.commit()
    return {"ok": True, "room": room_name, "workspace": workspace, "last_read_ts": ts}


@router.post("/api/send/{workspace_name}")
def send_to_workspace(workspace_name: str, body: dict):
    """Send a direct message to a workspace — stored in a shared dm:a+b room."""
    message = body.get("message", "").strip()
    if not message:
        return JSONResponse({"error": "message is required"}, status_code=400)

    sender = body.get("from", "unknown")
    room = _dm_room_name(sender, workspace_name)
    timestamp = time.time()
    with get_connection() as con:
        cur = con.execute(
            "INSERT INTO room_messages (room, sender, message, timestamp) VALUES (?, ?, ?, ?)",
            (room, sender, message, timestamp),
        )
        msg_id = cur.lastrowid

        # Notify recipient via mentions (same mechanism as @mentions)
        notification = f"[DM from {sender}] {message}"
        mention_room = f"mentions:{workspace_name}"
        con.execute(
            "INSERT INTO room_messages (room, sender, message, timestamp) VALUES (?, ?, ?, ?)",
            (mention_room, sender, notification, timestamp),
        )
        con.commit()

    # Inject into the target session (tmux send-keys or inbox file)
    inject_text = (
        f"DM from {sender}: {message}\n"
        f'(Read the conversation with fathom_room_read room="{room}" before replying '
        f"— this is one message without context.\n"
        f' Reply with: fathom_room_post room="{room}" message="...")'
    )
    injected = session_inject(inject_text, workspace=workspace_name, sender=sender)

    return {
        "ok": True,
        "id": msg_id,
        "room": room,
        "delivered": injected,
        "workspace": workspace_name,
    }


@router.post("/api/room/{room_name}")
def post_to_room(room_name: str, body: dict):
    """Post a message to a room. Supports @workspace mentions."""
    message = body.get("message", "").strip()
    if not message:
        return JSONResponse({"error": "message is required"}, status_code=400)

    sender = body.get("sender", "myra")

    # DM access control — only participants can post
    if _is_dm_room(room_name) and not _validate_dm_participant(room_name, sender):
        return JSONResponse(
            {"error": f"access denied: '{sender}' is not a participant in {room_name}"},
            status_code=403,
        )

    timestamp = time.time()

    with get_connection() as con:
        # Phase 1: Store in room
        cur = con.execute(
            "INSERT INTO room_messages (room, sender, message, timestamp) VALUES (?, ?, ?, ?)",
            (room_name, sender, message, timestamp),
        )
        msg_id = cur.lastrowid
        con.commit()

        # Prune expired messages
        retention_days = _get_retention_days()
        pruned = _prune_expired(con, retention_days)

        # Phase 2: DM rooms — notify + inject to recipient
        if room_name.startswith("dm:"):
            participants = room_name[3:].split("+")
            recipients = [p for p in participants if p != sender]
            for recipient in recipients:
                notification = f"[DM from {sender}] {message}"
                mention_room = f"mentions:{recipient}"
                con.execute(
                    "INSERT INTO room_messages (room, sender, message, timestamp) "
                    "VALUES (?, ?, ?, ?)",
                    (mention_room, sender, notification, timestamp),
                )
            con.commit()

        # Phase 3: Parse mentions and store notifications in virtual rooms
        # Skip for DM rooms — private conversations must not leak via @mentions
        if not _is_dm_room(room_name):
            tokens = _parse_mentions(message)
            targets = _resolve_mentions(tokens, sender)
        else:
            tokens, targets = [], []

        if targets:
            for ws in targets:
                notification = f"[#{room_name}] {sender}: {message}"
                mention_room = f"mentions:{ws}"
                con.execute(
                    "INSERT INTO room_messages (room, sender, message, timestamp) "
                    "VALUES (?, ?, ?, ?)",
                    (mention_room, sender, notification, timestamp),
                )
            con.commit()

    result = {
        "ok": True,
        "id": msg_id,
        "room": room_name,
        "sender": sender,
        "timestamp": timestamp,
    }
    if pruned > 0:
        result["pruned"] = pruned

    # Session injections happen outside the DB connection
    if room_name.startswith("dm:"):
        participants = room_name[3:].split("+")
        recipients = [p for p in participants if p != sender]
        for recipient in recipients:
            inject_text = (
                f"Message from workspace ({sender}): {message}\n"
                f'[Reply with: fathom_send workspace="{sender}" message="..."]'
            )
            session_inject(inject_text, workspace=recipient, sender=sender)

    if targets:
        notified = []
        for ws in targets:
            inject_text = (
                f"Room message from {sender} in #{room_name} (@{ws}): {message}\n"
                f'(Read the room with fathom_room_read room="{room_name}" before replying '
                f"— this is one message without context.)"
            )
            injected = session_inject(inject_text, workspace=ws, sender=sender)
            notified.append({"workspace": ws, "delivered": injected})
        result["mentions"] = {"parsed": tokens, "notified": notified}

    return result
