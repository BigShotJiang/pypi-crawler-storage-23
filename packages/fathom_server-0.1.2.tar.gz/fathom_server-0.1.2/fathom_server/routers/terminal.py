"""Terminal WebSocket — pty bridge for workspace-scoped fathom sessions.

FastAPI native WebSocket replacing Flask-Sock. PTY reader runs in a thread,
bridged to async WebSocket via asyncio.Queue.
"""

import asyncio
import fcntl
import json
import logging
import os
import pty
import select
import struct
import subprocess
import termios
import threading

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from fathom_server.auth import validate_token_value
from fathom_server.services.persistent_session import (
    ensure_running,
    is_headless_workspace,
    is_human_workspace,
    load_agent_entry,
    log_path,
    resolve_cmd,
    session_name,
    work_dir,
)

log = logging.getLogger("terminal-ws")

router = APIRouter()


@router.websocket("/ws/terminal")
async def terminal(websocket: WebSocket):
    token = websocket.query_params.get("token", "")
    if not validate_token_value(token):
        await websocket.accept()
        await websocket.send_text("\r\n[error: authentication required]\r\n")
        await websocket.close()
        return

    await websocket.accept()

    workspace = websocket.query_params.get("workspace")

    # Read initial dimensions from query params
    try:
        init_cols = max(1, min(500, int(websocket.query_params.get("cols", 80))))
    except (ValueError, TypeError):
        init_cols = 80
    try:
        init_rows = max(1, min(200, int(websocket.query_params.get("rows", 24))))
    except (ValueError, TypeError):
        init_rows = 24

    mode = websocket.query_params.get("mode")
    is_headless = is_headless_workspace(workspace)

    # Auto-detect log mode for headless workspaces
    if is_headless and mode != "terminal":
        mode = "log"

    tmux_session = session_name(workspace)
    if not is_headless:
        ensure_running(workspace)

    working_dir = work_dir(workspace)
    if not os.path.isdir(working_dir):
        working_dir = os.path.expanduser("~")

    env = os.environ.copy()
    env.pop("CLAUDECODE", None)
    env["TERM"] = "xterm-256color"
    env["COLORTERM"] = "truecolor"

    try:
        master_fd, slave_fd = pty.openpty()
        # Set PTY size before launching subprocess
        fcntl.ioctl(
            master_fd,
            termios.TIOCSWINSZ,
            struct.pack("HHHH", init_rows, init_cols, 0, 0),
        )

        if mode == "log":
            agent_log = log_path(workspace)
            os.makedirs(os.path.dirname(agent_log), exist_ok=True)
            if not os.path.exists(agent_log):
                open(agent_log, "a").close()  # noqa: SIM115
            formatter = os.path.join(
                os.path.dirname(os.path.dirname(__file__)),
                "scripts",
                "format-agent-log.py",
            )
            cmd = ["bash", "-c", f"tail -f {agent_log} | python3 {formatter}"]
        elif is_human_workspace(workspace):
            ensure_running(workspace)
            cmd = ["tmux", "new-session", "-A", "-s", tmux_session]
        else:
            entry = load_agent_entry(workspace)
            cmd_parts = resolve_cmd(entry.get("command", "claude --continue"))

            cmd = [
                "tmux",
                "new-session",
                "-A",
                "-s",
                tmux_session,
                *cmd_parts,
            ]

        subprocess.Popen(
            cmd,
            stdin=slave_fd,
            stdout=slave_fd,
            stderr=slave_fd,
            cwd=working_dir,
            close_fds=True,
            env=env,
        )
        os.close(slave_fd)
    except Exception as e:
        await websocket.send_text(f"\r\n[error: {e}]\r\n")
        return

    stop_event = threading.Event()
    send_queue = asyncio.Queue()
    loop = asyncio.get_event_loop()

    def pty_reader():
        while not stop_event.is_set():
            try:
                r, _, _ = select.select([master_fd], [], [], 0.1)
                if r:
                    data = os.read(master_fd, 4096)
                    if not data:
                        break
                    asyncio.run_coroutine_threadsafe(send_queue.put(data), loop)
            except OSError:
                break
        # Signal sender to stop
        asyncio.run_coroutine_threadsafe(send_queue.put(None), loop)

    reader_thread = threading.Thread(target=pty_reader, daemon=True)
    reader_thread.start()

    async def sender():
        while True:
            data = await send_queue.get()
            if data is None:
                break
            try:
                await websocket.send_bytes(data)
            except (WebSocketDisconnect, RuntimeError):
                break

    async def receiver():
        try:
            while True:
                msg = await websocket.receive()
                if msg.get("type") == "websocket.disconnect":
                    break
                if "text" in msg:
                    text = msg["text"]
                    try:
                        parsed = json.loads(text)
                        if isinstance(parsed, dict) and parsed.get("type") == "resize":
                            cols = max(1, min(500, int(parsed.get("cols", 80))))
                            rows = max(1, min(200, int(parsed.get("rows", 24))))
                            fcntl.ioctl(
                                master_fd,
                                termios.TIOCSWINSZ,
                                struct.pack("HHHH", rows, cols, 0, 0),
                            )
                            continue
                    except (json.JSONDecodeError, KeyError, ValueError):
                        pass
                    os.write(master_fd, text.encode())
                elif "bytes" in msg:
                    os.write(master_fd, msg["bytes"])
        except (WebSocketDisconnect, RuntimeError):
            pass

    try:
        done, pending = await asyncio.wait(
            [asyncio.create_task(sender()), asyncio.create_task(receiver())],
            return_when=asyncio.FIRST_COMPLETED,
        )
        for task in pending:
            task.cancel()
    finally:
        stop_event.set()
        try:
            os.close(master_fd)
        except OSError:
            pass
