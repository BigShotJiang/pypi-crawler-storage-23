"""Telegram REST API — contacts, messages, send, image serving, and bridge status."""

import base64

from fastapi import APIRouter, Depends, Query
from fastapi.responses import JSONResponse

from fathom_server.auth import fastapi_require_api_key
from fathom_server.db import get_connection
from fathom_server.paths import TELEGRAM_ASSETS_DIR
from fathom_server.services.telegram_bridge import telegram_bridge
from fathom_server.utils import ts_to_iso as _ts_to_iso

router = APIRouter(dependencies=[Depends(fastapi_require_api_key)])


@router.get("/api/telegram/contacts")
def list_contacts(workspace: str = Query(None)):
    """List known Telegram contacts from auto-discovery."""
    contacts = telegram_bridge.get_contacts()

    # Add unread counts per contact
    if workspace and contacts:
        with get_connection() as con:
            for c in contacts:
                room = f"telegram:{c['chat_id']}"
                row = con.execute(
                    """SELECT COUNT(*) as cnt FROM room_messages
                       WHERE room = ? AND timestamp > COALESCE(
                           (SELECT last_read_ts FROM room_read_state
                            WHERE room = ? AND workspace = ?),
                           0)""",
                    (room, room, workspace),
                ).fetchone()
                c["unread_count"] = row["cnt"] if row else 0

    return {"contacts": contacts}


@router.get("/api/telegram/messages/{chat_id}")
def read_messages(
    chat_id: int,
    minutes: float = Query(60),
    start: float = Query(0),
    mark_read: str = Query("true"),
    workspace: str = Query(None),
):
    """Read messages for a Telegram contact. Same windowed query as room read."""
    should_mark_read = mark_read.lower() != "false"

    room = f"telegram:{chat_id}"
    with get_connection() as con:
        # Find latest message as anchor
        row = con.execute(
            "SELECT MAX(timestamp) as latest FROM room_messages WHERE room = ?",
            (room,),
        ).fetchone()
        latest_ts = row["latest"] if row else None

        if latest_ts is None:
            return {
                "room": room,
                "chat_id": chat_id,
                "messages": [],
                "count": 0,
                "window": {
                    "start": None,
                    "end": None,
                    "latest_message": None,
                    "has_older": False,
                },
            }

        # Window calculation
        anchor = latest_ts
        window_end = anchor - (start * 60)
        window_start = window_end - (minutes * 60)

        rows = con.execute(
            "SELECT id, sender, message, timestamp, media_path FROM room_messages "
            "WHERE room = ? AND timestamp > ? AND timestamp <= ? ORDER BY timestamp ASC",
            (room, window_start, window_end),
        ).fetchall()

        older = con.execute(
            "SELECT 1 FROM room_messages WHERE room = ? AND timestamp <= ? LIMIT 1",
            (room, window_start),
        ).fetchone()
        has_older = older is not None

        # Auto-mark read
        if workspace and should_mark_read and rows:
            read_ts = rows[-1]["timestamp"]
            con.execute(
                "INSERT INTO room_read_state (workspace, room, last_read_ts) VALUES (?, ?, ?) "
                "ON CONFLICT(workspace, room) DO UPDATE SET last_read_ts = excluded.last_read_ts",
                (workspace, room, read_ts),
            )
            con.commit()

        return {
            "room": room,
            "chat_id": chat_id,
            "messages": [
                {
                    "id": r["id"],
                    "sender": r["sender"],
                    "message": r["message"],
                    "timestamp": r["timestamp"],
                    "datetime": _ts_to_iso(r["timestamp"]),
                    **({"media": True} if r["media_path"] else {}),
                }
                for r in rows
            ],
            "count": len(rows),
            "window": {
                "start": _ts_to_iso(window_start),
                "end": _ts_to_iso(window_end),
                "latest_message": _ts_to_iso(latest_ts),
                "has_older": has_older,
            },
        }


@router.post("/api/telegram/send/{chat_id}")
def send_message(chat_id: int, body: dict):
    """Send a message via the Telethon client."""
    text = (body.get("message") or "").strip()
    if not text:
        return JSONResponse({"error": "message is required"}, status_code=400)

    result = telegram_bridge.send_message(chat_id, text)
    if result.get("error"):
        return JSONResponse(result, status_code=502)

    return result


@router.post("/api/telegram/send-image/{chat_id}")
def send_image(chat_id: int, body: dict):
    """Send an image via the Telethon client."""
    file_path = (body.get("file_path") or "").strip()
    caption = (body.get("caption") or "").strip()

    if not file_path:
        return JSONResponse({"error": "file_path is required"}, status_code=400)

    result = telegram_bridge.send_image(chat_id, file_path, caption)
    if result.get("error"):
        return JSONResponse(result, status_code=502)

    return result


@router.post("/api/telegram/send-voice/{chat_id}")
def send_voice(chat_id: int, body: dict):
    """Send a voice note via the Telethon client. Requires OGG Opus format."""
    file_path = (body.get("file_path") or "").strip()
    caption = (body.get("caption") or "").strip()

    if not file_path:
        return JSONResponse({"error": "file_path is required"}, status_code=400)

    result = telegram_bridge.send_voice(chat_id, file_path, caption)
    if result.get("error"):
        return JSONResponse(result, status_code=502)

    return result


_ASSETS_DIR = TELEGRAM_ASSETS_DIR

_IMAGE_MIME = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".gif": "image/gif",
    ".webp": "image/webp",
}

_MAX_IMAGE_BYTES = 5 * 1024 * 1024  # 5MB


@router.get("/api/telegram/image/{message_id}")
def get_image(message_id: int):
    """Return a telegram message's image as base64."""
    with get_connection() as con:
        row = con.execute(
            "SELECT media_path FROM room_messages WHERE id = ?",
            (message_id,),
        ).fetchone()

    if not row or not row["media_path"]:
        return JSONResponse({"error": "No image for this message"}, status_code=404)

    filename = row["media_path"]
    filepath = _ASSETS_DIR / filename

    if not filepath.exists():
        return JSONResponse({"error": f"Image file not found: {filename}"}, status_code=404)

    # Validate path stays within assets dir
    try:
        filepath.resolve().relative_to(_ASSETS_DIR.resolve())
    except ValueError:
        return JSONResponse({"error": "Invalid path"}, status_code=400)

    if filepath.stat().st_size > _MAX_IMAGE_BYTES:
        return JSONResponse({"error": "Image too large (max 5MB)"}, status_code=413)

    ext = filepath.suffix.lower()
    mime_type = _IMAGE_MIME.get(ext, "image/jpeg")

    data = base64.b64encode(filepath.read_bytes()).decode("ascii")
    return {"data": data, "mimeType": mime_type, "filename": filename}


_MAX_FILE_BYTES = 5 * 1024 * 1024  # 5MB


@router.get("/api/telegram/file/{message_id}")
def get_file(message_id: int):
    """Return a telegram message's attached file as text content."""
    with get_connection() as con:
        row = con.execute(
            "SELECT media_path FROM room_messages WHERE id = ?",
            (message_id,),
        ).fetchone()

    if not row or not row["media_path"]:
        return JSONResponse({"error": "No file for this message"}, status_code=404)

    filename = row["media_path"]
    filepath = _ASSETS_DIR / filename

    if not filepath.exists():
        return JSONResponse({"error": f"File not found: {filename}"}, status_code=404)

    # Validate path stays within assets dir
    try:
        filepath.resolve().relative_to(_ASSETS_DIR.resolve())
    except ValueError:
        return JSONResponse({"error": "Invalid path"}, status_code=400)

    if filepath.stat().st_size > _MAX_FILE_BYTES:
        return JSONResponse({"error": "File too large (max 5MB)"}, status_code=413)

    ext = filepath.suffix.lower()

    # For text-like files, return content as text
    if ext in (
        ".txt",
        ".md",
        ".json",
        ".csv",
        ".py",
        ".js",
        ".ts",
        ".log",
        ".xml",
        ".yaml",
        ".yml",
        ".toml",
        ".ini",
        ".cfg",
        ".sh",
    ):
        try:
            content = filepath.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            content = filepath.read_text(encoding="latin-1")
        return {"content": content, "filename": filename, "type": "text"}

    # For binary files, return base64
    data = base64.b64encode(filepath.read_bytes()).decode("ascii")
    return {"data": data, "filename": filename, "type": "binary"}


@router.get("/api/telegram/status")
def bridge_status():
    """Return Telegram bridge connection status."""
    return telegram_bridge.status
