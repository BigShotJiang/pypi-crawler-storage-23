"""Agent WebSocket endpoint — push channel from server to MCP clients.

FastAPI native WebSocket replacing Flask-Sock. Clients connect, send a hello
handshake, then receive push messages (inject, ping_fire, image) from the server.
"""

import asyncio
import json
import logging

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from fathom_server.auth import validate_token_value
from fathom_server.services import agent_connections

log = logging.getLogger("agent-ws")

router = APIRouter()


@router.websocket("/ws/agent/{workspace}")
async def agent_ws(websocket: WebSocket, workspace: str):
    """WebSocket endpoint for agent push channel.

    Auth: ?token=KEY query param (same as terminal WS).
    Protocol:
      1. Client sends {"type": "hello", "agent": "...", "vault_mode": "..."}
      2. Server replies {"type": "welcome", "workspace": "<workspace>"}
      3. Server pushes messages; client sends pong keepalives.
    """
    token = websocket.query_params.get("token", "")
    if not validate_token_value(token):
        await websocket.accept()
        await websocket.send_text(
            json.dumps({"type": "error", "message": "authentication required"})
        )
        await websocket.close()
        return

    if not workspace or not workspace.strip():
        await websocket.accept()
        await websocket.send_text(json.dumps({"type": "error", "message": "workspace is required"}))
        await websocket.close()
        return

    await websocket.accept()
    log.info("Agent WebSocket connecting: workspace=%s", workspace)

    loop = asyncio.get_event_loop()

    try:
        # Wait for hello handshake (60s timeout)
        raw = await asyncio.wait_for(websocket.receive_text(), timeout=60)
        if not raw:
            log.warning("Agent WS: no hello received from workspace=%s", workspace)
            return

        try:
            hello = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            await websocket.send_text(json.dumps({"type": "error", "message": "invalid JSON"}))
            return

        if hello.get("type") != "hello":
            await websocket.send_text(
                json.dumps({"type": "error", "message": "expected hello message"})
            )
            return

        agent = hello.get("agent", "unknown")
        vault_mode = hello.get("vault_mode", "")

        # Register the connection with event loop ref for sync→async bridging
        agent_connections.register(
            workspace, websocket, agent=agent, vault_mode=vault_mode, loop=loop
        )

        # Send welcome
        await websocket.send_text(json.dumps({"type": "welcome", "workspace": workspace}))
        log.info("Agent WebSocket established: workspace=%s agent=%s", workspace, agent)

        # Receive loop — wait for pongs and keepalives
        while True:
            raw = await asyncio.wait_for(websocket.receive_text(), timeout=90)
            if raw is None:
                break

            try:
                msg = json.loads(raw)
            except (json.JSONDecodeError, TypeError):
                continue

            msg_type = msg.get("type")
            if msg_type == "pong":
                agent_connections.touch_heartbeat(workspace)
            else:
                log.debug(
                    "Agent WS unexpected message type=%s from workspace=%s", msg_type, workspace
                )

    except (WebSocketDisconnect, TimeoutError):
        log.info("Agent WebSocket closed: workspace=%s", workspace)
    except Exception:
        log.info("Agent WebSocket closed: workspace=%s", workspace)
    finally:
        agent_connections.unregister(workspace)
