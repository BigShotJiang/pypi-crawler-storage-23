"""Activation layer: Memento status, identity crystal, ping config — workspace-scoped."""

import asyncio
import json
import subprocess
import time

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import JSONResponse, StreamingResponse

from fathom_server.auth import fastapi_require_api_key, validate_token_value
from fathom_server.services.crystal_scheduler import crystal_scheduler
from fathom_server.services.crystallization import get_events, spawn
from fathom_server.services.memento import get_status
from fathom_server.services.persistent_session import status as session_status
from fathom_server.services.persistent_session import stop as session_stop
from fathom_server.services.ping_scheduler import ping_scheduler
from fathom_server.services.settings import (
    load_global_settings,
    load_routines,
    load_settings,
    new_routine_id,
    save_routines,
    save_settings,
)

router = APIRouter()
_auth = APIRouter(dependencies=[Depends(fastapi_require_api_key)])


@_auth.get("/api/activation/status")
def activation_status(workspace: str = Query(None)):
    """Memento connectivity + identity crystal status."""
    return get_status(workspace=workspace)


@_auth.post("/api/activation/crystal/spawn")
def crystal_spawn(body: dict = None, workspace: str = Query(None)):
    """Spawn a crystallization agent subprocess. Returns job_id."""
    body = body or {}
    job_id = spawn(
        additional_context=body.get("additionalContext", ""),
        workspace=workspace,
    )
    if job_id is None:
        return JSONResponse(
            {"error": "Crystallization already running or failed to start"},
            status_code=409,
        )
    return {"job_id": job_id}


@_auth.get("/api/activation/schedule")
def get_schedule():
    """Return current crystal auto-regenerate schedule."""
    return crystal_scheduler.status


@_auth.post("/api/activation/schedule")
def set_schedule(body: dict = None, workspace: str = Query(None)):
    """Configure crystal auto-regenerate schedule and persist to settings."""
    body = body or {}
    enabled = bool(body.get("enabled", False))
    interval_days = max(1, int(body.get("intervalDays", 7)))
    crystal_scheduler.configure(enabled, interval_days, workspace=workspace)
    s = load_settings(workspace)
    s["crystal_regen"] = {"enabled": enabled, "interval_days": interval_days}
    save_settings(s, workspace)
    return crystal_scheduler.status


# ── Cross-workspace aggregated view ──────────────────────────────────────────


@_auth.get("/api/activation/ping/routines/all")
def all_routines():
    """Aggregated routines across all agent workspaces for timeline view."""
    gs = load_global_settings()
    ws_names = []
    all_rs = []
    for name, entry in gs["workspaces"].items():
        if entry.get("type") == "human":
            continue
        ws_names.append(name)
        try:
            ws_status = ping_scheduler.status_for_workspace(name)
            for r in ws_status.get("routines", []):
                r["workspace"] = name
                all_rs.append(r)
        except Exception:
            pass
    return {"workspaces": sorted(ws_names), "routines": all_rs}


# ── Ping routines CRUD ────────────────────────────────────────────────────────


@_auth.get("/api/activation/ping/routines")
def list_routines(workspace: str = Query(None)):
    """List ping routines for the active workspace."""
    return ping_scheduler.status_for_workspace(workspace)


@_auth.post("/api/activation/ping/routines", status_code=201)
def create_routine(body: dict = None, workspace: str = Query(None)):
    """Create a new ping routine."""
    body = body or {}
    rid = new_routine_id()
    routine_dict = {
        "id": rid,
        "name": body.get("name", "New Routine"),
        "enabled": bool(body.get("enabled", False)),
        "interval_minutes": max(1, int(body.get("intervalMinutes", 60))),
        "single_fire": bool(body.get("singleFire", False)),
        "workspace": workspace or "fathom",
        "context_sources": body.get("contextSources", {"time": True, "scripts": [], "texts": []}),
        "schedule": body.get("schedule"),
        "conditions": body.get("conditions", []),
    }
    result = ping_scheduler.add_routine(routine_dict)

    # Persist to routines.json
    routines = load_routines()
    routines.append(routine_dict)
    save_routines(routines)

    return result


@_auth.get("/api/activation/ping/routines/{routine_id}")
def get_routine(routine_id: str, workspace: str = Query(None)):
    """Get one routine."""
    result = ping_scheduler.get_routine(routine_id, workspace=workspace)
    if result is None:
        return JSONResponse({"error": "not found"}, status_code=404)
    return result


@_auth.post("/api/activation/ping/routines/{routine_id}")
def update_routine(routine_id: str, body: dict = None, workspace: str = Query(None)):
    """Update a routine's fields."""
    body = body or {}
    kwargs = {}
    if "name" in body:
        kwargs["name"] = body["name"]
    if "enabled" in body:
        kwargs["enabled"] = bool(body["enabled"])
    if "intervalMinutes" in body:
        kwargs["interval_minutes"] = max(1, int(body["intervalMinutes"]))
    if "singleFire" in body:
        kwargs["single_fire"] = bool(body["singleFire"])
    if "contextSources" in body:
        kwargs["context_sources"] = body["contextSources"]
    if "schedule" in body:
        kwargs["schedule"] = body["schedule"]
    if "conditions" in body:
        kwargs["conditions"] = body["conditions"]

    result = ping_scheduler.configure_routine(routine_id, workspace=workspace, **kwargs)
    if result is None:
        return JSONResponse({"error": "not found"}, status_code=404)

    # Persist updated routine to routines.json
    routines = load_routines()
    for saved_r in routines:
        if saved_r["id"] == routine_id:
            if "name" in kwargs:
                saved_r["name"] = kwargs["name"]
            if "enabled" in kwargs:
                saved_r["enabled"] = kwargs["enabled"]
            if "interval_minutes" in kwargs:
                saved_r["interval_minutes"] = kwargs["interval_minutes"]
            if "single_fire" in kwargs:
                saved_r["single_fire"] = kwargs["single_fire"]
            if "context_sources" in kwargs:
                saved_r["context_sources"] = kwargs["context_sources"]
            if "schedule" in kwargs:
                saved_r["schedule"] = kwargs["schedule"]
            if "conditions" in kwargs:
                saved_r["conditions"] = kwargs["conditions"]
            saved_r["next_ping_at"] = result["next_ping_at"]
            break
    save_routines(routines)

    return result


@_auth.delete("/api/activation/ping/routines/{routine_id}")
def delete_routine(routine_id: str, workspace: str = Query(None)):
    """Delete a routine."""
    removed = ping_scheduler.remove_routine(routine_id, workspace=workspace)
    if not removed:
        return JSONResponse({"error": "not found"}, status_code=404)

    # Remove from routines.json
    routines = load_routines()
    routines = [r for r in routines if r["id"] != routine_id]
    save_routines(routines)

    return {"deleted": True}


@_auth.post("/api/activation/ping/routines/{routine_id}/now")
def fire_routine_now(routine_id: str, workspace: str = Query(None)):
    """Fire one routine immediately (non-blocking)."""
    ping_scheduler.fire_now(routine_id, workspace=workspace)
    return {"fired": True}


# ── Backward-compatible single-routine endpoints ──────────────────────────────


@_auth.get("/api/activation/ping")
def get_ping():
    """Return first routine's status (backward compat)."""
    return ping_scheduler.first_routine_status


@_auth.post("/api/activation/ping")
def set_ping(body: dict = None, workspace: str = Query(None)):
    """Update the first routine (backward compat)."""
    body = body or {}
    st = ping_scheduler.status
    routines_list = st.get("routines", [])
    if not routines_list:
        return JSONResponse({"error": "no routines"}, status_code=400)
    first_id = routines_list[0]["id"]

    kwargs = {}
    if "enabled" in body:
        kwargs["enabled"] = bool(body["enabled"])
    if "intervalMinutes" in body:
        kwargs["interval_minutes"] = max(1, int(body["intervalMinutes"]))
    if "contextSources" in body:
        kwargs["context_sources"] = body["contextSources"]

    result = ping_scheduler.configure_routine(first_id, **kwargs)

    file_routines = load_routines()
    for saved_r in file_routines:
        if saved_r["id"] == first_id:
            if "enabled" in kwargs:
                saved_r["enabled"] = kwargs["enabled"]
            if "interval_minutes" in kwargs:
                saved_r["interval_minutes"] = kwargs["interval_minutes"]
            if "context_sources" in kwargs:
                saved_r["context_sources"] = kwargs["context_sources"]
            if result:
                saved_r["next_ping_at"] = result["next_ping_at"]
            break
    save_routines(file_routines)

    return result or ping_scheduler.first_routine_status


@_auth.post("/api/activation/ping/now")
def ping_now():
    """Fire first routine immediately (backward compat)."""
    ping_scheduler.fire_now()
    return {"fired": True}


# ── Session management ────────────────────────────────────────────────────────


@_auth.get("/api/activation/session")
def get_session(workspace: str = Query(None)):
    """Return persistent session status for the active workspace."""
    return session_status(workspace=workspace)


@_auth.post("/api/activation/session/restart")
def restart_session(workspace: str = Query(None)):
    """Restart agent via fathom-mcp CLI."""
    result = subprocess.run(
        ["npx", "fathom-mcp", "restart", workspace],
        capture_output=True,
        text=True,
        timeout=30,
    )
    ok = result.returncode == 0
    return JSONResponse(
        {"restarted": ok, "output": result.stdout.strip()},
        status_code=200 if ok else 500,
    )


@_auth.post("/api/activation/session/stop")
def stop_session(workspace: str = Query(None)):
    """Kill a workspace's agent session (headless PIDs or tmux)."""
    ok = session_stop(workspace=workspace)
    return JSONResponse({"stopped": ok}, status_code=200 if ok else 500)


# ── SSE crystal stream (public — uses token query param for auth) ─────────


@router.get("/api/activation/crystal/stream/{job_id}")
async def crystal_stream(job_id: str, token: str = Query(None)):
    """SSE stream of progress events for a crystallization job.

    Uses token query param for auth (EventSource can't send custom headers).
    """
    if not validate_token_value(token or ""):
        raise HTTPException(status_code=401, detail="Invalid or missing token")

    async def generate():
        cursor = 0
        deadline = time.time() + 300  # 5 minute max
        while time.time() < deadline:
            events, status = get_events(job_id, after=cursor)
            if events is None:
                yield 'data: {"type":"error","message":"job not found"}\n\n'
                return
            for event in events:
                yield f"data: {json.dumps(event)}\n\n"
                cursor += 1
            if status in ("done", "failed"):
                return
            await asyncio.sleep(0.2)
        yield 'data: {"type":"error","message":"stream timeout"}\n\n'

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# Include authenticated routes into the public router
router.include_router(_auth)
