"""Settings API — workspace-scoped config, workspace CRUD, auth, TTS, and manual index trigger."""

import asyncio
import json
import os
import subprocess
import time

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import JSONResponse

from fathom_server.auth import (
    fastapi_require_api_key,
    get_api_key,
    is_auth_enabled,
    regenerate_api_key,
    set_auth_enabled,
)
from fathom_server.services import agent_connections
from fathom_server.services.indexer import indexer
from fathom_server.services.persistent_session import _tmux_cmd  # internal but stable
from fathom_server.services.persistent_session import stop as session_stop
from fathom_server.services.settings import (
    add_workspace,
    load_global_settings,
    load_routines,
    load_settings,
    remove_workspace,
    save_global_settings,
    save_settings,
    set_default_workspace,
)

router = APIRouter()

# Authenticated sub-router for routes requiring API key
_auth = APIRouter(dependencies=[Depends(fastapi_require_api_key)])


@_auth.get("/api/settings")
def get_settings(workspace: str = Query(None)):
    """Return merged settings for the active workspace + live indexer status."""
    settings = load_settings(workspace)
    settings["background_index"]["last_indexed"] = indexer.status["last_indexed"]

    # Mask telegram secrets in API response
    if "telegram" in settings:
        tg = settings["telegram"]
        if tg.get("session_string"):
            tg["session_string"] = "configured"
        else:
            tg["session_string"] = ""
        api_hash = tg.get("api_hash", "")
        if api_hash and len(api_hash) > 5:
            tg["api_hash"] = api_hash[:5] + "..."
    return settings


@_auth.post("/api/settings")
def update_settings(body: dict, workspace: str = Query(None)):
    """Persist settings and apply to indexer. Workspace-scoped."""
    data = body
    bi = data.get("background_index", {})
    mcp_data = data.get("mcp", {})

    if not isinstance(bi, dict):
        return JSONResponse({"error": "background_index must be an object"}, status_code=400)
    if not isinstance(mcp_data, dict):
        return JSONResponse({"error": "mcp must be an object"}, status_code=400)

    settings = load_settings(workspace)

    # --- background_index fields ---
    if "enabled" in bi:
        settings["background_index"]["enabled"] = bool(bi["enabled"])
    if "interval_minutes" in bi:
        minutes = bi["interval_minutes"]
        if not isinstance(minutes, int) or minutes < 1:
            return JSONResponse(
                {"error": "interval_minutes must be a positive integer"}, status_code=400
            )
        settings["background_index"]["interval_minutes"] = minutes
    if "excluded_dirs" in bi:
        excluded = bi["excluded_dirs"]
        if not isinstance(excluded, list) or not all(isinstance(d, str) for d in excluded):
            return JSONResponse(
                {"error": "excluded_dirs must be a list of strings"}, status_code=400
            )
        settings["background_index"]["excluded_dirs"] = excluded

    # --- mcp fields ---
    if "query_timeout_seconds" in mcp_data:
        timeout = mcp_data["query_timeout_seconds"]
        if not isinstance(timeout, int) or not (10 <= timeout <= 300):
            return JSONResponse(
                {"error": "query_timeout_seconds must be an integer between 10 and 300"},
                status_code=400,
            )
        settings["mcp"]["query_timeout_seconds"] = timeout
    if "search_results" in mcp_data:
        results = mcp_data["search_results"]
        if not isinstance(results, int) or not (1 <= results <= 100):
            return JSONResponse(
                {"error": "search_results must be an integer between 1 and 100"}, status_code=400
            )
        settings["mcp"]["search_results"] = results
    if "search_mode" in mcp_data:
        mode = mcp_data["search_mode"]
        if mode not in ("hybrid", "keyword"):
            return JSONResponse(
                {"error": 'search_mode must be "hybrid" or "keyword"'}, status_code=400
            )
        settings["mcp"]["search_mode"] = mode

    # --- activity fields ---
    if "activity" in data:
        act = data["activity"]
        if not isinstance(act, dict):
            return JSONResponse({"error": "activity must be an object"}, status_code=400)
        act_settings = settings.get("activity", {})
        if "decay_halflife_days" in act:
            v = act["decay_halflife_days"]
            if not isinstance(v, int | float) or v <= 0:
                return JSONResponse(
                    {"error": "decay_halflife_days must be a positive number"}, status_code=400
                )
            act_settings["decay_halflife_days"] = float(v)
        if "recency_window_hours" in act:
            v = act["recency_window_hours"]
            if not isinstance(v, int | float) or v <= 0:
                return JSONResponse(
                    {"error": "recency_window_hours must be a positive number"}, status_code=400
                )
            act_settings["recency_window_hours"] = float(v)
        if "max_access_boost" in act:
            v = act["max_access_boost"]
            if not isinstance(v, int | float) or v <= 0:
                return JSONResponse(
                    {"error": "max_access_boost must be a positive number"}, status_code=400
                )
            act_settings["max_access_boost"] = float(v)
        if "activity_sort_default" in act:
            act_settings["activity_sort_default"] = bool(act["activity_sort_default"])
        if "show_heat_indicator" in act:
            act_settings["show_heat_indicator"] = bool(act["show_heat_indicator"])
        if "excluded_from_scoring" in act:
            ex = act["excluded_from_scoring"]
            if not isinstance(ex, list) or not all(isinstance(d, str) for d in ex):
                return JSONResponse(
                    {"error": "excluded_from_scoring must be a list of strings"}, status_code=400
                )
            act_settings["excluded_from_scoring"] = ex
        settings["activity"] = act_settings

    # --- rooms fields (global) ---
    if "rooms" in data:
        rooms = data["rooms"]
        if not isinstance(rooms, dict):
            return JSONResponse({"error": "rooms must be an object"}, status_code=400)
        rooms_settings = settings.get("rooms", {})
        if "retention_days" in rooms:
            rd = rooms["retention_days"]
            if rd is not None and (
                not isinstance(rd, int) or isinstance(rd, bool) or not (1 <= rd <= 60)
            ):
                return JSONResponse(
                    {
                        "error": "retention_days must be an integer between 1 and 60, or null for unlimited"
                    },
                    status_code=400,
                )
            rooms_settings["retention_days"] = rd
        settings["rooms"] = rooms_settings

    # --- workspace fields (global) ---
    if "workspaces" in data:
        ws = data["workspaces"]
        if not isinstance(ws, dict):
            return JSONResponse({"error": "workspaces must be an object"}, status_code=400)
        for k, v in ws.items():
            if not isinstance(k, str):
                return JSONResponse({"error": "workspace keys must be strings"}, status_code=400)
            if not isinstance(v, str | dict):
                return JSONResponse(
                    {
                        "error": "workspace values must be path strings or {path, vault, description} objects"
                    },
                    status_code=400,
                )
        settings["workspaces"] = ws
    if "default_workspace" in data:
        dw = data["default_workspace"]
        if not isinstance(dw, str):
            return JSONResponse({"error": "default_workspace must be a string"}, status_code=400)
        ws = settings.get("workspaces", {})
        if dw not in ws:
            return JSONResponse(
                {"error": f'default_workspace "{dw}" not in workspaces'}, status_code=400
            )
        settings["default_workspace"] = dw

    # --- telegram fields (global) ---
    if "telegram" in data:
        tg = data["telegram"]
        if not isinstance(tg, dict):
            return JSONResponse({"error": "telegram must be an object"}, status_code=400)
        tg_settings = settings.get("telegram", {})
        if "enabled" in tg:
            tg_settings["enabled"] = bool(tg["enabled"])
        if "api_id" in tg:
            api_id = tg["api_id"]
            if not isinstance(api_id, int) or isinstance(api_id, bool):
                return JSONResponse({"error": "api_id must be an integer"}, status_code=400)
            tg_settings["api_id"] = api_id
        if "api_hash" in tg:
            api_hash = tg["api_hash"]
            if not isinstance(api_hash, str):
                return JSONResponse({"error": "api_hash must be a string"}, status_code=400)
            tg_settings["api_hash"] = api_hash
        if "session_string" in tg:
            ss = tg["session_string"]
            if not isinstance(ss, str):
                return JSONResponse({"error": "session_string must be a string"}, status_code=400)
            tg_settings["session_string"] = ss
        settings["telegram"] = tg_settings

    # --- tts fields (global) ---
    if "tts" in data:
        tts = data["tts"]
        if not isinstance(tts, dict):
            return JSONResponse({"error": "tts must be an object"}, status_code=400)
        tts_settings = settings.get("tts", {})
        if "preload" in tts:
            tts_settings["preload"] = bool(tts["preload"])
        settings["tts"] = tts_settings

    save_settings(settings, workspace)
    indexer.configure(
        settings["background_index"]["enabled"],
        settings["background_index"]["interval_minutes"],
        settings["background_index"]["excluded_dirs"],
    )

    # Reconfigure TTS bridge if tts settings changed
    if "tts" in data:
        from fathom_server.services.tts_bridge import tts_bridge

        tts_cfg = settings.get("tts", {})
        tts_bridge.configure(enabled=tts_cfg.get("preload", False))
        if tts_cfg.get("preload"):
            tts_bridge.start()
        else:
            tts_bridge.stop()

    # Reconfigure telegram bridge if telegram settings changed
    if "telegram" in data:
        from fathom_server.services.telegram_bridge import telegram_bridge

        tg_cfg = settings.get("telegram", {})
        telegram_bridge.configure(
            api_id=tg_cfg.get("api_id", 0),
            api_hash=tg_cfg.get("api_hash", ""),
            session_string=tg_cfg.get("session_string", ""),
            primary_agent=settings.get("default_workspace", ""),
            enabled=tg_cfg.get("enabled", False),
        )
        # Start if newly enabled (idempotent — start() checks if already running)
        telegram_bridge.start()

    settings["background_index"]["last_indexed"] = indexer.status["last_indexed"]
    return settings


@_auth.get("/api/tts/status")
def tts_status():
    """Return TTS bridge status."""
    from fathom_server.services.tts_bridge import tts_bridge

    return tts_bridge.status


@_auth.post("/api/tts/speak")
async def tts_speak(request: Request):
    """Synthesize speech via the Kokoro bridge. Proxies to the Unix socket."""
    import socket as stdlib_socket
    from pathlib import Path

    from fathom_server.services.tts_bridge import SOCKET_PATH, tts_bridge

    data = await request.json()
    text = data.get("text", "")
    file_path = data.get("file")
    speed = data.get("speed", 1.0)
    play = data.get("play", False)

    if file_path:
        try:
            text = Path(file_path).read_text().strip()
        except Exception as e:
            return JSONResponse({"error": f"Cannot read file: {e}"}, status_code=400)
    if not text:
        return JSONResponse({"error": "No text provided"}, status_code=400)

    output = f"/tmp/fathom-tts-{int(time.time() * 1000)}.wav"

    # Ensure bridge is running
    if not tts_bridge.is_ready:
        tts_bridge.configure(enabled=True)
        tts_bridge.start()
        for _ in range(50):
            await asyncio.sleep(0.2)
            if tts_bridge.is_ready:
                break
        if not tts_bridge.is_ready:
            return JSONResponse({"error": "TTS bridge failed to start"}, status_code=503)

    # Send to bridge via Unix socket
    req_payload = json.dumps({"text": text, "output": output, "speed": speed, "play": play}) + "\n"
    sock = stdlib_socket.socket(stdlib_socket.AF_UNIX, stdlib_socket.SOCK_STREAM)
    try:
        sock.settimeout(300)
        sock.connect(SOCKET_PATH)
        sock.sendall(req_payload.encode("utf-8"))
        sock.shutdown(stdlib_socket.SHUT_WR)

        response_data = b""
        while True:
            chunk = sock.recv(65536)
            if not chunk:
                break
            response_data += chunk

        result = json.loads(response_data.decode("utf-8").strip())
        if result.get("error"):
            return JSONResponse(result, status_code=500)

        # Convert to OGG Opus if requested (for Telegram voice notes)
        if data.get("format") == "ogg" and result.get("file"):
            ogg_path = result["file"].rsplit(".", 1)[0] + ".ogg"
            try:
                subprocess.run(
                    [
                        "ffmpeg",
                        "-y",
                        "-i",
                        result["file"],
                        "-c:a",
                        "libopus",
                        "-b:a",
                        "64k",
                        ogg_path,
                    ],
                    capture_output=True,
                    timeout=30,
                    check=True,
                )
                result["ogg_file"] = ogg_path
            except Exception as e:
                result["ogg_error"] = str(e)

        return result
    except Exception as e:
        return JSONResponse({"error": f"TTS bridge error: {e}"}, status_code=500)
    finally:
        sock.close()


@_auth.post("/api/settings/index-now")
def index_now():
    """Trigger an immediate background index run."""
    indexer.run_now()
    return {"ok": True}


# --- Workspace profiles ---


@_auth.get("/api/workspaces/profiles")
def workspace_profiles():
    """Return profile + live status for every workspace."""
    gs = load_global_settings()
    profiles = {}
    all_routines = load_routines()

    for ws_name, ws_entry in gs["workspaces"].items():
        ws_type = ws_entry.get("type", "local")
        default_exec = "none" if ws_type == "human" else "local"
        execution = ws_entry.get("execution", default_exec)

        # WebSocket connection status (primary signal)
        ws_connected = agent_connections.is_connected(ws_name)

        # Heartbeat status (kept for backward compat / debugging)
        hb = agent_connections.get_heartbeat(ws_name)
        hb_running = agent_connections.is_heartbeat_fresh(ws_name)
        last_heartbeat = hb["timestamp"] if hb else None

        # tmux status (only relevant for local execution)
        tmux_running = False
        if execution == "local":
            tmux_session = f"{ws_name}_fathom-session"
            try:
                result = subprocess.run(
                    _tmux_cmd("has-session", "-t", tmux_session),
                    capture_output=True,
                    timeout=2,
                )
                tmux_running = result.returncode == 0
            except (subprocess.TimeoutExpired, FileNotFoundError):
                tmux_running = False

        # Determine overall running status by execution mode
        if execution == "local":
            running = tmux_running and ws_connected
        elif execution == "remote":
            running = ws_connected
        else:
            running = False

        # Extract last_ping_at from the first routine for this workspace
        last_ping = None
        for _r in all_routines:
            if _r.get("workspace") == ws_name:
                last_ping = _r.get("last_ping_at")
                break

        profile = {
            "agents": ws_entry.get("agents", []),
            "running": running,
            "tmux": tmux_running,
            "connected": ws_connected,
            "heartbeat": hb_running,
            "last_ping": last_ping,
            "vault": ws_entry.get("vault", "vault"),
            "description": ws_entry.get("description", ""),
            "type": ws_type,
            "execution": execution,
        }
        if last_heartbeat is not None:
            profile["last_heartbeat"] = last_heartbeat
        profiles[ws_name] = profile

    return {"profiles": profiles}


# --- Heartbeat ---


@_auth.post("/api/workspaces/{name}/heartbeat")
def workspace_heartbeat(name: str, body: dict):
    """Record a heartbeat from a remote workspace's MCP client."""
    agent_connections.record_heartbeat(
        name,
        agent=body.get("agent", "unknown"),
        vault_mode=body.get("vault_mode"),
    )
    return {"ok": True}


# --- Workspace CRUD endpoints ---


@_auth.post("/api/workspaces")
def create_workspace(body: dict):
    """Add a workspace. Body: {"name": "...", "path": "...", "vault": "...", "description": "..."}."""
    name = body.get("name", "").strip()
    # Accept both "path" (new) and "vault_path" (legacy) field names
    project_path = body.get("path", "").strip() or body.get("vault_path", "").strip()
    vault = body.get("vault", "").strip() or "vault"
    description = body.get("description", "").strip()
    agents = body.get("agents", [])
    ws_type = body.get("type", "local").strip()

    # Validate agents array
    if agents and (not isinstance(agents, list) or not all(isinstance(a, str) for a in agents)):
        return JSONResponse({"error": "agents must be a list of strings"}, status_code=400)

    # Security: strip execution: "local" from API requests — admin privilege only
    execution = body.get("execution")
    if execution == "local":
        execution = "remote"  # downgrade to safe default

    ok, err = add_workspace(
        name,
        project_path,
        vault=vault,
        description=description,
        agents=agents,
        type=ws_type,
        execution=execution,
    )
    if not ok:
        return JSONResponse({"error": err}, status_code=400)
    return {"ok": True, "workspace": name}


@_auth.delete("/api/workspaces/{name}")
def delete_workspace(name: str):
    """Remove a workspace by name."""
    ok, err = remove_workspace(name)
    if not ok:
        return JSONResponse({"error": err}, status_code=400)
    return {"ok": True}


@_auth.post("/api/workspaces/default")
def update_default_workspace(body: dict):
    """Set the default workspace. Body: {"name": "..."}."""
    name = body.get("name", "").strip()

    ok, err = set_default_workspace(name)
    if not ok:
        return JSONResponse({"error": err}, status_code=400)
    return {"ok": True, "default_workspace": name}


@_auth.patch("/api/workspaces/{name}/execution")
def update_workspace_execution(name: str, body: dict):
    """Admin-only: grant or revoke local execution for a workspace."""
    from fathom_server.services.persistent_session import ensure_running as session_ensure

    execution = body.get("execution", "").strip()
    ws_path = body.get("path", "").strip()

    if execution not in ("local", "remote", "none"):
        return JSONResponse(
            {"error": 'execution must be "local", "remote", or "none"'}, status_code=400
        )

    gs = load_global_settings()
    ws_entry = gs["workspaces"].get(name)
    if not ws_entry:
        return JSONResponse({"error": f'Workspace "{name}" not found'}, status_code=404)

    old_execution = ws_entry.get("execution", "local")

    if execution == "local":
        if not ws_path:
            return JSONResponse({"error": "path is required for local execution"}, status_code=400)
        if not os.path.isdir(ws_path):
            return JSONResponse({"error": f"Path does not exist: {ws_path}"}, status_code=400)
        ws_entry["execution"] = "local"
        ws_entry["path"] = ws_path
    else:
        ws_entry["execution"] = execution

    gs["workspaces"][name] = ws_entry
    save_global_settings(gs)

    # If revoking local execution, kill the running tmux session
    if old_execution == "local" and execution != "local":
        session_stop(name)

    # If granting local execution, launch the tmux session
    launched = False
    if execution == "local":
        import threading

        def _launch():
            session_ensure(name)

        threading.Thread(target=_launch, daemon=True).start()
        launched = True

    return {
        "ok": True,
        "workspace": name,
        "execution": execution,
        "path": ws_entry.get("path", ""),
        "session_launched": launched,
    }


# --- Auth / API key management ---


@router.get("/api/auth/status")
def auth_status(request: Request):
    """Return current auth config. Masked key only included when authenticated."""
    auth_enabled = is_auth_enabled()
    result = {"auth_enabled": auth_enabled}

    # Only include masked key if the caller is authenticated
    authenticated = not auth_enabled
    if auth_enabled:
        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            import secrets as _secrets

            authenticated = _secrets.compare_digest(auth_header[7:], get_api_key())

    if authenticated:
        key = get_api_key()
        result["api_key_masked"] = key[:7] + "..." + key[-4:] if len(key) > 11 else key

    return result


@_auth.get("/api/auth/key")
def auth_key():
    """Return the full API key — requires authentication."""
    return {"api_key": get_api_key()}


@_auth.post("/api/auth/key/regenerate")
def auth_key_regenerate():
    """Generate a new API key, invalidating the old one."""
    new_key = regenerate_api_key()
    return {"api_key": new_key}


@_auth.post("/api/auth/toggle")
def auth_toggle(body: dict):
    """Enable or disable API key auth. Body: {"enabled": true|false}."""
    enabled = body.get("enabled")
    if not isinstance(enabled, bool):
        return JSONResponse({"error": "enabled must be a boolean"}, status_code=400)
    set_auth_enabled(enabled)
    return {"auth_enabled": enabled}


# Include authenticated routes
router.include_router(_auth)
