"""Vault browser endpoints: tree, folder listing, file read/write, raw image serving, search."""

import glob
import os
import re
import subprocess
from datetime import datetime

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import FileResponse, JSONResponse

from fathom_server.auth import fastapi_require_api_key
from fathom_server.config import (
    IMAGE_EXTENSIONS,
    get_vault_dir_for_dashboard,
    get_vault_storage_path,
)
from fathom_server.services.access import get_activity_scores, get_scores_for_paths, record_access
from fathom_server.services.links import find_file, get_file_links
from fathom_server.services.settings import load_settings
from fathom_server.services.vault import append_file, list_folder, read_file, write_file

router = APIRouter(dependencies=[Depends(fastapi_require_api_key)])


def _resolve_workspace(request: Request):
    """Resolve workspace from ?workspace query param, respecting vault mode.

    Returns (vault_dir, workspace_name, error_response).
    error_response is a JSONResponse if there's an error, None otherwise.
    """
    workspace = request.query_params.get("workspace")
    from fathom_server.config import get_default_workspace

    ws_name = workspace or get_default_workspace() or "fathom"
    vault_dir, err = get_vault_dir_for_dashboard(workspace)
    if err:
        status = 404 if err.get("vault_mode") == "none" else 400
        return None, ws_name, JSONResponse(err, status_code=status)
    return vault_dir, ws_name, None


def _scan_tree(path: str, prefix: str = "") -> list[dict]:
    """Recursively scan vault directory for folder tree."""
    items = []
    try:
        for entry in os.scandir(path):
            if entry.is_dir() and not entry.name.startswith("."):
                rel_path = os.path.join(prefix, entry.name) if prefix else entry.name
                md_files = glob.glob(os.path.join(entry.path, "*.md"))
                image_files = []
                for ext in IMAGE_EXTENSIONS:
                    image_files.extend(glob.glob(os.path.join(entry.path, f"*{ext}")))
                all_files = md_files + image_files
                mtime = max((os.path.getmtime(f) for f in all_files), default=0)
                children = _scan_tree(entry.path, rel_path)
                items.append(
                    {
                        "name": entry.name,
                        "path": rel_path,
                        "file_count": len(md_files),
                        "image_count": len(image_files),
                        "last_modified": (
                            datetime.fromtimestamp(mtime).isoformat() if mtime else None
                        ),
                        "children": children,
                    }
                )
    except (PermissionError, FileNotFoundError):
        pass
    return sorted(items, key=lambda x: x["name"])


@router.get("/api/vault")
def vault_tree(request: Request):
    """Folder tree — recursive, md + image counts."""
    vault_dir, ws_name, err_resp = _resolve_workspace(request)
    if err_resp:
        return err_resp

    try:
        root_md = glob.glob(os.path.join(vault_dir, "*.md"))
        root_img = []
        for ext in IMAGE_EXTENSIONS:
            root_img.extend(glob.glob(os.path.join(vault_dir, f"*{ext}")))

        tree = _scan_tree(vault_dir)

        if root_md or root_img:
            all_root = root_md + root_img
            mtime = max((os.path.getmtime(f) for f in all_root), default=0)
            tree.insert(
                0,
                {
                    "name": "(root)",
                    "path": "",
                    "file_count": len(root_md),
                    "image_count": len(root_img),
                    "last_modified": (datetime.fromtimestamp(mtime).isoformat() if mtime else None),
                    "children": [],
                },
            )

        return tree
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


@router.get("/api/vault/folder/{folder_path:path}")
@router.get("/api/vault/folder/")
def vault_folder(request: Request, folder_path: str = ""):
    """Files in a folder (title, date, tags, preview, activity scores). Supports nested paths."""
    vault_dir, ws_name, err_resp = _resolve_workspace(request)
    if err_resp:
        return err_resp

    result = list_folder(folder_path, vault_dir=vault_dir)
    if "error" in result:
        code = 404 if result["error"] in ("Folder not found",) else 400
        return JSONResponse(result, status_code=code)

    # Enrich markdown files with activity scores
    files = result.get("files", [])
    md_paths = [
        (folder_path + "/" + f["name"] if folder_path else f["name"])
        for f in files
        if f.get("type") == "markdown"
    ]
    if md_paths:
        scores = get_scores_for_paths(md_paths, workspace=ws_name)
        for f in files:
            if f.get("type") == "markdown":
                rel = folder_path + "/" + f["name"] if folder_path else f["name"]
                entry = scores.get(rel, {})
                f["activity_score"] = entry.get("score", 0.0)
                f["open_count"] = entry.get("open_count", 0)
                f["last_opened"] = entry.get("last_opened")
    result["files"] = files
    return result


@router.get("/api/vault/file/{rel_path:path}")
def vault_file_get(rel_path: str, request: Request):
    """File content + parsed frontmatter."""
    vault_dir, ws_name, err_resp = _resolve_workspace(request)
    if err_resp:
        return err_resp

    result = read_file(rel_path, vault_dir=vault_dir)
    if "error" in result:
        code = 404 if result["error"] == "File not found" else 400
        return JSONResponse(result, status_code=code)
    return result


@router.post("/api/vault/file/{rel_path:path}")
def vault_file_post(rel_path: str):
    """Vault writes disabled from dashboard — agents own writes via MCP."""
    return JSONResponse({"error": "Vault writes disabled from dashboard"}, status_code=405)


@router.post("/api/vault/append/{rel_path:path}")
def vault_append(rel_path: str):
    """Vault appends disabled from dashboard — agents own writes via MCP."""
    return JSONResponse({"error": "Vault appends disabled from dashboard"}, status_code=405)


@router.get("/api/vault/links/{rel_path:path}")
def vault_links(rel_path: str, request: Request):
    """Forward links and backlinks for a vault file (V-3/V-6)."""
    vault_dir, ws_name, err_resp = _resolve_workspace(request)
    if err_resp:
        return err_resp

    result = get_file_links(rel_path, vault_dir=vault_dir)
    return result


@router.get("/api/vault/resolve")
def vault_resolve(request: Request, name: str = Query("")):
    """Resolve a wikilink name to its full relative path (V-5)."""
    vault_dir, ws_name, err_resp = _resolve_workspace(request)
    if err_resp:
        return err_resp

    name = name.strip()
    if not name:
        return JSONResponse({"error": "name parameter required"}, status_code=400)
    path = find_file(name, vault_dir=vault_dir)
    if path:
        return {"path": path}
    return JSONResponse({"error": f"Not found: {name}"}, status_code=404)


@router.get("/api/vault/raw/{rel_path:path}")
def vault_raw(rel_path: str, request: Request):
    """Serve raw file (images). Validates path stays within vault dir."""
    vault_dir, ws_name, err_resp = _resolve_workspace(request)
    if err_resp:
        return err_resp

    abs_path = os.path.realpath(os.path.join(vault_dir, rel_path))
    vault_real = os.path.realpath(vault_dir)
    if abs_path != vault_real and not abs_path.startswith(vault_real + os.sep):
        return JSONResponse({"error": "Invalid path"}, status_code=403)
    if not os.path.isfile(abs_path):
        return JSONResponse({"error": "File not found"}, status_code=404)

    return FileResponse(abs_path)


# --- Access tracking ---


@router.post("/api/vault/access")
def vault_record_access(request: Request, body: dict):
    """Record a file open event.  Body: {"path": "relative/path.md"}."""
    vault_dir, ws_name, err_resp = _resolve_workspace(request)
    if err_resp:
        return err_resp

    path = body.get("path", "").strip()
    if not path:
        return JSONResponse({"error": "path is required"}, status_code=400)
    # Validate the path stays within vault dir
    abs_path = os.path.realpath(os.path.join(vault_dir, path))
    vault_real = os.path.realpath(vault_dir)
    if abs_path != vault_real and not abs_path.startswith(vault_real + os.sep):
        return JSONResponse({"error": "Invalid path"}, status_code=400)
    record_access(path, workspace=ws_name)
    return {"ok": True}


@router.get("/api/vault/activity")
def vault_activity(
    request: Request,
    limit: str = Query("20"),
    folder: str = Query(""),
):
    """Return files sorted by activity score."""
    vault_dir, ws_name, err_resp = _resolve_workspace(request)
    if err_resp:
        return err_resp

    try:
        limit = int(limit)
    except (ValueError, TypeError):
        limit = 20

    settings = load_settings(ws_name)
    activity_cfg = settings.get("activity", {})
    half_life = float(activity_cfg.get("decay_halflife_days", 7))
    recency_window = float(activity_cfg.get("recency_window_hours", 48))
    max_boost = float(activity_cfg.get("max_access_boost", 2.0))
    excluded_folders = activity_cfg.get("excluded_from_scoring", ["daily"])

    folder = folder.strip()

    files = get_activity_scores(
        limit=limit * 3,  # fetch extra so we can filter and still hit the limit
        workspace=ws_name,
        half_life_days=half_life,
        recency_window_hours=recency_window,
        max_boost=max_boost,
    )

    # Filter by folder prefix if requested
    if folder:
        folder_prefix = folder.rstrip("/") + "/"
        files = [f for f in files if f["path"].startswith(folder_prefix)]

    # Filter excluded folders
    if excluded_folders:

        def _not_excluded(entry):
            for ex in excluded_folders:
                ex = ex.strip().rstrip("/")
                if not ex:
                    continue
                if entry["path"] == ex or entry["path"].startswith(ex + "/"):
                    return False
            return True

        files = list(filter(_not_excluded, files))

    return {"files": files[:limit]}


# --- Search ---

# Pattern: "qmd://collection/path/file.md:line #color"
_QMD_HEADER_RE = re.compile(r"^qmd://[^/]+/(.+?):\d+\s+#[0-9a-f]+$")
_TITLE_RE = re.compile(r"^Title:\s+(.+)$")
_SCORE_RE = re.compile(r"^Score:\s+(\d+)%$")
_CONTEXT_RE = re.compile(r"^@@\s+")


def _parse_qmd_query_output(output: str) -> list[dict]:
    """Parse qmd query/search rich output into structured results."""
    results = []
    current = None

    for line in output.splitlines():
        header_match = _QMD_HEADER_RE.match(line)
        if header_match:
            if current:
                current["excerpt"] = current["excerpt"].strip()
                results.append(current)
            current = {
                "file": header_match.group(1),
                "title": "",
                "score": 0,
                "excerpt": "",
            }
            continue

        if current is None:
            continue

        title_match = _TITLE_RE.match(line)
        if title_match:
            current["title"] = title_match.group(1)
            continue

        score_match = _SCORE_RE.match(line)
        if score_match:
            current["score"] = int(score_match.group(1))
            continue

        if _CONTEXT_RE.match(line):
            continue

        if line.strip():
            current["excerpt"] += line + " "

    if current:
        current["excerpt"] = current["excerpt"].strip()
        results.append(current)

    return results


@router.get("/api/vault/search")
def vault_search(
    request: Request,
    q: str = Query(""),
    n: int = Query(None),
    mode: str = Query(None),
    timeout: int = Query(None),
    workspace: str = Query(None),
):
    """Full-text search via qmd."""
    vault_dir, ws_name, err_resp = _resolve_workspace(request)
    if err_resp:
        return err_resp

    q = q.strip()
    if not q:
        return {"results": [], "excluded": 0}

    settings = load_settings(ws_name)
    mcp = settings["mcp"]
    excluded_dirs = settings["background_index"].get("excluded_dirs", [])

    # Resolve params: query params override settings
    n_val = n if n is not None else mcp["search_results"]
    mode_val = mode if mode in ("hybrid", "keyword") else mcp["search_mode"]
    timeout_val = timeout if timeout is not None else mcp["query_timeout_seconds"]

    # "keyword" mode uses qmd search (BM25 only); "hybrid" uses qmd query (BM25 + vector)
    if mode_val == "keyword":
        cmd = ["qmd", "search", q, "-n", str(n_val)]
    else:
        cmd = ["qmd", "query", q, "-n", str(n_val)]

    # Scope search to workspace collection if a specific workspace was requested
    if workspace:
        cmd.extend(["-c", workspace])

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout_val,
        )
        parsed = _parse_qmd_query_output(result.stdout)

        # Post-filter: remove results whose path starts with any excluded dir
        if excluded_dirs:
            before = len(parsed)
            parsed = [
                r
                for r in parsed
                if not any(
                    r["file"] == ex.rstrip("/") or r["file"].startswith(ex.rstrip("/") + "/")
                    for ex in excluded_dirs
                )
            ]
            excluded_count = before - len(parsed)
        else:
            excluded_count = 0

        return {"results": parsed, "excluded": excluded_count}
    except subprocess.TimeoutExpired:
        return JSONResponse({"error": "Search timed out"}, status_code=504)
    except FileNotFoundError:
        return JSONResponse({"error": "qmd not found on PATH"}, status_code=500)


@router.get("/api/search")
def unified_search(
    request: Request,
    q: str = Query(""),
    mode: str = Query("hybrid"),
    n: int = Query(None),
    timeout: int = Query(None),
    workspace: str = Query(None),
):
    """Unified search endpoint — delegates to qmd with mode param."""
    vault_dir, ws_name, err_resp = _resolve_workspace(request)
    if err_resp:
        return err_resp

    q = q.strip()
    if not q:
        return {"results": [], "query": "", "mode": "", "workspace": ws_name}

    if mode not in ("bm25", "vector", "hybrid"):
        return JSONResponse(
            {"error": 'mode must be "bm25", "vector", or "hybrid"'}, status_code=400
        )

    settings = load_settings(ws_name)
    mcp = settings["mcp"]
    excluded_dirs = settings["background_index"].get("excluded_dirs", [])

    n_val = n if n is not None else mcp["search_results"]
    timeout_val = timeout if timeout is not None else mcp["query_timeout_seconds"]

    # Map mode to qmd subcommand
    mode_to_cmd = {"bm25": "search", "vector": "vsearch", "hybrid": "query"}
    collection = workspace or ws_name
    cmd = ["qmd", mode_to_cmd[mode], q, "-n", str(n_val), "-c", collection]

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout_val,
        )
        parsed = _parse_qmd_query_output(result.stdout)

        if excluded_dirs:
            before = len(parsed)
            parsed = [
                r
                for r in parsed
                if not any(
                    r["file"] == ex.rstrip("/") or r["file"].startswith(ex.rstrip("/") + "/")
                    for ex in excluded_dirs
                )
            ]
            excluded_count = before - len(parsed)
        else:
            excluded_count = 0

        return {
            "results": parsed,
            "excluded": excluded_count,
            "query": q,
            "mode": mode,
            "workspace": collection,
        }
    except subprocess.TimeoutExpired:
        return JSONResponse({"error": "Search timed out"}, status_code=504)
    except FileNotFoundError:
        return JSONResponse({"error": "qmd not found on PATH"}, status_code=500)


# --- Hosted vault storage (server-side CRUD) ----------------------------------


def _validate_workspace_name(workspace: str) -> str | None:
    """Validate workspace name to prevent path traversal. Returns error or None."""
    if not workspace or not isinstance(workspace, str):
        return "workspace name is required"
    if ".." in workspace or "/" in workspace or "\\" in workspace:
        return "Invalid workspace name"
    if workspace.startswith("."):
        return "Invalid workspace name"
    return None


@router.get("/api/vault/{workspace}/files")
def hosted_vault_list(workspace: str):
    """List all files in a workspace's server-stored vault."""
    err = _validate_workspace_name(workspace)
    if err:
        return JSONResponse({"error": err}, status_code=400)

    vault_dir = get_vault_storage_path(workspace)
    if not os.path.isdir(vault_dir):
        return {"files": []}

    files = []
    for root, _dirs, filenames in os.walk(vault_dir):
        for fname in filenames:
            if not fname.endswith(".md"):
                continue
            abs_path = os.path.join(root, fname)
            rel_path = os.path.relpath(abs_path, vault_dir)
            try:
                stat = os.stat(abs_path)
                with open(abs_path) as f:
                    content = f.read()
                from fathom_server.services.vault import parse_frontmatter

                fm, body = parse_frontmatter(content)
                preview = ""
                for line in body.splitlines():
                    stripped = line.strip()
                    if stripped and not stripped.startswith("#"):
                        preview = stripped[:120]
                        break
                files.append(
                    {
                        "path": rel_path,
                        "title": fm.get("title", fname),
                        "date": fm.get("date"),
                        "tags": fm.get("tags") or [],
                        "status": fm.get("status"),
                        "preview": preview,
                        "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                        "size": stat.st_size,
                    }
                )
            except Exception:
                continue

    files.sort(key=lambda x: x["modified"], reverse=True)
    return {"files": files}


@router.get("/api/vault/{workspace}/files/{file_path:path}")
def hosted_vault_read(workspace: str, file_path: str):
    """Read a file from a workspace's server-stored vault."""
    err = _validate_workspace_name(workspace)
    if err:
        return JSONResponse({"error": err}, status_code=400)

    vault_dir = get_vault_storage_path(workspace)
    result = read_file(file_path, vault_dir=vault_dir)
    if "error" in result:
        code = 404 if result["error"] == "File not found" else 400
        return JSONResponse(result, status_code=code)
    return result


@router.put("/api/vault/{workspace}/files/{file_path:path}")
def hosted_vault_write(workspace: str, file_path: str, body: dict):
    """Create or update a file in a workspace's server-stored vault."""
    err = _validate_workspace_name(workspace)
    if err:
        return JSONResponse({"error": err}, status_code=400)

    content = body.get("content", "")
    if not isinstance(content, str):
        return JSONResponse({"error": "content must be a string"}, status_code=400)

    vault_dir = get_vault_storage_path(workspace)
    os.makedirs(vault_dir, exist_ok=True)

    result = write_file(file_path, content, vault_dir=vault_dir)
    if "error" in result:
        return JSONResponse(result, status_code=400)
    return result


@router.delete("/api/vault/{workspace}/files/{file_path:path}")
def hosted_vault_delete(workspace: str, file_path: str):
    """Delete a file from a workspace's server-stored vault."""
    err = _validate_workspace_name(workspace)
    if err:
        return JSONResponse({"error": err}, status_code=400)

    vault_dir = get_vault_storage_path(workspace)
    from fathom_server.services.vault import _safe_path

    abs_path, path_err = _safe_path(file_path, vault_dir)
    if path_err:
        return JSONResponse({"error": path_err}, status_code=400)
    if not os.path.isfile(abs_path):
        return JSONResponse({"error": "File not found"}, status_code=404)

    try:
        os.remove(abs_path)
        return {"ok": True, "path": file_path}
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


@router.post("/api/vault/{workspace}/files/{file_path:path}/append")
def hosted_vault_append(workspace: str, file_path: str, body: dict):
    """Append content to a file in a workspace's server-stored vault."""
    err = _validate_workspace_name(workspace)
    if err:
        return JSONResponse({"error": err}, status_code=400)

    content = body.get("content", "")
    if not isinstance(content, str):
        return JSONResponse({"error": "content must be a string"}, status_code=400)

    vault_dir = get_vault_storage_path(workspace)
    os.makedirs(vault_dir, exist_ok=True)

    result = append_file(file_path, content, vault_dir=vault_dir)
    if "error" in result:
        return JSONResponse(result, status_code=400)
    return result


@router.post("/api/vault/{workspace}/sync/manifest")
async def hosted_vault_sync_manifest(workspace: str, request: Request):
    """Compare a client's file manifest against server storage."""
    err = _validate_workspace_name(workspace)
    if err:
        return JSONResponse({"error": err}, status_code=400)

    body = await request.json()
    if not isinstance(body, list):
        return JSONResponse(
            {"error": "Request body must be a JSON array of file entries"}, status_code=400
        )

    vault_dir = get_vault_storage_path(workspace)

    # Build server-side inventory
    server_files = {}
    if os.path.isdir(vault_dir):
        for root, _dirs, filenames in os.walk(vault_dir):
            for fname in filenames:
                abs_path = os.path.join(root, fname)
                rel_path = os.path.relpath(abs_path, vault_dir)
                stat = os.stat(abs_path)
                server_files[rel_path] = {
                    "mtime": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                    "size": stat.st_size,
                }

    # Determine what the server needs from the client
    client_paths = set()
    needed = []
    for entry in body:
        p = entry.get("path", "")
        if not p or ".." in p:
            continue
        client_paths.add(p)
        if p not in server_files or entry.get("size") != server_files.get(p, {}).get("size"):
            needed.append(p)

    # Files on server but not on client — may have been deleted locally
    deleted = [p for p in server_files if p not in client_paths]

    return {"needed": needed, "deleted": deleted}
