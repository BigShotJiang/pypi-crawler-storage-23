"""Version check endpoint — compares installed version against PyPI latest."""

import json
import time
import urllib.error
import urllib.request

from fastapi import APIRouter

from fathom_server import __version__

router = APIRouter()

_PYPI_URL = "https://pypi.org/pypi/fathom-server/json"
_CACHE_TTL = 3600  # 1 hour
_cache: dict = {"latest": None, "fetched_at": 0}


def _parse_version(v: str) -> tuple[int, ...]:
    """Parse '1.2.3' into (1, 2, 3) for comparison."""
    try:
        return tuple(int(x) for x in v.split("."))
    except (ValueError, AttributeError):
        return (0,)


def _fetch_latest() -> str | None:
    """Fetch latest version from PyPI, with in-memory caching."""
    now = time.time()
    if _cache["latest"] and now - _cache["fetched_at"] < _CACHE_TTL:
        return _cache["latest"]

    try:
        req = urllib.request.Request(_PYPI_URL, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
            latest = data["info"]["version"]
            _cache["latest"] = latest
            _cache["fetched_at"] = now
            return latest
    except (urllib.error.URLError, OSError, KeyError, json.JSONDecodeError):
        return _cache["latest"]  # return stale value if available, else None


@router.get("/api/version")
def version_check():
    """Return current and latest version info. No auth required."""
    latest = _fetch_latest()
    update_available = False
    if latest:
        update_available = _parse_version(latest) > _parse_version(__version__)

    return {
        "current": __version__,
        "latest": latest,
        "update_available": update_available,
    }
