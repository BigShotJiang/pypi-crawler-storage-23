"""Fathom Server — dashboard + REST API + background services for the vault layer."""

try:
    from importlib.metadata import version

    __version__ = version("fathom-server")
except Exception:
    __version__ = "0.0.0-dev"
