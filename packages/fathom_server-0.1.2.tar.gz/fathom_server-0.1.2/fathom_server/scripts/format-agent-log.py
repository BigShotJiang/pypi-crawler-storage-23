#!/usr/bin/env python3
"""Format stream-json agent logs for terminal display.

Reads newline-delimited JSON from stdin (tail -f agent.log | python3 format-agent-log.py)
and outputs styled, human-readable text with ANSI colors.
"""

import json
import sys
from datetime import datetime

# ANSI color codes
DIM = "\033[2m"
BOLD = "\033[1m"
RESET = "\033[0m"
CYAN = "\033[36m"
YELLOW = "\033[33m"
MAGENTA = "\033[35m"
GREEN = "\033[32m"
RED = "\033[31m"
WHITE = "\033[37m"
GRAY = "\033[90m"
BLUE = "\033[34m"

DIM_CYAN = f"{DIM}{CYAN}"
DIM_MAGENTA = f"{DIM}{MAGENTA}"
DIM_GREEN = f"{DIM}{GREEN}"
DIM_GRAY = f"{DIM}{GRAY}"
DIM_BLUE = f"{DIM}{BLUE}"
BOLD_YELLOW = f"{BOLD}{YELLOW}"
BOLD_RED = f"{BOLD}{RED}"
BOLD_MAGENTA = f"{BOLD}{MAGENTA}"


def now():
    return datetime.now().strftime("%I:%M:%S %p")


def sep(label="", width=50):
    if label:
        pad = width - len(label) - 2
        return f"{WHITE}{'─' * 2} {RESET}{label} {WHITE}{'─' * max(1, pad)}{RESET}"
    return f"{WHITE}{'─' * width}{RESET}"


def indent(text, prefix="  "):
    return "\n".join(f"{prefix}{line}" for line in text.split("\n"))


def truncate(text, max_lines=200):
    """Truncate text to max_lines, adding a dim count of hidden lines."""
    lines = text.split("\n")
    if len(lines) > max_lines:
        return (
            "\n".join(lines[: max_lines - 2])
            + f"\n{DIM_GRAY}  ... ({len(lines) - max_lines + 2} more lines){RESET}"
        )
    return text


def _is_tool_result_message(data):
    """Detect if a 'user' message is actually a tool result wrapper."""
    msg = data.get("message", {})
    content = msg.get("content")
    if isinstance(content, list):
        for block in content:
            if isinstance(block, dict) and block.get("type") == "tool_result":
                return True
    return False


def _extract_tool_results(data):
    """Extract tool result summaries from a user message containing tool_results."""
    msg = data.get("message", {})
    content = msg.get("content", [])
    results = []
    for block in content:
        if not isinstance(block, dict) or block.get("type") != "tool_result":
            continue
        tool_use_id = block.get("tool_use_id", "")[:12]
        is_error = block.get("is_error", False)
        # Extract text from content
        result_content = block.get("content", "")
        if isinstance(result_content, list):
            texts = []
            for sub in result_content:
                if isinstance(sub, dict) and sub.get("type") == "text":
                    texts.append(sub.get("text", ""))
            result_content = "\n".join(texts)
        result_text = str(result_content).strip()
        results.append((tool_use_id, is_error, result_text))
    return results


def format_tool_input(tool_name, tool_input):
    """Format tool input args — show all parameters in purple."""
    if not tool_input:
        return ""

    lines = []

    # Bash — show full command
    if tool_name == "Bash":
        cmd = tool_input.get("command", "")
        if cmd:
            cmd_lines = cmd.split("\n")
            for cl in cmd_lines:
                lines.append(f"    {GREEN}$ {cl}{RESET}")
        for k, v in tool_input.items():
            if k == "command":
                continue
            lines.append(f"    {GREEN}{k}: {_fmt_val(v)}{RESET}")
        return "\n" + "\n".join(lines) if lines else ""

    # All other tools — show every parameter
    for k, v in tool_input.items():
        lines.append(f"    {GREEN}{k}: {_fmt_val(v)}{RESET}")

    return "\n" + "\n".join(lines) if lines else ""


def _fmt_val(v):
    """Format a tool input value — no truncation."""
    if isinstance(v, str):
        return v
    if isinstance(v, list | dict):
        return json.dumps(v, ensure_ascii=False)
    return str(v)


def format_system(data):
    subtype = data.get("subtype", "")
    if subtype == "hook_response":
        hook = data.get("hook_name", "unknown")
        output = data.get("output", "")
        # Show brief hook output
        preview = ""
        if output:
            first_line = output.strip().split("\n")[0][:100]
            if first_line:
                preview = f"\n{DIM_CYAN}│{RESET} {DIM_GRAY}{first_line}{RESET}"
        return (
            f"\n{DIM_CYAN}┌─ ● HOOK {RESET}{DIM_CYAN}{hook}{RESET} {WHITE}{now()}{RESET}{preview}"
        )
    if subtype == "init":
        model = data.get("model", "")
        session = data.get("session_id", "")[:8]
        cwd = data.get("cwd", "")
        return (
            f"\n{DIM_CYAN}┌─ SESSION START {DIM_GRAY}{'─' * 30} {now()}{RESET}\n"
            f"{DIM_CYAN}│{RESET} {DIM_GRAY}model={model}  session={session}{RESET}\n"
            f"{DIM_CYAN}│{RESET} {DIM_GRAY}cwd={cwd}{RESET}\n"
            f"{DIM_CYAN}└{'─' * 48}{RESET}"
        )
    return f"{DIM_CYAN}[system:{subtype}]{RESET}"


def format_user(data):
    # Check if this is actually a tool result
    if _is_tool_result_message(data):
        results = _extract_tool_results(data)
        parts = []
        for _tid, is_error, text in results:
            if is_error:
                preview = truncate(text, 100)
                parts.append(f"  {BOLD_RED}✗ error{RESET}\n{indent(preview, '    ')}")
            elif text:
                preview = truncate(text, 50)
                parts.append(f"  {DIM_BLUE}↳{RESET} {DIM_GRAY}{preview}{RESET}")
        if parts:
            return "\n".join(parts)
        return None  # Empty tool result, skip

    # Real user message
    msg = data.get("message", {})
    content = ""
    if isinstance(msg.get("content"), str):
        content = msg["content"]
    elif isinstance(msg.get("content"), list):
        for block in msg["content"]:
            if isinstance(block, dict) and block.get("type") == "text":
                content += block.get("text", "")

    content = content.strip()
    if not content:
        return None  # Skip empty user messages

    content = truncate(content, 100)
    return f"\n{BOLD_YELLOW}▶ PROMPT{RESET} {WHITE}{now()}{RESET}\n{indent(content)}"


def format_assistant(data):
    msg = data.get("message", {})
    content_blocks = msg.get("content", [])
    parts = []

    for block in content_blocks:
        if not isinstance(block, dict):
            continue
        if block.get("type") == "text":
            text = block.get("text", "").strip()
            if text:
                text = truncate(text, 100)
                parts.append(indent(text))
        elif block.get("type") == "tool_use":
            tool = block.get("name", "unknown")
            tool_input = block.get("input", {})
            args_detail = format_tool_input(tool, tool_input)
            parts.append(f"  {GREEN}🔧 {BOLD}{GREEN}{tool}{RESET}{args_detail}")

    # Only show header for messages with content
    if not parts:
        return None

    header = f"\n{BOLD}{WHITE}◀ ASSISTANT{RESET} {WHITE}{now()}{RESET}"
    footer = ""

    body = "\n".join(parts)
    return f"{header}\n{body}{footer}"


def format_result(data):
    subtype = data.get("subtype", "")
    if subtype == "success":
        duration = data.get("duration_ms", 0)
        duration_s = duration / 1000 if duration else 0

        return f"\n{sep()}\n  {GREEN}✓ Done{RESET} {WHITE}· {duration_s:.0f}s{RESET}\n{sep()}"
    if subtype == "error":
        error = data.get("error", "unknown error")
        return f"\n{sep()}\n  {RED}✗ Error: {error}{RESET}\n{sep()}"
    return None


def process_line(line):
    line = line.strip()
    if not line:
        return None

    try:
        data = json.loads(line)
    except json.JSONDecodeError:
        # Plain text in the log
        return f"{DIM_GRAY}{line}{RESET}"

    msg_type = data.get("type", "")

    if msg_type == "system":
        return format_system(data)
    elif msg_type == "user":
        return format_user(data)
    elif msg_type == "assistant":
        return format_assistant(data)
    elif msg_type == "result":
        return format_result(data)
    # Skip content_block_start/stop, ping, etc.
    return None


def main():
    try:
        for line in sys.stdin:
            output = process_line(line)
            if output:
                print(output, flush=True)
    except KeyboardInterrupt:
        pass
    except BrokenPipeError:
        pass


if __name__ == "__main__":
    main()
