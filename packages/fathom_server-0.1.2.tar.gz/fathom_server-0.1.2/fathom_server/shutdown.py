"""Graceful shutdown orchestrator for fathom-server.

Handles SIGTERM/SIGINT with ordered service cleanup:
  1. Cancel ping & crystal schedulers (instant)
  2. Disconnect Telegram bridge (up to 5s)
  3. Stop background indexer (instant)
  4. Close agent WebSocket connections (instant)

Idempotent via threading.Event — safe to call from signal handler + atexit.
"""

import atexit
import logging
import signal
import threading
import time

log = logging.getLogger(__name__)

_shutdown_event = threading.Event()
SHUTDOWN_TIMEOUT = 15


def shutdown():
    """Execute ordered shutdown of all services. Idempotent."""
    if _shutdown_event.is_set():
        return
    _shutdown_event.set()
    log.info("Graceful shutdown initiated")
    deadline = time.monotonic() + SHUTDOWN_TIMEOUT

    # Phase 1: Stop scheduling (instant)
    from fathom_server.services.crystal_scheduler import crystal_scheduler
    from fathom_server.services.ping_scheduler import ping_scheduler

    ping_scheduler.shutdown()
    crystal_scheduler.shutdown()

    # Phase 1.5: Kill running crystallization processes
    from fathom_server.services import crystallization

    crystallization.shutdown()

    # Phase 2: Disconnect external I/O (up to 5s)
    from fathom_server.services.telegram_bridge import telegram_bridge

    remaining = max(0, deadline - time.monotonic())
    telegram_bridge.stop(timeout=min(remaining, 5))

    # Phase 3: Stop background processing (instant)
    from fathom_server.services.indexer import indexer

    indexer.shutdown()

    # Phase 4: Close WebSocket connections
    from fathom_server.services import agent_connections

    agent_connections.shutdown()

    log.info("Graceful shutdown complete")


def _signal_handler(signum, frame):
    sig_name = signal.Signals(signum).name
    log.info("Received %s", sig_name)
    shutdown()
    raise SystemExit(0)


def install():
    """Install signal handlers and atexit hook."""
    signal.signal(signal.SIGTERM, _signal_handler)
    signal.signal(signal.SIGINT, _signal_handler)
    atexit.register(shutdown)
