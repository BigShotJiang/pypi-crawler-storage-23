"""API key authentication for fathom-server.

Generates a server API key on first run (stored in data/server.json).
Provides FastAPI dependency for Bearer token auth on API routes.
"""

import json
import os
import secrets

from fastapi import HTTPException
from fastapi import Request as FARequest

from fathom_server.paths import DATA_DIR, SERVER_CONFIG_PATH

_DATA_DIR = str(DATA_DIR)
_SERVER_CONFIG_PATH = str(SERVER_CONFIG_PATH)

# Prefix makes keys visually identifiable and greppable
_KEY_PREFIX = "fv_"
_KEY_BYTES = 24  # 24 bytes = 32 base64 chars

# File-mtime cache for server config
_cached_config: dict | None = None
_cached_mtime: float = 0.0


def _generate_api_key() -> str:
    """Generate a new API key with the fv_ prefix."""
    return _KEY_PREFIX + secrets.token_urlsafe(_KEY_BYTES)


def load_server_config() -> dict:
    """Load server config from data/server.json, creating with defaults if missing.

    Returns the config dict with a transient ``_key_newly_created`` flag
    (True when the API key was just generated — not persisted to disk).
    Uses file-mtime caching to avoid repeated disk reads.
    """
    global _cached_config, _cached_mtime

    os.makedirs(_DATA_DIR, exist_ok=True)

    # Return cached config if file hasn't changed
    try:
        mtime = os.path.getmtime(_SERVER_CONFIG_PATH)
        if _cached_config is not None and mtime == _cached_mtime:
            return dict(_cached_config)
    except OSError:
        pass

    try:
        with open(_SERVER_CONFIG_PATH) as f:
            config = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        config = {}

    changed = False
    key_newly_created = False

    if "api_key" not in config:
        config["api_key"] = _generate_api_key()
        changed = True
        key_newly_created = True

    if "auth_enabled" not in config:
        config["auth_enabled"] = False  # Off by default for backward compat
        changed = True

    if changed:
        save_server_config(config)

    # Cache before adding transient flag
    _cached_config = dict(config)
    try:
        _cached_mtime = os.path.getmtime(_SERVER_CONFIG_PATH)
    except OSError:
        _cached_mtime = 0.0

    config["_key_newly_created"] = key_newly_created
    return config


def save_server_config(config: dict) -> None:
    """Persist server config to data/server.json."""
    global _cached_config, _cached_mtime

    os.makedirs(_DATA_DIR, exist_ok=True)
    with open(_SERVER_CONFIG_PATH, "w") as f:
        json.dump(config, f, indent=2)

    # Invalidate cache so next read picks up the new file
    _cached_config = None
    _cached_mtime = 0.0


def get_api_key() -> str:
    """Return the current server API key."""
    return load_server_config()["api_key"]


def regenerate_api_key() -> str:
    """Generate a new API key, invalidating the old one."""
    config = load_server_config()
    config["api_key"] = _generate_api_key()
    save_server_config(config)
    return config["api_key"]


def is_auth_enabled() -> bool:
    """Check whether API key auth is currently enforced."""
    return load_server_config().get("auth_enabled", False)


def set_auth_enabled(enabled: bool) -> None:
    """Enable or disable API key auth enforcement."""
    config = load_server_config()
    config["auth_enabled"] = enabled
    save_server_config(config)


def validate_token_value(token: str) -> bool:
    """Validate a raw token string against the stored API key.

    Returns True if auth is disabled or the token matches.
    Used by WebSocket/SSE routes that pass tokens via query params.
    """
    if not is_auth_enabled():
        return True
    if not token:
        return False
    return secrets.compare_digest(token, get_api_key())


# --- FastAPI dependency ---


def validate_token_param(query_string: str) -> bool:
    """Validate a token query parameter from a raw query string.

    Legacy helper — new code should use validate_token_value() with the
    token extracted from query params directly.
    """
    if not is_auth_enabled():
        return True

    from urllib.parse import parse_qs

    params = parse_qs(query_string)
    tokens = params.get("token", [])
    if not tokens:
        return False

    expected = get_api_key()
    return secrets.compare_digest(tokens[0], expected)


# --- FastAPI dependency ---


def fastapi_require_api_key(request: FARequest):
    """FastAPI dependency — validates Bearer token when auth is enabled."""
    if not is_auth_enabled():
        return
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing or malformed Authorization header")
    if not secrets.compare_digest(auth_header[7:], get_api_key()):
        raise HTTPException(status_code=401, detail="Invalid API key")
