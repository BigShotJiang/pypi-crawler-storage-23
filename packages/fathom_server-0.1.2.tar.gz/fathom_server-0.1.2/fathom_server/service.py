"""Systemd user service management for fathom-server."""

import os
import shutil
import subprocess
import sys
from pathlib import Path

_SERVICE_NAME = "fathom-server.service"
_SERVICE_DIR = Path.home() / ".config" / "systemd" / "user"

_UNIT_TEMPLATE = """\
[Unit]
Description=Fathom Server
After=network.target

[Service]
Type=simple
KillMode=process
TimeoutStopSec=20
SendSIGKILL=no
WorkingDirectory={working_dir}
ExecStart={exec_start}
Restart=on-failure
RestartSec=5
Environment=PYTHONUNBUFFERED=1
{env_lines}

[Install]
WantedBy=default.target
"""


def _find_executable() -> str:
    """Find the fathom-server executable path."""
    # Prefer the bin next to the running Python (venv-aware)
    bin_dir = Path(sys.executable).parent
    candidate = bin_dir / "fathom-server"
    if candidate.exists():
        return str(candidate)
    # Fall back to PATH lookup
    found = shutil.which("fathom-server")
    if found:
        return found
    raise FileNotFoundError(
        "Cannot find fathom-server executable. Is it installed? Try: pip install fathom-server"
    )


def install_service(
    *,
    data_dir: str | None = None,
    host: str = "0.0.0.0",
    port: int = 4243,
    working_dir: str | None = None,
    no_start: bool = False,
) -> None:
    """Write a systemd user unit, enable it, and optionally start it."""
    exe = _find_executable()
    exec_parts = [exe, "serve", "--host", host, "--port", str(port)]
    exec_start = " ".join(exec_parts)

    env_lines = []
    if data_dir:
        env_lines.append(f"Environment=FATHOM_DATA_DIR={data_dir}")

    wd = working_dir or str(Path.home())

    unit = _UNIT_TEMPLATE.format(
        working_dir=wd,
        exec_start=exec_start,
        env_lines="\n".join(env_lines),
    )

    _SERVICE_DIR.mkdir(parents=True, exist_ok=True)
    unit_path = _SERVICE_DIR / _SERVICE_NAME
    unit_path.write_text(unit)
    print(f"  Wrote {unit_path}")

    # Enable linger so user services start at boot without login
    user = os.environ.get("USER", "")
    if user:
        r = subprocess.run(
            ["loginctl", "enable-linger", user],
            capture_output=True,
            text=True,
        )
        if r.returncode == 0:
            print(f"  Enabled linger for {user}")
        else:
            print(f"  Warning: could not enable linger: {r.stderr.strip()}")

    # Reload systemd and enable the service
    subprocess.run(["systemctl", "--user", "daemon-reload"], capture_output=True)
    subprocess.run(["systemctl", "--user", "enable", _SERVICE_NAME], capture_output=True)
    print(f"  Enabled {_SERVICE_NAME}")

    if not no_start:
        subprocess.run(["systemctl", "--user", "start", _SERVICE_NAME], capture_output=True)
        print(f"  Started {_SERVICE_NAME}")

    print()
    print("  Service installed. Commands:")
    print(f"    systemctl --user status {_SERVICE_NAME}")
    print(f"    systemctl --user restart {_SERVICE_NAME}")
    print(f"    journalctl --user -u {_SERVICE_NAME} -f")
    print()


def uninstall_service() -> None:
    """Stop, disable, and remove the systemd user unit."""
    unit_path = _SERVICE_DIR / _SERVICE_NAME

    if not unit_path.exists():
        print(f"  {_SERVICE_NAME} is not installed.")
        return

    subprocess.run(
        ["systemctl", "--user", "stop", _SERVICE_NAME],
        capture_output=True,
    )
    subprocess.run(
        ["systemctl", "--user", "disable", _SERVICE_NAME],
        capture_output=True,
    )
    unit_path.unlink()
    subprocess.run(["systemctl", "--user", "daemon-reload"], capture_output=True)

    print(f"  Stopped and removed {_SERVICE_NAME}")
