"""FastAPI app — all routes served natively (REST, SSE, WebSocket, static)."""

import os

from fastapi import FastAPI
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from fathom_server.config import FRONTEND_DIR
from fathom_server.routers.activation import router as activation_router
from fathom_server.routers.agent_ws import router as agent_ws_router
from fathom_server.routers.room import router as room_router
from fathom_server.routers.settings import router as settings_router
from fathom_server.routers.telegram import router as telegram_router
from fathom_server.routers.terminal import router as terminal_router
from fathom_server.routers.vault import router as vault_router
from fathom_server.routers.version import router as version_router

fastapi_app = FastAPI(title="Fathom Server", docs_url=None, redoc_url=None)

# API routers (REST, SSE, WebSocket)
fastapi_app.include_router(version_router)
fastapi_app.include_router(room_router)
fastapi_app.include_router(telegram_router)
fastapi_app.include_router(settings_router)
fastapi_app.include_router(vault_router)
fastapi_app.include_router(activation_router)
fastapi_app.include_router(agent_ws_router)
fastapi_app.include_router(terminal_router)

# Static assets (must come before SPA catch-all)
_assets_dir = os.path.join(FRONTEND_DIR, "assets")
if os.path.isdir(_assets_dir):
    fastapi_app.mount("/assets", StaticFiles(directory=_assets_dir), name="assets")

_index_html = os.path.join(FRONTEND_DIR, "index.html")


# SPA catch-all (registered LAST — after all API routes and routers)
@fastapi_app.get("/{full_path:path}")
async def spa(full_path: str):
    # API paths that didn't match any router should 404, not serve the SPA
    if full_path.startswith("api/") or full_path.startswith("ws/"):
        return JSONResponse({"error": "not found"}, status_code=404)
    # Serve actual static files if they exist (favicon, manifest, etc.)
    candidate = os.path.join(FRONTEND_DIR, full_path)
    if full_path and os.path.isfile(candidate):
        return FileResponse(candidate)
    return FileResponse(_index_html)
