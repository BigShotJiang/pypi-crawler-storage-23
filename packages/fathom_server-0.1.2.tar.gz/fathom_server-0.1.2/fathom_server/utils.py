"""Shared utility functions."""

from datetime import UTC, datetime


def ts_to_iso(ts: float) -> str:
    """Convert unix timestamp to ISO 8601 UTC string."""
    return datetime.fromtimestamp(ts, tz=UTC).isoformat()
