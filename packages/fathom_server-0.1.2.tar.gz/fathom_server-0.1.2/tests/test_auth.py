"""Tests for auth.py — API key generation, validation, and middleware."""

import json
import os
import tempfile

import pytest

# Patch DATA_DIR before importing auth
_tmpdir = tempfile.mkdtemp()
os.environ.setdefault("_FATHOM_DATA_DIR_OVERRIDE", _tmpdir)

import fathom_server.auth as auth  # noqa: E402


@pytest.fixture(autouse=True)
def _isolated_config(tmp_path, monkeypatch):
    """Each test gets its own server.json."""
    config_path = str(tmp_path / "server.json")
    monkeypatch.setattr(auth, "_SERVER_CONFIG_PATH", config_path)
    monkeypatch.setattr(auth, "_DATA_DIR", str(tmp_path))
    yield


class TestApiKeyGeneration:
    def test_generated_key_has_prefix(self):
        key = auth._generate_api_key()
        assert key.startswith("fv_")

    def test_generated_keys_are_unique(self):
        keys = {auth._generate_api_key() for _ in range(100)}
        assert len(keys) == 100

    def test_key_length_is_sufficient(self):
        key = auth._generate_api_key()
        # fv_ prefix (3) + 32 base64url chars = 35 minimum
        assert len(key) >= 35


class TestServerConfig:
    def test_load_creates_config_on_first_run(self, tmp_path):
        config = auth.load_server_config()
        assert "api_key" in config
        assert config["api_key"].startswith("fv_")
        assert config["auth_enabled"] is False
        # File was written
        assert os.path.exists(str(tmp_path / "server.json"))

    def test_load_preserves_existing_key(self, tmp_path):
        config_path = str(tmp_path / "server.json")
        with open(config_path, "w") as f:
            json.dump({"api_key": "fv_test123", "auth_enabled": True}, f)
        config = auth.load_server_config()
        assert config["api_key"] == "fv_test123"
        assert config["auth_enabled"] is True

    def test_regenerate_changes_key(self):
        old_key = auth.get_api_key()
        new_key = auth.regenerate_api_key()
        assert old_key != new_key
        assert new_key.startswith("fv_")
        assert auth.get_api_key() == new_key

    def test_auth_toggle(self):
        assert not auth.is_auth_enabled()
        auth.set_auth_enabled(True)
        assert auth.is_auth_enabled()
        auth.set_auth_enabled(False)
        assert not auth.is_auth_enabled()


class TestFastapiRequireApiKey:
    """Tests for fastapi_require_api_key dependency."""

    def _make_app(self):
        from fastapi import Depends, FastAPI
        from starlette.testclient import TestClient

        test_app = FastAPI()

        @test_app.get("/api/test", dependencies=[Depends(auth.fastapi_require_api_key)])
        def protected():
            return {"ok": True}

        @test_app.get("/dashboard")
        def unprotected():
            return {"ok": True}

        return TestClient(test_app)

    def test_passes_when_auth_disabled(self):
        auth.set_auth_enabled(False)
        c = self._make_app()
        resp = c.get("/api/test")
        assert resp.status_code == 200

    def test_rejects_missing_header_when_auth_enabled(self):
        auth.set_auth_enabled(True)
        c = self._make_app()
        resp = c.get("/api/test")
        assert resp.status_code == 401
        auth.set_auth_enabled(False)

    def test_rejects_wrong_key(self):
        auth.set_auth_enabled(True)
        c = self._make_app()
        resp = c.get("/api/test", headers={"Authorization": "Bearer fv_wrong"})
        assert resp.status_code == 401
        auth.set_auth_enabled(False)

    def test_accepts_correct_key(self):
        auth.set_auth_enabled(True)
        key = auth.get_api_key()
        c = self._make_app()
        resp = c.get("/api/test", headers={"Authorization": f"Bearer {key}"})
        assert resp.status_code == 200
        auth.set_auth_enabled(False)

    def test_unprotected_route_always_accessible(self):
        auth.set_auth_enabled(True)
        c = self._make_app()
        resp = c.get("/dashboard")
        assert resp.status_code == 200
        auth.set_auth_enabled(False)


class TestValidateTokenValue:
    """Unit tests for validate_token_value — WebSocket/SSE token validation."""

    def test_passes_when_auth_disabled(self):
        auth.set_auth_enabled(False)
        assert auth.validate_token_value("") is True
        assert auth.validate_token_value("anything") is True

    def test_rejects_empty_token(self):
        auth.set_auth_enabled(True)
        assert auth.validate_token_value("") is False
        auth.set_auth_enabled(False)

    def test_rejects_wrong_token(self):
        auth.set_auth_enabled(True)
        assert auth.validate_token_value("fv_wrong") is False
        auth.set_auth_enabled(False)

    def test_accepts_valid_token(self):
        auth.set_auth_enabled(True)
        key = auth.get_api_key()
        assert auth.validate_token_value(key) is True
        auth.set_auth_enabled(False)


class TestRouteAuthEnforcement:
    """Integration tests — verify @require_api_key is applied to actual API routes."""

    @pytest.fixture()
    def app_client(self):
        from starlette.testclient import TestClient

        from fathom_server.fastapi_app import fastapi_app

        auth.set_auth_enabled(True)
        yield TestClient(fastapi_app, raise_server_exceptions=False)
        auth.set_auth_enabled(False)

    # Representative endpoints from each blueprint that should require auth.
    # We only check for 401 — downstream errors (500, 404) are fine as long as
    # the auth layer fires first.
    PROTECTED = [
        # settings
        ("GET", "/api/settings"),
        ("GET", "/api/workspaces/profiles"),
        ("POST", "/api/auth/toggle"),
        ("POST", "/api/auth/key/regenerate"),
        # vault
        ("GET", "/api/vault/folder/"),
        ("GET", "/api/vault/activity"),
        # room
        ("GET", "/api/room/list"),
        ("GET", "/api/room/test-room"),
        ("POST", "/api/room/test-room"),
        # activation
        ("GET", "/api/activation/status"),
        ("POST", "/api/activation/crystal/spawn"),
        ("GET", "/api/activation/schedule"),
        ("GET", "/api/activation/ping/routines"),
        ("GET", "/api/activation/ping"),
        ("GET", "/api/activation/session"),
    ]

    @pytest.mark.parametrize("method,path", PROTECTED)
    def test_rejects_without_token(self, app_client, method, path):
        fn = getattr(app_client, method.lower())
        resp = fn(path) if method == "GET" else fn(path, json={})
        assert resp.status_code == 401, f"{method} {path} → {resp.status_code}"

    @pytest.mark.parametrize("method,path", PROTECTED)
    def test_rejects_bad_token(self, app_client, method, path):
        headers = {"Authorization": "Bearer fv_wrong-key"}
        fn = getattr(app_client, method.lower())
        resp = fn(path, headers=headers) if method == "GET" else fn(path, json={}, headers=headers)
        assert resp.status_code == 401, f"{method} {path} → {resp.status_code}"

    def test_auth_status_always_accessible(self, app_client):
        """GET /api/auth/status must never require auth."""
        resp = app_client.get("/api/auth/status")
        assert resp.status_code == 200

    def test_settings_passes_with_valid_token(self, app_client):
        key = auth.get_api_key()
        resp = app_client.get("/api/settings", headers={"Authorization": f"Bearer {key}"})
        assert resp.status_code != 401
