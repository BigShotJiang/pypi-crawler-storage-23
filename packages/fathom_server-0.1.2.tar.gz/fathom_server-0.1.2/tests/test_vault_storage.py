"""Tests for hosted vault storage endpoints (server-side CRUD)."""

import os
from unittest.mock import patch

import pytest
from starlette.testclient import TestClient

from fathom_server.fastapi_app import fastapi_app

SAMPLE_MD = "---\ntitle: Test Note\ndate: 2026-01-01\n---\n\nBody text.\n"


@pytest.fixture()
def client(tmp_path):
    """Flask test client with vault storage rooted in a temp directory."""
    storage_dir = str(tmp_path / "vaults")
    os.makedirs(storage_dir, exist_ok=True)

    import fathom_server.config as config
    import fathom_server.routers.vault as rv

    original_fn = config.get_vault_storage_path

    def mock_get_vault_storage_path(workspace):
        return os.path.join(storage_dir, workspace)

    config.get_vault_storage_path = mock_get_vault_storage_path
    rv.get_vault_storage_path = mock_get_vault_storage_path

    with patch("fathom_server.auth.is_auth_enabled", return_value=False):
        yield tmp_path, storage_dir, TestClient(fastapi_app)

    config.get_vault_storage_path = original_fn
    rv.get_vault_storage_path = original_fn


# ---------------------------------------------------------------------------
# GET /api/vault/{workspace}/files — list
# ---------------------------------------------------------------------------


def test_hosted_list_empty_workspace(client):
    _, _, c = client
    resp = c.get("/api/vault/test-ws/files")
    assert resp.status_code == 200
    assert resp.json()["files"] == []


def test_hosted_list_with_files(client):
    _, storage_dir, c = client
    ws_dir = os.path.join(storage_dir, "test-ws")
    os.makedirs(ws_dir, exist_ok=True)
    with open(os.path.join(ws_dir, "hello.md"), "w") as f:
        f.write(SAMPLE_MD)

    resp = c.get("/api/vault/test-ws/files")
    assert resp.status_code == 200
    files = resp.json()["files"]
    assert len(files) == 1
    assert files[0]["path"] == "hello.md"
    assert files[0]["title"] == "Test Note"


def test_hosted_list_nested_files(client):
    _, storage_dir, c = client
    sub = os.path.join(storage_dir, "test-ws", "thinking")
    os.makedirs(sub, exist_ok=True)
    with open(os.path.join(sub, "note.md"), "w") as f:
        f.write(SAMPLE_MD)

    resp = c.get("/api/vault/test-ws/files")
    files = resp.json()["files"]
    assert any(f["path"] == "thinking/note.md" for f in files)


# ---------------------------------------------------------------------------
# PUT /api/vault/{workspace}/files/{path} — write
# ---------------------------------------------------------------------------


def test_hosted_write_creates_file(client):
    _, storage_dir, c = client

    resp = c.put(
        "/api/vault/test-ws/files/hello.md",
        json={"content": SAMPLE_MD},
    )
    assert resp.status_code == 200
    assert resp.json()["ok"] is True

    # Verify file on disk
    assert os.path.isfile(os.path.join(storage_dir, "test-ws", "hello.md"))


def test_hosted_write_creates_nested_dirs(client):
    _, storage_dir, c = client

    resp = c.put(
        "/api/vault/test-ws/files/thinking/deep/note.md",
        json={"content": SAMPLE_MD},
    )
    assert resp.status_code == 200
    assert os.path.isfile(os.path.join(storage_dir, "test-ws", "thinking", "deep", "note.md"))


def test_hosted_write_validates_frontmatter(client):
    _, _, c = client
    content = "---\ndate: 2026-01-01\n---\n\nMissing title.\n"

    resp = c.put(
        "/api/vault/test-ws/files/bad.md",
        json={"content": content},
    )
    assert resp.status_code == 400
    assert "validation_errors" in resp.json()


def test_hosted_write_rejects_non_string_content(client):
    _, _, c = client
    resp = c.put("/api/vault/test-ws/files/x.md", json={"content": 42})
    assert resp.status_code == 400


def test_hosted_write_overwrites_existing(client):
    _, storage_dir, c = client

    c.put("/api/vault/test-ws/files/note.md", json={"content": SAMPLE_MD})
    new_content = "---\ntitle: Updated\ndate: 2026-01-01\n---\n\nNew body.\n"
    resp = c.put("/api/vault/test-ws/files/note.md", json={"content": new_content})
    assert resp.status_code == 200

    with open(os.path.join(storage_dir, "test-ws", "note.md")) as f:
        assert "New body." in f.read()


# ---------------------------------------------------------------------------
# GET /api/vault/{workspace}/files/{path} — read
# ---------------------------------------------------------------------------


def test_hosted_read_happy(client):
    _, storage_dir, c = client
    ws_dir = os.path.join(storage_dir, "test-ws")
    os.makedirs(ws_dir, exist_ok=True)
    with open(os.path.join(ws_dir, "hello.md"), "w") as f:
        f.write(SAMPLE_MD)

    resp = c.get("/api/vault/test-ws/files/hello.md")
    assert resp.status_code == 200
    data = resp.json()
    assert data["frontmatter"]["title"] == "Test Note"
    assert "Body text." in data["body"]


def test_hosted_read_not_found(client):
    _, _, c = client
    resp = c.get("/api/vault/test-ws/files/missing.md")
    assert resp.status_code == 404


# ---------------------------------------------------------------------------
# DELETE /api/vault/{workspace}/files/{path}
# ---------------------------------------------------------------------------


def test_hosted_delete_happy(client):
    _, storage_dir, c = client
    ws_dir = os.path.join(storage_dir, "test-ws")
    os.makedirs(ws_dir, exist_ok=True)
    fpath = os.path.join(ws_dir, "deleteme.md")
    with open(fpath, "w") as f:
        f.write(SAMPLE_MD)

    resp = c.delete("/api/vault/test-ws/files/deleteme.md")
    assert resp.status_code == 200
    assert resp.json()["ok"] is True
    assert not os.path.exists(fpath)


def test_hosted_delete_not_found(client):
    _, _, c = client
    resp = c.delete("/api/vault/test-ws/files/ghost.md")
    assert resp.status_code == 404


# ---------------------------------------------------------------------------
# POST /api/vault/{workspace}/files/{path}/append
# ---------------------------------------------------------------------------


def test_hosted_append_creates_new(client):
    _, storage_dir, c = client

    resp = c.post(
        "/api/vault/test-ws/files/new-note.md/append",
        json={"content": "## Section\n\nContent."},
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["ok"] is True
    assert data["created"] is True


def test_hosted_append_to_existing(client):
    _, storage_dir, c = client

    c.put("/api/vault/test-ws/files/note.md", json={"content": SAMPLE_MD})
    resp = c.post(
        "/api/vault/test-ws/files/note.md/append",
        json={"content": "## Added\n\nNew section."},
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["created"] is False

    with open(os.path.join(storage_dir, "test-ws", "note.md")) as f:
        text = f.read()
    assert "## Added" in text
    assert "Body text." in text


# ---------------------------------------------------------------------------
# POST /api/vault/{workspace}/sync/manifest
# ---------------------------------------------------------------------------


def test_sync_manifest_all_new(client):
    _, _, c = client

    manifest = [
        {"path": "note.md", "mtime": "2026-01-01T00:00:00", "size": 100},
        {"path": "thinking/deep.md", "mtime": "2026-01-01T00:00:00", "size": 200},
    ]
    resp = c.post("/api/vault/test-ws/sync/manifest", json=manifest)
    assert resp.status_code == 200
    data = resp.json()
    assert set(data["needed"]) == {"note.md", "thinking/deep.md"}
    assert data["deleted"] == []


def test_sync_manifest_detects_server_extras(client):
    _, storage_dir, c = client
    ws_dir = os.path.join(storage_dir, "test-ws")
    os.makedirs(ws_dir, exist_ok=True)
    with open(os.path.join(ws_dir, "orphan.md"), "w") as f:
        f.write(SAMPLE_MD)

    resp = c.post("/api/vault/test-ws/sync/manifest", json=[])
    data = resp.json()
    assert "orphan.md" in data["deleted"]


def test_sync_manifest_rejects_non_array(client):
    _, _, c = client
    resp = c.post("/api/vault/test-ws/sync/manifest", json={"path": "x"})
    assert resp.status_code in (400, 422)  # FastAPI validates body type as 422


# ---------------------------------------------------------------------------
# Security: workspace name validation
# ---------------------------------------------------------------------------


def test_hosted_rejects_traversal_workspace(client):
    _, _, c = client
    resp = c.get("/api/vault/../etc/files")
    # Flask routing may produce 404 for malformed paths
    assert resp.status_code in (400, 404)


def test_hosted_rejects_dot_workspace(client):
    _, _, c = client
    resp = c.get("/api/vault/.hidden/files")
    assert resp.status_code == 400
    assert "Invalid" in resp.json()["error"]


def test_hosted_write_path_traversal_blocked(client):
    _, _, c = client
    resp = c.put(
        "/api/vault/test-ws/files/../../../etc/passwd",
        json={"content": "hacked"},
    )
    # FastAPI/Starlette resolves .. at routing level → 405/400, both block traversal
    assert resp.status_code in (400, 405)


# ---------------------------------------------------------------------------
# Dashboard vault routing by vault mode
# ---------------------------------------------------------------------------


@pytest.fixture()
def dashboard_client(tmp_path):
    """Flask test client with mocked workspace settings for vault mode routing.

    Creates workspaces with different vault modes:
      - ws-local:  type=local, with a real vault dir on disk
      - ws-hosted: type=hosted, files in server storage
      - ws-synced: type=synced, files in server storage
      - ws-none:   type=none, no vault
    """
    import fathom_server.config as config
    import fathom_server.routers.vault as rv

    local_vault = str(tmp_path / "local-project" / "vault")
    os.makedirs(local_vault, exist_ok=True)
    with open(os.path.join(local_vault, "local-note.md"), "w") as f:
        f.write(SAMPLE_MD)

    storage_dir = str(tmp_path / "server-vaults")
    hosted_vault = os.path.join(storage_dir, "ws-hosted")
    os.makedirs(hosted_vault, exist_ok=True)
    with open(os.path.join(hosted_vault, "hosted-note.md"), "w") as f:
        f.write(SAMPLE_MD)

    synced_vault = os.path.join(storage_dir, "ws-synced")
    os.makedirs(synced_vault, exist_ok=True)
    with open(os.path.join(synced_vault, "synced-note.md"), "w") as f:
        f.write(SAMPLE_MD)

    mock_workspaces = {
        "ws-local": {
            "path": str(tmp_path / "local-project"),
            "vault": "vault",
            "type": "local",
        },
        "ws-hosted": {
            "path": str(tmp_path / "hosted-project"),
            "vault": "vault",
            "type": "hosted",
        },
        "ws-synced": {
            "path": str(tmp_path / "synced-project"),
            "vault": "vault",
            "type": "synced",
        },
        "ws-none": {
            "path": str(tmp_path / "none-project"),
            "vault": "vault",
            "type": "none",
        },
    }

    original_read = config._read_setting
    original_storage = config.get_vault_storage_path
    original_rv_storage = rv.get_vault_storage_path

    def mock_read_setting(*keys, default=None):
        if keys == ("workspaces",):
            return mock_workspaces
        if keys == ("default_workspace",):
            return "ws-local"
        return original_read(*keys, default=default)

    def mock_storage_path(workspace):
        return os.path.join(storage_dir, workspace)

    config._read_setting = mock_read_setting
    config.get_vault_storage_path = mock_storage_path
    rv.get_vault_storage_path = mock_storage_path

    with patch("fathom_server.auth.is_auth_enabled", return_value=False):
        yield tmp_path, TestClient(fastapi_app)

    config._read_setting = original_read
    config.get_vault_storage_path = original_storage
    rv.get_vault_storage_path = original_rv_storage


def test_dashboard_local_reads_filesystem(dashboard_client):
    """Local mode: /api/vault reads from the workspace's local vault directory."""
    _, c = dashboard_client
    resp = c.get("/api/vault?workspace=ws-local")
    assert resp.status_code == 200
    # Should return folder tree (array) — may be empty or have entries
    data = resp.json()
    assert isinstance(data, list)


def test_dashboard_local_folder_lists_files(dashboard_client):
    """Local mode: /api/vault/folder/ lists files from local vault."""
    _, c = dashboard_client
    resp = c.get("/api/vault/folder/?workspace=ws-local")
    assert resp.status_code == 200
    data = resp.json()
    files = data.get("files", [])
    md_files = [f for f in files if f.get("type") == "markdown"]
    assert any(f["name"] == "local-note.md" for f in md_files)


def test_dashboard_hosted_reads_server_storage(dashboard_client):
    """Hosted mode: /api/vault reads from data/vaults/{workspace}/."""
    _, c = dashboard_client
    resp = c.get("/api/vault?workspace=ws-hosted")
    assert resp.status_code == 200
    data = resp.json()
    assert isinstance(data, list)


def test_dashboard_hosted_folder_lists_server_files(dashboard_client):
    """Hosted mode: /api/vault/folder/ lists files from server storage."""
    _, c = dashboard_client
    resp = c.get("/api/vault/folder/?workspace=ws-hosted")
    assert resp.status_code == 200
    data = resp.json()
    files = data.get("files", [])
    md_files = [f for f in files if f.get("type") == "markdown"]
    assert any(f["name"] == "hosted-note.md" for f in md_files)


def test_dashboard_synced_reads_server_storage(dashboard_client):
    """Synced mode: /api/vault reads from data/vaults/{workspace}/."""
    _, c = dashboard_client
    resp = c.get("/api/vault?workspace=ws-synced")
    assert resp.status_code == 200
    data = resp.json()
    assert isinstance(data, list)


def test_dashboard_synced_folder_lists_server_files(dashboard_client):
    """Synced mode: /api/vault/folder/ lists files from server storage."""
    _, c = dashboard_client
    resp = c.get("/api/vault/folder/?workspace=ws-synced")
    assert resp.status_code == 200
    data = resp.json()
    files = data.get("files", [])
    md_files = [f for f in files if f.get("type") == "markdown"]
    assert any(f["name"] == "synced-note.md" for f in md_files)


def test_dashboard_none_returns_vault_mode_error(dashboard_client):
    """None mode: /api/vault returns 404 with vault_mode indicator."""
    _, c = dashboard_client
    resp = c.get("/api/vault?workspace=ws-none")
    assert resp.status_code == 404
    data = resp.json()
    assert data["vault_mode"] == "none"
    assert "error" in data


def test_dashboard_none_folder_returns_error(dashboard_client):
    """None mode: /api/vault/folder/ also returns vault_mode error."""
    _, c = dashboard_client
    resp = c.get("/api/vault/folder/?workspace=ws-none")
    assert resp.status_code == 404
    data = resp.json()
    assert data["vault_mode"] == "none"


def test_dashboard_none_file_returns_error(dashboard_client):
    """None mode: /api/vault/file/ returns vault_mode error."""
    _, c = dashboard_client
    resp = c.get("/api/vault/file/any-file.md?workspace=ws-none")
    assert resp.status_code == 404
    data = resp.json()
    assert data["vault_mode"] == "none"
