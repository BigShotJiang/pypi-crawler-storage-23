"""Tests for activation API routes: spawn and SSE stream."""

import json
from unittest.mock import patch

import pytest
from starlette.testclient import TestClient

from fathom_server.fastapi_app import fastapi_app


@pytest.fixture()
def client():
    with patch("fathom_server.auth.is_auth_enabled", return_value=False):
        yield TestClient(fastapi_app)


# ---------------------------------------------------------------------------
# POST /api/activation/crystal/spawn
# ---------------------------------------------------------------------------


def test_spawn_returns_job_id(client):
    """spawn endpoint should return a job_id string."""
    fake_job_id = "abc-123"
    with patch("fathom_server.routers.activation.spawn", return_value=fake_job_id) as mock_spawn:
        resp = client.post(
            "/api/activation/crystal/spawn",
            json={"additionalContext": "some extra"},
        )
    assert resp.status_code == 200
    data = resp.json()
    assert data["job_id"] == fake_job_id
    mock_spawn.assert_called_once_with(
        additional_context="some extra",
        workspace=None,
    )


def test_spawn_empty_body_uses_defaults(client):
    """spawn endpoint should work with no request body (uses defaults)."""
    with patch("fathom_server.routers.activation.spawn", return_value="xyz-456") as mock_spawn:
        resp = client.post("/api/activation/crystal/spawn")
    assert resp.status_code == 200
    mock_spawn.assert_called_once_with(additional_context="", workspace=None)


def test_spawn_partial_body(client):
    """spawn endpoint should apply only the fields provided."""
    with patch("fathom_server.routers.activation.spawn", return_value="partial-789") as mock_spawn:
        resp = client.post(
            "/api/activation/crystal/spawn",
            json={"additionalContext": "partial context"},
        )
    assert resp.status_code == 200
    mock_spawn.assert_called_once_with(additional_context="partial context", workspace=None)


# ---------------------------------------------------------------------------
# GET /api/activation/crystal/stream/<job_id>
# ---------------------------------------------------------------------------


def test_stream_unknown_job(client):
    """stream endpoint should yield an error event for unknown job IDs."""
    with patch("fathom_server.routers.activation.get_events", return_value=(None, None)):
        resp = client.get("/api/activation/crystal/stream/no-such-job")
    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("text/event-stream")
    body = resp.text
    assert '"type":"error"' in body


def test_stream_yields_events_then_done(client):
    """stream endpoint should yield queued events followed by the done sentinel."""
    events = [
        {"type": "progress", "progress": 10, "stage": "Loading tools"},
        {"type": "progress", "progress": 50, "stage": "Synthesizing"},
        {"type": "done", "status": "done", "exit_code": 0},
    ]

    call_count = 0

    def fake_get_events(job_id, after=0):
        nonlocal call_count
        call_count += 1
        remaining = events[after:]
        # Report done status once all events are visible
        final_status = "done" if after >= len(events) - 1 else "running"
        return remaining, final_status

    with patch("fathom_server.routers.activation.get_events", side_effect=fake_get_events):
        resp = client.get("/api/activation/crystal/stream/some-job-id")

    body = resp.text
    lines = [ln for ln in body.splitlines() if ln.startswith("data: ")]
    parsed = [json.loads(ln[len("data: ") :]) for ln in lines]

    types = [e["type"] for e in parsed]
    assert "progress" in types
    assert "done" in types


def test_stream_failed_job(client):
    """stream endpoint should emit the failed done event from the job store."""
    events = [{"type": "done", "status": "failed", "exit_code": 1}]

    def fake_get_events(job_id, after=0):
        return events[after:], "failed"

    with patch("fathom_server.routers.activation.get_events", side_effect=fake_get_events):
        resp = client.get("/api/activation/crystal/stream/fail-job")

    body = resp.text
    assert '"status": "failed"' in body or '"status":"failed"' in body


# ---------------------------------------------------------------------------
# Ping routes
# ---------------------------------------------------------------------------

PING_STATUS = {
    "enabled": False,
    "interval_minutes": 60,
    "next_ping_at": None,
    "last_ping_at": None,
    "context_sources": {"time": True, "scripts": [], "texts": []},
}


def test_get_ping_returns_status(client):
    """GET /api/activation/ping returns first routine status."""
    with patch("fathom_server.routers.activation.ping_scheduler") as mock_sched:
        mock_sched.first_routine_status = PING_STATUS
        resp = client.get("/api/activation/ping")
    assert resp.status_code == 200
    data = resp.json()
    assert "enabled" in data
    assert "interval_minutes" in data
    assert "context_sources" in data


ROUTINES_STATUS = {"routines": [{"id": "default", **PING_STATUS}]}
SETTINGS_WITH_ROUTINES = {"ping": {"routines": [{"id": "default", **PING_STATUS}]}}


def test_post_ping_configures_scheduler(client):
    """POST /api/activation/ping configures the first routine."""
    result_status = {**PING_STATUS, "enabled": True, "interval_minutes": 30}
    with (
        patch("fathom_server.routers.activation.ping_scheduler") as mock_sched,
        patch(
            "fathom_server.routers.activation.load_settings", return_value=SETTINGS_WITH_ROUTINES
        ),
        patch("fathom_server.routers.activation.save_settings"),
    ):
        mock_sched.status = ROUTINES_STATUS
        mock_sched.configure_routine.return_value = result_status
        resp = client.post(
            "/api/activation/ping",
            json={"enabled": True, "intervalMinutes": 30},
        )
    assert resp.status_code == 200
    mock_sched.configure_routine.assert_called_once_with(
        "default", enabled=True, interval_minutes=30
    )


def test_post_ping_with_context_sources(client):
    """POST /api/activation/ping passes contextSources through to the scheduler."""
    ctx = {"time": True, "last_summary": False, "scripts": [], "texts": []}
    with (
        patch("fathom_server.routers.activation.ping_scheduler") as mock_sched,
        patch(
            "fathom_server.routers.activation.load_settings", return_value=SETTINGS_WITH_ROUTINES
        ),
        patch("fathom_server.routers.activation.save_settings"),
    ):
        mock_sched.status = ROUTINES_STATUS
        mock_sched.configure_routine.return_value = PING_STATUS
        resp = client.post(
            "/api/activation/ping",
            json={"enabled": False, "intervalMinutes": 60, "contextSources": ctx},
        )
    assert resp.status_code == 200
    mock_sched.configure_routine.assert_called_once_with(
        "default", enabled=False, interval_minutes=60, context_sources=ctx
    )


def test_post_ping_now_fires(client):
    """POST /api/activation/ping/now triggers fire_now and returns fired=True."""
    with patch("fathom_server.routers.activation.ping_scheduler") as mock_sched:
        resp = client.post("/api/activation/ping/now")
    assert resp.status_code == 200
    assert resp.json()["fired"] is True
    mock_sched.fire_now.assert_called_once()


# ---------------------------------------------------------------------------
# Routine CRUD — single_fire
# ---------------------------------------------------------------------------


def test_create_routine_with_single_fire(client):
    """POST /api/activation/ping/routines with singleFire passes through to scheduler."""
    with (
        patch("fathom_server.routers.activation.ping_scheduler") as mock_sched,
        patch(
            "fathom_server.routers.activation.load_settings",
            return_value={"ping": {"routines": []}},
        ),
        patch("fathom_server.routers.activation.save_settings"),
        patch("fathom_server.routers.activation.new_routine_id", return_value="abc123"),
        patch("fathom_server.routers.activation.load_routines", return_value=[]),
        patch("fathom_server.routers.activation.save_routines"),
    ):
        mock_sched.add_routine.return_value = {
            "id": "abc123",
            "name": "One-shot",
            "enabled": True,
            "interval_minutes": 5,
            "single_fire": True,
            "workspace": "fathom",
            "next_ping_at": None,
            "last_ping_at": None,
            "context_sources": {"time": True, "scripts": [], "texts": []},
        }
        resp = client.post(
            "/api/activation/ping/routines",
            json={"name": "One-shot", "enabled": True, "intervalMinutes": 5, "singleFire": True},
        )
    assert resp.status_code == 201
    data = resp.json()
    assert data["single_fire"] is True
    # Verify the routine dict passed to add_routine includes single_fire
    call_args = mock_sched.add_routine.call_args[0][0]
    assert call_args["single_fire"] is True


def test_create_routine_default_single_fire_false(client):
    """POST /api/activation/ping/routines without singleFire defaults to false."""
    with (
        patch("fathom_server.routers.activation.ping_scheduler") as mock_sched,
        patch(
            "fathom_server.routers.activation.load_settings",
            return_value={"ping": {"routines": []}},
        ),
        patch("fathom_server.routers.activation.save_settings"),
        patch("fathom_server.routers.activation.new_routine_id", return_value="def456"),
        patch("fathom_server.routers.activation.load_routines", return_value=[]),
        patch("fathom_server.routers.activation.save_routines"),
    ):
        mock_sched.add_routine.return_value = {
            "id": "def456",
            "name": "New Routine",
            "enabled": False,
            "interval_minutes": 60,
            "single_fire": False,
            "workspace": "fathom",
            "next_ping_at": None,
            "last_ping_at": None,
            "context_sources": {"time": True, "scripts": [], "texts": []},
        }
        resp = client.post(
            "/api/activation/ping/routines",
            json={"name": "Normal"},
        )
    assert resp.status_code == 201
    call_args = mock_sched.add_routine.call_args[0][0]
    assert call_args["single_fire"] is False


def test_update_routine_single_fire(client):
    """POST /api/activation/ping/routines/<id> with singleFire persists to routines.json."""
    routines = [{"id": "r1", "name": "Test", "enabled": True, "interval_minutes": 60}]
    with (
        patch("fathom_server.routers.activation.ping_scheduler") as mock_sched,
        patch("fathom_server.routers.activation.load_routines", return_value=routines),
        patch("fathom_server.routers.activation.save_routines") as mock_save,
    ):
        mock_sched.configure_routine.return_value = {
            "id": "r1",
            "name": "Test",
            "enabled": True,
            "interval_minutes": 60,
            "single_fire": True,
            "workspace": "fathom",
            "next_ping_at": None,
            "last_ping_at": None,
            "context_sources": {"time": True, "scripts": [], "texts": []},
        }
        resp = client.post(
            "/api/activation/ping/routines/r1",
            json={"singleFire": True},
        )
    assert resp.status_code == 200
    mock_sched.configure_routine.assert_called_once_with("r1", workspace=None, single_fire=True)
    # Check that single_fire was persisted to the routines list
    saved_routines = mock_save.call_args[0][0]
    saved_routine = saved_routines[0]
    assert saved_routine["single_fire"] is True


def test_get_session_status(client):
    """GET /api/activation/session returns session name and running state."""
    with patch(
        "fathom_server.routers.activation.session_status",
        return_value={
            "session": "fathom-session",
            "pane": "%0",
            "running": True,
        },
    ):
        resp = client.get("/api/activation/session")
    assert resp.status_code == 200
    data = resp.json()
    assert data["session"] == "fathom-session"
    assert "running" in data
