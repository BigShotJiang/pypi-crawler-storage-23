"""Tests for telegram image support — receive, serve, and send images."""

import base64
import sqlite3
from unittest.mock import MagicMock, patch

import pytest
from starlette.testclient import TestClient

from fathom_server.fastapi_app import fastapi_app


def _insert_message(db_path, room, sender, message, ts, media_path=None):
    """Insert a message and return its id."""
    con = sqlite3.connect(str(db_path))
    cur = con.execute(
        "INSERT INTO room_messages (room, sender, message, timestamp, media_path) "
        "VALUES (?, ?, ?, ?, ?)",
        (room, sender, message, ts, media_path),
    )
    msg_id = cur.lastrowid
    con.commit()
    con.close()
    return msg_id


def _create_test_image(assets_dir, filename):
    """Create a minimal JPEG-like test file."""
    assets_dir.mkdir(parents=True, exist_ok=True)
    filepath = assets_dir / filename
    # Minimal content — just needs to be readable
    filepath.write_bytes(b"\xff\xd8\xff\xe0" + b"\x00" * 100)
    return filepath


@pytest.fixture()
def client(tmp_path, isolated_db):
    """Flask test client with assets in temp directory."""
    assets_dir = tmp_path / "telegram-assets"

    with (
        patch("fathom_server.routers.telegram._ASSETS_DIR", assets_dir),
        patch("fathom_server.auth.is_auth_enabled", return_value=False),
    ):
        yield TestClient(fastapi_app), isolated_db, assets_dir


class TestTelegramReadWithMedia:
    """Messages with media_path should include media flag in read response."""

    def test_message_without_media(self, client):
        c, db_path, _ = client
        _insert_message(db_path, "telegram:123", "Myra", "hello", 1000.0)
        resp = c.get("/api/telegram/messages/123")
        assert resp.status_code == 200
        data = resp.json()
        msg = data["messages"][0]
        assert "media" not in msg

    def test_message_with_media(self, client):
        c, db_path, _ = client
        _insert_message(
            db_path,
            "telegram:123",
            "Myra",
            "check this out",
            1000.0,
            media_path="123_42.jpg",
        )
        resp = c.get("/api/telegram/messages/123")
        assert resp.status_code == 200
        data = resp.json()
        msg = data["messages"][0]
        assert msg["media"] is True

    def test_image_only_message(self, client):
        c, db_path, _ = client
        _insert_message(
            db_path,
            "telegram:123",
            "Myra",
            "",
            1000.0,
            media_path="123_99.jpg",
        )
        resp = c.get("/api/telegram/messages/123")
        assert resp.status_code == 200
        msg = resp.json()["messages"][0]
        assert msg["message"] == ""
        assert msg["media"] is True


class TestTelegramImageEndpoint:
    """GET /api/telegram/image/<message_id> serves images as base64."""

    def test_get_image_success(self, client):
        c, db_path, assets_dir = client
        filename = "123_42.jpg"
        _create_test_image(assets_dir, filename)
        msg_id = _insert_message(
            db_path,
            "telegram:123",
            "Myra",
            "photo",
            1000.0,
            media_path=filename,
        )
        resp = c.get(f"/api/telegram/image/{msg_id}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["mimeType"] == "image/jpeg"
        assert data["filename"] == filename
        # Verify base64 is decodable
        raw = base64.b64decode(data["data"])
        assert raw[:2] == b"\xff\xd8"

    def test_get_image_no_media(self, client):
        c, db_path, _ = client
        msg_id = _insert_message(
            db_path,
            "telegram:123",
            "Myra",
            "text only",
            1000.0,
        )
        resp = c.get(f"/api/telegram/image/{msg_id}")
        assert resp.status_code == 404
        assert "No image" in resp.json()["error"]

    def test_get_image_missing_file(self, client):
        c, db_path, _ = client
        msg_id = _insert_message(
            db_path,
            "telegram:123",
            "Myra",
            "photo",
            1000.0,
            media_path="nonexistent.jpg",
        )
        resp = c.get(f"/api/telegram/image/{msg_id}")
        assert resp.status_code == 404
        assert "not found" in resp.json()["error"]

    def test_get_image_nonexistent_message(self, client):
        c, _, _ = client
        resp = c.get("/api/telegram/image/99999")
        assert resp.status_code == 404

    def test_get_image_too_large(self, client):
        c, db_path, assets_dir = client
        filename = "123_big.jpg"
        assets_dir.mkdir(parents=True, exist_ok=True)
        big_file = assets_dir / filename
        big_file.write_bytes(b"\x00" * (6 * 1024 * 1024))  # 6MB
        msg_id = _insert_message(
            db_path,
            "telegram:123",
            "Myra",
            "huge",
            1000.0,
            media_path=filename,
        )
        resp = c.get(f"/api/telegram/image/{msg_id}")
        assert resp.status_code == 413
        assert "too large" in resp.json()["error"]

    def test_get_image_png(self, client):
        c, db_path, assets_dir = client
        filename = "123_50.png"
        assets_dir.mkdir(parents=True, exist_ok=True)
        (assets_dir / filename).write_bytes(b"\x89PNG" + b"\x00" * 50)
        msg_id = _insert_message(
            db_path,
            "telegram:123",
            "Myra",
            "screenshot",
            1000.0,
            media_path=filename,
        )
        resp = c.get(f"/api/telegram/image/{msg_id}")
        assert resp.status_code == 200
        assert resp.json()["mimeType"] == "image/png"


class TestTelegramSendImageEndpoint:
    """POST /api/telegram/send-image/<chat_id> sends an image via the bridge."""

    def test_send_image_success(self, client):
        c, _, assets_dir = client
        # Create a local image to send
        img_path = assets_dir.parent / "test_send.jpg"
        img_path.write_bytes(b"\xff\xd8\xff\xe0" + b"\x00" * 100)

        mock_bridge = MagicMock()
        mock_bridge.send_image.return_value = {"ok": True, "chat_id": 123, "timestamp": 9999.0}

        with patch("fathom_server.routers.telegram.telegram_bridge", mock_bridge):
            resp = c.post(
                "/api/telegram/send-image/123",
                json={"file_path": str(img_path), "caption": "test image"},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        mock_bridge.send_image.assert_called_once_with(123, str(img_path), "test image")

    def test_send_image_no_file_path(self, client):
        c, _, _ = client
        resp = c.post("/api/telegram/send-image/123", json={"caption": "no file"})
        assert resp.status_code == 400
        assert "file_path is required" in resp.json()["error"]

    def test_send_image_empty_file_path(self, client):
        c, _, _ = client
        resp = c.post("/api/telegram/send-image/123", json={"file_path": "", "caption": "empty"})
        assert resp.status_code == 400
        assert "file_path is required" in resp.json()["error"]

    def test_send_image_bridge_error(self, client):
        c, _, _ = client
        mock_bridge = MagicMock()
        mock_bridge.send_image.return_value = {"error": "Telegram bridge not connected"}

        with patch("fathom_server.routers.telegram.telegram_bridge", mock_bridge):
            resp = c.post(
                "/api/telegram/send-image/123",
                json={"file_path": "/tmp/test.jpg"},
            )

        assert resp.status_code == 502
        assert "not connected" in resp.json()["error"]

    def test_send_image_no_caption(self, client):
        c, _, assets_dir = client
        img_path = assets_dir.parent / "test_no_cap.jpg"
        img_path.write_bytes(b"\xff\xd8\xff\xe0" + b"\x00" * 50)

        mock_bridge = MagicMock()
        mock_bridge.send_image.return_value = {"ok": True, "chat_id": 123, "timestamp": 9999.0}

        with patch("fathom_server.routers.telegram.telegram_bridge", mock_bridge):
            resp = c.post(
                "/api/telegram/send-image/123",
                json={"file_path": str(img_path)},
            )

        assert resp.status_code == 200
        mock_bridge.send_image.assert_called_once_with(123, str(img_path), "")


class TestTelegramBridgeSendImage:
    """Unit tests for TelegramBridge.send_image validation."""

    def test_not_connected(self):
        from fathom_server.services.telegram_bridge import TelegramBridge

        bridge = TelegramBridge()
        result = bridge.send_image(123, "/tmp/test.jpg")
        assert result == {"error": "Telegram bridge not connected"}

    def test_file_not_found(self, tmp_path):
        from fathom_server.services.telegram_bridge import TelegramBridge

        bridge = TelegramBridge()
        bridge._connected = True
        bridge._loop = MagicMock()
        bridge._loop.is_closed.return_value = False

        result = bridge.send_image(123, str(tmp_path / "nonexistent.jpg"))
        assert "not found" in result["error"]

    def test_file_too_large(self, tmp_path):
        from fathom_server.services.telegram_bridge import TelegramBridge

        bridge = TelegramBridge()
        bridge._connected = True
        bridge._loop = MagicMock()
        bridge._loop.is_closed.return_value = False

        big_file = tmp_path / "huge.jpg"
        big_file.write_bytes(b"\x00" * (11 * 1024 * 1024))

        result = bridge.send_image(123, str(big_file))
        assert "too large" in result["error"]

    def test_not_a_file(self, tmp_path):
        from fathom_server.services.telegram_bridge import TelegramBridge

        bridge = TelegramBridge()
        bridge._connected = True
        bridge._loop = MagicMock()
        bridge._loop.is_closed.return_value = False

        result = bridge.send_image(123, str(tmp_path))
        assert "Not a file" in result["error"]


class TestMediaPathMigration:
    """Verify the ALTER TABLE migration works on existing DBs."""

    def test_migration_adds_column(self, tmp_path):
        """DB created without media_path gets it added by _run_migrations()."""
        import fathom_server.db as db_mod

        db_path = tmp_path / "legacy.db"
        # Create old-style table without media_path
        con = sqlite3.connect(str(db_path))
        con.execute(
            "CREATE TABLE room_messages ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "room TEXT NOT NULL, sender TEXT NOT NULL, "
            "message TEXT NOT NULL, timestamp REAL NOT NULL)"
        )
        con.execute(
            "INSERT INTO room_messages (room, sender, message, timestamp) VALUES ('r', 's', 'm', 1.0)"
        )
        con.commit()
        con.close()

        # Run migrations against the legacy DB
        with patch.object(db_mod, "_DB_PATH", db_path):
            migrated_con = db_mod._raw_connect()
            try:
                db_mod._run_migrations(migrated_con)
                # Should be able to query media_path now
                row = migrated_con.execute(
                    "SELECT media_path FROM room_messages WHERE id = 1"
                ).fetchone()
                assert row["media_path"] is None
            finally:
                migrated_con.close()
