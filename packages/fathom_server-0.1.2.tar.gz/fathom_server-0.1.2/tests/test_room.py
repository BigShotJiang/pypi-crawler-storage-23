"""Tests for room endpoints — windowed reads, retention, pruning."""

import sqlite3
import time
from unittest.mock import patch

import pytest
from starlette.testclient import TestClient

from fathom_server.fastapi_app import fastapi_app


def _seed_messages(db_path, room, messages):
    """Insert messages into the room_messages table.

    Each message is a tuple of (sender, text, timestamp).
    Tables already exist via conftest's isolated_db fixture.
    """
    con = sqlite3.connect(str(db_path))
    for sender, text, ts in messages:
        con.execute(
            "INSERT INTO room_messages (room, sender, message, timestamp) VALUES (?, ?, ?, ?)",
            (room, sender, text, ts),
        )
    con.commit()
    con.close()


@pytest.fixture()
def client(isolated_db):
    """Flask test client with room DB pointed at a temp directory."""
    global_settings = {
        "workspaces": {
            "fathom": {"path": "/tmp/fathom", "type": "synced"},
            "navier-stokes": {"path": "/tmp/ns", "type": "synced"},
            "myra": {"path": "/tmp/myra", "type": "human"},
        },
        "default_workspace": None,
        "rooms": {"retention_days": 7},
    }

    def fake_load_global():
        return dict(global_settings)

    with (
        patch("fathom_server.routers.room.load_global_settings", side_effect=fake_load_global),
        patch("fathom_server.routers.room.session_inject", return_value=True),
        patch("fathom_server.auth.is_auth_enabled", return_value=False),
    ):
        yield TestClient(fastapi_app), isolated_db, global_settings


# ---------------------------------------------------------------------------
# read_room — default 60-minute window
# ---------------------------------------------------------------------------


def test_read_empty_room(client):
    c, db_path, _ = client
    resp = c.get("/api/room/empty")
    assert resp.status_code == 200
    data = resp.json()
    assert data["count"] == 0
    assert data["window"]["latest_message"] is None
    assert data["window"]["has_older"] is False


def test_read_default_60min_window(client):
    c, db_path, _ = client
    now = time.time()
    _seed_messages(
        db_path,
        "general",
        [
            ("alice", "old message", now - 7200),  # 2h ago — outside default window
            ("bob", "recent 1", now - 1800),  # 30min ago
            ("alice", "recent 2", now - 600),  # 10min ago
            ("bob", "latest", now),  # now (anchor)
        ],
    )
    resp = c.get("/api/room/general")
    assert resp.status_code == 200
    data = resp.json()
    # Default window: 60min from latest — should get 3 messages (30min, 10min, now)
    assert data["count"] == 3
    assert data["messages"][0]["message"] == "recent 1"
    assert data["messages"][-1]["message"] == "latest"
    assert data["window"]["has_older"] is True
    # Each message should have a datetime field
    assert "datetime" in data["messages"][0]


# ---------------------------------------------------------------------------
# read_room — custom minutes param
# ---------------------------------------------------------------------------


def test_read_custom_minutes(client):
    c, db_path, _ = client
    now = time.time()
    _seed_messages(
        db_path,
        "dev",
        [
            ("alice", "msg1", now - 900),  # 15min ago
            ("bob", "msg2", now - 300),  # 5min ago
            ("alice", "msg3", now),  # now
        ],
    )
    # 10-minute window — should only get msg2 and msg3
    resp = c.get("/api/room/dev?minutes=10")
    data = resp.json()
    assert data["count"] == 2
    assert data["messages"][0]["message"] == "msg2"


# ---------------------------------------------------------------------------
# read_room — start offset (pseudo-pagination)
# ---------------------------------------------------------------------------


def test_read_with_start_offset(client):
    c, db_path, _ = client
    now = time.time()
    _seed_messages(
        db_path,
        "chat",
        [
            ("alice", "ancient", now - 7200),  # 120min ago
            ("bob", "older", now - 5400),  # 90min ago
            ("alice", "middle", now - 3600),  # 60min ago
            ("bob", "recent", now - 1800),  # 30min ago
            ("alice", "latest", now),  # now
        ],
    )
    # Window: 30 minutes, starting 60 minutes back from latest
    # window_end = now - 60min, window_start = now - 90min
    # Should get "older" (90min ago) — wait, that's at boundary
    # Actually: timestamp > window_start AND timestamp <= window_end
    # window_end = now - 3600, window_start = now - 5400
    # "older" at now-5400 is NOT > window_start (it equals it), so excluded
    # "middle" at now-3600 IS <= window_end, so included
    resp = c.get("/api/room/chat?minutes=30&start=60")
    data = resp.json()
    assert data["count"] == 1
    assert data["messages"][0]["message"] == "middle"
    assert data["window"]["has_older"] is True


# ---------------------------------------------------------------------------
# read_room — hours backward compat
# ---------------------------------------------------------------------------


def test_read_hours_backward_compat(client):
    c, db_path, _ = client
    now = time.time()
    _seed_messages(
        db_path,
        "compat",
        [
            ("alice", "old", now - 10800),  # 3h ago
            ("bob", "mid", now - 3600),  # 1h ago
            ("alice", "new", now),  # now
        ],
    )
    # hours=2 should convert to minutes=120
    resp = c.get("/api/room/compat?hours=2")
    data = resp.json()
    assert data["count"] == 2
    assert data["messages"][0]["message"] == "mid"


def test_minutes_overrides_hours(client):
    c, db_path, _ = client
    now = time.time()
    _seed_messages(
        db_path,
        "override",
        [
            ("alice", "msg1", now - 1800),  # 30min ago
            ("bob", "msg2", now),  # now
        ],
    )
    # If both minutes and hours present, minutes wins
    resp = c.get("/api/room/override?minutes=10&hours=24")
    data = resp.json()
    assert data["count"] == 1
    assert data["messages"][0]["message"] == "msg2"


# ---------------------------------------------------------------------------
# read_room — retention clamping
# ---------------------------------------------------------------------------


def test_retention_clamps_window(client):
    c, db_path, gs = client
    gs["rooms"]["retention_days"] = 1  # 1 day retention
    now = time.time()
    _seed_messages(
        db_path,
        "ret",
        [
            ("alice", "expired", now - 172800),  # 2 days ago — beyond retention
            ("bob", "kept", now - 3600),  # 1h ago
            ("alice", "latest", now),  # now
        ],
    )
    # Request a huge window — should be clamped to retention boundary
    resp = c.get("/api/room/ret?minutes=99999")
    data = resp.json()
    assert data["count"] == 2
    assert data["window"]["retention_limited"] is True
    # The expired message exists but is beyond retention window
    assert data["window"]["has_older"] is True


def test_null_retention_no_clamping(client):
    c, db_path, gs = client
    gs["rooms"]["retention_days"] = None  # Unlimited
    now = time.time()
    _seed_messages(
        db_path,
        "unlimited",
        [
            ("alice", "ancient", now - 864000),  # 10 days ago
            ("bob", "latest", now),
        ],
    )
    resp = c.get("/api/room/unlimited?minutes=999999")
    data = resp.json()
    assert data["count"] == 2
    assert data["window"]["retention_limited"] is False


# ---------------------------------------------------------------------------
# read_room — has_older
# ---------------------------------------------------------------------------


def test_has_older_false_when_all_messages_in_window(client):
    c, db_path, _ = client
    now = time.time()
    _seed_messages(
        db_path,
        "small",
        [
            ("alice", "only", now),
        ],
    )
    resp = c.get("/api/room/small")
    data = resp.json()
    assert data["count"] == 1
    assert data["window"]["has_older"] is False


# ---------------------------------------------------------------------------
# post_to_room — pruning
# ---------------------------------------------------------------------------


def test_post_prunes_expired_messages(client):
    c, db_path, gs = client
    gs["rooms"]["retention_days"] = 1
    now = time.time()
    _seed_messages(
        db_path,
        "prune",
        [
            ("alice", "expired1", now - 172800),  # 2 days ago
            ("bob", "expired2", now - 172800),  # 2 days ago
            ("alice", "kept", now - 3600),  # 1h ago
        ],
    )

    resp = c.post("/api/room/prune", json={"message": "new post", "sender": "test"})
    assert resp.status_code == 200
    data = resp.json()
    assert data["ok"] is True
    assert data["pruned"] == 2

    # Verify the expired messages are actually gone
    con = sqlite3.connect(str(db_path))
    count = con.execute("SELECT COUNT(*) FROM room_messages WHERE room = 'prune'").fetchone()[0]
    con.close()
    assert count == 2  # "kept" + "new post"


def test_post_null_retention_skips_pruning(client):
    c, db_path, gs = client
    gs["rooms"]["retention_days"] = None
    now = time.time()
    _seed_messages(
        db_path,
        "noprune",
        [
            ("alice", "ancient", now - 864000),  # 10 days old
        ],
    )

    resp = c.post("/api/room/noprune", json={"message": "new", "sender": "test"})
    data = resp.json()
    assert data["ok"] is True
    assert "pruned" not in data

    con = sqlite3.connect(str(db_path))
    count = con.execute("SELECT COUNT(*) FROM room_messages WHERE room = 'noprune'").fetchone()[0]
    con.close()
    assert count == 2  # ancient + new


# ---------------------------------------------------------------------------
# list_rooms — respects retention
# ---------------------------------------------------------------------------


def test_list_rooms_excludes_expired(client):
    c, db_path, gs = client
    gs["rooms"]["retention_days"] = 1
    now = time.time()
    # Room "active" has recent messages
    _seed_messages(
        db_path,
        "active",
        [
            ("alice", "hello", now - 3600),
            ("bob", "world", now),
        ],
    )
    # Room "dead" has only expired messages
    _seed_messages(
        db_path,
        "dead",
        [
            ("alice", "old", now - 172800),
        ],
    )

    resp = c.get("/api/room/list")
    data = resp.json()
    room_names = [r["name"] for r in data["rooms"]]
    assert "active" in room_names
    assert "dead" not in room_names


# ---------------------------------------------------------------------------
# Settings validation — rooms
# ---------------------------------------------------------------------------


def test_settings_rooms_retention_valid(client):
    """Settings POST accepts valid retention_days."""
    c, _, _ = client
    # This test uses the settings endpoint — needs its own mock setup
    # Tested via test_settings.py patterns; included here for completeness


def test_window_metadata_format(client):
    """Verify window metadata contains all expected fields."""
    c, db_path, _ = client
    now = time.time()
    _seed_messages(db_path, "meta", [("alice", "msg", now)])
    resp = c.get("/api/room/meta")
    data = resp.json()
    window = data["window"]
    assert "start" in window
    assert "end" in window
    assert "latest_message" in window
    assert "has_older" in window
    assert "retention_limited" in window
    # ISO 8601 format check
    assert "T" in window["start"]
    assert "T" in window["latest_message"]


# ---------------------------------------------------------------------------
# Unread tracking — room_read_state
# ---------------------------------------------------------------------------


def test_list_rooms_no_workspace_no_unread(client):
    """Backward compat: without workspace param, no unread_count field."""
    c, db_path, _ = client
    now = time.time()
    _seed_messages(db_path, "general", [("alice", "hi", now)])
    resp = c.get("/api/room/list")
    data = resp.json()
    room = data["rooms"][0]
    assert "unread_count" not in room


def test_list_rooms_unread_all_when_never_read(client):
    """No read-state entry = all messages unread."""
    c, db_path, _ = client
    now = time.time()
    _seed_messages(db_path, "general", [("alice", "hi", now)])
    resp = c.get("/api/room/list?workspace=fathom")
    data = resp.json()
    room = data["rooms"][0]
    assert room["unread_count"] == 1


def test_list_rooms_unread_after_mark_and_new_message(client):
    """Mark read, post new message, check unread = 1."""
    c, db_path, _ = client
    now = time.time()
    _seed_messages(db_path, "dev", [("alice", "old msg", now - 100)])

    # Mark room read for fathom
    resp = c.post("/api/room/dev/read", json={"workspace": "fathom"})
    assert resp.status_code == 200
    assert resp.json()["ok"] is True

    # Post a new message (after mark-read timestamp)
    resp = c.post("/api/room/dev", json={"message": "new msg", "sender": "bob"})
    assert resp.status_code == 200

    # List rooms — should show 1 unread for fathom
    resp = c.get("/api/room/list?workspace=fathom")
    data = resp.json()
    room = next(r for r in data["rooms"] if r["name"] == "dev")
    assert room["unread_count"] == 1


def test_mark_room_read_endpoint(client):
    """POST /api/room/<name>/read returns ok."""
    c, db_path, _ = client
    now = time.time()
    _seed_messages(db_path, "general", [("alice", "hi", now)])
    resp = c.post("/api/room/general/read", json={"workspace": "fathom"})
    assert resp.status_code == 200
    data = resp.json()
    assert data["ok"] is True
    assert data["room"] == "general"
    assert data["workspace"] == "fathom"
    assert "last_read_ts" in data


def test_mark_room_read_requires_workspace(client):
    """POST without workspace returns 400."""
    c, db_path, _ = client
    resp = c.post("/api/room/general/read", json={})
    assert resp.status_code == 400


def test_room_read_auto_marks_read(client):
    """GET with workspace param clears unread."""
    c, db_path, _ = client
    now = time.time()
    _seed_messages(
        db_path,
        "chat",
        [
            ("alice", "msg1", now - 200),
            ("bob", "msg2", now - 100),
            ("alice", "msg3", now),
        ],
    )

    # Read with workspace — auto-marks read
    resp = c.get("/api/room/chat?minutes=10080&workspace=fathom")
    assert resp.status_code == 200
    assert resp.json()["count"] == 3

    # Now list rooms — should show 0 unread
    resp = c.get("/api/room/list?workspace=fathom")
    room = next(r for r in resp.json()["rooms"] if r["name"] == "chat")
    assert room["unread_count"] == 0


def test_room_read_mark_read_false(client):
    """Peek without marking read — unread stays."""
    c, db_path, _ = client
    now = time.time()
    _seed_messages(db_path, "peek", [("alice", "msg1", now)])

    # First, mark as read so we have a baseline
    c.post("/api/room/peek/read", json={"workspace": "fathom"})

    # Post a new message
    c.post("/api/room/peek", json={"message": "new", "sender": "bob"})

    # Peek without marking read
    resp = c.get("/api/room/peek?minutes=10080&workspace=fathom&mark_read=false")
    assert resp.status_code == 200

    # Unread count should still show 1
    resp = c.get("/api/room/list?workspace=fathom")
    room = next(r for r in resp.json()["rooms"] if r["name"] == "peek")
    assert room["unread_count"] == 1


def test_unread_per_workspace_isolation(client):
    """fathom and navier-stokes have independent read states."""
    c, db_path, _ = client
    now = time.time()
    _seed_messages(
        db_path,
        "shared",
        [
            ("alice", "msg1", now - 100),
            ("bob", "msg2", now),
        ],
    )

    # fathom marks read
    c.post("/api/room/shared/read", json={"workspace": "fathom"})

    # Both should show 0 unread for fathom (just marked read)
    resp = c.get("/api/room/list?workspace=fathom")
    room = next(r for r in resp.json()["rooms"] if r["name"] == "shared")
    assert room["unread_count"] == 0

    # navier-stokes has never read — should show all messages as unread
    resp = c.get("/api/room/list?workspace=navier-stokes")
    room = next(r for r in resp.json()["rooms"] if r["name"] == "shared")
    assert room["unread_count"] == 2

    # Now post a new message
    c.post("/api/room/shared", json={"message": "new", "sender": "alice"})

    # fathom should see 1 unread
    resp = c.get("/api/room/list?workspace=fathom")
    room = next(r for r in resp.json()["rooms"] if r["name"] == "shared")
    assert room["unread_count"] == 1

    # navier-stokes has never read — all 3 messages are unread
    resp = c.get("/api/room/list?workspace=navier-stokes")
    room = next(r for r in resp.json()["rooms"] if r["name"] == "shared")
    assert room["unread_count"] == 3

    # navier-stokes marks read
    c.post("/api/room/shared/read", json={"workspace": "navier-stokes"})

    # Post another message
    c.post("/api/room/shared", json={"message": "another", "sender": "bob"})

    # fathom: 2 unread (since last mark-read)
    resp = c.get("/api/room/list?workspace=fathom")
    room = next(r for r in resp.json()["rooms"] if r["name"] == "shared")
    assert room["unread_count"] == 2

    # navier-stokes: 1 unread (since their more recent mark-read)
    resp = c.get("/api/room/list?workspace=navier-stokes")
    room = next(r for r in resp.json()["rooms"] if r["name"] == "shared")
    assert room["unread_count"] == 1


# ---------------------------------------------------------------------------
# Virtual rooms — DMs (persistent, shared dm:a+b rooms)
# ---------------------------------------------------------------------------


def test_dm_stores_in_paired_room(client):
    """Sending a DM stores it in dm:sorted+pair room."""
    c, db_path, _ = client
    resp = c.post("/api/send/fathom", json={"message": "hello fathom", "from": "myra"})
    assert resp.status_code == 200
    data = resp.json()
    assert data["ok"] is True
    assert data["room"] == "dm:fathom+myra"
    assert data["delivered"] is True

    # Verify message is raw (no wrapper text)
    con = sqlite3.connect(str(db_path))
    row = con.execute("SELECT message FROM room_messages WHERE room = 'dm:fathom+myra'").fetchone()
    con.close()
    assert row[0] == "hello fathom"


def test_dm_persistent_on_read(client):
    """Reading a DM room does NOT delete messages — they persist."""
    c, db_path, _ = client
    c.post("/api/send/fathom", json={"message": "msg1", "from": "myra"})
    c.post("/api/send/fathom", json={"message": "msg2", "from": "myra"})

    # First read — returns both messages
    resp = c.get("/api/room/dm:fathom+myra?minutes=10080&workspace=fathom")
    data = resp.json()
    assert data["count"] == 2

    # Second read — still there (persistent)
    resp = c.get("/api/room/dm:fathom+myra?minutes=10080&workspace=fathom")
    data = resp.json()
    assert data["count"] == 2


def test_dm_mark_read_false(client):
    """Reading with mark_read=false skips read-state update."""
    c, db_path, _ = client
    c.post("/api/send/fathom", json={"message": "peek me", "from": "myra"})

    # Mark read first to establish a baseline
    c.post("/api/room/dm:fathom+myra/read", json={"workspace": "fathom"})

    # Post another message
    c.post("/api/send/fathom", json={"message": "new one", "from": "myra"})

    # Peek without marking read
    resp = c.get("/api/room/dm:fathom+myra?minutes=10080&workspace=fathom&mark_read=false")
    assert resp.status_code == 200

    # Unread should still show 1 (the new message)
    resp = c.get("/api/room/list?workspace=fathom")
    dm = next(r for r in resp.json()["rooms"] if r["name"] == "dm:fathom+myra")
    assert dm["unread_count"] == 1


def test_dm_visible_to_both_participants(client):
    """dm:fathom+myra appears in room list for both fathom and myra."""
    c, db_path, _ = client
    c.post("/api/send/fathom", json={"message": "private", "from": "myra"})

    # Both participants see it
    resp = c.get("/api/room/list?workspace=fathom")
    names = [r["name"] for r in resp.json()["rooms"]]
    assert "dm:fathom+myra" in names

    resp = c.get("/api/room/list?workspace=myra")
    names = [r["name"] for r in resp.json()["rooms"]]
    assert "dm:fathom+myra" in names

    # Other workspace does not see it
    resp = c.get("/api/room/list?workspace=navier-stokes")
    names = [r["name"] for r in resp.json()["rooms"]]
    assert "dm:fathom+myra" not in names

    # No workspace param — virtual rooms excluded
    resp = c.get("/api/room/list")
    names = [r["name"] for r in resp.json()["rooms"]]
    assert "dm:fathom+myra" not in names


def test_dm_unread_uses_read_state(client):
    """DM unread tracks via read-state, not message_count."""
    c, db_path, _ = client
    c.post("/api/send/fathom", json={"message": "one", "from": "myra"})
    c.post("/api/send/fathom", json={"message": "two", "from": "myra"})

    # Mark read for fathom
    c.post("/api/room/dm:fathom+myra/read", json={"workspace": "fathom"})

    # Post one more
    c.post("/api/send/fathom", json={"message": "three", "from": "myra"})

    resp = c.get("/api/room/list?workspace=fathom")
    dm = next(r for r in resp.json()["rooms"] if r["name"] == "dm:fathom+myra")
    assert dm["unread_count"] == 1


def test_dm_sorted_pair_naming(client):
    """Sending from both directions creates the same room."""
    c, db_path, _ = client
    # myra → fathom
    resp1 = c.post("/api/send/fathom", json={"message": "hi", "from": "myra"})
    # fathom → myra
    resp2 = c.post("/api/send/myra", json={"message": "hey", "from": "fathom"})

    assert resp1.json()["room"] == "dm:fathom+myra"
    assert resp2.json()["room"] == "dm:fathom+myra"

    # Both messages in the same room
    con = sqlite3.connect(str(db_path))
    count = con.execute(
        "SELECT COUNT(*) FROM room_messages WHERE room = 'dm:fathom+myra'"
    ).fetchone()[0]
    con.close()
    assert count == 2


# ---------------------------------------------------------------------------
# Virtual rooms — Mentions (mentions:{workspace})
# ---------------------------------------------------------------------------


def test_dm_creates_mention_notification(client):
    """Sending a DM stores a notification in mentions:{recipient}."""
    c, db_path, _ = client
    resp = c.post("/api/send/fathom", json={"message": "hey fathom", "from": "myra"})
    assert resp.status_code == 200
    assert resp.json()["ok"] is True

    # Notification stored in mentions:fathom
    con = sqlite3.connect(str(db_path))
    row = con.execute(
        "SELECT sender, message FROM room_messages WHERE room = 'mentions:fathom'"
    ).fetchone()
    con.close()
    assert row is not None
    assert row[0] == "myra"
    assert "[DM from myra]" in row[1]
    assert "hey fathom" in row[1]


def test_mention_creates_notification(client):
    """@mention in a room post stores notification in mentions:{target}."""
    c, db_path, _ = client
    resp = c.post(
        "/api/room/general",
        json={"message": "hey @navier-stokes check this", "sender": "fathom"},
    )
    data = resp.json()
    assert data["ok"] is True
    assert "mentions" in data
    assert data["mentions"]["parsed"] == ["navier-stokes"]
    assert data["mentions"]["notified"][0]["workspace"] == "navier-stokes"
    assert data["mentions"]["notified"][0]["delivered"] is True

    # Notification stored in mentions:navier-stokes
    con = sqlite3.connect(str(db_path))
    row = con.execute(
        "SELECT * FROM room_messages WHERE room = 'mentions:navier-stokes'"
    ).fetchone()
    con.close()
    assert row is not None


def test_mention_persistent_on_read(client):
    """Reading mentions:{workspace} does NOT delete notifications — they persist."""
    c, db_path, _ = client
    c.post(
        "/api/room/general",
        json={"message": "@navier-stokes look", "sender": "fathom"},
    )

    # Read — notification returned
    resp = c.get("/api/room/mentions:navier-stokes?minutes=10080&workspace=navier-stokes")
    data = resp.json()
    assert data["count"] == 1
    assert "[#general]" in data["messages"][0]["message"]

    # Read again — still there (persistent)
    resp = c.get("/api/room/mentions:navier-stokes?minutes=10080&workspace=navier-stokes")
    data = resp.json()
    assert data["count"] == 1


def test_mention_visible_only_to_target(client):
    """mentions:navier-stokes visible only for navier-stokes workspace."""
    c, db_path, _ = client
    c.post(
        "/api/room/general",
        json={"message": "@navier-stokes hi", "sender": "fathom"},
    )

    # Target sees it
    resp = c.get("/api/room/list?workspace=navier-stokes")
    names = [r["name"] for r in resp.json()["rooms"]]
    assert "mentions:navier-stokes" in names

    # Other workspace does not
    resp = c.get("/api/room/list?workspace=fathom")
    names = [r["name"] for r in resp.json()["rooms"]]
    assert "mentions:navier-stokes" not in names


def test_original_message_preserved_after_mention_read(client):
    """Reading a mention notification doesn't affect the original room message."""
    c, db_path, _ = client
    c.post(
        "/api/room/dev",
        json={"message": "@navier-stokes review this", "sender": "fathom"},
    )

    # Read the mention notification
    c.get("/api/room/mentions:navier-stokes?minutes=10080&workspace=navier-stokes")

    # Original message in #dev is untouched
    resp = c.get("/api/room/dev?minutes=10080")
    data = resp.json()
    assert data["count"] == 1
    assert data["messages"][0]["message"] == "@navier-stokes review this"


def test_mention_unread_uses_read_state(client):
    """Mention room uses read-state tracking for unread counts."""
    c, db_path, _ = client
    c.post(
        "/api/room/general",
        json={"message": "@navier-stokes first", "sender": "fathom"},
    )

    # Mark read
    c.post("/api/room/mentions:navier-stokes/read", json={"workspace": "navier-stokes"})

    # Post another mention
    c.post(
        "/api/room/dev",
        json={"message": "@navier-stokes second", "sender": "fathom"},
    )

    # Unread should be 1 (only the new mention)
    resp = c.get("/api/room/list?workspace=navier-stokes")
    mentions = next(r for r in resp.json()["rooms"] if r["name"] == "mentions:navier-stokes")
    assert mentions["unread_count"] == 1


# ---------------------------------------------------------------------------
# DM access control — participant enforcement
# ---------------------------------------------------------------------------


def test_dm_post_rejected_for_non_participant(client):
    """Non-participant posting to a DM room gets 403."""
    c, db_path, _ = client
    # Seed the DM room first
    _seed_messages(db_path, "dm:fathom+myra", [("myra", "hello", time.time())])

    resp = c.post(
        "/api/room/dm:fathom+myra",
        json={"message": "intruder here", "sender": "trader-agent"},
    )
    assert resp.status_code == 403
    assert "access denied" in resp.json()["error"]


def test_dm_post_allowed_for_participant(client):
    """Participant posting to their DM room succeeds."""
    c, db_path, _ = client
    resp = c.post(
        "/api/room/dm:fathom+myra",
        json={"message": "hey myra", "sender": "fathom"},
    )
    assert resp.status_code == 200
    assert resp.json()["ok"] is True


def test_dm_read_rejected_for_non_participant(client):
    """Non-participant reading a DM room with workspace param gets 403."""
    c, db_path, _ = client
    _seed_messages(db_path, "dm:fathom+myra", [("myra", "private", time.time())])

    resp = c.get("/api/room/dm:fathom+myra?workspace=navier-stokes")
    assert resp.status_code == 403
    assert "access denied" in resp.json()["error"]


def test_dm_read_allowed_for_participant(client):
    """Participant reading their DM room succeeds."""
    c, db_path, _ = client
    _seed_messages(db_path, "dm:fathom+myra", [("myra", "private", time.time())])

    resp = c.get("/api/room/dm:fathom+myra?workspace=fathom")
    assert resp.status_code == 200
    assert resp.json()["count"] == 1


def test_dm_description_rejected_for_non_participant(client):
    """Non-participant setting DM room description gets 403."""
    c, db_path, _ = client
    resp = c.put(
        "/api/room/dm:fathom+myra/description",
        json={"description": "hacked", "sender": "navier-stokes"},
    )
    assert resp.status_code == 403
    assert "access denied" in resp.json()["error"]


def test_dm_mark_read_rejected_for_non_participant(client):
    """Non-participant marking DM room as read gets 403."""
    c, db_path, _ = client
    resp = c.post(
        "/api/room/dm:fathom+myra/read",
        json={"workspace": "navier-stokes"},
    )
    assert resp.status_code == 403
    assert "access denied" in resp.json()["error"]


def test_dm_no_mention_leakage(client):
    """@mention inside a DM room must NOT notify the mentioned workspace."""
    c, db_path, _ = client
    resp = c.post(
        "/api/room/dm:fathom+myra",
        json={"message": "hey @navier-stokes check this", "sender": "fathom"},
    )
    assert resp.status_code == 200
    data = resp.json()
    # No mentions key should appear — mentions are skipped for DM rooms
    assert "mentions" not in data

    # Verify no notification leaked to mentions:navier-stokes
    con = sqlite3.connect(str(db_path))
    row = con.execute(
        "SELECT COUNT(*) FROM room_messages WHERE room = 'mentions:navier-stokes'"
    ).fetchone()
    con.close()
    assert row[0] == 0


def test_mention_room_read_rejected_for_non_target(client):
    """Reading another workspace's mentions: room gets 403."""
    c, db_path, _ = client
    # Create a mention notification for navier-stokes
    c.post(
        "/api/room/general",
        json={"message": "@navier-stokes look", "sender": "fathom"},
    )

    # fathom tries to read navier-stokes's mentions — should be denied
    resp = c.get("/api/room/mentions:navier-stokes?workspace=fathom")
    assert resp.status_code == 403
    assert "access denied" in resp.json()["error"]
