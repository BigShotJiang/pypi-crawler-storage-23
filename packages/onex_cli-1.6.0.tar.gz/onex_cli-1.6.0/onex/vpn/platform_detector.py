"""
Platform detection and OS-specific command generation
"""

import platform
import subprocess
from typing import Optional


def detect_os() -> str:
    """
    Detect the current operating system

    Returns:
        'macos', 'linux', or 'windows'

    Raises:
        RuntimeError: If OS is not supported
    """
    system = platform.system().lower()

    if system == 'darwin':
        return 'macos'
    elif system == 'linux':
        return 'linux'
    elif system == 'windows':
        return 'windows'
    else:
        raise RuntimeError(f"Unsupported operating system: {system}")


def detect_linux_distro() -> Optional[str]:
    """
    Detect Linux distribution

    Returns:
        'debian', 'ubuntu', 'centos', 'rhel', 'fedora', or None
    """
    try:
        # Try reading /etc/os-release
        with open('/etc/os-release', 'r') as f:
            content = f.read().lower()

            if 'ubuntu' in content:
                return 'ubuntu'
            elif 'debian' in content:
                return 'debian'
            elif 'centos' in content:
                return 'centos'
            elif 'red hat' in content or 'rhel' in content:
                return 'rhel'
            elif 'fedora' in content:
                return 'fedora'
    except:
        pass

    return None


def detect_environment_from_ip(vpn_ip: str) -> str:
    """
    Detect environment from VPN IP address

    NOTE: IP ranges below are EXAMPLES and can be customized for your deployment.
    These are the default OneXEOS platform IP assignments:
    - 10.0.0.x = dev environment
    - 10.0.1.x = staging environment
    - 10.0.2.x = prod environment

    You can override these by configuring different IP ranges in your VPN setup.

    Args:
        vpn_ip: VPN IP address (e.g., '10.0.0.100')

    Returns:
        'dev', 'staging', 'prod', or 'local'
    """
    if vpn_ip.startswith('10.0.0.'):
        return 'dev'
    elif vpn_ip.startswith('10.0.1.'):
        return 'staging'
    elif vpn_ip.startswith('10.0.2.'):
        return 'prod'
    elif vpn_ip.startswith('127.0.0.') or vpn_ip.startswith('localhost'):
        return 'local'
    else:
        # Default to dev if unknown
        return 'dev'


def get_gateway_ip(vpn_ip: str) -> str:
    """
    Get gateway IP from VPN IP

    NOTE: Assumes gateway is always .1 in the subnet (e.g., 10.0.0.1).
    This is a common convention but can be customized in your VPN configuration.

    Args:
        vpn_ip: VPN IP address (e.g., '10.0.0.100')

    Returns:
        Gateway IP (e.g., '10.0.0.1')
    """
    parts = vpn_ip.split('.')
    if len(parts) == 4:
        parts[-1] = '1'
        return '.'.join(parts)
    return vpn_ip


def get_platform_url(gateway_ip: str) -> str:
    """
    Get platform URL from gateway IP

    NOTE: Assumes platform runs on port 8000.
    Override with PLATFORM_URL environment variable if using a different port or domain.

    Args:
        gateway_ip: Gateway IP address (e.g., '10.0.0.1')

    Returns:
        Platform URL (e.g., 'http://10.0.0.1:8000')
    """
    return f"http://{gateway_ip}:8000"


def get_install_command() -> str:
    """
    Get WireGuard installation command for current OS

    Returns:
        Installation command string
    """
    os_type = detect_os()

    if os_type == 'macos':
        return 'brew install wireguard-tools'

    elif os_type == 'linux':
        distro = detect_linux_distro()

        if distro in ['ubuntu', 'debian']:
            return 'sudo apt update && sudo apt install -y wireguard wireguard-tools'
        elif distro in ['centos', 'rhel']:
            return 'sudo yum install -y epel-release && sudo yum install -y wireguard-tools'
        elif distro == 'fedora':
            return 'sudo dnf install -y wireguard-tools'
        else:
            return 'sudo apt install -y wireguard wireguard-tools  # or use your package manager'

    elif os_type == 'windows':
        return 'Download from: https://www.wireguard.com/install/'

    return 'Unknown installation command'


def get_config_directory() -> str:
    """
    Get WireGuard configuration directory for current OS

    Returns:
        Configuration directory path
    """
    os_type = detect_os()

    if os_type == 'macos':
        # Detect Homebrew prefix (Apple Silicon vs Intel)
        # Apple Silicon (M1/M2): /opt/homebrew
        # Intel: /usr/local
        try:
            result = subprocess.run(
                ['brew', '--prefix'],
                capture_output=True,
                text=True,
                timeout=5
            )
            if result.returncode == 0:
                brew_prefix = result.stdout.strip()
                return f'{brew_prefix}/etc/wireguard'
        except:
            pass

        # Fallback to /usr/local if brew command fails
        return '/usr/local/etc/wireguard'

    elif os_type == 'linux':
        return '/etc/wireguard'
    elif os_type == 'windows':
        return 'C:\\Program Files\\WireGuard'

    return '/etc/wireguard'


def get_connect_command(interface_name: str) -> str:
    """
    Get command to connect to VPN

    Args:
        interface_name: WireGuard interface name (e.g., 'wg-onex-dev')

    Returns:
        Connect command string
    """
    os_type = detect_os()

    if os_type == 'macos':
        return f'sudo wg-quick up {interface_name}'
    elif os_type == 'linux':
        return f'sudo systemctl start wg-quick@{interface_name}'
    elif os_type == 'windows':
        return f'Start WireGuard GUI and activate "{interface_name}" tunnel'

    return f'wg-quick up {interface_name}'


def get_disconnect_command(interface_name: str) -> str:
    """
    Get command to disconnect from VPN

    Args:
        interface_name: WireGuard interface name (e.g., 'wg-onex-dev')

    Returns:
        Disconnect command string
    """
    os_type = detect_os()

    if os_type == 'macos':
        return f'sudo wg-quick down {interface_name}'
    elif os_type == 'linux':
        return f'sudo systemctl stop wg-quick@{interface_name}'
    elif os_type == 'windows':
        return f'Stop WireGuard GUI tunnel "{interface_name}"'

    return f'wg-quick down {interface_name}'


def get_status_command(interface_name: str) -> str:
    """
    Get command to check VPN status

    Args:
        interface_name: WireGuard interface name (e.g., 'wg-onex-dev')

    Returns:
        Status command string
    """
    return f'sudo wg show {interface_name}'


def check_wireguard_installed() -> bool:
    """
    Check if WireGuard is installed

    Returns:
        True if installed, False otherwise
    """
    try:
        result = subprocess.run(
            ['which', 'wg'],
            capture_output=True,
            text=True,
            timeout=5
        )
        return result.returncode == 0
    except:
        return False


def check_homebrew_installed() -> bool:
    """
    Check if Homebrew is installed (macOS only)

    Returns:
        True if installed, False otherwise
    """
    try:
        result = subprocess.run(
            ['which', 'brew'],
            capture_output=True,
            text=True,
            timeout=5
        )
        return result.returncode == 0
    except:
        return False
