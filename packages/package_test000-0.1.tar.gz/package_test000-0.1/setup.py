from setuptools import setup, find_packages

setup(
    name='package_test000',                    # Your package name
    version='0.1',                        # Version number
    packages=find_packages(),             # Automatically find packages
    install_requires=[],                  # List dependencies if any
    author='TanvirAfzal',                   # Your name
    author_email='tanvir.afza@gmail.com',# Your email
    description='A brief description of your package',
    url='https://github.com/MuhammadTanvirAfzal/my_package', # Your project URL
)
