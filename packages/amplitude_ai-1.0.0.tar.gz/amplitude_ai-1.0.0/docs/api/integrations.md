# Framework Integrations

Integrations with popular LLM frameworks that automatically track Agent events.

## LangChain

Callback handler for LangChain that tracks LLM calls, tool invocations, and chain runs.

```python
from amplitude import Amplitude
from amplitude_ai.integrations.langchain import AmplitudeCallbackHandler

amplitude = Amplitude("YOUR_API_KEY")
callback = AmplitudeCallbackHandler(
    amplitude=amplitude,
    user_id="user-1",
    conversation_id="sess-abc",
)

# Use with any LangChain component
from langchain_openai import ChatOpenAI
llm = ChatOpenAI(model="gpt-4o", callbacks=[callback])
response = llm.invoke("Hello!")
```

::: amplitude_ai.integrations.langchain.AmplitudeCallbackHandler

::: amplitude_ai.integrations.langchain.create_amplitude_callback

## OpenTelemetry

Span exporter that converts Amplitude AI events into OpenTelemetry spans.

```python
from amplitude_ai import AmplitudeSpanExporter

exporter = AmplitudeSpanExporter(tracer_name="amplitude-ai")

# Use as a callback-based exporter:
# exporter.record_event(event) converts Amplitude events to OTel spans
```

::: amplitude_ai.integrations.opentelemetry.AmplitudeSpanExporter

## LlamaIndex

Callback handler for LlamaIndex that tracks queries, retrievals, and LLM calls.

```python
from amplitude import Amplitude
from amplitude_ai.integrations.llamaindex import AmplitudeLlamaIndexHandler

amplitude = Amplitude("YOUR_API_KEY")
handler = AmplitudeLlamaIndexHandler(
    amplitude=amplitude,
    user_id="user-1",
    session_id="sess-abc",
)

# Use with LlamaIndex
from llama_index.core import Settings
from llama_index.core.callbacks import CallbackManager
Settings.callback_manager = CallbackManager([handler])
```

::: amplitude_ai.integrations.llamaindex.AmplitudeLlamaIndexHandler

::: amplitude_ai.integrations.llamaindex.create_amplitude_llamaindex_handler

## OpenAI Agents SDK

Tracing processor that plugs into the OpenAI Agents SDK tracing system. Maps spans to Amplitude Agent events:

- `GenerationSpanData` -> `[Agent] User Message` + `[Agent] AI Response`
- `FunctionSpanData` -> `[Agent] Tool Call`
- `AgentSpanData` -> `[Agent] Span` (agent lifecycle)
- `HandoffSpanData` -> `[Agent] Span` (handoff between agents)
- `GuardrailSpanData` -> `[Agent] Span` (guardrail check)

```python
from agents import Agent, Runner, RunConfig
from amplitude import Amplitude
from amplitude_ai.integrations.openai_agents import AmplitudeTracingProcessor

amplitude = Amplitude("YOUR_API_KEY")
processor = AmplitudeTracingProcessor(
    amplitude=amplitude,
    user_id="user-1",
    agent_id="my-agent",
)

agent = Agent(name="support-bot", instructions="You are helpful.")
result = Runner.run_sync(
    agent, "Hello!",
    run_config=RunConfig(tracing_processors=[processor]),
)
```

::: amplitude_ai.integrations.openai_agents.AmplitudeTracingProcessor

## Anthropic Tool Use Loop

Managed multi-turn tool_use loop for Anthropic's agentic pattern. Handles repeated `tool_use` -> `tool_result` cycles with automatic Amplitude tracking.

```python
from anthropic import Anthropic
from amplitude import Amplitude
from amplitude_ai.integrations.anthropic_tools import AmplitudeToolLoop

amplitude = Amplitude("YOUR_API_KEY")
client = Anthropic()

loop = AmplitudeToolLoop(
    amplitude=amplitude,
    client=client,
    user_id="user-1",
    tool_handlers={"get_weather": lambda city: f"72F in {city}"},
)

result = loop.run(
    model="claude-sonnet-4-20250514",
    messages=[{"role": "user", "content": "Weather in SF?"}],
    tools=[...],
)
```

::: amplitude_ai.integrations.anthropic_tools.AmplitudeToolLoop

## CrewAI

Event listener hooks for CrewAI that capture LLM calls and tool usage across multi-agent crews.

```python
from crewai import Crew, Agent, Task
from amplitude import Amplitude
from amplitude_ai.integrations.crewai import AmplitudeCrewAIHooks

amplitude = Amplitude("YOUR_API_KEY")

with AmplitudeCrewAIHooks(amplitude=amplitude, user_id="user-1") as hooks:
    crew = Crew(agents=[...], tasks=[...])
    result = crew.kickoff()
```

::: amplitude_ai.integrations.crewai.AmplitudeCrewAIHooks
