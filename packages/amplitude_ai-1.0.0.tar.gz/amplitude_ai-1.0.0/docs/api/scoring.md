# Scoring

General-purpose evaluation and annotation primitive for attaching quality signals to messages or sessions.

Scoring covers three main use cases:

- **User feedback** — thumbs up/down, star ratings
- **Automated evals** — model-graded or rule-based quality scores
- **Human annotations** — expert reviews and labeling

## Client Method

The primary way to track scores is via [`AmplitudeAI.score()`](client.md):

```python
ai.score(
    user_id="user-1",
    name="user-feedback",
    value=1.0,                     # 1 = thumbs up, 0 = thumbs down
    target_id="msg-abc-123",
    target_type="message",
    source="user",
    comment="Very helpful answer!",
    session_id="sess-abc",
)
```

## Score Naming Conventions

| Use Case            | `name`            | `value`       | `source`      |
| ------------------- | ----------------- | ------------- | ------------- |
| Thumbs up/down      | `"user-feedback"` | `1.0` / `0.0` | `"user"`      |
| Star rating         | `"user-rating"`   | `1.0` - `5.0` | `"user"`      |
| LLM-as-judge        | `"accuracy"`      | `0.0` - `1.0` | `"ai"`        |
| Hallucination check | `"groundedness"`  | `0.0` - `1.0` | `"ai"`        |
| Expert review       | `"quality"`       | `1.0` - `5.0` | `"reviewer"`  |

## Lower-Level Function

::: amplitude_ai.core.tracking.track_score
