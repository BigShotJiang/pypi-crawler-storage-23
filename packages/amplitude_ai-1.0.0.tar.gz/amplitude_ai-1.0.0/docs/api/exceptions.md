# Exceptions

Custom exception hierarchy for the Amplitude AI SDK. All exceptions inherit from `AmplitudeAIError`.

```
AmplitudeAIError
├── ConfigurationError    # Invalid SDK configuration
├── TrackingError         # Event tracking failures
└── ProviderError         # Provider wrapper errors
```

## AmplitudeAIError

::: amplitude_ai.exceptions.AmplitudeAIError

## ConfigurationError

::: amplitude_ai.exceptions.ConfigurationError

## TrackingError

::: amplitude_ai.exceptions.TrackingError

## ProviderError

::: amplitude_ai.exceptions.ProviderError
