# Constants

Event type and property name constants used throughout the SDK. These are useful for asserting on events in tests or building custom integrations.

## Event Types

| Constant | Value |
|---|---|
| `EVENT_USER_MESSAGE` | `[Agent] User Message` |
| `EVENT_AI_RESPONSE` | `[Agent] AI Response` |
| `EVENT_TOOL_CALL` | `[Agent] Tool Call` |
| `EVENT_EMBEDDING` | `[Agent] Embedding` |
| `EVENT_SPAN` | `[Agent] Span` |
| `EVENT_SESSION_END` | `[Agent] Session End` |
| `EVENT_SESSION_ENRICHMENT` | `[Agent] Session Enrichment` |
| `EVENT_SCORE` | `[Agent] Score` |

## Property Names

### Identity & Session

| Constant | Value |
|---|---|
| `PROP_SESSION_ID` | `[Agent] Session ID` |
| `PROP_MESSAGE_ID` | `[Agent] Message ID` |
| `PROP_TURN_ID` | `[Agent] Turn ID` |
| `PROP_AGENT_ID` | `[Agent] Agent ID` |
| `PROP_AGENT_VERSION` | `[Agent] Agent Version` |
| `PROP_INVOCATION_ID` | `[Agent] Invocation ID` |
| `PROP_SDK_VERSION` | `[Agent] SDK Version` |

### Model & Provider

| Constant | Value |
|---|---|
| `PROP_MODEL_NAME` | `[Agent] Model Name` |
| `PROP_PROVIDER` | `[Agent] Provider` |
| `PROP_COMPONENT_TYPE` | `[Agent] Component Type` |
| `PROP_RUNTIME` | `[Agent] Runtime` |
| `PROP_ENV` | `[Agent] Env` |
| `PROP_LOCALE` | `[Agent] Locale` |

### Tokens & Cost

| Constant | Value |
|---|---|
| `PROP_INPUT_TOKENS` | `[Agent] Input Tokens` |
| `PROP_OUTPUT_TOKENS` | `[Agent] Output Tokens` |
| `PROP_TOTAL_TOKENS` | `[Agent] Total Tokens` |
| `PROP_REASONING_TOKENS` | `[Agent] Reasoning Tokens` |
| `PROP_CACHE_READ_TOKENS` | `[Agent] Cache Read Tokens` |
| `PROP_CACHE_CREATION_TOKENS` | `[Agent] Cache Creation Tokens` |
| `PROP_COST_USD` | `[Agent] Cost USD` |

### Performance

| Constant | Value |
|---|---|
| `PROP_LATENCY_MS` | `[Agent] Latency Ms` |
| `PROP_TTFB_MS` | `[Agent] TTFB Ms` |

### Content & Reasoning

| Constant | Value |
|---|---|
| `PROP_REASONING_CONTENT` | `[Agent] Reasoning Content` |
| `PROP_HAS_REASONING` | `[Agent] Has Reasoning` |
| `PROP_FINISH_REASON` | `[Agent] Finish Reason` |

### Tools

| Constant | Value |
|---|---|
| `PROP_TOOL_NAME` | `[Agent] Tool Name` |
| `PROP_TOOL_SUCCESS` | `[Agent] Tool Success` |
| `PROP_TOOL_INPUT` | `[Agent] Tool Input` |
| `PROP_TOOL_OUTPUT` | `[Agent] Tool Output` |
| `PROP_TOOL_CALLS` | `[Agent] Tool Calls` |
| `PROP_PARENT_MESSAGE_ID` | `[Agent] Parent Message ID` |

### Scoring

| Constant | Value |
|---|---|
| `PROP_SCORE_NAME` | `[Agent] Score Name` |
| `PROP_SCORE_VALUE` | `[Agent] Score Value` |
| `PROP_EVALUATION_SOURCE` | `[Agent] Evaluation Source` |
| `PROP_TARGET_ID` | `[Agent] Target ID` |
| `PROP_TARGET_TYPE` | `[Agent] Target Type` |
| `PROP_COMMENT` | `[Agent] Comment` |

### Spans

| Constant | Value |
|---|---|
| `PROP_SPAN_ID` | `[Agent] Span ID` |
| `PROP_SPAN_NAME` | `[Agent] Span Name` |
| `PROP_SPAN_KIND` | `[Agent] Span Kind` |
| `PROP_TRACE_ID` | `[Agent] Trace ID` |
| `PROP_PARENT_SPAN_ID` | `[Agent] Parent Span ID` |
| `PROP_IS_ERROR` | `[Agent] Is Error` |
| `PROP_ERROR_MESSAGE` | `[Agent] Error Message` |
| `PROP_INPUT_STATE` | `[Agent] Input State` |
| `PROP_OUTPUT_STATE` | `[Agent] Output State` |

### Embeddings

| Constant | Value |
|---|---|
| `PROP_EMBEDDING_DIMENSIONS` | `[Agent] Embedding Dimensions` |

### Model Configuration

| Constant | Value |
|---|---|
| `PROP_SYSTEM_PROMPT` | `[Agent] System Prompt` |
| `PROP_SYSTEM_PROMPT_LENGTH` | `[Agent] System Prompt Length` |
| `PROP_TEMPERATURE` | `[Agent] Temperature` |
| `PROP_MAX_OUTPUT_TOKENS` | `[Agent] Max Output Tokens` |
| `PROP_TOP_P` | `[Agent] Top P` |
| `PROP_IS_STREAMING` | `[Agent] Is Streaming` |
| `PROP_PROMPT_ID` | `[Agent] Prompt ID` |

### Enrichments

| Constant | Value |
|---|---|
| `PROP_ENRICHMENTS` | `[Agent] Enrichments` |
