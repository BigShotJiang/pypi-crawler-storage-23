# Tracking Functions

Lower-level tracking functions for direct use without the `AmplitudeAI` client. These are the same functions that the client delegates to internally, and that Langley uses for internal instrumentation.

!!! note "Prefer the client API"
Most users should use [`AmplitudeAI`](client.md) methods instead of calling these functions directly. These are useful for advanced integrations that need direct access to the `Amplitude` instance.

## track_user_message

::: amplitude_ai.core.tracking.track_user_message

## track_ai_message

::: amplitude_ai.core.tracking.track_ai_message

## track_tool_call

::: amplitude_ai.core.tracking.track_tool_call

## track_embedding

::: amplitude_ai.core.tracking.track_embedding

## track_span

::: amplitude_ai.core.tracking.track_span

## track_session_end

::: amplitude_ai.core.tracking.track_session_end

## track_session_enrichment

::: amplitude_ai.core.tracking.track_session_enrichment

## track_score

::: amplitude_ai.core.tracking.track_score

## track_conversation

::: amplitude_ai.core.tracking.track_conversation
