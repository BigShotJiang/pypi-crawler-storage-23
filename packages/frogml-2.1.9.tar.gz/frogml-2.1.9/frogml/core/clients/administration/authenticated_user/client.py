from dependency_injector.wiring import Provide

from frogml._proto.qwak.administration.authenticated_user.v1.authenticated_user_service_pb2 import (
    GetCloudCredentialsRequest,
    GetCloudCredentialsResponse,
    GetDetailsRequest,
    GetDetailsResponse,
)
from frogml._proto.qwak.administration.authenticated_user.v1.authenticated_user_service_pb2_grpc import (
    AuthenticatedUserStub,
)
from frogml.core.inner.di_configuration import FrogmlContainer
from frogml.core.inner.tool.grpc.grpc_try_wrapping import grpc_try_catch_wrapper


class AuthenticatedUserClient:
    """
    Used for interacting with JFrog ML Authenticated User service
    """

    def __init__(self, grpc_channel=Provide[FrogmlContainer.core_grpc_channel]):
        self._authenticated_user = AuthenticatedUserStub(grpc_channel)

    @grpc_try_catch_wrapper(
        error_message="Failed to get authenticated user details",
        operation="Get User Details",
    )
    def get_details(self) -> GetDetailsResponse:
        request = GetDetailsRequest()
        return self._authenticated_user.GetDetails(request)

    @grpc_try_catch_wrapper(
        error_message="Failed to get cloud credentials",
        operation="Get Cloud Credentials",
    )
    def get_cloud_credentials(self) -> GetCloudCredentialsResponse:
        request = GetCloudCredentialsRequest()
        return self._authenticated_user.GetCloudCredentials(request)
