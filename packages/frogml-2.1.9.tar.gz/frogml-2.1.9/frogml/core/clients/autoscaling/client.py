from dependency_injector.wiring import Provide

from frogml._proto.qwak.auto_scaling.v1.auto_scaling_pb2 import AutoScalingConfig
from frogml._proto.qwak.auto_scaling.v1.auto_scaling_service_pb2 import (
    AttachAutoScalingRequest,
    AttachAutoScalingResponse,
)
from frogml._proto.qwak.auto_scaling.v1.auto_scaling_service_pb2_grpc import (
    AutoScalingServiceStub,
)
from frogml.core.inner.di_configuration import FrogmlContainer
from frogml.core.inner.tool.grpc.grpc_try_wrapping import grpc_try_catch_wrapper


class AutoScalingClient:
    def __init__(self, grpc_channel=Provide[FrogmlContainer.core_grpc_channel]):
        self._deployment_management = AutoScalingServiceStub(grpc_channel)

    @grpc_try_catch_wrapper(
        error_message="Failed to attach autoscaling",
        operation="Attach Autoscaling",
    )
    def attach_autoscaling(
        self, model_id: str, variation_name: str, auto_scaling_config: AutoScalingConfig
    ) -> AttachAutoScalingResponse:
        return self._deployment_management.AttachAutoScaling(
            AttachAutoScalingRequest(
                model_id=model_id,
                variation_name=variation_name,
                auto_scaling_config=auto_scaling_config,
            )
        )
