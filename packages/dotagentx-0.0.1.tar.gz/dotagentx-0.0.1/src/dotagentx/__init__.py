"""dotagentx package exports."""

from dotagentx.cli import main

__all__ = ["main"]
