"""Typed exception hierarchy for CLI-facing failures."""

from __future__ import annotations


class dotagentxError(Exception):
    """Base error for recoverable dotagentx failures."""

    exit_code: int = 1


class UsageError(dotagentxError):
    """Invalid flags, arguments, or command usage."""

    exit_code = 2


class ConfigNotFoundError(dotagentxError):
    """Requested agent config does not exist."""

    exit_code = 3


class ValidationFailureError(dotagentxError):
    """Config payload or schema validation failed."""

    exit_code = 4


class StorageError(dotagentxError):
    """Reading or writing config storage failed."""

    exit_code = 5
