"""Project Net Zero - Optimize your Python code for lower CO2 emissions."""

__version__ = "0.3.0"
