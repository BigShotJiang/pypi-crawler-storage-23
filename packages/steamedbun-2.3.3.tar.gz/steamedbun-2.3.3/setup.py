"""
@Author: 馒头 (chocolate)
@Email: neihanshenshou@163.com
@File: setup.py
@Time: 2025/01/23 23:36
"""

import os

from setuptools import find_packages, setup

__version__ = "2.3.3"


def read_readme():
    return open("README.md", "r", encoding="utf-8").read() if os.path.exists("README.md") else ""


install_requires = [
    "allure-pytest==2.15.3",
    "colorama==0.4.6",
    "openpyxl==3.1.0",
    "playwright==1.44.0",
    "pymysql==1.1.1",
    "python-dateutil==2.8.2",
    "pytest-repeat~=0.9.3",
    "PyYAML==6.0.3",
    "requests==2.30.0",
    "retry==0.9.2",
    "urllib3==1.26.12",
    # 3.7专属
    "numpy<1.25.0; python_version == '3.7'",
    "pandas<1.5.0; python_version == '3.7'",
    "Pillow<10.0.0; python_version == '3.7'",
    "pytest<7.0.0; python_version == '3.7'",
    "pytest-ordering==0.6; python_version == '3.7'",
    "pytest-xdist<3.0.0; python_version == '3.7'",
    "pytest-cov<4.0.0; python_version == '3.7'",
    "selenium<4.10.0; python_version == '3.7'",
    "setuptools>=60.2.0,<60.0.0; python_version == '3.7'",
    # 3.8~3.11专属
    "numpy>=1.24.0,<1.27.0; python_version >= '3.8' and python_version < '3.12'",
    "pandas>=2.0.3,<2.1.0; python_version >= '3.8' and python_version < '3.12'",
    "Pillow>=9.5.0,<10.3.0; python_version >= '3.8' and python_version < '3.12'",
    "pytest>=7.3.2,<8.0.0; python_version >= '3.8' and python_version < '3.12'",
    "pytest-order==1.1.0; python_version >= '3.8' and python_version < '3.12'",
    "pytest-xdist>=3.5.0,<3.7.0; python_version >= '3.8' and python_version < '3.12'",
    "pytest-cov>=4.0.0,<4.2.0; python_version >= '3.8' and python_version < '3.12'",
    "selenium>=4.4.3,<4.15.0; python_version >= '3.8' and python_version < '3.12'",
    "setuptools>=60.2.0,<69.0.0; python_version >= '3.8' and python_version < '3.12'",
    "setuptools>=62.0.0,<68.0.0; python_version == '3.9'",

    # 3.12+专属
    "numpy>=1.27.0; python_version >= '3.12'",
    "pandas>=2.1.0; python_version >= '3.12'",
    "Pillow>=10.3.0; python_version >= '3.12'",
    "pytest>=8.0.0; python_version >= '3.12'",
    "pytest-order==1.1.0; python_version >= '3.12'",
    "pytest-xdist>=3.7.0; python_version >= '3.12'",
    "pytest-cov>=4.2.0; python_version >= '3.12'",
    "selenium>=4.15.0; python_version >= '3.12'",
    "setuptools>=69.0.0; python_version >= '3.12'",
]

setup(
    name="steamedbun",
    version=__version__,
    author="馒头",
    author_email="neihanshenshou@163.com",
    description="馒头的第三方库",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    include_package_data=True,
    # 这里用包名作为键，符合所有版本规范
    package_data={"SteamedBun": ["font/song.ttc", "browser_session.yaml", "config.ini"]},
    install_requires=install_requires,
    license="Apache License 2.0",
    license_file="LICENSE" if os.path.exists("LICENSE") else None,
    platforms=["MacOS", "Windows"],
    url="https://github.com/neihanshenshou/SteamedBun",
    python_requires=">=3.7,<3.17",
    entry_points={
        "console_scripts": [
            "cpt=SteamedBun._FileTools.InitPytestProject:create_project_tool",
            "SteamedBun=SteamedBun._TipProject:tip",
            "sb=SteamedBun._TipProject:tip",
        ]
    },
    classifiers=[
        "Operating System :: MacOS",
        "Operating System :: Microsoft :: Windows",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ]
)
