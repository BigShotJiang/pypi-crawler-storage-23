"""Run exchanger as python -m exchanger."""

from .cli import main

if __name__ == "__main__":
    main()
