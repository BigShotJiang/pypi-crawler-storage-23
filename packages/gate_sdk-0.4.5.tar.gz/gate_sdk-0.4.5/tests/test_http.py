"""
Unit tests for gate_sdk.http (HttpClient).
"""

import os
import pytest
import httpx
import respx
from gate_sdk.http import HttpClient
from gate_sdk.errors import (
    GateAuthError,
    GateForbiddenError,
    GateNotFoundError,
    GateRateLimitError,
    GateServerError,
    GateTimeoutError,
    GateNetworkError,
    GateInvalidResponseError,
)


BASE_URL = "https://api.test.example.com"


@pytest.fixture
def http_client():
    """HttpClient with test base URL (no NODE_ENV=production so HTTP would be allowed elsewhere)."""
    return HttpClient(
        base_url=BASE_URL,
        timeout_ms=5000,
        max_attempts=2,
        base_delay_ms=1,
        max_delay_ms=5,
    )


@respx.mock
def test_request_success(http_client):
    respx.post(f"{BASE_URL}/defense/evaluate").mock(
        return_value=httpx.Response(200, json={"success": True, "decision": "ALLOW"})
    )
    result = http_client.request("POST", "/defense/evaluate", body={"key": "value"})
    assert result["success"] is True
    assert result["decision"] == "ALLOW"


@respx.mock
def test_request_401_raises_auth_error(http_client):
    respx.post(f"{BASE_URL}/defense/evaluate").mock(
        return_value=httpx.Response(401, json={"error": "Unauthorized"})
    )
    with pytest.raises(GateAuthError) as exc_info:
        http_client.request("POST", "/defense/evaluate", body={})
    assert "Authentication" in str(exc_info.value) or "401" in str(exc_info.value)


@respx.mock
def test_request_403_raises_forbidden_error(http_client):
    respx.post(f"{BASE_URL}/defense/evaluate").mock(
        return_value=httpx.Response(
            403,
            json={"success": False, "error": {"code": "FORBIDDEN", "message": "Policy denied"}},
        )
    )
    with pytest.raises(GateForbiddenError) as exc_info:
        http_client.request("POST", "/defense/evaluate", body={})
    assert exc_info.value.code == "FORBIDDEN"


@respx.mock
def test_request_404_raises_not_found_error(http_client):
    respx.post(f"{BASE_URL}/defense/evaluate").mock(
        return_value=httpx.Response(404, json={"error": "Not found"})
    )
    with pytest.raises(GateNotFoundError):
        http_client.request("POST", "/defense/evaluate", body={})


@respx.mock
def test_request_429_raises_rate_limit_error(http_client):
    respx.post(f"{BASE_URL}/defense/evaluate").mock(
        return_value=httpx.Response(
            429,
            headers={"Retry-After": "60"},
            json={"error": "Too many requests"},
        )
    )
    with pytest.raises(GateRateLimitError) as exc_info:
        http_client.request("POST", "/defense/evaluate", body={})
    assert exc_info.value.retry_after == 60


@respx.mock
def test_request_429_invalid_retry_after_header(http_client):
    respx.post(f"{BASE_URL}/defense/evaluate").mock(
        return_value=httpx.Response(
            429,
            headers={"Retry-After": "not-a-number"},
            json={},
        )
    )
    with pytest.raises(GateRateLimitError) as exc_info:
        http_client.request("POST", "/defense/evaluate", body={})
    assert exc_info.value.retry_after is None


@respx.mock
def test_request_500_raises_server_error(http_client):
    respx.post(f"{BASE_URL}/defense/evaluate").mock(
        return_value=httpx.Response(500, json={"error": "Internal error"})
    )
    with pytest.raises(GateServerError) as exc_info:
        http_client.request("POST", "/defense/evaluate", body={})
    assert exc_info.value.status_code == 500


@respx.mock
def test_request_timeout_raises_timeout_error(http_client):
    respx.post(f"{BASE_URL}/defense/evaluate").mock(
        side_effect=httpx.TimeoutException("timeout")
    )
    with pytest.raises(GateTimeoutError):
        http_client.request("POST", "/defense/evaluate", body={})


@respx.mock
def test_request_network_error_raises_network_error(http_client):
    respx.post(f"{BASE_URL}/defense/evaluate").mock(
        side_effect=httpx.NetworkError("connection failed")
    )
    with pytest.raises(GateNetworkError):
        http_client.request("POST", "/defense/evaluate", body={})


@respx.mock
def test_request_403_unparseable_json_raises_forbidden_with_snippet(http_client):
    respx.post(f"{BASE_URL}/defense/evaluate").mock(
        return_value=httpx.Response(403, text="not json at all")
    )
    with pytest.raises(GateForbiddenError) as exc_info:
        http_client.request("POST", "/defense/evaluate", body={})
    assert "body_snippet" in (exc_info.value.details or {})


@respx.mock
def test_request_success_with_request_id(http_client):
    respx.post(f"{BASE_URL}/defense/evaluate").mock(
        return_value=httpx.Response(200, json={"ok": True})
    )
    result = http_client.request(
        "POST", "/defense/evaluate", body={}, request_id="req-123"
    )
    assert result["ok"] is True


@respx.mock
def test_403_extracts_error_from_nested_and_top_level(http_client):
    respx.post(f"{BASE_URL}/defense/evaluate").mock(
        return_value=httpx.Response(
            403,
            json={
                "error": {"code": "HEARTBEAT_INVALID", "message": "Bad heartbeat"},
                "message": "fallback",
            },
        )
    )
    with pytest.raises(GateForbiddenError) as exc_info:
        http_client.request("POST", "/defense/evaluate", body={})
    assert exc_info.value.code == "HEARTBEAT_INVALID"


def test_http_client_rejects_http_in_production():
    with pytest.raises(ValueError, match="HTTPS"):
        with _env("NODE_ENV", "production"):
            HttpClient(base_url="http://evil.example.com", timeout_ms=5000)


def test_http_client_allows_http_localhost():
    with _env("NODE_ENV", "production"):
        client = HttpClient(base_url="http://localhost:3000", timeout_ms=5000)
    assert client.base_url == "http://localhost:3000"


class _env:
    def __init__(self, key: str, value: str):
        self.key = key
        self.value = value
        self._prev = None

    def __enter__(self):
        self._prev = os.environ.get(self.key)
        os.environ[self.key] = self.value
        return self

    def __exit__(self, *args):
        if self._prev is None:
            os.environ.pop(self.key, None)
        else:
            os.environ[self.key] = self._prev
        return False
