"""Tests for Gate receipt verifier (matches receipt-spec and hot path signing)."""

import base64
import hmac
import hashlib
import json
import pytest
from gate_sdk.receipt_verifier import (
    verify_receipt_signature,
    verify_receipt,
    RECEIPT_SIGNATURE_PREFIX,
)


def _sign_payload(payload: dict, secret: str) -> str:
    """Same canonical + HMAC as hot path."""
    canonical = json.dumps(payload, separators=(",", ":"), sort_keys=True)
    sig = hmac.new(secret.encode("utf-8"), canonical.encode("utf-8"), hashlib.sha256).digest()
    return RECEIPT_SIGNATURE_PREFIX + base64.b64encode(sig).decode("ascii")


PAYLOAD = {
    "requestId": "req-1",
    "decision": "ALLOW",
    "txDigest": "abc123",
    "policyHash": "snap_xyz",
    "timestamp": "2025-02-13T12:00:00.000Z",
    "tenantId": "tenant-1",
}
SECRET = "test-hmac-secret"


def test_verify_receipt_signature_valid():
    sig = _sign_payload(PAYLOAD, SECRET)
    assert verify_receipt_signature(PAYLOAD, sig, SECRET) is True


def test_verify_receipt_signature_wrong_secret():
    sig = _sign_payload(PAYLOAD, SECRET)
    assert verify_receipt_signature(PAYLOAD, sig, "wrong-secret") is False


def test_verify_receipt_signature_tampered():
    sig = _sign_payload(PAYLOAD, SECRET)
    tampered = {**PAYLOAD, "decision": "BLOCK"}
    assert verify_receipt_signature(tampered, sig, SECRET) is False


def test_verify_receipt_from_full():
    sig = _sign_payload(PAYLOAD, SECRET)
    full = {
        "request_id": PAYLOAD["requestId"],
        "tenant_id": PAYLOAD["tenantId"],
        "decision": PAYLOAD["decision"],
        "policy_snapshot_id": PAYLOAD["policyHash"],
        "timestamp": PAYLOAD["timestamp"],
        "txDigest": PAYLOAD["txDigest"],
    }
    valid, _ = verify_receipt(full, sig, SECRET)
    assert valid is True


def test_verify_receipt_invalid():
    valid, _ = verify_receipt(PAYLOAD, "HS256:invalid", SECRET)
    assert valid is False
