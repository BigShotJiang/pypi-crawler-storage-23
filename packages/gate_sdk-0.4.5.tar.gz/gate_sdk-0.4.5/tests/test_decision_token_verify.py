"""
Unit tests for gate_sdk.decision_token_verify (decode JWT, verify RS256).
"""

import base64
import json
import time
import pytest

from gate_sdk import decision_token_verify


def b64url(s: str) -> str:
    return base64.urlsafe_b64encode(s.encode()).decode().rstrip("=")


@pytest.fixture
def valid_payload():
    return {
        "tid": "t1",
        "sid": "s1",
        "env": "prod",
        "ph": "h",
        "txDigest": "d",
        "decision": "ALLOW",
        "request_id": "r1",
        "iat": 1,
        "exp": int(time.time()) + 60,
        "iss": "blockintel-gate",
        "aud": "gate-decision",
    }


class TestVerifyDecisionTokenRs256:
    def test_returns_none_for_invalid_token(self):
        assert decision_token_verify.verify_decision_token_rs256("bad", "") is None
        assert decision_token_verify.verify_decision_token_rs256("a.b", "") is None

    def test_returns_none_for_non_rs256_alg(self, valid_payload):
        header = b64url(json.dumps({"alg": "HS256"}))
        payload_b64 = b64url(json.dumps(valid_payload))
        token = f"{header}.{payload_b64}.{b64url('sig')}"
        assert decision_token_verify.verify_decision_token_rs256(token, "") is None

    def test_returns_none_for_wrong_iss(self, valid_payload):
        valid_payload["iss"] = "wrong"
        header = b64url(json.dumps({"alg": "RS256"}))
        payload_b64 = b64url(json.dumps(valid_payload))
        token = f"{header}.{payload_b64}.{b64url('x')}"
        # Invalid PEM will cause verify to fail (exception path)
        assert decision_token_verify.verify_decision_token_rs256(token, "not-a-pem") is None

    def test_returns_none_for_wrong_aud(self, valid_payload):
        valid_payload["aud"] = "wrong"
        header = b64url(json.dumps({"alg": "RS256"}))
        payload_b64 = b64url(json.dumps(valid_payload))
        token = f"{header}.{payload_b64}.{b64url('x')}"
        assert decision_token_verify.verify_decision_token_rs256(token, "") is None

    def test_returns_none_for_expired(self, valid_payload):
        valid_payload["exp"] = 1
        header = b64url(json.dumps({"alg": "RS256"}))
        payload_b64 = b64url(json.dumps(valid_payload))
        token = f"{header}.{payload_b64}.{b64url('x')}"
        assert decision_token_verify.verify_decision_token_rs256(token, "") is None
