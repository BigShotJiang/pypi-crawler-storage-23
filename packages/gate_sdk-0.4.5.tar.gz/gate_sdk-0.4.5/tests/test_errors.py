"""
Unit tests for gate_sdk.errors (exception classes and to_dict).
"""

import pytest

from gate_sdk.errors import (
    GateError,
    GateAuthError,
    GateForbiddenError,
    GateNotFoundError,
    GateRateLimitError,
    GateServerError,
    GateInvalidResponseError,
    StepUpNotConfiguredError,
    StepUpTimeoutError,
    BlockIntelBlockedError,
    BlockIntelUnavailableError,
    BlockIntelAuthError,
    BlockIntelStepUpRequiredError,
)


def test_gate_error_to_dict():
    e = GateError("msg", status_code=400, code="BAD", request_id="r1")
    d = e.to_dict()
    assert d["message"] == "msg"
    assert d["code"] == "BAD"
    assert d["status_code"] == 400
    assert d["request_id"] == "r1"


def test_gate_invalid_response_error():
    e = GateInvalidResponseError("bad json", status_code=500, request_id="r1")
    assert e.code == "INVALID_RESPONSE"
    assert "bad json" in str(e)


def test_step_up_not_configured_error():
    e = StepUpNotConfiguredError(request_id="req-1")
    assert e.code == "STEP_UP_NOT_CONFIGURED"
    assert "req-1" in str(e) or e.request_id == "req-1"


def test_step_up_timeout_error():
    e = StepUpTimeoutError("timed out after 5s", request_id="r1")
    assert e.code == "STEP_UP_TIMEOUT"


def test_block_intel_blocked_error_default_message():
    e = BlockIntelBlockedError(reason_code="POLICY_VIOLATION")
    assert "POLICY_VIOLATION" in str(e)
    assert e.reason_code == "POLICY_VIOLATION"
    assert e.reasonCodes == ["POLICY_VIOLATION"]


def test_block_intel_blocked_error_with_message_and_reason_codes():
    e = BlockIntelBlockedError(
        reason_code="RISK",
        reasonCodes=["RISK", "HIGH_RISK"],
        message="Custom message",
    )
    assert e.message == "Custom message"
    assert e.reasonCodes == ["RISK", "HIGH_RISK"]


def test_block_intel_unavailable_error():
    e = BlockIntelUnavailableError("Service down", request_id="r1")
    assert e.code == "SERVICE_UNAVAILABLE"
    assert e.request_id == "r1"


def test_block_intel_auth_error_401():
    e = BlockIntelAuthError("Unauthorized", 401, request_id="r1")
    assert e.code == "UNAUTHORIZED"
    assert e.status_code == 401


def test_block_intel_auth_error_403():
    e = BlockIntelAuthError("Forbidden", 403)
    assert e.code == "FORBIDDEN"


def test_block_intel_step_up_required_error():
    e = BlockIntelStepUpRequiredError(
        step_up_request_id="step-1",
        status_url="https://example.com/status",
        expires_at_ms=1234567890,
        request_id="r1",
    )
    assert e.code == "STEP_UP_NOT_CONFIGURED"
    assert e.details["step_up_request_id"] == "step-1"
    assert e.details.get("status_url") == "https://example.com/status"


def test_gate_rate_limit_error_retry_after():
    e = GateRateLimitError("rate limited", retry_after=60)
    assert e.retry_after == 60


def test_gate_forbidden_error_code():
    e = GateForbiddenError("forbidden", code="HEARTBEAT_INVALID")
    assert e.code == "HEARTBEAT_INVALID"
