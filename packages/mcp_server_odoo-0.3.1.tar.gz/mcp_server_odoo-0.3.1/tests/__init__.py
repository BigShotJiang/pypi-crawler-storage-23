"""Test package for mcp-server-odoo."""
