"""statsmodels.nonparametric.kernel_density.KDEMultivariate

This submodule is copied from statsmodels to avoid the additional
dependency in dclab.
"""
from . import nonparametric  # noqa: F401
