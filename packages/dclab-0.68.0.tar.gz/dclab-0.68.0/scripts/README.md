This is a collection of scripts around dclab. They are responsible
for static data generation (e.g. look-up tables, isoelastics), or
parameter estimation (e.g. pixelation correction).
