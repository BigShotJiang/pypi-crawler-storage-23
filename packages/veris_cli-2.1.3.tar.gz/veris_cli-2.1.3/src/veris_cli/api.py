"""API client for Veris backend."""

from typing import Any, Optional

import httpx

from veris_cli.config import Config


class VerisAPI:
    """Simple HTTP client for Veris backend API."""

    def __init__(self):
        config = Config()
        self.api_key = config.get_api_key()
        self.base_url = config.get_backend_url()

        if not self.api_key:
            raise ValueError("No API key found. Please run 'veris login <api-key>' first.")

    def _headers(self) -> dict:
        """Get request headers with auth."""
        return {"Authorization": f"Bearer {self.api_key}"}

    # Environments
    def create_environment(self, name: str, description: Optional[str] = None) -> dict[str, Any]:
        """Create a new environment (one-time setup)."""
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.post(
                "/v1/environments",
                json={"name": name, "description": description},
            )
            response.raise_for_status()
            return response.json()

    def create_environment_tag(self, environment_id: str, tag: str = "latest") -> dict[str, Any]:
        """Create a new tag for an environment and get push credentials."""
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.post(
                f"/v1/environments/{environment_id}/tags",
                json={"tag": tag},
            )
            response.raise_for_status()
            return response.json()

    def list_environments(
        self, status: Optional[str] = None, limit: int = 20, offset: int = 0
    ) -> dict[str, Any]:
        """List environments."""
        params = {"limit": limit, "offset": offset}
        if status:
            params["status"] = status
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.get("/v1/environments", params=params)
            response.raise_for_status()
            return response.json()

    def delete_environment(self, env_id: str) -> None:
        """Delete an environment."""
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.delete(f"/v1/environments/{env_id}")
            response.raise_for_status()

    # Scenario Sets
    def list_scenario_sets(
        self, environment_id: Optional[str] = None, limit: int = 100, skip: int = 0
    ) -> list[dict[str, Any]]:
        """List scenario sets."""
        params = {"limit": limit, "skip": skip}
        if environment_id:
            params["environment_id"] = environment_id
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.get("/v1/scenario-sets", params=params)
            response.raise_for_status()
            return response.json()

    def get_scenario_set(self, set_id: str) -> dict[str, Any]:
        """Get scenario set details."""
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.get(f"/v1/scenario-sets/{set_id}")
            response.raise_for_status()
            return response.json()

    # Runs
    def create_run(
        self,
        scenario_set_id: str,
        environment_id: str,
        parallel_jobs: int = 10,
        config: Optional[dict] = None,
    ) -> dict[str, Any]:
        """Create a new run."""
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.post(
                "/v1/runs",
                json={
                    "scenario_set_id": scenario_set_id,
                    "environment_id": environment_id,
                    "parallel_jobs": parallel_jobs,
                    "config": config or {},
                },
            )
            response.raise_for_status()
            return response.json()

    def list_runs(
        self, status: Optional[str] = None, limit: int = 20, offset: int = 0
    ) -> dict[str, Any]:
        """List runs."""
        params = {"limit": limit, "offset": offset}
        if status:
            params["status"] = status
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.get("/v1/runs", params=params)
            response.raise_for_status()
            return response.json()

    def get_run(self, run_id: str) -> dict[str, Any]:
        """Get run details."""
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.get(f"/v1/runs/{run_id}")
            response.raise_for_status()
            return response.json()

    def cancel_run(self, run_id: str) -> None:
        """Cancel a run."""
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.delete(f"/v1/runs/{run_id}")
            response.raise_for_status()

    def get_run_events(self, run_id: str, limit: int = 100, offset: int = 0) -> dict[str, Any]:
        """Get run events/logs."""
        params = {"limit": limit, "offset": offset}
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.get(f"/v1/runs/{run_id}/events", params=params)
            response.raise_for_status()
            return response.json()
