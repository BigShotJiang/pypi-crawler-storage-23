#!/usr/bin/env bash
set -e

# Docker build script for Veris CLI
# Usage: docker_build.sh <dockerfile_path> <image_uri> <registry> <username> <password> [no_cache]

DOCKERFILE_PATH="$1"
IMAGE_URI="$2"
REGISTRY="$3"
USERNAME="$4"
PASSWORD="$5"
NO_CACHE="${6:-0}"  # Optional, defaults to 0 (use cache)

if [ -z "$DOCKERFILE_PATH" ] || [ -z "$IMAGE_URI" ] || [ -z "$REGISTRY" ] || [ -z "$USERNAME" ] || [ -z "$PASSWORD" ]; then
    echo "Usage: $0 <dockerfile_path> <image_uri> <registry> <username> <password> [no_cache]"
    exit 1
fi

if [ ! -f "$DOCKERFILE_PATH" ]; then
    echo "Error: Dockerfile not found at $DOCKERFILE_PATH"
    exit 1
fi

# Use a temporary Docker config directory to avoid conflicts with
# system credential helpers (e.g., gcloud credHelper for gcr.io)
TEMP_DOCKER_CONFIG=$(mktemp -d)
export DOCKER_CONFIG="$TEMP_DOCKER_CONFIG"
trap "rm -rf $TEMP_DOCKER_CONFIG" EXIT

# Login to registry first so we can pull the base image
echo "Authenticating with Docker registry..."
echo "  Registry: $REGISTRY"
echo ""
echo "$PASSWORD" | docker login -u "$USERNAME" --password-stdin "$REGISTRY"

echo ""
echo "Building Docker image..."
echo "  Dockerfile: $DOCKERFILE_PATH"
echo "  Image URI: $IMAGE_URI"
echo ""

# Detect platform and use appropriate build command
if [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS - use buildx for multiplatform support
    echo "Detected macOS - using docker buildx"

    # Check if buildx is available
    if ! docker buildx version &> /dev/null; then
        echo "Error: docker buildx not available. Please install Docker Desktop."
        exit 1
    fi

    # Use default builder (docker-container driver doesn't inherit credentials well)
    # The default builder has better credential support
    docker buildx use default || true

    # Build for linux/amd64 (GKE target platform)
    # Note: --load only works with docker-container driver, but we're using default
    # which builds directly to the local daemon
    BUILD_ARGS="--platform linux/amd64 -f $DOCKERFILE_PATH -t $IMAGE_URI"
    if [ "$NO_CACHE" = "1" ]; then
        BUILD_ARGS="$BUILD_ARGS --no-cache --pull"
    fi
    docker buildx build $BUILD_ARGS .
else
    # Linux - use standard docker build
    echo "Using standard docker build"
    BUILD_ARGS="-f $DOCKERFILE_PATH -t $IMAGE_URI"
    if [ "$NO_CACHE" = "1" ]; then
        BUILD_ARGS="$BUILD_ARGS --no-cache --pull"
    fi
    docker build $BUILD_ARGS .
fi

echo ""
echo "✓ Image built successfully: $IMAGE_URI"
