"""Shell scripts for Docker operations."""
