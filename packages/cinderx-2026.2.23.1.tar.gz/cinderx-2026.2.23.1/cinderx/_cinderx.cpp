// Copyright (c) Meta Platforms, Inc. and affiliates.
#include "cinderx/_cinderx-lib.h"

PyMODINIT_FUNC PyInit__cinderx(void) {
  return _cinderx_lib_init();
}
