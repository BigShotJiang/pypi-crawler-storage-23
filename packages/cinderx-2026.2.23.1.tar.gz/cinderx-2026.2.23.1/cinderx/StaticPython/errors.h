// Copyright (c) Meta Platforms, Inc. and affiliates.

#pragma once

#include "cinderx/python.h"

#ifdef __cplusplus
extern "C" {
#endif

extern PyObject* CiExc_StaticTypeError;

#ifdef __cplusplus
}
#endif
