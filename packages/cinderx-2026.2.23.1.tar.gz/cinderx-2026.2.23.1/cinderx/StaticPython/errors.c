// Copyright (c) Meta Platforms, Inc. and affiliates.

#include "cinderx/StaticPython/errors.h"

PyObject* CiExc_StaticTypeError = NULL;
