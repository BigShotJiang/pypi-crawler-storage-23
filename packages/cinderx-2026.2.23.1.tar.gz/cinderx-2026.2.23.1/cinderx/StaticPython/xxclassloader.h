/* Copyright (c) Meta Platforms, Inc. and affiliates. */

#pragma once

#ifdef __cplusplus
extern "C" {
#endif

int _Ci_CreateXXClassLoaderModule(void);

#ifdef __cplusplus
} // extern "C"
#endif
