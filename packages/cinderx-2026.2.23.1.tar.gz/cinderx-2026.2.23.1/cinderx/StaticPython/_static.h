// Copyright (c) Meta Platforms, Inc. and affiliates.

#pragma once

#include "cinderx/python.h"

#ifdef __cplusplus
extern "C" {
#endif

int _Ci_CreateStaticModule(void);

#ifdef __cplusplus
}
#endif
