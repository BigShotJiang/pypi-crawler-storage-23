# Copyright (c) Meta Platforms, Inc. and affiliates.

# pyre-strict

checked_dicts = True
checked_lists = True
noframe = True  # Deprecated, has the same effect as shadow_frame.
shadow_frame = True
