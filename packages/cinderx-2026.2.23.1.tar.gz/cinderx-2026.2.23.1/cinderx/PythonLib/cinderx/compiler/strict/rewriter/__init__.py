# Copyright (c) Meta Platforms, Inc. and affiliates.
# pyre-strict

from .remove_annotations import AnnotationRemover, remove_annotations  # noqa: F401
from .rewriter import rewrite, StrictModuleRewriter  # noqa: F401
