# Copyright (c) Meta Platforms, Inc. and affiliates.

# Compile comprehensions as using their own inner scope
# (i.e. as lambdas).

# pyre-strict
COMPREHENSION_SCOPE = True
