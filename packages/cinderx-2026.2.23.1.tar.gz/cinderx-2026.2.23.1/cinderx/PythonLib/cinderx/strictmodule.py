# Copyright (c) Meta Platforms, Inc. and affiliates.
# pyre-strict

NONSTRICT_MODULE_KIND = 0
STRICT_MODULE_KIND = 1
STATIC_MODULE_KIND = 2
