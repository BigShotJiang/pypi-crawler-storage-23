// Copyright (c) Meta Platforms, Inc. and affiliates.

#define NEED_OPCODE_METADATA

#include "cinderx/Interpreter/cinder_opcode.h"
