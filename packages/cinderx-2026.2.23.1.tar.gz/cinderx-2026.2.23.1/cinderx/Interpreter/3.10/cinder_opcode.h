// Copyright (c) Meta Platforms, Inc. and affiliates.

#include "cinderx/Interpreter/cinder_opcode_ids.h"
#include "cinderx/Interpreter/cinder_opcode_metadata.h"
