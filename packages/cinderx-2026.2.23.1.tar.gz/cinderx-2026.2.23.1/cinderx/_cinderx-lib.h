// Copyright (c) Meta Platforms, Inc. and affiliates.

#include "cinderx/python.h"

PyObject* _cinderx_lib_init();
