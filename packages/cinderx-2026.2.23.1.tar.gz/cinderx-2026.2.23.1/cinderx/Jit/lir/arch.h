// Copyright (c) Meta Platforms, Inc. and affiliates.

#pragma once

#include "cinderx/Jit/codegen/arch.h"

namespace jit::lir {

using PhyLocation = jit::codegen::PhyLocation;

} // namespace jit::lir
