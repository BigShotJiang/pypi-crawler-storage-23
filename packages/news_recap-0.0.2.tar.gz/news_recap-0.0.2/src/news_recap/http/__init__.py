"""Shared HTTP fetching and content extraction utilities."""
