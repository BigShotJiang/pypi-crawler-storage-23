"""News recap pipeline — filtering, grouping, synthesis, and composition."""
