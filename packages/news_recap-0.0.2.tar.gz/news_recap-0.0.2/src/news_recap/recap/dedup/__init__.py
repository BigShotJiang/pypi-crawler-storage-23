"""Embedding-based similarity grouping for recap deduplication."""
