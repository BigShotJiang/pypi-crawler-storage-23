"""I/O JSON schemas (as hint strings) for recap pipeline steps.

MAP and REDUCE steps use text-based I/O (stdout and block files) and
do not require JSON schemas.
"""

from __future__ import annotations
