# chess-to-sqlite

Import PGN chess games into a SQLite database.

Works with exports from Lichess, Chess.com, or any standard PGN source.

## Installation

    pip install chess-to-sqlite

## Usage

    chess-to-sqlite games.pgn chess.db

Add player perspective columns:

    chess-to-sqlite games.pgn chess.db --player janschill

Options:

    --table TEXT     Target table name (default: games)
    --player TEXT    Your username — adds my_color, my_result, etc.
    --silent         Suppress progress output
    --version        Show version
    --help           Show help
