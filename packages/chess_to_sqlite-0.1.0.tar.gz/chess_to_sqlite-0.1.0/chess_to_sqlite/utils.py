"""PGN parsing and SQLite writing utilities."""

import hashlib

import chess.pgn
import sqlite_utils

# Time control boundaries in seconds for speed classification.
_SPEED_THRESHOLDS = [
    (29, "ultrabullet"),
    (179, "bullet"),
    (479, "blitz"),
    (1499, "rapid"),
]


def classify_speed(base_seconds, increment_seconds):
    """Classify a game's speed from its time control components.

    Uses the standard estimated duration formula: base + 40 * increment.
    """
    estimated = base_seconds + 40 * increment_seconds
    for threshold, name in _SPEED_THRESHOLDS:
        if estimated <= threshold:
            return name
    return "classical"


def parse_time_control(tc_string):
    """Parse a time control string like '300+3' into (base, increment).

    Returns (None, None) for unparseable formats (correspondence, etc.).
    """
    if not tc_string or tc_string == "-":
        return None, None
    parts = tc_string.split("+")
    try:
        base = int(parts[0])
        increment = int(parts[1]) if len(parts) > 1 else 0
        return base, increment
    except (ValueError, IndexError):
        return None, None


def normalize_date(date_str):
    """Convert PGN date format '2024.01.15' to ISO '2024-01-15'."""
    if not date_str or date_str == "????.??.??":
        return None
    return date_str.replace(".", "-")


def game_to_dict(game):
    """Convert a python-chess Game object to a flat dictionary.

    Extracts all standard PGN headers, normalizes dates, parses time
    controls, classifies speed, and counts moves.
    """
    headers = game.headers
    date = normalize_date(headers.get("UTCDate") or headers.get("Date"))
    time_ = headers.get("UTCTime")
    datetime_ = f"{date} {time_}" if date and time_ else date

    # Use GameId or Site URL as primary key; fall back to hash.
    game_id = headers.get("GameId", "")
    site = headers.get("Site", "")
    if game_id:
        pk = game_id
    elif site and site.startswith("http"):
        pk = site.rstrip("/").rsplit("/", 1)[-1]
    else:
        raw = f"{headers.get('White', '')}-{headers.get('Black', '')}-{date}-{time_}"
        pk = hashlib.sha256(raw.encode()).hexdigest()[:16]

    tc_raw = headers.get("TimeControl", "")
    base, increment = parse_time_control(tc_raw)
    speed = classify_speed(base, increment) if base is not None else None

    # Count full moves from the mainline.
    moves = list(game.mainline_moves())
    num_moves = (len(moves) + 1) // 2

    # Collect the move text.
    exporter = chess.pgn.StringExporter(headers=False, variations=False, comments=False)
    pgn_moves = game.accept(exporter).strip()

    def safe_int(val):
        if val is None:
            return None
        try:
            return int(val)
        except (ValueError, TypeError):
            return None

    return {
        "id": pk,
        "event": headers.get("Event"),
        "site": site or None,
        "date": date,
        "time": time_,
        "datetime": datetime_,
        "white": headers.get("White"),
        "black": headers.get("Black"),
        "result": headers.get("Result"),
        "white_elo": safe_int(headers.get("WhiteElo")),
        "black_elo": safe_int(headers.get("BlackElo")),
        "white_rating_diff": safe_int(headers.get("WhiteRatingDiff")),
        "black_rating_diff": safe_int(headers.get("BlackRatingDiff")),
        "variant": headers.get("Variant"),
        "time_control": tc_raw or None,
        "time_control_base": base,
        "time_control_increment": increment,
        "speed": speed,
        "eco": headers.get("ECO"),
        "opening": headers.get("Opening"),
        "termination": headers.get("Termination"),
        "num_moves": num_moves,
        "pgn_moves": pgn_moves or None,
    }


def add_player_perspective(record, player):
    """Add perspective columns for a specific player.

    Adds my_color, my_result, my_elo, my_rating_diff, opponent,
    opponent_elo, and opponent_rating_diff.
    """
    player_lower = player.lower()
    white_lower = (record.get("white") or "").lower()
    black_lower = (record.get("black") or "").lower()

    if white_lower == player_lower:
        color = "white"
    elif black_lower == player_lower:
        color = "black"
    else:
        return record

    result = record.get("result", "")
    if color == "white":
        if result == "1-0":
            my_result = "win"
        elif result == "0-1":
            my_result = "loss"
        elif result == "1/2-1/2":
            my_result = "draw"
        else:
            my_result = None
        record["my_color"] = "white"
        record["my_elo"] = record.get("white_elo")
        record["my_rating_diff"] = record.get("white_rating_diff")
        record["opponent"] = record.get("black")
        record["opponent_elo"] = record.get("black_elo")
        record["opponent_rating_diff"] = record.get("black_rating_diff")
    else:
        if result == "0-1":
            my_result = "win"
        elif result == "1-0":
            my_result = "loss"
        elif result == "1/2-1/2":
            my_result = "draw"
        else:
            my_result = None
        record["my_color"] = "black"
        record["my_elo"] = record.get("black_elo")
        record["my_rating_diff"] = record.get("black_rating_diff")
        record["opponent"] = record.get("white")
        record["opponent_elo"] = record.get("white_elo")
        record["opponent_rating_diff"] = record.get("white_rating_diff")

    record["my_result"] = my_result
    return record


def import_pgn(pgn_path, db_path, table_name="games", player=None, silent=False):
    """Import games from a PGN file into a SQLite database.

    Streams games one at a time for memory efficiency.
    Batches inserts for performance. Uses upsert on 'id' PK for
    idempotent reimport.

    Returns the number of games imported.
    """
    db = sqlite_utils.Database(db_path)
    batch = []
    count = 0
    batch_size = 100

    with open(pgn_path, encoding="utf-8", errors="replace") as f:
        while True:
            game = chess.pgn.read_game(f)
            if game is None:
                break
            record = game_to_dict(game)
            if player:
                record = add_player_perspective(record, player)
            batch.append(record)
            count += 1

            if len(batch) >= batch_size:
                _flush_batch(db, table_name, batch)
                if not silent:
                    print(f"  {count} games imported...", end="\r")
                batch = []

    if batch:
        _flush_batch(db, table_name, batch)

    if not silent:
        print(f"  {count} games imported.     ")

    return count


def _flush_batch(db, table_name, batch):
    """Write a batch of records to the database."""
    db[table_name].upsert_all(batch, pk="id", alter=True)
