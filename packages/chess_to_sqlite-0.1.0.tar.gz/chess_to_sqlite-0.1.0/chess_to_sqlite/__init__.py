"""Import PGN chess games into a SQLite database."""

__version__ = "0.1.0"
