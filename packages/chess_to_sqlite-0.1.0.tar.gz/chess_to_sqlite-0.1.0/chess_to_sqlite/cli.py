"""Command-line interface for chess-to-sqlite."""

import click

from chess_to_sqlite import __version__
from chess_to_sqlite.utils import import_pgn


@click.command()
@click.version_option(version=__version__)
@click.argument("pgn_file", type=click.Path(exists=True))
@click.argument("db_path", type=click.Path())
@click.option("--table", default="games", help="Target table name.", show_default=True)
@click.option("--player", default=None, help="Your username — adds perspective columns (my_color, my_result, etc.).")
@click.option("--silent", is_flag=True, help="Suppress progress output.")
def cli(pgn_file, db_path, table, player, silent):
    """Import PGN chess games into a SQLite database.

    Reads games from PGN_FILE and writes them to DB_PATH.
    Works with exports from Lichess, Chess.com, or any standard PGN source.
    """
    if not silent:
        click.echo(f"Importing {pgn_file} → {db_path}")
    count = import_pgn(pgn_file, db_path, table_name=table, player=player, silent=silent)
    if not silent:
        click.echo(f"Done. {count} games in {db_path}:{table}")
