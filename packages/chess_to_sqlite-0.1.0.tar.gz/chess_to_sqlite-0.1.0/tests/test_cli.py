"""Tests for chess_to_sqlite.cli."""

import os
import tempfile

import sqlite_utils
from click.testing import CliRunner

from chess_to_sqlite.cli import cli

FIXTURES = os.path.join(os.path.dirname(__file__), "fixtures")


def test_basic_import():
    runner = CliRunner()
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name
    try:
        result = runner.invoke(cli, [os.path.join(FIXTURES, "simple.pgn"), db_path])
        assert result.exit_code == 0
        assert "3 games" in result.output
        db = sqlite_utils.Database(db_path)
        assert len(list(db["games"].rows)) == 3
    finally:
        os.unlink(db_path)


def test_with_player_flag():
    runner = CliRunner()
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name
    try:
        result = runner.invoke(
            cli, [os.path.join(FIXTURES, "simple.pgn"), db_path, "--player", "player1"]
        )
        assert result.exit_code == 0
        db = sqlite_utils.Database(db_path)
        rows = list(db["games"].rows)
        assert all("my_color" in r for r in rows if r["white"] == "player1" or r["black"] == "player1")
    finally:
        os.unlink(db_path)


def test_custom_table():
    runner = CliRunner()
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name
    try:
        result = runner.invoke(
            cli, [os.path.join(FIXTURES, "simple.pgn"), db_path, "--table", "chess"]
        )
        assert result.exit_code == 0
        db = sqlite_utils.Database(db_path)
        assert "chess" in db.table_names()
    finally:
        os.unlink(db_path)


def test_silent_flag():
    runner = CliRunner()
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name
    try:
        result = runner.invoke(
            cli, [os.path.join(FIXTURES, "simple.pgn"), db_path, "--silent"]
        )
        assert result.exit_code == 0
        assert result.output == ""
    finally:
        os.unlink(db_path)


def test_version():
    runner = CliRunner()
    result = runner.invoke(cli, ["--version"])
    assert result.exit_code == 0
    assert "0.1.0" in result.output


def test_missing_file():
    runner = CliRunner()
    result = runner.invoke(cli, ["/nonexistent.pgn", "out.db"])
    assert result.exit_code != 0
