"""Tests for chess_to_sqlite.utils."""

import os
import tempfile

import chess.pgn
import sqlite_utils

from chess_to_sqlite.utils import (
    add_player_perspective,
    classify_speed,
    game_to_dict,
    import_pgn,
    normalize_date,
    parse_time_control,
)

FIXTURES = os.path.join(os.path.dirname(__file__), "fixtures")


def _read_first_game(path):
    with open(path) as f:
        return chess.pgn.read_game(f)


class TestClassifySpeed:
    def test_ultrabullet(self):
        assert classify_speed(15, 0) == "ultrabullet"

    def test_bullet(self):
        assert classify_speed(60, 0) == "bullet"
        assert classify_speed(120, 1) == "bullet"

    def test_blitz(self):
        assert classify_speed(300, 0) == "blitz"
        assert classify_speed(300, 3) == "blitz"

    def test_rapid(self):
        assert classify_speed(600, 0) == "rapid"
        assert classify_speed(600, 5) == "rapid"

    def test_classical(self):
        assert classify_speed(1800, 0) == "classical"
        assert classify_speed(1500, 0) == "classical"


class TestParseTimeControl:
    def test_standard(self):
        assert parse_time_control("300+3") == (300, 3)

    def test_no_increment(self):
        assert parse_time_control("60+0") == (60, 0)

    def test_correspondence(self):
        assert parse_time_control("-") == (None, None)

    def test_empty(self):
        assert parse_time_control("") == (None, None)

    def test_none(self):
        assert parse_time_control(None) == (None, None)


class TestNormalizeDate:
    def test_standard(self):
        assert normalize_date("2024.06.15") == "2024-06-15"

    def test_unknown(self):
        assert normalize_date("????.??.??") is None

    def test_none(self):
        assert normalize_date(None) is None


class TestGameToDict:
    def test_basic_extraction(self):
        game = _read_first_game(os.path.join(FIXTURES, "simple.pgn"))
        d = game_to_dict(game)
        assert d["id"] == "abc12345"
        assert d["white"] == "player1"
        assert d["black"] == "player2"
        assert d["result"] == "1-0"
        assert d["white_elo"] == 1500
        assert d["black_elo"] == 1450
        assert d["date"] == "2024-06-15"
        assert d["time"] == "10:30:00"
        assert d["datetime"] == "2024-06-15 10:30:00"
        assert d["speed"] == "blitz"
        assert d["eco"] == "B01"
        assert d["opening"] == "Scandinavian Defense"
        assert d["time_control"] == "300+3"
        assert d["time_control_base"] == 300
        assert d["time_control_increment"] == 3
        assert d["termination"] == "Normal"
        assert d["num_moves"] == 7
        assert d["variant"] == "Standard"

    def test_rating_diff(self):
        game = _read_first_game(os.path.join(FIXTURES, "simple.pgn"))
        d = game_to_dict(game)
        assert d["white_rating_diff"] == 5
        assert d["black_rating_diff"] == -5


class TestAddPlayerPerspective:
    def test_white_win(self):
        record = {"white": "player1", "black": "player2", "result": "1-0",
                  "white_elo": 1500, "black_elo": 1450,
                  "white_rating_diff": 5, "black_rating_diff": -5}
        result = add_player_perspective(record, "player1")
        assert result["my_color"] == "white"
        assert result["my_result"] == "win"
        assert result["my_elo"] == 1500
        assert result["opponent"] == "player2"
        assert result["opponent_elo"] == 1450

    def test_black_win(self):
        record = {"white": "player1", "black": "player2", "result": "0-1",
                  "white_elo": 1500, "black_elo": 1450,
                  "white_rating_diff": -5, "black_rating_diff": 5}
        result = add_player_perspective(record, "player2")
        assert result["my_color"] == "black"
        assert result["my_result"] == "win"
        assert result["my_elo"] == 1450

    def test_draw(self):
        record = {"white": "player1", "black": "player2", "result": "1/2-1/2",
                  "white_elo": 1500, "black_elo": 1450,
                  "white_rating_diff": 1, "black_rating_diff": -1}
        result = add_player_perspective(record, "player1")
        assert result["my_result"] == "draw"

    def test_case_insensitive(self):
        record = {"white": "Player1", "black": "player2", "result": "1-0",
                  "white_elo": 1500, "black_elo": 1450,
                  "white_rating_diff": 5, "black_rating_diff": -5}
        result = add_player_perspective(record, "player1")
        assert result["my_color"] == "white"

    def test_player_not_in_game(self):
        record = {"white": "player1", "black": "player2", "result": "1-0",
                  "white_elo": 1500, "black_elo": 1450,
                  "white_rating_diff": 5, "black_rating_diff": -5}
        result = add_player_perspective(record, "stranger")
        assert "my_color" not in result


class TestImportPgn:
    def test_import_simple(self):
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name
        try:
            count = import_pgn(
                os.path.join(FIXTURES, "simple.pgn"), db_path, silent=True
            )
            assert count == 3
            db = sqlite_utils.Database(db_path)
            assert "games" in db.table_names()
            rows = list(db["games"].rows)
            assert len(rows) == 3
            ids = {r["id"] for r in rows}
            assert ids == {"abc12345", "def67890", "ghi11111"}
        finally:
            os.unlink(db_path)

    def test_import_with_player(self):
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name
        try:
            count = import_pgn(
                os.path.join(FIXTURES, "simple.pgn"),
                db_path,
                player="player1",
                silent=True,
            )
            assert count == 3
            db = sqlite_utils.Database(db_path)
            rows = list(db["games"].rows)
            game1 = next(r for r in rows if r["id"] == "abc12345")
            assert game1["my_color"] == "white"
            assert game1["my_result"] == "win"
            game2 = next(r for r in rows if r["id"] == "def67890")
            assert game2["my_color"] == "black"
            assert game2["my_result"] == "win"
            game3 = next(r for r in rows if r["id"] == "ghi11111")
            assert game3["my_result"] == "draw"
        finally:
            os.unlink(db_path)

    def test_import_empty(self):
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name
        try:
            count = import_pgn(
                os.path.join(FIXTURES, "empty.pgn"), db_path, silent=True
            )
            assert count == 0
        finally:
            os.unlink(db_path)

    def test_import_custom_table(self):
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name
        try:
            import_pgn(
                os.path.join(FIXTURES, "simple.pgn"),
                db_path,
                table_name="chess",
                silent=True,
            )
            db = sqlite_utils.Database(db_path)
            assert "chess" in db.table_names()
            assert "games" not in db.table_names()
        finally:
            os.unlink(db_path)

    def test_idempotent_reimport(self):
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name
        try:
            import_pgn(os.path.join(FIXTURES, "simple.pgn"), db_path, silent=True)
            import_pgn(os.path.join(FIXTURES, "simple.pgn"), db_path, silent=True)
            db = sqlite_utils.Database(db_path)
            assert len(list(db["games"].rows)) == 3
        finally:
            os.unlink(db_path)
