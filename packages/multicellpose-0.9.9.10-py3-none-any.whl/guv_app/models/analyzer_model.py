class AnalyzerModel:
    def __init__(self):
        self.folder_path = None
