class ImageFile:
    """
    Represents an image loaded into the application.
    """
    pass

class SegmentationMask:
    """
    Represents a single segmented mask/ROI as an object.
    """
    pass
