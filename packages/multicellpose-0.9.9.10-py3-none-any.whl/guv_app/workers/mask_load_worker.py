from .base_worker import BaseWorker

class MaskLoadWorker(BaseWorker):
    """
    Worker for loading and processing masks from disk.
    """
    def run(self):
        """
        Entry-point routine that orchestrates execution.
        """
        pass
