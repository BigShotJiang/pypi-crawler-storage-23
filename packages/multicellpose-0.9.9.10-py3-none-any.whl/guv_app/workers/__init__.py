from .interface import AnalysisPlugin
from .basic_stats import BasicStatsPlugin