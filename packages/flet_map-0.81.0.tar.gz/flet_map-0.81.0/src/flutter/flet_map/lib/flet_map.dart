library flet_map;

export "src/extension.dart" show Extension;
