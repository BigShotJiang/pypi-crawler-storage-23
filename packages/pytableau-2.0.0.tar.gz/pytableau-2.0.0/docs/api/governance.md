# Governance

The governance module provides cross-workbook governance tooling including a SQLite-backed workbook index and configurable lint rules.

::: pytableau.governance
::: pytableau.governance.index
::: pytableau.governance.rules
