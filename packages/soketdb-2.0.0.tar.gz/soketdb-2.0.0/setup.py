from setuptools import setup, find_packages
import os

# Safe README read (no crash if missing)
long_description = ""
if os.path.exists("README.md"):
    with open("README.md", encoding="utf-8") as f:
        long_description = f.read()

setup(
    name="soketdb",
    version="2.0.0",  # Major version bump to reflect the massive upgrade
    author="Alex Austin",
    author_email="benmap40@gmail.com",
    description=(
        "SoketDB v2.0 — A production-ready, PostgreSQL-like database with AI-powered queries, "
        "automatic cloud backup, encryption, MVCC transactions, and zero setup. Now with WAL, "
        "indexes, constraints, and connection pooling!"
    ),
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/pythos-team/soketdb",
    license="MIT",
    packages=find_packages(),
    install_requires=[
        "huggingface_hub>=0.16.0",
        "sqlparse>=0.4.3",
        "requests>=2.28.0",
        "redis>=4.5.0",
        "dropbox>=11.36.0",
        "boto3>=1.26.0",
        "google-auth-oauthlib>=1.0.0",
        "google-auth-httplib2>=0.1.0",
        "google-api-python-client>=2.70.0",
        "cryptography>=39.0.0",  # For production encryption
    ],
    extras_require={
        "full": [
            "cryptography>=39.0.0",
            "huggingface_hub>=0.16.0",
            "boto3>=1.26.0",
            "dropbox>=11.36.0",
            "google-api-python-client>=2.70.0",
        ],
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "black>=22.0.0",
            "mypy>=0.990",
            "flake8>=5.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "soketdb = soketdb:cli_main",
        ],
    },
    python_requires=">=3.8",
    zip_safe=False,
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
        "Topic :: Database",
        "Topic :: Database :: Database Engines/Servers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Software Development :: Libraries",
    ],
    keywords=[
        "database",
        "json",
        "sql",
        "ai",
        "nlp",
        "offline",
        "lightweight",
        "local-storage",
        "cloud-sync",
        "huggingface",
        "google-drive",
        "transactions",
        "mvcc",
        "acid",
        "postgresql",
        "production-database",
        "encryption",
    ],
    project_urls={
        "Bug Reports": "https://github.com/pythos-team/soketdb/issues",
        "Source": "https://github.com/pythos-team/soketdb",
        "Documentation": "https://github.com/pythos-team/soketdb#readme",
    },
)