# soketdb/__main__.py
from soketdb import cli_main  # Assumes cli_main() is defined in __init__.py

if __name__ == "__main__":
    cli_main()