import os
import re
import json
import threading
import sqlparse
import requests
import pickle
import hashlib
import time
import base64
import secrets
import argparse
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Union, Tuple, Set, Callable
from enum import Enum
import io
import shutil
import tempfile
import zlib
import gzip
import queue
import weakref
import uuid
from collections import defaultdict, OrderedDict
import bisect
import heapq
import contextlib

# Enhanced imports with fallbacks
try:
    from huggingface_hub import HfApi, upload_file, login, hf_hub_download
    HUGGINGFACE_AVAILABLE = True
except ImportError:
    HUGGINGFACE_AVAILABLE = False

try:
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from googleapiclient.discovery import build
    from googleapiclient.http import MediaIoBaseUpload, MediaIoBaseDownload
    GOOGLE_DRIVE_AVAILABLE = True
except ImportError:
    GOOGLE_DRIVE_AVAILABLE = False

try:
    import boto3
    import botocore
    AWS_AVAILABLE = True
except ImportError:
    AWS_AVAILABLE = False

try:
    import dropbox
    DROPBOX_AVAILABLE = True
except ImportError:
    DROPBOX_AVAILABLE = False

# Encryption imports
try:
    from cryptography.fernet import Fernet
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    ENCRYPTION_AVAILABLE = True
except ImportError:
    ENCRYPTION_AVAILABLE = False

# Configuration
DATABASE = "./soketDB"
TABLE_EXT = ".sdb"
BACKUP_EXT = ".backup"
CONFIG_FILE = "database_config.json"
ENV_FILE = ".env"
WAL_EXT = ".wal"
INDEX_EXT = ".idx"
CONSTRAINT_EXT = ".con"

class StorageType(Enum):
    LOCAL = "local"
    GOOGLE_DRIVE = "google_drive"
    HUGGINGFACE = "huggingface"
    AWS_S3 = "aws_s3"
    DROPBOX = "dropbox"

class QueryType(Enum):
    SELECT = "SELECT"
    INSERT = "INSERT"
    UPDATE = "UPDATE"
    DELETE = "DELETE"
    CREATE = "CREATE"
    DROP = "DROP"
    ALTER = "ALTER"
    COUNT = "COUNT"
    SUM = "SUM"
    AVG = "AVG"
    GROUP_BY = "GROUP_BY"
    JOIN = "JOIN"
    UNKNOWN = "UNKNOWN"

class IsolationLevel(Enum):
    READ_UNCOMMITTED = "READ UNCOMMITTED"
    READ_COMMITTED = "READ COMMITTED"
    REPEATABLE_READ = "REPEATABLE READ"
    SERIALIZABLE = "SERIALIZABLE"

class ConstraintType(Enum):
    PRIMARY_KEY = "PRIMARY KEY"
    FOREIGN_KEY = "FOREIGN KEY"
    UNIQUE = "UNIQUE"
    NOT_NULL = "NOT NULL"
    CHECK = "CHECK"
    DEFAULT = "DEFAULT"

class IndexType(Enum):
    BTREE = "btree"
    HASH = "hash"
    GIN = "gin"  # Generalized Inverted Index for JSON/arrays

lock = threading.RLock()

class EnvironmentManager:
    """Manage environment variables with support for encrypted values"""
    
    def __init__(self, env_file: str = ENV_FILE, production: bool = False):
        self.env_file = env_file
        self.production = production
        self.encryption_manager = None
        self.env_vars = {}
        self.encrypted_prefix = "encrypted_"
        
        # Initialize encryption for production mode
        if production and ENCRYPTION_AVAILABLE:
            self.encryption_manager = EncryptionManager("env_manager", production)
        
        self.load_env()
    
    def load_env(self):
        """Load environment variables from file and system"""
        # Load from .env file
        if os.path.exists(self.env_file):
            with open(self.env_file, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#') and '=' in line:
                        key, value = line.split('=', 1)
                        key = key.strip()
                        value = value.strip()
                        
                        # Remove quotes if present
                        if (value.startswith('"') and value.endswith('"')) or (value.startswith("'") and value.endswith("'")):
                            value = value[1:-1]
                        
                        self.env_vars[key] = value
        
        # Override with system environment variables
        for key, value in os.environ.items():
            self.env_vars[key] = value
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get environment variable with decryption support"""
        value = self.env_vars.get(key, default)
        
        # Check for encrypted value
        if key.startswith(self.encrypted_prefix) and self.encryption_manager:
            try:
                # Try to decrypt
                decrypted = self.encryption_manager.decrypt_data(value)
                if decrypted is not None:
                    return decrypted
            except:
                pass
        
        return value
    
    def set(self, key: str, value: Any, encrypt: bool = False):
        """Set environment variable with optional encryption"""
        if encrypt and self.encryption_manager:
            encrypted_value = self.encryption_manager.encrypt_data(value)
            key = f"{self.encrypted_prefix}{key}"
            self.env_vars[key] = encrypted_value
        else:
            self.env_vars[key] = str(value)
        
        # Save to .env file
        self.save_to_file()
    
    def save_to_file(self):
        """Save environment variables to .env file"""
        with open(self.env_file, 'w') as f:
            for key, value in self.env_vars.items():
                # Skip system environment variables that weren't in original file
                if key in os.environ and not any(line.startswith(f"{key}=") for line in open(self.env_file).readlines() if '=' in line):
                    continue
                f.write(f"{key}={value}\n")
    
    def items(self):
        """Get all environment variables"""
        return self.env_vars.items()
    
    def to_dict(self):
        """Convert to dictionary"""
        return self.env_vars.copy()

class EncryptionManager:
    """Manage encryption and decryption for production databases"""
    
    def __init__(self, project_name: str, production: bool = False):
        self.project_name = project_name
        self.production = production
        self.fernet = None
        self.encryption_key = None
        self.key_identifier = None
        self.key_shown = False
        
        if self.production:
            if not ENCRYPTION_AVAILABLE:
                raise ImportError("Encryption libraries not installed. Run: pip install cryptography")
    
    def initialize_encryption(self, existing_key: str = None, env_manager: EnvironmentManager = None):
        """Initialize encryption system for production mode"""
        if existing_key:
            self.set_encryption_key(existing_key)
        elif env_manager and env_manager.get("encrypted_key"):
            # Try to get key from environment
            env_key = env_manager.get("encrypted_key")
            self.set_encryption_key(env_key)
        else:
            self._generate_new_key(env_manager)
    
    def _generate_new_key(self, env_manager: EnvironmentManager = None):
        """Generate new encryption key and display it ONCE"""
        self.encryption_key = Fernet.generate_key()
        self.fernet = Fernet(self.encryption_key)
        
        # Create a key identifier for runtime storage
        self.key_identifier = f"{self.project_name}_key"
        
        # Store key in runtime memory only (not on disk)
        RuntimeKeyStorage.set_key(self.key_identifier, self.encryption_key)
        
        # Store in environment if provided
        if env_manager:
            key_b64 = base64.urlsafe_b64encode(self.encryption_key).decode()
            env_manager.set("encrypted_key", key_b64, encrypt=False)
            print(f"✅ Encryption key saved to {env_manager.env_file} as 'encrypted_key'")
        
        # Display decryption key to user (ONLY ONCE during first setup)
        if not self.key_shown:
            self._display_decryption_key()
            self.key_shown = True
    
    def _display_decryption_key(self):
        """Display decryption key to user in terminal (ONLY ONCE)"""
        key_hex = self.encryption_key.hex()
        key_b64 = base64.urlsafe_b64encode(self.encryption_key).decode()
        
        print("\n" + "🔐" * 50)
        print("🚨 PRODUCTION ENCRYPTION ENABLED")
        print("🔐" * 50)
        print(f"📁 Project: {self.project_name}")
        print(f"🔑 Encryption Key (Hex): {key_hex}")
        print(f"🔑 Encryption Key (Base64): {key_b64}")
        print("\n⚠️  ⚠️  ⚠️  IMPORTANT: SAVE THIS KEY SECURELY! ⚠️  ⚠️  ⚠️")
        print("⚠️  This key will ONLY be shown NOW. Without it, your data is PERMANENTLY LOST!")
        print("⚠️  Store it in a password manager or secure location.")
        print("🔐" * 50)
        print("💡 Usage in code:")
        print("   my_envs = env()")
        print("   db = database('your_project', production=True, encryption_key=my_envs.get('encrypted_key'))")
        print("🔐" * 50 + "\n")
    
    def set_encryption_key(self, key: str):
        """Set encryption key manually (for restoration)"""
        try:
            # Try hex format first
            if len(key) == 64:  # Fernet key in hex is 64 chars
                self.encryption_key = bytes.fromhex(key)
            else:
                # Try base64 format
                self.encryption_key = base64.urlsafe_b64decode(key)
            
            self.fernet = Fernet(self.encryption_key)
            self.production = True
            
            # Store in runtime memory
            self.key_identifier = f"{self.project_name}_key"
            RuntimeKeyStorage.set_key(self.key_identifier, self.encryption_key)
            
            print(f"✅ Encryption key set for project: {self.project_name}")
        except Exception as e:
            print(f"❌ Invalid encryption key: {e}")
            raise
    
    def encrypt_data(self, data: Any) -> str:
        """Encrypt data for production mode"""
        if not self.production or not self.fernet:
            # Use pickle + gzip for better handling of complex data
            serialized = pickle.dumps(data)
            compressed = gzip.compress(serialized)
            return base64.b85encode(compressed).decode('ascii')
        
        try:
            # Serialize, compress, and encrypt
            serialized_data = pickle.dumps(data)
            compressed_data = gzip.compress(serialized_data)
            encrypted_data = self.fernet.encrypt(compressed_data)
            return base64.b85encode(encrypted_data).decode('ascii')
        except Exception as e:
            print(f"⚠️ Encryption failed: {e}")
            serialized = pickle.dumps(data)
            compressed = gzip.compress(serialized)
            return base64.b85encode(compressed).decode('ascii')
    
    def decrypt_data(self, encrypted_data: str) -> Any:
        """Decrypt data for production mode"""
        try:
            # Decode from base85
            decoded = base64.b85decode(encrypted_data.encode('ascii'))
            
            # Try to decrypt if in production mode
            if self.production and self.fernet:
                try:
                    decrypted = self.fernet.decrypt(decoded)
                    decompressed = gzip.decompress(decrypted)
                    return pickle.loads(decompressed)
                except:
                    # Not encrypted, just compressed
                    decompressed = gzip.decompress(decoded)
                    return pickle.loads(decompressed)
            else:
                # Just decompress
                decompressed = gzip.decompress(decoded)
                return pickle.loads(decompressed)
                
        except Exception as e:
            print(f"⚠️ Decryption failed: {e}")
            return None

    def migrate_to_encrypted(self, db_instance, env_manager: EnvironmentManager):
        """Migrate existing unencrypted data to encrypted format"""
        if not self.production:
            print("❌ Cannot migrate: Not in production mode")
            return False
        
        print("🔄 Starting encryption migration...")
        
        try:
            tables = db_instance.list_tables()
            migrated_count = 0
            
            for table in tables:
                if table.startswith('system_'):
                    continue
                
                # Read unencrypted data
                data = db_instance._read_table_unencrypted(table)
                if data is not None:
                    # Write with encryption
                    db_instance._write_table(table, data, "ENCRYPTION_MIGRATION")
                    migrated_count += 1
                    print(f"✅ Encrypted table: {table}")
            
            # Store encryption key in environment
            if migrated_count > 0:
                key_b64 = base64.urlsafe_b64encode(self.encryption_key).decode()
                env_manager.set("encrypted_key", key_b64, encrypt=False)
                
                print(f"✅ Successfully encrypted {migrated_count} tables")
                print(f"🔑 Encryption key saved to {env_manager.env_file}")
                return True
            
        except Exception as e:
            print(f"❌ Migration failed: {e}")
            return False
        
        return False

class RuntimeKeyStorage:
    """In-memory key storage for runtime use only"""
    _keys = {}
    _lock = threading.RLock()
    
    @classmethod
    def set_key(cls, identifier: str, key: bytes):
        """Store key in memory"""
        with cls._lock:
            cls._keys[identifier] = key
    
    @classmethod
    def get_key(cls, identifier: str) -> Optional[bytes]:
        """Retrieve key from memory"""
        with cls._lock:
            return cls._keys.get(identifier)
    
    @classmethod
    def clear_key(cls, identifier: str):
        """Remove key from memory"""
        with cls._lock:
            cls._keys.pop(identifier, None)
    
    @classmethod
    def clear_all(cls):
        """Clear all keys from memory"""
        with cls._lock:
            cls._keys.clear()

class WriteAheadLog:
    """Write-Ahead Log for durability and crash recovery"""
    
    def __init__(self, project_path: str, table: str):
        self.project_path = project_path
        self.table = table
        self.wal_path = os.path.join(project_path, f"{table}{WAL_EXT}")
        self.lock = threading.RLock()
        self.current_lsn = 0  # Log Sequence Number
        self.pending_entries = []
        self.checkpoint_threshold = 1000  # Entries before checkpoint
        self._load_checkpoint()
    
    def _load_checkpoint(self):
        """Load last checkpoint if exists"""
        if os.path.exists(self.wal_path):
            try:
                with open(self.wal_path, 'rb') as f:
                    checkpoint_data = gzip.decompress(f.read())
                    checkpoint = pickle.loads(checkpoint_data)
                    self.current_lsn = checkpoint.get('last_lsn', 0)
                    # Checkpoint doesn't restore pending entries
            except:
                pass
    
    def append(self, operation: str, data: Any, old_data: Any = None) -> int:
        """Append entry to WAL and return LSN"""
        with self.lock:
            self.current_lsn += 1
            entry = {
                'lsn': self.current_lsn,
                'timestamp': time.time(),
                'operation': operation,
                'table': self.table,
                'data': data,
                'old_data': old_data
            }
            
            self.pending_entries.append(entry)
            
            # Flush to disk periodically
            if len(self.pending_entries) >= self.checkpoint_threshold:
                self.checkpoint()
            
            return self.current_lsn
    
    def checkpoint(self):
        """Create checkpoint - write all pending entries to WAL file"""
        if not self.pending_entries:
            return
        
        with self.lock:
            try:
                # Read existing WAL
                existing_entries = []
                if os.path.exists(self.wal_path):
                    with open(self.wal_path, 'rb') as f:
                        existing_entries = pickle.loads(gzip.decompress(f.read()))
                
                # Merge with pending
                if isinstance(existing_entries, dict):
                    # It's a checkpoint, not entries
                    all_entries = self.pending_entries
                else:
                    all_entries = existing_entries + self.pending_entries
                
                # Write merged entries
                compressed = gzip.compress(pickle.dumps(all_entries))
                with tempfile.NamedTemporaryFile(mode='wb', delete=False) as temp_f:
                    temp_f.write(compressed)
                    temp_path = temp_f.name
                
                os.replace(temp_path, self.wal_path)
                self.pending_entries = []
                
            except Exception as e:
                print(f"⚠️ WAL checkpoint failed: {e}")
    
    def replay(self) -> List[Dict]:
        """Replay WAL for recovery"""
        if not os.path.exists(self.wal_path):
            return []
        
        try:
            with open(self.wal_path, 'rb') as f:
                entries = pickle.loads(gzip.decompress(f.read()))
            
            # Add pending entries that haven't been checkpointed
            return entries + self.pending_entries
        except:
            return self.pending_entries
    
    def truncate(self, up_to_lsn: int):
        """Truncate WAL up to given LSN"""
        with self.lock:
            entries = self.replay()
            remaining = [e for e in entries if e['lsn'] > up_to_lsn]
            
            if remaining:
                compressed = gzip.compress(pickle.dumps(remaining))
                with tempfile.NamedTemporaryFile(mode='wb', delete=False) as temp_f:
                    temp_f.write(compressed)
                    temp_path = temp_f.name
                
                os.replace(temp_path, self.wal_path)
            elif os.path.exists(self.wal_path):
                os.remove(self.wal_path)
            
            self.pending_entries = []
    
    def close(self):
        """Close WAL and create final checkpoint"""
        self.checkpoint()

class IndexManager:
    """B-tree and Hash index support for faster queries"""
    
    def __init__(self, project_path: str, table: str, column: str, index_type: IndexType = IndexType.BTREE):
        self.project_path = project_path
        self.table = table
        self.column = column
        self.index_type = index_type
        self.index_path = os.path.join(project_path, f"{table}_{column}{INDEX_EXT}")
        self.lock = threading.RLock()
        self.index = self._load_index()
    
    def _load_index(self) -> Dict:
        """Load index from disk"""
        if os.path.exists(self.index_path):
            try:
                with open(self.index_path, 'rb') as f:
                    return pickle.loads(gzip.decompress(f.read()))
            except:
                return {}
        return {}
    
    def _save_index(self):
        """Save index to disk"""
        with self.lock:
            compressed = gzip.compress(pickle.dumps(self.index))
            with tempfile.NamedTemporaryFile(mode='wb', delete=False) as temp_f:
                temp_f.write(compressed)
                temp_path = temp_f.name
            
            os.replace(temp_path, self.index_path)
    
    def build_index(self, data: List[Dict]):
        """Build index from table data"""
        with self.lock:
            if self.index_type == IndexType.BTREE:
                # B-tree like structure using sorted dictionary
                self.index = {}
                for i, row in enumerate(data):
                    val = row.get(self.column)
                    if val is not None:
                        if val not in self.index:
                            self.index[val] = []
                        self.index[val].append(i)
            elif self.index_type == IndexType.HASH:
                # Simple hash index
                self.index = {}
                for i, row in enumerate(data):
                    val = row.get(self.column)
                    if val is not None:
                        hash_key = hash(val) % 1000000
                        if hash_key not in self.index:
                            self.index[hash_key] = []
                        self.index[hash_key].append((val, i))
            elif self.index_type == IndexType.GIN:
                # GIN for JSON/array values
                self.index = defaultdict(list)
                for i, row in enumerate(data):
                    val = row.get(self.column)
                    if isinstance(val, (dict, list)):
                        # Index each key/value for JSON
                        self._index_json_value(val, i)
            
            self._save_index()
    
    def _index_json_value(self, val: Any, row_idx: int, path: str = ""):
        """Recursively index JSON values for GIN"""
        if isinstance(val, dict):
            for k, v in val.items():
                new_path = f"{path}.{k}" if path else k
                self.index[new_path].append(row_idx)
                self._index_json_value(v, row_idx, new_path)
        elif isinstance(val, list):
            for i, item in enumerate(val):
                new_path = f"{path}[{i}]"
                self.index[new_path].append(row_idx)
                self._index_json_value(item, row_idx, new_path)
        else:
            # Leaf value
            self.index[path].append(row_idx)
    
    def lookup(self, value: Any) -> List[int]:
        """Look up row indices for given value"""
        with self.lock:
            if self.index_type == IndexType.BTREE:
                return self.index.get(value, [])
            elif self.index_type == IndexType.HASH:
                hash_key = hash(value) % 1000000
                matches = []
                for val, idx in self.index.get(hash_key, []):
                    if val == value:
                        matches.append(idx)
                return matches
            elif self.index_type == IndexType.GIN:
                # For GIN, value should be a path or key
                return self.index.get(value, [])
            return []
    
    def range_lookup(self, start: Any, end: Any) -> List[int]:
        """Range lookup for B-tree indexes"""
        if self.index_type != IndexType.BTREE:
            return []
        
        with self.lock:
            matches = []
            for val, indices in self.index.items():
                if start <= val <= end:
                    matches.extend(indices)
            return matches
    
    def update_index(self, old_row: Dict, new_row: Dict, row_idx: int):
        """Update index after row modification"""
        with self.lock:
            old_val = old_row.get(self.column) if old_row else None
            new_val = new_row.get(self.column)
            
            # Remove old value
            if old_val is not None:
                if self.index_type == IndexType.BTREE:
                    if old_val in self.index and row_idx in self.index[old_val]:
                        self.index[old_val].remove(row_idx)
                        if not self.index[old_val]:
                            del self.index[old_val]
                elif self.index_type == IndexType.HASH:
                    hash_key = hash(old_val) % 1000000
                    self.index[hash_key] = [(v, i) for v, i in self.index.get(hash_key, []) if i != row_idx]
            
            # Add new value
            if new_val is not None:
                if self.index_type == IndexType.BTREE:
                    if new_val not in self.index:
                        self.index[new_val] = []
                    self.index[new_val].append(row_idx)
                elif self.index_type == IndexType.HASH:
                    hash_key = hash(new_val) % 1000000
                    if hash_key not in self.index:
                        self.index[hash_key] = []
                    self.index[hash_key].append((new_val, row_idx))
            
            self._save_index()
    
    def delete_index(self, row: Dict, row_idx: int):
        """Remove row from index"""
        self.update_index(row, None, row_idx)
    
    def drop(self):
        """Drop the index"""
        if os.path.exists(self.index_path):
            os.remove(self.index_path)

class ConstraintManager:
    """Manage table constraints (PK, FK, Unique, Not Null, Check, Default)"""
    
    def __init__(self, project_path: str, table: str):
        self.project_path = project_path
        self.table = table
        self.constraint_path = os.path.join(project_path, f"{table}{CONSTRAINT_EXT}")
        self.lock = threading.RLock()
        self.constraints = self._load_constraints()
    
    def _load_constraints(self) -> Dict:
        """Load constraints from disk"""
        if os.path.exists(self.constraint_path):
            try:
                with open(self.constraint_path, 'rb') as f:
                    return pickle.loads(gzip.decompress(f.read()))
            except:
                return {}
        return {}
    
    def _save_constraints(self):
        """Save constraints to disk"""
        with self.lock:
            compressed = gzip.compress(pickle.dumps(self.constraints))
            with tempfile.NamedTemporaryFile(mode='wb', delete=False) as temp_f:
                temp_f.write(compressed)
                temp_path = temp_f.name
            
            os.replace(temp_path, self.constraint_path)
    
    def add_constraint(self, name: str, constraint_type: ConstraintType, columns: List[str], 
                       check_expr: str = None, ref_table: str = None, ref_columns: List[str] = None,
                       default_value: Any = None):
        """Add a constraint to the table"""
        with self.lock:
            self.constraints[name] = {
                'type': constraint_type.value,
                'columns': columns,
                'check_expr': check_expr,
                'ref_table': ref_table,
                'ref_columns': ref_columns,
                'default_value': default_value,
                'created_at': datetime.now().isoformat()
            }
            self._save_constraints()
    
    def drop_constraint(self, name: str):
        """Drop a constraint"""
        with self.lock:
            if name in self.constraints:
                del self.constraints[name]
                self._save_constraints()
    
    def validate_insert(self, row: Dict, all_rows: List[Dict], row_idx: int = None) -> Tuple[bool, str]:
        """Validate row against all constraints"""
        for name, constraint in self.constraints.items():
            valid, msg = self._validate_constraint(constraint, row, all_rows, row_idx)
            if not valid:
                return False, f"Constraint '{name}' violated: {msg}"
        return True, "OK"
    
    def validate_update(self, old_row: Dict, new_row: Dict, all_rows: List[Dict], row_idx: int) -> Tuple[bool, str]:
        """Validate update against all constraints"""
        # For updates, we need to check with the new row
        return self.validate_insert(new_row, all_rows, row_idx)
    
    def _validate_constraint(self, constraint: Dict, row: Dict, all_rows: List[Dict], row_idx: int = None) -> Tuple[bool, str]:
        """Validate a single constraint"""
        constraint_type = constraint['type']
        columns = constraint['columns']
        
        if constraint_type == ConstraintType.NOT_NULL.value:
            for col in columns:
                if col not in row or row[col] is None:
                    return False, f"Column '{col}' cannot be NULL"
        
        elif constraint_type == ConstraintType.UNIQUE.value:
            for i, other in enumerate(all_rows):
                if i == row_idx:
                    continue
                match = True
                for col in columns:
                    if row.get(col) != other.get(col):
                        match = False
                        break
                if match:
                    cols_str = ', '.join(columns)
                    return False, f"Duplicate value for unique columns ({cols_str})"
        
        elif constraint_type == ConstraintType.PRIMARY_KEY.value:
            # PK implies NOT NULL and UNIQUE
            for col in columns:
                if col not in row or row[col] is None:
                    return False, f"Primary key column '{col}' cannot be NULL"
            
            for i, other in enumerate(all_rows):
                if i == row_idx:
                    continue
                match = True
                for col in columns:
                    if row.get(col) != other.get(col):
                        match = False
                        break
                if match:
                    cols_str = ', '.join(columns)
                    return False, f"Duplicate primary key ({cols_str})"
        
        elif constraint_type == ConstraintType.CHECK.value:
            # Simple check expression evaluation
            check_expr = constraint.get('check_expr', '')
            if check_expr:
                # Very simple evaluation - in real DB, this would use an expression evaluator
                try:
                    # Replace column names with values
                    expr = check_expr
                    for col, val in row.items():
                        expr = expr.replace(col, str(val))
                    if not eval(expr):
                        return False, f"Check constraint failed: {check_expr}"
                except:
                    return False, f"Error evaluating check constraint: {check_expr}"
        
        elif constraint_type == ConstraintType.FOREIGN_KEY.value:
            ref_table = constraint.get('ref_table')
            ref_columns = constraint.get('ref_columns', [])
            
            if not ref_table:
                return False, "Foreign key missing reference table"
            
            # This would require cross-table validation
            # Simplified - assume it's validated elsewhere
        
        elif constraint_type == ConstraintType.DEFAULT.value:
            default_value = constraint.get('default_value')
            for col in columns:
                if col not in row or row[col] is None:
                    row[col] = default_value
        
        return True, "OK"
    
    def get_defaults(self) -> Dict[str, Any]:
        """Get default values for columns"""
        defaults = {}
        for name, constraint in self.constraints.items():
            if constraint['type'] == ConstraintType.DEFAULT.value:
                for col in constraint['columns']:
                    defaults[col] = constraint.get('default_value')
        return defaults

class MVCCManager:
    """Multi-Version Concurrency Control for transaction isolation"""
    
    def __init__(self):
        self.transactions = {}  # tx_id -> transaction info
        self.row_versions = defaultdict(list)  # (table, row_id) -> list of versions
        self.lock = threading.RLock()
        self.next_tx_id = 1
        self.snapshot_cache = {}  # snapshot_id -> set of active transactions
    
    def begin_transaction(self, isolation_level: IsolationLevel) -> int:
        """Start a new transaction and return transaction ID"""
        with self.lock:
            tx_id = self.next_tx_id
            self.next_tx_id += 1
            
            self.transactions[tx_id] = {
                'id': tx_id,
                'start_time': time.time(),
                'isolation_level': isolation_level,
                'status': 'active',
                'snapshot': set(self.transactions.keys())  # Snapshot of active transactions
            }
            
            return tx_id
    
    def commit_transaction(self, tx_id: int):
        """Commit a transaction"""
        with self.lock:
            if tx_id in self.transactions:
                self.transactions[tx_id]['status'] = 'committed'
                self.transactions[tx_id]['end_time'] = time.time()
    
    def rollback_transaction(self, tx_id: int):
        """Rollback a transaction"""
        with self.lock:
            if tx_id in self.transactions:
                self.transactions[tx_id]['status'] = 'rolled_back'
                self.transactions[tx_id]['end_time'] = time.time()
                
                # Remove versions created by this transaction
                for key in list(self.row_versions.keys()):
                    self.row_versions[key] = [v for v in self.row_versions[key] if v.get('tx_id') != tx_id]
    
    def add_version(self, table: str, row_id: str, row_data: Dict, tx_id: int):
        """Add a new version of a row"""
        with self.lock:
            key = (table, row_id)
            version = {
                'tx_id': tx_id,
                'data': row_data,
                'timestamp': time.time()
            }
            self.row_versions[key].append(version)
    
    def get_visible_versions(self, table: str, tx_id: int) -> Dict[str, Dict]:
        """Get all visible versions for a transaction"""
        result = {}
        tx_info = self.transactions.get(tx_id, {})
        isolation = tx_info.get('isolation_level', IsolationLevel.READ_COMMITTED)
        snapshot = tx_info.get('snapshot', set())
        
        with self.lock:
            for (tbl, row_id), versions in self.row_versions.items():
                if tbl != table:
                    continue
                
                # Find the latest visible version
                visible_version = None
                
                # Sort versions by timestamp (newest first)
                sorted_versions = sorted(versions, key=lambda v: v['timestamp'], reverse=True)
                
                for version in sorted_versions:
                    v_tx_id = version['tx_id']
                    
                    # Check if this version is visible
                    if v_tx_id == tx_id:
                        # Own transaction's changes are always visible
                        visible_version = version
                        break
                    
                    v_tx_info = self.transactions.get(v_tx_id, {})
                    v_status = v_tx_info.get('status', 'committed')
                    
                    if isolation == IsolationLevel.READ_COMMITTED:
                        # In READ COMMITTED, see committed changes
                        if v_status == 'committed':
                            visible_version = version
                            break
                    
                    elif isolation == IsolationLevel.REPEATABLE_READ:
                        # In REPEATABLE READ, see snapshot at transaction start
                        if v_status == 'committed' and v_tx_id not in snapshot:
                            visible_version = version
                            break
                    
                    elif isolation == IsolationLevel.SERIALIZABLE:
                        # In SERIALIZABLE, similar to REPEATABLE READ but with stricter checks
                        if v_status == 'committed' and v_tx_id not in snapshot:
                            visible_version = version
                            break
                
                if visible_version:
                    result[row_id] = visible_version['data']
        
        return result

class CloudSyncManager:
    """Manage automatic cloud synchronization with immediate sync capability and backup restoration"""
    
    def __init__(self, config: Dict[str, Any], project_name: str):
        self.config = config
        self.project_name = project_name
        self.last_sync = {}
        self.sync_enabled = config.get('auto_sync', True)
        self.primary_storage = config.get('primary_storage', 'local')
        self.sync_queue = {}
        self.sync_thread = None
        self.sync_lock = threading.RLock()
        self.running = True
        self.backup_available = False
        self.backup_timestamp = None
        
        # Initialize cloud providers
        self.providers = {}
        self._initialize_primary_storage()
        
        # Start background sync thread
        self._start_sync_thread()
        
        # Check if backup is available on startup
        self._check_backup_availability()
    
    def _start_sync_thread(self):
        """Start background thread for processing sync queue"""
        def sync_worker():
            while self.running:
                time.sleep(1)  # Check queue every second
                self._process_sync_queue()
        
        self.sync_thread = threading.Thread(target=sync_worker, daemon=True)
        self.sync_thread.start()
    
    def _process_sync_queue(self):
        """Process pending sync operations"""
        with self.sync_lock:
            if not self.sync_queue:
                return
            
            current_time = time.time()
            tables_to_sync = []
            
            # Find tables that need immediate sync
            for table, sync_data in list(self.sync_queue.items()):
                if current_time - sync_data['timestamp'] < 0.5:  # Less than 500ms old
                    tables_to_sync.append((table, sync_data))
            
            for table, sync_data in tables_to_sync:
                try:
                    for provider_name, provider in self.providers.items():
                        provider.sync_table(self.project_name, table, sync_data['data'])
                    del self.sync_queue[table]
                    self.last_sync[table] = current_time
                except Exception as e:
                    print(f"⚠️ Cloud sync failed for {table}: {e}")
    
    def _initialize_primary_storage(self):
        """Initialize primary cloud storage"""
        if self.primary_storage == 'huggingface' and HUGGINGFACE_AVAILABLE:
            self.providers['huggingface'] = HuggingFaceBackup(self.config)
        elif self.primary_storage == 'google_drive' and GOOGLE_DRIVE_AVAILABLE:
            self.providers['google_drive'] = GoogleDriveBackup(self.config)
        elif self.primary_storage == 'aws_s3' and AWS_AVAILABLE:
            self.providers['aws_s3'] = AWSBackup(self.config)
        elif self.primary_storage == 'dropbox' and DROPBOX_AVAILABLE:
            self.providers['dropbox'] = DropboxBackup(self.config)
    
    def _check_backup_availability(self):
        """Check if backup is available in any provider"""
        for provider_name, provider in self.providers.items():
            try:
                if provider.exists(self.project_name):
                    self.backup_available = True
                    self.backup_timestamp = provider.get_last_backup_time(self.project_name)
                    break
            except:
                continue
    
    def restore_from_backup(self, table: str = None) -> Dict[str, Any]:
        """Restore data from backup (always queries backup first)"""
        if not self.backup_available:
            return {}
        
        restored_data = {}
        
        for provider_name, provider in self.providers.items():
            try:
                if table:
                    # Restore specific table
                    data = provider.get_table(self.project_name, table)
                    if data is not None:
                        restored_data[table] = data
                else:
                    # Restore all tables
                    data = provider.get_all_tables(self.project_name)
                    if data:
                        restored_data.update(data)
                
                # If we got data, break (use first successful provider)
                if restored_data:
                    break
                    
            except Exception as e:
                print(f"⚠️ Backup restore from {provider_name} failed: {e}")
                continue
        
        return restored_data
    
    def should_sync(self, table: str, operation: str) -> bool:
        """Check if sync should be performed"""
        if not self.sync_enabled or not self.providers:
            return False
        
        return True
    
    def sync_table(self, table: str, data: Any, operation: str):
        """Queue table for immediate cloud sync"""
        if not self.should_sync(table, operation):
            return
        
        with self.sync_lock:
            self.sync_queue[table] = {
                'data': data,
                'operation': operation,
                'timestamp': time.time()
            }
            
            # Update backup availability flag
            self.backup_available = True
            self.backup_timestamp = time.time()
    
    def force_sync(self, table: str = None):
        """Force immediate sync for all tables or specific table"""
        with self.sync_lock:
            if table:
                if table in self.sync_queue:
                    sync_data = self.sync_queue[table]
                    try:
                        for provider_name, provider in self.providers.items():
                            provider.sync_table(self.project_name, table, sync_data['data'])
                        del self.sync_queue[table]
                    except Exception as e:
                        print(f"⚠️ Force sync failed for {table}: {e}")
            else:
                # Sync all queued tables
                for table, sync_data in list(self.sync_queue.items()):
                    try:
                        for provider_name, provider in self.providers.items():
                            provider.sync_table(self.project_name, table, sync_data['data'])
                        del self.sync_queue[table]
                    except Exception as e:
                        print(f"⚠️ Force sync failed for {table}: {e}")
    
    def stop(self):
        """Stop the sync thread"""
        self.running = False
        if self.sync_thread:
            self.sync_thread.join(timeout=2)

class AdvancedNLU:
    """Advanced Natural Language Understanding for database queries"""
    
    def __init__(self):
        self.synonyms = {
            'show': ['display', 'list', 'get', 'find', 'retrieve', 'view', 'see'],
            'count': ['total', 'number of', 'how many', 'count'],
            'sum': ['total', 'add up', 'summarize', 'sum'],
            'average': ['avg', 'mean', 'average'],
            'where': ['filter', 'with', 'having', 'where', 'if'],
            'order by': ['sort by', 'arrange by', 'order by'],
            'group by': ['categorize by', 'organize by', 'group by', 'group'],
            'limit': ['top', 'first', 'last', 'limit'],
            'users': ['people', 'persons', 'customers', 'user'],
            'jobs': ['positions', 'roles', 'employment', 'job'],
            'orders': ['purchases', 'transactions', 'order'],
            'salary': ['pay', 'income', 'wage', 'salary'],
            'age': ['years old', 'age', 'older than', 'younger than'],
            'city': ['location', 'place', 'city'],
            'insert': ['add', 'create new', 'insert'],
            'update': ['change', 'modify', 'update'],
            'delete': ['remove', 'delete'],
            'join': ['combine', 'with', 'join'],
            'alter': ['modify table', 'add column', 'alter', 'drop column']
        }
        # Common table assumptions (expandable)
        self.common_tables = ['users', 'orders', 'products']
    
    def normalize_text(self, text: str) -> str:
        """Normalize text for better matching"""
        text = text.lower().strip()
        text = re.sub(r'[^\w\s]', ' ', text)  # Remove punctuation
        
        # Replace synonyms
        for standard, alternatives in self.synonyms.items():
            for alt in alternatives:
                text = re.sub(rf'\b{re.escape(alt)}\b', standard, text)
        
        return text
    
    def detect_query_type(self, text: str) -> QueryType:
        """Detect the type of query from natural language"""
        text = self.normalize_text(text)
        
        if any(word in text for word in ['count', 'how many', 'number of']):
            return QueryType.COUNT
        elif any(word in text for word in ['sum', 'total of', 'add up']):
            return QueryType.SUM
        elif any(word in text for word in ['average', 'avg', 'mean']):
            return QueryType.AVG
        elif any(word in text for word in ['show', 'display', 'list', 'get', 'find']):
            return QueryType.SELECT
        elif any(word in text for word in ['insert', 'add', 'create new']):
            return QueryType.INSERT
        elif any(word in text for word in ['update', 'change', 'modify']):
            return QueryType.UPDATE
        elif any(word in text for word in ['delete', 'remove']):
            return QueryType.DELETE
        elif any(word in text for word in ['group by', 'categorize']):
            return QueryType.GROUP_BY
        elif any(word in text for word in ['join', 'combine']):
            return QueryType.JOIN
        elif any(word in text for word in ['alter', 'add column', 'drop column']):
            return QueryType.ALTER
        
        return QueryType.UNKNOWN

    def extract_conditions(self, text: str) -> Dict[str, Any]:
        """Extract WHERE conditions, ORDER BY, LIMIT, table from text (enhanced)"""
        text = self.normalize_text(text)
        conditions = {}
        
        # Table detection
        for table in self.common_tables:
            if table in text:
                conditions['table'] = table
                break
        if 'table' not in conditions:
            conditions['table'] = self.common_tables[0]  # Default to 'users'
        
        # WHERE: age >/< =, city LIKE, etc.
        age_gt = re.findall(r'age\s+(over|above|greater than|older than)\s+(\d+)', text)
        if age_gt:
            conditions['age'] = f"> {age_gt[0][1]}"
        
        age_lt = re.findall(r'age\s+(under|below|less than|younger than)\s+(\d+)', text)
        if age_lt:
            conditions['age'] = f"< {age_lt[0][1]}"
        
        city_match = re.findall(r'city\s+(in|from|equals?)\s+([a-zA-Z\s]+)', text)
        if city_match:
            city_val = city_match[0][1].strip()
            conditions['city'] = f"= '{city_val}'" if 'equals' in city_match[0][0] else f"LIKE '%{city_val}%'"
        
        # Multiple conditions (simple AND)
        if len([c for c in conditions if c in ['age', 'city']]) > 1:
            conditions['where_op'] = 'AND'
        
        # ORDER BY
        order_match = re.search(r'order by\s+([a-zA-Z]+)', text)
        if order_match:
            conditions['order_by'] = order_match.group(1)
        
        # GROUP BY
        group_match = re.search(r'group by\s+([a-zA-Z]+)', text)
        if group_match:
            conditions['group_by'] = group_match.group(1)
        
        # LIMIT
        limit_match = re.search(r'(top|first)\s+(\d+)', text)
        if limit_match:
            conditions['limit'] = limit_match.group(2)
        
        return conditions

class BackupManager:
    """Manage multiple backup storage providers with automatic restoration"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.providers = {}
        
        # Initialize enabled providers
        if config.get('google_drive_enabled', False) and GOOGLE_DRIVE_AVAILABLE:
            self.providers['google_drive'] = GoogleDriveBackup(config)
        
        if config.get('huggingface_enabled', False) and HUGGINGFACE_AVAILABLE:
            self.providers['huggingface'] = HuggingFaceBackup(config)
        
        if config.get('aws_s3_enabled', False) and AWS_AVAILABLE:
            self.providers['aws_s3'] = AWSBackup(config)
        
        if config.get('dropbox_enabled', False) and DROPBOX_AVAILABLE:
            self.providers['dropbox'] = DropboxBackup(config)
    
    def backup_database(self, project_name: str, local_path: str) -> Dict[str, str]:
        """Backup database to all enabled providers"""
        results = {}
        
        for name, provider in self.providers.items():
            try:
                result = provider.backup(project_name, local_path)
                results[name] = f"✅ {result}"
            except Exception as e:
                results[name] = f"❌ {str(e)}"
        
        return results
    
    def restore_database(self, project_name: str, local_path: str, provider: str = None) -> str:
        """Restore database from specified provider or auto-detect"""
        if provider and provider in self.providers:
            return self.providers[provider].restore(project_name, local_path)
        
        # Auto-detect from any available provider
        for name, provider_instance in self.providers.items():
            try:
                if provider_instance.exists(project_name):
                    return provider_instance.restore(project_name, local_path)
            except:
                continue
        
        return "❌ No backup found in any provider"
    
    def get_table_from_backup(self, project_name: str, table: str) -> Optional[List[Dict]]:
        """Get specific table data from backup"""
        for name, provider in self.providers.items():
            try:
                data = provider.get_table(project_name, table)
                if data is not None:
                    return data
            except:
                continue
        return None
    
    def get_all_tables_from_backup(self, project_name: str) -> Dict[str, List[Dict]]:
        """Get all table data from backup"""
        for name, provider in self.providers.items():
            try:
                data = provider.get_all_tables(project_name)
                if data:
                    return data
            except:
                continue
        return {}

class HuggingFaceBackup:
    """HuggingFace Hub storage implementation with immediate sync and backup restoration"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.token = config.get('huggingface_token')
        self.repo_id = config.get('huggingface_repo_id')
        self.sync_queue = {}
        self.sync_lock = threading.RLock()
        self.cache = {}  # In-memory cache for quick access
        
        if self.token and HUGGINGFACE_AVAILABLE:
            try:
                login(token=self.token)
                self.api = HfApi()
                self.initialized = True
            except Exception as e:
                print(f"⚠️ HuggingFace login failed: {e}")
                self.initialized = False
        else:
            self.initialized = False
    
    def backup(self, project_name: str, local_path: str) -> str:
        """Backup entire database to HuggingFace"""
        if not self.initialized:
            return "HuggingFace not initialized"
        
        try:
            files_uploaded = 0
            for root, dirs, files in os.walk(local_path):
                for file in files:
                    if file.endswith(('.sdb', '.backup', '.idx', '.con', '.wal')):
                        file_path = os.path.join(root, file)
                        repo_path = f"{project_name}/{file}"
                        
                        self.api.upload_file(
                            path_or_fileobj=file_path,
                            path_in_repo=repo_path,
                            repo_id=self.repo_id,
                            repo_type="dataset"
                        )
                        files_uploaded += 1
            
            # Update cache
            self.cache[project_name] = {'last_backup': time.time()}
            
            return f"Backup completed: {files_uploaded} files to HuggingFace"
        except Exception as e:
            return f"Upload failed: {str(e)}"
    
    def sync_table(self, project_name: str, table: str, data: Any):
        """Sync single table to HuggingFace immediately"""
        if not self.initialized:
            return
        
        try:
            # Convert data to compressed format
            serialized = pickle.dumps(data)
            compressed = gzip.compress(serialized)
            
            # Upload to HuggingFace immediately
            self.api.upload_file(
                path_or_fileobj=io.BytesIO(compressed),
                path_in_repo=f"{project_name}/{table}.sdb",
                repo_id=self.repo_id,
                repo_type="dataset"
            )
            
            # Update cache
            if project_name not in self.cache:
                self.cache[project_name] = {}
            self.cache[project_name][table] = {
                'data': data,
                'timestamp': time.time()
            }
            
        except Exception as e:
            print(f"⚠️ HuggingFace sync failed for {table}: {e}")
            # Queue for retry
            with self.sync_lock:
                self.sync_queue[table] = {
                    'data': data,
                    'timestamp': time.time()
                }
    
    def exists(self, project_name: str) -> bool:
        """Check if project exists in HuggingFace"""
        if not self.initialized:
            return False
        
        try:
            files = self.api.list_repo_files(repo_id=self.repo_id, repo_type="dataset")
            return any(f.startswith(f"{project_name}/") for f in files)
        except:
            return False
    
    def get_last_backup_time(self, project_name: str) -> Optional[float]:
        """Get timestamp of last backup"""
        if project_name in self.cache:
            return self.cache[project_name].get('last_backup')
        return None
    
    def get_table(self, project_name: str, table: str) -> Optional[List[Dict]]:
        """Get specific table data from HuggingFace"""
        if not self.initialized:
            return None
        
        # Check cache first
        if project_name in self.cache and table in self.cache[project_name]:
            cache_entry = self.cache[project_name][table]
            if time.time() - cache_entry['timestamp'] < 300:  # 5 minute cache
                return cache_entry['data']
        
        try:
            file_path = f"{project_name}/{table}.sdb"
            
            # Download file
            downloaded_path = hf_hub_download(
                repo_id=self.repo_id,
                filename=file_path,
                repo_type="dataset"
            )
            
            # Read and decompress
            with open(downloaded_path, 'rb') as f:
                compressed_data = f.read()
            
            if compressed_data:
                decompressed = gzip.decompress(compressed_data)
                data = pickle.loads(decompressed)
                
                # Update cache
                if project_name not in self.cache:
                    self.cache[project_name] = {}
                self.cache[project_name][table] = {
                    'data': data,
                    'timestamp': time.time()
                }
                
                return data
            
        except Exception as e:
            print(f"⚠️ Failed to get table {table} from HuggingFace: {e}")
        
        return None
    
    def get_all_tables(self, project_name: str) -> Dict[str, List[Dict]]:
        """Get all tables data from HuggingFace"""
        if not self.initialized:
            return {}
        
        try:
            files = self.api.list_repo_files(repo_id=self.repo_id, repo_type="dataset")
            project_files = [f for f in files if f.startswith(f"{project_name}/") and f.endswith('.sdb')]
            
            result = {}
            for file_path in project_files:
                table = os.path.basename(file_path)[:-4]  # Remove .sdb
                
                # Check cache
                if project_name in self.cache and table in self.cache[project_name]:
                    cache_entry = self.cache[project_name][table]
                    if time.time() - cache_entry['timestamp'] < 300:
                        result[table] = cache_entry['data']
                        continue
                
                # Download and parse
                downloaded_path = hf_hub_download(
                    repo_id=self.repo_id,
                    filename=file_path,
                    repo_type="dataset"
                )
                
                with open(downloaded_path, 'rb') as f:
                    compressed_data = f.read()
                
                if compressed_data:
                    decompressed = gzip.decompress(compressed_data)
                    data = pickle.loads(decompressed)
                    result[table] = data
                    
                    # Update cache
                    if project_name not in self.cache:
                        self.cache[project_name] = {}
                    self.cache[project_name][table] = {
                        'data': data,
                        'timestamp': time.time()
                    }
            
            return result
            
        except Exception as e:
            print(f"⚠️ Failed to get all tables from HuggingFace: {e}")
            return {}
    
    def restore(self, project_name: str, local_path: str) -> str:
        """Restore database from HuggingFace"""
        if not self.initialized:
            return "HuggingFace not initialized"
        
        try:
            files = self.api.list_repo_files(repo_id=self.repo_id, repo_type="dataset")
            project_files = [f for f in files if f.startswith(f"{project_name}/")]
            
            restored_count = 0
            for file_path in project_files:
                local_file_path = os.path.join(local_path, os.path.basename(file_path))
                
                # Download file
                downloaded_path = hf_hub_download(
                    repo_id=self.repo_id,
                    filename=file_path,
                    repo_type="dataset"
                )
                
                # Copy to local path
                shutil.copy2(downloaded_path, local_file_path)
                restored_count += 1
            
            return f"Restored {restored_count} files from HuggingFace"
        except Exception as e:
            return f"Restore failed: {str(e)}"

class GoogleDriveBackup:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.service = None
        self.cache = {}
        if config.get('google_drive_enabled', False):
            self._authenticate()
    
    def _authenticate(self):
        try:
            creds = None
            token_file = self.config.get('google_token_file', 'token.json')
            credentials_file = self.config.get('google_credentials_file', 'credentials.json')
            
            if os.path.exists(token_file):
                creds = Credentials.from_authorized_user_file(token_file, ['https://www.googleapis.com/auth/drive.file'])
            
            if not creds or not creds.valid:
                if creds and creds.expired and creds.refresh_token:
                    creds.refresh(Request())
                else:
                    flow = InstalledAppFlow.from_client_secrets_file(credentials_file, ['https://www.googleapis.com/auth/drive.file'])
                    creds = flow.run_local_server(port=0)
                
                with open(token_file, 'w') as token:
                    token.write(creds.to_json())
            
            self.service = build('drive', 'v3', credentials=creds)
        except Exception as e:
            print(f"⚠️ Google Drive authentication failed: {e}")
    
    def sync_table(self, project_name: str, table: str, data: Any):
        """Sync table to Google Drive"""
        if not self.service:
            return
        
        try:
            # Convert to compressed format
            serialized = pickle.dumps(data)
            compressed = gzip.compress(serialized)
            file_name = f"{project_name}_{table}.sdb"
            
            # Search for existing file
            results = self.service.files().list(
                q=f"name='{file_name}'",
                fields="files(id, name)"
            ).execute()
            
            files = results.get('files', [])
            
            # Create file metadata
            file_metadata = {
                'name': file_name
            }
            
            # Create media
            media = MediaIoBaseUpload(
                io.BytesIO(compressed),
                mimetype='application/octet-stream',
                resumable=True
            )
            
            if files:
                # Update existing file
                file_id = files[0]['id']
                self.service.files().update(
                    fileId=file_id,
                    media_body=media
                ).execute()
            else:
                # Create new file
                self.service.files().create(
                    body=file_metadata,
                    media_body=media,
                    fields='id'
                ).execute()
            
            # Update cache
            if project_name not in self.cache:
                self.cache[project_name] = {}
            self.cache[project_name][table] = {
                'data': data,
                'timestamp': time.time()
            }
                
        except Exception as e:
            print(f"⚠️ Google Drive sync failed for {table}: {e}")
    
    def exists(self, project_name: str) -> bool:
        """Check if project exists in Google Drive"""
        if not self.service:
            return False
        
        try:
            results = self.service.files().list(
                q=f"name contains '{project_name}_'",
                fields="files(id, name)"
            ).execute()
            
            files = results.get('files', [])
            return len(files) > 0
        except:
            return False
    
    def get_last_backup_time(self, project_name: str) -> Optional[float]:
        """Get timestamp of last backup"""
        if project_name in self.cache:
            return self.cache[project_name].get('last_backup')
        return None
    
    def get_table(self, project_name: str, table: str) -> Optional[List[Dict]]:
        """Get specific table data from Google Drive"""
        if not self.service:
            return None
        
        # Check cache
        if project_name in self.cache and table in self.cache[project_name]:
            cache_entry = self.cache[project_name][table]
            if time.time() - cache_entry['timestamp'] < 300:
                return cache_entry['data']
        
        try:
            file_name = f"{project_name}_{table}.sdb"
            
            # Search for file
            results = self.service.files().list(
                q=f"name='{file_name}'",
                fields="files(id, name)"
            ).execute()
            
            files = results.get('files', [])
            if not files:
                return None
            
            file_id = files[0]['id']
            
            # Download file
            request = self.service.files().get_media(fileId=file_id)
            file_data = io.BytesIO()
            downloader = MediaIoBaseDownload(file_data, request)
            
            done = False
            while not done:
                status, done = downloader.next_chunk()
            
            file_data.seek(0)
            compressed_data = file_data.read()
            
            if compressed_data:
                decompressed = gzip.decompress(compressed_data)
                data = pickle.loads(decompressed)
                
                # Update cache
                if project_name not in self.cache:
                    self.cache[project_name] = {}
                self.cache[project_name][table] = {
                    'data': data,
                    'timestamp': time.time()
                }
                
                return data
            
        except Exception as e:
            print(f"⚠️ Failed to get table {table} from Google Drive: {e}")
        
        return None
    
    def get_all_tables(self, project_name: str) -> Dict[str, List[Dict]]:
        """Get all tables data from Google Drive"""
        if not self.service:
            return {}
        
        try:
            results = self.service.files().list(
                q=f"name contains '{project_name}_' and name contains '.sdb'",
                fields="files(id, name)"
            ).execute()
            
            files = results.get('files', [])
            
            result = {}
            for file_info in files:
                file_name = file_info['name']
                table = file_name[len(project_name)+1:-4]  # Remove project_name_ and .sdb
                
                # Check cache
                if project_name in self.cache and table in self.cache[project_name]:
                    cache_entry = self.cache[project_name][table]
                    if time.time() - cache_entry['timestamp'] < 300:
                        result[table] = cache_entry['data']
                        continue
                
                # Download
                file_id = file_info['id']
                request = self.service.files().get_media(fileId=file_id)
                file_data = io.BytesIO()
                downloader = MediaIoBaseDownload(file_data, request)
                
                done = False
                while not done:
                    status, done = downloader.next_chunk()
                
                file_data.seek(0)
                compressed_data = file_data.read()
                
                if compressed_data:
                    decompressed = gzip.decompress(compressed_data)
                    data = pickle.loads(decompressed)
                    result[table] = data
                    
                    # Update cache
                    if project_name not in self.cache:
                        self.cache[project_name] = {}
                    self.cache[project_name][table] = {
                        'data': data,
                        'timestamp': time.time()
                    }
            
            return result
            
        except Exception as e:
            print(f"⚠️ Failed to get all tables from Google Drive: {e}")
            return {}
    
    def restore(self, project_name: str, local_path: str) -> str:
        """Restore database from Google Drive"""
        if not self.service:
            return "Google Drive not authenticated"
        
        try:
            results = self.service.files().list(
                q=f"name contains '{project_name}_'",
                fields="files(id, name)"
            ).execute()
            
            files = results.get('files', [])
            
            restored_count = 0
            for file_info in files:
                file_name = file_info['name']
                local_file_path = os.path.join(local_path, file_name)
                
                # Download file
                file_id = file_info['id']
                request = self.service.files().get_media(fileId=file_id)
                
                with open(local_file_path, 'wb') as f:
                    downloader = MediaIoBaseDownload(f, request)
                    
                    done = False
                    while not done:
                        status, done = downloader.next_chunk()
                
                restored_count += 1
            
            return f"Restored {restored_count} files from Google Drive"
        except Exception as e:
            return f"Restore failed: {str(e)}"

class AWSBackup:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.cache = {}
        if config.get('aws_s3_enabled', False):
            try:
                self.s3_client = boto3.client(
                    's3',
                    aws_access_key_id=config.get('aws_access_key'),
                    aws_secret_access_key=config.get('aws_secret_key'),
                    region_name=config.get('aws_region', 'us-east-1')
                )
                self.bucket_name = config.get('aws_bucket_name')
            except Exception as e:
                print(f"⚠️ AWS S3 initialization failed: {e}")
    
    def sync_table(self, project_name: str, table: str, data: Any):
        """Sync table to AWS S3"""
        if not hasattr(self, 's3_client'):
            return
        
        try:
            # Convert to compressed format
            serialized = pickle.dumps(data)
            compressed = gzip.compress(serialized)
            key = f"{project_name}/{table}.sdb"
            
            # Upload to S3
            self.s3_client.put_object(
                Bucket=self.bucket_name,
                Key=key,
                Body=compressed,
                ContentType='application/octet-stream'
            )
            
            # Update cache
            if project_name not in self.cache:
                self.cache[project_name] = {}
            self.cache[project_name][table] = {
                'data': data,
                'timestamp': time.time()
            }
            
        except Exception as e:
            print(f"⚠️ AWS S3 sync failed for {table}: {e}")
    
    def exists(self, project_name: str) -> bool:
        """Check if project exists in S3"""
        if not hasattr(self, 's3_client'):
            return False
        
        try:
            response = self.s3_client.list_objects_v2(
                Bucket=self.bucket_name,
                Prefix=f"{project_name}/",
                MaxKeys=1
            )
            return 'Contents' in response
        except:
            return False
    
    def get_last_backup_time(self, project_name: str) -> Optional[float]:
        """Get timestamp of last backup"""
        if project_name in self.cache:
            return self.cache[project_name].get('last_backup')
        return None
    
    def get_table(self, project_name: str, table: str) -> Optional[List[Dict]]:
        """Get specific table data from S3"""
        if not hasattr(self, 's3_client'):
            return None
        
        # Check cache
        if project_name in self.cache and table in self.cache[project_name]:
            cache_entry = self.cache[project_name][table]
            if time.time() - cache_entry['timestamp'] < 300:
                return cache_entry['data']
        
        try:
            key = f"{project_name}/{table}.sdb"
            
            response = self.s3_client.get_object(
                Bucket=self.bucket_name,
                Key=key
            )
            
            compressed_data = response['Body'].read()
            
            if compressed_data:
                decompressed = gzip.decompress(compressed_data)
                data = pickle.loads(decompressed)
                
                # Update cache
                if project_name not in self.cache:
                    self.cache[project_name] = {}
                self.cache[project_name][table] = {
                    'data': data,
                    'timestamp': time.time()
                }
                
                return data
            
        except Exception as e:
            print(f"⚠️ Failed to get table {table} from S3: {e}")
        
        return None
    
    def get_all_tables(self, project_name: str) -> Dict[str, List[Dict]]:
        """Get all tables data from S3"""
        if not hasattr(self, 's3_client'):
            return {}
        
        try:
            response = self.s3_client.list_objects_v2(
                Bucket=self.bucket_name,
                Prefix=f"{project_name}/"
            )
            
            if 'Contents' not in response:
                return {}
            
            result = {}
            for obj in response['Contents']:
                key = obj['Key']
                if key.endswith('.sdb'):
                    table = key.split('/')[-1][:-4]  # Remove .sdb
                    
                    # Check cache
                    if project_name in self.cache and table in self.cache[project_name]:
                        cache_entry = self.cache[project_name][table]
                        if time.time() - cache_entry['timestamp'] < 300:
                            result[table] = cache_entry['data']
                            continue
                    
                    # Download
                    obj_response = self.s3_client.get_object(
                        Bucket=self.bucket_name,
                        Key=key
                    )
                    
                    compressed_data = obj_response['Body'].read()
                    
                    if compressed_data:
                        decompressed = gzip.decompress(compressed_data)
                        data = pickle.loads(decompressed)
                        result[table] = data
                        
                        # Update cache
                        if project_name not in self.cache:
                            self.cache[project_name] = {}
                        self.cache[project_name][table] = {
                            'data': data,
                            'timestamp': time.time()
                        }
            
            return result
            
        except Exception as e:
            print(f"⚠️ Failed to get all tables from S3: {e}")
            return {}
    
    def restore(self, project_name: str, local_path: str) -> str:
        """Restore database from S3"""
        if not hasattr(self, 's3_client'):
            return "AWS S3 not initialized"
        
        try:
            response = self.s3_client.list_objects_v2(
                Bucket=self.bucket_name,
                Prefix=f"{project_name}/"
            )
            
            if 'Contents' not in response:
                return "No files found in S3"
            
            restored_count = 0
            for obj in response['Contents']:
                key = obj['Key']
                local_file_path = os.path.join(local_path, os.path.basename(key))
                
                # Download file
                obj_response = self.s3_client.get_object(
                    Bucket=self.bucket_name,
                    Key=key
                )
                
                with open(local_file_path, 'wb') as f:
                    f.write(obj_response['Body'].read())
                
                restored_count += 1
            
            return f"Restored {restored_count} files from AWS S3"
        except Exception as e:
            return f"Restore failed: {str(e)}"

class DropboxBackup:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.cache = {}
        if config.get('dropbox_enabled', False):
            try:
                self.access_token = config.get('dropbox_access_token')
                self.dbx = dropbox.Dropbox(self.access_token) if self.access_token else None
            except Exception as e:
                print(f"⚠️ Dropbox initialization failed: {e}")
    
    def sync_table(self, project_name: str, table: str, data: Any):
        """Sync table to Dropbox"""
        if not self.dbx:
            return
        
        try:
            # Convert to compressed format
            serialized = pickle.dumps(data)
            compressed = gzip.compress(serialized)
            path = f"/{project_name}/{table}.sdb"
            
            # Upload to Dropbox
            self.dbx.files_upload(
                compressed,
                path,
                mode=dropbox.files.WriteMode.overwrite
            )
            
            # Update cache
            if project_name not in self.cache:
                self.cache[project_name] = {}
            self.cache[project_name][table] = {
                'data': data,
                'timestamp': time.time()
            }
            
        except Exception as e:
            print(f"⚠️ Dropbox sync failed for {table}: {e}")
    
    def exists(self, project_name: str) -> bool:
        """Check if project exists in Dropbox"""
        if not self.dbx:
            return False
        
        try:
            self.dbx.files_list_folder(f"/{project_name}")
            return True
        except:
            return False
    
    def get_last_backup_time(self, project_name: str) -> Optional[float]:
        """Get timestamp of last backup"""
        if project_name in self.cache:
            return self.cache[project_name].get('last_backup')
        return None
    
    def get_table(self, project_name: str, table: str) -> Optional[List[Dict]]:
        """Get specific table data from Dropbox"""
        if not self.dbx:
            return None
        
        # Check cache
        if project_name in self.cache and table in self.cache[project_name]:
            cache_entry = self.cache[project_name][table]
            if time.time() - cache_entry['timestamp'] < 300:
                return cache_entry['data']
        
        try:
            path = f"/{project_name}/{table}.sdb"
            
            metadata, response = self.dbx.files_download(path)
            compressed_data = response.content
            
            if compressed_data:
                decompressed = gzip.decompress(compressed_data)
                data = pickle.loads(decompressed)
                
                # Update cache
                if project_name not in self.cache:
                    self.cache[project_name] = {}
                self.cache[project_name][table] = {
                    'data': data,
                    'timestamp': time.time()
                }
                
                return data
            
        except Exception as e:
            print(f"⚠️ Failed to get table {table} from Dropbox: {e}")
        
        return None
    
    def get_all_tables(self, project_name: str) -> Dict[str, List[Dict]]:
        """Get all tables data from Dropbox"""
        if not self.dbx:
            return {}
        
        try:
            result = self.dbx.files_list_folder(f"/{project_name}")
            
            all_tables = {}
            for entry in result.entries:
                if isinstance(entry, dropbox.files.FileMetadata) and entry.name.endswith('.sdb'):
                    table = entry.name[:-4]  # Remove .sdb
                    
                    # Check cache
                    if project_name in self.cache and table in self.cache[project_name]:
                        cache_entry = self.cache[project_name][table]
                        if time.time() - cache_entry['timestamp'] < 300:
                            all_tables[table] = cache_entry['data']
                            continue
                    
                    # Download
                    path = f"/{project_name}/{entry.name}"
                    metadata, response = self.dbx.files_download(path)
                    compressed_data = response.content
                    
                    if compressed_data:
                        decompressed = gzip.decompress(compressed_data)
                        data = pickle.loads(decompressed)
                        all_tables[table] = data
                        
                        # Update cache
                        if project_name not in self.cache:
                            self.cache[project_name] = {}
                        self.cache[project_name][table] = {
                            'data': data,
                            'timestamp': time.time()
                        }
            
            return all_tables
            
        except Exception as e:
            print(f"⚠️ Failed to get all tables from Dropbox: {e}")
            return {}
    
    def restore(self, project_name: str, local_path: str) -> str:
        """Restore database from Dropbox"""
        if not self.dbx:
            return "Dropbox not initialized"
        
        try:
            result = self.dbx.files_list_folder(f"/{project_name}")
            
            restored_count = 0
            for entry in result.entries:
                if isinstance(entry, dropbox.files.FileMetadata):
                    local_file_path = os.path.join(local_path, entry.name)
                    
                    # Download file
                    metadata, response = self.dbx.files_download(f"/{project_name}/{entry.name}")
                    
                    with open(local_file_path, 'wb') as f:
                        f.write(response.content)
                    
                    restored_count += 1
            
            return f"Restored {restored_count} files from Dropbox"
        except Exception as e:
            return f"Restore failed: {str(e)}"

class QueryOptimizer:
    """Optimize queries for better performance"""
    
    def __init__(self):
        self.query_cache = {}
        self.cache_size = 100
        self.plan_cache = {}
    
    def get_cache_key(self, query: str) -> str:
        """Generate cache key from query"""
        return hashlib.md5(query.encode()).hexdigest()
    
    def cache_result(self, query: str, result: Any):
        """Cache query result"""
        if len(self.query_cache) >= self.cache_size:
            # Remove oldest entry
            self.query_cache.pop(next(iter(self.query_cache)))
        
        cache_key = self.get_cache_key(query)
        self.query_cache[cache_key] = {
            'result': result,
            'timestamp': time.time()
        }
    
    def get_cached_result(self, query: str) -> Optional[Any]:
        """Get cached result for query"""
        cache_key = self.get_cache_key(query)
        cached = self.query_cache.get(cache_key)
        
        if cached and time.time() - cached['timestamp'] < 300:  # 5 minutes cache
            return cached['result']
        
        return None
    
    def get_execution_plan(self, query: str) -> Dict[str, Any]:
        """Generate and cache execution plan"""
        cache_key = f"plan_{self.get_cache_key(query)}"
        
        if cache_key in self.plan_cache:
            cached = self.plan_cache[cache_key]
            if time.time() - cached['timestamp'] < 3600:  # 1 hour cache for plans
                return cached['plan']
        
        # Generate plan (simplified)
        plan = {
            'query': query,
            'type': self._detect_query_type(query),
            'tables': self._extract_tables(query),
            'estimated_cost': len(query) / 100,  # Placeholder
            'index_usage': self._suggest_indexes(query)
        }
        
        self.plan_cache[cache_key] = {
            'plan': plan,
            'timestamp': time.time()
        }
        
        return plan
    
    def _detect_query_type(self, query: str) -> str:
        """Detect query type"""
        query_upper = query.upper().strip()
        if query_upper.startswith('SELECT'):
            return 'SELECT'
        elif query_upper.startswith('INSERT'):
            return 'INSERT'
        elif query_upper.startswith('UPDATE'):
            return 'UPDATE'
        elif query_upper.startswith('DELETE'):
            return 'DELETE'
        return 'UNKNOWN'
    
    def _extract_tables(self, query: str) -> List[str]:
        """Extract table names from query"""
        # Simplified - just look for FROM and JOIN
        tables = []
        from_match = re.search(r'FROM\s+(\w+)', query, re.IGNORECASE)
        if from_match:
            tables.append(from_match.group(1))
        
        join_matches = re.findall(r'JOIN\s+(\w+)', query, re.IGNORECASE)
        tables.extend(join_matches)
        
        return tables
    
    def _suggest_indexes(self, query: str) -> List[str]:
        """Suggest indexes based on query"""
        suggestions = []
        
        # Look for WHERE conditions
        where_match = re.search(r'WHERE\s+(\w+)\s*=', query, re.IGNORECASE)
        if where_match:
            suggestions.append(f"Consider index on {where_match.group(1)}")
        
        # Look for ORDER BY
        order_match = re.search(r'ORDER\s+BY\s+(\w+)', query, re.IGNORECASE)
        if order_match:
            suggestions.append(f"Consider index on {order_match.group(1)} for sorting")
        
        return suggestions

class AdvancedAItoSQL:
    """Advanced AI to SQL converter (rule-based, no LLM, enhanced robustness)"""
    
    def __init__(self):
        self.nlu = AdvancedNLU()
        self.optimizer = QueryOptimizer()
    
    def convert(self, prompt: str) -> str:
        """Convert natural language to SQL (enhanced rule-based)"""
        
        # Check cache first
        cached_sql = self.optimizer.get_cached_result(prompt)
        if cached_sql:
            return cached_sql
        
        # Analyze query
        query_type = self.nlu.detect_query_type(prompt)
        conditions = self.nlu.extract_conditions(prompt)
        table = conditions.get('table', 'users')
        
        # Build SQL based on query type and conditions
        if query_type == QueryType.COUNT:
            sql = f"SELECT COUNT(*) as count FROM {table}"
        elif query_type == QueryType.SUM:
            agg_col = 'age' if 'age' in prompt.lower() else 'salary'  # Infer column
            sql = f"SELECT SUM({agg_col}) as total_{agg_col} FROM {table}"
        elif query_type == QueryType.AVG:
            agg_col = 'age' if 'age' in prompt.lower() else 'salary'
            sql = f"SELECT AVG({agg_col}) as avg_{agg_col} FROM {table}"
        elif query_type == QueryType.SELECT:
            columns = "*" if "all" in prompt.lower() else "name, age, city"  # Default columns
            sql = f"SELECT {columns} FROM {table}"
        elif query_type == QueryType.GROUP_BY:
            group_col = conditions.get('group_by', 'city')
            sql = f"SELECT {group_col}, COUNT(*) FROM {table} GROUP BY {group_col}"
        elif query_type == QueryType.JOIN:
            sql = f"SELECT * FROM {table} JOIN orders ON {table}.id = orders.user_id"  # Enhanced stub
        elif query_type == QueryType.INSERT:
            sql = f"INSERT INTO {table} DATA = {{}}"  # Placeholder
        elif query_type == QueryType.UPDATE:
            set_col = 'salary' if 'salary' in prompt.lower() else 'age'
            sql = f"UPDATE {table} SET {set_col} = {set_col} + 1"  # Example increment
        elif query_type == QueryType.DELETE:
            sql = f"DELETE FROM {table}"
        elif query_type == QueryType.ALTER:
            if 'add column' in prompt.lower():
                new_cols = 'new_column1, new_column2'  # Infer multiple
                sql = f"ALTER TABLE {table} ADD COLUMN {new_cols}"
            elif 'drop column' in prompt.lower():
                drop_cols = 'old_column1, old_column2'  # Infer multiple
                sql = f"ALTER TABLE {table} DROP COLUMN {drop_cols}"
            else:
                sql = f"ALTER TABLE {table} ADD COLUMN new_column"
        else:
            sql = f"SELECT * FROM {table}"
        
        # Add conditions
        if query_type in [QueryType.SELECT, QueryType.COUNT, QueryType.SUM, QueryType.AVG]:
            where_parts = []
            if 'age' in conditions:
                where_parts.append(f"age {conditions['age']}")
            if 'city' in conditions:
                where_parts.append(f"city {conditions['city']}")
            if where_parts:
                op = conditions.get('where_op', 'AND')
                sql += f" WHERE {' ' + op + ' '.join(where_parts)}"
            
            if 'order_by' in conditions:
                sql += f" ORDER BY {conditions['order_by']}"
            if 'group_by' in conditions:
                sql += f" GROUP BY {conditions['group_by']}"
            if 'limit' in conditions:
                sql += f" LIMIT {conditions['limit']}"
        
        # Cache the result
        self.optimizer.cache_result(prompt, sql)
        
        return sql

class Connection:
    """Database connection with transaction support"""
    
    def __init__(self, db):
        self.db = db
        self.transaction_id = None
        self.isolation_level = IsolationLevel.READ_COMMITTED
        self.closed = False
    
    def begin(self, isolation_level: IsolationLevel = IsolationLevel.READ_COMMITTED):
        """Begin a transaction"""
        if self.transaction_id is not None:
            raise Exception("Transaction already in progress")
        
        self.isolation_level = isolation_level
        self.transaction_id = self.db.mvcc.begin_transaction(isolation_level)
        return self
    
    def commit(self):
        """Commit the current transaction"""
        if self.transaction_id is None:
            raise Exception("No transaction in progress")
        
        self.db.mvcc.commit_transaction(self.transaction_id)
        self.transaction_id = None
    
    def rollback(self):
        """Rollback the current transaction"""
        if self.transaction_id is None:
            raise Exception("No transaction in progress")
        
        self.db.mvcc.rollback_transaction(self.transaction_id)
        self.transaction_id = None
    
    def execute(self, query: str, params: Optional[Tuple] = None) -> Any:
        """Execute a query within the current transaction"""
        if self.closed:
            raise Exception("Connection is closed")
        
        return self.db.execute(query, params, self.transaction_id)
    
    def cursor(self):
        """Get a cursor for this connection"""
        return Cursor(self)
    
    def close(self):
        """Close the connection"""
        if self.transaction_id is not None:
            self.rollback()
        self.closed = True

class Cursor:
    """Database cursor for fetching results"""
    
    def __init__(self, connection):
        self.connection = connection
        self.results = None
        self.index = 0
    
    def execute(self, query: str, params: Optional[Tuple] = None):
        """Execute a query and store results"""
        self.results = self.connection.execute(query, params)
        self.index = 0
        return self
    
    def fetchone(self) -> Optional[Dict]:
        """Fetch one row"""
        if self.results is None:
            return None
        
        if isinstance(self.results, list) and self.index < len(self.results):
            row = self.results[self.index]
            self.index += 1
            return row
        
        return None
    
    def fetchall(self) -> List[Dict]:
        """Fetch all rows"""
        if self.results is None:
            return []
        
        if isinstance(self.results, list):
            return self.results
        
        return []
    
    def fetchmany(self, size: int) -> List[Dict]:
        """Fetch many rows"""
        if self.results is None:
            return []
        
        if isinstance(self.results, list):
            result = self.results[self.index:self.index + size]
            self.index += len(result)
            return result
        
        return []
    
    def close(self):
        """Close the cursor"""
        self.results = None

class database:
    """Fully enhanced database with production encryption, cloud sync, and environment integration"""
    
    def __init__(self, project_name: str, config: Dict[str, Any] = None, 
                 production: bool = False, encryption_key: str = None,
                 env_file: str = ENV_FILE, auto_restore_backup: bool = True):
        self.project_name = project_name
        self.config = config or self._load_config()
        self.production = production
        self.auto_restore_backup = auto_restore_backup
        
        # Initialize environment manager
        self.env_manager = EnvironmentManager(env_file, production)
        
        # Initialize encryption manager
        self.encryption_manager = EncryptionManager(project_name, production)
        
        # Initialize encryption - check environment first
        if production:
            self.encryption_manager.initialize_encryption(encryption_key, self.env_manager)
            
            # Check if we need to migrate existing data
            if self._has_unencrypted_data() and not self._is_first_time_production():
                print("🔄 Migrating existing data to encrypted format...")
                if self.encryption_manager.migrate_to_encrypted(self, self.env_manager):
                    print("✅ Migration completed successfully!")
                else:
                    print("❌ Migration failed!")
        
        self.project_path = os.path.join(DATABASE, project_name)
        
        # Create project directory
        os.makedirs(self.project_path, exist_ok=True)
        
        # Initialize components
        self.ai_converter = AdvancedAItoSQL()
        self.backup_manager = BackupManager(self.config)
        self.query_optimizer = QueryOptimizer()
        self.cloud_sync = CloudSyncManager(self.config, project_name)
        self.mvcc = MVCCManager()
        self.lock = threading.RLock()
        self.wal_managers = {}  # table -> WriteAheadLog
        self.index_managers = {}  # (table, column) -> IndexManager
        self.constraint_managers = {}  # table -> ConstraintManager
        
        # Transaction support
        self.in_transaction = False
        self.temp_writes = {}  # table -> data
        
        # Check if backup is available and restore if needed
        if auto_restore_backup and self.cloud_sync.backup_available:
            self._restore_from_backup_if_needed()
        
        # Create system tables
        self._create_system_tables()
        
        # Log production mode
        if self.production:
            self._log_security_event("PRODUCTION_MODE_ENABLED", "Database encryption activated")
            
        # Initial backup if enabled
        if self.config.get('backup_enabled', False):
            self._perform_initial_backup()
    
    def _has_unencrypted_data(self) -> bool:
        """Check if there's unencrypted data that needs migration"""
        tables = self.list_tables()
        user_tables = [t for t in tables if not t.startswith('system_')]
        
        if not user_tables:
            return False
        
        # Check if any table is unencrypted
        for table in user_tables[:2]:  # Sample first 2 tables
            try:
                data = self._read_table_unencrypted(table)
                if data is not None:
                    return True
            except:
                continue
        
        return False
    
    def _is_first_time_production(self) -> bool:
        """Check if this is first time switching to production"""
        system_tables = self._read_table('system_security') or []
        production_events = [e for e in system_tables if e.get('event_type') == 'PRODUCTION_MODE_ENABLED']
        return len(production_events) <= 1
    
    def _read_table_unencrypted(self, table: str) -> Optional[List[Dict]]:
        """Read table data without decryption (for migration)"""
        file_path = os.path.join(self.project_path, f"{table}{TABLE_EXT}")
        
        if not os.path.exists(file_path):
            return None
        
        try:
            with open(file_path, 'rb') as f:
                compressed_data = f.read()
            
            if not compressed_data:
                return []
            
            # Decompress and unpickle
            decompressed = gzip.decompress(compressed_data)
            return pickle.loads(decompressed)
                
        except Exception:
            return None

    def _restore_from_backup_if_needed(self):
        """Restore from backup if local data is missing or older than backup"""
        # Check if local database exists
        tables = self.list_tables()
        user_tables = [t for t in tables if not t.startswith('system_')]
        
        # If no local tables, restore from backup
        if not user_tables:
            print("🔄 No local data found, restoring from backup...")
            restored_data = self.cloud_sync.restore_from_backup()
            
            if restored_data:
                for table, data in restored_data.items():
                    self._write_table(table, data, "BACKUP_RESTORE")
                print(f"✅ Restored {len(restored_data)} tables from backup")
            return
        
        # Check if backup is newer than local data (simplified - always prefer backup for latest data)
        # In a real implementation, you'd compare timestamps
        if self.cloud_sync.backup_timestamp:
            print("📦 Backup available, will query from backup for latest data")
    
    def get_connection(self) -> Connection:
        """Get a new database connection"""
        return Connection(self)
    
    def _get_wal(self, table: str) -> WriteAheadLog:
        """Get or create WAL for table"""
        if table not in self.wal_managers:
            self.wal_managers[table] = WriteAheadLog(self.project_path, table)
        return self.wal_managers[table]
    
    def _get_constraint_manager(self, table: str) -> ConstraintManager:
        """Get or create constraint manager for table"""
        if table not in self.constraint_managers:
            self.constraint_managers[table] = ConstraintManager(self.project_path, table)
        return self.constraint_managers[table]
    
    def create_index(self, table: str, column: str, index_type: IndexType = IndexType.BTREE):
        """Create an index on a table column"""
        data = self._read_table(table)
        if data is None:
            return f"❌ Table '{table}' not found"
        
        index_manager = IndexManager(self.project_path, table, column, index_type)
        index_manager.build_index(data)
        
        # Store in cache
        self.index_managers[(table, column)] = index_manager
        
        return f"✅ Index created on {table}.{column} ({index_type.value})"
    
    def add_constraint(self, table: str, name: str, constraint_type: ConstraintType, 
                       columns: List[str], **kwargs):
        """Add a constraint to a table"""
        constraint_manager = self._get_constraint_manager(table)
        constraint_manager.add_constraint(name, constraint_type, columns, **kwargs)
        return f"✅ Constraint '{name}' added to {table}"
    
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from file with environment variable support"""
        default_config = {
            'primary_storage': 'local',
            'backup_enabled': True,
            'auto_backup_hours': 24,
            'query_cache_enabled': True,
            'auto_sync': True,
            'google_drive_enabled': False,
            'huggingface_enabled': False,
            'aws_s3_enabled': False,
            'dropbox_enabled': False
        }
        
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                loaded_config = json.load(f)
                default_config.update(loaded_config)
        
        # Override with environment variables
        env = EnvironmentManager()
        for key in default_config.keys():
            env_key = f"SOKETDB_{key.upper()}"
            if env_key in env.env_vars:
                env_value = env.get(env_key)
                # Convert string to appropriate type
                if isinstance(default_config[key], bool):
                    default_config[key] = env_value.lower() in ['true', 'yes', '1', 'y']
                elif isinstance(default_config[key], int):
                    default_config[key] = int(env_value)
                else:
                    default_config[key] = env_value
        
        return default_config

    def transaction(self):
        """Context manager for batched transactions (benefits prod/local: atomicity via temp files)"""
        return self._TransactionContext(self)
    
    class _TransactionContext:
        def __init__(self, db):
            self.db = db
        
        def __enter__(self):
            self.db.in_transaction = True
            self.db.temp_writes = {}
            return self.db
        
        def __exit__(self, exc_type, exc_val, exc_tb):
            if exc_type is None:
                # Commit: Write temp to files
                for table, data in self.db.temp_writes.items():
                    self.db._write_table(table, data, "TRANSACTION_COMMIT")
                self.db._log_security_event("TRANSACTION_COMMIT", f"Committed {len(self.db.temp_writes)} tables")
            else:
                # Rollback: Discard temp
                self.db._log_security_event("TRANSACTION_ROLLBACK", f"Rolled back due to {exc_type.__name__}: {exc_val}")
            self.db.in_transaction = False
            self.db.temp_writes = {}
    
    def generate_config(self, output_file: str = CONFIG_FILE, interactive: bool = True):
        """Generate configuration file interactively or with defaults"""
        config = self._load_config()  # Start with defaults
        
        if interactive:
            print("🔧 Interactive Config Generator")
            print("Leave blank for defaults.")
            
            config['primary_storage'] = input(f"Primary storage ({config['primary_storage']}): ").strip() or config['primary_storage']
            
            if config['primary_storage'] == 'huggingface':
                config['huggingface_token'] = input("HuggingFace token: ").strip()
                config['huggingface_repo_id'] = input("HuggingFace repo ID: ").strip()
                config['huggingface_enabled'] = True
            elif config['primary_storage'] == 'google_drive':
                config['google_drive_enabled'] = True
            elif config['primary_storage'] == 'aws_s3':
                config['aws_s3_enabled'] = True
                config['aws_access_key'] = input("AWS Access Key: ").strip()
                config['aws_secret_key'] = input("AWS Secret Key: ").strip()
                config['aws_bucket_name'] = input("S3 Bucket: ").strip()
                config['aws_region'] = input("AWS Region (us-east-1): ").strip() or 'us-east-1'
            elif config['primary_storage'] == 'dropbox':
                config['dropbox_enabled'] = True
                config['dropbox_access_token'] = input("Dropbox Access Token: ").strip()
            
            config['auto_sync'] = input(f"Enable auto-sync ({config['auto_sync']}): ").lower() in ['y', 'yes', 'true']
            config['backup_enabled'] = input(f"Enable backups ({config['backup_enabled']}): ").lower() in ['y', 'yes', 'true']
        
        # Write config
        with open(output_file, 'w') as f:
            json.dump(config, f, indent=2)
        
        print(f"✅ Config generated: {output_file}")
        return config
    
    def _perform_initial_backup(self):
        """Perform initial backup if this is a new database"""
        try:
            tables = self.list_tables()
            if len(tables) <= 4:  # Only system tables
                print("🔄 Performing initial backup...")
                backup_results = self.backup()
                for provider, result in backup_results.items():
                    print(f"  {provider}: {result}")
        except Exception as e:
            print(f"⚠️ Initial backup failed: {e}")
    
    def _create_system_tables(self):
        """Create system tables for metadata"""
        system_tables = {
            'system_queries': ['query_id', 'query_text', 'execution_time', 'timestamp'],
            'system_tables': ['table_name', 'column_count', 'row_count', 'created_at', 'encrypted'],
            'system_backups': ['backup_id', 'provider', 'timestamp', 'size', 'encrypted'],
            'system_security': ['event_id', 'event_type', 'description', 'timestamp', 'project'],
            'system_indexes': ['index_name', 'table_name', 'column_name', 'index_type', 'created_at'],
            'system_constraints': ['constraint_name', 'table_name', 'constraint_type', 'columns', 'created_at']
        }
        
        for table, columns in system_tables.items():
            if not self._table_exists(table):
                self.execute(f"CREATE TABLE {table} ({', '.join(columns)})")
        
        # Update system tables with encryption info
        self._update_system_tables()
    
    def _log_security_event(self, event_type: str, description: str):
        """Log security-related events"""
        security_log = {
            'event_id': hashlib.md5(f"{event_type}{time.time()}".encode()).hexdigest()[:8],
            'event_type': event_type,
            'description': description,
            'timestamp': datetime.now().isoformat(),
            'project': self.project_name,
            'production_mode': self.production
        }
        
        # Append to system security log
        security_logs = self._read_table('system_security') or []
        security_logs.append(security_log)
        self._write_table('system_security', security_logs)
    
    def _table_exists(self, table: str) -> bool:
        """Check if table exists"""
        return os.path.exists(os.path.join(self.project_path, f"{table}{TABLE_EXT}"))
    
    def _read_table(self, table: str, tx_id: int = None) -> Optional[List[Dict]]:
        """Read table data with encryption support, MVCC, and backup fallback"""
        # First try to read from local
        file_path = os.path.join(self.project_path, f"{table}{TABLE_EXT}")
        
        if not os.path.exists(file_path):
            # If local doesn't exist, try backup
            if self.cloud_sync.backup_available:
                backup_data = self.cloud_sync.restore_from_backup(table)
                if backup_data and table in backup_data:
                    # Restore locally
                    self._write_table(table, backup_data[table], "BACKUP_RESTORE")
                    return backup_data[table]
            return None
        
        try:
            with open(file_path, 'rb') as f:
                compressed_data = f.read()
            
            if not compressed_data:
                return []
            
            # Decrypt if in production mode
            if self.production:
                decrypted_data = self.encryption_manager.decrypt_data(compressed_data.decode('ascii', errors='ignore'))
                if decrypted_data is not None:
                    data = decrypted_data
                else:
                    # Try to decompress and unpickle
                    decompressed = gzip.decompress(compressed_data)
                    data = pickle.loads(decompressed)
            else:
                # Decompress and unpickle
                decompressed = gzip.decompress(compressed_data)
                data = pickle.loads(decompressed)
            
            # Apply MVCC if transaction ID provided
            if tx_id is not None:
                # Get visible versions for this transaction
                visible_versions = self.mvcc.get_visible_versions(table, tx_id)
                if visible_versions:
                    # Convert to list format
                    data = list(visible_versions.values())
            
            return data
                
        except Exception as e:
            print(f"Error reading table {table}: {e}")
            self._log_security_event("READ_ERROR", f"Table read failed: {e}")
            
            # Try backup as fallback
            if self.cloud_sync.backup_available:
                backup_data = self.cloud_sync.restore_from_backup(table)
                if backup_data and table in backup_data:
                    return backup_data[table]
            return None
    
    def _write_table(self, table: str, data: List[Dict], operation: str = "WRITE", tx_id: int = None):
        """Write table data with encryption support, WAL, and cloud sync"""
        file_path = os.path.join(self.project_path, f"{table}{TABLE_EXT}")
        
        # Write to WAL first (Write-Ahead Logging)
        wal = self._get_wal(table)
        lsn = wal.append(operation, data, None)
        
        try:
            # Encrypt if in production mode
            if self.production:
                encrypted_content = self.encryption_manager.encrypt_data(data)
                content_to_write = encrypted_content.encode('ascii')
            else:
                # Compress and pickle
                serialized = pickle.dumps(data)
                compressed = gzip.compress(serialized)
                content_to_write = compressed
            
            # Atomic write using temp file
            with tempfile.NamedTemporaryFile(mode='wb', delete=False, dir=self.project_path) as temp_f:
                temp_f.write(content_to_write)
                temp_path = temp_f.name
            
            os.replace(temp_path, file_path)  # Atomic replace
            
            # Truncate WAL up to this LSN
            wal.truncate(lsn)
            
        except Exception as e:
            print(f"Error writing table {table}: {e}")
            self._log_security_event("WRITE_ERROR", f"Table write failed: {e}")
            raise  # Re-raise to fail transaction if in one
        
        # Update indexes if they exist
        for (tbl, col), index_manager in self.index_managers.items():
            if tbl == table:
                # For simplicity, we're not updating indexes here
                # In a real implementation, you'd need to update based on changes
                pass
        
        # Sync to cloud if enabled - immediate sync for all operations
        if not self.in_transaction:
            self.cloud_sync.sync_table(table, data, operation)
    
    def _write_metadata(self, table: str, metadata: Dict):
        """Write table metadata with encryption and error handling"""
        meta_path = os.path.join(self.project_path, f"{table}{TABLE_EXT}.meta")
        
        try:
            if self.production:
                encrypted_content = self.encryption_manager.encrypt_data(metadata)
                content_to_write = encrypted_content.encode('ascii')
            else:
                serialized = pickle.dumps(metadata)
                compressed = gzip.compress(serialized)
                content_to_write = compressed
            
            # Atomic write
            with tempfile.NamedTemporaryFile(mode='wb', delete=False, dir=self.project_path) as temp_f:
                temp_f.write(content_to_write)
                temp_path = temp_f.name
            
            os.replace(temp_path, meta_path)
            
        except Exception as e:
            print(f"Error writing metadata for {table}: {e}")
            raise
    
    def _read_metadata(self, table: str) -> Optional[Dict]:
        """Read table metadata with decryption and error handling"""
        meta_path = os.path.join(self.project_path, f"{table}{TABLE_EXT}.meta")
        if not os.path.exists(meta_path):
            return None
        
        try:
            with open(meta_path, 'rb') as f:
                compressed_data = f.read()
            
            if not compressed_data:
                return {}
            
            if self.production:
                decrypted_data = self.encryption_manager.decrypt_data(compressed_data.decode('ascii', errors='ignore'))
                if decrypted_data is not None:
                    return decrypted_data
            
            decompressed = gzip.decompress(compressed_data)
            return pickle.loads(decompressed)
        except Exception as e:
            print(f"Error reading metadata for {table}: {e}")
            return None
    
    def validate_schema(self, table: str, columns: List[str]) -> bool:
        """Validate schema columns: no duplicates, valid names"""
        if not columns:
            return False
        if len(columns) != len(set(columns)):
            print(f"❌ Duplicate columns in {table}")
            return False
        for col in columns:
            if not re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', col):
                print(f"❌ Invalid column name '{col}' in {table}")
                return False
        return True
    
    def validate_insert_data(self, table: str, data: List[Dict]) -> Tuple[bool, str]:
        """Validate insert data against schema and constraints"""
        metadata = self._read_metadata(table)
        constraint_manager = self._get_constraint_manager(table)
        
        if not metadata or not metadata.get('columns'):
            return True, "No schema; insert allowed"
        
        expected_columns = metadata['columns']
        
        # Get existing data for constraint validation
        existing_data = self._read_table(table) or []
        
        for row in data:
            # Check schema
            if set(row.keys()) != set(expected_columns):
                missing = set(expected_columns) - set(row.keys())
                extra = set(row.keys()) - set(expected_columns)
                return False, f"Schema mismatch in {table}: missing {missing}, extra {extra}"
            
            # Validate constraints
            valid, msg = constraint_manager.validate_insert(row, existing_data)
            if not valid:
                return False, msg
            
            # Basic type inference (e.g., age int)
            for col, val in row.items():
                if col == 'age' and not isinstance(val, (int, float)):
                    return False, f"Type mismatch: age must be number in {table}"
        
        return True, "Valid"
    
    def inspect_system_table(self, table_name: str = 'system_tables') -> Optional[List[Dict]]:
        """Inspect and return data from a system table"""
        if not table_name.startswith('system_'):
            return None
        
        data = self._read_table(table_name)
        if data:
            print(f"📊 System Table '{table_name}' Data:")
            for row in data:
                print(f"  - {json.dumps(row, indent=2)}")
        return data
    
    def _bind_params(self, query: str, params: Tuple) -> str:
        """Safely bind parameters to ? placeholders in the query."""
        if not params:
            return query
        
        # Split the query on ? placeholders
        parts = query.split('?')
        if len(parts) - 1 != len(params):
            raise ValueError(f"Parameter count mismatch: {len(parts)-1} placeholders, {len(params)} parameters")
        
        result = parts[0]
        for i, param in enumerate(params):
            if isinstance(param, str):
                # Use JSON serialization to handle all special characters
                escaped_param = json.dumps(param)
            elif isinstance(param, (dict, list)):
                escaped_param = json.dumps(param)
            elif param is None:
                escaped_param = 'null'
            else:
                escaped_param = str(param)
            
            result += escaped_param + parts[i + 1]
        
        return result
    
    def execute(self, query: str, params: Optional[Tuple] = None, tx_id: int = None) -> Any:
        """Execute SQL query with enhanced features and optional parameterized support."""
        
        # Bind params if provided
        if params:
            query = self._bind_params(query, params)
        
        # Check cache (key based on query only, ignore params for simplicity)
        if self.config.get('query_cache_enabled', True):
            cached_result = self.query_optimizer.get_cached_result(query)
            if cached_result is not None:
                return cached_result
        
        with self.lock:
            try:
                # Parse and validate query
                parsed_query = self._parse_query(query)
                
                # Execute query with transaction ID
                result = self._execute_parsed_query(parsed_query, tx_id)
                
                # Cache result
                if self.config.get('query_cache_enabled', True):
                    self.query_optimizer.cache_result(query, result)
                
                # Log query
                self._log_query(query, "success")
                
                return result
                
            except Exception as e:
                self._log_query(query, f"error: {str(e)}")
                return f"❌ Query execution failed: {str(e)}"
    
    def query(self, natural_language: str) -> Any:
        """Execute natural language query"""
        try:
            # Convert natural language to SQL
            sql = self.ai_converter.convert(natural_language)
            print(f"🤖 AI Translated: {sql}")
            
            # Execute the SQL
            return self.execute(sql)
            
        except Exception as e:
            return f"❌ AI translation failed: {e}"
    
    def _parse_query(self, query: str) -> Dict[str, Any]:
        """Parse SQL query into structured format"""
        # Remove extra whitespace
        query = re.sub(r'\s+', ' ', query.strip())
        
        # Basic query type detection
        query_upper = query.upper()
        
        if query_upper.startswith('SELECT'):
            return {'type': 'SELECT', 'query': query}
        elif query_upper.startswith('INSERT'):
            return {'type': 'INSERT', 'query': query}
        elif query_upper.startswith('UPDATE'):
            return {'type': 'UPDATE', 'query': query}
        elif query_upper.startswith('DELETE'):
            return {'type': 'DELETE', 'query': query}
        elif query_upper.startswith('CREATE'):
            return {'type': 'CREATE', 'query': query}
        elif query_upper.startswith('DROP'):
            return {'type': 'DROP', 'query': query}
        elif query_upper.startswith('ALTER'):
            return {'type': 'ALTER', 'query': query}
        else:
            return {'type': 'UNKNOWN', 'query': query}
    
    def _execute_parsed_query(self, parsed_query: Dict[str, Any], tx_id: int = None) -> Any:
        """Execute parsed query with transaction support"""
        query_type = parsed_query['type']
        query = parsed_query['query']
        
        if query_type == 'SELECT':
            return self._execute_select(query, tx_id)
        elif query_type == 'INSERT':
            return self._execute_insert(query, tx_id)
        elif query_type == 'UPDATE':
            return self._execute_update(query, tx_id)
        elif query_type == 'DELETE':
            return self._execute_delete(query, tx_id)
        elif query_type == 'CREATE':
            return self._execute_create(query)
        elif query_type == 'DROP':
            return self._execute_drop(query)
        elif query_type == 'ALTER':
            return self._execute_alter(query)
        else:
            return "❌ Unsupported query type"
    
    def _sanitize_identifier(self, ident: str) -> str:
        """Sanitize table or column name to prevent injection"""
        # Allow only alphanumeric, underscore, starting with letter or underscore
        sanitized = re.sub(r'[^a-zA-Z0-9_]', '', ident)
        if not re.match(r'^[a-zA-Z_]', sanitized):
            raise ValueError(f"Invalid identifier: {ident}")
        return sanitized
    
    def _sanitize_column_list(self, columns_str: str) -> List[str]:
        """Sanitize and parse column list to prevent injection"""
        # Split by comma, strip, and sanitize each
        columns = [self._sanitize_identifier(col.strip()) for col in columns_str.split(',') if col.strip()]
        # Remove duplicates
        return list(dict.fromkeys(columns))
    
    def _perform_in_memory_join(self, left_table: str, right_table: str, on_condition: str, tx_id: int = None) -> List[Dict]:
        """Perform simple INNER JOIN on two tables based on ON condition (e.g., left.id = right.user_id)"""
        left_data = self._read_table(left_table, tx_id) or []
        right_data = self._read_table(right_table, tx_id) or []
        
        if not left_data or not right_data:
            return []
        
        # Parse ON: Assume form left_col = right_col
        on_match = re.match(r'(\w+)\.(\w+)\s*=\s*(\w+)\.(\w+)', on_condition)
        if not on_match:
            raise ValueError("Invalid ON condition for JOIN")
        
        _, left_col, _, right_col = on_match.groups()
        left_col = self._sanitize_identifier(left_col)
        right_col = self._sanitize_identifier(right_col)
        
        # Create right index for fast lookup
        right_index = {row.get(right_col): row for row in right_data}
        
        joined_data = []
        for left_row in left_data:
            right_key = left_row.get(left_col)
            if right_key in right_index:
                joined_row = {**left_row, **right_index[right_key]}
                # Remove duplicate keys if any (keep left)
                if left_col in joined_row and right_col in joined_row and left_col == right_col:
                    del joined_row[right_col]
                joined_data.append(joined_row)
        
        return joined_data
    
    def _execute_select(self, query: str, tx_id: int = None) -> Any:
        """Execute SELECT query with SQL injection prevention, JOIN support, and full multiple column support"""
        # Enhanced parsing with JOIN support
        # Basic JOIN: SELECT cols FROM table1 JOIN table2 ON cond [WHERE ...]
        join_match = re.match(r"SELECT\s+(.+?)\s+FROM\s+(\w+)\s+JOIN\s+(\w+)\s+ON\s+(.+?)(?:\s+WHERE\s+(.+?))?(?:\s+ORDER\s+BY\s+(.+?))?(?:\s+GROUP\s+BY\s+(.+?))?(?:\s+LIMIT\s+(\d+))?$", query, re.IGNORECASE | re.DOTALL)
        if join_match:
            columns_str, left_table_raw, right_table_raw, on_raw, where_raw, order_raw, group_raw, limit_raw = join_match.groups()
            left_table = self._sanitize_identifier(left_table_raw)
            right_table = self._sanitize_identifier(right_table_raw)
            on_condition = on_raw.strip()
            
            try:
                data = self._perform_in_memory_join(left_table, right_table, on_condition, tx_id)
            except Exception as e:
                return f"❌ JOIN failed: {e}"
        else:
            # Standard SELECT without JOIN
            match = re.match(r"SELECT\s+(.+?)\s+FROM\s+(\w+)(?:\s+WHERE\s+(.+?))?(?:\s+ORDER\s+BY\s+(.+?))?(?:\s+GROUP\s+BY\s+(.+?))?(?:\s+LIMIT\s+(\d+))?$", query, re.IGNORECASE | re.DOTALL)
            if not match:
                return "❌ Invalid SELECT query format"
            
            columns_str, table_raw, where_raw, order_raw, group_raw, limit_raw = match.groups()
            table = self._sanitize_identifier(table_raw)
            data = self._read_table(table, tx_id)
            if data is None:
                return f"❌ Table '{table}' not found"

        # Sanitize columns early (for projection later)
        if columns_str.strip().lower() == '*':
            columns = ['*']
        else:
            columns = self._sanitize_column_list(columns_str)
            if not columns:
                return "❌ No valid columns specified"

        # Apply WHERE FIRST on FULL rows (before projection)
        if where_raw:
            conditions = where_raw.split('AND')
            new_data = []
            for row in data:
                # Full row here—all columns exist!
                row_matches = True
                for cond in conditions:
                    cond = cond.strip()
                    op_match = re.match(r'(\w+)\s*([=<>]+)\s*(.+)', cond)
                    if op_match:
                        key, op, val_raw = op_match.groups()
                        key = self._sanitize_identifier(key)
                        # Strip outer quotes from value
                        val = re.sub(r"^['\"]|['\"]$", '', val_raw.strip())
                        row_val = row.get(key, '')  # Now on full row!
                        try:
                            if op == '=':
                                if str(row_val) != val:
                                    row_matches = False
                            elif op == '>':
                                if not (float(row_val) > float(val)):
                                    row_matches = False
                            elif op == '<':
                                if not (float(row_val) < float(val)):
                                    row_matches = False
                            else:
                                row_matches = False
                        except (ValueError, TypeError):
                            row_matches = False  # Edge case: invalid type conversion
                    else:
                        row_matches = False
                    if not row_matches:
                        break
                if row_matches:
                    new_data.append(row)
            data = new_data
            if not data:
                return "⚠️ No rows match WHERE condition"  # Only triggers on real no-match

        # NOW project columns on filtered full rows
        if columns != ['*']:
            filtered_data = []
            for row in data:
                filtered_row = {col: row.get(col) for col in columns if col in row}
                if filtered_row:  # Only include if has data
                    filtered_data.append(filtered_row)
            data = filtered_data

        # ORDER BY: Supports multiple columns (comma-separated, ascending)
        if order_raw:
            order_cols = [self._sanitize_identifier(col.strip()) for col in order_raw.split(',') if col.strip()]
            if order_cols and data:
                # Sort by multiple keys (ascending)
                data.sort(key=lambda x: tuple(str(x.get(col, '')) for col in order_cols))

        # GROUP BY: Basic stub - groups by first column, counts (simple dict aggregation)
        if group_raw:
            group_col = self._sanitize_identifier(group_raw.split(',')[0].strip())
            if data and group_col in data[0]:
                grouped = {}
                for row in data:
                    key = row[group_col]
                    if key not in grouped:
                        grouped[key] = {'count': 0, group_col: key}
                    grouped[key]['count'] += 1
                data = list(grouped.values())
                print("ℹ️ GROUP BY applied with COUNT aggregation")
            else:
                print("⚠️ GROUP BY column not found")

        # LIMIT: Supports integer limit
        if limit_raw:
            try:
                limit = int(limit_raw)
                data = data[:limit]
            except ValueError:
                pass  # Ignore invalid limit

        return data
    
    def _execute_insert(self, query: str, tx_id: int = None) -> str:
        """Execute INSERT query with support for VALUES and DATA syntax"""
        # Try VALUES syntax first: INSERT INTO table (col1, col2) VALUES (val1, val2)
        values_match = re.match(r"INSERT\s+INTO\s+(\w+)\s*\((.+)\)\s*VALUES\s*\((.+)\)", query, re.IGNORECASE | re.DOTALL)
        if values_match:
            table_raw, columns_str, values_str = values_match.groups()
            table = self._sanitize_identifier(table_raw)
            
            # Parse columns
            columns = [self._sanitize_identifier(col.strip()) for col in columns_str.split(',')]
            
            # Parse values - they might be JSON strings or literals
            try:
                # Try to parse as JSON array
                values_list = json.loads(f"[{values_str}]")
                if len(values_list) != len(columns):
                    return f"❌ Column count ({len(columns)}) doesn't match value count ({len(values_list)})"
                
                # Create a single row dict
                row = dict(zip(columns, values_list))
                rows_to_insert = [row]
                
            except json.JSONDecodeError:
                # Handle literal values
                # Split values by comma, respecting quotes
                values = []
                current_val = ""
                in_quotes = False
                quote_char = None
                
                for char in values_str:
                    if char in ['"', "'"] and (not current_val or current_val[-1] != '\\'):
                        if not in_quotes:
                            in_quotes = True
                            quote_char = char
                        elif char == quote_char:
                            in_quotes = False
                            quote_char = None
                        current_val += char
                    elif char == ',' and not in_quotes:
                        # End of value
                        val = current_val.strip()
                        if (val.startswith('"') and val.endswith('"')) or (val.startswith("'") and val.endswith("'")):
                            val = val[1:-1]
                        values.append(val)
                        current_val = ""
                    else:
                        current_val += char
                
                # Add last value
                if current_val:
                    val = current_val.strip()
                    if (val.startswith('"') and val.endswith('"')) or (val.startswith("'") and val.endswith("'")):
                        val = val[1:-1]
                    values.append(val)
                
                if len(values) != len(columns):
                    return f"❌ Column count ({len(columns)}) doesn't match value count ({len(values)})"
                
                row = dict(zip(columns, values))
                rows_to_insert = [row]
        
        else:
            # Try DATA syntax: INSERT INTO table DATA = {...}
            match = re.match(r"INSERT\s+INTO\s+(\w+)\s+DATA\s*=\s*(.+)", query, re.IGNORECASE | re.DOTALL)
            if not match:
                return "❌ Invalid INSERT query. Use: INSERT INTO table (col1, col2) VALUES (val1, val2) or INSERT INTO table DATA = {...}"
            
            table_raw = match.group(1)
            data_str = match.group(2)
            table = self._sanitize_identifier(table_raw)
        
            try:
                rows_to_insert = json.loads(data_str)
            except json.JSONDecodeError:
                return "❌ Invalid JSON data in INSERT"

        if isinstance(rows_to_insert, dict):
            rows_to_insert = [rows_to_insert]

        # Apply default values from constraints
        constraint_manager = self._get_constraint_manager(table)
        defaults = constraint_manager.get_defaults()
        
        for row in rows_to_insert:
            for col, default_val in defaults.items():
                if col not in row:
                    row[col] = default_val

        # Schema validation
        valid, msg = self.validate_insert_data(table, rows_to_insert)
        if not valid:
            return f"❌ Schema validation failed for {table}: {msg}"

        existing_data = self._read_table(table, tx_id) or []

        # Get table columns from first row OR new row
        table_columns = list(existing_data[0].keys()) if existing_data else list(rows_to_insert[0].keys())

        # Precompute hashes for fast duplicate detection
        existing_hashes = {
            hashlib.md5(pickle.dumps(sorted(row.items()))).hexdigest()
            for row in existing_data
        }

        inserted_count = 0
        full_duplicates = []

        for row in rows_to_insert:
            # Ensure row has all columns
            for col in table_columns:
                if col not in row:
                    row[col] = None
            
            row_hash = hashlib.md5(pickle.dumps(sorted(row.items()))).hexdigest()

            if row_hash in existing_hashes:
                full_duplicates.append(row)
                continue

            existing_data.append(row)
            existing_hashes.add(row_hash)
            inserted_count += 1

        # Save updated table
        if self.in_transaction:
            self.temp_writes[table] = existing_data
        else:
            self._write_table(table, existing_data, "INSERT", tx_id)

        # Build return message
        msg = f"✅ {inserted_count} row(s) inserted into '{table}'"

        if full_duplicates:
            msg += f"\n⚠️ Skipped {len(full_duplicates)} duplicate row(s)"

        return msg
    
    def _execute_create(self, query: str) -> str:
        """Execute CREATE TABLE query with schema validation"""
        match = re.match(r"CREATE TABLE\s+(\w+)\s*\((.+)\)", query, re.IGNORECASE)
        if not match:
            return "❌ Invalid CREATE TABLE query"
        
        table_raw = match.group(1)
        columns_str = match.group(2)
        table = self._sanitize_identifier(table_raw)
        
        # Parse columns (simplified - just get column names)
        columns = []
        for col_def in columns_str.split(","):
            col_def = col_def.strip()
            if col_def:
                col_name = col_def.split()[0].strip()
                columns.append(self._sanitize_identifier(col_name))
        
        # Schema validation
        if not self.validate_schema(table, columns):
            return f"❌ Schema validation failed for {table}"
        
        if self._table_exists(table):
            return f"❌ Table '{table}' already exists"
        
        self._write_table(table, [], "CREATE")
        
        # Store metadata
        metadata = {"columns": columns, "created_at": datetime.now().isoformat()}
        self._write_metadata(table, metadata)
        
        # Update system tables
        self._update_system_tables()
        
        # Auto-backup if enabled
        if self.config.get('backup_enabled', False):
            self.backup()
        
        return f"✅ Table '{table}' created with columns: {columns}"
    
    def _execute_alter(self, query: str) -> str:
        """Execute ALTER TABLE query (support ADD/DROP multiple columns via comma-separated list) with enhanced error handling"""
        table_raw = None
        columns_str = None
        action = None
        
        # Parse for ADD COLUMN col1, col2
        add_match = re.match(r"ALTER TABLE\s+(\w+)\s+ADD\s+COLUMN\s+(.+?)(?:\s|$)", query, re.IGNORECASE | re.DOTALL)
        if add_match:
            table_raw, columns_str = add_match.groups()
            action = 'ADD'
        # Parse for DROP COLUMN col1, col2
        else:
            drop_match = re.match(r"ALTER TABLE\s+(\w+)\s+DROP\s+COLUMN\s+(.+?)(?:\s|$)", query, re.IGNORECASE | re.DOTALL)
            if drop_match:
                table_raw, columns_str = drop_match.groups()
                action = 'DROP'
        
        if not action:
            return "❌ Invalid ALTER TABLE query. Use: ALTER TABLE table ADD COLUMN col1, col2 or ALTER TABLE table DROP COLUMN col1, col2"
        
        table = self._sanitize_identifier(table_raw)
        columns = self._sanitize_column_list(columns_str)
        
        if not self._table_exists(table):
            return f"❌ Table '{table}' does not exist"
        
        if not columns:
            return "❌ No valid columns specified"
        
        try:
            metadata = self._read_metadata(table) or {'columns': []}
            data = self._read_table(table) or []
        except Exception as e:
            return f"❌ Failed to read table/metadata: {e}"
        
        altered_count = 0
        errors = []
        
        for column in columns:
            try:
                if action == 'ADD':
                    if column in metadata['columns']:
                        errors.append(f"Column '{column}' already exists")
                        continue
                    # Add column to each row with default None
                    for row in data:
                        row[column] = None
                    metadata['columns'].append(column)
                    altered_count += 1
                elif action == 'DROP':
                    if column not in metadata['columns']:
                        errors.append(f"Column '{column}' does not exist")
                        continue
                    # Remove column from each row
                    for row in data:
                        row.pop(column, None)
                    metadata['columns'].remove(column)
                    altered_count += 1
            except Exception as col_e:
                errors.append(f"Error with column '{column}': {col_e}")
                continue
        
        if errors:
            self._log_security_event("ALTER_PARTIAL", f"Partial ALTER on {table}: {errors}")
            if altered_count == 0:
                return f"❌ ALTER failed: {', '.join(errors)}"
        
        try:
            metadata['altered_at'] = datetime.now().isoformat()
            self._write_metadata(table, metadata)
            if self.in_transaction:
                self.temp_writes[table] = data
            else:
                self._write_table(table, data, "ALTER")
        except Exception as write_e:
            return f"❌ Failed to persist changes: {write_e}"
        
        # Update system tables
        self._update_system_tables()
        
        # Sync to cloud
        if not self.in_transaction:
            self.cloud_sync.sync_table(table, data, "ALTER")
        
        return f"✅ {altered_count} column(s) {action.lower()}ed from table '{table}'"
    
    def _execute_update(self, query: str, tx_id: int = None) -> str:
        """Execute UPDATE query with multi-column SET support, proper string escaping, and enhanced type handling"""
        # Enhanced: Support SET col1=val1, col2=val2 with proper string escaping
        match = re.match(r"UPDATE\s+(\w+)\s+SET\s+(.+?)(?:\s+WHERE\s+(.+))?$", query, re.IGNORECASE | re.DOTALL)
        if not match:
            return "❌ Invalid UPDATE query"
        
        table_raw, set_clauses_raw, where_clause = match.groups()
        table = self._sanitize_identifier(table_raw)
        
        # Parse multiple SET: col1=val1, col2=val2 with improved parsing for strings with quotes
        set_clauses = []
        current_clause = ""
        in_string = False
        string_char = None
        i = 0
        
        # Manual parsing to handle commas inside strings
        while i < len(set_clauses_raw):
            char = set_clauses_raw[i]
            
            # Handle string boundaries
            if char in ['"', "'"] and (i == 0 or set_clauses_raw[i-1] != '\\'):
                if not in_string:
                    in_string = True
                    string_char = char
                elif char == string_char:
                    in_string = False
                    string_char = None
            
            # Split on commas only when not in string
            if char == ',' and not in_string:
                set_clauses.append(current_clause.strip())
                current_clause = ""
            else:
                current_clause += char
            i += 1
        
        if current_clause:
            set_clauses.append(current_clause.strip())
        
        # Remove empty clauses
        set_clauses = [s for s in set_clauses if s]
        
        updates = {}
        metadata = self._read_metadata(table)
        
        for clause in set_clauses:
            # Parse SET clause with better regex that handles strings
            set_match = re.match(r'(\w+)\s*=\s*(.*?)$', clause, re.DOTALL)
            if set_match:
                col_raw, val_raw = set_match.groups()
                col = self._sanitize_identifier(col_raw)
                
                # Clean up the value - remove surrounding quotes if present
                val_raw = val_raw.strip()
                
                # Handle quoted strings (both single and double quotes)
                if (val_raw.startswith('"') and val_raw.endswith('"')) or (val_raw.startswith("'") and val_raw.endswith("'")):
                    # Remove quotes but preserve internal quotes
                    val = val_raw[1:-1]
                    # Unescape escaped quotes
                    val = val.replace('\\"', '"').replace("\\'", "'")
                else:
                    # Try to convert to number if possible
                    try:
                        if '.' in val_raw:
                            val = float(val_raw)
                        else:
                            val = int(val_raw)
                    except (ValueError, TypeError):
                        # Keep as string
                        val = val_raw
                
                updates[col] = val
            else:
                return f"❌ Invalid SET clause: {clause}"
        
        if not updates:
            return "❌ No valid updates specified"
        
        data = self._read_table(table, tx_id)
        if data is None:
            return f"❌ Table '{table}' not found"
        
        # Apply default values
        constraint_manager = self._get_constraint_manager(table)
        defaults = constraint_manager.get_defaults()
        
        # WHERE handling with improved parsing for strings with quotes
        filter_func = lambda row: True
        if where_clause:
            where_clause = where_clause.strip()
            
            # Parse WHERE condition with proper string handling
            op_match = re.match(r'(\w+)\s*([=<>]+)\s*(.+?)$', where_clause, re.DOTALL)
            if op_match:
                key, op, val_raw = op_match.groups()
                key = self._sanitize_identifier(key)
                val_raw = val_raw.strip()
                
                # Handle quoted strings in WHERE
                if (val_raw.startswith('"') and val_raw.endswith('"')) or (val_raw.startswith("'") and val_raw.endswith("'")):
                    val = val_raw[1:-1]
                    # Unescape
                    val = val.replace('\\"', '"').replace("\\'", "'")
                else:
                    try:
                        if '.' in val_raw:
                            val = float(val_raw)
                        else:
                            val = int(val_raw)
                    except (ValueError, TypeError):
                        val = val_raw
                
                try:
                    if op == '=':
                        filter_func = lambda row, k=key, v=val: str(row.get(k, '')) == str(v)
                    elif op == '>':
                        filter_func = lambda row, k=key, v=val: float(row.get(k, 0)) > float(v)
                    elif op == '<':
                        filter_func = lambda row, k=key, v=val: float(row.get(k, 0)) < float(v)
                    else:
                        return f"❌ Unsupported operator in WHERE: {op}"
                except (ValueError, TypeError):
                    return "⚠️ Invalid WHERE condition"
            else:
                return f"❌ Invalid WHERE clause format: {where_clause}"
        
        # Apply updates with constraint validation
        updated_count = 0
        for i, row in enumerate(data):
            if filter_func(row):
                # Create new row with updates
                new_row = row.copy()
                for col, val in updates.items():
                    new_row[col] = val
                
                # Validate against constraints
                valid, msg = constraint_manager.validate_update(row, new_row, data, i)
                if not valid:
                    return f"❌ Update failed: {msg}"
                
                # Apply updates
                for col, val in updates.items():
                    row[col] = val
                updated_count += 1
        
        if updated_count > 0:
            if self.in_transaction:
                self.temp_writes[table] = data
            else:
                self._write_table(table, data, "UPDATE", tx_id)
            return f"✅ {updated_count} row(s) updated in '{table}'"
        else:
            return "⚠️ No rows matched the condition"
    
    def _execute_delete(self, query: str, tx_id: int = None) -> str:
        """Execute DELETE query"""
        match = re.match(r"DELETE FROM\s+(\w+)(?:\s+WHERE\s+(.+))?", query, re.IGNORECASE)
        if not match:
            return "❌ Invalid DELETE query"
        
        table_raw, where_clause = match.groups()
        table = self._sanitize_identifier(table_raw)
        
        data = self._read_table(table, tx_id)
        if data is None:
            return f"❌ Table '{table}' not found"
        
        if not where_clause:
            # Delete all rows
            count = len(data)
            if self.in_transaction:
                self.temp_writes[table] = []
            else:
                self._write_table(table, [], "DELETE", tx_id)
            return f"🗑️ {count} row(s) deleted from '{table}'"
        
        # Simple WHERE condition implementation with >/< support
        new_data = []
        deleted_count = 0
        
        op_match = re.match(r'(\w+)\s*([=<>]+)\s*(.+)', where_clause.strip())
        if op_match:
            key, op, val_raw = op_match.groups()
            key = self._sanitize_identifier(key)
            val = re.sub(r"^['\"]|['\"]$", '', val_raw.strip())
            try:
                for row in data:
                    row_val = row.get(key, '')
                    match_cond = (
                        (str(row_val) == val) if op == '=' else
                        (float(row_val) > float(val)) if op == '>' else
                        (float(row_val) < float(val)) if op == '<' else False
                    )
                    if not match_cond:
                        new_data.append(row)
                    else:
                        deleted_count += 1
            except (ValueError, TypeError):
                return "⚠️ Invalid WHERE condition in DELETE"
        else:
            return "❌ Invalid WHERE in DELETE"
        
        if self.in_transaction:
            self.temp_writes[table] = new_data
        else:
            self._write_table(table, new_data, "DELETE", tx_id)
        return f"🗑️ {deleted_count} row(s) deleted from '{table}'"
    
    def _execute_drop(self, query: str) -> str:
        """Execute DROP TABLE query"""
        match = re.match(r"DROP TABLE\s+(\w+)", query, re.IGNORECASE)
        if not match:
            return "❌ Invalid DROP TABLE query"
        
        table_raw = match.group(1)
        table = self._sanitize_identifier(table_raw)
        table_path = os.path.join(self.project_path, f"{table}{TABLE_EXT}")
        meta_path = table_path + ".meta"
        
        if not os.path.exists(table_path):
            return f"❌ Table '{table}' does not exist"
        
        try:
            os.remove(table_path)
            if os.path.exists(meta_path):
                os.remove(meta_path)
            
            # Remove WAL
            wal_path = os.path.join(self.project_path, f"{table}{WAL_EXT}")
            if os.path.exists(wal_path):
                os.remove(wal_path)
            
            # Remove constraints
            constraint_path = os.path.join(self.project_path, f"{table}{CONSTRAINT_EXT}")
            if os.path.exists(constraint_path):
                os.remove(constraint_path)
            
            # Update cloud storage
            self.cloud_sync.sync_table(table, None, "DROP")
            
            return f"✅ Table '{table}' dropped successfully"
        except OSError as e:
            self._log_security_event("DROP_ERROR", f"Failed to drop {table}: {e}")
            return f"❌ Error dropping table '{table}': {e}"
    
    def _log_query(self, query: str, status: str):
        """Log query to system table"""
        query_log = {
            'query_id': hashlib.md5(f"{query}{time.time()}".encode()).hexdigest()[:8],
            'query_text': query[:500],  # Limit length
            'execution_time': time.time(),
            'timestamp': datetime.now().isoformat(),
            'status': status
        }
        
        # Append to system queries
        system_queries = self._read_table('system_queries') or []
        system_queries.append(query_log)
        self._write_table('system_queries', system_queries)
    
    def _update_system_tables(self):
        """Update system tables with current database state"""
        tables = self.list_tables()
        
        system_tables_data = []
        for table in tables:
            if table.startswith('system_'):
                continue
            
            data = self._read_table(table) or []
            metadata = self._read_metadata(table) or {}
            
            system_tables_data.append({
                'table_name': table,
                'column_count': len(metadata.get('columns', [])),
                'row_count': len(data),
                'created_at': metadata.get('created_at', datetime.now().isoformat()),
                'encrypted': self.production
            })
        
        self._write_table('system_tables', system_tables_data)
    
    def backup(self) -> Dict[str, str]:
        """Backup database with encryption awareness"""
        backup_results = self.backup_manager.backup_database(self.project_name, self.project_path)
        
        # Add encryption info to backup results
        if self.production:
            for provider in backup_results:
                backup_results[provider] += " (ENCRYPTED)"
        
        self._log_security_event("BACKUP_CREATED", f"Backup completed - Encrypted: {self.production}")
        return backup_results
    
    def restore(self, provider: str = None) -> str:
        """Restore database from backup"""
        return self.backup_manager.restore_database(self.project_name, self.project_path, provider)
    
    def list_tables(self) -> List[str]:
        """List all tables in database"""
        tables = []
        if os.path.exists(self.project_path):
            for file in os.listdir(self.project_path):
                if file.endswith(TABLE_EXT) and not file.endswith('.meta'):
                    tables.append(file[:-len(TABLE_EXT)])
        return tables
    
    def table_info(self, table: str) -> Optional[Dict]:
        """Get information about a table"""
        data = self._read_table(table)
        metadata = self._read_metadata(table)
        
        if data is None or metadata is None:
            return None
        
        # Get constraint info
        constraint_manager = self._get_constraint_manager(table)
        
        return {
            'table_name': table,
            'columns': metadata.get('columns', []),
            'row_count': len(data),
            'created_at': metadata.get('created_at'),
            'storage': self.config.get('primary_storage', 'local'),
            'encrypted': self.production,
            'constraints': list(constraint_manager.constraints.keys()),
            'indexes': [f"{col}" for (tbl, col) in self.index_managers.keys() if tbl == table]
        }
    
    def query_history(self, limit: int = 10) -> List[Dict]:
        """Get query history"""
        queries = self._read_table('system_queries') or []
        return queries[-limit:]
    
    def performance_stats(self) -> Dict[str, Any]:
        """Get database performance statistics"""
        tables = self.list_tables()
        total_rows = 0
        total_size = 0
        
        for table in tables:
            if table.startswith('system_'):
                continue
            
            data = self._read_table(table) or []
            total_rows += len(data)
            
            table_path = os.path.join(self.project_path, f"{table}{TABLE_EXT}")
            if os.path.exists(table_path):
                total_size += os.path.getsize(table_path)
        
        return {
            'total_tables': len([t for t in tables if not t.startswith('system_')]),
            'total_rows': total_rows,
            'total_size_bytes': total_size,
            'cache_hits': len(self.query_optimizer.query_cache),
            'backup_providers': list(self.backup_manager.providers.keys()),
            'production_mode': self.production,
            'cloud_sync': self.cloud_sync.sync_enabled,
            'pending_syncs': len(self.cloud_sync.sync_queue),
            'backup_available': self.cloud_sync.backup_available,
            'indexes': len(self.index_managers)
        }
    
    def get_encryption_info(self) -> Dict[str, Any]:
        """Get encryption information for the database"""
        return {
            'production_mode': self.production,
            'project_name': self.project_name,
            'tables_encrypted': self._get_encrypted_tables_count(),
            'encryption_status': 'ACTIVE' if self.production else 'INACTIVE'
        }
    
    def _get_encrypted_tables_count(self) -> int:
        """Get count of encrypted tables"""
        if not self.production:
            return 0
        
        tables = [t for t in self.list_tables() if not t.startswith('system_')]
        return len(tables)

    def get_environment(self) -> EnvironmentManager:
        """Get the environment manager instance"""
        return self.env_manager

    def force_sync(self, table: str = None):
        """Force immediate sync to cloud storage"""
        self.cloud_sync.force_sync(table)
    
    def close(self):
        """Close database and clean up resources"""
        # Close all WAL managers
        for wal in self.wal_managers.values():
            wal.close()
        
        # Stop cloud sync
        self.cloud_sync.stop()
        
        # Final backup if enabled
        if self.config.get('backup_enabled', False):
            self.backup()

def env(env_file: str = ENV_FILE, production: bool = False) -> EnvironmentManager:
    """
    Create and return an EnvironmentManager instance.
    
    Usage:
        my_envs = env()
        encrypted_key = my_envs.get("encrypted_key")
        api_key = my_envs.get("api_key", "default_value")
    """
    return EnvironmentManager(env_file, production)

def migrate_to_production(project_name: str, env_file: str = ENV_FILE):
    """
    Helper function to migrate an existing database to production mode.
    This will encrypt all existing data and generate encryption keys.
    """
    print(f"🚀 Migrating '{project_name}' to production mode...")
    
    # Initialize in non-production mode first to read existing data
    db = database(project_name, production=False, env_file=env_file)
    env_manager = db.get_environment()
    
    # Switch to production mode with migration
    db_prod = database(project_name, production=True, env_file=env_file)
    
    print("✅ Migration completed!")
    print("💡 Next time, use:")
    print(f"   my_envs = env()")
    print(f"   db = database('{project_name}', production=True, encryption_key=my_envs.get('encrypted_key'))")

# Enhanced CLI main function
def cli_main():
    """Main CLI entry point with enhanced production migration support"""
    parser = argparse.ArgumentParser(description="SoketDB CLI Tool")
    subparsers = parser.add_subparsers(dest="command", required=True)
    
    # Init command
    init_parser = subparsers.add_parser("init", help="Initialize a new database project")
    init_parser.add_argument("project", help="Project name")
    init_parser.add_argument("--production", action="store_true", help="Enable production mode")
    init_parser.add_argument("--key", help="Encryption key (if production)")
    init_parser.add_argument("--env-file", default=ENV_FILE, help="Environment file path")
    
    # Migrate command
    migrate_parser = subparsers.add_parser("migrate", help="Migrate to production mode")
    migrate_parser.add_argument("project", help="Project name")
    migrate_parser.add_argument("--env-file", default=ENV_FILE, help="Environment file path")
    
    # Env command
    env_parser = subparsers.add_parser("env", help="Manage environment variables")
    env_parser.add_argument("--set", nargs=2, action="append", metavar=("KEY", "VALUE"), help="Set environment variable")
    env_parser.add_argument("--get", help="Get environment variable")
    env_parser.add_argument("--list", action="store_true", help="List all environment variables")
    env_parser.add_argument("--env-file", default=ENV_FILE, help="Environment file path")
    
    # Sync command
    sync_parser = subparsers.add_parser("sync", help="Force immediate cloud sync")
    sync_parser.add_argument("project", help="Project name")
    sync_parser.add_argument("--table", help="Specific table to sync")
    sync_parser.add_argument("--production", action="store_true")
    sync_parser.add_argument("--key", help="Encryption key")
    sync_parser.add_argument("--env-file", default=ENV_FILE, help="Environment file path")
    
    # Query command
    query_parser = subparsers.add_parser("query", help="Execute SQL or natural language query")
    query_parser.add_argument("project", help="Project name")
    query_parser.add_argument("sql_or_nl", help="SQL or natural language query")
    query_parser.add_argument("--natural", action="store_true", help="Use natural language mode")
    query_parser.add_argument("--production", action="store_true")
    query_parser.add_argument("--key", help="Encryption key")
    query_parser.add_argument("--env-file", default=ENV_FILE, help="Environment file path")
    
    # Backup command
    backup_parser = subparsers.add_parser("backup", help="Backup database")
    backup_parser.add_argument("project", help="Project name")
    backup_parser.add_argument("--production", action="store_true")
    backup_parser.add_argument("--key", help="Encryption key")
    backup_parser.add_argument("--env-file", default=ENV_FILE, help="Environment file path")
    
    # List command
    list_parser = subparsers.add_parser("list", help="List tables")
    list_parser.add_argument("project", help="Project name")
    list_parser.add_argument("--production", action="store_true")
    list_parser.add_argument("--key", help="Encryption key")
    list_parser.add_argument("--env-file", default=ENV_FILE, help="Environment file path")
    
    # Inspect command
    inspect_parser = subparsers.add_parser("inspect", help="Inspect system table")
    inspect_parser.add_argument("project", help="Project name")
    inspect_parser.add_argument("--table", default="system_tables", help="System table to inspect")
    inspect_parser.add_argument("--production", action="store_true")
    inspect_parser.add_argument("--key", help="Encryption key")
    inspect_parser.add_argument("--env-file", default=ENV_FILE, help="Environment file path")
    
    # Config command
    config_parser = subparsers.add_parser("config", help="Generate config")
    config_parser.add_argument("--output", default=CONFIG_FILE, help="Output file")
    config_parser.add_argument("--non-interactive", action="store_true")
    
    args = parser.parse_args()
    
    if args.command == "config":
        generate_config_cli()
        return
    
    if args.command == "env":
        env_manager = env(args.env_file)
        
        if args.set:
            for key, value in args.set:
                env_manager.set(key, value)
                print(f"✅ Set {key}={value}")
        
        if args.get:
            value = env_manager.get(args.get)
            print(f"{args.get}={value}")
        
        if args.list:
            for key, value in env_manager.items():
                print(f"{key}={value}")
        
        return
    
    if args.command == "migrate":
        migrate_to_production(args.project, args.env_file)
        return
    
    if args.command in ["init", "query", "backup", "list", "inspect", "sync"]:
        if not os.path.exists(DATABASE):
            os.makedirs(DATABASE)
        
        try:
            db = database(
                args.project, 
                production=args.production, 
                encryption_key=args.key if args.key else None,
                env_file=args.env_file
            )
            
            if args.command == "init":
                print(f"✅ Initialized project: {args.project}")
                if args.production:
                    print("🔐 Production mode enabled")
                    print("💡 Use: my_envs = env()")
                    print("💡 Then: encrypted_key = my_envs.get('encrypted_key')")
                return
            
            elif args.command == "sync":
                db.force_sync(args.table)
                if args.table:
                    print(f"✅ Forced sync for table: {args.table}")
                else:
                    print("✅ Forced sync for all pending tables")
                return
            
            elif args.command == "query":
                if args.natural:
                    result = db.query(args.sql_or_nl)
                else:
                    result = db.execute(args.sql_or_nl)
                print(result)
            
            elif args.command == "backup":
                results = db.backup()
                for prov, res in results.items():
                    print(f"{prov}: {res}")
            
            elif args.command == "list":
                tables = db.list_tables()
                print("Tables:")
                for t in tables:
                    print(f"  - {t}")
            
            elif args.command == "inspect":
                data = db.inspect_system_table(args.table)
                if data:
                    print(f"✅ Inspected {len(data)} rows")
                else:
                    print("❌ No data or invalid table")
            
            # Close database connection
            db.close()
                    
        except Exception as e:
            print(f"❌ Error: {e}")
            return
    
    else:
        parser.print_help()

def generate_config_cli():
    """Generate config file via CLI"""
    db = database("temp")  # Temporary instance to use the method
    db.generate_config()

# Export the main classes
__all__ = ['database', 'env', 'migrate_to_production', 'Connection', 'Cursor', 
           'IsolationLevel', 'ConstraintType', 'IndexType']

if __name__ == "__main__":
    cli_main()