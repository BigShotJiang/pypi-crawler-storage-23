"""Iceberg Table Metadata Explorer CLI."""

__version__ = "0.2.1"
