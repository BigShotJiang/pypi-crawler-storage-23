class ToolkitError(Exception):
    pass
