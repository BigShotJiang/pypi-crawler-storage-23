HitchPyLibraryToolkit
---------------------

Note: You probably shouldn't be using this unless you're building a library
for use with hitch.

It's for deduplicating code across hitch libraries for doing:

* Specifying / Testing
* Documenting
* Deployment
* Linting
* Reformatting
