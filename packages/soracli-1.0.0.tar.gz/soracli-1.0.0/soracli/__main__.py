"""
Main entry point for running SoraCLI as a module.

Usage: python -m soracli [OPTIONS] COMMAND [ARGS]...
"""

from soracli.cli import main

if __name__ == "__main__":
    main()
