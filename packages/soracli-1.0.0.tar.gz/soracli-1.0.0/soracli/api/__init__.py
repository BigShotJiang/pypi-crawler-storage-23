"""
API module for external data fetching.
"""

from soracli.api.weather_fetcher import WeatherFetcher, WeatherData

__all__ = ["WeatherFetcher", "WeatherData"]
