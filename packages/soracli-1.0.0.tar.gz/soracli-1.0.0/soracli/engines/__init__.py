"""
Weather animation engines module.

Each engine provides animated ASCII simulations for specific weather conditions.
"""

from soracli.engines.rain import RainEngine
from soracli.engines.snow import SnowEngine
from soracli.engines.thunder import ThunderEngine
from soracli.engines.fog import FogEngine
from soracli.engines.clear import ClearEngine
from soracli.engines.base import BaseWeatherEngine

__all__ = [
    "BaseWeatherEngine",
    "RainEngine",
    "SnowEngine",
    "ThunderEngine",
    "FogEngine",
    "ClearEngine",
]

# Weather condition mapping to engines
ENGINE_MAP = {
    "rain": RainEngine,
    "drizzle": RainEngine,
    "snow": SnowEngine,
    "thunderstorm": ThunderEngine,
    "fog": FogEngine,
    "mist": FogEngine,
    "haze": FogEngine,
    "smoke": FogEngine,
    "clear": ClearEngine,
    "clouds": ClearEngine,
}


def get_engine_for_condition(condition: str) -> type:
    """Get the appropriate engine class for a weather condition."""
    condition_lower = condition.lower()
    for key, engine in ENGINE_MAP.items():
        if key in condition_lower:
            return engine
    return ClearEngine  # Default fallback
