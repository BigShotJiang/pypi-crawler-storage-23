"""
SoraCLI - Real-time terminal ambient environment engine.

A production-grade CLI tool that synchronizes real-world weather conditions
with animated terminal simulations.
"""

__version__ = "1.0.0"
__author__ = "SoraCLI Contributors"
__license__ = "MIT"

from soracli.cli import cli

__all__ = ["cli", "__version__"]
