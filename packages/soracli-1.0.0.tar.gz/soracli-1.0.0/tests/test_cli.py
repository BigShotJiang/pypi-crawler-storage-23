"""
Tests for CLI interface.
"""

import pytest
from click.testing import CliRunner
from soracli.cli import cli


class TestCLI:
    """Tests for CLI commands."""
    
    @pytest.fixture
    def runner(self):
        """Create CLI test runner."""
        return CliRunner()
    
    def test_cli_help(self, runner):
        """Test CLI help command."""
        result = runner.invoke(cli, ['--help'])
        assert result.exit_code == 0
        assert 'SoraCLI' in result.output
    
    def test_cli_version(self, runner):
        """Test CLI version command."""
        result = runner.invoke(cli, ['--version'])
        assert result.exit_code == 0
        assert '1.0.0' in result.output
    
    def test_demo_help(self, runner):
        """Test demo command help."""
        result = runner.invoke(cli, ['demo', '--help'])
        assert result.exit_code == 0
        assert '--rain' in result.output
        assert '--snow' in result.output
        assert '--storm' in result.output
    
    def test_demo_no_condition(self, runner):
        """Test demo without condition specified."""
        result = runner.invoke(cli, ['demo'])
        assert 'specify a weather condition' in result.output
    
    def test_init_help(self, runner):
        """Test init command help."""
        result = runner.invoke(cli, ['init', '--help'])
        assert result.exit_code == 0
        assert '--location' in result.output
        assert '--theme' in result.output
    
    def test_themes_command(self, runner):
        """Test themes list command."""
        result = runner.invoke(cli, ['themes'])
        assert result.exit_code == 0
        assert 'Available Themes' in result.output
    
    def test_status_command(self, runner):
        """Test status command."""
        result = runner.invoke(cli, ['status'])
        assert result.exit_code == 0
        assert 'SoraCLI' in result.output
        assert 'Configuration' in result.output
    
    def test_start_help(self, runner):
        """Test start command help."""
        result = runner.invoke(cli, ['start', '--help'])
        assert result.exit_code == 0
        assert '--location' in result.output
        assert '--theme' in result.output
    
    def test_weather_help(self, runner):
        """Test weather command help."""
        result = runner.invoke(cli, ['weather', '--help'])
        assert result.exit_code == 0
