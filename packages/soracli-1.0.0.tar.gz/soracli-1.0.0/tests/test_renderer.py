"""
Tests for ASCII renderer.
"""

import pytest
from soracli.renderer.ascii_renderer import ANSIRenderer, COLORS, RESET


class TestANSIRenderer:
    """Tests for ANSIRenderer class."""
    
    @pytest.fixture
    def renderer(self):
        """Create renderer instance."""
        return ANSIRenderer()
    
    def test_clear_screen(self, renderer):
        """Test clear screen escape code."""
        code = renderer.clear_screen()
        assert '\033[2J' in code
        assert '\033[H' in code
    
    def test_clear_line(self, renderer):
        """Test clear line escape code."""
        code = renderer.clear_line()
        assert '\033[2K' in code
    
    def test_move_cursor(self, renderer):
        """Test cursor movement."""
        code = renderer.move_cursor(10, 20)
        assert '\033[20;10H' in code
    
    def test_hide_cursor(self, renderer):
        """Test hide cursor."""
        code = renderer.hide_cursor()
        assert '\033[?25l' in code
    
    def test_show_cursor(self, renderer):
        """Test show cursor."""
        code = renderer.show_cursor()
        assert '\033[?25h' in code
    
    def test_color_text(self, renderer):
        """Test text coloring."""
        result = renderer.color('test', fg='red')
        assert COLORS['red'] in result
        assert 'test' in result
        assert RESET in result
    
    def test_color_with_background(self, renderer):
        """Test text coloring with background."""
        result = renderer.color('test', fg='white', bg='blue')
        assert 'test' in result
        assert RESET in result
    
    def test_color_bold(self, renderer):
        """Test bold text."""
        result = renderer.color('test', bold=True)
        assert '\033[1m' in result
    
    def test_color_256(self, renderer):
        """Test 256-color mode."""
        result = renderer.color_256('test', fg=196)
        assert '\033[38;5;196m' in result
    
    def test_color_256_background(self, renderer):
        """Test 256-color background."""
        result = renderer.color_256('test', bg=21)
        assert '\033[48;5;21m' in result
    
    def test_color_rgb(self, renderer):
        """Test RGB true color."""
        result = renderer.color_rgb('test', fg=(255, 128, 0))
        assert '\033[38;2;255;128;0m' in result
    
    def test_reset_terminal(self, renderer):
        """Test terminal reset."""
        reset = renderer.reset_terminal()
        assert '\033[?25h' in reset  # Show cursor
        assert RESET in reset
    
    def test_render_buffer(self, renderer):
        """Test buffer rendering."""
        buffer = [
            ['A', 'B', 'C'],
            ['D', 'E', 'F'],
        ]
        result = renderer.render_buffer(buffer, [], {})
        assert 'A' in result
        assert 'F' in result
    
    def test_gradient_text(self, renderer):
        """Test gradient text."""
        result = renderer.gradient_text('test', (255, 0, 0), (0, 0, 255))
        assert 'test' not in result  # Characters are split by color codes
        assert '\033[38;2;' in result
    
    def test_gradient_empty_text(self, renderer):
        """Test gradient with empty text."""
        result = renderer.gradient_text('', (255, 0, 0), (0, 0, 255))
        assert result == ''
    
    def test_render_status_bar(self, renderer):
        """Test status bar rendering."""
        result = renderer.render_status_bar('Status', 20, {'status_fg': 'black', 'status_bg': 'white'})
        assert 'Status' in result


class TestColorCodes:
    """Tests for color code constants."""
    
    def test_colors_exist(self):
        """Test that all basic colors exist."""
        expected_colors = ['black', 'red', 'green', 'yellow', 'blue', 
                         'magenta', 'cyan', 'white']
        for color in expected_colors:
            assert color in COLORS
    
    def test_bright_colors_exist(self):
        """Test that bright colors exist."""
        expected = ['bright_red', 'bright_green', 'bright_blue']
        for color in expected:
            assert color in COLORS
    
    def test_reset_code(self):
        """Test reset code."""
        assert RESET == '\033[0m'
