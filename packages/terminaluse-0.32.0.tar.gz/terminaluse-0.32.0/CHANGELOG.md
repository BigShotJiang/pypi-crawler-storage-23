# Changelog

## [0.32.0](https://github.com/terminal-use/monorepo/compare/python-sdk-v0.31.0...python-sdk-v0.32.0) (2026-02-23)


### Features

* **cli:** add PostHog command analytics tracking ([#303](https://github.com/terminal-use/monorepo/issues/303)) ([1b140a5](https://github.com/terminal-use/monorepo/commit/1b140a5b9526604e573570e82ab6f6d11c1a99b6))
* **python-cli:** add tasks create --branch override ([#287](https://github.com/terminal-use/monorepo/issues/287)) ([3e23b87](https://github.com/terminal-use/monorepo/commit/3e23b8741fe3fd9073743f23c5616f47d3a69823))

## [0.31.0](https://github.com/terminal-use/monorepo/compare/python-sdk-v0.30.0...python-sdk-v0.31.0) (2026-02-21)


### ⚠ BREAKING CHANGES

* **agentex:** simplify authz with org-owned groups and api-key sharing ([#237](https://github.com/terminal-use/monorepo/issues/237))

### Features

* **agentex:** simplify authz with org-owned groups and api-key sharing ([#237](https://github.com/terminal-use/monorepo/issues/237)) ([fd13c1a](https://github.com/terminal-use/monorepo/commit/fd13c1a42f81189115d404be2e454c5eae7efba8))
* **cli:** replace tasks fs with tasks pull ([#259](https://github.com/terminal-use/monorepo/issues/259)) ([678d091](https://github.com/terminal-use/monorepo/commit/678d0915f20b8cc411a84bea959d8cacaf04e567))
* **observability:** reduce low-signal telemetry for SSE and high-volume routes ([#252](https://github.com/terminal-use/monorepo/issues/252)) ([02301c3](https://github.com/terminal-use/monorepo/commit/02301c3a1ca10673218b42972518f67e84f8a836))
* **sdk:** extract reusable sandbox test harness from PR [#241](https://github.com/terminal-use/monorepo/issues/241) ([#264](https://github.com/terminal-use/monorepo/issues/264)) ([9a23606](https://github.com/terminal-use/monorepo/commit/9a236066b7195490a7406fbea37cbe4b57a2578f))
* **sidecar:** ship hardened sandbox sidecar MVP and isolated harness ([#241](https://github.com/terminal-use/monorepo/issues/241)) ([e52439b](https://github.com/terminal-use/monorepo/commit/e52439b097c200bb45656a2b4769a017a6686ddc))


### Bug Fixes

* **cli:** make agent output scrollable and remove truncation ([#248](https://github.com/terminal-use/monorepo/issues/248)) ([90cbb00](https://github.com/terminal-use/monorepo/commit/90cbb00a170d1d1df0d9af7979ececf2498ceacf))
* **nucleus:** eliminate ty invalid-type-form errors with type aliases ([#250](https://github.com/terminal-use/monorepo/issues/250)) ([905f22d](https://github.com/terminal-use/monorepo/commit/905f22d6acb8b63a90312b9b1f0513d3b44de90d))
* **nucleus:** eliminate ty invalid-type-form errors with type aliases ([#261](https://github.com/terminal-use/monorepo/issues/261)) ([cd830c3](https://github.com/terminal-use/monorepo/commit/cd830c3ea37274d6a8e588f6d8a4ab224197b012))
* **nucleus:** resolve ty type checking errors (Phase 1) ([#244](https://github.com/terminal-use/monorepo/issues/244)) ([a50c224](https://github.com/terminal-use/monorepo/commit/a50c224edce015b887903e099fd846bed01d72b9))
* Revert loading regression ([#251](https://github.com/terminal-use/monorepo/issues/251)) ([a5b6074](https://github.com/terminal-use/monorepo/commit/a5b60744a6ab9cdc35b320f9168da86807f25180))
* **sdk:** allow HTTP for host.docker.internal in LogSender ([#231](https://github.com/terminal-use/monorepo/issues/231)) ([a2803c4](https://github.com/terminal-use/monorepo/commit/a2803c48dc12ba9570ed8864ce1e2a623e65e224))
* **sdk:** improve CLI output formatting for Codex tool results ([#225](https://github.com/terminal-use/monorepo/issues/225)) ([6a19593](https://github.com/terminal-use/monorepo/commit/6a19593a0e14ab2fdb41093cb1dfb91f872b3bff))
* **sdk:** require claude-agent-sdk &gt;=0.1.38 ([#257](https://github.com/terminal-use/monorepo/issues/257)) ([33ed654](https://github.com/terminal-use/monorepo/commit/33ed654a515912572a9952340a4635e7a44498d5))


### Reverts

* remove sandbox sidecar MVP ([#241](https://github.com/terminal-use/monorepo/issues/241)) ([#258](https://github.com/terminal-use/monorepo/issues/258)) ([c59ca7d](https://github.com/terminal-use/monorepo/commit/c59ca7d1b77da2acb859c8ff25074c4c2ebc08a1))

## [0.30.0](https://github.com/terminal-use/monorepo/compare/python-sdk-v0.29.0...python-sdk-v0.30.0) (2026-02-17)


### Features

* add codex_tool runtime and codex adapter routing ([#175](https://github.com/terminal-use/monorepo/issues/175)) ([677301a](https://github.com/terminal-use/monorepo/commit/677301a0cdafb4040bec19ff13d4f35af6923f1d))
* **woz:** Woz v0 ([#220](https://github.com/terminal-use/monorepo/issues/220)) ([5b27189](https://github.com/terminal-use/monorepo/commit/5b271894a5fc75c1641890f77d5f925402615d22))

## [0.29.0](https://github.com/terminal-use/monorepo/compare/python-sdk-v0.28.1...python-sdk-v0.29.0) (2026-02-16)


### Features

* **sdk:** bump default agent memory limit from 2Gi to 6Gi ([#217](https://github.com/terminal-use/monorepo/issues/217)) ([096b11b](https://github.com/terminal-use/monorepo/commit/096b11b3572b6a4d71ebf8961b83212cfd4ef5cc))


### Bug Fixes

* **cli:** fix streaming output buffering in non-TTY environments ([#199](https://github.com/terminal-use/monorepo/issues/199)) ([d364a75](https://github.com/terminal-use/monorepo/commit/d364a75834d3a9d85679144932d0561039e3998a))

## [0.28.1](https://github.com/terminal-use/monorepo/compare/python-sdk-v0.28.0...python-sdk-v0.28.1) (2026-02-16)


### Bug Fixes

* graceful OpenFGA health gate and improved project list table ([#207](https://github.com/terminal-use/monorepo/issues/207)) ([9280e1d](https://github.com/terminal-use/monorepo/commit/9280e1d20d32e486c942a8474d8ceb5e7cd0d974))

## [0.28.0](https://github.com/terminal-use/monorepo/compare/python-sdk-v0.27.0...python-sdk-v0.28.0) (2026-02-16)


### Features

* add organization invitations and project collaborators management ([#162](https://github.com/terminal-use/monorepo/issues/162)) ([f515da3](https://github.com/terminal-use/monorepo/commit/f515da3383c518565af533b7cdc742fc71a21816))
* **agentex:** add API key scope mutation and auth hardening ([#166](https://github.com/terminal-use/monorepo/issues/166)) ([e16ca43](https://github.com/terminal-use/monorepo/commit/e16ca43eaaabf5c8610b73de6a1ce063ee35b033))
* **authz:** align OpenFGA discover semantics + SDK parity ([#198](https://github.com/terminal-use/monorepo/issues/198)) ([bf58926](https://github.com/terminal-use/monorepo/commit/bf589266918e178c7534a376d787107f129f63f2))
* harden OpenFGA semantics and release guardrails ([#170](https://github.com/terminal-use/monorepo/issues/170)) ([9e8ea99](https://github.com/terminal-use/monorepo/commit/9e8ea99a91b391591610324fc8fa7419d70eb558))
* **nucleus:** add version pod metrics API and local collector mirror ([#203](https://github.com/terminal-use/monorepo/issues/203)) ([9f0d411](https://github.com/terminal-use/monorepo/commit/9f0d41177e33d88f5924316162650f6e2622ef87))
* **nucleus:** org api keys ([#177](https://github.com/terminal-use/monorepo/issues/177)) ([4512da8](https://github.com/terminal-use/monorepo/commit/4512da847396dd3c468fc928a8de54ad1a060acd))
* **org:** add organization member role update and removal management ([#164](https://github.com/terminal-use/monorepo/issues/164)) ([1dbb4e2](https://github.com/terminal-use/monorepo/commit/1dbb4e2666256dce72fa03d89ca2fe6c31776ef5))
* **platform:** groups UI ([#201](https://github.com/terminal-use/monorepo/issues/201)) ([d8df730](https://github.com/terminal-use/monorepo/commit/d8df73064a7d650842ec16c49a94762218ae3b9c))
* split platform/agentex/infra updates into isolated commits ([#205](https://github.com/terminal-use/monorepo/issues/205)) ([2a30974](https://github.com/terminal-use/monorepo/commit/2a3097418f3c05fdf4e662472c11e1c60810e8eb))


### Bug Fixes

* **cli:** show full task IDs in `tu tasks ls` ([#178](https://github.com/terminal-use/monorepo/issues/178)) ([a7ab3b1](https://github.com/terminal-use/monorepo/commit/a7ab3b13154a8d9dcbec0b2238b37eb726728f9c))
* **python-sdk:** show "Up to date!" after version check ([#154](https://github.com/terminal-use/monorepo/issues/154)) ([76b99c0](https://github.com/terminal-use/monorepo/commit/76b99c0660a5dc49306bf4b197eec3e31b193559))
* **sdk:** harden bubblewrap sandbox isolation ([#184](https://github.com/terminal-use/monorepo/issues/184)) ([13b5b8c](https://github.com/terminal-use/monorepo/commit/13b5b8c7825b0b72413d686536ba5661769b5e1a))
* **sdk:** improve Docker layer caching for uv Dockerfile templates ([#176](https://github.com/terminal-use/monorepo/issues/176)) ([29d3635](https://github.com/terminal-use/monorepo/commit/29d36355bfd3238b772f60b75d4d8c7c8928f073))
* **ts-sdk:** trigger release for README update ([#157](https://github.com/terminal-use/monorepo/issues/157)) ([d6abaad](https://github.com/terminal-use/monorepo/commit/d6abaadeef1295f7f697faf7465ebc55011ba2be))

## [0.27.0](https://github.com/terminal-use/monorepo/compare/python-sdk-v0.26.0...python-sdk-v0.27.0) (2026-02-11)


### Features

* **python-sdk:** add CLI version update notifications ([#148](https://github.com/terminal-use/monorepo/issues/148)) ([ea4d62c](https://github.com/terminal-use/monorepo/commit/ea4d62c4bb5c6d276fd309fb7937e33783f9ed80))
* **sdk:** add AgentMessagePart types for simplified message sending ([#122](https://github.com/terminal-use/monorepo/issues/122)) ([27d49d7](https://github.com/terminal-use/monorepo/commit/27d49d77430fb1b6345d345d9c900d7357dcc6a5))


### Bug Fixes

* **woz:** posthog integration ([#135](https://github.com/terminal-use/monorepo/issues/135)) ([6d8bab2](https://github.com/terminal-use/monorepo/commit/6d8bab2bdaba39b1055c2440389ec8a9b58a5922))

## [0.26.0](https://github.com/terminal-use/monorepo/compare/python-sdk-v0.25.0...python-sdk-v0.26.0) (2026-02-10)


### Features

* **nucleus:** IDLE/RUNNING task state with optimistic locking ([#124](https://github.com/terminal-use/monorepo/issues/124)) ([7729ced](https://github.com/terminal-use/monorepo/commit/7729ced566e283aa52570c94cd8f5113b8161e3d))


### Bug Fixes

* redirect users to overview after login ([#128](https://github.com/terminal-use/monorepo/issues/128)) ([78f039b](https://github.com/terminal-use/monorepo/commit/78f039b28ead4e3e7800ada45495855dd51216da))


### Reverts

* **platform-woz:** reset platform-woz to main ([#136](https://github.com/terminal-use/monorepo/issues/136)) ([139113c](https://github.com/terminal-use/monorepo/commit/139113ca5e3ac21f349d1e78480383c6ef899a5c))

## [0.25.0](https://github.com/terminal-use/monorepo/compare/python-sdk-v0.24.2...python-sdk-v0.25.0) (2026-02-09)


### Features

* **cli:** add --no-cache flag to tu deploy ([#119](https://github.com/terminal-use/monorepo/issues/119)) ([d606aa6](https://github.com/terminal-use/monorepo/commit/d606aa62c22508cae3338914751f69df8546aede))
* **deploy:** capture failed pod log snapshots in diagnostics ([d9edcc3](https://github.com/terminal-use/monorepo/commit/d9edcc3c0e6f9e62fca6f3c8a26261d04a9e8c46))


### Bug Fixes

* **sdk:** preserve multipart payloads across http retries ([d794604](https://github.com/terminal-use/monorepo/commit/d79460456e59adf87bef40e1d7ba93dfb0bff3e3))
* **sdk:** unify filesystem path contract for sync and sandbox mounts ([e3d80fa](https://github.com/terminal-use/monorepo/commit/e3d80faa84ac6be60db957d619db0bfed2f4a8e0))

## [0.24.2](https://github.com/terminal-use/monorepo/compare/python-sdk-v0.24.1...python-sdk-v0.24.2) (2026-02-08)


### Bug Fixes

* add SSE keepalive framing and CLI TERMINALUSE_API_KEY auth ([f509e76](https://github.com/terminal-use/monorepo/commit/f509e76bdf6a9f742f9312fe5934a5a0e83f54d1))
* **cli-auth:** refresh expired sessions silently and retry once on 401 ([60d3ac2](https://github.com/terminal-use/monorepo/commit/60d3ac20dd596bead1e12dc62444fd4df8d9dca8))
* **cli:** honor TERMINALUSE_API_KEY env var ([1712f92](https://github.com/terminal-use/monorepo/commit/1712f928bec3d4edeeb1f78c920cd761ca075fdb))
* **python-sdk:** propagate sandbox handler failures in fastacp ([b197313](https://github.com/terminal-use/monorepo/commit/b1973131a67b0421d9372cba740fcc545cd3de20))
* **python-sdk:** sync up after task create handlers ([ec537dc](https://github.com/terminal-use/monorepo/commit/ec537dccffc5e825059d668718dc2b6b235951e7))

## [0.24.1](https://github.com/terminal-use/monorepo/compare/python-sdk-v0.24.0...python-sdk-v0.24.1) (2026-02-04)


### Bug Fixes

* **platform,sdk:** improve onboarding UX and fix task navigation ([565c5cc](https://github.com/terminal-use/monorepo/commit/565c5cc0a32d151566da622db0578c9c1509e2c1))

## [0.24.0](https://github.com/terminal-use/monorepo/compare/python-sdk-v0.23.0...python-sdk-v0.24.0) (2026-02-04)


### Features

* **sdk:** add ClaudeMessage support to ctx.messages.send() and update examples ([1448b14](https://github.com/terminal-use/monorepo/commit/1448b1414644191793ca133ee456bf12dbf90a5a))
* **sdk:** add ClaudeMessage support to ctx.messages.send() and update examples ([3392f94](https://github.com/terminal-use/monorepo/commit/3392f94d53be6ab555c54a2c4c5419faeab08569))


### Bug Fixes

* **cli:** add helpful error message for Docker exec format error ([8741709](https://github.com/terminal-use/monorepo/commit/874170972a53f3e33eaa63da664349c874bea361))
* **sdk:** rename client classes to TerminalUse (uppercase U) ([#85](https://github.com/terminal-use/monorepo/issues/85)) ([b651b6a](https://github.com/terminal-use/monorepo/commit/b651b6adb55fec6352072c00ef78f4944a16e2d0))

## [0.23.0](https://github.com/terminal-use/monorepo/compare/python-sdk-v0.22.0...python-sdk-v0.23.0) (2026-02-04)


### Features

* **cli:** Improve tu deploy UX with SSE streaming, trace_id, and better feedback ([#59](https://github.com/terminal-use/monorepo/issues/59)) ([048da80](https://github.com/terminal-use/monorepo/commit/048da8002ed8de3ad44aa4486985d83ae904c61b))
* **infra:** Security-harden OTel Collector + document observability architecture ([#76](https://github.com/terminal-use/monorepo/issues/76)) ([e5c28c2](https://github.com/terminal-use/monorepo/commit/e5c28c26395939ae7bd2666f358b7275f9791cab))
* **nucleus:** increase deployment timeout to 8 minutes ([c72e3a7](https://github.com/terminal-use/monorepo/commit/c72e3a7b2b748ea8534bd4c89b76451412ffddb2))
* **nucleus:** unify message storage in raw_messages collection ([#74](https://github.com/terminal-use/monorepo/issues/74)) ([f894493](https://github.com/terminal-use/monorepo/commit/f894493f7d59e1790579e974cdf85480af0cf394))
* **templates:** add observability extras and improve init templates ([01969c0](https://github.com/terminal-use/monorepo/commit/01969c0c3ad34b58bc6f2ee7ebe4f72b5cd1db9c))


### Bug Fixes

* **cli:** build only for linux/amd64 platform ([289308b](https://github.com/terminal-use/monorepo/commit/289308b88e6a9ecd10089d64a0d3cc5a9829c231))
* **cli:** improve error messages with detailed context ([#71](https://github.com/terminal-use/monorepo/issues/71)) ([d569707](https://github.com/terminal-use/monorepo/commit/d56970786e0f2d102d2a85497267c9d432ad67e2))
* **dev:** pin minikube static IP to 192.168.49.2 ([#79](https://github.com/terminal-use/monorepo/issues/79)) ([d9b8661](https://github.com/terminal-use/monorepo/commit/d9b8661495e1c8a10f0b35a63919714b1abf5e45))

## [0.22.0](https://github.com/terminal-use/monorepo/compare/python-sdk-v0.21.0...python-sdk-v0.22.0) (2026-02-03)


### ⚠ BREAKING CHANGES

* Custom exports are now imported from terminaluse.lib:

### Features

* **api:** add x-trace-id header to all HTTP responses ([#61](https://github.com/terminal-use/monorepo/issues/61)) ([f2b4d91](https://github.com/terminal-use/monorepo/commit/f2b4d91585b64a669651fa997765e6769f1863fd))
* **cli:** auto-detect agent for tu logs command ([#56](https://github.com/terminal-use/monorepo/issues/56)) ([3b8578a](https://github.com/terminal-use/monorepo/commit/3b8578ac7da233b90ae0ea88e8f7c2b20b10affb))
* implement Messaging System v2 with adapter pattern ([#3](https://github.com/terminal-use/monorepo/issues/3)) ([a0cab54](https://github.com/terminal-use/monorepo/commit/a0cab5434f283dbf915a77631dc532d1af70b09e))


### Bug Fixes

* **cli:** standardize error handling to use CLIError framework ([#58](https://github.com/terminal-use/monorepo/issues/58)) ([e7faee7](https://github.com/terminal-use/monorepo/commit/e7faee758d1d7b874a27e0f39a5df8325e524ac8))

## [0.21.0](https://github.com/terminal-use/monorepo/compare/python-sdk-v0.20.1...python-sdk-v0.21.0) (2026-02-02)


### Features

* **cli:** add centralized error handling for humans and agents ([#32](https://github.com/terminal-use/monorepo/issues/32)) ([d5dbf89](https://github.com/terminal-use/monorepo/commit/d5dbf89597cc2f3ade0f749fb612848fe4d9db2c))
* **python-sdk:** migrate from Poetry to PEP 621 with hatchling ([#54](https://github.com/terminal-use/monorepo/issues/54)) ([83b72aa](https://github.com/terminal-use/monorepo/commit/83b72aa9b2aad0633046d1c92fd717e7adf684bd))


### Bug Fixes

* AlertManager config + ClickHouse alert labels + observability updates ([#51](https://github.com/terminal-use/monorepo/issues/51)) ([16db76d](https://github.com/terminal-use/monorepo/commit/16db76db41d17c3383f0de116a6304b94ec77728))
* **cli:** add loading spinner for credential auto-refresh ([#50](https://github.com/terminal-use/monorepo/issues/50)) ([dcaffee](https://github.com/terminal-use/monorepo/commit/dcaffeeb2b44718561fc697462df8a0b16f9cad2))
* **python-sdk:** fix lint issues and remove duplicate CLI code ([#55](https://github.com/terminal-use/monorepo/issues/55)) ([7c539c1](https://github.com/terminal-use/monorepo/commit/7c539c1a2a4023abac36ac11cb75e84d45ec37fb))
* **python-sdk:** remove poetry-dynamic-versioning for Docker compatibility ([#52](https://github.com/terminal-use/monorepo/issues/52)) ([760e87d](https://github.com/terminal-use/monorepo/commit/760e87d899a6bf850f1ea23c76cf09666758e7d1))
* **routing:** add diagnostic logging for task branch routing ([#45](https://github.com/terminal-use/monorepo/issues/45)) ([9e7b4dd](https://github.com/terminal-use/monorepo/commit/9e7b4dd37cb8cda6db20ff01ff1f2e87bc4bad38))

## [0.20.1](https://github.com/terminal-use/monorepo/compare/python-sdk-v0.20.0...python-sdk-v0.20.1) (2026-02-01)


### Bug Fixes

* **python-sdk:** use poetry-dynamic-versioning for git tag versions ([#40](https://github.com/terminal-use/monorepo/issues/40)) ([ff95b70](https://github.com/terminal-use/monorepo/commit/ff95b7047608ef321888b9b99057a906c5c7a172))

## [0.20.0](https://github.com/terminal-use/monorepo/compare/python-sdk-v0.19.0...python-sdk-v0.20.0) (2026-02-01)


### Features

* **api:** add TaskStream event types to tasks endpoint ([10ef53d](https://github.com/terminal-use/monorepo/commit/10ef53d1cbd0b05e508252b39ff12c4b507ad3e6))
* **cli:** add real-time log streaming with -f/--follow flag ([#30](https://github.com/terminal-use/monorepo/issues/30)) ([f8942b0](https://github.com/terminal-use/monorepo/commit/f8942b0a3ca0a5be42855ca05258f4841980d4f3))
* **cli:** Add tu logs command and fix SDK HTTPS validation ([#13](https://github.com/terminal-use/monorepo/issues/13)) ([589a9a4](https://github.com/terminal-use/monorepo/commit/589a9a479ce7b98dc892fc2c9097e99611181a75))
* **cli:** comprehensive UX improvements for tu CLI ([#20](https://github.com/terminal-use/monorepo/issues/20)) ([f7e4a9a](https://github.com/terminal-use/monorepo/commit/f7e4a9adcab457a104f74d7e2a52e2d724ccdab3))
* **python-sdk:** pass task_id to tracer for span creation ([#8](https://github.com/terminal-use/monorepo/issues/8)) ([20eb956](https://github.com/terminal-use/monorepo/commit/20eb956648fa0e718cf88745c61ff28cec1f5e98))
* switch Fern to local generation and add TaskStream event types ([02e717d](https://github.com/terminal-use/monorepo/commit/02e717d96a6875981e02c5e9681c181c981f9a69))


### Bug Fixes

* **python-sdk:** correct type annotation in print_task_message_update ([#11](https://github.com/terminal-use/monorepo/issues/11)) ([14b5073](https://github.com/terminal-use/monorepo/commit/14b5073b09e26da48e01e2fd34fb398806c182d9))
* **python-sdk:** Fix CI and add type checking with ty ([28aee9f](https://github.com/terminal-use/monorepo/commit/28aee9fc99dca061c44403d5e8bd6d84b27179a2))
* **python-sdk:** Fix CI and add type checking with ty ([5bd7263](https://github.com/terminal-use/monorepo/commit/5bd7263b31d284d9c6b15db14ed9bf640fd87995))
* **python-sdk:** resolve mypy type errors and runtime bugs ([83513f4](https://github.com/terminal-use/monorepo/commit/83513f4b66d80e18375ee72e42894c6f6935a4d8))
* **python-sdk:** resolve mypy type errors and runtime bugs ([5fbca31](https://github.com/terminal-use/monorepo/commit/5fbca313ca50feafc0c4185196b3310506c48334))
* use TaskStreamEvent types for SSE stream handling ([8f7b885](https://github.com/terminal-use/monorepo/commit/8f7b8855bfa7c4cad4f483610448a0aa5312b75f))
* use TaskStreamEvent types for SSE stream handling ([f35eb23](https://github.com/terminal-use/monorepo/commit/f35eb23ec8ff4f5b81601f73118eefb04c6f95ad))
