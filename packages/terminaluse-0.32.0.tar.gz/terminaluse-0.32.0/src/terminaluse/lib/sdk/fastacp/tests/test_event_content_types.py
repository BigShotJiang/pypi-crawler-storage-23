"""Tests for EventContent types (TextPart | DataPart).

These tests verify that the simplified Events API types work correctly:
- TextPart for text content
- DataPart for structured data content
- EventContent union type

The Events API now uses these simpler types instead of TaskMessageContent.
"""

from terminaluse.types import DataPart, TextPart


class TestTextPart:
    """Tests for TextPart event content type."""

    def test_text_part_creation(self):
        """TextPart can be created with text field."""
        content = TextPart(text="Hello world")
        assert content.text == "Hello world"

    def test_text_part_has_type_field(self):
        """TextPart has optional type field."""
        content = TextPart(text="Test message")
        # Type is optional in SDK (defaults to None)
        assert hasattr(content, "type")

    def test_text_part_with_explicit_type(self):
        """TextPart accepts explicit type discriminator."""
        content = TextPart(text="Test message", type="text")
        assert content.type == "text"

    def test_text_part_serialization(self):
        """TextPart serializes to dict with correct fields."""
        content = TextPart(text="Serialization test", type="text")
        data = content.model_dump()
        assert data["text"] == "Serialization test"
        assert data["type"] == "text"

    def test_text_part_empty_text(self):
        """TextPart accepts empty string."""
        content = TextPart(text="")
        assert content.text == ""

    def test_text_part_unicode(self):
        """TextPart handles unicode text correctly."""
        unicode_text = "Hello 世界 🌍 مرحبا"
        content = TextPart(text=unicode_text)
        assert content.text == unicode_text

    def test_text_part_multiline(self):
        """TextPart handles multiline text."""
        multiline = "Line 1\nLine 2\nLine 3"
        content = TextPart(text=multiline)
        assert content.text == multiline


class TestDataPart:
    """Tests for DataPart event content type."""

    def test_data_part_creation_with_dict(self):
        """DataPart can be created with dict data."""
        content = DataPart(data={"key": "value"})
        assert content.data == {"key": "value"}

    def test_data_part_has_type_field(self):
        """DataPart has optional type field."""
        content = DataPart(data={"status": "ready"})
        # Type is optional in SDK (defaults to None)
        assert hasattr(content, "type")

    def test_data_part_with_explicit_type(self):
        """DataPart accepts explicit type discriminator."""
        content = DataPart(data={"status": "ready"}, type="data")
        assert content.type == "data"

    def test_data_part_serialization(self):
        """DataPart serializes to dict with correct fields."""
        content = DataPart(data={"nested": {"key": "value"}}, type="data")
        data = content.model_dump()
        assert data["data"] == {"nested": {"key": "value"}}
        assert data["type"] == "data"

    def test_data_part_with_list(self):
        """DataPart accepts list as data."""
        content = DataPart(data=[1, 2, 3, "four"])
        assert content.data == [1, 2, 3, "four"]

    def test_data_part_with_nested_structure(self):
        """DataPart handles nested data structures."""
        nested_data = {
            "users": [
                {"name": "Alice", "age": 30},
                {"name": "Bob", "age": 25},
            ],
            "metadata": {"count": 2},
        }
        content = DataPart(data=nested_data)
        assert content.data == nested_data

    def test_data_part_with_none_value(self):
        """DataPart accepts None as a valid value."""
        content = DataPart(data=None)
        assert content.data is None


class TestEventContentUnion:
    """Tests for EventContent union type behavior."""

    def test_text_part_is_valid_event_content(self):
        """TextPart is a valid EventContent type."""
        from terminaluse.types.event_content import EventContent

        content: EventContent = TextPart(text="Hello")
        assert isinstance(content, TextPart)

    def test_data_part_is_valid_event_content(self):
        """DataPart is a valid EventContent type."""
        from terminaluse.types.event_content import EventContent

        content: EventContent = DataPart(data={"key": "value"})
        assert isinstance(content, DataPart)

    def test_event_content_type_checking(self):
        """EventContent can be type-checked at runtime."""
        text_content = TextPart(text="Hello")
        data_content = DataPart(data={"key": "value"})

        assert isinstance(text_content, TextPart)
        assert not isinstance(text_content, DataPart)

        assert isinstance(data_content, DataPart)
        assert not isinstance(data_content, TextPart)


class TestEventContentBackwardsCompatibility:
    """Tests to verify EventContent doesn't have old TaskMessageContent fields."""

    def test_text_part_does_not_have_author_field(self):
        """TextPart should NOT have 'author' field (old TaskMessageContent format)."""
        content = TextPart(text="Test")
        assert not hasattr(content, "author") or "author" not in content.model_fields

    def test_text_part_does_not_have_content_field(self):
        """TextPart should NOT have 'content' field (old TaskMessageContent format).

        The field is now called 'text', not 'content'.
        """
        content = TextPart(text="Test")
        # TextPart uses 'text' field, not 'content'
        assert hasattr(content, "text")
        # The old 'content' field should not exist as a primary field
        assert "content" not in TextPart.model_fields

    def test_data_part_does_not_have_author_field(self):
        """DataPart should NOT have 'author' field (old TaskMessageContent format)."""
        content = DataPart(data={"key": "value"})
        assert not hasattr(content, "author") or "author" not in content.model_fields
