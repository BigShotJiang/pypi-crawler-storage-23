What does he care about?
- [ ] Removing complexity
    - What are the most complex pieces?
        - Warm pooling
        - Permissioning
        - Streaming messages
- [x] Easy update of claude agent sdk
- [v0] TS SDK
- [?] Sandbox lifecycle
    - Startup time
    - How long it stays alive

- top left corner has workspace picker
- left-hand sidebar has tabs
    - agents
        - click on agent
    - files
- 

- 1 workspace ("supply chain org") exists by default
    - agents tab in this workspace has 2 agents by default
    - files
        - view files
    
- supporting flows
    - can create new workspace

- blockers
    - UI glitches
    - need config in message send
    - need 