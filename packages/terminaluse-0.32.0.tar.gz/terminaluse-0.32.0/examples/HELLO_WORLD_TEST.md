# Hello World Agent Manual Test Guide

This guide walks through deploying and testing the Claude Agent SDK hello_world example, which requires setting environment variables after deployment.

## Prerequisites

- CLI authenticated (`tu login`)
- `ANTHROPIC_API_KEY` available (for the Claude Agent SDK)
- Agent deployed to `test` namespace

## Overview

The hello_world agent uses the Claude Agent SDK to power an intelligent assistant that can:
- Have multi-turn conversations
- Read/write files in `/workspace`
- Run bash commands
- Maintain session context

Unlike simpler agents, this one requires `ANTHROPIC_API_KEY` to be configured after deployment.

---

## Test 1: Initial Deploy

```bash
cd examples/hello_world

# Deploy the agent
tu deploy
```

**Expected:** Deployment succeeds. Agent is deployed but won't work until env vars are configured.

**Note the output:**
- Agent name: `test/hello-world`
- Branch: main

---

## Test 2: Check Current Environment Variables

```bash
# List current env vars (should be empty)
tu env ls
```

**Expected:** No environment variables found, or empty list.

---

## Test 3: Add ANTHROPIC_API_KEY

```bash
# Add the API key as a secret
tu env add ANTHROPIC_API_KEY --secret -e all --redeploy

# When prompted, paste your Anthropic API key
```

Or non-interactively:
```bash
tu env add ANTHROPIC_API_KEY --value "sk-ant-xxx" --secret -e all --redeploy
```

**Expected:**
- Key added to both production and preview environments
- Marked as secret (encrypted, write-only)
- Redeploy triggered automatically

---

## Test 4: Verify Environment Variable

```bash
# List env vars to confirm
tu env ls
```

**Expected:** Shows `ANTHROPIC_API_KEY` with checkmarks for both PROD and PREVIEW columns.

```
┏━━━━━━━━━━━━━━━━━━━━━┳━━━━━━┳━━━━━━━━━┓
┃ NAME                ┃ PROD ┃ PREVIEW ┃
┡━━━━━━━━━━━━━━━━━━━━━╇━━━━━━╇━━━━━━━━━┩
│ ANTHROPIC_API_KEY   │  ✓   │    ✓    │
└─────────────────────┴──────┴─────────┘
```

---

## Test 5: Create a Project

```bash
# Create a project for testing
tu projects create --namespace test --name "hello-world-test"

# Note the project ID
```

**Expected:** Project created successfully.

---

## Test 6: Basic Conversation Test

```bash
# Create a task and send a message
tu tasks create --project <project_id> -m "Hello! What can you help me with?"

# Note the task ID
```

**Expected:** Agent responds with a greeting explaining its capabilities (file operations, commands, etc.)

---

## Test 7: Multi-Turn Conversation

```bash
# Continue the conversation
tu tasks send <task_id> -m "Create a file called test.txt with 'Hello World' inside it"
```

**Expected:** Agent creates the file and confirms.

```bash
# Verify file creation
tu tasks send <task_id> -m "What files are in /workspace?"
```

**Expected:** Agent lists files including `test.txt`.

```bash
# Read the file
tu tasks send <task_id> -m "Read the contents of test.txt"
```

**Expected:** Agent reads and reports "Hello World".

---

## Test 8: Session Persistence

```bash
# Ask about previous context
tu tasks send <task_id> -m "What was the first thing I asked you to do?"
```

**Expected:** Agent recalls the file creation request, demonstrating session persistence.

---

## Test 9: Bash Command Execution

```bash
# Test command execution
tu tasks send <task_id> -m "Run 'echo $HOSTNAME' and tell me the result"
```

**Expected:** Agent executes the bash command and reports the hostname.

---

## Test 10: New Task (Fresh Session)

```bash
# Create a new task to test fresh session
tu tasks create --project <project_id> -m "What files have I created?"
```

**Expected:** Agent won't know about files from previous session (new task = new session).

---

## Test 11: Update Environment Variable

```bash
# Update an existing variable
tu env add SOME_CONFIG --value "test-value" -e prod --no-redeploy

# List to verify
tu env ls --show
```

**Expected:** Shows the new variable with its value (non-secret).

---

## Test 12: Remove Environment Variable

```bash
# Remove the test variable
tu env rm SOME_CONFIG -e prod --no-redeploy
```

**Expected:** Variable removed from production environment.

---

## Test 13: Import from .env File

Create a test .env file:
```bash
cat > /tmp/test.env << 'EOF'
MY_VAR=hello
DEBUG_MODE=true
EOF
```

```bash
# Import variables
tu env import /tmp/test.env -e preview --no-redeploy

# Verify
tu env ls
```

**Expected:** Both `MY_VAR` and `DEBUG_MODE` appear in preview.

---

## Test 14: Pull Environment to Local File

```bash
# Pull preview env vars to a local file
tu env pull .env.test -e preview
```

**Expected:** Creates `.env.test` file with environment variables.

---

## Cleanup

```bash
# Remove test variables
tu env rm MY_VAR --all --no-redeploy
tu env rm DEBUG_MODE --all --no-redeploy
tu env rm SOME_CONFIG --all --no-redeploy

# Keep ANTHROPIC_API_KEY for future testing
```

---

## Summary of Commands

| Command | Purpose |
|---------|---------|
| `tu deploy` | Deploy the agent |
| `tu env ls` | List all environment variables |
| `tu env add KEY --value "val" -e ENV` | Add/update a variable |
| `tu env add KEY --secret -e all` | Add a secret variable |
| `tu env rm KEY -e ENV` | Remove a variable |
| `tu env import FILE -e ENV` | Bulk import from .env file |
| `tu env pull FILE -e ENV` | Export to local .env file |
| `tu tasks create -m "msg"` | Create task and send message |
| `tu tasks send <id> -m "msg"` | Send message to existing task |

---

## Troubleshooting

**Agent not responding?**
- Check that `ANTHROPIC_API_KEY` is set: `tu env ls`
- Verify the agent was redeployed after adding the key
- Check pod logs for errors

**API key rejected?**
- Ensure the key starts with `sk-ant-`
- Verify the key has not expired
- Check Anthropic dashboard for usage limits

**Session not persisting?**
- Each task has its own session
- Session is stored in task state
- Creating a new task starts a fresh session

**File operations failing?**
- Agent works in `/workspace` directory
- Check available disk space
- Verify file permissions
