"""Codex SDK Hello World.

This agent uses OpenAI Agents `codex_tool` and forwards Codex thread events
to TerminalUse raw events.
"""

from __future__ import annotations

import os
from typing import Any

from agents import Agent, ModelSettings, Runner
from agents.extensions.experimental.codex import (
    CodexToolStreamEvent,
    ThreadOptions,
    codex_tool,
)
from agents.extensions.experimental.codex.events import (
    ThreadError,
    ThreadEvent,
    ThreadStartedEvent,
    TurnFailedEvent,
)
from terminaluse.lib import (
    AgentServer,
    TaskContext,
    make_logger,
)
from terminaluse.types import Event, TextPart

logger = make_logger(__name__)

# Create an agent server
server = AgentServer()


@server.on_create
async def handle_create(ctx: TaskContext, params: dict[str, Any]):
    """Handle task creation."""
    # Persist Codex thread id so subsequent turns can resume.
    await ctx.state.create(
        state={
            "thread_id": None,
        },
    )


@server.on_event
async def handle_event(ctx: TaskContext, event: Event):
    """Handle incoming user messages and route them to Codex."""
    os.environ.setdefault("CODEX_HOME", "/root/.codex")

    state = await ctx.state.get()
    thread_id = state.get("thread_id") if state else None
    if not isinstance(thread_id, str):
        thread_id = None
    resolved_thread_id = thread_id

    async def _on_codex_stream(payload: CodexToolStreamEvent) -> None:
        nonlocal resolved_thread_id
        thread_event: ThreadEvent = payload.event
        await ctx.messages.send(thread_event)
        if isinstance(thread_event, ThreadStartedEvent):
            resolved_thread_id = thread_event.thread_id

    if not isinstance(event.content, TextPart):
        await ctx.messages.send(
            TurnFailedEvent(
                error=ThreadError(message="Unsupported message type. Only text messages are supported."),
            )
        )
        return

    user_message = event.content.text

    try:
        codex_agent = Agent(
            name="Codex Runtime Agent",
            instructions=(
                "For every user request, call the codex tool exactly once using the user request "
                "as a text input. Keep your final response concise."
            ),
            model_settings=ModelSettings(tool_choice="required"),
            tools=[
                codex_tool(
                    thread_id=thread_id,
                    default_thread_options=ThreadOptions(
                        working_directory="/workspace",
                        skip_git_repo_check=True,
                        sandbox_mode="danger-full-access",
                        approval_policy="never",
                    ),
                    on_stream=_on_codex_stream,
                    failure_error_function=None,
                )
            ],
        )

        await Runner.run(codex_agent, user_message)

    except Exception as e:
        await ctx.messages.send(
            TurnFailedEvent(
                error=ThreadError(message=str(e)),
            )
        )
    finally:
        if isinstance(resolved_thread_id, str) and resolved_thread_id and resolved_thread_id != thread_id:
            await ctx.state.update({"thread_id": resolved_thread_id})


@server.on_cancel
async def handle_cancel(ctx: TaskContext):
    """Handle task cancellation."""
    logger.info(f"Task cancelled: {ctx.task.id}")
