from __future__ import annotations

from typing import Any

from terminaluse.lib.sdk.agent_server import AgentServer
from terminaluse.lib.types.task_context import TaskContext
from terminaluse.lib.utils.logging import make_logger
from terminaluse.types.event import Event

logger = make_logger(__name__)


# Create an agent server
# This sets up the core server that handles task creation, events, and cancellation
server = AgentServer()


@server.on_event
async def handle_event(ctx: TaskContext, event: Event):
    """Handle incoming messages from users.

    This is where you implement your main agent logic.
    """
    logger.info(f"Received event for task {ctx.task.id}: {event.content}")

    # Echo back the user's message
    await ctx.messages.send(event.content)

    # Send a response
    await ctx.messages.send("Hello! I've received your message. Edit this handler to add your agent logic.")


@server.on_cancel
async def handle_cancel(ctx: TaskContext):
    """Handle task cancellation.

    Clean up any resources or state when a task is cancelled.
    """
    logger.info(f"Task cancelled: {ctx.task.id}")


@server.on_create
async def handle_create(ctx: TaskContext, params: dict[str, Any]):
    """Handle task creation.

    Initialize any state or resources needed for the task.
    """
    logger.info(f"Task created: {ctx.task.id}")
