"""Staff Review & Decision Assistant."""

__version__ = "0.1.0"
