"""Shared pytest fixtures."""

from __future__ import annotations
