## Description

<!-- Briefly describe what this PR does -->

## Type of Change

- [ ] Bug fix (non-breaking change which fixes an issue)
- [ ] New feature (non-breaking change which adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] Documentation update
- [ ] Content pack addition/update
- [ ] CI/CD or tooling change

## Changes Made

<!-- List the specific changes or provide more details -->

-
-

## Testing

<!-- Describe how you tested these changes -->

- [ ] Tests pass locally (`make test`)
- [ ] Linting passes (`make lint`)
- [ ] Formatting is correct (`make format-check`)
- [ ] Tested manually with: <!-- specify LLM backend and command -->

## Related Issues

<!-- Link any related issues: Closes #123, Fixes #456 -->

## Checklist

- [ ] My code follows the project's style guidelines
- [ ] I have performed a self-review of my code
- [ ] I have commented my code, particularly in hard-to-understand areas
- [ ] I have made corresponding changes to the documentation
- [ ] My changes generate no new warnings or errors
- [ ] I have added tests that prove my fix is effective or that my feature works
- [ ] New and existing tests pass locally with my changes

## Additional Notes

<!-- Any additional information, context, or screenshots -->
