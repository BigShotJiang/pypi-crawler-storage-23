"""Tests for custom parsers."""
