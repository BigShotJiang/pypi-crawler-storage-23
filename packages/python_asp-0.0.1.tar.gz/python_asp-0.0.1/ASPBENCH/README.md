# ASP-Bench Supplementary Materials

Benchmark and experimental data for "ASP-Bench: From Natural Language to Logic Programs".

## Requirements

- Python 3.10+
- [uv](https://docs.astral.sh/uv/) (recommended) or clingo (`pip install clingo`)

## Contents

### `problems/`

128 benchmark problems (64 easy + 64 hard):

- `NN_problem_name_{easy|hard}.md` - Problem description with embedded instance data
- `NN_problem_name_{easy|hard}_ground_truth.py` - Validator script

### `solutions/`

128 example solutions (64 easy + 64 hard):

- `NN_problem_name_{easy|hard}_solution.py` - Reference solution

## Validation

Validate all problems and solutions with a single command:

```bash
uv run validate.py
```

This automatically installs dependencies and validates all 128 solutions against their ground truth.

### Manual validation

```bash
python3 solutions/easy/01_who_is_the_killer_easy_solution.py | \
  python3 problems/easy/01_who_is_the_killer_easy_ground_truth.py
```

Expected output: `{"valid": true, ...}`

## License

Licensed under Apache 2.0.
