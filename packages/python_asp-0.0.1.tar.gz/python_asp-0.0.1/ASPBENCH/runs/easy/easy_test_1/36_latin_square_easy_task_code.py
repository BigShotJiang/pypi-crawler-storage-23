import clingo
import json


def solve_latin_square():
    ctl = clingo.Control(["1"])
    
    program = """
    row(1..5).
    col(1..5).
    value(1..5).
    
    given(1, 1, 1).
    given(2, 3, 3).
    given(3, 4, 4).
    given(4, 5, 5).
    given(5, 2, 2).
    
    1 { cell(R, C, V) : value(V) } 1 :- row(R), col(C).
    
    :- cell(R, C, V1), given(R, C, V2), V1 != V2.
    
    :- row(R), value(V), #count { C : cell(R, C, V) } != 1.
    
    :- col(C), value(V), #count { R : cell(R, C, V) } != 1.
    """
    
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution_grid = None
    
    def on_model(model):
        nonlocal solution_grid
        solution_grid = [[0 for _ in range(5)] for _ in range(5)]
        
        for atom in model.symbols(atoms=True):
            if atom.name == "cell" and len(atom.arguments) == 3:
                row = atom.arguments[0].number
                col = atom.arguments[1].number
                val = atom.arguments[2].number
                solution_grid[row-1][col-1] = val
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable and solution_grid is not None:
        output = {
            "grid": solution_grid,
            "solved": True
        }
    else:
        output = {
            "error": "No solution exists",
            "solved": False
        }
    
    return output


solution = solve_latin_square()
print(json.dumps(solution))
