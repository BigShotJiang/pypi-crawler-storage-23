import clingo
import json

def create_asp_program():
    program = """
    person("Alice"; "Bob"; "Carol"; "Dave").
    color("Red"; "Blue"; "Green"; "Yellow").
    pet("Cat"; "Dog"; "Bird"; "Fish").
    house(1; 2; 3; 4).
    
    1 { has_color(P, C) : color(C) } 1 :- person(P).
    1 { has_pet(P, Pet) : pet(Pet) } 1 :- person(P).
    1 { lives_in(P, H) : house(H) } 1 :- person(P).
    
    1 { has_color(P, C) : person(P) } 1 :- color(C).
    1 { has_pet(P, Pet) : person(P) } 1 :- pet(Pet).
    1 { lives_in(P, H) : person(P) } 1 :- house(H).
    
    :- not lives_in("Alice", 1).
    :- has_color(P, "Red"), not lives_in(P, 2).
    :- not has_pet("Bob", "Cat").
    :- not has_color("Carol", "Blue").
    :- has_color(P, "Yellow"), not has_pet(P, "Fish").
    :- has_color(P, "Green"), not lives_in(P, 4).
    :- not has_pet("Dave", "Dog").
    :- has_pet("Alice", "Bird").
    """
    return program

def solve_puzzle():
    ctl = clingo.Control(["1"])
    
    program = create_asp_program()
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution = None
    
    def on_model(model):
        nonlocal solution
        solution = {"assignments": []}
        
        atoms = model.symbols(atoms=True)
        person_data = {}
        
        for atom in atoms:
            if atom.match("has_color", 2):
                person = str(atom.arguments[0]).strip('"')
                color = str(atom.arguments[1]).strip('"')
                if person not in person_data:
                    person_data[person] = {}
                person_data[person]["color"] = color
            
            elif atom.match("has_pet", 2):
                person = str(atom.arguments[0]).strip('"')
                pet = str(atom.arguments[1]).strip('"')
                if person not in person_data:
                    person_data[person] = {}
                person_data[person]["pet"] = pet
            
            elif atom.match("lives_in", 2):
                person = str(atom.arguments[0]).strip('"')
                house = int(str(atom.arguments[1]))
                if person not in person_data:
                    person_data[person] = {}
                person_data[person]["house"] = house
        
        for person, data in person_data.items():
            assignment = {
                "person": person,
                "color": data.get("color", ""),
                "pet": data.get("pet", ""),
                "house": data.get("house", 0)
            }
            solution["assignments"].append(assignment)
        
        solution["assignments"].sort(key=lambda x: x["house"])
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution
    else:
        return {"error": "No solution exists", 
                "reason": "Constraints are unsatisfiable"}

solution = solve_puzzle()
print(json.dumps(solution, indent=2))
