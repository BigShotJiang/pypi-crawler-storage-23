import clingo
import json

def create_asp_program():
    program = """
    vertex(1..6).
    
    edge(1,2). edge(2,1).
    edge(1,3). edge(3,1).
    edge(2,3). edge(3,2).
    edge(2,4). edge(4,2).
    edge(3,4). edge(4,3).
    edge(3,5). edge(5,3).
    edge(4,5). edge(5,4).
    edge(4,6). edge(6,4).
    edge(5,6). edge(6,5).
    
    color(1..3).
    
    1 { colored(V, C) : color(C) } 1 :- vertex(V).
    
    :- edge(V1, V2), colored(V1, C), colored(V2, C).
    
    used_color(C) :- colored(_, C).
    """
    return program

ctl = clingo.Control(["1"])
ctl.add("base", [], create_asp_program())
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    
    coloring = []
    used_colors = set()
    
    for atom in model.symbols(atoms=True):
        if atom.name == "colored" and len(atom.arguments) == 2:
            vertex = atom.arguments[0].number
            color = atom.arguments[1].number
            coloring.append({"vertex": vertex, "color": color})
            used_colors.add(color)
    
    coloring.sort(key=lambda x: x["vertex"])
    
    solution_data = {
        "num_colors": len(used_colors),
        "coloring": coloring
    }

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    print(json.dumps(solution_data))
else:
    print(json.dumps({"error": "No solution exists", 
                      "reason": "Graph coloring constraints cannot be satisfied"}))
