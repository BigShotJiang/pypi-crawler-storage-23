import clingo
import json


def solve_max_flow():
    ctl = clingo.Control(["1"])
    
    program = """
    node(1;2;3;4;5;6).
    source(1).
    sink(6).
    
    edge(1, 2, 10).
    edge(1, 3, 8).
    edge(2, 3, 5).
    edge(2, 4, 7).
    edge(3, 4, 3).
    edge(3, 5, 9).
    edge(4, 6, 8).
    edge(5, 6, 6).
    
    intermediate(N) :- node(N), not source(N), not sink(N).
    
    1 { flow(From, To, F) : F = 0..Cap } 1 :- edge(From, To, Cap).
    
    :- flow(From, To, F), edge(From, To, Cap), F > Cap.
    
    incoming(N, Sum) :- intermediate(N), 
                        Sum = #sum { F,From : flow(From, N, F) }.
    outgoing(N, Sum) :- intermediate(N), 
                        Sum = #sum { F,To : flow(N, To, F) }.
    :- intermediate(N), incoming(N, In), outgoing(N, Out), In != Out.
    
    total_flow(Total) :- Total = #sum { F,To : flow(1, To, F) }.
    
    :- total_flow(Total), Total < 14.
    
    #show flow/3.
    #show total_flow/1.
    """
    
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution = None
    
    def on_model(m):
        nonlocal solution
        atoms = m.symbols(atoms=True)
        
        flows = []
        max_flow = 0
        
        for atom in atoms:
            if atom.name == "flow" and len(atom.arguments) == 3:
                from_node = atom.arguments[0].number
                to_node = atom.arguments[1].number
                flow_amount = atom.arguments[2].number
                flows.append({
                    "from": from_node,
                    "to": to_node,
                    "flow": flow_amount
                })
            elif atom.name == "total_flow" and len(atom.arguments) == 1:
                max_flow = atom.arguments[0].number
        
        flows.sort(key=lambda x: (x["from"], x["to"]))
        
        solution = {
            "max_flow": max_flow,
            "flows": flows
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution
    else:
        return {
            "error": "No solution exists",
            "reason": "Problem is unsatisfiable"
        }


if __name__ == "__main__":
    result = solve_max_flow()
    print(json.dumps(result, indent=2))
