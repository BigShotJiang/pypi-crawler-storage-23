import clingo
import json

def create_asp_program():
    program = """
    item(1, 4).
    item(2, 6).
    item(3, 2).
    item(4, 3).
    item(5, 7).
    item(6, 1).
    item(7, 5).
    item(8, 2).
    item(9, 4).
    
    capacity(10).
    bin(1..9).
    
    1 { assigned(I, B) : bin(B) } 1 :- item(I, _).
    
    used(B) :- assigned(_, B).
    
    :- bin(B), #sum { S,I : assigned(I, B), item(I, S) } > C, capacity(C).
    
    :- #count { B : used(B) } > 4.
    
    #show assigned/2.
    #show used/1.
    """
    return program

def solve_bin_packing():
    ctl = clingo.Control(["1"])
    
    program = create_asp_program()
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution_data = None
    
    def on_model(model):
        nonlocal solution_data
        atoms = model.symbols(atoms=True)
        
        assignments = {}
        used_bins = set()
        
        for atom in atoms:
            if atom.name == "assigned" and len(atom.arguments) == 2:
                item_id = atom.arguments[0].number
                bin_id = atom.arguments[1].number
                
                if bin_id not in assignments:
                    assignments[bin_id] = []
                assignments[bin_id].append(item_id)
                used_bins.add(bin_id)
            elif atom.name == "used" and len(atom.arguments) == 1:
                used_bins.add(atom.arguments[0].number)
        
        solution_data = {
            'assignments': assignments,
            'used_bins': sorted(used_bins)
        }
    
    result = ctl.solve(on_model=on_model)
    
    return result, solution_data

def format_solution(solution_data):
    item_sizes = {
        1: 4, 2: 6, 3: 2, 4: 3, 5: 7,
        6: 1, 7: 5, 8: 2, 9: 4
    }
    
    bins = []
    assignments = solution_data['assignments']
    
    bin_mapping = {old_id: new_id for new_id, old_id in 
                   enumerate(solution_data['used_bins'], 1)}
    
    for old_bin_id in solution_data['used_bins']:
        items = sorted(assignments[old_bin_id])
        total_size = sum(item_sizes[item] for item in items)
        
        bins.append({
            "bin_id": bin_mapping[old_bin_id],
            "items": items,
            "total_size": total_size
        })
    
    bins.sort(key=lambda x: x['bin_id'])
    
    output = {
        "bins": bins,
        "num_bins": len(bins),
        "feasible": True
    }
    
    return output

result, solution_data = solve_bin_packing()

if result.satisfiable:
    output = format_solution(solution_data)
    print(json.dumps(output, indent=2))
else:
    print(json.dumps({
        "error": "No solution exists",
        "reason": "Unable to pack items within constraints",
        "feasible": False
    }))
