import clingo
import json


def solve_protein_folding(sequence):
    n = len(sequence)
    ctl = clingo.Control(["1"])
    
    program = f"""
residue(0, "h").
residue(1, "p").
residue(2, "p").
residue(3, "h").
residue(4, "p").
residue(5, "p").
residue(6, "h").
residue(7, "h").

coord(-{n}..{n}).

adjacent(X1, Y1, X2, Y2) :- coord(X1), coord(Y1), coord(X2), coord(Y2),
    |X1 - X2| + |Y1 - Y2| == 1.

1 {{ at(I, X, Y) : coord(X), coord(Y) }} 1 :- residue(I, _).

:- at(I1, X, Y), at(I2, X, Y), I1 != I2.

:- residue(I, _), I < {n-1}, at(I, X1, Y1), at(I+1, X2, Y2),
   not adjacent(X1, Y1, X2, Y2).

hh_contact(I1, I2) :- residue(I1, "h"), residue(I2, "h"),
    I1 < I2, I2 - I1 > 1,
    at(I1, X1, Y1), at(I2, X2, Y2),
    adjacent(X1, Y1, X2, Y2).

:- #count {{ I1, I2 : hh_contact(I1, I2) }} < 3.

#show at/3.
"""
    
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution = None
    
    def on_model(m):
        nonlocal solution
        atoms = m.symbols(atoms=True)
        coords = {}
        for atom in atoms:
            if atom.name == "at" and len(atom.arguments) == 3:
                idx = atom.arguments[0].number
                x = atom.arguments[1].number
                y = atom.arguments[2].number
                coords[idx] = [x, y]
        
        coordinates = [coords[i] for i in range(n)]
        solution = {
            "coordinates": coordinates,
            "sequence": sequence
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution
    else:
        return {"error": "No solution exists", "reason": "UNSAT"}


sequence = "HPPHPPHH"
solution = solve_protein_folding(sequence)
print(json.dumps(solution))
