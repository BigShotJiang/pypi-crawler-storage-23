import clingo
import json

def create_asp_program():
    program = """
% Facts: Grid dimensions
row(0..4).
col(0..4).

% Facts: Words with their properties
word(0, "CODE", 4). word(1, "DATA", 4). word(2, "TECH", 4).
word(3, "CHIP", 4). word(4, "BYTE", 4). word(5, "NET", 3).

% Facts: Directions
direction(h). direction(v).

% Facts: Letter positions in words
letter_in_word(0, 0, "C"). letter_in_word(0, 1, "O"). letter_in_word(0, 2, "D"). letter_in_word(0, 3, "E").
letter_in_word(1, 0, "D"). letter_in_word(1, 1, "A"). letter_in_word(1, 2, "T"). letter_in_word(1, 3, "A").
letter_in_word(2, 0, "T"). letter_in_word(2, 1, "E"). letter_in_word(2, 2, "C"). letter_in_word(2, 3, "H").
letter_in_word(3, 0, "C"). letter_in_word(3, 1, "H"). letter_in_word(3, 2, "I"). letter_in_word(3, 3, "P").
letter_in_word(4, 0, "B"). letter_in_word(4, 1, "Y"). letter_in_word(4, 2, "T"). letter_in_word(4, 3, "E").
letter_in_word(5, 0, "N"). letter_in_word(5, 1, "E"). letter_in_word(5, 2, "T").

% Choice rule: Each word placed exactly once
1 { placed(W, R, C, D) : row(R), col(C), direction(D) } 1 :- word(W, _, _).

% Constraint: Word must fit within grid bounds
:- placed(W, R, C, h), word(W, _, Len), C + Len > 5.
:- placed(W, R, C, v), word(W, _, Len), R + Len > 5.

% Define which grid cells are occupied by which letters
occupies(R, C+Pos, Letter, W) :- 
    placed(W, R, C, h), 
    letter_in_word(W, Pos, Letter),
    col(C+Pos).

occupies(R+Pos, C, Letter, W) :- 
    placed(W, R, C, v), 
    letter_in_word(W, Pos, Letter),
    row(R+Pos).

% Constraint: No conflicts - same cell must have same letter
:- occupies(R, C, L1, W1), occupies(R, C, L2, W2), W1 < W2, L1 != L2.

% Define intersections
intersects(W1, W2) :- occupies(R, C, L, W1), occupies(R, C, L, W2), W1 < W2.

% Require at least 3 intersections for a good crossword
:- #count { W1, W2 : intersects(W1, W2) } < 3.

% Minimize total cells used (encourages more intersections)
#minimize { 1, R, C : occupies(R, C, _, _) }.
"""
    return program

def solve_crossword():
    ctl = clingo.Control(["1"])
    
    program = create_asp_program()
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution_data = None
    
    def on_model(model):
        nonlocal solution_data
        atoms = model.symbols(atoms=True)
        
        placements = []
        occupancy = {}
        
        for atom in atoms:
            if atom.name == "placed" and len(atom.arguments) == 4:
                word_id = atom.arguments[0].number
                row = atom.arguments[1].number
                col = atom.arguments[2].number
                direction = str(atom.arguments[3])
                placements.append({
                    'word_id': word_id,
                    'row': row,
                    'col': col,
                    'direction': direction
                })
            
            if atom.name == "occupies" and len(atom.arguments) == 4:
                row = atom.arguments[0].number
                col = atom.arguments[1].number
                letter = str(atom.arguments[2]).strip('"')
                word_id = atom.arguments[3].number
                
                if (row, col) not in occupancy:
                    occupancy[(row, col)] = []
                occupancy[(row, col)].append({
                    'letter': letter,
                    'word_id': word_id
                })
        
        solution_data = {
            'placements': placements,
            'occupancy': occupancy
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution_data
    else:
        return None

def format_output(solution_data):
    words_data = [
        ("CODE", "Programming instructions"),
        ("DATA", "Information"),
        ("TECH", "Technology short"),
        ("CHIP", "Computer component"),
        ("BYTE", "Data unit"),
        ("NET", "Internet short")
    ]
    
    grid = [[" " for _ in range(5)] for _ in range(5)]
    
    for (row, col), cells in solution_data['occupancy'].items():
        grid[row][col] = cells[0]['letter']
    
    words = []
    for placement in sorted(solution_data['placements'], key=lambda x: x['word_id']):
        word_id = placement['word_id']
        word_text = words_data[word_id][0]
        clue = words_data[word_id][1]
        direction = "horizontal" if placement['direction'] == 'h' else "vertical"
        
        words.append({
            "word": word_text,
            "position": [placement['row'], placement['col']],
            "direction": direction,
            "clue": clue
        })
    
    intersections = []
    
    for (row, col), cells in solution_data['occupancy'].items():
        if len(cells) > 1:
            for i in range(len(cells)):
                for j in range(i + 1, len(cells)):
                    word1_id = cells[i]['word_id']
                    word2_id = cells[j]['word_id']
                    letter = cells[i]['letter']
                    
                    placement1 = next(p for p in solution_data['placements'] if p['word_id'] == word1_id)
                    placement2 = next(p for p in solution_data['placements'] if p['word_id'] == word2_id)
                    
                    if placement1['direction'] == 'h':
                        pos1 = col - placement1['col']
                    else:
                        pos1 = row - placement1['row']
                    
                    if placement2['direction'] == 'h':
                        pos2 = col - placement2['col']
                    else:
                        pos2 = row - placement2['row']
                    
                    intersections.append({
                        "word1": word1_id,
                        "word2": word2_id,
                        "position1": pos1,
                        "position2": pos2,
                        "letter": letter
                    })
    
    output = {
        "grid": grid,
        "words": words,
        "theme": "Technology",
        "intersections": intersections
    }
    
    return output

solution = solve_crossword()

if solution:
    output = format_output(solution)
    print(json.dumps(output, indent=2))
else:
    print(json.dumps({"error": "No solution exists", "reason": "Unable to place all words with required intersections"}))
