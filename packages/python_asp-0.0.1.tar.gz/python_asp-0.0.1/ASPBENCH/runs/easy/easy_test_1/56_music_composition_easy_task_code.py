import clingo
import json

def create_asp_program():
    program = """
    scale_note("C"; "D"; "E"; "F"; "G"; "A"; "B").
    semitone("C", 0).
    semitone("D", 2).
    semitone("E", 4).
    semitone("F", 5).
    semitone("G", 7).
    semitone("A", 9).
    semitone("B", 11).
    
    position(1..8).
    
    1 { note(P, N) : scale_note(N) } 1 :- position(P).
    
    :- not note(1, "C").
    :- not note(8, "C").
    
    interval(P, Diff) :- position(P), P < 8,
        note(P, N1), note(P+1, N2),
        semitone(N1, S1), semitone(N2, S2),
        Diff = S2 - S1.
    
    :- interval(P, Diff), Diff > 4.
    :- interval(P, Diff), Diff < -4.
    
    leap(P) :- interval(P, Diff), Diff > 2.
    leap(P) :- interval(P, Diff), Diff < -2.
    
    direction(P, 1) :- interval(P, Diff), Diff > 0.
    direction(P, -1) :- interval(P, Diff), Diff < 0.
    direction(P, 0) :- interval(P, 0).
    
    direction_change(P) :- position(P), P < 7,
        direction(P, D1), direction(P+1, D2),
        D1 != D2, D1 != 0, D2 != 0.
    
    #show note/2.
    #show interval/2.
    #show leap/1.
    #show direction_change/1.
    """
    return program

def solve_melody():
    ctl = clingo.Control(["1"])
    
    program = create_asp_program()
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution_data = None
    
    def on_model(model):
        nonlocal solution_data
        atoms = model.symbols(atoms=True)
        
        notes = {}
        intervals = {}
        leaps = set()
        direction_changes = set()
        
        for atom in atoms:
            if atom.name == "note" and len(atom.arguments) == 2:
                pos = atom.arguments[0].number
                note_name = str(atom.arguments[1]).strip('"')
                notes[pos] = note_name
            elif atom.name == "interval" and len(atom.arguments) == 2:
                pos = atom.arguments[0].number
                interval_val = atom.arguments[1].number
                intervals[pos] = interval_val
            elif atom.name == "leap" and len(atom.arguments) == 1:
                pos = atom.arguments[0].number
                leaps.add(pos)
            elif atom.name == "direction_change" and len(atom.arguments) == 1:
                pos = atom.arguments[0].number
                direction_changes.add(pos)
        
        solution_data = {
            'notes': notes,
            'intervals': intervals,
            'leaps': leaps,
            'direction_changes': direction_changes
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable and solution_data:
        return solution_data
    else:
        return None

def format_output(solution_data):
    melody = [solution_data['notes'][i] for i in range(1, 9)]
    interval_list = [solution_data['intervals'][i] for i in range(1, 8)]
    leap_count = len(solution_data['leaps'])
    direction_change_count = len(solution_data['direction_changes'])
    final_resolution = melody[-1] == "C"
    
    output = {
        "melody": melody,
        "intervals": interval_list,
        "analysis": {
            "key": "C_major",
            "total_steps": 8,
            "leap_count": leap_count,
            "direction_changes": direction_change_count,
            "final_resolution": final_resolution
        }
    }
    
    return output

solution = solve_melody()

if solution:
    output = format_output(solution)
    print(json.dumps(output, indent=2))
else:
    print(json.dumps({"error": "No solution exists"}))
