import clingo
import json

def solve_robot_puzzle():
    ctl = clingo.Control(["1"])
    
    program = """
    row(0..3).
    col(0..3).
    robot("A").
    robot("B").
    
    at("A", 0, 1, 0).
    at("B", 1, 1, 0).
    
    target("A", 2, 1).
    
    wall(0, 2, right).
    wall(1, 2, right).
    wall(0, 3, left).
    wall(1, 3, left).
    
    max_time(3).
    time(0..2).
    state_time(0..3).
    
    direction(up; down; left; right).
    delta(up, -1, 0).
    delta(down, 1, 0).
    delta(left, 0, -1).
    delta(right, 0, 1).
    
    neighbor(R1, C1, R2, C2, D) :- 
        row(R1), col(C1), row(R2), col(C2),
        direction(D), delta(D, DR, DC),
        R2 = R1 + DR, C2 = C1 + DC.
    
    1 { move(R, FromRow, FromCol, ToRow, ToCol, T) : 
        robot(R), 
        at(R, FromRow, FromCol, T),
        neighbor(FromRow, FromCol, ToRow, ToCol, _)
    } 1 :- time(T).
    
    :- move(R, FromRow, FromCol, ToRow, ToCol, T),
       FromRow = ToRow, FromCol < ToCol,
       wall(FromRow, FromCol, right).
    
    :- move(R, FromRow, FromCol, ToRow, ToCol, T),
       FromRow = ToRow, FromCol > ToCol,
       wall(FromRow, FromCol, left).
    
    :- move(R, FromRow, FromCol, ToRow, ToCol, T),
       FromRow = ToRow, FromCol < ToCol,
       wall(FromRow, ToCol, left).
    
    :- move(R, FromRow, FromCol, ToRow, ToCol, T),
       FromRow = ToRow, FromCol > ToCol,
       wall(FromRow, ToCol, right).
    
    at(R, ToRow, ToCol, T+1) :- move(R, FromRow, FromCol, ToRow, ToCol, T).
    
    at(R, Row, Col, T+1) :- at(R, Row, Col, T), 
                            state_time(T+1),
                            not move(R, Row, Col, _, _, T).
    
    :- at(R, Row1, Col1, T), at(R, Row2, Col2, T), (Row1, Col1) != (Row2, Col2).
    
    :- at(R1, Row, Col, T), at(R2, Row, Col, T), R1 != R2, state_time(T).
    
    :- target("A", Row, Col), not at("A", Row, Col, 3).
    
    #show move/6.
    #show at/4.
    """
    
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution_data = None
    
    def on_model(model):
        nonlocal solution_data
        atoms = model.symbols(atoms=True)
        
        moves = []
        positions_by_time = {}
        
        for atom in atoms:
            if atom.name == "at" and len(atom.arguments) == 4:
                robot = str(atom.arguments[0]).strip('"')
                row = atom.arguments[1].number
                col = atom.arguments[2].number
                time = atom.arguments[3].number
                
                if time not in positions_by_time:
                    positions_by_time[time] = {}
                positions_by_time[time][robot] = [row, col]
            
            elif atom.name == "move" and len(atom.arguments) == 6:
                robot = str(atom.arguments[0]).strip('"')
                from_row = atom.arguments[1].number
                from_col = atom.arguments[2].number
                to_row = atom.arguments[3].number
                to_col = atom.arguments[4].number
                time = atom.arguments[5].number
                
                moves.append({
                    "robot": robot,
                    "from": [from_row, from_col],
                    "to": [to_row, to_col],
                    "time": time
                })
        
        moves.sort(key=lambda x: x["time"])
        
        for move in moves:
            del move["time"]
        
        final_positions = positions_by_time.get(3, {})
        
        solution_data = {
            "solution_found": True,
            "moves": len(moves),
            "sequence": moves,
            "final_positions": final_positions
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution_data
    else:
        return {
            "solution_found": False,
            "error": "No solution exists",
            "reason": "Could not find a valid path to the target in 3 moves"
        }

solution = solve_robot_puzzle()
print(json.dumps(solution, indent=2))
