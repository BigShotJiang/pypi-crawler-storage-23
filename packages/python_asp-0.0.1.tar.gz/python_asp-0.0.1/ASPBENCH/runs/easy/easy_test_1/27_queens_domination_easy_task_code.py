import clingo
import json

asp_program = """
row(0..7).
col(0..7).
cell(R, C) :- row(R), col(C).

{ queen(R, C) : cell(R, C) }.

dominated(R, C) :- queen(R, C).
dominated(R, C) :- queen(R, C2), cell(R, C), C != C2.
dominated(R, C) :- queen(R2, C), cell(R, C), R != R2.
dominated(R, C) :- queen(R2, C2), cell(R, C), R - C == R2 - C2, 
                   (R, C) != (R2, C2).
dominated(R, C) :- queen(R2, C2), cell(R, C), R + C == R2 + C2, 
                   (R, C) != (R2, C2).

:- cell(R, C), not dominated(R, C).

num_queens(N) :- N = #count { R, C : queen(R, C) }.
:- num_queens(N), N > 5.

#show queen/2.
#show num_queens/1.
"""

def calculate_dominated_squares(queens):
    dominated = set()
    
    for qr, qc in queens:
        for c in range(8):
            dominated.add((qr, c))
        
        for r in range(8):
            dominated.add((r, qc))
        
        diag_const = qr - qc
        for r in range(8):
            c = r - diag_const
            if 0 <= c <= 7:
                dominated.add((r, c))
        
        diag_const = qr + qc
        for r in range(8):
            c = diag_const - r
            if 0 <= c <= 7:
                dominated.add((r, c))
    
    return sorted([[r, c] for r, c in dominated])

ctl = clingo.Control(["1"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    
    queens = []
    num_queens_val = 0
    
    for atom in model.symbols(atoms=True):
        if atom.name == "queen" and len(atom.arguments) == 2:
            r = atom.arguments[0].number
            c = atom.arguments[1].number
            queens.append([r, c])
        elif atom.name == "num_queens" and len(atom.arguments) == 1:
            num_queens_val = atom.arguments[0].number
    
    queens.sort()
    
    solution_data = {
        "queens": queens,
        "num_queens": num_queens_val
    }

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    dominated_squares = calculate_dominated_squares(solution_data["queens"])
    solution_data["dominated_squares"] = dominated_squares
    print(json.dumps(solution_data, indent=2))
else:
    print(json.dumps({"error": "No solution exists", 
                      "reason": "Could not find placement with <= 5 queens"}))
