import clingo
import json
from collections import deque

asp_program = """
% Rooms with their properties
room("room1"). room_type("room1", "entrance"). room_size("room1", "small").
room("room2"). room_type("room2", "chamber"). room_size("room2", "large").
room("room3"). room_type("room3", "corridor"). room_size("room3", "small").
room("room4"). room_type("room4", "chamber"). room_size("room4", "medium").
room("room5"). room_type("room5", "treasury"). room_size("room5", "medium").
room("room6"). room_type("room6", "corridor"). room_size("room6", "small").
room("room7"). room_type("room7", "boss_room"). room_size("room7", "large").

entrance("room1").
exit("room7").

connected("room1", "room2"). connected("room2", "room1").
connected("room1", "room3"). connected("room3", "room1").
connected("room2", "room4"). connected("room4", "room2").
connected("room3", "room5"). connected("room5", "room3").
connected("room4", "room6"). connected("room6", "room4").
connected("room5", "room6"). connected("room6", "room5").
connected("room5", "room7"). connected("room7", "room5").

treasure("treasure1"). treasure_value("treasure1", 100). treasure_rarity("treasure1", "common").
treasure("treasure2"). treasure_value("treasure2", 500). treasure_rarity("treasure2", "rare").
treasure("treasure3"). treasure_value("treasure3", 1000). treasure_rarity("treasure3", "legendary").

monster_type("goblin"). monster_danger("goblin", 2). monster_group_size("goblin", 3).
monster_type("orc"). monster_danger("orc", 4). monster_group_size("orc", 2).
monster_type("dragon"). monster_danger("dragon", 8). monster_group_size("dragon", 1).

rarity_level("common", 1).
rarity_level("rare", 2).
rarity_level("legendary", 3).

1 { treasure_in(T, R) : room(R) } 1 :- treasure(T).

{ monster_count(R, M, Count) : Count = 0..MaxCount } 1 :- 
    room(R), monster_type(M), monster_group_size(M, MaxCount).

room_danger(R, TotalDanger) :- 
    room(R),
    TotalDanger = #sum { Danger * Count, M : monster_count(R, M, Count), monster_danger(M, Danger) }.

:- room_danger(R, D), D > 10.

reachable(R) :- entrance(R).
reachable(R2) :- reachable(R1), connected(R1, R2).

:- room(R), not reachable(R).

:- treasure_in(T1, R1), treasure_in(T2, R2),
   treasure_rarity(T1, Rarity1), treasure_rarity(T2, Rarity2),
   rarity_level(Rarity1, Level1), rarity_level(Rarity2, Level2),
   Level1 > Level2,
   room_danger(R1, D1), room_danger(R2, D2),
   D1 < D2.

#maximize { D, R : room_danger(R, D) }.

total_danger(Total) :- Total = #sum { D, R : room_danger(R, D) }.
"""

ctl = clingo.Control(["0"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

best_solution = None
best_cost = None

def on_model(model):
    global best_solution, best_cost
    
    if model.optimality_proven or model.cost is not None:
        current_cost = model.cost
        
        current_solution = {
            'treasure_placements': [],
            'monster_placements': [],
            'room_dangers': {},
            'total_danger': 0
        }
        
        for atom in model.symbols(atoms=True):
            if atom.name == "treasure_in" and len(atom.arguments) == 2:
                treasure = str(atom.arguments[0]).strip('"')
                room = str(atom.arguments[1]).strip('"')
                current_solution['treasure_placements'].append({
                    'treasure': treasure,
                    'room': room
                })
            
            elif atom.name == "monster_count" and len(atom.arguments) == 3:
                room = str(atom.arguments[0]).strip('"')
                monster = str(atom.arguments[1]).strip('"')
                count = int(str(atom.arguments[2]))
                if count > 0:
                    current_solution['monster_placements'].append({
                        'room': room,
                        'monster': monster,
                        'count': count
                    })
            
            elif atom.name == "room_danger" and len(atom.arguments) == 2:
                room = str(atom.arguments[0]).strip('"')
                danger = int(str(atom.arguments[1]))
                current_solution['room_dangers'][room] = danger
            
            elif atom.name == "total_danger" and len(atom.arguments) == 1:
                current_solution['total_danger'] = int(str(atom.arguments[0]))
        
        if best_cost is None or current_cost < best_cost:
            best_cost = current_cost
            best_solution = current_solution

result = ctl.solve(on_model=on_model)

if result.satisfiable and best_solution:
    solution_data = best_solution
    
    room_data = {
        "room1": {"type": "entrance", "size": "small"},
        "room2": {"type": "chamber", "size": "large"},
        "room3": {"type": "corridor", "size": "small"},
        "room4": {"type": "chamber", "size": "medium"},
        "room5": {"type": "treasury", "size": "medium"},
        "room6": {"type": "corridor", "size": "small"},
        "room7": {"type": "boss_room", "size": "large"}
    }
    
    treasure_data = {
        "treasure1": {"value": 100, "rarity": "common"},
        "treasure2": {"value": 500, "rarity": "rare"},
        "treasure3": {"value": 1000, "rarity": "legendary"}
    }
    
    room_layout = []
    for room_id in sorted(room_data.keys()):
        room_info = {
            "room_id": room_id,
            "monsters": [],
            "treasures": [],
            "danger_level": solution_data['room_dangers'].get(room_id, 0)
        }
        
        for mp in solution_data['monster_placements']:
            if mp['room'] == room_id:
                room_info['monsters'].append({
                    "type": mp['monster'],
                    "count": mp['count']
                })
        
        for tp in solution_data['treasure_placements']:
            if tp['room'] == room_id:
                room_info['treasures'].append(tp['treasure'])
        
        room_layout.append(room_info)
    
    connections = {
        "room1": ["room2", "room3"],
        "room2": ["room1", "room4"],
        "room3": ["room1", "room5"],
        "room4": ["room2", "room6"],
        "room5": ["room3", "room6", "room7"],
        "room6": ["room4", "room5"],
        "room7": ["room5"]
    }
    
    def find_path_bfs(start, end, graph):
        if start == end:
            return [start]
        
        queue = deque([(start, [start])])
        visited = {start}
        
        while queue:
            current, path = queue.popleft()
            
            for neighbor in graph.get(current, []):
                if neighbor in visited:
                    continue
                
                new_path = path + [neighbor]
                
                if neighbor == end:
                    return new_path
                
                visited.add(neighbor)
                queue.append((neighbor, new_path))
        
        return None
    
    entrance = "room1"
    exit_room = "room7"
    main_path = find_path_bfs(entrance, exit_room, connections)
    
    path_danger = sum(solution_data['room_dangers'].get(room, 0) for room in main_path)
    path_treasures = []
    for tp in solution_data['treasure_placements']:
        if tp['room'] in main_path:
            path_treasures.append(tp['treasure'])
    
    all_rooms = set(room_data.keys())
    
    def get_reachable(start, graph):
        visited = {start}
        queue = deque([start])
        
        while queue:
            current = queue.popleft()
            for neighbor in graph.get(current, []):
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)
        
        return visited
    
    reachable_rooms = get_reachable(entrance, connections)
    isolated_rooms = list(all_rooms - reachable_rooms)
    
    treasure_distribution = {"common": 0, "rare": 0, "legendary": 0}
    for tp in solution_data['treasure_placements']:
        treasure_id = tp['treasure']
        rarity = treasure_data[treasure_id]['rarity']
        treasure_distribution[rarity] += 1
    
    total_danger = solution_data['total_danger']
    if total_danger < 20:
        difficulty = "easy"
    elif total_danger < 40:
        difficulty = "balanced"
    elif total_danger < 60:
        difficulty = "hard"
    else:
        difficulty = "extreme"
    
    final_output = {
        "room_layout": room_layout,
        "connectivity": {
            "paths": [
                {
                    "from": entrance,
                    "to": exit_room,
                    "route": main_path,
                    "total_danger": path_danger,
                    "treasures_found": path_treasures
                }
            ],
            "isolated_rooms": isolated_rooms
        },
        "balance_analysis": {
            "total_danger": total_danger,
            "treasure_distribution": treasure_distribution,
            "difficulty_progression": difficulty
        }
    }
    
    print(json.dumps(final_output, indent=2))
else:
    print(json.dumps({"error": "No solution exists", "reason": "Could not satisfy all constraints"}))
