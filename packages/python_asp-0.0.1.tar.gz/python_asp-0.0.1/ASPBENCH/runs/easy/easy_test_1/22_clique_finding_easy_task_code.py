import clingo
import json

vertices = [0, 1, 2, 3, 4, 5, 6]
edges = [
    (0, 1), (0, 2), (0, 3),
    (1, 2), (1, 3), (1, 4),
    (2, 3), (2, 5),
    (3, 4), (3, 5),
    (4, 5), (4, 6),
    (5, 6)
]

def generate_facts():
    facts = []
    for v in vertices:
        facts.append(f'vertex({v}).')
    for u, v in edges:
        if u < v:
            facts.append(f'edge({u}, {v}).')
        else:
            facts.append(f'edge({v}, {u}).')
    return '\n'.join(facts)

asp_program = generate_facts() + """

{ in_clique(V) : vertex(V) }.

:- in_clique(U), in_clique(V), U < V, not edge(U, V).

#maximize { 1, V : in_clique(V) }.
"""

ctl = clingo.Control(["0"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

solution = None

def on_model(model):
    global solution
    clique_vertices = []
    for atom in model.symbols(atoms=True):
        if atom.name == "in_clique" and len(atom.arguments) == 1:
            vertex = atom.arguments[0].number
            clique_vertices.append(vertex)
    clique_vertices.sort()
    clique_edges = []
    for i in range(len(clique_vertices)):
        for j in range(i + 1, len(clique_vertices)):
            u, v = clique_vertices[i], clique_vertices[j]
            if u < v:
                clique_edges.append([u, v])
            else:
                clique_edges.append([v, u])
    clique_edges.sort()
    solution = {
        "clique": clique_vertices,
        "clique_size": len(clique_vertices),
        "clique_edges": clique_edges
    }

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    print(json.dumps(solution))
else:
    print(json.dumps({"error": "No solution exists"}))
