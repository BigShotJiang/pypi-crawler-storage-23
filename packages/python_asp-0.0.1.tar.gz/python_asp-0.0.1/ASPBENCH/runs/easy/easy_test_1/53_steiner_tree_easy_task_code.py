import clingo
import json

asp_program = """
vertex(0). vertex(1). vertex(2). vertex(3). vertex(4). vertex(5). vertex(6).

edge(0, 1, 3). edge(0, 2, 5).
edge(1, 3, 2). edge(1, 4, 4).
edge(2, 3, 1). edge(2, 5, 6).
edge(3, 4, 3). edge(3, 5, 3). edge(3, 6, 2).
edge(4, 5, 2).
edge(5, 6, 4).

terminal(0). terminal(5). terminal(6).

{ in_tree(V1, V2) : edge(V1, V2, _) }.

used_vertex(V) :- in_tree(V, _).
used_vertex(V) :- in_tree(_, V).

:- terminal(T), not used_vertex(T).

reachable(V1, V2) :- in_tree(V1, V2).
reachable(V1, V2) :- in_tree(V2, V1).
reachable(V1, V3) :- reachable(V1, V2), reachable(V2, V3), V1 != V3.

:- terminal(T1), terminal(T2), T1 < T2, not reachable(T1, T2).

num_vertices(N) :- N = #count { V : used_vertex(V) }.
num_edges(N) :- N = #count { V1, V2 : in_tree(V1, V2) }.
:- num_vertices(NV), num_edges(NE), NE != NV - 1.

total_weight(W) :- W = #sum { Weight, V1, V2 : in_tree(V1, V2), edge(V1, V2, Weight) }.

:- total_weight(W), W > 10.
:- total_weight(W), W < 0.
"""

ctl = clingo.Control(["1"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    
    tree_edges = []
    used_vertices = set()
    total_weight = 0
    
    for atom in model.symbols(atoms=True):
        if atom.name == "in_tree" and len(atom.arguments) == 2:
            v1 = atom.arguments[0].number
            v2 = atom.arguments[1].number
            used_vertices.add(v1)
            used_vertices.add(v2)
            
            weight = None
            for check_atom in model.symbols(atoms=True):
                if check_atom.name == "edge" and len(check_atom.arguments) == 3:
                    e1 = check_atom.arguments[0].number
                    e2 = check_atom.arguments[1].number
                    w = check_atom.arguments[2].number
                    if (e1 == v1 and e2 == v2) or (e1 == v2 and e2 == v1):
                        weight = w
                        break
            
            if weight is not None:
                tree_edges.append({"from": v1, "to": v2, "weight": weight})
                total_weight += weight
        
        elif atom.name == "total_weight" and len(atom.arguments) == 1:
            total_weight = atom.arguments[0].number
    
    terminals = [0, 5, 6]
    steiner_vertices = sorted([v for v in used_vertices if v not in terminals])
    connected_components = [{"component": 1, "vertices": sorted(list(used_vertices))}]
    
    solution_data = {
        "total_weight": total_weight,
        "tree_edges": sorted(tree_edges, key=lambda x: (x["from"], x["to"])),
        "steiner_vertices": steiner_vertices,
        "terminals": terminals,
        "connected_components": connected_components
    }

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    print(json.dumps(solution_data, indent=2))
else:
    print(json.dumps({"error": "No solution exists", "reason": "Problem is unsatisfiable"}))
