import clingo
import json

def solve_meeting_schedule():
    ctl = clingo.Control(["1"])
    
    program = """
    meeting(m1; m2; m3; m4; m5).
    day(1..3).
    slot(1..3).
    room(r1; r2).
    person(p1; p2; p3; p4; p5).
    
    attends(m1, p1). attends(m1, p2). attends(m1, p3).
    attends(m2, p1). attends(m2, p5).
    attends(m3, p2). attends(m3, p3).
    attends(m4, p1). attends(m4, p4).
    attends(m5, p1). attends(m5, p2). attends(m5, p3).
    
    prefers(m1, 1, 1).
    prefers(m2, 1, 2).
    prefers(m4, 3, 3).
    
    1 { scheduled(M, D, S, R) : day(D), slot(S), room(R) } 1 :- meeting(M).
    
    :- scheduled(M1, D, S, R1), scheduled(M2, D, S, R2), 
       M1 < M2, attends(M1, P), attends(M2, P).
    
    :- scheduled(M1, D, S, R), scheduled(M2, D, S, R), M1 < M2.
    
    violation(M) :- meeting(M), prefers(M, PD, PS), 
                    scheduled(M, D, S, R), D != PD.
    violation(M) :- meeting(M), prefers(M, PD, PS), 
                    scheduled(M, D, S, R), S != PS.
    
    :- violation(M).
    
    #show scheduled/4.
    #show violation/1.
    """
    
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution_data = None
    
    def on_model(m):
        nonlocal solution_data
        atoms = m.symbols(atoms=True)
        
        schedule = []
        violations = []
        
        for atom in atoms:
            if atom.name == "scheduled" and len(atom.arguments) == 4:
                meeting = str(atom.arguments[0])
                day = atom.arguments[1].number
                slot = atom.arguments[2].number
                room = str(atom.arguments[3])
                
                schedule.append({
                    "meeting": meeting,
                    "day": day,
                    "slot": slot,
                    "room": room
                })
            elif atom.name == "violation" and len(atom.arguments) == 1:
                violations.append(str(atom.arguments[0]))
        
        schedule.sort(key=lambda x: x["meeting"])
        
        solution_data = {
            "schedule": schedule,
            "conflicts": [],
            "preference_violations": len(violations),
            "feasible": True
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution_data
    else:
        return {
            "schedule": [],
            "conflicts": ["No feasible schedule exists"],
            "preference_violations": -1,
            "feasible": False
        }

solution = solve_meeting_schedule()
print(json.dumps(solution, indent=2))
