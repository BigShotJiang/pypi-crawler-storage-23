import clingo
import json

program = """
patient_condition("pain").
patient_condition("hypertension").
patient_condition("diabetes").
patient_contraindication("bleeding_disorder").
max_drugs(3).

drug("drug1"). drug("drug2"). drug("drug3"). drug("drug4"). drug("drug5").

treats("drug1", "pain").
treats("drug1", "inflammation").
treats("drug2", "blood_clot_prevention").
treats("drug3", "hypertension").
treats("drug4", "diabetes").
treats("drug5", "pain").
treats("drug5", "inflammation").

drug_contraindication("drug1", "bleeding_disorder").
drug_contraindication("drug2", "pregnancy").
drug_contraindication("drug3", "kidney_disease").
drug_contraindication("drug4", "kidney_disease").

max_dose("drug1", 4000).
max_dose("drug2", 10).
max_dose("drug3", 40).
max_dose("drug4", 2000).
max_dose("drug5", 2400).

interaction("drug1", "drug2", "increased_bleeding", "moderate").
interaction("drug2", "drug1", "increased_bleeding", "moderate").
interaction("drug3", "drug4", "mild_nausea", "mild").
interaction("drug4", "drug3", "mild_nausea", "mild").
interaction("drug5", "drug3", "reduced_bp_effect", "moderate").
interaction("drug3", "drug5", "reduced_bp_effect", "moderate").

severity_cost("severe", 3).
severity_cost("moderate", 2).
severity_cost("mild", 1).

{ prescribe(D) : drug(D) } N :- max_drugs(N).

:- prescribe(D), drug_contraindication(D, C), patient_contraindication(C).

treated(C) :- patient_condition(C), prescribe(D), treats(D, C).

num_treated(N) :- N = #count { C : treated(C) }.

has_interaction(D1, D2, Type, Severity) :- 
    prescribe(D1), prescribe(D2), D1 < D2,
    interaction(D1, D2, Type, Severity).

total_interaction_cost(Cost) :- 
    Cost = #sum { SevCost, D1, D2 : has_interaction(D1, D2, _, Severity), 
                                     severity_cost(Severity, SevCost) }.

total_interaction_cost(0) :- not has_interaction(_, _, _, _).

#minimize { Cost@2 : total_interaction_cost(Cost) }.
#maximize { N@1 : num_treated(N) }.

#show prescribe/1.
#show treated/1.
#show has_interaction/4.
#show num_treated/1.
#show total_interaction_cost/1.
"""

ctl = clingo.Control(["0"])
ctl.add("base", [], program)
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    
    prescribed = []
    treated_conds = []
    interactions = []
    num_treated_val = 0
    interaction_cost = 0
    
    for atom in model.symbols(atoms=True):
        if atom.name == "prescribe" and len(atom.arguments) == 1:
            drug_id = str(atom.arguments[0]).strip('"')
            prescribed.append(drug_id)
        
        elif atom.name == "treated" and len(atom.arguments) == 1:
            condition = str(atom.arguments[0]).strip('"')
            treated_conds.append(condition)
        
        elif atom.name == "has_interaction" and len(atom.arguments) == 4:
            d1 = str(atom.arguments[0]).strip('"')
            d2 = str(atom.arguments[1]).strip('"')
            int_type = str(atom.arguments[2]).strip('"')
            severity = str(atom.arguments[3]).strip('"')
            interactions.append({
                "drugs": [d1, d2],
                "interaction": int_type,
                "severity": severity
            })
        
        elif atom.name == "num_treated" and len(atom.arguments) == 1:
            num_treated_val = int(str(atom.arguments[0]))
        
        elif atom.name == "total_interaction_cost" and len(atom.arguments) == 1:
            interaction_cost = int(str(atom.arguments[0]))
    
    solution_data = {
        "prescribed": prescribed,
        "treated": treated_conds,
        "interactions": interactions,
        "num_treated": num_treated_val,
        "interaction_cost": interaction_cost
    }

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    drug_info = {
        "drug1": {"max_dose": 4000},
        "drug2": {"max_dose": 10},
        "drug3": {"max_dose": 40},
        "drug4": {"max_dose": 2000},
        "drug5": {"max_dose": 2400}
    }
    
    frequency_map = {
        "drug1": "twice_daily",
        "drug2": "once_daily",
        "drug3": "once_daily",
        "drug4": "twice_daily",
        "drug5": "twice_daily"
    }
    
    all_conditions = ["pain", "hypertension", "diabetes"]
    patient_contraindications = ["bleeding_disorder"]
    
    prescribed_drugs = []
    for drug_id in solution_data['prescribed']:
        dose = drug_info[drug_id]["max_dose"] // 2
        prescribed_drugs.append({
            "drug_id": drug_id,
            "dose": dose,
            "frequency": frequency_map[drug_id]
        })
    
    treated_set = set(solution_data['treated'])
    untreated_conditions = [c for c in all_conditions if c not in treated_set]
    
    total_conditions = len(all_conditions)
    treated_count = len(solution_data['treated'])
    coverage_bonus = (treated_count / total_conditions) * 0.5
    
    severity_penalties = {
        "severe": 0.3,
        "moderate": 0.15,
        "mild": 0.05
    }
    
    total_penalty = 0
    for interaction in solution_data['interactions']:
        severity = interaction['severity']
        total_penalty += severity_penalties.get(severity, 0)
    
    safety_score = 0.5 + coverage_bonus - total_penalty
    safety_score = max(0.0, min(1.0, safety_score))
    
    output = {
        "prescribed_drugs": prescribed_drugs,
        "treated_conditions": solution_data['treated'],
        "untreated_conditions": untreated_conditions,
        "safety_analysis": {
            "interactions_detected": solution_data['interactions'],
            "contraindications_avoided": patient_contraindications,
            "safety_score": round(safety_score, 2)
        }
    }
    
    print(json.dumps(output, indent=2))
else:
    print(json.dumps({"error": "No solution exists", "reason": "No valid prescription found"}))
