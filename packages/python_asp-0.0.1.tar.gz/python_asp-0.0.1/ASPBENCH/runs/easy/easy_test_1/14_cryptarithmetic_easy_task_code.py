import clingo
import json

asp_program = """
letter(s; e; n; d; m; o; r; y).
digit(0..9).

1 { assign(L, D) : digit(D) } 1 :- letter(L).

:- assign(L1, D), assign(L2, D), L1 != L2.

:- assign(s, 0).
:- assign(m, 0).

carry(0..1).

1 { carry0(C) : carry(C) } 1.
1 { carry1(C) : carry(C) } 1.
1 { carry2(C) : carry(C) } 1.
1 { carry3(C) : carry(C) } 1.

:- assign(d, D), assign(e, E), assign(y, Y), carry0(C0),
   D + E != 10*C0 + Y.

:- assign(n, N), assign(r, R), assign(e, E), carry0(C0), carry1(C1),
   N + R + C0 != 10*C1 + E.

:- assign(e, E), assign(o, O), assign(n, N), carry1(C1), carry2(C2),
   E + O + C1 != 10*C2 + N.

:- assign(s, S), assign(m, M), assign(o, O), carry2(C2), carry3(C3),
   S + M + C2 != 10*C3 + O.

:- assign(m, M), carry3(C3), C3 != M.
"""

ctl = clingo.Control(["1"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    solution_data = {}
    
    assignment = {}
    for atom in model.symbols(atoms=True):
        if atom.name == "assign" and len(atom.arguments) == 2:
            letter = str(atom.arguments[0])
            digit = atom.arguments[1].number
            assignment[letter.upper()] = digit
    
    solution_data['assignment'] = assignment

result = ctl.solve(on_model=on_model)

if result.satisfiable and solution_data:
    assignment = solution_data['assignment']
    
    send = (assignment['S'] * 1000 + assignment['E'] * 100 + 
            assignment['N'] * 10 + assignment['D'])
    more = (assignment['M'] * 1000 + assignment['O'] * 100 + 
            assignment['R'] * 10 + assignment['E'])
    money = (assignment['M'] * 10000 + assignment['O'] * 1000 + 
             assignment['N'] * 100 + assignment['E'] * 10 + assignment['Y'])
    
    valid = (send + more == money)
    equation = f"{send} + {more} = {money}"
    
    output = {
        "assignment": assignment,
        "equation": f"SEND + MORE = MONEY becomes {equation}",
        "valid": valid
    }
    
    print(json.dumps(output, indent=2))
else:
    print(json.dumps({"error": "No solution exists", 
                      "reason": "Constraints are unsatisfiable"}))
