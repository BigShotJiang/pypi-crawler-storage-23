import clingo
import json

# Recipe data
recipes_data = {
    "pasta": [
        {"step": "prep", "duration": 10, "resource": "prep_area", "order": 1},
        {"step": "boil", "duration": 15, "resource": "stove", "order": 2},
        {"step": "serve", "duration": 5, "resource": "prep_area", "order": 3}
    ],
    "salad": [
        {"step": "chop", "duration": 15, "resource": "prep_area", "order": 1},
        {"step": "mix", "duration": 5, "resource": "prep_area", "order": 2}
    ],
    "bread": [
        {"step": "bake", "duration": 30, "resource": "oven", "order": 1}
    ]
}

resources = ["oven", "stove", "prep_area"]

def generate_asp_facts():
    """Generate ASP facts from problem data"""
    facts = []
    
    for recipe_name in recipes_data.keys():
        facts.append(f'recipe("{recipe_name}").')
    
    for res in resources:
        facts.append(f'resource("{res}").')
    
    for recipe_name, steps in recipes_data.items():
        for step_info in steps:
            facts.append(f'step("{recipe_name}", "{step_info["step"]}", '
                        f'{step_info["duration"]}, "{step_info["resource"]}", '
                        f'{step_info["order"]}).')
    
    return "\n".join(facts)

def build_asp_program():
    """Build the complete ASP program for recipe scheduling"""
    
    asp_facts = generate_asp_facts()
    program = asp_facts + "\n\n"
    
    program += """
#const max_horizon = 35.
time(0..max_horizon).

1 { start_time(R, S, T) : time(T) } 1 :- step(R, S, _, _, _).

end_time(R, S, T_end) :- start_time(R, S, T_start), 
                         step(R, S, Dur, _, _), 
                         T_end = T_start + Dur.

:- end_time(R, S, T), T > max_horizon.

:- step(R, S1, _, _, O1), step(R, S2, _, _, O2), O1 < O2,
   end_time(R, S1, T1), start_time(R, S2, T2), T1 > T2.

:- step(R1, S1, _, Res, _), step(R2, S2, _, Res, _), (R1, S1) != (R2, S2),
   start_time(R1, S1, ST1), end_time(R1, S1, ET1),
   start_time(R2, S2, ST2), end_time(R2, S2, ET2),
   ST1 < ET2, ST2 < ET1.

total_time(T) :- T = #max { ET : end_time(_, _, ET) }.

:- total_time(T), T > 35.

#show start_time/3.
#show end_time/3.
#show total_time/1.
"""
    
    return program

def solve_recipe_scheduling():
    """Solve the recipe scheduling problem using clingo"""
    
    ctl = clingo.Control(["1"])
    ctl.add("base", [], build_asp_program())
    ctl.ground([("base", [])])
    
    solution_data = None
    
    def on_model(model):
        nonlocal solution_data
        atoms = model.symbols(atoms=True)
        
        schedule = []
        total_time_val = 0
        start_times = {}
        end_times = {}
        
        for atom in atoms:
            if atom.name == "start_time" and len(atom.arguments) == 3:
                recipe = str(atom.arguments[0])[1:-1]
                step = str(atom.arguments[1])[1:-1]
                time_val = atom.arguments[2].number
                start_times[(recipe, step)] = time_val
            
            elif atom.name == "end_time" and len(atom.arguments) == 3:
                recipe = str(atom.arguments[0])[1:-1]
                step = str(atom.arguments[1])[1:-1]
                time_val = atom.arguments[2].number
                end_times[(recipe, step)] = time_val
            
            elif atom.name == "total_time" and len(atom.arguments) == 1:
                total_time_val = atom.arguments[0].number
        
        for recipe_name, steps in recipes_data.items():
            for step_info in steps:
                key = (recipe_name, step_info["step"])
                if key in start_times and key in end_times:
                    schedule.append({
                        "recipe": recipe_name,
                        "step": step_info["step"],
                        "start_time": start_times[key],
                        "end_time": end_times[key],
                        "resources": [step_info["resource"]]
                    })
        
        schedule.sort(key=lambda x: x["start_time"])
        
        solution_data = {
            "total_time": total_time_val,
            "schedule": schedule
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution_data
    else:
        return {"error": "No solution exists", 
                "reason": "Problem is unsatisfiable"}

def build_resource_usage(schedule):
    """Build resource usage summary from schedule"""
    resource_usage = {res: [] for res in resources}
    
    for entry in schedule:
        res = entry["resources"][0]
        resource_usage[res].append({
            "start": entry["start_time"],
            "end": entry["end_time"],
            "recipe": entry["recipe"]
        })
    
    for res in resource_usage:
        resource_usage[res].sort(key=lambda x: x["start"])
    
    return resource_usage

solution = solve_recipe_scheduling()
solution["resource_usage"] = build_resource_usage(solution["schedule"])

print(json.dumps(solution, indent=2))
