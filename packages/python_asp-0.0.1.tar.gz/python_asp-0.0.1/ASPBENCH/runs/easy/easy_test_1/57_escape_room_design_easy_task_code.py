import clingo
import json

puzzle_data = {
    1: {"difficulty": 1, "prerequisites": []},
    2: {"difficulty": 1, "prerequisites": [1]},
    3: {"difficulty": 2, "prerequisites": [2, 4]},
    4: {"difficulty": 2, "prerequisites": [1]},
    5: {"difficulty": 3, "prerequisites": [3]},
    6: {"difficulty": 3, "prerequisites": [5]}
}

asp_program = """
puzzle(1, 1).
puzzle(2, 1).
puzzle(3, 2).
puzzle(4, 2).
puzzle(5, 3).
puzzle(6, 3).

requires(2, 1).
requires(3, 2).
requires(3, 4).
requires(4, 1).
requires(5, 3).
requires(6, 5).

pos(1..6).

1 { position(P, Pos) : pos(Pos) } 1 :- puzzle(P, _).
1 { position(P, Pos) : puzzle(P, _) } 1 :- pos(Pos).

before(P1, P2) :- position(P1, Pos1), position(P2, Pos2), Pos1 < Pos2.

:- requires(P, PreReq), not before(PreReq, P).
:- before(P, P).
"""

ctl = clingo.Control(["1"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

solution_found = False
puzzle_order = []
position_map = {}

def on_model(model):
    global solution_found, puzzle_order, position_map
    solution_found = True
    
    position_map = {}
    for atom in model.symbols(atoms=True):
        if atom.name == "position" and len(atom.arguments) == 2:
            puzzle_id = atom.arguments[0].number
            pos = atom.arguments[1].number
            position_map[pos] = puzzle_id
    
    puzzle_order = [position_map[i] for i in sorted(position_map.keys())]

result = ctl.solve(on_model=on_model)

if solution_found:
    difficulty_progression = [puzzle_data[pid]["difficulty"] for pid in puzzle_order]
    
    puzzle_details = []
    for pid in range(1, 7):
        puzzle_details.append({
            "puzzle_id": pid,
            "difficulty": puzzle_data[pid]["difficulty"],
            "prerequisites": puzzle_data[pid]["prerequisites"]
        })
    
    dependencies_satisfied = True
    for i, pid in enumerate(puzzle_order):
        prereqs = puzzle_data[pid]["prerequisites"]
        for prereq in prereqs:
            prereq_pos = puzzle_order.index(prereq)
            if prereq_pos >= i:
                dependencies_satisfied = False
    
    output = {
        "puzzle_order": puzzle_order,
        "difficulty_progression": difficulty_progression,
        "dependencies_satisfied": dependencies_satisfied,
        "puzzle_details": puzzle_details
    }
    
    print(json.dumps(output, indent=2))
else:
    print(json.dumps({"error": "No solution exists", "reason": "Unable to find valid puzzle ordering"}))
