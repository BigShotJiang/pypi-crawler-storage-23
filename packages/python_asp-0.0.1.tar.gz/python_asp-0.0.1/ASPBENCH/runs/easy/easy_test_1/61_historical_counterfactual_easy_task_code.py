import clingo
import json

def solve_alternate_history():
    ctl = clingo.Control(["1"])
    
    program = """
    event("discovery_of_america", 1492).
    event("columbian_exchange", 1500).
    event("spanish_empire", 1520).
    event("industrial_revolution", 1750).
    event("world_wars", 1914).
    
    requires("columbian_exchange", "discovery_of_america").
    requires("spanish_empire", "discovery_of_america").
    requires("industrial_revolution", "spanish_empire").
    requires("world_wars", "industrial_revolution").
    
    intervention("discovery_of_america").
    
    in_original_timeline(E) :- event(E, _).
    
    prevented(E) :- intervention(E).
    
    prevented(E) :- requires(E, P), prevented(P).
    
    occurs(E) :- event(E, _), not prevented(E).
    
    direct_effect(E) :- requires(E, I), intervention(I).
    
    cascade_effect(E) :- prevented(E), not intervention(E), not direct_effect(E).
    
    preserved(E) :- occurs(E).
    """
    
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution_data = None
    
    def on_model(model):
        nonlocal solution_data
        
        original_timeline = []
        alternate_timeline = []
        prevented_events = []
        direct_effects = []
        cascade_effects = []
        preserved_events = []
        intervention_events = []
        
        events_with_years = {}
        
        for atom in model.symbols(atoms=True):
            if atom.name == "event":
                event_id = str(atom.arguments[0]).strip('"')
                year = atom.arguments[1].number
                events_with_years[event_id] = year
            
            elif atom.name == "in_original_timeline":
                event_id = str(atom.arguments[0]).strip('"')
                original_timeline.append(event_id)
            
            elif atom.name == "occurs":
                event_id = str(atom.arguments[0]).strip('"')
                alternate_timeline.append(event_id)
            
            elif atom.name == "prevented":
                event_id = str(atom.arguments[0]).strip('"')
                prevented_events.append(event_id)
            
            elif atom.name == "direct_effect":
                event_id = str(atom.arguments[0]).strip('"')
                direct_effects.append(event_id)
            
            elif atom.name == "cascade_effect":
                event_id = str(atom.arguments[0]).strip('"')
                cascade_effects.append(event_id)
            
            elif atom.name == "preserved":
                event_id = str(atom.arguments[0]).strip('"')
                preserved_events.append(event_id)
            
            elif atom.name == "intervention":
                event_id = str(atom.arguments[0]).strip('"')
                intervention_events.append(event_id)
        
        original_timeline.sort(key=lambda e: events_with_years.get(e, 0))
        alternate_timeline.sort(key=lambda e: events_with_years.get(e, 0))
        
        solution_data = {
            "original_timeline": original_timeline,
            "alternate_timeline": alternate_timeline,
            "prevented_events": prevented_events,
            "causal_analysis": {
                "direct_effects": direct_effects,
                "cascade_effects": cascade_effects,
                "preserved_events": preserved_events,
                "intervention_events": intervention_events
            }
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution_data
    else:
        return {"error": "No solution exists", 
                "reason": "Problem constraints are unsatisfiable"}

solution = solve_alternate_history()
print(json.dumps(solution, indent=2))
