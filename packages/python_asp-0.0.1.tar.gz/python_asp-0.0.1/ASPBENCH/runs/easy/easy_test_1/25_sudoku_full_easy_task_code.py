import clingo
import json

given_clues = [
    [5, 3, 0, 0, 7, 0, 0, 0, 0],
    [6, 0, 0, 1, 9, 5, 0, 0, 0],
    [0, 9, 8, 0, 0, 0, 0, 6, 0],
    [8, 0, 0, 0, 6, 0, 0, 0, 3],
    [4, 0, 0, 8, 0, 3, 0, 0, 1],
    [7, 0, 0, 0, 2, 0, 0, 0, 6],
    [0, 6, 0, 0, 0, 0, 2, 8, 0],
    [0, 0, 0, 4, 1, 9, 0, 0, 5],
    [0, 0, 0, 0, 8, 0, 0, 7, 9]
]

def generate_sudoku_asp(clues):
    facts = []
    facts.append("row(1..9).")
    facts.append("col(1..9).")
    facts.append("digit(1..9).")
    
    for r in range(1, 10):
        for c in range(1, 10):
            box_num = ((r-1)//3)*3 + ((c-1)//3) + 1
            facts.append(f"box({r},{c},{box_num}).")
    
    for r in range(9):
        for c in range(9):
            if clues[r][c] != 0:
                facts.append(f"given({r+1},{c+1},{clues[r][c]}).")
    
    choice_rule = "1 { cell(R,C,D) : digit(D) } 1 :- row(R), col(C)."
    clue_constraint = ":- given(R,C,D), not cell(R,C,D)."
    row_constraint = ":- row(R), digit(D), #count { C : cell(R,C,D) } != 1."
    col_constraint = ":- col(C), digit(D), #count { R : cell(R,C,D) } != 1."
    box_constraint = ":- digit(D), B = 1..9, #count { R,C : cell(R,C,D), box(R,C,B) } != 1."
    
    program = "\n".join(facts) + "\n\n"
    program += choice_rule + "\n"
    program += clue_constraint + "\n"
    program += row_constraint + "\n"
    program += col_constraint + "\n"
    program += box_constraint + "\n"
    
    return program

def verify_sudoku(grid, original_clues):
    clues_preserved = True
    for r in range(9):
        for c in range(9):
            if original_clues[r][c] != 0:
                if grid[r][c] != original_clues[r][c]:
                    clues_preserved = False
    
    rows_valid = all(sorted(grid[r]) == list(range(1, 10)) for r in range(9))
    
    cols_valid = all(
        sorted([grid[r][c] for r in range(9)]) == list(range(1, 10))
        for c in range(9)
    )
    
    boxes_valid = True
    for box_row in range(3):
        for box_col in range(3):
            box = []
            for r in range(3):
                for c in range(3):
                    box.append(grid[box_row*3 + r][box_col*3 + c])
            if sorted(box) != list(range(1, 10)):
                boxes_valid = False
    
    is_valid = rows_valid and cols_valid and boxes_valid and clues_preserved
    return is_valid, clues_preserved

asp_program = generate_sudoku_asp(given_clues)

ctl = clingo.Control(["1"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

solution_grid = None

def on_model(model):
    global solution_grid
    solution_grid = [[0 for _ in range(9)] for _ in range(9)]
    for atom in model.symbols(atoms=True):
        if atom.name == "cell" and len(atom.arguments) == 3:
            row = atom.arguments[0].number
            col = atom.arguments[1].number
            digit = atom.arguments[2].number
            solution_grid[row-1][col-1] = digit

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    is_valid, clues_preserved = verify_sudoku(solution_grid, given_clues)
    output = {
        "grid": solution_grid,
        "is_valid": is_valid,
        "clues_preserved": clues_preserved
    }
    print(json.dumps(output))
else:
    print(json.dumps({"error": "No solution exists", "reason": "UNSAT"}))
