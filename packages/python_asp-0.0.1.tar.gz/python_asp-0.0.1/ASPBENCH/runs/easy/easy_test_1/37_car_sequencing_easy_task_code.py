import clingo
import json

def solve_assembly_line():
    ctl = clingo.Control(["1"])
    
    program = """
    car_type(a, 1).
    car_type(b, 2).
    car_type(c, 3).
    
    has_option(a, 1).
    has_option(a, 2).
    has_option(b, 3).
    has_option(c, 1).
    
    capacity(1, 2, 3).
    capacity(2, 1, 2).
    capacity(3, 1, 2).
    
    position(1..6).
    
    1 { assigned(P, T) : car_type(T, _) } 1 :- position(P).
    
    :- car_type(T, Count), #count { P : assigned(P, T) } != Count.
    
    :- capacity(Opt, MaxCount, WindowSize), 
       position(Start), 
       Start + WindowSize - 1 <= 6,
       #count { P : assigned(P, T), has_option(T, Opt), 
                P >= Start, P < Start + WindowSize } > MaxCount.
    
    #show assigned/2.
    """
    
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution = None
    
    def on_model(m):
        nonlocal solution
        atoms = m.symbols(atoms=True)
        
        assignments = {}
        for atom in atoms:
            if atom.name == "assigned" and len(atom.arguments) == 2:
                pos = atom.arguments[0].number
                car_type = str(atom.arguments[1]).upper()
                assignments[pos] = car_type
        
        sequence = [assignments[i] for i in range(1, 7)]
        
        solution = {
            "sequence": sequence,
            "length": len(sequence)
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable and solution:
        return solution
    else:
        return {"error": "No solution exists", 
                "reason": "Constraints cannot be satisfied"}

solution = solve_assembly_line()
print(json.dumps(solution))
