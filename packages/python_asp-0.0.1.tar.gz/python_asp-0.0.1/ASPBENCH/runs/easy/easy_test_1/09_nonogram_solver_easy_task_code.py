import clingo
import json


def solve_nonogram():
    ctl = clingo.Control(["1"])
    
    program = """
    row(1..5).
    col(1..5).
    
    row_clue(1, 1, 2).
    row_clue(2, 1, 1).
    row_clue(3, 1, 3).
    row_clue(4, 1, 1).
    row_clue(4, 2, 1).
    row_clue(5, 1, 2).
    
    col_clue(1, 1, 1).
    col_clue(1, 2, 1).
    col_clue(2, 1, 1).
    col_clue(2, 2, 3).
    col_clue(3, 1, 2).
    col_clue(4, 1, 1).
    col_clue(5, 1, 1).
    
    { cell(R, C, 1) } :- row(R), col(C).
    cell(R, C, 0) :- row(R), col(C), not cell(R, C, 1).
    
    1 { row_run_pos(R, RunIdx, StartCol) : col(StartCol) } 1 
        :- row_clue(R, RunIdx, _).
    
    :- row_run_pos(R, RunIdx, Start), row_clue(R, RunIdx, Len),
       col(C), C >= Start, C < Start + Len,
       cell(R, C, 0).
    
    :- row_run_pos(R, RunIdx, Start), row_clue(R, RunIdx, Len),
       Start + Len > 6.
    
    :- row_run_pos(R, I1, C1), row_run_pos(R, I2, C2),
       row_clue(R, I1, L1), row_clue(R, I2, _),
       I2 = I1 + 1, C2 < C1 + L1.
    
    :- row_run_pos(R, I1, C1), row_run_pos(R, I2, C2),
       row_clue(R, I1, L1), row_clue(R, I2, _),
       I1 < I2, C2 < C1 + L1 + 1.
    
    :- cell(R, C, 1), row(R), col(C), not in_row_run(R, C).
    
    in_row_run(R, C) :- row_run_pos(R, RunIdx, Start),
                        row_clue(R, RunIdx, Len),
                        col(C), C >= Start, C < Start + Len.
    
    1 { col_run_pos(C, RunIdx, StartRow) : row(StartRow) } 1 
        :- col_clue(C, RunIdx, _).
    
    :- col_run_pos(C, RunIdx, Start), col_clue(C, RunIdx, Len),
       row(R), R >= Start, R < Start + Len,
       cell(R, C, 0).
    
    :- col_run_pos(C, RunIdx, Start), col_clue(C, RunIdx, Len),
       Start + Len > 6.
    
    :- col_run_pos(C, I1, R1), col_run_pos(C, I2, R2),
       col_clue(C, I1, L1), col_clue(C, I2, _),
       I2 = I1 + 1, R2 < R1 + L1.
    
    :- col_run_pos(C, I1, R1), col_run_pos(C, I2, R2),
       col_clue(C, I1, L1), col_clue(C, I2, _),
       I1 < I2, R2 < R1 + L1 + 1.
    
    :- cell(R, C, 1), row(R), col(C), not in_col_run(R, C).
    
    in_col_run(R, C) :- col_run_pos(C, RunIdx, Start),
                        col_clue(C, RunIdx, Len),
                        row(R), R >= Start, R < Start + Len.
    
    #show cell/3.
    """
    
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution = None
    
    def on_model(m):
        nonlocal solution
        solution = {}
        for atom in m.symbols(atoms=True):
            if atom.name == "cell" and len(atom.arguments) == 3:
                r = atom.arguments[0].number
                c = atom.arguments[1].number
                v = atom.arguments[2].number
                if r not in solution:
                    solution[r] = {}
                solution[r][c] = v
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable and solution:
        grid = []
        for r in range(1, 6):
            row = []
            for c in range(1, 6):
                row.append(solution[r][c])
            grid.append(row)
        
        return {
            "grid": grid,
            "valid": True
        }
    else:
        return {
            "error": "No solution exists",
            "reason": "The puzzle constraints cannot be satisfied"
        }


if __name__ == "__main__":
    result = solve_nonogram()
    print(json.dumps(result, indent=2))
