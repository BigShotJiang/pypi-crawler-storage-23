import clingo
import json

program = """
row(1..3).
col(1..3).
num(1..9).

1 { cell(R, C, N) : num(N) } 1 :- row(R), col(C).

:- num(N), #count { R, C : cell(R, C, N) } != 1.

:- row(R), #sum { N, C : cell(R, C, N) } != 15.

:- col(C), #sum { N, R : cell(R, C, N) } != 15.

:- #sum { N, R : cell(R, R, N) } != 15.

:- #sum { N, R : cell(R, 4-R, N) } != 15.
"""

ctl = clingo.Control(["1"])
ctl.add("base", [], program)
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    square = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
    
    for atom in model.symbols(atoms=True):
        if atom.name == "cell" and len(atom.arguments) == 3:
            row = atom.arguments[0].number
            col = atom.arguments[1].number
            value = atom.arguments[2].number
            square[row-1][col-1] = value
    
    solution_data = {
        "square": square,
        "magic_sum": 15,
        "valid": True
    }

result = ctl.solve(on_model=on_model)

if result.satisfiable and solution_data:
    print(json.dumps(solution_data))
else:
    print(json.dumps({"error": "No solution exists"}))
