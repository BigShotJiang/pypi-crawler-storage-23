import json
import random

class Strategy:
    def __init__(self, name):
        self.name = name
        self.total_score = 0
    
    def reset(self):
        pass
    
    def play(self, opponent_history):
        raise NotImplementedError

class COOP(Strategy):
    def __init__(self):
        super().__init__("COOP")
    
    def play(self, opponent_history):
        return 'C'

class DEFECT(Strategy):
    def __init__(self):
        super().__init__("DEFECT")
    
    def play(self, opponent_history):
        return 'D'

class TFT(Strategy):
    def __init__(self):
        super().__init__("TFT")
    
    def play(self, opponent_history):
        if len(opponent_history) == 0:
            return 'C'
        return opponent_history[-1]

class GTFT(Strategy):
    def __init__(self):
        super().__init__("GTFT")
    
    def play(self, opponent_history):
        if len(opponent_history) == 0:
            return 'C'
        last_move = opponent_history[-1]
        if last_move == 'D':
            if random.random() < 0.1:
                return 'C'
        return last_move

class RAND(Strategy):
    def __init__(self):
        super().__init__("RAND")
    
    def play(self, opponent_history):
        return 'C' if random.random() < 0.5 else 'D'

def get_payoff(move1, move2):
    if move1 == 'C' and move2 == 'C':
        return 3
    elif move1 == 'D' and move2 == 'D':
        return 1
    elif move1 == 'D' and move2 == 'C':
        return 5
    else:
        return 0

def play_match(strategy1, strategy2, rounds=100):
    strategy1.reset()
    strategy2.reset()
    
    history1 = []
    history2 = []
    score1 = 0
    score2 = 0
    
    for _ in range(rounds):
        move1 = strategy1.play(history2)
        move2 = strategy2.play(history1)
        
        score1 += get_payoff(move1, move2)
        score2 += get_payoff(move2, move1)
        
        history1.append(move1)
        history2.append(move2)
    
    return score1, score2

def run_tournament(seed=69):
    random.seed(seed)
    
    strategies = [COOP(), DEFECT(), TFT(), GTFT(), RAND()]
    
    for strategy in strategies:
        strategy.total_score = 0
    
    for i, strat1 in enumerate(strategies):
        for j, strat2 in enumerate(strategies):
            score1, score2 = play_match(strat1, strat2, 100)
            strat1.total_score += score1
    
    results = sorted(strategies, key=lambda s: s.total_score, reverse=True)
    
    tournament_results = [
        {"strategy": s.name, "total_score": s.total_score}
        for s in results
    ]
    
    output = {
        "tournament_results": tournament_results,
        "winner": results[0].name
    }
    
    return output

if __name__ == "__main__":
    result = run_tournament()
    print(json.dumps(result, indent=2))
