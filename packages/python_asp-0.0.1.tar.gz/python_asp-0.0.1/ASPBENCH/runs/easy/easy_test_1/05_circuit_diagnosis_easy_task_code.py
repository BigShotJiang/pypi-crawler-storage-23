import clingo
import json

def find_all_minimal_diagnoses():
    program_template = """
    component(and1; or1; notgate1; xor1; and2).
    
    gate_type(and1, and).
    gate_type(or1, or).
    gate_type(notgate1, notg).
    gate_type(xor1, xor).
    gate_type(and2, and).
    
    gate_input(and1, in1, 1).
    gate_input(and1, in2, 2).
    gate_input(or1, w1, 1).
    gate_input(or1, in3, 2).
    gate_input(notgate1, w2, 1).
    gate_input(xor1, in1, 1).
    gate_input(xor1, in4, 2).
    gate_input(and2, w3, 1).
    gate_input(and2, in2, 2).
    
    gate_output(and1, w1).
    gate_output(or1, w2).
    gate_output(notgate1, out1).
    gate_output(xor1, w3).
    gate_output(and2, out2).
    
    input_value(in1, 1).
    input_value(in2, 0).
    input_value(in3, 1).
    input_value(in4, 1).
    
    observed_output(out1, 1).
    observed_output(out2, 0).
    
    wire(W) :- input_value(W, _).
    wire(W) :- gate_output(_, W).
    
    value(0; 1).
    
    { faulty(C) } :- component(C).
    
    1 { wire_value(W, V) : value(V) } 1 :- wire(W).
    
    :- input_value(W, V), not wire_value(W, V).
    
    :- gate_type(G, and), gate_output(G, W), not faulty(G),
       gate_input(G, W1, 1), gate_input(G, W2, 2),
       wire_value(W1, 1), wire_value(W2, 1),
       not wire_value(W, 1).
    :- gate_type(G, and), gate_output(G, W), not faulty(G),
       gate_input(G, W1, 1), gate_input(G, W2, 2),
       wire_value(W1, 0),
       not wire_value(W, 0).
    :- gate_type(G, and), gate_output(G, W), not faulty(G),
       gate_input(G, W1, 1), gate_input(G, W2, 2),
       wire_value(W2, 0),
       not wire_value(W, 0).
    
    :- gate_type(G, or), gate_output(G, W), not faulty(G),
       gate_input(G, W1, 1), gate_input(G, W2, 2),
       wire_value(W1, 1),
       not wire_value(W, 1).
    :- gate_type(G, or), gate_output(G, W), not faulty(G),
       gate_input(G, W1, 1), gate_input(G, W2, 2),
       wire_value(W2, 1),
       not wire_value(W, 1).
    :- gate_type(G, or), gate_output(G, W), not faulty(G),
       gate_input(G, W1, 1), gate_input(G, W2, 2),
       wire_value(W1, 0), wire_value(W2, 0),
       not wire_value(W, 0).
    
    :- gate_type(G, notg), gate_output(G, W), not faulty(G),
       gate_input(G, W1, 1), wire_value(W1, 0),
       not wire_value(W, 1).
    :- gate_type(G, notg), gate_output(G, W), not faulty(G),
       gate_input(G, W1, 1), wire_value(W1, 1),
       not wire_value(W, 0).
    
    :- gate_type(G, xor), gate_output(G, W), not faulty(G),
       gate_input(G, W1, 1), gate_input(G, W2, 2),
       wire_value(W1, V1), wire_value(W2, V2),
       V1 != V2,
       not wire_value(W, 1).
    :- gate_type(G, xor), gate_output(G, W), not faulty(G),
       gate_input(G, W1, 1), gate_input(G, W2, 2),
       wire_value(W1, V), wire_value(W2, V),
       not wire_value(W, 0).
    
    :- observed_output(W, V), not wire_value(W, V).
    
    SIZE_CONSTRAINT
    
    #show faulty/1.
    """
    
    all_minimal = []
    
    for size in range(1, 6):
        ctl = clingo.Control(["0"])
        
        program = program_template.replace("SIZE_CONSTRAINT", 
                                          f":- #count {{ C : faulty(C) }} != {size}.")
        
        ctl.add("base", [], program)
        ctl.ground([("base", [])])
        
        size_diagnoses = []
        def on_model(model):
            faulty = []
            for atom in model.symbols(atoms=True):
                if atom.name == "faulty":
                    faulty.append(str(atom.arguments[0]))
            size_diagnoses.append(sorted(faulty))
        
        result = ctl.solve(on_model=on_model)
        
        if result.satisfiable:
            unique = []
            for diag in size_diagnoses:
                if diag not in unique:
                    unique.append(diag)
            
            all_minimal.extend(unique)
            break
    
    return all_minimal

minimal_diagnoses = find_all_minimal_diagnoses()

output = {
    "diagnoses": [
        {"components": diag, "minimal": True}
        for diag in minimal_diagnoses
    ],
    "explanation": "Each diagnosis represents a minimal set of components that, if faulty, would explain the observed discrepancy."
}

print(json.dumps(output, indent=2))
