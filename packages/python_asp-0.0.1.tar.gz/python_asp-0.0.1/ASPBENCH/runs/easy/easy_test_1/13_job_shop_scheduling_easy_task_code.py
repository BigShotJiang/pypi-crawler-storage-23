import clingo
import json

def create_asp_program():
    program = """
job(1..3).
op_num(1..3).

operation(1, 1, 1, 3).
operation(1, 2, 2, 2).
operation(1, 3, 3, 4).

operation(2, 1, 2, 2).
operation(2, 2, 1, 5).
operation(2, 3, 3, 1).

operation(3, 1, 3, 4).
operation(3, 2, 1, 1).
operation(3, 3, 2, 3).

machine(1..3).
time(0..11).

1 { start(J, O, T) : time(T) } 1 :- operation(J, O, _, _).

:- start(J, O, T), operation(J, O, _, D), T + D > 11.

:- start(J, O, T1), start(J, O+1, T2), operation(J, O, _, D1), 
   O < 3, T2 < T1 + D1.

:- start(J1, O1, T1), start(J2, O2, T2),
   operation(J1, O1, M, D1), operation(J2, O2, M, D2),
   (J1, O1) != (J2, O2),
   T1 < T2 + D2, T2 < T1 + D1.

end_time(J, O, T + D) :- start(J, O, T), operation(J, O, _, D).
makespan(M) :- M = #max { T : end_time(_, _, T) }.

:- makespan(M), M > 11.

#show start/3.
#show makespan/1.
"""
    return program

def solve_job_shop():
    ctl = clingo.Control(["1"])
    
    program = create_asp_program()
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution_data = None
    
    def on_model(model):
        nonlocal solution_data
        atoms = model.symbols(atoms=True)
        
        schedule = []
        makespan_val = 0
        
        op_data = {
            (1, 1): (1, 3), (1, 2): (2, 2), (1, 3): (3, 4),
            (2, 1): (2, 2), (2, 2): (1, 5), (2, 3): (3, 1),
            (3, 1): (3, 4), (3, 2): (1, 1), (3, 3): (2, 3)
        }
        
        for atom in atoms:
            if atom.name == "start" and len(atom.arguments) == 3:
                job = atom.arguments[0].number
                op_num = atom.arguments[1].number
                start_time = atom.arguments[2].number
                
                machine, duration = op_data[(job, op_num)]
                
                schedule.append({
                    "job": job,
                    "operation": op_num,
                    "machine": machine,
                    "start": start_time,
                    "duration": duration
                })
            
            elif atom.name == "makespan" and len(atom.arguments) == 1:
                makespan_val = atom.arguments[0].number
        
        schedule.sort(key=lambda x: (x["job"], x["operation"]))
        
        solution_data = {
            "schedule": schedule,
            "makespan": makespan_val,
            "feasible": True
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution_data
    else:
        return {
            "schedule": [],
            "makespan": 0,
            "feasible": False,
            "error": "No solution exists within the given time horizon"
        }

solution = solve_job_shop()
print(json.dumps(solution, indent=2))
