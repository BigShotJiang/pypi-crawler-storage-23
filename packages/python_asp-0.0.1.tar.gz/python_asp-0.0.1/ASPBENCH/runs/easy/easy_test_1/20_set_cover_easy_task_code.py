import clingo
import json

def solve_set_cover():
    ctl = clingo.Control()
    
    program = """
    element(1..8).
    set(0..5).
    
    contains(0, 1). contains(0, 2). contains(0, 3).
    contains(1, 2). contains(1, 4). contains(1, 5).
    contains(2, 3). contains(2, 6). contains(2, 7).
    contains(3, 1). contains(3, 4). contains(3, 8).
    contains(4, 5). contains(4, 6). contains(4, 7). contains(4, 8).
    contains(5, 1). contains(5, 2). contains(5, 6).
    
    { selected(S) } :- set(S).
    
    covered(E) :- element(E), selected(S), contains(S, E).
    :- element(E), not covered(E).
    
    #minimize { 1,S : selected(S) }.
    """
    
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution = None
    
    def on_model(m):
        nonlocal solution
        selected_sets = []
        for atom in m.symbols(atoms=True):
            if atom.name == "selected" and len(atom.arguments) == 1:
                set_id = atom.arguments[0].number
                selected_sets.append(set_id)
        
        selected_sets.sort()
        
        set_contents = {
            0: {1, 2, 3},
            1: {2, 4, 5},
            2: {3, 6, 7},
            3: {1, 4, 8},
            4: {5, 6, 7, 8},
            5: {1, 2, 6}
        }
        
        covered_elements = set()
        for s in selected_sets:
            covered_elements.update(set_contents[s])
        
        covered_elements = sorted(list(covered_elements))
        
        solution = {
            "selected_sets": selected_sets,
            "total_sets": len(selected_sets),
            "covered_elements": covered_elements
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution
    else:
        return {"error": "No solution exists", 
                "reason": "Problem is unsatisfiable"}

solution = solve_set_cover()
print(json.dumps(solution, indent=2))
