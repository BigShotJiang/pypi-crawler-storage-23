import clingo
import json

def solve_byzantine_generals():
    ctl = clingo.Control(["1"])
    
    program = """
    general("G1"). general("G2"). general("G3"). general("G4").
    
    initial_proposal("G1", 1).
    initial_proposal("G2", 1).
    initial_proposal("G3", 0).
    initial_proposal("G4", 1).
    
    traitor("G4").
    
    value(0). value(1).
    
    honest(G) :- general(G), not traitor(G).
    
    vote_count(V, N) :- value(V), 
        N = #count { G : honest(G), initial_proposal(G, V) }.
    
    max_votes(N) :- N = #max { Count : vote_count(_, Count) }.
    
    majority_candidate(V) :- vote_count(V, N), max_votes(N).
    
    consensus(0) :- vote_count(0, N), vote_count(1, N), N > 0.
    consensus(V) :- majority_candidate(V), 
        vote_count(V, N1), vote_count(V2, N2), V != V2, N1 > N2.
    
    :- #count { V : consensus(V) } != 1.
    
    #show consensus/1.
    #show honest/1.
    #show traitor/1.
    """
    
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution_data = None
    
    def on_model(m):
        nonlocal solution_data
        atoms = m.symbols(atoms=True)
        
        consensus_value = None
        honest_generals = []
        traitor_general = None
        
        for atom in atoms:
            if atom.name == "consensus" and len(atom.arguments) == 1:
                consensus_value = atom.arguments[0].number
            elif atom.name == "honest" and len(atom.arguments) == 1:
                honest_generals.append(str(atom.arguments[0]).strip('"'))
            elif atom.name == "traitor" and len(atom.arguments) == 1:
                traitor_general = str(atom.arguments[0]).strip('"')
        
        solution_data = {
            "consensus": consensus_value,
            "honest_generals": sorted(honest_generals),
            "traitor": traitor_general
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable and solution_data:
        return solution_data
    else:
        return {"error": "No solution exists", "reason": "UNSAT"}

solution = solve_byzantine_generals()
print(json.dumps(solution, indent=2))
