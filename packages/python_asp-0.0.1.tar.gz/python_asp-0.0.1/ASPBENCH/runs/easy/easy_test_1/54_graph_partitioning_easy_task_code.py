import clingo
import json

def generate_asp_program():
    program = """
    vertex(0..7).
    
    edge(0,1). edge(0,4).
    edge(1,2). edge(1,5).
    edge(2,3). edge(2,6).
    edge(3,7).
    edge(4,5). edge(4,6).
    edge(5,7).
    edge(6,7).
    
    { in_partition_1(V) } :- vertex(V).
    
    :- #count { V : in_partition_1(V) } != 4.
    
    cut_edge(V1, V2) :- edge(V1, V2), in_partition_1(V1), not in_partition_1(V2).
    cut_edge(V1, V2) :- edge(V1, V2), not in_partition_1(V1), in_partition_1(V2).
    
    #minimize { 1,V1,V2 : cut_edge(V1,V2) }.
    """
    return program

def solve_partition():
    ctl = clingo.Control(["0"])
    
    program = generate_asp_program()
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution = None
    best_cut_size = float('inf')
    
    def on_model(m):
        nonlocal solution, best_cut_size
        
        partition_1 = []
        partition_2 = []
        cut_edges_set = set()
        
        for atom in m.symbols(atoms=True):
            if atom.name == "in_partition_1" and len(atom.arguments) == 1:
                vertex = atom.arguments[0].number
                partition_1.append(vertex)
            elif atom.name == "cut_edge" and len(atom.arguments) == 2:
                v1 = atom.arguments[0].number
                v2 = atom.arguments[1].number
                if v1 < v2:
                    cut_edges_set.add((v1, v2))
                else:
                    cut_edges_set.add((v2, v1))
        
        all_vertices = set(range(8))
        partition_2 = sorted(list(all_vertices - set(partition_1)))
        partition_1 = sorted(partition_1)
        
        cut_edges = [{"from": e[0], "to": e[1]} for e in sorted(cut_edges_set)]
        
        current_cut_size = len(cut_edges)
        
        if current_cut_size <= best_cut_size:
            best_cut_size = current_cut_size
            solution = {
                "partition_1": partition_1,
                "partition_2": partition_2,
                "cut_size": len(cut_edges),
                "cut_edges": cut_edges,
                "balance": {
                    "partition_1_size": len(partition_1),
                    "partition_2_size": len(partition_2),
                    "is_balanced": len(partition_1) == 4 and len(partition_2) == 4
                }
            }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution
    else:
        return {"error": "No solution exists", "reason": "Problem is unsatisfiable"}

solution = solve_partition()
print(json.dumps(solution, indent=2))
