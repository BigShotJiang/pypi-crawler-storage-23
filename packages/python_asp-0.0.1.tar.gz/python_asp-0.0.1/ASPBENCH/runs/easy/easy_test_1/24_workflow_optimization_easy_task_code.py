import clingo
import json

task_data = [
    (0, 3, []),
    (1, 2, []),
    (2, 4, [0]),
    (3, 1, [1]),
    (4, 5, [2, 3]),
    (5, 2, [0]),
    (6, 3, [4]),
    (7, 2, [5, 6])
]

def generate_asp_program(tasks, max_time=17):
    facts = []
    
    for task_id, duration, prereqs in tasks:
        facts.append(f"task({task_id}, {duration}).")
        for prereq in prereqs:
            facts.append(f"prerequisite({task_id}, {prereq}).")
    
    facts.append(f"time(0..{max_time}).")
    
    asp_program = "\n".join(facts) + """

1 { start(T, Time) : time(Time) } 1 :- task(T, _).

end(T, Time + D) :- start(T, Time), task(T, D).

:- start(T, StartT), prerequisite(T, PrereqT), end(PrereqT, EndT), StartT < EndT.

makespan(M) :- M = #max { EndT : end(_, EndT) }.

:- makespan(M), M > 17.

#show start/2.
#show end/2.
#show makespan/1.
"""
    return asp_program

def find_critical_path(task_data, starts, ends, makespan):
    task_dict = {t[0]: {'duration': t[1], 'prereqs': t[2]} for t in task_data}
    
    critical_tasks = [tid for tid, end_time in ends.items() if end_time == makespan]
    
    def trace_critical_path(task_id):
        if not task_dict[task_id]['prereqs']:
            return [task_id]
        
        task_start = starts[task_id]
        critical_prereq = None
        
        for prereq in task_dict[task_id]['prereqs']:
            if ends[prereq] == task_start:
                critical_prereq = prereq
                break
        
        if critical_prereq is not None:
            path = trace_critical_path(critical_prereq)
            path.append(task_id)
            return path
        else:
            latest_prereq = max(task_dict[task_id]['prereqs'], 
                              key=lambda p: ends[p])
            path = trace_critical_path(latest_prereq)
            path.append(task_id)
            return path
    
    if critical_tasks:
        return trace_critical_path(critical_tasks[0])
    return []

program = generate_asp_program(task_data)

ctl = clingo.Control(["1"])
ctl.add("base", [], program)
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    solution_data = {
        'starts': {},
        'ends': {},
        'makespan': None
    }
    
    for atom in model.symbols(atoms=True):
        if atom.name == "start" and len(atom.arguments) == 2:
            task_id = atom.arguments[0].number
            start_time = atom.arguments[1].number
            solution_data['starts'][task_id] = start_time
        elif atom.name == "end" and len(atom.arguments) == 2:
            task_id = atom.arguments[0].number
            end_time = atom.arguments[1].number
            solution_data['ends'][task_id] = end_time
        elif atom.name == "makespan" and len(atom.arguments) == 1:
            solution_data['makespan'] = atom.arguments[0].number

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    critical_path = find_critical_path(task_data, solution_data['starts'], 
                                       solution_data['ends'], solution_data['makespan'])
    
    output = {
        "schedule": [],
        "makespan": solution_data['makespan'],
        "critical_path": critical_path
    }
    
    for task_id in range(8):
        output["schedule"].append({
            "task": task_id,
            "start_time": solution_data['starts'][task_id],
            "end_time": solution_data['ends'][task_id]
        })
    
    print(json.dumps(output, indent=2))
else:
    print(json.dumps({"error": "No solution exists", 
                      "reason": "Unable to schedule tasks within makespan constraint"}))
