import clingo
import json
import math

asp_program = """
% Species with carrying capacities
species("Grass", 100).
species("Rabbits", 30).
species("Foxes", 10).
species("Hawks", 5).

% Feeding relationships
eats("Rabbits", "Grass").
eats("Foxes", "Rabbits").
eats("Hawks", "Rabbits").
eats("Hawks", "Foxes").

% Each species gets exactly one population level (1 to capacity)
1 { population(S, P) : P = 1..Cap } 1 :- species(S, Cap).

% Each predator-prey relationship gets one consumption rate (1-5 = 0.1-0.5)
1 { consumption(Pred, Prey, Rate) : Rate = 1..5 } 1 :- eats(Pred, Prey).

% Herbivore sustainability: Rabbits <= 0.5 * Grass
:- population("Rabbits", R), population("Grass", G), R * 2 > G.

% Predator sustainability: Foxes <= 0.3 * Rabbits
:- population("Foxes", F), population("Rabbits", R), F * 10 > R * 3.

% Hawks sustainability: Hawks <= 0.3 * (Rabbits + Foxes)
:- population("Hawks", H), population("Rabbits", R), population("Foxes", F),
   H * 10 > (R + F) * 3.

% Grass must support herbivore load: Grass >= 2 * Rabbits
:- population("Rabbits", R), population("Grass", G), G < R * 2.

% Predator pressure constraint: Rabbits >= Foxes + Hawks
:- population("Rabbits", R), population("Foxes", F), population("Hawks", H),
   R < F + H.

% Maximize biodiversity (total population)
#maximize { P@1, S : population(S, P) }.
"""

ctl = clingo.Control(["0"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    solution_data = {
        'populations': {},
        'consumption_rates': {}
    }
    
    for atom in model.symbols(atoms=True):
        if atom.name == "population":
            species = str(atom.arguments[0]).strip('"')
            pop = atom.arguments[1].number
            solution_data['populations'][species] = pop
        elif atom.name == "consumption":
            predator = str(atom.arguments[0]).strip('"')
            prey = str(atom.arguments[1]).strip('"')
            rate = atom.arguments[2].number
            key = (predator, prey)
            solution_data['consumption_rates'][key] = rate

result = ctl.solve(on_model=on_model)

if result.satisfiable and solution_data:
    populations = solution_data['populations']
    
    food_web = []
    for (predator, prey), rate in sorted(solution_data['consumption_rates'].items()):
        food_web.append({
            "predator": predator,
            "prey": prey,
            "consumption_rate": rate / 10.0
        })
    
    total_pop = sum(populations.values())
    biodiversity_index = 0.0
    if total_pop > 0:
        for pop in populations.values():
            if pop > 0:
                p = pop / total_pop
                biodiversity_index -= p * math.log(p)
        max_diversity = math.log(len(populations))
        biodiversity_index = biodiversity_index / max_diversity if max_diversity > 0 else 0.0
    
    capacities = {"Grass": 100, "Rabbits": 30, "Foxes": 10, "Hawks": 5}
    utilization_scores = [populations[species] / cap for species, cap in capacities.items()]
    stability_score = sum(utilization_scores) / len(utilization_scores)
    
    grass = populations["Grass"]
    rabbits = populations["Rabbits"]
    foxes = populations["Foxes"]
    hawks = populations["Hawks"]
    
    sustainability = True
    sustainability &= (rabbits * 2 <= grass)
    sustainability &= (foxes * 10 <= rabbits * 3)
    sustainability &= (hawks * 10 <= (rabbits + foxes) * 3)
    sustainability &= all(pop > 0 for pop in populations.values())
    
    output = {
        "stable_populations": populations,
        "food_web": food_web,
        "ecosystem_health": {
            "biodiversity_index": round(biodiversity_index, 3),
            "stability_score": round(stability_score, 3),
            "sustainability": sustainability
        },
        "balance_achieved": sustainability
    }
    
    print(json.dumps(output, indent=2))
else:
    output = {
        "error": "No solution exists",
        "reason": "Constraints are unsatisfiable"
    }
    print(json.dumps(output, indent=2))
