import clingo
import json

def create_asp_program(initial_grid):
    """Generate ASP program for Conway's Game of Life with cycle detection"""
    
    program = """
cell(1..5, 1..5).
time(0..10).

"""
    
    program += "% Initial state (time 0)\n"
    for row_idx, row in enumerate(initial_grid):
        for col_idx, val in enumerate(row):
            if val == 1:
                program += f"alive({col_idx + 1}, {row_idx + 1}, 0).\n"
    
    program += """
neighbor_offset(-1, -1). neighbor_offset(-1, 0). neighbor_offset(-1, 1).
neighbor_offset(0, -1).                          neighbor_offset(0, 1).
neighbor_offset(1, -1).  neighbor_offset(1, 0).  neighbor_offset(1, 1).

neighbor_count(X, Y, T, N) :- 
    cell(X, Y), time(T),
    N = #count { DX, DY : 
        neighbor_offset(DX, DY),
        cell(NX, NY),
        NX = X + DX,
        NY = Y + DY,
        alive(NX, NY, T)
    }.

alive(X, Y, T+1) :- 
    alive(X, Y, T), 
    neighbor_count(X, Y, T, N),
    N >= 2, N <= 3,
    time(T), T < 10.

alive(X, Y, T+1) :- 
    cell(X, Y),
    not alive(X, Y, T),
    neighbor_count(X, Y, T, 3),
    time(T), T < 10.

same_state(T1, T2) :- 
    time(T1), time(T2), T1 < T2,
    not different_state(T1, T2).

different_state(T1, T2) :- 
    time(T1), time(T2), T1 < T2,
    cell(X, Y),
    alive(X, Y, T1),
    not alive(X, Y, T2).

different_state(T1, T2) :- 
    time(T1), time(T2), T1 < T2,
    cell(X, Y),
    not alive(X, Y, T1),
    alive(X, Y, T2).

#show alive/3.
#show same_state/2.
"""
    
    return program

def solve_game_of_life(asp_program):
    """Solve the ASP program and extract the solution"""
    
    ctl = clingo.Control(["1"])
    ctl.add("base", [], asp_program)
    ctl.ground([("base", [])])
    
    solution_data = None
    
    def on_model(model):
        nonlocal solution_data
        
        alive_cells = {}
        same_states = []
        
        for atom in model.symbols(atoms=True):
            if atom.name == "alive" and len(atom.arguments) == 3:
                x = atom.arguments[0].number
                y = atom.arguments[1].number
                t = atom.arguments[2].number
                
                if t not in alive_cells:
                    alive_cells[t] = set()
                alive_cells[t].add((x, y))
            
            elif atom.name == "same_state" and len(atom.arguments) == 2:
                t1 = atom.arguments[0].number
                t2 = atom.arguments[1].number
                same_states.append((t1, t2))
        
        solution_data = {
            'alive_cells': alive_cells,
            'same_states': same_states
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution_data
    else:
        return None

def grid_to_list(alive_cells_set, size=5):
    """Convert set of alive cells to 2D list grid"""
    grid = [[0 for _ in range(size)] for _ in range(size)]
    for (x, y) in alive_cells_set:
        grid[y-1][x-1] = 1
    return grid

def find_first_cycle(alive_cells, same_states):
    """Find the first cycle in the evolution"""
    
    if not same_states:
        return None
    
    same_states.sort()
    
    first_repeat = same_states[0]
    cycle_start = first_repeat[0]
    cycle_end = first_repeat[1]
    
    period = cycle_end - cycle_start
    
    states = []
    for t in range(cycle_start, cycle_end):
        if t in alive_cells:
            grid = grid_to_list(alive_cells[t])
            states.append(grid)
        else:
            states.append([[0]*5 for _ in range(5)])
    
    return {
        'pattern_id': 1,
        'period': period,
        'states': states
    }

initial_grid = [
    [0, 1, 0, 1, 0],
    [1, 0, 1, 0, 1],
    [0, 1, 0, 1, 0],
    [1, 0, 1, 0, 1],
    [0, 1, 0, 1, 0]
]

asp_program = create_asp_program(initial_grid)
solution = solve_game_of_life(asp_program)

if solution:
    cycle = find_first_cycle(solution['alive_cells'], solution['same_states'])
    output = {"stable_patterns": [cycle]}
    print(json.dumps(output, indent=2))
else:
    print(json.dumps({"error": "No solution exists", "reason": "Could not simulate Game of Life"}))
