import clingo
import json

ctl = clingo.Control(["1"])

program = """
person(0, "Agatha").
person(1, "Butler").
person(2, "Charles").

victim(0).

1 { killed(Killer, 0) : person(Killer, _) } 1.

:- killed(X, Y), not hates(X, Y).

:- killed(X, Y), richer(X, Y).

hates(0, 0).
hates(0, 2).

:- hates(0, X), hates(2, X).

hates(1, X) :- person(X, _), not richer(X, 0).

hates(1, X) :- hates(0, X).

:- person(X, _), person(Y1, _), person(Y2, _), person(Y3, _),
   Y1 != Y2, Y2 != Y3, Y1 != Y3,
   hates(X, Y1), hates(X, Y2), hates(X, Y3).

{ richer(X, Y) : person(X, _), person(Y, _), X != Y }.

:- richer(X, Y), richer(Y, X).
"""

ctl.add("base", [], program)
ctl.ground([("base", [])])

solution = None

def on_model(m):
    global solution
    atoms = m.symbols(atoms=True)
    
    for atom in atoms:
        if atom.name == "killed" and len(atom.arguments) == 2:
            killer_id = atom.arguments[0].number
            
            for atom2 in atoms:
                if atom2.name == "person" and len(atom2.arguments) == 2:
                    if atom2.arguments[0].number == killer_id:
                        killer_name = str(atom2.arguments[1]).strip('"')
                        solution = {
                            "killer": killer_id,
                            "killer_name": killer_name
                        }
                        break

result = ctl.solve(on_model=on_model)

if result.satisfiable and solution:
    print(json.dumps(solution))
else:
    print(json.dumps({"error": "No solution exists"}))
