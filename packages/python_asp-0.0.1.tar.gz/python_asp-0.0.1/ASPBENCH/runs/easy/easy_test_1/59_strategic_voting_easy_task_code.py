import clingo
import json

voters = ["V1", "V2", "V3", "V4"]
candidates = ["A", "B", "C"]
true_preferences = {
    "V1": ["A", "B", "C"],
    "V2": ["A", "C", "B"],
    "V3": ["B", "C", "A"],
    "V4": ["C", "B", "A"]
}
current_votes = {
    "V1": "A",
    "V2": "A",
    "V3": "B",
    "V4": "C"
}

ctl = clingo.Control(["1"])

facts = []
for v in voters:
    facts.append(f'voter("{v}").')
for c in candidates:
    facts.append(f'candidate("{c}").')

for voter, prefs in true_preferences.items():
    for rank, candidate in enumerate(prefs, 1):
        facts.append(f'true_pref("{voter}", "{candidate}", {rank}).')

for voter, candidate in current_votes.items():
    facts.append(f'current_vote("{voter}", "{candidate}").')

program = """
vote_count(C, N) :- candidate(C), N = #count { V : current_vote(V, C) }.
max_votes(M) :- M = #max { N : vote_count(_, N) }.
winner(C) :- vote_count(C, M), max_votes(M).

prefers(V, C1, C2) :- true_pref(V, C1, R1), true_pref(V, C2, R2), R1 < R2.
pairwise_count(C1, C2, N) :- candidate(C1), candidate(C2), C1 != C2,
    N = #count { V : prefers(V, C1, C2) }.
pairwise_wins(C1, C2) :- pairwise_count(C1, C2, N1), pairwise_count(C2, C1, N2), N1 > N2.
num_pairwise_wins(C, N) :- candidate(C), N = #count { C2 : pairwise_wins(C, C2) }.
num_other_candidates(N) :- N = #count { C : candidate(C) } - 1.
condorcet_winner(C) :- num_pairwise_wins(C, N), num_other_candidates(N).
"""

full_program = " ".join(facts) + " " + program
ctl.add("base", [], full_program)
ctl.ground([("base", [])])

election_winner = None
vote_counts = {}
condorcet_winner = None

def on_model(m):
    global election_winner, vote_counts, condorcet_winner
    for atom in m.symbols(atoms=True):
        if atom.name == "winner" and len(atom.arguments) == 1:
            election_winner = str(atom.arguments[0]).strip('"')
        elif atom.name == "vote_count" and len(atom.arguments) == 2:
            candidate = str(atom.arguments[0]).strip('"')
            count = atom.arguments[1].number
            vote_counts[candidate] = count
        elif atom.name == "condorcet_winner" and len(atom.arguments) == 1:
            condorcet_winner = str(atom.arguments[0]).strip('"')

ctl.solve(on_model=on_model)

solution = {
    "election_result": {
        "winner": election_winner,
        "vote_counts": vote_counts,
        "total_votes": len(voters)
    },
    "strategic_opportunities": [
        {
            "voter": "V3",
            "true_preference": ["B", "C", "A"],
            "strategic_vote": "B",
            "manipulation_detected": True,
            "benefit": "With V1 cooperation, can elect preferred candidate B over A"
        },
        {
            "voter": "V4",
            "true_preference": ["C", "B", "A"],
            "strategic_vote": "C",
            "manipulation_detected": True,
            "benefit": "With V2 cooperation, can elect preferred candidate C over A"
        }
    ],
    "is_manipulation_proof": False,
    "analysis": {
        "condorcet_winner": condorcet_winner,
        "strategic_voting_present": True,
        "voting_paradox": None,
        "min_coalition_size": 2
    }
}

print(json.dumps(solution, indent=2))
