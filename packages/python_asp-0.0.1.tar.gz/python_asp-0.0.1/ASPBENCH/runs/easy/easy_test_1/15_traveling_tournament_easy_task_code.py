import clingo
import json
import math

teams = ["A", "B", "C", "D"]
locations = {
    "A": (0, 0),
    "B": (3, 4),
    "C": (6, 0),
    "D": (2, 8)
}

def euclidean_distance(loc1, loc2):
    return math.sqrt((loc1[0] - loc2[0])**2 + (loc1[1] - loc2[1])**2)

distances = {}
for t1 in teams:
    for t2 in teams:
        if t1 != t2:
            dist = euclidean_distance(locations[t1], locations[t2])
            distances[(t1, t2)] = round(dist, 1)

asp_facts = []
for team in teams:
    asp_facts.append(f'team("{team}").')

for r in range(6):
    asp_facts.append(f'round({r}).')

for (t1, t2), dist in distances.items():
    asp_facts.append(f'distance("{t1}", "{t2}", {int(dist * 10)}).')

asp_program = "\n".join(asp_facts)

asp_rules = """
team_pair(T1, T2) :- team(T1), team(T2), T1 != T2.

{ match(Home, Away, R) : team_pair(Home, Away) } :- round(R).

:- team_pair(Home, Away), #count { R : match(Home, Away, R) } != 1.

:- round(R), #count { Home, Away : match(Home, Away, R) } != 2.

plays_home(T, R) :- match(T, _, R).
plays_away(T, R) :- match(_, T, R).

:- team(T), round(R), not plays_home(T, R), not plays_away(T, R).
:- team(T), round(R), plays_home(T, R), plays_away(T, R).

:- team(T), round(R), R <= 3, 
   plays_home(T, R), plays_home(T, R+1), plays_home(T, R+2).

:- team(T), round(R), R <= 3,
   plays_away(T, R), plays_away(T, R+1), plays_away(T, R+2).

match_distance(Home, Away, R, Dist) :- match(Home, Away, R), 
                                        distance(Home, Away, Dist).

total_distance(Total) :- Total = #sum { Dist, Home, Away, R : 
                                        match_distance(Home, Away, R, Dist) }.

:- total_distance(Total), Total > 750.

#show match/3.
#show total_distance/1.
"""

full_program = asp_program + "\n" + asp_rules

ctl = clingo.Control(["1"])
ctl.add("base", [], full_program)
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    
    matches = []
    
    for atom in model.symbols(atoms=True):
        if atom.name == "match" and len(atom.arguments) == 3:
            home = str(atom.arguments[0]).strip('"')
            away = str(atom.arguments[1]).strip('"')
            round_num = atom.arguments[2].number
            matches.append((round_num, home, away))
    
    schedule = [[] for _ in range(6)]
    for round_num, home, away in matches:
        schedule[round_num].append({"home": home, "away": away})
    
    actual_total = 0
    for round_matches in schedule:
        for match in round_matches:
            home = match["home"]
            away = match["away"]
            dist = distances.get((home, away), 0)
            actual_total += dist
    
    solution_data = {
        "schedule": schedule,
        "total_distance": int(actual_total),
        "feasible": True
    }

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    print(json.dumps(solution_data, indent=2))
else:
    print(json.dumps({"error": "No solution exists", "feasible": False}))
