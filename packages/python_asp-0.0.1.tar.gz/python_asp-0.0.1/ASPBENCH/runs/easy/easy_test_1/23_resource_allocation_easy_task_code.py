import clingo
import json

program = """
task(0, 50).
task(1, 40).
task(2, 60).
task(3, 35).
task(4, 70).
task(5, 45).

requires(0, a, 30).
requires(0, b, 20).
requires(0, c, 10).

requires(1, a, 25).
requires(1, b, 15).
requires(1, c, 15).

requires(2, a, 20).
requires(2, b, 30).
requires(2, c, 20).

requires(3, a, 15).
requires(3, b, 25).
requires(3, c, 10).

requires(4, a, 40).
requires(4, b, 10).
requires(4, c, 25).

requires(5, a, 20).
requires(5, b, 20).
requires(5, c, 15).

capacity(a, 100).
capacity(b, 80).
capacity(c, 60).

{ selected(T) } :- task(T, _).

:- capacity(R, Cap), 
   #sum { Amt,T : selected(T), requires(T, R, Amt) } > Cap.

total_value(V) :- V = #sum { Val,T : selected(T), task(T, Val) }.

:- total_value(V), V < 180.

resource_used(R, Used) :- capacity(R, _), 
                          Used = #sum { Amt,T : selected(T), requires(T, R, Amt) }.

#show selected/1.
#show total_value/1.
#show resource_used/2.
"""

ctl = clingo.Control(["1"])
ctl.add("base", [], program)
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    
    selected_tasks = []
    total_value = 0
    resource_usage = {}
    
    for atom in model.symbols(atoms=True):
        if atom.name == "selected" and len(atom.arguments) == 1:
            task_id = atom.arguments[0].number
            selected_tasks.append(task_id)
        elif atom.name == "total_value" and len(atom.arguments) == 1:
            total_value = atom.arguments[0].number
        elif atom.name == "resource_used" and len(atom.arguments) == 2:
            resource = str(atom.arguments[0])
            amount = atom.arguments[1].number
            resource_usage[f"resource_{resource}"] = amount
    
    selected_tasks.sort()
    
    solution_data = {
        "selected_tasks": selected_tasks,
        "total_value": total_value,
        "resource_usage": resource_usage
    }

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    print(json.dumps(solution_data))
else:
    print(json.dumps({"error": "No solution exists", 
                      "reason": "No task selection satisfies all constraints"}))
