import clingo
import json

asp_program = """
room("A"). room("B"). room("C"). room("D"). 
room("E"). room("F"). room("G"). room("H").

key("key1"). key("key2"). key("key3").

start("A").

requirement("null"). requirement("key1"). requirement("key2"). requirement("key3").

room_pair(R1, R2) :- room(R1), room(R2), R1 != R2.

0 { conn(R1, R2, Req) : requirement(Req) } 1 :- room_pair(R1, R2).

1 { key_at(K, R) : room(R) } 1 :- key(K).

reachable("A", "none").

reachable(R2, KeyState) :- reachable(R1, KeyState), conn(R1, R2, "null").

reachable(R2, KeyState) :- reachable(R1, KeyState), conn(R1, R2, K),
                           key(K), K != "null",
                           has_key(K, KeyState).

reachable(R, "key1") :- reachable(R, "none"), key_at("key1", R).
reachable(R, "key2") :- reachable(R, "none"), key_at("key2", R).
reachable(R, "key3") :- reachable(R, "none"), key_at("key3", R).

reachable(R, "key1_key2") :- reachable(R, "key1"), key_at("key2", R).
reachable(R, "key1_key2") :- reachable(R, "key2"), key_at("key1", R).

reachable(R, "key1_key3") :- reachable(R, "key1"), key_at("key3", R).
reachable(R, "key1_key3") :- reachable(R, "key3"), key_at("key1", R).

reachable(R, "key2_key3") :- reachable(R, "key2"), key_at("key3", R).
reachable(R, "key2_key3") :- reachable(R, "key3"), key_at("key2", R).

reachable(R, "all") :- reachable(R, "key1_key2"), key_at("key3", R).
reachable(R, "all") :- reachable(R, "key1_key3"), key_at("key2", R).
reachable(R, "all") :- reachable(R, "key2_key3"), key_at("key1", R).

has_key("key1", "key1").
has_key("key2", "key2").
has_key("key3", "key3").
has_key("key1", "key1_key2"). has_key("key2", "key1_key2").
has_key("key1", "key1_key3"). has_key("key3", "key1_key3").
has_key("key2", "key2_key3"). has_key("key3", "key2_key3").
has_key("key1", "all"). has_key("key2", "all"). has_key("key3", "all").

:- room(R), not reachable(R, _).

:- room(R), R != "A", not conn(_, R, _).

:- not conn("A", _, _).

:- room(R), not conn(R, _, _), not conn(_, R, _).

#show conn/3.
#show key_at/2.
"""

ctl = clingo.Control(["1"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    
    connections = []
    key_locations = {}
    reachable_rooms = set()
    
    for atom in model.symbols(atoms=True):
        if atom.name == "conn" and len(atom.arguments) == 3:
            from_room = str(atom.arguments[0]).strip('"')
            to_room = str(atom.arguments[1]).strip('"')
            requires = str(atom.arguments[2]).strip('"')
            
            connections.append({
                "from": from_room,
                "to": to_room,
                "requires": None if requires == "null" else requires
            })
        
        elif atom.name == "key_at" and len(atom.arguments) == 2:
            key_name = str(atom.arguments[0]).strip('"')
            room_name = str(atom.arguments[1]).strip('"')
            key_locations[key_name] = room_name
        
        elif atom.name == "reachable" and len(atom.arguments) == 2:
            room_name = str(atom.arguments[0]).strip('"')
            reachable_rooms.add(room_name)
    
    all_rooms = ["A", "B", "C", "D", "E", "F", "G", "H"]
    reachability_verified = all(room in reachable_rooms for room in all_rooms)
    
    solution_data = {
        "rooms": all_rooms,
        "connections": connections,
        "item_locations": key_locations,
        "reachability_verified": reachability_verified
    }

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    print(json.dumps(solution_data, indent=2))
else:
    print(json.dumps({"error": "No solution exists", 
                      "reason": "Could not find valid room layout"}))
