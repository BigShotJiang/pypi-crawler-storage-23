import clingo
import json


def calculate_wins(die1, die2):
    """Count how many times die1 beats die2 out of 36 matchups"""
    wins = 0
    for face1 in die1:
        for face2 in die2:
            if face1 > face2:
                wins += 1
    return wins


asp_program = """
die(a; b; c).
position(1..6).
value(0..6).

{ face(D, P, V) : value(V) } = 1 :- die(D), position(P).

beats_in_matchup(D1, D2, P1, P2) :- 
    face(D1, P1, V1), 
    face(D2, P2, V2), 
    D1 != D2,
    V1 > V2.

win_count(D1, D2, Count) :- 
    die(D1), die(D2), D1 != D2,
    Count = #count { P1, P2 : beats_in_matchup(D1, D2, P1, P2) }.

:- win_count(a, b, Count), Count <= 18.
:- win_count(b, c, Count), Count <= 18.
:- win_count(c, a, Count), Count <= 18.

#show face/3.
#show win_count/3.
"""

ctl = clingo.Control(["1"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

solution_data = None


def on_model(model):
    global solution_data
    
    dice_faces = {"a": {}, "b": {}, "c": {}}
    win_counts = {}
    
    for atom in model.symbols(atoms=True):
        if atom.name == "face":
            die_name = str(atom.arguments[0])
            position = atom.arguments[1].number
            value = atom.arguments[2].number
            dice_faces[die_name][position] = value
            
        elif atom.name == "win_count":
            d1 = str(atom.arguments[0])
            d2 = str(atom.arguments[1])
            count = atom.arguments[2].number
            win_counts[f"{d1}_vs_{d2}"] = count
    
    dice = {}
    for die_name in ["a", "b", "c"]:
        dice[die_name.upper()] = [dice_faces[die_name][i] for i in range(1, 7)]
    
    solution_data = {
        "dice": dice,
        "win_counts": win_counts
    }


result = ctl.solve(on_model=on_model)

if result.satisfiable and solution_data:
    dice_a = solution_data['dice']['A']
    dice_b = solution_data['dice']['B']
    dice_c = solution_data['dice']['C']
    
    wins_a_vs_b = calculate_wins(dice_a, dice_b)
    wins_b_vs_c = calculate_wins(dice_b, dice_c)
    wins_c_vs_a = calculate_wins(dice_c, dice_a)
    
    output = {
        "dice": {
            "A": dice_a,
            "B": dice_b,
            "C": dice_c
        },
        "win_probabilities": {
            "A_beats_B": round(wins_a_vs_b / 36, 3),
            "B_beats_C": round(wins_b_vs_c / 36, 3),
            "C_beats_A": round(wins_c_vs_a / 36, 3)
        }
    }
    
    print(json.dumps(output, indent=2))
else:
    print(json.dumps({"error": "No solution exists", 
                      "reason": "No valid nontransitive dice configuration found"}))
