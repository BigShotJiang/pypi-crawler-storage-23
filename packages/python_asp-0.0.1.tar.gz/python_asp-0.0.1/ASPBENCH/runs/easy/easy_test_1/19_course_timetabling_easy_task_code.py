import clingo
import json

program = """
course(0, 0, 25, "Math").
course(1, 1, 20, "Physics").
course(2, 2, 30, "Chemistry").
course(3, 1, 15, "Biology").
course(4, 0, 35, "Computer Science").

room(0, 40).
room(1, 25).
room(2, 20).

time_slot(0).
time_slot(1).
time_slot(2).
time_slot(3).

teacher_available(0, 0).
teacher_available(0, 1).
teacher_available(0, 2).
teacher_available(1, 1).
teacher_available(1, 2).
teacher_available(1, 3).
teacher_available(2, 0).
teacher_available(2, 2).
teacher_available(2, 3).

1 { assigned(C, R, T) : room(R, _), time_slot(T) } 1 :- 
    course(C, _, _, _).

:- assigned(C1, R, T), assigned(C2, R, T), C1 != C2.

:- assigned(C1, _, T), assigned(C2, _, T), 
   course(C1, Teacher, _, _), course(C2, Teacher, _, _), 
   C1 != C2.

:- assigned(C, R, _), course(C, _, Students, _), room(R, Capacity), 
   Students > Capacity.

:- assigned(C, _, T), course(C, Teacher, _, _), 
   not teacher_available(Teacher, T).

#show assigned/3.
"""

ctl = clingo.Control(["1"])
ctl.add("base", [], program)
ctl.ground([("base", [])])

solution = None

def on_model(m):
    global solution
    solution = {"assignments": []}
    
    for atom in m.symbols(atoms=True):
        if atom.name == "assigned" and len(atom.arguments) == 3:
            course = atom.arguments[0].number
            room = atom.arguments[1].number
            time_slot = atom.arguments[2].number
            
            solution["assignments"].append({
                "course": course,
                "room": room,
                "time_slot": time_slot
            })
    
    solution["assignments"].sort(key=lambda x: x["course"])

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    print(json.dumps(solution, indent=2))
else:
    error_solution = {
        "error": "No solution exists", 
        "reason": "Constraints cannot be satisfied"
    }
    print(json.dumps(error_solution, indent=2))
