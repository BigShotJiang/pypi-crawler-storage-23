import clingo
import json

program = """
house(1..5).

color_val(red; green; white; yellow; blue).
nationality_val(brit; swede; dane; norwegian; german).
drink_val(tea; coffee; milk; beer; water).
cigarette_val(pall_mall; dunhill; blends; blue_master; prince).
pet_val(dog; birds; cats; horse; zebra).

1 { color(H, C) : color_val(C) } 1 :- house(H).
1 { nationality(H, N) : nationality_val(N) } 1 :- house(H).
1 { drink(H, D) : drink_val(D) } 1 :- house(H).
1 { cigarette(H, C) : cigarette_val(C) } 1 :- house(H).
1 { pet(H, P) : pet_val(P) } 1 :- house(H).

1 { color(H, C) : house(H) } 1 :- color_val(C).
1 { nationality(H, N) : house(H) } 1 :- nationality_val(N).
1 { drink(H, D) : house(H) } 1 :- drink_val(D).
1 { cigarette(H, C) : house(H) } 1 :- cigarette_val(C).
1 { pet(H, P) : house(H) } 1 :- pet_val(P).

:- nationality(H, brit), not color(H, red).
:- nationality(H, swede), not pet(H, dog).
:- nationality(H, dane), not drink(H, tea).
:- color(H1, green), color(H2, white), H2 != H1 + 1.
:- color(H, green), not drink(H, coffee).
:- cigarette(H, pall_mall), not pet(H, birds).
:- color(H, yellow), not cigarette(H, dunhill).
:- not drink(3, milk).
:- not nationality(1, norwegian).
:- cigarette(H1, blends), not pet(H1-1, cats), not pet(H1+1, cats).
:- pet(H1, horse), not cigarette(H1-1, dunhill), not cigarette(H1+1, dunhill).
:- cigarette(H, blue_master), not drink(H, beer).
:- nationality(H, german), not cigarette(H, prince).
:- nationality(H1, norwegian), not color(H1-1, blue), not color(H1+1, blue).
:- cigarette(H1, blends), not drink(H1-1, water), not drink(H1+1, water).

#show color/2.
#show nationality/2.
#show drink/2.
#show cigarette/2.
#show pet/2.
"""

ctl = clingo.Control(["1"])
ctl.add("base", [], program)
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    houses = {i: {} for i in range(1, 6)}
    
    for atom in model.symbols(atoms=True):
        if atom.name == "color" and len(atom.arguments) == 2:
            house_num = atom.arguments[0].number
            color_name = str(atom.arguments[1])
            houses[house_num]["color"] = color_name.capitalize()
            
        elif atom.name == "nationality" and len(atom.arguments) == 2:
            house_num = atom.arguments[0].number
            nat_name = str(atom.arguments[1])
            houses[house_num]["nationality"] = nat_name.capitalize()
            
        elif atom.name == "drink" and len(atom.arguments) == 2:
            house_num = atom.arguments[0].number
            drink_name = str(atom.arguments[1])
            houses[house_num]["drink"] = drink_name.capitalize()
            
        elif atom.name == "cigarette" and len(atom.arguments) == 2:
            house_num = atom.arguments[0].number
            cig_name = str(atom.arguments[1])
            if cig_name == "pall_mall":
                cig_name = "Pall Mall"
            elif cig_name == "blue_master":
                cig_name = "Blue Master"
            else:
                cig_name = cig_name.capitalize()
            houses[house_num]["cigarette"] = cig_name
            
        elif atom.name == "pet" and len(atom.arguments) == 2:
            house_num = atom.arguments[0].number
            pet_name = str(atom.arguments[1])
            houses[house_num]["pet"] = pet_name.capitalize()
    
    solution_data = houses

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    zebra_owner = None
    for house_num, attrs in solution_data.items():
        if attrs.get("pet") == "Zebra":
            zebra_owner = attrs.get("nationality")
            break
    
    solution_array = []
    for house_num in range(1, 6):
        house_data = {
            "house": house_num,
            "color": solution_data[house_num]["color"],
            "nationality": solution_data[house_num]["nationality"],
            "drink": solution_data[house_num]["drink"],
            "cigarette": solution_data[house_num]["cigarette"],
            "pet": solution_data[house_num]["pet"]
        }
        solution_array.append(house_data)
    
    output = {
        "solution": solution_array,
        "zebra_owner": zebra_owner
    }
    
    print(json.dumps(output, indent=2))
else:
    print(json.dumps({"error": "No solution exists", 
                      "reason": "Constraints are unsatisfiable"}))
