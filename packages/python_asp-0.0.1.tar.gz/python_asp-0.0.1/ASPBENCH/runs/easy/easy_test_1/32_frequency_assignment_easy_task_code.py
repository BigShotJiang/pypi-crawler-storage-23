import clingo
import json

def solve_frequency_assignment():
    ctl = clingo.Control(["1"])
    
    program = """
    transmitter("A"). transmitter("B"). transmitter("C").
    transmitter("D"). transmitter("E"). transmitter("F").
    
    frequency(1..5).
    
    interferes("A", "B"). interferes("B", "A").
    interferes("A", "C"). interferes("C", "A").
    interferes("B", "D"). interferes("D", "B").
    interferes("B", "E"). interferes("E", "B").
    interferes("C", "D"). interferes("D", "C").
    interferes("C", "F"). interferes("F", "C").
    interferes("D", "E"). interferes("E", "D").
    interferes("E", "F"). interferes("F", "E").
    
    1 { assigned(T, F) : frequency(F) } 1 :- transmitter(T).
    
    :- interferes(T1, T2), assigned(T1, F), assigned(T2, F).
    
    :- interferes(T1, T2), assigned(T1, F1), assigned(T2, F2), 
       |F1 - F2| = 1.
    
    used(F) :- assigned(_, F).
    
    frequencies_used(N) :- N = #count { F : used(F) }.
    
    :- frequencies_used(N), N > 3.
    """
    
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution = None
    
    def on_model(model):
        nonlocal solution
        atoms = model.symbols(atoms=True)
        
        assignments = []
        frequencies_used_count = 0
        
        for atom in atoms:
            if atom.name == "assigned" and len(atom.arguments) == 2:
                transmitter = str(atom.arguments[0]).strip('"')
                frequency = atom.arguments[1].number
                assignments.append({
                    "transmitter": transmitter,
                    "frequency": frequency
                })
            elif atom.name == "frequencies_used" and len(atom.arguments) == 1:
                frequencies_used_count = atom.arguments[0].number
        
        assignments.sort(key=lambda x: x["transmitter"])
        
        solution = {
            "assignments": assignments,
            "frequencies_used": frequencies_used_count
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution
    else:
        return {
            "error": "No solution exists",
            "reason": "Constraints cannot be satisfied"
        }

solution = solve_frequency_assignment()
print(json.dumps(solution, indent=2))
