import clingo
import json

program = """
team("A"). team("B"). team("C"). team("D"). team("E").

beat("A", "B").
beat("B", "C").
beat("C", "A").
beat("A", "D").
beat("D", "E").
beat("E", "C").
beat("B", "E").
beat("D", "C").
beat("A", "E").
beat("B", "D").

position(1..5).

1 { rank(T, R) : position(R) } 1 :- team(T).

1 { rank(T, R) : team(T) } 1 :- position(R).

violation(X, Y) :- beat(X, Y), rank(X, RX), rank(Y, RY), RY < RX.

#minimize { 1,X,Y : violation(X,Y) }.

#show rank/2.
"""

ctl = clingo.Control(["0"])
ctl.add("base", [], program)
ctl.ground([("base", [])])

solution_data = None
best_violations = float('inf')

def on_model(model):
    global solution_data, best_violations
    
    ranking_dict = {}
    for atom in model.symbols(atoms=True):
        if atom.name == "rank" and len(atom.arguments) == 2:
            team = str(atom.arguments[0]).strip('"')
            rank = atom.arguments[1].number
            ranking_dict[rank] = team
    
    ranking = [ranking_dict[i] for i in sorted(ranking_dict.keys())]
    
    violations = 0
    for atom in model.symbols(shown=False, atoms=True):
        if atom.name == "violation":
            violations += 1
    
    if violations < best_violations:
        best_violations = violations
        solution_data = {
            "ranking": ranking,
            "violations": violations,
            "valid": len(ranking) == 5 and len(set(ranking)) == 5
        }

result = ctl.solve(on_model=on_model)

if result.satisfiable and solution_data:
    print(json.dumps(solution_data))
else:
    print(json.dumps({"error": "No solution found", "valid": False}))
