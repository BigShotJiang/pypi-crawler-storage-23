import clingo
import json

initial_piles = [3, 4, 5]
initial_nim_sum = initial_piles[0] ^ initial_piles[1] ^ initial_piles[2]

asp_program = """
pile(1, 3).
pile(2, 4).
pile(3, 5).

stones_to_remove(P, S) :- pile(P, N), S = 1..N.

1 { move(P, S) : stones_to_remove(P, S) } 1.

resulting_pile(P, N - S) :- move(P, S), pile(P, N).
resulting_pile(P, N) :- pile(P, N), not move(P, _).

#show move/2.
#show resulting_pile/2.
"""

ctl = clingo.Control(["0"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

all_moves = []

def on_model(model):
    move_info = {}
    resulting_piles = {}
    
    for atom in model.symbols(atoms=True):
        if atom.name == "move" and len(atom.arguments) == 2:
            pile_idx = atom.arguments[0].number
            stones_removed = atom.arguments[1].number
            move_info = {"pile": pile_idx, "stones": stones_removed}
        
        elif atom.name == "resulting_pile" and len(atom.arguments) == 2:
            pile_idx = atom.arguments[0].number
            remaining = atom.arguments[1].number
            resulting_piles[pile_idx] = remaining
    
    if move_info:
        nim_sum_after = 0
        result_list = []
        for i in range(1, 4):
            if i in resulting_piles:
                result_list.append(resulting_piles[i])
                nim_sum_after ^= resulting_piles[i]
        
        move_info["resulting_piles"] = result_list
        move_info["nim_sum_after"] = nim_sum_after
        all_moves.append(move_info)

ctl.solve(on_model=on_model)

optimal_moves = [move for move in all_moves if move["nim_sum_after"] == 0]

output = {
    "game_state": "winning" if initial_nim_sum != 0 else "losing",
    "optimal_moves": [
        {
            "pile": move["pile"],
            "stones": move["stones"],
            "resulting_piles": move["resulting_piles"]
        }
        for move in optimal_moves
    ],
    "nim_sum": initial_nim_sum,
    "analysis": {
        "is_winning_position": initial_nim_sum != 0,
        "strategy": "From a winning position (nim-sum ≠ 0), the optimal strategy is to make a move that results in nim-sum = 0, forcing the opponent into a losing position. From pile 1 with 3 stones, removing 2 stones leaves [1, 4, 5] with nim-sum = 0.",
        "after_optimal_move": {
            "nim_sum": 0,
            "position": "losing"
        }
    }
}

print(json.dumps(output, indent=2))
