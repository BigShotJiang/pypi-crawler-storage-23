import clingo
import json

def solve_auction():
    ctl = clingo.Control(["1"])
    
    program = """
    bid(1, "A", 100).
    bid_item(1, "item1"). bid_item(1, "item2").
    
    bid(2, "A", 50).
    bid_item(2, "item3").
    
    bid(3, "B", 120).
    bid_item(3, "item2"). bid_item(3, "item3").
    
    bid(4, "B", 80).
    bid_item(4, "item4"). bid_item(4, "item5").
    
    bid(5, "C", 150).
    bid_item(5, "item1"). bid_item(5, "item3"). bid_item(5, "item5").
    
    bid(6, "D", 40).
    bid_item(6, "item4").
    
    item("item1"; "item2"; "item3"; "item4"; "item5").
    
    { win(BidID) } :- bid(BidID, _, _).
    
    allocated(Item, BidID) :- win(BidID), bid_item(BidID, Item).
    
    :- allocated(Item, BidID1), allocated(Item, BidID2), BidID1 != BidID2.
    
    total_revenue(Total) :- Total = #sum { Price, BidID : win(BidID), 
                                           bid(BidID, _, Price) }.
    
    :- total_revenue(Total), Total < 230.
    
    #show win/1.
    #show allocated/2.
    #show total_revenue/1.
    """
    
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution_data = None
    
    def on_model(model):
        nonlocal solution_data
        atoms = model.symbols(atoms=True)
        
        winning_bids = []
        item_allocation = {}
        total_rev = 0
        
        winning_bid_ids = set()
        for atom in atoms:
            if atom.name == "win" and len(atom.arguments) == 1:
                bid_id = atom.arguments[0].number
                winning_bid_ids.add(bid_id)
            elif atom.name == "total_revenue" and len(atom.arguments) == 1:
                total_rev = atom.arguments[0].number
        
        bids_data = {
            1: {"bidder": "A", "items": ["item1", "item2"], "price": 100},
            2: {"bidder": "A", "items": ["item3"], "price": 50},
            3: {"bidder": "B", "items": ["item2", "item3"], "price": 120},
            4: {"bidder": "B", "items": ["item4", "item5"], "price": 80},
            5: {"bidder": "C", "items": ["item1", "item3", "item5"], 
                "price": 150},
            6: {"bidder": "D", "items": ["item4"], "price": 40}
        }
        
        for bid_id in sorted(winning_bid_ids):
            bid_info = bids_data[bid_id]
            winning_bids.append({
                "bidder": bid_info["bidder"],
                "items": bid_info["items"],
                "price": bid_info["price"]
            })
            
            for item in bid_info["items"]:
                item_allocation[item] = bid_info["bidder"]
        
        all_items = ["item1", "item2", "item3", "item4", "item5"]
        for item in all_items:
            if item not in item_allocation:
                item_allocation[item] = None
        
        solution_data = {
            "winning_bids": winning_bids,
            "total_revenue": total_rev,
            "item_allocation": item_allocation
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable and solution_data:
        return solution_data
    else:
        return {"error": "No solution exists", 
                "reason": "Could not find allocation meeting revenue target"}

solution = solve_auction()
print(json.dumps(solution, indent=2))
