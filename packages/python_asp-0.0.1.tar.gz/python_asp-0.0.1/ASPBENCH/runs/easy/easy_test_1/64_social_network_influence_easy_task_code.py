import clingo
import json

users = [
    ("user1", 0.8, 100, "influencer"),
    ("user2", 0.3, 50, "regular"),
    ("user3", 0.5, 80, "regular"),
    ("user4", 0.9, 150, "influencer"),
    ("user5", 0.4, 60, "regular"),
    ("user6", 0.6, 90, "regular"),
    ("user7", 0.7, 120, "influencer"),
    ("user8", 0.2, 40, "regular"),
]

connections = [
    ("user1", "user2", 0.6),
    ("user1", "user3", 0.7),
    ("user2", "user3", 0.4),
    ("user2", "user5", 0.5),
    ("user3", "user4", 0.3),
    ("user4", "user5", 0.8),
    ("user4", "user6", 0.6),
    ("user5", "user7", 0.5),
    ("user6", "user7", 0.7),
    ("user7", "user8", 0.4),
]

budget = 300
max_seeds = 2

asp_program = """
% Facts from instance data
"""

for user_id, weight, cost, category in users:
    asp_program += f'user("{user_id}", {int(weight*100)}, {cost}, "{category}").\n'

for from_user, to_user, strength in connections:
    asp_program += f'connection("{from_user}", "{to_user}", {int(strength*100)}).\n'

asp_program += f"budget({budget}).\n"
asp_program += f"max_seeds({max_seeds}).\n"

asp_program += """
{ seed(U) : user(U, _, _, _) } MaxSeeds :- max_seeds(MaxSeeds).

:- #sum { Cost, U : seed(U), user(U, _, Cost, _) } > Budget, budget(Budget).

directly_influenced(To) :- seed(From), connection(From, To, Strength), Strength >= 30, not seed(To).

secondary_influenced(To) :- directly_influenced(From), connection(From, To, Strength), 
                             Strength >= 20, not seed(To), not directly_influenced(To).

reached(U) :- seed(U).
reached(U) :- directly_influenced(U).
reached(U) :- secondary_influenced(U).

#maximize { 1, U : reached(U) }.
"""

ctl = clingo.Control(["0"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

best_solution = None
best_reach = 0

def on_model(model):
    global best_solution, best_reach
    
    seeds = []
    direct = []
    secondary = []
    reached = []
    
    for atom in model.symbols(atoms=True):
        if atom.name == "seed" and len(atom.arguments) == 1:
            user_id = str(atom.arguments[0]).strip('"')
            seeds.append(user_id)
        elif atom.name == "directly_influenced" and len(atom.arguments) == 1:
            user_id = str(atom.arguments[0]).strip('"')
            direct.append(user_id)
        elif atom.name == "secondary_influenced" and len(atom.arguments) == 1:
            user_id = str(atom.arguments[0]).strip('"')
            secondary.append(user_id)
        elif atom.name == "reached" and len(atom.arguments) == 1:
            user_id = str(atom.arguments[0]).strip('"')
            reached.append(user_id)
    
    current_reach = len(reached)
    if current_reach >= best_reach:
        best_reach = current_reach
        best_solution = {
            'seeds': seeds,
            'direct': direct,
            'secondary': secondary,
            'reached': reached
        }

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    user_data = {uid: (weight, cost, cat) for uid, weight, cost, cat in users}
    conn_data = {(f, t): s for f, t, s in connections}
    
    total_budget_used = sum(user_data[seed][1] for seed in best_solution['seeds'])
    total_users = len(users)
    total_reach = len(best_solution['reached'])
    coverage_ratio = total_reach / total_users
    efficiency_score = total_reach / total_budget_used if total_budget_used > 0 else 0
    
    cascade_depth = 1
    if best_solution['direct']:
        cascade_depth = 2
    if best_solution['secondary']:
        cascade_depth = 3
    
    selected_seeds_info = []
    for seed in best_solution['seeds']:
        weight, cost, category = user_data[seed]
        seed_reach = 1
        for user in best_solution['direct']:
            if (seed, user) in conn_data and conn_data[(seed, user)] >= 0.3:
                seed_reach += 1
        
        selected_seeds_info.append({
            "user_id": seed,
            "cost": cost,
            "expected_reach": round(seed_reach + weight * 2, 1)
        })
    
    all_strengths = []
    for seed in best_solution['seeds']:
        for user in best_solution['direct']:
            if (seed, user) in conn_data:
                all_strengths.append(conn_data[(seed, user)])
    for direct_user in best_solution['direct']:
        for user in best_solution['secondary']:
            if (direct_user, user) in conn_data:
                all_strengths.append(conn_data[(direct_user, user)])
    
    influence_probability = sum(all_strengths) / len(all_strengths) if all_strengths else 0
    
    output = {
        "selected_seeds": selected_seeds_info,
        "cascade_analysis": {
            "total_budget_used": total_budget_used,
            "direct_influence": sorted(best_solution['direct']),
            "secondary_influence": sorted(best_solution['secondary']),
            "total_reach": total_reach,
            "influence_probability": round(influence_probability, 2)
        },
        "network_metrics": {
            "coverage_ratio": round(coverage_ratio, 3),
            "efficiency_score": round(efficiency_score, 3),
            "cascade_depth": cascade_depth
        }
    }
    
    print(json.dumps(output, indent=2))
else:
    print(json.dumps({"error": "No solution exists", "reason": "Constraints cannot be satisfied"}))
