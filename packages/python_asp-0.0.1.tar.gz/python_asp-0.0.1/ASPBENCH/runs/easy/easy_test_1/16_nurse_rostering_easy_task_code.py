import clingo
import json

def solve_nurse_scheduling():
    program = """
    nurse(1..4).
    day(1..7).
    shift(1..3).
    
    coverage(1, 2).
    coverage(2, 1).
    coverage(3, 1).
    
    weekend(6).
    weekend(7).
    
    0 { assigned(N, D, S) : shift(S) } 1 :- nurse(N), day(D).
    
    :- shift(S), day(D), coverage(S, Required),
       #count { N : assigned(N, D, S) } != Required.
    
    :- assigned(N, D, 3), assigned(N, D+1, 1), day(D), D < 7.
    
    works(N, D) :- assigned(N, D, _).
    
    worked_last_n(N, D, 1) :- works(N, D).
    worked_last_n(N, D, K+1) :- worked_last_n(N, D, K), works(N, D-K), K < 7, D > K.
    
    :~ worked_last_n(N, D, 4). [1@1, N, D]
    :~ worked_last_n(N, D, 5). [1@1, N, D]
    :~ worked_last_n(N, D, 6). [1@1, N, D]
    :~ worked_last_n(N, D, 7). [1@1, N, D]
    
    total_shifts(N, Count) :- nurse(N), Count = #count { D, S : assigned(N, D, S) }.
    
    :~ total_shifts(N, Count), Count < 6. [6-Count@1, N]
    :~ total_shifts(N, Count), Count > 8. [Count-8@1, N]
    
    works_weekend(N) :- assigned(N, D, _), weekend(D).
    weekend_nurses_count(Count) :- Count = #count { N : works_weekend(N) }.
    
    :~ weekend_nurses_count(Count), Count < 2. [1@1]
    
    #show assigned/3.
    """
    
    ctl = clingo.Control(["1"])
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution_data = None
    
    def on_model(model):
        nonlocal solution_data
        atoms = model.symbols(atoms=True)
        
        assignments = {}
        
        for atom in atoms:
            if atom.name == "assigned" and len(atom.arguments) == 3:
                nurse = atom.arguments[0].number
                day = atom.arguments[1].number
                shift = atom.arguments[2].number
                
                if day not in assignments:
                    assignments[day] = {1: [], 2: [], 3: []}
                assignments[day][shift].append(nurse)
        
        roster = []
        for day in range(1, 8):
            day_schedule = []
            for shift in range(1, 4):
                if day in assignments and shift in assignments[day]:
                    nurses = sorted(assignments[day][shift])
                else:
                    nurses = []
                day_schedule.append(nurses)
            roster.append(day_schedule)
        
        coverage_met = True
        required = {1: 2, 2: 1, 3: 1}
        for day_schedule in roster:
            for shift_idx, nurses in enumerate(day_schedule):
                shift = shift_idx + 1
                if len(nurses) != required[shift]:
                    coverage_met = False
                    break
        
        violations = model.cost[0] if hasattr(model, 'cost') and model.cost else 0
        
        solution_data = {
            "roster": roster,
            "violations": violations,
            "coverage_met": coverage_met
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution_data
    else:
        return {"error": "No solution exists", "reason": "Constraints are unsatisfiable"}

solution = solve_nurse_scheduling()
print(json.dumps(solution, indent=2))
