import clingo
import json

asp_program = """
vertex(0..5).

edge(0,1). edge(0,2).
edge(1,2). edge(1,3). edge(1,4).
edge(2,1). edge(2,3). edge(2,4).
edge(3,4). edge(3,5).
edge(4,3). edge(4,5).

position(0..5).

1 { at_position(V, P) : position(P) } 1 :- vertex(V).
1 { at_position(V, P) : vertex(V) } 1 :- position(P).

:- not at_position(0, 0).
:- not at_position(5, 5).

next_in_path(V1, V2) :- at_position(V1, P), at_position(V2, P+1), 
                        position(P), P < 5.

:- next_in_path(V1, V2), not edge(V1, V2).
"""

ctl = clingo.Control(["0"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

all_paths = []

def on_model(model):
    position_map = {}
    for atom in model.symbols(atoms=True):
        if atom.name == "at_position" and len(atom.arguments) == 2:
            vertex = atom.arguments[0].number
            position = atom.arguments[1].number
            position_map[position] = vertex
    
    path = [position_map[p] for p in sorted(position_map.keys())]
    all_paths.append(path)

result = ctl.solve(on_model=on_model)

output = {
    "paths": all_paths,
    "count": len(all_paths),
    "exists": len(all_paths) > 0
}

print(json.dumps(output))
