import clingo
import json

program = """
vertex(1). vertex(2). vertex(3). vertex(4). vertex(5). vertex(6).

edge(1, 2). edge(1, 3).
edge(2, 4). edge(2, 5).
edge(3, 4). edge(3, 6).
edge(4, 2). edge(4, 5).
edge(5, 3). edge(5, 6).
edge(6, 1). edge(6, 4).

{ in_fvs(V) } :- vertex(V).

active_vertex(V) :- vertex(V), not in_fvs(V).

active_edge(V1, V2) :- edge(V1, V2), active_vertex(V1), active_vertex(V2).

reachable(V1, V2) :- active_edge(V1, V2).
reachable(V1, V3) :- reachable(V1, V2), active_edge(V2, V3).

:- active_vertex(V), reachable(V, V).

#minimize { 1,V : in_fvs(V) }.
"""

ctl = clingo.Control()
ctl.add("base", [], program)
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    
    fvs = []
    remaining = []
    
    for atom in model.symbols(atoms=True):
        if atom.name == "in_fvs" and len(atom.arguments) == 1:
            vertex_num = atom.arguments[0].number
            fvs.append(vertex_num)
        elif atom.name == "active_vertex" and len(atom.arguments) == 1:
            vertex_num = atom.arguments[0].number
            remaining.append(vertex_num)
    
    fvs.sort()
    remaining.sort()
    
    solution_data = {
        "feedback_set": fvs,
        "size": len(fvs),
        "remaining_vertices": remaining
    }

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    print(json.dumps(solution_data))
else:
    print(json.dumps({"error": "No solution exists", 
                      "reason": "Problem is unsatisfiable"}))
