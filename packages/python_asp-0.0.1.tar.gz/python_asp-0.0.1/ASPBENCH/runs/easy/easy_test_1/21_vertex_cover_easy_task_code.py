import clingo
import json

program = """
vertex(0). vertex(1). vertex(2). vertex(3). vertex(4). vertex(5).

edge(0, 1).
edge(0, 2).
edge(1, 3).
edge(1, 5).
edge(2, 3).
edge(2, 4).
edge(3, 5).
edge(4, 5).

{ in_cover(V) : vertex(V) }.

:- edge(U, V), not in_cover(U), not in_cover(V).

#minimize { 1,V : in_cover(V) }.
"""

ctl = clingo.Control()
ctl.add("base", [], program)
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    
    vertex_cover = []
    for atom in model.symbols(atoms=True):
        if atom.name == "in_cover" and len(atom.arguments) == 1:
            vertex = atom.arguments[0].number
            vertex_cover.append(vertex)
    
    vertex_cover.sort()
    
    all_edges = [
        [0, 1], [0, 2], [1, 3], [1, 5], 
        [2, 3], [2, 4], [3, 5], [4, 5]
    ]
    
    solution_data = {
        "vertex_cover": vertex_cover,
        "cover_size": len(vertex_cover),
        "covered_edges": all_edges
    }

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    print(json.dumps(solution_data))
else:
    print(json.dumps({"error": "No solution exists", 
                      "reason": "Problem is UNSAT"}))
