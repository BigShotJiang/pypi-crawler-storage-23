import clingo
import json

asp_program = """
exam("E1"). exam("E2"). exam("E3"). exam("E4"). exam("E5"). exam("E6").

student("S1"). student("S2"). student("S3"). student("S4").

enrolled("S1", "E1"). enrolled("S1", "E3"). enrolled("S1", "E5").
enrolled("S2", "E1"). enrolled("S2", "E4"). enrolled("S2", "E6").
enrolled("S3", "E2"). enrolled("S3", "E3"). enrolled("S3", "E6").
enrolled("S4", "E2"). enrolled("S4", "E4"). enrolled("S4", "E5").

time_slot(1). time_slot(2). time_slot(3).

room("R1"). room("R2").
room_capacity("R1", 3). room_capacity("R2", 3).

exam_students(E, Count) :- exam(E), Count = #count { S : enrolled(S, E) }.

1 { scheduled(E, T, R) : time_slot(T), room(R) } 1 :- exam(E).

:- enrolled(S, E1), enrolled(S, E2), E1 != E2,
   scheduled(E1, T, _), scheduled(E2, T, _).

:- scheduled(E, T, R), exam_students(E, Count), room_capacity(R, Cap), 
   Count > Cap.

:- scheduled(E1, T, R), scheduled(E2, T, R), E1 != E2.
"""

ctl = clingo.Control(["1"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

solution = None

def on_model(model):
    global solution
    
    schedule = []
    room_usage = {}
    
    for atom in model.symbols(atoms=True):
        if atom.name == "scheduled" and len(atom.arguments) == 3:
            exam = str(atom.arguments[0]).strip('"')
            time_slot = atom.arguments[1].number
            room = str(atom.arguments[2]).strip('"')
            
            if time_slot == 1:
                day, slot = 1, 1
            elif time_slot == 2:
                day, slot = 1, 2
            else:
                day, slot = 2, 1
            
            schedule.append({
                "exam": exam,
                "day": day,
                "time_slot": slot,
                "room": room,
                "duration": 2
            })
            
            if room not in room_usage:
                room_usage[room] = 0
            room_usage[room] += 1
    
    schedule.sort(key=lambda x: x["exam"])
    
    solution = {
        "schedule": schedule,
        "conflicts_resolved": True,
        "room_utilization": room_usage
    }

result = ctl.solve(on_model=on_model)

if result.satisfiable and solution:
    print(json.dumps(solution, indent=2))
else:
    error_output = {
        "error": "No solution exists",
        "reason": "Unable to schedule all exams without conflicts"
    }
    print(json.dumps(error_output, indent=2))
