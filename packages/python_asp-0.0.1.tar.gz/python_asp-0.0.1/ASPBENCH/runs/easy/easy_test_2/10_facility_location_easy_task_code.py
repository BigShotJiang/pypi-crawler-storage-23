import clingo
import json

customers = [
    (1, 1, 1),
    (2, 2, 4),
    (3, 4, 2),
    (4, 5, 5),
    (5, 7, 1),
    (6, 8, 3),
    (7, 3, 6),
    (8, 6, 4)
]

facilities = [
    ("A", 2, 2, 100),
    ("B", 4, 4, 120),
    ("C", 6, 2, 110),
    ("D", 3, 5, 90),
    ("E", 7, 3, 130)
]

coverage_radius = 3
service_cost_per_unit = 5

def manhattan_distance(x1, y1, x2, y2):
    return abs(x1 - x2) + abs(y1 - y2)

distances = {}
for cust_id, cx, cy in customers:
    for fac_id, fx, fy, _ in facilities:
        dist = manhattan_distance(cx, cy, fx, fy)
        distances[(cust_id, fac_id)] = dist

facts = []

for cust_id, cx, cy in customers:
    facts.append(f'customer({cust_id}, {cx}, {cy}).')

for fac_id, fx, fy, open_cost in facilities:
    facts.append(f'facility("{fac_id}", {fx}, {fy}, {open_cost}).')

for (cid, fid), dist in distances.items():
    if dist <= coverage_radius:
        facts.append(f'can_serve({cid}, "{fid}", {dist}).')

facts_str = "\n".join(facts)

program = f"""
{facts_str}

{{ opened(F) }} :- facility(F, _, _, _).

1 {{ serves(C, F) : can_serve(C, F, _) }} 1 :- customer(C, _, _).

:- serves(C, F), not opened(F).

opening_cost(F, Cost) :- facility(F, _, _, Cost), opened(F).
service_cost(C, F, ServiceCost) :- serves(C, F), can_serve(C, F, Dist), 
    ServiceCost = Dist * {service_cost_per_unit}.

total_opening_cost(Total) :- Total = #sum {{ Cost, F : opening_cost(F, Cost) }}.
total_service_cost(Total) :- Total = #sum {{ Cost, C, F : service_cost(C, F, Cost) }}.
total_cost(Total) :- total_opening_cost(OC), total_service_cost(SC), Total = OC + SC.

:- total_cost(Cost), Cost > 380.

#minimize {{ Cost : total_cost(Cost) }}.
"""

ctl = clingo.Control(["1"])
ctl.add("base", [], program)
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    
    opened_facilities = []
    assignments = {}
    
    for atom in model.symbols(atoms=True):
        if atom.name == "opened" and len(atom.arguments) == 1:
            fac_id = str(atom.arguments[0]).strip('"')
            opened_facilities.append(fac_id)
        elif atom.name == "serves" and len(atom.arguments) == 2:
            cust_id = str(atom.arguments[0])
            fac_id = str(atom.arguments[1]).strip('"')
            assignments[cust_id] = fac_id
        elif atom.name == "total_cost" and len(atom.arguments) == 1:
            total_cost = atom.arguments[0].number
            if solution_data is None:
                solution_data = {"total_cost": total_cost}
            else:
                solution_data["total_cost"] = total_cost
    
    if solution_data is None:
        solution_data = {}
    
    solution_data["facilities"] = sorted(opened_facilities)
    solution_data["assignments"] = assignments
    solution_data["feasible"] = True

result = ctl.solve(on_model=on_model)

if result.satisfiable and solution_data:
    print(json.dumps(solution_data))
else:
    print(json.dumps({"error": "No solution exists", "feasible": False}))
