import clingo
import json

def create_asp_program():
    program = """
    warehouse("W1", 100).
    warehouse("W2", 150).
    warehouse("W3", 120).
    
    customer("C1", 25).
    customer("C2", 30).
    customer("C3", 20).
    customer("C4", 35).
    customer("C5", 15).
    customer("C6", 25).
    
    distance("W1", "C1", 10).
    distance("W1", "C2", 15).
    distance("W1", "C3", 25).
    distance("W1", "C4", 20).
    distance("W1", "C5", 30).
    distance("W1", "C6", 12).
    
    distance("W2", "C1", 18).
    distance("W2", "C2", 8).
    distance("W2", "C3", 12).
    distance("W2", "C4", 15).
    distance("W2", "C5", 10).
    distance("W2", "C6", 20).
    
    distance("W3", "C1", 22).
    distance("W3", "C2", 25).
    distance("W3", "C3", 8).
    distance("W3", "C4", 18).
    distance("W3", "C5", 12).
    distance("W3", "C6", 15).
    
    { open(W) } :- warehouse(W, _).
    
    1 { assign(C, W) : warehouse(W, _) } 1 :- customer(C, _).
    
    :- assign(C, W), not open(W).
    
    :- warehouse(W, Capacity), 
       #sum { Demand, C : assign(C, W), customer(C, Demand) } > Capacity.
    
    assignment_cost(C, W, Cost) :- 
        assign(C, W), 
        customer(C, Demand), 
        distance(W, C, Dist),
        Cost = Demand * Dist.
    
    total_cost(Total) :- 
        Total = #sum { Cost, C, W : assignment_cost(C, W, Cost) }.
    
    :- total_cost(Cost), Cost > 1625.
    
    #show open/1.
    #show assign/2.
    #show total_cost/1.
    """
    return program

def solve_warehouse_problem():
    ctl = clingo.Control(["1"])
    
    program = create_asp_program()
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution = None
    
    def on_model(model):
        nonlocal solution
        atoms = model.symbols(atoms=True)
        
        selected_warehouses = []
        assignments = {}
        total_cost = 0
        
        for atom in atoms:
            if atom.name == "open" and len(atom.arguments) == 1:
                warehouse = str(atom.arguments[0]).strip('"')
                selected_warehouses.append(warehouse)
            
            elif atom.name == "assign" and len(atom.arguments) == 2:
                customer = str(atom.arguments[0]).strip('"')
                warehouse = str(atom.arguments[1]).strip('"')
                assignments[customer] = warehouse
            
            elif atom.name == "total_cost" and len(atom.arguments) == 1:
                total_cost = atom.arguments[0].number
        
        solution = {
            "selected_warehouses": sorted(selected_warehouses),
            "assignments": assignments,
            "total_cost": total_cost
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution
    else:
        return {
            "error": "No solution exists",
            "reason": "Problem constraints cannot be satisfied"
        }

solution = solve_warehouse_problem()
print(json.dumps(solution, indent=2))
