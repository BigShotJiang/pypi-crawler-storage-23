import clingo
import json

def solve_protein_folding(sequence):
    """
    Solve protein folding problem using HP model on 2D lattice.
    Minimizes energy by maximizing H-H contacts between non-sequential neighbors.
    """
    ctl = clingo.Control(["1"])
    
    n = len(sequence)
    
    program = """
    % Define residues with their types
    """
    
    for i, residue_type in enumerate(sequence):
        program += f'residue({i}, "{residue_type.lower()}").\n'
    
    program += f"""
    % Define coordinate range
    coord(-4..4).
    
    % Define adjacency (Manhattan distance = 1)
    adjacent(X1, Y1, X2, Y2) :- coord(X1), coord(Y1), coord(X2), coord(Y2),
        |X1 - X2| + |Y1 - Y2| == 1.
    
    % Each residue must be placed at exactly one coordinate
    1 {{ at(I, X, Y) : coord(X), coord(Y) }} 1 :- residue(I, _).
    
    % No two residues at the same position
    :- at(I1, X, Y), at(I2, X, Y), I1 != I2.
    
    % Consecutive residues must be adjacent
    :- residue(I, _), I < {n-1}, at(I, X1, Y1), at(I+1, X2, Y2),
       not adjacent(X1, Y1, X2, Y2).
    
    % Define H-H contacts (non-sequential neighbors)
    contact(I1, I2) :- residue(I1, "h"), residue(I2, "h"),
        I1 < I2, I2 > I1 + 1,
        at(I1, X1, Y1), at(I2, X2, Y2),
        adjacent(X1, Y1, X2, Y2).
    
    % Constraint: require at least 3 H-H contacts (energy = -3)
    :- #count {{ I1, I2 : contact(I1, I2) }} < 3.
    
    #show at/3.
    """
    
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution = None
    
    def on_model(model):
        nonlocal solution
        atoms = model.symbols(atoms=True)
        
        coordinates = {}
        
        for atom in atoms:
            if atom.name == "at" and len(atom.arguments) == 3:
                index = atom.arguments[0].number
                x = atom.arguments[1].number
                y = atom.arguments[2].number
                coordinates[index] = [x, y]
        
        coord_list = [coordinates[i] for i in range(n)]
        
        solution = {
            "coordinates": coord_list,
            "sequence": sequence
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution
    else:
        return {"error": "No solution exists", "reason": "UNSAT"}

if __name__ == "__main__":
    sequence = "HPPHPPHH"
    solution = solve_protein_folding(sequence)
    print(json.dumps(solution, indent=2))
