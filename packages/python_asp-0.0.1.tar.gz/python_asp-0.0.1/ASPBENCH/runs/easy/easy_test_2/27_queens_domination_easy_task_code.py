import clingo
import json

asp_program = """
row(0..7).
col(0..7).

{ queen(R, C) : row(R), col(C) }.

dominates(QR, QC, R, C) :- queen(QR, QC), row(R), col(C), QR == R.
dominates(QR, QC, R, C) :- queen(QR, QC), row(R), col(C), QC == C.
dominates(QR, QC, R, C) :- queen(QR, QC), row(R), col(C), |QR - R| == |QC - C|.

dominated(R, C) :- dominates(_, _, R, C).

:- row(R), col(C), not dominated(R, C).
:- #count { R, C : queen(R, C) } > 5.

#show queen/2.
"""

ctl = clingo.Control(["1"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    queens = []
    for atom in model.symbols(atoms=True):
        if atom.name == "queen" and len(atom.arguments) == 2:
            row = atom.arguments[0].number
            col = atom.arguments[1].number
            queens.append([row, col])
    queens.sort()
    solution_data = {"queens": queens, "num_queens": len(queens)}

result = ctl.solve(on_model=on_model)

if result.satisfiable and solution_data:
    queens = solution_data["queens"]
    
    def is_dominated(r, c, queens):
        for qr, qc in queens:
            if qr == r or qc == c or abs(qr - r) == abs(qc - c):
                return True
        return False
    
    dominated_squares = []
    for r in range(8):
        for c in range(8):
            if is_dominated(r, c, queens):
                dominated_squares.append([r, c])
    
    dominated_squares.sort()
    solution_data["dominated_squares"] = dominated_squares
    
    print(json.dumps(solution_data))
else:
    print(json.dumps({"error": "No solution exists", "reason": "Could not find 5-queen domination"}))
