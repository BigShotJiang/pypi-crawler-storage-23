import clingo
import json

asp_program = """
letter(s; e; n; d; m; o; r; y).
digit(0..9).

1 { assign(L, D) : digit(D) } 1 :- letter(L).

:- assign(L1, D), assign(L2, D), L1 != L2.

:- assign(s, 0).
:- assign(m, 0).

carry(0; 1).

1 { c1(C) : carry(C) } 1.
1 { c2(C) : carry(C) } 1.
1 { c3(C) : carry(C) } 1.
1 { c4(C) : carry(C) } 1.

:- assign(d, D), assign(e, E), assign(y, Y), c1(C1),
   D + E != 10*C1 + Y.

:- assign(n, N), assign(r, R), assign(e, E), c1(C1), c2(C2),
   N + R + C1 != 10*C2 + E.

:- assign(e, E), assign(o, O), assign(n, N), c2(C2), c3(C3),
   E + O + C2 != 10*C3 + N.

:- assign(s, S), assign(m, M), assign(o, O), c3(C3), c4(C4),
   S + M + C3 != 10*C4 + O.

:- assign(m, M), c4(C4), C4 != M.
"""

ctl = clingo.Control(["1"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    solution_data = {}
    
    assignment = {}
    for atom in model.symbols(atoms=True):
        if atom.name == "assign" and len(atom.arguments) == 2:
            letter = str(atom.arguments[0])
            digit = atom.arguments[1].number
            assignment[letter.upper()] = digit
    
    solution_data['assignment'] = assignment

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    assignment = solution_data['assignment']
    
    send = (assignment['S'] * 1000 + assignment['E'] * 100 + 
            assignment['N'] * 10 + assignment['D'])
    more = (assignment['M'] * 1000 + assignment['O'] * 100 + 
            assignment['R'] * 10 + assignment['E'])
    money = (assignment['M'] * 10000 + assignment['O'] * 1000 + 
             assignment['N'] * 100 + assignment['E'] * 10 + assignment['Y'])
    
    valid = (send + more == money)
    
    equation = f"{send} + {more} = {money}"
    
    output = {
        "assignment": assignment,
        "equation": f"SEND + MORE = MONEY becomes {equation}",
        "valid": valid
    }
    
    print(json.dumps(output, indent=2))
else:
    output = {
        "error": "No solution exists",
        "reason": "The puzzle constraints are unsatisfiable"
    }
    print(json.dumps(output, indent=2))
