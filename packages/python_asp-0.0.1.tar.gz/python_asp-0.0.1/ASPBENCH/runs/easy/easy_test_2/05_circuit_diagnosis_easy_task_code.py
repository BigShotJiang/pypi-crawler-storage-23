import clingo
import json

def solve_circuit_diagnosis():
    ctl = clingo.Control(["--opt-mode=optN", "0"])
    
    program = """
    component(and1, "and").
    component(or1, "or").
    component(notgate1, "not").
    component(xor1, "xor").
    component(and2, "and").
    
    wire(in1). wire(in2). wire(in3). wire(in4).
    wire(w1). wire(w2). wire(w3).
    wire(out1). wire(out2).
    
    gate_input(and1, in1, 1).
    gate_input(and1, in2, 2).
    gate_output(and1, w1).
    
    gate_input(or1, w1, 1).
    gate_input(or1, in3, 2).
    gate_output(or1, w2).
    
    gate_input(notgate1, w2, 1).
    gate_output(notgate1, out1).
    
    gate_input(xor1, in1, 1).
    gate_input(xor1, in4, 2).
    gate_output(xor1, w3).
    
    gate_input(and2, w3, 1).
    gate_input(and2, in2, 2).
    gate_output(and2, out2).
    
    input_value(in1, 1).
    input_value(in2, 0).
    input_value(in3, 1).
    input_value(in4, 1).
    
    observed_output(out1, 1).
    observed_output(out2, 0).
    
    value(0; 1).
    
    { faulty(C) } :- component(C, _).
    
    wire_value(W, V) :- input_value(W, V).
    
    wire_value(Out, 1) :- component(G, "and"), gate_output(G, Out), 
                          gate_input(G, In1, 1), gate_input(G, In2, 2),
                          wire_value(In1, 1), wire_value(In2, 1),
                          not faulty(G).
    
    wire_value(Out, 0) :- component(G, "and"), gate_output(G, Out),
                          gate_input(G, In1, 1), gate_input(G, In2, 2),
                          wire_value(In1, 0), not faulty(G).
    
    wire_value(Out, 0) :- component(G, "and"), gate_output(G, Out),
                          gate_input(G, In1, 1), gate_input(G, In2, 2),
                          wire_value(In2, 0), not faulty(G).
    
    wire_value(Out, 1) :- component(G, "or"), gate_output(G, Out),
                          gate_input(G, In1, 1), gate_input(G, In2, 2),
                          wire_value(In1, 1), not faulty(G).
    
    wire_value(Out, 1) :- component(G, "or"), gate_output(G, Out),
                          gate_input(G, In1, 1), gate_input(G, In2, 2),
                          wire_value(In2, 1), not faulty(G).
    
    wire_value(Out, 0) :- component(G, "or"), gate_output(G, Out),
                          gate_input(G, In1, 1), gate_input(G, In2, 2),
                          wire_value(In1, 0), wire_value(In2, 0),
                          not faulty(G).
    
    wire_value(Out, 1) :- component(G, "not"), gate_output(G, Out),
                          gate_input(G, In, 1), wire_value(In, 0),
                          not faulty(G).
    
    wire_value(Out, 0) :- component(G, "not"), gate_output(G, Out),
                          gate_input(G, In, 1), wire_value(In, 1),
                          not faulty(G).
    
    wire_value(Out, 1) :- component(G, "xor"), gate_output(G, Out),
                          gate_input(G, In1, 1), gate_input(G, In2, 2),
                          wire_value(In1, 0), wire_value(In2, 1),
                          not faulty(G).
    
    wire_value(Out, 1) :- component(G, "xor"), gate_output(G, Out),
                          gate_input(G, In1, 1), gate_input(G, In2, 2),
                          wire_value(In1, 1), wire_value(In2, 0),
                          not faulty(G).
    
    wire_value(Out, 0) :- component(G, "xor"), gate_output(G, Out),
                          gate_input(G, In1, 1), gate_input(G, In2, 2),
                          wire_value(In1, 0), wire_value(In2, 0),
                          not faulty(G).
    
    wire_value(Out, 0) :- component(G, "xor"), gate_output(G, Out),
                          gate_input(G, In1, 1), gate_input(G, In2, 2),
                          wire_value(In1, 1), wire_value(In2, 1),
                          not faulty(G).
    
    { wire_value(Out, V) : value(V) } 1 :- component(G, _), 
                                            gate_output(G, Out), 
                                            faulty(G).
    
    :- observed_output(W, V), not wire_value(W, V).
    :- wire_value(W, V1), wire_value(W, V2), V1 != V2.
    
    #minimize { 1,C : faulty(C) }.
    
    #show faulty/1.
    """
    
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    all_solutions = []
    
    def on_model(model):
        faulty_components = []
        for atom in model.symbols(atoms=True):
            if atom.name == "faulty" and len(atom.arguments) == 1:
                comp_name = str(atom.arguments[0])
                faulty_components.append(comp_name)
        all_solutions.append(sorted(faulty_components))
    
    result = ctl.solve(on_model=on_model)
    
    if not result.satisfiable:
        return {
            "error": "No solution exists",
            "reason": "No diagnosis can explain the observed outputs"
        }
    
    unique_solutions = []
    seen = set()
    for sol in all_solutions:
        sol_tuple = tuple(sol)
        if sol_tuple not in seen:
            seen.add(sol_tuple)
            unique_solutions.append(sol)
    
    minimal_solutions = []
    for sol in unique_solutions:
        is_minimal = True
        for other in unique_solutions:
            if (other != sol and 
                set(other).issubset(set(sol)) and 
                len(other) < len(sol)):
                is_minimal = False
                break
        if is_minimal:
            minimal_solutions.append(sol)
    
    output = {
        "diagnoses": [
            {"components": sol, "minimal": True}
            for sol in sorted(minimal_solutions)
        ],
        "explanation": "Each diagnosis represents a minimal set of components that, if faulty, would explain the observed discrepancy."
    }
    
    return output

if __name__ == "__main__":
    result = solve_circuit_diagnosis()
    print(json.dumps(result, indent=2))
