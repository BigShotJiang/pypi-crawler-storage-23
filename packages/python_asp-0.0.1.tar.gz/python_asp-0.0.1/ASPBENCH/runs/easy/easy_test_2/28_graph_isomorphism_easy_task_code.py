import clingo
import json

g1_vertices = [0, 1, 2, 3, 4]
g1_edges = [(0, 1), (0, 2), (1, 3), (2, 4), (3, 4)]
g2_vertices = ['a', 'b', 'c', 'd', 'e']
g2_edges = [('a', 'b'), ('a', 'c'), ('b', 'd'), ('c', 'e'), ('d', 'e')]

def generate_asp_program(g1_vertices, g1_edges, g2_vertices, g2_edges):
    facts = []
    
    for v in g1_vertices:
        facts.append(f'vertex1({v}).')
    
    for v in g2_vertices:
        facts.append(f'vertex2("{v}").')
    
    for u, v in g1_edges:
        facts.append(f'edge1({u},{v}).')
        facts.append(f'edge1({v},{u}).')
    
    for u, v in g2_edges:
        facts.append(f'edge2("{u}","{v}").')
        facts.append(f'edge2("{v}","{u}").')
    
    rules = '''
1 { mapping(V1, V2) : vertex2(V2) } 1 :- vertex1(V1).

:- mapping(V1a, V2), mapping(V1b, V2), V1a != V1b.

:- edge1(U, V), mapping(U, MU), mapping(V, MV), not edge2(MU, MV).

covered_edge2(U2, V2) :- edge2(U2, V2), edge1(U1, V1), 
                         mapping(U1, U2), mapping(V1, V2).

:- edge2(U2, V2), not covered_edge2(U2, V2).
'''
    
    return "\n".join(facts) + "\n" + rules

def solve_graph_isomorphism(asp_program):
    ctl = clingo.Control(["1"])
    ctl.add("base", [], asp_program)
    ctl.ground([("base", [])])
    
    solution_found = False
    mapping_dict = {}
    
    def on_model(model):
        nonlocal solution_found, mapping_dict
        solution_found = True
        
        for atom in model.symbols(atoms=True):
            if atom.name == "mapping" and len(atom.arguments) == 2:
                v1 = str(atom.arguments[0])
                v2 = str(atom.arguments[1]).strip('"')
                mapping_dict[v1] = v2
    
    result = ctl.solve(on_model=on_model)
    
    return solution_found, mapping_dict, result.satisfiable

def format_output(is_isomorphic, mapping, g1_edges):
    if not is_isomorphic:
        return {
            "is_isomorphic": False,
            "mapping": None,
            "preserved_edges": []
        }
    
    preserved_edges = []
    for u, v in g1_edges:
        u_str = str(u)
        v_str = str(v)
        mapped_u = mapping[u_str]
        mapped_v = mapping[v_str]
        
        edge_pair = [f"{u},{v}", f"{mapped_u},{mapped_v}"]
        preserved_edges.append(edge_pair)
    
    return {
        "is_isomorphic": True,
        "mapping": mapping,
        "preserved_edges": preserved_edges
    }

asp_program = generate_asp_program(g1_vertices, g1_edges, g2_vertices, g2_edges)
is_satisfiable, mapping, sat_result = solve_graph_isomorphism(asp_program)
output = format_output(is_satisfiable, mapping, g1_edges)

print(json.dumps(output, indent=2))
