import clingo
import json

def solve_steiner_tree():
    ctl = clingo.Control(["1"])
    
    program = """
    vertex(0..6).
    
    edge(0,1,3). edge(1,0,3).
    edge(0,2,5). edge(2,0,5).
    edge(1,3,2). edge(3,1,2).
    edge(1,4,4). edge(4,1,4).
    edge(2,3,1). edge(3,2,1).
    edge(2,5,6). edge(5,2,6).
    edge(3,4,3). edge(4,3,3).
    edge(3,5,3). edge(5,3,3).
    edge(3,6,2). edge(6,3,2).
    edge(4,5,2). edge(5,4,2).
    edge(5,6,4). edge(6,5,4).
    
    terminal(0). terminal(5). terminal(6).
    
    { in_tree(V1, V2) : edge(V1, V2, _), V1 < V2 } :- vertex(_).
    
    used_vertex(V) :- in_tree(V, _).
    used_vertex(V) :- in_tree(_, V).
    
    :- terminal(T), not used_vertex(T).
    
    num_used_vertices(N) :- N = #count { V : used_vertex(V) }.
    num_edges(E) :- E = #count { V1, V2 : in_tree(V1, V2) }.
    :- num_used_vertices(N), num_edges(E), E != N - 1.
    
    reachable(0, 0).
    reachable(V1, V2) :- reachable(V1, X), in_tree(X, V2).
    reachable(V1, V2) :- reachable(V1, X), in_tree(V2, X).
    :- used_vertex(V), not reachable(0, V).
    
    total_weight(W) :- W = #sum { Weight, V1, V2 : in_tree(V1, V2), 
                                   edge(V1, V2, Weight) }.
    
    :- total_weight(W), W > 10.
    
    #show in_tree/2.
    #show total_weight/1.
    #show used_vertex/1.
    """
    
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution = None
    
    def on_model(model):
        nonlocal solution
        atoms = model.symbols(atoms=True)
        
        edge_weights = {
            (0,1): 3, (0,2): 5, (1,3): 2, (1,4): 4, (2,3): 1,
            (2,5): 6, (3,4): 3, (3,5): 3, (3,6): 2, (4,5): 2, (5,6): 4
        }
        
        tree_edges = []
        used_vertices = set()
        
        for atom in atoms:
            if atom.name == "in_tree" and len(atom.arguments) == 2:
                v1 = atom.arguments[0].number
                v2 = atom.arguments[1].number
                w = edge_weights.get((v1, v2), edge_weights.get((v2, v1), 0))
                tree_edges.append({"from": v1, "to": v2, "weight": w})
                
            elif atom.name == "used_vertex" and len(atom.arguments) == 1:
                used_vertices.add(atom.arguments[0].number)
        
        total_w = sum(e["weight"] for e in tree_edges)
        terminals = [0, 5, 6]
        steiner_vertices = [v for v in used_vertices if v not in terminals]
        
        solution = {
            "total_weight": total_w,
            "tree_edges": tree_edges,
            "steiner_vertices": sorted(steiner_vertices),
            "terminals": sorted(terminals),
            "connected_components": [{
                "component": 1, 
                "vertices": sorted(list(used_vertices))
            }]
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution
    else:
        return {"error": "No solution exists", "reason": "UNSAT"}

solution = solve_steiner_tree()
print(json.dumps(solution, indent=2))
