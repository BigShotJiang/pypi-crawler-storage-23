import clingo
import json

asp_program = """
vertex(1). vertex(2). vertex(3). vertex(4). vertex(5). vertex(6).

edge(1,2). edge(1,3).
edge(2,4). edge(2,5).
edge(3,4). edge(3,6).
edge(4,2). edge(4,5).
edge(5,3). edge(5,6).
edge(6,1). edge(6,4).

{ in_feedback_set(V) } :- vertex(V).

active_edge(U,V) :- edge(U,V), not in_feedback_set(U), not in_feedback_set(V).

reachable(U,V) :- active_edge(U,V).
reachable(U,W) :- reachable(U,V), active_edge(V,W).

:- vertex(V), not in_feedback_set(V), reachable(V,V).

#minimize { 1,V : in_feedback_set(V) }.
"""

ctl = clingo.Control(["0", "--opt-mode=optN"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

best_solution = None

def on_model(model):
    global best_solution
    
    feedback_set = []
    for atom in model.symbols(atoms=True):
        if atom.name == "in_feedback_set" and len(atom.arguments) == 1:
            vertex_num = atom.arguments[0].number
            feedback_set.append(vertex_num)
    
    feedback_set.sort()
    all_vertices = [1, 2, 3, 4, 5, 6]
    remaining_vertices = [v for v in all_vertices if v not in feedback_set]
    
    best_solution = {
        "feedback_set": feedback_set,
        "size": len(feedback_set),
        "remaining_vertices": remaining_vertices
    }

result = ctl.solve(on_model=on_model)

if result.satisfiable and best_solution:
    print(json.dumps(best_solution, indent=2))
else:
    print(json.dumps({"error": "No solution exists", 
                      "reason": "Graph cannot be made acyclic"}))
