import clingo
import json

def solve_latin_square():
    ctl = clingo.Control(["1"])
    
    program = """
    row(1..5).
    col(1..5).
    value(1..5).
    
    given(1, 1, 1).
    given(2, 3, 3).
    given(3, 4, 4).
    given(4, 5, 5).
    given(5, 2, 2).
    
    1 { cell(R, C, V) : value(V) } 1 :- row(R), col(C), not given(R, C, _).
    
    cell(R, C, V) :- given(R, C, V).
    
    :- row(R), value(V), #count { C : cell(R, C, V) } != 1.
    
    :- col(C), value(V), #count { R : cell(R, C, V) } != 1.
    
    #show cell/3.
    """
    
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution = None
    
    def on_model(m):
        nonlocal solution
        grid = [[0 for _ in range(5)] for _ in range(5)]
        
        for atom in m.symbols(atoms=True):
            if atom.name == "cell" and len(atom.arguments) == 3:
                r = atom.arguments[0].number
                c = atom.arguments[1].number
                v = atom.arguments[2].number
                grid[r-1][c-1] = v
        
        solution = grid
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable and solution:
        output = {
            "grid": solution,
            "solved": True
        }
    else:
        output = {
            "error": "No solution exists",
            "solved": False
        }
    
    return output

result = solve_latin_square()
print(json.dumps(result, indent=2))
