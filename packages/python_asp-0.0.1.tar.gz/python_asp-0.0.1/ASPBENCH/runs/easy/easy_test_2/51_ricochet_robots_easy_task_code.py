import clingo
import json

def generate_all_slides():
    """Generate all possible slides for a 4x4 grid with walls"""
    slides = []
    
    for r in range(4):
        for c in range(4):
            for dest_c in range(c+1, 4):
                blocked = False
                if r in [2, 3] and c <= 2 and dest_c >= 3:
                    blocked = True
                if not blocked:
                    slides.append(f'possible_slide({r}, {c}, "right", {r}, {dest_c}).')
            
            for dest_r in range(r+1, 4):
                slides.append(f'possible_slide({r}, {c}, "down", {dest_r}, {c}).')
            
            for dest_c in range(0, c):
                blocked = False
                if r in [2, 3] and c >= 3 and dest_c <= 2:
                    blocked = True
                if not blocked:
                    slides.append(f'possible_slide({r}, {c}, "left", {r}, {dest_c}).')
            
            for dest_r in range(0, r):
                slides.append(f'possible_slide({r}, {c}, "up", {dest_r}, {c}).')
    
    return '\n'.join(slides)

def create_asp_program():
    slides = generate_all_slides()
    
    program = f"""
robot("A"). robot("B").
row(0..3). col(0..3).

initial_at("A", 0, 0).
initial_at("B", 1, 1).

#const max_time = 3.
time(0..max_time).

at(R, Row, Col, 0) :- initial_at(R, Row, Col).

{slides}

1 {{ execute_slide(Robot, FromR, FromC, Dir, ToR, ToC, T) : 
     robot(Robot), possible_slide(FromR, FromC, Dir, ToR, ToC) }} 1 :- time(T), T < max_time.

:- execute_slide(Robot, FromR, FromC, Dir, ToR, ToC, T), not at(Robot, FromR, FromC, T).
:- execute_slide(Robot, FromR, FromC, Dir, ToR, ToC, T), at(OtherRobot, ToR, ToC, T), Robot != OtherRobot.

:- execute_slide(Robot, FromR, FromC, "right", ToR, ToC, T),
   at(_, FromR, C, T), C > FromC, C < ToC.

:- execute_slide(Robot, FromR, FromC, "left", ToR, ToC, T),
   at(_, FromR, C, T), C < FromC, C > ToC.

:- execute_slide(Robot, FromR, FromC, "down", ToR, ToC, T),
   at(_, R, FromC, T), R > FromR, R < ToR.

:- execute_slide(Robot, FromR, FromC, "up", ToR, ToC, T),
   at(_, R, FromC, T), R < FromR, R > ToR.

at(Robot, ToR, ToC, T+1) :- execute_slide(Robot, _, _, _, ToR, ToC, T).

at(Robot, Row, Col, T+1) :-
    at(Robot, Row, Col, T),
    time(T+1),
    not execute_slide(Robot, Row, Col, _, _, _, T).

:- at(Robot, R1, C1, T), at(Robot, R2, C2, T), (R1, C1) != (R2, C2).
:- at(R1, Row, Col, T), at(R2, Row, Col, T), R1 != R2.

:- not at("A", 3, 1, max_time).

#show execute_slide/7.
#show at/4.
"""
    return program

def solve_ricochet_robots():
    ctl = clingo.Control(["1"])
    program = create_asp_program()
    ctl.add("base", [], program)
    
    try:
        ctl.ground([("base", [])])
    except Exception as e:
        return {"solution_found": False, "error": f"Grounding failed: {str(e)}"}
    
    solution_data = None
    
    def on_model(model):
        nonlocal solution_data
        atoms = model.symbols(atoms=True)
        
        moves = []
        pos_history = {}
        
        at_atoms = [a for a in atoms if a.name == "at" and len(a.arguments) == 4]
        for atom in at_atoms:
            robot = str(atom.arguments[0]).strip('"')
            row = int(str(atom.arguments[1]))
            col = int(str(atom.arguments[2]))
            time = int(str(atom.arguments[3]))
            
            if robot not in pos_history:
                pos_history[robot] = {}
            pos_history[robot][time] = [row, col]
        
        slide_atoms = [a for a in atoms if a.name == "execute_slide"]
        slide_atoms.sort(key=lambda a: int(str(a.arguments[6])))
        
        for atom in slide_atoms:
            robot = str(atom.arguments[0]).strip('"')
            from_r = int(str(atom.arguments[1]))
            from_c = int(str(atom.arguments[2]))
            direction = str(atom.arguments[3]).strip('"')
            to_r = int(str(atom.arguments[4]))
            to_c = int(str(atom.arguments[5]))
            
            moves.append({
                "robot": robot,
                "direction": direction,
                "from": [from_r, from_c],
                "to": [to_r, to_c]
            })
        
        final_positions = {}
        for robot in pos_history:
            max_t = max(pos_history[robot].keys())
            final_positions[robot] = pos_history[robot][max_t]
        
        solution_data = {
            "solution_found": True,
            "moves": len(moves),
            "sequence": moves,
            "final_positions": final_positions
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution_data
    else:
        return {
            "solution_found": False,
            "error": "No solution exists",
            "reason": "The puzzle may be unsolvable with the given constraints"
        }

solution = solve_ricochet_robots()
print(json.dumps(solution, indent=2))
