import clingo
import json

def solve_graph_coloring():
    ctl = clingo.Control(["1"])
    
    program = """
    vertex(1..6).
    
    edge(1,2). edge(2,1).
    edge(1,3). edge(3,1).
    edge(2,3). edge(3,2).
    edge(2,4). edge(4,2).
    edge(3,4). edge(4,3).
    edge(3,5). edge(5,3).
    edge(4,5). edge(5,4).
    edge(4,6). edge(6,4).
    edge(5,6). edge(6,5).
    
    color(1..6).
    
    1 { colored(V, C) : color(C) } 1 :- vertex(V).
    
    :- edge(V1, V2), colored(V1, C), colored(V2, C).
    
    used_color(C) :- colored(_, C).
    
    num_colors_used(N) :- N = #count { C : used_color(C) }.
    
    #minimize { N : num_colors_used(N) }.
    
    #show colored/2.
    #show num_colors_used/1.
    """
    
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution = None
    
    def on_model(model):
        nonlocal solution
        atoms = model.symbols(atoms=True)
        
        coloring = []
        num_colors = 0
        
        for atom in atoms:
            if atom.name == "colored" and len(atom.arguments) == 2:
                vertex = atom.arguments[0].number
                color = atom.arguments[1].number
                coloring.append({"vertex": vertex, "color": color})
            elif atom.name == "num_colors_used" and len(atom.arguments) == 1:
                num_colors = atom.arguments[0].number
        
        color_mapping = {}
        used_colors = sorted(set(item["color"] for item in coloring))
        for idx, old_color in enumerate(used_colors):
            color_mapping[old_color] = idx + 1
        
        for item in coloring:
            item["color"] = color_mapping[item["color"]]
        
        coloring.sort(key=lambda x: x["vertex"])
        
        solution = {
            "num_colors": num_colors,
            "coloring": coloring
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution
    else:
        return {"error": "No solution exists", 
                "reason": "Graph coloring problem is unsatisfiable"}

solution = solve_graph_coloring()
print(json.dumps(solution, indent=2))
