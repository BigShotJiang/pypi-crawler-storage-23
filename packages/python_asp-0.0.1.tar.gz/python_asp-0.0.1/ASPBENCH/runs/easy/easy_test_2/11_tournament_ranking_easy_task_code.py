import clingo
import json

program = """
team("A"). team("B"). team("C"). team("D"). team("E").

beat("A", "B").
beat("B", "C").
beat("C", "A").
beat("A", "D").
beat("D", "E").
beat("E", "C").
beat("B", "E").
beat("D", "C").
beat("A", "E").
beat("B", "D").

position(1..5).

1 { rank(T, P) : position(P) } 1 :- team(T).
1 { rank(T, P) : team(T) } 1 :- position(P).

violation(X, Y) :- beat(X, Y), rank(X, PX), rank(Y, PY), PY < PX.

#minimize { 1,X,Y : violation(X,Y) }.
"""

ctl = clingo.Control(["0"])
ctl.add("base", [], program)
ctl.ground([("base", [])])

best_solution = None
best_violations = float('inf')

def on_model(model):
    global best_solution, best_violations
    
    ranking_dict = {}
    violations_set = set()
    
    for atom in model.symbols(atoms=True):
        if atom.name == "rank" and len(atom.arguments) == 2:
            team = str(atom.arguments[0]).strip('"')
            position = atom.arguments[1].number
            ranking_dict[position] = team
        elif atom.name == "violation" and len(atom.arguments) == 2:
            x = str(atom.arguments[0]).strip('"')
            y = str(atom.arguments[1]).strip('"')
            violations_set.add((x, y))
    
    ranking = [ranking_dict[i] for i in sorted(ranking_dict.keys())]
    num_violations = len(violations_set)
    
    if num_violations < best_violations:
        best_violations = num_violations
        best_solution = {
            "ranking": ranking,
            "violations": num_violations,
            "valid": len(ranking) == 5 and len(set(ranking)) == 5
        }

result = ctl.solve(on_model=on_model)

if result.satisfiable and best_solution:
    output = {
        "ranking": best_solution['ranking'],
        "violations": best_solution['violations'],
        "valid": best_solution['valid']
    }
    print(json.dumps(output))
else:
    print(json.dumps({"error": "No solution exists", "reason": "Problem is unsatisfiable"}))
