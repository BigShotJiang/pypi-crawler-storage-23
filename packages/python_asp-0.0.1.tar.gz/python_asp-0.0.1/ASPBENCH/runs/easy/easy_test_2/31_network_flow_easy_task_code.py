import clingo
import json

program = """
node(1;2;3;4;5;6).
source(1).
sink(6).

edge(1, 2, 10).
edge(1, 3, 8).
edge(2, 3, 5).
edge(2, 4, 7).
edge(3, 4, 3).
edge(3, 5, 9).
edge(4, 6, 8).
edge(5, 6, 6).

flow_value(0..10).

1 { flow(From, To, F) : flow_value(F), F <= Cap } 1 :- edge(From, To, Cap).

inflow(N, Total) :- node(N), 
                    Total = #sum { F,From : flow(From, N, F) }.

outflow(N, Total) :- node(N), 
                     Total = #sum { F,To : flow(N, To, F) }.

:- node(N), not source(N), not sink(N), 
   inflow(N, In), outflow(N, Out), In != Out.

total_flow(Total) :- source(S), outflow(S, Total).

#maximize { Total : total_flow(Total) }.
"""

ctl = clingo.Control(["0"])
ctl.add("base", [], program)
ctl.ground([("base", [])])

solution_data = None
best_flow = -1

def on_model(model):
    global solution_data, best_flow
    
    flows = []
    max_flow = 0
    
    for atom in model.symbols(atoms=True):
        if atom.name == "flow" and len(atom.arguments) == 3:
            from_node = atom.arguments[0].number
            to_node = atom.arguments[1].number
            flow_amount = atom.arguments[2].number
            
            flows.append({
                "from": from_node,
                "to": to_node,
                "flow": flow_amount
            })
        
        elif atom.name == "total_flow" and len(atom.arguments) == 1:
            max_flow = atom.arguments[0].number
    
    if max_flow > best_flow:
        best_flow = max_flow
        non_zero_flows = [f for f in flows if f["flow"] > 0]
        solution_data = {
            "max_flow": max_flow,
            "flows": sorted(non_zero_flows, key=lambda x: (x["from"], x["to"]))
        }

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    print(json.dumps(solution_data))
else:
    print(json.dumps({"error": "No solution exists"}))
