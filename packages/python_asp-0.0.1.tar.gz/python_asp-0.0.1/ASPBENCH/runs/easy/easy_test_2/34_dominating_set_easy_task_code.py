import clingo
import json

program = """
vertex(1..7).

edge(1,2). edge(1,3).
edge(2,1). edge(2,3). edge(2,4).
edge(3,1). edge(3,2). edge(3,5).
edge(4,2). edge(4,6).
edge(5,3). edge(5,6). edge(5,7).
edge(6,4). edge(6,5). edge(6,7).
edge(7,5). edge(7,6).

{ in_set(V) } :- vertex(V).

dominated(V) :- in_set(V).
dominated(V) :- vertex(V), edge(V, U), in_set(U).

:- vertex(V), not dominated(V).

#minimize { 1,V : in_set(V) }.
"""

ctl = clingo.Control(["1"])
ctl.add("base", [], program)
ctl.ground([("base", [])])

solution = None

def on_model(model):
    global solution
    dominating_set = []
    for atom in model.symbols(atoms=True):
        if atom.name == "in_set" and len(atom.arguments) == 1:
            vertex = atom.arguments[0].number
            dominating_set.append(vertex)
    
    dominating_set.sort()
    solution = {
        "dominating_set": dominating_set,
        "size": len(dominating_set)
    }

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    print(json.dumps(solution, indent=2))
else:
    print(json.dumps({"error": "No solution exists",
                      "reason": "Problem is UNSAT"}))
