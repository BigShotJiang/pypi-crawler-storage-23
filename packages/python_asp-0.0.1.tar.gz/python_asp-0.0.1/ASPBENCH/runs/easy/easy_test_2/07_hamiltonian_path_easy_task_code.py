import clingo
import json

program = """
vertex(0..5).

edge(0,1). edge(0,2).
edge(1,2). edge(1,3). edge(1,4).
edge(2,1). edge(2,3). edge(2,4).
edge(3,4). edge(3,5).
edge(4,3). edge(4,5).

position(0..5).

1 { path(V, P) : position(P) } 1 :- vertex(V).
1 { path(V, P) : vertex(V) } 1 :- position(P).

:- not path(0, 0).
:- not path(5, 5).
:- path(V1, P), path(V2, P+1), position(P), P < 5, not edge(V1, V2).

#show path/2.
"""

ctl = clingo.Control(["0"])
ctl.add("base", [], program)
ctl.ground([("base", [])])

all_paths = []

def on_model(model):
    atoms = model.symbols(atoms=True)
    path_atoms = [atom for atom in atoms if atom.name == "path"]
    
    path_dict = {}
    for atom in path_atoms:
        vertex = atom.arguments[0].number
        position = atom.arguments[1].number
        path_dict[position] = vertex
    
    path_sequence = [path_dict[i] for i in range(6)]
    all_paths.append(path_sequence)

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    output = {
        "paths": all_paths,
        "count": len(all_paths),
        "exists": True
    }
else:
    output = {
        "paths": [],
        "count": 0,
        "exists": False
    }

print(json.dumps(output, indent=2))
