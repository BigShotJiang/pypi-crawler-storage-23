import clingo
import json

def create_asp_program(initial_grid, max_time=10):
    """Generate ASP program for Conway's Game of Life"""
    
    grid_size = len(initial_grid)
    facts = []
    
    for x in range(grid_size):
        for y in range(grid_size):
            facts.append(f"cell({x},{y}).")
    
    facts.append(f"time(0..{max_time}).")
    
    for x in range(grid_size):
        for y in range(grid_size):
            if initial_grid[x][y] == 1:
                facts.append(f"alive({x},{y},0).")
    
    for x1 in range(grid_size):
        for y1 in range(grid_size):
            for dx in [-1, 0, 1]:
                for dy in [-1, 0, 1]:
                    if dx == 0 and dy == 0:
                        continue
                    x2 = x1 + dx
                    y2 = y1 + dy
                    if 0 <= x2 < grid_size and 0 <= y2 < grid_size:
                        facts.append(f"neighbor({x1},{y1},{x2},{y2}).")
    
    program = "\n".join(facts) + "\n\n"
    
    rules = """
neighbor_count(X, Y, T, N) :- 
    cell(X, Y), time(T), T < 10,
    N = #count { X2, Y2 : neighbor(X, Y, X2, Y2), alive(X2, Y2, T) }.

alive(X, Y, T+1) :- 
    alive(X, Y, T), 
    neighbor_count(X, Y, T, N),
    N >= 2, N <= 3,
    time(T), T < 10.

alive(X, Y, T+1) :- 
    cell(X, Y),
    not alive(X, Y, T),
    neighbor_count(X, Y, T, 3),
    time(T), T < 10.

same_state(T1, T2) :- 
    time(T1), time(T2), T1 < T2,
    #count { X, Y : alive(X, Y, T1), not alive(X, Y, T2) } = 0,
    #count { X, Y : alive(X, Y, T2), not alive(X, Y, T1) } = 0.

#show alive/3.
#show same_state/2.
"""
    
    program += rules
    return program

def solve_game_of_life(asp_program):
    """Solve the ASP program and extract the solution"""
    
    ctl = clingo.Control(["1"])
    ctl.add("base", [], asp_program)
    ctl.ground([("base", [])])
    
    solution_data = None
    
    def on_model(model):
        nonlocal solution_data
        
        alive_cells = {}
        same_states = []
        
        for atom in model.symbols(atoms=True):
            if atom.name == "alive" and len(atom.arguments) == 3:
                x = atom.arguments[0].number
                y = atom.arguments[1].number
                t = atom.arguments[2].number
                if t not in alive_cells:
                    alive_cells[t] = []
                alive_cells[t].append((x, y))
            elif atom.name == "same_state" and len(atom.arguments) == 2:
                t1 = atom.arguments[0].number
                t2 = atom.arguments[1].number
                same_states.append((t1, t2))
        
        solution_data = {
            'alive_cells': alive_cells,
            'same_states': same_states
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution_data
    else:
        return None

def extract_stable_patterns(solution_data, grid_size=5):
    """Extract stable patterns from the solution"""
    
    alive_cells = solution_data['alive_cells']
    same_states = solution_data['same_states']
    
    def cells_to_grid(cells, grid_size):
        grid = [[0 for _ in range(grid_size)] for _ in range(grid_size)]
        for x, y in cells:
            grid[x][y] = 1
        return grid
    
    grids = {}
    for t in sorted(alive_cells.keys()):
        grids[t] = cells_to_grid(alive_cells[t], grid_size)
    
    same_states_sorted = sorted(same_states, key=lambda x: x[1])
    
    if not same_states_sorted:
        return {"stable_patterns": []}
    
    t1, t2 = same_states_sorted[0]
    period = t2 - t1
    
    cycle_states = []
    for t in range(t1, t2):
        if t in grids:
            cycle_states.append(grids[t])
    
    output = {
        "stable_patterns": [
            {
                "pattern_id": 1,
                "period": period,
                "states": cycle_states
            }
        ]
    }
    
    return output

initial_grid = [
    [0, 1, 0, 1, 0],
    [1, 0, 1, 0, 1],
    [0, 1, 0, 1, 0],
    [1, 0, 1, 0, 1],
    [0, 1, 0, 1, 0]
]

asp_program = create_asp_program(initial_grid)
solution = solve_game_of_life(asp_program)

if solution:
    output = extract_stable_patterns(solution, grid_size=5)
    print(json.dumps(output, indent=2))
else:
    print(json.dumps({"error": "No solution exists"}))
