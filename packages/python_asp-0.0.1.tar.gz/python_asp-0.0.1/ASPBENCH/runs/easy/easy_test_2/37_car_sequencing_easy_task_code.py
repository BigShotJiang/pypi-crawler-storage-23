import clingo
import json

asp_program = """
position(1..6).

car_type("A", 1).
car_type("B", 2).
car_type("C", 3).

has_option("A", 1).
has_option("A", 2).
has_option("B", 3).
has_option("C", 1).

capacity(1, 2, 3).
capacity(2, 1, 2).
capacity(3, 1, 2).

1 { assigned(Pos, Type) : car_type(Type, _) } 1 :- position(Pos).

type_count(Type, Count) :- car_type(Type, _), 
    Count = #count { Pos : assigned(Pos, Type) }.

:- car_type(Type, RequiredCount), type_count(Type, ActualCount), 
   RequiredCount != ActualCount.

option_at(Pos, Option) :- assigned(Pos, Type), has_option(Type, Option).

:- capacity(Option, MaxCount, WindowSize),
   position(StartPos),
   StartPos + WindowSize - 1 <= 6,
   #count { Pos : option_at(Pos, Option), Pos >= StartPos, 
            Pos < StartPos + WindowSize } > MaxCount.

#show assigned/2.
"""

ctl = clingo.Control(["1"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

solution = None

def on_model(model):
    global solution
    atoms = model.symbols(atoms=True)
    assignments = {}
    
    for atom in atoms:
        if atom.name == "assigned" and len(atom.arguments) == 2:
            pos = atom.arguments[0].number
            car_type = str(atom.arguments[1]).strip('"')
            assignments[pos] = car_type
    
    sequence = [assignments[i] for i in sorted(assignments.keys())]
    solution = {
        "sequence": sequence,
        "length": len(sequence)
    }

result = ctl.solve(on_model=on_model)

if solution:
    print(json.dumps(solution))
else:
    print(json.dumps({"error": "No solution exists"}))
