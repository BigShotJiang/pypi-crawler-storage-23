import clingo
import json


def generate_asp_program():
    program = """
% Facts: Transmitters
transmitter("A"). transmitter("B"). transmitter("C").
transmitter("D"). transmitter("E"). transmitter("F").

% Facts: Available frequencies
frequency(1). frequency(2). frequency(3). frequency(4). frequency(5).

% Facts: Interference graph (bidirectional)
interferes("A", "B"). interferes("B", "A").
interferes("A", "C"). interferes("C", "A").
interferes("B", "D"). interferes("D", "B").
interferes("B", "E"). interferes("E", "B").
interferes("C", "D"). interferes("D", "C").
interferes("C", "F"). interferes("F", "C").
interferes("D", "E"). interferes("E", "D").
interferes("E", "F"). interferes("F", "E").

% Choice rule: Each transmitter gets exactly one frequency
1 { assigned(T, F) : frequency(F) } 1 :- transmitter(T).

% Constraint: Interfering transmitters cannot use the same frequency
:- interferes(T1, T2), assigned(T1, F), assigned(T2, F).

% Constraint: Interfering transmitters cannot use adjacent frequencies
:- interferes(T1, T2), assigned(T1, F1), assigned(T2, F2), |F1 - F2| == 1.

% Define which frequencies are used
used(F) :- assigned(_, F).

% Count distinct frequencies used
num_frequencies(N) :- N = #count { F : used(F) }.

% Constraint: Use at most 3 frequencies (expected optimal value)
:- num_frequencies(N), N > 3.

% Show only relevant predicates
#show assigned/2.
#show num_frequencies/1.
"""
    return program


def solve_frequency_assignment():
    ctl = clingo.Control(["1"])
    
    program = generate_asp_program()
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution_data = None
    
    def on_model(model):
        nonlocal solution_data
        atoms = model.symbols(atoms=True)
        
        assignments = []
        
        for atom in atoms:
            if atom.name == "assigned" and len(atom.arguments) == 2:
                transmitter = str(atom.arguments[0]).strip('"')
                frequency = atom.arguments[1].number
                assignments.append({
                    "transmitter": transmitter,
                    "frequency": frequency
                })
        
        assignments.sort(key=lambda x: x["transmitter"])
        
        frequencies_used = len(set(a["frequency"] for a in assignments))
        
        solution_data = {
            "assignments": assignments,
            "frequencies_used": frequencies_used
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution_data
    else:
        return {
            "error": "No solution exists",
            "reason": "Constraints cannot be satisfied"
        }


solution = solve_frequency_assignment()
print(json.dumps(solution, indent=2))
