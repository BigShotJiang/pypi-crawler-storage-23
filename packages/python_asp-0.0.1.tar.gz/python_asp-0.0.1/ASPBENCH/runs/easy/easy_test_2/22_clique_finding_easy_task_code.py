import clingo
import json

vertices = [0, 1, 2, 3, 4, 5, 6]
edges = [
    (0, 1), (0, 2), (0, 3),
    (1, 2), (1, 3), (1, 4),
    (2, 3), (2, 5),
    (3, 4), (3, 5),
    (4, 5), (4, 6),
    (5, 6)
]

facts = []
for v in vertices:
    facts.append(f"vertex({v}).")

for u, v in edges:
    if u < v:
        facts.append(f"edge({u},{v}).")
    else:
        facts.append(f"edge({v},{u}).")

asp_program = """
{ in_clique(V) } :- vertex(V).

:- in_clique(U), in_clique(V), U < V, not edge(U, V).

#maximize { 1,V : in_clique(V) }.
"""

ctl = clingo.Control(["0"])

facts_str = "\n".join(facts)
ctl.add("base", [], facts_str)
ctl.add("base", [], asp_program)

ctl.ground([("base", [])])

solution_data = None
best_size = 0

def on_model(model):
    global solution_data, best_size
    
    clique_vertices = []
    for atom in model.symbols(atoms=True):
        if atom.name == "in_clique" and len(atom.arguments) == 1:
            vertex = atom.arguments[0].number
            clique_vertices.append(vertex)
    
    if len(clique_vertices) >= best_size:
        best_size = len(clique_vertices)
        clique_vertices.sort()
        
        clique_edges = []
        for i in range(len(clique_vertices)):
            for j in range(i + 1, len(clique_vertices)):
                u, v = clique_vertices[i], clique_vertices[j]
                clique_edges.append([u, v])
        
        solution_data = {
            "clique": clique_vertices,
            "clique_size": len(clique_vertices),
            "clique_edges": clique_edges
        }

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    print(json.dumps(solution_data))
else:
    print(json.dumps({"error": "No solution exists", 
                      "reason": "Graph has no clique"}))
