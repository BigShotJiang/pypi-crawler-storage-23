import clingo
import json

def solve_vertex_cover():
    ctl = clingo.Control()
    
    program = """
    vertex(0). vertex(1). vertex(2). vertex(3). vertex(4). vertex(5).
    
    edge(0, 1).
    edge(0, 2).
    edge(1, 3).
    edge(2, 3).
    edge(2, 4).
    edge(3, 5).
    edge(4, 5).
    edge(1, 5).
    
    { in_cover(V) } :- vertex(V).
    
    :- edge(U, V), not in_cover(U), not in_cover(V).
    
    #minimize { 1,V : in_cover(V) }.
    """
    
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution_data = None
    
    def on_model(model):
        nonlocal solution_data
        
        vertex_cover = []
        for atom in model.symbols(atoms=True):
            if atom.name == "in_cover" and len(atom.arguments) == 1:
                vertex_id = atom.arguments[0].number
                vertex_cover.append(vertex_id)
        
        vertex_cover.sort()
        
        covered_edges = [
            [0, 1], [0, 2], [1, 3], [2, 3], 
            [2, 4], [3, 5], [4, 5], [1, 5]
        ]
        
        solution_data = {
            "vertex_cover": vertex_cover,
            "cover_size": len(vertex_cover),
            "covered_edges": covered_edges
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution_data
    else:
        return {"error": "No solution exists", "reason": "Problem is UNSAT"}

solution = solve_vertex_cover()
print(json.dumps(solution))
