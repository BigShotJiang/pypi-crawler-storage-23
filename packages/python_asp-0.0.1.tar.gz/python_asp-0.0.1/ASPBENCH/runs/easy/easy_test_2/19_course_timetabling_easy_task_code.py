import clingo
import json

def solve_course_scheduling():
    ctl = clingo.Control(["1"])
    
    program = """
    course(0, 0, 25).
    course(1, 1, 20).
    course(2, 2, 30).
    course(3, 1, 15).
    course(4, 0, 35).
    
    room(0, 40).
    room(1, 25).
    room(2, 20).
    
    time_slot(0).
    time_slot(1).
    time_slot(2).
    time_slot(3).
    
    teacher_available(0, 0).
    teacher_available(0, 1).
    teacher_available(0, 2).
    teacher_available(1, 1).
    teacher_available(1, 2).
    teacher_available(1, 3).
    teacher_available(2, 0).
    teacher_available(2, 2).
    teacher_available(2, 3).
    
    1 { assigned(C, R, T) : room(R, _), time_slot(T), 
                            course(C, Teacher, Students), 
                            teacher_available(Teacher, T),
                            room(R, Capacity), Students <= Capacity } 1 
        :- course(C, _, _).
    
    :- assigned(C1, R, T), assigned(C2, R, T), C1 != C2.
    
    :- assigned(C1, _, T), assigned(C2, _, T), 
       course(C1, Teacher, _), course(C2, Teacher, _), 
       C1 != C2.
    """
    
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution = None
    
    def on_model(m):
        nonlocal solution
        solution = {"assignments": []}
        
        for atom in m.symbols(atoms=True):
            if atom.name == "assigned" and len(atom.arguments) == 3:
                course_id = atom.arguments[0].number
                room_id = atom.arguments[1].number
                time_slot_id = atom.arguments[2].number
                
                solution["assignments"].append({
                    "course": course_id,
                    "room": room_id,
                    "time_slot": time_slot_id
                })
        
        solution["assignments"].sort(key=lambda x: x["course"])
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution
    else:
        return {"error": "No solution exists", 
                "reason": "Constraints cannot be satisfied"}

solution = solve_course_scheduling()
print(json.dumps(solution, indent=2))
