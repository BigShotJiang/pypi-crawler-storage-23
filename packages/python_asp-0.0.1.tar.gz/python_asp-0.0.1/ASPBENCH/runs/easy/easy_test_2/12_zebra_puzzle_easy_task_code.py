import clingo
import json

def solve_zebra_puzzle():
    ctl = clingo.Control(["1"])
    
    program = """
    house(1..5).
    
    color(red; green; white; yellow; blue).
    nationality(brit; swede; dane; norwegian; german).
    drink(tea; coffee; milk; beer; water).
    cigarette(pall_mall; dunhill; blends; blue_master; prince).
    pet(dog; birds; cats; horse; zebra).
    
    1 { has_color(H, C) : color(C) } 1 :- house(H).
    1 { has_nationality(H, N) : nationality(N) } 1 :- house(H).
    1 { has_drink(H, D) : drink(D) } 1 :- house(H).
    1 { has_cigarette(H, C) : cigarette(C) } 1 :- house(H).
    1 { has_pet(H, P) : pet(P) } 1 :- house(H).
    
    1 { has_color(H, C) : house(H) } 1 :- color(C).
    1 { has_nationality(H, N) : house(H) } 1 :- nationality(N).
    1 { has_drink(H, D) : house(H) } 1 :- drink(D).
    1 { has_cigarette(H, C) : house(H) } 1 :- cigarette(C).
    1 { has_pet(H, P) : house(H) } 1 :- pet(P).
    
    :- has_nationality(H, brit), not has_color(H, red).
    :- has_color(H, red), not has_nationality(H, brit).
    
    :- has_nationality(H, swede), not has_pet(H, dog).
    :- has_pet(H, dog), not has_nationality(H, swede).
    
    :- has_nationality(H, dane), not has_drink(H, tea).
    :- has_drink(H, tea), not has_nationality(H, dane).
    
    :- has_color(H, green), not has_color(H+1, white).
    :- has_color(H, white), not has_color(H-1, green).
    
    :- has_color(H, green), not has_drink(H, coffee).
    :- has_drink(H, coffee), not has_color(H, green).
    
    :- has_cigarette(H, pall_mall), not has_pet(H, birds).
    :- has_pet(H, birds), not has_cigarette(H, pall_mall).
    
    :- has_color(H, yellow), not has_cigarette(H, dunhill).
    :- has_cigarette(H, dunhill), not has_color(H, yellow).
    
    :- not has_drink(3, milk).
    
    :- not has_nationality(1, norwegian).
    
    :- has_cigarette(H, blends), not has_pet(H-1, cats), 
       not has_pet(H+1, cats).
    
    :- has_pet(H, horse), not has_cigarette(H-1, dunhill), 
       not has_cigarette(H+1, dunhill).
    
    :- has_cigarette(H, blue_master), not has_drink(H, beer).
    :- has_drink(H, beer), not has_cigarette(H, blue_master).
    
    :- has_nationality(H, german), not has_cigarette(H, prince).
    :- has_cigarette(H, prince), not has_nationality(H, german).
    
    :- has_nationality(H, norwegian), not has_color(H-1, blue), 
       not has_color(H+1, blue).
    
    :- has_cigarette(H, blends), not has_drink(H-1, water), 
       not has_drink(H+1, water).
    """
    
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution_data = None
    
    def on_model(model):
        nonlocal solution_data
        atoms = model.symbols(atoms=True)
        
        houses = {}
        for h in range(1, 6):
            houses[h] = {"house": h}
        
        for atom in atoms:
            if atom.name == "has_color" and len(atom.arguments) == 2:
                h = atom.arguments[0].number
                c = str(atom.arguments[1])
                houses[h]["color"] = c.capitalize()
            elif atom.name == "has_nationality" and len(atom.arguments) == 2:
                h = atom.arguments[0].number
                n = str(atom.arguments[1])
                houses[h]["nationality"] = n.capitalize()
            elif atom.name == "has_drink" and len(atom.arguments) == 2:
                h = atom.arguments[0].number
                d = str(atom.arguments[1])
                houses[h]["drink"] = d.capitalize()
            elif atom.name == "has_cigarette" and len(atom.arguments) == 2:
                h = atom.arguments[0].number
                c = str(atom.arguments[1])
                if c == "pall_mall":
                    c = "Pall Mall"
                elif c == "blue_master":
                    c = "Blue Master"
                else:
                    c = c.capitalize()
                houses[h]["cigarette"] = c
            elif atom.name == "has_pet" and len(atom.arguments) == 2:
                h = atom.arguments[0].number
                p = str(atom.arguments[1])
                houses[h]["pet"] = p.capitalize()
        
        zebra_owner = None
        for h in range(1, 6):
            if houses[h].get("pet") == "Zebra":
                zebra_owner = houses[h].get("nationality")
                break
        
        solution_data = {
            "solution": [houses[h] for h in range(1, 6)],
            "zebra_owner": zebra_owner
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable and solution_data:
        return solution_data
    else:
        return {"error": "No solution exists", 
                "reason": "Constraints are unsatisfiable"}

solution = solve_zebra_puzzle()
print(json.dumps(solution, indent=2))
