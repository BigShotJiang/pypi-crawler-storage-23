import clingo
import json

def solve_blocks_world():
    ctl = clingo.Control(["1"])
    
    program = """
    block(a; b; c).
    location(table; a; b; c).
    
    #const max_time = 3.
    time(0..max_time).
    
    on(a, table, 0).
    on(b, table, 0).
    on(c, a, 0).
    
    goal_on(a, b).
    goal_on(b, c).
    goal_on(c, table).
    
    clear(B, T) :- block(B), time(T), not has_block_on_top(B, T).
    has_block_on_top(B, T) :- on(B2, B, T), block(B2), B2 != B.
    
    clear(table, T) :- time(T).
    
    1 { move(B, From, To, T) : 
        on(B, From, T), clear(B, T),
        clear(To, T), location(To),
        From != To, B != To, B != From
    } 1 :- time(T), T < max_time.
    
    :- move(B, _, _, T), has_block_on_top(B, T).
    
    :- move(B, _, To, T), not clear(To, T), To != table.
    
    :- move(B, _, B, _).
    
    on(B, To, T+1) :- move(B, From, To, T).
    
    on(B, L, T+1) :- on(B, L, T), time(T+1), not move(B, L, _, T).
    
    :- on(B, L1, T), on(B, L2, T), L1 != L2.
    
    :- on(B1, L, T), on(B2, L, T), B1 != B2, L != table.
    
    :- goal_on(B, L), not on(B, L, max_time).
    
    #minimize { 1,B,F,To,T : move(B,F,To,T) }.
    """
    
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution = None
    
    def on_model(m):
        nonlocal solution
        atoms = m.symbols(atoms=True)
        
        moves = []
        for atom in atoms:
            if atom.name == "move" and len(atom.arguments) == 4:
                block = str(atom.arguments[0])
                from_loc = str(atom.arguments[1])
                to_loc = str(atom.arguments[2])
                time_step = atom.arguments[3].number
                
                moves.append({
                    "step": time_step + 1,
                    "action": "move",
                    "block": block.upper(),
                    "from": from_loc if from_loc == "table" else from_loc.upper(),
                    "to": to_loc if to_loc == "table" else to_loc.upper()
                })
        
        moves.sort(key=lambda x: x["step"])
        
        solution = {
            "plan_length": len(moves),
            "actions": moves
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable and solution:
        return solution
    else:
        return {"error": "No solution exists", 
                "reason": "Problem is unsatisfiable"}

solution = solve_blocks_world()
print(json.dumps(solution, indent=2))
