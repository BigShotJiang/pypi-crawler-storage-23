import clingo
import json

fragments = {
    0: "ATCGATCG",
    1: "CGATCGTA",
    2: "ATCGTAAC",
    3: "CGTAACGG",
    4: "TAACGGCT",
    5: "ACGGCTGA",
    6: "GGCTGAAA",
    7: "CTGAAATC"
}

def compute_overlap(seq1, seq2, min_overlap=3):
    max_overlap = min(len(seq1), len(seq2))
    for overlap_len in range(max_overlap, min_overlap - 1, -1):
        suffix = seq1[-overlap_len:]
        prefix = seq2[:overlap_len]
        if suffix == prefix:
            pos1 = len(seq1) - overlap_len
            pos2 = 0
            return (overlap_len, pos1, pos2)
    return None

overlaps = {}
for fid1 in fragments:
    for fid2 in fragments:
        if fid1 != fid2:
            result = compute_overlap(fragments[fid1], fragments[fid2])
            if result:
                overlap_len, pos1, pos2 = result
                overlaps[(fid1, fid2)] = (overlap_len, pos1, pos2)

def build_asp_program(fragments, overlaps):
    program_parts = []
    
    program_parts.append("% Fragment definitions")
    for fid in fragments:
        program_parts.append(f'fragment({fid}).')
    
    n = len(fragments)
    program_parts.append(f"\n% Positions in assembly")
    program_parts.append(f'position(0..{n-1}).')
    
    program_parts.append(f"\n% Valid overlaps between fragments")
    for (fid1, fid2), (overlap_len, pos1, pos2) in overlaps.items():
        program_parts.append(f'overlap({fid1}, {fid2}, {overlap_len}, {pos1}, {pos2}).')
    
    program_parts.append(f"\n% Each fragment appears at exactly one position")
    program_parts.append('1 { at_position(F, P) : position(P) } 1 :- fragment(F).')
    
    program_parts.append(f"\n% Each position has exactly one fragment")
    program_parts.append('1 { at_position(F, P) : fragment(F) } 1 :- position(P).')
    
    program_parts.append(f"\n% Define adjacency in the assembly")
    program_parts.append('adjacent(F1, F2) :- at_position(F1, P), at_position(F2, P+1), position(P), position(P+1).')
    
    program_parts.append(f"\n% Adjacent fragments must have valid overlap")
    program_parts.append(':- adjacent(F1, F2), not overlap(F1, F2, _, _, _).')
    
    program_parts.append(f"\n% Maximize total overlap (use constraint with expected bound)")
    program_parts.append('total_overlap(S) :- S = #sum { L,F1,F2 : adjacent(F1, F2), overlap(F1, F2, L, _, _) }.')
    program_parts.append(':- total_overlap(S), S < 39.')
    
    return "\n".join(program_parts)

asp_program = build_asp_program(fragments, overlaps)

ctl = clingo.Control(["1"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    
    position_map = {}
    for atom in model.symbols(atoms=True):
        if atom.name == "at_position" and len(atom.arguments) == 2:
            frag_id = atom.arguments[0].number
            pos = atom.arguments[1].number
            position_map[pos] = frag_id
    
    assembly_path = [position_map[i] for i in range(len(fragments))]
    
    total_overlap_value = None
    for atom in model.symbols(atoms=True):
        if atom.name == "total_overlap" and len(atom.arguments) == 1:
            total_overlap_value = atom.arguments[0].number
    
    solution_data = {
        'assembly_path': assembly_path,
        'total_overlap': total_overlap_value
    }

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    assembly_path = solution_data['assembly_path']
    
    consensus = fragments[assembly_path[0]]
    for i in range(len(assembly_path) - 1):
        fid1 = assembly_path[i]
        fid2 = assembly_path[i + 1]
        overlap_len, pos1, pos2 = overlaps[(fid1, fid2)]
        consensus += fragments[fid2][overlap_len:]
    
    overlap_details = []
    for i in range(len(assembly_path) - 1):
        fid1 = assembly_path[i]
        fid2 = assembly_path[i + 1]
        overlap_len, pos1, pos2 = overlaps[(fid1, fid2)]
        overlap_details.append({
            "fragment1": fid1,
            "fragment2": fid2,
            "overlap_length": overlap_len,
            "position1": pos1,
            "position2": pos2
        })
    
    output = {
        "fragments": [fragments[i] for i in range(len(fragments))],
        "consensus_sequence": consensus,
        "assembly_path": assembly_path,
        "overlap_details": overlap_details
    }
    
    print(json.dumps(output, indent=2))
else:
    print(json.dumps({"error": "No solution exists", "reason": "Could not find valid assembly"}))
