import clingo
import json

def create_asp_program():
    program = """
    bid(1, "A", 100).
    bid_item(1, "item1"). bid_item(1, "item2").
    
    bid(2, "A", 50).
    bid_item(2, "item3").
    
    bid(3, "B", 120).
    bid_item(3, "item2"). bid_item(3, "item3").
    
    bid(4, "B", 80).
    bid_item(4, "item4"). bid_item(4, "item5").
    
    bid(5, "C", 150).
    bid_item(5, "item1"). bid_item(5, "item3"). bid_item(5, "item5").
    
    bid(6, "D", 40).
    bid_item(6, "item4").
    
    item("item1"; "item2"; "item3"; "item4"; "item5").
    
    { win(BidID) } :- bid(BidID, _, _).
    
    allocated(Item, Bidder) :- win(BidID), bid(BidID, Bidder, _), bid_item(BidID, Item).
    
    :- allocated(Item, Bidder1), allocated(Item, Bidder2), Bidder1 != Bidder2.
    
    total_revenue(Total) :- Total = #sum { Price, BidID : win(BidID), bid(BidID, _, Price) }.
    
    :- total_revenue(Total), Total < 230.
    
    #show win/1.
    #show allocated/2.
    #show total_revenue/1.
    """
    return program

def solve_auction():
    ctl = clingo.Control(["1"])
    
    program = create_asp_program()
    ctl.add("base", [], program)
    
    ctl.ground([("base", [])])
    
    solution_data = None
    
    def on_model(model):
        nonlocal solution_data
        
        winning_bids = []
        total_rev = 0
        item_allocation = {}
        
        bid_info = {
            1: ("A", ["item1", "item2"], 100),
            2: ("A", ["item3"], 50),
            3: ("B", ["item2", "item3"], 120),
            4: ("B", ["item4", "item5"], 80),
            5: ("C", ["item1", "item3", "item5"], 150),
            6: ("D", ["item4"], 40)
        }
        
        for atom in model.symbols(atoms=True):
            if atom.name == "win" and len(atom.arguments) == 1:
                bid_id = atom.arguments[0].number
                bidder, items, price = bid_info[bid_id]
                winning_bids.append({
                    "bidder": bidder,
                    "items": items,
                    "price": price
                })
                total_rev += price
                for item in items:
                    item_allocation[item] = bidder
            
            elif atom.name == "total_revenue" and len(atom.arguments) == 1:
                total_rev = atom.arguments[0].number
        
        all_items = ["item1", "item2", "item3", "item4", "item5"]
        for item in all_items:
            if item not in item_allocation:
                item_allocation[item] = None
        
        solution_data = {
            "winning_bids": winning_bids,
            "total_revenue": total_rev,
            "item_allocation": item_allocation
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution_data
    else:
        return {"error": "No solution exists", "reason": "Constraints cannot be satisfied"}

solution = solve_auction()
print(json.dumps(solution, indent=2))
