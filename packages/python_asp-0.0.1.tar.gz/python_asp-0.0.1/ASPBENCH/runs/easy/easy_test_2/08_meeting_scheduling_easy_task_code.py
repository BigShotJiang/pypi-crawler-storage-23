import clingo
import json


def generate_asp_program():
    """Generate the complete ASP program for meeting scheduling"""
    
    program = """
meeting(m1; m2; m3; m4; m5).
day(1; 2; 3).
slot(1; 2; 3).
room(r1; r2).
person(p1; p2; p3; p4; p5).

requires(m1, p1). requires(m1, p2). requires(m1, p3).
requires(m2, p1). requires(m2, p5).
requires(m3, p2). requires(m3, p3).
requires(m4, p1). requires(m4, p4).
requires(m5, p1). requires(m5, p2). requires(m5, p3).

prefers(m1, 1, 1).
prefers(m2, 1, 2).
prefers(m4, 3, 3).

1 { scheduled(M, D, S, R) : day(D), slot(S), room(R) } 1 :- meeting(M).

:- scheduled(M1, D, S, _), scheduled(M2, D, S, _), M1 != M2,
   requires(M1, P), requires(M2, P).

:- scheduled(M1, D, S, R), scheduled(M2, D, S, R), M1 != M2.

violation(M) :- meeting(M), prefers(M, PD, PS), scheduled(M, D, S, _), 
                (D, S) != (PD, PS).

:- #count { M : violation(M) } > 0.
"""
    
    return program


def solve_meeting_schedule():
    """Solve the meeting scheduling problem using clingo"""
    
    ctl = clingo.Control(["1"])
    
    ctl.add("base", [], generate_asp_program())
    
    ctl.ground([("base", [])])
    
    solution_data = None
    
    def on_model(model):
        nonlocal solution_data
        
        schedule = []
        violations = []
        
        for atom in model.symbols(atoms=True):
            if atom.name == "scheduled" and len(atom.arguments) == 4:
                meeting = str(atom.arguments[0])
                day = atom.arguments[1].number
                slot = atom.arguments[2].number
                room = str(atom.arguments[3])
                
                schedule.append({
                    "meeting": meeting,
                    "day": day,
                    "slot": slot,
                    "room": room
                })
            
            elif atom.name == "violation" and len(atom.arguments) == 1:
                meeting = str(atom.arguments[0])
                violations.append(meeting)
        
        schedule.sort(key=lambda x: x["meeting"])
        
        solution_data = {
            "schedule": schedule,
            "conflicts": [],
            "preference_violations": len(violations),
            "feasible": True
        }
    
    result = ctl.solve(on_model=on_model)
    
    if not result.satisfiable:
        solution_data = {
            "schedule": [],
            "conflicts": ["No feasible schedule exists"],
            "preference_violations": -1,
            "feasible": False
        }
    
    return solution_data


if __name__ == "__main__":
    solution = solve_meeting_schedule()
    print(json.dumps(solution, indent=2))
