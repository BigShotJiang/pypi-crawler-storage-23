import clingo
import json

asp_program = """
% Grid dimensions
row(0..4).
col(0..4).

% Words with their properties
word(0, "CODE", 4, "Programming instructions").
word(1, "DATA", 4, "Information").
word(2, "TECH", 4, "Technology short").
word(3, "CHIP", 4, "Computer component").
word(4, "BYTE", 4, "Data unit").
word(5, "NET", 3, "Internet short").

% Directions
direction(h).
direction(v).

% Letter positions in each word
letter(0, 0, "C"). letter(0, 1, "O"). letter(0, 2, "D"). letter(0, 3, "E").
letter(1, 0, "D"). letter(1, 1, "A"). letter(1, 2, "T"). letter(1, 3, "A").
letter(2, 0, "T"). letter(2, 1, "E"). letter(2, 2, "C"). letter(2, 3, "H").
letter(3, 0, "C"). letter(3, 1, "H"). letter(3, 2, "I"). letter(3, 3, "P").
letter(4, 0, "B"). letter(4, 1, "Y"). letter(4, 2, "T"). letter(4, 3, "E").
letter(5, 0, "N"). letter(5, 1, "E"). letter(5, 2, "T").

% Each word must be placed exactly once
1 { placed(W, R, C, D) : row(R), col(C), direction(D) } 1 :- word(W, _, _, _).

% Constraint: Word must fit within grid bounds
:- placed(W, R, C, h), word(W, _, Len, _), C + Len - 1 > 4.
:- placed(W, R, C, v), word(W, _, Len, _), R + Len - 1 > 4.

% Define which grid cells are occupied by which letters
cell(R, C + Pos, L) :- placed(W, R, C, h), letter(W, Pos, L).
cell(R + Pos, C, L) :- placed(W, R, C, v), letter(W, Pos, L).

% Constraint: No conflicts
:- cell(R, C, L1), cell(R, C, L2), L1 != L2.

% Define intersections
intersection_cell(R, C) :- cell(R, C, L), 
    #count { W : placed(W, WR, WC, h), WC <= C, C < WC + WLen, WR = R, 
             word(W, _, WLen, _) ;
             W : placed(W, WR, WC, v), WR <= R, R < WR + WLen, WC = C, 
             word(W, _, WLen, _) } >= 2.

% Require at least 3 intersections
:- #count { R, C : intersection_cell(R, C) } < 3.

% Minimize empty cells
#minimize { 1@1,R,C : row(R), col(C), not cell(R,C,_) }.
"""

words_data = [
    (0, "CODE", 4, "Programming instructions"),
    (1, "DATA", 4, "Information"),
    (2, "TECH", 4, "Technology short"),
    (3, "CHIP", 4, "Computer component"),
    (4, "BYTE", 4, "Data unit"),
    (5, "NET", 3, "Internet short")
]

word_letters = {
    0: ["C", "O", "D", "E"],
    1: ["D", "A", "T", "A"],
    2: ["T", "E", "C", "H"],
    3: ["C", "H", "I", "P"],
    4: ["B", "Y", "T", "E"],
    5: ["N", "E", "T"]
}

ctl = clingo.Control(["1"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    atoms = model.symbols(atoms=True)
    
    placements = []
    for atom in atoms:
        if atom.name == "placed" and len(atom.arguments) == 4:
            word_id = atom.arguments[0].number
            row = atom.arguments[1].number
            col = atom.arguments[2].number
            direction = str(atom.arguments[3])
            placements.append((word_id, row, col, direction))
    
    cells = {}
    for atom in atoms:
        if atom.name == "cell" and len(atom.arguments) == 3:
            row = atom.arguments[0].number
            col = atom.arguments[1].number
            letter = str(atom.arguments[2]).strip('"')
            cells[(row, col)] = letter
    
    solution_data = {
        'placements': placements,
        'cells': cells
    }

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    grid = [[" " for _ in range(5)] for _ in range(5)]
    for (row, col), letter in solution_data['cells'].items():
        grid[row][col] = letter
    
    words_output = []
    for word_id, row, col, direction in sorted(solution_data['placements']):
        word_info = words_data[word_id]
        words_output.append({
            "word": word_info[1],
            "position": [row, col],
            "direction": "horizontal" if direction == "h" else "vertical",
            "clue": word_info[3]
        })
    
    word_placements = []
    for i, (word_id, row, col, direction) in enumerate(
            sorted(solution_data['placements'])):
        word_text = words_data[word_id][1]
        letters = word_letters[word_id]
        word_placements.append((i, word_text, row, col, direction, letters))
    
    intersections = []
    for i in range(len(word_placements)):
        idx1, word1, row1, col1, dir1, letters1 = word_placements[i]
        
        for j in range(i+1, len(word_placements)):
            idx2, word2, row2, col2, dir2, letters2 = word_placements[j]
            
            for pos1, letter1 in enumerate(letters1):
                if dir1 == "h":
                    r1, c1 = row1, col1 + pos1
                else:
                    r1, c1 = row1 + pos1, col1
                
                for pos2, letter2 in enumerate(letters2):
                    if dir2 == "h":
                        r2, c2 = row2, col2 + pos2
                    else:
                        r2, c2 = row2 + pos2, col2
                    
                    if r1 == r2 and c1 == c2 and letter1 == letter2:
                        intersections.append({
                            "word1": i,
                            "word2": j,
                            "position1": pos1,
                            "position2": pos2,
                            "letter": letter1
                        })
    
    final_output = {
        "grid": grid,
        "words": words_output,
        "theme": "Technology",
        "intersections": intersections
    }
    
    print(json.dumps(final_output, indent=2))
else:
    print(json.dumps({"error": "No solution exists", 
                      "reason": "Could not place all words with required intersections"}))
