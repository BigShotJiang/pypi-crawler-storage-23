import clingo
import json

program = """
person(0).
person(1).
person(2).

victim(0).

{ hates(P1, P2) : person(P2) } :- person(P1).
{ richer(P1, P2) : person(P2), P1 != P2 } :- person(P1).

1 { killed(P, 0) : person(P) } 1.

:- killed(Killer, Victim), not hates(Killer, Victim).
:- killed(Killer, Victim), richer(Killer, Victim).
:- hates(0, P), hates(2, P).

hates(0, 0).
hates(0, 2).
:- hates(0, 1).

hates(1, P) :- person(P), not richer(P, 0).
hates(1, P) :- hates(0, P).

:- person(P1), not has_someone_not_hated(P1).
has_someone_not_hated(P1) :- person(P1), person(P2), not hates(P1, P2).

#show killed/2.
"""

ctl = clingo.Control(["1"])
ctl.add("base", [], program)
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    atoms = model.symbols(atoms=True)
    
    for atom in atoms:
        if atom.name == "killed" and len(atom.arguments) == 2:
            killer = atom.arguments[0].number
            solution_data = {"killer": killer}
            break

result = ctl.solve(on_model=on_model)

if result.satisfiable and solution_data:
    names = ["Agatha", "Butler", "Charles"]
    output = {
        "killer": solution_data["killer"],
        "killer_name": names[solution_data["killer"]]
    }
    print(json.dumps(output))
else:
    print(json.dumps({"error": "No solution exists"}))
