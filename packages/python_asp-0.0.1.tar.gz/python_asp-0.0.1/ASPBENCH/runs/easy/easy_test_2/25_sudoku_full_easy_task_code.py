import clingo
import json

def generate_sudoku_asp_program(clues):
    """Generate ASP program for Sudoku puzzle"""
    program_parts = []
    
    program_parts.append("row(1..9). col(1..9). digit(1..9).")
    program_parts.append("box(R, C, B) :- row(R), col(C), B = ((R-1)/3)*3 + (C-1)/3 + 1.")
    
    for r in range(9):
        for c in range(9):
            if clues[r][c] != 0:
                program_parts.append(f"clue({r+1}, {c+1}, {clues[r][c]}).")
    
    program_parts.append("1 { cell(R, C, D) : digit(D) } 1 :- row(R), col(C).")
    program_parts.append(":- clue(R, C, D), not cell(R, C, D).")
    program_parts.append(":- row(R), digit(D), #count { C : cell(R, C, D) } != 1.")
    program_parts.append(":- col(C), digit(D), #count { R : cell(R, C, D) } != 1.")
    program_parts.append(":- digit(D), B = 1..9, #count { R, C : cell(R, C, D), box(R, C, B) } != 1.")
    
    return "\n".join(program_parts)

def solve_sudoku(asp_program):
    """Solve Sudoku using clingo and extract solution"""
    ctl = clingo.Control(["1"])
    ctl.add("base", [], asp_program)
    ctl.ground([("base", [])])
    
    solution_grid = None
    
    def on_model(model):
        nonlocal solution_grid
        solution_grid = [[0 for _ in range(9)] for _ in range(9)]
        for atom in model.symbols(atoms=True):
            if atom.name == "cell" and len(atom.arguments) == 3:
                row = atom.arguments[0].number - 1
                col = atom.arguments[1].number - 1
                digit = atom.arguments[2].number
                solution_grid[row][col] = digit
    
    result = ctl.solve(on_model=on_model)
    return solution_grid if result.satisfiable and solution_grid is not None else None

def verify_sudoku_solution(grid, original_clues):
    """Verify that the solution satisfies all Sudoku constraints"""
    clues_preserved = True
    for r in range(9):
        for c in range(9):
            if original_clues[r][c] != 0:
                if grid[r][c] != original_clues[r][c]:
                    clues_preserved = False
                    break
        if not clues_preserved:
            break
    
    rows_valid = all(sorted(grid[r]) == list(range(1, 10)) for r in range(9))
    cols_valid = all(sorted([grid[r][c] for r in range(9)]) == list(range(1, 10)) for c in range(9))
    
    boxes_valid = True
    for box_row in range(3):
        for box_col in range(3):
            box = []
            for r in range(box_row * 3, box_row * 3 + 3):
                for c in range(box_col * 3, box_col * 3 + 3):
                    box.append(grid[r][c])
            if sorted(box) != list(range(1, 10)):
                boxes_valid = False
                break
        if not boxes_valid:
            break
    
    is_valid = clues_preserved and rows_valid and cols_valid and boxes_valid
    return {"is_valid": is_valid, "clues_preserved": clues_preserved}

clues = [
    [5, 3, 0, 0, 7, 0, 0, 0, 0],
    [6, 0, 0, 1, 9, 5, 0, 0, 0],
    [0, 9, 8, 0, 0, 0, 0, 6, 0],
    [8, 0, 0, 0, 6, 0, 0, 0, 3],
    [4, 0, 0, 8, 0, 3, 0, 0, 1],
    [7, 0, 0, 0, 2, 0, 0, 0, 6],
    [0, 6, 0, 0, 0, 0, 2, 8, 0],
    [0, 0, 0, 4, 1, 9, 0, 0, 5],
    [0, 0, 0, 0, 8, 0, 0, 7, 9]
]

asp_program = generate_sudoku_asp_program(clues)
solution = solve_sudoku(asp_program)

if solution:
    verification = verify_sudoku_solution(solution, clues)
    output = {
        "grid": solution,
        "is_valid": verification["is_valid"],
        "clues_preserved": verification["clues_preserved"]
    }
    print(json.dumps(output, indent=2))
else:
    print(json.dumps({"error": "No solution exists"}))
