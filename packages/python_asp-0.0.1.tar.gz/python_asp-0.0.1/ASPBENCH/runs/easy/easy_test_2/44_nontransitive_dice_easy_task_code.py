import clingo
import json

asp_program = """
die(a; b; c).
face_position(1..6).
face_value(0..6).

1 { has_value(D, Pos, Val) : face_value(Val) } 1 :- die(D), face_position(Pos).

wins(D1, D2, P1, P2) :- 
    has_value(D1, P1, V1), 
    has_value(D2, P2, V2),
    D1 != D2,
    V1 > V2.

win_count(D1, D2, Count) :- 
    die(D1), die(D2), D1 != D2,
    Count = #count { P1, P2 : wins(D1, D2, P1, P2) }.

:- win_count(a, b, Count), Count <= 18.
:- win_count(b, c, Count), Count <= 18.
:- win_count(c, a, Count), Count <= 18.

#show has_value/3.
#show win_count/3.
"""

ctl = clingo.Control(["1"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    
    dice = {"a": [None]*6, "b": [None]*6, "c": [None]*6}
    win_counts = {}
    
    for atom in model.symbols(atoms=True):
        if atom.name == "has_value" and len(atom.arguments) == 3:
            die = str(atom.arguments[0])
            position = atom.arguments[1].number - 1
            value = atom.arguments[2].number
            dice[die][position] = value
            
        elif atom.name == "win_count" and len(atom.arguments) == 3:
            die1 = str(atom.arguments[0])
            die2 = str(atom.arguments[1])
            count = atom.arguments[2].number
            win_counts[f"{die1}_vs_{die2}"] = count
    
    solution_data = {
        "dice": dice,
        "win_counts": win_counts
    }

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    a_beats_b = solution_data['win_counts'].get('a_vs_b', 0) / 36.0
    b_beats_c = solution_data['win_counts'].get('b_vs_c', 0) / 36.0
    c_beats_a = solution_data['win_counts'].get('c_vs_a', 0) / 36.0
    
    output = {
        "dice": {
            "A": solution_data['dice']['a'],
            "B": solution_data['dice']['b'],
            "C": solution_data['dice']['c']
        },
        "win_probabilities": {
            "A_beats_B": round(a_beats_b, 3),
            "B_beats_C": round(b_beats_c, 3),
            "C_beats_A": round(c_beats_a, 3)
        }
    }
    
    print(json.dumps(output, indent=2))
else:
    print(json.dumps({"error": "No solution exists"}))
