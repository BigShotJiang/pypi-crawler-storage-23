import random
import json


class Strategy:
    def __init__(self, name):
        self.name = name
        self.reset()
    
    def reset(self):
        self.history = []
        self.opponent_history = []
    
    def play(self, opponent_last_move=None):
        raise NotImplementedError


class COOP(Strategy):
    def play(self, opponent_last_move=None):
        return 'C'


class DEFECT(Strategy):
    def play(self, opponent_last_move=None):
        return 'D'


class TFT(Strategy):
    def play(self, opponent_last_move=None):
        if opponent_last_move is None:
            return 'C'
        return opponent_last_move


class GTFT(Strategy):
    def play(self, opponent_last_move=None):
        if opponent_last_move is None:
            return 'C'
        if opponent_last_move == 'D':
            if random.random() < 0.1:
                return 'C'
        return opponent_last_move


class RAND(Strategy):
    def play(self, opponent_last_move=None):
        return 'C' if random.random() < 0.5 else 'D'


def get_payoff(move1, move2):
    if move1 == 'C' and move2 == 'C':
        return 3
    elif move1 == 'D' and move2 == 'D':
        return 1
    elif move1 == 'D' and move2 == 'C':
        return 5
    else:
        return 0


def play_match(strategy1, strategy2, rounds=100):
    strategy1.reset()
    strategy2.reset()
    
    score1 = 0
    score2 = 0
    
    last_move1 = None
    last_move2 = None
    
    for _ in range(rounds):
        move1 = strategy1.play(last_move2)
        move2 = strategy2.play(last_move1)
        
        score1 += get_payoff(move1, move2)
        score2 += get_payoff(move2, move1)
        
        last_move1 = move1
        last_move2 = move2
    
    return score1, score2


def create_strategy(name):
    if name == 'COOP':
        return COOP(name)
    elif name == 'DEFECT':
        return DEFECT(name)
    elif name == 'TFT':
        return TFT(name)
    elif name == 'GTFT':
        return GTFT(name)
    else:
        return RAND(name)


def run_tournament(num_simulations=10000):
    strategy_names = ['COOP', 'DEFECT', 'TFT', 'GTFT', 'RAND']
    
    accumulated_scores = {name: 0.0 for name in strategy_names}
    
    random.seed(42)
    
    for sim in range(num_simulations):
        sim_scores = {name: 0 for name in strategy_names}
        
        for name1 in strategy_names:
            for name2 in strategy_names:
                s1 = create_strategy(name1)
                s2 = create_strategy(name2)
                
                score1, score2 = play_match(s1, s2, 100)
                sim_scores[name1] += score1
        
        for name in strategy_names:
            accumulated_scores[name] += sim_scores[name]
    
    final_scores = {name: accumulated_scores[name] / num_simulations 
                    for name in strategy_names}
    
    return final_scores


def format_results(scores):
    sorted_results = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    
    tournament_results = [
        {"strategy": name, "total_score": int(round(score))}
        for name, score in sorted_results
    ]
    
    winner = sorted_results[0][0]
    
    return {
        "tournament_results": tournament_results,
        "winner": winner
    }


if __name__ == "__main__":
    scores = run_tournament(num_simulations=10000)
    output = format_results(scores)
    print(json.dumps(output, indent=2))
