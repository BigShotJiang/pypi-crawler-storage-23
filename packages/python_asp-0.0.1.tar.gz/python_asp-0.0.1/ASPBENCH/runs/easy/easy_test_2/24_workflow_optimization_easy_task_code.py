import clingo
import json


def generate_asp_program(tasks, expected_makespan=17):
    """Generate ASP program for task scheduling"""
    facts = []
    
    for task_id, duration, prereqs in tasks:
        facts.append(f'task({task_id}, {duration}).')
        for prereq in prereqs:
            facts.append(f'prerequisite({task_id}, {prereq}).')
    
    facts.append(f'time(0..{expected_makespan}).')
    
    asp_program = "\n".join(facts) + """

% Each task starts at exactly one time
1 { start(T, Time) : time(Time) } 1 :- task(T, _).

% Calculate end time for each task
end(T, Time + D) :- start(T, Time), task(T, D).

% Precedence constraint: task cannot start until all prerequisites complete
:- start(T, StartT), prerequisite(T, PrereqT), end(PrereqT, EndPrereq), 
   StartT < EndPrereq.

% Calculate makespan (maximum end time)
makespan(M) :- M = #max { EndT : end(_, EndT) }.

% Constraint: makespan must not exceed expected optimal
:- makespan(M), M > """ + str(expected_makespan) + """.

% Minimize makespan
#minimize { M : makespan(M) }.
"""
    
    return asp_program


def find_critical_path(tasks, schedule):
    """Find the critical path - longest dependency chain determining makespan"""
    task_dict = {t[0]: {"duration": t[1], "prereqs": t[2]} for t in tasks}
    
    last_task_id = max(schedule.items(), key=lambda x: x[1]["end"])[0]
    
    def backtrack_critical_path(task_id):
        prereqs = task_dict[task_id]["prereqs"]
        
        if not prereqs:
            return [task_id]
        
        task_start = schedule[task_id]["start"]
        
        critical_prereq = None
        for prereq in prereqs:
            if schedule[prereq]["end"] == task_start:
                critical_prereq = prereq
                break
        
        if critical_prereq is None:
            critical_prereq = max(prereqs, key=lambda p: schedule[p]["end"])
        
        path = backtrack_critical_path(critical_prereq)
        path.append(task_id)
        return path
    
    return backtrack_critical_path(last_task_id)


def solve_scheduling(tasks, expected_makespan=17):
    """Solve task scheduling problem using ASP"""
    ctl = clingo.Control(["1"])
    
    program = generate_asp_program(tasks, expected_makespan)
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution = None
    
    def on_model(model):
        nonlocal solution
        atoms = model.symbols(atoms=True)
        
        schedule = {}
        makespan_value = 0
        
        for atom in atoms:
            if atom.name == "start" and len(atom.arguments) == 2:
                task_id = atom.arguments[0].number
                start_time = atom.arguments[1].number
                schedule[task_id] = {"start": start_time}
            
            elif atom.name == "end" and len(atom.arguments) == 2:
                task_id = atom.arguments[0].number
                end_time = atom.arguments[1].number
                if task_id in schedule:
                    schedule[task_id]["end"] = end_time
                else:
                    schedule[task_id] = {"end": end_time}
            
            elif atom.name == "makespan" and len(atom.arguments) == 1:
                makespan_value = atom.arguments[0].number
        
        solution = {
            "schedule": schedule,
            "makespan": makespan_value
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution
    else:
        return None


def format_solution(tasks, schedule, makespan, critical_path):
    """Format solution according to required JSON structure"""
    schedule_array = []
    for task_id in sorted(schedule.keys()):
        task_info = schedule[task_id]
        schedule_array.append({
            "task": task_id,
            "start_time": task_info["start"],
            "end_time": task_info["end"]
        })
    
    return {
        "schedule": schedule_array,
        "makespan": makespan,
        "critical_path": critical_path
    }


if __name__ == "__main__":
    task_data = [
        (0, 3, []),
        (1, 2, []),
        (2, 4, [0]),
        (3, 1, [1]),
        (4, 5, [2, 3]),
        (5, 2, [0]),
        (6, 3, [4]),
        (7, 2, [5, 6])
    ]
    
    solution = solve_scheduling(task_data, expected_makespan=17)
    
    if solution:
        critical_path = find_critical_path(task_data, solution["schedule"])
        final_solution = format_solution(
            task_data,
            solution["schedule"],
            solution["makespan"],
            critical_path
        )
        print(json.dumps(final_solution, indent=2))
    else:
        print(json.dumps({"error": "No solution exists"}))
