import clingo
import json


def generate_asp_program():
    program = """
    vertex(0..7).
    
    edge(0,1). edge(0,4).
    edge(1,2). edge(1,5).
    edge(2,3). edge(2,6).
    edge(3,7).
    edge(4,5). edge(4,6).
    edge(5,7).
    edge(6,7).
    
    { in_partition_1(V) : vertex(V) }.
    
    :- #count { V : in_partition_1(V) } != 4.
    
    cut_edge(V1, V2) :- edge(V1, V2), in_partition_1(V1), 
                        not in_partition_1(V2).
    cut_edge(V1, V2) :- edge(V1, V2), not in_partition_1(V1), 
                        in_partition_1(V2).
    
    cut_size(N) :- N = #count { V1, V2 : cut_edge(V1, V2) }.
    
    :- cut_size(N), N > 3.
    """
    return program


def solve_partition():
    ctl = clingo.Control(["1"])
    
    program = generate_asp_program()
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution_data = None
    
    def on_model(m):
        nonlocal solution_data
        atoms = m.symbols(atoms=True)
        
        partition_1 = []
        partition_2 = []
        cut_edges_set = set()
        
        for atom in atoms:
            if atom.name == "in_partition_1" and len(atom.arguments) == 1:
                vertex = atom.arguments[0].number
                partition_1.append(vertex)
        
        all_vertices = set(range(8))
        partition_1_set = set(partition_1)
        partition_2 = sorted(list(all_vertices - partition_1_set))
        partition_1 = sorted(partition_1)
        
        for atom in atoms:
            if atom.name == "cut_edge" and len(atom.arguments) == 2:
                v1 = atom.arguments[0].number
                v2 = atom.arguments[1].number
                edge = tuple(sorted([v1, v2]))
                cut_edges_set.add(edge)
        
        cut_edges = [{"from": e[0], "to": e[1]} 
                     for e in sorted(cut_edges_set)]
        cut_size = len(cut_edges)
        
        solution_data = {
            "partition_1": partition_1,
            "partition_2": partition_2,
            "cut_size": cut_size,
            "cut_edges": cut_edges,
            "balance": {
                "partition_1_size": len(partition_1),
                "partition_2_size": len(partition_2),
                "is_balanced": len(partition_1) == 4 and len(partition_2) == 4
            }
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable:
        return solution_data
    else:
        return {"error": "No solution exists", 
                "reason": "Problem is unsatisfiable"}


solution = solve_partition()
print(json.dumps(solution, indent=2))
