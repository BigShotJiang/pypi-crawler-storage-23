import clingo
import json

program = """
task(0, 50).
task(1, 40).
task(2, 60).
task(3, 35).
task(4, 70).
task(5, 45).

requires(0, a, 30).
requires(0, b, 20).
requires(0, c, 10).

requires(1, a, 25).
requires(1, b, 15).
requires(1, c, 15).

requires(2, a, 20).
requires(2, b, 30).
requires(2, c, 20).

requires(3, a, 15).
requires(3, b, 25).
requires(3, c, 10).

requires(4, a, 40).
requires(4, b, 10).
requires(4, c, 25).

requires(5, a, 20).
requires(5, b, 20).
requires(5, c, 15).

capacity(a, 100).
capacity(b, 80).
capacity(c, 60).

{ selected(T) } :- task(T, _).

:- capacity(R, Cap), 
   #sum { Amt,T : selected(T), requires(T, R, Amt) } > Cap.

:- #sum { V,T : selected(T), task(T, V) } < 180.

total_value(V) :- V = #sum { Val,T : selected(T), task(T, Val) }.
resource_used(R, U) :- capacity(R, _), 
   U = #sum { Amt,T : selected(T), requires(T, R, Amt) }.
"""

ctl = clingo.Control(["1"])
ctl.add("base", [], program)
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    
    selected_tasks = []
    total_val = 0
    resource_usage = {'a': 0, 'b': 0, 'c': 0}
    
    for atom in model.symbols(atoms=True):
        if atom.name == "selected" and len(atom.arguments) == 1:
            task_id = atom.arguments[0].number
            selected_tasks.append(task_id)
        elif atom.name == "total_value" and len(atom.arguments) == 1:
            total_val = atom.arguments[0].number
        elif atom.name == "resource_used" and len(atom.arguments) == 2:
            resource_type = str(atom.arguments[0])
            usage = atom.arguments[1].number
            resource_usage[resource_type] = usage
    
    selected_tasks.sort()
    
    solution_data = {
        "selected_tasks": selected_tasks,
        "total_value": total_val,
        "resource_usage": {
            "resource_a": resource_usage.get('a', 0),
            "resource_b": resource_usage.get('b', 0),
            "resource_c": resource_usage.get('c', 0)
        }
    }

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    print(json.dumps(solution_data))
else:
    error_output = {
        "error": "No solution exists",
        "reason": "Cannot achieve target value within resource constraints"
    }
    print(json.dumps(error_output))
