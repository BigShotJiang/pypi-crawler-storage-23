import clingo
import json
import math

teams = ["A", "B", "C", "D"]
locations = {
    "A": (0, 0),
    "B": (3, 4),
    "C": (6, 0),
    "D": (2, 8)
}

def euclidean_distance(loc1, loc2):
    return math.sqrt((loc1[0] - loc2[0])**2 + (loc1[1] - loc2[1])**2)

distances = {}
for t1 in teams:
    for t2 in teams:
        if t1 != t2:
            dist = euclidean_distance(locations[t1], locations[t2])
            distances[(t1, t2)] = dist

def generate_asp_facts():
    facts = []
    
    for team in teams:
        facts.append(f'team("{team}").')
    
    facts.append('round(1..6).')
    
    for (t1, t2), dist in distances.items():
        dist_int = int(round(dist * 10))
        facts.append(f'distance("{t1}", "{t2}", {dist_int}).')
    
    for i, t1 in enumerate(teams):
        for t2 in teams[i+1:]:
            facts.append(f'pair("{t1}", "{t2}").')
    
    return "\n".join(facts)

asp_facts = generate_asp_facts()

asp_program = asp_facts + """

{ match(Home, Away, R) : team(Home), team(Away), Home != Away } :- round(R).

:- team(T1), team(T2), T1 != T2, #count { R : match(T1, T2, R) } != 1.

:- round(R), #count { Home, Away : match(Home, Away, R) } != 2.

plays_in_round(T, R) :- match(T, _, R).
plays_in_round(T, R) :- match(_, T, R).
:- round(R), team(T), #count { 1 : plays_in_round(T, R) } != 1.

:- team(T), round(R), R <= 4,
   match(T, _, R), match(T, _, R+1), match(T, _, R+2).

:- team(T), round(R), R <= 4,
   match(_, T, R), match(_, T, R+1), match(_, T, R+2).

travel_cost(Cost) :- Cost = #sum { Dist, Home, Away, R : 
    match(Home, Away, R), distance(Away, Home, Dist) }.

:- travel_cost(Cost), Cost > 750.

#show match/3.
#show travel_cost/1.
"""

ctl = clingo.Control(["1"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    
    matches_by_round = {r: [] for r in range(1, 7)}
    total_cost = 0
    
    for atom in model.symbols(atoms=True):
        if atom.name == "match" and len(atom.arguments) == 3:
            home = str(atom.arguments[0]).strip('"')
            away = str(atom.arguments[1]).strip('"')
            round_num = atom.arguments[2].number
            matches_by_round[round_num].append({"home": home, "away": away})
        
        elif atom.name == "travel_cost" and len(atom.arguments) == 1:
            total_cost = atom.arguments[0].number
    
    solution_data = {
        "matches_by_round": matches_by_round,
        "total_cost": total_cost
    }

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    schedule = []
    for r in range(1, 7):
        round_matches = solution_data['matches_by_round'][r]
        schedule.append(round_matches)
    
    total_distance = 0
    for r in range(1, 7):
        for match in solution_data['matches_by_round'][r]:
            home = match['home']
            away = match['away']
            total_distance += distances[(away, home)]
    
    output = {
        "schedule": schedule,
        "total_distance": int(round(total_distance)),
        "feasible": True
    }
    
    print(json.dumps(output, indent=2))
else:
    output = {
        "error": "No solution exists",
        "reason": "Unable to find a schedule satisfying all constraints",
        "feasible": False
    }
    print(json.dumps(output, indent=2))
