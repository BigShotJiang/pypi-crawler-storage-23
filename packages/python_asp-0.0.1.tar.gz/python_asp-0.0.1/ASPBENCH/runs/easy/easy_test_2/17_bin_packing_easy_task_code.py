import clingo
import json

def solve_bin_packing():
    items = {
        1: 4, 2: 6, 3: 2, 4: 3, 5: 7,
        6: 1, 7: 5, 8: 2, 9: 4
    }
    
    bin_capacity = 10
    max_bins = 9
    
    program = ""
    
    for item_id, size in items.items():
        program += f'item({item_id}, {size}).\n'
    
    program += f"""
bin(1..{max_bins}).
capacity({bin_capacity}).

1 {{ assigned(I, B) : bin(B) }} 1 :- item(I, _).

used(B) :- assigned(_, B).

:- used(B), capacity(C), #sum {{ S,I : assigned(I, B), item(I, S) }} > C.

#minimize {{ 1,B : used(B) }}.
"""
    
    ctl = clingo.Control()
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    solution = None
    num_bins_used = 0
    
    def on_model(m):
        nonlocal solution, num_bins_used
        bins_dict = {}
        
        for atom in m.symbols(atoms=True):
            if atom.name == "assigned" and len(atom.arguments) == 2:
                item_id = atom.arguments[0].number
                bin_id = atom.arguments[1].number
                
                if bin_id not in bins_dict:
                    bins_dict[bin_id] = []
                bins_dict[bin_id].append(item_id)
        
        solution = bins_dict
        num_bins_used = len(bins_dict)
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable and solution:
        bins_list = []
        bin_mapping = {old_id: new_id for new_id, old_id in 
                      enumerate(sorted(solution.keys()), 1)}
        
        for old_bin_id in sorted(solution.keys()):
            new_bin_id = bin_mapping[old_bin_id]
            item_list = sorted(solution[old_bin_id])
            total_size = sum(items[i] for i in item_list)
            
            bins_list.append({
                "bin_id": new_bin_id,
                "items": item_list,
                "total_size": total_size
            })
        
        output = {
            "bins": bins_list,
            "num_bins": num_bins_used,
            "feasible": True
        }
    else:
        output = {
            "bins": [],
            "num_bins": 0,
            "feasible": False
        }
    
    return output

if __name__ == "__main__":
    result = solve_bin_packing()
    print(json.dumps(result, indent=2))
