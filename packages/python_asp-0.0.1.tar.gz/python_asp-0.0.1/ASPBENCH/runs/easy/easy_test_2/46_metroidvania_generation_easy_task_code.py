import clingo
import json

asp_program = """
room("A"; "B"; "C"; "D"; "E"; "F"; "G"; "H").
key("key1"; "key2"; "key3").
requirement("null"; "key1"; "key2"; "key3").

start("A").

room_pair(R1, R2) :- room(R1), room(R2), R1 != R2.

0 { conn(R1, R2, Req) : requirement(Req) } 1 :- room_pair(R1, R2).

1 { key_at(K, R) : room(R) } 1 :- key(K).

:- key_at(_, "A").

keyed_path(R1, R2) :- conn(R1, R2, Req), Req != "null".
:- keyed_path(R1, R2), not conn(R2, R1, "null").

:- room(R), R != "A", not conn(_, R, _).

:- not conn("A", _, _).

reachable("A", 0).
has_keys(0, none).

collected_key(K, Layer) :- reachable(R, Layer), key_at(K, R), Layer < 10.
has_keys(Layer+1, K) :- collected_key(K, Layer), Layer < 10.
has_keys(Layer+1, K) :- has_keys(Layer, K), Layer < 10.

can_traverse(R1, R2, Layer) :- 
    reachable(R1, Layer), 
    conn(R1, R2, "null"),
    Layer < 10.

can_traverse(R1, R2, Layer) :- 
    reachable(R1, Layer), 
    conn(R1, R2, Req),
    Req != "null",
    has_keys(Layer, Req),
    Layer < 10.

reachable(R2, Layer+1) :- can_traverse(_, R2, Layer), Layer < 10.

:- room(R), not reachable(R, _).

:- #count { R1, R2 : conn(R1, R2, _) } < 7.

:- #count { R1, R2 : conn(R1, R2, _) } > 16.

#show conn/3.
#show key_at/2.
#show reachable/2.
"""

ctl = clingo.Control(["1"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    
    connections = []
    key_locations = {}
    reachable_rooms = set()
    
    for atom in model.symbols(atoms=True):
        if atom.name == "conn" and len(atom.arguments) == 3:
            from_room = str(atom.arguments[0]).strip('"')
            to_room = str(atom.arguments[1]).strip('"')
            requires = str(atom.arguments[2]).strip('"')
            
            connections.append({
                "from": from_room,
                "to": to_room,
                "requires": None if requires == "null" else requires
            })
        
        elif atom.name == "key_at" and len(atom.arguments) == 2:
            key_name = str(atom.arguments[0]).strip('"')
            room_name = str(atom.arguments[1]).strip('"')
            key_locations[key_name] = room_name
        
        elif atom.name == "reachable" and len(atom.arguments) == 2:
            room_name = str(atom.arguments[0]).strip('"')
            reachable_rooms.add(room_name)
    
    solution_data = {
        "rooms": ["A", "B", "C", "D", "E", "F", "G", "H"],
        "connections": sorted(connections, key=lambda x: (x["from"], x["to"])),
        "item_locations": key_locations,
        "reachability_verified": len(reachable_rooms) == 8
    }

result = ctl.solve(on_model=on_model)

if result.satisfiable and solution_data:
    print(json.dumps(solution_data, indent=2))
else:
    print(json.dumps({"error": "No solution exists", 
                      "reason": "Unable to create valid Metroidvania layout"}))
