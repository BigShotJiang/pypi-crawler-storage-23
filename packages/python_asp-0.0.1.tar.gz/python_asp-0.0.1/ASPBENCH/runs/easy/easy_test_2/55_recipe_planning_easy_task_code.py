import clingo
import json

def create_asp_program():
    program = """
    recipe("pasta").
    recipe("salad").
    recipe("bread").
    
    resource("oven").
    resource("stove").
    resource("prep_area").
    
    step("pasta", "prep", 10, "prep_area").
    step("pasta", "boil", 15, "stove").
    step("pasta", "serve", 5, "prep_area").
    step("salad", "chop", 15, "prep_area").
    step("salad", "mix", 5, "prep_area").
    step("bread", "bake", 30, "oven").
    
    precedence("pasta", "prep", "boil").
    precedence("pasta", "boil", "serve").
    precedence("salad", "chop", "mix").
    
    time(0..50).
    
    1 { scheduled(R, S, T) : time(T) } 1 :- step(R, S, _, _).
    
    end_time(R, S, T + D) :- scheduled(R, S, T), step(R, S, D, _).
    
    :- precedence(R, S1, S2), end_time(R, S1, E1), scheduled(R, S2, T2), 
       E1 > T2.
    
    :- scheduled(R1, S1, T1), scheduled(R2, S2, T2),
       step(R1, S1, D1, Res), step(R2, S2, D2, Res),
       (R1, S1) != (R2, S2),
       T1 < T2 + D2, T2 < T1 + D1.
    
    makespan(M) :- M = #max { E : end_time(_, _, E) }.
    
    :- makespan(M), M > 35.
    
    #show scheduled/3.
    #show end_time/3.
    #show makespan/1.
    """
    return program

def solve_recipe_scheduling():
    ctl = clingo.Control(["1"])
    
    program = create_asp_program()
    ctl.add("base", [], program)
    
    ctl.ground([("base", [])])
    
    solution_data = None
    
    def on_model(m):
        nonlocal solution_data
        atoms = m.symbols(atoms=True)
        
        scheduled_steps = []
        end_times = {}
        makespan_value = 0
        
        for atom in atoms:
            if atom.name == "scheduled" and len(atom.arguments) == 3:
                recipe = str(atom.arguments[0]).strip('"')
                step_name = str(atom.arguments[1]).strip('"')
                start_time = atom.arguments[2].number
                scheduled_steps.append((recipe, step_name, start_time))
            
            elif atom.name == "end_time" and len(atom.arguments) == 3:
                recipe = str(atom.arguments[0]).strip('"')
                step_name = str(atom.arguments[1]).strip('"')
                end_time = atom.arguments[2].number
                end_times[(recipe, step_name)] = end_time
            
            elif atom.name == "makespan" and len(atom.arguments) == 1:
                makespan_value = atom.arguments[0].number
        
        solution_data = {
            'scheduled': scheduled_steps,
            'end_times': end_times,
            'makespan': makespan_value
        }
    
    result = ctl.solve(on_model=on_model)
    
    if result.satisfiable and solution_data:
        return solution_data
    else:
        return None

def format_output(solution):
    step_data = {
        ("pasta", "prep"): {"duration": 10, "resource": "prep_area"},
        ("pasta", "boil"): {"duration": 15, "resource": "stove"},
        ("pasta", "serve"): {"duration": 5, "resource": "prep_area"},
        ("salad", "chop"): {"duration": 15, "resource": "prep_area"},
        ("salad", "mix"): {"duration": 5, "resource": "prep_area"},
        ("bread", "bake"): {"duration": 30, "resource": "oven"},
    }
    
    schedule = []
    for recipe, step, start in solution['scheduled']:
        end = solution['end_times'][(recipe, step)]
        resource = step_data[(recipe, step)]["resource"]
        
        schedule.append({
            "recipe": recipe,
            "step": step,
            "start_time": start,
            "end_time": end,
            "resources": [resource]
        })
    
    schedule.sort(key=lambda x: x['start_time'])
    
    resource_usage = {
        "oven": [],
        "stove": [],
        "prep_area": []
    }
    
    for item in schedule:
        resource = item["resources"][0]
        resource_usage[resource].append({
            "start": item["start_time"],
            "end": item["end_time"],
            "recipe": item["recipe"]
        })
    
    for res in resource_usage:
        resource_usage[res].sort(key=lambda x: x['start'])
    
    output = {
        "total_time": solution['makespan'],
        "schedule": schedule,
        "resource_usage": resource_usage
    }
    
    return output

solution = solve_recipe_scheduling()

if solution:
    output = format_output(solution)
    print(json.dumps(output, indent=2))
else:
    print(json.dumps({"error": "No solution exists", 
                      "reason": "Unable to schedule within time bound"}))
