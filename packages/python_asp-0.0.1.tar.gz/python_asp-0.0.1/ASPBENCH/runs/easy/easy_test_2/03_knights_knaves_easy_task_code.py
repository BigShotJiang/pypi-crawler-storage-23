import clingo
import json

program = """
person(alice).
person(bob).
person(charlie).

1 { knight(P) ; knave(P) } 1 :- person(P).

statement_alice_true :- knave(bob).

statement_bob_true :- knight(alice), knight(charlie).
statement_bob_true :- knave(alice), knave(charlie).

statement_charlie_true :- knight(alice).

:- knight(alice), not statement_alice_true.
:- knight(bob), not statement_bob_true.
:- knight(charlie), not statement_charlie_true.

:- knave(alice), statement_alice_true.
:- knave(bob), statement_bob_true.
:- knave(charlie), statement_charlie_true.

#show knight/1.
#show knave/1.
"""

ctl = clingo.Control(["1"])
ctl.add("base", [], program)
ctl.ground([("base", [])])

solution = None

def on_model(model):
    global solution
    solution = {}
    
    for atom in model.symbols(atoms=True):
        if atom.name == "knight":
            person = str(atom.arguments[0])
            solution[person] = "knight"
        elif atom.name == "knave":
            person = str(atom.arguments[0])
            solution[person] = "knave"

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    output = {
        "alice": solution["alice"],
        "bob": solution["bob"],
        "charlie": solution["charlie"]
    }
    print(json.dumps(output))
else:
    print(json.dumps({"error": "No solution exists"}))
