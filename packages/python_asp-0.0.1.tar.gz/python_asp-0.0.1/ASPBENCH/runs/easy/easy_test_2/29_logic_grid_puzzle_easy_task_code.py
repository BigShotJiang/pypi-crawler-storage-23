import clingo
import json

asp_program = """
person("Alice"; "Bob"; "Carol"; "Dave").
color("Red"; "Blue"; "Green"; "Yellow").
pet("Cat"; "Dog"; "Bird"; "Fish").
house(1; 2; 3; 4).

1 { lives_in(P, H) : house(H) } 1 :- person(P).
1 { has_color(P, C) : color(C) } 1 :- person(P).
1 { has_pet(P, Pet) : pet(Pet) } 1 :- person(P).

1 { lives_in(P, H) : person(P) } 1 :- house(H).
1 { has_color(P, C) : person(P) } 1 :- color(C).
1 { has_pet(P, Pet) : person(P) } 1 :- pet(Pet).

:- not lives_in("Alice", 1).
:- has_color(P, "Red"), not lives_in(P, 2).
:- not has_pet("Bob", "Cat").
:- not has_color("Carol", "Blue").
:- has_color(P, "Yellow"), not has_pet(P, "Fish").
:- has_color(P, "Green"), not lives_in(P, 4).
:- not has_pet("Dave", "Dog").
:- has_pet("Alice", "Bird").
"""

ctl = clingo.Control(["1"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

solution_data = None

def on_model(model):
    global solution_data
    solution_data = {}
    
    for atom in model.symbols(atoms=True):
        if atom.name == "lives_in" and len(atom.arguments) == 2:
            person = str(atom.arguments[0]).strip('"')
            house = atom.arguments[1].number
            if person not in solution_data:
                solution_data[person] = {}
            solution_data[person]["house"] = house
        
        elif atom.name == "has_color" and len(atom.arguments) == 2:
            person = str(atom.arguments[0]).strip('"')
            color = str(atom.arguments[1]).strip('"')
            if person not in solution_data:
                solution_data[person] = {}
            solution_data[person]["color"] = color
        
        elif atom.name == "has_pet" and len(atom.arguments) == 2:
            person = str(atom.arguments[0]).strip('"')
            pet = str(atom.arguments[1]).strip('"')
            if person not in solution_data:
                solution_data[person] = {}
            solution_data[person]["pet"] = pet

result = ctl.solve(on_model=on_model)

if result.satisfiable:
    assignments = []
    for person, attrs in solution_data.items():
        assignment = {
            "person": person,
            "color": attrs["color"],
            "pet": attrs["pet"],
            "house": attrs["house"]
        }
        assignments.append(assignment)
    
    assignments.sort(key=lambda x: x["house"])
    output = {"assignments": assignments}
    print(json.dumps(output, indent=2))
else:
    print(json.dumps({"error": "No solution exists"}))
