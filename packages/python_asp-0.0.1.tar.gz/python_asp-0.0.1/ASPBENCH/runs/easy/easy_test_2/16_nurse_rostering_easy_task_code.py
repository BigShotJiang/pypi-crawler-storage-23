import clingo
import json

asp_program = """
nurse(1..4).
day(1..7).
shift(1..3).

coverage(1, 2).
coverage(2, 1).
coverage(3, 1).

weekend(6).
weekend(7).

{ assigned(N, D, S) : shift(S) } 1 :- nurse(N), day(D).

:- shift(S), day(D), coverage(S, Required), 
   #count { N : assigned(N, D, S) } != Required.

:- assigned(N, D, 3), assigned(N, D+1, 1), day(D), day(D+1).

works(N, D) :- assigned(N, D, _).

excess_day(N, D) :- works(N, D), works(N, D-1), works(N, D-2), works(N, D-3),
                    day(D), day(D-1), day(D-2), day(D-3).

shift_count(N, Count) :- nurse(N), Count = #count { D, S : assigned(N, D, S) }.
below_min(N, Deficit) :- shift_count(N, C), C < 6, Deficit = 6 - C.
above_max(N, Excess) :- shift_count(N, C), C > 8, Excess = C - 8.

works_weekend(N) :- assigned(N, D, _), weekend(D).
weekend_count(C) :- C = #count { N : works_weekend(N) }.
weekend_violation :- weekend_count(C), C < 2.

#minimize { 1@3, N, D : excess_day(N, D) }.
#minimize { Deficit@2, N : below_min(N, Deficit) }.
#minimize { Excess@2, N : above_max(N, Excess) }.
#minimize { 1@1 : weekend_violation }.

#show assigned/3.
"""

ctl = clingo.Control(["0"])
ctl.add("base", [], asp_program)
ctl.ground([("base", [])])

solution_data = None
optimal_cost = None

def on_model(model):
    global solution_data, optimal_cost
    assignments = []
    for atom in model.symbols(atoms=True):
        if atom.name == "assigned" and len(atom.arguments) == 3:
            nurse = atom.arguments[0].number
            day = atom.arguments[1].number
            shift = atom.arguments[2].number
            assignments.append((nurse, day, shift))
    solution_data = assignments
    optimal_cost = model.cost

result = ctl.solve(on_model=on_model)

if result.satisfiable and solution_data:
    roster = [[[],[],[]] for _ in range(7)]
    for nurse, day, shift in solution_data:
        roster[day-1][shift-1].append(nurse)
    
    for d in range(7):
        for s in range(3):
            roster[d][s].sort()
    
    total_violations = sum(optimal_cost)
    
    coverage_met = True
    required_coverage = [2, 1, 1]
    for d in range(7):
        for s in range(3):
            if len(roster[d][s]) != required_coverage[s]:
                coverage_met = False
    
    output = {
        "roster": roster,
        "violations": total_violations,
        "coverage_met": coverage_met
    }
    
    print(json.dumps(output, indent=2))
else:
    print(json.dumps({"error": "No solution exists"}))
