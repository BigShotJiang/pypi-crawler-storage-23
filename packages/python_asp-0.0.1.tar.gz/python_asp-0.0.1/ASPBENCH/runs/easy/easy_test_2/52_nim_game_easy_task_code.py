import clingo
import json

def solve_nim_game(piles):
    """Solve Nim game using ASP to generate moves, Python to analyze optimal strategy"""
    
    current_nim_sum = piles[0] ^ piles[1] ^ piles[2]
    is_winning = current_nim_sum != 0
    
    ctl = clingo.Control(["0"])
    
    program = f"""
pile(1, {piles[0]}).
pile(2, {piles[1]}).
pile(3, {piles[2]}).

possible_remove(P, R) :- pile(P, N), R = 1..N.

1 {{ move(P, R) : possible_remove(P, R) }} 1.

resulting_pile(P, N - R) :- move(P, R), pile(P, N).
resulting_pile(P, N) :- pile(P, N), not move(P, _).

#show move/2.
#show resulting_pile/2.
"""
    
    ctl.add("base", [], program)
    ctl.ground([("base", [])])
    
    all_moves = []
    
    def on_model(model):
        move_info = {}
        resulting = {}
        
        for atom in model.symbols(atoms=True):
            if atom.name == "move" and len(atom.arguments) == 2:
                pile_num = atom.arguments[0].number
                stones_removed = atom.arguments[1].number
                move_info = {"pile": pile_num, "stones": stones_removed}
            
            elif atom.name == "resulting_pile" and len(atom.arguments) == 2:
                pile_num = atom.arguments[0].number
                stones = atom.arguments[1].number
                resulting[pile_num] = stones
        
        if move_info and resulting:
            resulting_piles = [resulting[1], resulting[2], resulting[3]]
            nim_sum_after = resulting_piles[0] ^ resulting_piles[1] ^ resulting_piles[2]
            
            move_info["resulting_piles"] = resulting_piles
            move_info["nim_sum_after"] = nim_sum_after
            move_info["is_optimal"] = (nim_sum_after == 0 and is_winning)
            
            all_moves.append(move_info)
    
    ctl.solve(on_model=on_model)
    
    return all_moves, current_nim_sum, is_winning

def format_solution(piles, all_moves, current_nim_sum, is_winning):
    """Format the solution according to the required JSON structure"""
    
    optimal_moves = [m for m in all_moves if m["is_optimal"]]
    
    solution = {
        "game_state": "winning" if is_winning else "losing",
        "optimal_moves": [
            {
                "pile": move["pile"],
                "stones": move["stones"],
                "resulting_piles": move["resulting_piles"]
            }
            for move in optimal_moves
        ],
        "nim_sum": current_nim_sum,
        "analysis": {
            "is_winning_position": is_winning,
            "strategy": (
                "From a winning position (nim-sum ≠ 0), the optimal strategy is to make a move "
                "that forces the nim-sum to 0, putting the opponent in a losing position. "
                f"The current nim-sum is {current_nim_sum}. "
                f"There {'is' if len(optimal_moves) == 1 else 'are'} {len(optimal_moves)} optimal move(s) "
                "that achieve this goal."
            ) if is_winning else (
                "From a losing position (nim-sum = 0), any move will result in a non-zero nim-sum, "
                "giving the opponent a winning position. There are no optimal moves from this position."
            ),
            "after_optimal_move": {
                "nim_sum": 0 if optimal_moves else None,
                "position": "losing" if optimal_moves else None
            } if is_winning else {
                "nim_sum": "varies",
                "position": "winning"
            }
        }
    }
    
    return solution

initial_piles = [3, 4, 5]
all_moves, current_nim_sum, is_winning = solve_nim_game(initial_piles)
solution = format_solution(initial_piles, all_moves, current_nim_sum, is_winning)

print(json.dumps(solution, indent=2))
