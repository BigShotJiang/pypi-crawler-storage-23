import clingo
import json


def solve_magic_square():
    program = """
    row(1..3).
    col(1..3).
    num(1..9).

    1 { cell(R, C, N) : num(N) } 1 :- row(R), col(C).

    :- num(N), #count { R, C : cell(R, C, N) } != 1.

    :- row(R), #sum { N, C : cell(R, C, N) } != 15.

    :- col(C), #sum { N, R : cell(R, C, N) } != 15.

    :- #sum { N, R : cell(R, R, N) } != 15.

    :- #sum { N, R : cell(R, 4-R, N) } != 15.

    #show cell/3.
    """

    ctl = clingo.Control(["1"])
    ctl.add("base", [], program)
    ctl.ground([("base", [])])

    solution_data = None

    def on_model(model):
        nonlocal solution_data
        cells = {}
        for atom in model.symbols(atoms=True):
            if atom.name == "cell" and len(atom.arguments) == 3:
                row = atom.arguments[0].number
                col = atom.arguments[1].number
                value = atom.arguments[2].number
                cells[(row, col)] = value
        solution_data = cells

    result = ctl.solve(on_model=on_model)

    if result.satisfiable and solution_data:
        square = []
        for r in range(1, 4):
            row = [solution_data[(r, c)] for c in range(1, 4)]
            square.append(row)

        def verify_solution(square):
            all_nums = [num for row in square for num in row]
            if sorted(all_nums) != list(range(1, 10)):
                return False

            for row in square:
                if sum(row) != 15:
                    return False

            for c in range(3):
                if sum(square[r][c] for r in range(3)) != 15:
                    return False

            if sum(square[i][i] for i in range(3)) != 15:
                return False

            if sum(square[i][2-i] for i in range(3)) != 15:
                return False

            return True

        valid = verify_solution(square)

        output = {
            "square": square,
            "magic_sum": 15,
            "valid": valid
        }

        print(json.dumps(output))
    else:
        error_output = {
            "error": "No solution exists",
            "reason": "No valid magic square arrangement found"
        }
        print(json.dumps(error_output))


if __name__ == "__main__":
    solve_magic_square()
