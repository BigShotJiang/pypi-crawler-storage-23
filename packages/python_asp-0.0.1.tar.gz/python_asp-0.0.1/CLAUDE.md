## General Aim

ASPy — a Pythonic Answer Set Programming library inspired by CPMPy. Everything is a Python object. Target users are AI coding agents. Backend is clingo.

## Tools

- Python 3.10+, clingo (via pip/uv)
- uv for package management
- pytest for testing (`uv run --group dev pytest tests/`)

## Project Architecture

```
aspy/
├── __init__.py            # Public API exports
├── variables.py           # Var, Vars(), ArithExpr, Comparison, Anon, Range
├── predicates.py          # Predicate
├── expressions.py         # Atom, NafLiteral, Conjunction, NegatedBody
├── rules.py               # Rule, IntegrityConstraint, ChoiceRule, Choice, Constraint
├── aggregates.py          # Count, Sum, Min, Max, AggregateLiteral, Minimize, Maximize
├── program.py             # Program container (+=, solve, solve_all, to_asp, show)
├── compiler.py            # Expression tree → ASP text
├── results.py             # Result, AnswerSet
└── solvers/
    ├── __init__.py
    └── clingo_solver.py   # ClingoSolver backend
tests/
├── test_basic.py          # v1 tests (18): coloring, reachability, facts, NAF, etc.
├── test_v2.py             # v2 tests (16): aggregates, optimization, ranges, anon
└── test_errors.py         # error message tests (12): UNSAT, types, arity, ~, grounding
aspbench_solutions/        # ASPy solutions for ASP-Bench problems (validated)
pyproject.toml             # uv-managed, clingo dependency
```

## Key Documents

- `MEM/MEM_000.md` — Process notes (session log)
- `cimgo.md` — Clingo Python API reference (scraped docs)
- `cpmpy.txt` — CPMPy reference for design inspiration

## Conventions

- All ASP constructs are Python objects — no string-based ASP syntax
- Operator overloading: `<<` (rules), `&` (conjunction), `~` (negation/constraints)
- Aggregates use `where=` keyword (consistent with `cond=` in Choice)
- Run tests: `uv run --group dev pytest tests/ -v`
- Solver auto-switches to `num_models=0` when optimization directives present

## Accomplished Goals

- **v1**: Core library — predicates, atoms, variables, rules, choice rules, NAF, comparisons, arithmetic, Program container, clingo solver, AnswerSet querying, `to_asp()` debug output
- **v2**: Aggregates (#count, #sum, #min, #max with `where=` and fluent `.where()` builder), optimization (#minimize, #maximize with priority), Range terms, anonymous variables (Anon)
- **v3 (error messages)**: UNSAT answer_set access, `<< None` rejection, clingo error passthrough with ASP text, type validation in predicates, `~` on non-atom guidance
- 46 tests pass (18 basic + 16 v2 + 12 error)
- Evaluated against ASP-Bench problems — identified that aggregates + optimization were essential (now implemented)
- 5 ASP-Bench solutions validated: graph coloring, hamiltonian path, magic square, vertex cover, clique finding

## Open Goals

- Empirical comparison: test whether AI agents model better in ASPy vs raw clingo strings
- Conditional literals outside choice rules
- Classical negation (`-p`)
- Disjunctive heads
- Pooling (1..n ranges in rule bodies beyond facts)
- Multiple solver backends
- Incremental solving

## Session Status

### Last Completed (2026-03-04)
- Created 5 ASP-Bench solutions using ASPy (graph coloring, hamiltonian path, magic square, vertex cover, clique finding) — all validated against ground truth
- Audited error messages across 10 common mistake scenarios
- Fixed 5 error message issues: UNSAT answer_set, `<< None` silent bug, clingo error passthrough, type validation, `~` on non-atoms
- Added `test_errors.py` with 12 tests; all 46 tests pass

### Next Steps
- The main open question: does ASPy help AI agents model better than raw clingo? The 5 aspbench_solutions/ provide a starting point for side-by-side comparison. Next: have an AI agent solve more ASP-Bench problems using ASPy vs raw clingo strings and compare success rates.
- Consider adding conditional literals in rule bodies (not just choice rules) — some benchmark problems use them.
- `solve_all()` with optimization could be improved — currently returns only the last (optimal) model even when user wants all optimal models.
- Could add more ASP-Bench solutions to build a larger comparison dataset (currently 5 of 128).
