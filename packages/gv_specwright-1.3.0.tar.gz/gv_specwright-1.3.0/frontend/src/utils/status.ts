/**
 * Shared status-to-CSS-class mappings used across editor components.
 */

/** Returns a CSS class name (e.g. `status-draft`) for use with the status-badge system. */
export function statusClass(s: string): string {
  const map: Record<string, string> = {
    draft: 'status-draft',
    todo: 'status-todo',
    in_progress: 'status-in_progress',
    done: 'status-done',
    blocked: 'status-blocked',
    deprecated: 'status-deprecated',
  }
  return map[s] || 'status-draft'
}

/** Returns Tailwind utility classes for rendering a status badge in generated HTML. */
export function statusBadgeClass(status: string): string {
  const map: Record<string, string> = {
    draft: 'bg-gray-100 text-gray-600',
    todo: 'bg-amber-50 text-amber-700',
    in_progress: 'bg-blue-50 text-blue-700',
    done: 'bg-emerald-50 text-emerald-700',
    blocked: 'bg-red-50 text-red-700',
    deprecated: 'bg-gray-100 text-gray-500',
  }
  return map[String(status)] || map.draft
}
