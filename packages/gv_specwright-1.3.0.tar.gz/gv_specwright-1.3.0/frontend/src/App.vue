<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import AppNav from '@/components/layout/AppNav.vue'
import AppFooter from '@/components/layout/AppFooter.vue'

const route = useRoute()
const isPublic = computed(() => route.meta.public === true)
</script>

<template>
  <!-- Marketing pages render their own layout -->
  <router-view v-if="isPublic" />

  <!-- App pages use the shared chrome -->
  <template v-else>
    <div class="h-0.5 bg-gradient-to-r from-accent-500 to-cyan-400"></div>
    <AppNav />
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <router-view />
    </main>
    <AppFooter />
  </template>
</template>
