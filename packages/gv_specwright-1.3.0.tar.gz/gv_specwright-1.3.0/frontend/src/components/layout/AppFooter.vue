<template>
  <footer class="border-t border-border-light dark:border-slate-800 mt-auto">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
      <p class="text-sm text-slate-500 text-center">
        <span class="font-display font-semibold bg-gradient-to-r from-accent-500 to-cyan-400 bg-clip-text text-transparent">Specwright</span>
        by <a href="https://gernerventures.com" class="hover:text-accent-400 transition-colors">Gerner Ventures</a>
      </p>
    </div>
  </footer>
</template>
