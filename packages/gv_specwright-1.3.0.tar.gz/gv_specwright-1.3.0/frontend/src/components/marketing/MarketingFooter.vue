<template>
  <footer class="border-t border-border-light dark:border-slate-800 mt-16">
    <div class="max-w-6xl mx-auto px-4 sm:px-6 py-8 flex flex-col sm:flex-row justify-between items-center gap-4">
      <p class="text-sm text-slate-500">
        <span class="font-display font-bold bg-gradient-to-r from-accent-500 to-cyan-400 bg-clip-text text-transparent">Specwright</span>
        &mdash; an experiment by
        <a href="https://gernerventures.com" class="hover:text-accent-400 transition-colors">Gerner Ventures</a>
      </p>
      <div class="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-slate-500">
        <a href="/docs" class="hover:text-slate-700 dark:hover:text-slate-300 transition-colors">Docs</a>
        <a href="/changelog" class="hover:text-slate-700 dark:hover:text-slate-300 transition-colors">Changelog</a>
        <a href="https://github.com/Gerner-Ventures/gv-exp-specwright" class="hover:text-slate-700 dark:hover:text-slate-300 transition-colors">GitHub</a>
        <a href="https://gernerventures.com" class="hover:text-slate-700 dark:hover:text-slate-300 transition-colors">gernerventures.com</a>
      </div>
    </div>
  </footer>
</template>
