<script setup lang="ts">
import type { SpecDetail as SpecDetailType } from '@/api/types'
import SpecHeader from './SpecHeader.vue'
import SpecContent from './SpecContent.vue'

defineProps<{
  spec: SpecDetailType
  org: string
}>()
</script>

<template>
  <div>
    <SpecHeader
      :document="spec.document"
      :github-url="spec.github_url"
      :org="org"
      :repo-owner="spec.repo_owner"
      :repo-name="spec.repo_name"
    />
    <SpecContent :html="spec.rendered_html" />
  </div>
</template>
