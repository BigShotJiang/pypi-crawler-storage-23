/* TypeScript interfaces mirroring Python Pydantic models */

// --- Parser models ---

export type DocType = 'spec' | 'proposal' | 'design' | 'adr'
export type ReviewStatusValue = 'draft' | 'in_review' | 'approved'
export type StatusState = 'draft' | 'todo' | 'in_progress' | 'done' | 'blocked' | 'deprecated'

export interface SectionStatus {
  state: StatusState
  blocked_by?: string
}

export interface TicketLink {
  system: 'jira' | 'linear' | 'github'
  ticket_id: string
}

export interface RealizationRef {
  pr_number: number
  file_path: string
  lines: string
}

export interface AcceptanceCriterion {
  text: string
  checked: boolean
  line?: number
  realized_in: RealizationRef[]
  strength?: string
}

export interface SpecSection {
  id: string
  section_number: string
  title: string
  depth: number
  content: string
  prose_content?: string
  ticket_link?: TicketLink
  status: SectionStatus | string
  acceptance_criteria: AcceptanceCriterion[]
  children: SpecSection[]
  start_line?: number
  end_line?: number
}

export interface SpecFrontmatter {
  title: string
  status: string
  owner: string
  team: string
  ticket_project?: string
  created?: string
  updated?: string
  tags: string[]
  doc_type?: DocType
  depends_on?: string[]
  supersedes?: string[]
  review_status?: ReviewStatusValue
}

export interface SpecDocument {
  file_path: string
  frontmatter: SpecFrontmatter
  sections: SpecSection[]
  raw?: string
}

// --- Config models ---

export type TicketSystem = 'jira' | 'linear' | 'github'

export interface SpecsConfig {
  auto_tickets: boolean
  require_review: boolean
  doc_paths: string[]
}

export interface AgentsConfig {
  doc_updates: boolean
  pr_analysis: boolean
  realization_check: boolean
  stale_detection: string | false
}

export interface SpecwrightConfig {
  team: string
  ticket_system: TicketSystem | null
  project_key: string
  slack_channel: string
  specs: SpecsConfig
  agents: AgentsConfig
}

// --- Web view models ---

export interface SpecSummary {
  file_path: string
  title: string
  status: string
  owner: string
  team: string
  tags: string[]
  total_sections: number
  done_sections: number
  total_ac: number
  done_ac: number
  review_status?: string | null
  is_indexed: boolean
  last_doc_change_at?: string | null
  last_code_change_at?: string | null
  stale_since?: string | null
  is_stale: boolean
}

export interface DocFile {
  path: string
  name: string
  github_url: string
  title: string
  doc_type: string
  is_indexed: boolean
}

export interface RepoSummary {
  owner: string
  repo: string
  full_name: string
  description: string
  default_branch: string
  has_specs: boolean
  spec_count: number
  specs: SpecSummary[]
  config: SpecwrightConfig | null
  docs: DocFile[]
}

export interface OrgOverview {
  org: string
  repos_with_specs: RepoSummary[]
  repos_without_specs: RepoSummary[]
  total_specs: number
  total_repos: number
  total_docs: number
}

export interface SpecDetail {
  document: SpecDocument
  rendered_html: string
  repo_owner: string
  repo_name: string
  github_url: string
  config: SpecwrightConfig | null
}

export interface DocDetail {
  path: string
  title: string
  rendered_html: string
  repo_owner: string
  repo_name: string
  github_url: string
  doc_type: string
}

export interface SpecSearchResult {
  file_path: string
  title: string
  status: string
  owner: string
  team: string
  repo_full_name: string
  repo_owner: string
  repo_name: string
  tags: string[]
  heading: string
  snippet: string
  score: number
  doc_type: string
  review_status?: string | null
}

export interface FacetCounts {
  status: Record<string, number>
  repo: Record<string, number>
  team: Record<string, number>
  tag: Record<string, number>
}

export interface SearchApiResponse {
  results: SpecSearchResult[]
  total: number
  facets: FacetCounts
}

export interface CoverageSummary {
  total_specs: number
  total_sections: number
  done_sections: number
  total_ac: number
  done_ac: number
  realized_ac: number
  section_coverage_pct: number
  ac_coverage_pct: number
  realization_rate_pct: number
  health_score: number
}

export interface CoverageTrendPoint {
  date: string
  total_sections: number
  done_sections: number
  total_ac: number
  done_ac: number
  realized_ac: number
}

export interface CoverageApiResponse {
  summary: CoverageSummary
  trend: CoverageTrendPoint[]
  breakdown_by_repo: Record<string, CoverageSummary>
  breakdown_by_team: Record<string, CoverageSummary>
}

// --- Tasks models ---

export interface TaskItem {
  section_id: string
  section_number: string | null
  title: string
  status: StatusState
  blocked_by: string | null
  total_ac: number
  done_ac: number
  ticket_system: string | null
  ticket_id: string | null
  spec_title: string
  spec_file_path: string
  repo_owner: string
  repo_name: string
}

export interface TasksApiResponse {
  tasks: TaskItem[]
  total: number
}

// --- Editor models ---

export interface EditorSaveRequest {
  content: string
  sha: string
  message?: string
}

export interface EditorSavePRRequest extends EditorSaveRequest {
  branch_name?: string
  pr_title?: string
  pr_body?: string
}

export interface EditorParseRequest {
  content: string
}

export interface EditorSaveResponse {
  ok: boolean
  sha?: string
  error?: string
  server_content?: string
  server_sha?: string
}

export interface EditorSavePRResponse {
  ok: boolean
  pr_number?: number
  pr_url?: string
  error?: string
}

export interface EditorParseResponse {
  ok: boolean
  sections?: SpecSection[]
  error?: string
}

// --- Session ---

export interface SessionUser {
  sub: string
  email: string
  name: string
  picture: string
  org_login: string
}

export interface GitHubUser {
  login: string
  name: string
}

export interface SessionData {
  user: SessionUser | null
  org: string
  orgs: string[]
  permissions: string[]
  github_user: GitHubUser | null
  posthog_key: string
  posthog_host: string
}

// --- Welcome ---

export interface WelcomeData {
  user_name: string
  app_installed: boolean
  has_specs: boolean
  install_url: string
}

// --- Admin ---

export interface IndexingTask {
  task_id: string
  org_login: string
  status: string
  repos_done: number
  repos_total: number
  specs_indexed: number
  errors: number
}

export interface IndexingInstallation {
  org_login: string
  installation_id: number
  status: string
  repos_count: number
  last_indexed_at: string | null
}

export interface IndexingJob {
  repo: string
  status: string
  specs_indexed: number
  errors: number
  completed_at: string
}

export interface IndexingOverview {
  active_tasks: IndexingTask[]
  installations: IndexingInstallation[]
  recent_jobs: IndexingJob[]
}

// --- AI Spec Generation ---

export interface GenerateSpecRequest {
  description: string
}

// --- AI Section Editing ---

export interface AiEditRequest {
  action: 'improve' | 'generate_acs' | 'expand'
  section_title: string
  section_content: string
  acceptance_criteria?: string[]
}

// --- Profile ---

export interface ProfileResponse {
  sub: string
  email: string
  name: string
  picture: string
  org_login: string
  permissions: string[]
  all_permissions: string[]
  auth_method: string
  github_user: GitHubUser | null
  last_login_at: string | null
  inferred_role: string
}

// --- Editor repos listing ---

export interface EditorRepo {
  name: string
  full_name: string
  owner: { login: string }
  description: string | null
  default_branch: string
}
