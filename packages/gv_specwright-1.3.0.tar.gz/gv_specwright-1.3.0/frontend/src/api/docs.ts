import { get } from './client'
import type { DocDetail } from './types'

export function fetchDoc(org: string, owner: string, repo: string, path: string): Promise<DocDetail> {
  return get<DocDetail>(`/app/${org}/api/docs/${owner}/${repo}/${path}`)
}
