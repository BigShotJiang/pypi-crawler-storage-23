import { get } from './client'
import type { SessionData } from './types'

export function fetchSession(org: string): Promise<SessionData> {
  return get<SessionData>(`/app/${org}/api/session`)
}
