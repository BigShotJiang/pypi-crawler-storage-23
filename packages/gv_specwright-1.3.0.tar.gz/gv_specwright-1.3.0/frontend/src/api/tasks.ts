import { get } from './client'
import type { TasksApiResponse } from './types'

export function fetchTasks(
  org: string,
  opts?: { status?: string; repo?: string },
): Promise<TasksApiResponse> {
  const query = new URLSearchParams()
  if (opts?.status) query.set('status', opts.status)
  if (opts?.repo) query.set('repo', opts.repo)
  const qs = query.toString()
  return get<TasksApiResponse>(`/app/${org}/api/tasks${qs ? `?${qs}` : ''}`)
}
