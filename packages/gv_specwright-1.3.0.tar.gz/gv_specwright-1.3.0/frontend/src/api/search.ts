import { get } from './client'
import type { SearchApiResponse } from './types'

export interface SearchParams {
  q?: string
  team?: string
  status?: string
  tag?: string
  repo?: string
  limit?: number
  offset?: number
}

export function fetchSearch(org: string, params: SearchParams): Promise<SearchApiResponse> {
  const query = new URLSearchParams()
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined && v !== '') query.set(k, String(v))
  }
  return get<SearchApiResponse>(`/app/${org}/api/search?${query}`)
}
