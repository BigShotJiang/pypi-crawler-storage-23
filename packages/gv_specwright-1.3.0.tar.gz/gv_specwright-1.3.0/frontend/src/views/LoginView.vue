<script setup lang="ts">
import { computed, ref } from 'vue'
import { useRoute } from 'vue-router'

const route = useRoute()
const org = computed(() => (route.query.org as string) || '')
const loading = ref(false)

function loginWith(connection: string) {
  if (loading.value) return
  loading.value = true
  const params = new URLSearchParams()
  if (connection) params.set('connection', connection)
  if (org.value) params.set('org', org.value)
  window.location.href = `/auth/login?${params.toString()}`
  // Reset if navigation is blocked (e.g. by a browser extension)
  setTimeout(() => { loading.value = false }, 5000)
}
</script>

<template>
  <div class="login-page">
    <div class="login-card">
      <h1 class="login-title">Sign in to Specwright</h1>
      <p class="login-subtitle">Choose a sign-in method to continue</p>

      <div class="login-buttons">
        <button class="login-btn login-btn--github" :disabled="loading" @click="loginWith('github')">
          <svg class="login-btn__icon" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z"/>
          </svg>
          Continue with GitHub
        </button>

        <button class="login-btn login-btn--google" :disabled="loading" @click="loginWith('google-oauth2')">
          <svg class="login-btn__icon" viewBox="0 0 24 24" fill="currentColor">
            <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
            <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
            <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
            <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
          </svg>
          Continue with Google
        </button>

        <button class="login-btn login-btn--email" :disabled="loading" @click="loginWith('email')">
          <svg class="login-btn__icon" viewBox="0 0 24 24" fill="currentColor">
            <path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/>
          </svg>
          Continue with Email
        </button>
      </div>
    </div>
  </div>
</template>

<style scoped>
.login-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--color-bg-primary, #0a0a0a);
  padding: 1rem;
}

.login-card {
  width: 100%;
  max-width: 400px;
  padding: 2.5rem 2rem;
  border-radius: 12px;
  background: var(--color-bg-secondary, #141414);
  border: 1px solid var(--color-border, #262626);
}

.login-title {
  font-size: 1.5rem;
  font-weight: 600;
  color: var(--color-text-primary, #fafafa);
  text-align: center;
  margin: 0 0 0.5rem;
}

.login-subtitle {
  font-size: 0.875rem;
  color: var(--color-text-secondary, #a3a3a3);
  text-align: center;
  margin: 0 0 2rem;
}

.login-buttons {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.login-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.75rem;
  width: 100%;
  padding: 0.75rem 1rem;
  border-radius: 8px;
  border: 1px solid var(--color-border, #262626);
  background: var(--color-bg-primary, #0a0a0a);
  color: var(--color-text-primary, #fafafa);
  font-size: 0.9375rem;
  font-weight: 500;
  cursor: pointer;
  transition: background 0.15s, border-color 0.15s;
}

.login-btn:hover:not(:disabled) {
  background: var(--color-bg-hover, #1a1a1a);
  border-color: var(--color-border-hover, #404040);
}

.login-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.login-btn__icon {
  width: 20px;
  height: 20px;
  flex-shrink: 0;
}
</style>
