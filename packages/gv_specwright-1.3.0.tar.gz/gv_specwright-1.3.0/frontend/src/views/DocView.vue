<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import { useQuery } from '@tanstack/vue-query'
import { fetchDoc } from '@/api/docs'
import Breadcrumb from '@/components/layout/Breadcrumb.vue'
import DocDetail from '@/components/doc/DocDetail.vue'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'

const route = useRoute()

const org = computed(() => route.params.org as string)
const owner = computed(() => route.params.owner as string)
const repo = computed(() => route.params.repo as string)
const path = computed(() => route.params.path as string)

const { data, isLoading } = useQuery({
  queryKey: ['doc', org, owner, repo, path],
  queryFn: () => fetchDoc(org.value, owner.value, repo.value, path.value),
})

const breadcrumbs = computed(() => [
  { label: 'Dashboard', to: `/app/${org.value}/` },
  { label: `${owner.value}/${repo.value}`, to: `/app/${org.value}/repos/${owner.value}/${repo.value}` },
  { label: data.value?.title || path.value },
])
</script>

<template>
  <Breadcrumb :items="breadcrumbs" />
  <LoadingSpinner v-if="isLoading" />
  <DocDetail v-else-if="data" :doc="data" />
</template>
