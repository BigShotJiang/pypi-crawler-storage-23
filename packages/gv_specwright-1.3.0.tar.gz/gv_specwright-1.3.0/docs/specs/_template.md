---
title: "Feature Title"
status: draft
owner: your-name
team: team-name
ticket_project: null
created: YYYY-MM-DD
updated: YYYY-MM-DD
tags: []
---

# Feature Title

Brief overview of this feature.

## 1. Background

Why this feature exists and what problem it solves.

## 2. Requirements

<!-- specwright:system:2 status:todo -->

### 2.1 Functional Requirements

- Requirement one
- Requirement two

### 2.2 Non-Functional Requirements

- Performance target
- Availability target

## 3. Design

<!-- specwright:system:3 status:draft -->

Describe the technical approach.

### Acceptance Criteria

- [ ] Criterion one
- [ ] Criterion two
- [ ] Criterion three

## 4. Rollout Plan

<!-- specwright:system:4 status:draft -->

How this will be deployed and validated.

## 5. Open Questions

- Question one?
- Question two?
