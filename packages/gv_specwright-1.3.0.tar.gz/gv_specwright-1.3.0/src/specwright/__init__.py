"""Specwright — AI-native enterprise documentation platform."""
