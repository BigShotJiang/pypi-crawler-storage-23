"""Cron job scripts for scheduled tasks."""
