"""Stale document detection — identifies docs that may be outdated."""
