"""Claude agent runtime for PR analysis."""
