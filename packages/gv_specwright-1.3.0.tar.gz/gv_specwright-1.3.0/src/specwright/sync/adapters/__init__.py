"""Ticket system adapters."""
