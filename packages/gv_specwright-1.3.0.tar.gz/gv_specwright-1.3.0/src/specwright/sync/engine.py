"""Sync engine — forward sync (spec → tickets) and reverse sync (tickets → spec)."""

from __future__ import annotations

from specwright.parser.models import SpecDocument, SpecSection
from specwright.parser.writer import (
    StatusUpdate,
    TicketLinkInsertion,
    insert_ticket_links,
    update_status_comments,
)
from specwright.sync.adapters.base import TicketAdapter
from specwright.sync.models import (
    CreateTicketInput,
    SyncCreated,
    SyncError,
    SyncResult,
    SyncStatusChanged,
    SyncUpdated,
)


def _flatten_sections(sections: list[SpecSection]) -> list[SpecSection]:
    result: list[SpecSection] = []
    for section in sections:
        result.append(section)
        result.extend(section.children)
    return result


def _detect_system_from_adapter(adapter: TicketAdapter) -> str:
    name = type(adapter).__name__
    if name == "JiraAdapter":
        return "jira"
    if name == "LinearAdapter":
        return "linear"
    if name == "GitHubAdapter":
        return "github"
    return "unknown"


async def forward_sync(
    doc: SpecDocument,
    adapter: TicketAdapter,
    project_key: str,
    *,
    require_review: bool = False,
) -> tuple[str, SyncResult]:
    """Forward sync: create tickets for sections without one.

    When ``require_review`` is True, sync is blocked unless the spec's
    frontmatter ``review_status`` is ``"approved"``.

    Returns (updated_markdown, sync_result).
    """
    if require_review:
        review_status = getattr(doc.frontmatter, "review_status", None)
        if review_status != "approved":
            result = SyncResult()
            result.errors.append(
                SyncError(
                    section_id="__document__",
                    error=(
                        f"Spec requires review approval before ticket sync "
                        f"(current review_status: {review_status!r})"
                    ),
                )
            )
            return doc.raw, result

    result = SyncResult()
    insertions: list[TicketLinkInsertion] = []
    all_sections = _flatten_sections(doc.sections)

    for section in all_sections:
        if not section.section_number:
            continue

        if not section.ticket_link:
            try:
                ticket = await adapter.create_ticket(
                    CreateTicketInput(
                        project_key=project_key,
                        summary=f"[{section.section_number}] {section.title}",
                        description=section.content[:2000],
                        status=section.status,
                    )
                )
                insertions.append(
                    TicketLinkInsertion(
                        heading_line=section.start_line,
                        system=_detect_system_from_adapter(adapter),
                        ticket_id=ticket.ticket_id,
                    )
                )
                result.created.append(
                    SyncCreated(
                        section_id=section.id,
                        ticket_id=ticket.ticket_id,
                        ticket_url=ticket.ticket_url,
                    )
                )
            except Exception as err:
                result.errors.append(SyncError(section_id=section.id, error=str(err)))
        else:
            result.updated.append(
                SyncUpdated(
                    section_id=section.id,
                    ticket_id=section.ticket_link.ticket_id,
                )
            )

    markdown = insert_ticket_links(doc, insertions) if insertions else doc.raw
    return markdown, result


async def reverse_sync(
    doc: SpecDocument,
    adapter: TicketAdapter,
) -> tuple[str, SyncResult]:
    """Reverse sync: poll ticket statuses and update spec status comments.

    Returns (updated_markdown, sync_result).
    """
    result = SyncResult()
    updates: list[StatusUpdate] = []
    all_sections = _flatten_sections(doc.sections)

    for section in all_sections:
        if not section.ticket_link or not section.section_number:
            continue

        try:
            ticket_status = await adapter.get_ticket_status(section.ticket_link.ticket_id)

            if ticket_status.status.state != section.status.state:
                updates.append(
                    StatusUpdate(
                        section_number=section.section_number,
                        new_state=ticket_status.status.state,
                    )
                )
                result.status_changed.append(
                    SyncStatusChanged(
                        section_id=section.id,
                        ticket_id=section.ticket_link.ticket_id,
                        old_state=section.status.state,
                        new_state=ticket_status.status.state,
                    )
                )
        except Exception as err:
            result.errors.append(SyncError(section_id=section.id, error=str(err)))

    markdown = update_status_comments(doc, updates) if updates else doc.raw
    return markdown, result
