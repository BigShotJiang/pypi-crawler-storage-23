"""Ticket sync — bidirectional spec ↔ ticket synchronization."""
