"""Permission and Role enums for multi-tenant RBAC."""

from __future__ import annotations

from enum import StrEnum


class Permission(StrEnum):
    """Fine-grained permissions for Specwright resources."""

    SPECS_READ = "specs:read"
    SPECS_WRITE = "specs:write"
    SPECS_ADMIN = "specs:admin"
    ORG_MANAGE = "org:manage"


class Role(StrEnum):
    """Pre-defined roles that map to permission sets.

    .. note::

       Roles are defined here for future use when Auth0 Organizations
       role-based assignment is implemented (planned for a follow-up phase).
       Currently, permissions are resolved directly from Auth0 access token
       claims or API key scopes — roles are not assigned at runtime yet.
    """

    VIEWER = "viewer"
    EDITOR = "editor"
    ADMIN = "admin"


#: Mapping from role → granted permissions (cumulative).
#: Used by ``permissions_for_role`` — will be wired into user resolution
#: once role-based assignment is implemented.
ROLE_PERMISSIONS: dict[Role, frozenset[Permission]] = {
    Role.VIEWER: frozenset({Permission.SPECS_READ}),
    Role.EDITOR: frozenset({Permission.SPECS_READ, Permission.SPECS_WRITE}),
    Role.ADMIN: frozenset(Permission),  # all permissions
}


def permissions_for_role(role: Role) -> frozenset[Permission]:
    """Return the set of permissions granted by a role."""
    return ROLE_PERMISSIONS.get(role, frozenset())


#: All valid permission strings (for validation).
ALL_PERMISSION_VALUES: frozenset[str] = frozenset(p.value for p in Permission)
