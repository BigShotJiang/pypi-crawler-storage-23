"""Auth0 OAuth client configuration."""

from __future__ import annotations

from authlib.integrations.starlette_client import OAuth

from ..settings import Settings

oauth = OAuth()


def configure_oauth(settings: Settings) -> None:
    """Register Auth0 as an OIDC provider. Call during app startup."""
    client_kwargs: dict = {"scope": "openid email profile"}

    # When audience is set, Auth0 returns an access token with permissions claims.
    if settings.auth0_audience:
        client_kwargs["audience"] = settings.auth0_audience

    oauth.register(
        name="auth0",
        client_id=settings.auth0_client_id,
        client_secret=settings.auth0_client_secret,
        server_metadata_url=f"https://{settings.auth0_domain}/.well-known/openid-configuration",
        client_kwargs=client_kwargs,
    )
