---
title: "Untitled Spec"
type: spec
status: draft
owner: ""
team: ""
review_status: draft
tags: []
depends_on: []
created: ""
updated: ""
---

# Untitled Spec

## 1. Background

Describe the context and motivation for this spec.

## 2. Requirements

### Acceptance Criteria

- [ ] First requirement

## 3. Design

Describe the technical approach.

## 4. Rollout Plan

Describe phased rollout and success criteria.
