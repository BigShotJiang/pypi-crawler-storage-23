-- Specwright search schema
-- Extensions
CREATE EXTENSION IF NOT EXISTS vector;        -- pgvector

-- Spec documents table
CREATE TABLE IF NOT EXISTS spec_documents (
    id              BIGSERIAL PRIMARY KEY,
    repo            TEXT NOT NULL,
    path            TEXT NOT NULL,
    title           TEXT NOT NULL DEFAULT '',
    status          TEXT NOT NULL DEFAULT '',
    content_hash    TEXT NOT NULL DEFAULT '',
    commit_sha      TEXT NOT NULL DEFAULT '',
    embedding       vector(1024),
    indexed_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (repo, path)
);

-- Spec sections table
CREATE TABLE IF NOT EXISTS spec_sections (
    id              BIGSERIAL PRIMARY KEY,
    document_id     BIGINT NOT NULL REFERENCES spec_documents(id) ON DELETE CASCADE,
    heading         TEXT NOT NULL DEFAULT '',
    level           INT NOT NULL DEFAULT 1,
    body            TEXT NOT NULL DEFAULT '',
    status          TEXT NOT NULL DEFAULT '',
    ticket_ref      TEXT NOT NULL DEFAULT '',
    embedding       vector(1024),
    indexed_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- B-tree indices for filtering
CREATE INDEX IF NOT EXISTS idx_spec_documents_repo ON spec_documents (repo);
CREATE INDEX IF NOT EXISTS idx_spec_sections_document_id ON spec_sections (document_id);

-- Migration: resize embedding columns from 1536 to 1024 (for existing deployments)
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'spec_documents' AND column_name = 'embedding'
    ) THEN
        DROP INDEX IF EXISTS idx_spec_documents_embedding;
        ALTER TABLE spec_documents ALTER COLUMN embedding TYPE vector(1024);
    END IF;
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'spec_sections' AND column_name = 'embedding'
    ) THEN
        DROP INDEX IF EXISTS idx_spec_sections_embedding;
        ALTER TABLE spec_sections ALTER COLUMN embedding TYPE vector(1024);
    END IF;
END
$$;

-- Migration: add commit_sha column (for existing deployments)
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'spec_documents' AND column_name = 'commit_sha'
    ) THEN
        ALTER TABLE spec_documents ADD COLUMN commit_sha TEXT NOT NULL DEFAULT '';
    END IF;
END
$$;

-- Migration: add doc_type and staleness columns (for existing deployments)
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'spec_documents' AND column_name = 'doc_type'
    ) THEN
        ALTER TABLE spec_documents ADD COLUMN doc_type TEXT NOT NULL DEFAULT 'spec';
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'spec_documents' AND column_name = 'last_code_change_at'
    ) THEN
        ALTER TABLE spec_documents ADD COLUMN last_code_change_at TIMESTAMPTZ;
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'spec_documents' AND column_name = 'last_doc_change_at'
    ) THEN
        ALTER TABLE spec_documents ADD COLUMN last_doc_change_at TIMESTAMPTZ;
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'spec_documents' AND column_name = 'stale_since'
    ) THEN
        ALTER TABLE spec_documents ADD COLUMN stale_since TIMESTAMPTZ;
    END IF;
END
$$;

-- HNSW vector indices for similarity search
CREATE INDEX IF NOT EXISTS idx_spec_documents_embedding
    ON spec_documents USING hnsw (embedding vector_cosine_ops);
CREATE INDEX IF NOT EXISTS idx_spec_sections_embedding
    ON spec_sections USING hnsw (embedding vector_cosine_ops);
