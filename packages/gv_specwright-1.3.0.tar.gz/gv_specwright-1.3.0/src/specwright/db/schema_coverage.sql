-- Coverage snapshots: daily point-in-time coverage metrics per spec.
-- One row per spec per day, aggregatable by repo/team/org.

CREATE TABLE IF NOT EXISTS coverage_snapshots (
    id              BIGSERIAL PRIMARY KEY,
    snapshot_date   DATE NOT NULL,
    org             TEXT NOT NULL,
    repo            TEXT NOT NULL,
    team            TEXT NOT NULL DEFAULT '',
    spec_path       TEXT NOT NULL DEFAULT '',
    total_sections  INT NOT NULL DEFAULT 0,
    done_sections   INT NOT NULL DEFAULT 0,
    total_ac        INT NOT NULL DEFAULT 0,
    done_ac         INT NOT NULL DEFAULT 0,
    realized_ac     INT NOT NULL DEFAULT 0,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (snapshot_date, org, repo, spec_path)
);

CREATE INDEX IF NOT EXISTS idx_coverage_snapshots_org
    ON coverage_snapshots (org);

CREATE INDEX IF NOT EXISTS idx_coverage_snapshots_date
    ON coverage_snapshots (snapshot_date);

CREATE INDEX IF NOT EXISTS idx_coverage_snapshots_org_repo
    ON coverage_snapshots (org, repo);
