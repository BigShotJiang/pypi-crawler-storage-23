# Bundled plugin data for distribution.
# The skills/ symlink points to plugin/skills/ for local dev.
# In the wheel, hatch force-include copies the actual files here.
