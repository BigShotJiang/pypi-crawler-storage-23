# Getting Started

Specwright is an AI-native documentation platform that turns your markdown specs into living, self-maintaining documents. There are several ways to use it depending on your workflow.

## Choose Your Path

### GitHub App (recommended)

Install the Specwright GitHub App to get automated PR analysis, spec tracking, and doc maintenance across your repos. Best for teams that want the full platform experience.

[Installation Guide →](./installation)

### Claude Code Plugin

Add Specwright skills to Claude Code for spec-driven development workflows — context loading, verification, task tracking, and coverage dashboards.

[Installation Guide →](./installation#claude-code-plugin)

### MCP Server

Connect any MCP-compatible coding agent (Claude Code, Cursor, VS Code Copilot) to the Specwright knowledge base for spec search and context.

[Installation Guide →](./installation#mcp-server)

### Self-Hosted

Deploy Specwright to your own Kubernetes cluster for full control over data and configuration.

[Self-Hosting Guide →](/guides/self-hosting)

## Quick Links

- [Quickstart →](./quickstart) — Write your first spec in 5 minutes
- [Configuration →](./configuration) — SPECWRIGHT.yaml reference
- [Writing Specs →](/guides/writing-specs) — Spec authoring guide with examples
- [Concepts →](/concepts/) — Understand the core ideas behind Specwright
