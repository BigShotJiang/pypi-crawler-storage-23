# Guides

Practical how-to guides for working with Specwright.

## Authoring

- [Writing Specs](./writing-specs) — Spec authoring guide with format reference and examples

## Deployment

- [Self-Hosting](./self-hosting) — Deploy Specwright to your own Kubernetes cluster
- [GitHub App Setup](./github-app) — Configure the Specwright GitHub App

## Integration

- [Ticket Sync](./ticket-sync) — Connect specs to Jira, Linear, or GitHub Issues
- [CI Integration](./ci-integration) — Add spec validation to your CI/CD pipeline
