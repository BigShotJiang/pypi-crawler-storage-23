# CLI Reference

The Specwright CLI provides local spec management commands. Install via `uv` or `pip`.

## Installation

```bash
# With uv (recommended)
uv tool install gv-specwright

# With pip
pip install gv-specwright
```

## Commands

### `specwright login`

Authenticate with the Specwright platform using device authorization flow.

```bash
specwright login
```

Opens a browser for Auth0 device authorization. Tokens are stored at `~/.config/specwright/credentials.json`.

### `specwright init`

Initialize a repository for Specwright.

```bash
specwright init
```

Creates:
- `SPECWRIGHT.yaml` with sensible defaults
- `docs/specs/` directory
- `docs/specs/_template.md` spec template

### `specwright lint`

Validate spec files for format compliance.

```bash
specwright lint [PATH...]
```

| Option | Description |
|--------|-------------|
| `PATH` | Spec files or directories to lint (default: `docs/specs/`) |
| `--strict` | Treat warnings as errors |

Checks: valid frontmatter, status values, section numbering, AC format, status comment syntax.

### `specwright coverage`

Show spec coverage metrics.

```bash
specwright coverage [PATH...]
```

| Option | Description |
|--------|-------------|
| `PATH` | Spec files to analyze (default: `docs/specs/`) |
| `--min N` | Exit with error if coverage below N% |
| `--json` | Output as JSON |

### `specwright validate-config`

Validate `SPECWRIGHT.yaml` syntax and values.

```bash
specwright validate-config [FILE]
```

| Option | Description |
|--------|-------------|
| `FILE` | Config file path (default: `SPECWRIGHT.yaml`) |

### `specwright mcp`

Start the MCP server for coding agent integration.

```bash
specwright mcp
```

Starts a stdio-based MCP server. See [MCP Tools](./mcp) for available tools.

## Environment Variables

| Variable | Description |
|----------|-------------|
| `SPECWRIGHT_CONFIG` | Override config file path (default: `SPECWRIGHT.yaml`) |
| `ANTHROPIC_API_KEY` | API key for agent features |
| `LOG_LEVEL` | Logging level (`debug`, `info`, `warning`, `error`) |

::: warning Provisional
This CLI reference is hand-written and may not reflect the latest commands. It will be auto-generated from source in a future update.
:::
