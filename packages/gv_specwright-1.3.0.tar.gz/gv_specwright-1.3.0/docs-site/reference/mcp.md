# MCP Tools Reference

The Specwright MCP server exposes tools for coding agents (Claude Code, Cursor, VS Code Copilot) to query and update the spec knowledge base.

## Setup

### Claude Code

Add to your MCP configuration:

```json
{
  "mcpServers": {
    "specwright": {
      "command": "uvx",
      "args": ["specwright", "mcp"]
    }
  }
}
```

## Tools

### `search`

Search the spec knowledge base using hybrid search (vector + BM25).

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `query` | string | Yes | Search query text |
| `repo` | string | No | Filter by repository (`owner/repo`) |
| `status` | string | No | Filter by section status |
| `limit` | integer | No | Max results (default: 10) |

**Returns:** Matching sections with repo, path, title, heading, body snippet, status, and relevance score.

### `get_spec`

Get a full parsed spec document with frontmatter, sections, acceptance criteria, and status.

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `owner` | string | Yes | Repository owner |
| `repo` | string | Yes | Repository name |
| `file_path` | string | Yes | Path to spec file |

**Returns:** Structured spec data including all sections, their statuses, ticket links, and acceptance criteria.

### `get_section`

Get a single section from a spec by its ID.

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `owner` | string | Yes | Repository owner |
| `repo` | string | Yes | Repository name |
| `file_path` | string | Yes | Path to spec file |
| `section_id` | string | Yes | Section identifier |

**Returns:** Section content, acceptance criteria, status, and ticket link.

### `get_doc`

Get raw markdown content of any document from a repository.

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `owner` | string | Yes | Repository owner |
| `repo` | string | Yes | Repository name |
| `file_path` | string | Yes | Path to document |

**Returns:** Raw markdown content.

### `create_spec`

Create a new spec document from a template.

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `owner` | string | Yes | Repository owner |
| `repo` | string | Yes | Repository name |
| `title` | string | Yes | Spec title |
| `owner_name` | string | No | Spec owner name |
| `team` | string | No | Team name |
| `tags` | string[] | No | Tags |

**Returns:** Created file path and commit SHA.

### `update_section_status`

Update the status of a spec section.

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `owner` | string | Yes | Repository owner |
| `repo` | string | Yes | Repository name |
| `file_path` | string | Yes | Path to spec file |
| `section_id` | string | Yes | Section identifier |
| `new_state` | string | Yes | New status value |

**Returns:** Updated section data.

### `add_realization`

Add realization evidence linking a PR and code location to an acceptance criterion.

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `owner` | string | Yes | Repository owner |
| `repo` | string | Yes | Repository name |
| `file_path` | string | Yes | Path to spec file |
| `section_id` | string | Yes | Section identifier |
| `ac_text` | string | Yes | Acceptance criterion text |
| `pr_number` | integer | Yes | Pull request number |
| `code_file` | string | Yes | File path with evidence |
| `lines` | string | No | Line range (e.g., `42-60`) |

**Returns:** Updated section with realization evidence.

### `sync_spec_status`

Bulk update a spec: apply multiple status updates and realizations in a single commit.

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `owner` | string | Yes | Repository owner |
| `repo` | string | Yes | Repository name |
| `file_path` | string | Yes | Path to spec file |
| `status_updates` | object[] | No | List of status updates |
| `realizations` | object[] | No | List of realizations |
| `commit_message` | string | No | Custom commit message |

**Returns:** Commit SHA and summary of changes.

### `list_specs`

List all spec documents in a repository's `docs/specs/` directory.

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `owner` | string | Yes | Repository owner |
| `repo` | string | Yes | Repository name |

**Returns:** List of specs with title, status, and owner metadata.

### `get_coverage`

Get spec coverage metrics for the organization.

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `repo` | string | No | Filter by repository |
| `team` | string | No | Filter by team |
| `days` | integer | No | Time range for trend (default: 30) |

**Returns:** Coverage summary and time-series trend.

::: warning Provisional
This MCP reference is hand-written and may not reflect the latest tools. It will be auto-generated from source in a future update.
:::
