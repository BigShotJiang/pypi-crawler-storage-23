# REST API

::: warning Work in Progress
The REST API is under active development. This page documents the current endpoints. Additional endpoints for spec management, coverage queries, and org-level operations are planned.
:::

## Base URL

- **Hosted**: `https://specwright.gernerventures.com`
- **Self-hosted**: `https://<your-domain>`

## Authentication

API requests use Bearer token authentication:

```
Authorization: Bearer <token>
```

Tokens can be:
- JWT access tokens (from Auth0 login)
- API keys (prefixed with `sw_`)

## Endpoints

### Health Check

```
GET /healthz
```

Returns `200 OK` if the service is running.

**Response:**
```json
{
  "status": "ok"
}
```

### Webhook

```
POST /webhook
```

GitHub App webhook endpoint. Receives push, pull_request, issues, and issue_comment events. Requires HMAC SHA-256 signature verification via the `X-Hub-Signature-256` header.

### Spec Coverage

```
GET /api/coverage
```

Returns spec coverage metrics.

**Query Parameters:**
| Name | Type | Description |
|------|------|-------------|
| `repo` | string | Filter by repository (`owner/repo`) |
| `team` | string | Filter by team |

**Response:**
```json
{
  "total_specs": 12,
  "total_sections": 48,
  "total_acs": 156,
  "realized_acs": 89,
  "coverage_pct": 57.1,
  "health_score": 72
}
```

::: info
Full API reference will be auto-generated from the OpenAPI schema in a future update.
:::
