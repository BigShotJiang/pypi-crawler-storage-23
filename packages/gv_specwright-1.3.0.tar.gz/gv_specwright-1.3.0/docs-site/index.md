---
layout: home

hero:
  name: Specwright
  text: AI-Native Documentation Platform
  tagline: Living specs that generate tickets. AI agents that maintain docs. Repo-native knowledge that replaces Confluence.
  actions:
    - theme: brand
      text: Get Started
      link: /getting-started/
    - theme: alt
      text: View on GitHub
      link: https://github.com/Gerner-Ventures/gv-exp-specwright

features:
  - icon: "\U0001F4DD"
    title: Living Specs
    details: Structured markdown specs that track implementation status, generate tickets, and verify themselves against code.
  - icon: "\U0001F916"
    title: Agent-Maintained Docs
    details: Claude agents analyze PRs against specs, flag stale docs, and auto-generate doc-update PRs when code changes.
  - icon: "\U0001F3AF"
    title: Spec Realization
    details: Code is the ground truth. The agent verifies implementation against acceptance criteria — not just whether a ticket was closed.
  - icon: "\U0001F50D"
    title: All-Markdown Knowledge Base
    details: Every markdown file in your repo is indexed — specs, ADRs, guides, READMEs. One search surface for all documentation.
  - icon: "\U0001F3AB"
    title: Bidirectional Ticket Sync
    details: Spec sections auto-create Jira, Linear, or GitHub Issues. Ticket status flows back. Code merges close tickets with evidence.
  - icon: "\U0001F50C"
    title: IDE Integration
    details: MCP server connects Claude Code, Cursor, and VS Code to your spec knowledge base. Ask questions, get cited answers.
---
