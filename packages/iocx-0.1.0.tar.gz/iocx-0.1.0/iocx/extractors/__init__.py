# Manually import each detector module so they register themselves
from . import urls
from . import ips
from . import hashes
from . import emails
from . import filepaths
from . import base64
