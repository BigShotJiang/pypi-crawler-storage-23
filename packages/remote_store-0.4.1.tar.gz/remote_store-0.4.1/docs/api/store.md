# Store

The `Store` is the main entry point for all file operations. It is scoped to a folder within a backend and provides a uniform API regardless of the underlying storage.

::: remote_store.Store
