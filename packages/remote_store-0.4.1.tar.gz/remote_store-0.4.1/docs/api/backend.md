# Backend

The `Backend` is the abstract base class that all storage backends implement. You typically interact with backends through a `Store` rather than directly.

::: remote_store.Backend
