# Registry

The `Registry` manages backend instances and creates stores. Use it as a context manager to ensure proper cleanup.

::: remote_store.Registry

---

## register_backend

::: remote_store.register_backend
