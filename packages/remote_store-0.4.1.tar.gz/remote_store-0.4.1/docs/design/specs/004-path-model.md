{%
   include-markdown "../../../sdd/specs/004-path-model.md"
   rewrite-relative-urls=false
%}
