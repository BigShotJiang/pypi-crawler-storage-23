{%
   include-markdown "../../../sdd/specs/007-atomic-writes.md"
   rewrite-relative-urls=false
%}
