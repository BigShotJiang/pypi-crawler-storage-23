{%
   include-markdown "../../../sdd/specs/001-store-api.md"
   rewrite-relative-urls=false
%}
