{%
   include-markdown "../../../sdd/adrs/0003-fsspec-is-implementation-detail.md"
   rewrite-relative-urls=false
%}
