"""Empty package nvidia_vfx."""

__version__ = "0.0.0a0"
