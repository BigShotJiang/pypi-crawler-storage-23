"""Scoring algorithms for DockAudit."""
