"""Tests for the AGR Work service client."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.agr_work.schemas import HealthCheckData


class TestAgrWorkSchemas:
    """Tests for AGR Work schemas."""

    def test_health_check_data(self) -> None:
        """Should parse health check data."""
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"
        assert result.site_hash == "abc123"


class TestAgrWorkClient:
    """Tests for AgrWorkClient."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://agr-work.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.agr_work.health_check()
        assert response.data.site_id == "test-site"

    def test_ping(self, httpx_mock: HTTPXMock, api: AugurAPI, mock_ping_response: dict) -> None:
        """Should call ping endpoint."""
        httpx_mock.add_response(
            url="https://agr-work.augur-api.com/ping",
            json=mock_ping_response,
        )
        response = api.agr_work.ping()
        assert response.data == "pong"

    def test_whoami(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should call whoami endpoint."""
        mock_response = {
            "count": 1,
            "data": {"user_id": "test-user", "email": "test@example.com"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-work.augur-api.com/whoami",
            json=mock_response,
        )
        response = api.agr_work.whoami()
        assert response.data["user_id"] == "test-user"
