"""Tests for the Brand Folder service client."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.brand_folder.schemas import (
    Asset,
    AssetCreateParams,
    AssetListParams,
    Category,
    CategoryListParams,
    Collection,
    CollectionListParams,
    HealthCheckData,
)


class TestBrandFolderSchemas:
    """Tests for Brand Folder schemas."""

    def test_health_check_data(self) -> None:
        """Should parse health check data."""
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"

    def test_asset_list_params(self) -> None:
        """Should create asset list params."""
        params = AssetListParams(limit=10, offset=5, section_id="section-1")
        assert params.limit == 10
        assert params.offset == 5
        assert params.section_id == "section-1"

    def test_asset_model(self) -> None:
        """Should parse asset data."""
        data = {"assetsUid": 1, "name": "Test Asset", "fileType": "image/png"}
        result = Asset.model_validate(data)
        assert result.assets_uid == 1
        assert result.name == "Test Asset"

    def test_asset_create_params(self) -> None:
        """Should create asset create params."""
        params = AssetCreateParams(name="Test", section_id="section-1")
        assert params.name == "Test"
        assert params.section_id == "section-1"

    def test_category_list_params(self) -> None:
        """Should create category list params."""
        params = CategoryListParams(limit=10)
        assert params.limit == 10

    def test_category_model(self) -> None:
        """Should parse category data."""
        data = {"categoriesUid": 1, "name": "Test Category"}
        result = Category.model_validate(data)
        assert result.categories_uid == 1

    def test_collection_list_params(self) -> None:
        """Should create collection list params."""
        params = CollectionListParams(limit=10)
        assert params.limit == 10

    def test_collection_model(self) -> None:
        """Should parse collection data."""
        data = {"collectionsUid": 1, "name": "Test Collection", "public": True}
        result = Collection.model_validate(data)
        assert result.collections_uid == 1
        assert result.public is True


class TestBrandFolderClient:
    """Tests for BrandFolderClient."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://brand-folder.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.brand_folder.health_check()
        assert response.data.site_id == "test-site"

    def test_assets_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list assets."""
        mock_response = {
            "count": 1,
            "data": [{"assetsUid": 1, "name": "Test"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://brand-folder.augur-api.com/assets",
            json=mock_response,
        )
        response = api.brand_folder.assets.list()
        assert len(response.data) == 1

    def test_assets_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get asset by UID."""
        mock_response = {
            "count": 1,
            "data": {"assetsUid": 1, "name": "Test"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://brand-folder.augur-api.com/assets/1",
            json=mock_response,
        )
        response = api.brand_folder.assets.get(1)
        assert response.data.assets_uid == 1

    def test_assets_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create asset."""
        mock_response = {
            "count": 1,
            "data": {"assetsUid": 1, "name": "Test"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://brand-folder.augur-api.com/assets",
            json=mock_response,
            method="POST",
        )
        response = api.brand_folder.assets.create(
            AssetCreateParams(name="Test", section_id="section-1")
        )
        assert response.data.assets_uid == 1

    def test_categories_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list categories."""
        mock_response = {
            "count": 1,
            "data": [{"categoriesUid": 1, "name": "Test"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://brand-folder.augur-api.com/categories",
            json=mock_response,
        )
        response = api.brand_folder.categories.list()
        assert len(response.data) == 1

    def test_categories_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get category by UID."""
        mock_response = {
            "count": 1,
            "data": {"categoriesUid": 1, "name": "Test"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://brand-folder.augur-api.com/categories/1",
            json=mock_response,
        )
        response = api.brand_folder.categories.get(1)
        assert response.data.categories_uid == 1

    def test_collections_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list collections."""
        mock_response = {
            "count": 1,
            "data": [{"collectionsUid": 1, "name": "Test"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://brand-folder.augur-api.com/collections",
            json=mock_response,
        )
        response = api.brand_folder.collections.list()
        assert len(response.data) == 1

    def test_collections_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get collection by UID."""
        mock_response = {
            "count": 1,
            "data": {"collectionsUid": 1, "name": "Test"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://brand-folder.augur-api.com/collections/1",
            json=mock_response,
        )
        response = api.brand_folder.collections.get(1)
        assert response.data.collections_uid == 1

    def test_categories_focus_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should set category focus configuration."""
        mock_response = {
            "count": 1,
            "data": {"categoryId": "cat-1", "categoryName": "Focus Cat"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://brand-folder.augur-api.com/categories/focus",
            json=mock_response,
            method="POST",
        )
        response = api.brand_folder.categories.focus.create({"category_id": "cat-1"})
        assert response.data.category_id == "cat-1"

    def test_categories_focus_property_cached(self, api: AugurAPI) -> None:
        """Should return same focus resource instance."""
        categories = api.brand_folder.categories
        assert categories.focus is categories.focus

    def test_resource_properties_return_same_instance(self, api: AugurAPI) -> None:
        """Should return same resource instance on multiple accesses."""
        client = api.brand_folder
        assert client.assets is client.assets
        assert client.categories is client.categories
        assert client.collections is client.collections
