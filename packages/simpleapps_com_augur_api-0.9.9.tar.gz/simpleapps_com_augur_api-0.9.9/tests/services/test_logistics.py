"""Tests for the Logistics service client."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.logistics.schemas import (
    HealthCheckData,
    ShipviaLtlRate,
    ShipviaLtlRatesParams,
    ShipviaRate,
    ShipviaRatesParams,
    SpeedshipFreight,
    SpeedshipFreightParams,
)


class TestLogisticsSchemas:
    """Tests for Logistics schemas."""

    def test_health_check_data(self) -> None:
        """Should parse health check data."""
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"

    def test_shipvia_rates_params(self) -> None:
        """Should create shipvia rates params."""
        params = ShipviaRatesParams(
            origin_zip="90210",
            destination_zip="10001",
            weight=5.0,
            ship_via_cd="UPS-GND",
        )
        assert params.origin_zip == "90210"
        assert params.destination_zip == "10001"
        assert params.weight == 5.0

    def test_shipvia_rate_model(self) -> None:
        """Should parse shipvia rate data."""
        data = {
            "carrier": "UPS",
            "serviceType": "Ground",
            "rate": 12.99,
            "transitDays": 3,
        }
        result = ShipviaRate.model_validate(data)
        assert result.carrier == "UPS"
        assert result.rate == 12.99
        assert result.transit_days == 3

    def test_shipvia_ltl_rates_params(self) -> None:
        """Should create shipvia LTL rates params."""
        params = ShipviaLtlRatesParams(
            origin_zip="90210",
            destination_zip="10001",
            weight=500.0,
            freight_class="70",
        )
        assert params.freight_class == "70"
        assert params.weight == 500.0

    def test_shipvia_ltl_rate_model(self) -> None:
        """Should parse shipvia LTL rate data."""
        data = {
            "carrier": "FedEx Freight",
            "rate": 250.00,
            "transitDays": 5,
        }
        result = ShipviaLtlRate.model_validate(data)
        assert result.carrier == "FedEx Freight"
        assert result.rate == 250.00

    def test_speedship_freight_params(self) -> None:
        """Should create speedship freight params."""
        params = SpeedshipFreightParams(
            origin_zip="90210",
            destination_zip="10001",
            weight=5.0,
        )
        assert params.origin_zip == "90210"
        assert params.weight == 5.0

    def test_speedship_freight_model(self) -> None:
        """Should parse speedship freight data."""
        data = {
            "rate": 12.99,
            "transitDays": 3,
            "carrier": "UPS",
        }
        result = SpeedshipFreight.model_validate(data)
        assert result.rate == 12.99
        assert result.transit_days == 3


class TestLogisticsClient:
    """Tests for LogisticsClient."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://logistics.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.logistics.health_check()
        assert response.data.site_id == "test-site"

    def test_shipvia_rates(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get shipvia shipping rates."""
        mock_response = {
            "count": 2,
            "data": [
                {"carrier": "UPS", "serviceType": "Ground", "rate": 12.99, "transitDays": 3},
                {"carrier": "FedEx", "serviceType": "Ground", "rate": 11.99, "transitDays": 4},
            ],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 2,
            "totalResults": 2,
        }
        httpx_mock.add_response(
            url="https://logistics.augur-api.com/shipvia/rates",
            json=mock_response,
        )
        response = api.logistics.shipvia.rates()
        assert len(response.data) == 2
        assert response.data[0].carrier == "UPS"

    def test_shipvia_rates_with_params(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get shipvia rates with params."""
        mock_response = {
            "count": 1,
            "data": [{"carrier": "UPS", "rate": 12.99}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://logistics.augur-api.com/shipvia/rates?originZip=90210&destinationZip=10001",
            json=mock_response,
        )
        response = api.logistics.shipvia.rates(
            ShipviaRatesParams(origin_zip="90210", destination_zip="10001")
        )
        assert len(response.data) == 1

    def test_shipvia_rates_ltl(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get shipvia LTL freight rates."""
        mock_response = {
            "count": 1,
            "data": [{"carrier": "FedEx Freight", "rate": 250.00, "transitDays": 5}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://logistics.augur-api.com/shipvia/rates/ltl",
            json=mock_response,
        )
        response = api.logistics.shipvia.rates_ltl()
        assert len(response.data) == 1
        assert response.data[0].carrier == "FedEx Freight"

    def test_speedship_freight(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get speedship freight."""
        mock_response = {
            "count": 1,
            "data": {"rate": 12.99, "transitDays": 3, "carrier": "UPS"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://logistics.augur-api.com/speedship/freight",
            json=mock_response,
        )
        response = api.logistics.speedship.freight()
        assert response.data.rate == 12.99

    def test_speedship_freight_with_params(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get speedship freight with params."""
        mock_response = {
            "count": 1,
            "data": {"rate": 15.99, "transitDays": 2},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://logistics.augur-api.com/speedship/freight?originZip=90210&destinationZip=10001&weight=10.0",
            json=mock_response,
        )
        response = api.logistics.speedship.freight(
            SpeedshipFreightParams(origin_zip="90210", destination_zip="10001", weight=10.0)
        )
        assert response.data.rate == 15.99

    def test_resource_properties_return_same_instance(self, api: AugurAPI) -> None:
        """Should return same resource instance on multiple accesses."""
        client = api.logistics
        assert client.shipvia is client.shipvia
        assert client.speedship is client.speedship
