"""Tests for the Commerce service client."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.commerce.schemas import (
    AlsoBoughtItem,
    AlsoBoughtParams,
    CartHdr,
    CartHdrListParams,
    CartHdrLookupParams,
    CartLine,
    CartLineAddItem,
    CartLineDeleteResponse,
    CartLineUpdateItem,
    Checkout,
    CheckoutCreateParams,
    CheckoutDoc,
    CheckoutDocParams,
    HealthCheckData,
    Prophet21Hdr,
    Prophet21Line,
)


class TestCommerceSchemas:
    """Tests for Commerce schemas."""

    def test_health_check_data(self) -> None:
        """Should parse health check data."""
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"

    def test_cart_hdr_list_params(self) -> None:
        """Should create cart hdr list params."""
        params = CartHdrListParams(user_id=123)
        assert params.user_id == 123

    def test_cart_hdr_lookup_params(self) -> None:
        """Should create cart hdr lookup params."""
        params = CartHdrLookupParams(user_id=1, customer_id=100, contact_id=50)
        assert params.user_id == 1
        assert params.customer_id == 100
        assert params.contact_id == 50

    def test_cart_hdr_model(self) -> None:
        """Should parse cart hdr data."""
        data = {"cartHdrUid": 1, "userId": 123, "cartToken": "token123"}
        result = CartHdr.model_validate(data)
        assert result.cart_hdr_uid == 1
        assert result.user_id == 123

    def test_also_bought_params(self) -> None:
        """Should create also bought params."""
        params = AlsoBoughtParams(limit=10, offset=5)
        assert params.limit == 10

    def test_also_bought_item_model(self) -> None:
        """Should parse also bought item data."""
        data = {"invMastUid": 1, "itemId": "ABC123", "score": 0.95}
        result = AlsoBoughtItem.model_validate(data)
        assert result.inv_mast_uid == 1

    def test_cart_line_model(self) -> None:
        """Should parse cart line data."""
        data = {"cartLineUid": 1, "cartHdrUid": 1, "quantity": 5.0}
        result = CartLine.model_validate(data)
        assert result.cart_line_uid == 1

    def test_cart_line_add_item(self) -> None:
        """Should create cart line add item."""
        item = CartLineAddItem(inv_mast_uid=1, quantity=5.0)
        assert item.inv_mast_uid == 1
        assert item.quantity == 5.0

    def test_cart_line_update_item(self) -> None:
        """Should create cart line update item."""
        item = CartLineUpdateItem(line_no=1, quantity=10.0)
        assert item.line_no == 1
        assert item.quantity == 10.0

    def test_cart_line_delete_response(self) -> None:
        """Should parse cart line delete response."""
        data = {"success": True, "message": "Deleted"}
        result = CartLineDeleteResponse.model_validate(data)
        assert result.success is True

    def test_checkout_create_params(self) -> None:
        """Should create checkout create params."""
        params = CheckoutCreateParams(cart_hdr_uid=1, customer_id=100)
        assert params.cart_hdr_uid == 1

    def test_checkout_model(self) -> None:
        """Should parse checkout data."""
        data = {"checkoutUid": 1, "cartHdrUid": 1, "orderNo": 12345}
        result = Checkout.model_validate(data)
        assert result.checkout_uid == 1
        assert result.order_no == 12345

    def test_checkout_doc_params(self) -> None:
        """Should create checkout doc params."""
        params = CheckoutDocParams(cart_hdr_uid=1, limit=10)
        assert params.cart_hdr_uid == 1

    def test_checkout_doc_model(self) -> None:
        """Should parse checkout doc data."""
        data = {"checkoutUid": 1, "orderNo": 12345, "lines": []}
        result = CheckoutDoc.model_validate(data)
        assert result.checkout_uid == 1

    def test_prophet21_hdr_model(self) -> None:
        """Should parse prophet21 hdr data."""
        data = {"prophet21HdrUid": 1, "checkoutUid": 1, "orderNo": 12345}
        result = Prophet21Hdr.model_validate(data)
        assert result.prophet21_hdr_uid == 1

    def test_prophet21_line_model(self) -> None:
        """Should parse prophet21 line data."""
        data = {"prophet21LineUid": 1, "prophet21HdrUid": 1, "lineNo": 1}
        result = Prophet21Line.model_validate(data)
        assert result.prophet21_line_uid == 1


class TestCommerceClient:
    """Tests for CommerceClient."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://commerce.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.commerce.health_check()
        assert response.data.site_id == "test-site"

    def test_cart_hdr_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list cart headers."""
        mock_response = {
            "count": 1,
            "data": [{"cartHdrUid": 1, "userId": 123}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://commerce.augur-api.com/cart-hdr/list?userId=123",
            json=mock_response,
        )
        response = api.commerce.cart_hdr.list(CartHdrListParams(user_id=123))
        assert len(response.data) == 1

    def test_cart_hdr_lookup(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should lookup cart header."""
        mock_response = {
            "count": 1,
            "data": {"cartHdrUid": 1, "userId": 1},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://commerce.augur-api.com/cart-hdr/lookup?userId=1&customerId=100&contactId=50",
            json=mock_response,
        )
        response = api.commerce.cart_hdr.lookup(
            CartHdrLookupParams(user_id=1, customer_id=100, contact_id=50)
        )
        assert response.data.cart_hdr_uid == 1

    def test_cart_hdr_get_also_bought(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get also bought recommendations."""
        mock_response = {
            "count": 1,
            "data": [{"invMastUid": 1, "itemId": "ABC123"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://commerce.augur-api.com/cart-hdr/1/also-bought",
            json=mock_response,
        )
        response = api.commerce.cart_hdr.get_also_bought(1)
        assert len(response.data) == 1

    def test_cart_line_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get cart lines."""
        mock_response = {
            "count": 1,
            "data": [{"cartLineUid": 1, "cartHdrUid": 1}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://commerce.augur-api.com/cart-line/1",
            json=mock_response,
        )
        response = api.commerce.cart_line.get(1)
        assert len(response.data) == 1

    def test_cart_line_delete_all(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should delete all cart lines."""
        mock_response = {
            "count": 1,
            "data": {"success": True, "message": "Deleted"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://commerce.augur-api.com/cart-line/1",
            json=mock_response,
            method="DELETE",
        )
        response = api.commerce.cart_line.delete_all(1)
        assert response.data.success is True

    def test_cart_line_add(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should add items to cart."""
        mock_response = {
            "count": 1,
            "data": True,
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://commerce.augur-api.com/cart-line/1/add",
            json=mock_response,
            method="POST",
        )
        response = api.commerce.cart_line.add(1, [{"quantity": 5.0}])
        assert response.data is True

    def test_cart_line_delete_line(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should delete specific cart line."""
        mock_response = {
            "count": 1,
            "data": {"success": True, "message": "Deleted"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://commerce.augur-api.com/cart-line/1/lines/2",
            json=mock_response,
            method="DELETE",
        )
        response = api.commerce.cart_line.delete_line(1, 2)
        assert response.data.success is True

    def test_cart_line_update(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should update cart lines."""
        mock_response = {
            "count": 1,
            "data": True,
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://commerce.augur-api.com/cart-line/1/update",
            json=mock_response,
            method="POST",
        )
        response = api.commerce.cart_line.update(1, [{"line_no": 1, "quantity": 10.0}])
        assert response.data is True

    def test_checkout_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create checkout."""
        mock_response = {
            "count": 1,
            "data": {"checkoutUid": 1, "cartHdrUid": 1},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://commerce.augur-api.com/checkout",
            json=mock_response,
            method="POST",
        )
        response = api.commerce.checkout.create(CheckoutCreateParams(cart_hdr_uid=1))
        assert response.data.checkout_uid == 1

    def test_checkout_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get checkout by UID."""
        mock_response = {
            "count": 1,
            "data": {"checkoutUid": 1, "cartHdrUid": 1},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://commerce.augur-api.com/checkout/1",
            json=mock_response,
        )
        response = api.commerce.checkout.get(1)
        assert response.data.checkout_uid == 1

    def test_checkout_activate(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should activate checkout."""
        mock_response = {
            "count": 1,
            "data": {"checkoutUid": 1, "orderNo": 12345},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://commerce.augur-api.com/checkout/1/activate",
            json=mock_response,
            method="PUT",
        )
        response = api.commerce.checkout.activate(1)
        assert response.data.order_no == 12345

    def test_checkout_get_doc(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get checkout document."""
        mock_response = {
            "count": 1,
            "data": {"checkoutUid": 1, "orderNo": 12345, "lines": []},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://commerce.augur-api.com/checkout/1/doc",
            json=mock_response,
        )
        response = api.commerce.checkout.get_doc(1)
        assert response.data.checkout_uid == 1

    def test_checkout_validate(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should validate checkout."""
        mock_response = {
            "count": 1,
            "data": {"checkoutUid": 1},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://commerce.augur-api.com/checkout/1/validate",
            json=mock_response,
            method="PUT",
        )
        response = api.commerce.checkout.validate(1)
        assert response.data.checkout_uid == 1

    def test_checkout_create_prophet21_hdr(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create prophet21 header."""
        mock_response = {
            "count": 1,
            "data": {"prophet21HdrUid": 1, "checkoutUid": 1},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://commerce.augur-api.com/checkout/1/prophet21-hdr",
            json=mock_response,
            method="POST",
        )
        response = api.commerce.checkout.create_prophet21_hdr(1)
        assert response.data.prophet21_hdr_uid == 1

    def test_checkout_create_prophet21_line(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create prophet21 lines."""
        mock_response = {
            "count": 1,
            "data": [{"prophet21LineUid": 1, "prophet21HdrUid": 1}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://commerce.augur-api.com/checkout/1/prophet21-hdr/2/prophet21-line",
            json=mock_response,
            method="POST",
        )
        response = api.commerce.checkout.create_prophet21_line(1, 2)
        assert len(response.data) == 1

    def test_resource_properties_return_same_instance(self, api: AugurAPI) -> None:
        """Should return same resource instance on multiple accesses."""
        client = api.commerce
        assert client.cart_hdr is client.cart_hdr
        assert client.cart_line is client.cart_line
        assert client.checkout is client.checkout
