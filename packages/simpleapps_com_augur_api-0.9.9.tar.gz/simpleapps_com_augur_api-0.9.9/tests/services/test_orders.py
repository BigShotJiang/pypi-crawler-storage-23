"""Tests for the Orders service client."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.orders.schemas import (
    HealthCheckData,
    InvoiceReprintResponse,
    OeHdr,
    OeHdrDoc,
    OeHdrDocParams,
    OeHdrLookupParams,
    PickTicket,
    PickTicketLine,
    PickTicketLinesParams,
    PickTicketsListParams,
    PoHdr,
    PoHdrDoc,
    PoHdrListParams,
    PoHdrScanParams,
    SalesRepOeHdr,
)


class TestOrdersSchemas:
    """Tests for Orders schemas."""

    def test_health_check_data(self) -> None:
        """Should parse health check data."""
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"

    def test_oe_hdr_lookup_params(self) -> None:
        """Should create order header lookup params."""
        params = OeHdrLookupParams(limit=10, salesrep_id="REP001", completed="Y")
        assert params.limit == 10
        assert params.salesrep_id == "REP001"
        assert params.completed == "Y"

    def test_oe_hdr_doc_params(self) -> None:
        """Should create order doc params."""
        params = OeHdrDocParams(postal_code="90210")
        assert params.postal_code == "90210"

    def test_oe_hdr_model(self) -> None:
        """Should parse order header data."""
        data = {
            "orderNo": 12345,
            "customerId": 100,
            "totalAmount": 999.99,
            "statusCd": 1,
        }
        result = OeHdr.model_validate(data)
        assert result.order_no == 12345
        assert result.total_amount == 999.99

    def test_oe_hdr_doc_model(self) -> None:
        """Should parse order document data."""
        data = {
            "orderNo": 12345,
            "customerId": 100,
            "customerName": "Test Customer",
            "lines": [],
        }
        result = OeHdrDoc.model_validate(data)
        assert result.order_no == 12345
        assert result.customer_name == "Test Customer"

    def test_invoice_reprint_response_model(self) -> None:
        """Should parse invoice reprint response data."""
        data = {"success": True, "message": "Invoice reprinted", "invoiceNo": 123}
        result = InvoiceReprintResponse.model_validate(data)
        assert result.success is True
        assert result.invoice_no == 123

    def test_sales_rep_oe_hdr_model(self) -> None:
        """Should parse sales rep order header data."""
        data = {
            "orderNo": 12345,
            "customerId": 100,
            "customerName": "Test",
            "totalAmount": 500.00,
        }
        result = SalesRepOeHdr.model_validate(data)
        assert result.order_no == 12345

    def test_pick_tickets_list_params(self) -> None:
        """Should create pick tickets list params."""
        params = PickTicketsListParams(limit=10, location_id=5, order_status="pending")
        assert params.location_id == 5

    def test_pick_ticket_model(self) -> None:
        """Should parse pick ticket data."""
        data = {"pickTicketNo": 1001, "orderNo": 12345, "locationId": 5, "statusCd": 1}
        result = PickTicket.model_validate(data)
        assert result.pick_ticket_no == 1001

    def test_pick_ticket_lines_params(self) -> None:
        """Should create pick ticket lines params."""
        params = PickTicketLinesParams(limit=10, offset=5, order_by="lineNumber")
        assert params.order_by == "lineNumber"

    def test_pick_ticket_line_model(self) -> None:
        """Should parse pick ticket line data."""
        data = {
            "lineNumber": 1,
            "pickTicketNo": 1001,
            "itemId": "ABC123",
            "quantityOrdered": 10.0,
            "quantityPicked": 10.0,
        }
        result = PickTicketLine.model_validate(data)
        assert result.line_number == 1
        assert result.quantity_ordered == 10.0

    def test_po_hdr_list_params(self) -> None:
        """Should create PO header list params."""
        params = PoHdrListParams(limit=10, vendor_id="V001", status_cd=1)
        assert params.vendor_id == "V001"

    def test_po_hdr_scan_params(self) -> None:
        """Should create PO header scan params."""
        params = PoHdrScanParams(vendor_id="V001", item_id="ABC123")
        assert params.vendor_id == "V001"

    def test_po_hdr_model(self) -> None:
        """Should parse purchase order header data."""
        data = {
            "poNo": 5001,
            "vendorId": "V001",
            "vendorName": "Test Vendor",
            "totalAmount": 1500.00,
        }
        result = PoHdr.model_validate(data)
        assert result.po_no == 5001
        assert result.vendor_name == "Test Vendor"

    def test_po_hdr_doc_model(self) -> None:
        """Should parse purchase order document data."""
        data = {"poNo": 5001, "vendorId": "V001", "lines": [], "totals": {}}
        result = PoHdrDoc.model_validate(data)
        assert result.po_no == 5001


class TestOrdersClient:
    """Tests for OrdersClient."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://orders.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.orders.health_check()
        assert response.data.site_id == "test-site"

    def test_invoice_hdr_reprint(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should reprint invoice."""
        mock_response = {
            "count": 1,
            "data": {"success": True, "invoiceNo": 123},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://orders.augur-api.com/invoice-hdr/123/reprint",
            json=mock_response,
        )
        response = api.orders.invoice_hdr.reprint(123)
        assert response.data.success is True

    def test_oe_hdr_lookup(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should lookup order headers."""
        mock_response = {
            "count": 1,
            "data": [{"orderNo": 12345, "customerId": 100}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://orders.augur-api.com/oe-hdr/lookup",
            json=mock_response,
        )
        response = api.orders.oe_hdr.lookup()
        assert len(response.data) == 1

    def test_oe_hdr_get_doc(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get order document."""
        mock_response = {
            "count": 1,
            "data": {"orderNo": 12345, "customerName": "Test"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://orders.augur-api.com/oe-hdr/12345/doc",
            json=mock_response,
        )
        response = api.orders.oe_hdr.get_doc(12345)
        assert response.data.order_no == 12345

    def test_oe_hdr_salesrep_list_orders(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list orders for sales rep."""
        mock_response = {
            "count": 1,
            "data": [{"orderNo": 12345, "customerName": "Test"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://orders.augur-api.com/oe-hdr-salesrep/100/oe-hdr",
            json=mock_response,
        )
        response = api.orders.oe_hdr_salesrep.list_orders(100)
        assert len(response.data) == 1

    def test_oe_hdr_salesrep_get_order_doc(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get order document for sales rep."""
        mock_response = {
            "count": 1,
            "data": {"orderNo": 12345, "customerName": "Test"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://orders.augur-api.com/oe-hdr-salesrep/100/oe-hdr/12345/doc",
            json=mock_response,
        )
        response = api.orders.oe_hdr_salesrep.get_order_doc(100, 12345)
        assert response.data.order_no == 12345

    def test_pick_tickets_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list pick tickets."""
        mock_response = {
            "count": 1,
            "data": [{"pickTicketNo": 1001, "orderNo": 12345}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://orders.augur-api.com/pick-tickets",
            json=mock_response,
        )
        response = api.orders.pick_tickets.list()
        assert len(response.data) == 1

    def test_pick_tickets_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get pick ticket by number."""
        mock_response = {
            "count": 1,
            "data": {"pickTicketNo": 1001, "orderNo": 12345},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://orders.augur-api.com/pick-tickets/1001",
            json=mock_response,
        )
        response = api.orders.pick_tickets.get(1001)
        assert response.data.pick_ticket_no == 1001

    def test_pick_tickets_list_lines(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list pick ticket lines."""
        mock_response = {
            "count": 1,
            "data": [{"lineNumber": 1, "pickTicketNo": 1001}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://orders.augur-api.com/pick-tickets/1001/lines",
            json=mock_response,
        )
        response = api.orders.pick_tickets.list_lines(1001)
        assert len(response.data) == 1

    def test_pick_tickets_get_line(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get specific pick ticket line."""
        mock_response = {
            "count": 1,
            "data": {"lineNumber": 1, "pickTicketNo": 1001},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://orders.augur-api.com/pick-tickets/1001/lines/1",
            json=mock_response,
        )
        response = api.orders.pick_tickets.get_line(1001, 1)
        assert response.data.line_number == 1

    def test_po_hdr_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list purchase orders."""
        mock_response = {
            "count": 1,
            "data": [{"poNo": 5001, "vendorId": "V001"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://orders.augur-api.com/po-hdr",
            json=mock_response,
        )
        response = api.orders.po_hdr.list()
        assert len(response.data) == 1

    def test_po_hdr_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get purchase order by number."""
        mock_response = {
            "count": 1,
            "data": {"poNo": 5001, "vendorId": "V001"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://orders.augur-api.com/po-hdr/5001",
            json=mock_response,
        )
        response = api.orders.po_hdr.get(5001)
        assert response.data.po_no == 5001

    def test_po_hdr_get_doc(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get purchase order document."""
        mock_response = {
            "count": 1,
            "data": {"poNo": 5001, "vendorId": "V001", "lines": []},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://orders.augur-api.com/po-hdr/5001/doc",
            json=mock_response,
        )
        response = api.orders.po_hdr.get_doc(5001)
        assert response.data.po_no == 5001

    def test_po_hdr_scan(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should scan for purchase orders."""
        mock_response = {
            "count": 1,
            "data": [{"poNo": 5001, "vendorId": "V001"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://orders.augur-api.com/po-hdr/scan",
            json=mock_response,
            method="POST",
        )
        response = api.orders.po_hdr.scan(PoHdrScanParams(vendor_id="V001"))
        assert len(response.data) == 1

    def test_resource_properties_return_same_instance(self, api: AugurAPI) -> None:
        """Should return same resource instance on multiple accesses."""
        client = api.orders
        assert client.invoice_hdr is client.invoice_hdr
        assert client.oe_hdr is client.oe_hdr
        assert client.oe_hdr_salesrep is client.oe_hdr_salesrep
        assert client.pick_tickets is client.pick_tickets
        assert client.po_hdr is client.po_hdr
