"""Error classes for the Augur API client."""

from __future__ import annotations

from typing import Any


class AugurError(Exception):
    """Base error class for all Augur API errors.

    Attributes:
        message: Human-readable error message.
        code: Error code string (e.g., 'API_ERROR', 'NETWORK_ERROR').
        status_code: HTTP status code if applicable.
        service: The service that raised the error.
        endpoint: The endpoint that raised the error.
        request_id: Optional request ID for debugging.
        validation_errors: Optional list of validation errors.
    """

    def __init__(
        self,
        message: str,
        code: str,
        status_code: int,
        service: str,
        endpoint: str,
        request_id: str | None = None,
        validation_errors: list[dict[str, Any]] | None = None,
    ) -> None:
        """Initialize the error.

        Args:
            message: Human-readable error message.
            code: Error code string.
            status_code: HTTP status code.
            service: The service that raised the error.
            endpoint: The endpoint that raised the error.
            request_id: Optional request ID for debugging.
            validation_errors: Optional list of validation errors.
        """
        super().__init__(message)
        self.message = message
        self.code = code
        self.status_code = status_code
        self.service = service
        self.endpoint = endpoint
        self.request_id = request_id
        self.validation_errors = validation_errors

    def __str__(self) -> str:
        """Return string representation of the error."""
        parts = [f"{self.code}: {self.message}"]
        parts.append(f"(service={self.service}, endpoint={self.endpoint})")
        if self.request_id:
            parts.append(f"[request_id={self.request_id}]")
        return " ".join(parts)


class ValidationError(AugurError):
    """Error raised when request or response validation fails.

    Provides detailed information about which fields failed validation.
    """

    def __init__(
        self,
        message: str,
        service: str,
        endpoint: str,
        validation_errors: list[dict[str, Any]],
    ) -> None:
        """Initialize the validation error.

        Args:
            message: Human-readable error message.
            service: The service that raised the error.
            endpoint: The endpoint that raised the error.
            validation_errors: List of validation error details.
        """
        super().__init__(
            message=message,
            code="VALIDATION_ERROR",
            status_code=400,
            service=service,
            endpoint=endpoint,
            validation_errors=validation_errors,
        )

    def get_formatted_errors(self) -> list[str]:
        """Format validation errors into human-readable messages.

        Returns:
            List of formatted error messages.
        """
        if not self.validation_errors:
            return []

        formatted = []
        for error in self.validation_errors:
            path = ".".join(str(p) for p in error.get("loc", [])) or "root"
            msg = error.get("msg", "Unknown error")
            formatted.append(f"{path}: {msg}")
        return formatted

    def __str__(self) -> str:
        """Return string representation with validation details."""
        base = super().__str__()
        formatted = self.get_formatted_errors()
        if formatted:
            errors_str = "\n  - ".join(formatted)
            return f"{base}\nValidation errors:\n  - {errors_str}"
        return base


class AuthenticationError(AugurError):
    """Error raised when authentication fails (HTTP 401)."""

    def __init__(self, message: str, service: str, endpoint: str) -> None:
        """Initialize the authentication error.

        Args:
            message: Human-readable error message.
            service: The service that raised the error.
            endpoint: The endpoint that raised the error.
        """
        super().__init__(
            message=message,
            code="AUTHENTICATION_ERROR",
            status_code=401,
            service=service,
            endpoint=endpoint,
        )


class NotFoundError(AugurError):
    """Error raised when a resource is not found (HTTP 404)."""

    def __init__(self, message: str, service: str, endpoint: str) -> None:
        """Initialize the not found error.

        Args:
            message: Human-readable error message.
            service: The service that raised the error.
            endpoint: The endpoint that raised the error.
        """
        super().__init__(
            message=message,
            code="NOT_FOUND",
            status_code=404,
            service=service,
            endpoint=endpoint,
        )


class RateLimitError(AugurError):
    """Error raised when rate limit is exceeded (HTTP 429)."""

    def __init__(self, message: str, service: str, endpoint: str) -> None:
        """Initialize the rate limit error.

        Args:
            message: Human-readable error message.
            service: The service that raised the error.
            endpoint: The endpoint that raised the error.
        """
        super().__init__(
            message=message,
            code="RATE_LIMIT_EXCEEDED",
            status_code=429,
            service=service,
            endpoint=endpoint,
        )
