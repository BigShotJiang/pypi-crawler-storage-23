"""Base schemas for Augur API responses."""

from __future__ import annotations

from typing import Any, Generic, TypeVar

from pydantic import BaseModel, ConfigDict
from pydantic.alias_generators import to_camel

T = TypeVar("T")


class CamelCaseModel(BaseModel):
    """Base model that handles camelCase to snake_case conversion.

    The Augur API returns camelCase field names, but Python convention
    uses snake_case. This model automatically handles the conversion.
    """

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
        alias_generator=to_camel,
    )


class BaseResponse(CamelCaseModel, Generic[T]):
    """Base response schema for all Augur API responses.

    All API responses follow this structure, wrapping the actual data
    with metadata about the request and response.

    Attributes:
        count: Number of items in the current response.
        data: The actual response data (type varies by endpoint).
        message: Response message from the API.
        options: Additional options (supports both array and object formats).
        params: Parameters used in the request.
        status: HTTP status code.
        total: Total number of results available.
        total_results: Total results (alias handled by CamelCaseModel).
    """

    count: int
    data: T
    message: str
    options: list[Any] | dict[str, Any]
    params: list[Any] | dict[str, Any]
    status: int
    total: int
    total_results: int


class HealthCheckData(CamelCaseModel):
    """Health check response data.

    Returned by all service /health-check endpoints.

    Attributes:
        site_hash: Hash of the site configuration.
        site_id: Site identifier.
    """

    site_hash: str
    site_id: str


class PingData(BaseModel):
    """Ping response data.

    Simple connectivity check - returns 'pong'.
    """

    model_config = ConfigDict(extra="allow")


class PaginationParams(BaseModel):
    """Common pagination parameters for list endpoints.

    Attributes:
        limit: Maximum number of items to return.
        offset: Number of items to skip.
    """

    model_config = ConfigDict(
        populate_by_name=True,
        alias_generator=to_camel,
    )

    limit: int | None = None
    offset: int | None = None


class EdgeCacheParams(BaseModel):
    """Edge cache duration parameters.

    Supported values for Cloudflare cache rules.

    Attributes:
        edge_cache: Cache duration - sub-hour ('30s', '1m', '5m') or hourly (1-5, 8).
    """

    model_config = ConfigDict(
        populate_by_name=True,
        alias_generator=to_camel,
    )

    edge_cache: str | int | None = None


class BaseGetParams(PaginationParams, EdgeCacheParams):
    """Combined base parameters for GET requests.

    Includes both pagination and edge caching options.
    """
