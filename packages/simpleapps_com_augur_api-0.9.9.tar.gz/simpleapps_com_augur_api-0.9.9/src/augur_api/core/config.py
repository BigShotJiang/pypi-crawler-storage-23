"""Configuration classes for the Augur API client."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class AugurAPIConfig:
    """Configuration for the Augur API client.

    Attributes:
        token: JWT bearer token for authentication.
        site_id: Site identifier for the x-site-id header.
        timeout: Request timeout in seconds. Defaults to 30.0.
        retries: Number of retry attempts for failed requests. Defaults to 3.
        retry_delay: Base delay between retries in seconds. Defaults to 1.0.
    """

    token: str
    site_id: str
    timeout: float = 30.0
    retries: int = 3
    retry_delay: float = 1.0


@dataclass
class AugurContext:
    """Context object containing authentication and site information.

    This provides an alternative way to configure the client, useful for
    framework integration where context is passed between components.

    Attributes:
        site_id: Site identifier.
        jwt: JWT bearer token for authentication (alternative to bearer_token).
        bearer_token: Bearer token for authentication (alternative to jwt).
        parameters: Optional request parameters.
        filters: Optional filter parameters.
        user_id: Optional user identifier.
    """

    site_id: str
    jwt: str | None = None
    bearer_token: str | None = None
    parameters: dict[str, Any] = field(default_factory=dict)
    filters: dict[str, Any] = field(default_factory=dict)
    user_id: str | int | None = None


class ContextCreationError(Exception):
    """Error raised when context creation fails due to invalid or missing data.

    Attributes:
        message: Human-readable error message.
        field: The field that caused the error, if applicable.
    """

    def __init__(self, message: str, field: str | None = None) -> None:
        """Initialize the error.

        Args:
            message: Human-readable error message.
            field: The field that caused the error, if applicable.
        """
        super().__init__(message)
        self.message = message
        self.field = field

    def __str__(self) -> str:
        """Return string representation of the error."""
        if self.field:
            return f"{self.message} (field: {self.field})"
        return self.message
