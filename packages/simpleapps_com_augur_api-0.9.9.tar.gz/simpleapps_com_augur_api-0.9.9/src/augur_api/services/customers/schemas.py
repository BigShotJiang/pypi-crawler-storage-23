"""Schemas for the Customers service."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# Customer
class CustomerListParams(EdgeCacheParams):
    """Parameters for listing customers."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    class5id: str | None = None


class CustomerLookupParams(EdgeCacheParams):
    """Parameters for customer lookup."""

    q: str


class Customer(CamelCaseModel):
    """Customer entity."""

    customer_id: int | None = None
    customer_name: str | None = None
    address1: str | None = None
    address2: str | None = None
    city: str | None = None
    state: str | None = None
    postal_code: str | None = None
    country: str | None = None
    phone: str | None = None
    fax: str | None = None
    email: str | None = None
    web_address: str | None = None
    credit_limit: float | None = None
    terms_id: str | None = None
    salesrep_id: str | None = None
    status_cd: int | None = None
    created_at: str | None = None
    updated_at: str | None = None


class CustomerDoc(CamelCaseModel):
    """Full customer document."""

    customer_id: int | None = None
    customer_name: str | None = None
    contacts: list[Any] | None = None
    ship_tos: list[Any] | None = None
    addresses: list[Any] | None = None


# Address
class AddressParams(EdgeCacheParams):
    """Parameters for address query."""

    limit: int | None = None
    offset: int | None = None


class Address(CamelCaseModel):
    """Address entity."""

    address_id: int | None = None
    address_type: str | None = None
    address1: str | None = None
    address2: str | None = None
    city: str | None = None
    state: str | None = None
    postal_code: str | None = None
    country: str | None = None


# Contact
class ContactListParams(EdgeCacheParams):
    """Parameters for listing contacts."""

    limit: int | None = None
    offset: int | None = None
    q: str | None = None


class Contact(CamelCaseModel):
    """Contact entity."""

    contact_id: int | None = None
    customer_id: int | None = None
    first_name: str | None = None
    last_name: str | None = None
    email: str | None = None
    phone: str | None = None
    title: str | None = None
    department: str | None = None
    is_primary: bool | None = None
    status_cd: int | None = None
    created_at: str | None = None
    updated_at: str | None = None


class ContactCreateParams(BaseModel):
    """Parameters for creating a contact."""

    first_name: str | None = None
    last_name: str | None = None
    email: str | None = None
    phone: str | None = None
    title: str | None = None
    department: str | None = None


class ContactDoc(CamelCaseModel):
    """Full contact document."""

    contact_id: int | None = None
    first_name: str | None = None
    last_name: str | None = None
    customers: list[Any] | None = None
    permissions: list[Any] | None = None


class WebAllowance(CamelCaseModel):
    """Contact web allowance/permissions."""

    contact_id: int | None = None
    can_view_orders: bool | None = None
    can_view_invoices: bool | None = None
    can_view_quotes: bool | None = None
    can_place_orders: bool | None = None


class ContactUd(CamelCaseModel):
    """Contact user-defined data."""

    contact_id: int | None = None
    ud_field1: str | None = None
    ud_field2: str | None = None
    ud_field3: str | None = None


# Ship To
class ShipToListParams(EdgeCacheParams):
    """Parameters for listing ship-to addresses."""

    limit: int | None = None
    offset: int | None = None


class ShipTo(CamelCaseModel):
    """Ship-to address entity."""

    ship_to_id: int | None = None
    customer_id: int | None = None
    ship_to_name: str | None = None
    address1: str | None = None
    address2: str | None = None
    city: str | None = None
    state: str | None = None
    postal_code: str | None = None
    country: str | None = None
    phone: str | None = None
    is_default: bool | None = None


class ShipToCreateParams(BaseModel):
    """Parameters for creating a ship-to address."""

    ship_to_name: str | None = None
    address1: str | None = None
    address2: str | None = None
    city: str | None = None
    state: str | None = None
    postal_code: str | None = None
    country: str | None = None
    phone: str | None = None


# Orders
class OrderListParams(EdgeCacheParams):
    """Parameters for listing orders."""

    limit: int | None = None
    offset: int | None = None
    full_document: bool | None = None
    cancel_flag: str | None = None
    delete_flag: str | None = None


class Order(CamelCaseModel):
    """Order entity."""

    order_no: int | None = None
    customer_id: int | None = None
    order_date: str | None = None
    ship_to_id: int | None = None
    po_no: str | None = None
    total_amount: float | None = None
    status_cd: int | None = None
    created_at: str | None = None


# Invoice
class InvoiceListParams(EdgeCacheParams):
    """Parameters for listing invoices."""

    limit: int | None = None
    offset: int | None = None
    ship_to_id: int | None = None


class Invoice(CamelCaseModel):
    """Invoice entity."""

    invoice_no: int | None = None
    customer_id: int | None = None
    invoice_date: str | None = None
    due_date: str | None = None
    total_amount: float | None = None
    balance_due: float | None = None
    status_cd: int | None = None


# Quote
class QuoteListParams(EdgeCacheParams):
    """Parameters for listing quotes."""

    limit: int | None = None
    offset: int | None = None


class Quote(CamelCaseModel):
    """Quote entity."""

    order_no: int | None = None
    customer_id: int | None = None
    quote_date: str | None = None
    expiration_date: str | None = None
    total_amount: float | None = None
    status_cd: int | None = None


# Purchased Items
class PurchasedItemsParams(EdgeCacheParams):
    """Parameters for listing purchased items."""

    limit: int | None = None
    offset: int | None = None


class PurchasedItem(CamelCaseModel):
    """Purchased item entity."""

    inv_mast_uid: int | None = None
    item_id: str | None = None
    item_desc: str | None = None
    last_purchase_date: str | None = None
    total_quantity: float | None = None
    total_amount: float | None = None
