"""Schemas for the Payments service."""

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict
from pydantic.alias_generators import to_camel

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# Element schemas
class ElementPaymentParams(BaseModel, extra="allow"):
    """Parameters for element payment (passthrough)."""


class ElementPaymentResponse(CamelCaseModel, extra="allow"):
    """Element payment response (passthrough)."""


# Moneris schemas
class PreAuthParams(EdgeCacheParams):
    """Parameters for Moneris pre-authorization."""

    amount: float
    cc_number: str
    exp_date: str
    order_id: str
    test_mode: bool | None = None


class PreAuthCompleteParams(EdgeCacheParams):
    """Parameters for Moneris pre-auth completion."""

    amount: float
    order_id: str
    txn_number: str
    test_mode: bool | None = None


class MonerisData(CamelCaseModel, extra="allow"):
    """Moneris response data (passthrough)."""


# Paytrace schemas
class PaytraceAuthorizationParams(BaseModel):
    """Parameters for Paytrace authorization."""

    model_config = ConfigDict(extra="allow", populate_by_name=True, alias_generator=to_camel)

    amount: float
    credit_card: dict[str, Any]
    billing_address: dict[str, Any] | None = None
    csc: str | None = None
    invoice_id: str | None = None
    test_mode: bool | None = None


class PaytraceCaptureParams(BaseModel):
    """Parameters for Paytrace capture."""

    model_config = ConfigDict(extra="allow", populate_by_name=True, alias_generator=to_camel)

    transaction_id: str
    amount: float | None = None
    test_mode: bool | None = None


class PaytraceRefundParams(BaseModel):
    """Parameters for Paytrace refund."""

    model_config = ConfigDict(extra="allow", populate_by_name=True, alias_generator=to_camel)

    transaction_id: str
    amount: float | None = None
    test_mode: bool | None = None


class PaytraceSaleParams(BaseModel):
    """Parameters for Paytrace sale."""

    model_config = ConfigDict(extra="allow", populate_by_name=True, alias_generator=to_camel)

    amount: float
    credit_card: dict[str, Any]
    billing_address: dict[str, Any] | None = None
    csc: str | None = None
    invoice_id: str | None = None
    test_mode: bool | None = None


class PaytraceVoidParams(BaseModel):
    """Parameters for Paytrace void."""

    model_config = ConfigDict(extra="allow", populate_by_name=True, alias_generator=to_camel)

    transaction_id: str
    test_mode: bool | None = None


class PaytraceResponse(CamelCaseModel, extra="allow"):
    """Paytrace response (passthrough)."""


# Unified schemas
ApiMode = Literal["dev", "live"]


class TransactionSetupParams(EdgeCacheParams):
    """Parameters for transaction setup."""

    customer_id: str
    mode: ApiMode | None = None


class TransactionSetupData(CamelCaseModel, extra="allow"):
    """Transaction setup response data."""

    transaction_setup_id: str | None = None


class AccountQueryParams(EdgeCacheParams):
    """Parameters for account query."""

    customer_id: str
    transaction_setup_id: str
    mode: ApiMode | None = None


class AccountQueryData(CamelCaseModel, extra="allow"):
    """Account query response data."""

    payment_account_id: str | None = None


class BillingUpdateParams(EdgeCacheParams):
    """Parameters for billing update."""

    transaction_setup_id: str
    address1: str
    city: str
    state: str
    zip: str
    address2: str | None = None
    mode: ApiMode | None = None


class CardInfoParams(EdgeCacheParams):
    """Parameters for card info."""

    transaction_setup_id: str
    mode: ApiMode | None = None


class CardInfoData(CamelCaseModel, extra="allow"):
    """Card info response data (passthrough)."""


class SurchargeParams(EdgeCacheParams):
    """Parameters for surcharge calculation."""

    customer_id: str
    payment_account_id: str
    amount: str
    from_state: str
    to_state: str
    country: str
    mode: ApiMode | None = None


class SurchargeData(CamelCaseModel, extra="allow"):
    """Surcharge response data (passthrough)."""


class ValidateParams(EdgeCacheParams):
    """Parameters for transaction validation."""

    customer_id: str
    transaction_setup_id: str
    mode: ApiMode | None = None
