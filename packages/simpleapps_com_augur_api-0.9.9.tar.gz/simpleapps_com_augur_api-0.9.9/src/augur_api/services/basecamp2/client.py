"""Basecamp2 service client for project management."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, List

from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.basecamp2.schemas import (
    Comment,
    CommentListParams,
    Event,
    EventListParams,
    Metric,
    MetricsListParams,
    Person,
    PersonListParams,
    Project,
    ProjectListParams,
    Session,
    SessionListParams,
    SessionUpdateParams,
    Todo,
    Todolist,
    TodolistListParams,
    TodoListParams,
    TodosSummary,
    TodosSummaryListParams,
)
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient


class ProjectsResource(BaseResource):
    """Resource for /projects endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/projects")

    def list(self, params: ProjectListParams | None = None) -> BaseResponse[List[Project]]:
        """List projects.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of Project items.
        """
        response = self._get(params=params)
        return BaseResponse[List[Project]].model_validate(response)

    def get(self, projects_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Project]:
        """Get project by UID.

        Args:
            projects_uid: The project UID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the Project.
        """
        response = self._get(f"/{projects_uid}", params=options)
        return BaseResponse[Project].model_validate(response)

    def metrics(self, project_id: int, options: EdgeCacheParams | None = None) -> BaseResponse[Metric]:
        """Get metrics for a project.

        Args:
            project_id: The project ID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the project Metric.
        """
        response = self._get(f"/{project_id}/metrics", params=options)
        return BaseResponse[Metric].model_validate(response)

    def todolists(self, project_id: int, options: EdgeCacheParams | None = None) -> BaseResponse[List[Todolist]]:
        """Get todolists for a project.

        Args:
            project_id: The project ID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing a list of Todolist items.
        """
        response = self._get(f"/{project_id}/todolists", params=options)
        return BaseResponse[List[Todolist]].model_validate(response)

    def todolist_todos(self, project_id: int, todolist_id: int, options: EdgeCacheParams | None = None) -> BaseResponse[List[Todo]]:
        """Get todos for a specific todolist in a project.

        Args:
            project_id: The project ID.
            todolist_id: The todolist ID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing a list of Todo items.
        """
        response = self._get(f"/{project_id}/todolists/{todolist_id}/todos", params=options)
        return BaseResponse[List[Todo]].model_validate(response)


class TodosResource(BaseResource):
    """Resource for /todos endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/todos")

    def list(self, params: TodoListParams | None = None) -> BaseResponse[List[Todo]]:
        """List todos.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of Todo items.
        """
        response = self._get(params=params)
        return BaseResponse[List[Todo]].model_validate(response)

    def get(self, todos_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Todo]:
        """Get todo by UID.

        Args:
            todos_uid: The todo UID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the Todo.
        """
        response = self._get(f"/{todos_uid}", params=options)
        return BaseResponse[Todo].model_validate(response)

    def create(self, data: Any) -> BaseResponse[Todo]:
        """Create a new todo.

        Args:
            data: The todo data to create.

        Returns:
            BaseResponse containing the created Todo.
        """
        response = self._post(data=data)
        return BaseResponse[Todo].model_validate(response)

    def update(self, todos_uid: int, data: Any) -> BaseResponse[Todo]:
        """Update a todo.

        Args:
            todos_uid: The todo UID.
            data: The todo data to update.

        Returns:
            BaseResponse containing the updated Todo.
        """
        response = self._put(f"/{todos_uid}", data=data)
        return BaseResponse[Todo].model_validate(response)

    def delete(self, todos_uid: int) -> BaseResponse[bool]:
        """Delete a todo.

        Args:
            todos_uid: The todo UID.

        Returns:
            BaseResponse containing deletion success status.
        """
        response = self._delete(f"/{todos_uid}")
        return BaseResponse[bool].model_validate(response)

    def event(self, todo_id: int, event_num: int, options: EdgeCacheParams | None = None) -> BaseResponse[Event]:
        """Get a specific event for a todo.

        Args:
            todo_id: The todo ID.
            event_num: The event number.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the Event.
        """
        response = self._get(f"/{todo_id}/events/{event_num}", params=options)
        return BaseResponse[Event].model_validate(response)

    def metrics(self, todo_id: int, options: EdgeCacheParams | None = None) -> BaseResponse[Metric]:
        """Get metrics for a todo.

        Args:
            todo_id: The todo ID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the todo Metric.
        """
        response = self._get(f"/{todo_id}/metrics", params=options)
        return BaseResponse[Metric].model_validate(response)

    def list_sessions(
        self, todo_id: int, params: SessionListParams | None = None
    ) -> BaseResponse[List[Session]]:
        """List sessions for a todo.

        Args:
            todo_id: The todo ID.
            params: Optional query parameters.

        Returns:
            BaseResponse containing a list of Session items.
        """
        response = self._get(f"/{todo_id}/sessions", params=params)
        return BaseResponse[List[Session]].model_validate(response)

    def create_session(self, todo_id: int, data: Any) -> BaseResponse[Session]:
        """Create a session for a todo.

        Args:
            todo_id: The todo ID.
            data: Session creation data.

        Returns:
            BaseResponse containing the created Session.
        """
        response = self._post(f"/{todo_id}/sessions", data=data)
        return BaseResponse[Session].model_validate(response)

    def get_session(self, todo_id: int, session_id: int, options: EdgeCacheParams | None = None) -> BaseResponse[Session]:
        """Get a specific session for a todo.

        Args:
            todo_id: The todo ID.
            session_id: The session ID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the Session.
        """
        response = self._get(f"/{todo_id}/sessions/{session_id}", params=options)
        return BaseResponse[Session].model_validate(response)

    def update_session(
        self, todo_id: int, session_id: int, data: SessionUpdateParams
    ) -> BaseResponse[Session]:
        """Update a session for a todo.

        Args:
            todo_id: The todo ID.
            session_id: The session ID.
            data: Session update data.

        Returns:
            BaseResponse containing the updated Session.
        """
        response = self._put(f"/{todo_id}/sessions/{session_id}", data=data)
        return BaseResponse[Session].model_validate(response)

    def delete_session(self, todo_id: int, session_id: int) -> BaseResponse[bool]:
        """Delete a session for a todo.

        Args:
            todo_id: The todo ID.
            session_id: The session ID.

        Returns:
            BaseResponse containing deletion success status.
        """
        response = self._delete(f"/{todo_id}/sessions/{session_id}")
        return BaseResponse[bool].model_validate(response)


class PeopleResource(BaseResource):
    """Resource for /people endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/people")

    def list(self, params: PersonListParams | None = None) -> BaseResponse[List[Person]]:
        """List people.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of Person items.
        """
        response = self._get(params=params)
        return BaseResponse[List[Person]].model_validate(response)

    def get(self, people_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Person]:
        """Get person by UID.

        Args:
            people_uid: The person UID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the Person.
        """
        response = self._get(f"/{people_uid}", params=options)
        return BaseResponse[Person].model_validate(response)

    def metrics(self, person_id: int, options: EdgeCacheParams | None = None) -> BaseResponse[Metric]:
        """Get metrics for a person.

        Args:
            person_id: The person ID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the person Metric.
        """
        response = self._get(f"/{person_id}/metrics", params=options)
        return BaseResponse[Metric].model_validate(response)

    def project_todos(self, person_id: int, project_id: int, options: EdgeCacheParams | None = None) -> BaseResponse[List[Todo]]:
        """Get todos for a person in a specific project.

        Args:
            person_id: The person ID.
            project_id: The project ID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing a list of Todo items.
        """
        response = self._get(f"/{person_id}/projects/{project_id}/todos", params=options)
        return BaseResponse[List[Todo]].model_validate(response)


class CommentsResource(BaseResource):
    """Resource for /comments endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/comments")

    def list(self, params: CommentListParams | None = None) -> BaseResponse[List[Comment]]:
        """List comments.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of Comment items.
        """
        response = self._get(params=params)
        return BaseResponse[List[Comment]].model_validate(response)

    def get(self, comments_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Comment]:
        """Get comment by UID.

        Args:
            comments_uid: The comment UID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the Comment.
        """
        response = self._get(f"/{comments_uid}", params=options)
        return BaseResponse[Comment].model_validate(response)

    def create(self, data: Any) -> BaseResponse[Comment]:
        """Create a new comment.

        Args:
            data: The comment data to create.

        Returns:
            BaseResponse containing the created Comment.
        """
        response = self._post(data=data)
        return BaseResponse[Comment].model_validate(response)


class EventsResource(BaseResource):
    """Resource for /events endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/events")

    def list(self, params: EventListParams | None = None) -> BaseResponse[List[Event]]:
        """List events.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of Event items.
        """
        response = self._get(params=params)
        return BaseResponse[List[Event]].model_validate(response)


class MetricsResource(BaseResource):
    """Resource for /metrics endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/metrics")

    def list(self, params: MetricsListParams | None = None) -> BaseResponse[List[Metric]]:
        """List metrics.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of Metric items.
        """
        response = self._get(params=params)
        return BaseResponse[List[Metric]].model_validate(response)


class TodolistsResource(BaseResource):
    """Resource for /todolists endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/todolists")

    def list(self, params: TodolistListParams | None = None) -> BaseResponse[List[Todolist]]:
        """List todolists.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of Todolist items.
        """
        response = self._get(params=params)
        return BaseResponse[List[Todolist]].model_validate(response)

    def get(self, todolists_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Todolist]:
        """Get todolist by UID.

        Args:
            todolists_uid: The todolist UID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the Todolist.
        """
        response = self._get(f"/{todolists_uid}", params=options)
        return BaseResponse[Todolist].model_validate(response)


class TodosSummaryResource(BaseResource):
    """Resource for /todos-summary endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/todos-summary")

    def list(
        self, params: TodosSummaryListParams | None = None
    ) -> BaseResponse[List[TodosSummary]]:
        """List todos summary.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of TodosSummary items.
        """
        response = self._get(params=params)
        return BaseResponse[List[TodosSummary]].model_validate(response)

    def get(self, todos_summary_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[TodosSummary]:
        """Get todos summary by UID.

        Args:
            todos_summary_uid: The todos summary UID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the TodosSummary.
        """
        response = self._get(f"/{todos_summary_uid}", params=options)
        return BaseResponse[TodosSummary].model_validate(response)


class Basecamp2Client(BaseServiceClient):
    """Client for the Basecamp2 service.

    Provides access to Basecamp2 project management endpoints including:
    - Health check (health_check)
    - Projects (projects)
    - Todos (todos)
    - People (people)
    - Comments (comments)
    - Events (events)
    - Metrics (metrics)
    - Todolists (todolists)
    - Todos Summary (todos_summary)

    Example:
        >>> from augur_api import AugurAPI
        >>> api = AugurAPI(token="...", site_id="...")
        >>> projects = api.basecamp2.projects.list()
        >>> for project in projects.data:
        ...     print(project.name)
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the Basecamp2 client.

        Args:
            http_client: HTTP client for making requests.
        """
        super().__init__(http_client)
        self._projects: ProjectsResource | None = None
        self._todos: TodosResource | None = None
        self._people: PeopleResource | None = None
        self._comments: CommentsResource | None = None
        self._events: EventsResource | None = None
        self._metrics: MetricsResource | None = None
        self._todolists: TodolistsResource | None = None
        self._todos_summary: TodosSummaryResource | None = None

    @property
    def projects(self) -> ProjectsResource:
        """Access projects endpoints."""
        if self._projects is None:
            self._projects = ProjectsResource(self._http)
        return self._projects

    @property
    def todos(self) -> TodosResource:
        """Access todos endpoints."""
        if self._todos is None:
            self._todos = TodosResource(self._http)
        return self._todos

    @property
    def people(self) -> PeopleResource:
        """Access people endpoints."""
        if self._people is None:
            self._people = PeopleResource(self._http)
        return self._people

    @property
    def comments(self) -> CommentsResource:
        """Access comments endpoints."""
        if self._comments is None:
            self._comments = CommentsResource(self._http)
        return self._comments

    @property
    def events(self) -> EventsResource:
        """Access events endpoints."""
        if self._events is None:
            self._events = EventsResource(self._http)
        return self._events

    @property
    def metrics(self) -> MetricsResource:
        """Access metrics endpoints."""
        if self._metrics is None:
            self._metrics = MetricsResource(self._http)
        return self._metrics

    @property
    def todolists(self) -> TodolistsResource:
        """Access todolists endpoints."""
        if self._todolists is None:
            self._todolists = TodolistsResource(self._http)
        return self._todolists

    @property
    def todos_summary(self) -> TodosSummaryResource:
        """Access todos summary endpoints."""
        if self._todos_summary is None:
            self._todos_summary = TodosSummaryResource(self._http)
        return self._todos_summary
