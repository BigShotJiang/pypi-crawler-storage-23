"""Schemas for the VMI (Vendor Managed Inventory) service."""

from pydantic import BaseModel

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# Warehouse
class WarehouseListParams(EdgeCacheParams):
    """Parameters for listing warehouses."""

    limit: int | None = None
    offset: int | None = None
    customer_id: int | None = None
    status_cd: int | None = None
    order_by: str | None = None
    users_id: int | None = None


class Warehouse(CamelCaseModel, extra="allow"):
    """Warehouse entity (passthrough)."""

    warehouse_uid: int | None = None


class WarehouseCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a warehouse (passthrough)."""


class WarehouseUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a warehouse (passthrough)."""


class WarehouseEnableParams(BaseModel, extra="allow"):
    """Parameters for enabling/disabling a warehouse."""

    status_cd: int | None = None


# Warehouse nested resources
class InventoryAvailabilityParams(EdgeCacheParams):
    """Parameters for inventory availability search."""

    q: str
    limit: int | None = None
    offset: int | None = None


class InventoryAvailability(CamelCaseModel, extra="allow"):
    """Inventory availability item (passthrough)."""

    products_uid: int | None = None


class InventoryAdjustParams(BaseModel, extra="allow"):
    """Parameters for adjusting inventory (passthrough)."""


class InventoryReceiveParams(BaseModel, extra="allow"):
    """Parameters for receiving inventory (passthrough)."""


class ReplenishmentParams(EdgeCacheParams):
    """Parameters for replenishment info."""

    distributors_uid: int | None = None


class ReplenishmentInfo(CamelCaseModel, extra="allow"):
    """Replenishment info (passthrough)."""


class ReplenishParams(BaseModel, extra="allow"):
    """Parameters for executing replenishment (passthrough)."""


class TransferParams(BaseModel, extra="allow"):
    """Parameters for transferring inventory (passthrough)."""


class UsageParams(BaseModel, extra="allow"):
    """Parameters for recording usage (passthrough)."""


# Warehouse Users
class WarehouseUserListParams(EdgeCacheParams):
    """Parameters for listing warehouse users."""

    limit: int | None = None
    offset: int | None = None
    status_cd: int | None = None
    status_cd_list: str | None = None


class WarehouseUser(CamelCaseModel, extra="allow"):
    """Warehouse user assignment (passthrough)."""

    warehouse_x_users_uid: int | None = None


class WarehouseUserCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a warehouse user (passthrough)."""


class WarehouseUserCreateQueryParams(EdgeCacheParams):
    """Query parameters for creating a warehouse user."""

    make_primary_user: str | None = None


class WarehouseUserUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a warehouse user (passthrough)."""


# Distributors
class DistributorListParams(EdgeCacheParams):
    """Parameters for listing distributors."""

    limit: int | None = None
    offset: int | None = None
    customer_id: int | None = None
    status_cd: int | None = None


class Distributor(CamelCaseModel, extra="allow"):
    """Distributor entity (passthrough)."""

    distributors_uid: int | None = None


class DistributorCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a distributor (passthrough)."""


class DistributorUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a distributor (passthrough)."""


class DistributorEnableParams(BaseModel, extra="allow"):
    """Parameters for enabling/disabling a distributor."""

    status_cd: int | None = None


# Products
class ProductListParams(EdgeCacheParams):
    """Parameters for listing products."""

    limit: int | None = None
    offset: int | None = None
    customer_id: int | None = None
    distributors_uid: int | None = None
    status_cd: int | None = None


class Product(CamelCaseModel, extra="allow"):
    """VMI product entity (passthrough)."""

    products_uid: int | None = None


class ProductCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a product (passthrough)."""


class ProductUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a product (passthrough)."""


class ProductEnableParams(BaseModel, extra="allow"):
    """Parameters for enabling/disabling a product."""

    status_cd: int | None = None


class ProductFindParams(EdgeCacheParams):
    """Parameters for finding products."""

    customer_id: int
    prefix: str | None = None


class ProductFindItem(CamelCaseModel, extra="allow"):
    """Product find result item (passthrough)."""

    item_id: str | None = None
    item_type: str | None = None


# Inv Profile Hdr
class InvProfileHdrListParams(EdgeCacheParams):
    """Parameters for listing inventory profile headers."""

    limit: int | None = None
    offset: int | None = None
    customer_id: int | None = None


class InvProfileHdr(CamelCaseModel, extra="allow"):
    """Inventory profile header (passthrough)."""

    inv_profile_hdr_uid: int | None = None


class InvProfileHdrCreateParams(BaseModel, extra="allow"):
    """Parameters for creating an inventory profile header (passthrough)."""


class InvProfileHdrUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating an inventory profile header (passthrough)."""


# Inv Profile Line
class InvProfileLineListParams(EdgeCacheParams):
    """Parameters for listing inventory profile lines."""

    limit: int | None = None
    offset: int | None = None


class InvProfileLine(CamelCaseModel, extra="allow"):
    """Inventory profile line (passthrough)."""

    inv_profile_line_uid: int | None = None


class InvProfileLineCreateItem(BaseModel, extra="allow"):
    """Single inventory profile line item for bulk creation."""

    inv_profile_line_type: str
    inv_mast_uid: int


# Keep alias for backwards compatibility
InvProfileLineCreateParams = InvProfileLineCreateItem


class InvProfileLineUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating an inventory profile line (passthrough)."""


# Restock Hdr
class RestockHdrListParams(EdgeCacheParams):
    """Parameters for listing restock headers."""

    limit: int | None = None
    offset: int | None = None
    warehouse_uid: int | None = None
    distributors_uid: int | None = None


class RestockHdr(CamelCaseModel, extra="allow"):
    """Restock header (passthrough)."""

    restock_hdr_uid: int | None = None


class RestockHdrCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a restock header (passthrough)."""


class RestockHdrUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a restock header (passthrough)."""


# Sections
class SectionListParams(EdgeCacheParams):
    """Parameters for listing sections."""

    limit: int | None = None
    offset: int | None = None
    customer_id: int | None = None
    status_cd: int | None = None


class Section(CamelCaseModel, extra="allow"):
    """Section entity (passthrough)."""

    sections_uid: int | None = None


class SectionCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a section (passthrough)."""


class SectionUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a section (passthrough)."""


class SectionEnableParams(BaseModel, extra="allow"):
    """Parameters for enabling/disabling a section."""

    status_cd: int | None = None
