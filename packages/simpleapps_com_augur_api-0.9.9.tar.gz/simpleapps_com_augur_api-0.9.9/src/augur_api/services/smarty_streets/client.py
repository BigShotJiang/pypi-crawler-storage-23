"""Smarty Streets service client for address validation."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
from augur_api.core.schemas import BaseResponse
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource
from augur_api.services.smarty_streets.schemas import (
    UsLookupData,
    UsLookupParams,
)


class UsLookupResource(BaseResource):
    """Resource for /us/lookup endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/us/lookup")

    def get(self, params: UsLookupParams | None = None) -> BaseResponse[UsLookupData]:
        """Lookup and validate a US address.

        Args:
            params: Address lookup parameters.

        Returns:
            BaseResponse containing validated address candidates.
        """
        response = self._get(params=params)
        return BaseResponse[UsLookupData].model_validate(response)


class UsResource:
    """Namespace for US address endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the US resource namespace."""
        self._lookup = UsLookupResource(http)

    @property
    def lookup(self) -> UsLookupResource:
        """Access lookup endpoints."""
        return self._lookup


class SmartyStreetsClient(BaseServiceClient):
    """Client for the Smarty Streets service.

    Provides access to address validation endpoints including:
    - Health check (health_check)
    - US address lookup (us.lookup)

    Example:
        >>> from augur_api import AugurAPI
        >>> api = AugurAPI(token="...", site_id="...")
        >>> result = api.smarty_streets.us.lookup.get(
        ...     UsLookupParams(address1="123 Main St", city="Anytown", state="CA")
        ... )
        >>> for candidate in result.data.candidates or []:
        ...     print(candidate)
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the Smarty Streets client.

        Args:
            http_client: HTTP client for making requests.
        """
        super().__init__(http_client)
        self._us: UsResource | None = None

    @property
    def us(self) -> UsResource:
        """Access US address validation endpoints."""
        if self._us is None:
            self._us = UsResource(self._http)
        return self._us
