"""Schemas for the Smarty Streets service."""

from __future__ import annotations

from typing import Any

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# US Lookup
class UsLookupParams(EdgeCacheParams):
    """Parameters for US address lookup."""

    address1: str | None = None
    address2: str | None = None
    city: str | None = None
    state: str | None = None
    postal_code: str | None = None


class UsLookupData(CamelCaseModel, extra="allow"):
    """US address lookup result data (passthrough for API flexibility)."""

    candidates: list[dict[str, Any]] | None = None
