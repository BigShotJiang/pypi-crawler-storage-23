"""Slack service client for Slack integration."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource
from augur_api.services.slack.schemas import (
    WebHookMessage,
    WebHookResponse,
)


class WebHookResource(BaseResource):
    """Resource for /web-hook endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/web-hook")

    def send(self, data: WebHookMessage) -> BaseResponse[WebHookResponse]:
        """Send a message via web hook.

        Args:
            data: The message to send.

        Returns:
            BaseResponse containing the webhook response.
        """
        response = self._post(data=data)
        return BaseResponse[WebHookResponse].model_validate(response)

    def refresh(self, options: EdgeCacheParams | None = None) -> BaseResponse[bool]:
        """Refresh web hook configuration.

        Args:
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing refresh status.
        """
        response = self._get("/refresh", params=options)
        return BaseResponse[bool].model_validate(response)


class SlackClient(BaseServiceClient):
    """Client for the Slack service.

    Provides access to Slack integration endpoints including:
    - Health check (health_check)
    - Web hook messaging (web_hook)

    Example:
        >>> from augur_api import AugurAPI
        >>> api = AugurAPI(token="...", site_id="...")
        >>> api.slack.web_hook.send(WebHookMessage(text="Hello!"))
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the Slack client.

        Args:
            http_client: HTTP client for making requests.
        """
        super().__init__(http_client)
        self._web_hook: WebHookResource | None = None

    @property
    def web_hook(self) -> WebHookResource:
        """Access web hook endpoints."""
        if self._web_hook is None:
            self._web_hook = WebHookResource(self._http)
        return self._web_hook
