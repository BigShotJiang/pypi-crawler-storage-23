"""Gregorovich service client for AI/LLM operations."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.gregorovich.schemas import (
    ChatGptAskParams,
    ChatGptAskResult,
    DocumentsResult,
    OllamaGenerateResult,
)
from augur_api.services.resource import BaseResource


class ChatGptAskResource(BaseResource):
    """Resource for /chat-gpt/ask endpoint."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/chat-gpt/ask")

    def get(self, params: ChatGptAskParams) -> BaseResponse[ChatGptAskResult]:
        """Ask ChatGPT a question.

        Args:
            params: ChatGPT ask parameters including the question.

        Returns:
            BaseResponse containing ChatGPT ask result.
        """
        response = self._get(params=params)
        return BaseResponse[ChatGptAskResult].model_validate(response)


class ChatGptResource:
    """Namespace for ChatGPT endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the ChatGPT resource namespace."""
        self._ask = ChatGptAskResource(http)

    @property
    def ask(self) -> ChatGptAskResource:
        """Access ask endpoint."""
        return self._ask


class DocumentsResource(BaseResource):
    """Resource for /documents endpoint."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/documents")

    def list(self, options: EdgeCacheParams | None = None) -> BaseResponse[list[DocumentsResult]]:
        """List documents.

        Args:
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing list of documents.
        """
        response = self._get(params=options)
        return BaseResponse[list[DocumentsResult]].model_validate(response)


class OllamaGenerateResource(BaseResource):
    """Resource for /ollama/generate endpoint."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/ollama/generate")

    def create(self, data: Any) -> BaseResponse[OllamaGenerateResult]:
        """Generate with Ollama.

        Args:
            data: Ollama generate parameters.

        Returns:
            BaseResponse containing Ollama generate result.
        """
        response = self._post(data=data)
        return BaseResponse[OllamaGenerateResult].model_validate(response)


class OllamaResource:
    """Namespace for Ollama endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the Ollama resource namespace."""
        self._generate = OllamaGenerateResource(http)

    @property
    def generate(self) -> OllamaGenerateResource:
        """Access generate endpoint."""
        return self._generate


class GregorovichClient(BaseServiceClient):
    """Client for the Gregorovich AI service.

    Provides access to AI/LLM operation endpoints including:
    - Health check (health_check)
    - ChatGPT ask (chat_gpt.ask)
    - Documents (documents)
    - Ollama generate (ollama.generate)

    Example:
        >>> from augur_api import AugurAPI
        >>> api = AugurAPI(token="...", site_id="...")
        >>> response = api.gregorovich.chat_gpt.ask.get(
        ...     ChatGptAskParams(question="What is AI?")
        ... )
        >>> print(response.data)
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the Gregorovich client.

        Args:
            http_client: HTTP client for making requests.
        """
        super().__init__(http_client)
        self._chat_gpt: ChatGptResource | None = None
        self._documents: DocumentsResource | None = None
        self._ollama: OllamaResource | None = None

    @property
    def chat_gpt(self) -> ChatGptResource:
        """Access ChatGPT endpoints."""
        if self._chat_gpt is None:
            self._chat_gpt = ChatGptResource(self._http)
        return self._chat_gpt

    @property
    def documents(self) -> DocumentsResource:
        """Access documents endpoints."""
        if self._documents is None:
            self._documents = DocumentsResource(self._http)
        return self._documents

    @property
    def ollama(self) -> OllamaResource:
        """Access Ollama endpoints."""
        if self._ollama is None:
            self._ollama = OllamaResource(self._http)
        return self._ollama
