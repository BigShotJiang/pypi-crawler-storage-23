"""AGR Info service exports."""

from augur_api.services.agr_info.client import (
    AgrInfoClient,
    AkashaResource,
    JoomlaResource,
    MicroservicesResource,
    OllamaResource,
    RubricsResource,
)
from augur_api.services.agr_info.schemas import (
    AkashaGenerateParams,
    AkashaGenerateResponse,
    JoomlaGenerateParams,
    JoomlaGenerateResponse,
    Microservice,
    MicroserviceCreateParams,
    MicroservicesListParams,
    MicroserviceUpdateParams,
    OllamaTag,
    Rubric,
    RubricCreateParams,
    RubricsListParams,
    RubricUpdateParams,
)

__all__ = [
    "AgrInfoClient",
    "AkashaGenerateParams",
    "AkashaGenerateResponse",
    "AkashaResource",
    "JoomlaGenerateParams",
    "JoomlaGenerateResponse",
    "JoomlaResource",
    "Microservice",
    "MicroserviceCreateParams",
    "MicroservicesListParams",
    "MicroservicesResource",
    "MicroserviceUpdateParams",
    "OllamaResource",
    "OllamaTag",
    "Rubric",
    "RubricCreateParams",
    "RubricsListParams",
    "RubricsResource",
    "RubricUpdateParams",
]
