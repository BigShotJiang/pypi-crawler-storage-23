"""Schemas for the AGR Info service."""

from pydantic import BaseModel

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


# Context
class ContextGetParams(EdgeCacheParams):
    """Parameters for getting context."""


class ContextResponse(CamelCaseModel):
    """Context response data."""


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# Microservices
class MicroservicesListParams(EdgeCacheParams):
    """Parameters for listing microservices."""

    limit: int | None = None
    offset: int | None = None
    status_cd: int | None = None


class Microservice(CamelCaseModel):
    """Microservice entity."""

    microservices_uid: int | None = None
    name: str | None = None
    status_cd: int | None = None
    created_at: str | None = None
    updated_at: str | None = None


class MicroserviceCreateParams(BaseModel):
    """Parameters for creating a microservice."""

    name: str | None = None
    status_cd: int | None = None


class MicroserviceUpdateParams(BaseModel):
    """Parameters for updating a microservice."""

    name: str | None = None
    status_cd: int | None = None


# Rubrics
class RubricsListParams(EdgeCacheParams):
    """Parameters for listing rubrics."""

    limit: int | None = None
    offset: int | None = None


class Rubric(CamelCaseModel):
    """Rubric entity."""

    rubrics_uid: int | None = None
    name: str | None = None
    description: str | None = None
    created_at: str | None = None
    updated_at: str | None = None


class RubricCreateParams(BaseModel):
    """Parameters for creating a rubric."""

    name: str | None = None
    description: str | None = None


class RubricUpdateParams(BaseModel):
    """Parameters for updating a rubric."""

    name: str | None = None
    description: str | None = None


# Akasha
class AkashaGenerateParams(BaseModel):
    """Parameters for Akasha generation."""

    prompt: str | None = None


class AkashaGenerateResponse(CamelCaseModel):
    """Akasha generation response."""

    result: str | None = None


# Joomla Generate
class JoomlaGenerateParams(BaseModel):
    """Parameters for Joomla generation."""

    prompt: str | None = None


class JoomlaGenerateResponse(CamelCaseModel):
    """Joomla generation response."""

    result: str | None = None


# Ollama
class OllamaTag(CamelCaseModel):
    """Ollama tag/model entity."""

    name: str | None = None
    model: str | None = None
    modified_at: str | None = None
    size: int | None = None
