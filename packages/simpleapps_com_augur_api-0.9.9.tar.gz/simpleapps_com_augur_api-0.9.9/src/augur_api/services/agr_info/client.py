"""AGR Info service client for AI content generation and infrastructure."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.agr_info.schemas import (
    AkashaGenerateParams,
    AkashaGenerateResponse,
    ContextGetParams,
    ContextResponse,
    JoomlaGenerateParams,
    JoomlaGenerateResponse,
    Microservice,
    MicroservicesListParams,
    OllamaTag,
    Rubric,
    RubricsListParams,
)
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient


class ContextResource(BaseResource):
    """Resource for /context endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/context")

    def get(
        self, site_id: str, params: ContextGetParams | None = None
    ) -> BaseResponse[ContextResponse]:
        """Get context for a site.

        Args:
            site_id: The target site ID to get context for.
            params: Optional query parameters.

        Returns:
            BaseResponse containing the context data.
        """
        response = self._get(f"/{site_id}", params=params)
        return BaseResponse[ContextResponse].model_validate(response)


class MicroservicesResource(BaseResource):
    """Resource for /microservices endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/microservices")

    def list(
        self, params: MicroservicesListParams | None = None
    ) -> BaseResponse[list[Microservice]]:
        """List microservices.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of Microservice items.
        """
        response = self._get(params=params)
        return BaseResponse[list[Microservice]].model_validate(response)

    def get(self, microservices_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Microservice]:
        """Get microservice by UID.

        Args:
            microservices_uid: The microservice UID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the Microservice.
        """
        response = self._get(f"/{microservices_uid}", params=options)
        return BaseResponse[Microservice].model_validate(response)

    def create(self, data: Any) -> BaseResponse[Microservice]:
        """Create a new microservice.

        Args:
            data: The microservice data to create.

        Returns:
            BaseResponse containing the created Microservice.
        """
        response = self._post(data=data)
        return BaseResponse[Microservice].model_validate(response)

    def update(self, microservices_uid: int, data: Any) -> BaseResponse[Microservice]:
        """Update a microservice.

        Args:
            microservices_uid: The microservice UID.
            data: The microservice data to update.

        Returns:
            BaseResponse containing the updated Microservice.
        """
        response = self._put(f"/{microservices_uid}", data=data)
        return BaseResponse[Microservice].model_validate(response)

    def delete(self, microservices_uid: int) -> BaseResponse[bool]:
        """Delete a microservice.

        Args:
            microservices_uid: The microservice UID.

        Returns:
            BaseResponse containing deletion success status.
        """
        response = self._delete(f"/{microservices_uid}")
        return BaseResponse[bool].model_validate(response)


class RubricsResource(BaseResource):
    """Resource for /rubrics endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/rubrics")

    def list(self, params: RubricsListParams | None = None) -> BaseResponse[list[Rubric]]:
        """List rubrics.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of Rubric items.
        """
        response = self._get(params=params)
        return BaseResponse[list[Rubric]].model_validate(response)

    def get(self, rubrics_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Rubric]:
        """Get rubric by UID.

        Args:
            rubrics_uid: The rubric UID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the Rubric.
        """
        response = self._get(f"/{rubrics_uid}", params=options)
        return BaseResponse[Rubric].model_validate(response)

    def create(self, data: Any) -> BaseResponse[Rubric]:
        """Create a new rubric.

        Args:
            data: The rubric data to create.

        Returns:
            BaseResponse containing the created Rubric.
        """
        response = self._post(data=data)
        return BaseResponse[Rubric].model_validate(response)

    def update(self, rubrics_uid: int, data: Any) -> BaseResponse[Rubric]:
        """Update a rubric.

        Args:
            rubrics_uid: The rubric UID.
            data: The rubric data to update.

        Returns:
            BaseResponse containing the updated Rubric.
        """
        response = self._put(f"/{rubrics_uid}", data=data)
        return BaseResponse[Rubric].model_validate(response)

    def delete(self, rubrics_uid: int) -> BaseResponse[bool]:
        """Delete a rubric.

        Args:
            rubrics_uid: The rubric UID.

        Returns:
            BaseResponse containing deletion success status.
        """
        response = self._delete(f"/{rubrics_uid}")
        return BaseResponse[bool].model_validate(response)


class AkashaResource(BaseResource):
    """Resource for /akasha endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/akasha")

    def generate(
        self, params: AkashaGenerateParams | None = None
    ) -> BaseResponse[AkashaGenerateResponse]:
        """Generate content using Akasha AI.

        Args:
            params: Optional generation parameters.

        Returns:
            BaseResponse containing the generated content.
        """
        response = self._post("/generate", data=params)
        return BaseResponse[AkashaGenerateResponse].model_validate(response)


class JoomlaResource(BaseResource):
    """Resource for /joomla endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/joomla")

    def generate(
        self, params: JoomlaGenerateParams | None = None
    ) -> BaseResponse[JoomlaGenerateResponse]:
        """Generate Joomla content.

        Args:
            params: Optional generation parameters.

        Returns:
            BaseResponse containing the generated content.
        """
        response = self._post("/generate", data=params)
        return BaseResponse[JoomlaGenerateResponse].model_validate(response)


class OllamaResource(BaseResource):
    """Resource for /ollama endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/ollama")

    def list_tags(self, options: EdgeCacheParams | None = None) -> BaseResponse[list[OllamaTag]]:
        """List available Ollama models/tags.

        Args:
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing a list of OllamaTag items.
        """
        response = self._get("/tags", params=options)
        return BaseResponse[list[OllamaTag]].model_validate(response)


class AgrInfoClient(BaseServiceClient):
    """Client for the AGR Info service.

    Provides access to AI content generation and infrastructure endpoints including:
    - Context (context)
    - Health check (health_check)
    - Microservices (microservices)
    - Rubrics (rubrics)
    - Akasha AI generation (akasha)
    - Joomla content generation (joomla)
    - Ollama model management (ollama)

    Example:
        >>> from augur_api import AugurAPI
        >>> api = AugurAPI(token="...", site_id="...")
        >>> services = api.agr_info.microservices.list()
        >>> for svc in services.data:
        ...     print(svc.name)
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the AGR Info client.

        Args:
            http_client: HTTP client for making requests.
        """
        super().__init__(http_client)
        self._context: ContextResource | None = None
        self._microservices: MicroservicesResource | None = None
        self._rubrics: RubricsResource | None = None
        self._akasha: AkashaResource | None = None
        self._joomla: JoomlaResource | None = None
        self._ollama: OllamaResource | None = None

    @property
    def context(self) -> ContextResource:
        """Access context endpoints."""
        if self._context is None:
            self._context = ContextResource(self._http)
        return self._context

    @property
    def microservices(self) -> MicroservicesResource:
        """Access microservices endpoints."""
        if self._microservices is None:
            self._microservices = MicroservicesResource(self._http)
        return self._microservices

    @property
    def rubrics(self) -> RubricsResource:
        """Access rubrics endpoints."""
        if self._rubrics is None:
            self._rubrics = RubricsResource(self._http)
        return self._rubrics

    @property
    def akasha(self) -> AkashaResource:
        """Access Akasha AI generation endpoints."""
        if self._akasha is None:
            self._akasha = AkashaResource(self._http)
        return self._akasha

    @property
    def joomla(self) -> JoomlaResource:
        """Access Joomla content generation endpoints."""
        if self._joomla is None:
            self._joomla = JoomlaResource(self._http)
        return self._joomla

    @property
    def ollama(self) -> OllamaResource:
        """Access Ollama model management endpoints."""
        if self._ollama is None:
            self._ollama = OllamaResource(self._http)
        return self._ollama
