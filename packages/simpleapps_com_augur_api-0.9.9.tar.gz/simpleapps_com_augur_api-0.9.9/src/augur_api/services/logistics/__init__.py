"""Logistics service exports."""

from augur_api.services.logistics.client import (
    LogisticsClient,
    ShipviaResource,
    SpeedshipResource,
)
from augur_api.services.logistics.schemas import (
    HealthCheckData,
    ShipviaLtlRate,
    ShipviaLtlRatesParams,
    ShipviaRate,
    ShipviaRatesParams,
    SpeedshipFreight,
    SpeedshipFreightParams,
)

__all__ = [
    # Client
    "LogisticsClient",
    # Resources
    "ShipviaResource",
    "SpeedshipResource",
    # Health check
    "HealthCheckData",
    # Shipvia schemas
    "ShipviaRatesParams",
    "ShipviaRate",
    "ShipviaLtlRatesParams",
    "ShipviaLtlRate",
    # Speedship schemas
    "SpeedshipFreightParams",
    "SpeedshipFreight",
]
