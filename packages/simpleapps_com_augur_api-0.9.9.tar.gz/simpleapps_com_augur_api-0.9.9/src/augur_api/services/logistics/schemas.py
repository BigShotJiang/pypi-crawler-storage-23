"""Schemas for the Logistics service."""

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# Shipvia Rates
class ShipviaRatesParams(EdgeCacheParams):
    """Parameters for getting ShipVia rates."""

    origin_zip: str | None = None
    destination_zip: str | None = None
    weight: float | None = None
    ship_via_cd: str | None = None


class ShipviaRate(CamelCaseModel, extra="allow"):
    """ShipVia rate response."""

    carrier: str | None = None
    service_type: str | None = None
    rate: float | None = None
    transit_days: int | None = None


# Shipvia LTL Rates
class ShipviaLtlRatesParams(EdgeCacheParams):
    """Parameters for getting ShipVia LTL rates."""

    origin_zip: str | None = None
    destination_zip: str | None = None
    weight: float | None = None
    freight_class: str | None = None


class ShipviaLtlRate(CamelCaseModel, extra="allow"):
    """ShipVia LTL rate response."""

    carrier: str | None = None
    rate: float | None = None
    transit_days: int | None = None


# Speedship Freight
class SpeedshipFreightParams(EdgeCacheParams):
    """Parameters for getting Speedship freight."""

    origin_zip: str | None = None
    destination_zip: str | None = None
    weight: float | None = None


class SpeedshipFreight(CamelCaseModel, extra="allow"):
    """Speedship freight response."""

    rate: float | None = None
    transit_days: int | None = None
    carrier: str | None = None
