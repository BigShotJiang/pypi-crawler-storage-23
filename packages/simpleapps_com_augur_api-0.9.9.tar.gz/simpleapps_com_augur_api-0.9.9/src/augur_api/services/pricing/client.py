"""Pricing service client for price and tax calculations."""

from __future__ import annotations

from typing import TYPE_CHECKING, List

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.pricing.schemas import (
    JobPriceHdr,
    JobPriceHdrListParams,
    JobPriceLine,
    JobPriceLinesParams,
    PriceEngineParams,
    PriceEngineResult,
    TaxEngineRequest,
    TaxEngineResult,
)
from augur_api.services.resource import BaseResource


class PriceEngineResource(BaseResource):
    """Resource for /price-engine endpoint."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/price-engine")

    def get(self, params: PriceEngineParams) -> BaseResponse[PriceEngineResult]:
        """Get item price using the price engine.

        Args:
            params: Price engine parameters including customer_id and item_id.

        Returns:
            BaseResponse containing the PriceEngineResult.
        """
        response = self._get(params=params)
        return BaseResponse[PriceEngineResult].model_validate(response)


class TaxEngineResource(BaseResource):
    """Resource for /tax-engine endpoint."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/tax-engine")

    def calculate(self, request: TaxEngineRequest) -> BaseResponse[TaxEngineResult]:
        """Calculate tax for items.

        Args:
            request: Tax calculation request with items and address.

        Returns:
            BaseResponse containing the TaxEngineResult.
        """
        response = self._post(data=request)
        return BaseResponse[TaxEngineResult].model_validate(response)


class JobPriceHdrResource(BaseResource):
    """Resource for /job-price-hdr endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/job-price-hdr")

    def list(self, params: JobPriceHdrListParams | None = None) -> BaseResponse[List[JobPriceHdr]]:
        """List job price headers.

        Args:
            params: Optional query parameters for filtering.

        Returns:
            BaseResponse containing a list of JobPriceHdr items.
        """
        response = self._get(params=params)
        return BaseResponse[List[JobPriceHdr]].model_validate(response)

    def get(self, job_price_hdr_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[JobPriceHdr]:
        """Get job price header by UID.

        Args:
            job_price_hdr_uid: The job price header UID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the JobPriceHdr.
        """
        response = self._get(f"/{job_price_hdr_uid}", params=options)
        return BaseResponse[JobPriceHdr].model_validate(response)

    def list_lines(
        self, job_price_hdr_uid: int, params: JobPriceLinesParams | None = None
    ) -> BaseResponse[List[JobPriceLine]]:
        """List job price lines.

        Args:
            job_price_hdr_uid: The job price header UID.
            params: Optional query parameters for filtering.

        Returns:
            BaseResponse containing a list of JobPriceLine items.
        """
        response = self._get(f"/{job_price_hdr_uid}/lines", params=params)
        return BaseResponse[List[JobPriceLine]].model_validate(response)

    def get_line(
        self, job_price_hdr_uid: int, job_price_line_uid: int, options: EdgeCacheParams | None = None
    ) -> BaseResponse[JobPriceLine]:
        """Get specific job price line.

        Args:
            job_price_hdr_uid: The job price header UID.
            job_price_line_uid: The job price line UID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the JobPriceLine.
        """
        response = self._get(f"/{job_price_hdr_uid}/lines/{job_price_line_uid}", params=options)
        return BaseResponse[JobPriceLine].model_validate(response)


class PricingClient(BaseServiceClient):
    """Client for the Pricing service.

    Provides access to pricing and tax calculation endpoints including:
    - Health check (health_check)
    - Ping (ping)
    - Price engine (price_engine)
    - Tax engine (tax_engine)
    - Job price headers (job_price_hdr)

    Example:
        >>> from augur_api import AugurAPI
        >>> api = AugurAPI(token="...", site_id="...")
        >>> price = api.pricing.price_engine.get(PriceEngineParams(
        ...     customer_id=100, item_id="ABC123", quantity=10
        ... ))
        >>> print(price.data.unit_price)
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the Pricing client.

        Args:
            http_client: HTTP client for making requests.
        """
        super().__init__(http_client)
        self._price_engine: PriceEngineResource | None = None
        self._tax_engine: TaxEngineResource | None = None
        self._job_price_hdr: JobPriceHdrResource | None = None

    @property
    def price_engine(self) -> PriceEngineResource:
        """Access price engine endpoint."""
        if self._price_engine is None:
            self._price_engine = PriceEngineResource(self._http)
        return self._price_engine

    @property
    def tax_engine(self) -> TaxEngineResource:
        """Access tax engine endpoint."""
        if self._tax_engine is None:
            self._tax_engine = TaxEngineResource(self._http)
        return self._tax_engine

    @property
    def job_price_hdr(self) -> JobPriceHdrResource:
        """Access job price header endpoints."""
        if self._job_price_hdr is None:
            self._job_price_hdr = JobPriceHdrResource(self._http)
        return self._job_price_hdr
