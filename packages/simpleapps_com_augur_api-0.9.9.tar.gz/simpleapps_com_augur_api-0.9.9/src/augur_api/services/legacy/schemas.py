"""Schemas for the Legacy service."""

from pydantic import BaseModel

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# States
class StateListParams(EdgeCacheParams):
    """Parameters for listing states."""

    limit: int | None = None
    offset: int | None = None
    two_letter_code: str | None = None


class StateGetParams(EdgeCacheParams):
    """Parameters for getting a state."""

    two_letter_code: str | None = None


class State(CamelCaseModel, extra="allow"):
    """State entity (passthrough)."""

    state_uid: int | None = None
    state_cd: str | None = None
    state_name: str | None = None
    country_cd: str | None = None


class StateCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a state (passthrough)."""


class StateUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a state (passthrough)."""


# Also Bought
class AlsoBoughtListParams(EdgeCacheParams):
    """Parameters for listing also bought items."""

    limit: int | None = None
    offset: int | None = None


class AlsoBoughtItem(CamelCaseModel, extra="allow"):
    """Also bought item entity (passthrough)."""

    inv_mast_uid: int | None = None
    item_id: str | None = None
    item_desc: str | None = None


# Inv Mast Tags
class InvMastTagsListParams(EdgeCacheParams):
    """Parameters for listing inv mast tags."""

    limit: int | None = None
    offset: int | None = None


class InvMastTag(CamelCaseModel, extra="allow"):
    """Inv mast tag entity (passthrough)."""

    inv_mast_tags_uid: int | None = None
    inv_mast_uid: int | None = None
    tag: str | None = None


class InvMastTagCreateParams(BaseModel, extra="allow"):
    """Parameters for creating an inv mast tag (passthrough)."""


class InvMastTagUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating an inv mast tag (passthrough)."""


# Inv Mast Web Desc
class InvMastWebDescListParams(EdgeCacheParams):
    """Parameters for listing inv mast web descriptions."""

    limit: int | None = None
    offset: int | None = None


class InvMastWebDesc(CamelCaseModel, extra="allow"):
    """Inv mast web description entity (passthrough)."""

    inv_mast_web_desc_uid: int | None = None
    inv_mast_uid: int | None = None
    description: str | None = None


class InvMastWebDescCreateParams(BaseModel, extra="allow"):
    """Parameters for creating an inv mast web description (passthrough)."""


class InvMastWebDescUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating an inv mast web description (passthrough)."""


# Item Category
class ItemCategory(CamelCaseModel, extra="allow"):
    """Item category entity (passthrough)."""

    item_category_uid: int | None = None
    category_name: str | None = None


# Orders
class OrderResetResponse(CamelCaseModel, extra="allow"):
    """Order reset response (passthrough)."""
