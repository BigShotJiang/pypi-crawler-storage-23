"""Legacy service exports."""

from augur_api.services.legacy.client import (
    AlsoBoughtResource,
    InvMastTagsResource,
    InvMastWebDescResource,
    ItemCategoryResource,
    LegacyClient,
    OrdersResource,
    StateResource,
)
from augur_api.services.legacy.schemas import (
    AlsoBoughtItem,
    AlsoBoughtListParams,
    HealthCheckData,
    InvMastTag,
    InvMastTagCreateParams,
    InvMastTagsListParams,
    InvMastTagUpdateParams,
    InvMastWebDesc,
    InvMastWebDescCreateParams,
    InvMastWebDescListParams,
    InvMastWebDescUpdateParams,
    ItemCategory,
    OrderResetResponse,
    State,
    StateCreateParams,
    StateGetParams,
    StateListParams,
    StateUpdateParams,
)

__all__ = [
    # Client
    "LegacyClient",
    # Resources
    "StateResource",
    "AlsoBoughtResource",
    "InvMastTagsResource",
    "InvMastWebDescResource",
    "ItemCategoryResource",
    "OrdersResource",
    # Health check
    "HealthCheckData",
    # State schemas
    "State",
    "StateGetParams",
    "StateListParams",
    "StateCreateParams",
    "StateUpdateParams",
    # Also bought schemas
    "AlsoBoughtItem",
    "AlsoBoughtListParams",
    # Inv mast tags schemas
    "InvMastTag",
    "InvMastTagsListParams",
    "InvMastTagCreateParams",
    "InvMastTagUpdateParams",
    # Inv mast web desc schemas
    "InvMastWebDesc",
    "InvMastWebDescListParams",
    "InvMastWebDescCreateParams",
    "InvMastWebDescUpdateParams",
    # Item category schemas
    "ItemCategory",
    # Orders schemas
    "OrderResetResponse",
]
