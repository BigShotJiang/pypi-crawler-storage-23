"""Shared pytest fixtures for mkdocx tests."""

import textwrap
from pathlib import Path

import pytest


@pytest.fixture
def tmp_project(tmp_path):
    """Create a minimal MkDocs project structure in a temp directory."""
    mkdocs_yml = tmp_path / "mkdocs.yml"
    mkdocs_yml.write_text(textwrap.dedent("""\
        site_name: Test Site
        site_url: https://example.com/handbook
        extra:
          company_name: Acme Corp
          support_email: help@acme.com
    """), encoding="utf-8")

    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()

    return tmp_path


@pytest.fixture
def sample_md(tmp_project):
    """Create a sample markdown file under docs/."""
    docs = tmp_project / "docs"
    md_file = docs / "policy.md"
    md_file.write_text(textwrap.dedent("""\
        ---
        title: Test Policy
        tags:
          - policy
          - compliance
        ---

        ## 1. Introduction

        This is {{ company_name }}'s policy.

        Contact {{ support_email }} for help.

        ## 2. Details

        Some details here.
    """), encoding="utf-8")
    return md_file
