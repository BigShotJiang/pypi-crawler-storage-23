"""Tests for mkdocx.preprocess."""

import textwrap
from pathlib import Path

import pytest

from mkdocx.preprocess import (
    convert_admonitions,
    fix_empty_header_tables,
    parse_frontmatter,
    preprocess_markdown,
    resolve_macros,
    resolve_relative_links,
    shift_headings,
    strip_abbreviations,
    strip_heading_numbers,
)


# ---------------------------------------------------------------------------
# parse_frontmatter
# ---------------------------------------------------------------------------

class TestParseFrontmatter:
    def test_with_frontmatter(self):
        content = "---\ntitle: Hello\ntags:\n  - a\n---\nBody text"
        fm, body = parse_frontmatter(content)
        assert fm == {"title": "Hello", "tags": ["a"]}
        assert body == "Body text"

    def test_without_frontmatter(self):
        content = "Just some markdown\n\nWith paragraphs."
        fm, body = parse_frontmatter(content)
        assert fm == {}
        assert body == content

    def test_empty_frontmatter(self):
        content = "---\n\n---\nBody here"
        fm, body = parse_frontmatter(content)
        assert fm == {}
        assert body == "Body here"


# ---------------------------------------------------------------------------
# resolve_macros
# ---------------------------------------------------------------------------

class TestResolveMacros:
    def test_single_variable(self):
        assert resolve_macros("Hello {{ name }}", {"name": "World"}) == "Hello World"

    def test_no_space_form(self):
        assert resolve_macros("Hello {{name}}", {"name": "World"}) == "Hello World"

    def test_multiple_variables(self):
        text = "{{ a }} and {{ b }}"
        result = resolve_macros(text, {"a": "X", "b": "Y"})
        assert result == "X and Y"

    def test_missing_variable_left_alone(self):
        text = "Hello {{ unknown }}"
        assert resolve_macros(text, {"other": "val"}) == "Hello {{ unknown }}"

    def test_both_forms_same_key(self):
        text = "{{key}} and {{ key }}"
        result = resolve_macros(text, {"key": "V"})
        assert result == "V and V"


# ---------------------------------------------------------------------------
# resolve_relative_links
# ---------------------------------------------------------------------------

class TestResolveRelativeLinks:
    def setup_method(self):
        self.site_url = "https://example.com/handbook"

    def _make_paths(self, tmp_path, rel_md="docs/section/page.md"):
        project_root = tmp_path
        (tmp_path / "docs" / "section").mkdir(parents=True, exist_ok=True)
        input_path = tmp_path / rel_md
        input_path.touch()
        return input_path, project_root

    def test_relative_md_link_rewritten(self, tmp_path):
        inp, root = self._make_paths(tmp_path)
        text = "[Other](other-page.md)"
        result = resolve_relative_links(text, inp, root, self.site_url)
        assert result == "[Other](https://example.com/handbook/section/other-page/)"

    def test_external_https_left_alone(self, tmp_path):
        inp, root = self._make_paths(tmp_path)
        text = "[Google](https://google.com)"
        assert resolve_relative_links(text, inp, root, self.site_url) == text

    def test_mailto_left_alone(self, tmp_path):
        inp, root = self._make_paths(tmp_path)
        text = "[Email](mailto:a@b.com)"
        assert resolve_relative_links(text, inp, root, self.site_url) == text

    def test_anchor_only_left_alone(self, tmp_path):
        inp, root = self._make_paths(tmp_path)
        text = "[Section](#details)"
        assert resolve_relative_links(text, inp, root, self.site_url) == text

    def test_non_md_link_left_alone(self, tmp_path):
        inp, root = self._make_paths(tmp_path)
        text = "[Image](photo.png)"
        assert resolve_relative_links(text, inp, root, self.site_url) == text

    def test_parent_path_resolution(self, tmp_path):
        inp, root = self._make_paths(tmp_path)
        text = "[Up](../other.md)"
        result = resolve_relative_links(text, inp, root, self.site_url)
        assert result == "[Up](https://example.com/handbook/other/)"

    def test_index_md_trailing_slash(self, tmp_path):
        project_root = tmp_path
        sub = tmp_path / "docs" / "section" / "sub"
        sub.mkdir(parents=True, exist_ok=True)
        input_path = sub / "page.md"
        input_path.touch()
        text = "[Home](../index.md)"
        result = resolve_relative_links(text, input_path, project_root, self.site_url)
        assert result == "[Home](https://example.com/handbook/section/)"

    def test_file_not_under_docs_unchanged(self, tmp_path):
        project_root = tmp_path
        (tmp_path / "docs").mkdir(exist_ok=True)
        outside = tmp_path / "outside" / "file.md"
        outside.parent.mkdir(parents=True, exist_ok=True)
        outside.touch()
        text = "[Link](other.md)"
        assert resolve_relative_links(text, outside, project_root, self.site_url) == text

    def test_no_site_url_returns_unchanged(self, tmp_path):
        inp, root = self._make_paths(tmp_path)
        text = "[Link](other.md)"
        assert resolve_relative_links(text, inp, root, "") == text


# ---------------------------------------------------------------------------
# strip_heading_numbers
# ---------------------------------------------------------------------------

class TestStripHeadingNumbers:
    def test_strips_numbered_h2(self):
        assert strip_heading_numbers("## 1. Foo") == "## Foo"

    def test_leaves_unnumbered_alone(self):
        assert strip_heading_numbers("## Foo") == "## Foo"

    def test_handles_h3(self):
        assert strip_heading_numbers("### 3. Bar") == "### Bar"

    def test_handles_h4(self):
        assert strip_heading_numbers("#### 10. Deep") == "#### Deep"

    def test_multiline(self):
        text = "## 1. First\n\nParagraph\n\n## 2. Second"
        expected = "## First\n\nParagraph\n\n## Second"
        assert strip_heading_numbers(text) == expected


# ---------------------------------------------------------------------------
# shift_headings
# ---------------------------------------------------------------------------

class TestShiftHeadings:
    def test_h2_becomes_h1(self):
        assert shift_headings("## Title") == "# Title"

    def test_h3_becomes_h2(self):
        assert shift_headings("### Sub") == "## Sub"

    def test_h1_left_alone(self):
        assert shift_headings("# Top") == "# Top"

    def test_multiline_mixed(self):
        text = "## A\n\n### B\n\n# C"
        expected = "# A\n\n## B\n\n# C"
        assert shift_headings(text) == expected


# ---------------------------------------------------------------------------
# convert_admonitions
# ---------------------------------------------------------------------------

class TestConvertAdmonitions:
    def test_note_with_title(self):
        text = '!!! note "Important"\n    This is a note.'
        result = convert_admonitions(text)
        assert '::: {.admonition .note}' in result
        assert '**\u2139\ufe0f Important**' in result
        assert "This is a note." in result

    def test_collapsible(self):
        text = '??? warning "Caution"\n    Be careful.'
        result = convert_admonitions(text)
        assert '::: {.admonition .warning}' in result
        assert "Be careful." in result

    def test_multiline_content(self):
        text = '!!! tip "Hint"\n    Line one.\n\n    Line two.'
        result = convert_admonitions(text)
        assert "Line one." in result
        assert "Line two." in result

    def test_unknown_type_default_icon(self):
        text = '!!! custom "My Block"\n    Content.'
        result = convert_admonitions(text)
        assert "\U0001f4cc" in result  # default pin icon
        assert "My Block" in result

    def test_no_title_uses_type(self):
        text = "!!! warning\n    Content."
        result = convert_admonitions(text)
        assert "Warning" in result  # type.title()


# ---------------------------------------------------------------------------
# fix_empty_header_tables
# ---------------------------------------------------------------------------

class TestFixEmptyHeaderTables:
    def test_empty_header_promoted(self):
        text = "| | |\n|---|---|\n| A | B |\n| C | D |"
        result = fix_empty_header_tables(text)
        lines = result.split("\n")
        assert lines[0] == "| A | B |"
        assert lines[1] == "|---|---|"

    def test_normal_table_left_alone(self):
        text = "| H1 | H2 |\n|---|---|\n| A | B |"
        assert fix_empty_header_tables(text) == text


# ---------------------------------------------------------------------------
# strip_abbreviations
# ---------------------------------------------------------------------------

class TestStripAbbreviations:
    def test_removes_abbreviation_lines(self):
        text = "Some text.\n\n*[HTML]: Hyper Text Markup Language\n*[CSS]: Cascading Style Sheets"
        result = strip_abbreviations(text)
        assert "*[HTML]" not in result
        assert "*[CSS]" not in result
        assert "Some text." in result

    def test_leaves_normal_text(self):
        text = "Normal paragraph with no abbreviations."
        assert strip_abbreviations(text) == text


# ---------------------------------------------------------------------------
# preprocess_markdown (integration)
# ---------------------------------------------------------------------------

class TestPreprocessMarkdown:
    def test_full_pipeline(self):
        body = textwrap.dedent("""\
            ## 1. Introduction

            Welcome to {{ company }}.

            !!! note "Notice"
                Important info.

            ## 2. Details

            *[FAQ]: Frequently Asked Questions
        """)
        result = preprocess_markdown(body, {"company": "Acme"})

        # Heading numbers stripped and shifted
        assert "# Introduction" in result
        assert "## Details" not in result or "# Details" in result
        assert "1." not in result

        # Macro resolved
        assert "Acme" in result
        assert "{{ company }}" not in result

        # Admonition converted
        assert ":::" in result

        # Abbreviation stripped
        assert "*[FAQ]" not in result

    def test_keep_heading_numbers(self):
        body = "## 1. Intro\n\nText"
        result = preprocess_markdown(body, {}, keep_heading_numbers=True)
        assert "1. Intro" in result
