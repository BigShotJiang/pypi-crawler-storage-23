"""Tests for mkdocx.export."""

import textwrap
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from mkdocx.export import collect_markdown_files, export_file, has_tag


# ---------------------------------------------------------------------------
# collect_markdown_files
# ---------------------------------------------------------------------------

class TestCollectMarkdownFiles:
    def test_finds_md_recursively(self, tmp_path):
        (tmp_path / "a.md").write_text("# A")
        sub = tmp_path / "sub"
        sub.mkdir()
        (sub / "b.md").write_text("# B")
        (sub / "c.txt").write_text("not markdown")

        files = collect_markdown_files(tmp_path)
        stems = [f.stem for f in files]
        assert "a" in stems
        assert "b" in stems
        assert "c" not in stems

    def test_returns_sorted(self, tmp_path):
        for name in ["z.md", "a.md", "m.md"]:
            (tmp_path / name).write_text(f"# {name}")
        files = collect_markdown_files(tmp_path)
        names = [f.name for f in files]
        assert names == sorted(names)

    def test_empty_directory(self, tmp_path):
        assert collect_markdown_files(tmp_path) == []


# ---------------------------------------------------------------------------
# has_tag
# ---------------------------------------------------------------------------

class TestHasTag:
    def test_matches_tag(self, tmp_path):
        md = tmp_path / "tagged.md"
        md.write_text("---\ntags:\n  - policy\n  - hr\n---\nBody")
        assert has_tag(md, "policy") is True

    def test_returns_false_for_missing_tag(self, tmp_path):
        md = tmp_path / "tagged.md"
        md.write_text("---\ntags:\n  - policy\n---\nBody")
        assert has_tag(md, "finance") is False

    def test_handles_missing_frontmatter(self, tmp_path):
        md = tmp_path / "plain.md"
        md.write_text("No frontmatter here.")
        assert has_tag(md, "anything") is False

    def test_handles_empty_tags(self, tmp_path):
        md = tmp_path / "empty.md"
        md.write_text("---\ntags: []\n---\nBody")
        assert has_tag(md, "x") is False

    def test_handles_non_list_tags(self, tmp_path):
        md = tmp_path / "bad.md"
        md.write_text("---\ntags: not-a-list\n---\nBody")
        assert has_tag(md, "not-a-list") is False


# ---------------------------------------------------------------------------
# export_file
# ---------------------------------------------------------------------------

class TestExportFile:
    def test_calls_pandoc_with_correct_args(self, tmp_path):
        # Set up input
        md = tmp_path / "docs" / "test.md"
        md.parent.mkdir(parents=True)
        md.write_text("---\ntitle: Test\n---\n## Hello\n")

        output = tmp_path / "out" / "test.docx"

        with patch("mkdocx.export.subprocess.run") as mock_run, \
             patch("mkdocx.export.shrink_wide_tables"), \
             patch("mkdocx.export.disable_banded_columns"):
            export_file(
                md, output,
                pandoc_bin="/usr/bin/pandoc",
                project_root=tmp_path,
                site_url="",
                variables={},
            )

            mock_run.assert_called_once()
            cmd = mock_run.call_args[0][0]
            assert cmd[0] == "/usr/bin/pandoc"
            assert "-o" in cmd
            assert str(output) in cmd
            assert "--from=markdown+fenced_divs" in cmd
            assert "--to=docx" in cmd
            assert "--metadata=title:Test" in cmd
            assert "--metadata=lang:en-GB" in cmd

    def test_creates_output_directory(self, tmp_path):
        md = tmp_path / "docs" / "test.md"
        md.parent.mkdir(parents=True)
        md.write_text("## Hello\n")

        output = tmp_path / "deep" / "nested" / "test.docx"

        with patch("mkdocx.export.subprocess.run"), \
             patch("mkdocx.export.shrink_wide_tables"), \
             patch("mkdocx.export.disable_banded_columns"):
            export_file(
                md, output,
                pandoc_bin="pandoc",
                project_root=tmp_path,
                site_url="",
                variables={},
            )

        assert output.parent.exists()

    def test_includes_lua_filter_when_present(self, tmp_path):
        md = tmp_path / "docs" / "test.md"
        md.parent.mkdir(parents=True)
        md.write_text("## Hello\n")

        output = tmp_path / "out" / "test.docx"

        with patch("mkdocx.export.subprocess.run") as mock_run, \
             patch("mkdocx.export.shrink_wide_tables"), \
             patch("mkdocx.export.disable_banded_columns"), \
             patch("mkdocx.export._lua_filter_path") as mock_filter:
            mock_filter_path = MagicMock()
            mock_filter_path.is_file.return_value = True
            mock_filter_path.__str__ = lambda self: "/path/to/docx.lua"
            mock_filter.return_value = mock_filter_path

            export_file(
                md, output,
                pandoc_bin="pandoc",
                project_root=tmp_path,
                site_url="",
                variables={},
            )

            cmd = mock_run.call_args[0][0]
            lua_args = [a for a in cmd if "--lua-filter=" in a]
            assert len(lua_args) == 1

    def test_title_fallback_from_filename(self, tmp_path):
        md = tmp_path / "docs" / "my-great-doc.md"
        md.parent.mkdir(parents=True)
        md.write_text("## Content only\n")

        output = tmp_path / "out" / "test.docx"

        with patch("mkdocx.export.subprocess.run") as mock_run, \
             patch("mkdocx.export.shrink_wide_tables"), \
             patch("mkdocx.export.disable_banded_columns"):
            export_file(
                md, output,
                pandoc_bin="pandoc",
                project_root=tmp_path,
                site_url="",
                variables={},
            )

            cmd = mock_run.call_args[0][0]
            title_args = [a for a in cmd if a.startswith("--metadata=title:")]
            assert title_args[0] == "--metadata=title:My Great Doc"


# ---------------------------------------------------------------------------
# shrink_wide_tables
# ---------------------------------------------------------------------------

class TestShrinkWideTables:
    def test_with_python_docx(self, tmp_path):
        try:
            from docx import Document
            from docx.shared import Pt
        except ImportError:
            pytest.skip("python-docx not installed")

        from mkdocx.postprocess import shrink_wide_tables

        # Create a docx with a wide table
        doc = Document()
        table = doc.add_table(rows=2, cols=5)
        for row in table.rows:
            for cell in row.cells:
                cell.text = "Test"
        docx_path = tmp_path / "wide.docx"
        doc.save(str(docx_path))

        shrink_wide_tables(docx_path)

        # Verify font size was changed
        doc2 = Document(str(docx_path))
        for row in doc2.tables[0].rows:
            for cell in row.cells:
                for para in cell.paragraphs:
                    for run in para.runs:
                        assert run.font.size == Pt(9)

    def test_narrow_table_unchanged(self, tmp_path):
        try:
            from docx import Document
            from docx.shared import Pt
        except ImportError:
            pytest.skip("python-docx not installed")

        from mkdocx.postprocess import shrink_wide_tables

        doc = Document()
        table = doc.add_table(rows=2, cols=2)
        for row in table.rows:
            for cell in row.cells:
                run = cell.paragraphs[0].add_run("Test")
                run.font.size = Pt(11)
        docx_path = tmp_path / "narrow.docx"
        doc.save(str(docx_path))

        shrink_wide_tables(docx_path)

        doc2 = Document(str(docx_path))
        for row in doc2.tables[0].rows:
            for cell in row.cells:
                for para in cell.paragraphs:
                    for run in para.runs:
                        assert run.font.size == Pt(11)
