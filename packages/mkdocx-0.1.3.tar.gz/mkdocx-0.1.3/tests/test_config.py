"""Tests for mkdocx.config."""

import os
import textwrap

import pytest

from mkdocx.config import _make_yaml_loader, find_project_root, load_mkdocs_config


class TestFindProjectRoot:
    def test_finds_mkdocs_yml_in_parent(self, tmp_path, monkeypatch):
        (tmp_path / "mkdocs.yml").write_text("site_name: Test\n")
        child = tmp_path / "sub" / "dir"
        child.mkdir(parents=True)
        monkeypatch.chdir(child)
        assert find_project_root() == tmp_path

    def test_exits_when_not_found(self, tmp_path, monkeypatch):
        # Use a directory with no mkdocs.yml anywhere above it
        monkeypatch.chdir(tmp_path)
        with pytest.raises(SystemExit, match="Could not find mkdocs.yml"):
            find_project_root()


class TestMakeYamlLoader:
    def test_ignores_python_tags(self):
        import yaml

        loader = _make_yaml_loader()
        data = yaml.load(
            "plugins:\n  - !!python/name:some.module {}\n",
            Loader=loader,
        )
        assert data is not None
        # The python tag value should be None (ignored)
        assert data["plugins"] == [None]


class TestLoadMkdocsConfig:
    def test_returns_site_url_and_extra(self, tmp_path):
        (tmp_path / "mkdocs.yml").write_text(textwrap.dedent("""\
            site_name: Test
            site_url: https://example.com
            extra:
              company: Acme
              version: 2
        """), encoding="utf-8")
        site_url, extra = load_mkdocs_config(tmp_path)
        assert site_url == "https://example.com"
        assert extra == {"company": "Acme", "version": 2}

    def test_missing_fields_return_defaults(self, tmp_path):
        (tmp_path / "mkdocs.yml").write_text("site_name: Minimal\n", encoding="utf-8")
        site_url, extra = load_mkdocs_config(tmp_path)
        assert site_url == ""
        assert extra == {}
