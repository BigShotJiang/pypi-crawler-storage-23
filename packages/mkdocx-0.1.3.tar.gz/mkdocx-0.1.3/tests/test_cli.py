"""Tests for mkdocx.cli."""

import pytest

from mkdocx.cli import build_parser, DEFAULT_OUTPUT_FOLDER


class TestBuildParser:
    def test_basic_input(self):
        parser = build_parser()
        args = parser.parse_args(["docs/file.md"])
        assert args.input == "docs/file.md"
        assert args.output is None
        assert args.output_folder is None
        assert args.tag is None
        assert args.preserve_heading_numbers is False

    def test_output_flag(self):
        parser = build_parser()
        args = parser.parse_args(["file.md", "-o", "out.docx"])
        assert args.output == "out.docx"

    def test_output_folder_with_value(self):
        parser = build_parser()
        args = parser.parse_args(["file.md", "-of", "my-folder"])
        assert args.output_folder == "my-folder"

    def test_output_folder_without_value(self):
        parser = build_parser()
        args = parser.parse_args(["file.md", "-of"])
        assert args.output_folder == DEFAULT_OUTPUT_FOLDER

    def test_mutually_exclusive_o_and_of(self):
        parser = build_parser()
        with pytest.raises(SystemExit):
            parser.parse_args(["file.md", "-o", "out.docx", "-of", "folder"])

    def test_tag_argument(self):
        parser = build_parser()
        args = parser.parse_args(["docs/", "-t", "policy"])
        assert args.tag == "policy"

    def test_pandoc_path(self):
        parser = build_parser()
        args = parser.parse_args(["file.md", "--pandoc", "/usr/local/bin/pandoc"])
        assert args.pandoc == "/usr/local/bin/pandoc"

    def test_preserve_heading_numbers(self):
        parser = build_parser()
        args = parser.parse_args(["file.md", "--preserve-heading-numbers"])
        assert args.preserve_heading_numbers is True

    def test_add_gitignore_default_false(self):
        parser = build_parser()
        args = parser.parse_args(["file.md"])
        assert args.add_gitignore is False

    def test_add_gitignore_flag(self):
        parser = build_parser()
        args = parser.parse_args(["file.md", "--add-gitignore"])
        assert args.add_gitignore is True


class TestMainErrorCases:
    def test_tag_with_file_input(self, tmp_path, monkeypatch):
        """--tag with a file input should exit with an error."""
        from mkdocx.cli import main

        # Create project structure
        (tmp_path / "mkdocs.yml").write_text("site_name: T\n")
        md = tmp_path / "docs" / "file.md"
        md.parent.mkdir(parents=True)
        md.write_text("## Test\n")

        monkeypatch.chdir(tmp_path)

        with pytest.raises(SystemExit, match="--tag can only be used with directory"):
            main([str(md), "-t", "policy", "--pandoc", "pandoc"])

    def test_output_with_directory_input(self, tmp_path, monkeypatch):
        """-o with a directory input should exit with an error."""
        from mkdocx.cli import main

        (tmp_path / "mkdocs.yml").write_text("site_name: T\n")
        docs = tmp_path / "docs"
        docs.mkdir()
        (docs / "a.md").write_text("## A\n")

        monkeypatch.chdir(tmp_path)

        with pytest.raises(SystemExit, match="-o cannot be used with directory"):
            main([str(docs), "-o", "out.docx", "--pandoc", "pandoc"])
