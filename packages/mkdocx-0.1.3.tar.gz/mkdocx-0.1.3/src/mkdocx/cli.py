"""Command-line interface for mkdocx."""

import argparse
import subprocess
import sys
from importlib.metadata import version
from pathlib import Path

from .config import find_pandoc, find_project_root, load_mkdocs_config
from .export import collect_markdown_files, export_file, has_tag

DEFAULT_OUTPUT_FOLDER = "docx-exports"


def _resolve_output_folder(raw, project_root):
    """Resolve an output folder path, defaulting to project_root/docx-exports."""
    if not raw:
        return project_root / DEFAULT_OUTPUT_FOLDER
    folder = Path(raw)
    if not folder.is_absolute():
        folder = project_root / folder
    return folder.resolve()


def build_parser():
    """Build and return the argument parser."""
    parser = argparse.ArgumentParser(
        prog="mkdocx",
        description="Export MkDocs markdown to DOCX",
    )
    parser.add_argument(
        "-v",
        "--version",
        action="version",
        version=f"%(prog)s {version('mkdocx')}",
    )
    parser.add_argument("input", help="Path to a markdown file or directory")

    output_group = parser.add_mutually_exclusive_group()
    output_group.add_argument(
        "-o",
        "--output",
        help="Output DOCX path (single file only)",
    )
    output_group.add_argument(
        "-of",
        "--output-folder",
        nargs="?",
        const=DEFAULT_OUTPUT_FOLDER,
        default=None,
        help=f"Output folder (default: {DEFAULT_OUTPUT_FOLDER}/)",
    )

    parser.add_argument(
        "-t",
        "--tag",
        help="Filter by frontmatter tag (directory mode only)",
    )
    parser.add_argument(
        "--pandoc",
        default=None,
        help="Path to pandoc binary (auto-detected if not specified)",
    )
    parser.add_argument(
        "--preserve-heading-numbers",
        action="store_true",
        help="Keep leading numbers in headings (e.g. '1. Introduction')",
    )
    parser.add_argument(
        "--add-gitignore",
        action="store_true",
        help="Create a .gitignore in the output folder to ignore all exported files",
    )
    return parser


def main(argv=None):
    """Entry point for the mkdocx CLI."""
    parser = build_parser()
    args = parser.parse_args(argv)

    project_root = find_project_root()
    input_path = Path(args.input).resolve()

    if not input_path.exists():
        sys.exit(f"Error: {input_path} not found")

    pandoc_bin = args.pandoc or find_pandoc()
    if not pandoc_bin:
        sys.exit(
            "Error: pandoc not found. Install from https://pandoc.org/ or use --pandoc"
        )

    site_url, variables = load_mkdocs_config(project_root)

    export_kwargs = dict(
        pandoc_bin=pandoc_bin,
        project_root=project_root,
        site_url=site_url,
        variables=variables,
        keep_heading_numbers=args.preserve_heading_numbers,
    )

    # ----- Single file mode -----
    if input_path.is_file():
        if args.tag:
            sys.exit("Error: --tag can only be used with directory input")

        if args.output:
            output_path = Path(args.output).resolve()
        elif args.output_folder is not None:
            folder = _resolve_output_folder(args.output_folder, project_root)
            output_path = folder / (input_path.stem + ".docx")
        else:
            output_path = (
                project_root / DEFAULT_OUTPUT_FOLDER / (input_path.stem + ".docx")
            )

        export_file(input_path, output_path, **export_kwargs)

        if args.add_gitignore:
            gitignore = output_path.parent / ".gitignore"
            gitignore.write_text("*.*\n", encoding="utf-8")

    # ----- Directory mode -----
    elif input_path.is_dir():
        if args.output:
            sys.exit("Error: -o cannot be used with directory input; use -of instead")

        output_folder = _resolve_output_folder(args.output_folder, project_root)
        docs_dir = project_root / "docs"

        md_files = collect_markdown_files(input_path)
        if not md_files:
            sys.exit(f"Error: no .md files found in {input_path}")

        if args.tag:
            md_files = [f for f in md_files if has_tag(f, args.tag)]
            if not md_files:
                sys.exit(f"Error: no .md files with tag '{args.tag}' found")

        exported = 0
        errors = 0
        for md_file in md_files:
            if args.tag:
                # Flat output under tag subfolder
                out = output_folder / "tag" / args.tag / (md_file.stem + ".docx")
            else:
                # Mirror directory structure relative to docs/
                try:
                    rel = md_file.relative_to(docs_dir)
                except ValueError:
                    rel = md_file.relative_to(input_path)
                out = output_folder / rel.with_suffix(".docx")

            try:
                export_file(md_file, out, **export_kwargs)
                exported += 1
            except subprocess.CalledProcessError as e:
                print(f"Error exporting {md_file}: {e}", file=sys.stderr)
                errors += 1

        if args.add_gitignore:
            gitignore = output_folder / ".gitignore"
            gitignore.parent.mkdir(parents=True, exist_ok=True)
            gitignore.write_text("*\n", encoding="utf-8")

        summary = f"\nExported {exported}/{exported + errors} file(s)"
        if args.tag:
            summary += f" [tag: {args.tag}]"
        summary += f" to {output_folder}"
        print(summary)

    else:
        sys.exit(f"Error: {input_path} is neither a file nor a directory")
