"""Project configuration helpers: locate project root, load mkdocs.yml."""

import shutil
import sys
from pathlib import Path

import yaml


def find_project_root():
    """Walk up from CWD to find mkdocs.yml."""
    path = Path.cwd().resolve()
    while path != path.parent:
        if (path / "mkdocs.yml").exists():
            return path
        path = path.parent
    sys.exit("Error: Could not find mkdocs.yml in any parent directory.")


def find_pandoc():
    """Locate the pandoc binary, checking PATH and common install locations."""
    found = shutil.which("pandoc")
    if found:
        return found

    candidates = [
        Path.home() / "AppData" / "Local" / "Pandoc" / "pandoc.exe",
        Path("C:/Program Files/Pandoc/pandoc.exe"),
    ]
    for candidate in candidates:
        if candidate.exists():
            return str(candidate)

    return None


def _make_yaml_loader():
    """Create a YAML loader that ignores MkDocs-specific !!python/ tags."""
    loader = type("Loader", (yaml.SafeLoader,), {})
    loader.add_multi_constructor(
        "tag:yaml.org,2002:python/",
        lambda self, suffix, node: None,
    )
    return loader


def load_mkdocs_config(project_root):
    """Return (site_url, extra_dict) from mkdocs.yml."""
    with open(project_root / "mkdocs.yml", encoding="utf-8") as f:
        cfg = yaml.load(f, Loader=_make_yaml_loader())
    return cfg.get("site_url", ""), cfg.get("extra", {})
