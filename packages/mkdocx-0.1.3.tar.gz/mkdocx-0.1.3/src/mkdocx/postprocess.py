"""DOCX post-processing: table adjustments."""


def disable_banded_columns(docx_path):
    """Turn off the 'Banded Columns' table style option on every table."""
    try:
        from docx import Document
        from docx.oxml.ns import qn
    except ImportError:
        return

    doc = Document(str(docx_path))
    modified = False

    for table in doc.tables:
        tbl_pr = table._tbl.tblPr
        if tbl_pr is None:
            continue
        tbl_look = tbl_pr.find(qn("w:tblLook"))
        if tbl_look is not None:
            tbl_look.set(qn("w:noVBand"), "1")
            modified = True

    if modified:
        doc.save(str(docx_path))


def shrink_wide_tables(docx_path, min_cols=4, font_pt=9):
    """Reduce font size in tables with *min_cols* or more columns.

    Wide tables with many columns often can't fit their content at the
    default body font size.  This rewrites every run in qualifying tables
    to *font_pt* so that the Lua-filter column proportions have enough
    room to work.

    Requires python-docx; silently skips if the package is unavailable.
    """
    try:
        from docx import Document
        from docx.shared import Pt
    except ImportError:
        return

    doc = Document(str(docx_path))
    modified = False

    for table in doc.tables:
        if len(table.columns) >= min_cols:
            for row in table.rows:
                for cell in row.cells:
                    for paragraph in cell.paragraphs:
                        for run in paragraph.runs:
                            run.font.size = Pt(font_pt)
            modified = True

    if modified:
        doc.save(str(docx_path))
