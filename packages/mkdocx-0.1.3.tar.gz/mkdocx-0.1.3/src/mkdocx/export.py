"""Core export logic: convert markdown files to DOCX via pandoc."""

import subprocess
import tempfile
from importlib import resources
from pathlib import Path

from .postprocess import disable_banded_columns, shrink_wide_tables
from .preprocess import parse_frontmatter, preprocess_markdown


def _lua_filter_path():
    """Return the path to the bundled docx.lua filter."""
    return resources.files("mkdocx") / "filters" / "docx.lua"


def collect_markdown_files(directory):
    """Recursively collect all .md files in a directory."""
    return sorted(directory.rglob("*.md"))


def has_tag(file_path, tag):
    """Check if a markdown file has the given tag in its frontmatter."""
    content = file_path.read_text(encoding="utf-8")
    frontmatter, _ = parse_frontmatter(content)
    tags = frontmatter.get("tags", [])
    return isinstance(tags, list) and tag in tags


def export_file(input_path, output_path, *, pandoc_bin, project_root,
                site_url, variables, keep_heading_numbers=False):
    """Export a single markdown file to DOCX."""
    output_path.parent.mkdir(parents=True, exist_ok=True)

    content = input_path.read_text(encoding="utf-8")
    frontmatter, body = parse_frontmatter(content)

    title = frontmatter.get("title", input_path.stem.replace("-", " ").title())
    cleaned = preprocess_markdown(
        body, variables,
        input_path=input_path, project_root=project_root, site_url=site_url,
        keep_heading_numbers=keep_heading_numbers,
    )

    lua_filter = _lua_filter_path()

    with tempfile.TemporaryDirectory() as tmp_dir:
        md_file = Path(tmp_dir) / "input.md"
        md_file.write_text(cleaned, encoding="utf-8")

        cmd = [
            pandoc_bin,
            str(md_file),
            "-o",
            str(output_path),
            "--from=markdown+fenced_divs",
            "--to=docx",
            f"--metadata=title:{title}",
            "--metadata=lang:en-GB",
        ]
        if lua_filter.is_file():
            cmd.append(f"--lua-filter={lua_filter}")

        subprocess.run(cmd, check=True)

    disable_banded_columns(output_path)
    shrink_wide_tables(output_path)
    print(f"Exported: {output_path}")
