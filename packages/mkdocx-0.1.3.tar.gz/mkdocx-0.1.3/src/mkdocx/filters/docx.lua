-- Pandoc Lua filter for DOCX export from MkDocs markdown.
--
-- Handles:
--   1. <br/> HTML tags -> real line breaks (fixes table cell wrapping)
--   2. Admonition fenced divs -> visually distinct blocks with icons
--   3. Content-aware table column widths

-- Convert HTML <br> / <br/> / <br /> tags to Word line breaks.
function RawInline(el)
  if el.format == "html" and el.text:match("^%s*<br%s*/?>%s*$") then
    return pandoc.LineBreak()
  end
end

-- Balance table column widths based on content.
--
-- Two measurements per column:
--   min_w    – longest single word (hard floor; prevents mid-word wrapping).
--             Header words are scaled 1.3× because bold text renders wider.
--   max_line – longest individual line in any cell.  Lines are delimited by
--             LineBreak elements (from <br/> conversion).  We walk the AST
--             directly since pandoc.utils.stringify flattens LineBreak to a
--             space rather than a newline.
--
-- Final weight = floor + (max_line − floor) × GROWTH
--   → guarantees every column can display its longest word
--   → distributes remaining space toward content-heavy columns
-- A 5 % floor stops any column from collapsing entirely.

-- Walk a cell's inline AST and return a list of text lines, splitting on
-- LineBreak / SoftBreak elements.
local function cell_lines(cell)
  local lines = {}
  local cur = ""

  local function walk_inlines(inlines)
    for _, il in ipairs(inlines) do
      if il.t == "LineBreak" or il.t == "SoftBreak" then
        table.insert(lines, cur)
        cur = ""
      elseif il.t == "Str" then
        cur = cur .. il.text
      elseif il.t == "Space" then
        cur = cur .. " "
      elseif il.content then   -- Strong, Emph, Link, Span, …
        walk_inlines(il.content)
      end
    end
  end

  for _, block in ipairs(cell.contents) do
    if block.content then          -- Para / Plain
      walk_inlines(block.content)
    end
    if cur ~= "" then
      table.insert(lines, cur)
      cur = ""
    end
  end
  if cur ~= "" then table.insert(lines, cur) end
  return lines
end

function Table(el)
  local num_cols = #el.colspecs
  if num_cols == 0 then return end

  local min_w    = {}   -- longest word per column (chars, bold-adjusted)
  local max_line = {}   -- longest single line per column

  for i = 1, num_cols do
    min_w[i]    = 0
    max_line[i] = 0
  end

  -- bold_factor accounts for bold text rendering wider than regular text.
  local function measure_row(row, bold_factor)
    for i, cell in ipairs(row.cells) do
      if i <= num_cols then
        local lines = cell_lines(cell)
        for _, line in ipairs(lines) do
          local trimmed = line:match("^%s*(.-)%s*$") or ""
          if #trimmed > max_line[i] then
            max_line[i] = #trimmed
          end
          for word in trimmed:gmatch("%S+") do
            local wlen = math.ceil(#word * bold_factor)
            if wlen > min_w[i] then
              min_w[i] = wlen
            end
          end
        end
      end
    end
  end

  -- Header rows get a bold multiplier
  io.stderr:write(string.format("Header rows: %d, Body sections: %d\n",
    #el.head.rows, #el.bodies))
  for _, row in ipairs(el.head.rows) do
    measure_row(row, 1.3)
  end
  -- Body rows at normal width
  for _, tbody in ipairs(el.bodies) do
    for _, row in ipairs(tbody.body) do
      measure_row(row, 1.0)
    end
  end

  -- Build weights: guarantee floor, distribute extra moderately
  local PADDING = 2
  local GROWTH  = 0.3
  local weights = {}
  local total   = 0

  for i = 1, num_cols do
    local floor = min_w[i] + PADDING
    local extra = math.max(0, max_line[i] - floor)
    weights[i] = floor + extra * GROWTH
    total = total + weights[i]
  end

  if total > 0 then
    -- Normalise with a 5 % minimum per column
    local adjusted = {}
    local adj_total = 0
    for i = 1, num_cols do
      adjusted[i] = math.max(weights[i] / total, 0.05)
      adj_total = adj_total + adjusted[i]
    end
    -- Debug: show all measurements
    local d_min = "  min_w:   "
    local d_max = "  max_line:"
    local d_wt  = "  weights: "
    for i = 1, num_cols do
      d_min = d_min .. string.format(" %3d", min_w[i])
      d_max = d_max .. string.format(" %3d", max_line[i])
      d_wt  = d_wt  .. string.format(" %5.1f", weights[i])
    end
    io.stderr:write(d_min .. "\n" .. d_max .. "\n" .. d_wt .. "\n")

    local debug = "  widths:  "
    for i = 1, num_cols do
      local w = adjusted[i] / adj_total
      el.colspecs[i] = {el.colspecs[i][1], w}
      debug = debug .. string.format(" %3.0f%%", w * 100)
    end
    io.stderr:write(debug .. "\n")
  end

  return el
end

-- Convert admonition fenced divs into styled blocks.
-- Input divs look like:  ::: {.admonition .warning}
-- The first paragraph is expected to be the bold title with icon.
function Div(el)
  if el.classes:includes("admonition") then
    local blocks = {}

    -- Open with a horizontal rule
    table.insert(blocks, pandoc.HorizontalRule())

    -- Pass through all child blocks (title paragraph + content)
    for _, block in ipairs(el.content) do
      table.insert(blocks, block)
    end

    -- Close with a horizontal rule
    table.insert(blocks, pandoc.HorizontalRule())

    return blocks
  end
end
