"""Markdown preprocessing: macros, links, admonitions, tables, headings."""

import re

import yaml


def parse_frontmatter(content):
    """Split markdown into (frontmatter_dict, body_string)."""
    match = re.match(r"^---\s*\n(.*?)\n---\s*\n(.*)", content, re.DOTALL)
    if match:
        return yaml.safe_load(match.group(1)) or {}, match.group(2)
    return {}, content


def resolve_macros(text, variables):
    """Replace {{ key }} placeholders with values from mkdocs.yml extra."""
    for key, value in variables.items():
        text = text.replace("{{" + key + "}}", str(value))
        text = text.replace("{{ " + key + " }}", str(value))
    return text


def resolve_relative_links(text, input_path, project_root, site_url):
    """Convert relative .md links to full handbook URLs.

    External / fully-qualified links are left untouched.  Relative links
    are resolved against the input file's location inside the ``docs/``
    directory and converted to the MkDocs URL scheme
    (``some-page.md`` -> ``<site_url>/path/to/some-page/``).
    """
    if not site_url:
        return text

    docs_dir = project_root / "docs"
    try:
        rel_dir = input_path.parent.relative_to(docs_dir).as_posix()
    except ValueError:
        return text  # input file is not under docs/

    if rel_dir == ".":
        rel_dir = ""

    def _resolve(m):
        link_text = m.group(1)
        url = m.group(2)

        # Leave external / absolute / anchor-only links alone
        if re.match(r"^(https?://|//|mailto:|#)", url):
            return m.group(0)

        # Separate any #anchor
        anchor = ""
        if "#" in url:
            url, anchor = url.rsplit("#", 1)
            anchor = "#" + anchor

        # Only rewrite .md links
        if not url.endswith(".md"):
            return m.group(0)

        # Build path relative to docs/
        full_rel = f"{rel_dir}/{url}" if rel_dir else url

        # Normalise (resolve .. / .)
        parts = []
        for part in full_rel.split("/"):
            if part == "..":
                if parts:
                    parts.pop()
            elif part not in ("", "."):
                parts.append(part)
        normalised = "/".join(parts)

        # Convert to MkDocs URL pattern
        if normalised.endswith("/index.md"):
            mkdocs_path = normalised[: -len("index.md")]
        else:
            mkdocs_path = normalised[: -len(".md")] + "/"

        base = site_url.rstrip("/")
        return f"[{link_text}]({base}/{mkdocs_path}{anchor})"

    return re.sub(r"\[([^\]]*)\]\(([^)]*)\)", _resolve, text)


def strip_heading_numbers(text):
    """Remove leading numbering from headings (e.g. '## 1. Foo' -> '## Foo')."""
    return re.sub(
        r"^(#{1,6})\s+\d+\.\s+",
        r"\1 ",
        text,
        flags=re.MULTILINE,
    )


def shift_headings(text):
    """Shift heading levels down by one (## -> #, ### -> ##, etc.)."""
    def replace_heading(m):
        hashes = m.group(1)
        if len(hashes) > 1:
            return hashes[1:] + " " + m.group(2)
        return m.group(0)

    return re.sub(r"^(#{2,6})\s+(.+)$", replace_heading, text, flags=re.MULTILINE)


def convert_admonitions(text):
    """Convert MkDocs admonitions (!!! / ???) to pandoc fenced divs."""
    icons = {
        "note": "\u2139\ufe0f",
        "info": "\u2139\ufe0f",
        "tip": "\U0001f4a1",
        "warning": "\u26a0\ufe0f",
        "danger": "\U0001f6a8",
        "example": "\U0001f4cb",
    }

    lines = text.split("\n")
    result = []
    i = 0

    while i < len(lines):
        match = re.match(
            r'^(\?{3}|!{3})\s+(\w+)(?:\s+"([^"]*)")?\s*$', lines[i]
        )
        if match:
            adm_type = match.group(2)
            title = match.group(3) or adm_type.title()
            icon = icons.get(adm_type, "\U0001f4cc")

            content = []
            i += 1
            while i < len(lines):
                if lines[i].startswith("    "):
                    content.append(lines[i][4:])
                    i += 1
                elif (
                    lines[i].strip() == ""
                    and i + 1 < len(lines)
                    and lines[i + 1].startswith("    ")
                ):
                    content.append("")
                    i += 1
                else:
                    break

            result.append("")
            result.append(f"::: {{.admonition .{adm_type}}}")
            result.append(f"**{icon} {title}**")
            result.append("")
            for line in content:
                result.append(line)
            result.append(":::")
            result.append("")
        else:
            result.append(lines[i])
            i += 1

    return "\n".join(result)


def fix_empty_header_tables(text):
    """Promote first data row to header when the header row is empty.

    MkDocs Material uses empty header rows as a workaround for headerless
    tables.  Word renders these as a blank row, so we swap the empty header
    with the first data row.
    """
    lines = text.split("\n")
    result = []
    i = 0

    while i < len(lines):
        # Detect: empty-cell header row followed by separator row
        if (
            i + 2 < len(lines)
            and re.match(r"^\|(\s*\|)+\s*$", lines[i])
            and re.match(r"^[|\s:-]+$", lines[i + 1])
            and "-" in lines[i + 1]
        ):
            separator = lines[i + 1]
            i += 2  # skip empty header + separator
            if i < len(lines) and lines[i].startswith("|"):
                result.append(lines[i])   # promote data row to header
                result.append(separator)
                i += 1
        else:
            result.append(lines[i])
            i += 1

    return "\n".join(result)


def strip_abbreviations(text):
    """Remove MkDocs *[ABBR]: definition lines."""
    return re.sub(r"^\*\[.*?\]:.*$", "", text, flags=re.MULTILINE)


def preprocess_markdown(body, variables, *, input_path=None,
                        project_root=None, site_url="",
                        keep_heading_numbers=False):
    """Prepare markdown for pandoc."""
    text = resolve_macros(body, variables)
    if input_path and project_root:
        text = resolve_relative_links(text, input_path, project_root, site_url)
    text = convert_admonitions(text)
    text = strip_abbreviations(text)
    text = fix_empty_header_tables(text)
    if not keep_heading_numbers:
        text = strip_heading_numbers(text)
    text = shift_headings(text)
    return re.sub(r"\n{3,}", "\n\n", text).strip()
