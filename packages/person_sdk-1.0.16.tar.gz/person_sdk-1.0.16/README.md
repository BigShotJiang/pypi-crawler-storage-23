# person-sdk

Python SDK for the [person.run](https://person.run) API.

## Install

```bash
pip install person-sdk
```

With Pydantic models for typed responses:

```bash
pip install person-sdk[models]
```

## Quickstart

```python
from person_sdk import PersonClient

client = PersonClient(
    api_key="your-api-key",
    default_tenant_id="your-tenant-id",
)

persona = client.create_persona(seed={
    "firstName": "Aria",
    "lastName": "Chen",
    "age": 32,
    "location": "San Francisco",
    "baseOccupation": "Product designer",
})

wiki_persona = client.create_wikipedia_persona(
    "https://en.wikipedia.org/wiki/Ada_Lovelace",
    idempotency_key="wiki-import-ada-lovelace",
)

wiki_job = client.create_wikipedia_persona(
    "https://en.wikipedia.org/wiki/Alan_Turing",
    mode="async",
    response_url="https://example.com/persona-callback",
)
wiki_job_status = client.get_wikipedia_persona_create_job(wiki_job["jobId"])

reply = client.prompt(
    persona_id=wiki_persona["persona"]["id"],
    user_prompt="How do you approach design challenges?",
)
print(reply["response"])
```

## Features

- Auto-generated Pydantic models from OpenAPI spec (optional)
- Built-in retries with exponential backoff on 429/5xx
- `default_tenant_id` to avoid passing tenant on every call
- Full coverage: personas, prompting, timeline, populations, and studies
- Zero required dependencies — stdlib only

## License

MIT
