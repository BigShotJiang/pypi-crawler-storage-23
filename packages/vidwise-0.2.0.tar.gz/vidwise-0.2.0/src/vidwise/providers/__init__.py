"""AI providers for guide generation."""
