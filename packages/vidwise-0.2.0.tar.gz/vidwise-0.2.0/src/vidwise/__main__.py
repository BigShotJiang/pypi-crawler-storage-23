"""Allow running vidwise as `python -m vidwise`."""

from vidwise.cli import main

main()
