"""vidwise - Make any video AI-readable.

LLMs can't watch videos. vidwise gives them eyes.
"""

__version__ = "0.2.0"
