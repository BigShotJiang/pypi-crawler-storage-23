"""Basic import and unit tests for mag_logger package."""

import math


def test_version():
    """Package exposes __version__."""
    from mag_logger import __version__

    assert __version__
    parts = __version__.split(".")
    assert len(parts) == 3, f"Expected semver, got {__version__}"


def test_gui_entry_importable():
    """GUI entry module is importable."""
    from mag_logger import gui  # noqa: F401


def test_themes_exist():
    """THEMES dict has dark and light themes with required keys."""
    from mag_logger.mag_logger_app import THEMES

    for name in ("dark", "light"):
        assert name in THEMES
        t = THEMES[name]
        for key in ("bg", "fg", "panel_bg", "accent", "success", "error"):
            assert key in t, f"Missing key '{key}' in theme '{name}'"


def test_mlx_profiles():
    """MLX_PROFILES list contains required profiles."""
    from mag_logger.mag_logger_app import MLX_PROFILES

    assert "FAST" in MLX_PROFILES
    assert "DEFAULT" in MLX_PROFILES
    assert "HIACC" in MLX_PROFILES


def test_magnitude_calculation():
    """Verify |B| = sqrt(bx^2 + by^2 + bz^2) manually."""
    bx, by, bz = 1.0, 0.0, 0.0
    assert math.isclose(math.sqrt(bx**2 + by**2 + bz**2), 1.0)

    bx, by, bz = 1.0, 1.0, 1.0
    expected = math.sqrt(3.0)
    assert math.isclose(math.sqrt(bx**2 + by**2 + bz**2), expected)


def test_scpi_serial_importable():
    """SCPISerial is importable from tools."""
    from neng_scpi_tools.myserial.scpi_serial import SCPISerial  # noqa: F401


def test_scpi_universal_importable():
    """SCPIUniversal is importable from tools."""
    from neng_scpi_tools.myserial.scpi_universal import SCPIUniversal  # noqa: F401


def test_main_importable():
    """MagnetometerGUI class is importable (no Tk display needed)."""
    # We can't instantiate Tk in headless mode but we can import the class.
    import importlib

    mod = importlib.import_module("mag_logger.mag_logger_app")
    assert hasattr(mod, "MagnetometerGUI")
    assert hasattr(mod, "main")
