"""GUI entrypoint.

Launches the Tkinter 3Dmag magnetometer GUI.

(c) 2024-2026 Prof. Flavio ABREU ARAUJO. All rights reserved.
"""

from __future__ import annotations

import sys

from . import __version__
from .mag_logger_app import main as _gui_main

__all__ = ["main"]


def main() -> None:
    """Entry point for ``mag-logger`` command."""
    if len(sys.argv) > 1 and sys.argv[1] in ("--version", "-V"):
        print(f"mag-logger {__version__}")
        return
    _gui_main()


if __name__ == "__main__":
    main()
