"""3Dmag GUI — Real-time 3-axis magnetometer visualizer and data logger.

Professional Tkinter interface with embedded matplotlib plots for live
magnetic field visualization.

Features:
- Real-time Bx, By, Bz and |B| field visualization with matplotlib
- Temperature display on secondary y-axis
- Auto/Force USB/WiFi connection via SCPIUniversal
- WiFi IP discovery via USB
- Sensor type detection (MLX90393 / TLV493D / LIS2MDL / MMC5603 / DUMMY)
- MLX90393 profile switching (FAST / DEFAULT / HIACC)
- Optional CSV data logging
- Configurable sampling rate and max buffer points
- SCPI console with command history
- Dark / Light theme toggle

(c) 2024-2026 Prof. Flavio ABREU ARAUJO. All rights reserved.
"""

from __future__ import annotations

import contextlib
import csv
import math
import threading
import time
import tkinter as tk
from collections import deque
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import matplotlib.animation as animation  # type: ignore
import matplotlib.gridspec as gridspec  # type: ignore
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg  # type: ignore
from matplotlib.figure import Figure  # type: ignore
from neng_scpi_tools.connection_panel import ConnectionPanel  # type: ignore
from neng_scpi_tools.myserial.scpi_universal import SCPIUniversal

from . import __version__

# ===================================================================
# Theme / Colours
# ===================================================================
THEMES = {
    "dark": {
        "bg": "#2b2b2b",
        "fg": "#ffffff",
        "panel_bg": "#333333",
        "field_bg": "#3c3c3c",
        "console_bg": "#1e1e1e",
        "plot_bg": "#1e1e1e",
        "accent": "#0078d4",
        "success": "#107c10",
        "error": "#d83b01",
        "muted": "#888888",
        "grid": "#555555",
        "spine": "#555555",
        "btn_bg": "#0078d4",
        "btn_active": "#005a9e",
        "disabled_bg": "#4a4a4a",
        "green_btn": "#556B2F",
        "green_active": "#6B8E23",
        "red_btn": "#8B0000",
        "red_active": "#DC143C",
        "legend_face": "#333333",
        "legend_edge": "#555555",
        "profile_active": "#1a5276",
        "profile_active_fg": "#aed6f1",
    },
    "light": {
        "bg": "#f0f0f0",
        "fg": "#1e1e1e",
        "panel_bg": "#e8e8e8",
        "field_bg": "#ffffff",
        "console_bg": "#ffffff",
        "plot_bg": "#fafafa",
        "accent": "#0063b1",
        "success": "#0b7a0b",
        "error": "#c50f1f",
        "muted": "#666666",
        "grid": "#cccccc",
        "spine": "#aaaaaa",
        "btn_bg": "#0063b1",
        "btn_active": "#004e8c",
        "disabled_bg": "#b0b0b0",
        "green_btn": "#6B8E23",
        "green_active": "#556B2F",
        "red_btn": "#DC143C",
        "red_active": "#8B0000",
        "legend_face": "#e8e8e8",
        "legend_edge": "#aaaaaa",
        "profile_active": "#aed6f1",
        "profile_active_fg": "#1a5276",
    },
}

_current_theme = "dark"


def _t() -> dict:
    """Return current theme dict."""
    return THEMES[_current_theme]


# MLX90393 profiles
MLX_PROFILES = ["FAST", "DEFAULT", "HIACC"]


class MagnetometerGUI:
    """Professional 3Dmag GUI with real-time magnetic field visualization."""

    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("NEnG 3Dmag Magnetometer (© 2026 Prof. Flavio ABREU ARAUJO)")
        self.root.geometry("1280x820")
        self.root.resizable(True, True)
        self.root.configure(bg=_t()["bg"])

        # --- Connection / communication ---
        self._instr: SCPIUniversal | None = None
        self._scpi_lock = threading.Lock()
        self._connected = False

        # --- Data buffers ---
        self._max_points = 1501
        self._timestamps: deque[float] = deque(maxlen=self._max_points)
        self._bx: deque[float] = deque(maxlen=self._max_points)
        self._by: deque[float] = deque(maxlen=self._max_points)
        self._bz: deque[float] = deque(maxlen=self._max_points)
        self._babs: deque[float] = deque(maxlen=self._max_points)
        self._temp: deque[float] = deque(maxlen=self._max_points)
        self._point_count = 0
        self._log_start_ts: float | None = None

        # --- Data collection thread ---
        self._collect_thread: threading.Thread | None = None
        self._collecting = False
        self._sample_interval_s = 0.200  # default 200 ms

        # --- CSV logging ---
        self._csv_file = None
        self._csv_writer = None
        self._csv_path: str | None = None

        # --- Sensor info ---
        self._sensor_type = ""
        self._active_profile = "DEFAULT"

        # --- SCPI history ---
        self._scpi_history: list[str] = []
        self._scpi_history_index = 0

        # --- Plot text scale ---
        self.text_scale = 1.2

        # Build UI
        self._setup_styles()
        self._create_widgets()
        self.root.protocol("WM_DELETE_WINDOW", self._on_closing)

    # ================================================================
    # Styles
    # ================================================================
    def _setup_styles(self) -> None:
        t = _t()
        style = ttk.Style()
        style.theme_use("clam")
        style.configure(".", background=t["bg"], foreground=t["fg"], fieldbackground=t["field_bg"])
        style.configure("TFrame", background=t["bg"])
        style.configure("TLabel", background=t["bg"], foreground=t["fg"])
        style.configure("TLabelframe", background=t["bg"], foreground=t["fg"])
        style.configure("TLabelframe.Label", background=t["bg"], foreground=t["accent"])
        style.configure("TEntry", fieldbackground=t["field_bg"], foreground=t["fg"])
        style.configure("TCombobox", fieldbackground=t["field_bg"], foreground=t["fg"])
        style.configure("TSpinbox", fieldbackground=t["field_bg"], foreground=t["fg"])
        style.configure("TButton", background=t["btn_bg"], foreground="#ffffff", padding=4)
        style.map(
            "TButton",
            background=[("active", t["btn_active"]), ("disabled", t["disabled_bg"])],
        )
        style.configure(
            "Control.TLabel", background=t["bg"], foreground=t["fg"], font=("Arial", 10)
        )
        style.configure(
            "Value.TLabel", background=t["bg"], foreground=t["fg"], font=("Courier", 13, "bold")
        )
        style.configure("Green.TButton", background=t["green_btn"], foreground="#ffffff")
        style.map(
            "Green.TButton",
            background=[("active", t["green_active"]), ("disabled", t["disabled_bg"])],
        )
        style.configure("Red.TButton", background=t["red_btn"], foreground="#ffffff")
        style.map(
            "Red.TButton",
            background=[("active", t["red_active"]), ("disabled", t["disabled_bg"])],
        )
        style.configure("Profile.TButton", background=t["btn_bg"], foreground="#ffffff", padding=4)
        style.configure(
            "ProfileActive.TButton",
            background=t["profile_active"],
            foreground=t["profile_active_fg"],
            padding=4,
        )
        style.map(
            "ProfileActive.TButton",
            background=[("active", t["profile_active"]), ("disabled", t["disabled_bg"])],
        )

    # ================================================================
    # Widget creation
    # ================================================================
    def _create_widgets(self) -> None:
        # --- Status bar (pack first to reserve space) ---
        status_frame = ttk.Frame(self.root, relief=tk.SUNKEN, borderwidth=1)
        status_frame.pack(fill=tk.X, side=tk.BOTTOM)

        self.status_label = ttk.Label(
            status_frame, text="Ready", foreground=_t()["success"], font=("Arial", 9)
        )
        self.status_label.pack(side=tk.LEFT, padx=10, pady=3)

        self.theme_btn = ttk.Button(
            status_frame, text="☀ Light", command=self._toggle_theme, width=9
        )
        self.theme_btn.pack(side=tk.RIGHT, padx=(0, 10), pady=3)

        self.status_right = ttk.Label(
            status_frame,
            text=f"Points: 0  |  Sensor: -  |  Profile: -  |  v{__version__}",
            font=("Arial", 9),
        )
        self.status_right.pack(side=tk.RIGHT, padx=10, pady=3)

        # --- Main content ---
        content = ttk.Frame(self.root)
        content.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Left panel
        left = ttk.Frame(content)
        left.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 5))

        self._build_connection_panel(left)
        self._build_device_info_panel(left)
        self._build_live_readings_panel(left)
        self._build_profile_panel(left)
        self._build_logging_panel(left)
        self._build_scpi_console(left)

        # Right panel: chart on top, info log below
        right = ttk.Frame(content)
        right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        self._build_chart(right)
        self._build_info_panel(right)

    # ----------------------------------------------------------------
    # Connection panel
    # ----------------------------------------------------------------
    def _build_connection_panel(self, parent: ttk.Frame) -> None:
        self.conn_panel = ConnectionPanel(
            parent,
            default="USB",
            label="Mode:",
            on_connected=self._on_panel_connected,
            on_disconnected=self._on_panel_disconnected,
            on_log=self._add_info,
        )
        self.conn_panel.pack(fill=tk.X, pady=(0, 6))

    # ----------------------------------------------------------------
    # Device info panel
    # ----------------------------------------------------------------
    def _build_device_info_panel(self, parent: ttk.Frame) -> None:
        frame = ttk.LabelFrame(parent, text="Device Info", padding=10)
        frame.pack(fill=tk.X, pady=(0, 6))

        fields = [
            ("Model:", "model"),
            ("Serial:", "serial"),
            ("Firmware:", "firmware"),
            ("Sensor:", "sensor"),
            ("I2C Addr:", "addr"),
        ]
        self._info_vars: dict[str, tk.StringVar] = {}
        for row, (label, key) in enumerate(fields):
            ttk.Label(frame, text=label, style="Control.TLabel").grid(
                row=row, column=0, sticky=tk.W, pady=2
            )
            var = tk.StringVar(value="—")
            self._info_vars[key] = var
            ttk.Label(frame, textvariable=var, style="Control.TLabel").grid(
                row=row, column=1, sticky=tk.W, padx=6
            )

    # ----------------------------------------------------------------
    # Live readings panel
    # ----------------------------------------------------------------
    def _build_live_readings_panel(self, parent: ttk.Frame) -> None:
        frame = ttk.LabelFrame(parent, text="Live Readings", padding=10)
        frame.pack(fill=tk.X, pady=(0, 6))

        channels = [
            ("Bx:", "bx", "G"),
            ("By:", "by", "G"),
            ("Bz:", "bz", "G"),
            ("|B|:", "babs", "G"),
            ("Temp:", "temp", "°C"),
        ]
        self._reading_vars: dict[str, tk.StringVar] = {}
        for row, (label, key, unit) in enumerate(channels):
            ttk.Label(frame, text=label, style="Control.TLabel", width=6).grid(
                row=row, column=0, sticky=tk.W
            )
            var = tk.StringVar(value="—")
            self._reading_vars[key] = var
            ttk.Label(frame, textvariable=var, style="Value.TLabel", width=12).grid(
                row=row, column=1, sticky=tk.W, padx=4
            )
            ttk.Label(frame, text=unit, style="Control.TLabel").grid(row=row, column=2, sticky=tk.W)

    # ----------------------------------------------------------------
    # Sensor profile panel (MLX90393 only)
    # ----------------------------------------------------------------
    def _build_profile_panel(self, parent: ttk.Frame) -> None:
        frame = ttk.LabelFrame(parent, text="Sensor Profile (MLX90393)", padding=10)
        frame.pack(fill=tk.X, pady=(0, 6))

        self._profile_btns: dict[str, ttk.Button] = {}
        btn_row = ttk.Frame(frame)
        btn_row.pack(fill=tk.X)
        for prof in MLX_PROFILES:
            btn = ttk.Button(
                btn_row,
                text=prof,
                command=lambda p=prof: self._apply_profile(p),
                state=tk.DISABLED,
                style="Profile.TButton",
            )
            btn.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=2)
            self._profile_btns[prof] = btn

        self._profile_note = ttk.Label(
            frame,
            text="Connect to enable",
            style="Control.TLabel",
            foreground=_t()["muted"],
            font=("Arial", 8),
        )
        self._profile_note.pack(pady=(4, 0))

    # ----------------------------------------------------------------
    # Data logging panel
    # ----------------------------------------------------------------
    def _build_logging_panel(self, parent: ttk.Frame) -> None:
        frame = ttk.LabelFrame(parent, text="Data Logging", padding=10)
        frame.pack(fill=tk.X, pady=(0, 6))

        # Output file
        ttk.Label(frame, text="Output File:", style="Control.TLabel").grid(
            row=0, column=0, sticky=tk.NW, pady=4
        )
        file_row = ttk.Frame(frame)
        file_row.grid(row=0, column=1, columnspan=2, sticky=tk.EW, padx=5)
        self.log_file_var = tk.StringVar(value="3dmag_log.csv")
        self.log_file_entry = ttk.Entry(file_row, textvariable=self.log_file_var, width=18)
        self.log_file_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(file_row, text="...", command=self._browse_log_file, width=3).pack(
            side=tk.LEFT, padx=2
        )

        # Max points
        ttk.Label(frame, text="Max Points:", style="Control.TLabel").grid(
            row=1, column=0, sticky=tk.W, pady=4
        )
        self.max_points_var = tk.StringVar(value="1501")
        ttk.Spinbox(frame, from_=11, to=10001, textvariable=self.max_points_var, width=8).grid(
            row=1, column=1, sticky=tk.W, padx=5
        )

        # Sample rate
        ttk.Label(frame, text="Rate (ms):", style="Control.TLabel").grid(
            row=2, column=0, sticky=tk.W, pady=4
        )
        self.sample_rate_var = tk.StringVar(value="200")
        ttk.Spinbox(
            frame, from_=50, to=2000, increment=50, textvariable=self.sample_rate_var, width=8
        ).grid(row=2, column=1, sticky=tk.W, padx=5)

        # Start / Stop
        btn_row = ttk.Frame(frame)
        btn_row.grid(row=3, column=0, columnspan=3, pady=(6, 0), sticky=tk.EW)
        self.start_btn = ttk.Button(
            btn_row, text="▶ Start", command=self._start_collecting, style="Green.TButton"
        )
        self.start_btn.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=(0, 4))
        self.stop_btn = ttk.Button(
            btn_row,
            text="⏹ Stop",
            command=self._stop_collecting,
            style="Red.TButton",
            state=tk.DISABLED,
        )
        self.stop_btn.pack(side=tk.LEFT, expand=True, fill=tk.X)

    # ----------------------------------------------------------------
    # SCPI console
    # ----------------------------------------------------------------
    def _build_scpi_console(self, parent: ttk.Frame) -> None:
        frame = ttk.LabelFrame(parent, text="SCPI Console", padding=10)
        frame.pack(fill=tk.X, pady=(0, 6))

        row = ttk.Frame(frame)
        row.pack(fill=tk.X)
        self.scpi_entry = ttk.Entry(row, width=28)
        self.scpi_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 4))
        self.scpi_entry.bind("<Return>", self._send_scpi_command)
        self.scpi_entry.bind("<Up>", self._scpi_history_prev)
        self.scpi_entry.bind("<Down>", self._scpi_history_next)
        ttk.Button(row, text="📤 Send", command=self._send_scpi_command).pack(side=tk.LEFT)

    # ----------------------------------------------------------------
    # Chart (matplotlib)
    # ----------------------------------------------------------------
    def _build_chart(self, parent: ttk.Frame) -> None:
        chart_frame = ttk.LabelFrame(parent, text="Real-time Field Monitor", padding=5)
        chart_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 4))

        t = _t()
        self.fig = Figure(figsize=(8, 6), dpi=96, facecolor=t["bg"])
        gs = gridspec.GridSpec(2, 1, figure=self.fig, hspace=0.08)
        self.fig.subplots_adjust(left=0.12, right=0.88, top=0.97, bottom=0.08)

        # Top: Bx, By, Bz
        self.ax_field = self.fig.add_subplot(gs[0])
        self.ax_field.set_facecolor(t["plot_bg"])
        self.ax_field.set_ylabel("B (G)", fontsize=int(10 * self.text_scale), color=t["fg"])
        self.ax_field.tick_params(colors=t["fg"], labelsize=int(9 * self.text_scale))
        self.ax_field.grid(True, alpha=0.3, color=t["grid"])
        self.ax_field.set_xticklabels([])
        (self.line_bx,) = self.ax_field.plot([], [], "#4fc3f7", label="Bx", linewidth=1.5)
        (self.line_by,) = self.ax_field.plot([], [], "#ffb74d", label="By", linewidth=1.5)
        (self.line_bz,) = self.ax_field.plot([], [], "#81c784", label="Bz", linewidth=1.5)
        self.ax_field.legend(
            loc="upper right",
            ncol=3,
            fontsize=int(9 * self.text_scale),
            facecolor=t["legend_face"],
            edgecolor=t["legend_edge"],
            labelcolor=t["fg"],
        )

        # Bottom: |B| (left axis) and Temp (right axis)
        self.ax_babs = self.fig.add_subplot(gs[1])
        self.ax_babs.set_facecolor(t["plot_bg"])
        self.ax_babs.set_ylabel("|B| (G)", fontsize=int(10 * self.text_scale), color="#ce93d8")
        self.ax_babs.tick_params(colors=t["fg"], labelsize=int(9 * self.text_scale))
        self.ax_babs.grid(True, alpha=0.3, color=t["grid"])
        self.ax_babs.set_xlabel(
            "Elapsed Time (s)", fontsize=int(10 * self.text_scale), color=t["fg"]
        )
        (self.line_babs,) = self.ax_babs.plot([], [], "#ce93d8", label="|B|", linewidth=2)

        # Secondary y-axis for temperature
        self.ax_temp = self.ax_babs.twinx()
        self.ax_temp.set_facecolor(t["plot_bg"])
        self.ax_temp.set_ylabel("T (°C)", fontsize=int(10 * self.text_scale), color="#ef9a9a")
        self.ax_temp.tick_params(colors="#ef9a9a", labelsize=int(9 * self.text_scale))
        (self.line_temp,) = self.ax_temp.plot(
            [], [], "#ef9a9a", label="T", linewidth=1.5, linestyle="--"
        )

        # Combined legend for bottom subplot
        lines_bottom = [self.line_babs, self.line_temp]
        labels_bottom = ["|B|", "Temp"]
        self.ax_babs.legend(
            lines_bottom,
            labels_bottom,
            loc="upper right",
            ncol=2,
            fontsize=int(9 * self.text_scale),
            facecolor=t["legend_face"],
            edgecolor=t["legend_edge"],
            labelcolor=t["fg"],
        )

        for spine in (
            *self.ax_field.spines.values(),
            *self.ax_babs.spines.values(),
            *self.ax_temp.spines.values(),
        ):
            spine.set_color(t["spine"])

        self.canvas = FigureCanvasTkAgg(self.fig, master=chart_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        self.ani = animation.FuncAnimation(
            self.fig,
            self._update_plots,
            interval=200,
            blit=False,
            cache_frame_data=False,
            repeat=True,
        )
        self.canvas.draw_idle()

    # ----------------------------------------------------------------
    # Info / log panel
    # ----------------------------------------------------------------
    def _build_info_panel(self, parent: ttk.Frame) -> None:
        frame = ttk.LabelFrame(parent, text="Information", padding=6)
        frame.pack(fill=tk.BOTH, expand=False, pady=(0, 0))

        self.info_text = tk.Text(
            frame,
            height=7,
            bg=_t()["console_bg"],
            fg=_t()["fg"],
            font=("Courier", 9),
            state=tk.DISABLED,
        )
        self.info_text.pack(fill=tk.BOTH, expand=True, pady=(0, 4))

        btn_row = ttk.Frame(frame)
        btn_row.pack(fill=tk.X)
        ttk.Button(btn_row, text="📋 Copy", command=self._copy_info, width=12).pack(
            side=tk.LEFT, padx=2
        )
        ttk.Button(btn_row, text="🗑 Clear", command=self._clear_info, width=12).pack(
            side=tk.LEFT, padx=2
        )

        self._add_info("3Dmag GUI Ready — click Connect to start\n")

    # ================================================================
    # Connection callbacks
    # ================================================================
    def _on_panel_connected(self, instr: SCPIUniversal, idn: str) -> None:
        """Called by ConnectionPanel on worker thread after successful connection."""
        sensor_type = ""
        sensor_addr = ""
        with contextlib.suppress(Exception):
            sensor_type = instr.query(":SENS:TYPE?").strip()
        with contextlib.suppress(Exception):
            sensor_addr = instr.query(":SENS:ADDR?").strip()

        parts = idn.split(",")
        self._instr = instr
        self._connected = True
        self._sensor_type = sensor_type.upper()

        def _update_ui():
            self._info_vars["model"].set(parts[1].strip() if len(parts) > 1 else "—")
            self._info_vars["serial"].set(parts[2].strip() if len(parts) > 2 else "—")
            self._info_vars["firmware"].set(parts[3].strip() if len(parts) > 3 else "—")
            self._info_vars["sensor"].set(sensor_type or "—")
            self._info_vars["addr"].set(sensor_addr or "—")
            self.start_btn.config(state=tk.NORMAL)
            self._update_profile_buttons()
            self._add_info(f"✓ Connected: {idn}\n")
            self._add_info(f"  Sensor: {sensor_type}  Addr: {sensor_addr}\n")
            self._update_status(f"Connected: {instr.port_name}", _t()["success"])

        self.root.after(0, _update_ui)

    def _on_panel_disconnected(self) -> None:
        """Called by ConnectionPanel on main thread after disconnection."""
        self._connected = False
        self._stop_collecting()
        self._instr = None
        self._sensor_type = ""
        for key in self._info_vars:
            self._info_vars[key].set("—")
        self._update_profile_buttons()
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.DISABLED)
        self._add_info("⏹ Disconnected.\n")
        self._update_status("Ready", _t()["success"])

    # ================================================================
    # Data collection
    # ================================================================
    def _start_collecting(self) -> None:
        if not self._connected or self._collecting:
            return
        try:
            max_pts = int(self.max_points_var.get())
            rate_ms = int(self.sample_rate_var.get())
        except ValueError:
            self._add_info("❌ Invalid max points or sample rate.\n")
            return

        self._max_points = max(11, max_pts)
        self._sample_interval_s = max(0.05, rate_ms / 1000.0)

        # Resize deques
        self._timestamps = deque(maxlen=self._max_points)
        self._bx = deque(maxlen=self._max_points)
        self._by = deque(maxlen=self._max_points)
        self._bz = deque(maxlen=self._max_points)
        self._babs = deque(maxlen=self._max_points)
        self._temp = deque(maxlen=self._max_points)
        self._point_count = 0
        self._log_start_ts = None

        # Open CSV if a path is specified
        csv_path_str = self.log_file_var.get().strip()
        self._csv_file = None
        self._csv_writer = None
        if csv_path_str:
            csv_path = Path(csv_path_str)
            if csv_path.exists():
                resp = messagebox.askyesnocancel(
                    "File exists",
                    f"File already exists:\n{csv_path}\n\nYes: choose new filename\nNo: overwrite\nCancel: abort",
                )
                if resp is None:
                    return
                if resp:
                    new_path = filedialog.asksaveasfilename(
                        defaultextension=".csv",
                        filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
                        initialfile=csv_path.name,
                        initialdir=str(csv_path.parent),
                    )
                    if not new_path:
                        return
                    csv_path = Path(new_path)
                    self.log_file_var.set(str(csv_path))
            try:
                csv_path.parent.mkdir(parents=True, exist_ok=True)
                self._csv_file = csv_path.open("w", newline="")
                self._csv_writer = csv.writer(self._csv_file)
                self._csv_writer.writerow(
                    ["timestamp_s", "bx_G", "by_G", "bz_G", "babs_G", "temp_C"]
                )
            except Exception as exc:
                self._add_info(f"❌ Cannot open CSV: {exc}\n")
                return

        self._collecting = True
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self.log_file_entry.config(state="disabled")

        self._collect_thread = threading.Thread(target=self._collect_loop, daemon=True)
        self._collect_thread.start()
        self._add_info(
            f"▶ Data collection started (rate={rate_ms} ms, max={self._max_points} pts)\n"
        )
        if self._csv_file:
            self._add_info(f"  Logging to: {csv_path_str}\n")

    def _stop_collecting(self) -> None:
        if not self._collecting:
            return
        self._collecting = False
        if self._collect_thread:
            self._collect_thread.join(timeout=3.0)
        if self._csv_file:
            with contextlib.suppress(Exception):
                self._csv_file.close()
            self._csv_file = None
            self._csv_writer = None
        self.start_btn.config(state=tk.NORMAL if self._connected else tk.DISABLED)
        self.stop_btn.config(state=tk.DISABLED)
        self.log_file_entry.config(state="normal")
        self._add_info(f"⏹ Collection stopped — {self._point_count} points total.\n")

    def _collect_loop(self) -> None:
        while self._collecting and self._connected and self._instr:
            t0 = time.monotonic()
            try:
                with self._scpi_lock:
                    raw = self._instr.query(":READ?")
                parts = raw.strip().split(",")
                if len(parts) >= 5:
                    ts = float(parts[0])
                    bx = float(parts[1])
                    by = float(parts[2])
                    bz = float(parts[3])
                    tp = float(parts[4])
                    babs = math.sqrt(bx * bx + by * by + bz * bz)
                    if self._log_start_ts is None:
                        self._log_start_ts = ts
                    elapsed = ts - self._log_start_ts

                    self._timestamps.append(elapsed)
                    self._bx.append(bx)
                    self._by.append(by)
                    self._bz.append(bz)
                    self._babs.append(babs)
                    self._temp.append(tp)
                    self._point_count += 1

                    # Update live readings
                    def _upd(bx=bx, by=by, bz=bz, ba=babs, tp=tp):
                        self._reading_vars["bx"].set(f"{bx:+.5f}")
                        self._reading_vars["by"].set(f"{by:+.5f}")
                        self._reading_vars["bz"].set(f"{bz:+.5f}")
                        self._reading_vars["babs"].set(f"{ba:.5f}")
                        self._reading_vars["temp"].set(f"{tp:.2f}")

                    with contextlib.suppress(Exception):
                        self.root.after(0, _upd)

                    if self._csv_writer:
                        self._csv_writer.writerow(
                            [
                                f"{elapsed:.6f}",
                                f"{bx:.5f}",
                                f"{by:.5f}",
                                f"{bz:.5f}",
                                f"{babs:.5f}",
                                f"{tp:.2f}",
                            ]
                        )

            except Exception as exc:
                self._add_info(f"⚠ Read error: {exc}\n")
                time.sleep(1.0)
                continue

            elapsed_loop = time.monotonic() - t0
            remaining = self._sample_interval_s - elapsed_loop
            if remaining > 0:
                time.sleep(remaining)

    # ================================================================
    # Plot update
    # ================================================================
    def _update_plots(self, _frame) -> None:
        if not self._collecting or len(self._timestamps) < 2:
            return

        xs = list(self._timestamps)
        bx_data = list(self._bx)
        by_data = list(self._by)
        bz_data = list(self._bz)
        babs_data = list(self._babs)
        temp_data = list(self._temp)

        # Top: field components
        self.line_bx.set_data(xs, bx_data)
        self.line_by.set_data(xs, by_data)
        self.line_bz.set_data(xs, bz_data)

        all_field = bx_data + by_data + bz_data
        ymin = min(all_field)
        ymax = max(all_field)
        margin = (ymax - ymin) * 0.1 if ymax > ymin else 0.001
        self.ax_field.set_xlim(xs[0], xs[-1])
        self.ax_field.set_ylim(ymin - margin, ymax + margin)

        # Bottom: |B| and temperature
        self.line_babs.set_data(xs, babs_data)
        babs_min, babs_max = min(babs_data), max(babs_data)
        margin_b = (babs_max - babs_min) * 0.1 if babs_max > babs_min else 0.001
        self.ax_babs.set_xlim(xs[0], xs[-1])
        self.ax_babs.set_ylim(babs_min - margin_b, babs_max + margin_b)

        self.line_temp.set_data(xs, temp_data)
        t_min, t_max = min(temp_data), max(temp_data)
        margin_t = (t_max - t_min) * 0.1 if t_max > t_min else 0.5
        self.ax_temp.set_xlim(xs[0], xs[-1])
        self.ax_temp.set_ylim(t_min - margin_t, t_max + margin_t)

        # Status bar
        sensor_str = self._sensor_type or "-"
        profile_str = self._active_profile if self._sensor_type == "MLX90393" else "-"
        with contextlib.suppress(Exception):
            self.status_right.config(
                text=f"Points: {self._point_count}  |  Sensor: {sensor_str}  |  Profile: {profile_str}  |  v{__version__}"
            )

        self.canvas.draw_idle()

    # ================================================================
    # Sensor profile
    # ================================================================
    def _update_profile_buttons(self) -> None:
        is_mlx = self._sensor_type == "MLX90393"
        state = tk.NORMAL if (is_mlx and self._connected) else tk.DISABLED
        note = (
            ("Active profile: " + self._active_profile)
            if is_mlx
            else "Not supported for this sensor"
        )
        with contextlib.suppress(Exception):
            for prof, btn in self._profile_btns.items():
                btn.config(state=state)
                if is_mlx and self._connected:
                    btn.config(
                        style="ProfileActive.TButton"
                        if prof == self._active_profile
                        else "Profile.TButton"
                    )
            self._profile_note.config(text=note)

    def _apply_profile(self, profile: str) -> None:
        if not self._connected or not self._instr:
            return

        def _do():
            with contextlib.suppress(Exception):
                with self._scpi_lock:
                    self._instr.write(f":SENS:PROF {profile}")
                self._active_profile = profile
                self._add_info(f"✓ Profile set: {profile}\n")
                with contextlib.suppress(Exception):
                    self.root.after(0, self._update_profile_buttons)

        threading.Thread(target=_do, daemon=True).start()

    # ================================================================
    # SCPI console
    # ================================================================
    def _send_scpi_command(self, _event=None) -> None:
        cmd = self.scpi_entry.get().strip()
        if not cmd:
            return
        if not self._scpi_history or self._scpi_history[-1] != cmd:
            self._scpi_history.append(cmd)
        self._scpi_history_index = len(self._scpi_history)
        self.scpi_entry.delete(0, tk.END)

        if not self._connected or not self._instr:
            self._add_info(f"→ {cmd}\n❌ Not connected.\n")
            return

        def _do_send():
            try:
                self._add_info(f"→ {cmd}\n")
                is_query = cmd.strip().endswith("?")
                with self._scpi_lock:
                    if is_query:
                        resp = self._instr.query(cmd)
                        self._add_info(f"← {resp.strip()}\n")
                    else:
                        self._instr.write(cmd)
                        self._add_info("← ✓ OK\n")
            except Exception as exc:
                self._add_info(f"❌ Error: {exc}\n")

        threading.Thread(target=_do_send, daemon=True).start()

    def _scpi_history_prev(self, _event=None) -> None:
        if self._scpi_history and self._scpi_history_index > 0:
            self._scpi_history_index -= 1
            self.scpi_entry.delete(0, tk.END)
            self.scpi_entry.insert(0, self._scpi_history[self._scpi_history_index])

    def _scpi_history_next(self, _event=None) -> None:
        if self._scpi_history and self._scpi_history_index < len(self._scpi_history) - 1:
            self._scpi_history_index += 1
            self.scpi_entry.delete(0, tk.END)
            self.scpi_entry.insert(0, self._scpi_history[self._scpi_history_index])
        elif self._scpi_history_index >= len(self._scpi_history) - 1:
            self._scpi_history_index = len(self._scpi_history)
            self.scpi_entry.delete(0, tk.END)

    # ================================================================
    # Info log helpers
    # ================================================================
    def _add_info(self, text: str) -> None:
        print(text, end="")

        def _do():
            with contextlib.suppress(tk.TclError):
                if not self.info_text.winfo_exists():
                    return
                self.info_text.config(state=tk.NORMAL)
                self.info_text.insert(tk.END, text)
                self.info_text.see(tk.END)
                self.info_text.config(state=tk.DISABLED)

        with contextlib.suppress(Exception):
            self.root.after(0, _do)

    def _copy_info(self) -> None:
        with contextlib.suppress(Exception):
            content = self.info_text.get("1.0", tk.END)
            self.root.clipboard_clear()
            self.root.clipboard_append(content)

    def _clear_info(self) -> None:
        self.info_text.config(state=tk.NORMAL)
        self.info_text.delete("1.0", tk.END)
        self.info_text.config(state=tk.DISABLED)

    def _update_status(self, text: str, color: str | None = None) -> None:
        def _do():
            with contextlib.suppress(tk.TclError):
                if not self.status_label.winfo_exists():
                    return
                self.status_label.config(text=text, foreground=color or _t()["fg"])

        with contextlib.suppress(Exception):
            self.root.after(0, _do)

    # ================================================================
    # CSV file browsing
    # ================================================================
    def _browse_log_file(self) -> None:
        path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
            initialfile=self.log_file_var.get(),
        )
        if path:
            self.log_file_var.set(path)

    # ================================================================
    # Theme toggle
    # ================================================================
    def _toggle_theme(self) -> None:
        global _current_theme
        _current_theme = "light" if _current_theme == "dark" else "dark"
        t = _t()

        self.theme_btn.config(text="🌙 Dark" if _current_theme == "light" else "☀ Light")
        self._setup_styles()
        self.root.configure(bg=t["bg"])

        with contextlib.suppress(tk.TclError):
            self.info_text.config(bg=t["console_bg"], fg=t["fg"])

        self.fig.set_facecolor(t["bg"])
        for ax in (self.ax_field, self.ax_babs):
            ax.set_facecolor(t["plot_bg"])
            ax.tick_params(colors=t["fg"])
            ax.yaxis.label.set_color(t["fg"])
            ax.xaxis.label.set_color(t["fg"])
            ax.grid(True, alpha=0.3, color=t["grid"])
            for spine in ax.spines.values():
                spine.set_color(t["spine"])
            leg = ax.get_legend()
            if leg:
                leg.get_frame().set_facecolor(t["legend_face"])
                leg.get_frame().set_edgecolor(t["legend_edge"])
                for txt in leg.get_texts():
                    txt.set_color(t["fg"])

        self.ax_temp.set_facecolor(t["plot_bg"])
        for spine in self.ax_temp.spines.values():
            spine.set_color(t["spine"])

        with contextlib.suppress(Exception):
            self.canvas.draw_idle()

    # ================================================================
    # Window close
    # ================================================================
    def _on_closing(self) -> None:
        if self._collecting and not messagebox.askyesno(
            "Stop collecting?", "Data collection is running. Stop and exit?"
        ):
            return
        self._stop_collecting()
        with contextlib.suppress(Exception):
            if self._instr:
                self._instr.disconnect()
        with contextlib.suppress(Exception):
            self.ani.event_source.stop()
        self.root.destroy()


def main() -> int:
    """Main entry point."""
    root = tk.Tk()
    app = MagnetometerGUI(root)
    _ = app  # noqa: F841 — keep reference alive for animation
    with contextlib.suppress(KeyboardInterrupt):
        root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
