# Changelog

All notable changes to **mag-logger** will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.1] — 2026-02-22

## [0.1.0] — 2026-02-18

### Added in v0.1.0

- Initial release with `mag-logger` Tkinter GUI with embedded matplotlib charts.
- Real-time Bx, By, Bz field component plot (top subplot, color-coded).
- Real-time |B| magnitude (left axis) and temperature (right axis) plot (bottom subplot).
- Live readings panel: Bx, By, Bz (Gauss), |B| (Gauss), Temperature (°C).
- Connection panel with Auto/Force USB/WiFi and WiFi IP auto-discovery via USB.
- Device info panel: model, serial, firmware, sensor type, I2C address.
- Sensor profile control for MLX90393 (FAST / DEFAULT / HIACC).
- Optional CSV data logging with configurable output file and file browser.
- Configurable sampling rate (50–2000 ms) and max buffer points.
- SCPI console with Up/Down arrow command history navigation.
- Information/log panel with Copy and Clear buttons.
- Dark / Light theme toggle with full matplotlib chart recolouring.
- Thread-safe SCPI communication with `threading.Lock`.
- Clean shutdown on window close.
- CI/CD pipeline configuration (`.gitlab-ci.yml`) with lint, test, build, publish stages.
- Release automation (`release.sh`) for GitLab + PyPI deployment.

[Unreleased]: https://gitlab.flavio.be/flavio/mag-logger/-/compare/v0.1.1...HEAD
[0.1.1]: https://gitlab.flavio.be/flavio/mag-logger/-/compare/v0.1.0...v0.1.1[0.1.0]: https://gitlab.flavio.be/flavio/mag-logger/-/releases/v0.1.0
