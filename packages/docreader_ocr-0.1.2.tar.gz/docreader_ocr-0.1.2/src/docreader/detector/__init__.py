from docreader.detector.base import BaseDetector, Detection
from docreader.detector.yolo_obb import YoloObbDetector

__all__ = ["BaseDetector", "Detection", "YoloObbDetector"]