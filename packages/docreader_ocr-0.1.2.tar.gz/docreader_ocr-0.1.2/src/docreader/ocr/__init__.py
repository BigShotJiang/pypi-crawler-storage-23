from docreader.ocr.base import BaseOcrEngine, OcrResult
from docreader.ocr.easyocr_engine import EasyOcrEngine

__all__ = ["BaseOcrEngine", "OcrResult", "EasyOcrEngine"]