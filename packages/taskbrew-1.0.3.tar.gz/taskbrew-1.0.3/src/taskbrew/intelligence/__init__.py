"""Agent intelligence and capability modules."""
