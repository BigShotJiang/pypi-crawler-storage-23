def help():
    """
    显示 loopwn 工具包的使用说明。
    包括 Looplibc, loop2text, loopcsu 的详细参数和使用示例。
    """
    doc_text = """
================================================================================
                                LOOPWN HELP
================================================================================

[1] Looplibc 模块
--------------------------------------------------------------------------------
功能: 用于自动计算 Libc 基地址，并提供常用函数的地址（如 system, bin_sh）。

使用方法:
    from loopwn import Looplibc

    # 方式 1: 已知 Libc 文件路径和基地址
    libc = Looplibc('./libc.so.6', 0x7ffff7a0d000)

    # 方式 2: 已知 Libc 文件路径、泄露的函数名及其地址
    # 会自动计算基地址
    libc = Looplibc('./libc.so.6', 'puts', 0x7ffff7a8c5a0)

    # 获取地址
    print(hex(libc.address))   # Libc 基地址
    print(hex(libc.system))    # system 函数地址
    print(hex(libc.bin_sh))    # /bin/sh 字符串地址

参数说明:
    libc_path     (str)        : Libc 文件的路径
    func_name_or_base (str/int): 如果是 int，则视为基地址；
                                 如果是 str，则视为泄露的函数名 (需配合 leak_addr)
    leak_addr     (int, optional): 泄露函数的实际内存地址 (仅当第二个参数为函数名时需要)


[2] loop2text 模块
--------------------------------------------------------------------------------
功能: 针对 Ret2Text 漏洞的自动化利用工具。

使用方法:
    from loopwn import loop2text

    # 基础用法 (仅生成 payload)
    payload = loop2text(padding=112, return_addr=0x401186)

    # 高级用法 (自动发送 payload)
    # io 可以是 process() 或 remote() 对象
    loop2text(padding=112, return_addr=0x401186, io=p, send_method='sendline')

参数说明:
    padding     (int/bytes, optional): 
        - 填充长度 (int) 或 具体的填充数据 (bytes)。
        - 如果未设置，会打印提醒，但不会报错 (默认为 0)。
    return_addr (int, optional): 
        - 返回地址 (例如后门函数地址)。
        - 如果未设置，会打印提醒。
    io          (pwntools.tube, optional): 
        - pwntools 的交互对象。如果提供了此参数，会自动发送 payload。
    send_method (str, optional): 
        - 发送方式，默认为 'sendline'。可选值: 'send', 'sendline'。


[3] loopcsu 模块
--------------------------------------------------------------------------------
功能: 针对 ret2csu 技术的自动化利用工具 (通常用于 64 位程序参数传递)。

Payload 栈帧结构 (从低地址到高地址):
    +-------------------------+
    | padding                 |  <- 溢出偏移
    +-------------------------+
    | csu_end (Gadget 1)      |  <- pop rbx; pop rbp; ...
    +-------------------------+
    | 0 (rsp+8)               |  <- 平衡栈帧 (loopcsu 自动填充)
    +-------------------------+
    | rbx (0)                 |  <- loopcsu 自动设为 0
    +-------------------------+
    | rbp (1)                 |  <- loopcsu 自动设为 1
    +-------------------------+
    | r12 (arg1)              |  <- 传入 edi
    +-------------------------+
    | r13 (arg2)              |  <- 传入 rsi
    +-------------------------+
    | r14 (arg3)              |  <- 传入 rdx
    +-------------------------+
    | r15 (call target)       |  <- call [r15]
    +-------------------------+
    | csu_start (Gadget 2)    |  <- mov rdx, r14; ... call ...
    +-------------------------+
    | 0xdeadbeef * 7          |  <- Gadget 2 返回后的栈平衡填充
    +-------------------------+
    | return_addr             |  <- 最终返回地址
    +-------------------------+

使用方法:
    from loopwn import loopcsu

    # 构造 rop chain
    # 假设我们要调用 write(1, got_write, 8)
    payload = loopcsu(
        padding=0x108,         # 必须: 溢出偏移
        csu_end=0x4011da,      # Gadget 1: pop rbx, rbp, r12, r13, r14, r15; ret
        csu_start=0x4011c0,    # Gadget 2: mov rdx, r14; mov rsi, r13; mov edi, r12d; call [r15+rbx*8]
        r12=1,                 # 参数 1 (edi)
        r13=got_write,         # 参数 2 (rsi)
        r14=8,                 # 参数 3 (rdx)
        r15=got_write,         # call 目标 (注意是函数指针的地址，因为是 call [r15])
        return_addr=main_addr  # 执行完后的返回地址
    )

    # 自动发送
    loopcsu(..., io=p, send_method='send')

参数说明:
    csu_end     (int, optional): csu gadget 1 的地址 (负责 pop 寄存器)。
    csu_start   (int, optional): csu gadget 2 的地址 (负责 mov 寄存器并 call)。
    r12         (int, optional): 参数 1 (EDI)。
    r13         (int, optional): 参数 2 (RSI)。
    r14         (int, optional): 参数 3 (RDX)。
    r15         (int, optional): call 调用的函数指针地址 (call [r15])。
    return_addr (int, optional): 利用链结束后的返回地址。
    padding     (int/bytes, 必须): 
        - 填充长度或数据。
    rbx         (int, optional): rbx 的值，默认自动设为 0。
    rbp         (int, optional): rbp 的值，默认自动设为 1 (用于通过 cmp 检查)。
    io          (pwntools.tube, optional): 自动发送的对象。
    send_method (str, optional): 'send' 或 'sendline'。

================================================================================
"""
    print(doc_text)
