# Copyright (c) 2024, Crate.io Inc.
# Distributed under the terms of the AGPLv3 license, see LICENSE.
"""
Rockset Collections API mock, adapting to CrateDB backend.

https://docs.rockset.com/documentation/reference/createcollection
"""
# FIXME.
