(cfr-jobstats)=
# Job statistics collector

Collect and display job statistics.
```shell
export CRATEDB_CLUSTER_URL=crate://crate@localhost:4200/?schema=stats
```
```shell
ctk cfr jobstats collect
ctk cfr jobstats view
ctk cfr jobstats report
ctk cfr jobstats ui
```
