(cfr-info)=
# Cluster information recorder

Record complete outcomes of `ctk info cluster` and `ctk info jobs`.
```shell
ctk cfr info record
```
:::{tip}
See also {ref}`cluster-info`.
:::
