(cfr)=
# CrateDB Cluster Flight Recorder (CFR)

CrateDB Toolkit provides a few utilities about diagnostics and metadata
information collection and recording per `ctk cfr`. 

```{toctree}
:maxdepth: 1

info
jobstats
systable
```
