# Commands

A bundle of ad hoc inquiry utilities, for diagnostics and more.

```{toctree}
:maxdepth: 1

settings
shell
tail
```
