# Adapter Subsystem

Learn how to talk to CrateDB in surrogate to a different database server,
mostly for demonstration purposes.

```{toctree}
:maxdepth: 3

PyMongo Adapter <pymongo>
Rockset Adapter <rockset>
```
