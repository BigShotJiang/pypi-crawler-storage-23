from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="RegisterRequest")



@_attrs_define
class RegisterRequest:
    """ Unified user registration request (local and SSO).

    Used by: /user/register

    Accepts either:
    - 3-word verification code (local users): "purple-mountain-river"
    - SSO JWT token (SSO users): "eyJ..." (long token with dots)

    For local users: given_name and family_name are required
    For SSO users: given_name and family_name are optional (extracted from JWT if not provided)

    Key derivation:
    1. Client derives Ed25519 keypair from password using Argon2id
    2. Client sends Ed25519 public key (signing_key)
    3. Backend derives X25519 encryption key from Ed25519 signing key

        Attributes:
            email (str):
            signing_key (str):
            verification_credential (str):
            given_name (None | str | Unset):
            family_name (None | str | Unset):
            picture (None | str | Unset):
     """

    email: str
    signing_key: str
    verification_credential: str
    given_name: None | str | Unset = UNSET
    family_name: None | str | Unset = UNSET
    picture: None | str | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        email = self.email

        signing_key = self.signing_key

        verification_credential = self.verification_credential

        given_name: None | str | Unset
        if isinstance(self.given_name, Unset):
            given_name = UNSET
        else:
            given_name = self.given_name

        family_name: None | str | Unset
        if isinstance(self.family_name, Unset):
            family_name = UNSET
        else:
            family_name = self.family_name

        picture: None | str | Unset
        if isinstance(self.picture, Unset):
            picture = UNSET
        else:
            picture = self.picture


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "email": email,
            "signing_key": signing_key,
            "verification_credential": verification_credential,
        })
        if given_name is not UNSET:
            field_dict["given_name"] = given_name
        if family_name is not UNSET:
            field_dict["family_name"] = family_name
        if picture is not UNSET:
            field_dict["picture"] = picture

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        email = d.pop("email")

        signing_key = d.pop("signing_key")

        verification_credential = d.pop("verification_credential")

        def _parse_given_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        given_name = _parse_given_name(d.pop("given_name", UNSET))


        def _parse_family_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        family_name = _parse_family_name(d.pop("family_name", UNSET))


        def _parse_picture(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        picture = _parse_picture(d.pop("picture", UNSET))


        register_request = cls(
            email=email,
            signing_key=signing_key,
            verification_credential=verification_credential,
            given_name=given_name,
            family_name=family_name,
            picture=picture,
        )

        return register_request

