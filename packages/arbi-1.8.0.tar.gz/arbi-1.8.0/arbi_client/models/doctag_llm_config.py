from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.doctag_llm_config_api_type import DoctagLLMConfigApiType
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.tag_template import TagTemplate





T = TypeVar("T", bound="DoctagLLMConfig")



@_attrs_define
class DoctagLLMConfig:
    r""" Configuration for DoctagLLM - extracts information from documents based on tag instructions.

        Attributes:
            api_type (DoctagLLMConfigApiType | Unset): The inference type (local or remote). Default:
                DoctagLLMConfigApiType.REMOTE.
            model_name (str | Unset): The name of the non-reasoning model to be used. Default: 'dummy'.
            system_instruction (str | Unset):  Default: 'You are a document analysis assistant. Answer questions based
                strictly on document content.\n\nGuidelines:\n- Only use information explicitly stated in the document\n- Do not
                infer or assume information not present\n- If information is not found, respond with \\"Information not found in
                document.\\"\n- Follow format instructions exactly for each answer\n- Be concise and precise'.
            max_char_context_to_answer (int | Unset): Maximum characters in document for context. Default: 100000.
            temperature (float | Unset): Temperature for factual answers. Default: 0.1.
            max_tokens (int | Unset): Maximum number of tokens allowed for all answers. Default: 2000.
            max_concurrent_docs (int | Unset): Maximum concurrent documents for doctag generation. Default: 10.
            default_metadata_tags (list[TagTemplate] | Unset): Metadata templates used for automatic document metadata
                extraction during indexing.
     """

    api_type: DoctagLLMConfigApiType | Unset = DoctagLLMConfigApiType.REMOTE
    model_name: str | Unset = 'dummy'
    system_instruction: str | Unset = 'You are a document analysis assistant. Answer questions based strictly on document content.\n\nGuidelines:\n- Only use information explicitly stated in the document\n- Do not infer or assume information not present\n- If information is not found, respond with \\"Information not found in document.\\"\n- Follow format instructions exactly for each answer\n- Be concise and precise'
    max_char_context_to_answer: int | Unset = 100000
    temperature: float | Unset = 0.1
    max_tokens: int | Unset = 2000
    max_concurrent_docs: int | Unset = 10
    default_metadata_tags: list[TagTemplate] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.tag_template import TagTemplate
        api_type: str | Unset = UNSET
        if not isinstance(self.api_type, Unset):
            api_type = self.api_type.value


        model_name = self.model_name

        system_instruction = self.system_instruction

        max_char_context_to_answer = self.max_char_context_to_answer

        temperature = self.temperature

        max_tokens = self.max_tokens

        max_concurrent_docs = self.max_concurrent_docs

        default_metadata_tags: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.default_metadata_tags, Unset):
            default_metadata_tags = []
            for default_metadata_tags_item_data in self.default_metadata_tags:
                default_metadata_tags_item = default_metadata_tags_item_data.to_dict()
                default_metadata_tags.append(default_metadata_tags_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if api_type is not UNSET:
            field_dict["API_TYPE"] = api_type
        if model_name is not UNSET:
            field_dict["MODEL_NAME"] = model_name
        if system_instruction is not UNSET:
            field_dict["SYSTEM_INSTRUCTION"] = system_instruction
        if max_char_context_to_answer is not UNSET:
            field_dict["MAX_CHAR_CONTEXT_TO_ANSWER"] = max_char_context_to_answer
        if temperature is not UNSET:
            field_dict["TEMPERATURE"] = temperature
        if max_tokens is not UNSET:
            field_dict["MAX_TOKENS"] = max_tokens
        if max_concurrent_docs is not UNSET:
            field_dict["MAX_CONCURRENT_DOCS"] = max_concurrent_docs
        if default_metadata_tags is not UNSET:
            field_dict["DEFAULT_METADATA_TAGS"] = default_metadata_tags

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.tag_template import TagTemplate
        d = dict(src_dict)
        _api_type = d.pop("API_TYPE", UNSET)
        api_type: DoctagLLMConfigApiType | Unset
        if isinstance(_api_type,  Unset):
            api_type = UNSET
        else:
            api_type = DoctagLLMConfigApiType(_api_type)




        model_name = d.pop("MODEL_NAME", UNSET)

        system_instruction = d.pop("SYSTEM_INSTRUCTION", UNSET)

        max_char_context_to_answer = d.pop("MAX_CHAR_CONTEXT_TO_ANSWER", UNSET)

        temperature = d.pop("TEMPERATURE", UNSET)

        max_tokens = d.pop("MAX_TOKENS", UNSET)

        max_concurrent_docs = d.pop("MAX_CONCURRENT_DOCS", UNSET)

        _default_metadata_tags = d.pop("DEFAULT_METADATA_TAGS", UNSET)
        default_metadata_tags: list[TagTemplate] | Unset = UNSET
        if _default_metadata_tags is not UNSET:
            default_metadata_tags = []
            for default_metadata_tags_item_data in _default_metadata_tags:
                default_metadata_tags_item = TagTemplate.from_dict(default_metadata_tags_item_data)



                default_metadata_tags.append(default_metadata_tags_item)


        doctag_llm_config = cls(
            api_type=api_type,
            model_name=model_name,
            system_instruction=system_instruction,
            max_char_context_to_answer=max_char_context_to_answer,
            temperature=temperature,
            max_tokens=max_tokens,
            max_concurrent_docs=max_concurrent_docs,
            default_metadata_tags=default_metadata_tags,
        )


        doctag_llm_config.additional_properties = d
        return doctag_llm_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
