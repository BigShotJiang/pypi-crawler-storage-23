from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.remove_workspace_user_item import RemoveWorkspaceUserItem





T = TypeVar("T", bound="RemoveWorkspaceUsersRequest")



@_attrs_define
class RemoveWorkspaceUsersRequest:
    """ Request to remove users from a workspace (DELETE /workspace/{id}/users).

        Attributes:
            users (list[RemoveWorkspaceUserItem]):
     """

    users: list[RemoveWorkspaceUserItem]





    def to_dict(self) -> dict[str, Any]:
        from ..models.remove_workspace_user_item import RemoveWorkspaceUserItem
        users = []
        for users_item_data in self.users:
            users_item = users_item_data.to_dict()
            users.append(users_item)




        field_dict: dict[str, Any] = {}

        field_dict.update({
            "users": users,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.remove_workspace_user_item import RemoveWorkspaceUserItem
        d = dict(src_dict)
        users = []
        _users = d.pop("users")
        for users_item_data in (_users):
            users_item = RemoveWorkspaceUserItem.from_dict(users_item_data)



            users.append(users_item)


        remove_workspace_users_request = cls(
            users=users,
        )

        return remove_workspace_users_request

