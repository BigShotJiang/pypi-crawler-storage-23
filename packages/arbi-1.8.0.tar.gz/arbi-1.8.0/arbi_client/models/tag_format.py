from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.tag_format_type import TagFormatType
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="TagFormat")



@_attrs_define
class TagFormat:
    """ Tag format configuration stored as JSONB.

    Type-specific fields:
    - select: options (list of choices, can be single or multi-select)
    - search: tag name is the query, chunks include relevance scores
    - checkbox, text, number, folder: type only

        Attributes:
            type_ (TagFormatType | Unset):  Default: TagFormatType.CHECKBOX.
            options (list[str] | Unset):
     """

    type_: TagFormatType | Unset = TagFormatType.CHECKBOX
    options: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        type_: str | Unset = UNSET
        if not isinstance(self.type_, Unset):
            type_ = self.type_.value


        options: list[str] | Unset = UNSET
        if not isinstance(self.options, Unset):
            options = self.options




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if type_ is not UNSET:
            field_dict["type"] = type_
        if options is not UNSET:
            field_dict["options"] = options

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _type_ = d.pop("type", UNSET)
        type_: TagFormatType | Unset
        if isinstance(_type_,  Unset):
            type_ = UNSET
        else:
            type_ = TagFormatType(_type_)




        options = cast(list[str], d.pop("options", UNSET))


        tag_format = cls(
            type_=type_,
            options=options,
        )


        tag_format.additional_properties = d
        return tag_format

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
