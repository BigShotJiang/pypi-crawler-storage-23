from enum import Enum

class TagFormatType(str, Enum):
    ASSISTANT = "assistant"
    CHECKBOX = "checkbox"
    DATE = "date"
    FOLDER = "folder"
    NUMBER = "number"
    SEARCH = "search"
    SELECT = "select"
    TEXT = "text"

    def __str__(self) -> str:
        return str(self.value)
