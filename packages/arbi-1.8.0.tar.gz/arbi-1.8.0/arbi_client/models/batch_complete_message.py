from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.batch_complete_message_batch_type import BatchCompleteMessageBatchType
from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast






T = TypeVar("T", bound="BatchCompleteMessage")



@_attrs_define
class BatchCompleteMessage:
    """ Notification that a batch operation (upload or doctag generation) completed.

        Attributes:
            batch_type (BatchCompleteMessageBatchType):
            workspace_ext_id (str):
            doc_ext_ids (list[str]):
            type_ (Literal['batch_complete'] | Unset):  Default: 'batch_complete'.
     """

    batch_type: BatchCompleteMessageBatchType
    workspace_ext_id: str
    doc_ext_ids: list[str]
    type_: Literal['batch_complete'] | Unset = 'batch_complete'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        batch_type = self.batch_type.value

        workspace_ext_id = self.workspace_ext_id

        doc_ext_ids = self.doc_ext_ids



        type_ = self.type_


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "batch_type": batch_type,
            "workspace_ext_id": workspace_ext_id,
            "doc_ext_ids": doc_ext_ids,
        })
        if type_ is not UNSET:
            field_dict["type"] = type_

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        batch_type = BatchCompleteMessageBatchType(d.pop("batch_type"))




        workspace_ext_id = d.pop("workspace_ext_id")

        doc_ext_ids = cast(list[str], d.pop("doc_ext_ids"))


        type_ = cast(Literal['batch_complete'] | Unset , d.pop("type", UNSET))
        if type_ != 'batch_complete'and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'batch_complete', got '{type_}'")

        batch_complete_message = cls(
            batch_type=batch_type,
            workspace_ext_id=workspace_ext_id,
            doc_ext_ids=doc_ext_ids,
            type_=type_,
        )


        batch_complete_message.additional_properties = d
        return batch_complete_message

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
