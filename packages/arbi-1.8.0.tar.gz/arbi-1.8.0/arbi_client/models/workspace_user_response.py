from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.workspace_role import WorkspaceRole
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.user_response import UserResponse





T = TypeVar("T", bound="WorkspaceUserResponse")



@_attrs_define
class WorkspaceUserResponse:
    """ User with their role in a workspace.

        Attributes:
            user (UserResponse): Standard user representation used across all endpoints.

                Used for: login response, workspace users, contacts (when registered).
            role (WorkspaceRole): Role of a user within a workspace.
            joined_at (datetime.datetime):
            conversation_count (int | Unset):  Default: 0.
            document_count (int | Unset):  Default: 0.
     """

    user: UserResponse
    role: WorkspaceRole
    joined_at: datetime.datetime
    conversation_count: int | Unset = 0
    document_count: int | Unset = 0
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.user_response import UserResponse
        user = self.user.to_dict()

        role = self.role.value

        joined_at = self.joined_at.isoformat()

        conversation_count = self.conversation_count

        document_count = self.document_count


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "user": user,
            "role": role,
            "joined_at": joined_at,
        })
        if conversation_count is not UNSET:
            field_dict["conversation_count"] = conversation_count
        if document_count is not UNSET:
            field_dict["document_count"] = document_count

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.user_response import UserResponse
        d = dict(src_dict)
        user = UserResponse.from_dict(d.pop("user"))




        role = WorkspaceRole(d.pop("role"))




        joined_at = isoparse(d.pop("joined_at"))




        conversation_count = d.pop("conversation_count", UNSET)

        document_count = d.pop("document_count", UNSET)

        workspace_user_response = cls(
            user=user,
            role=role,
            joined_at=joined_at,
            conversation_count=conversation_count,
            document_count=document_count,
        )


        workspace_user_response.additional_properties = d
        return workspace_user_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
