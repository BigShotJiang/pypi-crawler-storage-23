from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="SSOStatusRequest")



@_attrs_define
class SSOStatusRequest:
    """ SSO status request - checks user registration state and syncs profile.

    Profile fields (given_name, family_name, picture) are optional.
    If user exists, these fields will be updated (profile sync on every login).

        Attributes:
            sso_token (str):
            email (str):
            given_name (None | str | Unset):
            family_name (None | str | Unset):
            picture (None | str | Unset):
     """

    sso_token: str
    email: str
    given_name: None | str | Unset = UNSET
    family_name: None | str | Unset = UNSET
    picture: None | str | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        sso_token = self.sso_token

        email = self.email

        given_name: None | str | Unset
        if isinstance(self.given_name, Unset):
            given_name = UNSET
        else:
            given_name = self.given_name

        family_name: None | str | Unset
        if isinstance(self.family_name, Unset):
            family_name = UNSET
        else:
            family_name = self.family_name

        picture: None | str | Unset
        if isinstance(self.picture, Unset):
            picture = UNSET
        else:
            picture = self.picture


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "sso_token": sso_token,
            "email": email,
        })
        if given_name is not UNSET:
            field_dict["given_name"] = given_name
        if family_name is not UNSET:
            field_dict["family_name"] = family_name
        if picture is not UNSET:
            field_dict["picture"] = picture

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        sso_token = d.pop("sso_token")

        email = d.pop("email")

        def _parse_given_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        given_name = _parse_given_name(d.pop("given_name", UNSET))


        def _parse_family_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        family_name = _parse_family_name(d.pop("family_name", UNSET))


        def _parse_picture(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        picture = _parse_picture(d.pop("picture", UNSET))


        sso_status_request = cls(
            sso_token=sso_token,
            email=email,
            given_name=given_name,
            family_name=family_name,
            picture=picture,
        )

        return sso_status_request

