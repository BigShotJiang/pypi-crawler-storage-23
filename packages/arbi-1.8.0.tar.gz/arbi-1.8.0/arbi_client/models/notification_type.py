from enum import Enum

class NotificationType(str, Enum):
    CONTACT_ACCEPTED = "contact_accepted"
    EMAIL_REPLY = "email_reply"
    USER_MESSAGE = "user_message"
    WORKSPACEUSER_ADDED_COLLABORATOR = "workspaceuser_added_collaborator"
    WORKSPACEUSER_ADDED_GUEST = "workspaceuser_added_guest"
    WORKSPACEUSER_ADDED_OWNER = "workspaceuser_added_owner"
    WORKSPACEUSER_REMOVED = "workspaceuser_removed"
    WORKSPACEUSER_UPDATED_COLLABORATOR = "workspaceuser_updated_collaborator"
    WORKSPACEUSER_UPDATED_GUEST = "workspaceuser_updated_guest"
    WORKSPACEUSER_UPDATED_OWNER = "workspaceuser_updated_owner"

    def __str__(self) -> str:
        return str(self.value)
