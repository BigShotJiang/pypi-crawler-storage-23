from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.chunk import Chunk
  from ..models.parsed_doc_footnotes import ParsedDocFootnotes
  from ..models.parsed_doc_metadata import ParsedDocMetadata





T = TypeVar("T", bound="ParsedDoc")



@_attrs_define
class ParsedDoc:
    """ 
        Attributes:
            metadata (ParsedDocMetadata):
            footnotes (ParsedDocFootnotes | Unset):
            chunks (list[Chunk] | Unset):
     """

    metadata: ParsedDocMetadata
    footnotes: ParsedDocFootnotes | Unset = UNSET
    chunks: list[Chunk] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.parsed_doc_footnotes import ParsedDocFootnotes
        from ..models.parsed_doc_metadata import ParsedDocMetadata
        from ..models.chunk import Chunk
        metadata = self.metadata.to_dict()

        footnotes: dict[str, Any] | Unset = UNSET
        if not isinstance(self.footnotes, Unset):
            footnotes = self.footnotes.to_dict()

        chunks: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.chunks, Unset):
            chunks = []
            for chunks_item_data in self.chunks:
                chunks_item = chunks_item_data.to_dict()
                chunks.append(chunks_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "metadata": metadata,
        })
        if footnotes is not UNSET:
            field_dict["footnotes"] = footnotes
        if chunks is not UNSET:
            field_dict["chunks"] = chunks

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chunk import Chunk
        from ..models.parsed_doc_footnotes import ParsedDocFootnotes
        from ..models.parsed_doc_metadata import ParsedDocMetadata
        d = dict(src_dict)
        metadata = ParsedDocMetadata.from_dict(d.pop("metadata"))




        _footnotes = d.pop("footnotes", UNSET)
        footnotes: ParsedDocFootnotes | Unset
        if isinstance(_footnotes,  Unset):
            footnotes = UNSET
        else:
            footnotes = ParsedDocFootnotes.from_dict(_footnotes)




        _chunks = d.pop("chunks", UNSET)
        chunks: list[Chunk] | Unset = UNSET
        if _chunks is not UNSET:
            chunks = []
            for chunks_item_data in _chunks:
                chunks_item = Chunk.from_dict(chunks_item_data)



                chunks.append(chunks_item)


        parsed_doc = cls(
            metadata=metadata,
            footnotes=footnotes,
            chunks=chunks,
        )


        parsed_doc.additional_properties = d
        return parsed_doc

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
