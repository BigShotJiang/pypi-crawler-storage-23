from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime






T = TypeVar("T", bound="ConversationResponse")



@_attrs_define
class ConversationResponse:
    """ 
        Attributes:
            external_id (str):
            title (None | str):
            created_by_ext_id (str):
            created_at (datetime.datetime):
            updated_at (datetime.datetime):
            message_count (int):
            updated_by_ext_id (None | str | Unset):
            is_shared (bool | Unset):  Default: False.
     """

    external_id: str
    title: None | str
    created_by_ext_id: str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    message_count: int
    updated_by_ext_id: None | str | Unset = UNSET
    is_shared: bool | Unset = False
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        external_id = self.external_id

        title: None | str
        title = self.title

        created_by_ext_id = self.created_by_ext_id

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        message_count = self.message_count

        updated_by_ext_id: None | str | Unset
        if isinstance(self.updated_by_ext_id, Unset):
            updated_by_ext_id = UNSET
        else:
            updated_by_ext_id = self.updated_by_ext_id

        is_shared = self.is_shared


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "external_id": external_id,
            "title": title,
            "created_by_ext_id": created_by_ext_id,
            "created_at": created_at,
            "updated_at": updated_at,
            "message_count": message_count,
        })
        if updated_by_ext_id is not UNSET:
            field_dict["updated_by_ext_id"] = updated_by_ext_id
        if is_shared is not UNSET:
            field_dict["is_shared"] = is_shared

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        external_id = d.pop("external_id")

        def _parse_title(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        title = _parse_title(d.pop("title"))


        created_by_ext_id = d.pop("created_by_ext_id")

        created_at = isoparse(d.pop("created_at"))




        updated_at = isoparse(d.pop("updated_at"))




        message_count = d.pop("message_count")

        def _parse_updated_by_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        updated_by_ext_id = _parse_updated_by_ext_id(d.pop("updated_by_ext_id", UNSET))


        is_shared = d.pop("is_shared", UNSET)

        conversation_response = cls(
            external_id=external_id,
            title=title,
            created_by_ext_id=created_by_ext_id,
            created_at=created_at,
            updated_at=updated_at,
            message_count=message_count,
            updated_by_ext_id=updated_by_ext_id,
            is_shared=is_shared,
        )


        conversation_response.additional_properties = d
        return conversation_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
