from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.agents_config import AgentsConfig
  from ..models.chunker_config import ChunkerConfig
  from ..models.doctag_llm_config import DoctagLLMConfig
  from ..models.embedder_config import EmbedderConfig
  from ..models.evaluator_llm_config import EvaluatorLLMConfig
  from ..models.keyword_embedder_config import KeywordEmbedderConfig
  from ..models.memory_llm_config import MemoryLLMConfig
  from ..models.model_citation_config import ModelCitationConfig
  from ..models.parser_config import ParserConfig
  from ..models.planning_llm_config import PlanningLLMConfig
  from ..models.query_llm_config import QueryLLMConfig
  from ..models.reranker_config import RerankerConfig
  from ..models.retriever_config import RetrieverConfig
  from ..models.review_llm_config import ReviewLLMConfig
  from ..models.summarise_llm_config import SummariseLLMConfig
  from ..models.title_llm_config import TitleLLMConfig
  from ..models.vision_llm_config import VisionLLMConfig





T = TypeVar("T", bound="ConfigUpdateData")



@_attrs_define
class ConfigUpdateData:
    """ Configuration update - only changed parameters need to be provided with proper validation

        Attributes:
            query_llm (None | QueryLLMConfig | Unset):
            review_llm (None | ReviewLLMConfig | Unset):
            agents (AgentsConfig | None | Unset):
            evaluator_llm (EvaluatorLLMConfig | None | Unset):
            title_llm (None | TitleLLMConfig | Unset):
            summarise_llm (None | SummariseLLMConfig | Unset):
            doctag_llm (DoctagLLMConfig | None | Unset):
            memory_llm (MemoryLLMConfig | None | Unset):
            planning_llm (None | PlanningLLMConfig | Unset):
            vision_llm (None | Unset | VisionLLMConfig):
            model_citation (ModelCitationConfig | None | Unset):
            parser (None | ParserConfig | Unset):
            chunker (ChunkerConfig | None | Unset):
            embedder (EmbedderConfig | None | Unset):
            retriever (None | RetrieverConfig | Unset):
            reranker (None | RerankerConfig | Unset):
            keyword_embedder (KeywordEmbedderConfig | None | Unset):
            title (str | Unset):  Default: ''.
            parent_message_ext_id (None | str | Unset):
            tag_ext_id (None | str | Unset):
     """

    query_llm: None | QueryLLMConfig | Unset = UNSET
    review_llm: None | ReviewLLMConfig | Unset = UNSET
    agents: AgentsConfig | None | Unset = UNSET
    evaluator_llm: EvaluatorLLMConfig | None | Unset = UNSET
    title_llm: None | TitleLLMConfig | Unset = UNSET
    summarise_llm: None | SummariseLLMConfig | Unset = UNSET
    doctag_llm: DoctagLLMConfig | None | Unset = UNSET
    memory_llm: MemoryLLMConfig | None | Unset = UNSET
    planning_llm: None | PlanningLLMConfig | Unset = UNSET
    vision_llm: None | Unset | VisionLLMConfig = UNSET
    model_citation: ModelCitationConfig | None | Unset = UNSET
    parser: None | ParserConfig | Unset = UNSET
    chunker: ChunkerConfig | None | Unset = UNSET
    embedder: EmbedderConfig | None | Unset = UNSET
    retriever: None | RetrieverConfig | Unset = UNSET
    reranker: None | RerankerConfig | Unset = UNSET
    keyword_embedder: KeywordEmbedderConfig | None | Unset = UNSET
    title: str | Unset = ''
    parent_message_ext_id: None | str | Unset = UNSET
    tag_ext_id: None | str | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        from ..models.reranker_config import RerankerConfig
        from ..models.chunker_config import ChunkerConfig
        from ..models.vision_llm_config import VisionLLMConfig
        from ..models.memory_llm_config import MemoryLLMConfig
        from ..models.model_citation_config import ModelCitationConfig
        from ..models.planning_llm_config import PlanningLLMConfig
        from ..models.embedder_config import EmbedderConfig
        from ..models.review_llm_config import ReviewLLMConfig
        from ..models.query_llm_config import QueryLLMConfig
        from ..models.agents_config import AgentsConfig
        from ..models.parser_config import ParserConfig
        from ..models.doctag_llm_config import DoctagLLMConfig
        from ..models.retriever_config import RetrieverConfig
        from ..models.evaluator_llm_config import EvaluatorLLMConfig
        from ..models.title_llm_config import TitleLLMConfig
        from ..models.keyword_embedder_config import KeywordEmbedderConfig
        from ..models.summarise_llm_config import SummariseLLMConfig
        query_llm: dict[str, Any] | None | Unset
        if isinstance(self.query_llm, Unset):
            query_llm = UNSET
        elif isinstance(self.query_llm, QueryLLMConfig):
            query_llm = self.query_llm.to_dict()
        else:
            query_llm = self.query_llm

        review_llm: dict[str, Any] | None | Unset
        if isinstance(self.review_llm, Unset):
            review_llm = UNSET
        elif isinstance(self.review_llm, ReviewLLMConfig):
            review_llm = self.review_llm.to_dict()
        else:
            review_llm = self.review_llm

        agents: dict[str, Any] | None | Unset
        if isinstance(self.agents, Unset):
            agents = UNSET
        elif isinstance(self.agents, AgentsConfig):
            agents = self.agents.to_dict()
        else:
            agents = self.agents

        evaluator_llm: dict[str, Any] | None | Unset
        if isinstance(self.evaluator_llm, Unset):
            evaluator_llm = UNSET
        elif isinstance(self.evaluator_llm, EvaluatorLLMConfig):
            evaluator_llm = self.evaluator_llm.to_dict()
        else:
            evaluator_llm = self.evaluator_llm

        title_llm: dict[str, Any] | None | Unset
        if isinstance(self.title_llm, Unset):
            title_llm = UNSET
        elif isinstance(self.title_llm, TitleLLMConfig):
            title_llm = self.title_llm.to_dict()
        else:
            title_llm = self.title_llm

        summarise_llm: dict[str, Any] | None | Unset
        if isinstance(self.summarise_llm, Unset):
            summarise_llm = UNSET
        elif isinstance(self.summarise_llm, SummariseLLMConfig):
            summarise_llm = self.summarise_llm.to_dict()
        else:
            summarise_llm = self.summarise_llm

        doctag_llm: dict[str, Any] | None | Unset
        if isinstance(self.doctag_llm, Unset):
            doctag_llm = UNSET
        elif isinstance(self.doctag_llm, DoctagLLMConfig):
            doctag_llm = self.doctag_llm.to_dict()
        else:
            doctag_llm = self.doctag_llm

        memory_llm: dict[str, Any] | None | Unset
        if isinstance(self.memory_llm, Unset):
            memory_llm = UNSET
        elif isinstance(self.memory_llm, MemoryLLMConfig):
            memory_llm = self.memory_llm.to_dict()
        else:
            memory_llm = self.memory_llm

        planning_llm: dict[str, Any] | None | Unset
        if isinstance(self.planning_llm, Unset):
            planning_llm = UNSET
        elif isinstance(self.planning_llm, PlanningLLMConfig):
            planning_llm = self.planning_llm.to_dict()
        else:
            planning_llm = self.planning_llm

        vision_llm: dict[str, Any] | None | Unset
        if isinstance(self.vision_llm, Unset):
            vision_llm = UNSET
        elif isinstance(self.vision_llm, VisionLLMConfig):
            vision_llm = self.vision_llm.to_dict()
        else:
            vision_llm = self.vision_llm

        model_citation: dict[str, Any] | None | Unset
        if isinstance(self.model_citation, Unset):
            model_citation = UNSET
        elif isinstance(self.model_citation, ModelCitationConfig):
            model_citation = self.model_citation.to_dict()
        else:
            model_citation = self.model_citation

        parser: dict[str, Any] | None | Unset
        if isinstance(self.parser, Unset):
            parser = UNSET
        elif isinstance(self.parser, ParserConfig):
            parser = self.parser.to_dict()
        else:
            parser = self.parser

        chunker: dict[str, Any] | None | Unset
        if isinstance(self.chunker, Unset):
            chunker = UNSET
        elif isinstance(self.chunker, ChunkerConfig):
            chunker = self.chunker.to_dict()
        else:
            chunker = self.chunker

        embedder: dict[str, Any] | None | Unset
        if isinstance(self.embedder, Unset):
            embedder = UNSET
        elif isinstance(self.embedder, EmbedderConfig):
            embedder = self.embedder.to_dict()
        else:
            embedder = self.embedder

        retriever: dict[str, Any] | None | Unset
        if isinstance(self.retriever, Unset):
            retriever = UNSET
        elif isinstance(self.retriever, RetrieverConfig):
            retriever = self.retriever.to_dict()
        else:
            retriever = self.retriever

        reranker: dict[str, Any] | None | Unset
        if isinstance(self.reranker, Unset):
            reranker = UNSET
        elif isinstance(self.reranker, RerankerConfig):
            reranker = self.reranker.to_dict()
        else:
            reranker = self.reranker

        keyword_embedder: dict[str, Any] | None | Unset
        if isinstance(self.keyword_embedder, Unset):
            keyword_embedder = UNSET
        elif isinstance(self.keyword_embedder, KeywordEmbedderConfig):
            keyword_embedder = self.keyword_embedder.to_dict()
        else:
            keyword_embedder = self.keyword_embedder

        title = self.title

        parent_message_ext_id: None | str | Unset
        if isinstance(self.parent_message_ext_id, Unset):
            parent_message_ext_id = UNSET
        else:
            parent_message_ext_id = self.parent_message_ext_id

        tag_ext_id: None | str | Unset
        if isinstance(self.tag_ext_id, Unset):
            tag_ext_id = UNSET
        else:
            tag_ext_id = self.tag_ext_id


        field_dict: dict[str, Any] = {}

        field_dict.update({
        })
        if query_llm is not UNSET:
            field_dict["QueryLLM"] = query_llm
        if review_llm is not UNSET:
            field_dict["ReviewLLM"] = review_llm
        if agents is not UNSET:
            field_dict["Agents"] = agents
        if evaluator_llm is not UNSET:
            field_dict["EvaluatorLLM"] = evaluator_llm
        if title_llm is not UNSET:
            field_dict["TitleLLM"] = title_llm
        if summarise_llm is not UNSET:
            field_dict["SummariseLLM"] = summarise_llm
        if doctag_llm is not UNSET:
            field_dict["DoctagLLM"] = doctag_llm
        if memory_llm is not UNSET:
            field_dict["MemoryLLM"] = memory_llm
        if planning_llm is not UNSET:
            field_dict["PlanningLLM"] = planning_llm
        if vision_llm is not UNSET:
            field_dict["VisionLLM"] = vision_llm
        if model_citation is not UNSET:
            field_dict["ModelCitation"] = model_citation
        if parser is not UNSET:
            field_dict["Parser"] = parser
        if chunker is not UNSET:
            field_dict["Chunker"] = chunker
        if embedder is not UNSET:
            field_dict["Embedder"] = embedder
        if retriever is not UNSET:
            field_dict["Retriever"] = retriever
        if reranker is not UNSET:
            field_dict["Reranker"] = reranker
        if keyword_embedder is not UNSET:
            field_dict["KeywordEmbedder"] = keyword_embedder
        if title is not UNSET:
            field_dict["title"] = title
        if parent_message_ext_id is not UNSET:
            field_dict["parent_message_ext_id"] = parent_message_ext_id
        if tag_ext_id is not UNSET:
            field_dict["tag_ext_id"] = tag_ext_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agents_config import AgentsConfig
        from ..models.chunker_config import ChunkerConfig
        from ..models.doctag_llm_config import DoctagLLMConfig
        from ..models.embedder_config import EmbedderConfig
        from ..models.evaluator_llm_config import EvaluatorLLMConfig
        from ..models.keyword_embedder_config import KeywordEmbedderConfig
        from ..models.memory_llm_config import MemoryLLMConfig
        from ..models.model_citation_config import ModelCitationConfig
        from ..models.parser_config import ParserConfig
        from ..models.planning_llm_config import PlanningLLMConfig
        from ..models.query_llm_config import QueryLLMConfig
        from ..models.reranker_config import RerankerConfig
        from ..models.retriever_config import RetrieverConfig
        from ..models.review_llm_config import ReviewLLMConfig
        from ..models.summarise_llm_config import SummariseLLMConfig
        from ..models.title_llm_config import TitleLLMConfig
        from ..models.vision_llm_config import VisionLLMConfig
        d = dict(src_dict)
        def _parse_query_llm(data: object) -> None | QueryLLMConfig | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                query_llm_type_0 = QueryLLMConfig.from_dict(data)



                return query_llm_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | QueryLLMConfig | Unset, data)

        query_llm = _parse_query_llm(d.pop("QueryLLM", UNSET))


        def _parse_review_llm(data: object) -> None | ReviewLLMConfig | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                review_llm_type_0 = ReviewLLMConfig.from_dict(data)



                return review_llm_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ReviewLLMConfig | Unset, data)

        review_llm = _parse_review_llm(d.pop("ReviewLLM", UNSET))


        def _parse_agents(data: object) -> AgentsConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                agents_type_0 = AgentsConfig.from_dict(data)



                return agents_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AgentsConfig | None | Unset, data)

        agents = _parse_agents(d.pop("Agents", UNSET))


        def _parse_evaluator_llm(data: object) -> EvaluatorLLMConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                evaluator_llm_type_0 = EvaluatorLLMConfig.from_dict(data)



                return evaluator_llm_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(EvaluatorLLMConfig | None | Unset, data)

        evaluator_llm = _parse_evaluator_llm(d.pop("EvaluatorLLM", UNSET))


        def _parse_title_llm(data: object) -> None | TitleLLMConfig | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                title_llm_type_0 = TitleLLMConfig.from_dict(data)



                return title_llm_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TitleLLMConfig | Unset, data)

        title_llm = _parse_title_llm(d.pop("TitleLLM", UNSET))


        def _parse_summarise_llm(data: object) -> None | SummariseLLMConfig | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                summarise_llm_type_0 = SummariseLLMConfig.from_dict(data)



                return summarise_llm_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SummariseLLMConfig | Unset, data)

        summarise_llm = _parse_summarise_llm(d.pop("SummariseLLM", UNSET))


        def _parse_doctag_llm(data: object) -> DoctagLLMConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                doctag_llm_type_0 = DoctagLLMConfig.from_dict(data)



                return doctag_llm_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DoctagLLMConfig | None | Unset, data)

        doctag_llm = _parse_doctag_llm(d.pop("DoctagLLM", UNSET))


        def _parse_memory_llm(data: object) -> MemoryLLMConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                memory_llm_type_0 = MemoryLLMConfig.from_dict(data)



                return memory_llm_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(MemoryLLMConfig | None | Unset, data)

        memory_llm = _parse_memory_llm(d.pop("MemoryLLM", UNSET))


        def _parse_planning_llm(data: object) -> None | PlanningLLMConfig | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                planning_llm_type_0 = PlanningLLMConfig.from_dict(data)



                return planning_llm_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PlanningLLMConfig | Unset, data)

        planning_llm = _parse_planning_llm(d.pop("PlanningLLM", UNSET))


        def _parse_vision_llm(data: object) -> None | Unset | VisionLLMConfig:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                vision_llm_type_0 = VisionLLMConfig.from_dict(data)



                return vision_llm_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | VisionLLMConfig, data)

        vision_llm = _parse_vision_llm(d.pop("VisionLLM", UNSET))


        def _parse_model_citation(data: object) -> ModelCitationConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                model_citation_type_0 = ModelCitationConfig.from_dict(data)



                return model_citation_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ModelCitationConfig | None | Unset, data)

        model_citation = _parse_model_citation(d.pop("ModelCitation", UNSET))


        def _parse_parser(data: object) -> None | ParserConfig | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                parser_type_0 = ParserConfig.from_dict(data)



                return parser_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ParserConfig | Unset, data)

        parser = _parse_parser(d.pop("Parser", UNSET))


        def _parse_chunker(data: object) -> ChunkerConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                chunker_type_0 = ChunkerConfig.from_dict(data)



                return chunker_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChunkerConfig | None | Unset, data)

        chunker = _parse_chunker(d.pop("Chunker", UNSET))


        def _parse_embedder(data: object) -> EmbedderConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                embedder_type_0 = EmbedderConfig.from_dict(data)



                return embedder_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(EmbedderConfig | None | Unset, data)

        embedder = _parse_embedder(d.pop("Embedder", UNSET))


        def _parse_retriever(data: object) -> None | RetrieverConfig | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                retriever_type_0 = RetrieverConfig.from_dict(data)



                return retriever_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | RetrieverConfig | Unset, data)

        retriever = _parse_retriever(d.pop("Retriever", UNSET))


        def _parse_reranker(data: object) -> None | RerankerConfig | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                reranker_type_0 = RerankerConfig.from_dict(data)



                return reranker_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | RerankerConfig | Unset, data)

        reranker = _parse_reranker(d.pop("Reranker", UNSET))


        def _parse_keyword_embedder(data: object) -> KeywordEmbedderConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                keyword_embedder_type_0 = KeywordEmbedderConfig.from_dict(data)



                return keyword_embedder_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(KeywordEmbedderConfig | None | Unset, data)

        keyword_embedder = _parse_keyword_embedder(d.pop("KeywordEmbedder", UNSET))


        title = d.pop("title", UNSET)

        def _parse_parent_message_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        parent_message_ext_id = _parse_parent_message_ext_id(d.pop("parent_message_ext_id", UNSET))


        def _parse_tag_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tag_ext_id = _parse_tag_ext_id(d.pop("tag_ext_id", UNSET))


        config_update_data = cls(
            query_llm=query_llm,
            review_llm=review_llm,
            agents=agents,
            evaluator_llm=evaluator_llm,
            title_llm=title_llm,
            summarise_llm=summarise_llm,
            doctag_llm=doctag_llm,
            memory_llm=memory_llm,
            planning_llm=planning_llm,
            vision_llm=vision_llm,
            model_citation=model_citation,
            parser=parser,
            chunker=chunker,
            embedder=embedder,
            retriever=retriever,
            reranker=reranker,
            keyword_embedder=keyword_embedder,
            title=title,
            parent_message_ext_id=parent_message_ext_id,
            tag_ext_id=tag_ext_id,
        )

        return config_update_data

