from enum import Enum

class DoctagLLMConfigApiType(str, Enum):
    LOCAL = "local"
    REMOTE = "remote"

    def __str__(self) -> str:
        return str(self.value)
