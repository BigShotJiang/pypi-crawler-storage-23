from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast






T = TypeVar("T", bound="AuthResultMessage")



@_attrs_define
class AuthResultMessage:
    """ Server response to authentication.

        Attributes:
            success (bool):
            type_ (Literal['auth_result'] | Unset):  Default: 'auth_result'.
            reason (None | str | Unset):
     """

    success: bool
    type_: Literal['auth_result'] | Unset = 'auth_result'
    reason: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        success = self.success

        type_ = self.type_

        reason: None | str | Unset
        if isinstance(self.reason, Unset):
            reason = UNSET
        else:
            reason = self.reason


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "success": success,
        })
        if type_ is not UNSET:
            field_dict["type"] = type_
        if reason is not UNSET:
            field_dict["reason"] = reason

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        success = d.pop("success")

        type_ = cast(Literal['auth_result'] | Unset , d.pop("type", UNSET))
        if type_ != 'auth_result'and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'auth_result', got '{type_}'")

        def _parse_reason(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        reason = _parse_reason(d.pop("reason", UNSET))


        auth_result_message = cls(
            success=success,
            type_=type_,
            reason=reason,
        )


        auth_result_message.additional_properties = d
        return auth_result_message

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
