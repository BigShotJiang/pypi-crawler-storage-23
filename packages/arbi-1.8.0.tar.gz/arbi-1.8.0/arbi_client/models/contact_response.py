from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.contact_response_status import ContactResponseStatus
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.user_response import UserResponse





T = TypeVar("T", bound="ContactResponse")



@_attrs_define
class ContactResponse:
    """ Contact record - may or may not be a registered user.

        Attributes:
            external_id (str):
            email (str):
            status (ContactResponseStatus):
            created_at (str):
            user (None | Unset | UserResponse):
     """

    external_id: str
    email: str
    status: ContactResponseStatus
    created_at: str
    user: None | Unset | UserResponse = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.user_response import UserResponse
        external_id = self.external_id

        email = self.email

        status = self.status.value

        created_at = self.created_at

        user: dict[str, Any] | None | Unset
        if isinstance(self.user, Unset):
            user = UNSET
        elif isinstance(self.user, UserResponse):
            user = self.user.to_dict()
        else:
            user = self.user


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "external_id": external_id,
            "email": email,
            "status": status,
            "created_at": created_at,
        })
        if user is not UNSET:
            field_dict["user"] = user

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.user_response import UserResponse
        d = dict(src_dict)
        external_id = d.pop("external_id")

        email = d.pop("email")

        status = ContactResponseStatus(d.pop("status"))




        created_at = d.pop("created_at")

        def _parse_user(data: object) -> None | Unset | UserResponse:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                user_type_0 = UserResponse.from_dict(data)



                return user_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UserResponse, data)

        user = _parse_user(d.pop("user", UNSET))


        contact_response = cls(
            external_id=external_id,
            email=email,
            status=status,
            created_at=created_at,
            user=user,
        )


        contact_response.additional_properties = d
        return contact_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
