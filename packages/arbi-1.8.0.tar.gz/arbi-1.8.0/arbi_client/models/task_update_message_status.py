from enum import Enum

class TaskUpdateMessageStatus(str, Enum):
    ANALYSING = "analysing"
    COMPLETED = "completed"
    ENCRYPTING = "encrypting"
    FAILED = "failed"
    INDEXING = "indexing"
    PARSING = "parsing"
    QUEUED = "queued"
    SKIPPED = "skipped"

    def __str__(self) -> str:
        return str(self.value)
