from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="KeywordEmbedderConfig")



@_attrs_define
class KeywordEmbedderConfig:
    """ Configuration for keyword embedder with BM25 scoring.

        Attributes:
            dimension_space (int | Unset): Total dimension space for hash trick (1,048,576 dimensions) Default: 1048576.
            filter_stopwords (bool | Unset): Remove common stopwords to reduce noise Default: True.
            bm25_k1 (float | Unset): BM25 term frequency saturation (1.2-2.0). Higher = more weight on term repetition.
                Default 1.5 works for most cases. Default: 1.5.
            bm25_b (float | Unset): BM25 document length normalization (0.0-1.0). 0=ignore length, 1=full penalty for long
                docs. Default 0.75 is standard. Default: 0.75.
            bm25_avgdl (float | Unset): Average document length in tokens. Adjust based on your documents: chat messages
                ~20-50, articles ~100-300, papers ~1000+ Default: 100.0.
     """

    dimension_space: int | Unset = 1048576
    filter_stopwords: bool | Unset = True
    bm25_k1: float | Unset = 1.5
    bm25_b: float | Unset = 0.75
    bm25_avgdl: float | Unset = 100.0
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        dimension_space = self.dimension_space

        filter_stopwords = self.filter_stopwords

        bm25_k1 = self.bm25_k1

        bm25_b = self.bm25_b

        bm25_avgdl = self.bm25_avgdl


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if dimension_space is not UNSET:
            field_dict["DIMENSION_SPACE"] = dimension_space
        if filter_stopwords is not UNSET:
            field_dict["FILTER_STOPWORDS"] = filter_stopwords
        if bm25_k1 is not UNSET:
            field_dict["BM25_K1"] = bm25_k1
        if bm25_b is not UNSET:
            field_dict["BM25_B"] = bm25_b
        if bm25_avgdl is not UNSET:
            field_dict["BM25_AVGDL"] = bm25_avgdl

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        dimension_space = d.pop("DIMENSION_SPACE", UNSET)

        filter_stopwords = d.pop("FILTER_STOPWORDS", UNSET)

        bm25_k1 = d.pop("BM25_K1", UNSET)

        bm25_b = d.pop("BM25_B", UNSET)

        bm25_avgdl = d.pop("BM25_AVGDL", UNSET)

        keyword_embedder_config = cls(
            dimension_space=dimension_space,
            filter_stopwords=filter_stopwords,
            bm25_k1=bm25_k1,
            bm25_b=bm25_b,
            bm25_avgdl=bm25_avgdl,
        )


        keyword_embedder_config.additional_properties = d
        return keyword_embedder_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
