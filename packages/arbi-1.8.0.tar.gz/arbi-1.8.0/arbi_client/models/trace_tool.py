from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast

if TYPE_CHECKING:
  from ..models.trace_tool_steps_item import TraceToolStepsItem





T = TypeVar("T", bound="TraceTool")



@_attrs_define
class TraceTool:
    """ Execution trace tool that captures the full execution history of a request.

        Attributes:
            name (Literal['trace'] | Unset):  Default: 'trace'.
            description (str | Unset):  Default: 'execution trace'.
            trace_id (None | str | Unset):
            start_time (float | None | Unset):
            duration_seconds (float | None | Unset):
            steps (list[TraceToolStepsItem] | Unset):
     """

    name: Literal['trace'] | Unset = 'trace'
    description: str | Unset = 'execution trace'
    trace_id: None | str | Unset = UNSET
    start_time: float | None | Unset = UNSET
    duration_seconds: float | None | Unset = UNSET
    steps: list[TraceToolStepsItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.trace_tool_steps_item import TraceToolStepsItem
        name = self.name

        description = self.description

        trace_id: None | str | Unset
        if isinstance(self.trace_id, Unset):
            trace_id = UNSET
        else:
            trace_id = self.trace_id

        start_time: float | None | Unset
        if isinstance(self.start_time, Unset):
            start_time = UNSET
        else:
            start_time = self.start_time

        duration_seconds: float | None | Unset
        if isinstance(self.duration_seconds, Unset):
            duration_seconds = UNSET
        else:
            duration_seconds = self.duration_seconds

        steps: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.steps, Unset):
            steps = []
            for steps_item_data in self.steps:
                steps_item = steps_item_data.to_dict()
                steps.append(steps_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if trace_id is not UNSET:
            field_dict["trace_id"] = trace_id
        if start_time is not UNSET:
            field_dict["start_time"] = start_time
        if duration_seconds is not UNSET:
            field_dict["duration_seconds"] = duration_seconds
        if steps is not UNSET:
            field_dict["steps"] = steps

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.trace_tool_steps_item import TraceToolStepsItem
        d = dict(src_dict)
        name = cast(Literal['trace'] | Unset , d.pop("name", UNSET))
        if name != 'trace'and not isinstance(name, Unset):
            raise ValueError(f"name must match const 'trace', got '{name}'")

        description = d.pop("description", UNSET)

        def _parse_trace_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        trace_id = _parse_trace_id(d.pop("trace_id", UNSET))


        def _parse_start_time(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        start_time = _parse_start_time(d.pop("start_time", UNSET))


        def _parse_duration_seconds(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        duration_seconds = _parse_duration_seconds(d.pop("duration_seconds", UNSET))


        _steps = d.pop("steps", UNSET)
        steps: list[TraceToolStepsItem] | Unset = UNSET
        if _steps is not UNSET:
            steps = []
            for steps_item_data in _steps:
                steps_item = TraceToolStepsItem.from_dict(steps_item_data)



                steps.append(steps_item)


        trace_tool = cls(
            name=name,
            description=description,
            trace_id=trace_id,
            start_time=start_time,
            duration_seconds=duration_seconds,
            steps=steps,
        )


        trace_tool.additional_properties = d
        return trace_tool

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
