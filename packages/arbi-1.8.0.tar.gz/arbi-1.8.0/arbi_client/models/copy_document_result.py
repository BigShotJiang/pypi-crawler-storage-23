from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="CopyDocumentResult")



@_attrs_define
class CopyDocumentResult:
    """ 
        Attributes:
            source_doc_ext_id (str):
            success (bool):
            new_doc_ext_id (None | str | Unset):
            error (None | str | Unset):
     """

    source_doc_ext_id: str
    success: bool
    new_doc_ext_id: None | str | Unset = UNSET
    error: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        source_doc_ext_id = self.source_doc_ext_id

        success = self.success

        new_doc_ext_id: None | str | Unset
        if isinstance(self.new_doc_ext_id, Unset):
            new_doc_ext_id = UNSET
        else:
            new_doc_ext_id = self.new_doc_ext_id

        error: None | str | Unset
        if isinstance(self.error, Unset):
            error = UNSET
        else:
            error = self.error


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "source_doc_ext_id": source_doc_ext_id,
            "success": success,
        })
        if new_doc_ext_id is not UNSET:
            field_dict["new_doc_ext_id"] = new_doc_ext_id
        if error is not UNSET:
            field_dict["error"] = error

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        source_doc_ext_id = d.pop("source_doc_ext_id")

        success = d.pop("success")

        def _parse_new_doc_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        new_doc_ext_id = _parse_new_doc_ext_id(d.pop("new_doc_ext_id", UNSET))


        def _parse_error(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error = _parse_error(d.pop("error", UNSET))


        copy_document_result = cls(
            source_doc_ext_id=source_doc_ext_id,
            success=success,
            new_doc_ext_id=new_doc_ext_id,
            error=error,
        )


        copy_document_result.additional_properties = d
        return copy_document_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
