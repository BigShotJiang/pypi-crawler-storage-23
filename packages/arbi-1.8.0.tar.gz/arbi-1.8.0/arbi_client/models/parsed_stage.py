from enum import Enum

class ParsedStage(str, Enum):
    FINAL = "final"
    MARKER = "marker"
    SUBCHUNK = "subchunk"

    def __str__(self) -> str:
        return str(self.value)
