from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="FileObject")



@_attrs_define
class FileObject:
    """ OpenAI-compatible file object response.

        Attributes:
            id (str):
            created_at (int):
            status (str):
            object_ (str | Unset):  Default: 'file'.
            bytes_ (int | None | Unset):
            filename (None | str | Unset):
            purpose (str | Unset):  Default: 'assistants'.
     """

    id: str
    created_at: int
    status: str
    object_: str | Unset = 'file'
    bytes_: int | None | Unset = UNSET
    filename: None | str | Unset = UNSET
    purpose: str | Unset = 'assistants'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        created_at = self.created_at

        status = self.status

        object_ = self.object_

        bytes_: int | None | Unset
        if isinstance(self.bytes_, Unset):
            bytes_ = UNSET
        else:
            bytes_ = self.bytes_

        filename: None | str | Unset
        if isinstance(self.filename, Unset):
            filename = UNSET
        else:
            filename = self.filename

        purpose = self.purpose


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "created_at": created_at,
            "status": status,
        })
        if object_ is not UNSET:
            field_dict["object"] = object_
        if bytes_ is not UNSET:
            field_dict["bytes"] = bytes_
        if filename is not UNSET:
            field_dict["filename"] = filename
        if purpose is not UNSET:
            field_dict["purpose"] = purpose

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        created_at = d.pop("created_at")

        status = d.pop("status")

        object_ = d.pop("object", UNSET)

        def _parse_bytes_(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        bytes_ = _parse_bytes_(d.pop("bytes", UNSET))


        def _parse_filename(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        filename = _parse_filename(d.pop("filename", UNSET))


        purpose = d.pop("purpose", UNSET)

        file_object = cls(
            id=id,
            created_at=created_at,
            status=status,
            object_=object_,
            bytes_=bytes_,
            filename=filename,
            purpose=purpose,
        )


        file_object.additional_properties = d
        return file_object

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
