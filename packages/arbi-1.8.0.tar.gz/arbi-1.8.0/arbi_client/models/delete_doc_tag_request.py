from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast






T = TypeVar("T", bound="DeleteDocTagRequest")



@_attrs_define
class DeleteDocTagRequest:
    """ Remove a tag from one or more documents.

        Attributes:
            tag_ext_id (str):
            doc_ext_ids (list[str]):
     """

    tag_ext_id: str
    doc_ext_ids: list[str]





    def to_dict(self) -> dict[str, Any]:
        tag_ext_id = self.tag_ext_id

        doc_ext_ids = self.doc_ext_ids




        field_dict: dict[str, Any] = {}

        field_dict.update({
            "tag_ext_id": tag_ext_id,
            "doc_ext_ids": doc_ext_ids,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        tag_ext_id = d.pop("tag_ext_id")

        doc_ext_ids = cast(list[str], d.pop("doc_ext_ids"))


        delete_doc_tag_request = cls(
            tag_ext_id=tag_ext_id,
            doc_ext_ids=doc_ext_ids,
        )

        return delete_doc_tag_request

