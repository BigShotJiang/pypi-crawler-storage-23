from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="RetrievalFullContextToolArgs")



@_attrs_define
class RetrievalFullContextToolArgs:
    """ Typed arguments for retrieval full context tool.

        Attributes:
            doc_ext_ids (list[str] | Unset):
            from_ref (None | str | Unset):
            to_ref (None | str | Unset):
     """

    doc_ext_ids: list[str] | Unset = UNSET
    from_ref: None | str | Unset = UNSET
    to_ref: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        doc_ext_ids: list[str] | Unset = UNSET
        if not isinstance(self.doc_ext_ids, Unset):
            doc_ext_ids = self.doc_ext_ids



        from_ref: None | str | Unset
        if isinstance(self.from_ref, Unset):
            from_ref = UNSET
        else:
            from_ref = self.from_ref

        to_ref: None | str | Unset
        if isinstance(self.to_ref, Unset):
            to_ref = UNSET
        else:
            to_ref = self.to_ref


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if doc_ext_ids is not UNSET:
            field_dict["doc_ext_ids"] = doc_ext_ids
        if from_ref is not UNSET:
            field_dict["from_ref"] = from_ref
        if to_ref is not UNSET:
            field_dict["to_ref"] = to_ref

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        doc_ext_ids = cast(list[str], d.pop("doc_ext_ids", UNSET))


        def _parse_from_ref(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        from_ref = _parse_from_ref(d.pop("from_ref", UNSET))


        def _parse_to_ref(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        to_ref = _parse_to_ref(d.pop("to_ref", UNSET))


        retrieval_full_context_tool_args = cls(
            doc_ext_ids=doc_ext_ids,
            from_ref=from_ref,
            to_ref=to_ref,
        )


        retrieval_full_context_tool_args.additional_properties = d
        return retrieval_full_context_tool_args

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
