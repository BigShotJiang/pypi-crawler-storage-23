from enum import Enum

class WorkspaceRole(str, Enum):
    COLLABORATOR = "collaborator"
    GUEST = "guest"
    OWNER = "owner"

    def __str__(self) -> str:
        return str(self.value)
