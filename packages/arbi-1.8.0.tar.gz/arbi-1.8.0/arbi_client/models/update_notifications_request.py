from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.notification_update import NotificationUpdate





T = TypeVar("T", bound="UpdateNotificationsRequest")



@_attrs_define
class UpdateNotificationsRequest:
    """ Bulk update notifications.

        Attributes:
            updates (list[NotificationUpdate]):
     """

    updates: list[NotificationUpdate]





    def to_dict(self) -> dict[str, Any]:
        from ..models.notification_update import NotificationUpdate
        updates = []
        for updates_item_data in self.updates:
            updates_item = updates_item_data.to_dict()
            updates.append(updates_item)




        field_dict: dict[str, Any] = {}

        field_dict.update({
            "updates": updates,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.notification_update import NotificationUpdate
        d = dict(src_dict)
        updates = []
        _updates = d.pop("updates")
        for updates_item_data in (_updates):
            updates_item = NotificationUpdate.from_dict(updates_item_data)



            updates.append(updates_item)


        update_notifications_request = cls(
            updates=updates,
        )

        return update_notifications_request

