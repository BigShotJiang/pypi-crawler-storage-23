from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast






T = TypeVar("T", bound="AddContactsRequest")



@_attrs_define
class AddContactsRequest:
    """ Request model for adding contacts by email.

        Attributes:
            emails (list[str]):
     """

    emails: list[str]





    def to_dict(self) -> dict[str, Any]:
        emails = self.emails




        field_dict: dict[str, Any] = {}

        field_dict.update({
            "emails": emails,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        emails = cast(list[str], d.pop("emails"))


        add_contacts_request = cls(
            emails=emails,
        )

        return add_contacts_request

