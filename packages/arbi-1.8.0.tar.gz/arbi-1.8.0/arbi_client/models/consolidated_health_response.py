from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.models_health_status import ModelsHealthStatus
  from ..models.service_status import ServiceStatus





T = TypeVar("T", bound="ConsolidatedHealthResponse")



@_attrs_define
class ConsolidatedHealthResponse:
    """ Consolidated health response containing all system status and version information

        Attributes:
            status (str):
            backend_git_hash (None | str | Unset):
            frontend_docker_version (None | str | Unset):
            services (list[ServiceStatus] | Unset):
            models_health (ModelsHealthStatus | None | Unset):
            available_models (list[str] | Unset):
     """

    status: str
    backend_git_hash: None | str | Unset = UNSET
    frontend_docker_version: None | str | Unset = UNSET
    services: list[ServiceStatus] | Unset = UNSET
    models_health: ModelsHealthStatus | None | Unset = UNSET
    available_models: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.service_status import ServiceStatus
        from ..models.models_health_status import ModelsHealthStatus
        status = self.status

        backend_git_hash: None | str | Unset
        if isinstance(self.backend_git_hash, Unset):
            backend_git_hash = UNSET
        else:
            backend_git_hash = self.backend_git_hash

        frontend_docker_version: None | str | Unset
        if isinstance(self.frontend_docker_version, Unset):
            frontend_docker_version = UNSET
        else:
            frontend_docker_version = self.frontend_docker_version

        services: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.services, Unset):
            services = []
            for services_item_data in self.services:
                services_item = services_item_data.to_dict()
                services.append(services_item)



        models_health: dict[str, Any] | None | Unset
        if isinstance(self.models_health, Unset):
            models_health = UNSET
        elif isinstance(self.models_health, ModelsHealthStatus):
            models_health = self.models_health.to_dict()
        else:
            models_health = self.models_health

        available_models: list[str] | Unset = UNSET
        if not isinstance(self.available_models, Unset):
            available_models = self.available_models




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "status": status,
        })
        if backend_git_hash is not UNSET:
            field_dict["backend_git_hash"] = backend_git_hash
        if frontend_docker_version is not UNSET:
            field_dict["frontend_docker_version"] = frontend_docker_version
        if services is not UNSET:
            field_dict["services"] = services
        if models_health is not UNSET:
            field_dict["models_health"] = models_health
        if available_models is not UNSET:
            field_dict["available_models"] = available_models

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.models_health_status import ModelsHealthStatus
        from ..models.service_status import ServiceStatus
        d = dict(src_dict)
        status = d.pop("status")

        def _parse_backend_git_hash(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        backend_git_hash = _parse_backend_git_hash(d.pop("backend_git_hash", UNSET))


        def _parse_frontend_docker_version(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        frontend_docker_version = _parse_frontend_docker_version(d.pop("frontend_docker_version", UNSET))


        _services = d.pop("services", UNSET)
        services: list[ServiceStatus] | Unset = UNSET
        if _services is not UNSET:
            services = []
            for services_item_data in _services:
                services_item = ServiceStatus.from_dict(services_item_data)



                services.append(services_item)


        def _parse_models_health(data: object) -> ModelsHealthStatus | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                models_health_type_0 = ModelsHealthStatus.from_dict(data)



                return models_health_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ModelsHealthStatus | None | Unset, data)

        models_health = _parse_models_health(d.pop("models_health", UNSET))


        available_models = cast(list[str], d.pop("available_models", UNSET))


        consolidated_health_response = cls(
            status=status,
            backend_git_hash=backend_git_hash,
            frontend_docker_version=frontend_docker_version,
            services=services,
            models_health=models_health,
            available_models=available_models,
        )


        consolidated_health_response.additional_properties = d
        return consolidated_health_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
