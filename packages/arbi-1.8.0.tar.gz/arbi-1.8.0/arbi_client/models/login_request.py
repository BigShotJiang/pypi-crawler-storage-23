from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="LoginRequest")



@_attrs_define
class LoginRequest:
    """ Unified login request (local and SSO).

    For local users: email + signature + timestamp
    For SSO users: email + signature + timestamp + sso_token

    Authentication flow:
    1. Client derives Ed25519 keypair from password
    2. Client signs "email|timestamp" with Ed25519 private key
    3. Server verifies signature using stored Ed25519 public key
    4. Server derives X25519 from Ed25519 for session key encryption

        Attributes:
            email (str):
            signature (str):
            timestamp (int):
            sso_token (None | str | Unset):
     """

    email: str
    signature: str
    timestamp: int
    sso_token: None | str | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        email = self.email

        signature = self.signature

        timestamp = self.timestamp

        sso_token: None | str | Unset
        if isinstance(self.sso_token, Unset):
            sso_token = UNSET
        else:
            sso_token = self.sso_token


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "email": email,
            "signature": signature,
            "timestamp": timestamp,
        })
        if sso_token is not UNSET:
            field_dict["sso_token"] = sso_token

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        email = d.pop("email")

        signature = d.pop("signature")

        timestamp = d.pop("timestamp")

        def _parse_sso_token(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        sso_token = _parse_sso_token(d.pop("sso_token", UNSET))


        login_request = cls(
            email=email,
            signature=signature,
            timestamp=timestamp,
            sso_token=sso_token,
        )

        return login_request

