from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast

if TYPE_CHECKING:
  from ..models.response_failed_event_response import ResponseFailedEventResponse





T = TypeVar("T", bound="ResponseFailedEvent")



@_attrs_define
class ResponseFailedEvent:
    """ OpenAI response.failed: terminal error event.

        Attributes:
            response (ResponseFailedEventResponse):
            t (float | None | Unset): Seconds elapsed since stream start.
            type_ (Literal['response.failed'] | Unset):  Default: 'response.failed'.
     """

    response: ResponseFailedEventResponse
    t: float | None | Unset = UNSET
    type_: Literal['response.failed'] | Unset = 'response.failed'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.response_failed_event_response import ResponseFailedEventResponse
        response = self.response.to_dict()

        t: float | None | Unset
        if isinstance(self.t, Unset):
            t = UNSET
        else:
            t = self.t

        type_ = self.type_


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "response": response,
        })
        if t is not UNSET:
            field_dict["t"] = t
        if type_ is not UNSET:
            field_dict["type"] = type_

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.response_failed_event_response import ResponseFailedEventResponse
        d = dict(src_dict)
        response = ResponseFailedEventResponse.from_dict(d.pop("response"))




        def _parse_t(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        t = _parse_t(d.pop("t", UNSET))


        type_ = cast(Literal['response.failed'] | Unset , d.pop("type", UNSET))
        if type_ != 'response.failed'and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'response.failed', got '{type_}'")

        response_failed_event = cls(
            response=response,
            t=t,
            type_=type_,
        )


        response_failed_event.additional_properties = d
        return response_failed_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
