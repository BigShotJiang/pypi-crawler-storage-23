from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.retrieval_chunk_tool_args_search_mode_type_0 import RetrievalChunkToolArgsSearchModeType0
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="RetrievalChunkToolArgs")



@_attrs_define
class RetrievalChunkToolArgs:
    """ Typed arguments for retrieval chunk tool.

        Attributes:
            doc_ext_ids (list[str] | Unset):
            search_mode (None | RetrievalChunkToolArgsSearchModeType0 | Unset):
     """

    doc_ext_ids: list[str] | Unset = UNSET
    search_mode: None | RetrievalChunkToolArgsSearchModeType0 | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        doc_ext_ids: list[str] | Unset = UNSET
        if not isinstance(self.doc_ext_ids, Unset):
            doc_ext_ids = self.doc_ext_ids



        search_mode: None | str | Unset
        if isinstance(self.search_mode, Unset):
            search_mode = UNSET
        elif isinstance(self.search_mode, RetrievalChunkToolArgsSearchModeType0):
            search_mode = self.search_mode.value
        else:
            search_mode = self.search_mode


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if doc_ext_ids is not UNSET:
            field_dict["doc_ext_ids"] = doc_ext_ids
        if search_mode is not UNSET:
            field_dict["search_mode"] = search_mode

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        doc_ext_ids = cast(list[str], d.pop("doc_ext_ids", UNSET))


        def _parse_search_mode(data: object) -> None | RetrievalChunkToolArgsSearchModeType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                search_mode_type_0 = RetrievalChunkToolArgsSearchModeType0(data)



                return search_mode_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | RetrievalChunkToolArgsSearchModeType0 | Unset, data)

        search_mode = _parse_search_mode(d.pop("search_mode", UNSET))


        retrieval_chunk_tool_args = cls(
            doc_ext_ids=doc_ext_ids,
            search_mode=search_mode,
        )


        retrieval_chunk_tool_args.additional_properties = d
        return retrieval_chunk_tool_args

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
