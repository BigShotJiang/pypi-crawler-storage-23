from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="SubscriptionStatusResponse")



@_attrs_define
class SubscriptionStatusResponse:
    """ Subscription status response - unified model for all subscription states.

    Status can be:
    - "trialing": User is on trial (has trial_expires, days_remaining)
    - "active": Active Stripe subscription (has plan, amount, currency, etc.)
    - "canceled": Had subscription but canceled (has portal_url)
    - "none": No subscription or trial

        Attributes:
            status (str):
            trial_expires (int | None | Unset):
            days_remaining (int | None | Unset):
            price_id (None | str | Unset):
            plan (None | str | Unset):
            amount (int | None | Unset):
            currency (None | str | Unset):
            current_period_end (int | None | Unset):
            cancel_at_period_end (bool | None | Unset):
            portal_url (None | str | Unset):
            spend (float | None | Unset):
            max_budget (float | None | Unset):
            budget_reset_at (int | None | Unset):
            total_files_mb (float | None | Unset):
            storage_quota_mb (int | None | Unset):
     """

    status: str
    trial_expires: int | None | Unset = UNSET
    days_remaining: int | None | Unset = UNSET
    price_id: None | str | Unset = UNSET
    plan: None | str | Unset = UNSET
    amount: int | None | Unset = UNSET
    currency: None | str | Unset = UNSET
    current_period_end: int | None | Unset = UNSET
    cancel_at_period_end: bool | None | Unset = UNSET
    portal_url: None | str | Unset = UNSET
    spend: float | None | Unset = UNSET
    max_budget: float | None | Unset = UNSET
    budget_reset_at: int | None | Unset = UNSET
    total_files_mb: float | None | Unset = UNSET
    storage_quota_mb: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        status = self.status

        trial_expires: int | None | Unset
        if isinstance(self.trial_expires, Unset):
            trial_expires = UNSET
        else:
            trial_expires = self.trial_expires

        days_remaining: int | None | Unset
        if isinstance(self.days_remaining, Unset):
            days_remaining = UNSET
        else:
            days_remaining = self.days_remaining

        price_id: None | str | Unset
        if isinstance(self.price_id, Unset):
            price_id = UNSET
        else:
            price_id = self.price_id

        plan: None | str | Unset
        if isinstance(self.plan, Unset):
            plan = UNSET
        else:
            plan = self.plan

        amount: int | None | Unset
        if isinstance(self.amount, Unset):
            amount = UNSET
        else:
            amount = self.amount

        currency: None | str | Unset
        if isinstance(self.currency, Unset):
            currency = UNSET
        else:
            currency = self.currency

        current_period_end: int | None | Unset
        if isinstance(self.current_period_end, Unset):
            current_period_end = UNSET
        else:
            current_period_end = self.current_period_end

        cancel_at_period_end: bool | None | Unset
        if isinstance(self.cancel_at_period_end, Unset):
            cancel_at_period_end = UNSET
        else:
            cancel_at_period_end = self.cancel_at_period_end

        portal_url: None | str | Unset
        if isinstance(self.portal_url, Unset):
            portal_url = UNSET
        else:
            portal_url = self.portal_url

        spend: float | None | Unset
        if isinstance(self.spend, Unset):
            spend = UNSET
        else:
            spend = self.spend

        max_budget: float | None | Unset
        if isinstance(self.max_budget, Unset):
            max_budget = UNSET
        else:
            max_budget = self.max_budget

        budget_reset_at: int | None | Unset
        if isinstance(self.budget_reset_at, Unset):
            budget_reset_at = UNSET
        else:
            budget_reset_at = self.budget_reset_at

        total_files_mb: float | None | Unset
        if isinstance(self.total_files_mb, Unset):
            total_files_mb = UNSET
        else:
            total_files_mb = self.total_files_mb

        storage_quota_mb: int | None | Unset
        if isinstance(self.storage_quota_mb, Unset):
            storage_quota_mb = UNSET
        else:
            storage_quota_mb = self.storage_quota_mb


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "status": status,
        })
        if trial_expires is not UNSET:
            field_dict["trial_expires"] = trial_expires
        if days_remaining is not UNSET:
            field_dict["days_remaining"] = days_remaining
        if price_id is not UNSET:
            field_dict["price_id"] = price_id
        if plan is not UNSET:
            field_dict["plan"] = plan
        if amount is not UNSET:
            field_dict["amount"] = amount
        if currency is not UNSET:
            field_dict["currency"] = currency
        if current_period_end is not UNSET:
            field_dict["current_period_end"] = current_period_end
        if cancel_at_period_end is not UNSET:
            field_dict["cancel_at_period_end"] = cancel_at_period_end
        if portal_url is not UNSET:
            field_dict["portal_url"] = portal_url
        if spend is not UNSET:
            field_dict["spend"] = spend
        if max_budget is not UNSET:
            field_dict["max_budget"] = max_budget
        if budget_reset_at is not UNSET:
            field_dict["budget_reset_at"] = budget_reset_at
        if total_files_mb is not UNSET:
            field_dict["total_files_mb"] = total_files_mb
        if storage_quota_mb is not UNSET:
            field_dict["storage_quota_mb"] = storage_quota_mb

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        status = d.pop("status")

        def _parse_trial_expires(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        trial_expires = _parse_trial_expires(d.pop("trial_expires", UNSET))


        def _parse_days_remaining(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        days_remaining = _parse_days_remaining(d.pop("days_remaining", UNSET))


        def _parse_price_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        price_id = _parse_price_id(d.pop("price_id", UNSET))


        def _parse_plan(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        plan = _parse_plan(d.pop("plan", UNSET))


        def _parse_amount(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        amount = _parse_amount(d.pop("amount", UNSET))


        def _parse_currency(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        currency = _parse_currency(d.pop("currency", UNSET))


        def _parse_current_period_end(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        current_period_end = _parse_current_period_end(d.pop("current_period_end", UNSET))


        def _parse_cancel_at_period_end(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        cancel_at_period_end = _parse_cancel_at_period_end(d.pop("cancel_at_period_end", UNSET))


        def _parse_portal_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        portal_url = _parse_portal_url(d.pop("portal_url", UNSET))


        def _parse_spend(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        spend = _parse_spend(d.pop("spend", UNSET))


        def _parse_max_budget(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        max_budget = _parse_max_budget(d.pop("max_budget", UNSET))


        def _parse_budget_reset_at(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        budget_reset_at = _parse_budget_reset_at(d.pop("budget_reset_at", UNSET))


        def _parse_total_files_mb(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        total_files_mb = _parse_total_files_mb(d.pop("total_files_mb", UNSET))


        def _parse_storage_quota_mb(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        storage_quota_mb = _parse_storage_quota_mb(d.pop("storage_quota_mb", UNSET))


        subscription_status_response = cls(
            status=status,
            trial_expires=trial_expires,
            days_remaining=days_remaining,
            price_id=price_id,
            plan=plan,
            amount=amount,
            currency=currency,
            current_period_end=current_period_end,
            cancel_at_period_end=cancel_at_period_end,
            portal_url=portal_url,
            spend=spend,
            max_budget=max_budget,
            budget_reset_at=budget_reset_at,
            total_files_mb=total_files_mb,
            storage_quota_mb=storage_quota_mb,
        )


        subscription_status_response.additional_properties = d
        return subscription_status_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
