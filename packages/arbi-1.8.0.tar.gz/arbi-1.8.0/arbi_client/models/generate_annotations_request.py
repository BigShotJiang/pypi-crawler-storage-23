from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast






T = TypeVar("T", bound="GenerateAnnotationsRequest")



@_attrs_define
class GenerateAnnotationsRequest:
    """ Request to generate AI annotations for documents using tag instructions.

    Creates a matrix of (docs × tags) annotations. Each tag's name is used as
    the instruction/question to answer about each document.

        Attributes:
            tag_ext_ids (list[str]):
            doc_ext_ids (list[str]):
     """

    tag_ext_ids: list[str]
    doc_ext_ids: list[str]





    def to_dict(self) -> dict[str, Any]:
        tag_ext_ids = self.tag_ext_ids



        doc_ext_ids = self.doc_ext_ids




        field_dict: dict[str, Any] = {}

        field_dict.update({
            "tag_ext_ids": tag_ext_ids,
            "doc_ext_ids": doc_ext_ids,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        tag_ext_ids = cast(list[str], d.pop("tag_ext_ids"))


        doc_ext_ids = cast(list[str], d.pop("doc_ext_ids"))


        generate_annotations_request = cls(
            tag_ext_ids=tag_ext_ids,
            doc_ext_ids=doc_ext_ids,
        )

        return generate_annotations_request

