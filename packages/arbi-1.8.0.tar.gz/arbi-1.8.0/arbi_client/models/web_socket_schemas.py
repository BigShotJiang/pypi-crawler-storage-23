from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.auth_message import AuthMessage
  from ..models.auth_result_message import AuthResultMessage
  from ..models.batch_complete_message import BatchCompleteMessage
  from ..models.connection_closed_message import ConnectionClosedMessage
  from ..models.error_message import ErrorMessage
  from ..models.notification_response import NotificationResponse
  from ..models.presence_update_message import PresenceUpdateMessage
  from ..models.send_message_request import SendMessageRequest
  from ..models.task_update_message import TaskUpdateMessage





T = TypeVar("T", bound="WebSocketSchemas")



@_attrs_define
class WebSocketSchemas:
    """ Container for all WebSocket message schemas.

    Each field exposes a message type to the OpenAPI spec so the TS frontend
    can autogenerate types.  The endpoint returns defaults (None) — only the
    schema components matter.

        Attributes:
            auth_result (AuthResultMessage | None | Unset):
            connection_closed (ConnectionClosedMessage | None | Unset):
            presence_update (None | PresenceUpdateMessage | Unset):
            error (ErrorMessage | None | Unset):
            task_update (None | TaskUpdateMessage | Unset):
            batch_complete (BatchCompleteMessage | None | Unset):
            notification (None | NotificationResponse | Unset):
            auth (AuthMessage | None | Unset):
            send_message (None | SendMessageRequest | Unset):
     """

    auth_result: AuthResultMessage | None | Unset = UNSET
    connection_closed: ConnectionClosedMessage | None | Unset = UNSET
    presence_update: None | PresenceUpdateMessage | Unset = UNSET
    error: ErrorMessage | None | Unset = UNSET
    task_update: None | TaskUpdateMessage | Unset = UNSET
    batch_complete: BatchCompleteMessage | None | Unset = UNSET
    notification: None | NotificationResponse | Unset = UNSET
    auth: AuthMessage | None | Unset = UNSET
    send_message: None | SendMessageRequest | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.error_message import ErrorMessage
        from ..models.notification_response import NotificationResponse
        from ..models.send_message_request import SendMessageRequest
        from ..models.auth_result_message import AuthResultMessage
        from ..models.batch_complete_message import BatchCompleteMessage
        from ..models.connection_closed_message import ConnectionClosedMessage
        from ..models.presence_update_message import PresenceUpdateMessage
        from ..models.auth_message import AuthMessage
        from ..models.task_update_message import TaskUpdateMessage
        auth_result: dict[str, Any] | None | Unset
        if isinstance(self.auth_result, Unset):
            auth_result = UNSET
        elif isinstance(self.auth_result, AuthResultMessage):
            auth_result = self.auth_result.to_dict()
        else:
            auth_result = self.auth_result

        connection_closed: dict[str, Any] | None | Unset
        if isinstance(self.connection_closed, Unset):
            connection_closed = UNSET
        elif isinstance(self.connection_closed, ConnectionClosedMessage):
            connection_closed = self.connection_closed.to_dict()
        else:
            connection_closed = self.connection_closed

        presence_update: dict[str, Any] | None | Unset
        if isinstance(self.presence_update, Unset):
            presence_update = UNSET
        elif isinstance(self.presence_update, PresenceUpdateMessage):
            presence_update = self.presence_update.to_dict()
        else:
            presence_update = self.presence_update

        error: dict[str, Any] | None | Unset
        if isinstance(self.error, Unset):
            error = UNSET
        elif isinstance(self.error, ErrorMessage):
            error = self.error.to_dict()
        else:
            error = self.error

        task_update: dict[str, Any] | None | Unset
        if isinstance(self.task_update, Unset):
            task_update = UNSET
        elif isinstance(self.task_update, TaskUpdateMessage):
            task_update = self.task_update.to_dict()
        else:
            task_update = self.task_update

        batch_complete: dict[str, Any] | None | Unset
        if isinstance(self.batch_complete, Unset):
            batch_complete = UNSET
        elif isinstance(self.batch_complete, BatchCompleteMessage):
            batch_complete = self.batch_complete.to_dict()
        else:
            batch_complete = self.batch_complete

        notification: dict[str, Any] | None | Unset
        if isinstance(self.notification, Unset):
            notification = UNSET
        elif isinstance(self.notification, NotificationResponse):
            notification = self.notification.to_dict()
        else:
            notification = self.notification

        auth: dict[str, Any] | None | Unset
        if isinstance(self.auth, Unset):
            auth = UNSET
        elif isinstance(self.auth, AuthMessage):
            auth = self.auth.to_dict()
        else:
            auth = self.auth

        send_message: dict[str, Any] | None | Unset
        if isinstance(self.send_message, Unset):
            send_message = UNSET
        elif isinstance(self.send_message, SendMessageRequest):
            send_message = self.send_message.to_dict()
        else:
            send_message = self.send_message


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if auth_result is not UNSET:
            field_dict["auth_result"] = auth_result
        if connection_closed is not UNSET:
            field_dict["connection_closed"] = connection_closed
        if presence_update is not UNSET:
            field_dict["presence_update"] = presence_update
        if error is not UNSET:
            field_dict["error"] = error
        if task_update is not UNSET:
            field_dict["task_update"] = task_update
        if batch_complete is not UNSET:
            field_dict["batch_complete"] = batch_complete
        if notification is not UNSET:
            field_dict["notification"] = notification
        if auth is not UNSET:
            field_dict["auth"] = auth
        if send_message is not UNSET:
            field_dict["send_message"] = send_message

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.auth_message import AuthMessage
        from ..models.auth_result_message import AuthResultMessage
        from ..models.batch_complete_message import BatchCompleteMessage
        from ..models.connection_closed_message import ConnectionClosedMessage
        from ..models.error_message import ErrorMessage
        from ..models.notification_response import NotificationResponse
        from ..models.presence_update_message import PresenceUpdateMessage
        from ..models.send_message_request import SendMessageRequest
        from ..models.task_update_message import TaskUpdateMessage
        d = dict(src_dict)
        def _parse_auth_result(data: object) -> AuthResultMessage | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                auth_result_type_0 = AuthResultMessage.from_dict(data)



                return auth_result_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AuthResultMessage | None | Unset, data)

        auth_result = _parse_auth_result(d.pop("auth_result", UNSET))


        def _parse_connection_closed(data: object) -> ConnectionClosedMessage | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                connection_closed_type_0 = ConnectionClosedMessage.from_dict(data)



                return connection_closed_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ConnectionClosedMessage | None | Unset, data)

        connection_closed = _parse_connection_closed(d.pop("connection_closed", UNSET))


        def _parse_presence_update(data: object) -> None | PresenceUpdateMessage | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                presence_update_type_0 = PresenceUpdateMessage.from_dict(data)



                return presence_update_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PresenceUpdateMessage | Unset, data)

        presence_update = _parse_presence_update(d.pop("presence_update", UNSET))


        def _parse_error(data: object) -> ErrorMessage | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                error_type_0 = ErrorMessage.from_dict(data)



                return error_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ErrorMessage | None | Unset, data)

        error = _parse_error(d.pop("error", UNSET))


        def _parse_task_update(data: object) -> None | TaskUpdateMessage | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                task_update_type_0 = TaskUpdateMessage.from_dict(data)



                return task_update_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TaskUpdateMessage | Unset, data)

        task_update = _parse_task_update(d.pop("task_update", UNSET))


        def _parse_batch_complete(data: object) -> BatchCompleteMessage | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                batch_complete_type_0 = BatchCompleteMessage.from_dict(data)



                return batch_complete_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(BatchCompleteMessage | None | Unset, data)

        batch_complete = _parse_batch_complete(d.pop("batch_complete", UNSET))


        def _parse_notification(data: object) -> None | NotificationResponse | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                notification_type_0 = NotificationResponse.from_dict(data)



                return notification_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | NotificationResponse | Unset, data)

        notification = _parse_notification(d.pop("notification", UNSET))


        def _parse_auth(data: object) -> AuthMessage | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                auth_type_0 = AuthMessage.from_dict(data)



                return auth_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AuthMessage | None | Unset, data)

        auth = _parse_auth(d.pop("auth", UNSET))


        def _parse_send_message(data: object) -> None | SendMessageRequest | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                send_message_type_0 = SendMessageRequest.from_dict(data)



                return send_message_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SendMessageRequest | Unset, data)

        send_message = _parse_send_message(d.pop("send_message", UNSET))


        web_socket_schemas = cls(
            auth_result=auth_result,
            connection_closed=connection_closed,
            presence_update=presence_update,
            error=error,
            task_update=task_update,
            batch_complete=batch_complete,
            notification=notification,
            auth=auth,
            send_message=send_message,
        )


        web_socket_schemas.additional_properties = d
        return web_socket_schemas

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
