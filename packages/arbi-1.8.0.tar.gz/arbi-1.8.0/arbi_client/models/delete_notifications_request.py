from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast






T = TypeVar("T", bound="DeleteNotificationsRequest")



@_attrs_define
class DeleteNotificationsRequest:
    """ Delete one or more notifications by external ID.

        Attributes:
            external_ids (list[str]):
     """

    external_ids: list[str]





    def to_dict(self) -> dict[str, Any]:
        external_ids = self.external_ids




        field_dict: dict[str, Any] = {}

        field_dict.update({
            "external_ids": external_ids,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        external_ids = cast(list[str], d.pop("external_ids"))


        delete_notifications_request = cls(
            external_ids=external_ids,
        )

        return delete_notifications_request

