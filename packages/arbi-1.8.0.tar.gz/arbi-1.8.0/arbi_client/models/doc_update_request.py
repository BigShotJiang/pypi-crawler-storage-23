from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast

if TYPE_CHECKING:
  from ..models.doc_metadata import DocMetadata





T = TypeVar("T", bound="DocUpdateRequest")



@_attrs_define
class DocUpdateRequest:
    """ Document update request - identifies doc and fields to update.

        Attributes:
            external_id (str):
            shared (bool | None | Unset):
            doc_metadata (DocMetadata | None | Unset):
            status (Literal['processing'] | None | Unset):
            content (None | str | Unset):
     """

    external_id: str
    shared: bool | None | Unset = UNSET
    doc_metadata: DocMetadata | None | Unset = UNSET
    status: Literal['processing'] | None | Unset = UNSET
    content: None | str | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        from ..models.doc_metadata import DocMetadata
        external_id = self.external_id

        shared: bool | None | Unset
        if isinstance(self.shared, Unset):
            shared = UNSET
        else:
            shared = self.shared

        doc_metadata: dict[str, Any] | None | Unset
        if isinstance(self.doc_metadata, Unset):
            doc_metadata = UNSET
        elif isinstance(self.doc_metadata, DocMetadata):
            doc_metadata = self.doc_metadata.to_dict()
        else:
            doc_metadata = self.doc_metadata

        status: Literal['processing'] | None | Unset
        if isinstance(self.status, Unset):
            status = UNSET
        else:
            status = self.status

        content: None | str | Unset
        if isinstance(self.content, Unset):
            content = UNSET
        else:
            content = self.content


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "external_id": external_id,
        })
        if shared is not UNSET:
            field_dict["shared"] = shared
        if doc_metadata is not UNSET:
            field_dict["doc_metadata"] = doc_metadata
        if status is not UNSET:
            field_dict["status"] = status
        if content is not UNSET:
            field_dict["content"] = content

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.doc_metadata import DocMetadata
        d = dict(src_dict)
        external_id = d.pop("external_id")

        def _parse_shared(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        shared = _parse_shared(d.pop("shared", UNSET))


        def _parse_doc_metadata(data: object) -> DocMetadata | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                doc_metadata_type_0 = DocMetadata.from_dict(data)



                return doc_metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DocMetadata | None | Unset, data)

        doc_metadata = _parse_doc_metadata(d.pop("doc_metadata", UNSET))


        def _parse_status(data: object) -> Literal['processing'] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            status_type_0 = cast(Literal['processing'] , data)
            if status_type_0 != 'processing':
                raise ValueError(f"status_type_0 must match const 'processing', got '{status_type_0}'")
            return status_type_0
            return cast(Literal['processing'] | None | Unset, data)

        status = _parse_status(d.pop("status", UNSET))


        def _parse_content(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        content = _parse_content(d.pop("content", UNSET))


        doc_update_request = cls(
            external_id=external_id,
            shared=shared,
            doc_metadata=doc_metadata,
            status=status,
            content=content,
        )

        return doc_update_request

