from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="SSOSendVerificationEmailRequest")



@_attrs_define
class SSOSendVerificationEmailRequest:
    """ 
        Attributes:
            auth0_id (str):
     """

    auth0_id: str





    def to_dict(self) -> dict[str, Any]:
        auth0_id = self.auth0_id


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "auth0_id": auth0_id,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        auth0_id = d.pop("auth0_id")

        sso_send_verification_email_request = cls(
            auth0_id=auth0_id,
        )

        return sso_send_verification_email_request

