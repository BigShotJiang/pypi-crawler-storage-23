from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="UploadDocumentsResponse")



@_attrs_define
class UploadDocumentsResponse:
    """ Response for document upload operations.

    Returns array of document IDs in the same order as uploaded files.
    Includes duplicate warnings for files with identical content already in workspace.

        Attributes:
            doc_ext_ids (list[str]):
            duplicates (list[str] | Unset): Doc IDs that have identical content to existing documents in the workspace
     """

    doc_ext_ids: list[str]
    duplicates: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        doc_ext_ids = self.doc_ext_ids



        duplicates: list[str] | Unset = UNSET
        if not isinstance(self.duplicates, Unset):
            duplicates = self.duplicates




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "doc_ext_ids": doc_ext_ids,
        })
        if duplicates is not UNSET:
            field_dict["duplicates"] = duplicates

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        doc_ext_ids = cast(list[str], d.pop("doc_ext_ids"))


        duplicates = cast(list[str], d.pop("duplicates", UNSET))


        upload_documents_response = cls(
            doc_ext_ids=doc_ext_ids,
            duplicates=duplicates,
        )


        upload_documents_response.additional_properties = d
        return upload_documents_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
