from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.embedder_config_api_type import EmbedderConfigApiType
from ..types import UNSET, Unset






T = TypeVar("T", bound="EmbedderConfig")



@_attrs_define
class EmbedderConfig:
    r""" 
        Attributes:
            model_name (str | Unset): The name of the embedder model. Default: 'Qwen/Qwen3-Embedding-0.6B'.
            api_type (EmbedderConfigApiType | Unset): The inference type (local or remote). Default:
                EmbedderConfigApiType.LOCAL.
            batch_size (int | Unset): Smaller batch size for better parallelization. Default: 128.
            max_concurrent_requests (int | Unset): Adjust concurrency level as needed. Default: 64.
            document_prefix (str | Unset): Prefix for document embeddings. Empty for Qwen3-style models. Default: ''.
            query_prefix (str | Unset): Instruction prefix for query embeddings. Used with Qwen3-style instruction-aware
                models. Default: 'Instruct: Represent the user search query for retrieving relevant documents.\nQuery:'.
     """

    model_name: str | Unset = 'Qwen/Qwen3-Embedding-0.6B'
    api_type: EmbedderConfigApiType | Unset = EmbedderConfigApiType.LOCAL
    batch_size: int | Unset = 128
    max_concurrent_requests: int | Unset = 64
    document_prefix: str | Unset = ''
    query_prefix: str | Unset = 'Instruct: Represent the user search query for retrieving relevant documents.\nQuery:'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        model_name = self.model_name

        api_type: str | Unset = UNSET
        if not isinstance(self.api_type, Unset):
            api_type = self.api_type.value


        batch_size = self.batch_size

        max_concurrent_requests = self.max_concurrent_requests

        document_prefix = self.document_prefix

        query_prefix = self.query_prefix


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if model_name is not UNSET:
            field_dict["MODEL_NAME"] = model_name
        if api_type is not UNSET:
            field_dict["API_TYPE"] = api_type
        if batch_size is not UNSET:
            field_dict["BATCH_SIZE"] = batch_size
        if max_concurrent_requests is not UNSET:
            field_dict["MAX_CONCURRENT_REQUESTS"] = max_concurrent_requests
        if document_prefix is not UNSET:
            field_dict["DOCUMENT_PREFIX"] = document_prefix
        if query_prefix is not UNSET:
            field_dict["QUERY_PREFIX"] = query_prefix

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        model_name = d.pop("MODEL_NAME", UNSET)

        _api_type = d.pop("API_TYPE", UNSET)
        api_type: EmbedderConfigApiType | Unset
        if isinstance(_api_type,  Unset):
            api_type = UNSET
        else:
            api_type = EmbedderConfigApiType(_api_type)




        batch_size = d.pop("BATCH_SIZE", UNSET)

        max_concurrent_requests = d.pop("MAX_CONCURRENT_REQUESTS", UNSET)

        document_prefix = d.pop("DOCUMENT_PREFIX", UNSET)

        query_prefix = d.pop("QUERY_PREFIX", UNSET)

        embedder_config = cls(
            model_name=model_name,
            api_type=api_type,
            batch_size=batch_size,
            max_concurrent_requests=max_concurrent_requests,
            document_prefix=document_prefix,
            query_prefix=query_prefix,
        )


        embedder_config.additional_properties = d
        return embedder_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
