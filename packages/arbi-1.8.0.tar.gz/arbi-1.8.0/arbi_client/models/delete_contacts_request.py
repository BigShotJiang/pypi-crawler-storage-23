from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast






T = TypeVar("T", bound="DeleteContactsRequest")



@_attrs_define
class DeleteContactsRequest:
    """ Request model for deleting specific contacts.

        Attributes:
            contact_ids (list[str]):
     """

    contact_ids: list[str]





    def to_dict(self) -> dict[str, Any]:
        contact_ids = self.contact_ids




        field_dict: dict[str, Any] = {}

        field_dict.update({
            "contact_ids": contact_ids,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        contact_ids = cast(list[str], d.pop("contact_ids"))


        delete_contacts_request = cls(
            contact_ids=contact_ids,
        )

        return delete_contacts_request

