from enum import Enum

class ContactResponseStatus(str, Enum):
    INVITATION_EXPIRED = "invitation_expired"
    INVITATION_PENDING = "invitation_pending"
    REGISTERED = "registered"

    def __str__(self) -> str:
        return str(self.value)
