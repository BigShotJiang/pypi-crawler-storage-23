from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.doc_update_request import DocUpdateRequest





T = TypeVar("T", bound="UpdateDocumentsRequest")



@_attrs_define
class UpdateDocumentsRequest:
    """ Update one or more documents.

        Attributes:
            documents (list[DocUpdateRequest]):
     """

    documents: list[DocUpdateRequest]





    def to_dict(self) -> dict[str, Any]:
        from ..models.doc_update_request import DocUpdateRequest
        documents = []
        for documents_item_data in self.documents:
            documents_item = documents_item_data.to_dict()
            documents.append(documents_item)




        field_dict: dict[str, Any] = {}

        field_dict.update({
            "documents": documents,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.doc_update_request import DocUpdateRequest
        d = dict(src_dict)
        documents = []
        _documents = d.pop("documents")
        for documents_item_data in (_documents):
            documents_item = DocUpdateRequest.from_dict(documents_item_data)



            documents.append(documents_item)


        update_documents_request = cls(
            documents=documents,
        )

        return update_documents_request

