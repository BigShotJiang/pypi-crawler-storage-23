from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.create_doc_tag_request_citations_type_0 import CreateDocTagRequestCitationsType0





T = TypeVar("T", bound="CreateDocTagRequest")



@_attrs_define
class CreateDocTagRequest:
    """ Apply a tag to one or more documents.

        Attributes:
            tag_ext_id (str):
            doc_ext_ids (list[str]):
            note (None | str | Unset):
            citations (CreateDocTagRequestCitationsType0 | None | Unset):
     """

    tag_ext_id: str
    doc_ext_ids: list[str]
    note: None | str | Unset = UNSET
    citations: CreateDocTagRequestCitationsType0 | None | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        from ..models.create_doc_tag_request_citations_type_0 import CreateDocTagRequestCitationsType0
        tag_ext_id = self.tag_ext_id

        doc_ext_ids = self.doc_ext_ids



        note: None | str | Unset
        if isinstance(self.note, Unset):
            note = UNSET
        else:
            note = self.note

        citations: dict[str, Any] | None | Unset
        if isinstance(self.citations, Unset):
            citations = UNSET
        elif isinstance(self.citations, CreateDocTagRequestCitationsType0):
            citations = self.citations.to_dict()
        else:
            citations = self.citations


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "tag_ext_id": tag_ext_id,
            "doc_ext_ids": doc_ext_ids,
        })
        if note is not UNSET:
            field_dict["note"] = note
        if citations is not UNSET:
            field_dict["citations"] = citations

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_doc_tag_request_citations_type_0 import CreateDocTagRequestCitationsType0
        d = dict(src_dict)
        tag_ext_id = d.pop("tag_ext_id")

        doc_ext_ids = cast(list[str], d.pop("doc_ext_ids"))


        def _parse_note(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        note = _parse_note(d.pop("note", UNSET))


        def _parse_citations(data: object) -> CreateDocTagRequestCitationsType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                citations_type_0 = CreateDocTagRequestCitationsType0.from_dict(data)



                return citations_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CreateDocTagRequestCitationsType0 | None | Unset, data)

        citations = _parse_citations(d.pop("citations", UNSET))


        create_doc_tag_request = cls(
            tag_ext_id=tag_ext_id,
            doc_ext_ids=doc_ext_ids,
            note=note,
            citations=citations,
        )

        return create_doc_tag_request

