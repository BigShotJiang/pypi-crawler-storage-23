from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.tag_format import TagFormat





T = TypeVar("T", bound="UpdateTagRequest")



@_attrs_define
class UpdateTagRequest:
    """ 
        Attributes:
            name (None | str | Unset):
            instruction (None | str | Unset):
            tag_type (None | TagFormat | Unset):
            shared (bool | None | Unset):
            parent_ext_id (None | str | Unset):
     """

    name: None | str | Unset = UNSET
    instruction: None | str | Unset = UNSET
    tag_type: None | TagFormat | Unset = UNSET
    shared: bool | None | Unset = UNSET
    parent_ext_id: None | str | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        from ..models.tag_format import TagFormat
        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        instruction: None | str | Unset
        if isinstance(self.instruction, Unset):
            instruction = UNSET
        else:
            instruction = self.instruction

        tag_type: dict[str, Any] | None | Unset
        if isinstance(self.tag_type, Unset):
            tag_type = UNSET
        elif isinstance(self.tag_type, TagFormat):
            tag_type = self.tag_type.to_dict()
        else:
            tag_type = self.tag_type

        shared: bool | None | Unset
        if isinstance(self.shared, Unset):
            shared = UNSET
        else:
            shared = self.shared

        parent_ext_id: None | str | Unset
        if isinstance(self.parent_ext_id, Unset):
            parent_ext_id = UNSET
        else:
            parent_ext_id = self.parent_ext_id


        field_dict: dict[str, Any] = {}

        field_dict.update({
        })
        if name is not UNSET:
            field_dict["name"] = name
        if instruction is not UNSET:
            field_dict["instruction"] = instruction
        if tag_type is not UNSET:
            field_dict["tag_type"] = tag_type
        if shared is not UNSET:
            field_dict["shared"] = shared
        if parent_ext_id is not UNSET:
            field_dict["parent_ext_id"] = parent_ext_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.tag_format import TagFormat
        d = dict(src_dict)
        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))


        def _parse_instruction(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        instruction = _parse_instruction(d.pop("instruction", UNSET))


        def _parse_tag_type(data: object) -> None | TagFormat | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                tag_type_type_0 = TagFormat.from_dict(data)



                return tag_type_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TagFormat | Unset, data)

        tag_type = _parse_tag_type(d.pop("tag_type", UNSET))


        def _parse_shared(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        shared = _parse_shared(d.pop("shared", UNSET))


        def _parse_parent_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        parent_ext_id = _parse_parent_ext_id(d.pop("parent_ext_id", UNSET))


        update_tag_request = cls(
            name=name,
            instruction=instruction,
            tag_type=tag_type,
            shared=shared,
            parent_ext_id=parent_ext_id,
        )

        return update_tag_request

