from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast






T = TypeVar("T", bound="UserInputRequestEvent")



@_attrs_define
class UserInputRequestEvent:
    """ Agent requests human input with structured options.

    Frontend should render the question with clickable options and an "Other"
    free-text fallback. The user's response is sent via POST /assistant/respond
    using the assistant_message_ext_id from the stream_start event.

    Examples:
        {"type": "arbi.user_input_request",
         "question": "Which clause should I focus on?",
         "options": ["Clause 5 - Force Majeure", "Clause 12 - Liability", "Other"],
         "timeout_seconds": 300}

        Attributes:
            question (str): The question to display to the user
            options (list[str]): Selectable choices. Last option is always 'Other' for free text.
            t (float | None | Unset): Seconds elapsed since stream start.
            type_ (Literal['arbi.user_input_request'] | Unset):  Default: 'arbi.user_input_request'.
            timeout_seconds (int | Unset): Frontend countdown timer (seconds) Default: 300.
     """

    question: str
    options: list[str]
    t: float | None | Unset = UNSET
    type_: Literal['arbi.user_input_request'] | Unset = 'arbi.user_input_request'
    timeout_seconds: int | Unset = 300
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        question = self.question

        options = self.options



        t: float | None | Unset
        if isinstance(self.t, Unset):
            t = UNSET
        else:
            t = self.t

        type_ = self.type_

        timeout_seconds = self.timeout_seconds


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "question": question,
            "options": options,
        })
        if t is not UNSET:
            field_dict["t"] = t
        if type_ is not UNSET:
            field_dict["type"] = type_
        if timeout_seconds is not UNSET:
            field_dict["timeout_seconds"] = timeout_seconds

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        question = d.pop("question")

        options = cast(list[str], d.pop("options"))


        def _parse_t(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        t = _parse_t(d.pop("t", UNSET))


        type_ = cast(Literal['arbi.user_input_request'] | Unset , d.pop("type", UNSET))
        if type_ != 'arbi.user_input_request'and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'arbi.user_input_request', got '{type_}'")

        timeout_seconds = d.pop("timeout_seconds", UNSET)

        user_input_request_event = cls(
            question=question,
            options=options,
            t=t,
            type_=type_,
            timeout_seconds=timeout_seconds,
        )


        user_input_request_event.additional_properties = d
        return user_input_request_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
