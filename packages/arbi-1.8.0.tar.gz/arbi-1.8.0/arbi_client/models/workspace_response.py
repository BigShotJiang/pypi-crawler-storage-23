from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.workspace_user_response import WorkspaceUserResponse





T = TypeVar("T", bound="WorkspaceResponse")



@_attrs_define
class WorkspaceResponse:
    """ 
        Attributes:
            external_id (str):
            name (str):
            description (None | str):
            is_public (bool):
            created_by_ext_id (str):
            created_at (datetime.datetime):
            updated_at (datetime.datetime):
            updated_by_ext_id (None | str | Unset):
            wrapped_key (None | str | Unset):
            shared_conversation_count (int | Unset):  Default: 0.
            private_conversation_count (int | Unset):  Default: 0.
            shared_document_count (int | Unset):  Default: 0.
            private_document_count (int | Unset):  Default: 0.
            user_files_mb (float | Unset):  Default: 0.0.
            users (list[WorkspaceUserResponse] | Unset):
     """

    external_id: str
    name: str
    description: None | str
    is_public: bool
    created_by_ext_id: str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    updated_by_ext_id: None | str | Unset = UNSET
    wrapped_key: None | str | Unset = UNSET
    shared_conversation_count: int | Unset = 0
    private_conversation_count: int | Unset = 0
    shared_document_count: int | Unset = 0
    private_document_count: int | Unset = 0
    user_files_mb: float | Unset = 0.0
    users: list[WorkspaceUserResponse] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.workspace_user_response import WorkspaceUserResponse
        external_id = self.external_id

        name = self.name

        description: None | str
        description = self.description

        is_public = self.is_public

        created_by_ext_id = self.created_by_ext_id

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        updated_by_ext_id: None | str | Unset
        if isinstance(self.updated_by_ext_id, Unset):
            updated_by_ext_id = UNSET
        else:
            updated_by_ext_id = self.updated_by_ext_id

        wrapped_key: None | str | Unset
        if isinstance(self.wrapped_key, Unset):
            wrapped_key = UNSET
        else:
            wrapped_key = self.wrapped_key

        shared_conversation_count = self.shared_conversation_count

        private_conversation_count = self.private_conversation_count

        shared_document_count = self.shared_document_count

        private_document_count = self.private_document_count

        user_files_mb = self.user_files_mb

        users: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.users, Unset):
            users = []
            for users_item_data in self.users:
                users_item = users_item_data.to_dict()
                users.append(users_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "external_id": external_id,
            "name": name,
            "description": description,
            "is_public": is_public,
            "created_by_ext_id": created_by_ext_id,
            "created_at": created_at,
            "updated_at": updated_at,
        })
        if updated_by_ext_id is not UNSET:
            field_dict["updated_by_ext_id"] = updated_by_ext_id
        if wrapped_key is not UNSET:
            field_dict["wrapped_key"] = wrapped_key
        if shared_conversation_count is not UNSET:
            field_dict["shared_conversation_count"] = shared_conversation_count
        if private_conversation_count is not UNSET:
            field_dict["private_conversation_count"] = private_conversation_count
        if shared_document_count is not UNSET:
            field_dict["shared_document_count"] = shared_document_count
        if private_document_count is not UNSET:
            field_dict["private_document_count"] = private_document_count
        if user_files_mb is not UNSET:
            field_dict["user_files_mb"] = user_files_mb
        if users is not UNSET:
            field_dict["users"] = users

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.workspace_user_response import WorkspaceUserResponse
        d = dict(src_dict)
        external_id = d.pop("external_id")

        name = d.pop("name")

        def _parse_description(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        description = _parse_description(d.pop("description"))


        is_public = d.pop("is_public")

        created_by_ext_id = d.pop("created_by_ext_id")

        created_at = isoparse(d.pop("created_at"))




        updated_at = isoparse(d.pop("updated_at"))




        def _parse_updated_by_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        updated_by_ext_id = _parse_updated_by_ext_id(d.pop("updated_by_ext_id", UNSET))


        def _parse_wrapped_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        wrapped_key = _parse_wrapped_key(d.pop("wrapped_key", UNSET))


        shared_conversation_count = d.pop("shared_conversation_count", UNSET)

        private_conversation_count = d.pop("private_conversation_count", UNSET)

        shared_document_count = d.pop("shared_document_count", UNSET)

        private_document_count = d.pop("private_document_count", UNSET)

        user_files_mb = d.pop("user_files_mb", UNSET)

        _users = d.pop("users", UNSET)
        users: list[WorkspaceUserResponse] | Unset = UNSET
        if _users is not UNSET:
            users = []
            for users_item_data in _users:
                users_item = WorkspaceUserResponse.from_dict(users_item_data)



                users.append(users_item)


        workspace_response = cls(
            external_id=external_id,
            name=name,
            description=description,
            is_public=is_public,
            created_by_ext_id=created_by_ext_id,
            created_at=created_at,
            updated_at=updated_at,
            updated_by_ext_id=updated_by_ext_id,
            wrapped_key=wrapped_key,
            shared_conversation_count=shared_conversation_count,
            private_conversation_count=private_conversation_count,
            shared_document_count=shared_document_count,
            private_document_count=private_document_count,
            user_files_mb=user_files_mb,
            users=users,
        )


        workspace_response.additional_properties = d
        return workspace_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
