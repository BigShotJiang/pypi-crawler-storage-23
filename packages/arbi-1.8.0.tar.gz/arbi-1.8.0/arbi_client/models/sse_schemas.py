from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.agent_step_event import AgentStepEvent
  from ..models.artifact_event import ArtifactEvent
  from ..models.response_completed_event import ResponseCompletedEvent
  from ..models.response_created_event import ResponseCreatedEvent
  from ..models.response_failed_event import ResponseFailedEvent
  from ..models.response_output_text_delta_event import ResponseOutputTextDeltaEvent
  from ..models.user_input_request_event import UserInputRequestEvent





T = TypeVar("T", bound="SSESchemas")



@_attrs_define
class SSESchemas:
    """ Container for all SSE event schemas — drives OpenAPI component generation.

    Each field exposes an event type to the OpenAPI spec so the TS frontend
    can autogenerate types.  The endpoint returns defaults (None) — only the
    schema components matter.

        Attributes:
            response_created (None | ResponseCreatedEvent | Unset):
            agent_step (AgentStepEvent | None | Unset):
            user_input_request (None | Unset | UserInputRequestEvent):
            response_output_text_delta (None | ResponseOutputTextDeltaEvent | Unset):
            response_completed (None | ResponseCompletedEvent | Unset):
            response_failed (None | ResponseFailedEvent | Unset):
            artifact (ArtifactEvent | None | Unset):
     """

    response_created: None | ResponseCreatedEvent | Unset = UNSET
    agent_step: AgentStepEvent | None | Unset = UNSET
    user_input_request: None | Unset | UserInputRequestEvent = UNSET
    response_output_text_delta: None | ResponseOutputTextDeltaEvent | Unset = UNSET
    response_completed: None | ResponseCompletedEvent | Unset = UNSET
    response_failed: None | ResponseFailedEvent | Unset = UNSET
    artifact: ArtifactEvent | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.artifact_event import ArtifactEvent
        from ..models.response_completed_event import ResponseCompletedEvent
        from ..models.agent_step_event import AgentStepEvent
        from ..models.response_output_text_delta_event import ResponseOutputTextDeltaEvent
        from ..models.response_created_event import ResponseCreatedEvent
        from ..models.response_failed_event import ResponseFailedEvent
        from ..models.user_input_request_event import UserInputRequestEvent
        response_created: dict[str, Any] | None | Unset
        if isinstance(self.response_created, Unset):
            response_created = UNSET
        elif isinstance(self.response_created, ResponseCreatedEvent):
            response_created = self.response_created.to_dict()
        else:
            response_created = self.response_created

        agent_step: dict[str, Any] | None | Unset
        if isinstance(self.agent_step, Unset):
            agent_step = UNSET
        elif isinstance(self.agent_step, AgentStepEvent):
            agent_step = self.agent_step.to_dict()
        else:
            agent_step = self.agent_step

        user_input_request: dict[str, Any] | None | Unset
        if isinstance(self.user_input_request, Unset):
            user_input_request = UNSET
        elif isinstance(self.user_input_request, UserInputRequestEvent):
            user_input_request = self.user_input_request.to_dict()
        else:
            user_input_request = self.user_input_request

        response_output_text_delta: dict[str, Any] | None | Unset
        if isinstance(self.response_output_text_delta, Unset):
            response_output_text_delta = UNSET
        elif isinstance(self.response_output_text_delta, ResponseOutputTextDeltaEvent):
            response_output_text_delta = self.response_output_text_delta.to_dict()
        else:
            response_output_text_delta = self.response_output_text_delta

        response_completed: dict[str, Any] | None | Unset
        if isinstance(self.response_completed, Unset):
            response_completed = UNSET
        elif isinstance(self.response_completed, ResponseCompletedEvent):
            response_completed = self.response_completed.to_dict()
        else:
            response_completed = self.response_completed

        response_failed: dict[str, Any] | None | Unset
        if isinstance(self.response_failed, Unset):
            response_failed = UNSET
        elif isinstance(self.response_failed, ResponseFailedEvent):
            response_failed = self.response_failed.to_dict()
        else:
            response_failed = self.response_failed

        artifact: dict[str, Any] | None | Unset
        if isinstance(self.artifact, Unset):
            artifact = UNSET
        elif isinstance(self.artifact, ArtifactEvent):
            artifact = self.artifact.to_dict()
        else:
            artifact = self.artifact


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if response_created is not UNSET:
            field_dict["response_created"] = response_created
        if agent_step is not UNSET:
            field_dict["agent_step"] = agent_step
        if user_input_request is not UNSET:
            field_dict["user_input_request"] = user_input_request
        if response_output_text_delta is not UNSET:
            field_dict["response_output_text_delta"] = response_output_text_delta
        if response_completed is not UNSET:
            field_dict["response_completed"] = response_completed
        if response_failed is not UNSET:
            field_dict["response_failed"] = response_failed
        if artifact is not UNSET:
            field_dict["artifact"] = artifact

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent_step_event import AgentStepEvent
        from ..models.artifact_event import ArtifactEvent
        from ..models.response_completed_event import ResponseCompletedEvent
        from ..models.response_created_event import ResponseCreatedEvent
        from ..models.response_failed_event import ResponseFailedEvent
        from ..models.response_output_text_delta_event import ResponseOutputTextDeltaEvent
        from ..models.user_input_request_event import UserInputRequestEvent
        d = dict(src_dict)
        def _parse_response_created(data: object) -> None | ResponseCreatedEvent | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_created_type_0 = ResponseCreatedEvent.from_dict(data)



                return response_created_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ResponseCreatedEvent | Unset, data)

        response_created = _parse_response_created(d.pop("response_created", UNSET))


        def _parse_agent_step(data: object) -> AgentStepEvent | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                agent_step_type_0 = AgentStepEvent.from_dict(data)



                return agent_step_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AgentStepEvent | None | Unset, data)

        agent_step = _parse_agent_step(d.pop("agent_step", UNSET))


        def _parse_user_input_request(data: object) -> None | Unset | UserInputRequestEvent:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                user_input_request_type_0 = UserInputRequestEvent.from_dict(data)



                return user_input_request_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UserInputRequestEvent, data)

        user_input_request = _parse_user_input_request(d.pop("user_input_request", UNSET))


        def _parse_response_output_text_delta(data: object) -> None | ResponseOutputTextDeltaEvent | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_output_text_delta_type_0 = ResponseOutputTextDeltaEvent.from_dict(data)



                return response_output_text_delta_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ResponseOutputTextDeltaEvent | Unset, data)

        response_output_text_delta = _parse_response_output_text_delta(d.pop("response_output_text_delta", UNSET))


        def _parse_response_completed(data: object) -> None | ResponseCompletedEvent | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_completed_type_0 = ResponseCompletedEvent.from_dict(data)



                return response_completed_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ResponseCompletedEvent | Unset, data)

        response_completed = _parse_response_completed(d.pop("response_completed", UNSET))


        def _parse_response_failed(data: object) -> None | ResponseFailedEvent | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_failed_type_0 = ResponseFailedEvent.from_dict(data)



                return response_failed_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ResponseFailedEvent | Unset, data)

        response_failed = _parse_response_failed(d.pop("response_failed", UNSET))


        def _parse_artifact(data: object) -> ArtifactEvent | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                artifact_type_0 = ArtifactEvent.from_dict(data)



                return artifact_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ArtifactEvent | None | Unset, data)

        artifact = _parse_artifact(d.pop("artifact", UNSET))


        sse_schemas = cls(
            response_created=response_created,
            agent_step=agent_step,
            user_input_request=user_input_request,
            response_output_text_delta=response_output_text_delta,
            response_completed=response_completed,
            response_failed=response_failed,
            artifact=artifact,
        )


        sse_schemas.additional_properties = d
        return sse_schemas

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
