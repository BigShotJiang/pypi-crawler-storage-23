from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.chat_completion_request_messages_item import ChatCompletionRequestMessagesItem
  from ..models.chat_completion_request_response_format_type_0 import ChatCompletionRequestResponseFormatType0
  from ..models.chat_completion_request_tool_choice_type_1 import ChatCompletionRequestToolChoiceType1
  from ..models.chat_completion_request_tools_type_0_item import ChatCompletionRequestToolsType0Item





T = TypeVar("T", bound="ChatCompletionRequest")



@_attrs_define
class ChatCompletionRequest:
    """ OpenAI-compatible chat completion request.

        Attributes:
            model (str):
            messages (list[ChatCompletionRequestMessagesItem]):
            stream (bool | Unset):  Default: True.
            temperature (float | None | Unset):
            max_tokens (int | None | Unset):
            tools (list[ChatCompletionRequestToolsType0Item] | None | Unset):
            tool_choice (ChatCompletionRequestToolChoiceType1 | None | str | Unset):
            response_format (ChatCompletionRequestResponseFormatType0 | None | Unset):
     """

    model: str
    messages: list[ChatCompletionRequestMessagesItem]
    stream: bool | Unset = True
    temperature: float | None | Unset = UNSET
    max_tokens: int | None | Unset = UNSET
    tools: list[ChatCompletionRequestToolsType0Item] | None | Unset = UNSET
    tool_choice: ChatCompletionRequestToolChoiceType1 | None | str | Unset = UNSET
    response_format: ChatCompletionRequestResponseFormatType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.chat_completion_request_tools_type_0_item import ChatCompletionRequestToolsType0Item
        from ..models.chat_completion_request_tool_choice_type_1 import ChatCompletionRequestToolChoiceType1
        from ..models.chat_completion_request_messages_item import ChatCompletionRequestMessagesItem
        from ..models.chat_completion_request_response_format_type_0 import ChatCompletionRequestResponseFormatType0
        model = self.model

        messages = []
        for messages_item_data in self.messages:
            messages_item = messages_item_data.to_dict()
            messages.append(messages_item)



        stream = self.stream

        temperature: float | None | Unset
        if isinstance(self.temperature, Unset):
            temperature = UNSET
        else:
            temperature = self.temperature

        max_tokens: int | None | Unset
        if isinstance(self.max_tokens, Unset):
            max_tokens = UNSET
        else:
            max_tokens = self.max_tokens

        tools: list[dict[str, Any]] | None | Unset
        if isinstance(self.tools, Unset):
            tools = UNSET
        elif isinstance(self.tools, list):
            tools = []
            for tools_type_0_item_data in self.tools:
                tools_type_0_item = tools_type_0_item_data.to_dict()
                tools.append(tools_type_0_item)


        else:
            tools = self.tools

        tool_choice: dict[str, Any] | None | str | Unset
        if isinstance(self.tool_choice, Unset):
            tool_choice = UNSET
        elif isinstance(self.tool_choice, ChatCompletionRequestToolChoiceType1):
            tool_choice = self.tool_choice.to_dict()
        else:
            tool_choice = self.tool_choice

        response_format: dict[str, Any] | None | Unset
        if isinstance(self.response_format, Unset):
            response_format = UNSET
        elif isinstance(self.response_format, ChatCompletionRequestResponseFormatType0):
            response_format = self.response_format.to_dict()
        else:
            response_format = self.response_format


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "model": model,
            "messages": messages,
        })
        if stream is not UNSET:
            field_dict["stream"] = stream
        if temperature is not UNSET:
            field_dict["temperature"] = temperature
        if max_tokens is not UNSET:
            field_dict["max_tokens"] = max_tokens
        if tools is not UNSET:
            field_dict["tools"] = tools
        if tool_choice is not UNSET:
            field_dict["tool_choice"] = tool_choice
        if response_format is not UNSET:
            field_dict["response_format"] = response_format

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chat_completion_request_messages_item import ChatCompletionRequestMessagesItem
        from ..models.chat_completion_request_response_format_type_0 import ChatCompletionRequestResponseFormatType0
        from ..models.chat_completion_request_tool_choice_type_1 import ChatCompletionRequestToolChoiceType1
        from ..models.chat_completion_request_tools_type_0_item import ChatCompletionRequestToolsType0Item
        d = dict(src_dict)
        model = d.pop("model")

        messages = []
        _messages = d.pop("messages")
        for messages_item_data in (_messages):
            messages_item = ChatCompletionRequestMessagesItem.from_dict(messages_item_data)



            messages.append(messages_item)


        stream = d.pop("stream", UNSET)

        def _parse_temperature(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        temperature = _parse_temperature(d.pop("temperature", UNSET))


        def _parse_max_tokens(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        max_tokens = _parse_max_tokens(d.pop("max_tokens", UNSET))


        def _parse_tools(data: object) -> list[ChatCompletionRequestToolsType0Item] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                tools_type_0 = []
                _tools_type_0 = data
                for tools_type_0_item_data in (_tools_type_0):
                    tools_type_0_item = ChatCompletionRequestToolsType0Item.from_dict(tools_type_0_item_data)



                    tools_type_0.append(tools_type_0_item)

                return tools_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ChatCompletionRequestToolsType0Item] | None | Unset, data)

        tools = _parse_tools(d.pop("tools", UNSET))


        def _parse_tool_choice(data: object) -> ChatCompletionRequestToolChoiceType1 | None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                tool_choice_type_1 = ChatCompletionRequestToolChoiceType1.from_dict(data)



                return tool_choice_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChatCompletionRequestToolChoiceType1 | None | str | Unset, data)

        tool_choice = _parse_tool_choice(d.pop("tool_choice", UNSET))


        def _parse_response_format(data: object) -> ChatCompletionRequestResponseFormatType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_format_type_0 = ChatCompletionRequestResponseFormatType0.from_dict(data)



                return response_format_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChatCompletionRequestResponseFormatType0 | None | Unset, data)

        response_format = _parse_response_format(d.pop("response_format", UNSET))


        chat_completion_request = cls(
            model=model,
            messages=messages,
            stream=stream,
            temperature=temperature,
            max_tokens=max_tokens,
            tools=tools,
            tool_choice=tool_choice,
            response_format=response_format,
        )


        chat_completion_request.additional_properties = d
        return chat_completion_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
