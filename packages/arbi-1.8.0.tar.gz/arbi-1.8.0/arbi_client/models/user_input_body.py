from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="UserInputBody")



@_attrs_define
class UserInputBody:
    """ Request body for POST /assistant/respond.

        Attributes:
            assistant_message_ext_id (str):
            answer (str):
     """

    assistant_message_ext_id: str
    answer: str





    def to_dict(self) -> dict[str, Any]:
        assistant_message_ext_id = self.assistant_message_ext_id

        answer = self.answer


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "assistant_message_ext_id": assistant_message_ext_id,
            "answer": answer,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        assistant_message_ext_id = d.pop("assistant_message_ext_id")

        answer = d.pop("answer")

        user_input_body = cls(
            assistant_message_ext_id=assistant_message_ext_id,
            answer=answer,
        )

        return user_input_body

