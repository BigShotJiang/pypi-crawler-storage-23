from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.planning_llm_config_api_type import PlanningLLMConfigApiType
from ..types import UNSET, Unset






T = TypeVar("T", bound="PlanningLLMConfig")



@_attrs_define
class PlanningLLMConfig:
    r""" Configuration for PlanningLLM — generates research plans on demand.

    Backed by a reasoning model. The agent calls the create_plan tool when it
    deems a task complex enough; the plan text is returned as a tool result.

        Attributes:
            api_type (PlanningLLMConfigApiType | Unset): The inference type (local or remote). Default:
                PlanningLLMConfigApiType.REMOTE.
            model_name (str | Unset): The model for plan generation. Defaults to reasoning model. Default: 'dummy'.
            system_instruction (str | Unset): System instruction for the planning LLM. Default: 'You are a research planning
                assistant. Your job is to analyze a user query and produce a concise, numbered research plan.\n\nYou have access
                to a workspace of documents. The available tools for executing the plan are:\n- search_documents: Search
                workspace documents for relevant passages (semantic, keyword, or hybrid)\n- get_document_passages: Read a
                specific page range from a document\n- get_table_of_contents: Get document headings with page
                references\n\nConsider:\n- What information is needed to answer the query\n- Which documents are likely relevant
                based on the document index\n- What search queries and document passages to examine\n- What order of operations
                will be most efficient\n- Whether parallel searches can be used for different aspects\n\nRespond with ONLY the
                plan (numbered steps). Do not execute any steps.'.
            temperature (float | Unset): Temperature for planning. Default: 0.3.
            max_tokens (int | Unset): Maximum tokens for the plan output. Default: 4000.
            max_char_size_to_answer (int | Unset): Maximum character size for planning context. Default: 200000.
            approval_timeout (int | Unset): Seconds to wait for user approval after generating the plan. 0 = no approval
                (auto-proceed). Safe for non-interactive contexts. Default: 0.
     """

    api_type: PlanningLLMConfigApiType | Unset = PlanningLLMConfigApiType.REMOTE
    model_name: str | Unset = 'dummy'
    system_instruction: str | Unset = 'You are a research planning assistant. Your job is to analyze a user query and produce a concise, numbered research plan.\n\nYou have access to a workspace of documents. The available tools for executing the plan are:\n- search_documents: Search workspace documents for relevant passages (semantic, keyword, or hybrid)\n- get_document_passages: Read a specific page range from a document\n- get_table_of_contents: Get document headings with page references\n\nConsider:\n- What information is needed to answer the query\n- Which documents are likely relevant based on the document index\n- What search queries and document passages to examine\n- What order of operations will be most efficient\n- Whether parallel searches can be used for different aspects\n\nRespond with ONLY the plan (numbered steps). Do not execute any steps.'
    temperature: float | Unset = 0.3
    max_tokens: int | Unset = 4000
    max_char_size_to_answer: int | Unset = 200000
    approval_timeout: int | Unset = 0
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        api_type: str | Unset = UNSET
        if not isinstance(self.api_type, Unset):
            api_type = self.api_type.value


        model_name = self.model_name

        system_instruction = self.system_instruction

        temperature = self.temperature

        max_tokens = self.max_tokens

        max_char_size_to_answer = self.max_char_size_to_answer

        approval_timeout = self.approval_timeout


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if api_type is not UNSET:
            field_dict["API_TYPE"] = api_type
        if model_name is not UNSET:
            field_dict["MODEL_NAME"] = model_name
        if system_instruction is not UNSET:
            field_dict["SYSTEM_INSTRUCTION"] = system_instruction
        if temperature is not UNSET:
            field_dict["TEMPERATURE"] = temperature
        if max_tokens is not UNSET:
            field_dict["MAX_TOKENS"] = max_tokens
        if max_char_size_to_answer is not UNSET:
            field_dict["MAX_CHAR_SIZE_TO_ANSWER"] = max_char_size_to_answer
        if approval_timeout is not UNSET:
            field_dict["APPROVAL_TIMEOUT"] = approval_timeout

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _api_type = d.pop("API_TYPE", UNSET)
        api_type: PlanningLLMConfigApiType | Unset
        if isinstance(_api_type,  Unset):
            api_type = UNSET
        else:
            api_type = PlanningLLMConfigApiType(_api_type)




        model_name = d.pop("MODEL_NAME", UNSET)

        system_instruction = d.pop("SYSTEM_INSTRUCTION", UNSET)

        temperature = d.pop("TEMPERATURE", UNSET)

        max_tokens = d.pop("MAX_TOKENS", UNSET)

        max_char_size_to_answer = d.pop("MAX_CHAR_SIZE_TO_ANSWER", UNSET)

        approval_timeout = d.pop("APPROVAL_TIMEOUT", UNSET)

        planning_llm_config = cls(
            api_type=api_type,
            model_name=model_name,
            system_instruction=system_instruction,
            temperature=temperature,
            max_tokens=max_tokens,
            max_char_size_to_answer=max_char_size_to_answer,
            approval_timeout=approval_timeout,
        )


        planning_llm_config.additional_properties = d
        return planning_llm_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
