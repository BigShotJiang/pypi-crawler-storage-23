from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.update_doc_tag_request_citations_type_0 import UpdateDocTagRequestCitationsType0





T = TypeVar("T", bound="UpdateDocTagRequest")



@_attrs_define
class UpdateDocTagRequest:
    """ Update a doctag's note or citations. Identified by (tag_ext_id, doc_ext_id) pair.

        Attributes:
            tag_ext_id (str):
            doc_ext_id (str):
            note (None | str | Unset):
            citations (None | Unset | UpdateDocTagRequestCitationsType0):
     """

    tag_ext_id: str
    doc_ext_id: str
    note: None | str | Unset = UNSET
    citations: None | Unset | UpdateDocTagRequestCitationsType0 = UNSET





    def to_dict(self) -> dict[str, Any]:
        from ..models.update_doc_tag_request_citations_type_0 import UpdateDocTagRequestCitationsType0
        tag_ext_id = self.tag_ext_id

        doc_ext_id = self.doc_ext_id

        note: None | str | Unset
        if isinstance(self.note, Unset):
            note = UNSET
        else:
            note = self.note

        citations: dict[str, Any] | None | Unset
        if isinstance(self.citations, Unset):
            citations = UNSET
        elif isinstance(self.citations, UpdateDocTagRequestCitationsType0):
            citations = self.citations.to_dict()
        else:
            citations = self.citations


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "tag_ext_id": tag_ext_id,
            "doc_ext_id": doc_ext_id,
        })
        if note is not UNSET:
            field_dict["note"] = note
        if citations is not UNSET:
            field_dict["citations"] = citations

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.update_doc_tag_request_citations_type_0 import UpdateDocTagRequestCitationsType0
        d = dict(src_dict)
        tag_ext_id = d.pop("tag_ext_id")

        doc_ext_id = d.pop("doc_ext_id")

        def _parse_note(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        note = _parse_note(d.pop("note", UNSET))


        def _parse_citations(data: object) -> None | Unset | UpdateDocTagRequestCitationsType0:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                citations_type_0 = UpdateDocTagRequestCitationsType0.from_dict(data)



                return citations_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UpdateDocTagRequestCitationsType0, data)

        citations = _parse_citations(d.pop("citations", UNSET))


        update_doc_tag_request = cls(
            tag_ext_id=tag_ext_id,
            doc_ext_id=doc_ext_id,
            note=note,
            citations=citations,
        )

        return update_doc_tag_request

