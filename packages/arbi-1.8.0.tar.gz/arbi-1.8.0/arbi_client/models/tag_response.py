from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.tag_format import TagFormat





T = TypeVar("T", bound="TagResponse")



@_attrs_define
class TagResponse:
    """ 
        Attributes:
            external_id (str):
            workspace_ext_id (str):
            name (str):
            tag_type (TagFormat): Tag format configuration stored as JSONB.

                Type-specific fields:
                - select: options (list of choices, can be single or multi-select)
                - search: tag name is the query, chunks include relevance scores
                - checkbox, text, number, folder: type only
            shared (bool):
            doctag_count (int):
            created_by_ext_id (str):
            created_at (datetime.datetime):
            updated_at (datetime.datetime):
            instruction (None | str | Unset):
            parent_ext_id (None | str | Unset):
            updated_by_ext_id (None | str | Unset):
     """

    external_id: str
    workspace_ext_id: str
    name: str
    tag_type: TagFormat
    shared: bool
    doctag_count: int
    created_by_ext_id: str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    instruction: None | str | Unset = UNSET
    parent_ext_id: None | str | Unset = UNSET
    updated_by_ext_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.tag_format import TagFormat
        external_id = self.external_id

        workspace_ext_id = self.workspace_ext_id

        name = self.name

        tag_type = self.tag_type.to_dict()

        shared = self.shared

        doctag_count = self.doctag_count

        created_by_ext_id = self.created_by_ext_id

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        instruction: None | str | Unset
        if isinstance(self.instruction, Unset):
            instruction = UNSET
        else:
            instruction = self.instruction

        parent_ext_id: None | str | Unset
        if isinstance(self.parent_ext_id, Unset):
            parent_ext_id = UNSET
        else:
            parent_ext_id = self.parent_ext_id

        updated_by_ext_id: None | str | Unset
        if isinstance(self.updated_by_ext_id, Unset):
            updated_by_ext_id = UNSET
        else:
            updated_by_ext_id = self.updated_by_ext_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "external_id": external_id,
            "workspace_ext_id": workspace_ext_id,
            "name": name,
            "tag_type": tag_type,
            "shared": shared,
            "doctag_count": doctag_count,
            "created_by_ext_id": created_by_ext_id,
            "created_at": created_at,
            "updated_at": updated_at,
        })
        if instruction is not UNSET:
            field_dict["instruction"] = instruction
        if parent_ext_id is not UNSET:
            field_dict["parent_ext_id"] = parent_ext_id
        if updated_by_ext_id is not UNSET:
            field_dict["updated_by_ext_id"] = updated_by_ext_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.tag_format import TagFormat
        d = dict(src_dict)
        external_id = d.pop("external_id")

        workspace_ext_id = d.pop("workspace_ext_id")

        name = d.pop("name")

        tag_type = TagFormat.from_dict(d.pop("tag_type"))




        shared = d.pop("shared")

        doctag_count = d.pop("doctag_count")

        created_by_ext_id = d.pop("created_by_ext_id")

        created_at = isoparse(d.pop("created_at"))




        updated_at = isoparse(d.pop("updated_at"))




        def _parse_instruction(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        instruction = _parse_instruction(d.pop("instruction", UNSET))


        def _parse_parent_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        parent_ext_id = _parse_parent_ext_id(d.pop("parent_ext_id", UNSET))


        def _parse_updated_by_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        updated_by_ext_id = _parse_updated_by_ext_id(d.pop("updated_by_ext_id", UNSET))


        tag_response = cls(
            external_id=external_id,
            workspace_ext_id=workspace_ext_id,
            name=name,
            tag_type=tag_type,
            shared=shared,
            doctag_count=doctag_count,
            created_by_ext_id=created_by_ext_id,
            created_at=created_at,
            updated_at=updated_at,
            instruction=instruction,
            parent_ext_id=parent_ext_id,
            updated_by_ext_id=updated_by_ext_id,
        )


        tag_response.additional_properties = d
        return tag_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
