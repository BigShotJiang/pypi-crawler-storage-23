from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.service_status_service_info_type_0 import ServiceStatusServiceInfoType0





T = TypeVar("T", bound="ServiceStatus")



@_attrs_define
class ServiceStatus:
    """ 
        Attributes:
            name (str):
            status (str):
            detail (None | str | Unset):
            service_info (None | ServiceStatusServiceInfoType0 | Unset):
     """

    name: str
    status: str
    detail: None | str | Unset = UNSET
    service_info: None | ServiceStatusServiceInfoType0 | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.service_status_service_info_type_0 import ServiceStatusServiceInfoType0
        name = self.name

        status = self.status

        detail: None | str | Unset
        if isinstance(self.detail, Unset):
            detail = UNSET
        else:
            detail = self.detail

        service_info: dict[str, Any] | None | Unset
        if isinstance(self.service_info, Unset):
            service_info = UNSET
        elif isinstance(self.service_info, ServiceStatusServiceInfoType0):
            service_info = self.service_info.to_dict()
        else:
            service_info = self.service_info


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
            "status": status,
        })
        if detail is not UNSET:
            field_dict["detail"] = detail
        if service_info is not UNSET:
            field_dict["service_info"] = service_info

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.service_status_service_info_type_0 import ServiceStatusServiceInfoType0
        d = dict(src_dict)
        name = d.pop("name")

        status = d.pop("status")

        def _parse_detail(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        detail = _parse_detail(d.pop("detail", UNSET))


        def _parse_service_info(data: object) -> None | ServiceStatusServiceInfoType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                service_info_type_0 = ServiceStatusServiceInfoType0.from_dict(data)



                return service_info_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ServiceStatusServiceInfoType0 | Unset, data)

        service_info = _parse_service_info(d.pop("service_info", UNSET))


        service_status = cls(
            name=name,
            status=status,
            detail=detail,
            service_info=service_info,
        )


        service_status.additional_properties = d
        return service_status

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
