from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.file_object import FileObject
from ...models.http_validation_error import HTTPValidationError
from ...models.upload_file_body import UploadFileBody
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    body: UploadFileBody | Unset = UNSET,
    purpose: str | Unset = 'assistants',

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    params: dict[str, Any] = {}

    params["purpose"] = purpose


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/files",
        "params": params,
    }

    if not isinstance(body, Unset):
        _kwargs["files"] = body.to_multipart()



    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> FileObject | HTTPValidationError | None:
    if response.status_code == 201:
        response_201 = FileObject.from_dict(response.json())



        return response_201

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[FileObject | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: UploadFileBody | Unset = UNSET,
    purpose: str | Unset = 'assistants',

) -> Response[FileObject | HTTPValidationError]:
    """ Upload File

     Upload a file (OpenAI-compatible).

    Accepts a single file upload and queues it for processing.

    Args:
        purpose (str | Unset): Intended purpose (always 'assistants') Default: 'assistants'.
        body (UploadFileBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FileObject | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        body=body,
purpose=purpose,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: UploadFileBody | Unset = UNSET,
    purpose: str | Unset = 'assistants',

) -> FileObject | HTTPValidationError | None:
    """ Upload File

     Upload a file (OpenAI-compatible).

    Accepts a single file upload and queues it for processing.

    Args:
        purpose (str | Unset): Intended purpose (always 'assistants') Default: 'assistants'.
        body (UploadFileBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FileObject | HTTPValidationError
     """


    return sync_detailed(
        client=client,
body=body,
purpose=purpose,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: UploadFileBody | Unset = UNSET,
    purpose: str | Unset = 'assistants',

) -> Response[FileObject | HTTPValidationError]:
    """ Upload File

     Upload a file (OpenAI-compatible).

    Accepts a single file upload and queues it for processing.

    Args:
        purpose (str | Unset): Intended purpose (always 'assistants') Default: 'assistants'.
        body (UploadFileBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FileObject | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        body=body,
purpose=purpose,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: UploadFileBody | Unset = UNSET,
    purpose: str | Unset = 'assistants',

) -> FileObject | HTTPValidationError | None:
    """ Upload File

     Upload a file (OpenAI-compatible).

    Accepts a single file upload and queues it for processing.

    Args:
        purpose (str | Unset): Intended purpose (always 'assistants') Default: 'assistants'.
        body (UploadFileBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FileObject | HTTPValidationError
     """


    return (await asyncio_detailed(
        client=client,
body=body,
purpose=purpose,

    )).parsed
