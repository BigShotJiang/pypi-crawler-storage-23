from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.verify_email_request import VerifyEmailRequest
from ...models.verify_email_response import VerifyEmailResponse
from typing import cast



def _get_kwargs(
    *,
    body: VerifyEmailRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/user/verify-email",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | VerifyEmailResponse | None:
    if response.status_code == 200:
        response_200 = VerifyEmailResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | VerifyEmailResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: VerifyEmailRequest,

) -> Response[HTTPValidationError | VerifyEmailResponse]:
    """ Verify Email

     Send verification email with 3-word code to user.
    Calls central server to send the email.

    Note: Fails silently if email already exists to prevent email enumeration attacks.
    Also returns success even on rate limit/errors to avoid information disclosure.

    Args:
        body (VerifyEmailRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | VerifyEmailResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: VerifyEmailRequest,

) -> HTTPValidationError | VerifyEmailResponse | None:
    """ Verify Email

     Send verification email with 3-word code to user.
    Calls central server to send the email.

    Note: Fails silently if email already exists to prevent email enumeration attacks.
    Also returns success even on rate limit/errors to avoid information disclosure.

    Args:
        body (VerifyEmailRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | VerifyEmailResponse
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: VerifyEmailRequest,

) -> Response[HTTPValidationError | VerifyEmailResponse]:
    """ Verify Email

     Send verification email with 3-word code to user.
    Calls central server to send the email.

    Note: Fails silently if email already exists to prevent email enumeration attacks.
    Also returns success even on rate limit/errors to avoid information disclosure.

    Args:
        body (VerifyEmailRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | VerifyEmailResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: VerifyEmailRequest,

) -> HTTPValidationError | VerifyEmailResponse | None:
    """ Verify Email

     Send verification email with 3-word code to user.
    Calls central server to send the email.

    Note: Fails silently if email already exists to prevent email enumeration attacks.
    Also returns success even on rate limit/errors to avoid information disclosure.

    Args:
        body (VerifyEmailRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | VerifyEmailResponse
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
