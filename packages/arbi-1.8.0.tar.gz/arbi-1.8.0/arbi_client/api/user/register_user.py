from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.register_request import RegisterRequest
from typing import cast



def _get_kwargs(
    *,
    body: RegisterRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/user/register",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = response.json()
        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: RegisterRequest,

) -> Response[Any | HTTPValidationError]:
    """ Register User

     Register a new user with email verification (local or SSO).

    Accepts either:
    - 3-word verification code for local users
    - SSO JWT token for SSO users

    Auto-detects credential type and handles both flows.

    Args:
        body (RegisterRequest): Unified user registration request (local and SSO).

            Used by: /user/register

            Accepts either:
            - 3-word verification code (local users): "purple-mountain-river"
            - SSO JWT token (SSO users): "eyJ..." (long token with dots)

            For local users: given_name and family_name are required
            For SSO users: given_name and family_name are optional (extracted from JWT if not
            provided)

            Key derivation:
            1. Client derives Ed25519 keypair from password using Argon2id
            2. Client sends Ed25519 public key (signing_key)
            3. Backend derives X25519 encryption key from Ed25519 signing key

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: RegisterRequest,

) -> Any | HTTPValidationError | None:
    """ Register User

     Register a new user with email verification (local or SSO).

    Accepts either:
    - 3-word verification code for local users
    - SSO JWT token for SSO users

    Auto-detects credential type and handles both flows.

    Args:
        body (RegisterRequest): Unified user registration request (local and SSO).

            Used by: /user/register

            Accepts either:
            - 3-word verification code (local users): "purple-mountain-river"
            - SSO JWT token (SSO users): "eyJ..." (long token with dots)

            For local users: given_name and family_name are required
            For SSO users: given_name and family_name are optional (extracted from JWT if not
            provided)

            Key derivation:
            1. Client derives Ed25519 keypair from password using Argon2id
            2. Client sends Ed25519 public key (signing_key)
            3. Backend derives X25519 encryption key from Ed25519 signing key

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: RegisterRequest,

) -> Response[Any | HTTPValidationError]:
    """ Register User

     Register a new user with email verification (local or SSO).

    Accepts either:
    - 3-word verification code for local users
    - SSO JWT token for SSO users

    Auto-detects credential type and handles both flows.

    Args:
        body (RegisterRequest): Unified user registration request (local and SSO).

            Used by: /user/register

            Accepts either:
            - 3-word verification code (local users): "purple-mountain-river"
            - SSO JWT token (SSO users): "eyJ..." (long token with dots)

            For local users: given_name and family_name are required
            For SSO users: given_name and family_name are optional (extracted from JWT if not
            provided)

            Key derivation:
            1. Client derives Ed25519 keypair from password using Argon2id
            2. Client sends Ed25519 public key (signing_key)
            3. Backend derives X25519 encryption key from Ed25519 signing key

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: RegisterRequest,

) -> Any | HTTPValidationError | None:
    """ Register User

     Register a new user with email verification (local or SSO).

    Accepts either:
    - 3-word verification code for local users
    - SSO JWT token for SSO users

    Auto-detects credential type and handles both flows.

    Args:
        body (RegisterRequest): Unified user registration request (local and SSO).

            Used by: /user/register

            Accepts either:
            - 3-word verification code (local users): "purple-mountain-river"
            - SSO JWT token (SSO users): "eyJ..." (long token with dots)

            For local users: given_name and family_name are required
            For SSO users: given_name and family_name are optional (extracted from JWT if not
            provided)

            Key derivation:
            1. Client derives Ed25519 keypair from password using Argon2id
            2. Client sends Ed25519 public key (signing_key)
            3. Backend derives X25519 encryption key from Ed25519 signing key

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
