from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.create_subscription_request import CreateSubscriptionRequest
from ...models.create_subscription_response import CreateSubscriptionResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    body: CreateSubscriptionRequest,
    origin: str | Unset = UNSET,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(origin, Unset):
        headers["origin"] = origin



    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/user/subscription",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> CreateSubscriptionResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = CreateSubscriptionResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[CreateSubscriptionResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateSubscriptionRequest,
    origin: str | Unset = UNSET,

) -> Response[CreateSubscriptionResponse | HTTPValidationError]:
    """ Create Subscription

     Create a new Stripe checkout session for subscription purchase.

    Args:
        origin (str | Unset):
        body (CreateSubscriptionRequest): Request to create a new subscription checkout session.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateSubscriptionResponse | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        body=body,
origin=origin,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: CreateSubscriptionRequest,
    origin: str | Unset = UNSET,

) -> CreateSubscriptionResponse | HTTPValidationError | None:
    """ Create Subscription

     Create a new Stripe checkout session for subscription purchase.

    Args:
        origin (str | Unset):
        body (CreateSubscriptionRequest): Request to create a new subscription checkout session.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateSubscriptionResponse | HTTPValidationError
     """


    return sync_detailed(
        client=client,
body=body,
origin=origin,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateSubscriptionRequest,
    origin: str | Unset = UNSET,

) -> Response[CreateSubscriptionResponse | HTTPValidationError]:
    """ Create Subscription

     Create a new Stripe checkout session for subscription purchase.

    Args:
        origin (str | Unset):
        body (CreateSubscriptionRequest): Request to create a new subscription checkout session.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateSubscriptionResponse | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        body=body,
origin=origin,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: CreateSubscriptionRequest,
    origin: str | Unset = UNSET,

) -> CreateSubscriptionResponse | HTTPValidationError | None:
    """ Create Subscription

     Create a new Stripe checkout session for subscription purchase.

    Args:
        origin (str | Unset):
        body (CreateSubscriptionRequest): Request to create a new subscription checkout session.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateSubscriptionResponse | HTTPValidationError
     """


    return (await asyncio_detailed(
        client=client,
body=body,
origin=origin,

    )).parsed
