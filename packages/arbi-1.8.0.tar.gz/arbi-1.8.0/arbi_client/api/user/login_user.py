from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.login_request import LoginRequest
from ...models.login_response import LoginResponse
from typing import cast



def _get_kwargs(
    *,
    body: LoginRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/user/login",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | LoginResponse | None:
    if response.status_code == 200:
        response_200 = LoginResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | LoginResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: LoginRequest,

) -> Response[HTTPValidationError | LoginResponse]:
    r""" Login User

     Login with Ed25519 signature verification (local or SSO).

    Authentication flow:
    1. Client derives Ed25519 keypair from password
    2. Client signs \"email|timestamp\" with Ed25519 private key
    3. Server verifies signature using stored Ed25519 public key
    4. Server encrypts response with stored X25519 public key

    For SSO users: Also validates SSO token before proceeding.

    Returns encrypted login response that only the correct password can decrypt.

    Args:
        body (LoginRequest): Unified login request (local and SSO).

            For local users: email + signature + timestamp
            For SSO users: email + signature + timestamp + sso_token

            Authentication flow:
            1. Client derives Ed25519 keypair from password
            2. Client signs "email|timestamp" with Ed25519 private key
            3. Server verifies signature using stored Ed25519 public key
            4. Server derives X25519 from Ed25519 for session key encryption

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | LoginResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: LoginRequest,

) -> HTTPValidationError | LoginResponse | None:
    r""" Login User

     Login with Ed25519 signature verification (local or SSO).

    Authentication flow:
    1. Client derives Ed25519 keypair from password
    2. Client signs \"email|timestamp\" with Ed25519 private key
    3. Server verifies signature using stored Ed25519 public key
    4. Server encrypts response with stored X25519 public key

    For SSO users: Also validates SSO token before proceeding.

    Returns encrypted login response that only the correct password can decrypt.

    Args:
        body (LoginRequest): Unified login request (local and SSO).

            For local users: email + signature + timestamp
            For SSO users: email + signature + timestamp + sso_token

            Authentication flow:
            1. Client derives Ed25519 keypair from password
            2. Client signs "email|timestamp" with Ed25519 private key
            3. Server verifies signature using stored Ed25519 public key
            4. Server derives X25519 from Ed25519 for session key encryption

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | LoginResponse
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: LoginRequest,

) -> Response[HTTPValidationError | LoginResponse]:
    r""" Login User

     Login with Ed25519 signature verification (local or SSO).

    Authentication flow:
    1. Client derives Ed25519 keypair from password
    2. Client signs \"email|timestamp\" with Ed25519 private key
    3. Server verifies signature using stored Ed25519 public key
    4. Server encrypts response with stored X25519 public key

    For SSO users: Also validates SSO token before proceeding.

    Returns encrypted login response that only the correct password can decrypt.

    Args:
        body (LoginRequest): Unified login request (local and SSO).

            For local users: email + signature + timestamp
            For SSO users: email + signature + timestamp + sso_token

            Authentication flow:
            1. Client derives Ed25519 keypair from password
            2. Client signs "email|timestamp" with Ed25519 private key
            3. Server verifies signature using stored Ed25519 public key
            4. Server derives X25519 from Ed25519 for session key encryption

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | LoginResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: LoginRequest,

) -> HTTPValidationError | LoginResponse | None:
    r""" Login User

     Login with Ed25519 signature verification (local or SSO).

    Authentication flow:
    1. Client derives Ed25519 keypair from password
    2. Client signs \"email|timestamp\" with Ed25519 private key
    3. Server verifies signature using stored Ed25519 public key
    4. Server encrypts response with stored X25519 public key

    For SSO users: Also validates SSO token before proceeding.

    Returns encrypted login response that only the correct password can decrypt.

    Args:
        body (LoginRequest): Unified login request (local and SSO).

            For local users: email + signature + timestamp
            For SSO users: email + signature + timestamp + sso_token

            Authentication flow:
            1. Client derives Ed25519 keypair from password
            2. Client signs "email|timestamp" with Ed25519 private key
            3. Server verifies signature using stored Ed25519 public key
            4. Server derives X25519 from Ed25519 for session key encryption

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | LoginResponse
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
