from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.workspace_response import WorkspaceResponse
from ...models.workspace_update_request import WorkspaceUpdateRequest
from typing import cast



def _get_kwargs(
    *,
    body: WorkspaceUpdateRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v1/workspace/",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | WorkspaceResponse | None:
    if response.status_code == 200:
        response_200 = WorkspaceResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | WorkspaceResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: WorkspaceUpdateRequest,

) -> Response[HTTPValidationError | WorkspaceResponse]:
    """ Update Workspace

     Update workspace metadata such as name, description, or public status.
    Changes are persisted to the database.

    Only developers can change the is_public field.
    When making a workspace public, the workspace key from the JWT is used.

    Args:
        body (WorkspaceUpdateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | WorkspaceResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: WorkspaceUpdateRequest,

) -> HTTPValidationError | WorkspaceResponse | None:
    """ Update Workspace

     Update workspace metadata such as name, description, or public status.
    Changes are persisted to the database.

    Only developers can change the is_public field.
    When making a workspace public, the workspace key from the JWT is used.

    Args:
        body (WorkspaceUpdateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | WorkspaceResponse
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: WorkspaceUpdateRequest,

) -> Response[HTTPValidationError | WorkspaceResponse]:
    """ Update Workspace

     Update workspace metadata such as name, description, or public status.
    Changes are persisted to the database.

    Only developers can change the is_public field.
    When making a workspace public, the workspace key from the JWT is used.

    Args:
        body (WorkspaceUpdateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | WorkspaceResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: WorkspaceUpdateRequest,

) -> HTTPValidationError | WorkspaceResponse | None:
    """ Update Workspace

     Update workspace metadata such as name, description, or public status.
    Changes are persisted to the database.

    Only developers can change the is_public field.
    When making a workspace public, the workspace key from the JWT is used.

    Args:
        body (WorkspaceUpdateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | WorkspaceResponse
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
