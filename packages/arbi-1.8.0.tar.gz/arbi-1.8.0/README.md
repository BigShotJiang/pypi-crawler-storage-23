# arbi

Official Python client for the [ARBI](https://arbicity.com) API, auto-generated from the OpenAPI specification.

## Installation

```bash
pip install arbi
```

## Quick start

```python
from arbi_client import Client, AuthenticatedClient
from arbi_client.api.user import login_user
from arbi_client.models import LoginRequest

# 1. Log in with the unauthenticated client
with Client(base_url="https://your-instance.arbicity.com") as c:
    response = login_user.sync_detailed(
        client=c,
        body=LoginRequest(
            email="user@example.com",
            signature="<base64-ed25519-signature>",
            timestamp=1700000000,
        ),
    )
    login = response.parsed
    token = login.access_token

# 2. Use the JWT for all authenticated requests
with AuthenticatedClient(base_url="https://your-instance.arbicity.com", token=token) as c:
    ...
```

Login uses Ed25519 signature-based authentication: the client derives a keypair from the user's password, signs `email|timestamp`, and sends the signature. The server verifies it against the stored public key and returns a JWT. See the [ARBI documentation](https://arbicity.com) for details on the key derivation and signing process.

## Async support

Every endpoint has both sync and async variants:

```python
from arbi_client import AuthenticatedClient
from arbi_client.api.user import get_user_workspaces

async with AuthenticatedClient(base_url="https://your-instance.arbicity.com", token=token) as c:
    workspaces = await get_user_workspaces.asyncio(client=c)
```

## API structure

Each endpoint is a Python module with four functions:

| Function           | Blocking | Returns                |
|--------------------|----------|------------------------|
| `sync`             | Yes      | Parsed data or `None`  |
| `sync_detailed`    | Yes      | Full `Response` object |
| `asyncio`          | No       | Parsed data or `None`  |
| `asyncio_detailed` | No       | Full `Response` object |

Endpoints are grouped by tag under `arbi_client.api`:

```
arbi_client.api.user          # login, register, settings
arbi_client.api.workspace     # workspace management
arbi_client.api.document      # document upload and tagging
arbi_client.api.conversation  # conversations and messages
arbi_client.api.assistant     # AI assistant queries
arbi_client.api.tag           # tag management
arbi_client.api.configs       # configuration management
arbi_client.api.notifications # notification management
arbi_client.api.health        # health checks
```

## Links

- [ARBI](https://arbicity.com)
- [PyPI](https://pypi.org/project/arbi/)
