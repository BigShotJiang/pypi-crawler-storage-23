# NativeBridge CLI

Connect to cloud Android devices via ADB — as if they were plugged in locally.

NativeBridge CLI authenticates with your API key, authorizes your IP, and establishes an ADB connection to cloud-hosted Android devices through a secure TCP proxy.

## Installation

```bash
pip install nativebridge
```

**Prerequisite:** [Android SDK Platform Tools](https://developer.android.com/tools/releases/platform-tools) must be installed and `adb` available on your PATH.

## Quick Start

```bash
# 1. Save your API key (one-time)
nativebridge login --api-key YOUR_API_KEY

# 2. Connect to a cloud device
nativebridge connect --device SESSION_ID

# 3. Use ADB as usual
nativebridge adb -s host:port shell
```

## Commands

### `login` — Save API key

```bash
nativebridge login --api-key nb_live_abc123
nativebridge login --api-key nb_live_abc123 --api-base https://custom.api.com
```

Saves your API key to `~/.nativebridge/config.json` so you don't need to pass it every time.

### `logout` — Remove saved API key

```bash
nativebridge logout
```

### `connect` — Connect to a cloud device

```bash
nativebridge connect --device SESSION_ID
nativebridge connect -d SESSION_ID --api-key nb_live_abc123
```

This command:
1. Validates your API key with the NativeBridge backend
2. Authorizes your IP address for ADB access
3. Runs `adb connect` to the cloud device

On success, you'll see the connection details and quick-start commands.

### `disconnect` — Disconnect from a cloud device

```bash
nativebridge disconnect --device SESSION_ID
nativebridge disconnect -d SESSION_ID
```

### `devices` — List connected ADB devices

```bash
nativebridge devices
```

Runs `adb devices -l` and displays the output.

### `status` — Show CLI configuration

```bash
nativebridge status
```

Displays your current API base URL, masked API key, and connected ADB devices.

### `adb` — ADB passthrough

```bash
nativebridge adb devices
nativebridge adb -s host:port shell
nativebridge adb -s host:port install app.apk
nativebridge adb -s host:port push local.txt /sdcard/
nativebridge adb -s host:port logcat
nativebridge adb -s host:port shell pm list packages
```

Passes any arguments directly to `adb`. This is a convenience wrapper so you can use a single tool for all device interactions.

## Configuration

NativeBridge CLI reads configuration in the following order (first match wins):

| Setting  | Environment Variable      | Config File Key | Default                    |
|----------|---------------------------|-----------------|----------------------------|
| API Key  | `NATIVEBRIDGE_API_KEY`    | `api_key`       | —                          |
| API Base | `NATIVEBRIDGE_API_BASE`   | `api_base`      | `https://api.nativebridge.io` |

Config file location: `~/.nativebridge/config.json`

## Requirements

- Python 3.8+
- `adb` (Android SDK Platform Tools) on your PATH
- A NativeBridge API key

## License

MIT License. See [LICENSE](LICENSE) for details.
