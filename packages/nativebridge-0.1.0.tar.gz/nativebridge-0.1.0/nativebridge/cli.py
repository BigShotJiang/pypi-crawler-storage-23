import argparse
import sys
import textwrap

from nativebridge import __version__
from nativebridge.api import APIError, authorize_adb
from nativebridge.adb import (
    adb_connect,
    adb_disconnect,
    adb_devices,
    adb_passthrough,
    check_adb_installed,
)
from nativebridge.config import get_api_key, get_api_base, save_config, delete_config_key

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table

    console = Console()
    err_console = Console(stderr=True)
    HAS_RICH = True
except ImportError:
    HAS_RICH = False
    console = None
    err_console = None


# ─── Helpers ──────────────────────────────────────────────────────────────────


def _success(msg: str):
    if HAS_RICH:
        console.print(f"[bold green]✔[/] {msg}")
    else:
        print(f"✔ {msg}")


def _info(msg: str):
    if HAS_RICH:
        console.print(f"[bold blue]ℹ[/] {msg}")
    else:
        print(f"ℹ {msg}")


def _warn(msg: str):
    if HAS_RICH:
        err_console.print(f"[bold yellow]⚠[/] {msg}")
    else:
        print(f"⚠ {msg}", file=sys.stderr)


def _error(msg: str):
    if HAS_RICH:
        err_console.print(f"[bold red]✖[/] {msg}")
    else:
        print(f"✖ {msg}", file=sys.stderr)


def _dim(msg: str):
    if HAS_RICH:
        console.print(f"[dim]{msg}[/]")
    else:
        print(msg)


def _mask_key(key: str) -> str:
    if len(key) <= 8:
        return "***" + key[-4:]
    return key[:4] + "…" + key[-4:]


# ─── Commands ─────────────────────────────────────────────────────────────────


def cmd_login(args):
    """Save API key locally for future use."""
    save_config({"api_key": args.api_key})
    if args.api_base:
        save_config({"api_base": args.api_base})
    _success("API key saved to ~/.nativebridge/config.json")
    _dim(f"  Key: {_mask_key(args.api_key)}")
    if args.api_base:
        _dim(f"  API base: {args.api_base}")


def cmd_logout(args):
    """Remove saved API key."""
    delete_config_key("api_key")
    _success("API key removed.")


def cmd_connect(args):
    """Authorize and connect to a cloud device via ADB."""
    api_key = args.api_key or get_api_key()
    if not api_key:
        _error("No API key provided.")
        _info("Pass --api-key or run: nativebridge login --api-key YOUR_KEY")
        sys.exit(1)

    if not check_adb_installed():
        _error("adb not found on PATH.")
        _info("Install Android SDK platform-tools and ensure 'adb' is in your PATH.")
        sys.exit(1)

    session_id = args.device

    # Step 1: Authorize
    _info(f"Authorizing connection to session [bold]{session_id}[/bold]..." if HAS_RICH else f"Authorizing connection to session {session_id}...")
    try:
        result = authorize_adb(api_key, session_id)
    except APIError as e:
        if e.status_code in (401, 403):
            _error(f"Authentication failed — {e.detail}")
        elif e.status_code == 404:
            _error(f"Session '{session_id}' not found.")
        else:
            _error(e.detail)
        sys.exit(1)

    port = result["port"]
    proxy_host = result["proxy_host"]
    ttl = result.get("ttl", 0)
    client_ip = result.get("client_ip", "unknown")

    minutes, seconds = divmod(ttl, 60)
    _success(f"Authorized — IP {client_ip} for {minutes}m {seconds}s")

    # Step 2: ADB connect
    target = f"{proxy_host}:{port}"
    _info(f"Connecting: adb connect {target}")
    success, output = adb_connect(proxy_host, port)

    if success:
        _success(f"Connected to {target}")
        print()
        if HAS_RICH:
            table = Table(show_header=False, box=None, padding=(0, 2))
            table.add_column(style="dim")
            table.add_column(style="bold")
            table.add_row("Shell", f"adb -s {target} shell")
            table.add_row("Install", f"adb -s {target} install app.apk")
            table.add_row("Push", f"adb -s {target} push local.txt /sdcard/")
            table.add_row("Logcat", f"adb -s {target} logcat")
            console.print(Panel(table, title="[bold]Quick Commands[/]", border_style="green", expand=False))
            print()
            _dim(f"Or use the built-in wrapper:  nativebridge adb -s {target} shell")
        else:
            print(f"  adb -s {target} shell")
            print(f"  adb -s {target} install app.apk")
            print(f"  adb -s {target} push local.txt /sdcard/")
    else:
        _error(f"ADB connection failed: {output}")
        sys.exit(1)


def cmd_disconnect(args):
    """Disconnect from a cloud device."""
    api_key = args.api_key or get_api_key()
    session_id = args.device

    if not api_key:
        _error("API key required to resolve session.")
        _info("Pass --api-key or run: nativebridge login --api-key YOUR_KEY")
        sys.exit(1)

    _info(f"Resolving session {session_id}...")
    try:
        result = authorize_adb(api_key, session_id)
    except APIError as e:
        _error(f"Cannot resolve session: {e.detail}")
        sys.exit(1)

    port = result["port"]
    proxy_host = result["proxy_host"]
    target = f"{proxy_host}:{port}"

    success, output = adb_disconnect(proxy_host, port)
    if success:
        _success(f"Disconnected from {target}")
    else:
        _error(f"Disconnect failed: {output}")
        sys.exit(1)


def cmd_devices(args):
    """List connected ADB devices."""
    if not check_adb_installed():
        _error("adb not found on PATH.")
        sys.exit(1)
    output = adb_devices()
    print(output)


def cmd_status(args):
    """Show current configuration and connection status."""
    api_key = get_api_key()
    api_base = get_api_base()

    if HAS_RICH:
        table = Table(show_header=False, box=None, padding=(0, 2))
        table.add_column(style="bold")
        table.add_column()
        table.add_row("API Base", api_base)
        table.add_row("API Key", _mask_key(api_key) if api_key else "[dim]Not set[/]")
        console.print(Panel(table, title="[bold]Configuration[/]", expand=False))
        print()
    else:
        print(f"API Base:  {api_base}")
        print(f"API Key:   {_mask_key(api_key) if api_key else 'Not set'}")
        print()

    print("Connected ADB devices:")
    if check_adb_installed():
        print(adb_devices())
    else:
        _warn("adb not found — cannot list devices.")


def cmd_adb(args):
    """Pass commands directly to adb."""
    exit_code = adb_passthrough(args.adb_args)
    sys.exit(exit_code)


# ─── Argument Parser ──────────────────────────────────────────────────────────


class CustomFormatter(argparse.RawDescriptionHelpFormatter):
    """Formatter that preserves description newlines and widens help."""

    def __init__(self, prog, **kwargs):
        kwargs.setdefault("max_help_position", 30)
        kwargs.setdefault("width", 90)
        super().__init__(prog, **kwargs)


MAIN_DESCRIPTION = textwrap.dedent("""\
    NativeBridge CLI — Connect to cloud Android devices via ADB.

    Authenticate with your API key, then use ADB commands as if the
    device were connected locally.

    Quick start:
      nativebridge login --api-key YOUR_KEY
      nativebridge connect --device SESSION_ID
      nativebridge adb shell
""")

MAIN_EPILOG = textwrap.dedent("""\
    examples:
      nativebridge login --api-key nb_live_abc123
      nativebridge connect --device a1b2c3
      nativebridge adb -s host:5432 shell
      nativebridge adb -s host:5432 install app.apk
      nativebridge devices
      nativebridge status

    documentation:
      https://docs.nativebridge.io/cli
""")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="nativebridge",
        description=MAIN_DESCRIPTION,
        epilog=MAIN_EPILOG,
        formatter_class=CustomFormatter,
    )
    parser.add_argument(
        "-v", "--version",
        action="version",
        version=f"nativebridge {__version__}",
    )

    sub = parser.add_subparsers(dest="command", title="commands", metavar="<command>")

    # ── login ──
    p_login = sub.add_parser(
        "login",
        help="Save API key for future use",
        description="Save your NativeBridge API key locally so you don't need to pass it every time.",
        epilog="example:\n  nativebridge login --api-key nb_live_abc123",
        formatter_class=CustomFormatter,
    )
    p_login.add_argument("--api-key", required=True, metavar="KEY", help="Your NativeBridge API key")
    p_login.add_argument("--api-base", metavar="URL", help="Custom API base URL (advanced)")

    # ── logout ──
    sub.add_parser(
        "logout",
        help="Remove saved API key",
        description="Remove the locally saved API key from ~/.nativebridge/config.json.",
        formatter_class=CustomFormatter,
    )

    # ── connect ──
    p_connect = sub.add_parser(
        "connect",
        help="Authorize and connect to a cloud device",
        description=textwrap.dedent("""\
            Authenticate with the NativeBridge backend, authorize your IP,
            and run `adb connect` to the cloud device.

            The session ID can be the short ID (e.g. a1b2c3) or the full
            MongoDB ID shown in the dashboard.
        """),
        epilog=textwrap.dedent("""\
            examples:
              nativebridge connect --device a1b2c3
              nativebridge connect --device a1b2c3 --api-key nb_live_abc123
        """),
        formatter_class=CustomFormatter,
    )
    p_connect.add_argument("--device", "-d", required=True, metavar="SESSION_ID", help="Session ID (short or full)")
    p_connect.add_argument("--api-key", metavar="KEY", help="API key (overrides saved key)")

    # ── disconnect ──
    p_disconnect = sub.add_parser(
        "disconnect",
        help="Disconnect from a cloud device",
        description="Resolve the session to its ADB target and disconnect.",
        epilog="example:\n  nativebridge disconnect --device a1b2c3",
        formatter_class=CustomFormatter,
    )
    p_disconnect.add_argument("--device", "-d", required=True, metavar="SESSION_ID", help="Session ID to disconnect")
    p_disconnect.add_argument("--api-key", metavar="KEY", help="API key (overrides saved key)")

    # ── devices ──
    sub.add_parser(
        "devices",
        help="List connected ADB devices",
        description="Run `adb devices -l` and display the output.",
        formatter_class=CustomFormatter,
    )

    # ── status ──
    sub.add_parser(
        "status",
        help="Show CLI configuration and connection info",
        description="Display the current API base, masked API key, and connected ADB devices.",
        formatter_class=CustomFormatter,
    )

    # ── adb (passthrough) ──
    p_adb = sub.add_parser(
        "adb",
        help="Run any ADB command (passthrough)",
        description=textwrap.dedent("""\
            Pass any arguments directly to adb. Everything after
            `nativebridge adb` is forwarded as-is.

            This is a convenience wrapper so you can keep using a single
            tool for all device interactions.
        """),
        epilog=textwrap.dedent("""\
            examples:
              nativebridge adb devices
              nativebridge adb -s host:5432 shell
              nativebridge adb -s host:5432 install app.apk
              nativebridge adb -s host:5432 push local.txt /sdcard/
              nativebridge adb -s host:5432 logcat
              nativebridge adb -s host:5432 shell pm list packages
        """),
        formatter_class=CustomFormatter,
    )
    p_adb.add_argument("adb_args", nargs=argparse.REMAINDER, metavar="...", help="Arguments passed to adb")

    return parser


# ─── Entrypoint ───────────────────────────────────────────────────────────────


def main():
    parser = build_parser()
    args = parser.parse_args()

    if not args.command:
        if HAS_RICH:
            console.print(
                Panel(
                    "[bold]NativeBridge CLI[/] — Connect to cloud Android devices via ADB.\n\n"
                    f"[dim]Version {__version__}[/]\n\n"
                    "Run [bold]nativebridge --help[/] for usage information.",
                    border_style="blue",
                    expand=False,
                )
            )
        else:
            parser.print_help()
        sys.exit(0)

    commands = {
        "login": cmd_login,
        "logout": cmd_logout,
        "connect": cmd_connect,
        "disconnect": cmd_disconnect,
        "devices": cmd_devices,
        "status": cmd_status,
        "adb": cmd_adb,
    }

    commands[args.command](args)


if __name__ == "__main__":
    main()
