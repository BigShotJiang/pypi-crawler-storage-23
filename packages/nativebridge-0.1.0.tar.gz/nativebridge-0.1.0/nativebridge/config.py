import json
import os
from pathlib import Path
from typing import Optional

CONFIG_DIR = Path.home() / ".nativebridge"
CONFIG_FILE = CONFIG_DIR / "config.json"

DEFAULT_API_BASE = "https://api.nativebridge.io"


def _ensure_config_dir():
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def load_config() -> dict:
    """Load saved config from ~/.nativebridge/config.json"""
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def save_config(data: dict):
    """Merge and save config to ~/.nativebridge/config.json"""
    _ensure_config_dir()
    existing = load_config()
    existing.update(data)
    CONFIG_FILE.write_text(json.dumps(existing, indent=2))


def delete_config_key(key: str):
    """Remove a key from config"""
    config = load_config()
    config.pop(key, None)
    _ensure_config_dir()
    CONFIG_FILE.write_text(json.dumps(config, indent=2))


def get_api_key() -> Optional[str]:
    """Get API key from env var > saved config"""
    return os.environ.get("NATIVEBRIDGE_API_KEY") or load_config().get("api_key")


def get_api_base() -> str:
    """Get API base URL from env var > saved config > default"""
    return (
        os.environ.get("NATIVEBRIDGE_API_BASE")
        or load_config().get("api_base")
        or DEFAULT_API_BASE
    )
