import requests
from nativebridge.config import get_api_base


class APIError(Exception):
    """Raised when the NativeBridge API returns a non-200 response."""

    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"[{status_code}] {detail}")


def _headers(api_key: str) -> dict:
    return {
        "X-Api-Key": api_key,
        "Content-Type": "application/json",
    }


def _extract_error(resp: requests.Response) -> str:
    try:
        body = resp.json()
        return body.get("detail") or body.get("message") or resp.text
    except Exception:
        return resp.text


def authorize_adb(api_key: str, session_id: str) -> dict:
    """
    Validate API key and authorize this machine's IP for ADB access.

    Returns dict with: status, port, proxy_host, session_id, ttl, client_ip
    """
    url = f"{get_api_base()}/api/v1/adb/authorize"
    try:
        resp = requests.post(
            url,
            json={"session_id": session_id},
            headers=_headers(api_key),
            timeout=15,
        )
    except requests.ConnectionError:
        raise APIError(0, f"Cannot reach NativeBridge API at {get_api_base()}")
    except requests.Timeout:
        raise APIError(0, "Request timed out — check your network connection")

    if resp.status_code == 200:
        return resp.json()

    raise APIError(resp.status_code, _extract_error(resp))
