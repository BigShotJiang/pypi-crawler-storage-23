import shutil
import subprocess
import sys
from typing import List, Optional, Tuple


def check_adb_installed() -> bool:
    """Check if adb is available on PATH."""
    return shutil.which("adb") is not None


def get_adb_path() -> Optional[str]:
    """Return the full path to adb, or None."""
    return shutil.which("adb")


def adb_connect(host: str, port: int) -> Tuple[bool, str]:
    """Run `adb connect host:port` and return (success, output)."""
    target = f"{host}:{port}"
    try:
        result = subprocess.run(
            ["adb", "connect", target],
            capture_output=True,
            text=True,
            timeout=30,
        )
        output = (result.stdout + result.stderr).strip()
        success = "connected to" in output.lower() or "already connected" in output.lower()
        return success, output
    except subprocess.TimeoutExpired:
        return False, "adb connect timed out after 30 seconds"
    except FileNotFoundError:
        return False, "adb not found. Install Android SDK platform-tools."


def adb_disconnect(host: str, port: int) -> Tuple[bool, str]:
    """Run `adb disconnect host:port` and return (success, output)."""
    target = f"{host}:{port}"
    try:
        result = subprocess.run(
            ["adb", "disconnect", target],
            capture_output=True,
            text=True,
            timeout=10,
        )
        output = (result.stdout + result.stderr).strip()
        success = "disconnected" in output.lower() or result.returncode == 0
        return success, output
    except Exception as e:
        return False, str(e)


def adb_devices() -> str:
    """Run `adb devices -l` and return the output."""
    try:
        result = subprocess.run(
            ["adb", "devices", "-l"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return (result.stdout + result.stderr).strip()
    except Exception as e:
        return f"Error: {e}"


def adb_passthrough(args: List[str]) -> int:
    """
    Pass any arguments directly to adb, streaming stdout/stderr to the terminal.
    Returns the adb exit code.
    """
    if not check_adb_installed():
        print("Error: adb not found on PATH.", file=sys.stderr)
        print("Install Android SDK platform-tools and ensure 'adb' is in your PATH.", file=sys.stderr)
        return 1

    try:
        proc = subprocess.run(
            ["adb"] + args,
            stdin=sys.stdin,
            stdout=sys.stdout,
            stderr=sys.stderr,
        )
        return proc.returncode
    except KeyboardInterrupt:
        return 130
    except Exception as e:
        print(f"Error running adb: {e}", file=sys.stderr)
        return 1
