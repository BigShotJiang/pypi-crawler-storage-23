# sumo-wrapper-python

[![Documentation Status](https://readthedocs.org/projects/sumo-wrapper-python/badge/?version=latest)](https://sumo-wrapper-python.readthedocs.io/en/latest/?badge=latest)
[![SCM Compliance](https://scm-compliance-api.radix.equinor.com/repos/equinor/sumo-wrapper-python/badge)](https://scm-compliance-api.radix.equinor.com/repos/equinor/sumo-wrapper-python/badge)

## Documentation and guidelines
[sumo-wrapper-python documentation](https://sumo-wrapper-python.readthedocs.io/en/latest/)

## Contribute
[Contribution guidelines](./CONTRIBUTING.md)

