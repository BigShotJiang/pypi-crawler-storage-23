.. sumo-wrapper-python documentation master file, created by
   sphinx-quickstart on Wed Jun  8 15:11:37 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to sumo-wrapper-python's documentation!
===============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   self
   sumo-wrapper-python
   api
