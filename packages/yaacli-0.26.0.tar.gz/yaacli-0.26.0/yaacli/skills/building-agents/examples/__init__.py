"""Example scripts for ya-agent-sdk.

This package contains example scripts demonstrating various use cases.
To use these examples, install with the examples extra:

    pip install "ya-agent-sdk[examples]"

Or for development:

    uv sync --extra examples
"""
