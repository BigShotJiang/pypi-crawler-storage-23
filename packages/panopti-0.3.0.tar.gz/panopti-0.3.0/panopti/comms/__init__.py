# panopti/comms/__init__.py
from .websocket import SocketManager

__all__ = ['SocketManager']