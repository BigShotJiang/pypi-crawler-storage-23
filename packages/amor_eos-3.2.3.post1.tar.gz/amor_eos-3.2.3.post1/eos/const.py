"""
Constants used in data reduction.
"""

hdm = 6.626176e-34/1.674928e-27  # h / m
lamdaCut = 2.5  # Aa
lamdaMax = 15.0 # Aa

polarizationConfigs = ['unpolarized', 'unpolarized', 'po', 'mo', 'op', 'pp', 'mp', 'om', 'pm', 'mm']
polarizationLabels = ['undetermined', 'unpolarized', 'spin-up', 'spin-down', 'op',
                      'up-up', 'down-up', 'om', 'up-down', 'down-down']
