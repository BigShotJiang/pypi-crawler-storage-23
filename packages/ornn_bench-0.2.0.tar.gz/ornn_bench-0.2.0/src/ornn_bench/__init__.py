"""Ornn GPU Benchmarking CLI."""

__version__ = "0.2.0"
