# ec2-tui (Deprecated)

**This package has been renamed to [servonaut](https://pypi.org/project/servonaut/).**

```bash
pipx uninstall ec2-tui
pipx install servonaut
```
