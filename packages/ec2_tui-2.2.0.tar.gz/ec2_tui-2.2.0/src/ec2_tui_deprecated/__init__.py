import sys

def main():
    print("\n  ec2-tui has been renamed to 'servonaut'.")
    print("  Please reinstall with:\n")
    print("    pipx uninstall ec2-tui")
    print("    pipx install servonaut\n")
    print("  Then run: servonaut\n")
    sys.exit(0)
