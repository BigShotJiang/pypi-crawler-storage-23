*******************
LLM Message History
*******************

SemanticMessageHistory
======================

.. _semantic_message_history_api:

.. currentmodule:: redisvl.extensions.message_history.semantic_history

.. autoclass:: SemanticMessageHistory
   :show-inheritance:
   :members:
   :inherited-members:


MessageHistory
==============

.. _message_history_api:

.. currentmodule:: redisvl.extensions.message_history.message_history

.. autoclass:: MessageHistory
   :show-inheritance:
   :members:
   :inherited-members:
