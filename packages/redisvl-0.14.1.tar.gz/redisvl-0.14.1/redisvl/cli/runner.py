from redisvl.cli.main import RedisVlCLI


def main():
    """Main call to init the RedisVL CLI tool."""
    RedisVlCLI()


if __name__ == "__main__":
    main()
