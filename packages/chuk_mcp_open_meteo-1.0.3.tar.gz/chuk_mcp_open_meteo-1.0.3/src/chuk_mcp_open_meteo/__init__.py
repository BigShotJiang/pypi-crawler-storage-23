"""Chuk MCP Open-Meteo: Comprehensive weather data MCP server."""

__version__ = "1.0.0"
