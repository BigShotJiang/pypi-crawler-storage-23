"""Allow running as python -m proxypin_mcp."""

from .server import main

if __name__ == "__main__":
    main()
