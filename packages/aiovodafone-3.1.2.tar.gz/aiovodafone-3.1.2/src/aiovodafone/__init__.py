"""aiovodafone library."""

__version__ = "3.1.2"
