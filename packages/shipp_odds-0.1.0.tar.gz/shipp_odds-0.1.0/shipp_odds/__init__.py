"""
shipp-odds: Real-time betting odds monitoring with line movements and cross-sportsbook comparison.
"""
__version__ = "0.1.0"
