"""auto-yes: automatically respond 'yes' to interactive CLI prompts."""

__version__ = "0.2.0"
