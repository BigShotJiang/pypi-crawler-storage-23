from setuptools import setup, find_packages

setup(
    name="saleshub-cli",
    version="0.1.3",
    packages=find_packages(),
    install_requires=[
        "click",
        "requests",
        "tabulate",
        "websocket-client",
    ],
    entry_points={
        "console_scripts": [
            "saleshub=salescode.cli:cli",
        ],
    },
)
