import os
import json
import click
import requests
import sys
import datetime
from pathlib import Path
from tabulate import tabulate
import websocket
import threading
import time

CONFIG_DIR = Path.home() / ".saleshub"
CONFIG_FILE = CONFIG_DIR / "config.json"

def save_config(config):
    CONFIG_DIR.mkdir(exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)

def load_config():
    if not CONFIG_FILE.exists():
        return {}
    with open(CONFIG_FILE, "r") as f:
        return json.load(f)

def truncate(text, max_length=100):
    text = str(text)
    return (text[:max_length] + '...') if len(text) > max_length else text

def get_token(config, force_refresh=False):
    if not force_refresh and config.get("token"):
        # Check if token is still valid (minimal check, or just try and catch 401)
        return config.get("token")
    
    # Login to get new token
    login_url = f"{config['base_url']}/auth/login"
    payload = {
        "tenantId": config["tenant_id"],
        "username": config["username"],
        "password": config["password"]
    }
    
    try:
        resp = requests.post(login_url, json=payload)
        resp.raise_for_status()
        token = resp.json().get("token")
        config["token"] = token
        save_config(config)
        return token
    except Exception as e:
        click.echo(f"Error: Login failed: {e}", err=True)
        sys.exit(1)

def request_with_auth(method, url, config, **kwargs):
    token = get_token(config)
    headers = kwargs.get("headers", {})
    headers["Authorization"] = f"Bearer {token}"
    headers["X-Tenant-Id"] = config["tenant_id"]
    kwargs["headers"] = headers
    
    resp = requests.request(method, url, **kwargs)
    
    if resp.status_code == 401:
        # Token might be expired, try once more with refresh
        token = get_token(config, force_refresh=True)
        headers["Authorization"] = f"Bearer {token}"
        resp = requests.request(method, url, **kwargs)
        
    return resp

@click.group()
def cli():
    """SalesHub Command Line Interface"""
    pass

@cli.command()
@click.option("--base-url", prompt="Base URL", help="API Base URL (e.g. http://localhost:8080)")
@click.option("--tenant-id", prompt="Tenant ID", help="Default Tenant ID")
@click.option("--username", prompt="Username", help="Username")
@click.option("--password", prompt="Password", hide_input=True, help="Password")
def configure(base_url, tenant_id, username, password):
    """Configure SalesHub CLI credentials"""
    config = {
        "base_url": base_url.rstrip("/"),
        "tenant_id": tenant_id,
        "username": username,
        "password": password
    }
    # Test login
    click.echo("Testing credentials...")
    get_token(config, force_refresh=True)
    click.echo("Configuration saved successfully!")

@cli.command()
def login():
    """Explicitly refresh the authentication token"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return
    click.echo("Logging in...")
    get_token(config, force_refresh=True)
    click.echo("Login successful! Token updated.")

@cli.command()
def status():
    """Show current configuration status"""
    config = load_config()
    if not config:
        click.echo("Not configured.")
        return
    click.echo(f"Base URL:  {config.get('base_url')}")
    click.echo(f"Tenant ID: {config.get('tenant_id')}")
    click.echo(f"Username:  {config.get('username')}")
    if config.get("token"):
        click.echo("Token:     [SET]")
    else:
        click.echo("Token:     [NOT SET]")

@cli.group()
def tenants():
    """Tenant management commands"""
    pass

@click.group(name="meta-catalog")
def meta_catalog():
    """Catalog metadata management commands"""
    pass

cli.add_command(meta_catalog)

@meta_catalog.command(name="list")
@click.option("--type", type=click.Choice(['BRAND', 'CATEGORY', 'SUBCATEGORY', 'MOTHERCODE', 'GROUP'], case_sensitive=False), help="Filter by type")
@click.option("--parent-type", help="Filter by parent type")
@click.option("--parent-code", help="Filter by parent code")
@click.option("--q", help="Search query")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def list_meta(type, parent_type, parent_code, q, raw):
    """List catalog metadata (Brands, Categories, etc.)"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    params = {}
    if type: params["type"] = type.upper()
    if parent_type: params["parentType"] = parent_type
    if parent_code: params["parentCode"] = parent_code
    if q: params["q"] = q
    params["limit"] = 100

    url = f"{config['base_url']}/catalog/meta"
    resp = request_with_auth("GET", url, config, params=params)
    
    if resp.status_code == 200:
        items = resp.json()
        if raw:
            click.echo(json.dumps(items, indent=2))
        else:
            table_data = []
            for i in items:
                table_data.append([
                    i.get("type"),
                    i.get("code"),
                    i.get("name"),
                    i.get("parentType") or "-",
                    i.get("parentCode") or "-"
                ])
            headers = ["Type", "Code", "Name", "Parent Type", "Parent Code"]
            click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
    else:
        click.echo(f"Error: Failed to fetch catalog meta: {resp.status_code} - {resp.text}", err=True)

@meta_catalog.command(name="tree")
@click.option("--root", default="GROUP", help="Root type for the tree (default: GROUP)")
@click.option("--code", help="Filter tree by a specific root code")
@click.option("--raw/--pretty", default=False, help="Show raw JSON output")
def meta_tree(root, code, raw):
    """View catalog metadata as a hierarchical tree"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/catalog/meta/tree"
    params = {"rootType": root.upper()}
    if code: params["rootCode"] = code
    resp = request_with_auth("GET", url, config, params=params)
    
    if resp.status_code == 200:
        data = resp.json()
        if raw:
            click.echo(json.dumps(data, indent=2))
        else:
            def print_node(node, level=0):
                indent = "  " * level
                prefix = "└── " if level > 0 else ""
                brands_str = f" [Brands: {', '.join(node['brands'])}]" if node.get("brands") else ""
                click.echo(f"{indent}{prefix}[{node['type']}] {node['code']} ({node['name']}){brands_str}")
                for child in node.get("children", []):
                    print_node(child, level + 1)
            
            for root_node in data:
                print_node(root_node)
    else:
        click.echo(f"Error: Failed to fetch catalog tree: {resp.status_code} - {resp.text}", err=True)

@click.group()
def catalog():
    """Catalog management commands"""
    pass

cli.add_command(catalog)

@catalog.command(name="list")
@click.option("--outlet-code", help="Outlet Code")
@click.option("--salesrep", help="Salesrep Username")
@click.option("--distributor", help="Distributor Code")
@click.option("--q", help="Search query (SKU, Name, Brand, Tags)")
@click.option("--hierarchical/--no-hierarchical", default=True, help="Include child tenants (default: True)")
@click.option("--raw/--table", default=False, help="Show raw JSON output instead of table")
def list_catalog(outlet_code, salesrep, distributor, q, hierarchical, raw):
    """List catalog items (resolved products with prices)"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    params = {
        "hierarchical": str(hierarchical).lower(),
        "limit": 100
    }
    if outlet_code: params["outlet_code"] = outlet_code
    if salesrep: params["salesrep"] = salesrep
    if distributor: params["distributor"] = distributor
    if q: params["q"] = q

    url = f"{config['base_url']}/catalog"
    resp = request_with_auth("GET", url, config, params=params)
    
    if resp.status_code == 200:
        items = resp.json()
        if raw:
            click.echo(json.dumps(items, indent=2))
        else:
            table_data = []
            for i in items:
                table_data.append([
                    truncate(i.get("sku")),
                    truncate(i.get("name")),
                    i.get("priceUnit"),
                    i.get("priceCase"),
                    i.get("pricePiece"),
                    i.get("distributorCode"),
                    i.get("tenantId")
                ])
            headers = ["SKU", "Name", "Unit Price", "Case Price", "Piece Price", "Distributor", "Tenant"]
            click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
    else:
        click.echo(f"Error: Failed to fetch catalog: {resp.status_code} - {resp.text}", err=True)

@click.group()
def pricing():
    """Pricing calculation commands"""
    pass

cli.add_command(pricing)

@pricing.command(name="resolve")
@click.option("--product-id", required=True, help="SKU/Product ID")
@click.option("--outlet-code", help="Outlet Code")
@click.option("--distributor", help="Distributor Code")
@click.option("--salesrep", help="Salesrep Username")
@click.option("--qty", default=1.0, help="Quantity (default: 1.0)")
@click.option("--uom", default="UNIT", help="Unit of Measure (default: UNIT)")
def resolve_price(product_id, outlet_code, distributor, salesrep, qty, uom):
    """Resolve price for a specific context"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    payload = {
        "tenantId": config["tenant_id"],
        "sku": product_id,
        "outletCode": outlet_code,
        "distributor": distributor,
        "salesrep": salesrep,
        "request": {
            "uom": uom,
            "qty": qty
        }
    }

    url = f"{config['base_url']}/pricing/resolve"
    resp = request_with_auth("POST", url, config, json=payload)
    
    if resp.status_code == 200:
        res = resp.json()
        click.echo("Price Resolution Result:")
        click.echo("-" * 40)
        
        main_info = [
            ["SKU", product_id],
            ["Resolved Scope", res.get("resolvedScope")],
            ["Rule ID", res.get("ruleId")],
            ["Start Date", res.get("validity", {}).get("startOn")],
            ["End Date", res.get("validity", {}).get("endOn")]
        ]
        click.echo(tabulate(main_info, tablefmt="plain"))
        
        click.echo("\nPricing Details:")
        pricing = res.get("price", {})
        price_info = [
            ["Per UoM", pricing.get("perUom")],
            ["Value", pricing.get("perUomValue")],
            ["Per Unit Value", pricing.get("perUnitValue")]
        ]
        click.echo(tabulate(price_info, tablefmt="plain"))

        if res.get("moq"):
            click.echo("\nMOQ Requirements:")
            moq = res.get("moq", {})
            click.echo(f"  Units Required: {moq.get('unitsRequired')} (Source: {moq.get('source')})")

        if res.get("explain"):
            click.echo("\nExplanation:")
            for note in res.get("explain"):
                click.echo(f"  - {note}")
                
    else:
        click.echo(f"Error: Failed to resolve price: {resp.status_code} - {resp.text}", err=True)

@click.group(name="retailer-map")
def retailer_map():
    """Retailer mapping management commands"""
    pass

cli.add_command(retailer_map)

@retailer_map.command(name="list")
@click.option("--outlet-code", help="Filter by Outlet Code")
@click.option("--distributor-code", help="Filter by Distributor Code")
@click.option("--salesrep-code", help="Filter by Salesrep Code")
@click.option("--active", type=bool, help="Filter by active status")
@click.option("--q", help="Search query")
@click.option("--limit", default=25, help="Limit results")
@click.option("--offset", default=0, help="Pagination offset")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def list_retailer_maps(outlet_code, distributor_code, salesrep_code, active, q, limit, offset, raw):
    """List retailer mappings"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    params = {
        "limit": limit,
        "offset": offset
    }
    if outlet_code: params["outletCode"] = outlet_code
    if distributor_code: params["distributorCode"] = distributor_code
    if salesrep_code: params["salesrepCode"] = salesrep_code
    if active is not None: params["active"] = str(active).lower()
    if q: params["q"] = q

    url = f"{config['base_url']}/retailer-maps"
    resp = request_with_auth("GET", url, config, params=params)
    
    if resp.status_code == 200:
        data = resp.json()
        if raw:
            click.echo(json.dumps(data, indent=2))
        else:
            items = data.get("items", [])
            table_data = []
            for i in items:
                table_data.append([
                    i.get("id"),
                    truncate(i.get("outletCode")),
                    truncate(i.get("distributorCode") or "-"),
                    truncate(i.get("salesrepCode") or "-"),
                    i.get("active"),
                    truncate(str(i.get("extendedAttr") or ""))
                ])
            headers = ["ID", "Outlet", "Distributor", "Salesrep", "Active", "Ext"]
            click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
    else:
        click.echo(f"Error: Failed to fetch retailer maps: {resp.status_code} - {resp.text}", err=True)

@pricing.command(name="list")
@click.option("--product-id", help="Filter by SKU/Product ID")
@click.option("--limit", default=50, help="Limit results")
@click.option("--offset", default=0, help="Pagination offset")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def list_pricing(product_id, limit, offset, raw):
    """List all pricing rules"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    params = {"limit": limit, "offset": offset}
    if product_id:
        params["q"] = product_id

    url = f"{config['base_url']}/price-rules"
    resp = request_with_auth("GET", url, config, params=params)
    
    if resp.status_code == 200:
        rules = resp.json()
        if raw:
            click.echo(json.dumps(rules, indent=2))
        else:
            table_data = []
            for r in rules:
                table_data.append([
                    r.get("id"),
                    truncate(r.get("productId")),
                    r.get("scope"),
                    truncate(r.get("outletCode") or "-"),
                    truncate(r.get("salesrep") or "-"),
                    truncate(r.get("distributor") or "-"),
                    r.get("priceUnit"),
                    r.get("priceCase"),
                    r.get("pricePiece"),
                    r.get("startOn")
                ])
            headers = ["ID", "Product", "Scope", "Outlet", "Salesrep", "Distributor", "Unit", "Case", "Piece", "Start Date"]
            click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
    else:
        click.echo(f"Error: Failed to fetch pricing rules: {resp.status_code} - {resp.text}", err=True)

@tenants.command(name="list")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def list_tenants(raw):
    """List all child tenants"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/api/tenants/children/details"
    resp = request_with_auth("GET", url, config)
    
    if resp.status_code == 200:
        data = resp.json()
        if raw:
            click.echo(json.dumps(data, indent=2))
        else:
            children = data.get("children", [])
            table_data = []
            for c in children:
                table_data.append([
                    c.get("tenantId"),
                    c.get("tenantName"),
                    c.get("adminUsername"),
                    c.get("adminEmail")
                ])
            headers = ["Tenant ID", "Name", "Admin", "Email"]
            click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
    else:
        click.echo(f"Error: Failed to fetch tenants: {resp.status_code} - {resp.text}", err=True)

@tenants.command(name="create")
@click.option("--id", required=True, help="Child Tenant ID")
@click.option("--name", required=True, help="Child Tenant Name")
@click.option("--admin-user", required=True, help="Admin Username")
@click.option("--admin-pass", required=True, help="Admin Password")
@click.option("--first-name", default="Admin", help="Admin First Name")
@click.option("--last-name", default="User", help="Admin Last Name")
def create_tenant(id, name, admin_user, admin_pass, first_name, last_name):
    """Create a new child tenant"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    payload = {
        "childTenantId": id,
        "childTenantName": name,
        "adminUsername": admin_user,
        "adminPassword": admin_pass,
        "firstName": first_name,
        "lastName": last_name
    }

    url = f"{config['base_url']}/api/tenants/child"
    click.echo(f"Creating child tenant '{id}'...")
    resp = request_with_auth("POST", url, config, json=payload)

    if resp.status_code in [200, 201]:
        click.echo(click.style(f"✅ Tenant '{id}' created successfully.", fg="green"))
    else:
        click.echo(f"Error: Failed to create tenant: {resp.status_code} - {resp.text}", err=True)

@tenants.command(name="clear")
@click.confirmation_option(prompt="Are you sure you want to clear ALL data for this tenant? This cannot be undone.")
def clear_data():
    """Clear all data for the current tenant"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/critical/actions/reset"
    resp = request_with_auth("GET", url, config)
    
    if resp.status_code in [200, 204]:
        click.echo("Data cleared successfully.")
    else:
        click.echo(f"Error: Failed to clear data: {resp.status_code} - {resp.text}", err=True)

@cli.command()
@click.argument("file", type=click.Path(exists=True))
@click.option("--tenant", help="Target child tenant ID")
@click.option("--check", is_flag=True, help="Perform dry-run check")
@click.option("--skip", default=2, help="Number of rows to skip (default: 2)")
@click.option("--extended", help="Comma-separated extended attribute fields")
@click.option("--entity", help="Force entity type hint (e.g. PRODUCT, OUTLET, PRICING, etc.)")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
@click.option("--map", help="Explicit field mapping (e.g. 'skucode:ID,sku_name:Desc')")
def upload(file, tenant, check, skip, extended, entity, raw, map):
    """Upload Master Data (Excel/CSV)"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    file_path = Path(file)
    url = f"{config['base_url']}/master/upload/multipart"
    params = {
        "check": str(check).lower(),
        "ignoreTopRows": skip,
        "header": "true"
    }
    if extended:
        params["extendedAttrFields"] = extended
    if entity:
        params["entityType"] = entity
    if map:
        params["fieldMapping"] = map

    headers = {}
    if tenant:
        headers["X-Tenant-Child"] = tenant

    click.echo(f"Uploading {file_path.name}...")
    
    with open(file_path, "rb") as f:
        files = {"file": (file_path.name, f)}
        resp = request_with_auth("POST", url, config, params=params, headers=headers, files=files)

    if resp.status_code == 200:
        result = resp.json()
        if raw:
            click.echo(json.dumps(result, indent=2))
            return

        if check:
            click.echo("Check successful!")
            click.echo(f"Detected Entity:  {result.get('entityType', 'Unknown')}")

            expected = result.get("expectedColumns", [])
            if expected:
                click.echo(f"Expected Columns: {', '.join(expected)}")
            
            input_cols = result.get("inputColumns", result.get("detectedColumns", []))
            if input_cols:
                click.echo(f"Input Columns:    {', '.join(input_cols)}")
            
            mapping = result.get("columnMapping", {})
            if mapping:
                click.echo("\nColumn Mapping (Expected -> Actual):")
                mapping_data = [[k, v] for k, v in mapping.items()]
                click.echo(tabulate(mapping_data, headers=["Expected", "Actual"], tablefmt="simple"))
            
            unmapped = result.get("unmappedColumns", [])
            if unmapped:
                click.echo(f"\nExtra (Unmapped) Columns: {', '.join(unmapped)}")
            
            preview = result.get("previewRows", [])
            if preview:
                click.echo("\nData Preview:")
                click.echo(tabulate(preview, headers="keys", tablefmt="grid"))
        else:
            click.echo(f"Upload successful: Inserted={result.get('inserted')}, Updated={result.get('updated')}")
    else:
        click.echo(f"Error: Upload failed: {resp.status_code} - {resp.text}", err=True)

@cli.group()
def products():
    """Product management commands"""
    pass

@products.command(name="list")
@click.option("--brand", help="Filter by Brand code")
@click.option("--category", help="Filter by Category code")
@click.option("--subcategory", help="Filter by Subcategory code")
@click.option("--tags", multiple=True, help="Filter by tags (can use multiple times)")
@click.option("--hierarchical/--no-hierarchical", default=True, help="Includes child tenants (default: True)")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def list_products(brand, category, subcategory, tags, hierarchical, raw):
    """List products with filtering"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/products"
    params = {"hierarchical": str(hierarchical).lower()}
    if brand: params["brand"] = brand
    if category: params["category"] = category
    if subcategory: params["subcategory"] = subcategory
    if tags: params["tags"] = list(tags)

    resp = request_with_auth("GET", url, config, params=params)
    
    if resp.status_code == 200:
        items = resp.json()
        if raw:
            click.echo(json.dumps(items, indent=2))
        else:
            table_data = []
            for p in items:
                table_data.append([
                    p.get("sku"),
                    p.get("name"),
                    p.get("category"),
                    p.get("brand"),
                    p.get("mrp"),
                    p.get("active")
                ])
            headers = ["SKU", "Name", "Category", "Brand", "MRP", "Active"]
            click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
    else:
        click.echo(f"Error: Failed to fetch products: {resp.status_code} - {resp.text}", err=True)

@cli.group()
def orders():
    """Order management commands"""
    pass

@orders.command(name="summary")
def get_order_summary():
    """Get calculated metrics for orders"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/orders/summary"
    resp = request_with_auth("GET", url, config)
    
    if resp.status_code == 200:
        summary = resp.json()
        table_data = [[k, v] for k, v in summary.items()]
        click.echo(tabulate(table_data, headers=["Metric", "Value"], tablefmt="plain"))
    else:
        click.echo(f"Error: Failed to fetch order summary: {resp.status_code} - {resp.text}", err=True)

@orders.command(name="list")
@click.option("--status", help="Filter by order status")
@click.option("--outlet-code", help="Filter by Outlet Code")
@click.option("--distributor-code", help="Filter by Distributor Code")
@click.option("--date-from", help="Filter by date from (YYYY-MM-DD)")
@click.option("--date-to", help="Filter by date to (YYYY-MM-DD)")
@click.option("--limit", default=20, help="Limit results")
@click.option("--offset", default=0, help="Pagination offset")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def list_orders(status, outlet_code, distributor_code, date_from, date_to, limit, offset, raw):
    """List orders"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    params = {
        "limit": limit,
        "offset": offset
    }
    if status: params["status"] = status
    if outlet_code: params["outlet"] = outlet_code
    if distributor_code: params["distributor"] = distributor_code
    if date_from: params["from"] = date_from
    if date_to: params["to"] = date_to

    url = f"{config['base_url']}/orders"
    resp = request_with_auth("GET", url, config, params=params)
    
    if resp.status_code == 200:
        orders = resp.json()
        if raw:
            click.echo(json.dumps(orders, indent=2))
        else:
            status_map = {0: "DRAFT", 1: "PLACED", 2: "CONFIRMED", 3: "DISPATCHED",
                          4: "DELIVERED", 5: "CANCELLED", 6: "RETURNED", 7: "PARTIAL"}
            table_data = []
            for o in orders:
                sc = o.get("statusCode")
                status_label = status_map.get(sc, str(sc)) if sc is not None else ""
                ordered_at = o.get("orderedAtLocal") or o.get("orderedAt") or ""
                if isinstance(ordered_at, str) and "T" in ordered_at:
                    ordered_at = ordered_at[:16].replace("T", " ")
                table_data.append([
                    o.get("id"),
                    truncate(o.get("orderNumber") or o.get("referenceNumber")),
                    ordered_at,
                    status_label,
                    truncate(o.get("outlet")),
                    truncate(o.get("outletName") or "", 20),
                    o.get("salesrep") or "",
                    f"{(o.get('netAmount') or 0):.2f}",
                    o.get("source") or ""
                ])
            headers = ["ID", "Order #", "Date", "Status", "Outlet", "Outlet Name", "Salesrep", "Amount", "Source"]
            click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
            click.echo(f"\nTotal: {len(orders)} orders")
    else:
        click.echo(f"Error: Failed to fetch orders: {resp.status_code} - {resp.text}", err=True)

@orders.command(name="create")
@click.option("--outlet-code", required=True, help="Outlet Code")
@click.option("--distributor", help="Distributor Code (optional, will use first available from catalog if not provided)")
@click.option("--salesrep", help="Salesrep Username (optional)")
def create_interactive_order(outlet_code, distributor, salesrep):
    """Interactively create an order for an outlet"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    # 1. Fetch catalog and Outlet details
    # Get outlet details to find default distributor if not provided
    outlet_url = f"{config['base_url']}/outlets/{outlet_code}"
    outlet_resp = request_with_auth("GET", outlet_url, config)
    default_distributor = distributor
    if outlet_resp.status_code == 200:
        outlet_data = outlet_resp.json()
        # The API doesn't return default distributor in summary but we can try to fetch from retailer-maps if needed
        # For now, let's just proceed with catalog
        pass

    params = {"outlet_code": outlet_code, "limit": 1000}
    if distributor: params["distributor"] = distributor
    if salesrep: params["salesrep"] = salesrep
    
    catalog_url = f"{config['base_url']}/catalog"
    resp = request_with_auth("GET", catalog_url, config, params=params)
    if resp.status_code != 200:
        click.echo(f"Error: Failed to fetch catalog for outlet {outlet_code}: {resp.text}", err=True)
        return
    
    catalog = resp.json()
    if not catalog:
        click.echo(f"No items available in catalog for outlet {outlet_code}.")
        return

    # Try to find a fallback distributor from catalog if not provided
    if not default_distributor:
        for i in catalog:
            if i.get("distributorCode"):
                default_distributor = i.get("distributorCode")
                break
    
    # If still no distributor, try fetching from retailer-maps
    if not default_distributor:
        rm_url = f"{config['base_url']}/retailer-maps"
        rm_resp = request_with_auth("GET", rm_url, config, params={"outletCode": outlet_code, "active": "true"})
        if rm_resp.status_code == 200:
            maps = rm_resp.json().get("items", [])
            if maps:
                default_distributor = maps[0].get("distributorCode")

    # Display mini catalog
    click.echo(f"\nCatalog for {outlet_code} (Distributor: {default_distributor or 'Auto'}):")
    table_data = []
    for i in catalog:
        table_data.append([i.get("sku"), truncate(i.get("name"), 40), i.get("priceUnit"), i.get("distributorCode") or default_distributor])
    headers = ["SKU", "Name", "Price", "Distributor"]
    click.echo(tabulate(table_data, headers=headers, tablefmt="simple"))

    # 2. Interactive Input
    lines = []
    order_distributor = default_distributor
    
    while True:
        sku = click.prompt("\nEnter SKU (or 'done' to finish)", type=str)
        if sku.lower() == 'done':
            break
        
        # Validate SKU in catalog
        item = next((i for i in catalog if i["sku"].lower() == sku.lower()), None)
        if not item:
            click.echo(f"Error: SKU '{sku}' not found in catalog. Try again.", err=True)
            continue
        
        qty = click.prompt(f"Quantity for {item['sku']}", type=float, default=1.0)
        uom = click.prompt(f"UOM for {item['sku']}", type=click.Choice(['UNIT', 'CASE', 'PIECE'], case_sensitive=False), default='UNIT')
        
        line_distributor = item.get("distributorCode") or order_distributor
        if not line_distributor:
             line_distributor = click.prompt(f"Distributor for {item['sku']}", type=str)

        # If order-level distributor not yet set, pick from first line
        if not order_distributor:
            order_distributor = line_distributor

        lines.append({
            "sku": item["sku"],
            "uom": uom.upper(),
            "lineUnits": qty if uom.upper() == 'UNIT' else 0,
            "qtyCases": qty if uom.upper() == 'CASE' else 0,
            "qtyPieces": qty if uom.upper() == 'PIECE' else 0,
            "distributor": line_distributor
        })
        
        if not click.confirm("Add more items?", default=True):
            break

    if not lines:
        click.echo("No items added. Aborting.")
        return

    # 3. Build payload
    payload = {
        "outletCode": outlet_code,
        "distributor": order_distributor,
        "salesrep": salesrep,
        "orderDate": datetime.date.today().isoformat(),
        "lines": lines
    }

    # 4. Place order
    click.echo("\nPlacing order...")
    url = f"{config['base_url']}/orders"
    resp = request_with_auth("POST", url, config, json=payload)
    
    if resp.status_code == 201:
        data = resp.json()
        order = data.get("order", {})
        click.echo(click.style("\n✅ Order Placed Successfully!", fg="green", bold=True))
        click.echo(f"Order Code: {order.get('orderNumber')}")
        status_code = order.get('statusCode')
        status_map = {0: "PENDING", 1: "OPEN", 2: "SUBMITTED", 3: "APPROVED", 4: "DELIVERED", 5: "CANCELLED"}
        click.echo(f"Status:     {status_map.get(status_code, status_code)}")
        
        # 5. Show Invoice
        click.echo("\n" + "="*30)
        click.echo("           INVOICE")
        click.echo("="*30)
        
        gross = order.get('grossAmount') or 0.0
        tax = order.get('taxAmount') or 0.0
        discount = order.get('totalDiscount') or order.get('discount') or 0.0
        final_total = order.get('netAmount') or 0.0
        
        invoice_data = [
            ["Gross Amount", f"{gross:10.2f}"],
            ["Discount Total", f"-{discount:9.2f}"],
            ["Tax Total", f"{tax:10.2f}"],
            ["-" * 15, "-" * 10],
            ["TOTAL AMOUNT", click.style(f"{final_total:10.2f}", bold=True)]
        ]
        click.echo(tabulate(invoice_data, tablefmt="plain"))
        
        click.echo("\nLine Details:")
        line_data = []
        for l in order.get("lines", []):
            promo_info = ""
            if l.get("isFree"):
                promo_info = click.style("[FREE]", fg="cyan")
            elif (l.get("discount") or l.get("discountAmount") or 0.0) > 0:
                disc = l.get("discount") or l.get("discountAmount")
                promo_info = click.style(f"[Disc: {disc:.2f}]", fg="yellow")
            
            tax_val = l.get("taxAmount") or 0.0
            total_val = l.get("netAmount") or 0.0 # netAmount in OrderLine usually includes tax or is total? 
            # In model it's (gross - discount). Tax is separate.
            # Final invoice line total = netAmount + taxAmount
            total_val = (l.get("netAmount") or 0.0) + tax_val
            
            line_data.append([
                l.get("sku"),
                f"{l.get('lineUnits') or 0:.0f} U",
                f"{(l.get('unitPrice') or 0.0):.2f}",
                f"{tax_val:.2f}",
                f"{total_val:.2f}",
                promo_info
            ])
        headers = ["SKU", "Qty", "Price", "Tax", "Total", "Notes"]
        click.echo(tabulate(line_data, headers=headers, tablefmt="simple"))
        
        applied_promos = order.get("appliedPromotions") or order.get("promoInfo")
        if applied_promos:
            click.echo("\nPromotions Applied:")
            applied_set = set() # Avoid duplicates
            for p in applied_promos:
                name = p.get('promotionName') or p.get('name')
                code = p.get('promotionCode') or p.get('code')
                if code not in applied_set:
                    click.echo(f" - {name} ({code})")
                    applied_set.add(code)
    else:
        click.echo(f"Error: Failed to place order: {resp.status_code} - {resp.text}", err=True)

@orders.command(name="get")
@click.argument("order_id")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def get_order(order_id, raw):
    """Get order details by ID"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/orders/{order_id}"
    params = {"expand": "lines"} # Always fetch lines for details
    resp = request_with_auth("GET", url, config, params=params)
    
    if resp.status_code == 200:
        order = resp.json()
        if raw:
            click.echo(json.dumps(order, indent=2))
        else:
            click.echo("Order Details:")
            exclude_keys = ["lines", "extendedAttr"]
            display_order = {k: v for k, v in order.items() if k not in exclude_keys}
            table_data = [[k, truncate(v)] for k, v in display_order.items()]
            click.echo(tabulate(table_data, headers=["Attribute", "Value"], tablefmt="plain"))
            
            click.echo("\nLines:")
            lines = order.get("lines", [])
            if lines:
                line_data = []
                for l in lines:
                     line_data.append([
                         l.get("sku"),
                         l.get("qtyCases"),
                         l.get("qtyPieces"),
                         l.get("unitPrice"),
                         l.get("lineAmount"),
                         l.get("isFree")
                     ])
                headers = ["SKU", "Cases", "Pieces", "Unit Price", "Total", "Free"]
                click.echo(tabulate(line_data, headers=headers, tablefmt="grid"))
            else:
                click.echo("No line items.")
    else:
        click.echo(f"Error: Failed to fetch order: {resp.status_code} - {resp.text}", err=True)

@cli.group()
def promotions():
    """Promotion management commands"""
    pass

@promotions.command(name="list")
@click.option("--limit", default=25, help="Number of items to fetch (default: 25)")
@click.option("--offset", default=0, help="Pagination offset (default: 0)")
@click.option("--sku", help="Filter by SKU")
@click.option("--tags", multiple=True, help="Filter by tags (can be used multiple times)")
@click.option("--outlet-code", help="Filter by Outlet Code")
@click.option("--distributor-code", help="Filter by Distributor Code")
@click.option("--salesrep-username", help="Filter by Salesrep Username")
@click.option("--channel", help="Filter by Channel")
@click.option("--segment", help="Filter by Segment")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def list_promotions(limit, offset, sku, tags, outlet_code, distributor_code, salesrep_username, channel, segment, raw):
    """List all promotions"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    params = {
        "limit": limit,
        "offset": offset
    }
    if sku: params["sku"] = sku
    if tags: params["tags"] = list(tags) 
    if outlet_code: params["outletCode"] = outlet_code
    if distributor_code: params["distributorCode"] = distributor_code
    if salesrep_username: params["salesrepUsername"] = salesrep_username
    if channel: params["channel"] = channel
    if segment: params["segment"] = segment

    url = f"{config['base_url']}/promotions"
    resp = request_with_auth("GET", url, config, params=params)
    
    if resp.status_code == 200:
        promos = resp.json()
        if raw:
            click.echo(json.dumps(promos, indent=2))
        else:
            table_data = []
            for p in promos:
                table_data.append([
                    p.get("id"),
                    truncate(p.get("code")),
                    truncate(p.get("name")),
                    p.get("kind"),
                    p.get("status"),
                    p.get("startDate"),
                    p.get("endDate")
                ])
            headers = ["ID", "Code", "Name", "Kind", "Status", "Start", "End"]
            click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
    else:
        click.echo(f"Error: Failed to fetch promotions: {resp.status_code} - {resp.text}", err=True)

@promotions.command(name="get")
@click.argument("promotion_id")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def get_promotion(promotion_id, raw):
    """Get promotion details by ID"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/promotions/{promotion_id}"
    resp = request_with_auth("GET", url, config)
    
    if resp.status_code == 200:
        detail = resp.json()
        if raw:
            click.echo(json.dumps(detail, indent=2))
        else:
            promo = detail.get("promotion", {})
            click.echo("Promotion Details:")
            
            simple_view = {k: v for k, v in promo.items() if not isinstance(v, (dict, list))}
            table_data = [[k, truncate(v)] for k, v in simple_view.items()]
            click.echo(tabulate(table_data, headers=["Attribute", "Value"], tablefmt="plain"))

            if promo.get("tags"):
                click.echo(f"\nTags: {', '.join(promo.get('tags'))}")

            rules = detail.get("rules", [])
            if rules:
                click.echo(f"\nRules ({len(rules)}):")
                for idx, rule in enumerate(rules):
                    click.echo(f"\nRule #{idx + 1}:")
                    rule_info = [
                        ["Scope", rule.get("scope")],
                        ["Priority", rule.get("priority")]
                    ]
                    click.echo(tabulate(rule_info, tablefmt="plain"))

                    # Show Conditions
                    conditions = rule.get("conditions", [])
                    if conditions:
                        click.echo("  Conditions:")
                        cond_data = []
                        for c in conditions:
                            cond_data.append([
                                c.get("slabIndex"),
                                c.get("basis"),
                                c.get("minValue"),
                                c.get("maxValue") or "∞"
                            ])
                        click.echo(tabulate(cond_data, headers=["Slab", "Basis", "Min", "Max"], tablefmt="grid", stralign="right"))
                    
                    # Show Benefits
                    benefits = rule.get("benefits", [])
                    if benefits:
                        click.echo("  Benefits:")
                        bene_data = []
                        for b in benefits:
                            b_type = b.get("type")
                            value = "-"
                            if b_type == "PERCENT_DISCOUNT":
                                value = f"{b.get('percentOff')}%"
                            elif b_type == "FIXED_DISCOUNT":
                                value = f"{b.get('discountAmount')}"
                            elif b_type == "FREE_GOODS":
                                value = f"{b.get('freeQty')} x {b.get('freeSku')}"
                            
                            bene_data.append([
                                b.get("slabIndex"),
                                b_type,
                                value
                            ])
                        click.echo(tabulate(bene_data, headers=["Slab", "Type", "Value"], tablefmt="grid"))
    else:
        click.echo(f"Error: Failed to fetch promotion: {resp.status_code} - {resp.text}", err=True)

@cli.group()
def users():
    """User management commands"""
    pass

@users.command(name="list")
@click.option("--q", help="Search query (Name, Username, Phone, Email)")
@click.option("--org-type", help="Filter by Org Type (e.g. DISTRIBUTOR, RETAILER)")
@click.option("--org-code", help="Filter by Org Code")
@click.option("--reports-to", help="Filter by Reporting Manager Username")
@click.option("--location", help="Filter by Location Code")
@click.option("--limit", default=25, help="Limit results (default: 25)")
@click.option("--offset", default=0, help="Offset results")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def list_users(q, org_type, org_code, reports_to, location, limit, offset, raw):
    """List users with filtering"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/users"
    params = {"limit": limit, "offset": offset}
    if q: params["q"] = q
    if org_type: params["orgType"] = org_type
    if org_code: params["orgCode"] = org_code
    if reports_to: params["reportsTo"] = reports_to
    if location: params["location"] = location

    resp = request_with_auth("GET", url, config, params=params)
    
    if resp.status_code == 200:
        items = resp.json()
        if raw:
            click.echo(json.dumps(items, indent=2))
        else:
            table_data = []
            for u in items:
                table_data.append([
                    u.get("id"),
                    u.get("username"),
                    f"{u.get('firstName', '')} {u.get('lastName', '')}",
                    u.get("email"),
                    u.get("phone"),
                    u.get("orgType"),
                    u.get("orgCode"),
                    u.get("active")
                ])
            headers = ["ID", "Username", "Name", "Email", "Phone", "Org Type", "Org Code", "Active"]
            click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
    else:
        click.echo(f"Error: Failed to fetch users: {resp.status_code} - {resp.text}", err=True)

@cli.group()
def outlets():
    """Outlet management commands"""
    pass

@outlets.command(name="list")
@click.option("--q", help="Search query (Name, Code)")
@click.option("--channel", help="Filter by Channel (e.g. GT, MT)")
@click.option("--location", help="Filter by Location Code")
@click.option("--tags", multiple=True, help="Filter by tags")
@click.option("--hierarchical/--no-hierarchical", default=True, help="Includes child tenants (default: True)")
@click.option("--limit", default=25, help="Limit results (default: 25)")
@click.option("--offset", default=0, help="Offset results")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def list_outlets(q, channel, location, tags, hierarchical, limit, offset, raw):
    """List outlets with filtering"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/outlets"
    params = {"limit": limit, "offset": offset, "hierarchical": str(hierarchical).lower()}
    if q: params["q"] = q
    if channel: params["channel"] = channel
    if location: params["location"] = location
    if tags: params["tags"] = list(tags)

    resp = request_with_auth("GET", url, config, params=params)
    
    if resp.status_code == 200:
        items = resp.json()
        if raw:
            click.echo(json.dumps(items, indent=2))
        else:
            table_data = []
            for o in items:
                table_data.append([
                    o.get("id"),
                    o.get("code"),
                    o.get("name"),
                    o.get("phone") or o.get("mobile"),
                    o.get("channel"),
                    o.get("location", {}).get("code") or "N/A",
                    o.get("active")
                ])
            headers = ["ID", "Code", "Name", "Phone", "Channel", "Location", "Active"]
            click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
    else:
        click.echo(f"Error: Failed to fetch outlets: {resp.status_code} - {resp.text}", err=True)

@outlets.command(name="get")
@click.argument("outlet_id")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def get_outlet(outlet_id, raw):
    """Get outlet details by ID"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/outlets/{outlet_id}"
    resp = request_with_auth("GET", url, config)
    
    if resp.status_code == 200:
        outlet = resp.json()
        if raw:
            click.echo(json.dumps(outlet, indent=2))
        else:
            click.echo("Outlet Details:")
            
            # Display main fields
            simple_view = {k: v for k, v in outlet.items() if not isinstance(v, (dict, list))}
            table_data = [[k, truncate(v)] for k, v in simple_view.items()]
            click.echo(tabulate(table_data, headers=["Attribute", "Value"], tablefmt="plain"))

            # Display location if present
            if outlet.get("location"):
                 click.echo("\nLocation:")
                 click.echo(json.dumps(outlet.get("location"), indent=2))
            
            # Display associated users if any
            users = outlet.get("users", [])
            if users:
                click.echo("\nAssociated Users:")
                user_table = []
                for u in users:
                    user_table.append([u.get("username"), u.get("role")])
                click.echo(tabulate(user_table, headers=["Username", "Role"], tablefmt="grid"))
    else:
        click.echo(f"Error: Failed to fetch outlet: {resp.status_code} - {resp.text}", err=True)

@outlets.command(name="register")
@click.option("--name", required=True, help="Outlet Name")
@click.option("--code", help="Outlet Code (optional, auto-generated if omitted)")
@click.option("--pincode", help="Pincode")
@click.option("--address", help="Full address")
@click.option("--channel", help="Sales channel")
@click.option("--phone", help="Phone number")
@click.option("--lat", type=float, help="Latitude")
@click.option("--lon", type=float, help="Longitude")
@click.option("--propagate", is_flag=True, help="Propagate to child tenants")
@click.option("--auto-map", is_flag=True, default=True, help="Auto-map to nearest distributor (default: True)")
@click.option("--raw/--pretty", default=False, help="Show raw JSON output")
def register_outlet(name, code, pincode, address, channel, phone, lat, lon, propagate, auto_map, raw):
    """Register a new outlet (with optional propagation)"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    payload = {
        "name": name,
        "code": code,
        "pincode": pincode,
        "address": address,
        "channel": channel,
        "phone": phone,
        "lat": lat,
        "lon": lon
    }
    # Clean up None values
    payload = {k: v for k, v in payload.items() if v is not None}

    params = {
        "propagate": str(propagate).lower(),
        "autoMapDistributor": str(auto_map).lower()
    }

    url = f"{config['base_url']}/outlets/register"
    click.echo("Registering outlet...")
    resp = request_with_auth("POST", url, config, json=payload, params=params)

    if resp.status_code in [200, 201]:
        data = resp.json()
        if raw:
            click.echo(json.dumps(data, indent=2))
            return

        click.echo(click.style(f"\n✅ {data.get('message', 'Registration successful!')}", fg="green", bold=True))
        
        # Display Primary Result
        primary = data.get("primary")
        if primary:
            click.echo("\nPrimary Result:")
            outlet = primary.get("outlet", {})
            table_data = [
                ["Status", data.get("status")],
                ["Action", primary.get("action")],
                ["Outlet Code", outlet.get("code")],
                ["Outlet Name", outlet.get("name")],
                ["User Mapped", primary.get("user")]
            ]
            click.echo(tabulate(table_data, tablefmt="plain"))

        # Display Propagation Result
        prop = data.get("propagation")
        if prop and prop.get("attempted"):
            click.echo(f"\nPropagation Result: {prop.get('successCount')} success(es)")
            details = prop.get("details", [])
            if details:
                table_data = []
                for d in details:
                    table_data.append([
                        d.get("tenantId"),
                        d.get("action"),
                        d.get("outletCode") or "-",
                        d.get("reason") or "-"
                    ])
                headers = ["Tenant ID", "Action", "Code", "Reason"]
                click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
    else:
        click.echo(f"Error: Registration failed: {resp.status_code} - {resp.text}", err=True)

@outlets.command(name="resync")
@click.option("--raw/--pretty", default=False, help="Show raw JSON output")
def resync_outlets(raw):
    """Resync current user's outlets to child tenants"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/outlets/resync"
    click.echo("Triggering resync...")
    resp = request_with_auth("POST", url, config)

    if resp.status_code == 200:
        data = resp.json()
        if raw:
            click.echo(json.dumps(data, indent=2))
            return

        click.echo(click.style(f"\n✅ {data.get('message', 'Resync complete!')}", fg="green", bold=True))
        
        prop = data.get("propagation")
        if prop and prop.get("attempted"):
            click.echo(f"Success Count: {prop.get('successCount')}")
            details = prop.get("details", [])
            if details:
                table_data = []
                for d in details:
                    table_data.append([
                        d.get("tenantId"),
                        d.get("action"),
                        d.get("outletCode") or "-",
                        d.get("reason") or "-"
                    ])
                headers = ["Tenant ID", "Action", "Code", "Reason"]
                click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
    else:
        click.echo(f"Error: Resync failed: {resp.status_code} - {resp.text}", err=True)

# ========================================================================
# LOCATIONS
# ========================================================================

@cli.group()
def locations():
    """Location management commands"""
    pass

@locations.command(name="list")
@click.option("--q", help="Search query (Name, Code)")
@click.option("--level", help="Filter by level (e.g., COUNTRY, STATE, CITY)")
@click.option("--parent-code", help="Filter by parent location code")
@click.option("--limit", default=50, help="Limit results (default: 50)")
@click.option("--offset", default=0, help="Offset results")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def list_locations(q, level, parent_code, limit, offset, raw):
    """List organizational locations"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/org/locations"
    params = {"limit": limit, "offset": offset}
    if q: params["q"] = q
    if level: params["level"] = level
    if parent_code: params["parentCode"] = parent_code

    resp = request_with_auth("GET", url, config, params=params)
    
    if resp.status_code == 200:
        items = resp.json()
        if raw:
            click.echo(json.dumps(items, indent=2))
        else:
            table_data = []
            for loc in items:
                table_data.append([
                    loc.get("code"),
                    loc.get("name"),
                    loc.get("level"),
                    loc.get("parentCode") or "-",
                    f"{loc.get('lat', 'N/A')}, {loc.get('lon', 'N/A')}" if loc.get("lat") else "N/A",
                    loc.get("cityName") or loc.get("stateName") or loc.get("countryName") or "N/A"
                ])
            headers = ["Code", "Name", "Level", "Parent", "Coordinates", "Address"]
            click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
            click.echo(f"\nTotal: {len(items)} locations")
    else:
        click.echo(f"Error: Failed to fetch locations: {resp.status_code} - {resp.text}", err=True)

@locations.command(name="hierarchy")
@click.option("--root", help="Root location code (default: show all top-level)")
@click.option("--raw/--tree", default=False, help="Show raw JSON output")
def show_hierarchy(root, raw):
    """View location hierarchy as a tree"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    # Use the hierarchy endpoint - if root specified use /{code}/hierarchy, otherwise get all top-level
    if root:
        url = f"{config['base_url']}/org/locations/{root}/hierarchy"
        params = {}
    else:
        # Get all locations and build hierarchy from root nodes (no parent)
        url = f"{config['base_url']}/org/locations"
        params = {"limit": 1000}  # Get more for hierarchy view

    resp = request_with_auth("GET", url, config, params=params)
    
    if resp.status_code == 200:
        data = resp.json()
        
        if raw:
            click.echo(json.dumps(data, indent=2))
            return
        
        def print_node(node, level=0):
            """Recursively print hierarchy tree"""
            indent = "  " * level
            marker = "└─ " if level > 0 else ""
            code = node.get("code", "?")
            name = node.get("name", "?")
            level_type = node.get("level", "?")
            
            click.echo(f"{indent}{marker}{code} ({level_type}) - {name}")
            
            for child in node.get("children", []):
                print_node(child, level + 1)
        
        # If we got a structured hierarchy response (from /{code}/hierarchy)
        if isinstance(data, list) and len(data) > 0 and "children" in data[0]:
            for node in data:
                print_node(node)
        # If we got a flat list (from /org/locations), show top-level nodes
        elif isinstance(data, list):
            # Filter for root nodes (no parent)
            root_nodes = [loc for loc in data if not loc.get("parentCode")]
            if root_nodes:
                click.echo("Top-level locations:")
                for loc in root_nodes:
                    click.echo(f"{loc.get('code')} ({loc.get('level')}) - {loc.get('name')}")
                click.echo(f"\nShowing {len(root_nodes)} top-level locations")
                click.echo("Use --root CODE to see full hierarchy for a specific location")
            else:
                click.echo("No root locations found")
        else:
            # Single node response
            print_node(data)
    else:
        click.echo(f"Error: Failed to fetch hierarchy: {resp.status_code} - {resp.text}", err=True)

@users.command(name="get")
@click.argument("user_id")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def get_user(user_id, raw):
    """Get user details by ID"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/users/{user_id}"
    resp = request_with_auth("GET", url, config)
    
    if resp.status_code == 200:
        user = resp.json()
        if raw:
            click.echo(json.dumps(user, indent=2))
        else:
            click.echo("User Details:")
            # Flatten for simple display if needed, or just show key-values
            # Filter out complex objects/lists for the main view
            simple_view = {k: v for k, v in user.items() if not isinstance(v, (dict, list))}
            table_data = [[k, truncate(v)] for k, v in simple_view.items()]
            click.echo(tabulate(table_data, headers=["Attribute", "Value"], tablefmt="plain"))
            
            # Show specific complex fields if important, e.g. parentUsernames
            if user.get("parentUsernames"):
                click.echo("\nReporting Managers:")
                click.echo(", ".join(user.get("parentUsernames")))
                
    else:
        click.echo(f"Error: Failed to fetch user: {resp.status_code} - {resp.text}", err=True)

@cli.group()
def system():
    """System and server utilities"""
    pass

@system.command(name="tail")
def tail_logs():
    """Stream server logs in real-time"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/logs/stream"
    try:
        # Use stream=True for SSE
        resp = request_with_auth("GET", url, config, stream=True)
        
        if resp.status_code == 200:
            click.echo("Streaming server logs (Ctrl+C to stop)...\n")
            for line in resp.iter_lines():
                if line:
                    decoded = line.decode('utf-8').strip()
                    if decoded.startswith("data:"):
                        log_line = decoded[5:].strip()
                        click.echo(log_line)
        else:
            click.echo(f"Error: Failed to connect to log stream: {resp.status_code} - {resp.text}", err=True)
            
    except KeyboardInterrupt:
        click.echo("\nStopping log stream...")
    except Exception as e:
        click.echo(f"\nError: {e}", err=True)

@system.command(name="ping")
def ping_server():
    """Check server connectivity"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/auth/login" # Using login as a proxy for health check
    try:
        resp = requests.get(config['base_url'], timeout=5)
        if resp.status_code < 500:
            click.echo(f"Server is UP ({resp.status_code})")
        else:
            click.echo(f"Server returned error: {resp.status_code}")
    except Exception as e:
        click.echo(f"Server is DOWN: {e}")

@cli.group()
def settings():
    """Manage backend settings"""
    pass

@settings.command(name="list")
@click.option("--feature", help="Filter by feature")
@click.option("--q", help="Search query")
@click.option("--include-secrets", is_flag=True, help="Include secret values (visible if authorized)")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def list_settings(feature, q, include_secrets, raw):
    """List setting keys and values"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    params = {"include_secrets": str(include_secrets).lower()}
    if feature: params["feature"] = feature
    if q: params["q"] = q

    url = f"{config['base_url']}/api/settings"
    resp = request_with_auth("GET", url, config, params=params)
    
    if resp.status_code == 200:
        data = resp.json()
        if raw:
            click.echo(json.dumps(data, indent=2))
        else:
            items = data.get("items", [])
            table_data = []
            for item in items:
                v = item.get("valueJson")
                if isinstance(v, (dict, list)):
                    v_str = json.dumps(v)
                else:
                    v_str = str(v) if v is not None else ""
                
                table_data.append([
                    item.get("feature"),
                    item.get("key"),
                    item.get("valueType"),
                    truncate(v_str),
                    "Yes" if item.get("isSecret") else "No"
                ])
            headers = ["Feature", "Key", "Type", "Value", "Secret?"]
            click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
    else:
        click.echo(f"Error: Failed to fetch settings: {resp.status_code} - {resp.text}", err=True)

@settings.command(name="get")
@click.argument("feature")
@click.argument("key")
@click.option("--include-secrets", is_flag=True, help="Reveal secret value")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def get_setting(feature, key, include_secrets, raw):
    """Get a specific setting value"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    params = {"include_secrets": str(include_secrets).lower()}
    url = f"{config['base_url']}/api/settings/{feature}/{key}"
    resp = request_with_auth("GET", url, config, params=params)
    
    if resp.status_code == 200:
        item = resp.json()
        if raw:
            click.echo(json.dumps(item, indent=2))
        else:
            table_data = []
            for k, v in item.items():
                if k == "valueJson" and isinstance(v, (dict, list)):
                    v = json.dumps(v, indent=2)
                table_data.append([k, truncate(str(v), max_length=500)])
            click.echo(tabulate(table_data, headers=["Attribute", "Value"], tablefmt="plain"))
    else:
        click.echo(f"Error: Failed to fetch setting: {resp.status_code} - {resp.text}", err=True)

@settings.command(name="set")
@click.argument("feature")
@click.argument("key")
@click.argument("value")
@click.option("--secret", is_flag=True, help="Mark as secret")
@click.option("--type", default="STRING", help="Value type (STRING, JSON, NUMBER, BOOLEAN)")
def set_setting(feature, key, value, secret, type):
    """Set or update a setting value"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    payload = {
        "feature": feature,
        "key": key,
        "value": value,
        "isSecret": secret,
        "type": type.upper()
    }
    
    url = f"{config['base_url']}/api/settings"
    resp = request_with_auth("PUT", url, config, json=payload)
    
    if resp.status_code == 200:
        click.echo(f"Setting '{feature}:{key}' updated successfully.")
    else:
        click.echo(f"Error: Failed to set setting: {resp.status_code} - {resp.text}", err=True)

@settings.command(name="delete")
@click.argument("feature")
@click.argument("key")
def delete_setting(feature, key):
    """Delete a setting"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/api/settings/{feature}/{key}"
    resp = request_with_auth("DELETE", url, config)
    
    if resp.status_code == 204:
        click.echo(f"Setting '{feature}:{key}' deleted successfully.")
    else:
        click.echo(f"Error: Failed to delete setting: {resp.status_code} - {resp.text}", err=True)

@settings.command(name="features")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def list_features(raw):
    """List all distinct features with settings"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/api/settings/features"
    resp = request_with_auth("GET", url, config, params=None)
    
    if resp.status_code == 200:
        data = resp.json()
        if raw:
            click.echo(json.dumps(data, indent=2))
        else:
            items = data.get("items", [])
            for item in items:
                click.echo(item)
    else:
        click.echo(f"Error: Failed to fetch features: {resp.status_code} - {resp.text}", err=True)

@click.group()
def tax():
    """Tax rule management commands"""
    pass

cli.add_command(tax)

@tax.command(name="list")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def list_tax(raw):
    """List all tax rules"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/tax-rules"
    resp = request_with_auth("GET", url, config)
    
    if resp.status_code == 200:
        rules = resp.json()
        if raw:
            click.echo(json.dumps(rules, indent=2))
        else:
            table_data = []
            for r in rules:
                table_data.append([
                    r.get("id"),
                    r.get("sku") or "*",
                    r.get("name"),
                    r.get("rate"),
                    json.dumps(r.get("components") or {}),
                    "Yes" if r.get("active") else "No"
                ])
            headers = ["ID", "SKU", "Name", "Rate (%)", "Components", "Active"]
            click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
    else:
        click.echo(f"Error: Failed to fetch tax rules: {resp.status_code} - {resp.text}", err=True)

@tax.command(name="effective")
@click.option("--sku", help="SKU code (default: '*' for global)")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def get_effective_tax(sku, raw):
    """Get the effective tax rule for a SKU"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/tax-rules/effective"
    params = {}
    if sku: params["sku"] = sku
    
    resp = request_with_auth("GET", url, config, params=params)
    
    if resp.status_code == 200:
        rule = resp.json()
        if not rule:
            click.echo("No effective tax rule found.")
            return
            
        if raw:
            click.echo(json.dumps(rule, indent=2))
        else:
            data = []
            for k, v in rule.items():
                if isinstance(v, (dict, list)):
                    v = json.dumps(v, indent=2)
                data.append([k, v])
            click.echo(tabulate(data, headers=["Attribute", "Value"], tablefmt="plain"))
    else:
        click.echo(f"Error: Failed to fetch effective tax: {resp.status_code} - {resp.text}", err=True)

@tax.command(name="delete")
@click.argument("id")
def delete_tax(id):
    """Delete a tax rule by ID"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/tax-rules/{id}"
    resp = request_with_auth("DELETE", url, config)
    
    if resp.status_code == 204:
        click.echo(f"Tax rule {id} deleted successfully.")
    else:
        click.echo(f"Error: Failed to delete tax rule: {resp.status_code} - {resp.text}", err=True)



@click.group()
def device():
    """Device management commands"""
    pass

cli.add_command(device)

@device.command(name="register-sse")
def register_sse():
    """Register device via SSE and stream notifications"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/notification/v1/stream"
    click.echo(f"Connecting to SSE stream at {url}...")
    
    try:
        token = get_token(config)
        headers = {
            "Authorization": f"Bearer {token}",
            "X-Tenant-Id": config["tenant_id"]
        }
        
        # Manually using requests here to control streaming properly
        import requests
        resp = requests.get(url, headers=headers, stream=True)
        
        if resp.status_code == 200:
            click.echo("Connected! Listening for events...")
            # SSE usually sends 'data: ...\n\n'
            for line in resp.iter_lines():
                if line:
                    decoded = line.decode('utf-8')
                    click.echo(decoded)
        elif resp.status_code == 401:
             click.echo("Error: Unauthorized. Try 'saleshub login' to refresh token.", err=True)
        else:
            click.echo(f"Error: Failed to connect: {resp.status_code} - {resp.text}", err=True)
            
    except KeyboardInterrupt:
        click.echo("\nDisconnected.")
    except Exception as e:
        click.echo(f"Error: {e}", err=True)

@device.command(name="register-websocket")
def register_websocket():
    """Register device via WebSocket"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    base_url = config['base_url']
    ws_url = base_url.replace("http://", "ws://").replace("https://", "wss://")
    url = f"{ws_url}/ws/notifications"
    
    # Refresh token if needed
    try:
        token = get_token(config)
    except:
        click.echo("Error: Could not get token. Run 'saleshub login'.", err=True)
        return

    tenant_id = config["tenant_id"]
    username = config["username"]

    def on_message(ws, message):
        try:
            msg = json.loads(message)
            click.echo(f"Received: {json.dumps(msg, indent=2)}")
            
            # Auto-respond to pings or requests from server if needed
            # (Server doesn't ask for pings, client sends them, but receiving one is fine)
            if msg.get("type") == "ping":
                 pong = {"type": "pong", "timestamp": int(time.time() * 1000)}
                 ws.send(json.dumps(pong))
                 click.echo("Sent: pong")

        except Exception as e:
            click.echo(f"Raw Message: {message}")

    def on_error(ws, error):
        click.echo(f"Error: {error}")

    def on_close(ws, close_status_code, close_msg):
        click.echo("Disconnected")

    def on_open(ws):
        click.echo("Connected! Authenticating...")
        auth_msg = {
            "type": "auth",
            "token": token,
            "tenantId": tenant_id,
            "username": username
        }
        ws.send(json.dumps(auth_msg))
        click.echo("Sent auth message")

    click.echo(f"Connecting to WebSocket at {url}...")
    
    # WebSocketApp
    ws = websocket.WebSocketApp(url,
                              on_open=on_open,
                              on_message=on_message,
                              on_error=on_error,
                              on_close=on_close)

    try:
        ws.run_forever()
    except KeyboardInterrupt:
        ws.close()
        click.echo("\nDisconnected.")



@click.group()
def notification():
    """Notification management commands"""
    pass

cli.add_command(notification)

@notification.command(name="send")
@click.option("--template", help="Template to use (optional)")
@click.option("--title", help="Title (if no template)")
@click.option("--body", help="Body/Message (if no template)")
@click.option("--media-url", help="Media URL (optional)")
@click.option("--user", multiple=True, help="Target username(s)")
@click.option("--channel", multiple=True, help="Target channel(s) e.g. FCM, WEBSOCKET")
@click.option("--filter-json", help="Raw JSON string for advanced filters")
@click.option("--data", help="JSON string for custom data payload")
@click.option("--sync/--async", default=False, help="Send synchronously (default: async)")
def send_notification(template, title, body, media_url, user, channel, filter_json, data, sync):
    """Send a notification"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    payload = {}
    
    # Content
    if template:
        payload["templateCode"] = template
    if title:
        payload["title"] = title
    if body:
        payload["body"] = body
    if media_url:
        payload["mediaUrl"] = media_url
        
    if data:
        try:
             payload["data"] = json.loads(data)
        except Exception as e:
             click.echo(f"Error: Invalid JSON for data: {e}", err=True)
             return

    # Channels
    if channel:
        payload["channels"] = list(channel)

    # Targeting
    if filter_json:
        try:
            filters = json.loads(filter_json)
            # Support both passing a list of filters or the full object
            if isinstance(filters, list):
                 payload["filters"] = filters
            elif isinstance(filters, dict) and "filters" in filters:
                 payload.update(filters)
            else:
                 payload["filters"] = [filters] # Single object
        except Exception as e:
            click.echo(f"Error: Invalid JSON for filters: {e}", err=True)
            return
    elif user:
        # Construct a simple USERNAME filter
        payload["filters"] = [{
            "type": "username",
            "values": list(user)
        }]
    else:
        # Default to sending to self if nothing specified? Or fail?
        # Let's target self
        payload["filters"] = [{
             "type": "username",
             "values": [config["username"]]
        }]
        click.echo(f"No target specified, sending to self ({config['username']})...")

    url = f"{config['base_url']}/notification/v1/send"
    params = {"sync": str(sync).lower()}
    
    click.echo("Sending notification...")
    if not sync:
        click.echo("(This is an async job by default. Use --sync to wait for completion)")

    resp = request_with_auth("POST", url, config, json=payload, params=params)
    
    if resp.status_code in [200, 201]:
        res = resp.json()
        click.echo(f"Success: {res.get('message')}")
        if res.get("jobId"):
            click.echo(f"Job ID: {res.get('jobId')}")
    else:
        click.echo(f"Error: Failed to send notification: {resp.status_code} - {resp.text}", err=True)


@device.command(name="list")
@click.option("--username", help="Filter by username")
@click.option("--platform", help="Filter by platform (e.g. android, ios)")
@click.option("--channel", help="Filter by channel")
@click.option("--limit", default=50, help="Limit results")
@click.option("--offset", default=0, help="Pagination offset")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def list_devices(username, platform, channel, limit, offset, raw):
    """List registered devices"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/devices"
    params = {
        "limit": limit,
        "offset": offset
    }
    if username: params["username"] = username
    if platform: params["platform"] = platform
    if channel: params["channel"] = channel

    resp = request_with_auth("GET", url, config, params=params)
    
    if resp.status_code == 200:
        data = resp.json()
        if raw:
            click.echo(json.dumps(data, indent=2))
        else:
            items = data.get("items", [])
            table_data = []
            for d in items:
                table_data.append([
                    truncate(d.get("deviceId")),
                    d.get("username"),
                    d.get("platform"),
                    d.get("channel"),
                    truncate(d.get("deviceToken"), 30),
                    d.get("lastActive")
                ])
            headers = ["Device ID", "User", "Platform", "Channel", "Token", "Last Active"]
            click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
            click.echo(f"\nTotal: {data.get('total')}")
    else:
         click.echo(f"Error: Failed to fetch devices: {resp.status_code} - {resp.text}", err=True)

@click.group()
def kpis():
    """KPI management commands"""
    pass

cli.add_command(kpis)

@kpis.command(name="list")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def list_kpis(raw):
    """List all available KPIs"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/kpi/definitions"
    resp = request_with_auth("GET", url, config)
    
    if resp.status_code == 200:
        items = resp.json()
        if raw:
            click.echo(json.dumps(items, indent=2))
        else:
            table_data = []
            for i in items:
                table_data.append([
                    i.get("kpiName"),
                    truncate(i.get("description") or "-"),
                    i.get("processorName"),
                    i.get("executionMode") or "-",
                    i.get("sourceLocation") or "-",
                    i.get("active") or i.get("isEnabled") # Handle both naming conventions if present
                ])
            headers = ["Name", "Description", "Processor", "Mode", "Source", "Active"]
            click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
    else:
        click.echo(f"Error: Failed to fetch KPIs: {resp.status_code} - {resp.text}", err=True)

@kpis.command(name="create")
@click.option("--name", required=True, help="KPI Name (Unique)")
@click.option("--description", required=True, help="KPI Description")
@click.option("--processor", default="GRAAL_JS_KPI_PROCESSOR", help="Processor Name (default: GRAAL_JS_KPI_PROCESSOR)")
@click.option("--mode", type=click.Choice(['LOCAL', 'REMOTE'], case_sensitive=False), default="LOCAL", help="Execution Mode (LOCAL, REMOTE)")
@click.option("--source-location", type=click.Choice(['INLINE', 'URL', 'DOCUMENT', 'CLASSPATH'], case_sensitive=False), required=True, help="Source Location")
@click.option("--source-content", required=True, help="Source Content (Script file path, URL, Document ID, or Class Name)")
@click.option("--remote-protocol", type=click.Choice(['HTTP', 'GRPC', 'LAMBDA'], case_sensitive=False), help="Remote Protocol (for REMOTE mode)")
@click.option("--active/--inactive", default=True, help="Set active status")
def create_kpi(name, description, processor, mode, source_location, source_content, remote_protocol, active):
    """Create a new KPI definition"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    # Handle INLINE source content from file
    content_to_send = source_content
    if source_location.upper() == 'INLINE' and os.path.exists(source_content):
        try:
            with open(source_content, "r") as f:
                content_to_send = f.read()
        except Exception as e:
            click.echo(f"Error reading script file: {e}", err=True)
            return

    payload = {
        "kpiName": name,
        "description": description,
        "processorName": processor,
        "executionMode": mode.upper(),
        "sourceLocation": source_location.upper(),
        "sourceContent": content_to_send,
        "isEnabled": active
    }

    if remote_protocol:
        payload["remoteProtocol"] = remote_protocol.upper()

    url = f"{config['base_url']}/kpi/definitions" # Using correct endpoint from integration test learning
    
    # Check if exists (to update or create)
    # Actually KpiDefinitionResource.create handles creation. Update might need ID or separate endpoint.
    # For now assume create/overwrite logic or handle 409.
    # The integration test used delete then post.
    
    resp = request_with_auth("POST", url, config, json=payload)
    
    if resp.status_code in [200, 201]:
        click.echo(click.style(f"✅ KPI '{name}' created/updated successfully.", fg="green"))
    else:
        click.echo(f"Error: Failed to create KPI: {resp.status_code} - {resp.text}", err=True)

@kpis.command(name="call")
@click.argument("kpi_name")
@click.option("--params", multiple=True, help="Key=Value parameters (e.g. salesAmount=1000)")
@click.option("--param-type", type=click.Choice(['string', 'int', 'float', 'bool']), default='string', help="Type for params (applies to all)")
@click.option("--calc-context", multiple=True, help="Context params (e.g. timezone=UTC)")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def call_kpi(kpi_name, params, param_type, calc_context, raw):
    """Execute a KPI and show results"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    # Parse params
    attributes = {}
    for p in params:
        if "=" in p:
            k, v = p.split("=", 1)
            # Simple Type Conversion
            if param_type == 'int':
                try: v = int(v)
                except: pass
            elif param_type == 'float':
                try: v = float(v)
                except: pass
            elif param_type == 'bool':
                v = v.lower() == 'true'
            attributes[k.strip()] = v
    
    # Parse context
    context_map = {}
    for c in calc_context:
        if "=" in c:
            k, v = c.split("=", 1)
            context_map[k.strip()] = v

    # Build Request Body
    # Using the structure confirmed in integration tests:
    # POST to /kpi/generic/process
    # Body: { "kpiName": ..., "attributes": ... }
    
    payload = {
        "kpiName": kpi_name,
        "attributes": attributes,
        "additionalParams": context_map
    }

    url = f"{config['base_url']}/kpi/generic/process"
    click.echo(f"Executing KPI '{kpi_name}'...")
    
    resp = request_with_auth("POST", url, config, json=payload)
    
    if resp.status_code == 200:
        result = resp.json()
        if raw:
            click.echo(json.dumps(result, indent=2))
        else:
            click.echo("\nKPI Execution Result:")
            click.echo(f"KPI: {result.get('kpiName')}")
            
            data = result.get("data")
            if isinstance(data, list) and data:
                # Dynamically determine headers from first row
                first_row = data[0]
                if isinstance(first_row, dict):
                    headers = list(first_row.keys())
                    table_data = []
                    for row in data:
                        table_data.append([str(row.get(h, "")) for h in headers])
                    click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
                else:
                    click.echo(json.dumps(data, indent=2))
            elif isinstance(data, dict):
                 click.echo(json.dumps(data, indent=2))
            else:
                 click.echo(str(data))
                 
            if result.get("errors"):
                click.echo(click.style(f"\nErrors: {json.dumps(result.get('errors'))}", fg="red"))
                
    else:
        click.echo(f"Error: Failed to execute KPI: {resp.status_code} - {resp.text}", err=True)

@kpis.command(name="delete")
@click.argument("kpi_name")
@click.confirmation_option(prompt="Are you sure you want to delete this KPI definition?")
def delete_kpi(kpi_name):
    """Delete a KPI definition"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/kpi/definitions/{kpi_name}"
    click.echo(f"Deleting KPI '{kpi_name}'...")
    
    resp = request_with_auth("DELETE", url, config)
    
    if resp.status_code in [200, 204]:
        click.echo(click.style(f"✅ KPI '{kpi_name}' deleted successfully.", fg="green"))
    elif resp.status_code == 404:
        click.echo(f"Error: KPI '{kpi_name}' not found.", err=True)
    else:
        click.echo(f"Error: Failed to delete KPI: {resp.status_code} - {resp.text}", err=True)

# ========================================================================
# INTEGRATION
# ========================================================================

@click.group()
def integration():
    """Integration pipeline management commands"""
    pass

cli.add_command(integration)

@integration.command(name="ingest")
@click.argument("file", type=click.Path(exists=True))
@click.option("--type", "entity_type", required=True, help="Entity type (PRODUCT, OUTLET, RETAILER_MAP, PRICE_RULE, etc.)")
@click.option("--transformer", help="Transformer ID (optional)")
@click.option("--sync/--async", "is_sync", default=False, help="Process synchronously (default: async)")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def integration_ingest(file, entity_type, transformer, is_sync, raw):
    """Ingest a JSON batch file for integration"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    try:
        with open(file, "r") as f:
            records = json.load(f)
    except Exception as e:
        click.echo(f"Error reading file: {e}", err=True)
        return

    # Support both array of records and full payload object
    if isinstance(records, list):
        payload = {
            "type": entity_type.upper(),
            "records": records
        }
    elif isinstance(records, dict) and "records" in records:
        payload = records
        payload["type"] = entity_type.upper()
    else:
        click.echo("Error: File must contain a JSON array of records or an object with 'records' key.", err=True)
        return

    if transformer:
        payload["transformerId"] = transformer

    url = f"{config['base_url']}/integration/ingest"
    params = {"sync": str(is_sync).lower()}

    click.echo(f"Ingesting {len(payload['records'])} {entity_type} records...")
    resp = request_with_auth("POST", url, config, json=payload, params=params)

    if resp.status_code in [200, 201, 202]:
        result = resp.json()
        if raw:
            click.echo(json.dumps(result, indent=2))
        else:
            click.echo(click.style("✅ Batch ingested successfully!", fg="green"))
            click.echo(f"  Batch ID:  {result.get('batchId')}")
            click.echo(f"  Status:    {result.get('status')}")
            click.echo(f"  Records:   {result.get('recordCount', len(payload['records']))}")
            if result.get("insertedCount") is not None:
                click.echo(f"  Inserted:  {result.get('insertedCount')}")
                click.echo(f"  Updated:   {result.get('updatedCount')}")
                click.echo(f"  Failed:    {result.get('failedCount')}")
    else:
        click.echo(f"Error: Failed to ingest: {resp.status_code} - {resp.text}", err=True)

@integration.command(name="batches")
@click.option("--status", help="Filter by status (RECEIVED, PROCESSING, COMPLETED, FAILED)")
@click.option("--type", "entity_type", help="Filter by entity type")
@click.option("--limit", default=50, help="Limit results")
@click.option("--offset", default=0, help="Pagination offset")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def integration_batches(status, entity_type, limit, offset, raw):
    """List integration batches"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/integration/batches"
    params = {"limit": limit, "offset": offset}
    if status: params["status"] = status
    if entity_type: params["type"] = entity_type

    resp = request_with_auth("GET", url, config, params=params)

    if resp.status_code == 200:
        data = resp.json()
        if raw:
            click.echo(json.dumps(data, indent=2))
        else:
            items = data if isinstance(data, list) else data.get("items", data.get("batches", []))
            table_data = []
            for b in items:
                created = str(b.get("createdAt", b.get("receivedAt", "")))
                if isinstance(created, str) and "T" in created:
                    created = created[:16].replace("T", " ")
                table_data.append([
                    str(b.get("batchId", b.get("id", ""))),
                    b.get("entityType", b.get("type", "")),
                    b.get("status"),
                    b.get("recordCount", ""),
                    b.get("insertedCount", ""),
                    b.get("failedCount", ""),
                    created,
                ])
            headers = ["Batch ID", "Type", "Status", "Records", "Inserted", "Failed", "Created"]
            click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
            click.echo(f"\nShowing {len(items)} batches")
    else:
        click.echo(f"Error: Failed to fetch batches: {resp.status_code} - {resp.text}", err=True)

@integration.command(name="batch")
@click.argument("batch_id")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def integration_batch_detail(batch_id, raw):
    """Get details for a specific batch"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/integration/batches/{batch_id}"
    resp = request_with_auth("GET", url, config)

    if resp.status_code == 200:
        data = resp.json()
        if raw:
            click.echo(json.dumps(data, indent=2))
        else:
            click.echo("Batch Details:")
            for k, v in data.items():
                if k == "payload":
                    click.echo(f"  {k}: ({len(json.dumps(v))} bytes)")
                elif isinstance(v, (dict, list)):
                    click.echo(f"  {k}: {json.dumps(v)[:200]}")
                else:
                    click.echo(f"  {k}: {v}")
    else:
        click.echo(f"Error: Failed to fetch batch: {resp.status_code} - {resp.text}", err=True)

@integration.command(name="failures")
@click.argument("batch_id", required=False)
@click.option("--type", "entity_type", help="Filter by entity type")
@click.option("--limit", default=50, help="Limit results")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def integration_failures(batch_id, entity_type, limit, raw):
    """List all failed batches, or get failed records for a specific batch.

    \b
    Usage:
      saleshub integration failures              # List all failed batches
      saleshub integration failures <BATCH_ID>   # Show failures for a batch
    """
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    if batch_id:
        # Show per-record failures for a specific batch
        url = f"{config['base_url']}/integration/batches/{batch_id}/failures"
        resp = request_with_auth("GET", url, config)

        if resp.status_code == 200:
            data = resp.json()
            if raw:
                click.echo(json.dumps(data, indent=2))
            else:
                failures = data.get("failures", [])
                if not failures:
                    click.echo("No failures for this batch.")
                    return
                table_data = []
                for f in failures:
                    table_data.append([
                        f.get("index"),
                        truncate(f.get("refId", ""), 15),
                        truncate(f.get("error", ""), 80),
                    ])
                headers = ["Index", "Ref ID", "Error"]
                click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
                click.echo(f"\nTotal failures: {len(failures)}")
        else:
            click.echo(f"Error: Failed to fetch failures: {resp.status_code} - {resp.text}", err=True)
    else:
        # List all failed batches
        url = f"{config['base_url']}/integration/batches"
        params = {"status": "FAILED", "limit": limit}
        if entity_type:
            params["type"] = entity_type

        resp = request_with_auth("GET", url, config, params=params)

        if resp.status_code == 200:
            data = resp.json()
            if raw:
                click.echo(json.dumps(data, indent=2))
            else:
                items = data if isinstance(data, list) else data.get("items", data.get("batches", []))
                if not items:
                    click.echo("✅ No failed batches found.")
                    return
                table_data = []
                for b in items:
                    error_count = b.get("errorCount", b.get("failedCount", ""))
                    total = b.get("recordCount", b.get("totalRecords", ""))
                    created = str(b.get("createdAt", b.get("receivedAt", "")))
                    if isinstance(created, str) and "T" in created:
                        created = created[:16].replace("T", " ")
                    table_data.append([
                        str(b.get("batchId", b.get("id", ""))),
                        b.get("entityType", b.get("type", "")),
                        b.get("status"),
                        total,
                        b.get("insertedCount", ""),
                        b.get("updatedCount", ""),
                        error_count,
                        truncate(b.get("transformerId", ""), 15),
                        created,
                    ])
                headers = ["Batch ID", "Type", "Status", "Total", "Inserted", "Updated", "Errors", "Transformer", "Created"]
                click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
                click.echo(f"\n❌ {len(items)} failed batch(es)")
                click.echo("Tip: Run 'saleshub integration failures <BATCH_ID>' to see per-record errors.")
        else:
            click.echo(f"Error: Failed to fetch failed batches: {resp.status_code} - {resp.text}", err=True)

@integration.command(name="retry")
@click.argument("batch_id")
def integration_retry(batch_id):
    """Retry failed records from a batch"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/integration/batches/{batch_id}/retry"
    click.echo(f"Retrying failures for batch {batch_id}...")
    resp = request_with_auth("POST", url, config)

    if resp.status_code in [200, 201, 202]:
        result = resp.json()
        click.echo(click.style("✅ Retry submitted!", fg="green"))
        click.echo(json.dumps(result, indent=2))
    else:
        click.echo(f"Error: Failed to retry: {resp.status_code} - {resp.text}", err=True)

@integration.command(name="process")
@click.option("--batch-id", help="Process a specific batch by ID")
@click.option("--limit", default=20, help="Max batches to process (for bulk)")
@click.option("--async", "is_async", is_flag=True, help="Process asynchronously")
def integration_process(batch_id, limit, is_async):
    """Process received integration batches"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    if batch_id:
        url = f"{config['base_url']}/integration/process/{batch_id}"
        click.echo(f"Processing batch {batch_id}...")
    elif is_async:
        url = f"{config['base_url']}/integration/process/async"
        click.echo(f"Triggering async processing (limit: {limit})...")
    else:
        url = f"{config['base_url']}/integration/process"
        click.echo(f"Processing up to {limit} batches...")

    params = {"limit": limit} if not batch_id else {}
    resp = request_with_auth("POST", url, config, params=params)

    if resp.status_code in [200, 202]:
        result = resp.json()
        click.echo(click.style("✅ Processing complete!", fg="green"))
        click.echo(json.dumps(result, indent=2))
    else:
        click.echo(f"Error: Failed to process: {resp.status_code} - {resp.text}", err=True)

@integration.command(name="metrics")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def integration_metrics(raw):
    """Show pipeline metrics (throughput, latency, queue)"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/integration/pipeline/metrics"
    resp = request_with_auth("GET", url, config)

    if resp.status_code == 200:
        data = resp.json()
        if raw:
            click.echo(json.dumps(data, indent=2))
        else:
            click.echo("Pipeline Metrics:")
            click.echo(f"  Uptime:              {data.get('uptimeSeconds', 0)}s")
            click.echo(f"  Total Batches:       {data.get('totalBatches', 0)}")
            click.echo(f"  Batches/min:         {data.get('batchesPerMinute', '-')}")
            click.echo(f"  Routed to Kinesis:   {data.get('routedToKinesis', 0)}")
            click.echo(f"  Routed to Iceberg:   {data.get('routedToIcebergDirect', 0)}")
            click.echo(f"  Avg Write Latency:   {data.get('avgWriteLatencyMs', '-')}ms")
    else:
        click.echo(f"Error: Failed to fetch metrics: {resp.status_code} - {resp.text}", err=True)

@integration.command(name="queue")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def integration_queue(raw):
    """Show async write queue status"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/integration/pipeline/queue"
    resp = request_with_auth("GET", url, config)

    if resp.status_code == 200:
        data = resp.json()
        if raw:
            click.echo(json.dumps(data, indent=2))
        else:
            click.echo("Write Queue Status:")
            for k, v in data.items():
                click.echo(f"  {k}: {v}")
    else:
        click.echo(f"Error: Failed to fetch queue: {resp.status_code} - {resp.text}", err=True)

@integration.command(name="types")
@click.option("--type", "entity_type", help="Get schema for specific type")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def integration_types(entity_type, raw):
    """List supported entity types or get schema for a specific type"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    if entity_type:
        url = f"{config['base_url']}/integration/types/{entity_type.upper()}/fields"
    else:
        url = f"{config['base_url']}/integration/types"

    resp = request_with_auth("GET", url, config)

    if resp.status_code == 200:
        data = resp.json()
        if raw:
            click.echo(json.dumps(data, indent=2))
        else:
            if entity_type:
                click.echo(f"Schema for {entity_type.upper()}:")
                mf = data.get("mandatoryFields", [])
                af = data.get("allFields", [])
                click.echo(f"  Mandatory: {', '.join(mf)}")
                click.echo(f"  All fields: {', '.join(af)}")
                if data.get("sample"):
                    click.echo(f"\n  Sample payload:")
                    click.echo(json.dumps(data["sample"], indent=2))
            else:
                types = data.get("types", [])
                for t in types:
                    name = t.get("type", t.get("name", ""))
                    fields = t.get("mandatoryFields", t.get("fields", []))
                    click.echo(f"  {name}: {', '.join(fields[:5])}{'...' if len(fields) > 5 else ''}")
                click.echo(f"\nTotal: {data.get('count', len(types))} types")
    else:
        click.echo(f"Error: Failed to fetch types: {resp.status_code} - {resp.text}", err=True)

@integration.command(name="recent")
@click.option("--limit", default=20, help="Number of recent statuses")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def integration_recent(limit, raw):
    """Show recent batch write statuses"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/integration/pipeline/recent"
    resp = request_with_auth("GET", url, config, params={"limit": limit})

    if resp.status_code == 200:
        data = resp.json()
        if raw:
            click.echo(json.dumps(data, indent=2))
        else:
            items = data if isinstance(data, list) else data.get("items", [])
            table_data = []
            for s in items:
                table_data.append([
                    truncate(str(s.get("batchId", "")), 20),
                    s.get("status"),
                    s.get("writeLatencyMs", ""),
                    s.get("recordCount", ""),
                ])
            headers = ["Batch ID", "Status", "Latency (ms)", "Records"]
            click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
    else:
        click.echo(f"Error: Failed to fetch recent: {resp.status_code} - {resp.text}", err=True)


# ========================================================================
# RECOMMENDATIONS
# ========================================================================

@click.group()
def recommendations():
    """Recommendation management commands"""
    pass

cli.add_command(recommendations)

@recommendations.command(name="list")
@click.option("--outlet", help="Filter by outlet code")
@click.option("--salesrep", help="Filter by salesrep username")
@click.option("--from-date", help="From date (YYYY-MM-DD)")
@click.option("--to-date", help="To date (YYYY-MM-DD)")
@click.option("--types", help="Comma-separated types (e.g. CROSS_SELL,UP_SELL)")
@click.option("--limit", default=200, help="Limit results")
@click.option("--offset", default=0, help="Pagination offset")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def list_recommendations(outlet, salesrep, from_date, to_date, types, limit, offset, raw):
    """List recommendations"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/recommendations"
    params = {"limit": limit, "offset": offset}
    if outlet: params["outlet"] = outlet
    if salesrep: params["salesrep"] = salesrep
    if from_date: params["fromDate"] = from_date
    if to_date: params["toDate"] = to_date
    if types: params["types"] = types

    resp = request_with_auth("GET", url, config, params=params)

    if resp.status_code == 200:
        data = resp.json()
        if raw:
            click.echo(json.dumps(data, indent=2))
        else:
            items = data if isinstance(data, list) else data.get("items", [])
            table_data = []
            for r in items:
                table_data.append([
                    r.get("outletCode", ""),
                    r.get("sku", ""),
                    truncate(r.get("productName", ""), 30),
                    r.get("recType", ""),
                    r.get("score", ""),
                    truncate(r.get("reason", ""), 40),
                ])
            headers = ["Outlet", "SKU", "Product", "Type", "Score", "Reason"]
            click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
            click.echo(f"\nTotal: {len(items)} recommendations")
    else:
        click.echo(f"Error: Failed to fetch recommendations: {resp.status_code} - {resp.text}", err=True)

@recommendations.command(name="rerun")
def rerun_recommendations():
    """Re-generate recommendations from sales data"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/recommendations/rerun"
    click.echo("Re-running recommendation engine...")

    resp = request_with_auth("POST", url, config)

    if resp.status_code == 200:
        result = resp.json()
        click.echo(click.style("✅ Recommendations regenerated!", fg="green"))
        click.echo(f"  Status:  {result.get('status')}")
        click.echo(f"  Elapsed: {result.get('elapsedMs', 0)}ms")
    else:
        click.echo(f"Error: Failed to rerun: {resp.status_code} - {resp.text}", err=True)


# ========================================================================
# ANALYTICS
# ========================================================================

@click.group()
def analytics():
    """Analytics and dashboard commands"""
    pass

cli.add_command(analytics)

@analytics.command(name="dormancy")
@click.option("--outlet", help="Filter by outlet code")
@click.option("--salesrep", help="Filter by salesrep")
@click.option("--days", default=30, help="Dormancy threshold in days (default: 30)")
@click.option("--limit", default=50, help="Limit results")
@click.option("--offset", default=0, help="Pagination offset")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def analytics_dormancy(outlet, salesrep, days, limit, offset, raw):
    """List dormant outlets (no orders in N days)"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/analytics/dormancy"
    params = {"days": days, "limit": limit, "offset": offset}
    if outlet: params["outletCode"] = outlet
    if salesrep: params["salesrep"] = salesrep

    resp = request_with_auth("GET", url, config, params=params)

    if resp.status_code == 200:
        data = resp.json()
        if raw:
            click.echo(json.dumps(data, indent=2))
        else:
            items = data if isinstance(data, list) else data.get("items", data.get("outlets", []))
            table_data = []
            for d in items:
                table_data.append([
                    d.get("outletCode", d.get("code", "")),
                    truncate(d.get("outletName", d.get("name", "")), 30),
                    d.get("lastOrderDate", d.get("lastOrder", "")),
                    d.get("daysSinceLastOrder", d.get("days", "")),
                    d.get("salesrep", ""),
                ])
            headers = ["Outlet", "Name", "Last Order", "Days Since", "Salesrep"]
            click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
            click.echo(f"\nTotal: {len(items)} dormant outlets (>{days} days)")
    else:
        click.echo(f"Error: Failed to fetch dormancy: {resp.status_code} - {resp.text}", err=True)

@analytics.command(name="trending")
@click.option("--period", type=click.Choice(["today", "last7", "lastMonth", "monthly", "daily", "range"]), default="last7", help="Time period")
@click.option("--from-date", help="From date for 'range' period (YYYY-MM-DD)")
@click.option("--to-date", help="To date for 'range' period (YYYY-MM-DD)")
@click.option("--limit", default=20, help="Limit results")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def analytics_trending(period, from_date, to_date, limit, raw):
    """Show trending products"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    if period in ("today", "last7", "lastMonth"):
        url = f"{config['base_url']}/analytics/products/trending/quick/{period}"
        params = {"limit": limit}
    elif period == "range":
        url = f"{config['base_url']}/analytics/products/trending/range"
        params = {"limit": limit}
        if from_date: params["fromDate"] = from_date
        if to_date: params["toDate"] = to_date
    else:
        url = f"{config['base_url']}/analytics/products/trending/{period}"
        params = {"limit": limit}

    resp = request_with_auth("GET", url, config, params=params)

    if resp.status_code == 200:
        data = resp.json()
        if raw:
            click.echo(json.dumps(data, indent=2))
        else:
            items = data if isinstance(data, list) else data.get("items", data.get("products", []))
            table_data = []
            for p in items:
                table_data.append([
                    p.get("sku", ""),
                    truncate(p.get("name", p.get("productName", "")), 30),
                    p.get("totalQuantity", p.get("qty", "")),
                    p.get("totalRevenue", p.get("revenue", "")),
                    p.get("orderCount", p.get("orders", "")),
                ])
            headers = ["SKU", "Product", "Quantity", "Revenue", "Orders"]
            click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))
            click.echo(f"\nTop {len(items)} trending products ({period})")
    else:
        click.echo(f"Error: Failed to fetch trending: {resp.status_code} - {resp.text}", err=True)

@analytics.command(name="dashboard")
@click.option("--outlet", help="Outlet code")
@click.option("--from-date", help="From date (YYYY-MM-DD)")
@click.option("--to-date", help="To date (YYYY-MM-DD)")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def analytics_dashboard(outlet, from_date, to_date, raw):
    """Show outlet dashboard metrics"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/analytics/dashboard"
    params = {}
    if outlet: params["outletCode"] = outlet
    if from_date: params["fromDate"] = from_date
    if to_date: params["toDate"] = to_date

    resp = request_with_auth("GET", url, config, params=params)

    if resp.status_code == 200:
        data = resp.json()
        if raw:
            click.echo(json.dumps(data, indent=2))
        else:
            click.echo("Dashboard Metrics:")
            for k, v in data.items():
                if isinstance(v, (dict, list)):
                    click.echo(f"  {k}: {json.dumps(v)[:200]}")
                else:
                    click.echo(f"  {k}: {v}")
    else:
        click.echo(f"Error: Failed to fetch dashboard: {resp.status_code} - {resp.text}", err=True)


# ========================================================================
# JOBS
# ========================================================================

@click.group()
def jobs():
    """Job status tracking commands"""
    pass

cli.add_command(jobs)

@jobs.command(name="status")
@click.argument("job_id")
@click.option("--raw/--table", default=False, help="Show raw JSON output")
def job_status(job_id, raw):
    """Get the status of a background job"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/jobs/{job_id}"
    resp = request_with_auth("GET", url, config)

    if resp.status_code == 200:
        job = resp.json()
        if raw:
            click.echo(json.dumps(job, indent=2))
        else:
            click.echo("Job Details:")
            for k, v in job.items():
                if isinstance(v, (dict, list)):
                    click.echo(f"  {k}: {json.dumps(v)[:200]}")
                else:
                    click.echo(f"  {k}: {v}")
    elif resp.status_code == 404:
        click.echo(f"Error: Job '{job_id}' not found.", err=True)
    else:
        click.echo(f"Error: Failed to fetch job: {resp.status_code} - {resp.text}", err=True)


# ========================================================================
# TARGETS
# ========================================================================

@click.group()
def targets():
    """Target management commands"""
    pass

cli.add_command(targets)

@targets.command(name="upload")
@click.argument("file", type=click.Path(exists=True))
@click.option("--header/--no-header", default=True, help="File has header row (default: yes)")
@click.option("--dry-run/--execute", default=True, help="Dry run mode (default: dry-run)")
def upload_targets(file, header, dry_run):
    """Upload targets from a CSV file"""
    config = load_config()
    if not config:
        click.echo("Error: CLI not configured. Run 'saleshub configure' first.", err=True)
        return

    url = f"{config['base_url']}/target-generator"
    params = {
        "header": str(header).lower(),
        "dryRun": str(dry_run).lower()
    }

    mode_str = "DRY RUN" if dry_run else "LIVE"
    click.echo(f"Uploading targets ({mode_str})...")

    try:
        token = get_token(config)
        headers = {
            "Authorization": f"Bearer {token}",
            "X-Tenant-Id": config["tenant_id"]
        }
        with open(file, "rb") as f:
            files = {"file": (os.path.basename(file), f)}
            resp = requests.post(url, headers=headers, params=params, files=files)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        return

    if resp.status_code == 200:
        result = resp.json()
        click.echo(click.style(f"✅ Targets uploaded ({mode_str})!", fg="green"))
        click.echo(json.dumps(result, indent=2))
    else:
        click.echo(f"Error: Failed to upload targets: {resp.status_code} - {resp.text}", err=True)


if __name__ == '__main__':
    cli()
