"""
Nowledge Mem CLI - AI agent-friendly memory management.

Aliases:
  m  = memories
  t  = threads
  c  = communities
"""

import argparse
import json as json_module
import os
import platform
import shutil
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Optional
from urllib.parse import quote, urlsplit, urlunsplit

import httpx
from rich import box
from rich.console import Console
from rich.markdown import Markdown
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Confirm, Prompt
from rich.table import Table

from . import __version__

SUPPORTED_PROVIDER_TYPES = [
    "openai",
    "anthropic",
    "gemini",
    "xai",
    "deepseek",
    "openrouter",
    "ollama",
    "github_copilot",
    "openai_codex",
    "minimax",
    "zai",
    "moonshot",
    "groq",
    "together",
    "fireworks",
    "kimi",
    "openai_compatible",
]

PROVIDER_OPTIONS = [
    ("OpenAI (`openai`)", "openai"),
    ("Anthropic (`anthropic`)", "anthropic"),
    ("Gemini (`gemini`)", "gemini"),
    ("xAI (`xai`)", "xai"),
    ("DeepSeek (`deepseek`)", "deepseek"),
    ("OpenRouter (`openrouter`)", "openrouter"),
    ("Ollama (`ollama`)", "ollama"),
    ("GitHub Copilot (`github_copilot`)", "github_copilot"),
    ("ChatGPT Subscription (`openai_codex`)", "openai_codex"),
    ("MiniMax (`minimax`)", "minimax"),
    ("Z.AI (`zai`)", "zai"),
    ("Moonshot (`moonshot`)", "moonshot"),
    ("Groq (`groq`)", "groq"),
    ("Together (`together`)", "together"),
    ("Fireworks (`fireworks`)", "fireworks"),
    ("Kimi OpenAI-compatible (`kimi`)", "kimi"),
    ("Custom OpenAI-compatible (`openai_compatible`)", "openai_compatible"),
]

PROVIDER_DEFAULTS: dict[str, dict[str, str]] = {
    "openai": {"model": "gpt-4o", "api_base": "https://api.openai.com/v1"},
    "anthropic": {"model": "claude-sonnet-4-20250514", "api_base": "https://api.anthropic.com"},
    "gemini": {"model": "gemini-flash-latest", "api_base": "https://generativelanguage.googleapis.com"},
    "xai": {"model": "grok-3", "api_base": "https://api.x.ai/v1"},
    "deepseek": {"model": "deepseek-chat", "api_base": "https://api.deepseek.com/v1"},
    "openrouter": {"model": "anthropic/claude-sonnet-4", "api_base": "https://openrouter.ai/api/v1"},
    "minimax": {"model": "MiniMax-M2.1", "api_base": "https://api.minimax.io/v1"},
    "zai": {"model": "glm-4.7", "api_base": "https://api.z.ai/api/paas/v4"},
    "moonshot": {"model": "kimi-k2-thinking", "api_base": "https://api.moonshot.ai/v1"},
    "ollama": {"model": "llama3.2", "api_base": "http://127.0.0.1:11434"},
    "kimi": {"model": "kimi-k2-thinking", "api_base": "https://api.moonshot.cn/v1"},
}

DEFAULT_API_URL = "http://127.0.0.1:14242"

# Server-only commands (serve) are only shown on Linux where headless mode is used.
# On macOS/Windows the Tauri desktop app manages the backend lifecycle.
_is_server_platform = platform.system() == "Linux"

console = Console()
_json_mode = False


def set_json_mode(enabled: bool) -> None:
    global _json_mode
    _json_mode = enabled


def is_json_mode() -> bool:
    return _json_mode


def output_json(data: Any) -> None:
    print(json_module.dumps(data, indent=2, default=str, ensure_ascii=False))


def _normalize_labels(labels: list[str] | None) -> list[str] | None:
    """Split comma-separated labels into individual labels.

    Allows both:
    - nmem m add -l "test" -l "python"
    - nmem m add -l "test,python"
    """
    if not labels:
        return labels
    result: list[str] = []
    for label in labels:
        # Split on comma and strip whitespace
        for part in label.split(","):
            part = part.strip()
            if part:
                result.append(part)
    return result if result else None


def get_api_url() -> str:
    return os.environ.get("NMEM_API_URL", DEFAULT_API_URL)


def get_api_key() -> str:
    return os.environ.get("NMEM_API_KEY", "").strip()


def get_api_headers() -> dict[str, str]:
    api_key = get_api_key()
    if not api_key:
        return {}
    # Send both standard bearer auth and explicit key header.
    # Some proxies strip one header but preserve the other.
    return {
        "Authorization": f"Bearer {api_key}",
        "X-NMEM-API-Key": api_key,
    }


def get_api_cookies() -> dict[str, str]:
    api_key = get_api_key()
    if not api_key:
        return {}
    return {"nmem_api_key": api_key}


def _build_params_with_query_key(
    params: dict[str, Any] | list[tuple[str, Any]] | Any | None,
) -> dict[str, Any] | list[tuple[str, Any]] | Any | None:
    api_key = get_api_key()
    if not api_key:
        return params

    if params is None:
        return {"nmem_api_key": api_key}

    if isinstance(params, dict):
        if "nmem_api_key" in params:
            return params
        merged = dict(params)
        merged["nmem_api_key"] = api_key
        return merged

    if isinstance(params, list):
        has_key = any(str(key).lower() == "nmem_api_key" for key, _ in params)
        if has_key:
            return params
        return [*params, ("nmem_api_key", api_key)]

    return params


def _strip_remote_api_path_prefix(url: str) -> str:
    """Compatibility fallback for legacy tunnel URLs ending in /remote-api.

    Some earlier tunnel setups surfaced URLs like:
      https://<random>.trycloudflare.com/remote-api
    while Cloudflare already routed requests at root paths.
    """

    parts = urlsplit(url)
    path = parts.path or ""

    if path == "/remote-api":
        path = "/"
    elif path.startswith("/remote-api/"):
        path = path[len("/remote-api") :]
    else:
        return url

    return urlunsplit((parts.scheme, parts.netloc, path, parts.query, parts.fragment))


def _response_detail(response: httpx.Response) -> str:
    try:
        payload = response.json()
        if isinstance(payload, dict):
            detail = payload.get("detail")
            if isinstance(detail, str):
                return detail
    except Exception:
        pass
    return response.text


def _is_missing_api_key_response(response: httpx.Response) -> bool:
    if response.status_code != 401:
        return False
    return "missing api key" in _response_detail(response).lower()


def api_request(
    method: str,
    url: str,
    *,
    timeout: float,
    headers: dict[str, str] | None = None,
    params: dict[str, Any] | list[tuple[str, Any]] | Any | None = None,
    json: dict[str, Any] | None = None,
) -> httpx.Response:
    merged_headers = get_api_headers()
    if headers:
        merged_headers.update(headers)

    cookies = get_api_cookies() or None
    response = httpx.request(
        method,
        url,
        params=params,
        json=json,
        timeout=timeout,
        headers=merged_headers,
        cookies=cookies,
    )

    # Proxy-compat retry:
    # If auth headers are stripped in transit, retry once with query-key fallback.
    if get_api_key() and _is_missing_api_key_response(response):
        retry_params = _build_params_with_query_key(params)
        response = httpx.request(
            method,
            url,
            params=retry_params,
            json=json,
            timeout=timeout,
            headers=merged_headers,
            cookies=cookies,
        )

    # Legacy URL compatibility retry:
    # Earlier tunnel URLs used ".../remote-api". For quick tunnels the correct
    # public URL is root-based, so retry once with the prefix removed.
    if get_api_key() and _is_missing_api_key_response(response):
        compat_url = _strip_remote_api_path_prefix(url)
        if compat_url != url:
            retry_params = _build_params_with_query_key(params)
            response = httpx.request(
                method,
                compat_url,
                params=retry_params,
                json=json,
                timeout=timeout,
                headers=merged_headers,
                cookies=cookies,
            )

    return response


def print_error(title: str, message: str, hint: str | None = None) -> None:
    if is_json_mode():
        return
    console.print(f"[bold red]x[/bold red] [bold]{title}[/bold]")
    console.print(f"  [dim]{message}[/dim]")
    if hint:
        console.print(f"  [dim cyan]Hint: {hint}[/dim cyan]")


def print_success(message: str, detail: str | None = None) -> None:
    if is_json_mode():
        return
    if detail:
        console.print(f"[green]ok[/green] {message}: [cyan]{detail}[/cyan]")
    else:
        console.print(f"[green]ok[/green] {message}")


# ═══════════════════════════════════════════════════════════════════════════════
# API Client
# ═══════════════════════════════════════════════════════════════════════════════


def api_get(endpoint: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
    url = f"{get_api_url()}{endpoint}"
    try:
        response = api_request(
            "GET",
            url,
            params=params,
            timeout=30.0,
        )
        response.raise_for_status()
        return response.json()
    except httpx.ConnectError:
        error = {
            "error": "connection_failed",
            "message": f"Cannot connect to {get_api_url()}",
        }
        if is_json_mode():
            output_json(error)
        else:
            print_error(
                "Connection Failed",
                f"Cannot reach {get_api_url()}",
                "Make sure Nowledge Mem is running",
            )
        sys.exit(1)
    except httpx.HTTPStatusError as e:
        error = {"error": "api_error", "status_code": e.response.status_code}
        try:
            error["detail"] = e.response.json().get("detail", "")
        except Exception:
            pass
        if is_json_mode():
            output_json(error)
        else:
            status = e.response.status_code
            if status == 404:
                print_error("Not Found", "Resource doesn't exist", "Check the ID")
            else:
                print_error(
                    f"API Error ({status})", error.get("detail", "Request failed")
                )
        sys.exit(1)


def api_post(
    endpoint: str, data: dict[str, Any], *, timeout: float = 60.0
) -> dict[str, Any]:
    url = f"{get_api_url()}{endpoint}"
    try:
        response = api_request(
            "POST",
            url,
            json=data,
            timeout=timeout,
        )
        response.raise_for_status()
        return response.json()
    except httpx.ConnectError:
        error = {
            "error": "connection_failed",
            "message": f"Cannot connect to {get_api_url()}",
        }
        if is_json_mode():
            output_json(error)
        else:
            print_error("Connection Failed", f"Cannot reach {get_api_url()}")
        sys.exit(1)
    except httpx.HTTPStatusError as e:
        error = {"error": "api_error", "status_code": e.response.status_code}
        try:
            error["detail"] = e.response.json().get("detail", "")
        except Exception:
            pass
        if is_json_mode():
            output_json(error)
        else:
            print_error(
                f"API Error ({e.response.status_code})",
                error.get("detail", "Request failed"),
            )
        sys.exit(1)


def api_delete(
    endpoint: str, params: dict[str, Any] | None = None
) -> dict[str, Any]:
    url = f"{get_api_url()}{endpoint}"
    try:
        response = api_request(
            "DELETE",
            url,
            params=params,
            timeout=30.0,
        )
        response.raise_for_status()
        return response.json()
    except httpx.ConnectError:
        error = {"error": "connection_failed", "message": "Cannot connect"}
        if is_json_mode():
            output_json(error)
        else:
            print_error("Connection Failed", "Cannot reach server")
        sys.exit(1)
    except httpx.HTTPStatusError as e:
        error = {"error": "api_error", "status_code": e.response.status_code}
        if is_json_mode():
            output_json(error)
        else:
            if e.response.status_code == 404:
                print_error("Not Found", "Already deleted or invalid ID")
            else:
                print_error(
                    f"Delete Failed ({e.response.status_code})", "Could not delete"
                )
        sys.exit(1)


def api_patch(endpoint: str, data: dict[str, Any]) -> dict[str, Any]:
    url = f"{get_api_url()}{endpoint}"
    try:
        response = api_request(
            "PATCH",
            url,
            json=data,
            timeout=30.0,
        )
        response.raise_for_status()
        return response.json()
    except httpx.ConnectError:
        error = {"error": "connection_failed", "message": "Cannot connect"}
        if is_json_mode():
            output_json(error)
        else:
            print_error("Connection Failed", "Cannot reach server")
        sys.exit(1)
    except httpx.HTTPStatusError as e:
        error = {"error": "api_error", "status_code": e.response.status_code}
        if is_json_mode():
            output_json(error)
        else:
            print_error(f"Update Failed ({e.response.status_code})", "Could not update")
        sys.exit(1)


def _extract_mcp_json(response_text: str) -> dict[str, Any]:
    """Parse FastMCP stateless HTTP response (JSON or SSE data envelope)."""
    text = response_text.strip()
    if not text:
        raise ValueError("Empty MCP response")

    if text.startswith("{"):
        return json_module.loads(text)

    for line in response_text.splitlines():
        if line.startswith("data: "):
            return json_module.loads(line[6:])

    raise ValueError("No MCP data event found in response")


def api_mcp_tool_call(tool_name: str, arguments: dict[str, Any]) -> dict[str, Any]:
    """Call an MCP tool via /mcp/ and return structuredContent if present."""
    url = f"{get_api_url()}/mcp/"
    headers = get_api_headers()
    headers["Accept"] = "application/json, text/event-stream"
    headers["Connection"] = "close"

    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {
            "name": tool_name,
            "arguments": arguments,
        },
    }

    try:
        response = api_request(
            "POST",
            url,
            json=payload,
            timeout=60.0,
            headers=headers,
        )
        response.raise_for_status()

        parsed = _extract_mcp_json(response.text)
        if "error" in parsed:
            raise RuntimeError(parsed["error"].get("message", "Unknown MCP error"))

        result = parsed.get("result", {})
        if isinstance(result, dict) and isinstance(result.get("structuredContent"), dict):
            return result["structuredContent"]

        return result if isinstance(result, dict) else {"result": result}

    except httpx.ConnectError:
        if is_json_mode():
            output_json({"error": "connection_failed", "message": "Cannot connect"})
        else:
            print_error("Connection Failed", "Cannot reach server")
        sys.exit(1)
    except Exception as e:
        if is_json_mode():
            output_json({"error": "mcp_error", "message": str(e)})
        else:
            print_error("MCP Error", str(e), "Check MCP endpoint availability")
        sys.exit(1)


def api_put(endpoint: str, data: dict[str, Any]) -> dict[str, Any]:
    url = f"{get_api_url()}{endpoint}"
    try:
        response = api_request(
            "PUT",
            url,
            json=data,
            timeout=30.0,
        )
        response.raise_for_status()
        return response.json()
    except httpx.ConnectError:
        error = {"error": "connection_failed", "message": "Cannot connect"}
        if is_json_mode():
            output_json(error)
        else:
            print_error("Connection Failed", "Cannot reach server")
        sys.exit(1)
    except httpx.HTTPStatusError as e:
        error = {"error": "api_error", "status_code": e.response.status_code}
        try:
            error["detail"] = e.response.json().get("detail", "")
        except Exception:
            pass
        if is_json_mode():
            output_json(error)
        else:
            print_error(
                f"API Error ({e.response.status_code})",
                error.get("detail", "Request failed"),
            )
        sys.exit(1)


# ═══════════════════════════════════════════════════════════════════════════════
# Utilities
# ═══════════════════════════════════════════════════════════════════════════════


def format_date(date_str: str | None) -> str:
    if not date_str:
        return "-"
    try:
        dt = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d")
    except (ValueError, AttributeError):
        return date_str[:10] if date_str else "-"


def truncate(text: str, max_len: int = 50) -> str:
    if not text:
        return ""
    text = text.replace("\n", " ").strip()
    if len(text) <= max_len:
        return text
    return text[: max_len - 1] + "..."


def format_score(score: float) -> str:
    if score >= 0.8:
        return f"[bold green]{score:.2f}[/bold green]"
    elif score >= 0.5:
        return f"[green]{score:.2f}[/green]"
    elif score >= 0.3:
        return f"[yellow]{score:.2f}[/yellow]"
    else:
        return f"[dim]{score:.2f}[/dim]"


def format_importance(imp: float) -> str:
    if imp >= 0.7:
        return f"[green]{imp:.1f}[/green]"
    elif imp >= 0.4:
        return f"[yellow]{imp:.1f}[/yellow]"
    else:
        return f"[dim]{imp:.1f}[/dim]"


def parse_time_filter(time_str: str) -> str | None:
    now = datetime.now()
    time_map = {
        "today": now - timedelta(days=1),
        "yesterday": now - timedelta(days=2),
        "week": now - timedelta(weeks=1),
        "month": now - timedelta(days=30),
        "year": now - timedelta(days=365),
    }
    if time_str in time_map:
        return time_map[time_str].strftime("%Y-%m-%d")
    return time_str


# ═══════════════════════════════════════════════════════════════════════════════
# Commands: Status & Stats
# ═══════════════════════════════════════════════════════════════════════════════


def _format_tokens(n: int) -> str:
    """Format token count as human-readable string (e.g. 123K, 1.5M)."""
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n / 1_000:.0f}K"
    return str(n)


def cmd_status() -> None:
    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Connecting...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get("/health")
    else:
        data = api_get("/health")

    result = {
        "status": data.get("status", "ok"),
        "version": data.get("version", __version__),
        "api_url": get_api_url(),
        "database": data.get("database_connected", True),
    }

    # Fetch agent status for token budget info
    agent_data: dict = {}
    try:
        agent_data = api_get("/agent/status")
    except Exception:
        pass

    if is_json_mode():
        if agent_data:
            result["agent"] = {
                "running": agent_data.get("running", False),
                "tokens_this_hour": agent_data.get("tokens_this_hour", 0),
                "tokens_today": agent_data.get("tokens_today", 0),
                "max_tokens_per_hour": agent_data.get("max_tokens_per_hour", 0),
                "max_tokens_per_day": agent_data.get("max_tokens_per_day", 0),
                "budget_paused": agent_data.get("budget_paused", False),
            }
        output_json(result)
    else:
        status_color = "green" if result["status"] == "ok" else "yellow"
        console.print()
        console.print(f"[bold]nmem[/bold] v{result['version']}")
        console.print(f"  status   [{status_color}]{result['status']}[/{status_color}]")
        console.print(f"  api      {result['api_url']}")
        console.print(
            f"  database {'connected' if result['database'] else 'disconnected'}"
        )

        # Agent token budget info
        if agent_data:
            agent_running = agent_data.get("running", False)
            agent_color = "green" if agent_running else "dim"
            console.print(
                f"  agent    [{agent_color}]{'running' if agent_running else 'stopped'}[/{agent_color}]"
            )

            tokens_hour = agent_data.get("tokens_this_hour", 0)
            tokens_day = agent_data.get("tokens_today", 0)
            max_hour = agent_data.get("max_tokens_per_hour", 0)
            max_day = agent_data.get("max_tokens_per_day", 0)
            paused = agent_data.get("budget_paused", False)

            if max_hour > 0 or max_day > 0:
                hour_str = f"{_format_tokens(tokens_hour)}/{_format_tokens(max_hour)}"
                day_str = f"{_format_tokens(tokens_day)}/{_format_tokens(max_day)}"
                budget_color = "red" if paused else "green"
                console.print(f"  tokens   [{budget_color}]{hour_str}/h  {day_str}/d[/{budget_color}]")
                if paused:
                    console.print("  [bold red]! Token budget exceeded — background tasks paused[/bold red]")

        console.print()


def cmd_stats() -> None:
    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Loading...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get("/stats")
    else:
        data = api_get("/stats")

    result = {
        "memories": data.get("memory_count", data.get("memories", 0)),
        "threads": data.get("thread_count", data.get("threads", 0)),
        "entities": data.get("entity_count", data.get("entities", 0)),
        "labels": data.get("label_count", data.get("labels", 0)),
        "communities": data.get("community_count", 0),
    }

    if is_json_mode():
        output_json(result)
    else:
        console.print()
        console.print("[bold]Database Statistics[/bold]")
        console.print(f"  memories    [cyan]{result['memories']:,}[/cyan]")
        console.print(f"  threads     [cyan]{result['threads']:,}[/cyan]")
        console.print(f"  entities    [magenta]{result['entities']:,}[/magenta]")
        console.print(f"  labels      [yellow]{result['labels']:,}[/yellow]")
        console.print(f"  communities [green]{result['communities']:,}[/green]")
        console.print()


# ═══════════════════════════════════════════════════════════════════════════════
# Community Commands
# ═══════════════════════════════════════════════════════════════════════════════


def cmd_communities_list(limit: int = 20) -> None:
    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Loading communities...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get("/communities", params={"limit": limit})
    else:
        data = api_get("/communities", params={"limit": limit})

    communities = data.get("communities", [])

    if is_json_mode():
        output_json(data)
        return

    if not communities:
        console.print()
        console.print("[dim]No communities detected yet.[/dim]")
        console.print("[dim]Run community detection to discover knowledge themes.[/dim]")
        console.print()
        return

    console.print()
    console.print(f"[bold]Knowledge Communities[/bold]  [dim]({len(communities)} found)[/dim]")
    console.print()

    for c in communities:
        name = c.get("name", "Unnamed")
        member_count = c.get("member_count", 0)
        summary = c.get("summary", c.get("description", ""))
        cid = c.get("id", "")

        console.print(f"  [bold cyan]{name}[/bold cyan]  [dim]({member_count} entities)[/dim]")
        if summary:
            # Truncate summary to ~100 chars for list view
            short = summary[:120] + "..." if len(summary) > 120 else summary
            console.print(f"    [dim]{short}[/dim]")
        console.print(f"    [dim]id: {cid}[/dim]")
        console.print()


def cmd_communities_show(community_id: str) -> None:
    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Loading community...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get(f"/communities/{community_id}")
    else:
        data = api_get(f"/communities/{community_id}")

    if is_json_mode():
        output_json(data)
        return

    community = data.get("community", {})
    entities = data.get("entities", [])
    sample_memories = data.get("sample_memories", [])

    console.print()
    console.print(f"[bold]{community.get('name', 'Unnamed')}[/bold]")
    console.print(f"  [dim]{community.get('member_count', 0)} entities[/dim]")
    console.print()

    summary = community.get("summary", "")
    if summary:
        console.print(Markdown(summary))
        console.print()

    if entities:
        table = Table(box=box.SIMPLE, show_header=True, header_style="bold")
        table.add_column("Entity", style="cyan")
        table.add_column("Type", style="dim")
        table.add_column("Memories", justify="right")
        for e in entities[:15]:
            table.add_row(
                e.get("name", "?"),
                e.get("entity_type", ""),
                str(e.get("memory_count", 0)),
            )
        console.print(table)

    if sample_memories:
        console.print()
        console.print("[bold]Sample Memories[/bold]")
        for m in sample_memories:
            title = m.get("title", "Untitled")
            preview = m.get("content_preview", "")
            unit_type = m.get("unit_type", "")
            console.print(f"  [cyan]{title}[/cyan]  [dim]{unit_type}[/dim]")
            if preview:
                short = preview[:100] + "..." if len(preview) > 100 else preview
                console.print(f"    [dim]{short}[/dim]")

    console.print()


def cmd_communities_detect(resolution: float = 1.0) -> None:
    url = f"{get_api_url()}/agent/trigger/community-detection"
    try:
        response = api_request(
            "POST",
            url,
            params={"resolution": resolution, "generate_ai_summary": True},
            timeout=30.0,
        )
        response.raise_for_status()
        data = response.json()
    except httpx.ConnectError:
        print_error("Connection failed", "Cannot reach the backend server")
        sys.exit(1)
    except httpx.HTTPStatusError as e:
        print_error("Request failed", str(e))
        sys.exit(1)

    if is_json_mode():
        output_json(data)
    else:
        console.print("[green]ok[/green] Community detection triggered")
        if data.get("message"):
            console.print(f"  [dim]{data['message']}[/dim]")


# ═══════════════════════════════════════════════════════════════════════════════
# Graph Commands
# ═══════════════════════════════════════════════════════════════════════════════


def cmd_graph_evolves(memory_id: str, limit: int = 20) -> None:
    """Show the EVOLVES version chain for a memory.

    Returns all edges where the memory appears as older or newer,
    showing how understanding of a topic has grown or changed over time.
    Each edge has a relation type: replaces | enriches | confirms | challenges.
    """
    params: dict[str, Any] = {"memory_id": memory_id, "limit": limit}
    data = api_get("/agent/evolves", params=params)

    edges: list[dict[str, Any]] = data.get("edges", [])

    if is_json_mode():
        output_json(data)
        return

    console.print()
    console.print(f"[bold]EVOLVES chain for: [cyan]{memory_id}[/cyan][/bold]")
    console.print()

    if not edges:
        console.print("[dim]No EVOLVES relationships found for this memory.[/dim]")
        return

    _EVOLVES_LABELS: dict[str, str] = {
        "replaces":   "supersedes — newer understanding replaces older",
        "enriches":   "enriches  — adds depth to earlier knowledge",
        "confirms":   "confirms  — corroborated from another source",
        "challenges": "challenges — contradicts or questions",
    }

    for edge in edges:
        older_id = edge.get("older_id", "")
        older_title = edge.get("older_title", "(untitled)")
        newer_id = edge.get("newer_id", "")
        newer_title = edge.get("newer_title", "(untitled)")
        relation = edge.get("content_relation") or "related"
        label = _EVOLVES_LABELS.get(relation, relation)
        marker = " [dim][you][/dim]" if memory_id in (older_id, newer_id) else ""

        console.print(f"  [dim cyan]{older_id}[/dim cyan]  {truncate(older_title, 35)}{marker}")
        console.print(f"    [yellow]→ {label}[/yellow]")
        console.print(f"  [dim cyan]{newer_id}[/dim cyan]  {truncate(newer_title, 35)}")
        console.print()


def cmd_graph_expand(memory_id: str, depth: int = 1, limit: int = 20) -> None:
    """Expand the knowledge graph around a memory node.

    Returns connected memories, entities, and source documents with
    their relationship types and strengths.
    """
    params: dict[str, Any] = {"depth": depth, "limit": limit}
    data = api_get(f"/graph/expand/{memory_id}", params=params)

    neighbors = data.get("neighbors", [])
    edges = data.get("edges", [])
    center = data.get("center_node", memory_id)

    if is_json_mode():
        output_json(data)
        return

    console.print()
    console.print(f"[bold]Graph: [cyan]{center}[/cyan][/bold]  depth={depth}")
    console.print()

    if not neighbors:
        console.print("[dim]No connections found.[/dim]")
        return

    # Build node map for edge joining
    node_map = {n["id"]: n for n in neighbors}

    # Group edges by type
    by_type: dict[str, list[dict[str, Any]]] = {}
    for edge in edges:
        etype = edge.get("edge_type", "RELATED")
        by_type.setdefault(etype, []).append(edge)

    edge_type_labels = {
        "CRYSTALLIZED_FROM": "Synthesized from",
        "EVOLVES": "Knowledge evolution",
        "SOURCED_FROM": "Sourced from document",
        "MENTIONS": "Mentions entity",
        "RELATED": "Related",
    }

    for etype, elist in by_type.items():
        label = edge_type_labels.get(etype, etype)
        console.print(f"[bold yellow]{label}[/bold yellow] ({len(elist)})")
        for edge in elist:
            neighbor_id = edge["target"] if edge["source"] == center else edge["source"]
            node = node_map.get(neighbor_id, {})
            title = node.get("label") or node.get("metadata", {}).get("title", neighbor_id)
            relation = edge.get("metadata", {}).get("relation_type") or ""
            weight = edge.get("weight", 0)
            weight_str = f" [{weight*100:.0f}%]" if weight else ""
            relation_str = f" — {relation}" if relation else ""
            console.print(f"  [dim cyan]{neighbor_id}[/dim cyan]{weight_str}  {title}{relation_str}")
        console.print()


# ═══════════════════════════════════════════════════════════════════════════════
# Feed Commands
# ═══════════════════════════════════════════════════════════════════════════════


_FEED_EVENT_LABELS: dict[str, str] = {
    "memory_created": "Memory saved",
    "insight_generated": "Insight",
    "pattern_detected": "Pattern",
    "agent_observation": "Observation",
    "daily_briefing": "Daily briefing",
    "crystal_created": "Crystal",
    "flag_contradiction": "Flag: contradiction",
    "flag_stale": "Flag: stale",
    "flag_merge_candidate": "Flag: duplicate",
    "flag_review": "Flag: review",
    "source_ingested": "Document ingested",
    "source_extracted": "Knowledge extracted",
    "working_memory_updated": "Working Memory updated",
    "evolves_detected": "Knowledge evolution",
    "kg_extraction": "Entity extraction",
    "url_captured": "URL captured",
}

_FEED_TIER1 = frozenset([
    "memory_created", "insight_generated", "pattern_detected", "agent_observation",
    "daily_briefing", "crystal_created", "flag_contradiction", "flag_stale",
    "flag_merge_candidate", "source_ingested", "source_extracted", "url_captured",
])


def cmd_feed_events(
    last_n_days: int = 7,
    event_type: str | None = None,
    tier1_only: bool = True,
    limit: int = 100,
    date_from: str | None = None,
    date_to: str | None = None,
) -> None:
    """Browse recent activity from the feed (what was saved, learned, or ingested).

    Groups events by day in human-readable format. Use --all for background events.
    """
    params: dict[str, Any] = {"last_n_days": last_n_days, "limit": limit}
    if event_type:
        params["event_type"] = event_type
    if date_from:
        params["date_from"] = date_from
    if date_to:
        params["date_to"] = date_to

    data = api_get("/agent/feed/events", params=params)

    events: list[dict[str, Any]] = (
        data.get("events", data) if isinstance(data, dict) else data
    )

    # Filter to tier-1 unless caller asked for everything or a specific type
    if tier1_only and not event_type:
        events = [e for e in events if e.get("event_type") in _FEED_TIER1]

    if is_json_mode():
        output_json({"events": events, "total": len(events), "last_n_days": last_n_days})
        return

    console.print()
    if not events:
        range_label = "today" if last_n_days == 1 else f"the last {last_n_days} days"
        console.print(f"[dim]No activity found for {range_label}.[/dim]")
        return

    # Group by date
    by_day: dict[str, list[dict[str, Any]]] = {}
    for event in events:
        raw = event.get("created_at") or event.get("timestamp") or ""
        date = raw[:10] or "unknown"
        by_day.setdefault(date, []).append(event)

    sorted_days = sorted(by_day.keys(), reverse=True)

    if date_from and date_to:
        range_label = f"{date_from} → {date_to}"
    elif date_from:
        range_label = f"From {date_from}"
    elif date_to:
        range_label = f"Until {date_to}"
    elif last_n_days == 1:
        range_label = "Today"
    else:
        range_label = f"Last {last_n_days} days"
    console.print(f"[bold]{range_label} ({len(events)} events)[/bold]")
    console.print()

    for date in sorted_days:
        day_events = by_day[date]
        console.print(f"[bold cyan]{date}[/bold cyan]  [dim]{len(day_events)} events[/dim]")
        for e in day_events[:20]:
            label = _FEED_EVENT_LABELS.get(e.get("event_type", ""), e.get("event_type", ""))
            title = e.get("title") or e.get("description") or (e.get("content") or "")[:60]
            memory_ids = e.get("related_memory_ids") or []
            id_hint = f" [dim](id: {memory_ids[0]})[/dim]" if memory_ids else ""
            console.print(f"  [dim yellow][{label}][/dim yellow] {title}{id_hint}")
        if len(day_events) > 20:
            console.print(f"  [dim]... and {len(day_events) - 20} more[/dim]")
        console.print()


# ═══════════════════════════════════════════════════════════════════════════════
# Memory Commands
# ═══════════════════════════════════════════════════════════════════════════════


def cmd_memories_list(limit: int = 10, importance_min: float | None = None) -> None:
    """List memories. Only importance filter is supported by the /memories API."""
    params: dict[str, Any] = {"limit": limit, "offset": 0}
    if importance_min is not None and importance_min > 0:
        params["importance_min"] = importance_min

    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Loading...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get("/memories", params=params)
    else:
        data = api_get("/memories", params=params)

    memories = data.get("memories", [])
    pagination = data.get("pagination", {})

    result = {
        "memories": [
            {
                "id": m.get("id", ""),
                "title": m.get("title", ""),
                "content": m.get("content", ""),
                "importance": m.get("importance", 0),
                "source": m.get("source", ""),
                "created_at": m.get("created_at", ""),
            }
            for m in memories
        ],
        "total": pagination.get("total", len(memories)),
    }

    if is_json_mode():
        output_json(result)
    else:
        if not memories:
            if importance_min and importance_min > 0:
                console.print(
                    f"[dim]No memories found with importance >= {importance_min}[/dim]"
                )
            else:
                console.print("[dim]No memories found.[/dim]")
            return
        console.print()
        if importance_min and importance_min > 0:
            console.print(f"[dim]Filter: importance >= {importance_min}[/dim]")
            console.print()
        table = Table(box=box.SIMPLE, header_style="bold", show_edge=False)
        table.add_column("ID", style="dim cyan", no_wrap=True)
        table.add_column("Title", min_width=30)
        table.add_column("Imp", justify="right", width=4)
        table.add_column("Source", style="yellow", width=10)
        table.add_column("Date", style="dim", width=10)
        for m in result["memories"]:
            table.add_row(
                m["id"],
                truncate(m["title"], 35),
                format_importance(m["importance"]),
                truncate(m["source"], 10),
                format_date(m["created_at"]),
            )
        console.print(table)
        if result["total"] > len(result["memories"]):
            console.print(
                f"[dim]Showing {len(result['memories'])} of {result['total']}[/dim]"
            )
        console.print()


def cmd_memories_search(
    query: str,
    limit: int = 10,
    labels: list[str] | None = None,
    time_range: str | None = None,
    importance_min: float | None = None,
    mode: str = "normal",
    event_date_from: str | None = None,
    event_date_to: str | None = None,
    recorded_date_from: str | None = None,
    recorded_date_to: str | None = None,
) -> None:
    params: dict[str, Any] = {"q": query, "limit": limit}
    if labels:
        # Pass labels as repeated query params (labels=x&labels=y)
        params["labels"] = labels
    if time_range:
        # Use time_range directly - backend handles conversion (deprecated)
        params["time_range"] = time_range
    # Bi-temporal filters — prefer these over deprecated time_range
    if event_date_from:
        params["event_date_from"] = event_date_from
    if event_date_to:
        params["event_date_to"] = event_date_to
    if recorded_date_from:
        params["recorded_date_from"] = recorded_date_from
    if recorded_date_to:
        params["recorded_date_to"] = recorded_date_to
    if importance_min is not None and importance_min > 0:
        params["importance_min"] = importance_min
    # Map CLI mode to API mode: "normal" -> "fast", "deep" -> "deep"
    api_mode = "fast" if mode == "normal" else "deep"
    params["mode"] = api_mode

    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn(f"[cyan]Searching '{query}'...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get("/memories/search", params=params)
    else:
        data = api_get("/memories/search", params=params)

    memories = data.get("memories", [])
    meta = data.get("search_metadata", {})

    result = {
        "query": query,
        "total": meta.get("total_found", len(memories)),
        "search_mode": meta.get("search_mode", ""),
        "memories": [
            {
                "id": m.get("id", ""),
                "title": m.get("title", ""),
                "content": m.get("content", ""),
                "score": m.get("confidence", m.get("metadata", {}).get("similarity_score", 0)),
                "importance": m.get("metadata", {}).get("importance", m.get("rating", 0.5)),
                "relevance_reason": m.get("metadata", {}).get("relevance_reason"),
                "labels": m.get("label_ids", []),
                "event_start": m.get("metadata", {}).get("event_start"),
                "event_end": m.get("metadata", {}).get("event_end"),
                "temporal_context": m.get("metadata", {}).get("temporal_context"),
                "source": m.get("source", ""),
                "source_thread": m.get("source_thread"),
            }
            for m in memories
        ],
    }

    if is_json_mode():
        output_json(result)
    else:
        console.print()
        if not memories:
            filter_info = []
            if labels:
                filter_info.append(f"labels={','.join(labels)}")
            if time_range:
                filter_info.append(f"time={time_range}")
            if event_date_from or event_date_to:
                ef = f"{event_date_from or ''}..{event_date_to or ''}"
                filter_info.append(f"event={ef}")
            if recorded_date_from or recorded_date_to:
                rf = f"{recorded_date_from or ''}..{recorded_date_to or ''}"
                filter_info.append(f"recorded={rf}")
            if importance_min:
                filter_info.append(f"importance>={importance_min}")
            if filter_info:
                console.print(
                    f"[dim]No results for '{query}' with filters: {' '.join(filter_info)}[/dim]"
                )
            else:
                console.print(f"[dim]No results for '{query}'[/dim]")
            return

        # Show filter info if any
        filter_parts = []
        if labels:
            filter_parts.append(f"[magenta]{','.join(labels)}[/magenta]")
        if time_range:
            filter_parts.append(f"[cyan]{time_range}[/cyan]")
        if event_date_from or event_date_to:
            ef = f"{event_date_from or ''}..{event_date_to or ''}"
            filter_parts.append(f"[cyan]event:{ef}[/cyan]")
        if recorded_date_from or recorded_date_to:
            rf = f"{recorded_date_from or ''}..{recorded_date_to or ''}"
            filter_parts.append(f"[cyan]recorded:{rf}[/cyan]")
        if importance_min:
            filter_parts.append(f"[green]imp>={importance_min}[/green]")

        if filter_parts:
            console.print(
                f"[green]Found {result['total']} matches[/green] for [cyan]{query}[/cyan] [dim]({' '.join(filter_parts)})[/dim]"
            )
        else:
            console.print(
                f"[green]Found {result['total']} matches[/green] for [cyan]{query}[/cyan]"
            )
        console.print()
        table = Table(box=box.SIMPLE, header_style="bold", show_edge=False)
        table.add_column("ID", style="dim cyan", no_wrap=True)
        table.add_column("Title", min_width=25)
        table.add_column("Score", justify="right", width=5)
        table.add_column("Matched via", style="dim", min_width=20)
        table.add_column("Imp", justify="right", width=4)
        for m in result["memories"]:
            matched_via = m.get("relevance_reason") or ""
            # Shorten for table: "Text Match (100%) + Semantic (69%)" -> "TM100+S69"
            imp = m.get("importance", 0.5)
            imp_str = format_importance(imp) if imp is not None else ""
            table.add_row(
                m["id"],
                truncate(m["title"], 30),
                format_score(m["score"]),
                truncate(matched_via, 40),
                imp_str,
            )
        console.print(table)
        console.print()


def cmd_memories_show(memory_id: str, content_limit: int | None = None) -> None:
    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Loading...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get(f"/memories/{memory_id}")
    else:
        data = api_get(f"/memories/{memory_id}")

    # Get labels from API response (which returns label_ids like "label_python", "label_testing")
    # Extract the label name from the "label_*" prefix
    label_ids = data.get("label_ids", [])
    labels = []
    if label_ids:
        for label_id in label_ids:
            if isinstance(label_id, str) and label_id.startswith("label_"):
                label_name = label_id[6:]  # Remove "label_" prefix
                labels.append(label_name)
            else:
                labels.append(str(label_id))
    meta = data.get("metadata", {}) or {}
    result = {
        "id": data.get("id", memory_id),
        "title": data.get("title", ""),
        "content": data.get("content", ""),
        "importance": data.get("importance", 0),
        "confidence": data.get("confidence", 0),
        "source": data.get("source", ""),
        "created_at": data.get("created_at", "") or meta.get("created_at", ""),
        "labels": labels,
        "event_start": meta.get("event_start"),
        "event_end": meta.get("event_end"),
        "temporal_context": meta.get("temporal_context"),
    }

    if is_json_mode():
        output_json(result)
    else:
        console.print()
        console.print(f"[bold]{result['title'] or 'Untitled'}[/bold]")
        console.print(f"[dim]ID:[/dim] [cyan]{result['id']}[/cyan]")
        console.print(
            f"[dim]Importance:[/dim] {format_importance(result['importance'])}  [dim]Source:[/dim] [yellow]{result['source']}[/yellow]"
        )
        if labels:
            console.print(f"[dim]Labels:[/dim] [magenta]{', '.join(labels)}[/magenta]")
        if result["event_start"] or result["event_end"]:
            date_range = result["event_start"] or ""
            if result["event_end"] and result["event_end"] != result["event_start"]:
                date_range += f" → {result['event_end']}"
            ctx = result["temporal_context"]
            ctx_suffix = f"  ({ctx})" if ctx and ctx not in ("timeless",) else ""
            console.print(f"[dim]When:[/dim] [blue]{date_range}[/blue][dim]{ctx_suffix}[/dim]")
        elif result["temporal_context"] and result["temporal_context"] not in ("timeless",):
            console.print(f"[dim]When:[/dim] [blue]{result['temporal_context']}[/blue]")
        console.print()
        content = result["content"]
        if content_limit and len(content) > content_limit:
            console.print(content[:content_limit])
            console.print(f"[dim]... ({len(result['content'])} chars total)[/dim]")
        else:
            console.print(Markdown(content))
        console.print()


_VALID_UNIT_TYPES = frozenset([
    "fact", "preference", "decision", "plan",
    "procedure", "learning", "context", "event",
])


def cmd_memories_add(
    content: str,
    title: str | None = None,
    importance: float = 0.5,
    labels: list[str] | None = None,
    source: str = "cli",
    event_start: str | None = None,
    event_end: str | None = None,
    temporal_context: str | None = None,
    unit_type: str | None = None,
) -> None:
    payload: dict[str, Any] = {
        "content": content,
        "importance": importance,
        "source": source,
    }
    if title:
        payload["title"] = title
    if labels:
        payload["labels"] = labels
    if event_start:
        payload["event_start"] = event_start
    if event_end:
        payload["event_end"] = event_end
    if temporal_context:
        payload["temporal_context"] = temporal_context
    if unit_type and unit_type in _VALID_UNIT_TYPES:
        payload["unit_type"] = unit_type

    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Creating...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_post("/memories", payload)
    else:
        data = api_post("/memories", payload)

    memory_data = data.get("memory", {})
    memory_id = memory_data.get("id", data.get("memory_id", data.get("id", "")))
    # Read back stored unit_type from response (may differ if invalid type was passed)
    stored_unit_type = memory_data.get("unit_type") or unit_type or "fact"
    result: dict[str, Any] = {
        "success": True,
        "id": memory_id,
        "title": memory_data.get("title", title or ""),
        "unit_type": stored_unit_type,
    }
    if labels:
        result["labels"] = labels
    if event_start:
        result["event_start"] = event_start
    if event_end:
        result["event_end"] = event_end
    if temporal_context:
        result["temporal_context"] = temporal_context

    if is_json_mode():
        output_json(result)
    else:
        extras: list[str] = []
        if stored_unit_type and stored_unit_type != "fact":
            extras.append(f"[cyan]{stored_unit_type}[/cyan]")
        if labels:
            extras.append(f"labels: {','.join(labels)}")
        if event_start:
            extras.append(f"event: {event_start}" + (f"→{event_end}" if event_end else ""))
        label_info = f" [dim]{' · '.join(extras)}[/dim]" if extras else ""
        print_success("Created", f"{result['id']}{label_info}")


def cmd_memories_update(
    memory_id: str,
    title: str | None = None,
    content: str | None = None,
    importance: float | None = None,
) -> None:
    payload: dict[str, Any] = {}
    if title is not None:
        payload["title"] = title
    if content is not None:
        payload["content"] = content
    if importance is not None:
        payload["importance"] = importance

    if len(payload) == 0:
        if is_json_mode():
            output_json({"error": "no_updates", "message": "No updates specified"})
        else:
            console.print("[yellow]No updates specified[/yellow]")
        return

    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Updating...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_patch(f"/memories/{memory_id}", payload)
    else:
        data = api_patch(f"/memories/{memory_id}", payload)

    if is_json_mode():
        output_json({"success": True, "id": data.get("id", memory_id)})
    else:
        print_success("Updated", data.get("id", memory_id))


def cmd_memories_delete(memory_ids: list[str], force: bool = False) -> None:
    normalized_ids: list[str] = []
    seen: set[str] = set()
    for memory_id in memory_ids:
        clean_id = memory_id.strip()
        if not clean_id or clean_id in seen:
            continue
        normalized_ids.append(clean_id)
        seen.add(clean_id)

    if not normalized_ids:
        if is_json_mode():
            output_json({"error": "invalid_input", "message": "No memory IDs provided"})
        else:
            print_error("Invalid Input", "No memory IDs provided")
        return

    if not force and not is_json_mode():
        if len(normalized_ids) == 1:
            prompt = f"Delete {normalized_ids[0]}?"
        else:
            prompt = f"Delete {len(normalized_ids)} memories?"
        if not Confirm.ask(prompt):
            console.print("[dim]Cancelled[/dim]")
            return

    if len(normalized_ids) == 1:
        target_id = normalized_ids[0]
        if not is_json_mode():
            with Progress(
                SpinnerColumn(),
                TextColumn("[cyan]Deleting...[/cyan]"),
                console=console,
                transient=True,
            ) as p:
                p.add_task("", total=None)
                api_delete(f"/memories/{target_id}")
        else:
            api_delete(f"/memories/{target_id}")

        if is_json_mode():
            output_json({"success": True, "id": target_id})
        else:
            print_success("Deleted", target_id)
        return

    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Bulk deleting...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            result = api_mcp_tool_call("memory_delete", {"memory_ids": normalized_ids})
    else:
        result = api_mcp_tool_call("memory_delete", {"memory_ids": normalized_ids})

    summary = result.get("summary", {})
    deleted_count = int(summary.get("deleted_count", 0))
    failed_count = int(summary.get("failed_count", 0))

    if is_json_mode():
        output_json({
            "success": failed_count == 0,
            "bulk": True,
            "requested_ids": normalized_ids,
            **result,
        })
        return

    if failed_count == 0:
        print_success("Bulk deleted", f"{deleted_count} memories")
    else:
        print_error(
            "Bulk delete completed with failures",
            f"Deleted {deleted_count}, failed {failed_count}",
        )


# ═══════════════════════════════════════════════════════════════════════════════
# Thread Commands
# ═══════════════════════════════════════════════════════════════════════════════


def cmd_threads_list(limit: int = 10) -> None:
    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Loading...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get("/threads", params={"limit": limit, "offset": 0})
    else:
        data = api_get("/threads", params={"limit": limit, "offset": 0})

    threads = data.get("threads", [])
    pagination = data.get("pagination", {})

    result = {
        "threads": [
            {
                "id": t.get("id", ""),
                "title": t.get("title", ""),
                "messages": t.get("messages", 0),
                "source": t.get("source", ""),
                "created_at": t.get("date", t.get("created_at", "")),
            }
            for t in threads
        ],
        "total": pagination.get("total", len(threads)),
    }

    if is_json_mode():
        output_json(result)
    else:
        if not threads:
            console.print("[dim]No threads found.[/dim]")
            return
        console.print()
        table = Table(box=box.SIMPLE, header_style="bold", show_edge=False)
        table.add_column("ID", style="dim cyan", no_wrap=True)
        table.add_column("Title", min_width=35)
        table.add_column("Msgs", justify="right", width=4)
        table.add_column("Source", style="yellow", width=10)
        table.add_column("Date", style="dim", width=10)
        for t in result["threads"]:
            table.add_row(
                t["id"],
                truncate(t["title"], 40),
                str(t["messages"]),
                truncate(t["source"], 10),
                t["created_at"][:10] if t["created_at"] else "-",
            )
        console.print(table)
        if result["total"] > len(result["threads"]):
            console.print(
                f"[dim]Showing {len(result['threads'])} of {result['total']}[/dim]"
            )
        console.print()


def cmd_threads_show(
    thread_id: str,
    messages_limit: int = 10,
    content_limit: int | None = None,
    offset: int = 0,
) -> None:
    params: dict[str, Any] = {}
    if messages_limit:
        params["limit"] = messages_limit
    if offset > 0:
        params["offset"] = offset

    url = f"/threads/{quote(thread_id, safe='')}"
    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Loading...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get(url, params=params or None)
    else:
        data = api_get(url, params=params or None)

    thread = data.get("thread", {})
    messages = data.get("messages", [])
    total_messages = data.get("total_messages", len(messages))

    result = {
        "id": thread.get("thread_id", thread_id),
        "title": thread.get("title", ""),
        "source": thread.get("source", ""),
        "created_at": thread.get("created_at", ""),
        "total_messages": total_messages,
        "message_count": len(messages),
        "messages": [
            {
                "index": offset + i,
                "role": m.get("role", "unknown"),
                "content": m.get("content", ""),
            }
            for i, m in enumerate(messages)
        ],
    }

    if is_json_mode():
        output_json(result)
    else:
        console.print()
        console.print(f"[bold]{result['title'] or 'Untitled'}[/bold]")
        console.print(
            f"[dim]ID:[/dim] [cyan]{result['id']}[/cyan]  [dim]Messages:[/dim] {total_messages}  [dim]Source:[/dim] [yellow]{result['source']}[/yellow]"
        )
        console.print()
        if offset > 0:
            console.print(
                f"[dim]... {offset} earlier messages (use --offset 0 to start from beginning) ...[/dim]"
            )
            console.print()
        for m in messages:
            role = m.get("role", "unknown")
            content = m.get("content", "")
            if content_limit and len(content) > content_limit:
                content = (
                    content[:content_limit] + f"... ({len(m.get('content', ''))} chars)"
                )
            role_color = "blue" if role == "user" else "green"
            if len(content) > 300:
                console.print(f"[bold {role_color}]{role.upper()}[/bold {role_color}]")
                console.print(content)
                console.print()
            else:
                console.print(
                    f"[bold {role_color}]{role.upper()}:[/bold {role_color}] {truncate(content, 200)}"
                )
        console.print()


def cmd_threads_search(
    query: str, limit: int = 10, source: str | None = None
) -> None:
    params: dict[str, Any] = {"query": query, "limit": limit}
    if source:
        params["source"] = source
    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn(f"[cyan]Searching '{query}'...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get("/threads/search", params=params)
    else:
        data = api_get("/threads/search", params=params)

    threads = data.get("threads", [])

    # Get matches (message-level) and message count from API response
    result = {
        "query": query,
        "total": data.get("total_found", len(threads)),
        "threads": [
            {
                "id": t.get("thread_id", t.get("id", "")),
                "title": t.get("title", ""),
                "message_count": t.get("message_count", 0),
                "matches": t.get("total_matches", t.get("matched_messages_count", 0)),
                "source": t.get("source", ""),
            }
            for t in threads
        ],
    }

    if is_json_mode():
        output_json(result)
    else:
        console.print()
        if not threads:
            console.print(f"[dim]No results for '{query}'[/dim]")
            return
        console.print(
            f"[green]Found {result['total']} threads[/green] for [cyan]{query}[/cyan]"
        )
        console.print()
        table = Table(box=box.SIMPLE, header_style="bold", show_edge=False)
        table.add_column("ID", style="dim cyan", no_wrap=True)
        table.add_column("Title", min_width=35)
        table.add_column("Msgs", justify="right", width=5)
        table.add_column("Hits", justify="right", width=5)
        table.add_column("Source", style="yellow", width=10)
        for t in result["threads"]:
            table.add_row(
                t["id"],
                truncate(t["title"], 40),
                str(t["message_count"]),
                str(t["matches"]),
                truncate(t["source"], 10),
            )
        console.print(table)
        console.print()


def cmd_threads_create(
    thread_id: str | None,
    title: str,
    content: str | None = None,
    messages_json: str | None = None,
    file: str | None = None,
    source: str = "cli",
) -> None:
    """Create a new thread from content, messages JSON, or file."""
    import hashlib

    if file:
        # File-based creation
        file_path = Path(file).resolve()
        if not file_path.exists():
            if is_json_mode():
                output_json({"error": "file_not_found", "path": str(file_path)})
            else:
                print_error("File Not Found", str(file_path))
            sys.exit(1)

        payload = {"file_path": str(file_path), "format": "auto"}
        if title:
            payload["title"] = title

        if not is_json_mode():
            with Progress(
                SpinnerColumn(),
                TextColumn("[cyan]Creating from file...[/cyan]"),
                console=console,
                transient=True,
            ) as p:
                p.add_task("", total=None)
                data = api_post("/threads/from-file", payload)
        else:
            data = api_post("/threads/from-file", payload)

        result = {
            "success": data.get("success", True),
            "id": data.get("thread_id", ""),
            "title": data.get("title", title),
            "messages": data.get("message_count", 0),
        }
    else:
        # Content or messages-based creation
        messages: list[dict[str, str]] = []

        if messages_json:
            # Parse JSON messages array
            try:
                messages = json_module.loads(messages_json)
                if not isinstance(messages, list):
                    raise ValueError("Must be a JSON array")
                for i, msg in enumerate(messages):
                    if not isinstance(msg, dict):
                        raise ValueError(f"Message {i} must be an object")
                    if "role" not in msg or "content" not in msg:
                        raise ValueError(f"Message {i} missing 'role' or 'content'")
            except (json_module.JSONDecodeError, ValueError) as e:
                if is_json_mode():
                    output_json({"error": "invalid_messages", "message": str(e)})
                else:
                    print_error(
                        "Invalid Messages JSON",
                        str(e),
                        'Format: [{"role":"user","content":"..."},{"role":"assistant","content":"..."}]',
                    )
                sys.exit(1)
        elif content:
            # Single content becomes a user message
            messages = [{"role": "user", "content": content}]
        else:
            if is_json_mode():
                output_json(
                    {
                        "error": "missing_content",
                        "message": "Provide --content, --messages, or --file",
                    }
                )
            else:
                print_error(
                    "Missing Content", "Provide --content, --messages, or --file"
                )
            sys.exit(1)

        # Generate thread_id from title and timestamp unless explicitly provided
        normalized_thread_id = (thread_id or "").strip()
        if normalized_thread_id:
            generated_thread_id = normalized_thread_id
        else:
            ts = datetime.now().strftime("%Y%m%d%H%M%S")
            title_hash = hashlib.md5(title.encode()).hexdigest()[:6]
            generated_thread_id = f"cli-{ts}-{title_hash}"

        payload = {
            "thread_id": generated_thread_id,
            "title": title,
            "messages": messages,
            "source": source,
        }

        if not is_json_mode():
            with Progress(
                SpinnerColumn(),
                TextColumn("[cyan]Creating...[/cyan]"),
                console=console,
                transient=True,
            ) as p:
                p.add_task("", total=None)
                data = api_post("/threads", payload)
        else:
            data = api_post("/threads", payload)

        # Response has thread object with thread_id
        thread_data = data.get("thread", {})
        result = {
            "success": True,
            "id": thread_data.get("thread_id", generated_thread_id),
            "title": thread_data.get("title", title),
            "messages": len(data.get("messages", [])),
        }

    if is_json_mode():
        output_json(result)
    else:
        print_success("Created", f"{result['id']} ({result['messages']} messages)")


def cmd_threads_delete(
    thread_id: str, force: bool = False, cascade: bool = False
) -> None:
    if not force and not is_json_mode():
        msg = f"Delete {thread_id}?" + (" (with memories)" if cascade else "")
        if not Confirm.ask(msg):
            console.print("[dim]Cancelled[/dim]")
            return

    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Deleting...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_delete(
                f"/threads/{quote(thread_id, safe='')}", params={"cascade_delete_memories": cascade}
            )
    else:
        data = api_delete(
            f"/threads/{quote(thread_id, safe='')}", params={"cascade_delete_memories": cascade}
        )

    result = {
        "success": True,
        "id": thread_id,
        "deleted_messages": data.get("deleted_messages", 0),
        "deleted_memories": data.get("deleted_memories", 0) if cascade else 0,
    }

    if is_json_mode():
        output_json(result)
    else:
        print_success("Deleted", thread_id)


def cmd_threads_append(
    thread_id: str,
    messages_json: str | None = None,
    content: str | None = None,
    role: str = "user",
    file: str | None = None,
    format: str = "auto",
    deduplicate: bool = True,
    idempotency_key: str | None = None,
) -> None:
    """Append messages to an existing thread."""
    payload: dict[str, Any] = {"deduplicate": deduplicate}
    if idempotency_key:
        payload["idempotency_key"] = idempotency_key

    if file:
        file_path = Path(file).resolve()
        if not file_path.exists():
            if is_json_mode():
                output_json({"error": "file_not_found", "path": str(file_path)})
            else:
                print_error("File Not Found", str(file_path))
            sys.exit(1)
        payload["file_path"] = str(file_path)
        payload["format"] = format
    else:
        messages: list[dict[str, str]] = []
        if messages_json:
            try:
                parsed = json_module.loads(messages_json)
                if not isinstance(parsed, list):
                    raise ValueError("Must be a JSON array")
                for i, msg in enumerate(parsed):
                    if not isinstance(msg, dict):
                        raise ValueError(f"Message {i} must be an object")
                    if "role" not in msg or "content" not in msg:
                        raise ValueError(f"Message {i} missing 'role' or 'content'")
                messages = parsed
            except (json_module.JSONDecodeError, ValueError) as e:
                if is_json_mode():
                    output_json({"error": "invalid_messages", "message": str(e)})
                else:
                    print_error(
                        "Invalid Messages JSON",
                        str(e),
                        'Format: [{"role":"user","content":"..."},{"role":"assistant","content":"..."}]',
                    )
                sys.exit(1)
        elif content:
            messages = [{"role": role, "content": content}]
        else:
            if is_json_mode():
                output_json(
                    {
                        "error": "missing_content",
                        "message": "Provide --messages, --content, or --file",
                    }
                )
            else:
                print_error(
                    "Missing Content", "Provide --messages, --content, or --file"
                )
            sys.exit(1)

        payload["messages"] = messages

    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Appending...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_post(f"/threads/{quote(thread_id, safe='')}/append", payload)
    else:
        data = api_post(f"/threads/{quote(thread_id, safe='')}/append", payload)

    result = {
        "success": data.get("success", True),
        "id": thread_id,
        "messages_added": data.get("messages_added", 0),
        "total_messages": data.get("total_messages", 0),
        "deduplicate": deduplicate,
    }

    if is_json_mode():
        output_json(result)
    else:
        print_success(
            "Appended",
            f"{result['messages_added']} added, total {result['total_messages']}",
        )


def cmd_threads_save(
    client: str,
    project_path: str,
    mode: str = "current",
    session_id: str | None = None,
    summary: str | None = None,
    truncate: bool = False,
) -> None:
    """Save coding session(s) as conversation thread(s).

    Supports Claude Code and Codex. Auto-detects sessions from project path.
    """
    # Validate client
    if client not in ["claude-code", "codex"]:
        if is_json_mode():
            output_json(
                {"error": "invalid_client", "message": f"Must be claude-code or codex"}
            )
        else:
            print_error(
                "Invalid Client",
                f"'{client}' is not supported",
                "Use 'claude-code' or 'codex'",
            )
        sys.exit(1)

    # Resolve project path
    resolved_path = Path(project_path).resolve()
    if not resolved_path.exists():
        if is_json_mode():
            output_json({"error": "path_not_found", "path": str(resolved_path)})
        else:
            print_error("Path Not Found", str(resolved_path))
        sys.exit(1)

    payload = {
        "client": client,
        "project_path": str(resolved_path),
        "persist_mode": mode,
        "truncate_large_content": truncate,
    }
    if session_id:
        payload["session_id"] = session_id
    if summary:
        payload["summary"] = summary

    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn(f"[cyan]Saving {client} session...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_post("/threads/sessions/save", payload)
    else:
        data = api_post("/threads/sessions/save", payload)

    if data.get("status") == "error":
        if is_json_mode():
            output_json(data)
        else:
            print_error(
                "Save Failed",
                data.get("error", "Unknown error"),
                data.get("hint"),
            )
        sys.exit(1)

    if is_json_mode():
        output_json(data)
    else:
        results = data.get("results", [])
        if len(results) == 1:
            r = results[0]
            action = r["action"]
            if action == "created":
                print_success(
                    "Created",
                    f"{r['thread_id']} ({r['message_count']} messages)",
                )
            else:
                print_success(
                    "Updated",
                    f"{r['thread_id']} (+{r['messages_added']} messages)",
                )
        else:
            created = sum(1 for r in results if r["action"] == "created")
            appended = sum(1 for r in results if r["action"] == "appended")
            console.print(
                f"[green]ok[/green] Processed {len(results)} sessions: "
                f"{created} created, {appended} updated"
            )


# ═══════════════════════════════════════════════════════════════════════════════
# Thread Triage & Distillation Commands
# ═══════════════════════════════════════════════════════════════════════════════


def _resolve_triage_content(
    thread_id: str | None,
    content: str | None,
    file: str | None,
) -> str:
    """Resolve conversation content from one of three sources."""
    if content:
        return content

    if file:
        file_path = Path(file).resolve()
        if not file_path.exists():
            if is_json_mode():
                output_json({"error": "file_not_found", "path": str(file_path)})
            else:
                print_error("File Not Found", str(file_path))
            sys.exit(1)
        return file_path.read_text(encoding="utf-8")

    if thread_id:
        data = api_get(f"/threads/{thread_id}")
        messages = data.get("messages", [])
        if not messages:
            if is_json_mode():
                output_json({"error": "empty_thread", "thread_id": thread_id})
            else:
                print_error("Empty Thread", f"No messages in {thread_id}")
            sys.exit(1)
        parts = []
        for msg in messages:
            role = msg.get("role", "unknown")
            text = msg.get("content", "")
            parts.append(f"{role}: {text}")
        return "\n\n".join(parts)

    if is_json_mode():
        output_json(
            {
                "error": "missing_content",
                "message": "Provide thread_id, --content, or --file",
            }
        )
    else:
        print_error(
            "Missing Content",
            "Provide a thread ID, --content, or --file",
        )
    sys.exit(1)


def cmd_threads_triage(
    thread_id: str | None = None,
    content: str | None = None,
    file: str | None = None,
) -> None:
    """Triage a conversation to decide if it's worth distilling."""
    conversation = _resolve_triage_content(thread_id, content, file)

    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Triaging conversation...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_post("/memories/distill/triage", {"thread_content": conversation})
    else:
        data = api_post("/memories/distill/triage", {"thread_content": conversation})

    if is_json_mode():
        output_json(data)
    else:
        should = data.get("should_distill", False)
        reason = data.get("reason", "")
        if should:
            console.print(f"[green]Worth distilling[/green] — {reason}")
        else:
            console.print(f"[dim]Not worth distilling[/dim] — {reason}")


def cmd_threads_distill(
    thread_id: str,
    distillation_type: str = "simple_llm",
    extraction_level: str = "swift",
    run_triage: bool = False,
) -> None:
    """Distill a thread into structured memories."""
    # Fetch thread content
    thread_data = api_get(f"/threads/{thread_id}")
    messages = thread_data.get("messages", [])
    title = thread_data.get("title", "")

    if not messages:
        if is_json_mode():
            output_json({"error": "empty_thread", "thread_id": thread_id})
        else:
            print_error("Empty Thread", f"No messages in {thread_id}")
        sys.exit(1)

    parts = []
    for msg in messages:
        role = msg.get("role", "unknown")
        text = msg.get("content", "")
        parts.append(f"{role}: {text}")
    conversation = "\n\n".join(parts)

    # Optional triage gate
    if run_triage:
        if not is_json_mode():
            with Progress(
                SpinnerColumn(),
                TextColumn("[cyan]Triaging...[/cyan]"),
                console=console,
                transient=True,
            ) as p:
                p.add_task("", total=None)
                triage = api_post(
                    "/memories/distill/triage", {"thread_content": conversation}
                )
        else:
            triage = api_post(
                "/memories/distill/triage", {"thread_content": conversation}
            )

        if not triage.get("should_distill", False):
            reason = triage.get("reason", "")
            if is_json_mode():
                output_json(
                    {"skipped": True, "reason": reason, "thread_id": thread_id}
                )
            else:
                console.print(f"[dim]Skipped[/dim] — {reason}")
            return

        if not is_json_mode():
            console.print(
                f"[green]Triage passed[/green] — {triage.get('reason', '')}"
            )

    # Run distillation (120s timeout — LLM processing can be slow)
    payload = {
        "thread_id": thread_id,
        "thread_title": title,
        "thread_content": conversation,
        "distillation_type": distillation_type,
        "extraction_level": extraction_level,
    }

    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Distilling thread...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_post("/memories/distill", payload, timeout=120.0)
    else:
        data = api_post("/memories/distill", payload, timeout=120.0)

    if is_json_mode():
        output_json(data)
    else:
        memory = data.get("memory", {})
        memories_created = data.get("memories_created", 1)
        memory_id = memory.get("id", "?")
        memory_title = memory.get("title", "Untitled")
        print_success(
            "Distilled",
            f"{memories_created} memories from {thread_id}",
        )
        console.print(f"  [dim]Primary:[/dim] {memory_id} — {memory_title}")


# ═══════════════════════════════════════════════════════════════════════════════
# Working Memory Commands
# ═══════════════════════════════════════════════════════════════════════════════


def cmd_wm_read(date: str | None = None) -> None:
    """Read Working Memory (today or archived)."""
    params: dict[str, Any] = {}
    if date:
        params["date"] = date

    if not is_json_mode():
        label = f"Loading WM for {date}..." if date else "Loading Working Memory..."
        with Progress(
            SpinnerColumn(),
            TextColumn(f"[cyan]{label}[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get("/agent/working-memory", params=params)
    else:
        data = api_get("/agent/working-memory", params=params)

    if is_json_mode():
        output_json(data)
    else:
        if not data.get("exists"):
            target = date or "today"
            console.print(f"[dim]No Working Memory for {target}.[/dim]")
            return
        console.print()
        console.print(f"[bold]Working Memory[/bold] [dim]({data.get('date', '')})[/dim]")
        console.print()
        console.print(Markdown(data.get("content", "")))
        console.print()


def cmd_wm_edit(message: str | None = None) -> None:
    """Edit Working Memory — set from -m or open $EDITOR."""
    if message:
        content = message
    else:
        # Fetch current content, open in $EDITOR
        data = api_get("/agent/working-memory")
        current = data.get("content", "") if data.get("exists") else _wm_template()

        import subprocess
        import tempfile

        editor = os.environ.get("EDITOR", os.environ.get("VISUAL", "nano"))
        with tempfile.NamedTemporaryFile(
            suffix=".md", mode="w", delete=False, encoding="utf-8"
        ) as f:
            f.write(current)
            tmp_path = f.name

        try:
            result = subprocess.run([editor, tmp_path])
            if result.returncode != 0:
                print_error("Editor Error", f"Editor exited with code {result.returncode}")
                return
            content = Path(tmp_path).read_text(encoding="utf-8")
        finally:
            Path(tmp_path).unlink(missing_ok=True)

        if content.strip() == current.strip():
            if not is_json_mode():
                console.print("[dim]No changes made.[/dim]")
            return

    data = api_put("/agent/working-memory", {"content": content})

    if is_json_mode():
        output_json(data)
    else:
        if data.get("success"):
            print_success(
                "Working Memory updated",
                f"{data.get('size_bytes', 0)} bytes, "
                f"{data.get('focus_areas', 0)} focus areas, "
                f"{data.get('flags', 0)} flags",
            )
        else:
            print_error("Update Failed", str(data))


def _wm_patch_content(
    current: str,
    heading: str,
    new_content: str | None,
    append_text: str | None,
) -> str:
    """Apply a section-level patch to Working Memory markdown.

    Finds the first heading line that contains `heading` (case-insensitive),
    then replaces or appends to the block between that heading and the next
    same-or-higher-level heading (or end of file).

    Returns the updated document as a string.
    Raises ValueError if the heading is not found.
    """
    import re

    lines = current.splitlines(keepends=True)
    heading_lc = heading.strip().lower()

    # Determine heading level from search string (e.g. "## " → level 2)
    level_match = re.match(r"^(#{1,6})\s", heading.strip())
    target_level = len(level_match.group(1)) if level_match else 2

    # Find the start line of the target section
    start_idx: int | None = None
    for i, line in enumerate(lines):
        if heading_lc in line.strip().lower():
            start_idx = i
            break

    if start_idx is None:
        raise ValueError(
            f"Heading not found: '{heading}'. "
            f"Available headings: {_wm_list_headings(current)}"
        )

    # Find where this section ends (next heading of same or higher level)
    end_idx = len(lines)
    for i in range(start_idx + 1, len(lines)):
        m = re.match(r"^(#{1,6})\s", lines[i])
        if m and len(m.group(1)) <= target_level:
            end_idx = i
            break

    # Extract existing section body (between the heading line and end_idx)
    heading_line = lines[start_idx]
    body_lines = lines[start_idx + 1 : end_idx]

    if append_text is not None:
        # Append to existing body — preserve existing content
        existing_body = "".join(body_lines).rstrip("\n")
        new_body = f"{existing_body}\n{append_text.strip()}\n"
    else:
        # Full section replacement
        new_body = (new_content or "").rstrip("\n") + "\n"

    new_section = heading_line + new_body
    updated_lines = lines[:start_idx] + [new_section] + lines[end_idx:]
    return "".join(updated_lines)


def _wm_list_headings(content: str) -> list[str]:
    """Return all heading lines from a markdown document."""
    import re
    return [
        line.strip()
        for line in content.splitlines()
        if re.match(r"^#{1,6}\s", line)
    ]


def cmd_wm_patch(
    heading: str,
    new_content: str | None = None,
    append_text: str | None = None,
) -> None:
    """Patch a single section of Working Memory without touching the rest.

    Reads the current WM, updates just the requested section, then writes back.
    This is a client-side read-modify-write since the API only supports full overwrite.
    """
    if not heading:
        print_error("Missing argument", "Provide --heading to identify the section to patch.")
        return
    if new_content is None and append_text is None:
        print_error("Missing argument", "Provide --content (replace) or --append (add text).")
        return

    data = api_get("/agent/working-memory")
    if not data.get("exists"):
        print_error("Not found", "Working Memory does not exist yet.")
        return

    current = data.get("content", "")
    try:
        updated = _wm_patch_content(current, heading, new_content, append_text)
    except ValueError as e:
        print_error("Heading not found", str(e))
        return

    if updated.strip() == current.strip():
        if not is_json_mode():
            console.print("[dim]No changes — content is identical.[/dim]")
        return

    result = api_put("/agent/working-memory", {"content": updated})

    if is_json_mode():
        output_json(result)
    elif result.get("success"):
        print_success(
            f"Section updated: {heading}",
            f"{'Appended' if append_text else 'Replaced'} content, "
            f"{result.get('size_bytes', 0)} bytes total",
        )
    else:
        print_error("Update Failed", str(result))


def cmd_wm_history(limit: int = 30) -> None:
    """List archived Working Memory dates."""
    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Loading history...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get("/agent/working-memory/history", params={"limit": limit})
    else:
        data = api_get("/agent/working-memory/history", params={"limit": limit})

    if is_json_mode():
        output_json(data)
    else:
        dates = data.get("dates", [])
        if not dates:
            console.print("[dim]No Working Memory history found.[/dim]")
            return

        console.print()
        console.print("[bold]Working Memory History[/bold]")
        console.print()
        table = Table(box=box.SIMPLE, header_style="bold", show_edge=False)
        table.add_column("Date", style="cyan", no_wrap=True)
        table.add_column("Size", justify="right", width=10)
        table.add_column("", width=8)
        for entry in dates:
            size_kb = entry.get("size_bytes", 0) / 1024
            label = "[green]current[/green]" if entry.get("current") else ""
            table.add_row(
                entry["date"],
                f"{size_kb:.1f} KB",
                label,
            )
        console.print(table)
        console.print(f"[dim]{len(dates)} entries[/dim]")
        console.print()


def _wm_template() -> str:
    """Default template for new Working Memory."""
    return """## Focus Areas

-

## Briefing

"""


# ═══════════════════════════════════════════════════════════════════════════════
# Source Commands
# ═══════════════════════════════════════════════════════════════════════════════


def cmd_sources_list(
    limit: int = 20,
    source_type: str | None = None,
    lifecycle_state: str | None = None,
) -> None:
    params: dict[str, Any] = {"limit": limit, "offset": 0}
    if source_type:
        params["source_type"] = source_type
    if lifecycle_state:
        params["lifecycle_state"] = lifecycle_state

    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Loading...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get("/sources", params=params)
    else:
        data = api_get("/sources", params=params)

    sources = data.get("sources", [])

    if is_json_mode():
        output_json(data)
        return

    if not sources:
        console.print("[dim]No sources in library[/dim]")
        return

    table = Table(show_header=True, header_style="bold", box=None, pad_edge=False)
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Name")
    table.add_column("Type", style="dim")
    table.add_column("State")
    table.add_column("Chunks", justify="right")
    table.add_column("Memories", justify="right")

    for s in sources:
        state = s.get("lifecycle_state", "")
        state_style = "green" if state == "indexed" else "yellow" if state == "error" else ""
        table.add_row(
            s.get("id", ""),
            s.get("original_name", ""),
            s.get("source_type", ""),
            f"[{state_style}]{state}[/{state_style}]" if state_style else state,
            str(s.get("chunk_count", "")),
            str(s.get("memory_count", "")),
        )

    console.print(table)
    total = data.get("total", len(sources))
    if total > len(sources):
        console.print(f"\n[dim]Showing {len(sources)} of {total}[/dim]")


def cmd_sources_show(source_id: str) -> None:
    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Loading...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get(f"/sources/{source_id}")
    else:
        data = api_get(f"/sources/{source_id}")

    if is_json_mode():
        output_json(data)
        return

    console.print(f"\n[bold]{data.get('original_name', source_id)}[/bold]")
    console.print(f"  [dim]ID[/dim]        {data.get('id', '')}")
    console.print(f"  [dim]Type[/dim]      {data.get('source_type', '')}")
    console.print(f"  [dim]MIME[/dim]      {data.get('mime_type', '')}")
    console.print(f"  [dim]State[/dim]     {data.get('lifecycle_state', '')}")
    console.print(f"  [dim]Version[/dim]   {data.get('version', '')}")
    console.print(f"  [dim]Chunks[/dim]    {data.get('chunk_count', '')}")
    console.print(f"  [dim]Memories[/dim]  {data.get('memory_count', '')}")

    size = data.get("size_bytes")
    if size:
        if size > 1_000_000:
            console.print(f"  [dim]Size[/dim]      {size / 1_000_000:.1f} MB")
        elif size > 1_000:
            console.print(f"  [dim]Size[/dim]      {size / 1_000:.1f} KB")
        else:
            console.print(f"  [dim]Size[/dim]      {size} bytes")

    url = data.get("source_url")
    if url:
        console.print(f"  [dim]URL[/dim]       {url}")

    summary = data.get("summary", "")
    if summary:
        if len(summary) > 500:
            summary = summary[:500] + "..."
        console.print(f"\n[bold]Summary[/bold]\n{summary}")

    # Related memories
    memories = data.get("memories", [])
    if memories:
        console.print(f"\n[bold]Related Memories[/bold] ({len(memories)})")
        for m in memories[:10]:
            title = m.get("title") or m.get("content", "")[:60]
            console.print(f"  {m.get('id', '')}  {title}")
        if len(memories) > 10:
            console.print(f"  [dim]... and {len(memories) - 10} more[/dim]")
    console.print()


def cmd_sources_delete(source_ids: list[str], force: bool = False) -> None:
    normalized_ids: list[str] = []
    seen: set[str] = set()
    for sid in source_ids:
        clean_id = sid.strip()
        if not clean_id or clean_id in seen:
            continue
        normalized_ids.append(clean_id)
        seen.add(clean_id)

    if not normalized_ids:
        if is_json_mode():
            output_json({"error": "invalid_input", "message": "No source IDs provided"})
        else:
            print_error("Invalid Input", "No source IDs provided")
        return

    if not force and not is_json_mode():
        if len(normalized_ids) == 1:
            prompt = f"Delete source {normalized_ids[0]}? This removes all files, chunks, and graph links."
        else:
            prompt = f"Delete {len(normalized_ids)} sources? This removes all files, chunks, and graph links."
        if not Confirm.ask(prompt):
            console.print("[dim]Cancelled[/dim]")
            return

    deleted = 0
    failed = 0
    for target_id in normalized_ids:
        try:
            if not is_json_mode() and len(normalized_ids) == 1:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[cyan]Deleting...[/cyan]"),
                    console=console,
                    transient=True,
                ) as p:
                    p.add_task("", total=None)
                    api_delete(f"/sources/{target_id}")
            else:
                api_delete(f"/sources/{target_id}")
            deleted += 1
        except SystemExit:
            failed += 1

    if is_json_mode():
        output_json({
            "success": failed == 0,
            "deleted": deleted,
            "failed": failed,
            "requested_ids": normalized_ids,
        })
        return

    if len(normalized_ids) == 1:
        if failed == 0:
            print_success("Deleted", normalized_ids[0])
        # api_delete already prints error on failure
    else:
        if failed == 0:
            print_success("Deleted", f"{deleted} sources")
        else:
            print_error(
                "Bulk delete completed with failures",
                f"Deleted {deleted}, failed {failed}",
            )


# ═══════════════════════════════════════════════════════════════════════════════
# Serve Command
# ═══════════════════════════════════════════════════════════════════════════════

# Database names in order of preference (newest engine version first)
_DB_NAMES = ("nowledge_graph_v2.db", "nowledge_graph_v1.db", "nowledge_graph.db")


def _find_legacy_database(xdg_dir: Path) -> Optional[Path]:
    """Search common locations for databases created by older headless versions.

    Older ``nmem serve`` stored data in ``./data/`` relative to the working
    directory.  When the user switches from a manual run to a systemd service
    (or simply ``cd``s elsewhere), the CWD changes and the data "disappears."

    We probe the directories where data is most likely to end up:

    1. ``./data/``  — current working directory (same-CWD upgrade)
    2. ``~/data/``  — home directory (most common manual run, and the new
       systemd ``WorkingDirectory`` default)
    3. ``/data/``   — filesystem root (systemd *system* service default when
       the old unit file had no ``WorkingDirectory``)

    Returns the *resolved* path to the first database found, or ``None``.
    """
    seen: set[str] = set()
    search_dirs: list[Path] = []

    for candidate_dir in [Path.cwd() / "data", Path.home() / "data", Path("/data")]:
        resolved = str(candidate_dir.resolve())
        if resolved not in seen:
            seen.add(resolved)
            search_dirs.append(candidate_dir)

    # Also check if the XDG parent itself has a stray database (shouldn't
    # happen, but belt-and-suspenders).
    xdg_resolved = str(xdg_dir.resolve())
    if xdg_resolved not in seen:
        seen.add(xdg_resolved)
        search_dirs.append(xdg_dir)

    for search_dir in search_dirs:
        for name in _DB_NAMES:
            candidate = search_dir / name
            try:
                if candidate.exists():
                    return candidate.resolve()
            except (PermissionError, OSError):
                # /data/ may not be readable, or path may be broken — skip
                continue

    return None


def _print_legacy_migration_warning(legacy_path: Path, xdg_dir: Path) -> None:
    """Print a prominent migration warning with copy-paste commands."""
    data_dir = legacy_path.parent
    console.print()
    console.print("[bold yellow]Database found at a legacy location[/bold yellow]")
    console.print(f"  Current:  {legacy_path}")
    console.print(f"  Standard: {xdg_dir}/")
    console.print()
    console.print("  The server will use the legacy location for now to keep your data safe.")
    console.print("  To migrate, stop the server and run:")
    console.print()
    console.print(f"    [bold]mkdir -p {xdg_dir}[/bold]")
    console.print(f"    [bold]mv {data_dir}/nowledge_graph*.db* {xdg_dir}/[/bold]")
    # Move companion files if present (search index, version metadata)
    if (data_dir / "search_index").exists():
        console.print(f"    [bold]mv {data_dir}/search_index {xdg_dir}/[/bold]")
    if (data_dir / "db_version.json").exists():
        console.print(f"    [bold]mv {data_dir}/db_version.json {xdg_dir}/[/bold]")
    console.print()


def cmd_serve(host: str = "0.0.0.0", port: int = 14242) -> None:
    """Start the Nowledge Mem server in the foreground (Ctrl+C to stop).

    This runs the server directly in the current terminal session.
    For production deployments, use 'nmem service install' to set up
    a systemd service that runs in the background and starts on boot.
    """
    try:
        import uvicorn
    except ImportError:
        print_error(
            "Server Not Available",
            "uvicorn is not installed.",
            "Run from the bundled Nowledge Mem installation, or install uvicorn manually.",
        )
        sys.exit(1)

    # ── Database path resolution ──────────────────────────────────────
    # Without explicit resolution, config.py falls back to ./data/nowledge_graph.db
    # (relative to CWD). This caused data loss for headless users:
    #
    #   1. User runs `nmem serve` from /home/user → data at /home/user/data/
    #   2. User runs `nmem service install` → systemd starts from / → empty DB at /data/
    #   3. User's memories appear to vanish.
    #
    # Resolution order:
    #   1. NOWLEDGE_DB_PATH env var (explicit override — always wins)
    #   2. Standard XDG location (~/.local/share/NowledgeGraph/) — checks v2/v1/v0
    #   3. Legacy ./data/ search — checks CWD, ~, / for old headless databases
    #   4. Fresh install default → standard XDG location
    #
    # When legacy data is found, we USE it (to prevent data loss) and print
    # migration instructions to move it to the standard location.
    db_path_display = os.environ.get("NOWLEDGE_DB_PATH")
    if not db_path_display:
        try:
            from nowledge_graph_server.database.version_upgrade.db_version_manager import (
                get_db_path,
                _get_app_data_dir,
            )

            xdg_dir = _get_app_data_dir()
            xdg_path = get_db_path()  # Checks XDG for v2/v1/v0
            xdg_has_data = xdg_path.exists()

            if xdg_has_data:
                # Standard location has data — use it directly.
                db_path = xdg_path
            else:
                # No data at standard location. Search legacy locations where
                # older headless versions may have created ./data/ databases.
                # Check CWD, home dir, and root (systemd system service default).
                legacy_path = _find_legacy_database(xdg_dir)

                if legacy_path:
                    db_path = legacy_path
                    _print_legacy_migration_warning(legacy_path, xdg_dir)
                else:
                    # Nothing found anywhere — fresh install or data at an
                    # unknown location.  Create at the standard XDG path.
                    db_path = xdg_path
                    # Ensure the directory exists for new installs
                    xdg_dir.mkdir(parents=True, exist_ok=True)

            os.environ["NOWLEDGE_DB_PATH"] = str(db_path)
            db_path_display = str(db_path)
        except Exception as e:
            # Fallback: force the standard XDG location even if we couldn't auto-detect.
            # This is safer than letting config.py use its ./data/ relative default,
            # which caused data loss when the CWD changed between runs.
            fallback_dir = Path(
                os.environ.get("XDG_DATA_HOME", os.path.expanduser("~/.local/share"))
            ) / "NowledgeGraph"
            fallback_path = fallback_dir / "nowledge_graph_v2.db"
            os.environ["NOWLEDGE_DB_PATH"] = str(fallback_path)
            db_path_display = str(fallback_path)
            console.print(
                f"[yellow]Warning: Database auto-detection failed ({e}). "
                f"Using {fallback_path}[/yellow]"
            )

    console.print()
    console.print("[bold]Starting Nowledge Mem server (foreground)[/bold]")
    console.print(f"  host   {host}")
    console.print(f"  port   {port}")
    if db_path_display:
        console.print(f"  data   {db_path_display}")
    console.print(
        f"  docs   http://{'127.0.0.1' if host == '0.0.0.0' else host}:{port}/docs"
    )
    console.print()
    # If the resolved path doesn't exist yet, hint about upgrade recovery
    if db_path_display and not Path(db_path_display).exists():
        console.print(
            "[dim]First run — creating a new database. If you are upgrading and expected[/dim]"
        )
        console.print(
            "[dim]existing data, see: https://nowledge.com/docs/server-deployment#missing-data-after-upgrade[/dim]"
        )
        console.print()
    console.print("[dim]Press Ctrl+C to stop. For background service: nmem service install[/dim]")
    console.print()

    uvicorn.run(
        "nowledge_graph_server.fastapi_server:app",
        host=host,
        port=port,
    )


# ═══════════════════════════════════════════════════════════════════════════════
# Service Commands (systemd lifecycle — Linux only)
# ═══════════════════════════════════════════════════════════════════════════════

_SYSTEMD_UNIT = "nmem"
_SYSTEM_UNIT_DIR = Path("/etc/systemd/system")
_USER_UNIT_DIR = Path.home() / ".config" / "systemd" / "user"


def _nmem_exe_path() -> str:
    """Find the nmem executable path for the systemd unit file."""
    # Check the symlink first (DEB install)
    if Path("/usr/local/bin/nmem").exists():
        return "/usr/local/bin/nmem"
    # Fallback: wherever we're running from
    return shutil.which("nmem") or "/usr/local/bin/nmem"


def _generate_unit_content(host: str, port: int) -> str:
    """Generate a systemd unit file.

    WorkingDirectory is set to the user's home to ensure consistent behavior.
    Without it, systemd defaults to / for system services and ~ for user services,
    which caused data loss when users switched from manual `nmem serve` to systemd
    (the CWD-relative ./data/ path resolved to a different location).
    """
    exe = _nmem_exe_path()
    home = Path.home()
    return f"""\
[Unit]
Description=Nowledge Mem Server
After=network.target

[Service]
Type=simple
ExecStart={exe} serve --host {host} --port {port}
WorkingDirectory={home}
Restart=on-failure
RestartSec=5
Environment=NMEM_API_URL=http://127.0.0.1:{port}

StandardOutput=journal
StandardError=journal
SyslogIdentifier=nmem

[Install]
WantedBy=default.target
"""


def _run_systemctl(args: list[str], user: bool = False, check: bool = True) -> subprocess.CompletedProcess:
    """Run a systemctl command."""
    cmd = ["systemctl"]
    if user:
        cmd.append("--user")
    cmd.extend(args)
    return subprocess.run(cmd, capture_output=True, text=True, check=check)


def cmd_service_install(host: str, port: int, user: bool) -> None:
    """Install and enable the nmem systemd service."""
    unit_content = _generate_unit_content(host, port)

    if user:
        unit_dir = _USER_UNIT_DIR
        scope = "user"
    else:
        unit_dir = _SYSTEM_UNIT_DIR
        scope = "system"

    unit_file = unit_dir / f"{_SYSTEMD_UNIT}.service"

    # Check permissions
    if not user and os.geteuid() != 0:
        print_error(
            "Root Required",
            "System-wide service installation requires root.",
            "Run with sudo, or use --user for a user-level service.",
        )
        sys.exit(1)

    unit_dir.mkdir(parents=True, exist_ok=True)
    unit_file.write_text(unit_content)

    # Reload, enable, and start
    _run_systemctl(["daemon-reload"], user=user)
    _run_systemctl(["enable", f"{_SYSTEMD_UNIT}.service"], user=user)
    _run_systemctl(["start", f"{_SYSTEMD_UNIT}.service"], user=user)

    print_success(
        "Service installed",
        f"Unit file: {unit_file}\n"
        f"  Scope:     {scope}\n"
        f"  Binding:   {host}:{port}\n"
        f"  Status:    nmem service status" + (" --user" if user else ""),
    )


def cmd_service_uninstall(user: bool) -> None:
    """Stop, disable, and remove the nmem systemd service."""
    if not user and os.geteuid() != 0:
        print_error(
            "Root Required",
            "System-wide service removal requires root.",
            "Run with sudo, or use --user for a user-level service.",
        )
        sys.exit(1)

    unit_dir = _USER_UNIT_DIR if user else _SYSTEM_UNIT_DIR
    unit_file = unit_dir / f"{_SYSTEMD_UNIT}.service"

    if not unit_file.exists():
        scope = "user" if user else "system"
        print_error("Not Installed", f"No {scope} service found at {unit_file}")
        sys.exit(1)

    _run_systemctl(["stop", f"{_SYSTEMD_UNIT}.service"], user=user, check=False)
    _run_systemctl(["disable", f"{_SYSTEMD_UNIT}.service"], user=user, check=False)
    unit_file.unlink()
    _run_systemctl(["daemon-reload"], user=user)

    print_success("Service uninstalled", f"Removed {unit_file}")


def cmd_service_status(user: bool) -> None:
    """Show nmem systemd service status."""
    result = _run_systemctl(
        ["status", f"{_SYSTEMD_UNIT}.service"], user=user, check=False,
    )
    if result.returncode == 4:
        # Unit not found
        scope = "user" if user else "system"
        print_error(
            "Not Installed",
            f"No {scope} service found.",
            "Run 'nmem service install' to set up the service.",
        )
        sys.exit(1)
    # Print raw systemctl output (it's already well-formatted)
    console.print(result.stdout)
    if result.stderr:
        console.print(f"[dim]{result.stderr}[/dim]")


def cmd_service_start(user: bool) -> None:
    """Start the nmem systemd service."""
    result = _run_systemctl(["start", f"{_SYSTEMD_UNIT}.service"], user=user, check=False)
    if result.returncode != 0:
        msg = result.stderr.strip() or result.stdout.strip() or "Unknown error"
        print_error("Failed to start service", msg, "Is the service installed? Run 'nmem service install' first.")
        sys.exit(1)
    print_success("Service started")


def cmd_service_stop(user: bool) -> None:
    """Stop the nmem systemd service."""
    result = _run_systemctl(["stop", f"{_SYSTEMD_UNIT}.service"], user=user, check=False)
    if result.returncode != 0:
        msg = result.stderr.strip() or result.stdout.strip() or "Unknown error"
        print_error("Failed to stop service", msg)
        sys.exit(1)
    print_success("Service stopped")


def cmd_service_logs(user: bool, follow: bool, lines: int) -> None:
    """Show nmem service logs via journalctl."""
    cmd = ["journalctl"]
    if user:
        cmd.append("--user")
    cmd.extend(["-u", f"{_SYSTEMD_UNIT}.service", "-n", str(lines)])
    if follow:
        cmd.append("-f")
    # Stream directly to terminal (don't capture)
    subprocess.run(cmd)


# ═══════════════════════════════════════════════════════════════════════════════
# Update Commands (Linux headless self-update)
# ═══════════════════════════════════════════════════════════════════════════════

_UPDATE_CHECK_URL = "https://backbone-mem.nowledge.co/latest"
_UPDATE_USER_AGENT = f"nmem-cli/{__version__}"


def _detect_deployment_type() -> str:
    """Detect whether this CLI is running from a DEB install or AppImage.

    Returns ``"appimage"``, ``"deb"``, or ``"unknown"``.
    """
    # AppImage sets this env var to the .AppImage file path
    if os.environ.get("APPIMAGE"):
        return "appimage"

    # DEB: the postinstall symlinks /usr/local/bin/nmem into /usr/lib/...
    nmem_link = Path("/usr/local/bin/nmem")
    if nmem_link.is_symlink():
        target = str(nmem_link.resolve())
        if "/usr/lib/" in target or "/usr/lib64/" in target:
            return "deb"

    # Fallback: ask dpkg
    try:
        result = subprocess.run(
            ["dpkg", "-s", "nowledge-mem"],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0 and "install ok installed" in result.stdout:
            return "deb"
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    return "unknown"


def _compare_versions(current: str, available: str) -> bool:
    """Return True if *available* is strictly newer than *current* (semver).

    Handles pre-release suffixes like ``0.6.4-beta1`` by extracting the leading
    numeric part of each segment (``4-beta1`` → ``4``).
    """
    import re

    def parse(v: str) -> list[int]:
        parts: list[int] = []
        for seg in v.lstrip("v").split("."):
            m = re.match(r"(\d+)", seg)
            if m:
                parts.append(int(m.group(1)))
        return parts

    cur, avail = parse(current), parse(available)
    if not avail:
        return False  # empty / unparseable available version is never newer
    for c, a in zip(cur, avail):
        if a > c:
            return True
        if a < c:
            return False
    return len(avail) > len(cur)


def _check_for_update(platform_id: str) -> Optional[dict]:
    """Call backbone API to check for updates.  Returns parsed JSON or None."""
    url = f"{_UPDATE_CHECK_URL}?platform={platform_id}&secure=false"
    try:
        resp = httpx.get(
            url,
            headers={"Accept": "application/json", "User-Agent": _UPDATE_USER_AGENT},
            timeout=30.0,
        )
        resp.raise_for_status()
        data = resp.json()
        if not isinstance(data, dict):
            return None
        return data
    except Exception:
        # Network errors, HTTP errors, JSON decode errors — all non-fatal
        return None


def _is_apt_repo_configured() -> bool:
    """Check if the Nowledge Mem APT source and GPG key are in place."""
    return (
        Path("/etc/apt/sources.list.d/nowledge-mem.list").exists()
        and Path("/usr/share/keyrings/nowledge-mem-archive-keyring.gpg").exists()
    )


def _is_service_active(user: bool = False) -> bool:
    """Check if the nmem systemd service is currently running."""
    try:
        result = _run_systemctl(
            ["is-active", f"{_SYSTEMD_UNIT}.service"], user=user, check=False,
        )
        return result.stdout.strip() == "active"
    except Exception:
        return False


# ── nmem update check ─────────────────────────────────────────────


def cmd_update_check() -> None:
    """Check if a newer version of Nowledge Mem is available."""
    deploy_type = _detect_deployment_type()

    if deploy_type == "unknown":
        if is_json_mode():
            output_json({"error": "unknown_deployment",
                         "message": "Cannot determine installation type (DEB or AppImage)"})
        else:
            print_error(
                "Unknown Deployment",
                "Cannot determine if installed via DEB or AppImage.",
                "For DEB: reinstall from the .deb package.\n"
                "For AppImage: ensure the APPIMAGE env var is set.",
            )
        return

    platform_id = "linux-appimage" if deploy_type == "appimage" else "linux-deb"

    with Progress(
        SpinnerColumn(), TextColumn("[cyan]Checking for updates...[/cyan]"),
        console=console, transient=True, disable=is_json_mode(),
    ) as p:
        p.add_task("", total=None)
        update_info = _check_for_update(platform_id)

    if update_info is None:
        if is_json_mode():
            output_json({"error": "check_failed", "message": "Could not reach update server"})
        else:
            print_error("Check Failed", "Could not reach update server.",
                        "Check your internet connection and try again.")
        return

    available = update_info.get("version", "")
    is_newer = _compare_versions(__version__, available)

    result = {
        "current_version": __version__,
        "available_version": available,
        "update_available": is_newer,
        "deployment_type": deploy_type,
        "release_notes": update_info.get("release_notes", ""),
        "pub_date": update_info.get("pub_date", ""),
        "file_size": update_info.get("file_size"),
    }

    if is_json_mode():
        output_json(result)
        return

    console.print()
    if is_newer:
        console.print(
            f"[bold green]Update available[/bold green]  "
            f"[dim]{__version__}[/dim] -> [bold cyan]{available}[/bold cyan]"
        )
        console.print(f"  Deployment: [cyan]{deploy_type}[/cyan]")
        notes = update_info.get("release_notes", "")
        if notes:
            console.print(f"  Notes: {notes[:200]}")
        console.print()
        if deploy_type == "deb":
            console.print("  Run [bold]sudo nmem update apply[/bold] or:")
            console.print("  [dim]sudo apt-get update && sudo apt-get upgrade nowledge-mem[/dim]")
        else:
            console.print("  Run [bold]nmem update apply[/bold] to download and install.")
    else:
        console.print(
            f"[green]ok[/green] You are on the latest version ([cyan]{__version__}[/cyan])"
        )
    console.print()


# ── nmem update apply ─────────────────────────────────────────────


def cmd_update_apply(yes: bool = False) -> None:
    """Download and apply an update (auto-detects DEB vs AppImage)."""
    deploy_type = _detect_deployment_type()

    if deploy_type == "unknown":
        if is_json_mode():
            output_json({"error": "unknown_deployment",
                         "message": "Cannot determine installation type (DEB or AppImage)"})
        else:
            print_error(
                "Unknown Deployment",
                "Cannot determine if installed via DEB or AppImage.",
                "For DEB:      sudo apt-get update && sudo apt-get upgrade nowledge-mem\n"
                "For AppImage: set the APPIMAGE env var and re-run.",
            )
        return

    if deploy_type == "deb":
        _update_deb(yes)
    else:
        _update_appimage(yes)


def _update_deb(yes: bool) -> None:
    """Apply update via APT."""
    # 1. Check APT repo
    if not _is_apt_repo_configured():
        if is_json_mode():
            output_json({"error": "apt_not_configured",
                         "message": "APT repository not configured"})
        else:
            print_error(
                "APT Repository Not Configured",
                "The Nowledge Mem APT source is not set up.",
                "Reinstall the .deb package (it configures APT automatically), or run:\n\n"
                "  curl -fsSL https://nowledge-co.github.io/community/apt/install.sh | sudo bash",
            )
        return

    # 2. Check root
    if os.geteuid() != 0:
        if is_json_mode():
            output_json({"error": "root_required",
                         "message": "DEB update requires root privileges"})
        else:
            print_error(
                "Root Required",
                "Updating via APT requires root privileges.",
                "Run: [bold]sudo nmem update apply[/bold]",
            )
        return

    # 3. Service notice
    for user_flag in (False, True):
        if _is_service_active(user_flag):
            scope = "user" if user_flag else "system"
            if not is_json_mode():
                console.print(
                    f"[yellow]Note:[/yellow] The nmem {scope} service is running. "
                    "It will be stopped gracefully during the upgrade."
                )

    # 4. Confirm
    if not yes and not is_json_mode():
        if not Confirm.ask("Update nowledge-mem via APT?"):
            console.print("[dim]Cancelled[/dim]")
            return
        console.print()

    # 5. Scoped apt-get update (only refresh nowledge-mem source)
    try:
        with Progress(
            SpinnerColumn(), TextColumn("[cyan]Refreshing package index...[/cyan]"),
            console=console, transient=True, disable=is_json_mode(),
        ) as p:
            p.add_task("", total=None)
            result = subprocess.run(
                ["apt-get", "update",
                 "-o", "Dir::Etc::sourcelist=sources.list.d/nowledge-mem.list",
                 "-o", "Dir::Etc::sourceparts=-",
                 "-o", "APT::Get::List-Cleanup=0",
                 "--quiet"],
                capture_output=True, text=True, timeout=120,
            )
    except FileNotFoundError:
        if is_json_mode():
            output_json({"error": "apt_not_found", "message": "apt-get not found on PATH"})
        else:
            print_error("APT Not Found", "apt-get is not available on this system.")
        return
    except subprocess.TimeoutExpired:
        if is_json_mode():
            output_json({"error": "apt_update_timeout"})
        else:
            print_error("Timeout", "apt-get update timed out after 2 minutes.")
        return

    if result.returncode != 0:
        if is_json_mode():
            output_json({"error": "apt_update_failed", "stderr": result.stderr.strip()})
        else:
            print_error("APT Update Failed", result.stderr.strip())
        return

    # 6. Install upgrade
    try:
        with Progress(
            SpinnerColumn(), TextColumn("[cyan]Installing update...[/cyan]"),
            console=console, transient=True, disable=is_json_mode(),
        ) as p:
            p.add_task("", total=None)
            result = subprocess.run(
                ["apt-get", "install", "--only-upgrade", "-y", "nowledge-mem"],
                capture_output=True, text=True, timeout=300,
            )
    except subprocess.TimeoutExpired:
        if is_json_mode():
            output_json({"error": "apt_install_timeout"})
        else:
            print_error("Timeout", "apt-get install timed out after 5 minutes.")
        return

    if result.returncode != 0:
        if is_json_mode():
            output_json({"error": "apt_install_failed", "stderr": result.stderr.strip()})
        else:
            print_error("Installation Failed", result.stderr.strip())
        return

    # 7. Read new version from dpkg
    new_version = __version__
    try:
        dpkg_result = subprocess.run(
            ["dpkg-query", "-W", "-f", "${Version}", "nowledge-mem"],
            capture_output=True, text=True, timeout=5,
        )
        if dpkg_result.returncode == 0:
            new_version = dpkg_result.stdout.strip()
    except Exception:
        pass

    if new_version == __version__:
        if is_json_mode():
            output_json({"status": "up_to_date", "version": __version__})
        else:
            console.print(
                f"[green]ok[/green] Already on the latest version ([cyan]{__version__}[/cyan])"
            )
    else:
        if is_json_mode():
            output_json({"status": "updated", "previous_version": __version__,
                          "new_version": new_version})
        else:
            print_success("Updated", f"{__version__} -> {new_version}")


def _update_appimage(yes: bool) -> None:
    """Apply update for AppImage deployment."""
    import tempfile

    appimage_env = os.environ.get("APPIMAGE", "")
    if not appimage_env:
        if is_json_mode():
            output_json({"error": "no_appimage_env",
                         "message": "APPIMAGE environment variable not set"})
        else:
            print_error(
                "Not an AppImage",
                "APPIMAGE environment variable is not set.",
                "Run this command from within the AppImage.",
            )
        return

    appimage_path = Path(appimage_env)
    if not appimage_path.exists():
        if is_json_mode():
            output_json({"error": "appimage_not_found", "path": str(appimage_path)})
        else:
            print_error("AppImage Not Found", f"File does not exist: {appimage_path}")
        return

    if not os.access(appimage_path.parent, os.W_OK):
        if is_json_mode():
            output_json({"error": "permission_denied",
                         "message": f"No write permission to {appimage_path.parent}"})
        else:
            print_error(
                "Permission Denied", f"Cannot write to {appimage_path.parent}",
                "Run with sudo, or move the AppImage to a user-writable location.",
            )
        return

    # Fetch update info with pre-signed URL
    with Progress(
        SpinnerColumn(), TextColumn("[cyan]Checking for updates...[/cyan]"),
        console=console, transient=True, disable=is_json_mode(),
    ) as p:
        p.add_task("", total=None)
        try:
            resp = httpx.get(
                f"{_UPDATE_CHECK_URL}?platform=linux-appimage&secure=true",
                headers={"Accept": "application/json", "User-Agent": _UPDATE_USER_AGENT},
                timeout=30.0,
            )
            resp.raise_for_status()
            update_info = resp.json()
            if not isinstance(update_info, dict):
                raise ValueError("Unexpected response format from update server")
        except Exception as e:
            if is_json_mode():
                output_json({"error": "fetch_failed", "message": str(e)})
            else:
                print_error("Fetch Failed", f"Cannot reach update server: {e}")
            return

    available = update_info.get("version", "")
    if not _compare_versions(__version__, available):
        if is_json_mode():
            output_json({"status": "up_to_date", "version": __version__})
        else:
            console.print(
                f"[green]ok[/green] Already on the latest version ([cyan]{__version__}[/cyan])"
            )
        return

    download_url = update_info.get("secure_download_url") or update_info.get("download_url")
    if not download_url:
        if is_json_mode():
            output_json({"error": "no_download_url"})
        else:
            print_error("No Download URL", "Update server did not provide a download URL.")
        return

    raw_size = update_info.get("file_size")
    try:
        file_size = int(raw_size) if raw_size else 0
    except (TypeError, ValueError):
        file_size = 0
    size_str = f" ({file_size // (1024 * 1024)} MB)" if file_size else ""

    if not is_json_mode():
        console.print()
        console.print(
            f"  Update: [dim]{__version__}[/dim] -> [bold cyan]{available}[/bold cyan]{size_str}"
        )
        console.print(f"  Target: [cyan]{appimage_path}[/cyan]")
        console.print()

    if not yes and not is_json_mode():
        if not Confirm.ask("Download and apply this update?"):
            console.print("[dim]Cancelled[/dim]")
            return

    # Stop systemd service(s) if running (we'll restart after)
    # NOTE: Do NOT call cmd_service_stop() — it calls sys.exit(1) on failure,
    # which would abort the update mid-flight. Inline the systemctl call instead.
    stopped_services: list[bool] = []  # user flags for services we stopped
    for user_flag in (False, True):
        if _is_service_active(user_flag):
            scope = "user" if user_flag else "system"
            if not is_json_mode():
                console.print(f"[cyan]Stopping {scope} service...[/cyan]")
            stop_result = _run_systemctl(
                ["stop", f"{_SYSTEMD_UNIT}.service"], user=user_flag, check=False,
            )
            if stop_result.returncode == 0:
                stopped_services.append(user_flag)
            elif not is_json_mode():
                console.print(
                    f"[yellow]Warning:[/yellow] Failed to stop {scope} service, "
                    "continuing with update."
                )

    # Download to temp file in the same directory (for same-filesystem copy)
    temp_path: Optional[Path] = None
    try:
        with Progress(
            SpinnerColumn(), TextColumn("[cyan]Downloading...[/cyan]"),
            console=console, transient=True, disable=is_json_mode(),
        ) as p:
            p.add_task("", total=None)
            with tempfile.NamedTemporaryFile(
                suffix=".AppImage", dir=str(appimage_path.parent), delete=False,
            ) as tmp:
                temp_path = Path(tmp.name)
                with httpx.stream(
                    "GET", download_url, timeout=600.0, follow_redirects=True,
                ) as stream:
                    stream.raise_for_status()
                    for chunk in stream.iter_bytes(chunk_size=65536):
                        tmp.write(chunk)

        # Replace current AppImage
        if not is_json_mode():
            console.print("[cyan]Replacing AppImage...[/cyan]")
        shutil.copy2(str(temp_path), str(appimage_path))
        os.chmod(str(appimage_path), 0o755)

        # Clean up
        temp_path.unlink(missing_ok=True)
        temp_path = None

    except Exception as e:
        if temp_path and temp_path.exists():
            temp_path.unlink(missing_ok=True)
        if is_json_mode():
            output_json({"error": "update_failed", "message": str(e)})
        else:
            print_error("Update Failed", str(e))
        return

    # Restart service(s) that we stopped
    services_restarted = False
    for user_flag in stopped_services:
        scope = "user" if user_flag else "system"
        if not is_json_mode():
            console.print(f"[cyan]Restarting {scope} service...[/cyan]")
        start_result = _run_systemctl(
            ["start", f"{_SYSTEMD_UNIT}.service"], user=user_flag, check=False,
        )
        if start_result.returncode == 0:
            services_restarted = True
        elif not is_json_mode():
            console.print(
                f"[yellow]Warning:[/yellow] Failed to restart {scope} service. "
                f"Run 'nmem service start{' --user' if user_flag else ''}' manually."
            )

    if is_json_mode():
        output_json({
            "status": "updated", "previous_version": __version__,
            "new_version": available, "appimage_path": str(appimage_path),
            "service_restarted": services_restarted,
        })
    else:
        print_success("Updated", f"{__version__} -> {available}")
        console.print(f"  AppImage: [cyan]{appimage_path}[/cyan]")
        if services_restarted:
            console.print("  Service restarted automatically.")
        elif not stopped_services:
            console.print(
                "  [dim]Restart 'nmem serve' or 'nmem service start' to use the new version.[/dim]"
            )
        console.print()


# ═══════════════════════════════════════════════════════════════════════════════
# Models Commands
# ═══════════════════════════════════════════════════════════════════════════════


def _render_model_state(state: str | None, exists_fallback: bool) -> str:
    normalized = state or ("ready" if exists_fallback else "not_installed")
    if normalized == "ready":
        return "[green]ready[/green]"
    if normalized == "installed_unverified":
        return "[yellow]installed (unverified)[/yellow]"
    if normalized == "corrupted":
        return "[red]corrupted[/red]"
    if normalized == "unsupported":
        return "[dim]unsupported[/dim]"
    return "[dim]not installed[/dim]"


def _render_model_details(model_state: dict[str, Any], fallback_detail: str = "") -> str:
    parts: list[str] = []
    model_name = model_state.get("model_name")
    if model_name:
        parts.append(str(model_name))
    elif fallback_detail:
        parts.append(fallback_detail)

    size_mb = model_state.get("estimated_size_mb")
    if isinstance(size_mb, (int, float)) and size_mb > 0:
        parts.append(f"~{int(size_mb)}MB")

    last_verified_at = model_state.get("last_verified_at")
    if last_verified_at:
        parts.append(f"verified: {last_verified_at}")

    error = model_state.get("error")
    if error:
        parts.append(f"error: {error}")

    return " | ".join(parts)


def cmd_models_status(verify: bool = False, force_refresh: bool = False) -> None:
    """Show status and verification state of built-in local models."""
    params: dict[str, Any] = {}
    if verify:
        params["full_verify"] = True
    if force_refresh or verify:
        params["force_refresh"] = True

    data = api_get("/models/status", params=params or None)
    if is_json_mode():
        output_json(data)
        return

    console.print()
    console.print("[bold]Model Status[/bold]")
    if verify:
        console.print("[dim]Full verification requested (runtime smoke tests enabled).[/dim]")
    console.print()

    table = Table(box=box.SIMPLE)
    table.add_column("Model", style="bold")
    table.add_column("State")
    table.add_column("Details")

    model_states = data.get("model_states", {})
    cache_info = data.get("cache_info", {})
    search_state = model_states.get("search_embedding", {})
    llm_state = model_states.get("local_llm", {})

    bge_info = cache_info.get("bge_m3", {})
    search_fallback = ""
    if isinstance(bge_info, dict):
        search_fallback = str(bge_info.get("model", ""))
        size_mb = bge_info.get("size_mb", 0)
        if search_fallback and size_mb:
            search_fallback = f"{search_fallback} (~{size_mb}MB)"

    table.add_row(
        "Search Embedding",
        _render_model_state(search_state.get("state"), bool(data.get("bge_m3", False))),
        _render_model_details(search_state, search_fallback),
    )

    llm_fallback = ""
    for item in cache_info.get("models", []):
        if isinstance(item, dict) and item.get("type") == "llm":
            llm_fallback = str(item.get("name", ""))
            size_mb = item.get("size_mb")
            if llm_fallback and isinstance(size_mb, (int, float)) and size_mb > 0:
                llm_fallback = f"{llm_fallback} (~{int(size_mb)}MB)"
            break

    table.add_row(
        "Local LLM",
        _render_model_state(llm_state.get("state"), bool(data.get("local_llm", False))),
        _render_model_details(llm_state, llm_fallback),
    )

    console.print(table)

    needs_install = data.get("needs_installation", False)
    if needs_install:
        console.print("  [yellow]Some models need installation.[/yellow]")
        console.print("  Run [bold]nmem models download[/bold] to install embedding model.")

    verification_summary = data.get("verification_summary", {})
    corrupted = verification_summary.get("corrupted_models", [])
    if corrupted:
        console.print(f"  [red]Corrupted model(s): {', '.join(str(m) for m in corrupted)}[/red]")
        console.print("  Reinstall impacted model(s) before using local inference.")
    elif not verify:
        any_unverified = any(
            isinstance(state, dict) and state.get("state") == "installed_unverified"
            for state in model_states.values()
        )
        if any_unverified:
            console.print("  [yellow]Some models are installed but not runtime-verified.[/yellow]")
            console.print("  Run [bold]nmem models status --verify[/bold] for full validation.")

    console.print()


def cmd_models_download(force: bool = False) -> None:
    """Download the embedding model for hybrid search."""
    # First check current status
    status = api_get("/models/bge-m3/status")
    if not force and status.get("exists"):
        if is_json_mode():
            output_json({"status": "already_installed", "model": status})
            return
        console.print()
        console.print("[green]ok[/green] Embedding model already installed")
        model_name = status.get("model_name", "")
        if model_name:
            console.print(f"  Model: [cyan]{model_name}[/cyan]")
        console.print("  Use [bold]--force[/bold] to reinstall")
        console.print()
        return

    if not is_json_mode():
        console.print()
        console.print("[bold]Downloading embedding model...[/bold]")
        console.print("  This may take several minutes depending on your connection.")
        console.print()

    # Use longer timeout for model download (10 minutes)
    url = f"{get_api_url()}/models/bge-m3/install"
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Downloading and installing model...[/cyan]"),
            console=console,
            transient=True,
            disable=is_json_mode(),
        ) as p:
            p.add_task("", total=None)
            response = api_request(
                "POST",
                url,
                json={"force_reinstall": force},
                timeout=600.0,
            )
            response.raise_for_status()
            result = response.json()
    except httpx.ConnectError:
        if is_json_mode():
            output_json({"error": "connection_failed"})
        else:
            print_error("Connection Failed", f"Cannot reach {get_api_url()}")
        sys.exit(1)
    except httpx.HTTPStatusError as e:
        if is_json_mode():
            output_json({"error": "api_error", "status_code": e.response.status_code})
        else:
            print_error(
                f"Download Failed ({e.response.status_code})",
                "Model installation failed",
            )
        sys.exit(1)

    if is_json_mode():
        output_json(result)
        return

    if result.get("success", result.get("installed")):
        console.print("[green]ok[/green] Embedding model installed successfully")
        model_name = result.get("model_name", "")
        if model_name:
            console.print(f"  Model: [cyan]{model_name}[/cyan]")
    else:
        msg = result.get("error", result.get("message", "Unknown error"))
        print_error("Installation Failed", msg)


def cmd_models_reindex() -> None:
    """Rebuild the search index from the database."""
    if not is_json_mode():
        console.print()
        console.print("[bold]Rebuilding search index...[/bold]")
        console.print("  This reindexes all memories, threads, and entities.")
        console.print()

    url = f"{get_api_url()}/search-index/reindex"
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Reindexing...[/cyan]"),
            console=console,
            transient=True,
            disable=is_json_mode(),
        ) as p:
            p.add_task("", total=None)
            response = api_request(
                "POST",
                url,
                timeout=600.0,
            )
            response.raise_for_status()
            result = response.json()
    except httpx.ConnectError:
        if is_json_mode():
            output_json({"error": "connection_failed"})
        else:
            print_error("Connection Failed", f"Cannot reach {get_api_url()}")
        sys.exit(1)
    except httpx.HTTPStatusError as e:
        if is_json_mode():
            output_json({"error": "api_error", "status_code": e.response.status_code})
        else:
            print_error(
                f"Reindex Failed ({e.response.status_code})",
                "Search index rebuild failed",
            )
        sys.exit(1)

    if is_json_mode():
        output_json(result)
        return

    if result.get("success"):
        console.print("[green]ok[/green] Search index rebuilt successfully")
        count = result.get("indexed_count", result.get("count", ""))
        if count:
            console.print(f"  Indexed: [cyan]{count}[/cyan] records")
    else:
        msg = result.get("error", result.get("message", "Unknown error"))
        print_error("Reindex Failed", msg)


# ═══════════════════════════════════════════════════════════════════════════════
# License Commands
# ═══════════════════════════════════════════════════════════════════════════════


def cmd_license_status() -> None:
    """Show license status."""
    data = api_get("/api/license/status")
    if is_json_mode():
        output_json(data)
        return

    tier = data.get("tier", "free")
    email = data.get("email")
    activated = data.get("is_device_activated", False)
    activation_status = data.get("activation_status", "not_activated")
    device_id = data.get("device_id", "")
    memory_count = data.get("memory_count", 0)
    memory_limit = data.get("memory_limit", 20)

    console.print()
    console.print("[bold]License Status[/bold]")
    console.print()

    tier_display = "[green]Pro[/green]" if tier == "pro" else "[dim]Free[/dim]"
    console.print(f"  Tier:        {tier_display}")
    if email:
        console.print(f"  Email:       [cyan]{email}[/cyan]")
    console.print(f"  Activated:   {'[green]Yes[/green]' if activated else '[yellow]No[/yellow]'}")
    console.print(f"  Status:      {activation_status}")
    limit_str = "unlimited" if memory_limit == -1 else str(memory_limit)
    console.print(f"  Memories:    {memory_count} / {limit_str}")
    if device_id:
        console.print(f"  Device ID:   [dim]{device_id[:16]}...[/dim]")
    console.print()


def cmd_license_activate(license_code: str, email: str) -> None:
    """Activate a license key."""
    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Activating license...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_post(
                "/api/license/activate",
                {"license_code": license_code, "email": email},
            )
    else:
        data = api_post(
            "/api/license/activate",
            {"license_code": license_code, "email": email},
        )

    if is_json_mode():
        output_json(data)
    else:
        status = data.get("status", "error")
        message = data.get("message", "")
        if status == "activated":
            print_success("License activated", message)
        elif status == "verified_offline":
            console.print(f"[yellow]![/yellow] {message}")
        else:
            print_error("Activation failed", message)


def cmd_license_deactivate() -> None:
    """Deactivate the current license."""
    if not is_json_mode():
        if not Confirm.ask("Deactivate license? This will remove all license data"):
            return

    data = api_post("/api/license/deactivate", {})

    if is_json_mode():
        output_json(data)
    else:
        if data.get("success"):
            print_success("License deactivated")
        else:
            print_error("Deactivation failed", str(data))


# ═══════════════════════════════════════════════════════════════════════════════
# Config Commands
# ═══════════════════════════════════════════════════════════════════════════════


def cmd_config_provider_list() -> None:
    """List configured LLM providers."""
    data = api_get("/remote-llm/config")
    if is_json_mode():
        output_json(data)
        return

    console.print()
    console.print("[bold]LLM Providers[/bold]")
    console.print()

    enabled = data.get("enabled", False)
    active = data.get("active_provider", "")
    console.print(f"  Remote LLM:    {'[green]Enabled[/green]' if enabled else '[dim]Disabled[/dim]'}")
    console.print(f"  Active:        [cyan]{active}[/cyan]" if active else "  Active:        [dim]none[/dim]")
    console.print()

    providers = data.get("providers", {})
    if providers:
        table = Table(box=box.SIMPLE, header_style="bold", show_edge=False)
        table.add_column("Provider", style="cyan")
        table.add_column("Type")
        table.add_column("Model")
        table.add_column("API Key")
        table.add_column("Active")

        for pid, p in providers.items():
            is_active = pid == active
            table.add_row(
                p.get("display_name") or pid,
                p.get("provider_type", ""),
                p.get("model", ""),
                "[green]set[/green]" if p.get("has_api_key") else "[dim]none[/dim]",
                "[green]>>>[/green]" if is_active else "",
            )
        console.print(table)
    else:
        console.print("  [dim]No providers configured.[/dim]")

    # Show purpose selections
    purposes = data.get("purposes", {})
    if purposes:
        console.print()
        console.print("[bold]Purpose Assignments[/bold]")
        for purpose, info in purposes.items():
            eff_provider = info.get("effective_provider", "")
            eff_model = info.get("effective_model", "")
            console.print(f"  {purpose}: [cyan]{eff_provider}[/cyan] / {eff_model}")
    console.print()


def cmd_config_provider_set(
    provider: str | None,
    api_key: str | None = None,
    model: str | None = None,
    api_base: str | None = None,
) -> None:
    """Configure an LLM provider."""
    config_data = api_get("/remote-llm/config")
    providers = (
        config_data.get("providers", {})
        if isinstance(config_data, dict)
        else {}
    )
    configured_options: list[tuple[str, str]] = []
    if isinstance(providers, dict):
        for pid, p in providers.items():
            if not isinstance(pid, str):
                continue
            if not isinstance(p, dict):
                p = {}
            display_name = str(p.get("display_name") or pid)
            provider_type = str(p.get("provider_type") or pid)
            model_name = str(p.get("model") or "").strip()
            label = f"{display_name} (configured, type={provider_type})"
            if model_name:
                label += f" ({model_name})"
            configured_options.append((label, pid))

    selection_options = list(configured_options)
    configured_ids = {value for _, value in configured_options}
    for label, value in PROVIDER_OPTIONS:
        if value not in configured_ids:
            selection_options.append((label, value))

    if not provider:
        if is_json_mode():
            output_json(
                {
                    "error": "provider_required",
                    "message": "Provider is required in JSON mode.",
                    "supported_providers": SUPPORTED_PROVIDER_TYPES,
                }
            )
            return
        console.print()
        console.print("[bold]Select Provider[/bold]")
        for idx, (label, value) in enumerate(selection_options, start=1):
            console.print(f"  {idx:>2}. {label} [dim]=> {value}[/dim]")
        selected_idx = Prompt.ask(
            "Provider number",
            choices=[str(i) for i in range(1, len(selection_options) + 1)],
            default="1",
        )
        provider = selection_options[int(selected_idx) - 1][1]

    target_existing = providers.get(provider, {}) if isinstance(providers, dict) else {}
    if not isinstance(target_existing, dict):
        target_existing = {}
    defaults = PROVIDER_DEFAULTS.get(provider, {})

    effective_model = (
        model
        or str(target_existing.get("model") or "").strip()
        or defaults.get("model", "")
    )
    effective_api_base = (
        api_base
        or str(target_existing.get("api_base") or "").strip()
        or defaults.get("api_base", "")
    )

    payload: dict[str, Any] = {
        "enabled": True,
        "provider": provider,
        "model": effective_model,
        "temperature": 0.7,
        "max_tokens": 8192,
        "timeout": 60.0,
    }
    if api_key:
        payload["api_key"] = api_key
    if effective_api_base:
        payload["api_base"] = effective_api_base

    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Saving provider config...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_post("/remote-llm/config", payload)
    else:
        data = api_post("/remote-llm/config", payload)

    if is_json_mode():
        output_json(data)
    else:
        if "error" in data:
            print_error("Failed to save provider config", data["error"])
        else:
            print_success(f"Provider '{provider}' configured")


def _get_configured_provider_options() -> list[tuple[str, str]]:
    """Return configured provider options as (label, provider_id)."""
    config_data = api_get("/remote-llm/config")
    providers = (
        config_data.get("providers", {})
        if isinstance(config_data, dict)
        else {}
    )
    configured_options: list[tuple[str, str]] = []
    if isinstance(providers, dict):
        for pid, p in providers.items():
            if not isinstance(pid, str):
                continue
            if not isinstance(p, dict):
                p = {}
            display_name = str(p.get("display_name") or pid)
            provider_type = str(p.get("provider_type") or pid)
            model_name = str(p.get("model") or "").strip()
            label = f"{display_name} (configured, type={provider_type})"
            if model_name:
                label += f" ({model_name})"
            configured_options.append((label, pid))
    return configured_options


def cmd_config_provider_purpose_set(
    purpose: str,
    provider: str | None = None,
    model: str | None = None,
    inherit: bool = False,
) -> None:
    """Set provider/model for default or agents purpose."""
    normalized_purpose = "ai_now" if purpose in ("agents", "ai_now") else "default"
    configured_options = _get_configured_provider_options()

    if normalized_purpose == "default":
        if not configured_options:
            print_error(
                "No providers configured",
                "Configure at least one provider first with 'nmem config provider set'.",
            )
            return
        if not provider:
            if is_json_mode():
                output_json(
                    {
                        "error": "provider_required",
                        "message": "default purpose requires a provider.",
                    }
                )
                return
            console.print()
            console.print("[bold]Select Default Provider[/bold]")
            for idx, (label, value) in enumerate(configured_options, start=1):
                console.print(f"  {idx:>2}. {label} [dim]=> {value}[/dim]")
            selected_idx = Prompt.ask(
                "Provider number",
                choices=[str(i) for i in range(1, len(configured_options) + 1)],
                default="1",
            )
            provider = configured_options[int(selected_idx) - 1][1]
    else:
        if inherit:
            provider = None
            model = None
        elif not provider:
            if not configured_options:
                print_error(
                    "No providers configured",
                    "Configure at least one provider first with 'nmem config provider set'.",
                )
                return
            if is_json_mode():
                output_json(
                    {
                        "error": "provider_required",
                        "message": "agents purpose requires provider or --inherit.",
                    }
                )
                return
            console.print()
            console.print("[bold]Select Agents Provider[/bold]")
            console.print("   0. Inherit default provider/model")
            for idx, (label, value) in enumerate(configured_options, start=1):
                console.print(f"  {idx:>2}. {label} [dim]=> {value}[/dim]")
            selected_idx = Prompt.ask(
                "Provider number",
                choices=["0"] + [str(i) for i in range(1, len(configured_options) + 1)],
                default="0",
            )
            if selected_idx == "0":
                provider = None
                model = None
            else:
                provider = configured_options[int(selected_idx) - 1][1]

    payload: dict[str, Any] = {"purpose": normalized_purpose}
    if provider is not None:
        payload["provider"] = provider
    if model is not None:
        payload["model"] = model

    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Saving purpose selection...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_post("/remote-llm/purpose", payload)
    else:
        data = api_post("/remote-llm/purpose", payload)

    if is_json_mode():
        output_json(data)
    elif "error" in data:
        print_error("Failed to save purpose selection", data["error"])
    else:
        if normalized_purpose == "default":
            print_success(
                "Default purpose updated",
                f"Provider: {provider or 'none'}"
                + (f" / Model override: {model}" if model else ""),
            )
        elif provider is None:
            print_success("Agents purpose updated", "Inheriting default provider/model")
        else:
            print_success(
                "Agents purpose updated",
                f"Provider: {provider}" + (f" / Model override: {model}" if model else ""),
            )


def cmd_config_provider_test() -> None:
    """Test connection to the active LLM provider."""
    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Testing connection...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_post("/remote-llm/test", {})
    else:
        data = api_post("/remote-llm/test", {})

    if is_json_mode():
        output_json(data)
    else:
        success = data.get("success", False)
        message = data.get("message", "")
        if success:
            provider = data.get("provider", "")
            model = data.get("model", "")
            print_success(f"Connection OK — {provider}/{model}", message)
        else:
            print_error("Connection test failed", message)


def cmd_config_provider_activate(provider: str | None) -> None:
    """Activate a specific LLM provider."""
    if not provider:
        configured_options = _get_configured_provider_options()
        if not configured_options:
            print_error(
                "No providers configured",
                "Configure at least one provider first with 'nmem config provider set'.",
            )
            return
        if is_json_mode():
            output_json(
                {
                    "error": "provider_required",
                    "message": "Provider is required in JSON mode.",
                }
            )
            return
        console.print()
        console.print("[bold]Select Active (Default) Provider[/bold]")
        for idx, (label, value) in enumerate(configured_options, start=1):
            console.print(f"  {idx:>2}. {label} [dim]=> {value}[/dim]")
        selected_idx = Prompt.ask(
            "Provider number",
            choices=[str(i) for i in range(1, len(configured_options) + 1)],
            default="1",
        )
        provider = configured_options[int(selected_idx) - 1][1]

    data = api_post("/remote-llm/activate", {"provider": provider})
    if is_json_mode():
        output_json(data)
    else:
        if "error" in data:
            print_error("Failed to activate provider", data["error"])
        else:
            print_success(f"Provider '{provider}' activated")


def cmd_config_settings_show() -> None:
    """Show knowledge processing settings."""
    data = api_get("/settings/knowledge-processing")
    if is_json_mode():
        output_json(data)
        return

    settings = data.get("settings", {})
    console.print()
    console.print("[bold]Knowledge Processing Settings[/bold]")
    console.print()

    # Boolean toggles
    toggles = [
        ("backgroundIntelligence", "Background Intelligence"),
        ("autoDailyBriefing", "Daily Briefing"),
        ("autoKGExtraction", "KG Extraction"),
        ("autoCommunityDetection", "Community Detection"),
        ("autoEVOLVESDetection", "EVOLVES Detection"),
        ("autoCrystallization", "Crystallization"),
        ("autoInsightDetection", "Insight Detection"),
        ("autoWMRefresh", "Working Memory Refresh"),
        ("generateCommunityAISummary", "Community AI Summaries"),
    ]

    for key, label in toggles:
        val = settings.get(key, False)
        indicator = "[green]on[/green]" if val else "[dim]off[/dim]"
        console.print(f"  {label:<30} {indicator}")

    console.print()

    # Numeric settings
    console.print(f"  Briefing Hour:               {settings.get('briefingHour', 5)}:00")
    console.print(f"  Community Interval:          {settings.get('communityDetectionIntervalDays', 14)} days")
    console.print(f"  Community Resolution:        {settings.get('communityResolution', 1.0)}")
    console.print(f"  KG Extraction Confidence:    {settings.get('kgExtractionConfidence', 0.7)}")

    # Token budget
    max_hour = settings.get("maxTokensPerHour", 500_000)
    max_day = settings.get("maxTokensPerDay", 2_000_000)
    max_task = settings.get("maxTokensPerTask", 500_000)
    console.print(f"  Max Tokens/Hour:             {_format_tokens(max_hour)}")
    console.print(f"  Max Tokens/Day:              {_format_tokens(max_day)}")
    console.print(f"  Max Tokens/Task:             {_format_tokens(max_task)}")
    console.print()


def cmd_config_settings_set(key: str, value: str) -> None:
    """Update a knowledge processing setting."""
    # Coerce value to appropriate type
    bool_keys = {
        "backgroundIntelligence", "autoKGExtraction", "autoCommunityDetection",
        "autoEVOLVESDetection", "autoDailyBriefing", "autoCrystallization",
        "autoInsightDetection", "autoWMRefresh", "generateCommunityAISummary",
    }
    int_keys = {"briefingHour", "communityDetectionIntervalDays", "maxTokensPerHour", "maxTokensPerDay", "maxTokensPerTask"}
    float_keys = {"communityResolution", "kgExtractionConfidence"}

    if key in bool_keys:
        parsed: Any = value.lower() in ("true", "1", "yes", "on")
    elif key in int_keys:
        parsed = int(value)
    elif key in float_keys:
        parsed = float(value)
    else:
        print_error("Unknown setting", f"'{key}' is not a valid knowledge processing setting")
        return

    data = api_post("/settings/knowledge-processing", {key: parsed})

    if is_json_mode():
        output_json(data)
    else:
        if "error" in data:
            print_error("Failed to update setting", data["error"])
        else:
            print_success(f"Set {key} = {parsed}")


# ═══════════════════════════════════════════════════════════════════════════════
# Argument Parser
# ═══════════════════════════════════════════════════════════════════════════════


def create_parser() -> argparse.ArgumentParser:
    _server_examples = """\
  nmem serve                        Start server in foreground
  nmem serve --port 8080            Start on custom port
  nmem service install              Install + enable + start systemd service
  nmem service install --user       User-level service (no root)
  nmem service status               Show service status
  nmem service logs -f              Follow service logs
  nmem service stop                 Stop the service
  nmem service uninstall            Remove the service
  nmem update                       Check for CLI/server updates
  nmem update check                 Check for updates (default)
  nmem update apply                 Download and apply update
  nmem update apply --yes           Non-interactive update
""" if _is_server_platform else ""

    epilog = f"""
EXAMPLES
{_server_examples}\
  nmem status                       Check server
  nmem tui                          Launch interactive TUI
  nmem m                            List memories (alias)
  nmem m search "query"             Search memories
  nmem m add "content"              Add memory
  nmem t                            List threads (alias)
  nmem t create -t "Title" -f x.md  Create from file
  nmem t append <id> -m '[{{"role":"user","content":"..."}}]'  Append messages
  nmem wm                           Read today's Working Memory
  nmem wm --date 2026-02-12         Read archived WM
  nmem wm edit                      Edit WM in $EDITOR
  nmem wm edit -m "## Focus..."     Set WM content directly
  nmem wm patch --heading "## Focus Areas" --content "new..."  Replace a section
  nmem wm patch --heading "## Notes" --append "extra note"     Append to a section
  nmem wm history                   List past WM dates
  nmem models status                Show built-in model status
  nmem models status --verify       Run full runtime verification
  nmem models download              Download embedding model
  nmem models reindex               Rebuild search index
  nmem license status               Check license
  nmem license activate <key> <email> Activate license
  nmem config provider list         List LLM providers
  nmem config provider set openai --api-key sk-xxx --model gpt-4o
  nmem config provider activate     Choose active/default provider
  nmem config provider purpose set default --provider openai
  nmem config provider purpose set agents --provider openrouter --model openrouter/openai/gpt-4o-mini
  nmem config provider purpose set agents --inherit
  nmem config provider test         Test active provider
  nmem config settings              Show processing settings
  nmem config settings set briefingHour 8
  nmem --json m search "x"          JSON output
  nmem s                             List sources in library
  nmem s show <id>                   Show source details
  nmem s delete <id>                 Delete a source
  nmem g expand <id>                 Graph connections for a memory
  nmem f                             Activity feed (last 7 days)
  nmem f --days 1                    Today's activity
  nmem f --type crystal_created      Only crystal events

ALIASES
  m  = memories
  t  = threads
  wm = working-memory
  s  = sources
  g  = graph
  f  = feed
  c  = communities

SEARCH FILTERS (for 'm search' only)
  -l, --label, --labels LABEL
                        Filter by label
  -t, --time RANGE     today, week, month, year
  --importance MIN     Minimum importance
  --mode MODE          Search mode: normal (fast, default) or deep

ENVIRONMENT
  NMEM_API_URL         Override API URL
  NMEM_API_KEY         Optional API key (Bearer auth + proxy-safe fallback)
"""

    parser = argparse.ArgumentParser(
        prog="nmem",
        description="Nowledge Mem CLI",
        epilog=epilog,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "-v", "--version", action="version", version=f"nmem {__version__}"
    )
    parser.add_argument("--api-url", help="API server URL")
    parser.add_argument("-j", "--json", action="store_true", help="JSON output")

    subparsers = parser.add_subparsers(dest="command", metavar="COMMAND")

    # status
    subparsers.add_parser("status", help="Check server status")

    # stats
    subparsers.add_parser("stats", help="Show statistics")

    # tui - Interactive Terminal UI
    subparsers.add_parser("tui", help="Launch interactive TUI (Textual-based)")

    # serve / service — Linux only; on macOS/Windows the desktop app manages the backend
    if _is_server_platform:
        serve_parser = subparsers.add_parser(
            "serve", help="Run the server in the foreground (Ctrl+C to stop)",
        )
        serve_parser.add_argument(
            "--host", default="0.0.0.0", help="Host to bind to (default: 0.0.0.0)"
        )
        serve_parser.add_argument(
            "--port", type=int, default=14242, help="Port to bind to (default: 14242)"
        )

        svc_parser = subparsers.add_parser(
            "service", help="Manage background systemd service (install/start/stop)",
        )
        svc_subs = svc_parser.add_subparsers(dest="action")

        # Shared --user flag inherited by all service subcommands
        _user_parent = argparse.ArgumentParser(add_help=False)
        _user_parent.add_argument(
            "--user", action="store_true",
            help="User-level service (no root required)",
        )

        svc_install = svc_subs.add_parser(
            "install", help="Install, enable, and start the systemd service",
            parents=[_user_parent],
        )
        svc_install.add_argument(
            "--host", default="127.0.0.1",
            help="Host to bind to (default: 127.0.0.1)",
        )
        svc_install.add_argument(
            "--port", type=int, default=14242,
            help="Port to bind to (default: 14242)",
        )

        svc_subs.add_parser("uninstall", help="Stop, disable, and remove the service", parents=[_user_parent])
        svc_subs.add_parser("start", help="Start the service", parents=[_user_parent])
        svc_subs.add_parser("stop", help="Stop the service", parents=[_user_parent])
        svc_subs.add_parser("status", help="Show service status", parents=[_user_parent])

        svc_logs = svc_subs.add_parser("logs", help="Show service logs (journalctl)", parents=[_user_parent])
        svc_logs.add_argument(
            "-f", "--follow", action="store_true", help="Follow log output",
        )
        svc_logs.add_argument(
            "-n", "--lines", type=int, default=50,
            help="Number of log lines (default: 50)",
        )

        # update (self-update for headless deployments)
        update_parser = subparsers.add_parser(
            "update", help="Check for and apply CLI/server updates",
        )
        update_subs = update_parser.add_subparsers(dest="action")

        update_subs.add_parser("check", help="Check if an update is available (default)")

        update_apply = update_subs.add_parser("apply", help="Download and apply the update")
        update_apply.add_argument(
            "-y", "--yes", action="store_true",
            help="Non-interactive mode (skip confirmation)",
        )

    # models
    models_parser = subparsers.add_parser("models", help="Embedding model management")
    models_subs = models_parser.add_subparsers(dest="action")

    models_status = models_subs.add_parser("status", help="Show model status")
    models_status.add_argument(
        "--verify",
        action="store_true",
        help="Run full runtime verification checks",
    )
    models_status.add_argument(
        "--force-refresh",
        action="store_true",
        help="Bypass cached verification result",
    )

    dl = models_subs.add_parser("download", help="Download embedding model")
    dl.add_argument(
        "-f", "--force", action="store_true", help="Force reinstall"
    )

    models_subs.add_parser("reindex", help="Rebuild search index")

    # memories (with alias 'm')
    for name in ["memories", "m"]:
        mem_parser = subparsers.add_parser(name, help="Memory operations")
        mem_parser.add_argument("-n", "--limit", type=int, default=10)
        mem_parser.add_argument(
            "--importance", type=float, help="Filter by min importance (list only)"
        )
        mem_subs = mem_parser.add_subparsers(dest="action")

        s = mem_subs.add_parser("search", help="Search memories")
        s.add_argument("query", nargs="+")
        s.add_argument("-n", "--limit", type=int, default=10)
        s.add_argument(
            "-l",
            "--label",
            "--labels",
            action="append",
            dest="labels",
            help="Filter by label",
        )
        s.add_argument("-t", "--time", dest="time_range", help="today/week/month/year (deprecated, use --event-from/--recorded-from)")
        s.add_argument("--importance", type=float, help="Minimum importance")
        s.add_argument(
            "--mode",
            choices=["normal", "deep"],
            default="normal",
            help="Search mode: normal (fast, default) or deep (Graph and LLM-enhanced)",
        )
        # Bi-temporal filters
        s.add_argument(
            "--event-from",
            dest="event_date_from",
            metavar="DATE",
            help="Event date from (YYYY, YYYY-MM, or YYYY-MM-DD) — when the fact happened",
        )
        s.add_argument(
            "--event-to",
            dest="event_date_to",
            metavar="DATE",
            help="Event date to (YYYY, YYYY-MM, or YYYY-MM-DD)",
        )
        s.add_argument(
            "--recorded-from",
            dest="recorded_date_from",
            metavar="DATE",
            help="Record date from (YYYY-MM-DD) — when it was saved to Nowledge Mem",
        )
        s.add_argument(
            "--recorded-to",
            dest="recorded_date_to",
            metavar="DATE",
            help="Record date to (YYYY-MM-DD)",
        )

        sh = mem_subs.add_parser("show", help="Show details")
        sh.add_argument("id")
        sh.add_argument("--content-limit", type=int)

        a = mem_subs.add_parser("add", help="Add memory")
        a.add_argument("content")
        a.add_argument("-t", "--title")
        a.add_argument("-i", "--importance", type=float, default=0.5)
        a.add_argument(
            "-l",
            "--label",
            "--labels",
            action="append",
            dest="labels",
            help="Add label (repeatable)",
        )
        a.add_argument(
            "-s", "--source", default="cli", help="Source identifier (default: cli)"
        )
        a.add_argument(
            "--event-start",
            dest="event_start",
            metavar="DATE",
            help="When this event occurred (YYYY, YYYY-MM, or YYYY-MM-DD)",
        )
        a.add_argument(
            "--event-end",
            dest="event_end",
            metavar="DATE",
            help="When this event ended, for ranges (YYYY, YYYY-MM, or YYYY-MM-DD)",
        )
        a.add_argument(
            "--when",
            dest="temporal_context",
            choices=["past", "present", "future", "timeless"],
            help="Temporal context: past, present, future, or timeless (default: timeless)",
        )
        a.add_argument(
            "--unit-type",
            dest="unit_type",
            choices=["fact", "preference", "decision", "plan", "procedure", "learning", "context", "event"],
            help="Knowledge unit type (default: fact)",
        )

        u = mem_subs.add_parser("update", help="Update")
        u.add_argument("id")
        u.add_argument("-t", "--title")
        u.add_argument("-c", "--content")
        u.add_argument("-i", "--importance", type=float)

        d = mem_subs.add_parser("delete", help="Delete")
        d.add_argument("id", nargs="+", help="Memory ID(s) to delete")
        d.add_argument("-f", "--force", action="store_true")

    # threads (with alias 't')
    for name in ["threads", "t"]:
        thr_parser = subparsers.add_parser(name, help="Thread operations")
        thr_parser.add_argument("-n", "--limit", type=int, default=10)
        thr_subs = thr_parser.add_subparsers(dest="action")

        s = thr_subs.add_parser("search", help="Search")
        s.add_argument("query", nargs="+")
        s.add_argument("-n", "--limit", type=int, default=10)
        s.add_argument("--source", help="Filter by source (e.g. openclaw, claude-code)")

        sh = thr_subs.add_parser("show", help="Show details")
        sh.add_argument("id")
        sh.add_argument("-m", "--messages", "--limit", type=int, default=10)
        sh.add_argument("--offset", type=int, default=0)
        sh.add_argument("--content-limit", type=int)

        c = thr_subs.add_parser("create", help="Create thread from content or file")
        c.add_argument("--id", help="Optional thread ID (otherwise generated)")
        c.add_argument("-t", "--title", required=True, help="Thread title")
        c.add_argument("-c", "--content", help="Text content (creates 1 user message)")
        c.add_argument(
            "-m",
            "--messages",
            help='JSON: [{"role":"user|assistant","content":"..."},...]',
        )
        c.add_argument(
            "-f", "--file", help="Import from file (1 msg unless Cursor format)"
        )
        c.add_argument(
            "-s", "--source", default="cli", help="Source tag (default: cli)"
        )

        a = thr_subs.add_parser("append", help="Append messages to existing thread")
        a.add_argument("id", help="Existing thread ID")
        a.add_argument(
            "-m",
            "--messages",
            help='JSON: [{"role":"user|assistant","content":"..."},...]',
        )
        a.add_argument("-c", "--content", help="Single message content")
        a.add_argument(
            "-r",
            "--role",
            choices=["user", "assistant", "system"],
            default="user",
            help="Role for --content (default: user)",
        )
        a.add_argument("-f", "--file", help="Append messages parsed from file")
        a.add_argument(
            "--format",
            default="auto",
            help="File format for --file (default: auto)",
        )
        a.add_argument(
            "--no-deduplicate",
            action="store_true",
            help="Disable duplicate filtering",
        )
        a.add_argument(
            "--idempotency-key",
            help="Stable key to safely deduplicate retried append batches",
        )

        d = thr_subs.add_parser("delete", help="Delete")
        d.add_argument("id")
        d.add_argument("-f", "--force", action="store_true")
        d.add_argument("--cascade", action="store_true")

        # save - Save coding session as thread
        sv = thr_subs.add_parser(
            "save", help="Save Claude Code or Codex session as thread"
        )
        sv.add_argument(
            "--from",
            dest="source_app",
            required=True,
            choices=["claude-code", "codex"],
            help="Source app: claude-code or codex",
        )
        sv.add_argument(
            "-p",
            "--project",
            default=".",
            help="Project directory path (default: current dir)",
        )
        sv.add_argument(
            "-m",
            "--mode",
            choices=["current", "all"],
            default="current",
            help="Save mode: current (latest) or all sessions",
        )
        sv.add_argument(
            "--session-id", help="Specific session ID (Codex only)"
        )
        sv.add_argument(
            "-s", "--summary", help="Brief session summary"
        )
        sv.add_argument(
            "--truncate",
            action="store_true",
            help="Truncate large tool results (>10KB)",
        )

        # triage - Check if conversation is worth distilling
        tr = thr_subs.add_parser(
            "triage",
            help="Check if a conversation is worth distilling into memories",
        )
        tr.add_argument(
            "thread_id",
            nargs="?",
            help="Thread ID to triage (reads messages from stored thread)",
        )
        tr.add_argument(
            "-c",
            "--content",
            help="Raw conversation text to triage (alternative to thread_id)",
        )
        tr.add_argument(
            "-f",
            "--file",
            help="Read conversation from file (plain text or JSONL)",
        )

        # distill - Distill thread into structured memories
        di = thr_subs.add_parser(
            "distill",
            help="Distill a thread into structured memories",
        )
        di.add_argument("thread_id", help="Thread ID to distill")
        di.add_argument(
            "-t",
            "--type",
            dest="distillation_type",
            choices=["simple_llm", "knowledge_graph"],
            default="simple_llm",
            help="Distillation mode (default: simple_llm)",
        )
        di.add_argument(
            "-l",
            "--level",
            dest="extraction_level",
            choices=["swift", "guided"],
            default="swift",
            help="Extraction depth: swift (fast) or guided (multi-step, default: swift)",
        )
        di.add_argument(
            "--triage",
            action="store_true",
            help="Run triage first; skip distillation if not worth it",
        )

    # working-memory (with alias 'wm')
    for name in ["working-memory", "wm"]:
        wm_parser = subparsers.add_parser(
            name, help="Working Memory — daily focus surface"
        )
        wm_parser.add_argument(
            "--date", help="Read archived WM for YYYY-MM-DD"
        )
        wm_subs = wm_parser.add_subparsers(dest="action")

        wm_subs.add_parser("read", help="Read working memory (default)")

        e = wm_subs.add_parser("edit", help="Edit working memory")
        e.add_argument(
            "-m", "--message", help="Set content directly (markdown string)"
        )

        p = wm_subs.add_parser(
            "patch",
            help="Update a single WM section without affecting the rest",
        )
        p.add_argument(
            "--heading",
            required=True,
            metavar="HEADING",
            help="Section heading to target (e.g. '## Focus Areas'). Case-insensitive partial match.",
        )
        p.add_argument(
            "--content",
            metavar="MARKDOWN",
            help="Replace the section body with this markdown text.",
        )
        p.add_argument(
            "--append",
            metavar="TEXT",
            dest="append_text",
            help="Append text to the section body (preserves existing content).",
        )

        h = wm_subs.add_parser("history", help="List archived dates")
        h.add_argument("-n", "--limit", type=int, default=30)

    # communities (with alias 'c')
    for name in ["communities", "c"]:
        com_parser = subparsers.add_parser(
            name, help="Knowledge communities — topic clusters"
        )
        com_parser.add_argument(
            "-n", "--limit", type=int, default=20, help="Max communities to show"
        )
        com_subs = com_parser.add_subparsers(dest="action")

        com_subs.add_parser("list", help="List communities (default)")

        sh = com_subs.add_parser("show", help="Show community details")
        sh.add_argument("id", help="Community UUID")

        det = com_subs.add_parser("detect", help="Trigger community detection")
        det.add_argument(
            "--resolution", type=float, default=1.0,
            help="Louvain resolution (higher = more communities)"
        )

    # graph (with alias 'g')
    for name in ["graph", "g"]:
        graph_parser = subparsers.add_parser(
            name, help="Knowledge graph operations"
        )
        graph_subs = graph_parser.add_subparsers(dest="action")

        exp = graph_subs.add_parser(
            "expand", help="Expand graph neighborhood around a memory"
        )
        exp.add_argument("id", help="Memory ID to expand from")
        exp.add_argument(
            "--depth", type=int, default=1, help="Traversal depth (default: 1)"
        )
        exp.add_argument(
            "-n", "--limit", type=int, default=20,
            help="Max neighbors per hop (default: 20)"
        )

        ev = graph_subs.add_parser(
            "evolves", help="Show EVOLVES version chain for a memory"
        )
        ev.add_argument("id", help="Memory ID to show evolution for")
        ev.add_argument(
            "-n", "--limit", type=int, default=20,
            help="Max edges to return (default: 20)"
        )

    # feed (with alias 'f')
    for name in ["feed", "f"]:
        feed_parser = subparsers.add_parser(
            name, help="Activity feed — what was saved, learned, or ingested"
        )
        feed_parser.add_argument(
            "--days", type=int, default=7, dest="last_n_days",
            help="How many days back to look (default: 7; use 1 for today)",
        )
        feed_parser.add_argument(
            "--type", dest="event_type",
            metavar="EVENT_TYPE",
            help=(
                "Filter to event type: memory_created, crystal_created, "
                "insight_generated, source_ingested, source_extracted, "
                "daily_briefing, url_captured"
            ),
        )
        feed_parser.add_argument(
            "--all", action="store_true", dest="all_events",
            help="Include background/low-signal events (default: high-signal only)",
        )
        feed_parser.add_argument(
            "--from",
            dest="date_from",
            metavar="DATE",
            help="Start date (YYYY-MM-DD). Use with --to for an exact range.",
        )
        feed_parser.add_argument(
            "--to",
            dest="date_to",
            metavar="DATE",
            help="End date (YYYY-MM-DD, inclusive). Defaults to today.",
        )
        feed_parser.add_argument(
            "-n", "--limit", type=int, default=100,
            help="Max events to fetch (default: 100)",
        )

    # sources (with alias 's')
    for name in ["sources", "s"]:
        src_parser = subparsers.add_parser(
            name, help="Source library — files, URLs, documents"
        )
        src_subs = src_parser.add_subparsers(dest="action")

        ls = src_subs.add_parser("list", help="List sources (default)")
        ls.add_argument(
            "-n", "--limit", type=int, default=20, help="Max sources to show"
        )
        ls.add_argument(
            "--type", dest="source_type",
            help="Filter by type: file, url, obsidian_note",
        )
        ls.add_argument(
            "--state", dest="lifecycle_state",
            help="Filter by state: ingested, parsed, chunked, indexed, error",
        )

        sh = src_subs.add_parser("show", help="Show source details")
        sh.add_argument("id", help="Source ID")

        d = src_subs.add_parser("delete", help="Delete source(s)")
        d.add_argument("id", nargs="+", help="Source ID(s) to delete")
        d.add_argument(
            "-f", "--force", action="store_true",
            help="Skip confirmation prompt",
        )

    # license
    lic_parser = subparsers.add_parser("license", help="License management")
    lic_subs = lic_parser.add_subparsers(dest="action")

    lic_subs.add_parser("status", help="Show license status")

    act = lic_subs.add_parser("activate", help="Activate license")
    act.add_argument("code", help="Base64-encoded license key")
    act.add_argument("email", help="Email associated with the license")

    lic_subs.add_parser("deactivate", help="Deactivate license")

    # config
    cfg_parser = subparsers.add_parser("config", help="Configuration management")
    cfg_subs = cfg_parser.add_subparsers(dest="section")

    # config provider
    prov_parser = cfg_subs.add_parser("provider", help="LLM provider configuration")
    prov_subs = prov_parser.add_subparsers(dest="action")

    prov_subs.add_parser("list", help="List configured providers")

    ps = prov_subs.add_parser("set", help="Configure a provider")
    ps.add_argument(
        "provider",
        nargs="?",
        help="Provider id (omit to choose from an interactive list)",
    )
    ps.add_argument("--api-key", help="API key")
    ps.add_argument("--model", help="Model name")
    ps.add_argument("--api-base", help="Custom API base URL")

    prov_subs.add_parser("test", help="Test active provider connection")

    pa = prov_subs.add_parser("activate", help="Set active provider")
    pa.add_argument("provider", nargs="?", help="Provider id to activate")

    pp = prov_subs.add_parser(
        "purpose", help="Set purpose selection (default or agents)"
    )
    pp_subs = pp.add_subparsers(dest="purpose_action")
    pps = pp_subs.add_parser("set", help="Set purpose provider/model")
    pps.add_argument(
        "purpose",
        choices=["default", "agents", "ai_now"],
        help="Purpose to configure",
    )
    pps.add_argument("--provider", help="Configured provider id")
    pps.add_argument("--model", help="Optional model override")
    pps.add_argument(
        "--inherit",
        action="store_true",
        help="For agents purpose: clear override and inherit default provider/model",
    )

    # config settings
    set_parser = cfg_subs.add_parser("settings", help="Knowledge processing settings")
    set_subs = set_parser.add_subparsers(dest="action")

    ss = set_subs.add_parser("set", help="Update a setting")
    ss.add_argument("key", help="Setting key (e.g. briefingHour, autoDailyBriefing)")
    ss.add_argument("value", help="New value")

    return parser


def main() -> int:
    parser = create_parser()
    args = parser.parse_args()

    if args.api_url:
        os.environ["NMEM_API_URL"] = args.api_url
    if getattr(args, "json", False):
        set_json_mode(True)

    cmd = args.command

    if cmd == "status":
        cmd_status()
    elif cmd == "stats":
        cmd_stats()
    elif cmd == "tui":
        # Launch the interactive TUI
        from .tui import run_tui

        run_tui()
    elif cmd == "serve":
        if not _is_server_platform:
            print_error(
                "Not Available",
                "'nmem serve' is for Linux server deployments.",
                "The desktop app manages the backend automatically. Use 'nmem status' to check.",
            )
            return 1
        cmd_serve(args.host, args.port)
    elif cmd == "service":
        if not _is_server_platform:
            print_error(
                "Not Available",
                "'nmem service' is for Linux server deployments.",
                "The desktop app manages the backend automatically. Use 'nmem status' to check.",
            )
            return 1
        user = getattr(args, "user", False)
        action = args.action
        if action == "install":
            cmd_service_install(args.host, args.port, user)
        elif action == "uninstall":
            cmd_service_uninstall(user)
        elif action == "start":
            cmd_service_start(user)
        elif action == "stop":
            cmd_service_stop(user)
        elif action == "logs":
            cmd_service_logs(user, getattr(args, "follow", False), getattr(args, "lines", 50))
        else:
            cmd_service_status(user)
    elif cmd == "update":
        if not _is_server_platform:
            print_error(
                "Not Available",
                "'nmem update' is for Linux server deployments.",
                "On macOS/Windows the desktop app handles updates automatically.",
            )
            return 1
        action = args.action
        if action == "apply":
            cmd_update_apply(yes=getattr(args, "yes", False))
        else:
            # Default: "check" or no subcommand
            cmd_update_check()
    elif cmd == "models":
        action = args.action
        if action == "download":
            cmd_models_download(getattr(args, "force", False))
        elif action == "reindex":
            cmd_models_reindex()
        elif action == "status":
            cmd_models_status(
                verify=getattr(args, "verify", False),
                force_refresh=getattr(args, "force_refresh", False),
            )
        else:
            cmd_models_status()
    elif cmd in ("memories", "m"):
        action = args.action
        if action == "search":
            cmd_memories_search(
                " ".join(args.query),
                args.limit,
                _normalize_labels(getattr(args, "labels", None)),
                getattr(args, "time_range", None),
                getattr(args, "importance", None),
                getattr(args, "mode", "normal"),
                getattr(args, "event_date_from", None),
                getattr(args, "event_date_to", None),
                getattr(args, "recorded_date_from", None),
                getattr(args, "recorded_date_to", None),
            )
        elif action == "show":
            cmd_memories_show(args.id, getattr(args, "content_limit", None))
        elif action == "add":
            cmd_memories_add(
                args.content,
                args.title,
                args.importance,
                _normalize_labels(getattr(args, "labels", None)),
                getattr(args, "source", "cli"),
                getattr(args, "event_start", None),
                getattr(args, "event_end", None),
                getattr(args, "temporal_context", None),
                getattr(args, "unit_type", None),
            )
        elif action == "update":
            cmd_memories_update(args.id, args.title, args.content, args.importance)
        elif action == "delete":
            cmd_memories_delete(args.id, args.force)
        else:
            cmd_memories_list(args.limit, getattr(args, "importance", None))
    elif cmd in ("threads", "t"):
        action = args.action
        if action == "search":
            cmd_threads_search(
                " ".join(args.query),
                args.limit,
                getattr(args, "source", None),
            )
        elif action == "show":
            cmd_threads_show(
                args.id,
                getattr(args, "messages", 10),
                getattr(args, "content_limit", None),
                getattr(args, "offset", 0),
            )
        elif action == "create":
            cmd_threads_create(
                getattr(args, "id", None),
                args.title,
                args.content,
                getattr(args, "messages", None),
                args.file,
                args.source,
            )
        elif action == "append":
            cmd_threads_append(
                thread_id=args.id,
                messages_json=getattr(args, "messages", None),
                content=getattr(args, "content", None),
                role=getattr(args, "role", "user"),
                file=getattr(args, "file", None),
                format=getattr(args, "format", "auto"),
                deduplicate=not bool(getattr(args, "no_deduplicate", False)),
                idempotency_key=getattr(args, "idempotency_key", None),
            )
        elif action == "delete":
            cmd_threads_delete(args.id, args.force, getattr(args, "cascade", False))
        elif action == "save":
            cmd_threads_save(
                client=args.source_app,
                project_path=args.project,
                mode=args.mode,
                session_id=getattr(args, "session_id", None),
                summary=getattr(args, "summary", None),
                truncate=getattr(args, "truncate", False),
            )
        elif action == "triage":
            cmd_threads_triage(
                thread_id=getattr(args, "thread_id", None),
                content=getattr(args, "content", None),
                file=getattr(args, "file", None),
            )
        elif action == "distill":
            cmd_threads_distill(
                thread_id=args.thread_id,
                distillation_type=getattr(args, "distillation_type", "simple_llm"),
                extraction_level=getattr(args, "extraction_level", "swift"),
                run_triage=getattr(args, "triage", False),
            )
        else:
            cmd_threads_list(args.limit)
    elif cmd in ("working-memory", "wm"):
        action = args.action
        if action == "edit":
            cmd_wm_edit(getattr(args, "message", None))
        elif action == "patch":
            cmd_wm_patch(
                heading=args.heading,
                new_content=getattr(args, "content", None),
                append_text=getattr(args, "append_text", None),
            )
        elif action == "history":
            cmd_wm_history(getattr(args, "limit", 30))
        else:
            # Default: read (also handles explicit "read" action)
            cmd_wm_read(getattr(args, "date", None))
    elif cmd in ("communities", "c"):
        action = args.action
        if action == "show":
            cmd_communities_show(args.id)
        elif action == "detect":
            cmd_communities_detect(getattr(args, "resolution", 1.0))
        else:
            # Default: list
            cmd_communities_list(getattr(args, "limit", 20))
    elif cmd in ("graph", "g"):
        action = args.action
        if action == "expand":
            cmd_graph_expand(
                args.id,
                depth=getattr(args, "depth", 1),
                limit=getattr(args, "limit", 20),
            )
        elif action == "evolves":
            cmd_graph_evolves(
                args.id,
                limit=getattr(args, "limit", 20),
            )
        else:
            # Default: help
            parser.parse_args([cmd, "--help"])
    elif cmd in ("feed", "f"):
        cmd_feed_events(
            last_n_days=getattr(args, "last_n_days", 7),
            event_type=getattr(args, "event_type", None),
            tier1_only=not getattr(args, "all_events", False),
            limit=getattr(args, "limit", 100),
            date_from=getattr(args, "date_from", None),
            date_to=getattr(args, "date_to", None),
        )
    elif cmd in ("sources", "s"):
        action = args.action
        if action == "show":
            cmd_sources_show(args.id)
        elif action == "delete":
            cmd_sources_delete(args.id, getattr(args, "force", False))
        else:
            # Default: list
            cmd_sources_list(
                limit=getattr(args, "limit", 20),
                source_type=getattr(args, "source_type", None),
                lifecycle_state=getattr(args, "lifecycle_state", None),
            )
    elif cmd == "license":
        action = args.action
        if action == "activate":
            cmd_license_activate(args.code, args.email)
        elif action == "deactivate":
            cmd_license_deactivate()
        else:
            cmd_license_status()
    elif cmd == "config":
        section = getattr(args, "section", None)
        if section == "provider":
            action = getattr(args, "action", None)
            if action == "set":
                cmd_config_provider_set(
                    args.provider,
                    getattr(args, "api_key", None),
                    getattr(args, "model", None),
                    getattr(args, "api_base", None),
                )
            elif action == "test":
                cmd_config_provider_test()
            elif action == "activate":
                cmd_config_provider_activate(args.provider)
            elif action == "purpose":
                purpose_action = getattr(args, "purpose_action", None)
                if purpose_action == "set":
                    cmd_config_provider_purpose_set(
                        args.purpose,
                        getattr(args, "provider", None),
                        getattr(args, "model", None),
                        bool(getattr(args, "inherit", False)),
                    )
                else:
                    cmd_config_provider_list()
            else:
                cmd_config_provider_list()
        elif section == "settings":
            action = getattr(args, "action", None)
            if action == "set":
                cmd_config_settings_set(args.key, args.value)
            else:
                cmd_config_settings_show()
        else:
            if is_json_mode():
                output_json({"error": "no_section", "sections": ["provider", "settings"]})
            else:
                console.print("[bold]Available config sections:[/bold]")
                console.print("  provider  — LLM provider configuration")
                console.print("  settings  — Knowledge processing settings")
    else:
        if is_json_mode():
            cmds = ["status", "stats", "models", "m", "t", "wm", "g", "f", "c", "license", "config"]
            if _is_server_platform:
                cmds = ["serve", "service"] + cmds
            output_json({"error": "no_command", "commands": cmds})
        else:
            parser.print_help()
        return 0

    return 0


if __name__ == "__main__":
    sys.exit(main())
