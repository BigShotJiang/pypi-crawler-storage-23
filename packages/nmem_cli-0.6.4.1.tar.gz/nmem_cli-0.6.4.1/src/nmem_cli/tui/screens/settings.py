"""
Settings Screen - Configuration and preferences for server/headless deployments.

Provides license activation, LLM provider configuration, embedding model
management, knowledge processing settings, and keyboard shortcuts reference.
"""

from typing import Any, Literal

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Button, Input, Rule, Select, Static

from ..api_client import ApiClient

PROVIDER_OPTIONS = [
    ("OpenAI (`openai`)", "openai"),
    ("Anthropic (`anthropic`)", "anthropic"),
    ("Gemini (`gemini`)", "gemini"),
    ("xAI (`xai`)", "xai"),
    ("DeepSeek (`deepseek`)", "deepseek"),
    ("OpenRouter (`openrouter`)", "openrouter"),
    ("Ollama (`ollama`)", "ollama"),
    ("GitHub Copilot (`github_copilot`)", "github_copilot"),
    ("ChatGPT Subscription (`openai_codex`)", "openai_codex"),
    ("MiniMax (`minimax`)", "minimax"),
    ("Z.AI (`zai`)", "zai"),
    ("Moonshot (`moonshot`)", "moonshot"),
    ("Groq (`groq`)", "groq"),
    ("Together (`together`)", "together"),
    ("Fireworks (`fireworks`)", "fireworks"),
    ("Kimi OpenAI-compatible (`kimi`)", "kimi"),
    ("Custom OpenAI-compatible (`openai_compatible`)", "openai_compatible"),
]

PROVIDER_DEFAULTS: dict[str, dict[str, str]] = {
    "openai": {"model": "gpt-4o", "api_base": "https://api.openai.com/v1"},
    "anthropic": {"model": "claude-sonnet-4-20250514", "api_base": "https://api.anthropic.com"},
    "gemini": {"model": "gemini-flash-latest", "api_base": "https://generativelanguage.googleapis.com"},
    "xai": {"model": "grok-3", "api_base": "https://api.x.ai/v1"},
    "deepseek": {"model": "deepseek-chat", "api_base": "https://api.deepseek.com/v1"},
    "openrouter": {"model": "anthropic/claude-sonnet-4", "api_base": "https://openrouter.ai/api/v1"},
    "minimax": {"model": "MiniMax-M2.1", "api_base": "https://api.minimax.io/v1"},
    "zai": {"model": "glm-4.7", "api_base": "https://api.z.ai/api/paas/v4"},
    "moonshot": {"model": "kimi-k2-thinking", "api_base": "https://api.moonshot.ai/v1"},
    "ollama": {"model": "llama3.2", "api_base": "http://127.0.0.1:11434"},
    "kimi": {"model": "kimi-k2-thinking", "api_base": "https://api.moonshot.cn/v1"},
}


# =============================================================================
# Modal: License Activation
# =============================================================================


class LicenseActivateModal(ModalScreen):
    """Modal for entering license key and email."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
    ]

    DEFAULT_CSS = """
    LicenseActivateModal { align: center middle; }
    LicenseActivateModal > Vertical {
        width: 70%;
        max-width: 80;
        height: auto;
        max-height: 20;
        background: $surface;
        border: round $primary;
        padding: 1 2;
    }
    LicenseActivateModal .modal-title {
        text-style: bold;
        color: $primary;
        text-align: center;
        margin-bottom: 1;
    }
    LicenseActivateModal .field-label {
        color: $secondary;
        margin-top: 1;
    }
    LicenseActivateModal Input {
        margin-bottom: 1;
        border: round $boost;
    }
    LicenseActivateModal Input:focus { border: round $primary; }
    LicenseActivateModal .hint { color: $text-muted; text-align: center; }
    """

    def __init__(self, api_client: ApiClient) -> None:
        super().__init__()
        self.api_client = api_client

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static("ACTIVATE LICENSE", classes="modal-title")
            yield Static("License Key (base64):", classes="field-label")
            yield Input(placeholder="Paste your license key...", id="lic-key-input")
            yield Static("Email:", classes="field-label")
            yield Input(placeholder="email@example.com", id="lic-email-input")
            yield Static("Press Enter on email field to activate  |  Esc to cancel", classes="hint")

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "lic-email-input":
            key_input = self.query_one("#lic-key-input", Input)
            email_input = self.query_one("#lic-email-input", Input)
            key = key_input.value.strip()
            email = email_input.value.strip()
            if not key or not email:
                return
            result = await self.api_client.activate_license(key, email)
            self.dismiss(result)

    def action_cancel(self) -> None:
        self.dismiss(None)


# =============================================================================
# Modal: Provider Configuration
# =============================================================================


class ProviderConfigModal(ModalScreen):
    """Modal for configuring an LLM provider."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
    ]

    DEFAULT_CSS = """
    ProviderConfigModal { align: center middle; }
    ProviderConfigModal > Vertical {
        width: 70%;
        max-width: 80;
        height: auto;
        max-height: 26;
        background: $surface;
        border: round $primary;
        padding: 1 2;
    }
    ProviderConfigModal .modal-title {
        text-style: bold;
        color: $primary;
        text-align: center;
        margin-bottom: 1;
    }
    ProviderConfigModal .field-label {
        color: $secondary;
        margin-top: 1;
    }
    ProviderConfigModal Input {
        margin-bottom: 1;
        border: round $boost;
    }
    ProviderConfigModal Select {
        margin-bottom: 1;
    }
    ProviderConfigModal Input:focus { border: round $primary; }
    ProviderConfigModal .hint { color: $text-muted; text-align: center; }
    """

    def __init__(self, api_client: ApiClient, config_data: dict[str, Any] | None = None) -> None:
        super().__init__()
        self.api_client = api_client
        data = config_data or {}
        providers = data.get("providers", {}) if isinstance(data, dict) else {}
        active_provider = (
            str(data.get("active_provider", "")).strip()
            if isinstance(data, dict)
            else ""
        )

        configured_options: list[tuple[str, str]] = []
        self._provider_configs: dict[str, dict[str, Any]] = {}
        if isinstance(providers, dict):
            for pid, p in providers.items():
                if not isinstance(pid, str):
                    continue
                if not isinstance(p, dict):
                    p = {}
                self._provider_configs[pid] = p
                display_name = str(p.get("display_name") or pid)
                provider_type = str(p.get("provider_type") or pid)
                model_name = str(p.get("model") or "").strip()
                # Keep labels markup-safe for Textual Select overlay rendering.
                label = f"{display_name} (configured, type={provider_type})"
                if model_name:
                    label += f" ({model_name})"
                configured_options.append((label, pid))

        configured_ids = {value for _, value in configured_options}
        self._provider_options = list(configured_options)
        for label, value in PROVIDER_OPTIONS:
            if value not in configured_ids:
                self._provider_options.append((label, value))

        self._initial_provider = (
            active_provider if active_provider in self._provider_configs else "openai"
        )

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static("CONFIGURE LLM PROVIDER", classes="modal-title")
            yield Static("Provider:", classes="field-label")
            yield Select(self._provider_options, value=self._initial_provider, id="prov-name-select")
            yield Static("API Key:", classes="field-label")
            yield Input(placeholder="sk-...", password=True, id="prov-key-input")
            yield Static("Model:", classes="field-label")
            yield Input(placeholder="e.g. claude-sonnet-4-20250514", id="prov-model-input")
            yield Static("Base URL (optional):", classes="field-label")
            yield Input(placeholder="Leave empty for default", id="prov-base-input")
            yield Button("Save Provider Config", id="btn-save-provider-config", variant="primary")
            yield Static("Press Enter on Base URL or click Save  |  Esc to cancel", classes="hint")

    def on_mount(self) -> None:
        self._apply_provider_defaults(self._initial_provider)

    def on_select_changed(self, event: Select.Changed) -> None:
        if event.select.id != "prov-name-select":
            return
        if isinstance(event.value, str):
            self._apply_provider_defaults(event.value)

    def _apply_provider_defaults(self, provider: str) -> None:
        model_input = self.query_one("#prov-model-input", Input)
        base_input = self.query_one("#prov-base-input", Input)
        if provider not in self._provider_configs:
            defaults = PROVIDER_DEFAULTS.get(provider, {})
            model_input.value = defaults.get("model", "")
            base_input.value = defaults.get("api_base", "")
            return
        existing = self._provider_configs.get(provider, {})
        model_input.value = str(existing.get("model") or "")
        base_input.value = str(existing.get("api_base") or "")

    async def _save_config(self) -> None:
        provider_value = self.query_one("#prov-name-select", Select).value
        provider = provider_value.strip() if isinstance(provider_value, str) else ""
        api_key = self.query_one("#prov-key-input", Input).value.strip()
        model = self.query_one("#prov-model-input", Input).value.strip()
        api_base = self.query_one("#prov-base-input", Input).value.strip()
        if not provider:
            return
        config: dict[str, Any] = {
            "enabled": True,
            "provider": provider,
            "model": model or "",
            "temperature": 0.7,
            "max_tokens": 8192,
            "timeout": 60.0,
        }
        if api_key:
            config["api_key"] = api_key
        if api_base:
            config["api_base"] = api_base
        result = await self.api_client.update_remote_llm_config(config)
        self.dismiss(result)

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "prov-base-input":
            await self._save_config()

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-save-provider-config":
            await self._save_config()

    def action_cancel(self) -> None:
        self.dismiss(None)


class PurposeConfigModal(ModalScreen):
    """Modal for selecting purpose-specific provider/model."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
    ]

    DEFAULT_CSS = ProviderConfigModal.DEFAULT_CSS

    def __init__(
        self,
        api_client: ApiClient,
        config_data: dict[str, Any],
        purpose: Literal["default", "ai_now"],
    ) -> None:
        super().__init__()
        self.api_client = api_client
        self.purpose = purpose
        self._provider_configs: dict[str, dict[str, Any]] = {}
        providers = (
            config_data.get("providers", {}) if isinstance(config_data, dict) else {}
        )
        purposes = (
            config_data.get("purposes", {}) if isinstance(config_data, dict) else {}
        )

        options: list[tuple[str, str]] = []
        if purpose == "ai_now":
            options.append(("Inherit default provider/model", "__inherit__"))

        if isinstance(providers, dict):
            for pid, p in providers.items():
                if not isinstance(pid, str):
                    continue
                if not isinstance(p, dict):
                    p = {}
                self._provider_configs[pid] = p
                display_name = str(p.get("display_name") or pid)
                provider_type = str(p.get("provider_type") or pid)
                model_name = str(p.get("model") or "").strip()
                label = f"{display_name} (type={provider_type})"
                if model_name:
                    label += f" ({model_name})"
                options.append((label, pid))
        self._provider_options = options

        selected_provider: str = (
            str(config_data.get("active_provider") or "").strip()
            if isinstance(config_data, dict)
            else ""
        )
        selected_model = ""
        if isinstance(purposes, dict):
            this_purpose = purposes.get(purpose, {})
            if isinstance(this_purpose, dict):
                selected_provider = (
                    str(this_purpose.get("provider") or "").strip() or selected_provider
                )
                selected_model = str(this_purpose.get("model") or "").strip()

        if purpose == "ai_now" and not selected_provider:
            selected_provider = "__inherit__"

        valid_values = {v for _, v in self._provider_options}
        self._initial_provider = (
            selected_provider
            if selected_provider in valid_values
            else ("__inherit__" if purpose == "ai_now" else (next(iter(valid_values)) if valid_values else "openai"))
        )
        self._initial_model = selected_model

    def compose(self) -> ComposeResult:
        with Vertical():
            title = "SET AGENTS PURPOSE" if self.purpose == "ai_now" else "SET DEFAULT PURPOSE"
            yield Static(title, classes="modal-title")
            yield Static("Provider:", classes="field-label")
            yield Select(self._provider_options, value=self._initial_provider, id="purpose-provider-select")
            yield Static("Model override (optional):", classes="field-label")
            yield Input(
                placeholder="Leave empty to use selected provider default model",
                id="purpose-model-input",
            )
            yield Button("Save Purpose Selection", id="btn-save-purpose-selection", variant="primary")
            yield Static("Press Enter on model field or click Save  |  Esc to cancel", classes="hint")

    def on_mount(self) -> None:
        model_input = self.query_one("#purpose-model-input", Input)
        model_input.value = self._initial_model

    async def _save_purpose(self) -> None:
        provider_value = self.query_one("#purpose-provider-select", Select).value
        provider = provider_value.strip() if isinstance(provider_value, str) else ""
        model = self.query_one("#purpose-model-input", Input).value.strip()

        if self.purpose == "ai_now" and provider == "__inherit__":
            result = await self.api_client.set_remote_llm_purpose("ai_now")
            self.dismiss(result)
            return

        payload_provider = provider or None
        payload_model = model if model else None
        result = await self.api_client.set_remote_llm_purpose(
            self.purpose, payload_provider, payload_model
        )
        self.dismiss(result)

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "purpose-model-input":
            await self._save_purpose()

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-save-purpose-selection":
            await self._save_purpose()

    def action_cancel(self) -> None:
        self.dismiss(None)


# =============================================================================
# Main Settings Screen
# =============================================================================


class SettingsScreen(VerticalScroll):
    """Screen for managing settings and configuration."""

    DEFAULT_CSS = """
    SettingsScreen {
        padding: 1 2;
    }

    SettingsScreen > .section-title {
        text-style: bold;
        color: $primary;
        margin-top: 1;
        padding: 0 1;
    }

    SettingsScreen > .setting {
        padding: 0 2;
        color: $text;
    }

    SettingsScreen > .setting-muted {
        padding: 0 2;
        color: $text-muted;
    }

    SettingsScreen > .key-group {
        margin-top: 1;
        padding: 0 2;
        color: $secondary;
    }

    SettingsScreen > .about-text {
        padding: 0 2;
        color: $primary;
    }

    SettingsScreen Rule {
        margin: 1 0;
        color: $boost;
    }

    SettingsScreen > .status-row {
        padding: 0 2;
        height: auto;
    }

    SettingsScreen > .status-row > Static {
        width: auto;
    }

    SettingsScreen > .status-row > Button {
        min-width: 12;
        margin-left: 2;
    }

    SettingsScreen > .action-button {
        margin: 0 2;
        min-width: 16;
    }

    SettingsScreen > .success-text {
        padding: 0 2;
        color: $success;
    }

    SettingsScreen > .warning-text {
        padding: 0 2;
        color: $warning;
    }

    SettingsScreen > .error-text {
        padding: 0 2;
        color: $error;
    }
    """

    def __init__(self, api_client: ApiClient, **kwargs) -> None:
        super().__init__(**kwargs)
        self.api_client = api_client

    def compose(self) -> ComposeResult:
        yield Static("◈ SETTINGS", classes="section-title")
        yield Rule()

        # --- Connection ---
        yield Static("◇ CONNECTION", classes="section-title")
        yield Static(f"API URL: {self.api_client.base_url}", classes="setting")
        yield Static("Status: ◌ checking...", id="server-status", classes="setting")

        yield Rule()

        # --- License ---
        yield Static("◇ LICENSE", classes="section-title")
        yield Static("Tier: ◌ checking...", id="license-tier", classes="setting")
        yield Static("", id="license-email", classes="setting")
        yield Static("", id="license-activation", classes="setting")
        yield Static("", id="license-device-id", classes="setting-muted")
        yield Button("Activate License", id="btn-activate-license", variant="primary", classes="action-button")
        yield Button("Deactivate", id="btn-deactivate-license", variant="error", classes="action-button", disabled=True)
        yield Static("", id="license-action-status", classes="setting-muted")

        yield Rule()

        # --- LLM Providers ---
        yield Static("◇ LLM PROVIDERS", classes="section-title")
        yield Static(
            "Configure remote LLM providers for AI features (Knowledge Agent, insights, etc.).",
            classes="setting-muted",
        )
        yield Static("Provider: ◌ checking...", id="llm-provider-status", classes="setting")
        yield Static("", id="llm-model-status", classes="setting")
        yield Static("", id="llm-purpose-status", classes="setting-muted")
        yield Static("", id="llm-providers-list", classes="setting-muted")
        yield Button("Configure Provider", id="btn-config-provider", variant="primary", classes="action-button")
        yield Button("Set Default Provider", id="btn-set-default-provider", variant="default", classes="action-button", disabled=True)
        yield Button("Set Agents Purpose", id="btn-set-agents-purpose", variant="default", classes="action-button", disabled=True)
        yield Button("Test Connection", id="btn-test-llm", variant="default", classes="action-button", disabled=True)
        yield Static("", id="llm-action-status", classes="setting-muted")

        yield Rule()

        # --- Search Index ---
        yield Static("◇ SEARCH INDEX", classes="section-title")
        yield Static(
            "Hybrid search uses semantic embeddings for better results.",
            classes="setting-muted",
        )
        yield Static("Embedding Model: ◌ checking...", id="bge-m3-status", classes="setting")
        yield Static("Local LLM: ◌ checking...", id="local-llm-status", classes="setting")
        yield Static("Search Index: ◌ checking...", id="search-index-status", classes="setting")
        yield Button("Verify Models", id="btn-verify-models", variant="default", classes="action-button")
        yield Button("Download Model", id="btn-install-bge-m3", variant="primary", classes="action-button", disabled=True)
        yield Button("Rebuild Index", id="btn-reindex", variant="default", classes="action-button", disabled=True)
        yield Static("", id="search-action-status", classes="setting-muted")

        yield Rule()

        # --- Knowledge Processing ---
        yield Static("◇ KNOWLEDGE PROCESSING", classes="section-title")
        yield Static(
            "Background intelligence features (require LLM provider).",
            classes="setting-muted",
        )
        yield Static("◌ loading...", id="kp-settings-display", classes="setting")
        yield Button("Toggle Background Intelligence", id="btn-toggle-bg-intel", variant="default", classes="action-button")
        yield Button("Toggle Daily Briefing", id="btn-toggle-briefing", variant="default", classes="action-button")
        yield Button("Toggle KG Extraction", id="btn-toggle-kg-extract", variant="default", classes="action-button")
        yield Button("Toggle Community Detection", id="btn-toggle-community", variant="default", classes="action-button")
        yield Button("Toggle Crystallization", id="btn-toggle-crystal", variant="default", classes="action-button")
        yield Button("Toggle Insight Detection", id="btn-toggle-insight", variant="default", classes="action-button")
        yield Static("", id="kp-action-status", classes="setting-muted")

        yield Rule()

        # --- Token Budget ---
        yield Static("◇ TOKEN BUDGET", classes="section-title")
        yield Static(
            "Limit token usage for background intelligence tasks.",
            classes="setting-muted",
        )
        yield Static("◌ loading...", id="budget-display", classes="setting")
        yield Static("", id="budget-action-status", classes="setting-muted")

        yield Rule()

        # --- Keyboard Shortcuts ---
        yield Static("◇ KEYBOARD SHORTCUTS", classes="section-title")

        yield Static("◇ Navigation", classes="key-group")
        yield Static("  1-5       Switch between tabs", classes="setting-muted")
        yield Static("  /         Focus search input", classes="setting-muted")
        yield Static("  ?         Show help overlay", classes="setting-muted")
        yield Static("  q         Quit application", classes="setting-muted")

        yield Static("◇ Lists", classes="key-group")
        yield Static("  j / Down  Move down in list", classes="setting-muted")
        yield Static("  k / Up    Move up in list", classes="setting-muted")
        yield Static("  Enter     Select / Open item", classes="setting-muted")
        yield Static("  Esc       Go back / Close", classes="setting-muted")

        yield Static("◇ Memories", classes="key-group")
        yield Static("  a         Add new memory", classes="setting-muted")
        yield Static("  e         Edit selected memory", classes="setting-muted")
        yield Static("  c         Copy memory content", classes="setting-muted")
        yield Static("  d         Delete selected memory", classes="setting-muted")
        yield Static("  r         Refresh list", classes="setting-muted")

        yield Static("◇ Detail Views", classes="key-group")
        yield Static("  c         Copy content to clipboard", classes="setting-muted")
        yield Static("  y         Copy ID to clipboard", classes="setting-muted")

        yield Static("◇ Threads", classes="key-group")
        yield Static("  d         Distill to memories", classes="setting-muted")
        yield Static("  x         Delete thread", classes="setting-muted")
        yield Static("  r         Refresh list", classes="setting-muted")

        yield Static("◇ Graph", classes="key-group")
        yield Static("  e         Expand all nodes", classes="setting-muted")
        yield Static("  c         Collapse all nodes", classes="setting-muted")
        yield Static("  r         Refresh graph", classes="setting-muted")

        yield Rule()
        yield Static("◇ ABOUT", classes="section-title")
        yield Static("◈ Nowledge Mem", classes="about-text")
        yield Static("  AI that remembers your world", classes="setting-muted")
        yield Static(
            "  TUI built with Textual (textual.textualize.io)", classes="setting-muted"
        )
        yield Static("  Your data stays only on your device.", classes="setting-muted")

    def on_mount(self) -> None:
        self.run_worker(self._check_status(), exclusive=True, thread=False)
        self.run_worker(self._check_search_index_status(), exclusive=False, thread=False)
        self.run_worker(self._check_license_status(), exclusive=False, thread=False)
        self.run_worker(self._check_llm_status(), exclusive=False, thread=False)
        self.run_worker(self._check_kp_settings(), exclusive=False, thread=False)
        self.run_worker(self._check_budget_status(), exclusive=False, thread=False)

    # =========================================================================
    # Status checks
    # =========================================================================

    async def _check_status(self) -> None:
        try:
            health = await self.api_client.get_health()
            status = health.get("status", "unknown")
            version = health.get("version", "unknown")

            status_widget = self.query_one("#server-status", Static)
            if status == "ok":
                status_widget.update(f"Status: ● Online (v{version})")
            else:
                status_widget.update(f"Status: ○ {status}")
        except Exception as e:
            self.query_one("#server-status", Static).update(f"Status: ✗ Error - {e}")

    async def _check_license_status(self) -> None:
        try:
            data = await self.api_client.get_license_status()
            if "error" in data:
                self.query_one("#license-tier", Static).update(f"Tier: ✗ {data['error']}")
                return

            tier = data.get("tier", "free")
            email = data.get("email", "")
            activated = data.get("is_device_activated", False)
            activation_status = data.get("activation_status", "not_activated")
            device_id = data.get("device_id", "")

            tier_display = "● Pro" if tier == "pro" else "○ Free"
            self.query_one("#license-tier", Static).update(f"Tier: {tier_display}")

            if email:
                self.query_one("#license-email", Static).update(f"Email: {email}")

            act_icon = "●" if activated else "○"
            self.query_one("#license-activation", Static).update(
                f"Activation: {act_icon} {activation_status}"
            )

            if device_id:
                self.query_one("#license-device-id", Static).update(
                    f"Device: {device_id[:16]}..."
                )

            # Enable/disable buttons based on state
            activate_btn = self.query_one("#btn-activate-license", Button)
            deactivate_btn = self.query_one("#btn-deactivate-license", Button)
            if tier == "pro":
                activate_btn.disabled = True
                activate_btn.label = "Licensed"
                activate_btn.variant = "success"
                deactivate_btn.disabled = False
            else:
                activate_btn.disabled = False
                activate_btn.label = "Activate License"
                activate_btn.variant = "primary"
                deactivate_btn.disabled = True

        except Exception as e:
            try:
                self.query_one("#license-tier", Static).update(f"Tier: ✗ Error - {e}")
            except Exception:
                pass

    async def _check_llm_status(self) -> None:
        try:
            data = await self.api_client.get_remote_llm_config()
            if "error" in data:
                self.query_one("#llm-provider-status", Static).update(
                    f"Provider: ✗ {data['error']}"
                )
                self.query_one("#btn-test-llm", Button).disabled = True
                self.query_one("#btn-set-default-provider", Button).disabled = True
                self.query_one("#btn-set-agents-purpose", Button).disabled = True
                return

            enabled = data.get("enabled", False)
            active = data.get("active_provider", "")
            model = data.get("model", "")
            has_key = data.get("has_api_key", False)
            purposes = data.get("purposes", {})

            if enabled and active:
                key_str = "● key set" if has_key else "○ no key"
                self.query_one("#llm-provider-status", Static).update(
                    f"Provider: ● {active} ({key_str})"
                )
                self.query_one("#llm-model-status", Static).update(
                    f"Model: {model}" if model else ""
                )
                self.query_one("#btn-test-llm", Button).disabled = not has_key
            else:
                self.query_one("#llm-provider-status", Static).update(
                    "Provider: ○ Not configured"
                )
                self.query_one("#btn-test-llm", Button).disabled = True

            # Show provider list summary
            providers = data.get("providers", {})
            if providers:
                names = [
                    f"{p.get('display_name') or pid}"
                    + (" [key]" if p.get("has_api_key") else "")
                    for pid, p in providers.items()
                ]
                self.query_one("#llm-providers-list", Static).update(
                    f"Configured: {', '.join(names)}"
                )
                self.query_one("#btn-set-default-provider", Button).disabled = False
                self.query_one("#btn-set-agents-purpose", Button).disabled = False
            else:
                self.query_one("#llm-providers-list", Static).update(
                    "Configured: none"
                )
                self.query_one("#btn-set-default-provider", Button).disabled = True
                self.query_one("#btn-set-agents-purpose", Button).disabled = True

            if isinstance(purposes, dict):
                default_info = purposes.get("default", {})
                agents_info = purposes.get("ai_now", {})
                d_provider = (
                    default_info.get("effective_provider", "")
                    if isinstance(default_info, dict)
                    else ""
                )
                d_model = (
                    default_info.get("effective_model", "")
                    if isinstance(default_info, dict)
                    else ""
                )
                a_provider = (
                    agents_info.get("effective_provider", "")
                    if isinstance(agents_info, dict)
                    else ""
                )
                a_model = (
                    agents_info.get("effective_model", "")
                    if isinstance(agents_info, dict)
                    else ""
                )
                self.query_one("#llm-purpose-status", Static).update(
                    "Purposes: "
                    + f"default={d_provider}/{d_model or '-'}; "
                    + f"agents={a_provider}/{a_model or '-'}"
                )
            else:
                self.query_one("#llm-purpose-status", Static).update("")

        except Exception as e:
            try:
                self.query_one("#llm-provider-status", Static).update(
                    f"Provider: ✗ Error - {e}"
                )
            except Exception:
                pass

    @staticmethod
    def _render_state_text(state: str | None, exists_fallback: bool) -> str:
        normalized = state or ("ready" if exists_fallback else "not_installed")
        if normalized == "ready":
            return "● ready"
        if normalized == "installed_unverified":
            return "◐ installed (unverified)"
        if normalized == "corrupted":
            return "✗ corrupted"
        if normalized == "unsupported":
            return "○ unsupported"
        return "○ not installed"

    async def _check_search_index_status(
        self,
        *,
        full_verify: bool = False,
        force_refresh: bool = False,
    ) -> dict[str, Any]:
        """Check embedding model and search index status."""
        try:
            models_status = await self.api_client.get_models_status(
                full_verify=full_verify,
                force_refresh=force_refresh,
            )
            model_status = await self.api_client.get_bge_m3_status(
                full_verify=full_verify,
                force_refresh=force_refresh,
            )
            model_widget = self.query_one("#bge-m3-status", Static)
            llm_widget = self.query_one("#local-llm-status", Static)
            install_btn = self.query_one("#btn-install-bge-m3", Button)
            reindex_btn = self.query_one("#btn-reindex", Button)
            verify_btn = self.query_one("#btn-verify-models", Button)

            model_name = model_status.get("model_name", "Embedding Model")
            size_mb = model_status.get("size_mb", 500)
            search_state = model_status.get("state")

            if model_status.get("error"):
                model_widget.update(f"Embedding Model: ✗ Error - {model_status['error']}")
                install_btn.disabled = True
                verify_btn.disabled = False
            elif search_state == "corrupted":
                model_widget.update(f"Embedding Model: ✗ {model_name} (corrupted)")
                install_btn.disabled = False
                install_btn.label = "Reinstall"
                install_btn.variant = "error"
            elif model_status.get("exists"):
                state_text = self._render_state_text(search_state, True)
                model_widget.update(f"Embedding Model: {state_text} {model_name} (~{size_mb}MB)")
                install_btn.disabled = True
                install_btn.label = "Installed"
                install_btn.variant = "success"
            else:
                state_text = self._render_state_text(search_state, False)
                model_widget.update(f"Embedding Model: {state_text} {model_name} (~{size_mb}MB)")
                install_btn.disabled = False
                install_btn.label = "Download Model"
                install_btn.variant = "primary"

            local_state = models_status.get("model_states", {}).get("local_llm", {})
            local_state_name = local_state.get("model_name", "Local LLM")
            local_state_text = self._render_state_text(
                local_state.get("state"),
                bool(models_status.get("local_llm", False)),
            )
            if models_status.get("error"):
                llm_widget.update(f"Local LLM: ✗ Error - {models_status['error']}")
            else:
                llm_widget.update(f"Local LLM: {local_state_text} {local_state_name}")
            verify_btn.disabled = False

            index_status = await self.api_client.get_search_index_status()
            index_widget = self.query_one("#search-index-status", Static)

            if index_status.get("error"):
                index_widget.update(f"Search Index: ✗ Error - {index_status['error']}")
                reindex_btn.disabled = True
            elif index_status.get("available"):
                index_widget.update("Search Index: ● Ready for hybrid search")
                reindex_btn.disabled = False
            elif index_status.get("model_cached"):
                index_widget.update("Search Index: ○ Model cached, index not initialized")
                reindex_btn.disabled = False
            else:
                index_widget.update(f"Search Index: ○ {model_name} required")
                reindex_btn.disabled = True

            return {
                "models_status": models_status,
                "search_model_status": model_status,
                "index_status": index_status,
            }
        except Exception as e:
            try:
                self.query_one("#bge-m3-status", Static).update(f"Embedding Model: ✗ Error - {e}")
                self.query_one("#local-llm-status", Static).update(f"Local LLM: ✗ Error - {e}")
                self.query_one("#search-index-status", Static).update(f"Search Index: ✗ Error - {e}")
            except Exception:
                pass
            return {"error": str(e)}

    async def _check_kp_settings(self) -> None:
        """Load knowledge processing settings."""
        try:
            data = await self.api_client.get_knowledge_processing_settings()
            if "error" in data:
                self.query_one("#kp-settings-display", Static).update(
                    f"✗ {data['error']}"
                )
                return

            settings = data.get("settings", {})
            self._render_kp_settings(settings)
        except Exception as e:
            try:
                self.query_one("#kp-settings-display", Static).update(f"✗ Error - {e}")
            except Exception:
                pass

    def _render_kp_settings(self, settings: dict[str, Any]) -> None:
        """Render knowledge processing settings display."""
        toggles = [
            ("backgroundIntelligence", "Background Intelligence"),
            ("autoDailyBriefing", "Daily Briefing"),
            ("autoKGExtraction", "KG Extraction"),
            ("autoCommunityDetection", "Community Detection"),
            ("autoCrystallization", "Crystallization"),
            ("autoInsightDetection", "Insight Detection"),
        ]
        lines = []
        for key, label in toggles:
            val = settings.get(key, False)
            icon = "●" if val else "○"
            lines.append(f"  {icon} {label}")

        hour = settings.get("briefingHour", 5)
        lines.append(f"  Briefing Hour: {hour}:00")

        self.query_one("#kp-settings-display", Static).update("\n".join(lines))

    async def _check_budget_status(self) -> None:
        """Load token budget status from agent."""
        try:
            # Get current limits from settings
            kp_data = await self.api_client.get_knowledge_processing_settings()
            settings = kp_data.get("settings", {})
            max_hour = settings.get("maxTokensPerHour", 500_000)
            max_day = settings.get("maxTokensPerDay", 2_000_000)
            max_task = settings.get("maxTokensPerTask", 500_000)

            # Get current usage from agent status
            agent_data = await self.api_client.get_agent_status()
            tokens_hour = agent_data.get("tokens_this_hour", 0)
            tokens_day = agent_data.get("tokens_today", 0)
            paused = agent_data.get("budget_paused", False)

            self._render_budget(tokens_hour, tokens_day, max_hour, max_day, max_task, paused)
        except Exception as e:
            try:
                self.query_one("#budget-display", Static).update(f"✗ Error - {e}")
            except Exception:
                pass

    @staticmethod
    def _format_tokens(n: int) -> str:
        if n >= 1_000_000:
            return f"{n / 1_000_000:.1f}M"
        if n >= 1_000:
            return f"{n / 1_000:.0f}K"
        return str(n)

    def _render_budget(
        self,
        tokens_hour: int,
        tokens_day: int,
        max_hour: int,
        max_day: int,
        max_task: int,
        paused: bool,
    ) -> None:
        fmt = self._format_tokens
        lines = [
            f"  Hourly:   {fmt(tokens_hour)} / {fmt(max_hour)}",
            f"  Daily:    {fmt(tokens_day)} / {fmt(max_day)}",
            f"  Per Task: {fmt(max_task) if max_task > 0 else '∞'}",
        ]
        if paused:
            lines.append("  ✗ Budget exceeded — background tasks paused")

        # Show editable hint
        lines.append("")
        lines.append("  Set via: nmem config settings set maxTokensPerHour <value>")
        lines.append("           nmem config settings set maxTokensPerDay <value>")
        lines.append("           nmem config settings set maxTokensPerTask <value>")

        self.query_one("#budget-display", Static).update("\n".join(lines))

    # =========================================================================
    # Button handlers
    # =========================================================================

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        button_id = event.button.id

        # Search index buttons
        if button_id == "btn-verify-models":
            status_widget = self.query_one("#search-action-status", Static)
            await self._verify_models(status_widget)
        elif button_id == "btn-install-bge-m3":
            status_widget = self.query_one("#search-action-status", Static)
            await self._install_bge_m3(status_widget)
        elif button_id == "btn-reindex":
            status_widget = self.query_one("#search-action-status", Static)
            await self._reindex_search_index(status_widget)

        # License buttons
        elif button_id == "btn-activate-license":
            self.app.push_screen(
                LicenseActivateModal(self.api_client),
                callback=self._on_license_activate_result,
            )
        elif button_id == "btn-deactivate-license":
            result = await self.api_client.deactivate_license()
            status_widget = self.query_one("#license-action-status", Static)
            if result.get("success"):
                status_widget.update("License deactivated.")
            else:
                status_widget.update(f"✗ {result}")
            await self._check_license_status()

        # LLM provider buttons
        elif button_id == "btn-config-provider":
            config_data = await self.api_client.get_remote_llm_config()
            self.app.push_screen(
                ProviderConfigModal(self.api_client, config_data=config_data),
                callback=self._on_provider_config_result,
            )
        elif button_id == "btn-set-default-provider":
            config_data = await self.api_client.get_remote_llm_config()
            self.app.push_screen(
                PurposeConfigModal(self.api_client, config_data, purpose="default"),
                callback=self._on_purpose_config_result,
            )
        elif button_id == "btn-set-agents-purpose":
            config_data = await self.api_client.get_remote_llm_config()
            self.app.push_screen(
                PurposeConfigModal(self.api_client, config_data, purpose="ai_now"),
                callback=self._on_purpose_config_result,
            )
        elif button_id == "btn-test-llm":
            status_widget = self.query_one("#llm-action-status", Static)
            status_widget.update("Testing connection...")
            test_btn = self.query_one("#btn-test-llm", Button)
            test_btn.disabled = True
            try:
                result = await self.api_client.test_remote_llm_connection()
                if result.get("success"):
                    provider = result.get("provider", "")
                    model = result.get("model", "")
                    status_widget.update(f"● Connection OK — {provider}/{model}")
                else:
                    status_widget.update(f"✗ {result.get('message', 'Test failed')}")
            except Exception as e:
                status_widget.update(f"✗ Error: {e}")
            finally:
                test_btn.disabled = False

        # Knowledge processing toggles
        elif button_id and button_id.startswith("btn-toggle-"):
            await self._handle_kp_toggle(button_id)

    async def _on_license_activate_result(self, result: dict | None) -> None:
        """Callback for license activation modal."""
        if result:
            status = result.get("status", "error")
            msg = result.get("message", "")
            status_widget = self.query_one("#license-action-status", Static)
            if status in ("activated", "verified_offline"):
                status_widget.update(f"● {msg}")
            else:
                status_widget.update(f"✗ {msg}")
            await self._check_license_status()

    async def _on_provider_config_result(self, result: dict | None) -> None:
        """Callback for provider configuration modal."""
        if result:
            status_widget = self.query_one("#llm-action-status", Static)
            if "error" in result:
                status_widget.update(f"✗ {result['error']}")
            else:
                status_widget.update("Provider configured.")
            await self._check_llm_status()

    async def _on_purpose_config_result(self, result: dict | None) -> None:
        """Callback for purpose configuration modal."""
        if result:
            status_widget = self.query_one("#llm-action-status", Static)
            if "error" in result:
                status_widget.update(f"✗ {result['error']}")
            else:
                status_widget.update("Purpose selection updated.")
            await self._check_llm_status()

    async def _handle_kp_toggle(self, button_id: str) -> None:
        """Toggle a knowledge processing setting."""
        toggle_map = {
            "btn-toggle-bg-intel": "backgroundIntelligence",
            "btn-toggle-briefing": "autoDailyBriefing",
            "btn-toggle-kg-extract": "autoKGExtraction",
            "btn-toggle-community": "autoCommunityDetection",
            "btn-toggle-crystal": "autoCrystallization",
            "btn-toggle-insight": "autoInsightDetection",
        }
        key = toggle_map.get(button_id)
        if not key:
            return

        status_widget = self.query_one("#kp-action-status", Static)

        # Get current value and flip it
        current = await self.api_client.get_knowledge_processing_settings()
        settings = current.get("settings", {})
        new_val = not settings.get(key, False)

        result = await self.api_client.update_knowledge_processing_settings({key: new_val})
        if "error" in result:
            status_widget.update(f"✗ {result['error']}")
        else:
            state = "on" if new_val else "off"
            status_widget.update(f"Set {key} = {state}")
            self._render_kp_settings(result.get("settings", {}))

    # =========================================================================
    # Existing action handlers
    # =========================================================================

    async def _verify_models(self, status_widget: Static) -> None:
        """Run full verification for built-in local models."""
        verify_btn = self.query_one("#btn-verify-models", Button)
        verify_btn.disabled = True
        verify_btn.label = "Verifying..."
        status_widget.update("Running full model verification...")
        try:
            status = await self._check_search_index_status(
                full_verify=True,
                force_refresh=True,
            )
            if "error" in status:
                status_widget.update(f"Verification failed: {status['error']}")
                return

            states = status.get("models_status", {}).get("model_states", {})
            corrupted = [
                model_id
                for model_id, state in states.items()
                if isinstance(state, dict) and state.get("state") == "corrupted"
            ]
            if corrupted:
                status_widget.update(
                    "Verification failed. Corrupted model(s): "
                    + ", ".join(corrupted)
                    + ". Reinstall required."
                )
            else:
                status_widget.update("Verification complete. Installed models look healthy.")
        except Exception as e:
            status_widget.update(f"Verification error: {e}")
        finally:
            verify_btn.label = "Verify Models"
            verify_btn.disabled = False

    async def _install_bge_m3(self, status_widget: Static) -> None:
        """Download and install embedding model."""
        try:
            install_btn = self.query_one("#btn-install-bge-m3", Button)
            install_btn.disabled = True
            install_btn.label = "Downloading..."
            status_widget.update("Downloading embedding model... This may take a few minutes.")

            result = await self.api_client.install_bge_m3()

            if result.get("success"):
                status_widget.update("Model installed successfully! Click 'Rebuild Index' to enable hybrid search.")
                install_btn.label = "Installed"
                install_btn.variant = "success"
                await self._check_search_index_status(full_verify=True, force_refresh=True)
            else:
                error_msg = result.get("error") or result.get("message", "Unknown error")
                status_widget.update(f"Installation failed: {error_msg}")
                install_btn.label = "Download Model"
                install_btn.disabled = False

        except Exception as e:
            status_widget.update(f"Installation error: {e}")
            try:
                install_btn = self.query_one("#btn-install-bge-m3", Button)
                install_btn.label = "Download Model"
                install_btn.disabled = False
            except Exception:
                pass

    async def _reindex_search_index(self, status_widget: Static) -> None:
        """Rebuild the search index."""
        try:
            reindex_btn = self.query_one("#btn-reindex", Button)
            reindex_btn.disabled = True
            reindex_btn.label = "Reindexing..."
            status_widget.update("Rebuilding search index... This may take a while for large databases.")

            result = await self.api_client.reindex_search_index()

            if result.get("success"):
                memories = result.get("memories", 0)
                messages = result.get("messages", 0)
                communities = result.get("communities", 0)
                entities = result.get("entities", 0)
                status_widget.update(
                    f"Reindex complete! Indexed {memories} memories, {messages} messages, "
                    f"{communities} communities, {entities} entities."
                )
                await self._check_search_index_status()
            else:
                error_msg = result.get("error") or result.get("message", "Unknown error")
                status_widget.update(f"Reindex failed: {error_msg}")

            reindex_btn.label = "Rebuild Index"
            reindex_btn.disabled = False

        except Exception as e:
            status_widget.update(f"Reindex error: {e}")
            try:
                reindex_btn = self.query_one("#btn-reindex", Button)
                reindex_btn.label = "Rebuild Index"
                reindex_btn.disabled = False
            except Exception:
                pass
