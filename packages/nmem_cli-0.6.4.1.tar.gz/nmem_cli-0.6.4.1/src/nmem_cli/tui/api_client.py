"""
Async HTTP client for the Nowledge Mem REST API.
"""

import os
from typing import Any
from urllib.parse import quote

import httpx

DEFAULT_API_URL = "http://127.0.0.1:14242"


class ApiClient:
    """Async HTTP client for communicating with the Nowledge Mem server."""

    def __init__(self, base_url: str | None = None):
        self.base_url = base_url or os.environ.get("NMEM_API_URL", DEFAULT_API_URL)
        api_key = os.environ.get("NMEM_API_KEY", "").strip()
        self._headers = (
            {
                "Authorization": f"Bearer {api_key}",
                "X-NMEM-API-Key": api_key,
            }
            if api_key
            else {}
        )
        self._cookies = {"nmem_api_key": api_key} if api_key else {}
        self._client: httpx.AsyncClient | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create the async HTTP client."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=30.0,
                headers=self._headers,
                cookies=self._cookies,
            )
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    # =========================================================================
    # Health & Status
    # =========================================================================

    async def get_health(self) -> dict[str, Any]:
        """Get server health status."""
        client = await self._get_client()
        try:
            response = await client.get("/health")
            response.raise_for_status()
            return response.json()
        except httpx.ConnectError:
            return {"status": "offline", "error": "Cannot connect to server"}
        except Exception as e:
            return {"status": "error", "error": str(e)}

    async def get_stats(self) -> dict[str, Any]:
        """Get database statistics."""
        client = await self._get_client()
        try:
            response = await client.get("/stats")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    # =========================================================================
    # Memories
    # =========================================================================

    async def list_memories(
        self,
        limit: int = 20,
        offset: int = 0,
        importance_min: float = 0.0,
    ) -> dict[str, Any]:
        """List memories with pagination."""
        client = await self._get_client()
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if importance_min > 0:
            params["importance_min"] = importance_min
        response = await client.get("/memories", params=params)
        response.raise_for_status()
        return response.json()

    async def search_memories(
        self,
        query: str,
        limit: int = 20,
        labels: list[str] | None = None,
        importance_min: float = 0.0,
        mode: str = "deep",
    ) -> dict[str, Any]:
        """Search memories with filters."""
        client = await self._get_client()
        params: dict[str, Any] = {"q": query, "limit": limit, "mode": mode}
        if labels:
            params["labels"] = labels
        if importance_min > 0:
            params["importance_min"] = importance_min
        response = await client.get("/memories/search", params=params)
        response.raise_for_status()
        return response.json()

    async def get_memory(self, memory_id: str) -> dict[str, Any]:
        """Get a single memory by ID."""
        client = await self._get_client()
        response = await client.get(f"/memories/{memory_id}")
        response.raise_for_status()
        return response.json()

    async def create_memory(
        self,
        content: str,
        title: str | None = None,
        importance: float = 0.5,
        source: str = "tui",
        labels: list[str] | None = None,
        event_start: str | None = None,
        event_end: str | None = None,
        temporal_context: str | None = None,
    ) -> dict[str, Any]:
        """Create a new memory."""
        client = await self._get_client()
        payload: dict[str, Any] = {
            "content": content,
            "importance": importance,
            "source": source,
        }
        if title:
            payload["title"] = title
        if labels:
            payload["labels"] = labels
        if event_start:
            payload["event_start"] = event_start
        if event_end:
            payload["event_end"] = event_end
        if temporal_context:
            payload["temporal_context"] = temporal_context
        response = await client.post("/memories", json=payload)
        response.raise_for_status()
        return response.json()

    async def delete_memory(self, memory_id: str) -> dict[str, Any]:
        """Delete a memory."""
        client = await self._get_client()
        response = await client.delete(f"/memories/{memory_id}")
        response.raise_for_status()
        return response.json()

    async def update_memory(
        self,
        memory_id: str,
        title: str | None = None,
        content: str | None = None,
        importance: float | None = None,
    ) -> dict[str, Any]:
        """Update a memory."""
        client = await self._get_client()
        payload: dict[str, Any] = {}
        if title is not None:
            payload["title"] = title
        if content is not None:
            payload["content"] = content
        if importance is not None:
            payload["importance"] = importance
        response = await client.patch(f"/memories/{memory_id}", json=payload)
        response.raise_for_status()
        return response.json()

    # =========================================================================
    # Threads
    # =========================================================================

    async def list_threads(self, limit: int = 20, offset: int = 0) -> dict[str, Any]:
        """List threads with pagination."""
        client = await self._get_client()
        params = {"limit": limit, "offset": offset}
        response = await client.get("/threads", params=params)
        response.raise_for_status()
        return response.json()

    async def search_threads(self, query: str, limit: int = 20) -> dict[str, Any]:
        """Search threads."""
        client = await self._get_client()
        params = {"query": query, "limit": limit}
        response = await client.get("/threads/search", params=params)
        response.raise_for_status()
        return response.json()

    async def get_thread(self, thread_id: str) -> dict[str, Any]:
        """Get a thread with messages."""
        client = await self._get_client()
        response = await client.get(f"/threads/{quote(thread_id, safe='')}")
        response.raise_for_status()
        return response.json()

    async def delete_thread(
        self, thread_id: str, cascade: bool = False
    ) -> dict[str, Any]:
        """Delete a thread."""
        client = await self._get_client()
        params = {"cascade_delete_memories": cascade}
        response = await client.delete(f"/threads/{quote(thread_id, safe='')}", params=params)
        response.raise_for_status()
        return response.json()

    # =========================================================================
    # Graph
    # =========================================================================

    async def search_graph(
        self, query: str, limit: int = 30, depth: int = 2
    ) -> dict[str, Any]:
        """Search the knowledge graph."""
        client = await self._get_client()
        params = {"query": query, "limit": limit, "depth": depth}
        response = await client.get("/graph/search", params=params)
        response.raise_for_status()
        return response.json()

    async def get_graph_sample(
        self, limit: int = 100, depth: int = 1
    ) -> dict[str, Any]:
        """Get a sample of the graph for visualization."""
        client = await self._get_client()
        params = {"limit": limit, "depth": depth}
        response = await client.get("/graph/sample", params=params)
        response.raise_for_status()
        return response.json()

    async def get_graph_analysis(self) -> dict[str, Any]:
        """Get graph analysis including communities and centrality."""
        client = await self._get_client()
        response = await client.get("/graph/analysis")
        response.raise_for_status()
        return response.json()

    # =========================================================================
    # Labels
    # =========================================================================

    async def list_labels(self) -> list[dict[str, Any]]:
        """List all labels."""
        client = await self._get_client()
        response = await client.get("/labels")
        response.raise_for_status()
        data = response.json()
        return data.get("labels", [])

    # =========================================================================
    # Models Management
    # =========================================================================

    async def get_models_status(
        self,
        *,
        full_verify: bool = False,
        force_refresh: bool = False,
    ) -> dict[str, Any]:
        """Get status of all cached models (embedding, LLM, search)."""
        client = await self._get_client()
        try:
            params: dict[str, Any] = {}
            if full_verify:
                params["full_verify"] = True
            if force_refresh:
                params["force_refresh"] = True
            response = await client.get("/models/status", params=params or None)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    async def get_bge_m3_status(
        self,
        *,
        full_verify: bool = False,
        force_refresh: bool = False,
    ) -> dict[str, Any]:
        """Get status of search embedding model for hybrid search.

        Platform-specific: Qwen3-Embedding on macOS, BGE-M3 on Windows/Linux.
        """
        client = await self._get_client()
        try:
            params: dict[str, Any] = {}
            if full_verify:
                params["full_verify"] = True
            if force_refresh:
                params["force_refresh"] = True
            response = await client.get("/models/bge-m3/status", params=params or None)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    async def install_bge_m3(
        self, force_reinstall: bool = False
    ) -> dict[str, Any]:
        """Download and install the search embedding model for hybrid search.

        Platform-specific: Qwen3-Embedding on macOS, BGE-M3 on Windows/Linux.
        """
        client = await self._get_client()
        try:
            response = await client.post(
                "/models/bge-m3/install",
                json={"force_reinstall": force_reinstall},
                timeout=600.0,  # 10 minute timeout for model download
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"success": False, "error": str(e)}

    # =========================================================================
    # Search Index Management
    # =========================================================================

    async def get_search_index_status(self) -> dict[str, Any]:
        """Get status of the search index (LanceDB + embeddings)."""
        client = await self._get_client()
        try:
            response = await client.get("/search-index/status")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"available": False, "error": str(e)}

    async def reindex_search_index(self) -> dict[str, Any]:
        """Rebuild the search index from Kuzu database.

        This reindexes all memories, messages, communities, and entities.
        It can take a while for large databases.
        """
        client = await self._get_client()
        try:
            response = await client.post(
                "/search-index/reindex",
                timeout=600.0,  # 10 minute timeout for reindex
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"success": False, "error": str(e)}

    # =========================================================================
    # License Management
    # =========================================================================

    async def get_license_status(self) -> dict[str, Any]:
        """Get current license status."""
        client = await self._get_client()
        try:
            response = await client.get("/api/license/status")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    async def activate_license(
        self,
        license_code: str,
        email: str,
        device_name: str | None = None,
    ) -> dict[str, Any]:
        """Activate a license key."""
        client = await self._get_client()
        try:
            payload: dict[str, Any] = {"license_code": license_code, "email": email}
            if device_name:
                payload["device_name"] = device_name
            response = await client.post(
                "/api/license/activate",
                json=payload,
                timeout=30.0,
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"status": "error", "message": str(e)}

    async def deactivate_license(self) -> dict[str, Any]:
        """Deactivate the current license."""
        client = await self._get_client()
        try:
            response = await client.post("/api/license/deactivate")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def renew_license(self) -> dict[str, Any]:
        """Renew device authorization."""
        client = await self._get_client()
        try:
            response = await client.post("/api/license/renew", timeout=30.0)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"success": False, "message": str(e)}

    # =========================================================================
    # Remote LLM Configuration
    # =========================================================================

    async def get_remote_llm_config(self) -> dict[str, Any]:
        """Get current remote LLM configuration."""
        client = await self._get_client()
        try:
            response = await client.get("/remote-llm/config")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    async def update_remote_llm_config(self, config: dict[str, Any]) -> dict[str, Any]:
        """Update remote LLM configuration."""
        client = await self._get_client()
        try:
            response = await client.post("/remote-llm/config", json=config)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    async def test_remote_llm_connection(self) -> dict[str, Any]:
        """Test connection to the configured remote LLM."""
        client = await self._get_client()
        try:
            response = await client.post("/remote-llm/test", timeout=60.0)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"success": False, "message": str(e)}

    async def test_remote_llm_connection_with_config(
        self, config: dict[str, Any]
    ) -> dict[str, Any]:
        """Test connection with a transient config (test-before-save)."""
        client = await self._get_client()
        try:
            response = await client.post(
                "/remote-llm/test/with-config", json=config, timeout=60.0
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"success": False, "message": str(e)}

    async def list_remote_llm_models(
        self, provider: str | None = None
    ) -> dict[str, Any]:
        """List available models for a provider."""
        client = await self._get_client()
        try:
            params = {}
            if provider:
                params["provider"] = provider
            response = await client.get("/remote-llm/models", params=params)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"success": False, "models": [], "message": str(e)}

    async def activate_remote_llm_provider(self, provider: str) -> dict[str, Any]:
        """Activate a specific LLM provider."""
        client = await self._get_client()
        try:
            response = await client.post(
                "/remote-llm/activate", json={"provider": provider}
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    async def set_remote_llm_purpose(
        self, purpose: str, provider: str | None = None, model: str | None = None
    ) -> dict[str, Any]:
        """Set purpose-specific provider/model selection."""
        client = await self._get_client()
        payload: dict[str, Any] = {"purpose": purpose}
        if provider is not None:
            payload["provider"] = provider
        if model is not None:
            payload["model"] = model
        try:
            response = await client.post("/remote-llm/purpose", json=payload)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    # =========================================================================
    # App Settings / Knowledge Processing
    # =========================================================================

    async def get_knowledge_processing_settings(self) -> dict[str, Any]:
        """Get knowledge processing settings."""
        client = await self._get_client()
        try:
            response = await client.get("/settings/knowledge-processing")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    async def update_knowledge_processing_settings(
        self, settings: dict[str, Any]
    ) -> dict[str, Any]:
        """Update knowledge processing settings (partial update)."""
        client = await self._get_client()
        try:
            response = await client.post(
                "/settings/knowledge-processing", json=settings
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    async def get_agent_status(self) -> dict[str, Any]:
        """Get Knowledge Agent status including token budget info."""
        client = await self._get_client()
        try:
            response = await client.get("/agent/status")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}
