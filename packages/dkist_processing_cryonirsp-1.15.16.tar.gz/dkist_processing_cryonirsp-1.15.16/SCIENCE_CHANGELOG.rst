v1.8.0 (2025-06-16)
===================

Misc
----

- Update the beam alignment code to handle edge effects in determining the shift required to align beams one and two. The final spectra passed to the cross correlation method are now cropped by removing the outside 10% of pixels on each edge. (`#195 <https://bitbucket.org/dkistdc/dkist-processing-cryonirsp/pull-requests/195>`__)


v1.0.0 (2024-08-21)
===================

Misc
----

- CRYO-NIRSP processing pipeline data accepted for release to the community.


v0.0.1 (2023-08-25)
===================

Misc
----

- Initial release of pipeline for science review
