"""deeprepo — Deep codebase intelligence powered by recursive multi-model orchestration."""

__version__ = "0.2.1"
