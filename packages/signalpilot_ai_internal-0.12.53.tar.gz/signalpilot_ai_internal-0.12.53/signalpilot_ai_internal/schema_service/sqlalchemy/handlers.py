"""Unified schema handlers for PostgreSQL, MySQL, and Databricks.

Uses schema-search v3 package for schema extraction with catalog/schema filtering.
"""

import logging
import warnings
from pathlib import Path
from typing import Any, Dict, List, Optional

from schema_search import SchemaSearch
from sqlalchemy import create_engine, text

# Suppress Databricks connector warnings
warnings.filterwarnings("ignore", message=".*pyarrow is not installed.*")
warnings.filterwarnings("ignore", message=".*_user_agent_entry.*deprecated.*")
logging.getLogger("databricks.sql.client").setLevel(logging.ERROR)
logging.getLogger("databricks.sql.session").setLevel(logging.ERROR)

from signalpilot_ai_internal.db_config.factory import build_url, detect_db_type
from signalpilot_ai_internal.schema_service.base.formatters import ResponseFormatter
from signalpilot_ai_internal.schema_service.base.handlers import BaseQueryHandler, BaseSchemaHandler
from signalpilot_ai_internal.schema_service.base.package_manager import PackageManager


CONFIG_PATH = Path(__file__).parents[1] / "schema_search_config.yml"

DB_TITLES = {
    "postgresql": "PostgreSQL",
    "mysql": "MySQL",
    "databricks": "Databricks",
}


class SQLAlchemySchemaHandler(BaseSchemaHandler):
    """Unified schema handler for PostgreSQL, MySQL, and Databricks using schema-search v3."""

    db_type = "postgresql"

    def _get_config(self, body: Dict) -> Optional[Dict]:
        """Get config, detecting type from URL or explicit type field."""
        config = super()._get_config(body)
        if not config:
            return None

        if "type" in config:
            self.db_type = config["type"]
        elif "connectionUrl" in config:
            self.db_type = detect_db_type(config["connectionUrl"])
            config["type"] = self.db_type

        return config

    def extract_schema(self, config: Dict) -> Dict[str, Any]:
        """Extract schema using schema-search v3 with optional catalog/schema filters."""
        db_type = config.get("type", "postgresql")
        url = build_url(config)

        PackageManager.ensure_installed(db_type)

        connect_args = {"user_agent_entry": "signalpilot"} if db_type == "databricks" else {}
        engine = create_engine(url, connect_args=connect_args)
        try:
            searcher = SchemaSearch(engine=engine, config_path=str(CONFIG_PATH))
            searcher.index(force=False)

            catalogs = [config["catalog"]] if config.get("catalog") else None
            schemas = [config["schema"]] if config.get("schema") else None
            db_schema = searcher.get_schema(catalogs=catalogs, schemas=schemas)

            flat_schemas = {}
            for schema_key, tables in db_schema.items():
                for table_name, table_schema in tables.items():
                    full_name = f"{schema_key}.{table_name}"
                    flat_schemas[full_name] = table_schema

            title = DB_TITLES.get(db_type, db_type.title())
            return ResponseFormatter.schema_response(flat_schemas, title)
        finally:
            engine.dispose()


class SQLAlchemyQueryHandler(BaseQueryHandler):
    """Query handler for PostgreSQL, MySQL, and Databricks."""

    db_type = "postgresql"

    def _get_config(self, body: Dict) -> Optional[Dict]:
        """Get config, detecting type from URL or explicit type field."""
        config = super()._get_config(body)
        if not config:
            return None

        if "type" in config:
            self.db_type = config["type"]
        elif "connectionUrl" in config:
            self.db_type = detect_db_type(config["connectionUrl"])
            config["type"] = self.db_type

        return config

    def execute_query(self, config: Dict, query: str) -> List[Dict[str, Any]]:
        """Execute query using SQLAlchemy."""
        db_type = config.get("type", "postgresql")
        url = build_url(config)

        PackageManager.ensure_installed(db_type)

        connect_args = {"user_agent_entry": "signalpilot"} if db_type == "databricks" else {}
        engine = create_engine(url, connect_args=connect_args)
        try:
            with engine.connect() as conn:
                result = conn.execute(text(query))
                return [dict(row._mapping) for row in result]
        finally:
            engine.dispose()


UnifiedDatabaseSchemaHandler = SQLAlchemySchemaHandler
UnifiedDatabaseQueryHandler = SQLAlchemyQueryHandler
