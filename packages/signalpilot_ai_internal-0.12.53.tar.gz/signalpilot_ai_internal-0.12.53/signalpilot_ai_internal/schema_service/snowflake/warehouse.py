"""Snowflake warehouse management."""

from typing import Dict, List, Optional

from signalpilot_ai_internal.schema_service.base.constants import SNOWFLAKE_SIZE_ORDER


class WarehouseManager:
    """Manage Snowflake warehouse selection and lifecycle."""

    @staticmethod
    def _size_rank(size: Optional[str]) -> int:
        """Get numeric rank of a warehouse size."""
        s = (size or "").upper()
        if s in SNOWFLAKE_SIZE_ORDER:
            return SNOWFLAKE_SIZE_ORDER.index(s)
        return len(SNOWFLAKE_SIZE_ORDER) + 1

    @staticmethod
    def get_warehouses(cursor) -> List[Dict]:
        """Get all warehouses with their state and size."""
        cursor.execute("SHOW WAREHOUSES")
        cursor.execute("""
            SELECT "name","state","size","auto_suspend","auto_resume"
            FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
        """)
        rows = cursor.fetchall()

        if rows and isinstance(rows[0], dict):
            return [{k.lower(): v for k, v in row.items()} for row in rows]
        else:
            cols = [d[0].lower() for d in cursor.description]
            return [dict(zip(cols, row)) for row in rows]

    @classmethod
    def choose_smallest_running(cls, warehouses: List[Dict]) -> Optional[str]:
        """Choose the smallest running warehouse."""
        running = [
            w for w in warehouses
            if (w.get("state") or "").upper() == "STARTED"
        ]
        if not running:
            return None
        running.sort(key=lambda w: cls._size_rank(w.get("size")))
        return running[0]["name"]

    @classmethod
    def choose_smallest_suspended(cls, warehouses: List[Dict]) -> Optional[str]:
        """Choose the smallest suspended warehouse."""
        suspended = [
            w for w in warehouses
            if (w.get("state") or "").upper() in ("SUSPENDED", "RESIZING")
        ]
        if not suspended:
            return None
        suspended.sort(key=lambda w: cls._size_rank(w.get("size")))
        return suspended[0]["name"]

    @staticmethod
    def resume_warehouse(cursor, name: str) -> None:
        """Resume a suspended warehouse."""
        cursor.execute(f'ALTER WAREHOUSE "{name}" RESUME')

    @staticmethod
    def create_tiny_warehouse(cursor, name: str = "SPAI_TINY_WH") -> str:
        """Create a tiny warehouse (requires proper privilege)."""
        cursor.execute(f'''
            CREATE WAREHOUSE IF NOT EXISTS "{name}"
            WITH WAREHOUSE_SIZE = XSMALL
                 AUTO_SUSPEND = 60
                 AUTO_RESUME = TRUE
                 INITIALLY_SUSPENDED = TRUE
        ''')
        cursor.execute(f'ALTER WAREHOUSE "{name}" RESUME')
        return name

    @classmethod
    def ensure_warehouse(cls, cursor, preferred: Optional[str] = None) -> str:
        """Ensure a warehouse is available and running."""
        # Try preferred warehouse first
        if preferred:
            try:
                cursor.execute(f"SHOW WAREHOUSES LIKE '{preferred}'")
                cursor.execute('SELECT "name","state","size" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))')
                row = cursor.fetchone()
                if row:
                    state = (row["state"] if isinstance(row, dict) else row[1] or "").upper()
                    if state != "STARTED":
                        cls.resume_warehouse(cursor, preferred)
                    return preferred
            except Exception:
                pass  # Fall back to discovery

        warehouses = cls.get_warehouses(cursor)

        # Try smallest running
        name = cls.choose_smallest_running(warehouses)
        if name:
            return name

        # Try smallest suspended
        name = cls.choose_smallest_suspended(warehouses)
        if name:
            cls.resume_warehouse(cursor, name)
            return name

        # Create new tiny warehouse
        return cls.create_tiny_warehouse(cursor)
