"""
MCP Whitelist Manager - Handles tool whitelisting and enabling/disabling.
"""
import logging
from typing import Dict, List, Set

from .constants import DEFAULT_WHITELISTED_TOOLS_BY_SERVER, DEFAULT_WHITELISTED_TOOLS

logger = logging.getLogger(__name__)


class MCPWhitelistManager:
    """Manages tool whitelisting for MCP servers."""

    def __init__(self, config_manager):
        """
        Initialize the whitelist manager.

        Args:
            config_manager: MCPConfigManager instance for saving configs.
        """
        self._config_manager = config_manager

    def _get_server_whitelist(self, server_name: str) -> Set[str]:
        """Get the default whitelist for a server based on its name."""
        for prefix in ['Notion', 'Dbt', 'Slack', 'Google']:
            if server_name.startswith(prefix):
                return set(DEFAULT_WHITELISTED_TOOLS_BY_SERVER[prefix])
        return set(DEFAULT_WHITELISTED_TOOLS)

    def _should_use_selective_whitelist(self, server_name: str) -> bool:
        """Check if server should use selective whitelisting."""
        return any(server_name.startswith(prefix) for prefix in ['Notion', 'Dbt', 'Slack', 'Google'])

    def ensure_default_whitelisted_tools(
        self,
        server_id: str,
        config: Dict,
        available_tool_names: List[str]
    ) -> None:
        """Ensure default whitelisted tools are enabled for a server."""
        existing_enabled = set(config.get('enabledTools') or [])
        available_tools = set(available_tool_names)
        server_name = config['name']

        should_use_selective = self._should_use_selective_whitelist(server_name)
        default_whitelisted = self._get_server_whitelist(server_name)
        available_default_tools = default_whitelisted & available_tools

        if 'enabledTools' not in config or not config['enabledTools']:
            if should_use_selective:
                config['enabledTools'] = list(available_default_tools)
            else:
                config['enabledTools'] = list(available_tools)
            self._config_manager.save_server_config(config)
            logger.info(f"[MCP] Auto-whitelisted tools for {server_id}")
        else:
            final_enabled = existing_enabled | available_default_tools
            if final_enabled != existing_enabled:
                config['enabledTools'] = list(final_enabled)
                self._config_manager.save_server_config(config)
                logger.info(f"[MCP] Auto-enabled default tools for {server_id}")

    def update_tool_enabled(
        self,
        server_id: str,
        tool_name: str,
        enabled: bool,
        tools_cache: Dict[str, List[Dict]]
    ) -> bool:
        """Update enabled/disabled state for a specific tool."""
        config = self._config_manager.get_server_config(server_id)
        if not config:
            return False

        enabled_tools = config.get('enabledTools')
        if enabled_tools is None:
            if server_id in tools_cache:
                enabled_tools = [tool['name'] for tool in tools_cache[server_id]]
            else:
                enabled_tools = []

        enabled_tools_set = set(enabled_tools)

        if enabled:
            enabled_tools_set.add(tool_name)
        else:
            enabled_tools_set.discard(tool_name)

        config['enabledTools'] = list(enabled_tools_set)
        self._config_manager.save_server_config(config)

        logger.info(f"[MCP] {'Enabled' if enabled else 'Disabled'} tool {tool_name} for {server_id}")
        return True
