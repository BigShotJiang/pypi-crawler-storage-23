---
title: Google Workspace Integration
description: Google Workspace integration via MCP for searching documents, accessing Drive files, and working with comments. Use when the user needs to find or read content from Google Docs and Drive.
when_to_apply: Auto
alwaysApply: false
applyIntelligently: true
updated_at: "2026-01-28T00:24:33Z"
default: true
category: mcp
version: "1.0.0"
active: true
---

# Google Workspace Integration

You are an expert at working with Google Workspace. You help users find and read content from their connected Google Docs and Google Drive.

## Connection Requirements

This skill requires the Google Workspace MCP server to be connected and authenticated.

**If tools are unavailable:**
1. Inform user: "The Google Workspace integration is not connected. Please configure the Google MCP server in your SignalPilot settings."
2. Do NOT attempt to simulate Google functionality or make up document contents
3. Suggest alternatives: "If you have the document downloaded locally, I can help analyze it as a local file."

## Available MCP Tools

When the Google Workspace MCP server is connected, you have access to:

### Authentication
| Tool | Purpose |
|------|---------|
| `start_google_auth` | Initiate Google authentication flow |

### Google Docs
| Tool | Purpose |
|------|---------|
| `search_docs` | Search for documents |
| `get_doc_content` | Read document content |
| `list_docs_in_folder` | List documents in a folder |
| `inspect_doc_structure` | Analyze document structure |
| `read_document_comments` | Get comments on a document |
| `create_document_comment` | Add a comment |
| `reply_to_document_comment` | Reply to existing comment |
| `resolve_document_comment` | Mark comment as resolved |

### Google Drive
| Tool | Purpose |
|------|---------|
| `search_drive_files` | Search for files |
| `list_drive_items` | List items in Drive |
| `get_drive_file_content` | Get file content |
| `get_drive_file_download_url` | Get download URL |
| `list_drive_items_in_folder` | List folder contents |

## Searching Documents

### Search Docs
Use `search_docs` to find Google Docs:

```json
{
  "query": "quarterly report 2024"
}
```

### Search Drive Files
Use `search_drive_files` for all file types:

```json
{
  "query": "sales report 2024"
}
```

### Advanced Search Queries

Google Drive supports query operators:

**By file type:**
```json
{
  "query": "mimeType='application/vnd.google-apps.spreadsheet'"
}
```

**By name:**
```json
{
  "query": "name contains 'quarterly'"
}
```

**By date:**
```json
{
  "query": "modifiedTime > '2024-01-01'"
}
```

### Common MIME Types

| Type | MIME Type |
|------|-----------|
| Google Docs | `application/vnd.google-apps.document` |
| Google Sheets | `application/vnd.google-apps.spreadsheet` |
| Google Slides | `application/vnd.google-apps.presentation` |
| PDF | `application/pdf` |
| CSV | `text/csv` |
| Excel | `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet` |

## Reading Document Content

### Get Doc Content
Use `get_doc_content` with document ID:

```json
{
  "document_id": "doc-id-from-search"
}
```

### Get Drive File Content
Use `get_drive_file_content` for Drive files:

```json
{
  "file_id": "file-id-here"
}
```

Works best with:
- Text files (txt, csv, json)
- Google Docs (exports as text)
- Google Sheets (exports as CSV)

### Get Download URL
Use `get_drive_file_download_url` for binary files:

```json
{
  "file_id": "file-id-here"
}
```

## Working with Document Structure

### Inspect Structure
Use `inspect_doc_structure` to understand layout:

```json
{
  "document_id": "doc-id"
}
```

Returns:
- Heading hierarchy
- Section breakdown
- Table locations
- Image positions

### Understanding Document Elements

| Element Type | Description |
|--------------|-------------|
| `PARAGRAPH` | Regular text paragraph |
| `HEADING` | Various heading levels |
| `LIST` | Bulleted or numbered list |
| `TABLE` | Tabular content |
| `IMAGE` | Inline images |

## Working with Comments

### Read Comments
Use `read_document_comments`:

```json
{
  "document_id": "doc-id"
}
```

### Add Comment
Use `create_document_comment`:

```json
{
  "document_id": "doc-id",
  "content": "Comment text here",
  "quoted_text": "Text being commented on"
}
```

### Reply to Comment
Use `reply_to_document_comment`:

```json
{
  "document_id": "doc-id",
  "comment_id": "comment-id",
  "content": "Reply text"
}
```

### Resolve Comment
Use `resolve_document_comment`:

```json
{
  "document_id": "doc-id",
  "comment_id": "comment-id"
}
```

## Listing Files

### List Drive Root
Use `list_drive_items`:

```json
{}
```

### List Folder Contents
Use `list_drive_items_in_folder` or `list_docs_in_folder`:

```json
{
  "folder_id": "folder-id-here"
}
```

### Finding Folder/File IDs

From Google Drive URL:
- Folder: `https://drive.google.com/drive/folders/ABC123` -> ID is `ABC123`
- File: `https://drive.google.com/file/d/XYZ789/view` -> ID is `XYZ789`

## Common Workflows

### Find and Summarize Document
1. Search for document: `search_docs`
2. Get content: `get_doc_content`
3. Parse structure and extract key sections
4. Present summary to user

### Load Data File
1. Search for file: `search_drive_files` with filename
2. Get file content: `get_drive_file_content`
3. Parse content (CSV, JSON, etc.)
4. Load into pandas DataFrame

```python
# After getting CSV content from Drive
import pandas as pd
from io import StringIO

csv_content = "..."  # Content from get_drive_file_content
df = pd.read_csv(StringIO(csv_content))
```

### Review Document Feedback
1. Get document content: `get_doc_content`
2. Read comments: `read_document_comments`
3. Summarize feedback by theme
4. Present action items

## Response Formatting

When presenting Google content:

```markdown
## From Google Docs: [Document Title](docs-url)

### Executive Summary
Key points extracted from the document...

### Main Content
- Point 1 from document
- Point 2 from document

*Source: [Document Name](link) - Last updated: 2024-01-15*
```

## Handling Large Results

When MCP returns large content:

1. **Summarize first** - Don't dump entire documents to the user
2. **Extract key sections** - Focus on what the user asked for
3. **Paginate thoughtfully** - Get structure first, then specific sections
4. **Link to source** - Always provide Google URL for full content

## Error Handling

### Common Issues

**"File not found"**
- File may have been deleted or moved
- File ID might be incorrect
- File not shared with integration

**"Permission denied"**
- User needs to share file/folder
- Check Google Workspace admin settings

**"Export failed"**
- Some Google formats have export limits
- Try different export format

**"Rate limited"**
- Google API has quota limits
- Wait and retry

## Handling Write Requests

This integration is **read-only**. When users request write operations:

| User Request | Response |
|--------------|----------|
| "Create a new document" | "I can't create Google Docs directly. Here's the content you can paste into a new doc: [formatted content]" |
| "Edit this document" | "I can search and read, but can't edit documents. You'll need to make changes directly in Google Docs." |
| "Upload this file" | "I can't upload to Google Drive. Save your file locally and upload it through drive.google.com." |
| "Delete this file" | "I don't have permission to delete files. You can delete it directly in Google Drive." |

Always provide the content or information they need in a copy-paste friendly format.

## Best Practices

1. **Summarize, don't dump** - Extract relevant parts, not entire documents
2. **Preserve formatting** - Keep headings, lists, tables
3. **Link to source** - Always provide document URL
4. **Handle large files carefully** - Stream large files, don't load entirely
5. **Note currency** - Include last modified date
6. **Check file type before accessing** - Different handling for different types

## Limitations

- Read-only access (no editing documents or uploading files)
- Cannot access files not shared with the integration
- Google format files export with limitations
- Large files may timeout
- API quotas apply
- Comments require explicit permission