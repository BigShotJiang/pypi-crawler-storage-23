---
title: Chat History Search
description: "Search through past SignalPilot chat conversations to find previous discussions, code snippets, solutions, or context from earlier sessions."
when_to_apply: Auto
alwaysApply: false
applyIntelligently: true
updated_at: "2026-02-16T00:00:00Z"
default: true
category: core
version: "1.2.0"
active: true
---

# Chat History Search

Search through past SignalPilot chat conversations stored on disk. Use this when the user wants to find previous discussions, recall earlier solutions, or reference past context.

## Storage Location

Chat histories are JSON files stored at:

| OS | Path |
|----|------|
| **macOS** | `~/Library/Caches/SignalPilotAI/chat-histories/` |
| **Linux** | `~/.cache/signalpilot-ai-internal/chat-histories/` |
| **Windows** | `%LOCALAPPDATA%\SignalPilotAI\Cache\chat-histories\` |

Files follow the pattern: `notebook_chat_*.json`. First identify what system user has and only search in the correct path. Other directories may not exist in the system.

## How to Search

Use the `terminal-grep` MCP tool. **Always limit results** with `max_results` - there can be hundreds of chats.

### Basic Search

Call `terminal-grep` with these parameters:

```json
{
  "pattern": "search_term",
  "path": "~/Library/Caches/SignalPilotAI/chat-histories/",
  "glob": "*.json",
  "case_insensitive": true,
  "max_results": 20
}
```

### Search Examples

**Find keyword matches:**
```json
{
  "pattern": "pandas",
  "path": "~/Library/Caches/SignalPilotAI/chat-histories/",
  "glob": "*.json",
  "case_insensitive": true,
  "max_results": 15
}
```

**Find code patterns:**
```json
{
  "pattern": "def .*\\(",
  "path": "~/Library/Caches/SignalPilotAI/chat-histories/",
  "glob": "*.json",
  "max_results": 10
}
```

**Search with context lines:**
```json
{
  "pattern": "error|exception",
  "path": "~/Library/Caches/SignalPilotAI/chat-histories/",
  "glob": "*.json",
  "case_insensitive": true,
  "context_lines": 2,
  "max_results": 15
}
```

## Sorting by Recency

Chat files and threads have timestamps. To prioritize recent conversations:

### Step 1: List Recent Files First

Use `terminal-execute` to list files by modification time:

```json
{
  "command": "ls -t ~/Library/Caches/SignalPilotAI/chat-histories/*.json | head -10",
  "description": "List 10 most recent chat files"
}
```

### Step 2: Search in Recent Files

Then search specific recent files with `terminal-grep`:

```json
{
  "pattern": "search_term",
  "path": "~/Library/Caches/SignalPilotAI/chat-histories/notebook_chat_SPECIFIC_FILE.json",
  "max_results": 20
}
```

### Alternative: Get Recent Threads by Timestamp

Each thread has a `lastUpdated` field (Unix ms). Use `terminal-execute`:

```json
{
  "command": "cat ~/Library/Caches/SignalPilotAI/chat-histories/*.json 2>/dev/null | jq -s 'add | sort_by(-.lastUpdated) | .[0:10] | .[] | \"\\(.lastUpdated / 1000 | strftime(\"%Y-%m-%d\")) - \\(.name)\"'",
  "description": "List 10 most recent chat threads"
}
```

## JSON Structure

Each file contains an array of threads:

```json
[
  {
    "id": "thread_uuid",
    "name": "Thread Name",
    "lastUpdated": 1708041600000,
    "messages": [
      {"role": "user", "content": "..."},
      {"role": "assistant", "content": "..."}
    ]
  }
]
```

**Key fields:**
- `lastUpdated` - Unix timestamp in milliseconds (sort by this for recency)
- `name` - Thread title
- `messages[].content` - The actual conversation text to search

## Best Practices

1. **Always set `max_results`** - Default is 100, but use 15-20 for most searches
2. **Search recent first** - List files by mtime, then search specific ones
3. **Use `case_insensitive: true`** - Unless searching exact code/identifiers
4. **Keep `context_lines` low** - 2 is usually enough, max is 10
5. **Start broad, narrow down** - Simple terms first, then refine pattern

## Quick Reference

| User Request | Action |
|--------------|--------|
| "Find chats about X" | `terminal-grep` with `pattern: "X"`, `max_results: 15` |
| "Recent discussions" | `terminal-execute` with `ls -t ... \| head -10` first |
| "Code I wrote for Y" | Search for function names, imports, or variable names |
| "When did we discuss Z" | Search Z, check file timestamps in results |
