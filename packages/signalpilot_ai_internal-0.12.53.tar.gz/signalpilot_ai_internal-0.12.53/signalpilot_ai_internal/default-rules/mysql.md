---
title: MySQL Connector
description: MySQL database connection and querying skill. Use when the user needs to connect to MySQL, explore schemas, or query data from MySQL databases.
when_to_apply: Auto
alwaysApply: false
applyIntelligently: true
updated_at: "2026-01-27T16:36:28Z"
default: true
category: database
version: "1.0.0"
active: true
---

# MySQL Connector

Expert guidance for working with MySQL databases.

## Critical Safety Rules

### Destructive Operations - ALWAYS WARN

Before generating ANY of these operations, you MUST warn the user about potential data loss:

- `DROP TABLE`, `DROP DATABASE`
- `DELETE` (especially without WHERE clause)
- `TRUNCATE TABLE`
- `ALTER TABLE` (structure changes)
- `UPDATE` without WHERE clause

When user requests destructive operations:
1. **Warn clearly**: "This operation will permanently delete/modify data and cannot be undone."
2. **Suggest safer alternatives**: soft deletes, backups, WHERE clause additions
3. **Show exactly what will be affected**: row counts, table names
4. **Never execute DELETE/UPDATE without WHERE** unless user explicitly confirms

### Query Safety - LIMIT Enforcement

For exploratory or ad-hoc SELECT queries:

1. **Always apply LIMIT** (default 1000) unless user explicitly requests all rows
2. **Warn about large result sets**: "This query may return many rows. Adding LIMIT 1000."
3. **For aggregations**, LIMIT is usually not needed but consider the grouping cardinality

Never generate unbounded `SELECT *` on tables without knowing their size.

### Data Privacy

Be cautious with columns that may contain PII:
- `email`, `phone`, `ssn`, `address`, `name`, `first_name`, `last_name`
- Columns containing `personal`, `private`, `secret`, `password`, `token`

## Package

```python
# Install package (use your environment's package manager):
# - If using uv: !uv pip install pymysql
# - Otherwise: !pip install pymysql
```

## Connection Setup

### Using Environment Variables
```python
import os
import pymysql

conn = pymysql.connect(
    host=os.environ['MYDB_HOST'],
    port=int(os.environ.get('MYDB_PORT', 3306)),
    database=os.environ['MYDB_DATABASE'],
    user=os.environ['MYDB_USERNAME'],
    password=os.environ['MYDB_PASSWORD'],
    cursorclass=pymysql.cursors.DictCursor  # Returns dicts instead of tuples
)
```

### Using Context Managers
```python
import pymysql

config = {
    'host': 'hostname',
    'database': 'database_name',
    'user': 'username',
    'password': 'password',
    'cursorclass': pymysql.cursors.DictCursor
}

with pymysql.connect(**config) as conn:
    with conn.cursor() as cursor:
        cursor.execute("SELECT * FROM table_name")
        results = cursor.fetchall()
```

### Using with pandas
```python
import pandas as pd
import pymysql

conn = pymysql.connect(
    host='hostname',
    database='database_name',
    user='username',
    password='password'
)

df = pd.read_sql("SELECT * FROM table_name", conn)
conn.close()
```

## Identifiers

MySQL uses backticks for identifier quoting:

```sql
-- Use backticks for reserved words or special characters
SELECT `select`, `from`, `table-name`
FROM `my-database`.`my-table`;
```

## Case Sensitivity

```sql
-- Table names: Case sensitive on Linux, insensitive on Windows/macOS
-- Column names: Always case insensitive
-- String comparisons depend on collation

-- Check collation
SHOW VARIABLES LIKE 'collation%';

-- Case-sensitive comparison
SELECT * FROM users WHERE BINARY name = 'John';
```

## Schema Discovery

```sql
-- List all databases
SHOW DATABASES;

-- List all tables in current database
SHOW TABLES;

-- Get table structure
DESCRIBE table_name;
-- or
SHOW COLUMNS FROM table_name;

-- Get full column info
SELECT
    COLUMN_NAME,
    DATA_TYPE,
    CHARACTER_MAXIMUM_LENGTH,
    IS_NULLABLE,
    COLUMN_DEFAULT,
    COLUMN_KEY,
    EXTRA
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'database_name'
  AND TABLE_NAME = 'table_name'
ORDER BY ORDINAL_POSITION;

-- List indexes
SHOW INDEX FROM table_name;

-- Get CREATE TABLE statement
SHOW CREATE TABLE table_name;
```

## Query Patterns

### Date/Time Functions

```sql
-- Current timestamp
SELECT NOW();
SELECT CURRENT_TIMESTAMP;
SELECT CURDATE();  -- Date only
SELECT CURTIME();  -- Time only

-- Date arithmetic
SELECT DATE_ADD(CURDATE(), INTERVAL 7 DAY);
SELECT DATE_SUB(CURDATE(), INTERVAL 1 MONTH);

-- Date difference
SELECT DATEDIFF('2024-12-31', '2024-01-01');  -- Days
SELECT TIMESTAMPDIFF(MONTH, '2024-01-01', '2024-12-31');  -- Months

-- Date formatting
SELECT DATE_FORMAT(created_at, '%Y-%m-%d %H:%i:%s');
SELECT DATE_FORMAT(created_at, '%M %d, %Y');  -- "January 15, 2024"

-- Extract parts
SELECT YEAR(created_at), MONTH(created_at), DAY(created_at);
SELECT DAYOFWEEK(created_at);  -- 1=Sunday, 7=Saturday

-- Truncate to period
SELECT DATE(created_at);  -- Truncate to date
SELECT DATE_FORMAT(created_at, '%Y-%m-01') as month_start;
```

### JSON Functions (MySQL 5.7+)

```sql
-- Access JSON fields
SELECT JSON_EXTRACT(data, '$.field_name') as field_value
FROM table_with_json;

-- Shorthand syntax (MySQL 5.7.9+)
SELECT data->>'$.field_name' as field_value  -- Unquoted text
FROM table_with_json;

-- Nested access
SELECT data->>'$.nested.field' as nested_value
FROM table_with_json;

-- Array access
SELECT data->>'$.array[0]' as first_element
FROM table_with_json;

-- Check if path exists
SELECT * FROM table_with_json
WHERE JSON_CONTAINS_PATH(data, 'one', '$.field_name');

-- Build JSON
SELECT JSON_OBJECT('id', id, 'name', name) as json_record
FROM users;

-- Aggregate to JSON array
SELECT JSON_ARRAYAGG(name) FROM users;
```

### Window Functions (MySQL 8.0+)

```sql
-- Row number
SELECT
    *,
    ROW_NUMBER() OVER (PARTITION BY category ORDER BY amount DESC) as rank_num
FROM products;

-- Running total
SELECT
    date,
    amount,
    SUM(amount) OVER (ORDER BY date) as running_total
FROM transactions;

-- Lead/Lag
SELECT
    date,
    amount,
    LAG(amount, 1) OVER (ORDER BY date) as prev_amount,
    LEAD(amount, 1) OVER (ORDER BY date) as next_amount
FROM transactions;
```

### Common Table Expressions (MySQL 8.0+)

```sql
WITH monthly_sales AS (
    SELECT
        DATE_FORMAT(sale_date, '%Y-%m') as month,
        SUM(amount) as total
    FROM sales
    GROUP BY 1
)
SELECT * FROM monthly_sales WHERE total > 10000;
```

### Upsert (INSERT ON DUPLICATE KEY)

```sql
INSERT INTO users (email, name, updated_at)
VALUES ('user@example.com', 'User Name', NOW())
ON DUPLICATE KEY UPDATE
    name = VALUES(name),
    updated_at = NOW();
```

### Bulk Insert

```sql
INSERT INTO table_name (col1, col2)
VALUES
    ('a', 1),
    ('b', 2),
    ('c', 3);
```

### Pagination

```sql
-- Simple pagination (slow for large offsets)
SELECT * FROM products
ORDER BY id
LIMIT 20 OFFSET 100;

-- Keyset pagination (better for large datasets)
SELECT * FROM products
WHERE id > 100
ORDER BY id
LIMIT 20;
```

## Performance

### EXPLAIN
```sql
-- Basic explain
EXPLAIN SELECT * FROM large_table WHERE category = 'A';

-- With execution stats (MySQL 8.0.18+)
EXPLAIN ANALYZE SELECT * FROM large_table WHERE category = 'A';
```

### Index Creation
```sql
-- Basic index
CREATE INDEX idx_name ON table_name(column_name);

-- Composite index
CREATE INDEX idx_composite ON table_name(col1, col2);

-- Unique index
CREATE UNIQUE INDEX idx_unique ON table_name(email);

-- Full-text index
CREATE FULLTEXT INDEX idx_fulltext ON articles(title, content);

-- Prefix index (for long strings)
CREATE INDEX idx_prefix ON table_name(long_column(20));
```

### Full-Text Search
```sql
-- Create fulltext index
ALTER TABLE articles ADD FULLTEXT INDEX ft_idx(title, content);

-- Natural language search
SELECT * FROM articles
WHERE MATCH(title, content) AGAINST('database optimization');

-- Boolean mode
SELECT * FROM articles
WHERE MATCH(title, content) AGAINST('+mysql -postgres' IN BOOLEAN MODE);

-- With relevance score
SELECT *, MATCH(title, content) AGAINST('database') as relevance
FROM articles
WHERE MATCH(title, content) AGAINST('database')
ORDER BY relevance DESC;
```

## Common Errors

| Error | Cause | Solution |
|-------|-------|----------|
| 1045 Access denied | Wrong username/password | Verify credentials |
| 1049 Unknown database | Database doesn't exist | Check database name |
| 1146 Table doesn't exist | Wrong table name | Verify table name |
| 1062 Duplicate entry | Unique constraint violation | Check for duplicates |
| 1452 Foreign key constraint fails | Referenced record doesn't exist | Verify foreign key |

## Key Rules

1. Use backticks for identifiers with reserved words or special characters
2. Parameterize queries - never concatenate user input
3. Use InnoDB engine for transactions and foreign keys
4. Default to `utf8mb4` for full Unicode support