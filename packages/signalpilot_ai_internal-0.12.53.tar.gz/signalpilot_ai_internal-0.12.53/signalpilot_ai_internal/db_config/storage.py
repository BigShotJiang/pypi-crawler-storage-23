"""Database configuration storage service."""

import json
import logging
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from signalpilot_ai_internal.db_config.constants import (
    SUPPORTED_TYPES,
    TYPE_MAPPING_TO_BACKEND,
    TYPE_MAPPING_TO_FRONTEND,
)
from signalpilot_ai_internal.db_config.factory import build_url, normalize_db_name
from signalpilot_ai_internal.signalpilot_home import get_signalpilot_home

logger = logging.getLogger(__name__)


class ConfigStorage:
    """Manages database configurations stored in db.toml."""

    _instance = None

    def __init__(self, home_manager):
        self._home = home_manager

    @classmethod
    def get_instance(cls) -> "ConfigStorage":
        """Get singleton instance."""
        if cls._instance is None:
            cls._instance = ConfigStorage(get_signalpilot_home())
        return cls._instance

    def get_all(self) -> List[Dict[str, Any]]:
        """Get all database configurations."""
        return self._home.get_database_configs()

    def get_by_type(self, db_type: str) -> List[Dict[str, Any]]:
        """Get configurations for a specific database type."""
        return [c for c in self.get_all() if c.get("type") == db_type]

    def get(self, db_type: str, name: str) -> Optional[Dict[str, Any]]:
        """Get a specific configuration."""
        return self._home.get_database_config(db_type, name)

    def add(self, db_type: str, config: Dict[str, Any]) -> bool:
        """Add a new configuration."""
        if db_type not in SUPPORTED_TYPES:
            logger.error(f"Unsupported database type: {db_type}")
            return False
        if "name" not in config:
            logger.error("Config must have 'name' field")
            return False
        return self._home.add_database_config(db_type, config)

    def update(self, db_type: str, name: str, updates: Dict[str, Any]) -> bool:
        """Update an existing configuration."""
        return self._home.update_database_config(db_type, name, updates)

    def remove(self, db_type: str, name: str) -> bool:
        """Remove a configuration."""
        return self._home.remove_database_config(db_type, name)

    def get_defaults(self) -> Dict[str, Any]:
        """Get global defaults."""
        return self._home.get_database_defaults()

    def set_defaults(self, defaults: Dict[str, Any]) -> bool:
        """Set global defaults."""
        return self._home.set_database_defaults(defaults)

    def sync_all(self, configs: List[Dict[str, Any]]) -> bool:
        """Replace all configurations from frontend format."""
        try:
            configs_by_type: Dict[str, List] = {}
            for config in configs:
                db_type = TYPE_MAPPING_TO_BACKEND.get(config.get("type", "").lower())
                if not db_type or db_type not in SUPPORTED_TYPES:
                    continue
                if db_type not in configs_by_type:
                    configs_by_type[db_type] = []
                toml_config = ConfigConverter.to_toml(config)
                if toml_config:
                    configs_by_type[db_type].append(toml_config)

            full_config = self._home.read_db_config()
            new_config = {"defaults": full_config.get("defaults", {})}
            for db_type in SUPPORTED_TYPES:
                if configs_by_type.get(db_type):
                    new_config[db_type] = configs_by_type[db_type]

            return self._home.write_db_config(new_config)
        except Exception as e:
            logger.error(f"Error syncing configs: {e}")
            return False

    def get_all_frontend_format(self) -> List[Dict[str, Any]]:
        """Get all configurations in frontend format."""
        return [c for c in (ConfigConverter.to_frontend(cfg) for cfg in self.get_all()) if c]


class ConfigConverter:
    """Convert between TOML and frontend config formats."""

    CREDENTIAL_FIELDS = [
        "host", "port", "database", "username", "password",
        "connectionUrl", "warehouse", "role", "authType",
        "accessToken", "clientId", "clientSecret", "warehouseHttpPath",
        "catalog", "schema",
    ]

    @staticmethod
    def to_toml(config: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Convert frontend config to TOML format.

        Keeps camelCase field names to match frontend format consistently.
        """
        try:
            name = config.get("name", "")
            if not name:
                return None

            toml = {"name": name}

            for field in ["id", "createdAt", "updatedAt", "schema_last_updated"]:
                if config.get(field):
                    toml[field] = config[field]

            if config.get("database_schema"):
                schema = config["database_schema"]
                toml["database_schema"] = schema if isinstance(schema, str) else json.dumps(schema)

            creds = config.get("credentials", {})
            for field in ConfigConverter.CREDENTIAL_FIELDS:
                value = creds.get(field) or config.get(field)
                if value:
                    toml[field] = value

            url_conn = config.get("urlConnection", {})
            if url_conn.get("connectionUrl"):
                toml["connectionUrl"] = url_conn["connectionUrl"]

            return toml
        except Exception as e:
            logger.error(f"Error converting to TOML: {e}")
            return None

    @staticmethod
    def to_frontend(config: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Convert TOML config to frontend format."""
        try:
            name = config.get("name", "")
            if not name:
                return None

            db_type = config.get("type", "")
            frontend_type = TYPE_MAPPING_TO_FRONTEND.get(db_type, db_type)
            config_id = config.get("id") or str(uuid.uuid5(uuid.NAMESPACE_DNS, f"{name}-{db_type}"))
            now = datetime.now().isoformat()

            credentials = {
                "id": config_id,
                "name": name,
                "description": config.get("description", ""),
                "type": frontend_type,
                "host": config.get("host", ""),
                "port": config.get("port", 0),
                "database": config.get("database", ""),
                "username": config.get("username", ""),
                "password": config.get("password", ""),
                "createdAt": config.get("createdAt", now),
                "updatedAt": config.get("updatedAt", now),
            }

            if config.get("connectionUrl"):
                credentials["connectionUrl"] = config["connectionUrl"]

            if db_type == "snowflake":
                for field in ["warehouse", "role"]:
                    if config.get(field):
                        credentials[field] = config[field]

            if db_type == "databricks":
                credentials["authType"] = config.get("authType", "pat")
                for field in ["accessToken", "clientId", "clientSecret", "warehouseHttpPath", "catalog", "schema"]:
                    if config.get(field):
                        credentials[field] = config[field]

            db_schema = config.get("databaseSchema")
            if db_schema and isinstance(db_schema, str):
                try:
                    db_schema = json.loads(db_schema)
                except (json.JSONDecodeError, ValueError):
                    db_schema = None

            return {
                "id": config_id,
                "name": name,
                "type": frontend_type,
                "connectionType": "credentials",
                "credentials": credentials,
                "schema_last_updated": config.get("schemaLastUpdated"),
                "database_schema": db_schema,
                "createdAt": config.get("createdAt", now),
                "updatedAt": config.get("updatedAt", now),
            }
        except Exception as e:
            logger.error(f"Error converting to frontend: {e}")
            return None


def get_storage() -> ConfigStorage:
    """Get the singleton storage instance."""
    return ConfigStorage.get_instance()


def get_mcp_env_vars() -> Dict[str, str]:
    """Build DATABASE_<NAME>_URL env vars for MCP server."""
    env_vars = {}
    try:
        for config in get_storage().get_all():
            try:
                name = config.get("name", config.get("type", ""))
                env_vars[f"DATABASE_{normalize_db_name(name)}_URL"] = build_url(config)
            except Exception as e:
                logger.warning(f"Failed to build URL for {config.get('type', 'unknown')}: {e}")
    except Exception as e:
        logger.warning(f"Failed to get database configs: {e}")
    return env_vars
