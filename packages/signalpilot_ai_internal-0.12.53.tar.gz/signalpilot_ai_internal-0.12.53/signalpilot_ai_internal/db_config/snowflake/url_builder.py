"""Snowflake URL builder."""

from typing import Any, Dict

from signalpilot_ai_internal.db_config.base.url_builder import BaseURLBuilder


class SnowflakeURLBuilder(BaseURLBuilder):
    """Builds Snowflake SQLAlchemy connection URLs."""

    def build(self, config: Dict[str, Any]) -> str:
        """Build Snowflake connection URL.

        Format: snowflake://{user}:{password}@{account}/{database}?warehouse={warehouse}
        """
        account = self._get_required(config, "account")
        username = self._get_required(config, "username")
        password = self._get_optional(config, "password")
        database = self._get_optional(config, "database")
        warehouse = self._get_optional(config, "warehouse")

        url = f"snowflake://{username}:{password}@{account}/{database}"
        if warehouse:
            url += f"?warehouse={warehouse}"
        return url
