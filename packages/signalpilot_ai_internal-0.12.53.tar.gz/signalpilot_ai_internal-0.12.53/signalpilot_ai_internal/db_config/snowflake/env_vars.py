"""Snowflake environment variable builder."""

from signalpilot_ai_internal.db_config.base.env_vars import BaseEnvVarBuilder
from signalpilot_ai_internal.db_config.snowflake.url_builder import SnowflakeURLBuilder


class SnowflakeEnvVarBuilder(BaseEnvVarBuilder):
    """Builds environment variables for Snowflake."""

    URL_BUILDER_CLASS = SnowflakeURLBuilder
    EXTRA_FIELDS = [
        ("account", "ACCOUNT"),
        ("warehouse", "WAREHOUSE"),
        ("role", "ROLE"),
    ]
