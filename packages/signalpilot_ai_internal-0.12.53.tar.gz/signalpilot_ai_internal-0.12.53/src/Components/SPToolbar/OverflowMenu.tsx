import React, {
  useState,
  useRef,
  useEffect,
  useCallback,
  ReactNode
} from 'react';
import { EllipsisIcon } from './ToolbarIcons';

interface OverflowItem {
  key: string;
  label: string;
  icon: ReactNode;
  onClick: () => void;
  disabled?: boolean;
}

interface OverflowMenuProps {
  items: OverflowItem[];
  /** Width in px below which items start overflowing */
  breakpoint?: number;
  children: ReactNode;
}

export const OverflowMenu: React.FC<OverflowMenuProps> = ({
  items,
  breakpoint = 500,
  children
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const popoverRef = useRef<HTMLDivElement>(null);
  const [isOverflowing, setIsOverflowing] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const observer = new ResizeObserver(entries => {
      for (const entry of entries) {
        setIsOverflowing(entry.contentRect.width < breakpoint);
      }
    });
    observer.observe(el);
    return () => observer.disconnect();
  }, [breakpoint]);

  // Close popover on outside click
  useEffect(() => {
    if (!isOpen) return;
    const handleClickOutside = (e: MouseEvent) => {
      if (
        popoverRef.current &&
        !popoverRef.current.contains(e.target as Node)
      ) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  const handleItemClick = useCallback(
    (onClick: () => void) => {
      onClick();
      setIsOpen(false);
    },
    []
  );

  return (
    <div className="sp-toolbar-overflow-wrapper" ref={containerRef}>
      {!isOverflowing && children}
      {isOverflowing && (
        <div className="sp-toolbar-overflow-container" ref={popoverRef}>
          <button
            className="sp-toolbar-btn"
            onClick={() => setIsOpen(!isOpen)}
            title="More actions"
          >
            <EllipsisIcon size={16} />
          </button>
          {isOpen && (
            <div className="sp-toolbar-overflow-popover">
              {items.map(item => (
                <button
                  key={item.key}
                  className="sp-toolbar-overflow-item"
                  onClick={() => handleItemClick(item.onClick)}
                  disabled={item.disabled}
                >
                  <span className="sp-toolbar-overflow-item-icon">
                    {item.icon}
                  </span>
                  <span>{item.label}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
