import * as React from 'react';
import { ReactWidget, LabIcon } from '@jupyterlab/ui-components';

const spLogoIcon = new LabIcon({
  name: 'signalpilot-ai-internal:sp-logo-chat',
  svgstr: `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" viewBox="0 0 799 800">
  <defs>
    <linearGradient id="sp-logo-grad" x1="522.45" y1="325.25" x2="450.55" y2="283.75" gradientUnits="userSpaceOnUse">
      <stop offset="0" stop-color="#f9a8d4"/>
      <stop offset=".16" stop-color="#eeaadb"/>
      <stop offset=".7" stop-color="#cfb2f3"/>
      <stop offset="1" stop-color="#c4b5fd"/>
    </linearGradient>
  </defs>
  <g>
    <g>
      <g>
        <g>
          <path d="M572.96,619.47c13.47-23.33,26.93-46.65,40.4-69.98,16.51-28.6,33.03-57.21,49.54-85.81,8.95-15.49,10.36-34.47,1.48-50.44-3.85-6.93-7.93-13.74-11.9-20.61-18.31-31.71-36.61-63.42-54.92-95.12-18.31-31.71-36.61-63.42-54.92-95.12-3.96-6.87-7.83-13.8-11.9-20.61-8.96-15-25.82-23.82-43.1-23.82-26.86,0-53.71,0-80.57,0-40.79,0-81.58,0-122.37,0-21.04,0-42.16-.52-63.2,0-16.03.39-32.02,9.58-40.37,23.28-.91,1.49-1.75,3.03-2.62,4.54-5.65,9.79-11.31,19.59-16.96,29.38-19.5,33.77-39,67.55-58.5,101.32-16.61,28.77-33.22,57.54-49.83,86.31-5.16,8.93-10.19,16.95-11.58,27.55s.31,21.53,5.64,30.92c1.36,2.4,2.76,4.78,4.14,7.17,15.82,27.4,31.64,54.8,47.46,82.21,19.89,34.45,39.78,68.9,59.67,103.35,6.18,10.7,12.35,21.39,18.53,32.09,1.28,2.21,2.51,4.44,3.83,6.63,6.34,10.54,16.84,18.12,28.51,21.78,8.37,2.62,17.55,1.91,26.21,1.91h42.31c40.38,0,80.76,0,121.14,0,28.82,0,57.65,0,86.47,0,17.93,0,35.38-7.58,44.98-23.43,7.82-12.91,15.11-26.18,22.66-39.25,6.59-11.41,13.18-22.83,19.77-34.24,7.74-13.4-12.99-25.5-20.72-12.11-14.14,24.48-27.8,49.31-42.43,73.5-3.93,6.5-12.89,11.4-19.94,11.54-2.11.04-4.23,0-6.34,0-11.5,0-22.99,0-34.49,0-38.55,0-77.1,0-115.65,0-32.75,0-65.49,0-98.24,0-7.53,0-15.41.73-21.44-1.77-9-3.73-12.26-10.33-17.11-18.72-15.83-27.42-31.66-54.83-47.49-82.25-19.52-33.8-39.03-67.61-58.55-101.41l-18.53-32.1c-1.35-2.33-2.72-4.66-4.04-7-3.3-5.84-3.96-14.03-1.42-21.12.45-1.26,1.71-3.34,2.86-5.33,1.98-3.43,3.96-6.86,5.94-10.28,7.08-12.27,14.17-24.54,21.25-36.81,19.91-34.49,39.82-68.98,59.74-103.46,14.31-24.79,28.63-49.59,42.94-74.38.85-1.47,1.66-2.96,2.54-4.41,3.92-6.44,12.96-11.27,19.96-11.39s14.12,0,21.18,0c35.1,0,70.2,0,105.29,0h111.3c9.35,0,18.7,0,28.05,0s18.01,4.43,22.88,12.8c12.71,21.84,25.27,43.76,37.9,65.64,20,34.64,40,69.28,60,103.92,11.74,20.34,23.43,40.72,35.23,61.03,3.4,5.85,3.95,15.58.91,22.1-.69,1.48-2.39,4.12-3.5,6.05-6.88,11.92-13.76,23.84-20.65,35.76-19.02,32.94-38.04,65.89-57.06,98.83-3.71,6.42-7.42,12.84-11.12,19.27-7.74,13.4,12.99,25.5,20.72,12.11h0Z" fill="currentColor"/>
        </g>
        <g>
          <path d="M659.41,619.73c13.47-23.33,26.93-46.65,40.4-69.98,16.51-28.6,33.03-57.21,49.54-85.81,8.95-15.49,10.36-34.47,1.48-50.44-3.85-6.93-7.93-13.74-11.9-20.61-18.31-31.71-36.61-63.42-54.92-95.12-18.31-31.71-36.61-63.42-54.92-95.12-3.96-6.87-7.83-13.8-11.9-20.61-8.96-15-25.82-23.82-43.1-23.82-26.86,0-53.71,0-80.57,0-40.79,0-81.58,0-122.37,0-21.04,0-42.16-.52-63.2,0-16.03.39-32.02,9.58-40.37,23.28-.91,1.49-1.75,3.03-2.62,4.54-5.65,9.79-11.31,19.59-16.96,29.38-19.5,33.77-39,67.55-58.5,101.32-16.61,28.77-33.22,57.54-49.83,86.31-5.16,8.93-10.19,16.95-11.58,27.55s.31,21.53,5.64,30.92c1.36,2.4,2.76,4.78,4.14,7.17,15.82,27.4,31.64,54.8,47.46,82.21,19.89,34.45,39.78,68.9,59.67,103.35,6.18,10.7,12.35,21.39,18.53,32.09,1.28,2.21,2.51,4.44,3.83,6.63,6.34,10.54,16.84,18.12,28.51,21.78,8.37,2.62,17.55,1.91,26.21,1.91h42.31c40.38,0,80.76,0,121.14,0,28.82,0,57.65,0,86.47,0,17.93,0,35.38-7.58,44.98-23.43,7.82-12.91,15.11-26.18,22.66-39.25,6.59-11.41,13.18-22.83,19.77-34.24,7.74-13.4-12.99-25.5-20.72-12.11-14.14,24.48-27.8,49.31-42.43,73.5-3.93,6.5-12.89,11.4-19.94,11.54-2.11.04-4.23,0-6.34,0-11.5,0-22.99,0-34.49,0-38.55,0-77.1,0-115.65,0-32.75,0-65.49,0-98.24,0-7.53,0-15.41.73-21.44-1.77-9-3.73-12.26-10.33-17.11-18.72-15.83-27.42-31.66-54.83-47.49-82.25-19.52-33.8-39.03-67.61-58.55-101.41-6.18-10.7-12.35-21.4-18.53-32.1-1.35-2.33-2.72-4.66-4.04-7-3.3-5.84-3.96-14.03-1.42-21.12.45-1.26,1.71-3.34,2.86-5.33,1.98-3.43,3.96-6.86,5.94-10.28,7.08-12.27,14.17-24.54,21.25-36.81,19.91-34.49,39.82-68.98,59.74-103.46,14.31-24.79,28.63-49.59,42.94-74.38.85-1.47,1.66-2.96,2.54-4.41,3.92-6.44,12.96-11.27,19.96-11.39s14.12,0,21.18,0c35.1,0,70.2,0,105.29,0,37.1,0,74.2,0,111.3,0,9.35,0,18.7,0,28.05,0s18.01,4.43,22.88,12.8c12.71,21.84,25.27,43.76,37.9,65.64,20,34.64,40,69.28,60,103.92,11.74,20.34,23.43,40.72,35.23,61.03,3.4,5.85,3.95,15.58.91,22.1-.69,1.48-2.39,4.12-3.5,6.05-6.88,11.92-13.76,23.84-20.65,35.76-19.02,32.94-38.04,65.89-57.06,98.83-3.71,6.42-7.42,12.84-11.12,19.27-7.74,13.4,12.99,25.5,20.72,12.11h0Z" fill="currentColor"/>
        </g>
        <g>
          <path d="M615.96,544.99c13.47-23.33,26.93-46.65,40.4-69.98,16.51-28.6,33.03-57.21,49.54-85.81,8.95-15.49,10.36-34.47,1.48-50.44-3.85-6.93-7.93-13.74-11.9-20.61-18.31-31.71-36.61-63.42-54.92-95.12-18.31-31.71-36.61-63.42-54.92-95.12-3.96-6.87-7.83-13.8-11.9-20.61-8.96-15-25.82-23.82-43.1-23.82-26.86,0-53.71,0-80.57,0-40.79,0-81.58,0-122.37,0-21.04,0-42.16-.52-63.2,0-16.03.39-32.02,9.58-40.37,23.28-.91,1.49-1.75,3.03-2.62,4.54-5.65,9.79-11.31,19.59-16.96,29.38-19.5,33.77-39,67.55-58.5,101.32-16.61,28.77-33.22,57.54-49.83,86.31-5.16,8.93-10.19,16.95-11.58,27.55s.31,21.53,5.64,30.92c1.36,2.4,2.76,4.78,4.14,7.17,15.82,27.4,31.64,54.8,47.46,82.21,19.89,34.45,39.78,68.9,59.67,103.35,6.18,10.7,12.35,21.39,18.53,32.09,1.28,2.21,2.51,4.44,3.83,6.63,6.34,10.54,16.84,18.12,28.51,21.78,8.37,2.62,17.55,1.91,26.21,1.91h42.31c40.38,0,80.76,0,121.14,0,28.82,0,57.65,0,86.47,0,17.93,0,35.38-7.58,44.98-23.43,7.82-12.91,15.11-26.18,22.66-39.25,6.59-11.41,13.18-22.83,19.77-34.24,7.74-13.4-12.99-25.5-20.72-12.11-14.14,24.48-27.8,49.31-42.43,73.5-3.93,6.5-12.89,11.4-19.94,11.54-2.11.04-4.23,0-6.34,0-11.5,0-22.99,0-34.49,0-38.55,0-77.1,0-115.65,0-32.75,0-65.49,0-98.24,0-7.53,0-15.41.73-21.44-1.77-9-3.73-12.26-10.33-17.11-18.72-15.83-27.42-31.66-54.83-47.49-82.25-19.52-33.8-39.03-67.61-58.55-101.41-6.18-10.7-12.35-21.4-18.53-32.1-1.35-2.33-2.72-4.66-4.04-7-3.3-5.84-3.96-14.03-1.42-21.12.45-1.26,1.71-3.34,2.86-5.33,1.98-3.43,3.96-6.86,5.94-10.28,7.08-12.27,14.17-24.54,21.25-36.81,19.91-34.49,39.82-68.98,59.74-103.46,14.31-24.79,28.63-49.59,42.94-74.38.85-1.47,1.66-2.96,2.54-4.41,3.92-6.44,12.96-11.27,19.96-11.39s14.12,0,21.18,0c35.1,0,70.2,0,105.29,0,37.1,0,74.2,0,111.3,0h28.05c9.27,0,18.01,4.43,22.88,12.8,12.71,21.84,25.27,43.76,37.9,65.64,20,34.64,40,69.28,60,103.92,11.74,20.34,23.43,40.72,35.23,61.03,3.4,5.85,3.95,15.58.91,22.1-.69,1.48-2.39,4.12-3.5,6.05-6.88,11.92-13.76,23.84-20.65,35.76-19.02,32.94-38.04,65.89-57.06,98.83-3.71,6.42-7.42,12.84-11.12,19.27-7.74,13.4,12.99,25.5,20.72,12.11h0Z" fill="currentColor"/>
        </g>
      </g>
      <circle cx="486.5" cy="304.5" r="41.5" fill="url(#sp-logo-grad)"/>
    </g>
  </g>
</svg>`
});
import { ToolService } from '../LLM/ToolService';
import { NotebookContextManager } from './NotebookContextManager';
import {
  subscribeToNotebookChange,
  useNotebookEventsStore
} from '../stores/notebookEventsStore';
import { useServicesStore } from '../stores/servicesStore';
import { useAppStore } from '../stores/appStore';
import { ActionHistory } from '@/ChatBox/services/ActionHistory';
import { ChatBox } from '@/ChatBox';
import { useChatboxStore } from '../stores/chatboxStore';
import { useChatHistoryStore } from '../stores/chatHistoryStore';

/**
 * React component for the chat container
 * Now uses the pure React ChatBox component
 */
function ChatContainerContent({
  onReady
}: {
  onReady?: () => void;
}): JSX.Element {
  // Get notebook ID directly from store for immediate updates
  const notebookId = useNotebookEventsStore(state => state.currentNotebookId);

  // Debug logging
  console.log('[ChatContainerContent] Rendering with notebookId:', notebookId);

  return (
    <div className="sage-ai-chat-container-inner h-100">
      <ChatBox onReady={onReady} className="h-100" />
    </div>
  );
}

/**
 * Container widget that holds the chat interface
 *
 * This is the new implementation using pure React ChatBox component
 * instead of the legacy ChatBoxWidget.
 */
export class NotebookChatContainer extends ReactWidget {
  private toolService: ToolService;
  private contextManager: NotebookContextManager | null;
  private actionHistory: ActionHistory;
  private currentNotebookId: string | null = null;
  private _isReady: boolean = false;

  constructor(
    toolService: ToolService,
    contextManager: NotebookContextManager | null | undefined,
    actionHistory: ActionHistory
  ) {
    super();

    this.id = 'sage-ai-chat-container';
    this.title.icon = spLogoIcon;
    this.title.label = 'Agent Chat';
    this.title.caption = 'Agent Chat';
    this.title.closable = true;
    this.addClass('sage-ai-chat-container');
    this.toolService = toolService;
    this.contextManager = contextManager || null;
    this.actionHistory = actionHistory;

    // Set the minimum width of the widget's node
    this.node.style.minWidth = '320px';

    // Initialize the chatbox store with services
    this.initializeStoreServices();

    // Subscribe to notebook changes from store
    subscribeToNotebookChange(async ({ newNotebookId, fromLauncher }) => {
      if (
        newNotebookId &&
        (fromLauncher || newNotebookId !== this.currentNotebookId)
      ) {
        await this.switchToNotebook(newNotebookId, fromLauncher);
      }
    });
  }

  /**
   * Legacy compatibility: get chatWidget property
   * Returns a compatibility object for code that expects chatWidget
   */
  public get chatWidget(): any {
    // Return a compatibility shim that redirects to store actions
    return {
      isFullyReady: () => this.isFullyReady(),
      setInputValue: (value: string) => {
        const {
          useChatInputStore
        } = require('../stores/chatInput/chatInputStore');
        useChatInputStore.getState().setInputValue(value);
      },
      sendMessage: async () => {
        // Trigger send through store
        console.log('[NotebookChatContainer] sendMessage called via shim');
      },
      cancelMessage: () => {
        // Cancel message through store
        console.log('[NotebookChatContainer] cancelMessage called via shim');
        useChatboxStore.getState().cancelMessage();
      },
      startWelcomeMessagePreload: () => {
        useChatboxStore.getState().setWelcomeMessagePreloaded(true);
      },
      showWelcomeMessage: () => {
        useChatboxStore.getState().setHasShownWelcomeMessage(true);
      },
      reinitializeForNotebook: async (notebookId: string) => {
        await this.switchToNotebook(notebookId, true);
      },
      setNotebookId: async (notebookId: string) => {
        await this.switchToNotebook(notebookId, false);
      },
      updateNotebookPath: (path: string) => {
        useChatboxStore.getState().updateNotebookPath(path);
      },
      onCellAddedToContext: (path: string) => this.onCellAddedToContext(path),
      onCellRemovedFromContext: (path: string) =>
        this.onCellRemovedFromContext(path),
      updateTokenProgress: () => {
        // Token progress is handled by ChatInputContainer's internal state
        // This triggers a recalculation via the store
        const services = useChatboxStore.getState().services;
        if (services.messageComponent) {
          const messages = services.messageComponent.getMessageHistory();
          // The actual token calculation happens in ChatInputContainer
          // This is a no-op here since token progress is managed reactively
          console.log(
            '[NotebookChatContainer] updateTokenProgress called, messages:',
            messages.length
          );
        }
      },
      // Expose messageComponent for legacy code that accesses chatWidget.messageComponent
      get messageComponent() {
        return useChatboxStore.getState().services.messageComponent;
      },
      // threadManager is null - its functionality is handled by ChatHistoryManager directly
      threadManager: null,
      // Expose chatHistoryManager for legacy code that accesses it
      get chatHistoryManager() {
        return useChatboxStore.getState().services.chatHistoryManager;
      },
      // Expose llmStateDisplay for legacy code that accesses it
      get llmStateDisplay() {
        return useServicesStore.getState().llmStateDisplay;
      },
      // Expose conversationService for legacy code that accesses it
      get conversationService() {
        return useChatboxStore.getState().services.conversationService;
      },
      isDisposed: this.isDisposed
    };
  }

  /**
   * Render the React component
   */
  render(): JSX.Element {
    return (
      <ChatContainerContent
        onReady={() => {
          this._isReady = true;
          console.log('[NotebookChatContainer] ChatBox is ready');
        }}
      />
    );
  }

  /**
   * Check if the chat is fully ready
   */
  public isFullyReady(): boolean {
    return this._isReady && useChatboxStore.getState().isReady;
  }

  public updateNotebookId(oldNotebookId: string, newNotebookId: string): void {
    this.contextManager?.updateNotebookId(oldNotebookId, newNotebookId);

    // Update through stores
    useChatboxStore.getState().updateNotebookId(newNotebookId);

    this.toolService.updateNotebookId(oldNotebookId, newNotebookId);
    this.currentNotebookId = newNotebookId;
  }

  /**
   * Switch to a different notebook
   */
  public async switchToNotebook(
    notebookId: string,
    fromLauncher?: boolean
  ): Promise<void> {
    console.log('[NotebookChatContainer] Switching to notebook:', notebookId);
    console.log('[NotebookChatContainer] From launcher:', fromLauncher);

    if (!fromLauncher && this.currentNotebookId === notebookId) {
      return;
    }

    const previousNotebookId = this.currentNotebookId;
    this.currentNotebookId = notebookId;

    // Update the tool service
    this.toolService.setCurrentNotebookId(notebookId);

    // Update context manager
    if (this.contextManager) {
      this.contextManager.getContext(notebookId);
    }

    // Update stores
    if (fromLauncher || !previousNotebookId) {
      console.log('[NotebookChatContainer] Full re-initialization');
      if (useAppStore.getState().isDemoMode) {
        await new Promise(resolve => setTimeout(resolve, 100));
      }
      await useChatboxStore.getState().reinitializeForNotebook(notebookId);
    } else {
      await useChatboxStore.getState().setNotebookId(notebookId);
    }

    // Load threads for this notebook
    await useChatHistoryStore.getState().loadThreads(notebookId);

    // Force re-render
    this.update();
  }

  /**
   * Handle a cell added to context
   */
  public onCellAddedToContext(notebookId: string): void {
    if (!this.currentNotebookId || this.currentNotebookId !== notebookId) {
      console.warn(
        `Cannot add cell from ${notebookId} to context when current notebook is ${this.currentNotebookId}`
      );
      return;
    }
    useChatboxStore.getState().onCellAddedToContext(notebookId);
  }

  /**
   * Handle a cell removed from context
   */
  public onCellRemovedFromContext(notebookId: string): void {
    if (!this.currentNotebookId || this.currentNotebookId !== notebookId) {
      console.warn(
        `Cannot remove cell from ${notebookId} context when current notebook is ${this.currentNotebookId}`
      );
      return;
    }
    useChatboxStore.getState().onCellRemovedFromContext(notebookId);
  }

  /**
   * Initialize the chatbox store with service references
   */
  private initializeStoreServices(): void {
    // Get services from servicesStore
    const servicesState = useServicesStore.getState();

    useChatboxStore.getState().setServices({
      conversationService: null, // Will be wired later
      chatHistoryManager: null, // Will be wired later
      threadManager: null, // Will be set when available
      chatService: servicesState.chatService || null,
      messageComponent: null, // Will be set when ChatBox mounts
      uiHelper: null
    });
  }
}
