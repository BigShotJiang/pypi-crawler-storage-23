"""MCP server package for SignalPilot tools."""
