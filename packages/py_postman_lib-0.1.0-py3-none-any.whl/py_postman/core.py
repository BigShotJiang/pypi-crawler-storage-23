import smtplib
import asyncio
import aiosmtplib
import urllib.request
import json

from .providers import PROVIDERS, SMTPConfig
from .message import MessageBuilder


class AsyncMailSession:

    def __init__(self, postman):
        self.postman = postman
        self.client = None

    async def __aenter__(self):
        if self.postman.test_mode:
            return self

        self.client = aiosmtplib.SMTP(
            hostname=self.postman.config.host,
            port=self.postman.config.port,
            use_tls=self.postman.config.use_ssl,
            start_tls=self.postman.config.use_tls and not self.postman.config.use_ssl
        )
        await self.client.connect()
        await self.client.login(self.postman.email, self.postman.password)
        return self

    async def __aexit__(self, exc_type, exc, tb):
        if self.client:
            await self.client.quit()

    async def send_async(self, to: str | list[str], subject: str, **kwargs):
        if self.postman.test_mode:
            print(f"[TEST MODE 🟡] Session: Email '{subject}' to {to} has been 'sent'.")
            return True

        msg = self.postman._build_msg({"to": to, "subject": subject, **kwargs})
        try:
            await self.client.send_message(msg)
            return True
        except Exception as e:
            print(f"Session error: {e}")
            await self.postman._notify_tg_async(f"Session error: {e}")
            return False


class Postman:
    def __init__(self, email: str, password: str, provider: str = None, custom_config: dict = None,
                 test_mode: bool = False, tg_token: str = None, tg_chat_id: str = None):
        self.email = email
        self.password = password
        self.test_mode = test_mode
        self.tg_token = tg_token
        self.tg_chat_id = tg_chat_id

        if provider:
            provider_key = provider.lower()
            if provider_key not in PROVIDERS:
                raise ValueError(f"Provider '{provider}' is not supported.")
            self.config = PROVIDERS[provider_key]
        elif custom_config:
            self.config = SMTPConfig(**custom_config)
        else:
            raise ValueError("Specify either a provider or a custom_config")

    def _build_msg(self, kwargs_dict):
        return MessageBuilder.build(sender=self.email, **kwargs_dict)

    def _notify_tg(self, error_msg: str):
        """Synchronously sends an error log to Telegram."""
        if not (self.tg_token and self.tg_chat_id):
            return
        try:
            url = f"https://api.telegram.org/bot{self.tg_token}/sendMessage"
            data = json.dumps({
                "chat_id": self.tg_chat_id,
                "text": f"🚨 <b>py-postman Error:</b>\n<pre>{error_msg}</pre>",
                "parse_mode": "HTML"
            }).encode('utf-8')
            req = urllib.request.Request(url, data=data, headers={'Content-Type': 'application/json'})
            urllib.request.urlopen(req, timeout=5)
        except Exception as e:
            print(f"Failed to send log to Telegram: {e}")

    async def _notify_tg_async(self, error_msg: str):
        """Asynchronously sends a log (does not block the Event Loop)."""
        if self.tg_token and self.tg_chat_id:
            await asyncio.to_thread(self._notify_tg, error_msg)

    def save_draft(self, filename: str, to: str | list[str], subject: str, **kwargs):
        """Saves the email to disk in .eml format (draft)."""
        msg = self._build_msg({"to": to, "subject": subject, **kwargs})
        with open(filename, 'wb') as f:
            f.write(bytes(msg))
        return True

    def get_async_session(self):
        """Returns a context manager to maintain the connection."""
        return AsyncMailSession(self)

    def send(self, to: str | list[str], subject: str, **kwargs):
        if self.test_mode:
            print(f"[TEST MODE 🟡] Email '{subject}' to {to} was successfully 'sent' (sandbox).")
            return True

        msg = self._build_msg({"to": to, "subject": subject, **kwargs})
        try:
            if self.config.use_ssl:
                server = smtplib.SMTP_SSL(self.config.host, self.config.port)
            else:
                server = smtplib.SMTP(self.config.host, self.config.port)
                if self.config.use_tls:
                    server.starttls()
            server.login(self.email, self.password)
            server.send_message(msg)
            server.quit()
            return True
        except Exception as e:
            print(f"Error during sending: {e}")
            self._notify_tg(str(e))
            return False

    async def send_async(self, to: str | list[str], subject: str, **kwargs):
        if self.test_mode:
            print(f"[TEST MODE 🟡] Async-Email '{subject}' to {to} was successfully 'sent' (sandbox).")
            return True

        msg = self._build_msg({"to": to, "subject": subject, **kwargs})
        try:
            client = aiosmtplib.SMTP(
                hostname=self.config.host,
                port=self.config.port,
                use_tls=self.config.use_ssl,
                start_tls=self.config.use_tls and not self.config.use_ssl
            )
            async with client:
                await client.login(self.email, self.password)
                await client.send_message(msg)
            return True
        except Exception as e:
            print(f"Async sending error: {e}")
            await self._notify_tg_async(str(e))
            return False
