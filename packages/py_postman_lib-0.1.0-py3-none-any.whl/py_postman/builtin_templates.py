BUILTIN_TEMPLATES = {
    "welcome": """
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px;">
        <h2 style="color: #4CAF50; text-align: center;">Welcome, {{ name }}! 🎉</h2>
        <p style="font-size: 16px; color: #333;">We are glad to have you on board. Your account has been successfully created!</p>
        <div style="text-align: center; margin-top: 20px;">
            <a href="{{ link }}" style="background-color: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Get Started</a>
        </div>
    </div>
    """,
    "reset_password": """
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px;">
        <h2 style="color: #FF5722; text-align: center;">Password Reset 🔒</h2>
        <p style="font-size: 16px; color: #333;">Hi, {{ name }}! Someone requested a password reset for your account.</p>
        <p>Confirmation code: <b style="font-size: 20px; color: #000;">{{ code }}</b></p>
        <p style="font-size: 12px; color: #777;">If this was not you, please ignore this email.</p>
    </div>
    """
}
