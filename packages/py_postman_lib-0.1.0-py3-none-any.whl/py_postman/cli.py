import argparse
from .core import Postman

def main():
    parser = argparse.ArgumentParser(description="py-postman CLI 🚀 - Send emails from the console")
    parser.add_argument("--email", required=True, help="Your email (sender)")
    parser.add_argument("--password", required=True, help="App Password")
    parser.add_argument("--provider", default="gmail", help="Provider (gmail, yandex, mail.ru, outlook)")
    parser.add_argument("--to", required=True, help="Recipient's email")
    parser.add_argument("--subject", required=True, help="Email subject")
    parser.add_argument("--text", default="", help="Plain text content of the email")
    parser.add_argument("--attach", nargs="*", help="Paths to files for attachments (space-separated)")

    args = parser.parse_args()

    mailer = Postman(email=args.email, password=args.password, provider=args.provider)
    print(f"⏳ Sending email to {args.to}...")

    success = mailer.send(to=args.to, subject=args.subject, text=args.text, attachments=args.attach)

    if success:
        print("✅ Sent successfully!")
    else:
        print("❌ Sending failed. Please check your data.")

if __name__ == "__main__":
    main()
