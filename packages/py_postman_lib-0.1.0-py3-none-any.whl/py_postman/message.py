import os
import mimetypes
import textwrap
import uuid
import datetime
import zipfile
import io
from email.message import EmailMessage
from jinja2 import Template
import markdown as md

from .builtin_templates import BUILTIN_TEMPLATES

class MessageBuilder:
    @staticmethod
    def build(sender: str, to: str | list[str], subject: str,
              text: str = "", html: str = "", markdown: str = "",
              template_str: str = "", builtin_template: str = "", template_context: dict = None,
              attachments: list[str] = None, attachments_bytes: list[dict] = None,
              inline_images: dict = None, calendar_event: dict = None,
              cc: str | list[str] = None, bcc: str | list[str] = None,
              reply_to: str = None, priority: str = "normal",
              tracking_url: str = None, auto_zip: bool = False) -> EmailMessage:

        msg = EmailMessage()
        msg['Subject'] = subject
        msg['From'] = sender
        msg['To'] = ", ".join(to) if isinstance(to, list) else to

        if cc: msg['Cc'] = ", ".join(cc) if isinstance(cc, list) else cc
        if bcc: msg['Bcc'] = ", ".join(bcc) if isinstance(bcc, list) else bcc
        if reply_to: msg['Reply-To'] = reply_to

        if priority.lower() == 'high':
            msg['X-Priority'] = '1 (Highest)'
            msg['Importance'] = 'High'

        if builtin_template:
            template_str = BUILTIN_TEMPLATES.get(builtin_template.lower(), "")

        if template_str and template_context:
            template = Template(template_str)
            html = template.render(**template_context)

        if markdown:
            clean_md = textwrap.dedent(markdown).strip()
            html = md.markdown(clean_md, extensions=['extra'])
            text = clean_md

        if tracking_url and html:
            pixel = f'<img src="{tracking_url}" width="1" height="1" style="display:none;" alt=""/>'
            if "</body>" in html.lower():
                html = html.replace("</body>", f"{pixel}</body>", 1)
            else:
                html += pixel

        if html:
            msg.set_content(text or "Please enable HTML to view this message.")
            msg.add_alternative(html, subtype='html')
        else:
            msg.set_content(text)

        if auto_zip and attachments:
            files_added = 0
            zip_buffer = io.BytesIO()
            with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
                for filepath in attachments:
                    if os.path.exists(filepath):
                        zip_file.write(filepath, arcname=os.path.basename(filepath))
                        files_added += 1

            if files_added > 0:
                zip_buffer.seek(0)
                msg.add_attachment(zip_buffer.read(), maintype='application', subtype='zip', filename='attachments.zip')
            attachments = None

        if attachments:
            for filepath in attachments:
                if not os.path.exists(filepath):
                    continue
                ctype, _ = mimetypes.guess_type(filepath)
                maintype, subtype = (ctype or 'application/octet-stream').split('/', 1)
                with open(filepath, 'rb') as f:
                    msg.add_attachment(f.read(), maintype=maintype, subtype=subtype,
                                       filename=os.path.basename(filepath))

        if attachments_bytes:
            for file_obj in attachments_bytes:
                mime = file_obj.get('mime_type', 'application/octet-stream')
                maintype, subtype = mime.split('/', 1) if '/' in mime else ('application', 'octet-stream')
                msg.add_attachment(file_obj['data'], maintype=maintype, subtype=subtype, filename=file_obj['name'])

        if inline_images:
            for cid_name, filepath in inline_images.items():
                if os.path.exists(filepath):
                    ctype, _ = mimetypes.guess_type(filepath)
                    maintype, subtype = (ctype or 'image/png').split('/', 1)
                    with open(filepath, 'rb') as f:
                        msg.get_payload()[1].add_related(f.read(), maintype=maintype, subtype=subtype,
                                                         cid=f"<{cid_name}>")

        if calendar_event:
            dtstamp = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
            event_uid = str(uuid.uuid4())
            ics_content = (
                "BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//py-postman//EN\nMETHOD:REQUEST\n"
                "BEGIN:VEVENT\n"
                f"UID:{event_uid}\n"
                f"DTSTAMP:{dtstamp}\n"
                f"SUMMARY:{calendar_event.get('title', 'Event')}\n"
                f"DTSTART:{calendar_event.get('start', '')}\n"
                f"DTEND:{calendar_event.get('end', '')}\n"
                f"LOCATION:{calendar_event.get('location', '')}\n"
                "END:VEVENT\nEND:VCALENDAR"
            )
            msg.add_attachment(ics_content.encode('utf-8'), maintype='text', subtype='calendar', filename='invite.ics',
                               params={'method': 'REQUEST'})

        return msg
