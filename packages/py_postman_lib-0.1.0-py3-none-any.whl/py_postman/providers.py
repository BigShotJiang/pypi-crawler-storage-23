from dataclasses import dataclass

@dataclass
class SMTPConfig:
    host: str
    port: int
    use_tls: bool = True
    use_ssl: bool = False

PROVIDERS = {
    "gmail": SMTPConfig(host="smtp.gmail.com", port=587, use_tls=True),
    "yandex": SMTPConfig(host="smtp.yandex.ru", port=465, use_ssl=True, use_tls=False),
    "mail.ru": SMTPConfig(host="smtp.mail.ru", port=465, use_ssl=True, use_tls=False),
    "outlook": SMTPConfig(host="smtp-mail.outlook.com", port=587, use_tls=True)
}
