"""Media management for ragnarbot."""

from ragnarbot.media.manager import MediaManager

__all__ = ["MediaManager"]
