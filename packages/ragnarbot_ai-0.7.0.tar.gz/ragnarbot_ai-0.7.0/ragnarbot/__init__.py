"""
ragnarbot - A lightweight AI agent framework
"""

__version__ = "0.7.0"
__logo__ = "🤖"
