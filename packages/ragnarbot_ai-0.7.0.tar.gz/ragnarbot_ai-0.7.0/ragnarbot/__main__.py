"""
Entry point for running ragnarbot as a module: python -m ragnarbot
"""

from ragnarbot.cli.commands import app

if __name__ == "__main__":
    app()
