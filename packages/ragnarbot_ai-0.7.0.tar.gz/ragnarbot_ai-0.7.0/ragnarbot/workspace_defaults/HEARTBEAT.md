<!-- Heartbeat task file — checked at the interval configured in heartbeat.intervalM (default: 30 minutes).
     Use the heartbeat tool to add/remove/edit tasks.
     Format: each task is a block wrapped in --- separators with a [ID] prefix.
     Empty file = heartbeat skipped silently. -->
