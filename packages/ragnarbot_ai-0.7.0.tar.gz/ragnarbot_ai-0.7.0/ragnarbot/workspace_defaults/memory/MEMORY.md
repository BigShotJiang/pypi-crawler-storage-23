# Long-term Memory

_Persistent knowledge that helps across sessions. Technical discoveries, environment details, project context, patterns, gotchas — anything that isn't about the user's profile or your identity._

_Keep it concise and up to date._
