# Identity

_Who you are. Your name, personality, tone of voice, quirks, behavioral patterns — your character sheet._

_Fill this out during bootstrap or whenever the user shapes your identity. Keep it concise and up to date._
