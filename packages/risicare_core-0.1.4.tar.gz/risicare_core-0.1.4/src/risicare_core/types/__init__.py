"""
Risicare Core Types.

This subpackage contains all type definitions for the Risicare SDK.
"""

from risicare_core.types.base import (
    AgentID,
    AgentRole,
    EvaluationType,
    FixType,
    MessageType,
    Metadata,
    SemanticPhase,
    SessionID,
    SpanID,
    SpanKind,
    SpanStatus,
    TimeRange,
    Timestamp,
    TraceFlags,
    TraceID,
    generate_agent_id,
    generate_session_id,
    generate_span_id,
    generate_trace_id,
    utc_now,
    validate_span_id,
    validate_trace_id,
)
from risicare_core.types.spans import (
    ExceptionInfo,
    LLMAttributes,
    Span,
    SpanEvent,
    SpanLink,
)

__all__ = [
    # Type aliases
    "TraceID",
    "SpanID",
    "SessionID",
    "AgentID",
    "Timestamp",
    "Metadata",
    # Enumerations
    "SpanKind",
    "SpanStatus",
    "TraceFlags",
    "AgentRole",
    "MessageType",
    "SemanticPhase",
    "EvaluationType",
    "FixType",
    # Data classes
    "TimeRange",
    "SpanEvent",
    "SpanLink",
    "ExceptionInfo",
    "LLMAttributes",
    "Span",
    # Functions
    "generate_trace_id",
    "generate_span_id",
    "generate_session_id",
    "generate_agent_id",
    "utc_now",
    "validate_trace_id",
    "validate_span_id",
]
