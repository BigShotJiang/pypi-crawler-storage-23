# risicare-core

Shared types, context propagation, and error taxonomy for [Risicare](https://risicare.ai) — self-healing infrastructure for AI agents.

This package is a dependency of the [`risicare`](https://pypi.org/project/risicare/) SDK. You typically don't install it directly.

```bash
pip install risicare
```

## What's Inside

- **Type system** — `Span`, `SpanKind`, `SpanStatus`, `LLMAttributes`, ID generation
- **Context propagation** — Thread-safe and async-safe session/agent/phase tracking via `contextvars`
- **Error taxonomy** — 154 error codes across 10 modules (Perception, Reasoning, Tool, Memory, Output, Coordination, Communication, Orchestration, Consensus, Resources)
- **Observability** — Prometheus-compatible metrics and context health reporting

Zero external dependencies. Pure Python 3.10+.

## Links

- [Risicare Documentation](https://risicare.ai/docs)
- [Risicare SDK](https://pypi.org/project/risicare/)
