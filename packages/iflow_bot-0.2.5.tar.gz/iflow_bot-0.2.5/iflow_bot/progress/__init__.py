"""Progress monitoring module for long-running iflow tasks.

Ported from feishu-iflow-bridge/src/modules/ProgressManager.js
"""
