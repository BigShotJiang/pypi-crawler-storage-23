import ftplib
import os

from modulitiz_mini.rete.ftp.FtpReturnBean import FtpReturnBean
from modulitiz_nano.ModuloListe import ModuloListe
from modulitiz_nano.ModuloStringhe import ModuloStringhe
from modulitiz_nano.files.ModuloFiles import ModuloFiles


class ModuloFtp(object):
	DEFAULT_FTP_PORT=ftplib.FTP_PORT
	
	def __init__(self,host:str,username:str,password:str):
		self.host=host
		self.port=self.DEFAULT_FTP_PORT
		self.username=username
		self.password=password
		self.conn:ftplib.FTP|None=None
		self.isConnected=False
	
	def connect(self)->str:
		conn=ftplib.FTP(encoding=ModuloStringhe.CODIFICA_LATIN1)
		try:
			conn.connect(self.host,self.port)
			welcomeMsg=conn.welcome
		except UnicodeDecodeError as udError:
			welcomeMsg=udError.object.decode(ModuloStringhe.CODIFICA_ASCII,'ignore')
		conn.login(self.username,self.password)
		self.conn=conn
		self.isConnected=True
		return welcomeMsg
	
	def uploadCartella(self,rootLocal:str,rootRemote:str,
			excludeFiles:list|tuple,excludeDirs:list|tuple,
			minByteSize:int|None,maxByteSize:int|None):
		rootLocal=ModuloFiles.normalizzaPercorsoLocale(rootLocal)
		rootRemote=ModuloFiles.normalizzaPercorsoRemoto(rootRemote)
		countFiles=countDirs=0
		
		for percorsoLocaleRel,percorsoLocaleAbs,folders,nomefiles in ModuloFiles.walk(rootLocal,excludeFiles,excludeDirs,minByteSize,maxByteSize):
			percorso_remoto_abs=ModuloFiles.normalizzaPercorsoRemoto(ModuloFiles.pathJoin(rootRemote,percorsoLocaleRel))
			# carico i file contenuti nella cartella corrente
			for nomefile in nomefiles:
				self.uploadFile(percorsoLocaleAbs,percorso_remoto_abs,nomefile,False)
				countFiles+=1
				yield FtpReturnBean(percorso_remoto_abs,nomefile,True,countFiles,countDirs)
			# upload folders
			for cartella in folders:
				cartella=ModuloFiles.normalizzaPercorsoRemoto(ModuloFiles.pathJoin(percorso_remoto_abs,cartella))
				try:
					self.conn.mkd(cartella)
				except Exception:
					pass
				countDirs+=1
				yield FtpReturnBean(percorso_remoto_abs,cartella,False,countFiles,countDirs)
	
	def uploadFile(self,pathLocal:str,pathRemote:str,filename:str,renameIfExist:bool)->str:
		filenameLocal=ModuloFiles.pathJoin(pathLocal,filename)
		filenameRemote=ModuloFiles.normalizzaPercorsoRemoto(ModuloFiles.pathJoin(pathRemote,filename))
		if renameIfExist is True and self.isFile(filenameRemote):
			filenameRemote=ModuloStringhe.addTimestamp(filenameRemote)
		# carico il file
		with open(filenameLocal,'rb') as fp:
			self.conn.storbinary("STOR "+filenameRemote,fp)
		return filenameRemote
	
	def downloadCartella(self,pathRemote:str,pathLocal:str,excludeFiles: list|tuple,excludeDirs: list|tuple):
		pathRemote=ModuloFiles.normalizzaPercorsoRemoto(pathRemote)
		return self.__downloadCartella(pathRemote,pathLocal,excludeFiles,excludeDirs)
	
	def downloadFile(self,filePathRemote:str,filePathLocal:str):
		filePathRemote=ModuloFiles.normalizzaPercorsoRemoto(filePathRemote)
		filePathLocal=ModuloFiles.normalizzaPercorsoLocale(filePathLocal)
		# creo le cartelle locali
		pathDirLocal=os.path.dirname(filePathLocal)
		os.makedirs(pathDirLocal,exist_ok=True)
		# scarico il file
		with open(filePathLocal,"wb") as fp:
			self.conn.retrbinary("RETR "+filePathRemote,fp.write)
	
	def eliminaCartella(self,pathRemote:str,excludeFiles: list|tuple,excludeDirs: list|tuple):
		pathRemote=ModuloFiles.normalizzaPercorsoRemoto(pathRemote)
		return self.__eliminaCartella(pathRemote,'.',excludeFiles,excludeDirs)
	
	def listaContenutoCartella(self,pathRemote:str)->list:
		elements = []
		if self.isFile(pathRemote):
			return elements
		if not pathRemote.startswith(('.','/')):
			pathRemote="./"+pathRemote
		cmd = "NLST -a "+pathRemote
		try:
			self.conn.retrlines(cmd, elements.append)
			elements.sort()
			# elimino . e ..
			elements=elements[2:]
		except ftplib.error_perm:
			pass
		return elements
	
	def mkdirs(self,pathRemote:str):
		pathRemote=ModuloFiles.normalizzaPercorsoRemoto(pathRemote)
		folders=ModuloListe.eliminaElementiVuoti(pathRemote.split("/"))
		pathCurrent=""
		for folder in folders:
			pathCurrent=ModuloFiles.normalizzaPercorsoRemoto(ModuloFiles.pathJoin(pathCurrent,folder))
			try:
				self.conn.mkd(pathCurrent)
			except Exception:
				pass
	
	def chiudi(self):
		"""
		chiude la connessione
		"""
		if not self.isConnected:
			return
		try:
			self.conn.quit()
		except Exception:
			self.conn.close()
		finally:
			self.isConnected = False
	
	def getFileSize(self,filePathRemote:str)->int:
		try:
			self.conn.voidcmd('TYPE I')
			size=self.conn.size(filePathRemote)
			return size
		except Exception:
			return -1
	
	def isFile(self,element:str)->bool:
		"""
		controlla se un oggetto e' un file o una cartella
		"""
		return self.getFileSize(element)>=0
	
	def goParentDir(self):
		# bisogna per forza usare 2 punti, se c'e' anche lo slash finale non funziona
		self.conn.cwd("..")
	
	
	def __downloadCartella(self,pathRemote:str,pathLocal:str,
			excludeFiles: list|tuple,excludeDirs: list|tuple,
			countFiles:int=0,countDirs:int=1):
		"""
		funzione ricorsiva
		"""
		elements=self.listaContenutoCartella(pathRemote)
		for element in elements:
			elementRelPath=element
			if elementRelPath.startswith("/"):
				elementRelPath=elementRelPath[1:]
			elementRemote=ModuloFiles.normalizzaPercorsoRemoto(element)
			elementLocal=ModuloFiles.pathJoin(pathLocal,elementRelPath)
			# controllo se l'elemento e' un file o una cartella
			if self.isFile(elementRemote):
				os.makedirs(os.path.dirname(elementLocal),exist_ok=True)
				if elementRemote not in excludeFiles:
					self.downloadFile(elementRemote,elementLocal)
					countFiles+=1
					yield FtpReturnBean(pathRemote,element,True,countFiles,countDirs)
			else:
				countDirs+=1
				# creo la cartella
				if ModuloListe.stringContainsCollection(elementRemote,excludeDirs):
					yield FtpReturnBean(pathRemote,element,True,countFiles,countDirs)
					break
				os.makedirs(elementLocal,exist_ok=True)
				yield FtpReturnBean(pathRemote,element,False,countFiles,countDirs)
				# entro ed elaboro la sottocartella
				for bean in self.__downloadCartella(elementRemote,pathLocal,excludeFiles,excludeDirs,
						countFiles,countDirs):
					countFiles=bean.countFiles
					countDirs=bean.countDirs
					yield bean
	
	def __eliminaCartella(self,rootRemote:str,pathRemoteRel:str,
			excludeFiles: list|tuple,excludeDirs: list|tuple):
		"""
		funzione ricorsiva
		"""
		countFiles=countDirs=0
		elements=self.listaContenutoCartella(pathRemoteRel)
		for element in elements:
			elementRemoteRel=element
			elementRemoteAbs=ModuloFiles.pathJoin("/",element)
			# controllo se e' un file o una cartella
			if self.isFile(elementRemoteAbs):
				if ModuloListe.collectionContainsString(excludeDirs,pathRemoteRel) is False and elementRemoteRel not in excludeFiles:
					self.conn.delete(elementRemoteAbs)
					countFiles+=1
					yield FtpReturnBean(pathRemoteRel,element,True,countFiles,countDirs)
			else:
				# entro ed elaboro la sottocartella
				if not ModuloListe.collectionContainsString(excludeDirs,elementRemoteRel):
					countFilesSubDir=countDirsSubDir=0
					for bean in self.__eliminaCartella(rootRemote,elementRemoteRel,excludeFiles,excludeDirs):
						countFilesSubDir=bean.countFiles+countFiles
						countDirsSubDir=bean.countDirs+countDirs
						bean.countFiles=countFilesSubDir
						bean.countDirs=countDirsSubDir
						yield bean
					countFiles=countFilesSubDir
					countDirs=countDirsSubDir
					# cancello la cartella dopo aver cancellato i file al suo interno
					if not ModuloListe.collectionContainsString(excludeDirs,elementRemoteRel):
						self.conn.rmd(elementRemoteAbs)
						countDirs+=1
						yield FtpReturnBean(pathRemoteRel,element,False,countFiles,countDirs)
