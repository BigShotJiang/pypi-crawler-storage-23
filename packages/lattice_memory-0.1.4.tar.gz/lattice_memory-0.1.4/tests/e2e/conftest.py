"""
Pytest configuration for E2E tests.

The --run-e2e option is registered in tests/conftest.py and can be used
to explicitly enable tests that require real LLM API access.

Most tests in this directory run locally without external dependencies.
Only test_real_llm.py requires API keys and needs the --run-e2e flag.
"""

import pytest


def pytest_collection_modifyitems(config, items):
    """Skip LLM tests unless --run-e2e is specified."""
    if not config.getoption("--run-e2e"):
        skip_real_llm = pytest.mark.skip(reason="Use --run-e2e to run real LLM tests")
        for item in items:
            # Only skip tests in test_real_llm.py (real LLM tests)
            if "test_real_llm" in item.nodeid:
                item.add_marker(skip_real_llm)
