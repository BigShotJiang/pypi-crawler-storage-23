"""
Shell module — I/O adapters.

Rules:
- All public functions must return Result[T, E] from 'returns' library
- Handle all I/O operations (file, network, database, environment)
- Wrap Core functions for external use
"""

# Placeholder for shell implementations
# Will be implemented in P1-S3 onwards
