"""Enum types for Lattice."""

from enum import Enum


class Role(str, Enum):
    """Message role in a conversation turn."""

    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


class PatternType(str, Enum):
    """Type of pattern identified by the Compiler."""

    CONVENTION = "convention"
    BUG_PATTERN = "bug-pattern"
    PREFERENCE = "preference"
    ARCHITECTURE = "architecture"


class ProposalAction(str, Enum):
    """Action to take on a rule proposal."""

    ADD = "add"
    MERGE = "merge"
    REMOVE = "remove"
    UPDATE = "update"


class Scope(str, Enum):
    """Search scope."""

    PROJECT = "project"
    GLOBAL = "global"


class EventType(str, Enum):
    """Type of event in a session log.

    Used for compression decisions: user/assistant/reasoning are high-signal
    and kept in full; tool events only store metadata (input, status, error),
    not raw output.

    >>> EventType.USER.value
    'user'
    >>> EventType.TOOL.value
    'tool'
    """

    USER = "user"
    ASSISTANT = "assistant"
    REASONING = "reasoning"
    TOOL = "tool"
