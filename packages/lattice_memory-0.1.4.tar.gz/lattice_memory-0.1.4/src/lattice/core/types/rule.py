"""Rule types for Lattice."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import deal


@dataclass(frozen=True)
class Rule:
    """A rule from rules/*.md file.

    >>> rule = Rule(
    ...     file_path="conventions.md",
    ...     title="Use snake_case",
    ...     content="Always use snake_case for Python variables.",
    ...     token_count=10,
    ... )
    >>> rule.file_path
    'conventions.md'
    """

    file_path: str
    title: str
    content: str
    token_count: int = 0
    is_promoted: bool = False
    is_override: bool = False

    @deal.post(lambda result: isinstance(result, Rule))
    def with_metadata(self, **kwargs: Any) -> "Rule":
        """Return a copy with updated metadata.

        >>> rule = Rule(file_path="test.md", title="Test", content="Content")
        >>> rule.with_metadata(token_count=5).token_count
        5
        """
        return Rule(
            file_path=kwargs.get("file_path", self.file_path),
            title=kwargs.get("title", self.title),
            content=kwargs.get("content", self.content),
            token_count=kwargs.get("token_count", self.token_count),
            is_promoted=kwargs.get("is_promoted", self.is_promoted),
            is_override=kwargs.get("is_override", self.is_override),
        )


@dataclass(frozen=True)
class RuleDiff:
    """Diff between old and new rule content.

    >>> diff = RuleDiff(
    ...     file_path="conventions.md",
    ...     old_content="old",
    ...     new_content="new",
    ... )
    >>> diff.file_path
    'conventions.md'
    """

    file_path: str
    old_content: str | None
    new_content: str
