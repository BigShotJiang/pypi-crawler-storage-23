""" Used for PyTest """

from .client import AOTY

__all__ = ["AOTY"]
