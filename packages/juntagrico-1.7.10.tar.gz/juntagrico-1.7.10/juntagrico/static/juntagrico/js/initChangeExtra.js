/*global define*/
define([], function () {

    $("input[type='number']").inputSpinner();

});