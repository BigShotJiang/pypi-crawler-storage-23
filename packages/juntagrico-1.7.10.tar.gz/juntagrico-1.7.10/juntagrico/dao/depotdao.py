from juntagrico.entity.depot import Depot


class DepotDao:

    @staticmethod
    def all_depots():
        return Depot.objects.all()

    @staticmethod
    def all_depots_ordered():
        return Depot.objects.all()

    @staticmethod
    def all_visible_depots():
        return Depot.objects.all().filter(visible=True)

    @staticmethod
    def all_visible_depots_with_map_info():
        depots = DepotDao.all_visible_depots()
        depots.map_info = [depot.map_info for depot in depots]
        return depots

    @staticmethod
    def all_depots_for_list():
        return Depot.objects.all().filter(depot_list=True)

    @staticmethod
    def depots_for_contact(member):
        return Depot.objects.filter(contact=member)

    @staticmethod
    def depot_by_id(identifier):
        return Depot.objects.all().filter(id=identifier)[0]
