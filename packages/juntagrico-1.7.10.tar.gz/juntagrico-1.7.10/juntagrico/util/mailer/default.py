class Mailer:
    @staticmethod
    def send(msg):
        msg.send()
