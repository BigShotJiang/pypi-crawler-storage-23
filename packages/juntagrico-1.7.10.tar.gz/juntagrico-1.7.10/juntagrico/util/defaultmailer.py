from .mailer.default import Mailer  # noqa: F401

print("DEPRECATED: use DEFAULT_MAILER = 'juntagrico.util.mailer.default.Mailer' instead")
