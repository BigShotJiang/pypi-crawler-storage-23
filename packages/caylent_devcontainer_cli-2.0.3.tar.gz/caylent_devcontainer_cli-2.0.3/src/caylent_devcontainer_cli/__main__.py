"""Allow caylent_devcontainer_cli to be executed as a module with python -m."""

from caylent_devcontainer_cli.cli import main

if __name__ == "__main__":
    main()
