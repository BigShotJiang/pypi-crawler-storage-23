"""Caylent Devcontainer CLI package."""

__version__ = "2.0.3"
