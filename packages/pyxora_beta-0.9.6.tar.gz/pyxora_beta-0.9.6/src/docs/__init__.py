import warnings

warnings.filterwarnings("ignore")

from .local import local_docs
from .build import build_docs
from .online import online_docs
