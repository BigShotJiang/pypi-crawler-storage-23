# System
TIME = "/time"

# API Keys
CREATE_API_KEY = "/auth/api-key"
GET_API_KEYS = "/auth/api-keys"
DELETE_API_KEY = "/auth/api-key"
DERIVE_API_KEY = "/auth/derive-api-key"

CREATE_READONLY_API_KEY = "/auth/readonly-api-key"
GET_READONLY_API_KEYS = "/auth/readonly-api-keys"
DELETE_READONLY_API_KEY = "/auth/readonly-api-key"

# Orders
POST_ORDER = "/order"
POST_ORDERS = "/orders"
CANCEL = "/order"
CANCEL_ORDERS = "/orders"
CANCEL_ALL = "/cancel-all"
CANCEL_MARKET_ORDERS = "/cancel-market-orders"
ORDERS = "/data/orders"

# Order Books
GET_ORDER_BOOK = "/book"
GET_ORDER_BOOKS = "/books"

# Pricing
MID_POINT = "/midpoint"
MID_POINTS = "/midpoints"
PRICE = "/price"
GET_PRICES = "/prices"
GET_SPREAD = "/spread"
GET_SPREADS = "/spreads"
GET_LAST_TRADE_PRICE = "/last-trade-price"
GET_LAST_TRADES_PRICES = "/last-trades-prices"

# Trades
TRADES = "/data/trades"

# Markets
GET_SAMPLING_SIMPLIFIED_MARKETS = "/sampling-simplified-markets"
GET_SAMPLING_MARKETS = "/sampling-markets"
GET_SIMPLIFIED_MARKETS = "/simplified-markets"
GET_MARKETS = "/markets"
GET_MARKET = "/markets/"
GET_MARKET_TRADES_EVENTS = "/live-activity/events/"

# Market Data
GET_TICK_SIZE = "/tick-size"
GET_NEG_RISK = "/neg-risk"
GET_FEE_RATE = "/fee-rate"

# Rewards
IS_ORDER_SCORING = "/order-scoring"
ARE_ORDERS_SCORING = "/orders-scoring"

# Balance
GET_BALANCE_ALLOWANCE = "/balance-allowance"
UPDATE_BALANCE_ALLOWANCE = "/balance-allowance/update"

# Notifications
GET_NOTIFICATIONS = "/notifications"
DROP_NOTIFICATIONS = "/notifications"
