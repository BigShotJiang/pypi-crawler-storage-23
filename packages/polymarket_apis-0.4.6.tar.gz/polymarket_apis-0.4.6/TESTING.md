# Testing Lanes

The suite is split into local-first lanes:

1. `contract`: deterministic, mocked request/response and parser tests.
2. `prod_read`: live, read-only checks against production endpoints.
3. `auth_clob`: authenticated CLOB read checks (non-destructive).
4. `amoy_web3`: tiny state-changing checks on Amoy.
5. `amoy_gasless`: optional gasless Amoy checks.
6. `websocket_live`: explicit opt-in websocket lane.

## Setup

```bash
uv sync --dev
```

Populate `.env.test.local` with required values.

## Run Commands

Contract only:

```bash
uv run pytest -m "contract" -q
```

Production read-only:

```bash
uv run pytest -m "prod_read" -q
```

Authenticated CLOB:

```bash
uv run pytest -m "auth_clob" -q
```

Amoy Web3:

```bash
uv run pytest -m "amoy_web3" -q
```

Optional gasless:

```bash
uv run pytest -m "amoy_gasless" -q
```

Full local suite:

```bash
uv run pytest -q
```

## Notes

- No snapshot baseline is used. Test failures are drift signals.
- Live tests retry only transient transport errors.
- `amoy_web3` and `amoy_gasless` are intentionally isolated from mainnet.
