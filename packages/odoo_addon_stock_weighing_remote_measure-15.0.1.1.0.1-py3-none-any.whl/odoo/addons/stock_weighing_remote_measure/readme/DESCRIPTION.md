Meausure the weight remotely from the weighing assistant.
