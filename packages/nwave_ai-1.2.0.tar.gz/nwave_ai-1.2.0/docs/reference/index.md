# nWave Reference

Auto-generated documentation for 23 agents, 22 commands, 98 skills, and 9 templates.

## Contents

- [Agents](agents/index.md) (23)
- [Commands](commands/index.md) (22)
- [Skills](skills/index.md) (98)
- [Templates](templates/index.md) (9)
