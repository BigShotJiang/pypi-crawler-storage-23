# hausdorff-stats

Multi-stat bidirectional Hausdorff distance for 3D mesh surfaces.

Returns min, max, mean, and 95th-percentile distances in both directions —
not just the single worst-case number.

## Installation

```bash
pip install hausdorff-stats
```

For point-to-cell distance (projects onto triangle surfaces via VTK):

```bash
pip install hausdorff-stats[vtk]
```

## Quick start

### Point-to-point (numpy arrays)

```python
import numpy as np
from hausdorff_stats import hausdorff_metrics

# Two point clouds of shape (N, 3)
a = np.random.rand(500, 3)
b = np.random.rand(600, 3) + 0.1

result = hausdorff_metrics(a, b)

result.hausdorff      # bidirectional Hausdorff distance
result.mean_a_to_b    # mean distance from A to B
result.p95_b_to_a     # 95th percentile from B to A
result.summary()      # dict of all stats (handy for pandas / JSON)
```

### Point-to-cell (VTP mesh files)

```python
from hausdorff_stats import hausdorff_metrics

result = hausdorff_metrics(
    "surface_a.vtp",
    "surface_b.vtp",
    method="point_to_cell",
)
```

This projects each point onto the nearest triangle cell on the opposite
surface, giving more accurate distances for tessellated geometry.

## Available statistics

`hausdorff_metrics` returns a `HausdorffResult` with:

| Property | Description |
|---|---|
| `hausdorff` | Bidirectional Hausdorff distance (max of both directed maxima) |
| `min_a_to_b` / `min_b_to_a` | Minimum directed distance |
| `max_a_to_b` / `max_b_to_a` | Maximum directed distance |
| `mean_a_to_b` / `mean_b_to_a` | Mean directed distance |
| `p95_a_to_b` / `p95_b_to_a` | 95th percentile directed distance |
| `percentile(q)` | Arbitrary percentile for both directions |
| `summary()` | Flat dict of all stats |

Raw per-point distance arrays are also accessible as `distances_a_to_b` and
`distances_b_to_a`.

## License

MIT
