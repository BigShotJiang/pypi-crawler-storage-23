"""Shared fixtures for hausdorff-stats tests."""

from pathlib import Path

import numpy as np
import pytest

DATA_DIR = Path(__file__).parent / "data"


@pytest.fixture
def cube_points() -> np.ndarray:
    """8 vertices of a unit cube centered at origin."""
    return np.array(
        [
            [-1, -1, -1],
            [-1, -1, 1],
            [-1, 1, -1],
            [-1, 1, 1],
            [1, -1, -1],
            [1, -1, 1],
            [1, 1, -1],
            [1, 1, 1],
        ],
        dtype=np.float64,
    )


@pytest.fixture
def shifted_cube_points(cube_points: np.ndarray) -> np.ndarray:
    """Unit cube shifted by (2, 0, 0)."""
    return cube_points + np.array([2.0, 0.0, 0.0])


@pytest.fixture
def phantom0_path() -> Path:
    return DATA_DIR / "phantom0.vtp"


@pytest.fixture
def phantom1_path() -> Path:
    return DATA_DIR / "phantom1.vtp"


@pytest.fixture
def phantom2_path() -> Path:
    return DATA_DIR / "phantom2.vtp"


@pytest.fixture
def phantom3_path() -> Path:
    return DATA_DIR / "phantom3.vtp"
