"""Tests for the point-to-point distance engine (no VTK required)."""

import numpy as np
import pytest

from hausdorff_stats._core import point_to_point_distances


class TestPointToPointDistances:
    def test_identical_points_gives_zeros(self, cube_points: np.ndarray) -> None:
        d = point_to_point_distances(cube_points, cube_points)
        np.testing.assert_allclose(d, 0.0)

    def test_known_shift(self) -> None:
        source = np.array([[0.0, 0.0, 0.0]])
        target = np.array([[3.0, 4.0, 0.0]])
        d = point_to_point_distances(source, target)
        np.testing.assert_allclose(d, [5.0])

    def test_symmetry(self, cube_points: np.ndarray, shifted_cube_points: np.ndarray) -> None:
        d_ab = point_to_point_distances(cube_points, shifted_cube_points)
        d_ba = point_to_point_distances(shifted_cube_points, cube_points)
        # For symmetric shifted cubes, the distance distributions should be identical
        np.testing.assert_allclose(sorted(d_ab), sorted(d_ba))

    def test_cube_shift_distances(
        self, cube_points: np.ndarray, shifted_cube_points: np.ndarray
    ) -> None:
        d = point_to_point_distances(cube_points, shifted_cube_points)
        # Closest point for each vertex is the corresponding face vertex shifted by 2
        # min distance = 2-2=0? No, shift is +2 so min dist among nearest neighbors
        # Each source point (-1,-1,-1) has nearest target at (1,-1,-1) -> dist=2
        # and (1,-1,-1) has nearest target at (1,-1,-1) -> dist=0
        # So distances should be either 0 (for points at x=1) or 2 (for points at x=-1)
        assert np.min(d) == pytest.approx(0.0)
        assert np.max(d) == pytest.approx(2.0)

    def test_output_shape(self, cube_points: np.ndarray) -> None:
        d = point_to_point_distances(cube_points, cube_points)
        assert d.shape == (8,)
        assert d.dtype == np.float64
