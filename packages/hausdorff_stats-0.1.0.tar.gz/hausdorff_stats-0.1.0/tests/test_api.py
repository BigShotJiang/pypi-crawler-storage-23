"""Integration tests for the public API (no VTK required)."""

import numpy as np
import pytest

from hausdorff_stats import HausdorffResult, hausdorff_metrics


class TestHausdorffMetricsPointToPoint:
    def test_identical_arrays(self, cube_points: np.ndarray) -> None:
        result = hausdorff_metrics(cube_points, cube_points)
        assert result.hausdorff == pytest.approx(0.0)
        assert result.min_a_to_b == pytest.approx(0.0)
        assert result.max_a_to_b == pytest.approx(0.0)
        assert result.mean_a_to_b == pytest.approx(0.0)

    def test_shifted_cubes(
        self, cube_points: np.ndarray, shifted_cube_points: np.ndarray
    ) -> None:
        result = hausdorff_metrics(cube_points, shifted_cube_points)
        assert result.hausdorff == pytest.approx(2.0)
        assert result.min_a_to_b == pytest.approx(0.0)
        assert result.max_a_to_b == pytest.approx(2.0)

    def test_summary_keys(self, cube_points: np.ndarray) -> None:
        result = hausdorff_metrics(cube_points, cube_points)
        s = result.summary()
        expected_keys = {
            "hausdorff",
            "min_a_to_b", "max_a_to_b", "mean_a_to_b", "p95_a_to_b",
            "min_b_to_a", "max_b_to_a", "mean_b_to_a", "p95_b_to_a",
        }
        assert set(s.keys()) == expected_keys

    def test_percentile_method(
        self, cube_points: np.ndarray, shifted_cube_points: np.ndarray
    ) -> None:
        result = hausdorff_metrics(cube_points, shifted_cube_points)
        p50_a2b, p50_b2a = result.percentile(50)
        assert isinstance(p50_a2b, float)
        assert isinstance(p50_b2a, float)

    def test_raw_distances_accessible(self, cube_points: np.ndarray) -> None:
        result = hausdorff_metrics(cube_points, cube_points)
        assert isinstance(result.distances_a_to_b, np.ndarray)
        assert result.distances_a_to_b.shape == (8,)

    def test_invalid_method_raises(self, cube_points: np.ndarray) -> None:
        with pytest.raises(ValueError, match="Unknown method"):
            hausdorff_metrics(cube_points, cube_points, method="invalid")

    def test_bad_array_shape_raises(self) -> None:
        bad = np.array([[1.0, 2.0]])  # (1, 2) not (N, 3)
        good = np.array([[0.0, 0.0, 0.0]])
        with pytest.raises(ValueError, match="\\(N, 3\\)"):
            hausdorff_metrics(bad, good)

    def test_unsupported_file_format_raises(self, tmp_path: object) -> None:
        with pytest.raises(ValueError, match="Unsupported file format"):
            hausdorff_metrics("mesh.stl", "mesh.stl")


class TestHausdorffResult:
    def test_frozen(self) -> None:
        r = HausdorffResult(
            distances_a_to_b=np.array([1.0]),
            distances_b_to_a=np.array([2.0]),
        )
        with pytest.raises(AttributeError):
            r.distances_a_to_b = np.array([99.0])  # type: ignore[misc]
