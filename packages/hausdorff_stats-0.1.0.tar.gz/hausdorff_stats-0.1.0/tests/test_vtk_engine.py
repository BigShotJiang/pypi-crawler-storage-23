"""Tests for VTK engine (require vtk to be installed)."""

import tempfile
from pathlib import Path

import numpy as np
import pytest

vtk = pytest.importorskip("vtk", reason="VTK not installed")

from hausdorff_stats import hausdorff_metrics
from hausdorff_stats._vtk_engine import (
    point_to_cell_distances,
    read_vtp,
    write_vtp_with_scalars,
)

from hausdorff_stats._vtk_engine import _require_vtk

DATA_DIR = Path(__file__).parent / "data"


class TestRequireVtk:
    def test_missing_vtk_raises_helpful_error(self, monkeypatch: pytest.MonkeyPatch) -> None:
        import builtins
        real_import = builtins.__import__

        def mock_import(name: str, *args: object, **kwargs: object) -> object:
            if name == "vtk":
                raise ImportError("No module named 'vtk'")
            return real_import(name, *args, **kwargs)

        monkeypatch.setattr(builtins, "__import__", mock_import)
        with pytest.raises(ImportError, match="pip install hausdorff-stats\\[vtk\\]"):
            _require_vtk()


class TestReadVtp:
    def test_reads_phantom0(self, phantom0_path: Path) -> None:
        points, polydata = read_vtp(phantom0_path)
        assert points.ndim == 2
        assert points.shape[1] == 3
        assert polydata.GetNumberOfPoints() > 0

    def test_bad_path_raises(self, tmp_path: Path) -> None:
        with pytest.raises(ValueError, match="Failed to read"):
            read_vtp(tmp_path / "nonexistent.vtp")


class TestWriteVtpWithScalars:
    def test_round_trip(self, phantom0_path: Path) -> None:
        points, polydata = read_vtp(phantom0_path)
        dists = np.ones(len(points), dtype=np.float32)
        with tempfile.TemporaryDirectory() as tmpdir:
            out = Path(tmpdir) / "out.vtp"
            write_vtp_with_scalars(polydata, dists, out)
            assert out.exists()
            pts2, pd2 = read_vtp(out)
            assert pts2.shape == points.shape


class TestPointToCellDistances:
    def test_phantom0_self(self, phantom0_path: Path) -> None:
        points, polydata = read_vtp(phantom0_path)
        d = point_to_cell_distances(points, polydata)
        np.testing.assert_allclose(d, 0.0, atol=1e-10)

    def test_phantom0_vs_phantom1(
        self, phantom0_path: Path, phantom1_path: Path
    ) -> None:
        pts0, pd0 = read_vtp(phantom0_path)
        pts1, pd1 = read_vtp(phantom1_path)
        d_0to1 = point_to_cell_distances(pts0, pd1)
        d_1to0 = point_to_cell_distances(pts1, pd0)
        # Reference values from notebook (point to cell mode)
        assert np.min(d_0to1) == pytest.approx(2.0, abs=1e-4)
        assert np.max(d_0to1) == pytest.approx(2.0, abs=1e-4)
        assert np.min(d_1to0) == pytest.approx(3.464102, abs=1e-3)
        assert np.max(d_1to0) == pytest.approx(3.464102, abs=1e-3)


class TestHausdorffMetricsPointToCell:
    def test_phantom0_vs_phantom1(
        self, phantom0_path: Path, phantom1_path: Path
    ) -> None:
        result = hausdorff_metrics(
            str(phantom0_path), str(phantom1_path), method="point_to_cell"
        )
        assert result.hausdorff == pytest.approx(3.464102, abs=1e-3)
        assert result.mean_a_to_b == pytest.approx(2.0, abs=1e-4)
        assert result.mean_b_to_a == pytest.approx(3.464102, abs=1e-3)

    def test_phantom0_vs_phantom3(
        self, phantom0_path: Path, phantom3_path: Path
    ) -> None:
        result = hausdorff_metrics(
            str(phantom0_path), str(phantom3_path), method="point_to_cell"
        )
        assert result.hausdorff == pytest.approx(6.557439, abs=1e-3)

    def test_numpy_arrays_raise_for_point_to_cell(self) -> None:
        pts = np.array([[0.0, 0.0, 0.0], [1.0, 1.0, 1.0]])
        with pytest.raises(ValueError, match="point_to_cell"):
            hausdorff_metrics(pts, pts, method="point_to_cell")
