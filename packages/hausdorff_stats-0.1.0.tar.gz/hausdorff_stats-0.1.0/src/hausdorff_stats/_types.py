"""HausdorffResult dataclass — stores per-point distances and computed stats."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
from numpy.typing import NDArray


@dataclass(frozen=True)
class HausdorffResult:
    """Bidirectional Hausdorff distance result with summary statistics.

    Parameters
    ----------
    distances_a_to_b : ndarray of shape (N,)
        Per-point distances from surface A to surface B.
    distances_b_to_a : ndarray of shape (M,)
        Per-point distances from surface B to surface A.
    """

    distances_a_to_b: NDArray[np.floating[Any]]
    distances_b_to_a: NDArray[np.floating[Any]]

    # --- A → B statistics ---------------------------------------------------

    @property
    def min_a_to_b(self) -> float:
        return float(np.min(self.distances_a_to_b))

    @property
    def max_a_to_b(self) -> float:
        return float(np.max(self.distances_a_to_b))

    @property
    def mean_a_to_b(self) -> float:
        return float(np.mean(self.distances_a_to_b))

    @property
    def p95_a_to_b(self) -> float:
        return float(np.percentile(self.distances_a_to_b, 95))

    # --- B → A statistics ---------------------------------------------------

    @property
    def min_b_to_a(self) -> float:
        return float(np.min(self.distances_b_to_a))

    @property
    def max_b_to_a(self) -> float:
        return float(np.max(self.distances_b_to_a))

    @property
    def mean_b_to_a(self) -> float:
        return float(np.mean(self.distances_b_to_a))

    @property
    def p95_b_to_a(self) -> float:
        return float(np.percentile(self.distances_b_to_a, 95))

    # --- Bidirectional ------------------------------------------------------

    @property
    def hausdorff(self) -> float:
        """Bidirectional Hausdorff distance (max of both directed maxima)."""
        return max(self.max_a_to_b, self.max_b_to_a)

    # --- Helpers ------------------------------------------------------------

    def percentile(self, q: float) -> tuple[float, float]:
        """Return the *q*-th percentile for both directions.

        Parameters
        ----------
        q : float
            Percentile in [0, 100].

        Returns
        -------
        (a_to_b, b_to_a) : tuple[float, float]
        """
        return (
            float(np.percentile(self.distances_a_to_b, q)),
            float(np.percentile(self.distances_b_to_a, q)),
        )

    def summary(self) -> dict[str, float]:
        """Return a flat dict suitable for ``pandas.DataFrame`` or JSON."""
        return {
            "hausdorff": self.hausdorff,
            "min_a_to_b": self.min_a_to_b,
            "max_a_to_b": self.max_a_to_b,
            "mean_a_to_b": self.mean_a_to_b,
            "p95_a_to_b": self.p95_a_to_b,
            "min_b_to_a": self.min_b_to_a,
            "max_b_to_a": self.max_b_to_a,
            "mean_b_to_a": self.mean_b_to_a,
            "p95_b_to_a": self.p95_b_to_a,
        }
