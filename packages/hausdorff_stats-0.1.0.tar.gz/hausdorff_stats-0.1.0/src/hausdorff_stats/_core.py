"""Point-to-point distance engine using scipy KDTree."""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray
from scipy.spatial import KDTree


def point_to_point_distances(
    source: NDArray[np.floating], target: NDArray[np.floating]
) -> NDArray[np.float64]:
    """Compute the nearest-neighbour distance from each *source* point to *target*.

    Parameters
    ----------
    source : ndarray of shape (N, 3)
    target : ndarray of shape (M, 3)

    Returns
    -------
    distances : ndarray of shape (N,)
        Euclidean distance from each source point to the closest target point.
    """
    tree = KDTree(target)
    distances, _ = tree.query(source)
    return np.asarray(distances, dtype=np.float64)
