"""Input coercion and validation helpers."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
from numpy.typing import NDArray


def coerce_points(inp: Any) -> tuple[NDArray[np.float64], Any]:
    """Accept an (N, 3) ndarray **or** a path to a ``.vtp`` file.

    Parameters
    ----------
    inp : ndarray or str or Path
        Either an (N, 3) array of point coordinates or a filesystem path to a
        VTP file (requires the ``vtk`` extra).

    Returns
    -------
    points : ndarray of shape (N, 3)
    polydata : vtkPolyData or None
        Non-``None`` only when a VTP file was loaded.
    """
    if isinstance(inp, (str, Path)):
        path = Path(inp)
        if path.suffix.lower() != ".vtp":
            raise ValueError(f"Unsupported file format: {path.suffix!r} (expected .vtp)")
        from hausdorff_stats._vtk_engine import read_vtp

        return read_vtp(path)

    arr = np.asarray(inp, dtype=np.float64)
    if arr.ndim != 2 or arr.shape[1] != 3:
        raise ValueError(
            f"Expected an (N, 3) array of 3-D points, got shape {arr.shape}"
        )
    return arr, None
