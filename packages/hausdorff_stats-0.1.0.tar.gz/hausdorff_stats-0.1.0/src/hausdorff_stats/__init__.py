"""hausdorff-stats — Multi-stat Hausdorff distance for 3D mesh surfaces."""

from __future__ import annotations

from typing import Any

import numpy as np
from numpy.typing import NDArray

from hausdorff_stats._types import HausdorffResult

__all__ = ["hausdorff_metrics", "HausdorffResult"]


def hausdorff_metrics(
    a: NDArray[np.floating] | str,
    b: NDArray[np.floating] | str,
    *,
    method: str = "point_to_point",
) -> HausdorffResult:
    """Compute bidirectional Hausdorff distance statistics between two surfaces.

    Parameters
    ----------
    a, b : ndarray of shape (N, 3) **or** str/Path to a ``.vtp`` file
        The two surfaces to compare. VTP paths require ``pip install
        hausdorff-stats[vtk]``.
    method : ``"point_to_point"`` or ``"point_to_cell"``
        ``"point_to_point"`` uses scipy KDTree (works with numpy arrays).
        ``"point_to_cell"`` projects onto the closest cell surface and
        requires VTK polydata (pass VTP paths, not raw arrays).

    Returns
    -------
    HausdorffResult
    """
    from hausdorff_stats._utils import coerce_points

    points_a, polydata_a = coerce_points(a)
    points_b, polydata_b = coerce_points(b)

    if method == "point_to_point":
        from hausdorff_stats._core import point_to_point_distances

        d_a2b = point_to_point_distances(points_a, points_b)
        d_b2a = point_to_point_distances(points_b, points_a)

    elif method == "point_to_cell":
        if polydata_a is None or polydata_b is None:
            raise ValueError(
                "method='point_to_cell' requires VTP file paths (not numpy arrays) "
                "because cell topology is needed. Pass file paths or use "
                "method='point_to_point'."
            )
        from hausdorff_stats._vtk_engine import point_to_cell_distances

        d_a2b = point_to_cell_distances(points_a, polydata_b)
        d_b2a = point_to_cell_distances(points_b, polydata_a)

    else:
        raise ValueError(
            f"Unknown method {method!r}. Use 'point_to_point' or 'point_to_cell'."
        )

    return HausdorffResult(distances_a_to_b=d_a2b, distances_b_to_a=d_b2a)
