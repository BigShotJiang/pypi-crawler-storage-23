"""VTK-based engine: point-to-cell distances and VTP I/O."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
from numpy.typing import NDArray


def _require_vtk() -> Any:
    """Import and return the ``vtk`` package, raising a helpful error if missing."""
    try:
        import vtk  # type: ignore[import-untyped]
    except ImportError as exc:
        raise ImportError(
            "VTK is required for this operation. "
            "Install it with:  pip install hausdorff-stats[vtk]"
        ) from exc
    return vtk


# ---------------------------------------------------------------------------
# VTP I/O
# ---------------------------------------------------------------------------


def read_vtp(path: str | Path) -> tuple[NDArray[np.float64], Any]:
    """Read a VTP file and return ``(points, polydata)``.

    Parameters
    ----------
    path : str or Path
        Filesystem path to a ``.vtp`` file.

    Returns
    -------
    points : ndarray of shape (N, 3)
    polydata : vtkPolyData
    """
    vtk = _require_vtk()
    from vtk.util.numpy_support import vtk_to_numpy  # type: ignore[import-untyped]

    reader = vtk.vtkXMLPolyDataReader()
    reader.SetFileName(str(path))
    reader.Update()

    polydata = reader.GetOutput()
    if polydata is None or polydata.GetNumberOfPoints() == 0:
        raise ValueError(f"Failed to read VTP file or file is empty: {path}")

    vtk_points = polydata.GetPoints().GetData()
    points = vtk_to_numpy(vtk_points).astype(np.float64)
    return points, polydata


def write_vtp_with_scalars(
    polydata: Any,
    distances: NDArray[np.floating],
    path: str | Path,
    *,
    scalar_name: str = "Distance",
) -> None:
    """Write a VTP file with per-point distance scalars attached.

    Parameters
    ----------
    polydata : vtkPolyData
        The surface mesh.
    distances : ndarray of shape (N,)
        Per-point distance values.
    path : str or Path
        Output ``.vtp`` file path.
    scalar_name : str
        Name of the scalar array in the output file.
    """
    vtk = _require_vtk()
    from vtk.util.numpy_support import numpy_to_vtk  # type: ignore[import-untyped]

    vtk_arr = numpy_to_vtk(np.asarray(distances, dtype=np.float32), deep=True)
    vtk_arr.SetName(scalar_name)
    polydata.GetPointData().SetScalars(vtk_arr)

    writer = vtk.vtkXMLPolyDataWriter()
    writer.SetInputData(polydata)
    writer.SetFileName(str(path))
    writer.Update()


# ---------------------------------------------------------------------------
# Point-to-cell distance
# ---------------------------------------------------------------------------


def point_to_cell_distances(
    source: NDArray[np.floating], target_polydata: Any
) -> NDArray[np.float64]:
    """Compute the distance from each *source* point to the nearest cell on *target_polydata*.

    Parameters
    ----------
    source : ndarray of shape (N, 3)
    target_polydata : vtkPolyData

    Returns
    -------
    distances : ndarray of shape (N,)
    """
    vtk = _require_vtk()

    cell_locator = vtk.vtkCellLocator()
    cell_locator.SetDataSet(target_polydata)
    cell_locator.BuildLocator()

    cell_id = vtk.mutable(0)
    sub_id = vtk.mutable(0)
    dist2 = vtk.mutable(0.0)
    closest_point = np.zeros(3)

    n = source.shape[0]
    distances = np.empty(n, dtype=np.float64)

    for i in range(n):
        pt = source[i]
        cell_locator.FindClosestPoint(pt, closest_point, cell_id, sub_id, dist2)
        distances[i] = np.sqrt(
            (pt[0] - closest_point[0]) ** 2
            + (pt[1] - closest_point[1]) ** 2
            + (pt[2] - closest_point[2]) ** 2
        )

    return distances
