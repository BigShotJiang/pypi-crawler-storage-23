# Changelog

## 0.1.0 — 2026-02-24

Initial release.

- Bidirectional Hausdorff distance with min, max, mean, and 95th percentile stats
- `point_to_point` method using scipy KDTree (numpy arrays)
- `point_to_cell` method using VTK (`.vtp` mesh files)
- `HausdorffResult` dataclass with `summary()` dict export
