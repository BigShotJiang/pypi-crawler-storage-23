"""Tests for semantic-cache-mcp."""
