"""AI-CLI - Cross-platform AI CLI launcher."""

__version__ = "3.0.3"
__author__ = "AI-CLI Team"
