from __future__ import annotations

import asyncio
from asyncio import IncompleteReadError, Queue, Task, create_task, open_connection
from dataclasses import dataclass
from uuid import uuid4

from .abc import PbxClient
from .asyncutils import run_task, socket_operation
from .exceptions import InternalError
from .types import JsonDict, JsonValue

_RESPONSE_SUCCESS: str = 'Success'
_UNKNOWN_ERROR: str = 'Unknown error'


@dataclass
class AmiClient(PbxClient[JsonDict]):
    def __post_init__(self) -> None:
        super().__post_init__()
        self._action_queues: dict[str, Queue[dict[str, str]]] = {}
        self._max_connect_tries = 3

    async def _prepare_ami_action(self, ami_action: JsonDict) -> tuple[str, Queue[dict[str, str]]]:
        action_id: str = str(uuid4())
        action_q: Queue[dict[str, str]] = Queue()
        self._action_queues[action_id] = action_q
        ami_action['ActionID'] = action_id
        create_task(self.queue.put(ami_action))
        return action_id, action_q

    async def _send_ami_action(self, ami_action: JsonDict) -> None:
        command: str = ''
        for name, value in ami_action.items():
            if isinstance(value, (list, tuple, set)):
                subvalue: str | int | float
                for subvalue in value:
                    command += f'{name}: {subvalue}\r\n'
            else:
                command += f'{name}: {value}\r\n'
        command += '\r\n'
        assert self._writer is not None  # For type checkers
        self._writer.write(command.encode(self.config.encoding))
        if self._logger_trace:
            self._logger_trace.trace(command)
        await socket_operation(self._writer.drain())

    async def _read_ami_message(self) -> dict[str, str]:
        assert self._reader is not None  # For type checkers
        octets: bytes = await self._reader.readuntil(b'\r\n\r\n')
        message = octets.decode(self.config.encoding)
        if self._logger_trace:
            self._logger_trace.trace(message)
        lines: list[str] = message.splitlines()
        result: dict[str, str] = {}
        for line in lines:
            if ': ' not in line:
                break
            key, value = line.rstrip('\r\n').split(': ', maxsplit=1)
            if key == 'Variable' and '=' in value:
                # There could be multiple variables, so we use variable name as key
                key, value = value.split('=', maxsplit=1)
            result[key] = value
        return result

    async def _connect(self) -> set[Task[None]]:
        pbx_host: str = self.config.host
        pbx_port: int = self.config.port
        user: str = self.config.user
        pswd: str = self.config.pswd
        login: str = f'Action: Login\r\nUsername: {user}\r\nSecret: {pswd}\r\n\r\n'
        # Some older versions of Asterisk may reject a valid login in some circumstances,
        # (in embedded devices, for example) so we try several times
        for attempt in range(self._max_connect_tries):
            self.logger.debug(
                'Opening TCP connection',
                server=self.name,
                host=pbx_host,
                port=pbx_port,
                attempt=attempt + 1,
            )
            self._reader, self._writer = await socket_operation(open_connection(pbx_host, pbx_port))
            prompt: bytes = await socket_operation(self._reader.readuntil(b'\r\n'))
            if self._logger_trace:
                self._logger_trace.trace(prompt.decode(self.config.encoding))
            if self._logger_trace:
                self._logger_trace.trace(login)
            self._writer.write(login.encode(self.config.encoding))
            await socket_operation(self._writer.drain())
            pbx_message: dict[str, str] = await socket_operation(self._read_ami_message())
            response: str = pbx_message.get('Response', '')
            if response == _RESPONSE_SUCCESS:
                self.logger.info(
                    'Connected to TCP server', server=self.name, host=pbx_host, port=pbx_port
                )
                self.logger.debug('Waiting for FullyBooted event.', server=self.name)
                return set()
            self.logger.error(
                'TCP server authentication failed', server=self.name, response=response
            )
            await self._disconnect()
            if attempt < self._max_connect_tries - 1:
                await asyncio.sleep(1)
        self.logger.critical('Permanently aborting communication with TCP server', server=self.name)
        raise RuntimeError('Authentication failed')

    async def _ping(self) -> None:
        ami_action: JsonDict = {'Action': 'Ping'}
        try:
            await self.execute(ami_action)
        except InternalError:
            return  # We consume the error so it does not trigger service shutdown

    async def _receiver(self) -> None:
        try:
            while True:
                message: dict[str, str] = await self._read_ami_message()
                self._data_received_event.set()  # Indicate to keeper that data was received
                action_id: str = message.get('ActionID', '')
                if action_id:
                    # If action ID is present, check if this is a response to one of our commands,
                    # and if so, put a message to corresponding queue
                    # so calling function can process it
                    action_q: Queue[dict[str, str]] | None = self._action_queues.get(action_id)
                    if action_q:
                        create_task(action_q.put(message))
                        continue
                event_type: str = message.get('Event', '')
                if not event_type:
                    # Unknown, possibly a response which does not contain ActionID
                    # Send it to event hook if present, otherwise log a warning
                    if self.event_hook:
                        run_task(self.event_hook(message))
                    else:
                        self.logger.warning(
                            'Received unknown message from server (neither an '
                            'event nor a response).',
                            server=self.name,
                            **message,
                        )
                    continue
                if event_type == 'FullyBooted':
                    self.logger.info('Server ready.', server=self.name)
                    if self.start_hook:
                        run_task(self.start_hook(message))
                    elif self.event_hook:
                        run_task(self.event_hook(message))
                elif event_type == 'Reload':
                    if message['Status'] == '0' and message['Module'] in ('All', 'res_pjsip.so'):
                        self.logger.info('Server data reloaded.', server=self.name)
                    if self.reload_hook:
                        run_task(self.reload_hook(message))
                    elif self.event_hook:
                        run_task(self.event_hook(message))
                elif event_type == 'Shutdown':
                    self.logger.info('Server is shutting down.', server=self.name)
                    if self.stop_hook:
                        run_task(self.stop_hook(message))
                    elif self.event_hook:
                        run_task(self.event_hook(message))
                    # Receiver will fail and connection will be attempted again
                elif self.event_hook:
                    run_task(self.event_hook(message))
        except (OSError, TimeoutError, IncompleteReadError):
            if not self._is_shutting_down:  # If we are shutting down, we don't care about errors
                raise

    async def _sender(self) -> None:
        while True:
            ami_action: JsonDict = await self.queue.get()
            run_task(self._send_ami_action(ami_action))
            self.queue.task_done()

    async def read_list(
        self,
        ami_action: JsonDict,
        list_events: str | tuple[str, ...],
        list_end_event: str,
    ) -> list[dict[str, str]]:
        if isinstance(list_events, str):
            list_events = (list_events,)
        action_name: JsonValue = ami_action['Action']
        action_id, action_q = await self._prepare_ami_action(ami_action)
        items: list[dict[str, str]] = []
        try:
            while True:
                message: dict[str, str] = await socket_operation(action_q.get())
                action_q.task_done()
                response: str | None = message.get('Response')
                if response and response != _RESPONSE_SUCCESS:
                    if message.get('Message', '').endswith('found'):
                        # For some reason, Asterisk returns error if there are no items found
                        break
                    self.logger.error(
                        'Server rejected action',
                        server=self.name,
                        action=action_name,
                        action_id=action_id,
                        response=message,
                    )
                    raise InternalError(message.get('Message', _UNKNOWN_ERROR))
                event: str = message.get('Event', '')
                if event == list_end_event:
                    break
                if event in list_events:
                    items.append(message)
        except TimeoutError:
            self.logger.error(
                'Timed out while waiting for Asterisk response',
                action=action_name,
                action_id=action_id,
            )
        finally:
            del self._action_queues[action_id]

        return items

    async def read_scalar(self, ami_action: JsonDict, value_name: str) -> str:
        action_name: JsonValue = ami_action['Action']
        action_id, action_q = await self._prepare_ami_action(ami_action)
        try:
            message: dict[str, str] = await socket_operation(action_q.get())
            action_q.task_done()
            success: bool = message.get('Response') == _RESPONSE_SUCCESS
            if not success:
                self.logger.error(
                    'Server rejected action',
                    server=self.name,
                    action=action_name,
                    action_id=action_id,
                    response=message,
                )
                raise InternalError(message.get('Message', _UNKNOWN_ERROR))
            result: str | None = message.get(value_name)
            if result is None:
                action_name = ami_action['Action']
                self.logger.error(
                    'Non-existing scalar value requested',
                    server=self.name,
                    action=action_name,
                    parameter=value_name,
                )
                raise InternalError(f'Internal error: value {value_name} does not exist')
            return result
        except TimeoutError:
            self.logger.error(
                'Timed out while waiting for Asterisk response',
                server=self.name,
                action=action_name,
                action_id=action_id,
            )
        finally:
            del self._action_queues[action_id]
        return ''

    async def read_scalars(self, ami_action: JsonDict, value_names: tuple[str, ...]) -> list[str]:
        action_name: JsonValue = ami_action['Action']
        result: list[str] = []
        action_id, action_q = await self._prepare_ami_action(ami_action)
        try:
            message: dict[str, str] = await socket_operation(action_q.get())
            action_q.task_done()
            success: bool = message.get('Response') == _RESPONSE_SUCCESS
            if not success:
                action_name = ami_action['Action']
                self.logger.error(
                    'Server rejected action',
                    server=self.name,
                    action=action_name,
                    action_id=action_id,
                    response=message,
                )
                raise InternalError(message.get('Message', _UNKNOWN_ERROR))
            for index, value_name in enumerate(value_names):
                value: str | None = message.get(value_name)
                if value is None and index == 0:
                    # First value must exist
                    self.logger.error(
                        'Non-existing scalar value requested',
                        server=self.name,
                        action=action_name,
                        parameter=value_name,
                    )
                    raise InternalError(f'Internal error: value {value_name} does not exist')
                result.append(value or '')
        except TimeoutError:
            self.logger.error(
                'Timed out while waiting for Asterisk response',
                server=self.name,
                action=action_name,
                action_id=action_id,
            )
        finally:
            del self._action_queues[action_id]
        return result

    async def execute(self, ami_action: JsonDict) -> dict[str, str]:
        action_name: JsonValue = ami_action['Action']
        action_id, action_q = await self._prepare_ami_action(ami_action)
        try:
            message: dict[str, str] = await socket_operation(action_q.get())
            action_q.task_done()
            success: bool = message.get('Response') == _RESPONSE_SUCCESS
            if not success:
                self.logger.error(
                    'Server rejected action',
                    server=self.name,
                    action=action_name,
                    action_id=action_id,
                    response=message,
                )
                raise InternalError(message.get('Message', _UNKNOWN_ERROR))
            return message
        except TimeoutError:
            self.logger.error(
                'Timed out while waiting for Asterisk response',
                server=self.name,
                action=action_name,
                action_id=action_id,
            )
        finally:
            del self._action_queues[action_id]
        return {}

    async def get_variable(self, variable: str, channel_id: str = '') -> str:
        ami_action: JsonDict = {
            'Action': 'GetVar',
            'Variable': variable,
        }
        if channel_id:
            ami_action['channel'] = channel_id
        return await self.read_scalar(ami_action, 'Value')

    async def set_variable(self, variable: str, value: str, channel_id: str = '') -> dict[str, str]:
        ami_action = {
            'Action': 'SetVar',
            'Variable': variable,
            'Value': value,
        }
        if channel_id:
            ami_action['channel'] = channel_id
        return await self.execute(ami_action)
