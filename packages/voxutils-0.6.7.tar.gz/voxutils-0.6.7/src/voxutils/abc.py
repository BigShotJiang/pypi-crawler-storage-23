import os
from abc import ABC, abstractmethod
from asyncio import (
    FIRST_COMPLETED,
    CancelledError,
    Event,
    IncompleteReadError,
    Queue,
    StreamReader,
    StreamWriter,
    Task,
    create_task,
    sleep,
    wait,
    wait_for,
)
from collections.abc import Callable, Coroutine
from dataclasses import dataclass
from logging.handlers import RotatingFileHandler
from typing import Generic

from .asyncutils import end_task, run_task, socket_operation
from .config import TcpClientConfig
from .log import INFO, TRACE, StructuredLogger
from .types import JsonDict, T


@dataclass
class Communicator(ABC, Generic[T]):
    name: str  # Client name
    queue: Queue[T]  # Outbound message queue

    def __post_init__(self) -> None:
        self.connect_attempted_event: Event = Event()

    @abstractmethod
    async def start(self) -> None:
        raise NotImplementedError()

    @abstractmethod
    async def stop(self) -> None:
        raise NotImplementedError()

    @abstractmethod
    def is_running(self) -> bool:
        raise NotImplementedError()


class AbstractRetryTimer(ABC):
    """
    This class is used for timing consecutive retries in case of failure.
    User implementations should inherit this class and implement the
    :func:`wait <AbstractRetryTimer.wait>`, :func:`reset <AbstractRetryTimer.reset>`
    and :func:`reset <AbstractRetryTimer.next_delay>` methods.
    """

    @abstractmethod
    async def wait(self) -> float:
        """
        Wait for some time, based on timer algorithm.
        Returns number of seconds waited.
        """
        raise NotImplementedError()

    @abstractmethod
    def reset(self) -> None:
        """
        Reset the timer to default.
        """
        raise NotImplementedError()

    @abstractmethod
    def next(self) -> float:
        """
        Advances the timer and returns the time the timer would have waited in seconds.
        """
        raise NotImplementedError()

    @abstractmethod
    def next_delay(self) -> float:
        """
        Returns the next delay time in seconds.
        """
        raise NotImplementedError()



@dataclass
class TcpClient(Generic[T], Communicator[T]):
    config: TcpClientConfig
    logger: StructuredLogger
    retry_timer: AbstractRetryTimer

    def __post_init__(self) -> None:
        super().__post_init__()
        self._logger_trace: StructuredLogger | None = None
        if self.logger.isEnabledFor(TRACE) and self.config.comm_log:
            logger_name: str = self.config.name.lower()
            self._logger_trace = StructuredLogger(
                logger_name=logger_name,
                level=TRACE,
                handler=RotatingFileHandler(
                    filename=os.path.join(self.config.log_dir, logger_name),
                    maxBytes=self.config.log_max_bytes,
                    backupCount=self.config.log_backup_count,
                    encoding='utf-8',
                ),
                include_timestamp=True,
                include_level=False,
            )
        self._ready_event: Event = Event()
        self._data_received_event: Event = Event()
        self._shut_down: Event = Event()
        self._is_shutting_down: bool = False
        self._reader: StreamReader | None = None
        self._writer: StreamWriter | None = None

    @property
    def ready(self) -> Event:
        return self._ready_event

    async def start(self) -> None:
        name: str = self.config.name
        self.logger.info('Starting %s client', name)
        error_message: str = ''
        conn_error: Exception | None
        tasks: set[Task[None]] = set()
        while True:
            try:
                conn_error = None
                tasks = await self._connect()  # Should raise error if not successful
                tasks.update(
                    {
                        create_task(self._connection_keeper(), name=f'[{self.config.name}] Keeper'),
                        create_task(self._sender(), name=f'[{self.config.name}] Sender'),
                        create_task(self._receiver(), name=f'[{self.config.name}] Receiver'),
                    }
                )
                self.retry_timer.reset()
                self.connect_attempted_event.set()
                self._ready_event.set()  # Inform anyone interested that the service is ready
                # Wait until any task fails
                done_tasks: set[Task[None]] = set()
                pending_tasks: set[Task[None]] = set()
                done_tasks, pending_tasks = await wait(tasks, return_when=FIRST_COMPLETED)
                task: Task[None]
                for task in done_tasks:
                    await self._end_task(task)
                for task in pending_tasks:
                    await self._end_task(task)
            except RuntimeError as err:
                self.logger.critical(
                    'Permanently aborting communication with TCP server',
                    server=name,
                    reason=str(err),
                )
                break
            except ConnectionResetError as err:
                error_message = 'Connection lost'
                conn_error = err
            except TimeoutError as err:
                error_message = 'Timed out'
                conn_error = err
            except (IncompleteReadError, OSError, ValueError) as err:
                error_message = 'Error while reading from network'
                conn_error = err
            except CancelledError:
                self.logger.debug('%s client cancelled', name)
                await self._disconnect()
                for task in tasks:
                    await self._end_task(task)
                self._shut_down.set()
                raise
            finally:
                self.connect_attempted_event.set()

            if self._is_shutting_down:
                break
            if conn_error:
                self.logger.error(error_message, exception=repr(conn_error), server=name)
            if conn_error and self.logger.isEnabledFor(INFO):
                delay: float = self.retry_timer.next_delay()
                if delay > 0.0:
                    self.logger.info('Delaying next connect attempt', delay=delay, server=name)
            await self.retry_timer.wait()
        self._shut_down.set()

    async def stop(self) -> None:
        """
        Cleanly shutdown the TCP client.
        """
        name: str = self.config.name
        self.logger.info('Shutting down TCP client', server=name)
        self._is_shutting_down = True
        await self._disconnect()
        await self._shut_down.wait()
        self.connect_attempted_event.clear()
        self.logger.info('TCP client is shut down', server=name)

    def is_running(self) -> bool:
        return self._ready_event.is_set()

    @abstractmethod
    async def _connect(self) -> set[Task[None]]:
        raise NotImplementedError()

    @abstractmethod
    async def _ping(self) -> None:
        raise NotImplementedError()

    @abstractmethod
    async def _receiver(self) -> None:
        raise NotImplementedError()

    @abstractmethod
    async def _sender(self) -> None:
        raise NotImplementedError()

    async def _disconnect(self) -> None:
        if self._writer is None:
            return  # Already disconnected
        name: str = self.config.name
        self.logger.debug('Closing network connection to TCP server', server=name)
        try:
            self._writer.transport.set_write_buffer_limits(0)  # pytype: disable=attribute-error
            await self._writer.drain()
            self._writer.write_eof()
            self._writer = None
        except (OSError, TimeoutError, IncompleteReadError, RuntimeError):
            self.logger.exception('Error while shutting down TCP connection', server=name)
        self.logger.debug('Closed network connection to TCP server', server=name)

    async def _end_task(self, task: Task[T]) -> None:
        """
        Ends a top-level task after error or shutdown.
        """
        task_name: str = task.get_name()
        self.logger.debug('Ending task', task=task_name)
        try:
            await wait_for(task, 0.5)  # Give task a chance to end gracefully
        except TimeoutError:
            await end_task(task)
            return
        except (ConnectionResetError, TimeoutError, IncompleteReadError, OSError, ValueError):
            # We are ending a task so we don't care about errors
            pass
        self.logger.debug('Ended task', task=task_name)

    async def _connection_keeper(self) -> None:
        """
        Keeps TCP connection to server alive, and exits in case of broken connection.
        """
        interval: int = self.config.keepalive_frequency
        sleep_task: Task[None] | None = None
        event_task: Task[bool] | None = None
        try:
            while True:
                # Wait for interval to expire or data event to be triggered, whichever comes first.
                # Receiver function will trigger the event after data is received.
                sleep_task = run_task(sleep(interval))
                event_task = run_task(self._data_received_event.wait())
                done: set[Task[None | bool]]
                done, _pending = await wait({sleep_task, event_task}, return_when=FIRST_COMPLETED)
                await next(iter(done))  # There must be only one element

                if self._is_shutting_down:
                    break

                if sleep_task in done:
                    # Interval expired, send keep-alive message
                    run_task(self._ping())
                    # Wait for data for predefined time, after which TimeoutError will be raised
                    await socket_operation(event_task)
                else:
                    # Data was received, cancel sleep task and start over
                    await end_task(sleep_task)

                if self._is_shutting_down:
                    break

                self._data_received_event.clear()
        except TimeoutError:
            # This error is expected so we don't include it in logging
            self.logger.error('Timed out while waiting for ping response')
        except CancelledError:
            if sleep_task:
                await end_task(sleep_task)
            if event_task:
                await end_task(event_task)
            raise


@dataclass
class PbxClient(TcpClient):
    event_hook: Callable[[dict[str, str]], Coroutine[None, None, None]] | None = None
    start_hook: Callable[[dict[str, str]], Coroutine[None, None, None]] | None = None
    stop_hook: Callable[[dict[str, str]], Coroutine[None, None, None]] | None = None
    reload_hook: Callable[[dict[str, str]], Coroutine[None, None, None]] | None = None

    def __post_init__(self) -> None:
        super().__post_init__()

    @abstractmethod
    async def read_list(
        self,
        ami_action: JsonDict,
        list_events: str | tuple[str, ...],
        list_end_event: str,
    ) -> list[JsonDict]:
        raise NotImplementedError()

    @abstractmethod
    async def read_scalar(self, ami_action: JsonDict, value_name: str) -> str:
        raise NotImplementedError()

    @abstractmethod
    async def read_scalars(self, ami_action: JsonDict, value_names: tuple[str, ...]) -> list[str]:
        raise NotImplementedError()

    @abstractmethod
    async def execute(self, ami_action: JsonDict) -> dict[str, str]:
        raise NotImplementedError()

    @abstractmethod
    async def get_variable(self, variable: str, channel_id: str = '') -> str:
        raise NotImplementedError()

    @abstractmethod
    async def set_variable(self, variable: str, value: str, channel_id: str = '') -> dict[str, str]:
        raise NotImplementedError()
