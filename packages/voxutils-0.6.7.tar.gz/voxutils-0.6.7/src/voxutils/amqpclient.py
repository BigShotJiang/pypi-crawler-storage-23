import os
from asyncio import (
    AbstractEventLoop,
    CancelledError,
    Event,
    Future,
    create_task,
    get_event_loop,
    sleep,
    wait_for,
)
from collections.abc import Awaitable, Callable, Collection
from dataclasses import dataclass
from logging.handlers import RotatingFileHandler
from typing import cast

import aiormq
import orjson
from aiormq.abc import ArgumentsType, DeliveredMessage
from aiormq.channel import Channel
from aiormq.connection import Connection
from pamqp.exceptions import PAMQPException

from .abc import AbstractRetryTimer
from .asyncutils import end_task, run_task
from .config import AmqpClientConfig, AmqpConfig
from .log import INFO, TRACE, StructuredLogger
from .types import ClientStatus, JsonDict, JsonValue, T

_AMQP_CONNECTION_EXCEPTIONS: tuple[type[Exception], ...] = (
    RuntimeError,
    ConnectionError,
    PAMQPException,
    aiormq.exceptions.AMQPError,
)
_SOCKET_TIMEOUT: int = 15  # In seconds


@dataclass
class AmqpClient:
    config: AmqpConfig  # AMQP configuration
    clients: Collection[AmqpClientConfig]  # list of AMQP clients
    logger: StructuredLogger  # Logger instance
    retry_timer: AbstractRetryTimer  # Retry timer for connection attempts
    processor: Callable[[JsonDict], Awaitable[None]]  # AMQP message processor coroutine
    trace_ignore_in: dict[str, list[str]] | None = None  # Don't log messages with these values
    trace_ignore_out: dict[str, list[str]] | None = None  # Don't log messages with these values

    def __post_init__(self) -> None:
        self._status: ClientStatus = ClientStatus.UNINITIALIZED
        self._ready_event: Event = Event()
        self._processing_event: Event = Event()
        self._is_shutting_down: bool = False
        self._connection: Connection | None = None
        self._channel_in: Channel | None = None
        self._channel_out: Channel | None = None
        self._logger_in: StructuredLogger | None = None
        self._loggers_client: dict[str, StructuredLogger] = {}
        if self.logger.isEnabledFor(TRACE):
            if self.config.comm_log:
                logger_name: str = 'amqp_in_' + self.config.queue
                self._logger_in = StructuredLogger(
                    logger_name=logger_name,
                    level=TRACE,
                    handler=RotatingFileHandler(
                        filename=os.path.join(self.config.log_dir, logger_name),
                        maxBytes=self.config.log_max_bytes,
                        backupCount=self.config.log_backup_count,
                        encoding='utf-8',
                    ),
                    include_timestamp=False,
                    include_level=False,
                )
            for client_config in (conf for conf in self.clients if conf.amqp_log):
                logger_name: str = 'amqp_out_' + client_config.amqp_exchange
                self._loggers_client[client_config.amqp_exchange] = StructuredLogger(
                    logger_name=logger_name,
                    level=TRACE,
                    handler=RotatingFileHandler(
                        filename=os.path.join(self.config.log_dir, logger_name),
                        maxBytes=client_config.log_max_bytes,
                        backupCount=client_config.log_backup_count,
                        encoding='utf-8',
                    ),
                    include_timestamp=False,
                    include_level=False,
                )

    @property
    def status(self) -> ClientStatus:
        return self._status

    @property
    def ready(self) -> Event:
        return self._ready_event

    def _reconnect(self, closing: Future[T]) -> None:
        # pylint: disable=unused-argument
        loop: AbstractEventLoop = get_event_loop()
        # loop.run_until_complete(self._disconnect())
        self.logger.info('AMQP connection closed', host=self.config.host)
        if self._is_shutting_down:
            return
        self._status = ClientStatus.ERROR
        self._channel_in = None
        self._channel_out = None
        self._connection = None
        self._ready_event.clear()
        loop.create_task(end_task(f'{self.config.queue} AMQP consumer'))
        loop.create_task(self.start())

    async def _consumer(self, message: DeliveredMessage) -> None:
        await self._processing_event.wait()
        self._processing_event.clear()
        event_data: JsonDict = orjson.loads(message.body)
        if self._logger_in:
            if self.trace_ignore_in:
                ignore: bool = any(
                    event_data.get(key) in val for key, val in self.trace_ignore_in.items()
                )
            else:
                ignore: bool = False
            if not ignore:
                trace: bytes = orjson.dumps(event_data, option=orjson.OPT_INDENT_2)
                self._logger_in.trace(trace.decode('utf-8'))
        await self.processor(event_data)
        # Acknowledge reception
        assert message.delivery_tag is not None  # For type checkers
        await message.channel.basic_ack(message.delivery_tag)
        self._processing_event.set()

    async def _consumer_monitor(self) -> None:
        queue_name: str = self.config.queue
        timeout: int = self.config.timeout
        while True:
            try:
                await self._ready_event.wait()
                assert self._channel_in is not None
                if queue_name not in self._channel_in.consumers:
                    await self._channel_in.basic_consume(
                        queue_name, self._consumer, timeout=timeout, consumer_tag=queue_name
                    )
                    self.logger.debug('AMQP consumer started', host=self.config.host)
            except Exception:  # pylint: disable=broad-except
                self.logger.exception('AMQP consumer error', host=self.config.host)
            if self._is_shutting_down:
                return
            await sleep(5)

    async def publish(self, message: JsonValue, routing_key: str, exchange: str) -> bool:
        await self._ready_event.wait()
        client_logger: StructuredLogger | None = self._loggers_client.get(exchange)
        if client_logger:
            if self.trace_ignore_out and isinstance(message, dict):
                ignore: bool = any(
                    message.get(key) in val
                    for key, val in self.trace_ignore_out.items()
                )
            else:
                ignore: bool = False
            if not ignore:
                trace: bytes = orjson.dumps(message, option=orjson.OPT_INDENT_2)
                client_logger.trace(trace.decode('utf-8'))
        try:
            assert self._channel_out is not None  # For type checkers
            await self._channel_out.basic_publish(
                orjson.dumps(message),
                routing_key=routing_key,
                exchange=exchange,
                timeout=self.config.timeout,
            )
            await self._channel_out.confirm_delivery(timeout=self.config.timeout)
        except Exception:  # pylint: disable=broad-except
            self.logger.exception(
                'Error while publihing to AMQP', routing_key=routing_key, exchange=exchange
            )
            await self._disconnect()
            return False
        return True

    async def start(self) -> None:
        if self._status in (ClientStatus.CONNECTED, ClientStatus.CONNECTING):
            raise RuntimeError('AMQP client already started')

        self._processing_event.set()  # Event is cleared initially
        prefetch_count: int = self.config.prefetch_count
        timeout: int = self.config.timeout
        queue_name: str = self.config.queue
        host: str = self.config.host
        port: int = self.config.port
        user: str = self.config.user
        pswd: str = self.config.pswd
        amqp_url: str = f'amqp://{user}:{pswd}@{host}:{port}?heartbeat=1'

        self._status = ClientStatus.CONNECTING
        run_task(self._consumer_monitor(), f'{queue_name} AMQP consumer')
        while True:
            try:
                self.logger.debug('Trying connection to AMQP', host=self.config.host)
                self._connection = Connection(amqp_url)
                await wait_for(self._connection.connect(), _SOCKET_TIMEOUT)
                self._channel_in = cast(Channel, await self._connection.channel())
                await self._channel_in.basic_qos(prefetch_count=prefetch_count, timeout=timeout)
                await self._channel_in.queue_declare(queue_name, durable=True)
                self._channel_out = cast(Channel, await self._connection.channel())
                for client in self.clients:
                    await self._channel_out.exchange_declare(
                        exchange=client.amqp_exchange, exchange_type='fanout', durable=True
                    )
                    arguments: ArgumentsType = {}
                    if client.amqp_dead_letter_exchange:
                        arguments['x-dead-letter-exchange'] = client.amqp_dead_letter_exchange
                    # Queue is assumed to have the same name as the exchange
                    await self._channel_out.queue_declare(
                        client.amqp_exchange, durable=True, arguments=arguments
                    )
                    await self._channel_out.queue_bind(client.amqp_exchange, client.amqp_exchange)
                self._connection.closing.add_done_callback(self._reconnect)
                self._status = ClientStatus.CONNECTED
                self.retry_timer.reset()
                self._ready_event.set()
                self.logger.info('AMQP connection established')
                return
            except TimeoutError:
                self.logger.error('AMQP connection attempt timed out', host=self.config.host)
                self._status = ClientStatus.ERROR
            except _AMQP_CONNECTION_EXCEPTIONS as err:
                self.logger.error('AMQP connection error', err=str(err), host=self.config.host)
                self._status = ClientStatus.ERROR
            except Exception:  # pylint: disable=broad-except
                self.logger.exception('Unexpected AMQP connection error', host=self.config.host)
                self._status = ClientStatus.ERROR
            except CancelledError:
                self._status = ClientStatus.ERROR
                if not self._is_shutting_down:
                    create_task(self.start())
                raise

            if self._is_shutting_down:
                return

            if self.logger.isEnabledFor(INFO):
                delay: float = self.retry_timer.next_delay()
                if delay > 0.0:
                    self.logger.info(
                        'Delaying next connect attempt', delay=delay, host=self.config.host
                    )
            await self.retry_timer.wait()

    async def stop(self) -> None:
        self.logger.debug('Stopping AMQP client', host=self.config.host)

        self._is_shutting_down = True
        await end_task(f'{self.config.queue} AMQP consumer')
        await self._disconnect()

    def is_running(self) -> bool:
        return self.status == ClientStatus.CONNECTED

    async def _disconnect(self) -> None:
        self._ready_event.clear()
        if self._channel_in:
            try:
                await wait_for(self._channel_in.close(), _SOCKET_TIMEOUT)
            except Exception:  # pylint: disable=broad-except
                self.logger.exception('Error while closing input channel', host=self.config.host)
            else:
                self.logger.debug('AMQP input channel closed', host=self.config.host)
            self._channel_in = None
        if self._channel_out:
            try:
                await wait_for(self._channel_out.close(), _SOCKET_TIMEOUT)
            except Exception:  # pylint: disable=broad-except
                self.logger.exception('Error while closing output channel', host=self.config.host)
            else:
                self.logger.debug('AMQP output channel closed', host=self.config.host)
            self._channel_out = None
        if self._connection:
            self._status = ClientStatus.UNINITIALIZED
            try:
                await wait_for(self._connection.close(), _SOCKET_TIMEOUT)
            except Exception:  # pylint: disable=broad-except
                self.logger.exception('Error while closing connection', host=self.config.host)
