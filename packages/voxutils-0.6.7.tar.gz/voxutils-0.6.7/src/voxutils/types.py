from datetime import date, datetime, time, timedelta
from decimal import Decimal
from enum import IntEnum, auto
from typing import TypeAlias, TypeVar
from uuid import UUID

DBValue: TypeAlias = (
    None
    | bool
    | int
    | float
    | str
    | bytes
    | Decimal
    | UUID
    | date
    | time
    | datetime
    | timedelta
    | list['DBValue']
    | tuple['DBValue', ...]
    | dict[str, 'DBValue']
)
DBTuple: TypeAlias = tuple[DBValue, ...]
DBList: TypeAlias = list[DBValue]
DBDict: TypeAlias = dict[str, DBValue]
DBParams: TypeAlias = DBTuple | DBList | DBDict
JsonValue: TypeAlias = (
    None
    | bool
    | int
    | float
    | str
    | tuple['JsonValue', ...]
    | list['JsonValue']
    | dict[str, 'JsonValue']
)
JsonTuple: TypeAlias = tuple[JsonValue, ...]
JsonList: TypeAlias = list[JsonValue]
JsonDict: TypeAlias = dict[str, JsonValue]
T = TypeVar('T')


class ClientStatus(IntEnum):
    UNINITIALIZED = auto()
    CONNECTING = auto()
    CONNECTED = auto()
    ERROR = auto()
    CRITICAL_ERROR = auto()
