import asyncio
import os
from unittest.mock import MagicMock

import pytest
import pytest_asyncio

from voxutils.abc import AbstractRetryTimer
from voxutils.postgresdriver import PostgresDriver
from voxutils.types import DBDict, DBValue

_DSN: str | None = os.getenv('TEST_POSTGRES_DSN')


class DummyRetryTimer(AbstractRetryTimer):
    async def wait(self) -> float:
        return 0.0

    def reset(self) -> None:
        pass

    def next(self) -> float:
        return 0.0

    def next_delay(self) -> float:
        return 0.0


@pytest.fixture
def mock_logger() -> MagicMock:
    logger = MagicMock()
    # By default disable trace logging to avoid noise in mock calls
    logger.isEnabledFor.return_value = False
    return logger


@pytest_asyncio.fixture
async def driver(mock_logger: MagicMock) -> PostgresDriver:
    if not _DSN:
        pytest.skip(
            'TEST_POSTGRES_DSN environment variable not set '
            '(example: postgresql://postgres:password@localhost:5432/postgres)'
        )
    driver: PostgresDriver = PostgresDriver(
        dsn=_DSN,
        retry_timer=DummyRetryTimer(),
        logger=mock_logger,
        pool_min_size=1,
        pool_max_size=10,
        timeout=5.0,
        command_timeout=30.0,
    )
    await driver.start()
    # Create a fresh test table for this test
    await driver.exec(
        """
        DROP TABLE IF EXISTS test_table;
        CREATE TABLE test_table (
            id SERIAL PRIMARY KEY,
            name TEXT NOT NULL,
            value INTEGER NOT NULL
        );
        """
    )
    return driver


@pytest.mark.asyncio
async def test_basic_exec_and_select(driver: PostgresDriver) -> None:
    # Insert data with plain positional query
    await driver.exec(
        """
        INSERT INTO test_table (name, value)
        VALUES ('alice', 100), ('bob', 200), ('charlie', 300)
        """
    )
    assert driver.rowcount == 3

    rows = await driver.select("SELECT id, name, value FROM test_table ORDER BY id")
    assert driver.rowcount == 3
    assert len(rows) == 3
    assert rows == [
        (1, 'alice', 100),
        (2, 'bob', 200),
        (3, 'charlie', 300),
    ]


@pytest.mark.asyncio
async def test_named_parameters(driver: PostgresDriver) -> None:
    await driver.exec(
        "INSERT INTO test_table (name, value) VALUES (:name, :value)",
        {'name': 'dave', 'value': 400},
    )
    assert driver.rowcount == 1

    rows = await driver.select(
        "SELECT id, name, value FROM test_table WHERE name = :name",
        {'name': 'dave'},
    )
    assert len(rows) == 1
    assert rows[0] == (1, 'dave', 400)  # first inserted in this test


@pytest.mark.asyncio
async def test_select_dict(driver: PostgresDriver) -> None:
    await driver.exec(
        "INSERT INTO test_table (name, value) VALUES (:n1, :v1), (:n2, :v2)",
        {'n1': 'emma', 'v1': 500, 'n2': 'frank', 'v2': 600},
    )

    rows = await driver.select_dict("SELECT * FROM test_table ORDER BY id")
    assert len(rows) == 2
    assert rows[0]['name'] == 'emma'
    assert rows[0]['value'] == 500
    assert rows[1]['name'] == 'frank'
    assert rows[1]['value'] == 600


@pytest.mark.asyncio
async def test_scalar_and_scalarlist(driver: PostgresDriver) -> None:
    await driver.exec(
        """
        INSERT INTO test_table (name, value)
        VALUES ('one', 1), ('two', 2), ('three', 3)
        """
    )

    count = await driver.scalar("SELECT COUNT(*) FROM test_table")
    assert count == 3
    assert driver.rowcount == 1  # scalar sets rowcount to 1 if value, else 0

    names = await driver.scalarlist("SELECT name FROM test_table ORDER BY id")
    assert names == ('one', 'two', 'three')

    single_row = await driver.scalarlist("SELECT name, value FROM test_table WHERE name = 'two'")
    assert single_row == ('two', 2)


@pytest.mark.asyncio
async def test_rowcount(driver: PostgresDriver) -> None:
    await driver.exec(
        "INSERT INTO test_table (name, value) VALUES ('test', 999)"
    )
    assert driver.rowcount == 1

    await driver.exec("UPDATE test_table SET value = 1000 WHERE name = 'test'")
    assert driver.rowcount == 1

    await driver.exec("DELETE FROM test_table WHERE name = 'test'")
    assert driver.rowcount == 1


@pytest.mark.asyncio
async def test_streaming_yield(driver: PostgresDriver) -> None:
    # Insert a few rows
    await driver.exec(
        """
        INSERT INTO test_table (name, value)
        VALUES ('a', 1), ('b', 2), ('c', 3)
        """
    )

    # Test yield_dict
    collected_dicts: list[DBDict] = []
    async for row in driver.yield_dict("SELECT * FROM test_table ORDER BY id"):
        collected_dicts.append(row)
    assert len(collected_dicts) == 3
    assert collected_dicts[0] == {'id': 1, 'name': 'a', 'value': 1}

    # Test yield_tuple
    collected_tuples: list[tuple[DBValue, ...]] = []
    async for row in driver.yield_tuple("SELECT * FROM test_table ORDER BY id"):
        collected_tuples.append(row)
    assert len(collected_tuples) == 3
    assert collected_tuples[0] == (1, 'a', 1)


@pytest.mark.asyncio
async def test_transaction_commit_and_rollback(driver: PostgresDriver) -> None:
    # Successful transaction (auto-commit)
    async with driver.transaction() as conn:
        await conn.execute(
            "INSERT INTO test_table (name, value) VALUES ('committed', 123)"
        )

    rows = await driver.select("SELECT value FROM test_table WHERE name = 'committed'")
    assert len(rows) == 1
    assert rows[0][0] == 123

    # Failed transaction (auto-rollback)
    with pytest.raises(RuntimeError):
        async with driver.transaction() as conn:
            await conn.execute(
                "INSERT INTO test_table (name, value) VALUES ('rolledback', 999)"
            )
            raise RuntimeError('force rollback')

    rows = await driver.select("SELECT value FROM test_table WHERE name = 'rolledback'")
    assert len(rows) == 0


@pytest.mark.asyncio
async def test_listen_notify(driver: PostgresDriver) -> None:
    received: list[object] = []
    termination_listener_called: bool = False

    async def notify_callback(_channel: str, payload: object) -> None:
        nonlocal received
        received.append(payload)

    async def termination_callback() -> None:
        nonlocal termination_listener_called
        termination_listener_called = True

    # Test notify
    await driver.add_listener('test_channel', notify_callback)
    await driver.notify('test_channel', 'hello_world')
    for _ in range(10):
        if received:
            break
        await asyncio.sleep(0.05)
    assert received == ['hello_world']

    driver.add_termination_listener(termination_callback)
    # Simulate connection termination
    # Get the backend PID of driver listener connection
    assert driver._listener_conn is not None
    pid: int = driver._listener_conn.get_server_pid()
    # Simulate sudden drop - exactly what happens on network/server issues (needs superuser rights)
    await driver.exec(f"SELECT pg_terminate_backend({pid})")
    # Test termination listener
    for _ in range(10):
        if termination_listener_called:
            break
        await asyncio.sleep(0.05)
    assert termination_listener_called

    await driver.ready.wait()  # Wait for reconnect

    # Test notify again
    received.clear()
    await driver.notify('test_channel', 'hello_world')
    for _ in range(10):
        if received:
            break
        await asyncio.sleep(0.05)
    assert received == ['hello_world']
    await driver.remove_listener('test_channel', notify_callback)

    # Test termination listener again, this time by stopping the driver
    termination_listener_called = False
    await driver.exec("DROP TABLE IF EXISTS test_table")  # Cleanup
    await driver.stop()
    for _ in range(10):
        if termination_listener_called:
            break
        await asyncio.sleep(0.05)
    assert termination_listener_called
    # No need to remove listener, it will be removed automatically
