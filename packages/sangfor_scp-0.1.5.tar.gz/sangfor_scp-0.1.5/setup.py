# Geriye dönük uyumluluk için (pip install -e . gibi komutlar için)
# Asıl konfigürasyon pyproject.toml'dadır.
from setuptools import setup
setup()
