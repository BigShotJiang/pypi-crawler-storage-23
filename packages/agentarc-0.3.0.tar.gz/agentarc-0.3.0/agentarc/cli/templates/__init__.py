"""
Agent code and env templates for the AgentARC CLI wizard.
"""
