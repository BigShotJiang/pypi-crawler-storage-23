print("boo")
