# py2docfx user guides

Document generation tool for docfx style yamls based on Sphinx. [py2docx · PyPI](https://pypi.org/project/py2docfx/)

## Environment

We recommand you install a python release with version == 3.11, it's the SDK version we're currently using in our document generation pipelines.
This package doesn't support Python 3.13 because it depends on sphinx==6.1.3. When using Python 3.13, you may encounter this problem: [Python issue #104818](https://github.com/python/cpython/issues/104818).

When use py2docfx to locally generate documents, please [create and activate a new venv to run](https://docs.python.org/3/library/venv.html) the tool. If the tool isn't runing under a venv, it will raise an error.
This is to prevent py2docfx install/upgrade denpendencies in developer's local environments, you can use "--no-venv-required" to suppress this check, just to be careful changes in your local python environment.

![not-in-venv](doc/image/root-readme/not-in-venv-error.png)
![activate-venv](doc/image/root-readme/create-venv.png)

## Install py2docfx

Run the command below to install py2docfx. It will install its dependency like Sphinx 6.1.3, pyyaml, wheel, etc.

`python -m pip install py2docfx`

![install-py2docfx](doc/image/root-readme/install-py2docfx.png)

## Run py2docfx

py2docfx supports building documents for single package with passing package information through command parameters, and it also supports building document for multiple packages with passing package information through a Json string or a path of local Json config file in format of [package-latest.json](https://github.com/MicrosoftDocs/azure-docs-sdk-python/blob/main/ci-configs/packages-latest.json)

You can pass path of an empty folder (or a path not existing) by `-o` parameter and py2docfx will move generated yamls there. If the folder isn't empty, py2docfx will raise exception to prevent overwriting any files in it.

![output-folder](doc/image/root-readme/output-folder.png)

### Run py2docfx with package information in command parameters

#### To use PyPi package as input

##### required parameters

| Parameter Name | Value | Example |
| -- | -- | -- |
| -t (--install-type) | "pypi" | / |
| -n (--package-name) | package name on pypi | "azure-common" |

##### optional parameters

| Parameter Name | Value | Example / Description |
| -- | -- | -- |
| -v (--version) | version specifier acceptable by pip | "==1.1.28"/">1.0" |
| -i (--extra-index-url) | Python Package Index used by pip | `"https://my.local.mirror.com/simple"` |
| --prefer-source-distribution | / | a flag to use "--no-binary" mode during pip download/install |

##### example

`python -m py2docfx -t pypi -n azure-common -v ==1.1.28`

![pypi](doc/image/root-readme/pypi.png)

#### To use source code as input

##### required parameters

| Parameter Name | Value | Example |
| -- | -- | -- |
| -t (--install-type) | "source_code" | / |

##### optional parameters

Note: either url (remote git repo) or folder (local source code) should be provided. 
| Parameter Name | Value | Example |
| -- | -- | -- |
| --url | github repo url of source code | `"https://github.com/Azure/azure-sdk-for-python"` |
| --branch | github branch of source code (useless when folder is a local path) | "main" |
| --folder | when given url, it's relative path from repo root to python package root, otherwise should be a path to a local Python package root | `"sdk/core/azure-common"` or `"C:\temp\azure-ai-ml-1.11.0a20230913004"` |

##### example

From github repo:

`python -m py2docfx -t source_code --url https://github.com/Azure/azure-sdk-for-python --branch main --folder "sdk/core/azure-common"`

![source-code-github](doc/image/root-readme/source-code-github.png)

From local source code (below command):

`python -m py2docfx -t source_code --folder "C:/git_sdk_repos/azure-sdk-for-python/sdk/core/azure-common" "tests\**"`

![source-code-local](doc/image/root-readme/source-code-local.png)

#### To use distribution file as input

##### required parameters

| Parameter Name | Value | Example |
| -- | -- | -- |
| -t (--install-type) | "dist_file" | / |

##### optional parameters

| Parameter Name | Value | Example |
| -- | -- | -- |
| --location | a remote url or a local path to the distribution file | `"https://<>.blob.core.windows.net/repackaged/azure-functions-1.4.0.tar.gz"` or `"C:\temp\semantic_kernel-0.3.11.dev0-py3-none-any.whl"` |

##### example

From remote distribution file:

`python -m py2docfx -t dist_file --location "https://<DISTRIBUTION_STORAGE>/repackaged/azure-functions-1.4.0.tar.gz"`

![dist-file-remote](doc/image/root-readme/dist-file-remote.png)

From local distribution file:

`python -m py2docfx -t dist_file --location "d:\\0921\azure_common-1.1.28-py2.py3-none-any.whl"`

![dist-file-local](doc/image/root-readme/dist-file-local.png)

#### Common optional parameters

| Parameter Name | Value | Example/Description |
| -- | -- | -- |
| -o (--output-root-folder) | a parameter to override default folder containing yamls built by py2docfx, need to be empty if path already exists | "D:\temp\0921" |
| --editable | / | flag to install a local project in “editable” mode in pip |
| --build-in-subpackage | / | flag to run sphinx build in each subpackages, used to accelerate when package is huge |
| --venv-required | / | defaultly True, when passing `--no-venv-required` py2docfx, won't check whether current python environment is a venv |

#### nargs

py2docfx accepts multiple fnmatch-style patterns to mark some files as excluded when generating documents, you can append them to the tail of other parts of command
| Example | Description |
| -- | -- |
| "test*" "build/*" | skip files matching given patterns when Sphinx generating documents |

`python -m py2docfx -t pypi -n azure-common --no-venv-required "tests/**" "doc/**" "build/**" "*.egg-info/**"`

![exclude](doc/image/root-readme/exclude.png)

### Run py2docfx with package information in Json file

Use `--param-file-path` parameter to provide the Json config file path.
the Json should follow the format of [package-latest.json](https://github.com/MicrosoftDocs/azure-docs-sdk-python/blob/main/ci-configs/packages-latest.json).
Detailed explanations of each parameter are given in the "Run py2docfx with package information in command parameters" section above.

#### example
`python -m py2docfx --param-file-path "C:\git_doc_repos\azure-docs-sdk-python\ci-configs\packages-latest.json"`

![param-file](doc/image/root-readme/param-file.png)

### Run py2docfx with package information in Json string

A Json string following the format of [package-latest.json](https://github.com/MicrosoftDocs/azure-docs-sdk-python/blob/main/ci-configs/packages-latest.json).
Note that you may need to escape some characters. Detailed explanation of each parameter are given in the "Run py2docfx with package information in command parameters" section above.

### Possible issues

We suppose tool is executed in a new venv per new run, if py2docfx reports a git clone conflict error, it means a repo cloned in previous run hasn't been cleared. Please go to the py2docfx root folder installed by pip and delete these folders: `source_repo`/`dist_temp`/`target_repo`.

Error message like "Unknown archive format" also means you need to clear temp folders.
![dist_temp-conflict](doc/image/root-readme/error-conflict-dist-temp.png)

Error message like "fail to import module", "You need to install" means a dependency of the SDK package isn't included in its metadata. You may need to manual install it in the venv.
![missing-dependency](doc/image/root-readme/error-missing-dependency.png)
![missing-dependency-install](doc/image/root-readme/error-missing-dependency-install.png)

Error message like "The system cannot find the file specified" and it's in call stack of "py2docfx\convert_prepare\pip_utils" may indicates "pip" isn't recognizable on your local machine. You may need to add path of `pip.exe` to system path.
![pip-not-in-path](doc/image/root-readme/pip-not-in-path.png)

## Develop Guideline (Don'ts)

1. Don't change the working directory(cwd) in source code (except to PACKAGE_ROOT at the start of __main__.py),
because all subprocess calls are presumed to work under PACKAGE_ROOT, running in difference working directory will
 cause components(e.g. download/install/build) fail to work together.

## Local Debug
Go to [Local Debug guideline](doc/partial/local-debug.md) file.

## Package Publishing
The package is published via [ESRP Release ADO task](https://dev.azure.com/ceapex/Engineering/_git/py2docfx?path=/.pipelines/templates/build.yml&version=GBdevelop&line=94&lineEnd=111&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents), 
and the task uses the service connection [
Learn-Reference-ESRP-Release](https://dev.azure.com/ceapex/Engineering/_settings/adminservices?resourceId=ff6be5d8-4686-47c3-adf8-b79fe70d084b) 
to access the cert "ESRP-Release" stored in [ReferenceAutomation-Prod](https://portal.azure.com/#@mspmecloud.onmicrosoft.com/resource/subscriptions/99697fb6-fa09-4b61-bd5a-1f29d252d9a1/resourceGroups/ReferenceAutomation-PROD/providers/Microsoft.KeyVault/vaults/ReferenceAutomation-Prod/certificates)
to do the auth and sign work when connecting to ESRP Release Service.