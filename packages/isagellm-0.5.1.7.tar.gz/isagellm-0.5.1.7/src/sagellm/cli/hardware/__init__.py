"""Hardware detection utilities."""

from .ascend import check_ascend_available
from .cuda import check_cuda_available
from .domestic import check_haiguang_available, check_kunlun_available, check_muxi_available
from .install_configs import (
    BACKEND_PRIORITY,
    PYTORCH_INSTALL_CONFIGS,
    PYTORCH_MIRRORS,
)

__all__ = [
    "check_cuda_available",
    "check_ascend_available",
    "check_kunlun_available",
    "check_haiguang_available",
    "check_muxi_available",
    "BACKEND_PRIORITY",
    "PYTORCH_INSTALL_CONFIGS",
    "PYTORCH_MIRRORS",
]
