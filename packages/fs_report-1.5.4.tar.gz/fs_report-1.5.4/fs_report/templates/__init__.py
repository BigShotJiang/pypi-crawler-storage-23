"""Bundled Jinja2 HTML templates for fs-report."""
