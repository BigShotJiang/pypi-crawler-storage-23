"""Bundled recipe YAML files for fs-report."""
