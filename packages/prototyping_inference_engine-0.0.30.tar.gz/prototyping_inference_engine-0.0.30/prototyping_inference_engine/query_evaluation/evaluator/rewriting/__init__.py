"""
Package: rewriting evaluators.
"""
