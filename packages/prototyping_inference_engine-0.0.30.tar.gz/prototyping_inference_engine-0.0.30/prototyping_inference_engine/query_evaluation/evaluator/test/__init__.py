"""Tests for query evaluators."""
