"""
ID rule compilation package.
"""
