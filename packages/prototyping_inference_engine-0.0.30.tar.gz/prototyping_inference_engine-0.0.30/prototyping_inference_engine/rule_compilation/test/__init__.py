"""
Tests for rule compilation.
"""
