"""
Hierarchical rule compilation package.
"""
