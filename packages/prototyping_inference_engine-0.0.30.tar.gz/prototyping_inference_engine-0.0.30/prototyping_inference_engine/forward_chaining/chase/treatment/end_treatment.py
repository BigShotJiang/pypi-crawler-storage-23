"""End-of-step treatment marker."""

from prototyping_inference_engine.forward_chaining.chase.treatment.treatment import (
    Treatment,
)


class EndTreatment(Treatment):
    pass
