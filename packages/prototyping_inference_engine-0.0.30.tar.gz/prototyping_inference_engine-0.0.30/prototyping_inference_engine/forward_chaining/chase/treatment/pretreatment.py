"""Pretreatment marker."""

from prototyping_inference_engine.forward_chaining.chase.treatment.treatment import (
    Treatment,
)


class Pretreatment(Treatment):
    pass
