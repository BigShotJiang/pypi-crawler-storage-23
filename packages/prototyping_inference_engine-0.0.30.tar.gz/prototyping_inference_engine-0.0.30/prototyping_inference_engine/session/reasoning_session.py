"""
ReasoningSession - Main class for scoped reasoning sessions.

Provides a session context for reasoning with managed vocabulary,
fact bases, ontologies, and query rewriting.
"""

from math import inf
from pathlib import Path
from urllib.parse import urlparse
from typing import Optional, Iterable, Iterator, Tuple, Union, TYPE_CHECKING

from prototyping_inference_engine.api.atom.atom import Atom
from prototyping_inference_engine.api.atom.predicate import Predicate
from prototyping_inference_engine.api.atom.set.frozen_atom_set import FrozenAtomSet
from prototyping_inference_engine.api.atom.term.constant import Constant
from prototyping_inference_engine.api.atom.term.literal import Literal
from prototyping_inference_engine.api.atom.term.term import Term
from prototyping_inference_engine.api.atom.term.variable import Variable
from prototyping_inference_engine.api.atom.term.factory import (
    VariableFactory,
    ConstantFactory,
    LiteralFactory,
    PredicateFactory,
)
from prototyping_inference_engine.api.atom.term.storage import (
    DictStorage,
    WeakRefStorage,
)
from prototyping_inference_engine.api.atom.term.storage.storage_strategy import (
    TermStorageStrategy,
)
from prototyping_inference_engine.api.atom.term.literal_config import LiteralConfig
from prototyping_inference_engine.api.kb.knowledge_base import KnowledgeBase
from prototyping_inference_engine.api.kb.rule_base import RuleBase
from prototyping_inference_engine.api.ontology.ontology import Ontology
from prototyping_inference_engine.api.ontology.rule.rule import Rule
from prototyping_inference_engine.api.ontology.constraint.negative_constraint import (
    NegativeConstraint,
)
from prototyping_inference_engine.api.query.conjunctive_query import ConjunctiveQuery
from prototyping_inference_engine.api.query.union_query import UnionQuery
from prototyping_inference_engine.api.data.schema import (
    SchemaAware,
    SessionSchemaRegistry,
)
from prototyping_inference_engine.session.cleanup_stats import SessionCleanupStats
from prototyping_inference_engine.session.io_config import SessionIOConfig
from prototyping_inference_engine.session.parse_result import ParseResult
from prototyping_inference_engine.session.term_factories import TermFactories
from prototyping_inference_engine.session.providers import (
    FactBaseFactoryProvider,
    RewritingAlgorithmProvider,
    ParserProvider,
    DefaultFactBaseFactoryProvider,
    DefaultRewritingAlgorithmProvider,
    DlgpeParserProvider,
)

if TYPE_CHECKING:
    from prototyping_inference_engine.api.data.readable_data import ReadableData
    from prototyping_inference_engine.api.fact_base.fact_base import FactBase
    from prototyping_inference_engine.api.fact_base.mutable_in_memory_fact_base import (
        MutableInMemoryFactBase,
    )
    from prototyping_inference_engine.api.formula.formula_builder import FormulaBuilder
    from prototyping_inference_engine.api.query.fo_query import FOQuery
    from prototyping_inference_engine.api.query.query import Query
    from prototyping_inference_engine.api.query.factory.fo_query_factory import (
        FOQueryFactory,
    )
    from prototyping_inference_engine.rdf.translator import RDFTranslationMode


def _unique_preserve_order(queries: Iterable["Query"]) -> list["Query"]:
    seen: set["Query"] = set()
    ordered: list["Query"] = []
    for query in queries:
        if query in seen:
            continue
        seen.add(query)
        ordered.append(query)
    return ordered


class ReasoningSession:
    """
    A scoped reasoning session with managed vocabulary and reasoning capabilities.

    The session provides:
    - Extensible term factory registry (OCP compliant)
    - Factory methods for creating atoms, fact bases, and ontologies
    - DLGPE parsing with term tracking
    - UCQ rewriting
    - Context manager support for automatic cleanup

    Example usage:
        # Simple usage with defaults
        with ReasoningSession.create(auto_cleanup=True) as session:
            result = session.parse("p(a,b). q(X) :- p(X,Y).")
            x = session.variable("X")
            rewritten = session.rewrite(result.queries[0], result.rules)

        # Advanced usage with custom factories
        factories = TermFactories()
        factories.register(Variable, VariableFactory(custom_storage))
        factories.register(Constant, ConstantFactory(custom_storage))
        factories.register(Predicate, PredicateFactory(custom_storage))

        session = ReasoningSession(term_factories=factories)
    """

    def __init__(
        self,
        term_factories: TermFactories,
        parser_provider: Optional[ParserProvider] = None,
        fact_base_provider: Optional[FactBaseFactoryProvider] = None,
        rewriting_provider: Optional[RewritingAlgorithmProvider] = None,
        literal_config: Optional[LiteralConfig] = None,
        io_config: Optional[SessionIOConfig] = None,
    ) -> None:
        """
        Initialize a reasoning session.

        Args:
            term_factories: Registry of term factories (must include Variable, Constant, Predicate)
            parser_provider: Provider for parsing content (default: DlgpeParserProvider)
            fact_base_provider: Provider for creating fact bases (default: DefaultFactBaseFactoryProvider)
            rewriting_provider: Provider for rewriting algorithm (default: DefaultRewritingAlgorithmProvider)
        """
        self._term_factories = term_factories
        self._literal_config = literal_config or LiteralConfig.default()
        self._io_config = io_config or SessionIOConfig()

        if Literal not in self._term_factories:
            self._term_factories.register(
                Literal, LiteralFactory(DictStorage(), self._literal_config)
            )

        self._python_function_source = None

        if Literal in self._term_factories:
            from prototyping_inference_engine.api.data.python_function_data import (
                PythonFunctionReadable,
            )

            literal_factory = self._term_factories.get(Literal)
            self._python_function_source = PythonFunctionReadable(literal_factory)

        self._parser_provider = parser_provider or DlgpeParserProvider(
            self._term_factories,
            python_function_names=(
                self._python_function_source.function_names
                if self._python_function_source
                else None
            ),
        )
        self._fact_base_provider = (
            fact_base_provider or DefaultFactBaseFactoryProvider()
        )
        self._rewriting_provider = (
            rewriting_provider or DefaultRewritingAlgorithmProvider()
        )

        # Session-owned resources
        self._fact_bases: list["FactBase"] = []
        self._rule_bases: list[RuleBase] = []
        self._ontologies: list[Ontology] = []
        self._knowledge_bases: list[KnowledgeBase] = []
        self._closed = False
        self._iri_base: str | None = None
        self._iri_prefixes: dict[str, str] = {}
        self._computed_prefixes: dict[str, str] = {}
        self._schema_registry = SessionSchemaRegistry()

    @classmethod
    def create(
        cls,
        auto_cleanup: bool = True,
        parser_provider: Optional[ParserProvider] = None,
        fact_base_provider: Optional[FactBaseFactoryProvider] = None,
        rewriting_provider: Optional[RewritingAlgorithmProvider] = None,
        literal_config: Optional[LiteralConfig] = None,
        io_config: Optional[SessionIOConfig] = None,
        rdf_translation_mode: Optional["RDFTranslationMode"] = None,
    ) -> "ReasoningSession":
        """
        Factory method to create a session with default term factories.

        Args:
            auto_cleanup: If True, use WeakRefStorage for automatic cleanup.
                         If False, use DictStorage (manual cleanup via clear).
            parser_provider: Custom parser provider (optional, default: DlgpeParserProvider)
            fact_base_provider: Custom fact base provider (optional)
            rewriting_provider: Custom rewriting provider (optional)

        Returns:
            A new ReasoningSession with standard term factories configured
        """
        # Choose storage strategy based on auto_cleanup
        var_storage: TermStorageStrategy[str, Variable]
        const_storage: TermStorageStrategy[object, Constant]
        pred_storage: TermStorageStrategy[tuple[str, int], Predicate]
        lit_storage: TermStorageStrategy[object, Literal]
        if auto_cleanup:
            var_storage = WeakRefStorage()
            const_storage = WeakRefStorage()
            pred_storage = WeakRefStorage()
            lit_storage = WeakRefStorage()
        else:
            var_storage = DictStorage()
            const_storage = DictStorage()
            pred_storage = DictStorage()
            lit_storage = DictStorage()

        # Create and register standard factories
        factories = TermFactories()
        factories.register(Variable, VariableFactory(var_storage))
        factories.register(Constant, ConstantFactory(const_storage))
        factories.register(
            Literal,
            LiteralFactory(lit_storage, literal_config or LiteralConfig.default()),
        )
        factories.register(Predicate, PredicateFactory(pred_storage))

        if rdf_translation_mode is not None:
            if io_config is None:
                io_config = SessionIOConfig().with_rdf_translation_mode(
                    rdf_translation_mode
                )
            else:
                io_config = io_config.with_rdf_translation_mode(rdf_translation_mode)

        return cls(
            term_factories=factories,
            parser_provider=parser_provider,
            fact_base_provider=fact_base_provider,
            rewriting_provider=rewriting_provider,
            literal_config=literal_config,
            io_config=io_config,
        )

    # =========================================================================
    # Properties
    # =========================================================================

    @property
    def term_factories(self) -> TermFactories:
        """Access the term factory registry."""
        return self._term_factories

    @property
    def io_config(self) -> SessionIOConfig:
        """Access the session IO configuration."""
        return self._io_config

    @property
    def literal_config(self) -> LiteralConfig:
        """Access the literal configuration for this session."""
        return self._literal_config

    @property
    def python_function_source(self):
        """Access the Python function readable data source."""
        return self._python_function_source

    @property
    def fact_bases(self) -> list["FactBase"]:
        """Return a copy of the list of fact bases created in this session."""
        return list(self._fact_bases)

    @property
    def iri_base(self) -> str | None:
        """Return the last parsed base IRI (if any)."""
        return self._iri_base

    @property
    def iri_prefixes(self) -> dict[str, str]:
        """Return the last parsed prefix map."""
        return dict(self._iri_prefixes)

    @property
    def computed_prefixes(self) -> dict[str, str]:
        """Return the last parsed computed prefix map."""
        return dict(self._computed_prefixes)

    @property
    def ontologies(self) -> list[Ontology]:
        """Return a copy of the list of ontologies created in this session."""
        return list(self._ontologies)

    @property
    def rule_bases(self) -> list[RuleBase]:
        """Return a copy of the list of rule bases created in this session."""
        return list(self._rule_bases)

    @property
    def knowledge_bases(self) -> list[KnowledgeBase]:
        """Return a copy of the list of knowledge bases created in this session."""
        return list(self._knowledge_bases)

    @property
    def is_closed(self) -> bool:
        """Return True if the session has been closed."""
        return self._closed

    @property
    def schema_registry(self) -> SessionSchemaRegistry:
        """Access the session-level predicate schema registry."""
        return self._schema_registry

    # =========================================================================
    # Term creation convenience methods
    # =========================================================================

    def variable(self, identifier: str) -> Variable:
        """
        Create or get a variable.

        Args:
            identifier: The variable identifier (e.g., "X", "Y")

        Returns:
            The Variable instance
        """
        self._check_not_closed()
        return self._term_factories.get(Variable).create(identifier)

    def constant(self, identifier: object) -> Constant:
        """
        Create or get a constant.

        Args:
            identifier: The constant identifier (e.g., "a", 42)

        Returns:
            The Constant instance
        """
        self._check_not_closed()
        return self._term_factories.get(Constant).create(identifier)

    def literal(
        self,
        lexical: str,
        datatype: Optional[str] = None,
        lang: Optional[str] = None,
    ) -> Literal:
        """
        Create or get a literal term.

        Args:
            lexical: The literal lexical form
            datatype: Optional datatype IRI or prefixed name
            lang: Optional language tag

        Returns:
            The Literal instance
        """
        self._check_not_closed()
        return self._term_factories.get(Literal).create(lexical, datatype, lang)

    def register_python_function(
        self,
        name: str,
        func,
        *,
        mode: str = "terms",
        input_arity: Optional[int] = None,
        output_position: Optional[int] = None,
        required_positions: Optional[Iterable[int]] = None,
        min_bound: Optional[int] = None,
        solver=None,
        returns_multiple: bool = False,
    ):
        """
        Register a Python function for computed evaluation.

        Args:
            name: Function name
            func: Callable to execute
            mode: \"terms\" or \"python\"
            input_arity: Number of input arguments
            output_position: Result position (default: last)
            required_positions: Positions that must be bound to evaluate
            min_bound: Minimum number of bound positions
            solver: Optional solver for reversible functions
            returns_multiple: True if func returns an iterable of results
        """
        if self._python_function_source is None:
            raise RuntimeError("Python function source is not available")
        return self._python_function_source.register_function(
            name,
            func,
            mode=mode,
            input_arity=input_arity,
            output_position=output_position,
            required_positions=required_positions,
            min_bound=min_bound,
            solver=solver,
            returns_multiple=returns_multiple,
        )

    def predicate(self, name: str, arity: int) -> Predicate:
        """
        Create or get a predicate.

        Args:
            name: The predicate name (e.g., "p", "parent")
            arity: The number of arguments

        Returns:
            The Predicate instance
        """
        self._check_not_closed()
        return self._term_factories.get(Predicate).create(name, arity)

    def fresh_variable(self) -> Variable:
        """
        Create a fresh variable with a unique identifier.

        Returns:
            A new Variable with a unique identifier
        """
        self._check_not_closed()
        return self._term_factories.get(Variable).fresh()

    def atom(self, predicate: Predicate, *terms: Term) -> Atom:
        """
        Create an atom with the given predicate and terms.

        Args:
            predicate: The predicate
            *terms: The terms (variables or constants)

        Returns:
            A new Atom instance
        """
        self._check_not_closed()
        return Atom(predicate, *terms)

    def formula(self) -> "FormulaBuilder":
        """
        Create a formula builder for constructing first-order formulas.

        Returns:
            A new FormulaBuilder bound to this session

        Example:
            formula = (session.formula()
                .forall("X")
                .exists("Y")
                .atom("p", "X", "Y")
                .and_()
                .atom("q", "Y")
                .build())
        """
        from prototyping_inference_engine.api.formula.formula_builder import (
            FormulaBuilder,
        )

        self._check_not_closed()
        return FormulaBuilder(self)

    def fo_query(self) -> "FOQueryFactory":
        """
        Create a factory for constructing first-order queries.

        Returns:
            A new FOQueryFactory bound to this session

        Example using builder:
            query = (session.fo_query().builder()
                .answer("X")
                .exists("Y")
                .atom("p", "X", "Y")
                .and_()
                .atom("q", "Y")
                .build())
            # Result: ?(X) :- ∃Y.(p(X,Y) ∧ q(Y))

        Example from formula:
            formula = session.formula().atom("p", "X", "Y").build()
            query = session.fo_query().from_formula(formula, ["X"])
        """
        from prototyping_inference_engine.api.query.factory.fo_query_factory import (
            FOQueryFactory,
        )

        self._check_not_closed()
        return FOQueryFactory(self)

    # =========================================================================
    # Factory methods for complex objects
    # =========================================================================

    def create_fact_base(
        self, atoms: Optional[Iterable[Atom]] = None
    ) -> "MutableInMemoryFactBase":
        """
        Create a mutable fact base and register it with the session.

        Args:
            atoms: Optional initial atoms

        Returns:
            A new mutable fact base
        """
        self._check_not_closed()
        fb = self._fact_base_provider.create_mutable(atoms)
        self._fact_bases.append(fb)
        self._register_source_schemas(fb)
        return fb

    def create_ontology(
        self,
        rules: Optional[set[Rule]] = None,
        constraints: Optional[set[NegativeConstraint]] = None,
    ) -> Ontology:
        """
        Create an ontology and register it with the session.

        Args:
            rules: Optional set of rules
            constraints: Optional set of negative constraints

        Returns:
            A new Ontology instance
        """
        self._check_not_closed()
        onto = Ontology(rules or set(), constraints or set())
        self._ontologies.append(onto)
        return onto

    def create_rule_base(
        self,
        rules: Optional[set[Rule]] = None,
        constraints: Optional[set[NegativeConstraint]] = None,
    ) -> RuleBase:
        """
        Create a rule base and register it with the session.

        Args:
            rules: Optional set of rules
            constraints: Optional set of negative constraints

        Returns:
            A new RuleBase instance
        """
        self._check_not_closed()
        rule_base = RuleBase(rules or set(), constraints or set())
        self._rule_bases.append(rule_base)
        return rule_base

    def create_knowledge_base(
        self,
        fact_base: Optional["FactBase"] = None,
        rule_base: Optional[RuleBase] = None,
    ) -> KnowledgeBase:
        """
        Create a knowledge base and register it with the session.

        Args:
            fact_base: Optional FactBase to attach (defaults to new mutable FactBase)
            rule_base: Optional RuleBase to attach (defaults to new RuleBase)

        Returns:
            A new KnowledgeBase instance
        """
        self._check_not_closed()
        if fact_base is None:
            fact_base = self.create_fact_base()
        else:
            self._register_source_schemas(fact_base)
        if rule_base is None:
            rule_base = self.create_rule_base()
        kb = KnowledgeBase(fact_base, rule_base)
        self._knowledge_bases.append(kb)
        return kb

    # =========================================================================
    # Parsing methods
    # =========================================================================

    def parse(self, text: str) -> ParseResult:
        """
        Parse text content and return structured results.

        Uses the configured parser provider (default: DLGPE).
        All terms and predicates are tracked by this session's factories.

        Args:
            text: Text content to parse (format depends on parser provider)

        Returns:
            ParseResult containing facts, rules, queries, constraints, and sources
        """
        return self._parse_with_imports(text, source_path=None)

    def parse_file(self, path: Union[str, Path]) -> ParseResult:
        """
        Parse a DLGPE file and resolve @import directives relative to it.
        """
        self._check_not_closed()
        source_path = Path(path)
        text = source_path.read_text(encoding="utf-8")
        return self._parse_with_imports(text, source_path=source_path)

    def _parse_with_imports(
        self, text: str, source_path: Optional[Path]
    ) -> ParseResult:
        self._check_not_closed()

        self._iri_base = None
        self._iri_prefixes = {}
        self._computed_prefixes = {}

        parsed = None
        parse_document = getattr(self._parser_provider, "parse_document", None)
        if callable(parse_document):
            parsed = parse_document(text)
            if isinstance(parsed, dict):
                header = parsed.get("header", {}) or {}
                if isinstance(header, dict):
                    base = header.get("base")
                    prefixes = header.get("prefixes", {})
                    computed = header.get("computed", {})
                    if isinstance(base, str) or base is None:
                        self._iri_base = base
                    if isinstance(prefixes, dict):
                        self._iri_prefixes = dict(prefixes)
                    if isinstance(computed, dict):
                        self._computed_prefixes = dict(computed)

        if isinstance(parsed, dict) and "facts" in parsed:
            facts = list(parsed.get("facts", []))
            rules = set(parsed.get("rules", []))
            queries = list(parsed.get("queries", []))
            constraints = set(parsed.get("constraints", []))
            imports = list(parsed.get("imports", []))
            header = parsed.get("header", {}) or {}
            view_directives = list(header.get("views", []))
        else:
            facts = list(self._parser_provider.parse_atoms(text))
            rules = set(self._parser_provider.parse_rules(text))
            queries = list(self._parser_provider.parse_queries(text))
            constraints = set(self._parser_provider.parse_negative_constraints(text))
            imports = []
            view_directives = []

        imported_sources: list["ReadableData"] = []
        if imports:
            imported_sources = self._merge_imports(
                facts,
                rules,
                queries,
                constraints,
                imports,
                source_path,
            )

        declared_view_sources = self._build_declared_view_sources(
            view_directives, source_path
        )

        # Track all terms and predicates
        for atom in facts:
            self._track_atom(atom)
        for rule in rules:
            self._track_rule(rule)
        queries = _unique_preserve_order(queries)
        for query in queries:
            self._track_query(query)
        for constraint in constraints:
            self._track_query(constraint.body)

        atoms_for_sources = self._collect_atoms_for_sources(
            facts, rules, queries, constraints
        )
        self._register_computed_functions(atoms_for_sources)

        sources = self._build_parse_sources(facts, rules, queries, constraints)
        sources.extend(imported_sources)
        sources.extend(declared_view_sources)
        for source in sources:
            self._register_source_schemas(source)
        return ParseResult(
            facts=FrozenAtomSet(facts),
            rules=frozenset(rules),
            queries=tuple(queries),
            constraints=frozenset(constraints),
            sources=tuple(sources),
            base_iri=self._iri_base,
            prefixes=tuple(self._iri_prefixes.items()),
            computed_prefixes=tuple(self._computed_prefixes.items()),
        )

    def _merge_imports(
        self,
        facts: list[Atom],
        rules: set[Rule],
        queries: list["Query"],
        constraints: set[NegativeConstraint],
        imports: list[str],
        source_path: Optional[Path],
    ) -> list["ReadableData"]:
        from prototyping_inference_engine.io.registry import (
            ImportContext,
            ImportResolver,
            ParserRegistry,
        )

        context = ImportContext(
            term_factories=self._term_factories,
            io_config=self._io_config,
            python_function_names=(
                self._python_function_source.function_names()
                if self._python_function_source
                else set()
            ),
        )
        resolver = ImportResolver(ParserRegistry.default(), context)
        base_dir = source_path.parent if source_path is not None else None
        resolution = resolver.resolve_all(imports, base_dir)
        imported_sources: list["ReadableData"] = []

        seen_queries: set["Query"] = set(queries)
        for result in resolution.results:
            facts.extend(result.facts)
            rules.update(result.rules)
            for query in result.queries:
                if query in seen_queries:
                    continue
                seen_queries.add(query)
                queries.append(query)
            constraints.update(result.constraints)
            self._merge_computed_prefixes(result.computed_prefixes)
            imported_sources.extend(result.sources)

        return imported_sources

    def _merge_computed_prefixes(self, imported: tuple[tuple[str, str], ...]) -> None:
        for prefix, value in imported:
            if prefix in self._computed_prefixes:
                if self._computed_prefixes[prefix] != value:
                    raise ValueError(
                        f"Computed prefix conflict for '{prefix}': "
                        f"{self._computed_prefixes[prefix]} vs {value}"
                    )
                continue
            self._computed_prefixes[prefix] = value

    def _build_parse_sources(
        self,
        facts: list[Atom],
        rules: set[Rule],
        queries: list["Query"],
        constraints: set[NegativeConstraint],
    ) -> list["ReadableData"]:
        from prototyping_inference_engine.api.atom.predicate import (
            is_comparison_predicate,
        )
        from prototyping_inference_engine.api.data.comparison_data import (
            ComparisonDataSource,
        )
        from prototyping_inference_engine.api.data.functions.integraal_standard_functions import (
            IntegraalStandardFunctionSource,
        )
        from prototyping_inference_engine.api.data.readable_data import ReadableData

        atoms = self._collect_atoms_for_sources(facts, rules, queries, constraints)

        sources: list[ReadableData] = []
        if any(is_comparison_predicate(atom.predicate) for atom in atoms):
            sources.append(ComparisonDataSource(self._literal_config.comparison))
        if self._python_function_source is not None and _contains_function_term(atoms):
            sources.append(self._python_function_source)
        std_prefixes = {
            prefix
            for prefix, value in self._computed_prefixes.items()
            if value == "stdfct"
        }
        resolved_prefixes = {prefix: "stdfct:" for prefix in std_prefixes}
        if not resolved_prefixes:
            resolved_prefixes = {"stdfct": "stdfct:"}
        computed_predicates = _extract_computed_predicates(atoms, resolved_prefixes)
        if computed_predicates:
            literal_factory = self._term_factories.get(Literal)
            sources.append(
                IntegraalStandardFunctionSource(
                    literal_factory, resolved_prefixes, computed_predicates
                )
            )
        return sources

    def _collect_atoms_for_sources(
        self,
        facts: list[Atom],
        rules: set[Rule],
        queries: list["Query"],
        constraints: set[NegativeConstraint],
    ) -> list[Atom]:
        atoms: list[Atom] = list(facts)

        for rule in rules:
            atoms.extend(rule.body.atoms)
            atoms.extend(rule.head.atoms)

        for query in queries:
            atoms.extend(self._extract_query_atoms(query))

        for constraint in constraints:
            atoms.extend(self._extract_query_atoms(constraint.body))

        return atoms

    def _register_computed_functions(self, atoms: list[Atom]) -> None:
        computed_files = {
            prefix: value
            for prefix, value in self._computed_prefixes.items()
            if value != "stdfct"
        }
        if not computed_files:
            return
        if self._python_function_source is None:
            raise RuntimeError("Python function source is not available")

        from prototyping_inference_engine.io.parsers.dlgpe.computed_function_loader import (
            load_computed_config,
            register_python_functions,
        )

        registered_names: set[str] = set()
        for prefix, raw_path in computed_files.items():
            config_path = _coerce_computed_path(raw_path)
            config = load_computed_config(config_path)
            registered_names.update(
                register_python_functions(prefix, config, self._python_function_source)
            )

        _validate_function_terms(atoms, registered_names, computed_files)

    @staticmethod
    def _extract_query_atoms(query: object) -> list[Atom]:
        if hasattr(query, "formula"):
            return list(query.formula.atoms)
        if hasattr(query, "atoms"):
            return list(query.atoms)
        if hasattr(query, "queries"):
            atoms: list[Atom] = []
            for sub in query.queries:
                atoms.extend(ReasoningSession._extract_query_atoms(sub))
            return atoms
        return []

    # =========================================================================
    # Reasoning methods
    # =========================================================================

    def rewrite(
        self,
        query: Union[
            ConjunctiveQuery,
            UnionQuery[ConjunctiveQuery],
            "FOQuery",
        ],
        rules: set[Rule],
        step_limit: float = inf,
        verbose: bool = False,
    ) -> UnionQuery[ConjunctiveQuery]:
        """
        Perform UCQ rewriting.

        Args:
            query: The query to rewrite (CQ, UCQ, or FOQuery convertible to UCQ)
            rules: The rules to use for rewriting
            step_limit: Maximum number of rewriting steps (default: unlimited)
            verbose: Whether to print progress

        Returns:
            The rewritten union of conjunctive queries
        """
        self._check_not_closed()

        # Convert FOQuery to UCQ if needed
        if not isinstance(query, (ConjunctiveQuery, UnionQuery)):
            from prototyping_inference_engine.io.parsers.dlgpe.conversions import (
                try_convert_fo_query,
            )
            from prototyping_inference_engine.api.query.union_conjunctive_queries import (
                UnionConjunctiveQueries,
            )

            converted = try_convert_fo_query(query)
            if isinstance(converted, ConjunctiveQuery):
                query = UnionQuery(
                    frozenset([converted]),
                    converted.answer_variables,
                    converted.label,
                )
            elif isinstance(converted, UnionConjunctiveQueries):
                query = converted
            else:
                raise ValueError("FOQuery is not UCQ-compatible for rewriting.")

        # Convert CQ to UCQ if needed
        if isinstance(query, ConjunctiveQuery):
            query = UnionQuery(
                frozenset([query]),
                query.answer_variables,
                query.label,
            )

        algorithm = self._rewriting_provider.get_algorithm()
        return algorithm.rewrite(query, rules, step_limit, verbose)

    def evaluate_query(
        self,
        query: "FOQuery",
        fact_base: "FactBase",
    ) -> Iterator[Tuple[Term, ...]]:
        """
        Evaluate a first-order query against a fact base.

        Args:
            query: The FOQuery to evaluate
            fact_base: The fact base to query against

        Yields:
            Tuples of terms corresponding to the answer variables

        Example:
            query = (session.fo_query().builder()
                .answer("X")
                .atom("p", "a", "X")
                .build())
            for answer in session.evaluate_query(query, fact_base):
                print(answer)  # (b,), (c,), ...
        """
        from prototyping_inference_engine.query_evaluation.evaluator.fo_query.fo_query_evaluators import (
            GenericFOQueryEvaluator,
        )

        self._check_not_closed()
        evaluator = GenericFOQueryEvaluator()
        return evaluator.evaluate_and_project(query, fact_base)

    def evaluate_query_with_sources(
        self,
        query: "FOQuery",
        fact_base: "FactBase",
        sources: Iterable["ReadableData"],
    ) -> Iterator[Tuple[Term, ...]]:
        """
        Evaluate a first-order query against a fact base plus extra sources.

        Args:
            query: The FOQuery to evaluate
            fact_base: The fact base to query against
            sources: Extra ReadableData sources to combine with the fact base

        Yields:
            Tuples of terms corresponding to the answer variables
        """
        from prototyping_inference_engine.api.data.collection.builder import (
            ReadableCollectionBuilder,
        )
        from prototyping_inference_engine.query_evaluation.evaluator.fo_query.fo_query_evaluators import (
            GenericFOQueryEvaluator,
        )

        self._check_not_closed()
        self._register_source_schemas(fact_base)
        builder = ReadableCollectionBuilder().add_all_predicates_from(fact_base)
        for source in sources:
            self._register_source_schemas(source)
            builder.add_all_predicates_from(source)
        data = builder.build()
        evaluator = GenericFOQueryEvaluator()
        return evaluator.evaluate_and_project(query, data)

    # =========================================================================
    # Lifecycle methods
    # =========================================================================

    def cleanup(self) -> SessionCleanupStats:
        """
        Trigger cleanup of tracked terms.

        For WeakRefStorage, this forces garbage collection.
        For DictStorage, this clears all tracked items.

        Returns:
            Statistics about items removed
        """
        self._check_not_closed()
        import gc

        vars_before = 0
        consts_before = 0
        preds_before = 0

        # Get counts before cleanup
        if Variable in self._term_factories:
            vars_before = len(self._term_factories.get(Variable))
        if Constant in self._term_factories:
            consts_before = len(self._term_factories.get(Constant))
        if Predicate in self._term_factories:
            preds_before = len(self._term_factories.get(Predicate))

        # Force garbage collection
        gc.collect()

        # Get counts after cleanup
        vars_after = 0
        consts_after = 0
        preds_after = 0

        if Variable in self._term_factories:
            vars_after = len(self._term_factories.get(Variable))
        if Constant in self._term_factories:
            consts_after = len(self._term_factories.get(Constant))
        if Predicate in self._term_factories:
            preds_after = len(self._term_factories.get(Predicate))

        return SessionCleanupStats(
            variables_removed=vars_before - vars_after,
            constants_removed=consts_before - consts_after,
            predicates_removed=preds_before - preds_after,
        )

    def close(self) -> None:
        """
        Close the session and release resources.

        After closing, no operations can be performed on this session.
        """
        if self._closed:
            return

        # Clear storage in all factories
        for term_type in self._term_factories:
            factory = self._term_factories.get(term_type)
            if hasattr(factory, "_storage"):
                factory._storage.clear()

        self._fact_bases.clear()
        self._rule_bases.clear()
        self._ontologies.clear()
        self._knowledge_bases.clear()
        self._closed = True

    # =========================================================================
    # Context manager
    # =========================================================================

    def __enter__(self) -> "ReasoningSession":
        """Enter the context manager."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Exit the context manager and close the session."""
        self.close()

    # =========================================================================
    # Private helpers
    # =========================================================================

    def _check_not_closed(self) -> None:
        """Raise an error if the session is closed."""
        if self._closed:
            raise RuntimeError("Cannot perform operations on a closed session")

    def _build_declared_view_sources(
        self,
        view_directives: list[object],
        source_path: Optional[Path],
    ) -> list["ReadableData"]:
        from prototyping_inference_engine.api.data.views.builder import (
            load_view_sources,
        )

        if not view_directives:
            return []

        base_dir = source_path.parent if source_path is not None else Path.cwd()
        literal_factory = self._term_factories.get(Literal)
        loaded_sources: list["ReadableData"] = []

        for directive in view_directives:
            if not isinstance(directive, (list, tuple)) or len(directive) != 2:
                raise ValueError(f"Invalid @view directive payload: {directive!r}")
            alias = str(directive[0]).strip()
            location = str(directive[1]).strip()
            if not alias:
                raise ValueError(f"Invalid @view alias: {directive!r}")
            if not location:
                raise ValueError(f"Invalid @view location: {directive!r}")

            resolved_path = self._resolve_path_like_import(location, base_dir)
            for source in load_view_sources(
                resolved_path, alias_prefix=alias, literal_factory=literal_factory
            ):
                loaded_sources.append(source)

        return loaded_sources

    @staticmethod
    def _resolve_path_like_import(raw: str, base_dir: Path) -> Path:
        stripped = raw.strip()
        if stripped.startswith("file://"):
            parsed = urlparse(stripped)
            return Path(parsed.path).resolve()
        parsed = urlparse(stripped)
        if parsed.scheme and parsed.scheme != "file":
            raise ValueError(f"Unsupported @view scheme: {parsed.scheme}")
        path = Path(stripped)
        if not path.is_absolute():
            path = base_dir / path
        return path.resolve()

    def _register_source_schemas(self, source: object) -> None:
        """Register schemas from a source when it supports schema-awareness."""
        if isinstance(source, SchemaAware):
            self._schema_registry.register_many(source.get_schemas())

    def _track_atom(self, atom: Atom) -> None:
        """Track all terms and predicate in an atom."""
        # Track predicate
        from prototyping_inference_engine.api.atom.identity_predicate import (
            IdentityPredicate,
        )

        if Predicate in self._term_factories:
            self._term_factories.get(Predicate).create(
                atom.predicate.name, atom.predicate.arity
            )
        elif IdentityPredicate in self._term_factories:
            self._term_factories.get(IdentityPredicate).create(
                atom.predicate.name, atom.predicate.arity
            )

        # Track terms
        for term in atom.terms:
            from prototyping_inference_engine.api.atom.term.identity_constant import (
                IdentityConstant,
            )
            from prototyping_inference_engine.api.atom.term.identity_literal import (
                IdentityLiteral,
            )
            from prototyping_inference_engine.api.atom.term.identity_variable import (
                IdentityVariable,
            )

            if isinstance(term, Variable) and Variable in self._term_factories:
                self._term_factories.get(Variable).create(str(term.identifier))
            elif (
                isinstance(term, IdentityVariable)
                and IdentityVariable in self._term_factories
            ):
                self._term_factories.get(IdentityVariable).create(str(term.identifier))
            elif isinstance(term, Constant) and Constant in self._term_factories:
                self._term_factories.get(Constant).create(term.identifier)
            elif (
                isinstance(term, IdentityConstant)
                and IdentityConstant in self._term_factories
            ):
                self._term_factories.get(IdentityConstant).create(term.identifier)
            elif isinstance(term, Literal) and Literal in self._term_factories:
                self._term_factories.get(Literal).create(
                    term.lexical or str(term.value), term.datatype, term.lang
                )
            elif (
                isinstance(term, IdentityLiteral)
                and IdentityLiteral in self._term_factories
            ):
                self._term_factories.get(IdentityLiteral).create(
                    term.lexical or str(term.value), term.datatype, term.lang
                )

    def _track_rule(self, rule: Rule) -> None:
        """Track all terms in a rule."""
        for atom in rule.body.atoms:
            self._track_atom(atom)
        for atom in rule.head.atoms:
            self._track_atom(atom)

    def _track_query(self, query) -> None:
        """Track all terms in a query."""
        if isinstance(query, UnionQuery):
            for cq in query.conjunctive_queries:
                self._track_query(cq)
            return

        atoms = getattr(query, "atoms", None)
        if atoms is None:
            return

        for atom in atoms:
            self._track_atom(atom)


def _contains_function_term(atoms: Iterable[Atom]) -> bool:
    for atom in atoms:
        for term in atom.terms:
            if _term_contains_function(term):
                return True
    return False


def _term_contains_function(term: Term) -> bool:
    from prototyping_inference_engine.api.atom.term.evaluable_function_term import (
        EvaluableFunctionTerm,
    )

    if isinstance(term, EvaluableFunctionTerm):
        return True
    args = getattr(term, "args", None)
    if args:
        for arg in args:
            if _term_contains_function(arg):
                return True
    return False


def _extract_computed_predicates(
    atoms: Iterable[Atom], computed_prefixes: dict[str, str]
) -> set[Predicate]:
    base_iris = list(computed_prefixes.values())
    if not base_iris:
        return set()
    predicates: set[Predicate] = set()
    for atom in atoms:
        name = atom.predicate.name
        if any(name.startswith(base) for base in base_iris):
            predicates.add(atom.predicate)
        for term in atom.terms:
            _collect_computed_predicates_from_term(term, base_iris, predicates)
    return predicates


def _collect_computed_predicates_from_term(
    term: Term, base_iris: list[str], predicates: set[Predicate]
) -> None:
    from prototyping_inference_engine.api.atom.term.evaluable_function_term import (
        EvaluableFunctionTerm,
    )

    if isinstance(term, EvaluableFunctionTerm):
        if any(term.name.startswith(base) for base in base_iris):
            predicates.add(Predicate(term.name, len(term.args) + 1))
        for arg in term.args:
            _collect_computed_predicates_from_term(arg, base_iris, predicates)
    else:
        args = getattr(term, "args", None)
        if args:
            for arg in args:
                _collect_computed_predicates_from_term(arg, base_iris, predicates)


def _collect_function_term_names(term: Term, names: set[str]) -> None:
    from prototyping_inference_engine.api.atom.term.evaluable_function_term import (
        EvaluableFunctionTerm,
    )

    if isinstance(term, EvaluableFunctionTerm):
        names.add(term.name)
        for arg in term.args:
            _collect_function_term_names(arg, names)
        return
    args = getattr(term, "args", None)
    if args:
        for arg in args:
            _collect_function_term_names(arg, names)


def _validate_function_terms(
    atoms: Iterable[Atom],
    registered_names: set[str],
    computed_files: dict[str, str],
) -> None:
    computed_prefixes = tuple(computed_files.keys())
    for atom in atoms:
        predicate_name = atom.predicate.name
        if predicate_name.startswith("stdfct:"):
            continue
        for prefix in computed_prefixes:
            if predicate_name.startswith(f"{prefix}:"):
                raise ValueError(
                    "Computed functions loaded from configuration files must be used "
                    "as functional terms, not predicates."
                )

    used_names: set[str] = set()
    for atom in atoms:
        for term in atom.terms:
            _collect_function_term_names(term, used_names)

    for name in sorted(used_names):
        if name.startswith("stdfct:"):
            continue
        if name not in registered_names:
            raise ValueError(f"Unknown computed function: {name}")


def _coerce_computed_path(value: str) -> Path:
    from urllib.parse import urlparse

    if value.startswith("file://"):
        return Path(urlparse(value).path).expanduser().resolve()
    return Path(value).expanduser().resolve()
