def increment(value: int) -> int:
    return value + 1
