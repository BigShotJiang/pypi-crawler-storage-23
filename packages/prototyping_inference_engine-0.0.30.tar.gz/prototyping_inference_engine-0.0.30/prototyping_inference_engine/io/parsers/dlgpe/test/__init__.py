"""Tests for DLGPE parser."""
