"""
RDF parsers.
"""

from prototyping_inference_engine.io.parsers.rdf.rdf_parser import RDFParser

__all__ = ["RDFParser"]
