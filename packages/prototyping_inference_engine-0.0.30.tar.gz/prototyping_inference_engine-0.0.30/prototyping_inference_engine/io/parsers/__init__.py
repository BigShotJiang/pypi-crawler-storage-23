"""Parser entry points."""

from prototyping_inference_engine.io.parsers.dlgpe_parser import DlgpeParser

__all__ = ["DlgpeParser"]
