"""DLGPE parser entry point for IO package."""

from prototyping_inference_engine.io.parsers.dlgpe.dlgpe_parser import DlgpeParser

__all__ = ["DlgpeParser"]
