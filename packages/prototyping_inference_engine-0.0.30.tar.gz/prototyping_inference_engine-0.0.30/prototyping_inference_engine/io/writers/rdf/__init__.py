"""
RDF writers.
"""

from prototyping_inference_engine.io.writers.rdf.rdf_writer import RDFWriter

__all__ = ["RDFWriter"]
