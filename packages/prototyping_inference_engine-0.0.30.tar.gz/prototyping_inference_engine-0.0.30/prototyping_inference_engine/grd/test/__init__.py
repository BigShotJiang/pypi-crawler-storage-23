"""Tests for GRD utilities and stratification."""
