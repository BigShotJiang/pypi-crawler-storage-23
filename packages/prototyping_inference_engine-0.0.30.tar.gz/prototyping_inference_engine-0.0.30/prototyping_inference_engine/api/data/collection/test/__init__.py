"""Tests for data collection module."""
