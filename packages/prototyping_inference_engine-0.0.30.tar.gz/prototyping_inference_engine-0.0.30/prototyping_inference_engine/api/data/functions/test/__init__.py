"""Tests for function-backed data sources."""
