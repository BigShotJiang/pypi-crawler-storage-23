"""Tests for data access abstractions."""
