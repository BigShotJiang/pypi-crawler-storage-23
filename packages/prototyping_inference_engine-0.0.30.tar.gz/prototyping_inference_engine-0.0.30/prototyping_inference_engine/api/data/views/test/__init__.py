"""Tests for view declaration and runtime modules."""
