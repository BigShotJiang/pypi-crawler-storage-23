"""Tests for the formula module."""
