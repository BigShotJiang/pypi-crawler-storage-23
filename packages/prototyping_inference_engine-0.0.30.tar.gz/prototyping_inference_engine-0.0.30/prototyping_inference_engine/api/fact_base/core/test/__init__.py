"""Tests for fact-base core adapters."""
