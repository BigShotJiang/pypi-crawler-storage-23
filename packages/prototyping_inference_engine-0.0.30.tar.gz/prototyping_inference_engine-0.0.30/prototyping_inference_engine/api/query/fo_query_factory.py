"""
Backward-compatible import path for FOQueryFactory.
"""

from prototyping_inference_engine.api.query.factory.fo_query_factory import (
    FOQueryBuilder,
    FOQueryFactory,
)

__all__ = ["FOQueryFactory", "FOQueryBuilder"]
