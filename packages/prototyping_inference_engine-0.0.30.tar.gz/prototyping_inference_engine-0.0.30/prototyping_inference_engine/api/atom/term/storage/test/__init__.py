"""Tests for term storage strategies."""
