// Copyright Contributors to the OpenImageIO project.
// SPDX-License-Identifier: Apache-2.0
// https://github.com/AcademySoftwareFoundation/OpenImageIO


// DEPRECATED header OpenImageIO/version.h
// For back compatibility, just include the new name, oiioversion.h.

#include "oiioversion.h"
