from b3denv import main

if __name__ == "__main__":
    main()