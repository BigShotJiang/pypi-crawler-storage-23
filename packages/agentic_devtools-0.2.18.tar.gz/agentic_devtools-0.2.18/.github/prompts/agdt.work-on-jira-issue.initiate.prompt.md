---
agent: agdt.work-on-jira-issue.initiate
---
