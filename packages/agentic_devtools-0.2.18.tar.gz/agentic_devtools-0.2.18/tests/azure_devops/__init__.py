"""
Test package for Azure DevOps CLI commands.
"""
