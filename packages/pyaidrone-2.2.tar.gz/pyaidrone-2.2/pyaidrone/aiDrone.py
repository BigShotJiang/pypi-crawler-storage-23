import serial
import binascii
import math
from time import sleep
import random
import platform
import subprocess
from operator import eq
from threading import Thread
from serial.tools.list_ports import comports
from pyaidrone.parse import *
from pyaidrone.packet import *
from pyaidrone.deflib import *


class AIDrone(Parse, Packet):
    def __init__(self, receiveCallback=None, index=0):
        self.serial = None
        self.isThreadRun = False
        self.parse = Parse(AIDRONE)
        self.makepkt = Packet(AIDRONE)
        self.receiveCallback = receiveCallback
        self.makepkt.clearPacket()
        self.posX = 0
        self.posY = 0
        self.rot = 0
        self.portIndex = index          # 멀티 연결 시 드론 번호 식별용
        # --- 영상 스트리밍 관련 기본값 ---
        self.stream_host = "192.168.4.1"
        self.stream_port = 80
        self.stream_path = "/?action=stream"
        self._cap = None

    def receiveHandler(self):
        while self.isThreadRun:
            readData = self.serial.read(self.serial.in_waiting or 1)
            packet = self.parse.packetArrange(readData)
            if not eq(packet, "None"):
                if self.receiveCallback is not None:
                    self.receiveCallback(packet)
            self.serial.write(self.makepkt.getPacket())

    def Open(self, portName="None"):
        if eq(portName, "None"):
            nodes = comports()
            for node in nodes:
                if "CH340" in node.description:
                    portName = node.device

            if eq(portName, "None"):
                print("Can't find Serial Port")
                exit()
                return False
        try:
            self.serial = serial.Serial(port=portName, baudrate=19200, timeout=1)
            if self.serial.isOpen():
                self.isThreadRun = True
                self.thread = Thread(target=self.receiveHandler, args=(), daemon=True)
                self.thread.start()
                print(f"[Drone #{self.portIndex}] Connected to {portName}")
                return True
            else:
                print("Can't open " + portName)
                exit()
                return False
        except Exception:
            print("Can't open " + portName)
            exit()
            return False

    def Close(self):
        self.isThreadRun = False
        sleep(0.2)
        pkt = self.makepkt.getPacket()
        if (pkt[15] & 0x80) == 0x80:
            self.makepkt.clearPacket()
            self.setOption(0x8000)
            self.serial.write(self.makepkt.getPacket())
            sleep(0.2)
        self.serial.write(self.makepkt.clearPacket())
        sleep(0.2)
        if self.serial is not None:
            if self.serial.isOpen():
                self.serial.close()

    def setOption(self, option):
        data = option.to_bytes(2, byteorder="little", signed=False)
        self.makepkt.makePacket(14, data)

    def takeoff(self):
        alt = 70
        data = alt.to_bytes(2, byteorder="little", signed=False)
        self.makepkt.makePacket(12, data)
        self.setOption(0x2F)

    def landing(self):
        alt = 0
        data = alt.to_bytes(2, byteorder="little", signed=False)
        self.makepkt.makePacket(12, data)

    def altitude(self, alt):
        data = alt.to_bytes(2, byteorder="little", signed=False)
        self.makepkt.makePacket(12, data)

    def velocity(self, dir=0, vel=100):
        if dir > 3:
            return
        if dir == 1 or dir == 3:
            vel *= -1
        data = vel.to_bytes(2, byteorder="little", signed=True)
        if dir == 0 or dir == 1:
            self.makepkt.makePacket(8, data)
        else:
            self.makepkt.makePacket(6, data)
        self.setOption(0x0F)

    def move(self, dir=0, dist=100):
        if dir > 3:
            return
        if dir == 1 or dir == 3:
            dist *= -1
        if dir == 0 or dir == 1:
            self.posX += dist
            data = self.posX.to_bytes(2, byteorder="little", signed=True)
            self.makepkt.makePacket(8, data)
        else:
            self.posY += dist
            data = self.posY.to_bytes(2, byteorder="little", signed=True)
            self.makepkt.makePacket(6, data)
        self.setOption(0x2F)

    def rotation(self, rot=90):
        self.rot += rot
        data = self.rot.to_bytes(2, byteorder="little", signed=True)
        self.makepkt.makePacket(10, data)

    def motor(self, what, speed):
        speed = DefLib.constrain(speed, 100, 0)
        data = speed.to_bytes(2, byteorder="little", signed=True)
        self.makepkt.makePacket(what * 2 + 6, data)
        self.setOption(0x8000)

    def emergency(self):
        self.setOption(0x00)
        self.serial.write(self.makepkt.getPacket())

    # ── 스트리밍 관련 ──────────────────────────────────────────────────────────
    def setStreamAddress(self, host: str, port: int = 80, path: str = "/?action=stream"):
        """MJPG-Streamer 주소 구성 요소를 저장합니다."""
        if not isinstance(host, str) or len(host.strip()) == 0:
            raise ValueError("host가 올바르지 않습니다.")
        self.stream_host = host.strip()
        self.stream_port = int(port)
        if not path.startswith("/"):
            path = "/" + path
        self.stream_path = path
        return self._build_stream_url()

    def _build_stream_url(self):
        """내부 사용: 저장된 host/port/path로 URL 생성."""
        if self.stream_port in (80, None):
            return f"http://{self.stream_host}{self.stream_path}"
        return f"http://{self.stream_host}:{self.stream_port}{self.stream_path}"

    def streamon(self, host: str = None, port: int = None, path: str = None, return_url: bool = False):
        """
        MJPG-Streamer 스트림을 엽니다.
        - 인자를 주면 해당 값으로 주소를 덮어쓰고, 안 주면 저장된 값 사용.
        - return_url=True 이면 URL 문자열만 반환(캡처는 열지 않음).
        """
        if host is not None or port is not None or path is not None:
            self.setStreamAddress(
                host or self.stream_host,
                self.stream_port if port is None else port,
                self.stream_path if path is None else path,
            )
        url = self._build_stream_url()
        if return_url:
            return url
        try:
            import cv2 as cv
        except Exception as e:
            raise RuntimeError(f"OpenCV(cv2) 임포트 실패: {e}")
        self.streamoff()
        self._cap = cv.VideoCapture(url)
        if not self._cap.isOpened():
            self._cap.release()
            self._cap = None
            raise RuntimeError(f"스트림 열기 실패: {url}")
        return self._cap

    def streamoff(self):
        """열려 있는 스트림을 닫습니다."""
        if self._cap is not None:
            try:
                self._cap.release()
            except Exception:
                pass
            self._cap = None

    # ── 센서 데이터 요청 ────────────────────────────────────────────────────────
    def requestSensorData(self, type_num, mode=1):
        """
        드론에게 센서 및 비행 정보 출력을 요청합니다.
        type_num: 9 (비행 정보), 10 (센서 신호)
        mode: 1 (출력 시작), 0 (출력 중지)
        """
        if type_num == 9:
            data = mode.to_bytes(1, byteorder="little")
            self.makepkt.packet[3] = 0xB2
            self.makepkt.makePacket(7, data)
        elif type_num == 10:
            data = mode.to_bytes(1, byteorder="little")
            self.makepkt.packet[3] = 0xB1
            self.makepkt.makePacket(7, data)


# ══════════════════════════════════════════════════════════════════════════════
# 멀티 드론 헬퍼 함수
# ══════════════════════════════════════════════════════════════════════════════

def getWindowsPortList():
    """Windows에서 CH340 포트 목록 반환."""
    nodes = comports()
    portList = [node.device for node in nodes if "CH340" in node.description]
    if not portList:
        print("Can't find Serial Port (CH340)")
        return None
    print(f"발견된 포트: {portList}")
    return portList


def getLinuxPortList():
    """Linux에서 /dev/ttyUSB* 포트 목록 반환."""
    try:
        output = subprocess.check_output("ls /dev/ttyUSB*", shell=True)
        return tuple(output.decode().strip().split())
    except subprocess.CalledProcessError:
        print("Can't find Serial Port (/dev/ttyUSB*)")
        return None


def AIDroneMultiOpen(nameList=None, receiveCallback=None):
    """
    여러 대의 AIDrone을 동시에 연결합니다.

    Parameters
    ----------
    nameList : list[str] | None
        포트 이름 목록. None이면 OS에 맞게 자동 탐색.
    receiveCallback : callable | None
        수신 콜백. 호출 시 첫 번째 인자로 AIDrone 인스턴스가 전달됩니다.

    Returns
    -------
    list[AIDrone] | None
        연결된 드론 객체 목록.

    Example
    -------
    >>> drones = AIDroneMultiOpen()
    >>> multi_takeoff(drones)
    >>> sleep(3)
    >>> multi_landing(drones)
    >>> AIDroneMultiClose(drones)
    """
    if nameList is None:
        if platform.system() == "Linux":
            nameList = getLinuxPortList()
        else:
            nameList = getWindowsPortList()

    if not nameList:
        return None

    howMany = min(len(nameList), 10)  # 최대 10대 제한
    drones = []

    for n in range(howMany):
        drone = AIDrone(receiveCallback, n)
        if drone.Open(nameList[n]):
            drones.append(drone)
        else:
            print(f"[Drone #{n}] 연결 실패 → 전체 연결 중단")
            AIDroneMultiClose(drones)
            return None

    print(f"총 {len(drones)}대 드론 연결 완료.")
    return drones


def AIDroneMultiClose(drones):
    """연결된 모든 드론을 안전하게 닫습니다."""
    if not drones:
        return
    # 착륙 명령 먼저 전송
    for drone in drones:
        drone.landing()
    sleep(0.5)
    for drone in drones:
        drone.Close()
    print("모든 드론 연결 종료.")


# ── 멀티 제어 함수 ─────────────────────────────────────────────────────────────

def multi_takeoff(drones):
    """모든 드론 이륙."""
    for drone in drones:
        drone.takeoff()


def multi_landing(drones):
    """모든 드론 착륙."""
    for drone in drones:
        drone.landing()


def multi_altitude(drones, alt):
    """모든 드론 고도 설정."""
    for drone in drones:
        drone.altitude(alt)


def multi_move(drones, dir=0, dist=100):
    """모든 드론 이동."""
    for drone in drones:
        drone.move(dir, dist)


def multi_velocity(drones, dir=0, vel=100):
    """모든 드론 속도 제어."""
    for drone in drones:
        drone.velocity(dir, vel)


def multi_rotation(drones, rot=90):
    """모든 드론 회전."""
    for drone in drones:
        drone.rotation(rot)


def multi_motor(drones, what, speed):
    """모든 드론 모터 제어."""
    for drone in drones:
        drone.motor(what, speed)


def multi_emergency(drones):
    """모든 드론 긴급 정지."""
    for drone in drones:
        drone.emergency()
