import cv2
import time
import numpy as np
import os
from pyaidrone.aiDrone import AIDrone
from pyaidrone.vision_ai import TFLiteDetector, yolo_decode, draw_box_xywh, largest_contour, contour_centroid
from pyaidrone.deflib import *

class EduAIDrone:
    """
    AI 교육을 위해 복잡한 기능을 단순화한 통합 API 클래스
    """
    def __init__(self, port="COM3", use_simulation=False, model_path=None, labels_path=None):
        self.use_simulation = use_simulation
        self.last_frame = None
        self.height = 100
        self.cap = None
        self.stream_url = None # 수정: self.stream.url 오타 수정
        
        # 1. 시뮬레이션 모드 전용 설정 (지연 로딩 적용)
        if self.use_simulation:
            try:
                import rclpy
                from rclpy.node import Node
                from geometry_msgs.msg import Twist
                from sensor_msgs.msg import Image
                from cv_bridge import CvBridge

                if not rclpy.ok(): rclpy.init()
                self.node = Node('edu_drone_node')
                self.cmd_vel_pub = self.node.create_publisher(Twist, '/cmd_vel', 10)
                self.bridge = CvBridge()
                self.sim_frame = None
                self.image_sub = self.node.create_subscription(Image, '/camera', self._gz_image_cb, 10)
                print("🎮 ROS2 Gazebo 모드 활성화됨")
            except ImportError:
                print("❌ ROS2 환경을 찾을 수 없습니다. 실기체 모드로 전환합니다.")
                self.use_simulation = False

        # 2. 하드웨어 드론 인터페이스 초기화
        self.aidrone = AIDrone()
        self.port = port
        
        # 3. AI 탐지기 및 라벨 설정
        self.detector = TFLiteDetector(model_path) if model_path else None
        self.labels = []
        if labels_path and os.path.exists(labels_path):
            with open(labels_path, 'r', encoding='utf-8') as f:
                self.labels = [line.strip() for line in f.readlines()]

    def _gz_image_cb(self, msg):
        """Gazebo 카메라 데이터 수신 콜백"""
        self.sim_frame = self.bridge.imgmsg_to_cv2(msg, "bgr8")

    def connect(self):
        """드론 연결 (실기체인 경우 시리얼 오픈)"""
        if self.use_simulation:
            return True
        return self.aidrone.Open(self.port)

    def update_screen(self, window_name="AI Drone Edu"):
        """영상 업데이트 (시뮬레이션 토픽 또는 실기체 MJPG 스트림)"""
        if self.use_simulation:
            import rclpy
            rclpy.spin_once(self.node, timeout_sec=0)
            if self.sim_frame is not None:
                self.last_frame = cv2.resize(self.sim_frame, (640, 480))
            return self.last_frame
        else:
            if self.cap is None: return None
            ret, frame = self.cap.read()
            if ret and frame is not None:
                self.last_frame = cv2.resize(frame, (640, 480))
                return self.last_frame
            return None

    def takeoff(self):
        print("🚀 이륙합니다...")
        if not self.use_simulation:
            self.aidrone.takeoff()
        time.sleep(2)

    def land(self):
        print("🛬 착륙합니다...")
        if self.use_simulation:
            from geometry_msgs.msg import Twist
            self.cmd_vel_pub.publish(Twist()) 
        else:
            self.aidrone.landing()

    def move(self, direction, speed=100):
        if self.use_simulation:
            from geometry_msgs.msg import Twist
            msg = Twist()
            val = speed / 100.0
            if direction == 'front': msg.linear.x = val
            elif direction == 'back': msg.linear.x = -val
            elif direction == 'left': msg.linear.y = val
            elif direction == 'right': msg.linear.y = -val
            self.cmd_vel_pub.publish(msg)
        else:
            dir_map = {'front': FRONT, 'back': BACK, 'right': RIGHT, 'left': LEFT}
            if direction in dir_map:
                self.aidrone.velocity(dir_map[direction], speed)
                self.aidrone.setOption(0x0F)

    def turn(self, angle):
        if self.use_simulation:
            from geometry_msgs.msg import Twist
            msg = Twist()
            msg.angular.z = float(angle) * (np.pi / 180.0)
            self.cmd_vel_pub.publish(msg)
        else:
            self.aidrone.rotation(angle)

    def stop(self):
        if self.use_simulation:
            from geometry_msgs.msg import Twist
            self.cmd_vel_pub.publish(Twist())
        else:
            self.aidrone.velocity(FRONT, 0)
            self.aidrone.setOption(0x0F)

    def find_color(self, color="red"):
        if self.last_frame is None: return None
        hsv = cv2.cvtColor(self.last_frame, cv2.COLOR_BGR2HSV)
        ranges = {
            "red": [(0, 150, 50), (10, 255, 255)],
            "blue": [(100, 150, 50), (140, 255, 255)],
            "green": [(40, 100, 50), (80, 255, 255)]
        }
        low, high = ranges.get(color, ranges["red"])
        mask = cv2.inRange(hsv, np.array(low), np.array(high))
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        big_c = largest_contour(contours)
        if big_c is not None:
            return contour_centroid(big_c)
        return None

    def find_object(self, target_name, threshold=0.5):
        if not self.detector or self.last_frame is None: return None
        results = self.detector.infer(self.last_frame, yolo_decode)
        for res in results:
            name = self.labels[res.class_id] if self.labels else f"ID:{res.class_id}"
            if name == target_name and res.score > threshold:
                return ((res.box[0] + res.box[2]) / 2, (res.box[1] + res.box[3]) / 2)
        return None

    def read_qr(self):
        if self.last_frame is None: return None
        data, _, _ = cv2.QRCodeDetector().detectAndDecode(self.last_frame)
        return data if data else None
    
    def follow_target(self, error_x, error_y):  
        """오차값을 보고 드론을 자동으로 회전 및 고도 조절"""
        yaw_step = int(error_x * 0.15)
        
        if self.use_simulation:
            self.turn(yaw_step)
        else:
            self.aidrone.rotation(yaw_step)

        throttle_change = int(error_y * 0.2)
        self.height = max(50, min(150, self.height + throttle_change))
        
        if self.use_simulation:
            from geometry_msgs.msg import Twist
            msg = Twist()
            # 고도 조절 시 기존 회전 성분 유지 필요 시 여기에 추가 로직 필요
            msg.linear.z = float(throttle_change / 100.0) 
            self.cmd_vel_pub.publish(msg)
        else:
            self.aidrone.altitude(self.height)
            
    def start_stream(self, url):
        self.stream_url = url
        self.cap = cv2.VideoCapture(url)
        return self.cap.isOpened()

    def reconnect_stream(self):
        """스트림 재연결 (중복 제거 및 통합)"""
        if self.stream_url is None: return False
        if self.cap: self.cap.release()
        self.cap = None
        time.sleep(1)
        return self.start_stream(self.stream_url)
                
    def save_image(self, frame, folder="captured_images"):
        if not os.path.exists(folder): os.makedirs(folder)
        timestamp = time.strftime("%H%M%S")
        filename = f"{folder}/target_{timestamp}.jpg"
        cv2.imwrite(filename, frame)