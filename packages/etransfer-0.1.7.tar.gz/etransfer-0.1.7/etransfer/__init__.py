"""EasyTransfer - TUS-based file transfer tool."""

__version__ = "0.1.7"
__author__ = "ETransfer Team"
