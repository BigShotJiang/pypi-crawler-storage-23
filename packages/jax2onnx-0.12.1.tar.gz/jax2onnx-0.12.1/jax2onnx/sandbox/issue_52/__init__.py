# jax2onnx/sandbox/issue_52/__init__.py
