# jax2onnx/plugins/examples/jnp/__init__.py

"""JAX jnp example registrations for the converter pipeline."""
