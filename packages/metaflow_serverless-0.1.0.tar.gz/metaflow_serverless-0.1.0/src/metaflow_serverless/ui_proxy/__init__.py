"""
UI proxy package.
"""
