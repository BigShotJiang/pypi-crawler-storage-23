__version__ = 'v26.02.1'
__version_str__ = 'v26.02.1'
__branch__ = 'master'
__unclean__ = False
