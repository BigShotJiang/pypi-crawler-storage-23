DragonLog - Help
================

Online available documentation
------------------------------

* [Manual](https://codeberg.org/dragoncode/DragonLog/src/branch/master/doc/EN_00_MANUAL.md) (english)
* [Handbuch](https://codeberg.org/dragoncode/DragonLog/src/branch/master/doc/DE_00_HANDBUCH.md) (german)
