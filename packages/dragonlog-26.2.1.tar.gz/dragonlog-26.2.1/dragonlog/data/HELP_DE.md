DragonLog - Hilfe
=================

Online verfügbare documentation
-------------------------------

* [Handbuch](https://codeberg.org/dragoncode/DragonLog/src/branch/master/doc/DE_00_HANDBUCH.md) (deutsch)
* [Manual](https://codeberg.org/dragoncode/DragonLog/src/branch/master/doc/EN_00_MANUAL.md) (englisch)
