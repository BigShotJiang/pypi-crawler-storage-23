"""Smoke tests related to loading entry points."""

from dataclasses import dataclass
from importlib.metadata import entry_points as _discover_entry_points

import pytest

from awx_plugins.inventory.plugins import PluginFileInjector


@dataclass(frozen=True)
class EntryPointParam:
    """Data structure representing a single exposed plugin."""

    group: str
    name: str
    spec: str

    def __str__(self) -> str:
        """Render an entry-point parameter as a string.

        To be used as a part of parametrized test ID.
        """  # noqa: DAR201; FIXME
        return f'{self.name}={self.spec}@{self.group}'


credential_plugins = (
    EntryPointParam(
        'awx_plugins.credentials',
        'aim',
        'awx_plugins.credentials.aim:aim_plugin',
    ),
    EntryPointParam(
        'awx_plugins.credentials',
        'conjur',
        'awx_plugins.credentials.conjur:conjur_plugin',
    ),
    EntryPointParam(
        'awx_plugins.credentials',
        'hashivault_kv',
        'awx_plugins.credentials.hashivault:hashivault_kv_plugin',
    ),
    EntryPointParam(
        'awx_plugins.credentials',
        'hashivault_ssh',
        'awx_plugins.credentials.hashivault:hashivault_ssh_plugin',
    ),
    EntryPointParam(
        'awx_plugins.credentials',
        'hashivault-kv-oidc',
        'awx_plugins.credentials.hashivault:hashivault_kv_oidc_plugin',
    ),
    EntryPointParam(
        'awx_plugins.credentials',
        'hashivault-ssh-oidc',
        'awx_plugins.credentials.hashivault:hashivault_ssh_oidc_plugin',
    ),
    EntryPointParam(
        'awx_plugins.credentials',
        'azure_kv',
        'awx_plugins.credentials.azure_kv:azure_keyvault_plugin',
    ),
    EntryPointParam(
        'awx_plugins.credentials',
        'centrify_vault_kv',
        'awx_plugins.credentials.centrify_vault:centrify_plugin',
    ),
    EntryPointParam(
        'awx_plugins.credentials',
        'thycotic_dsv',
        'awx_plugins.credentials.dsv:dsv_plugin',
    ),
    EntryPointParam(
        'awx_plugins.credentials',
        'thycotic_tss',
        'awx_plugins.credentials.tss:tss_plugin',
    ),
    EntryPointParam(
        'awx_plugins.credentials',
        'aws_secretsmanager_credential',
        'awx_plugins.credentials.aws_secretsmanager:aws_secretmanager_plugin',
    ),
)


managed_credential_plugins = (
    EntryPointParam(
        'awx_plugins.managed_credentials.supported',
        'hcp_terraform',
        'awx_plugins.credentials._managed_types.terraform:hcp_terraform',
    ),
)


inventory_plugins = (
    EntryPointParam(
        'awx_plugins.inventory',
        'azure_rm',
        'awx_plugins.inventory.plugins:azure_rm',
    ),
    EntryPointParam(
        'awx_plugins.inventory',
        'ec2',
        'awx_plugins.inventory.plugins:ec2',
    ),
    EntryPointParam(
        'awx_plugins.inventory',
        'gce',
        'awx_plugins.inventory.plugins:gce',
    ),
    EntryPointParam(
        'awx_plugins.inventory',
        'vmware',
        'awx_plugins.inventory.plugins:vmware',
    ),
    EntryPointParam(
        'awx_plugins.inventory',
        'openstack',
        'awx_plugins.inventory.plugins:openstack',
    ),
    EntryPointParam(
        'awx_plugins.inventory',
        'rhv',
        'awx_plugins.inventory.plugins:rhv',
    ),
    EntryPointParam(
        'awx_plugins.inventory',
        'satellite6',
        'awx_plugins.inventory.plugins:satellite6',
    ),
    EntryPointParam(
        'awx_plugins.inventory',
        'terraform',
        'awx_plugins.inventory.plugins:terraform',
    ),
    EntryPointParam(
        'awx_plugins.inventory',
        'controller',
        'awx_plugins.inventory.plugins:controller',
    ),
    EntryPointParam(
        'awx_plugins.inventory',
        'insights',
        'awx_plugins.inventory.plugins:insights',
    ),
    EntryPointParam(
        'awx_plugins.inventory',
        'openshift_virtualization',
        'awx_plugins.inventory.plugins:openshift_virtualization',
    ),
    EntryPointParam(
        'awx_plugins.inventory',
        'constructed',
        'awx_plugins.inventory.plugins:constructed',
    ),
    EntryPointParam(
        'awx_plugins.inventory.supported',
        'rhv',
        'awx_plugins.inventory.plugins:rhv_supported',
    ),
    EntryPointParam(
        'awx_plugins.inventory.supported',
        'satellite6',
        'awx_plugins.inventory.plugins:satellite6_supported',
    ),
    EntryPointParam(
        'awx_plugins.inventory.supported',
        'controller',
        'awx_plugins.inventory.plugins:controller_supported',
    ),
    EntryPointParam(
        'awx_plugins.inventory.supported',
        'insights',
        'awx_plugins.inventory.plugins:insights_supported',
    ),
    EntryPointParam(
        'awx_plugins.inventory.supported',
        'openshift_virtualization',
        'awx_plugins.inventory.plugins:openshift_virtualization_supported',
    ),
    EntryPointParam(
        'awx_plugins.inventory.supported',
        'vmware_esxi',
        'awx_plugins.inventory.plugins:vmware_esxi_supported',
    ),
)


with_credential_plugins = pytest.mark.parametrize(
    'entry_point',
    credential_plugins,
    ids=str,
)


with_managed_credential_plugins = pytest.mark.parametrize(
    'entry_point',
    managed_credential_plugins,
    ids=str,
)


with_inventory_plugins = pytest.mark.parametrize(
    'entry_point',
    inventory_plugins,
    ids=str,
)


with_all_plugins = pytest.mark.parametrize(
    'entry_point',
    credential_plugins + managed_credential_plugins + inventory_plugins,
    ids=str,
)


@with_all_plugins
def test_entry_points_exposed(entry_point: EntryPointParam) -> None:
    """Verify the plugin entry points are discoverable.

    This check relies on the plugin-declaring distribution package to be
    pre-installed.
    """  # noqa: DAR101; FIXME
    entry_points = _discover_entry_points(group=entry_point.group)

    assert entry_point.name in entry_points.names
    assert entry_points[entry_point.name].value == entry_point.spec


@with_credential_plugins
def test_entry_points_are_credential_plugin(
    entry_point: EntryPointParam,
) -> None:
    """Ensure all exposed credential plugins are of the same class."""  # noqa: D200, DAR101; FIXME
    entry_points = _discover_entry_points(group=entry_point.group)
    loaded_plugin_class = entry_points[entry_point.name].load()

    loaded_plugin_class_name = type(loaded_plugin_class).__name__
    assert loaded_plugin_class_name == 'CredentialPlugin'


@with_managed_credential_plugins
def test_entry_points_are_managed_credential_type(
    entry_point: EntryPointParam,
) -> None:
    """Ensure all exposed managed credential plugins are of the same class."""  # noqa: D200, DAR101; FIXME
    entry_points = _discover_entry_points(group=entry_point.group)
    loaded_plugin_class = entry_points[entry_point.name].load()

    loaded_plugin_class_name = type(loaded_plugin_class).__name__
    assert loaded_plugin_class_name == 'ManagedCredentialType'


@with_inventory_plugins
def test_entry_points_are_inventory_plugin(
    entry_point: EntryPointParam,
) -> None:
    """Ensure all exposed inventory plugins are of the same class."""  # noqa: D200, DAR101; FIXME
    entry_points = _discover_entry_points(group=entry_point.group)
    loaded_plugin_class = entry_points[entry_point.name].load()

    assert issubclass(loaded_plugin_class, PluginFileInjector)
