"""
Track item transformations, effects, etc.

See this: https://chatgpt.com/share/695a0558-4d1c-8004-8440-5d9c4b683adb
"""
