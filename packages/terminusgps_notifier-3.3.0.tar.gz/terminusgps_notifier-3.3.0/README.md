# TerminusGPS Notifier

Accepts webhooks from Wialon and sends voice calls/text messages based on path parameters.
