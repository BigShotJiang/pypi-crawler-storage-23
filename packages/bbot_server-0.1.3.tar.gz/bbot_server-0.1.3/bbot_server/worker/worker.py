import asyncio
import logging
import traceback
from contextlib import suppress
from taskiq.schedule_sources import LabelScheduleSource
from taskiq.api import run_receiver_task, run_scheduler_task
from taskiq import TaskiqScheduler, TaskiqEvents, TaskiqState

from bbot_server.assets import Asset
from bbot.models.pydantic import Event
from bbot_server.errors import BBOTServerNotFoundError
from bbot_server.modules.activity.activity_models import Activity


class BBOTWorker:
    """
    Contains:
        - taskiq worker
        - taskiq scheduler
        - event queue listener
    """

    def __init__(self, bbot_server):
        self.log = logging.getLogger(__name__)
        # bbot server
        self.bbot_server = bbot_server

    async def start(self) -> None:
        self.broker = await self.bbot_server.message_queue.make_taskiq_broker()
        self.broker.is_worker_process = True

        # attach bbot_server to the taskiq broker state
        async def startup(state: TaskiqState) -> None:
            state.bbot_server = self.bbot_server

        self.broker.add_event_handler(TaskiqEvents.WORKER_STARTUP, startup)
        # taskiq scheduler
        self.taskiq_schedule_source = LabelScheduleSource(self.broker)
        self.taskiq_scheduler = TaskiqScheduler(self.broker, [self.taskiq_schedule_source])

        await self.broker.startup()

        # register worker tasks
        for app in self.bbot_server.all_child_applets(include_self=True):
            await app.register_worker_tasks(self.broker)

        # taskiq worker tasks
        self.taskiq_worker_task = asyncio.create_task(run_receiver_task(self.broker))
        self.taskiq_scheduler_task = asyncio.create_task(run_scheduler_task(self.taskiq_scheduler))

        # listen for new events
        self.event_listener = await self.bbot_server.message_queue.subscribe(
            "events", self._event_listener, durable="bbot_worker"
        )
        # listen for new activities
        self.activity_listener = await self.bbot_server.message_queue.subscribe(
            "assets", self._activity_listener, durable="bbot_worker"
        )

    async def _event_listener(self, message: dict) -> None:
        """
        Consume events from the queue and distribute them to the applets
        """
        try:
            activities = []
            event = Event(**message)
            event_data = getattr(event, "data", None)
            event_host = getattr(event, "host", None)
            if event_data:
                event_preview = f": {event_data}"
            elif event_host:
                event_preview = f": {event_host}"
            else:
                event_preview = ""
            self.log.info(f"Received event: {event.type}{event_preview}")
            # get the event's associated asset (this saves on database queries since it will be passed down to each applet)
            asset, _activities = await self._get_or_create_asset(event.host, event=event)
            activities.extend(_activities)

            # let each applet process the event
            for applet in self.bbot_server.all_child_applets(include_self=True):
                if not applet._enabled:
                    continue
                if await applet.watches_event(event.type):
                    try:
                        _activities = await applet.handle_event(event, asset) or []
                        activities.extend(_activities)
                    except Exception as e:
                        self.log.error(f"Error ingesting event {event.type} for applet {applet.name}: {e}")
                        self.log.error(traceback.format_exc())

            # update the asset in the database
            if activities and asset is not None:
                await self.bbot_server.assets.update_asset(asset)

            # publish applet activities to the message queue
            for activity in activities:
                await self.bbot_server._emit_activity(activity)

        except Exception as e:
            self.log.error(f"Error ingesting event {event.type}: {e}")
            self.log.error(traceback.format_exc())

    async def _activity_listener(self, message: dict) -> None:
        """
        Consume activities from the queue and distribute them to the applets
        """
        try:
            activity = Activity(**message)
            activity_json = activity.model_dump()
            activities = []
            asset, _activities = await self._get_or_create_asset(activity.host, parent_activity=activity)
            activities.extend(_activities)

            # let each applet process the activity
            for applet in self.bbot_server.all_child_applets(include_self=True):
                if await applet.watches_activity(activity, activity_json):
                    try:
                        _activities = await applet.handle_activity(activity, asset) or []
                        activities.extend(_activities)
                    except Exception as e:
                        self.log.error(f"Error processing activity {activity.type} for applet {applet.name}: {e}")
                        self.log.error(traceback.format_exc())

            # publish new activities to the message queue
            for activity in activities:
                await self.bbot_server._emit_activity(activity)

            # update the asset in the database
            if activities and asset is not None:
                await self.bbot_server.assets.update_asset(asset)
        except Exception:
            self.log.error(f"Error ingesting activity {message}")
            self.log.error(traceback.format_exc())

    async def _get_or_create_asset(self, host: str, event: Event = None, parent_activity: Activity = None) -> Asset:
        """
        Given a host, get the asset from the database. If it doesn't exist, create it.

        Returns the asset and a list of activities that were generated (NEW_ASSET if the asset was created).
        """
        if not host:
            return None, []
        activities = []
        try:
            asset = await self.bbot_server.assets.get_asset(host)
        except BBOTServerNotFoundError:
            asset = Asset(host=host)
            activities = [
                self.bbot_server.assets.make_activity(
                    type="NEW_ASSET",
                    description=f"New asset: [[COLOR]{host}[/COLOR]]",
                    event=event,
                    parent_activity=parent_activity,
                )
            ]
        return asset, activities

    async def stop(self) -> None:
        self.log.info("Stopping worker")
        await self.bbot_server.message_queue.unsubscribe(self.event_listener)
        self.taskiq_worker_task.cancel()
        self.taskiq_scheduler_task.cancel()
        with suppress(asyncio.CancelledError):
            await self.taskiq_worker_task
            await self.taskiq_scheduler_task
        await self.broker.shutdown()
        await self.bbot_server.cleanup()
