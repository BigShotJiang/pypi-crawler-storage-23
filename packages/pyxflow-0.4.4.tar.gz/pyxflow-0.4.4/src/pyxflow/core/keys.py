"""Key - keyboard key constants for shortcuts."""

from enum import Enum


class Key(Enum):
    """Keyboard key constants matching Vaadin's Key enum."""

    ENTER = "Enter"
    ESCAPE = "Escape"
    SPACE = " "
    TAB = "Tab"
    ARROW_DOWN = "ArrowDown"
    ARROW_UP = "ArrowUp"
    ARROW_LEFT = "ArrowLeft"
    ARROW_RIGHT = "ArrowRight"
    BACKSPACE = "Backspace"
    DELETE = "Delete"
    HOME = "Home"
    END = "End"
    PAGE_UP = "PageUp"
    PAGE_DOWN = "PageDown"
    F1 = "F1"
    F2 = "F2"
    F3 = "F3"
    F4 = "F4"
    F5 = "F5"
    F6 = "F6"
    F7 = "F7"
    F8 = "F8"
    F9 = "F9"
    F10 = "F10"
    F11 = "F11"
    F12 = "F12"
