import os
import logging
from typing import Any, Dict, Final, List, Optional
import yaml
import requests

from .database import DatabasePyKx
from .kdbai_exception import KDBAIException
from .utils import _unlicensed_getitem_dict, process_result
from .version import check_version


os.environ['IGNORE_QHOME'] = '1'
os.environ['PYKX_NOQCE'] = '1'
os.environ['SKIP_UNDERQ'] = '1'
os.environ['QARGS'] = '--unlicensed'
import pykx as kx  # noqa: E402

logger = logging.getLogger(__name__)

class SessionPyKx:
    """Session represents a connection to a KDB.AI instance using QIPC connection."""
    def __init__(self,
                 oauth: Dict = None, # enabled,config_file and manager
                 *,
                 host: Optional[str],
                 port: Optional[int],
                 endpoint: Optional[str],
                 options: Dict[str, Any]):
        """Create a QIPC API connection to a KDB.AI endpoint.

        Args:
            api_key: API Key to be used for authentication.
            endpoint: Server endpoint to connect to.
            host: Server host.
            port: Server port number.
            options: Extra options to create QIPC connection.

        Example:
            Open a session on a custom KDB.AI instance on http://localhost:8082:

            ```python
            session = kdbai.Session(host='localhost' port=8082)
            ```

            Open a session on a custom KDB.AI instance on http://localhost:8082 with authentication:

            ```python
            session = kdbai.Session(host='localhost' port=8082, options={'username': 'John', 'password': 'test'})
            ```
        """
        self.oauth = oauth
        if host is None or port is None:
            if endpoint is None:
                raise KDBAIException('Either host and port or endpoint must be provided')
            else:
                url = requests.utils.urlparse(endpoint)
                host = url.hostname
                port = url.port
        if not host or not port:
            raise KDBAIException(f'Host and port must not be empty: "{host}:{port}"')
        self.host = host
        self.port = port
        
        # for oauth token
        if oauth["enabled"]:
            options['password'] = oauth["manager"].get_token()
            self._write_oauth_tokens()
        try:
            self._gw = kx.SyncQConnection(host=host, port=port, no_ctx=True, **options)
        except Exception as e:
            if self._is_auth_error(e) and self.oauth["enabled"]:
                logger.info('Initial auth failed, attempting token refresh')
                try:
                    options['password'] =self.oauth["manager"].refresh()
                    self._write_oauth_tokens()
                    self._gw = kx.SyncQConnection(host=host, port=port, no_ctx=True, **options)
                except Exception as retry_err:
                    raise KDBAIException(
                        f'Authentication error (token refresh also failed: {retry_err})')
                else:
                    raise KDBAIException('Authentication error')
            elif self._is_auth_error(e):
                raise KDBAIException('Authentication error')
            else:
                raise KDBAIException('Error during creating connection, make sure KDB.AI server is running'
                                    f' and accepts QIPC connection on port {port}: {e}')

        self._is_alive: bool = True
        check_version(self.version())
        self.operator_map: Final[Dict[str, Any]] = self._send_request('getSupportedFilters', None).py()

    def close(self) -> None:
        """Close connection to the server"""
        self._is_alive = False
        self._gw.close()

    def version(self) -> dict:
        """Retrieve version information from server"""
        return {k: v.decode('utf-8') for k, v in self._send_request('getVersion', None).py().items()}

    def create_database(self, database: str) -> DatabasePyKx:
        """Create a new database"""
        result = self._send_request('createDatabase', {'database': database})
        process_result(result)
        return DatabasePyKx(name=database, session=self, tables_meta=dict())

    def databases(self, include_tables: bool) -> List[DatabasePyKx]:
        """List databases"""
        result = self._send_request('listDatabases', None)
        result = process_result(result)
        if include_tables:
            return [self.database(db_name) for db_name in result]

        return [DatabasePyKx(name=db_name, session=self, tables_meta=dict()) for db_name in result]

    def database(self, database: str) -> DatabasePyKx:
        """Fetch a database"""
        result = self._send_request('getDatabase', {'database': database})
        try:
            result = process_result(result)
        except Exception as e:
            if "access not allowed" in str(e):
                return DatabasePyKx(name=database, session=self, tables_meta=dict())
            else:
                raise 
        return DatabasePyKx(name=database, session=self, tables_meta=result.get('tables') or dict())
    
    def databases_info(self) -> Dict[str, Any]:
        """Get Databases Info"""
        result = self._send_request('getAllDatabasesInfo', None)
        info = process_result(result)
        # convert databses and tables output to a row like form instead of column like form
        db=info['databases']
        out = [dict(zip(db.keys(), values)) for values in zip(*db.values())]
        for t in out:
            if t['tables']:
                t['tables']=[dict(zip(t['tables'].keys(), values)) for values in zip(*t['tables'].values())]
            else:
                t['tables'] = []
        info['databases'] = out
        return info

    def session_info(self) -> Dict[str, Any]:
        """Get Session Info"""
        result = self._send_request('getSessionInfo', None)
        info = process_result(result)
        info['sessions'] = [dict(zip(info['sessions'].keys(), values)) for values in zip(*info['sessions'].values())]
        return info
    
    def process_info(self) -> Dict[str, Any]:
        """Get Process Info"""
        result = self._send_request('getProcessInfo', None)
        info = process_result(result)
        info['processes'] = [dict(zip(info['processes'].keys(), values)) for values in zip(*info['processes'].values())]
        return info
    
    def system_info(self) -> Dict[str, Any]:
        """Get System Info"""
        result = self._send_request('getSystemInfo', None)
        info = process_result(result)
        info['sessionsInfo']['sessions'] = [dict(zip(info['sessionsInfo']['sessions'].keys(), values)) for values in zip(*info['sessionsInfo']['sessions'].values())]
        info['processesInfo']['processes'] = [dict(zip(info['processesInfo']['processes'].keys(), values)) for values in zip(*info['processesInfo']['processes'].values())]
        db=info['databasesInfo']['databases']
        out = [dict(zip(db.keys(), values)) for values in zip(*db.values())]
        for t in out:
            if t['tables']:
                t['tables']=[dict(zip(t['tables'].keys(), values)) for values in zip(*t['tables'].values())]
            else:
                t['tables'] = []
        info['databasesInfo']['databases'] = out
        return info

    # -------- Worker API -----
    def add_worker(self, worker_type='general') -> dict:
        result = self._send_request('addWorker', {'type': worker_type})
        return process_result(result)
    
    def remove_worker(self, id) -> bool:
        result = self._send_request('removeWorker', {'id': id})
        return process_result(result)

    # -------- Grants API -----
    # Get all grants
    def get_all_grants(self) -> dict:
        result = self._send_request('getAllGrants', None)
        d = process_result(result)
        res = {}
        for key, value in d.items():
            out = [dict(zip(value.keys(), values))for values in zip(*value.values())]
            res[key] = out
        return res
    
    # get grant by id
    def get_grant_by_id(self, id) -> dict:
        result = self._send_request('getGrantById', {'id': id})
        return process_result(result)
    
    # add grants
    def add_grants(self,items) -> dict:
        result = self._send_request('addGrants', items)
        response = process_result(result)
        # Case 1: Already list of dictionaries
        if isinstance(response, list) and all(isinstance(i, dict) for i in response):
            return response
        # Case 2: Column-wise dict format (dict of lists)
        if isinstance(response, dict) and all(isinstance(v, list) for v in response.values()):
            return [dict(zip(response.keys(), values)) for values in zip(*response.values())]
        
    # delete grant by id
    def delete_grant(self, id) -> dict:
        result = self._send_request('deleteGrant', {'id': id})
        return process_result(result)
    
    def _send_request(self, endpoint: str, *args, **kwargs):
        """Send request through QIPC connection"""
        """
        On auth errors, refreshes the token and retries once.
        Auth errors can come as either:
          1. An exception from the QIPC call (e.g. connection rejected)
          2. A success=false response with an error message in the payload
        """
        if not self._is_alive:
            raise RuntimeError('Attempted to use closed session')
        try:
            result = self._gw(endpoint, *args, **kwargs)
        except Exception as e:
            # Token was invalid at connection time -- pykx threw an exception.
            # Refresh and retry once; if the retry fails, let it propagate.
            if self._is_auth_error(e) and self.oauth["enabled"]:
                logger.info('Auth error detected, attempting token refresh')
                self._refresh_oauth_token()
                return self._gw(endpoint, *args, **kwargs)
            if isinstance(e, RuntimeError):
                raise RuntimeError('Error during request, make sure KDB.AI server running')
            raise
        # Token expired between requests -- the call succeeded but the
        # response payload contains an auth error. Refresh and retry once.
        if self._is_auth_error_response(result) and self.oauth["enabled"]:
            logger.info('Auth error in response, attempting token refresh')
            self._refresh_oauth_token()
            result = self._gw(endpoint, *args, **kwargs)
        return result

    def _refresh_oauth_token(self):
        if self.oauth["manager"].is_expired():
            newToken = self.oauth["manager"].refresh()
            self._write_oauth_tokens()
            self._gw('updateOauthToken', newToken.encode("utf-8"))
    
    @staticmethod
    def _is_auth_error(e: Exception) -> bool:
        """Check if a QIPC exception is an auth/token expiry error.

        QIPC auth errors can surface in two ways (unlike REST which always
        returns HTTP 401):
          1. The token is invalid at connection time -- the server rejects
             the connection and pykx throws an exception. Handled here.
          2. The token was valid at connection time but expired between
             requests -- the server returns {success: false, error: "..."}
             in the response payload. Handled by _is_auth_error_response().

        pykx raises generic exceptions with the error message as the first
        arg (e.args[0]).  We match three known patterns:
          - 'Authentication error'  -- credentials rejected
          - 'access:...'            -- server denied access
          - contains 'expired'      -- e.g. 'Session token has expired.'
        """
        if not e.args or not isinstance(e.args[0], str):
            return False
        msg = e.args[0]
        return (msg == 'Authentication error'
                or msg.startswith('access:')
                or 'expired' in msg.lower())

    @staticmethod
    def _is_auth_error_response(result) -> bool:
        """Check if a QIPC response dict contains an auth/token expiry error.

        Unlike HTTP 401, QIPC can return auth errors as a successful response
        with {success: false, error: "Session token has expired."} in the
        payload.  The try/except catches cases where the result isn't a dict
        (e.g. normal data results) so we don't crash.
        """
        try:
            if _unlicensed_getitem_dict(result, 'success').py():
                return False
            msg = _unlicensed_getitem_dict(result, 'error').py()
            if isinstance(msg, bytes):
                msg = msg.decode('utf-8')
            return ('expired' in msg.lower()
                    or msg.startswith('access:')
                    or msg == 'Authentication error')
        except Exception:
            return False

    # write oauth token back to config file
    def _write_oauth_tokens(self) -> None:
        # Load existing YAML
        with open(self.oauth["config_file"], "r") as f:
            config = yaml.safe_load(f) or {}

        # Update or insert tokens
        config["oauth"]["access_token"] = self.oauth["manager"]._token["access_token"]

        if self.oauth["manager"]._token["refresh_token"]:
            config["oauth"]["refresh_token"] = self.oauth["manager"]._token["refresh_token"]

        # Write back to file
        with open(self.oauth["config_file"], "w") as f:
            yaml.safe_dump(config, f, default_flow_style=False)