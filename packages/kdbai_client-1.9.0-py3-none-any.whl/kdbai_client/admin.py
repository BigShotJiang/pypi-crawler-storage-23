# ------- Admin class -------------------------
# This will be used  as a namespace in Session class.
# It separates data functions layer(ex:CRUD ops) from control functions which will be used by admin like add worker etc.
# ----------------------------------------------

class Admin:
    def __init__(self,session, mode):
        self._session = session  # parent session object
        self._mode = mode  # session mode qipc or rest
    
    # -------- Worker API -----
    # Adds a new worker of given worker_type.
    def add_worker(self, worker_type='general') -> dict:
        return self._session.add_worker(worker_type)
    
    # Removes worker of given worker id    
    def remove_worker(self, id) -> bool:
        return self._session.remove_worker(id)
    
    # -------- Grants API -----
    # Get all grants
    def get_all_grants(self) -> bool:
        return self._session.get_all_grants()
    
    # get grant by id
    def get_grant_by_id(self, id) -> dict:
        return self._session.get_grant_by_id(id)
    
    # add grants
    def add_grants(self,items) -> dict:
        return self._session.add_grants(items)
    
    # delete grant by id
    def delete_grant(self, id) -> dict:
        return self._session.delete_grant(id)