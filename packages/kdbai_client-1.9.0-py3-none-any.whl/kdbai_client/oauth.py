"""
JWT Token Manager using authlib.
Reads OAuth config from a YAML file and supports client_credentials and password grant types.
"""

import time
import logging
import base64
import json
import yaml
from pathlib import Path
from typing import Optional

from authlib.integrations.requests_client import OAuth2Session

logger = logging.getLogger(__name__)


class JWTTokenManager:
    """
    OAuth2 JWT Token Manager backed by authlib.

    Reads configuration from a YAML file.
    Supports:
      - client_credentials grant
      - password grant

    Token expiry is determined by decoding the JWT's `exp` claim —
    no signature verification is done since this client is only
    fetching tokens to use in outgoing API calls.

    Config file format (oauth_config.yaml):

        oauth:
          token_url: "https://auth.example.com/oauth/token"
          client_id: "my-client-id"
          client_secret: "my-client-secret"
          grant_type: "client_credentials"   # or "password"
          scope: "openid profile"            # optional

          # only required when grant_type is "password"
          username: "user@example.com"
          password: "secret123"
    """

    SUPPORTED_GRANTS = ("client_credentials", "password")

    def __init__(self, config_path: str, expiry_buffer: int = 10):
        """
        Args:
            config_path:   Path to the YAML config file.
            expiry_buffer: Seconds before actual token expiry to treat it as
                           expired and proactively refresh. Defaults to 10s.
        """
        self.expiry_buffer = expiry_buffer
        self._config: dict = self._load_config(config_path)
        self._session: OAuth2Session = self._build_session()
        self._token: Optional[dict] = None       # raw token dict returned by authlib
        self._claims: Optional[dict] = None      # decoded JWT payload (for exp)

        # Bootstrap from pre-supplied tokens in config if present
        self._bootstrap_from_config()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_token(self) -> str:
        """
        Return a valid JWT access token string.
        Automatically fetches a new token if none exists or the current one is expired.
        """
        if self._token is None or self.is_expired():
            logger.debug("Token missing or expired — fetching a new one.")
            self._fetch_and_store_token()
        return self._token["access_token"]

    def get_claims(self) -> Optional[dict]:
        """
        Return the decoded JWT claims (payload) of the current token.
        Useful for inspecting sub, exp, roles, etc. without verification overhead.
        Returns None if the token could not be decoded.
        """
        self.get_token()  # ensure token is fresh
        return self._claims

    def is_expired(self) -> bool:
        """
        Check whether the current token is expired (or within the expiry buffer).
        Falls back to authlib's expires_at if the JWT cannot be decoded.
        """
        if self._token is None:
            return True

        exp = None

        # Prefer exp from decoded JWT claims
        if self._claims:
            exp = self._claims.get("exp")

        # Fall back to expires_at in the token dict (set by authlib)
        if exp is None:
            exp = self._token.get("expires_at")

        if exp is None:
            # No expiry info available — treat as expired to be safe
            logger.warning("No expiry info found in token; treating as expired.")
            return True

        return time.time() >= (exp - self.expiry_buffer)

    def refresh(self) -> str:
        """
        Force-fetch a new token regardless of the current token's expiry.
        Returns the new access token string.
        """
        logger.debug("Force-refreshing token.")
        self._fetch_and_store_token()
        return self._token["access_token"]

    # ------------------------------------------------------------------
    # Internal — config loading & validation
    # ------------------------------------------------------------------

    def _load_config(self, config_path: str) -> dict:
        path = Path(config_path)
        if not path.exists():
            raise FileNotFoundError(f"OAuth config file not found: {path.resolve()}")

        with open(path) as f:
            raw = yaml.safe_load(f)

        cfg = raw.get("oauth") if raw else None
        if not cfg:
            raise ValueError("Config file must have a top-level 'oauth:' key.")

        self._validate_config(cfg)
        return cfg

    def _validate_config(self, cfg: dict) -> None:
        # If access_token is provided, nothing else is strictly required at load time.
        # token_url/client creds are validated lazily when actually needed.
        if cfg.get("access_token"):
            # Warn if refresh_token is present but token_url is missing
            if cfg.get("refresh_token") and not cfg.get("token_url"):
                raise ValueError(
                    "'token_url' is required when 'refresh_token' is provided."
                )
            return

        # No pre-supplied token — need everything to fetch from scratch
        required_fields = ["token_url", "client_id", "grant_type"]
        missing = [f for f in required_fields if not cfg.get(f)]
        if missing:
            raise ValueError(f"Missing required config fields: {missing}")

        grant = cfg["grant_type"]
        if grant not in self.SUPPORTED_GRANTS:
            raise ValueError(
                f"Unsupported grant_type '{grant}'. "
                f"Must be one of: {self.SUPPORTED_GRANTS}"
            )

        # client_secret required for client_credentials, optional for password (public clients)
        if grant == "client_credentials" and not cfg.get("client_secret"):
            raise ValueError("'client_secret' is required for grant_type 'client_credentials'.")

        if grant == "password":
            if not cfg.get("username") or not cfg.get("password"):
                raise ValueError(
                    "grant_type 'password' requires both 'username' and 'password' in config."
                )

    # ------------------------------------------------------------------
    # Internal — session & token fetching
    # ------------------------------------------------------------------

    def _build_session(self) -> Optional[OAuth2Session]:
        # Session is only needed if we may need to fetch/refresh via the token endpoint
        if not self._config.get("client_id"):
            return None

        kwargs = {
            "client_id": self._config["client_id"],
            "scope": self._config.get("scope"),
        }
        # client_secret is optional for password grant (public clients)
        if self._config.get("client_secret"):
            kwargs["client_secret"] = self._config["client_secret"]

        return OAuth2Session(**kwargs)

    def _bootstrap_from_config(self) -> None:
        """
        If the config file contains a pre-supplied access_token, use it directly
        instead of hitting the token endpoint. The refresh_token (if provided) will
        be used when this token expires.
        """
        access_token = self._config.get("access_token")
        if not access_token:
            return

        refresh_token = self._config.get("refresh_token")
        self._token = {
            "access_token": access_token,
            "token_type": "Bearer",
            # authlib needs expires_at; we'll derive it from JWT claims below,
            # or default to 0 so is_expired() triggers a refresh immediately
            # if the token can't be decoded.
            "expires_at": 0,
        }
        if refresh_token:
            self._token["refresh_token"] = refresh_token

        self._claims = self._decode_jwt(access_token)

        # Patch expires_at from JWT exp claim so is_expired() works correctly
        if self._claims and self._claims.get("exp"):
            self._token["expires_at"] = self._claims["exp"]

        logger.debug(
            f"Bootstrapped from config-supplied token. "
            f"Has refresh_token: {bool(refresh_token)}, "
            f"exp: {self._claims.get('exp') if self._claims else 'unknown'}"
        )

    def _fetch_and_store_token(self) -> None:
        """Try refresh token first, fall back to full re-auth."""
        refresh_token = self._token.get("refresh_token") if self._token else None

        if refresh_token:
            try:
                token = self._refresh_with_refresh_token(refresh_token)
                logger.debug("Token refreshed using refresh_token.")
            except Exception as e:
                logger.warning(f"Refresh token failed ({e}), falling back to full re-auth.")
                token = self._fetch_token()
        else:
            token = self._fetch_token()

        self._token = token
        self._claims = self._decode_jwt(token["access_token"])

    def _refresh_with_refresh_token(self, refresh_token: str) -> dict:
        if not self._config.get("token_url"):
            raise RuntimeError("Cannot refresh token — 'token_url' is missing from config.")
        return self._session.fetch_token(
            url=self._config["token_url"],
            grant_type="refresh_token",
            refresh_token=refresh_token,
        )

    def _fetch_token(self) -> dict:
        if not self._config.get("token_url"):
            raise RuntimeError("Cannot fetch token — 'token_url' is missing from config.")
        if self._session is None:
            raise RuntimeError(
                "Cannot fetch a new token — no client_id/client_secret in config. "
                "Either provide credentials or supply a valid access_token with a refresh_token."
            )
        grant = self._config["grant_type"]
        token_url = self._config["token_url"]

        try:
            if grant == "client_credentials":
                token = self._session.fetch_token(
                    url=token_url,
                    grant_type="client_credentials",
                )

            elif grant == "password":
                token = self._session.fetch_token(
                    url=token_url,
                    grant_type="password",
                    username=self._config["username"],
                    password=self._config["password"],
                )

            logger.debug("Token fetched successfully.")
            return token

        except Exception as e:
            raise RuntimeError(f"Failed to fetch token from '{token_url}': {e}") from e

    # ------------------------------------------------------------------
    # Internal — JWT decoding (exp extraction only, no verification)
    # ------------------------------------------------------------------

    def _decode_jwt(self, access_token: str) -> Optional[dict]:
        """
        Decode JWT payload without signature verification by manually base64-decoding
        the claims segment. We only need the claims (especially `exp`) to manage token
        refresh timing — full JWT validation is the API server's responsibility.
        """
        try:
            # JWT structure: header.payload.signature — we only need the payload (index 1)
            payload_segment = access_token.split(".")[1]

            # Base64url decode — pad to a multiple of 4 to avoid padding errors
            padding = 4 - len(payload_segment) % 4
            payload_segment += "=" * (padding % 4)

            decoded = base64.urlsafe_b64decode(payload_segment)
            claims = json.loads(decoded)

            logger.debug(f"JWT claims decoded. exp={claims.get('exp')}, sub={claims.get('sub')}")
            return claims

        except Exception as e:
            logger.warning(f"Could not decode JWT — will fall back to authlib expires_at: {e}")
            return None
