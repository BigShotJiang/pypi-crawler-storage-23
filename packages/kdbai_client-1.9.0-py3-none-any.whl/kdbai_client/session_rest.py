from base64 import b64encode
from typing import Any, Dict, List, Optional
from urllib import parse
import logging
import requests
import yaml

from .constants import Headers, RestPath
from .database_rest import DatabaseRest
from .kdbai_exception import KDBAIException
from .utils import process_response
from .version import check_version


logger = logging.getLogger(__name__)

MAX_QIPC_SERIALIZATION_SIZE = 10*1024*1024  # 10MB

class SessionRest:
    """Session represents a REST connection to a KDB.AI instance."""

    def __init__(
        self,
        oauth: Dict = None, # enabled,config_file and manager
        *,
        endpoint: str,
        options: Dict[str, Any]  # can be used to pass username and password for server authentication
    ):
        """Create a REST API connection to a KDB.AI endpoint.

        Args:
            api_key (str): API Key to be used for authentication.
            endpoint (str): Server endpoint to connect to.

        Example:
            Open a session on KDB.AI Cloud with an api key:

            ```python
            session = Session(endpoint='YOUR_INSTANCE_ENDPOINT', api_key='YOUR_API_KEY')
            ```

            Open a session on a custom KDB.AI instance on http://localhost:8081:

            ```python
            session = Session(endpoint='http://localhost:8081', mode='rest')

            Open a session on a custom KDB.AI instance on http://localhost:8081 with authentication:

            ```python
            session = Session(endpoint='http://localhost:8081', mode='rest',
                              options={'username': 'John', 'password': 'test'})
            ```
        """
        self.oauth = oauth
        self.endpoint = endpoint
        username = options.get('username', None)
        password = options.get('password', None)
        self.headers = dict()
        # set authentication
        if oauth["enabled"] and username is not None and password is not None:
            raise KDBAIException('Cannot use both oauth token and username/password for authentication')
        if oauth["enabled"]:
            self.headers['Authorization'] = "Bearer " + oauth["manager"].get_token()
            self._write_oauth_tokens()
        elif username is not None and password is not None:
            self.headers['Authorization'] = "Basic {}".format(
        b64encode(bytes(f"{username}:{password}", "utf-8")).decode("ascii"))

        self._is_alive: bool = True
        self._check_endpoint()
        self._check_readiness()
        check_version(self.version())

    def _check_endpoint(self):
        try:
            url = parse.urlparse(self.endpoint)
            if url.scheme not in ('http', 'https') or url.netloc == '':
                raise AssertionError
        except Exception:
            raise KDBAIException(f'Invalid URL: {self.endpoint}.')
        return True

    def _check_readiness(self):
        try:
            response = self._send_request(requests.get, self._build_url(RestPath.READY), headers=self.headers)
            if response.status_code != 200:
                raise AssertionError
        except Exception:
            tmp = None if not self.oauth['enabled'] else self.oauth['manager'].get_token()
            raise KDBAIException(
                f'Failed to open a session on {self.endpoint}. '
                'Please double check your `endpoint` and `credentials`.'
                )

    def _build_url(self, path):
        return f'{self.endpoint}{path}'

    def _build_headers(self, headers):
        return {**headers, **self.headers}

    def close(self) -> None:
        """Close connection to the server"""
        self._is_alive = False

    def version(self) -> Dict[str, Any]:
        """Retrieve version information from server"""
        response = self._send_request(requests.get, self._build_url(RestPath.VERSION), headers=self.headers)
        if response.status_code == 401:
            raise KDBAIException('Authentication error')
        return response.json()

    def create_database(self, database: str) -> DatabaseRest:
        """Create a new database"""
        response = self._send_request(requests.post,
                                      self._build_url(RestPath.DATABASE_CREATE),
                                      json={'database': database},
                                      headers=self._build_headers(Headers.JSON_JSON))
        process_response(response, expected_status_code=201)
        return DatabaseRest(name=database, session=self, tables_meta=dict())

    def databases(self, include_tables: bool) -> List[DatabaseRest]:
        """List databases"""
        response = self._send_request(requests.get,
                                      self._build_url(RestPath.DATABASE_LIST),
                                      headers=self._build_headers(Headers.ACCEPT_JSON))
        result = process_response(response, expected_status_code=200)['result']
        if include_tables:
            return [self.database(db_name) for db_name in result]

        return [DatabaseRest(name=db_name, session=self, tables_meta=dict()) for db_name in result]

    def database(self, database: str) -> DatabaseRest:
        """Fetch a database"""
        response = self._send_request(requests.get,
                                      self._build_url(RestPath.DATABASE_GET.format(db_name=database)),
                                      headers=self._build_headers(Headers.ACCEPT_JSON))
        try:
            result = process_response(response, expected_status_code=200)['result']
        except Exception as e:
            if "access not allowed" in str(e):
                return DatabaseRest(name=database, session=self, tables_meta=dict())
            else:
                raise
        return DatabaseRest(name=database, session=self, tables_meta=result.get('tables') or dict())
    
    def databases_info(self) -> Dict[str, Any]:
        """Fetch all databases info"""
        response = self._send_request(requests.get,
                                      self._build_url(RestPath.DATABASES_INFO_GET.format()),
                                      headers=self._build_headers(Headers.ACCEPT_JSON))
        return process_response(response, expected_status_code=200)['result']
    
    def session_info(self) -> Dict[str, Any]:
        """Fetch all sessions info"""
        response = self._send_request(requests.get,
                                      self._build_url(RestPath.SESSION_INFO_GET.format()),
                                      headers=self._build_headers(Headers.ACCEPT_JSON))
        return process_response(response, expected_status_code=200)['result']
    
    def process_info(self) -> Dict[str, Any]:
        """Fetch all processes info"""
        response = self._send_request(requests.get,
                                      self._build_url(RestPath.PROCESS_INFO_GET.format()),
                                      headers=self._build_headers(Headers.ACCEPT_JSON))
        return process_response(response, expected_status_code=200)['result']
    
    def system_info(self) -> Dict[str, Any]:
        """Fetch system info"""
        response = self._send_request(requests.get,
                                      self._build_url(RestPath.SYSTEM_INFO_GET.format()),
                                      headers=self._build_headers(Headers.ACCEPT_JSON))
        return process_response(response, expected_status_code=200)['result']
    
    # -------- Worker API -----
    def add_worker(self, worker_type='general') -> dict:
        response = self._send_request(requests.post,
                                      self._build_url(RestPath.ADD_WORKER.format()),
                                      json={'type': worker_type},
                                      headers=self._build_headers(Headers.ACCEPT_JSON))
        return process_response(response, expected_status_code=200)['result']
    
    # Removes worker of given worker id    
    def remove_worker(self, id) -> bool:
        response = self._send_request(requests.delete,
                                      self._build_url(RestPath.REMOVE_WORKER.format(id=id)),
                                      headers=self._build_headers(Headers.ACCEPT_JSON))
        return process_response(response, expected_status_code=200)['result']

    # -------- Grants API -----
    # Get all grants
    def get_all_grants(self) -> dict:
        response = self._send_request(requests.get,
                                      self._build_url(RestPath.GRANTS_BASE.format()),
                                      headers=self._build_headers(Headers.ACCEPT_JSON))
        return process_response(response, expected_status_code=200)['result']
    
    # get grant by id
    def get_grant_by_id(self, id) -> dict:
        response = self._send_request(requests.get,
                                      self._build_url(RestPath.GRANTS_BY_ID.format(id=id)),
                                      headers=self._build_headers(Headers.ACCEPT_JSON))
        return process_response(response, expected_status_code=200)['result']
    
    # add grants
    def add_grants(self,items) -> dict:
        response = self._send_request(requests.post,
                                      self._build_url(RestPath.GRANTS_BASE.format()),
                                      json=items,
                                      headers=self._build_headers(Headers.ACCEPT_JSON))
        return process_response(response, expected_status_code=200)['result']
    
    # delete grant by id
    def delete_grant(self, id) -> dict:
        response = self._send_request(requests.delete,
                                      self._build_url(RestPath.GRANTS_BY_ID.format(id=id)),
                                      headers=self._build_headers(Headers.ACCEPT_JSON))
        return process_response(response, expected_status_code=200)['result']

    # ---------- Helper functions
    def _send_request(self, func, *args, **kwargs):
        """Send REST request"""
        if not self._is_alive:
            raise RuntimeError('Attempted to use closed session')
        try:
            response = func(*args, **kwargs)
        except requests.exceptions.ConnectionError:
            raise RuntimeError('Error during request, make sure KDB.AI server running')

        if response.status_code == 401 and self.oauth["enabled"]:
            logger.info('401 received, attempting token refresh')
            self._refresh_oauth_token()
            self._write_oauth_tokens()
            # The retry's kwargs still have the old token baked in; swap it out.
            if 'headers' in kwargs:
                kwargs['headers']['Authorization'] = self.headers['Authorization']
            response = func(*args, **kwargs)
        return response

    def _refresh_oauth_token(self) -> None:
        """Refresh the OAuth token if expired and update the Authorization header."""
        if self.oauth["manager"].is_expired():
            new_token = self.oauth["manager"].refresh()
            logger.info('Token refreshed, updating REST session headers')
            self.headers['Authorization'] = 'Bearer ' + new_token
    
    # write oauth token back to config file
    def _write_oauth_tokens(self) -> None:
        # Load existing YAML
        with open(self.oauth["config_file"], "r") as f:
            config = yaml.safe_load(f) or {}

        # Update or insert tokens
        config["oauth"]["access_token"] = self.oauth["manager"]._token["access_token"]

        if self.oauth["manager"]._token["refresh_token"]:
            config["oauth"]["refresh_token"] = self.oauth["manager"]._token["refresh_token"]

        # Write back to file
        with open(self.oauth["config_file"], "w") as f:
            yaml.safe_dump(config, f, default_flow_style=False)