"""
cobol-parser-mcp
~~~~~~~~~~~~~~~~
MCP server that parses COBOL mainframe programs and extracts structured data
plus AI-powered business logic summaries via any LLM provider.

Quick usage:
    from cobol_parser_mcp.tools.parser import parse_cobol_file
    from cobol_parser_mcp.tools.batch import parse_all_programs
"""

__version__ = "0.1.0"
__author__  = "Rohan Nair"