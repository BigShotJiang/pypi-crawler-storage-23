# pyontoenv compatibility package

This is a lightweight wrapper that depends on the main `ontoenv` wheel and re-exports its public API so that existing `pip install pyontoenv` workflows continue to function.

It contains no additional functionality beyond importing `ontoenv`.
