# FILE-SIZE-OK: Recency backfill logic (REST, fromId, adaptive loop)
"""Layer 2 recency backfill for open deviation bar cache (Issue #92).

Bridges the gap between the latest Binance Vision archive data and the current
time by fetching recent trades via REST API and computing open deviation bars.

Architecture:
    Binance Vision (Tier 1) → [gap] → REST API (Layer 2) → ClickHouse

The adaptive polling loop self-tunes its frequency based on observed gap size,
configured via OPENDEVIATIONBAR_RECENCY_* env vars in .mise.toml (SSoT).

Usage
-----
Single-shot backfill:

>>> from opendeviationbar.recency import backfill_recent
>>> result = backfill_recent("BTCUSDT", threshold_decimal_bps=250)
>>> print(f"Filled {result.bars_written} bars, gap was {result.gap_seconds}s")

Backfill all cached symbols:

>>> from opendeviationbar.recency import backfill_all_recent
>>> results = backfill_all_recent()

Adaptive loop (long-running sidecar):

>>> from opendeviationbar.recency import run_adaptive_loop
>>> run_adaptive_loop()  # Runs until interrupted
"""

from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime

logger = logging.getLogger(__name__)


# =============================================================================
# Adaptive Thresholds (from .mise.toml [env] SSoT)
# =============================================================================


def _env_int(key: str, default: int) -> int:
    return int(os.environ.get(key, str(default)))


def _fresh_threshold_s() -> int:
    """Gap below which data is considered fresh (sleep longer)."""
    return _env_int("OPENDEVIATIONBAR_RECENCY_FRESH_THRESHOLD_MIN", 30) * 60


def _stale_threshold_s() -> int:
    """Gap above which data is stale (poll more aggressively)."""
    return _env_int("OPENDEVIATIONBAR_RECENCY_STALE_THRESHOLD_MIN", 120) * 60


def _critical_threshold_s() -> int:
    """Gap above which data is critically stale (fast backfill)."""
    return _env_int("OPENDEVIATIONBAR_RECENCY_CRITICAL_THRESHOLD_MIN", 1440) * 60


def _adaptive_sleep(gap_seconds: float) -> float:
    """Compute sleep duration based on observed gap size.

    Returns sleep time in seconds. Larger gaps = shorter sleep = faster polling.
    """
    fresh = _fresh_threshold_s()
    stale = _stale_threshold_s()
    critical = _critical_threshold_s()

    if gap_seconds < fresh:
        return 15 * 60  # 15 min — data is fresh
    if gap_seconds < stale:
        return 5 * 60  # 5 min — getting stale
    if gap_seconds < critical:
        return 2 * 60  # 2 min — large gap
    return 30  # 30 sec — major gap


# =============================================================================
# Result Types
# =============================================================================


@dataclass
class BackfillResult:
    """Result of a single backfill operation."""

    symbol: str
    threshold_decimal_bps: int
    bars_written: int
    gap_seconds: float
    latest_ts_before: int | None
    latest_ts_after: int | None
    duration_seconds: float = 0.0
    error: str | None = None


@dataclass
class LoopState:
    """State tracked across adaptive loop iterations."""

    iteration: int = 0
    total_bars_written: int = 0
    started_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    last_gaps: dict[str, float] = field(default_factory=dict)


# =============================================================================
# Core Backfill Logic
# =============================================================================


def _get_cached_symbol_threshold_pairs() -> list[tuple[str, int]]:
    """Query ClickHouse for all distinct (symbol, threshold) pairs in cache.

    Issue #126: Filters by operational ouroboros_mode to avoid returning
    pairs that only exist in a different mode.

    Returns
    -------
    list[tuple[str, int]]
        List of (symbol, threshold_decimal_bps) pairs.
    """
    from opendeviationbar.clickhouse import OpenDeviationBarCache
    from opendeviationbar.ouroboros import get_operational_ouroboros_mode

    mode = get_operational_ouroboros_mode()
    with OpenDeviationBarCache() as cache:
        result = cache.client.query(
            "SELECT DISTINCT symbol, threshold_decimal_bps "
            "FROM opendeviationbar_cache.open_deviation_bars FINAL "
            "WHERE ouroboros_mode = {mode:String} "
            "ORDER BY symbol, threshold_decimal_bps",
            parameters={"mode": mode},
        )
        return [(row[0], row[1]) for row in result.result_rows]


def backfill_recent(
    symbol: str,
    threshold_decimal_bps: int = 250,
    *,
    include_microstructure: bool = True,
    verbose: bool = False,
) -> BackfillResult:
    """Backfill the gap between latest cached bar and now via REST API.

    Parameters
    ----------
    symbol : str
        Trading symbol (e.g., "BTCUSDT").
    threshold_decimal_bps : int
        Threshold in decimal basis points.
    include_microstructure : bool
        Include all 26 microstructure features (default True).
    verbose : bool
        Enable detailed logging.

    Returns
    -------
    BackfillResult
        Summary of the backfill operation.
    """
    from opendeviationbar.clickhouse import OpenDeviationBarCache
    from opendeviationbar.symbol_registry import validate_symbol_registered
    from opendeviationbar.threshold import resolve_and_validate_threshold

    validate_symbol_registered(symbol, operation="backfill_recent")
    threshold_decimal_bps = resolve_and_validate_threshold(
        symbol, threshold_decimal_bps
    )

    t0 = time.monotonic()
    now_ms = int(datetime.now(UTC).timestamp() * 1000)

    # Step 1: Query latest bar timestamp
    with OpenDeviationBarCache() as cache:
        latest_ts = cache.get_latest_bar_timestamp(symbol, threshold_decimal_bps)

    if latest_ts is None:
        logger.warning(
            "No cached bars for %s @ %d dbps — cannot backfill "
            "(run populate_cache_resumable first)",
            symbol,
            threshold_decimal_bps,
        )
        return BackfillResult(
            symbol=symbol,
            threshold_decimal_bps=threshold_decimal_bps,
            bars_written=0,
            gap_seconds=0,
            latest_ts_before=None,
            latest_ts_after=None,
            duration_seconds=time.monotonic() - t0,
            error="no_cached_bars",
        )

    gap_ms = now_ms - latest_ts
    gap_seconds = gap_ms / 1000.0

    if gap_seconds < 60:
        # Less than 1 minute gap — nothing meaningful to backfill
        logger.debug(
            "%s @ %d dbps: gap %.0fs — fresh, skipping",
            symbol,
            threshold_decimal_bps,
            gap_seconds,
        )
        return BackfillResult(
            symbol=symbol,
            threshold_decimal_bps=threshold_decimal_bps,
            bars_written=0,
            gap_seconds=gap_seconds,
            latest_ts_before=latest_ts,
            latest_ts_after=latest_ts,
            duration_seconds=time.monotonic() - t0,
        )

    logger.info(
        "%s @ %d dbps: gap %.1f min — backfilling from REST API",
        symbol,
        threshold_decimal_bps,
        gap_seconds / 60,
    )

    # Step 2: Fetch recent trades via REST API
    try:
        bars_written = _fetch_and_process_gap(
            symbol=symbol,
            threshold_decimal_bps=threshold_decimal_bps,
            start_ms=latest_ts + 1,
            end_ms=now_ms,
            include_microstructure=include_microstructure,
            verbose=verbose,
        )
    except (RuntimeError, OSError, ConnectionError) as e:
        logger.warning(
            "%s @ %d dbps: backfill failed: %s",
            symbol,
            threshold_decimal_bps,
            e,
        )
        return BackfillResult(
            symbol=symbol,
            threshold_decimal_bps=threshold_decimal_bps,
            bars_written=0,
            gap_seconds=gap_seconds,
            latest_ts_before=latest_ts,
            latest_ts_after=latest_ts,
            duration_seconds=time.monotonic() - t0,
            error=str(e),
        )

    # Step 3: Query new latest timestamp
    with OpenDeviationBarCache() as cache:
        new_latest_ts = cache.get_latest_bar_timestamp(symbol, threshold_decimal_bps)

    elapsed = time.monotonic() - t0
    logger.info(
        "%s @ %d dbps: backfilled %d bars in %.1fs (gap was %.1f min)",
        symbol,
        threshold_decimal_bps,
        bars_written,
        elapsed,
        gap_seconds / 60,
    )

    return BackfillResult(
        symbol=symbol,
        threshold_decimal_bps=threshold_decimal_bps,
        bars_written=bars_written,
        gap_seconds=gap_seconds,
        latest_ts_before=latest_ts,
        latest_ts_after=new_latest_ts,
        duration_seconds=elapsed,
    )


def _fetch_aggtrades_rest(
    symbol: str,
    start_ms: int,
    end_ms: int,
) -> list[dict]:
    """Fetch aggregated trades from Binance REST API via Rust (native performance).

    Delegates to Rust `fetch_aggtrades_rest()` which uses reqwest to paginate
    through /api/v3/aggTrades (max 1000 per request) with async I/O.

    Returns list of trade dicts compatible with
    OpenDeviationBarProcessor.process_trades().
    """
    from opendeviationbar._core import fetch_aggtrades_rest

    try:
        return fetch_aggtrades_rest(symbol, start_ms, end_ms)
    except Exception as e:
        msg = f"REST API fetch failed for {symbol} [{start_ms}-{end_ms}]: {e}"
        raise RuntimeError(msg) from e


def _fetch_aggtrades_by_id(
    symbol: str,
    from_id: int,
    limit: int = 1000,
) -> list[dict]:
    """Fetch aggregated trades by fromId (zero-gap pagination via Rust).

    Uses ``fromId`` parameter instead of ``startTime`` to avoid dropping
    trades at millisecond boundaries.  Delegates to Rust
    ``fetch_aggtrades_by_id()`` which includes 429 backoff.

    Returns list of trade dicts compatible with
    OpenDeviationBarProcessor.process_trades().
    """
    from opendeviationbar._core import fetch_aggtrades_by_id

    try:
        return fetch_aggtrades_by_id(symbol, from_id, limit)
    except Exception as e:
        msg = (
            f"REST API fetch (fromId) failed for {symbol} "
            f"[fromId={from_id}, limit={limit}]: {e}"
        )
        raise RuntimeError(msg) from e


def _fetch_latest_aggtrade(symbol: str) -> dict:
    """Fetch the latest aggregated trade for a symbol via Rust.

    Single REST call with ``limit=1``.  Returns single trade dict as
    anchor point for cursor-based ``fromId`` pagination.
    """
    from opendeviationbar._core import fetch_latest_aggtrade

    try:
        return fetch_latest_aggtrade(symbol)
    except Exception as e:
        msg = f"REST API fetch (latest) failed for {symbol}: {e}"
        raise RuntimeError(msg) from e


def _fetch_and_process_gap(
    *,
    symbol: str,
    threshold_decimal_bps: int,
    start_ms: int,
    end_ms: int,
    include_microstructure: bool = True,
    verbose: bool = False,
) -> int:
    """Fetch trades and process into open deviation bars using Ariadne (fromId).

    Issue #115 (Kintsugi Phase 2a): Uses Ariadne fromId pagination when
    a last_agg_trade_id anchor exists in ClickHouse. Falls back to
    startTime only for first-ever backfill (no bars at all).

    Returns number of bars written.
    """
    import polars as pl

    from opendeviationbar.clickhouse import OpenDeviationBarCache
    from opendeviationbar.orchestration.helpers import (
        _create_processor,
    )

    # Step 1: Try Ariadne (fromId) first — zero-gap by construction
    ariadne_anchor: int | None = None
    with OpenDeviationBarCache() as cache:
        ariadne_anchor = cache.get_ariadne_high_water_mark(
            symbol,
            threshold_decimal_bps,
        )

    if ariadne_anchor is not None:
        trades = _fetch_trades_ariadne(
            symbol,
            ariadne_anchor + 1,
            end_ms,
            verbose=verbose,
        )
        logger.debug(
            "%s: Ariadne fetched %d trades (from_id=%d)",
            symbol,
            len(trades),
            ariadne_anchor + 1,
        )
    else:
        # Fallback to startTime (first-ever backfill only)
        trades = _fetch_aggtrades_rest(symbol, start_ms, end_ms)
        logger.debug(
            "%s: startTime fallback fetched %d trades (%d-%d ms)",
            symbol,
            len(trades),
            start_ms,
            end_ms,
        )

    if not trades:
        logger.debug(
            "%s: no trades in gap %d-%d",
            symbol,
            start_ms,
            end_ms,
        )
        return 0

    # Process trades through Rust processor
    processor = _create_processor(
        threshold_decimal_bps,
        include_microstructure,
        symbol=symbol,
    )
    bars = processor.process_trades(trades)

    if not bars:
        logger.debug(
            "%s: no completed bars from %d trades",
            symbol,
            len(trades),
        )
        return 0

    # Convert bars to Polars DataFrame for batch storage
    bars_df = pl.DataFrame(bars)

    # Write to ClickHouse via store_bars_batch (with dedup token)
    with OpenDeviationBarCache() as cache:
        written = cache.store_bars_batch(
            symbol=symbol,
            threshold_decimal_bps=threshold_decimal_bps,
            bars=bars_df,
        )

    return written


def _fetch_trades_ariadne(
    symbol: str,
    from_id: int,
    end_ms: int,
    *,
    batch_size: int = 1000,
    verbose: bool = False,
) -> list[dict]:
    """Paginate trades using Ariadne fromId cursor until end_ms.

    Returns all trades from from_id up to end_ms (inclusive).
    """
    all_trades: list[dict] = []
    current_id = from_id

    while True:
        batch = _fetch_aggtrades_by_id(symbol, current_id, batch_size)
        if not batch:
            break

        for trade in batch:
            ts = trade.get("timestamp") or trade.get("time", 0)
            if ts > end_ms:
                return all_trades
            all_trades.append(trade)

        # Advance cursor past this batch
        last_id = batch[-1].get("agg_trade_id", batch[-1].get("a", 0))
        if last_id <= current_id:
            break  # Safety: no progress
        current_id = last_id + 1

        if verbose and len(all_trades) % 10000 == 0:
            logger.debug(
                "%s: Ariadne progress %d trades, current_id=%d",
                symbol,
                len(all_trades),
                current_id,
            )

    return all_trades


# =============================================================================
# Multi-Symbol Backfill
# =============================================================================

# Issue #115 (Kintsugi Phase 2b): Sustained failure tracking
_SUSTAINED_FAILURE_THRESHOLD = 5


def _notify_sustained_failure(consecutive_errors: int) -> None:
    """Send Telegram alert after N consecutive backfill failures."""
    try:
        from opendeviationbar.notify.telegram import _build_context_block, send_telegram
    except ImportError:
        return
    try:
        msg = (
            "<b>BACKFILL SUSTAINED FAILURE</b>\n"
            f"<b>Consecutive errors:</b> {consecutive_errors}\n"
            f"<b>Threshold:</b> {_SUSTAINED_FAILURE_THRESHOLD}\n"
            "<b>Check:</b> REST API connectivity + ClickHouse status\n"
            "<b>Debug:</b> <code>curl -s 'http://localhost:8123/?query=SELECT+1'</code>"
            + _build_context_block("backfill")
        )
        send_telegram(msg, disable_notification=False)
    except (OSError, RuntimeError, ConnectionError):
        logger.exception("failed to send sustained failure alert")


def backfill_all_recent(
    *,
    include_microstructure: bool = True,
    verbose: bool = False,
) -> list[BackfillResult]:
    """Backfill all cached symbol x threshold pairs.

    Queries ClickHouse for all distinct (symbol, threshold) pairs and runs
    backfill_recent for each.

    Issue #115 (Kintsugi Phase 2b): Sends Telegram alert after 5 consecutive
    errors across the batch (sustained failure detection).

    Returns
    -------
    list[BackfillResult]
        Results for each pair, including any errors.
    """
    pairs = _get_cached_symbol_threshold_pairs()
    logger.info("Backfilling %d symbol x threshold pairs", len(pairs))

    results = []
    consecutive_errors = 0
    for symbol, threshold in pairs:
        try:
            result = backfill_recent(
                symbol,
                threshold,
                include_microstructure=include_microstructure,
                verbose=verbose,
            )
            results.append(result)
            if result.error:
                consecutive_errors += 1
            else:
                consecutive_errors = 0
        except (ValueError, RuntimeError, OSError, ConnectionError) as e:
            logger.warning(
                "Backfill failed for %s @ %d: %s",
                symbol,
                threshold,
                e,
            )
            results.append(
                BackfillResult(
                    symbol=symbol,
                    threshold_decimal_bps=threshold,
                    bars_written=0,
                    gap_seconds=0,
                    latest_ts_before=None,
                    latest_ts_after=None,
                    error=str(e),
                )
            )
            consecutive_errors += 1

        if consecutive_errors >= _SUSTAINED_FAILURE_THRESHOLD:
            _notify_sustained_failure(consecutive_errors)
            consecutive_errors = 0  # Reset after alert

    total_bars = sum(r.bars_written for r in results)
    errors = sum(1 for r in results if r.error)
    logger.info(
        "Backfill complete: %d pairs, %d bars written, %d errors",
        len(results),
        total_bars,
        errors,
    )
    return results


# =============================================================================
# Adaptive Loop
# =============================================================================


def run_adaptive_loop(
    *,
    include_microstructure: bool = True,
    verbose: bool = False,
) -> None:
    """Run adaptive recency backfill loop until interrupted.

    Self-tunes polling frequency based on observed gap sizes. Designed to run
    as a long-lived sidecar process (systemd service or tmux session).

    The loop:
    1. Queries all cached symbol x threshold pairs
    2. Backfills each pair
    3. Computes max gap across all pairs
    4. Sleeps for adaptive duration based on max gap
    5. Repeats

    Stop with Ctrl+C (SIGINT).
    """
    # Issue #126: SIGHUP reloads config (enables runtime ouroboros_mode switching)
    import signal

    def _sighup_handler(*_args: object) -> None:
        from opendeviationbar.config import Settings

        Settings.reload_and_clear()
        new_mode = Settings.get().population.ouroboros_mode
        logger.info("SIGHUP: config reloaded (ouroboros_mode=%s)", new_mode)
        # Issue #134: Notify operators of runtime config change
        try:
            from opendeviationbar.notify.telegram import send_telegram

            send_telegram(
                f"<b>SIGHUP: recency config reloaded</b>\n"
                f"<b>ouroboros_mode:</b> {new_mode}\n"
                f"<b>PID:</b> {os.getpid()}",
                disable_notification=True,
            )
        except (ImportError, OSError):
            logger.debug("SIGHUP: Telegram notification failed (non-fatal)")

    signal.signal(signal.SIGHUP, _sighup_handler)

    state = LoopState()
    logger.info("Starting adaptive recency backfill loop")

    try:
        while True:
            state.iteration += 1
            logger.info("=== Iteration %d ===", state.iteration)

            results = backfill_all_recent(
                include_microstructure=include_microstructure,
                verbose=verbose,
            )

            # Track gaps per symbol for adaptive sleep
            max_gap = 0.0
            for r in results:
                key = f"{r.symbol}@{r.threshold_decimal_bps}"
                state.last_gaps[key] = r.gap_seconds
                state.total_bars_written += r.bars_written
                max_gap = max(max_gap, r.gap_seconds)

            sleep_seconds = _adaptive_sleep(max_gap)
            logger.info(
                "Max gap: %.1f min | Sleep: %.0fs | Total bars: %d",
                max_gap / 60,
                sleep_seconds,
                state.total_bars_written,
            )

            time.sleep(sleep_seconds)

    except KeyboardInterrupt:
        logger.info(
            "Loop stopped after %d iterations, %d total bars written",
            state.iteration,
            state.total_bars_written,
        )


@dataclass
class BackfillStatus:
    """Status of the most recent backfill request for a symbol x threshold pair."""

    status: str  # "none" | "pending" | "running" | "completed" | "failed"
    request_id: str | None = None
    requested_at: datetime | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None
    bars_written: int = 0
    gap_seconds: float = 0.0
    error: str | None = None
    elapsed_seconds: float = 0.0
    watcher_likely_offline: bool = False


def check_backfill_status(
    symbol: str,
    threshold_decimal_bps: int = 250,
) -> BackfillStatus:
    """Check the status of the most recent backfill request.

    Queries the backfill_requests table for the latest request matching the
    given symbol and threshold. If the request has been pending for more than
    300 seconds, sets ``watcher_likely_offline=True``.

    Parameters
    ----------
    symbol : str
        Trading symbol (e.g., "BTCUSDT").
    threshold_decimal_bps : int
        Threshold in decimal basis points (use 0 to match any threshold).

    Returns
    -------
    BackfillStatus
        Current status of the most recent backfill request, or status="none"
        if no matching request exists.
    """
    from opendeviationbar.clickhouse import OpenDeviationBarCache

    with OpenDeviationBarCache() as cache:
        result = cache.client.query(
            "SELECT request_id, status, requested_at, started_at, "
            "completed_at, bars_written, gap_seconds, error "
            "FROM opendeviationbar_cache.backfill_requests FINAL "
            "WHERE symbol = {symbol:String} "
            "  AND (threshold_decimal_bps = {threshold:UInt32} "
            "       OR threshold_decimal_bps = 0) "
            "ORDER BY requested_at DESC "
            "LIMIT 1",
            parameters={
                "symbol": symbol,
                "threshold": threshold_decimal_bps,
            },
        )

    if not result.result_rows:
        return BackfillStatus(status="none")

    row = result.result_rows[0]
    request_id = str(row[0])
    status = str(row[1])
    requested_at = row[2] if row[2] else None
    started_at = row[3] if row[3] else None
    completed_at = row[4] if row[4] else None
    bars_written = int(row[5]) if row[5] else 0
    gap_seconds = float(row[6]) if row[6] else 0.0
    error = str(row[7]) if row[7] else None

    # Compute elapsed time from requested_at
    elapsed_seconds = 0.0
    if requested_at:
        now = datetime.now(UTC)
        if hasattr(requested_at, "timestamp"):
            elapsed_seconds = (now - requested_at).total_seconds()

    watcher_likely_offline = status == "pending" and elapsed_seconds > 300

    return BackfillStatus(
        status=status,
        request_id=request_id,
        requested_at=requested_at,
        started_at=started_at,
        completed_at=completed_at,
        bars_written=bars_written,
        gap_seconds=gap_seconds,
        error=error,
        elapsed_seconds=elapsed_seconds,
        watcher_likely_offline=watcher_likely_offline,
    )


__all__ = [
    "BackfillResult",
    "BackfillStatus",
    "LoopState",
    "backfill_all_recent",
    "backfill_recent",
    "check_backfill_status",
    "run_adaptive_loop",
]
