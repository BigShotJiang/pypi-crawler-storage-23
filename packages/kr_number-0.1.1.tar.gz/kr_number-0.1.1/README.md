# kr-number

숫자를 한글로 변환하거나, 콤마를 찍을 수 있는 도구에요!

## 설치 방법

```bash
pip install kr-number
```

## 예제

### 읽기 방식으로 변환하기

```python
import knum
print(knum.convert(1000000,"원"))
#출력 : 백만원
```

### 천 단위 콤마 찍기

```python
import knum
print(knum.comma(1000000))
#출력 : 1,000,000
```
