def comma(number: int):
    "숫자에 천 단위 콤마를 넣어줍니다."
    return f"{number:,}"

def convert(number:int ,suffix:str):
    """숫자를 한국어로 읽기 편하게 바꿔줍니다."""
    num_u = ["","일","이","삼","사","오","육","칠","팔","구"]
    u = ["","십","백","천"]
    big_u = ["","만","억","조","경","해"]
    lst = []
    for i,num in enumerate(reversed(str(number))):
        n = int(num)
        if i > 0 and i % 4 == 0:
            lst.append(big_u[i//4])
        if n != 0:
            lst.append(u[i % 4])
            if not (n == 1 and i % 4 != 0):
                lst.append(num_u[n])
    lst.reverse()
    return "".join(lst) + suffix