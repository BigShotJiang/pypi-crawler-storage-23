from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.test_suite import TestSuite





T = TypeVar("T", bound="WorkflowSuiteOutput")



@_attrs_define
class WorkflowSuiteOutput:
    """ 
        Attributes:
            workflow_id (str):
            test_suite (TestSuite):
            enabled (bool):
     """

    workflow_id: str
    test_suite: TestSuite
    enabled: bool
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.test_suite import TestSuite
        workflow_id = self.workflow_id

        test_suite = self.test_suite.to_dict()

        enabled = self.enabled


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "workflowID": workflow_id,
            "testSuite": test_suite,
            "enabled": enabled,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.test_suite import TestSuite
        d = dict(src_dict)
        workflow_id = d.pop("workflowID")

        test_suite = TestSuite.from_dict(d.pop("testSuite"))




        enabled = d.pop("enabled")

        workflow_suite_output = cls(
            workflow_id=workflow_id,
            test_suite=test_suite,
            enabled=enabled,
        )


        workflow_suite_output.additional_properties = d
        return workflow_suite_output

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
