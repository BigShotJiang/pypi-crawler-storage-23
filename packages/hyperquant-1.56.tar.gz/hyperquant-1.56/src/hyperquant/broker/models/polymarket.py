from __future__ import annotations

import json
from dataclasses import dataclass, field
from heapq import heappop, heappush
import time
from typing import TYPE_CHECKING, Any, Iterable

from pybotters.store import DataStore, DataStoreCollection
from pybotters.ws import ClientWebSocketResponse

if TYPE_CHECKING:
    from pybotters.typedefs import Item

   
class Position(DataStore):
    """Position store fed only by User WS trade events."""

    _KEYS = ["asset"]

    def _init(self) -> None:
        self._owner_key: str | None = None
        self._dedup_seen: dict[str, float] = {}
        self._dedup_ttl_secs = 15 * 60
        self._dedup_max_entries = 50_000
        self._market_state: dict[str, dict[str, Any]] = {}
        self._market_assets: dict[str, dict[str, str | None]] = {}

    def set_owner_key(self, api_key: str | None) -> None:
        owner = str(api_key).strip().lower() if api_key else ""
        self._owner_key = owner or None

    def sorted(
        self, query: Item | None = None, limit: int | None = None
    ) -> dict[str, list[Item]]:
        if query is None:
            query = {}
        result: dict[str, list[Item]] = {}
        for item in self:
            if all(k in item and query[k] == item[k] for k in query):
                outcome = item.get("outcome") or "unknown"
                result.setdefault(outcome, []).append(item)
        for outcome in result:
            result[outcome].sort(key=lambda x: float(x.get("ts") or 0.0), reverse=True)
            if limit:
                result[outcome] = result[outcome][:limit]
        return result

    def _on_response(self, msg: list[Item]) -> None:
        # Inventory is user-trade driven only (do not overwrite via REST snapshots).
        _ = msg
        return

    @staticmethod
    def _to_float(value: Any) -> float | None:
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _status_bucket(status: str) -> str | None:
        if status in {"MATCHED", "MINED", "CONFIRMED"}:
            return "SUCCESS"
        if status == "FAILED":
            return "FAILED"
        return None

    @staticmethod
    def _normalize_owner(owner: Any) -> str:
        return str(owner or "").strip().lower()

    @staticmethod
    def _dedup_bucket(status_bucket: str) -> str:
        return "SUCCESS" if status_bucket == "SUCCESS" else "FAILED"

    def _remember_dedup(self, key: str) -> bool:
        now = time.time()
        cutoff = now - self._dedup_ttl_secs
        if self._dedup_seen:
            stale = [k for k, ts in self._dedup_seen.items() if ts < cutoff]
            for k in stale:
                self._dedup_seen.pop(k, None)

        if key in self._dedup_seen:
            return False

        self._dedup_seen[key] = now
        if len(self._dedup_seen) > self._dedup_max_entries:
            oldest_key = min(self._dedup_seen, key=self._dedup_seen.get)
            self._dedup_seen.pop(oldest_key, None)
        return True

    def _infer_side_key(
        self,
        *,
        market: str,
        asset_id: str,
        outcome: str | None,
        outcome_index: Any,
    ) -> str | None:
        assets = self._market_assets.setdefault(market, {"YES": None, "NO": None})

        mapped_side: str | None = None
        if asset_id:
            if assets.get("YES") == asset_id:
                mapped_side = "YES"
            elif assets.get("NO") == asset_id:
                mapped_side = "NO"

        # Prefer outcome text for side inference; outcome_index is fallback only.
        text_side: str | None
        text = str(outcome or "").strip().upper()
        if text in {"YES", "UP", "TRUE"}:
            text_side = "YES"
        elif text in {"NO", "DOWN", "FALSE"}:
            text_side = "NO"
        else:
            text_side = None

        idx_side: str | None = None
        if outcome_index is not None:
            try:
                idx = int(outcome_index)
                if idx == 0:
                    idx_side = "YES"
                elif idx == 1:
                    idx_side = "NO"
            except (TypeError, ValueError):
                idx_side = None

        explicit_side = text_side if text_side is not None else idx_side

        # Correct a previously wrong binding once explicit side appears.
        if mapped_side and explicit_side and mapped_side != explicit_side:
            dst_asset = assets.get(explicit_side)
            if dst_asset in (None, asset_id):
                assets[mapped_side] = None
                assets[explicit_side] = asset_id
                self._migrate_side_state(market=market, from_side=mapped_side, to_side=explicit_side)
                mapped_side = explicit_side
            else:
                # Conflicting mapping (both legs already occupied by different assets): skip.
                return None

        if mapped_side:
            return mapped_side

        # Unknown outcome/index: do not guess side to avoid poisoning inventory.
        if explicit_side is None:
            return None

        bound = assets.get(explicit_side)
        if bound not in (None, asset_id):
            return None
        assets[explicit_side] = asset_id
        return explicit_side

    def _migrate_side_state(self, *, market: str, from_side: str, to_side: str) -> None:
        if from_side == to_side:
            return
        state = self._market_state.get(market)
        if not state:
            return

        from_qty_key = "yes_qty" if from_side == "YES" else "no_qty"
        from_avg_key = "yes_avg_cost" if from_side == "YES" else "no_avg_cost"
        to_qty_key = "yes_qty" if to_side == "YES" else "no_qty"
        to_avg_key = "yes_avg_cost" if to_side == "YES" else "no_avg_cost"

        from_qty = float(state.get(from_qty_key) or 0.0)
        from_avg = float(state.get(from_avg_key) or 0.0)
        to_qty = float(state.get(to_qty_key) or 0.0)

        # Safe migration only when destination leg has no existing inventory.
        if to_qty > 1e-12:
            return
        state[to_qty_key] = from_qty
        state[to_avg_key] = from_avg
        state[from_qty_key] = 0.0
        state[from_avg_key] = 0.0
        self._recompute_derived(state)

    def _default_state(self) -> dict[str, Any]:
        return {
            "yes_qty": 0.0,
            "no_qty": 0.0,
            "yes_avg_cost": 0.0,
            "no_avg_cost": 0.0,
            "net_diff": 0.0,
            "portfolio_cost": 0.0,
            "yes_asset": None,
            "no_asset": None,
            "yes_outcome": "Yes",
            "no_outcome": "No",
        }

    def _recompute_derived(self, state: dict[str, Any]) -> None:
        yes_qty = float(state.get("yes_qty") or 0.0)
        no_qty = float(state.get("no_qty") or 0.0)
        yes_avg = float(state.get("yes_avg_cost") or 0.0)
        no_avg = float(state.get("no_avg_cost") or 0.0)

        state["net_diff"] = yes_qty - no_qty
        state["portfolio_cost"] = (yes_avg + no_avg) if (yes_qty > 0.0 and no_qty > 0.0) else 0.0

    def _upsert_row(self, row: dict[str, Any]) -> None:
        existing = self.get({"asset": row["asset"]})
        if existing:
            self._update([row])
        else:
            self._insert([row])

    def _publish_market_state(self, market: str, state: dict[str, Any]) -> None:
        now_ms = int(time.time() * 1000)

        common = {
            "market": market,
            "yes_qty": float(state.get("yes_qty") or 0.0),
            "no_qty": float(state.get("no_qty") or 0.0),
            "yes_avg_cost": float(state.get("yes_avg_cost") or 0.0),
            "no_avg_cost": float(state.get("no_avg_cost") or 0.0),
            "net_diff": float(state.get("net_diff") or 0.0),
            "portfolio_cost": float(state.get("portfolio_cost") or 0.0),
            "ts": now_ms,
            "source": "user_ws_trade",
        }

        yes_asset = state.get("yes_asset")
        no_asset = state.get("no_asset")
        if yes_asset:
            yes_qty = common["yes_qty"]
            yes_avg = common["yes_avg_cost"]
            self._upsert_row(
                {
                    "asset": yes_asset,
                    "outcome": state.get("yes_outcome") or "Yes",
                    "size": yes_qty,
                    "avgPrice": yes_avg,
                    "totalAvgPrice": yes_avg,
                    **common,
                }
            )
        if no_asset:
            no_qty = common["no_qty"]
            no_avg = common["no_avg_cost"]
            self._upsert_row(
                {
                    "asset": no_asset,
                    "outcome": state.get("no_outcome") or "No",
                    "size": no_qty,
                    "avgPrice": no_avg,
                    "totalAvgPrice": no_avg,
                    **common,
                }
            )

    def _apply_fill(self, fill: dict[str, Any], status_bucket: str) -> None:
        market = str(fill.get("market") or "")
        if not market:
            market = "__unknown_market__"

        asset_id = str(fill.get("asset_id") or "")
        if not asset_id:
            return

        outcome = fill.get("outcome")
        side = str(fill.get("side") or "").upper()
        size = self._to_float(fill.get("size"))
        price = self._to_float(fill.get("price"))
        if side not in {"BUY", "SELL"} or size is None or price is None or size <= 0.0 or price <= 0.0:
            return

        side_key = self._infer_side_key(
            market=market,
            asset_id=asset_id,
            outcome=str(outcome or ""),
            outcome_index=fill.get("outcome_index"),
        )
        if side_key is None:
            return

        state = self._market_state.setdefault(market, self._default_state())
        assets = self._market_assets.get(market) or {}
        state["yes_asset"] = assets.get("YES")
        state["no_asset"] = assets.get("NO")
        if side_key == "YES":
            state["yes_asset"] = asset_id
            if outcome:
                state["yes_outcome"] = outcome
        else:
            state["no_asset"] = asset_id
            if outcome:
                state["no_outcome"] = outcome

        trade_sign = 1.0 if side == "BUY" else -1.0
        status_sign = -1.0 if status_bucket == "FAILED" else 1.0
        delta = size * trade_sign * status_sign
        if abs(delta) < 1e-12:
            return

        qty_key = "yes_qty" if side_key == "YES" else "no_qty"
        avg_key = "yes_avg_cost" if side_key == "YES" else "no_avg_cost"
        old_qty = float(state.get(qty_key) or 0.0)
        old_avg = float(state.get(avg_key) or 0.0)
        new_qty = max(old_qty + delta, 0.0)
        state[qty_key] = new_qty

        if delta > 0.0 and new_qty > 0.0:
            state[avg_key] = (old_qty * old_avg + delta * price) / new_qty
        elif new_qty < 1e-12:
            state[avg_key] = 0.0
        else:
            state[avg_key] = old_avg

        self._recompute_derived(state)
        self._publish_market_state(market, state)

    def _parse_maker_fills(self, trade: Item) -> list[dict[str, Any]]:
        fills: list[dict[str, Any]] = []
        maker_orders = trade.get("maker_orders") or []
        if not isinstance(maker_orders, list):
            return fills

        trade_price = self._to_float(trade.get("price"))
        trade_size = self._to_float(trade.get("size"))
        trade_side = str(trade.get("side") or "").upper()

        for maker in maker_orders:
            if not isinstance(maker, dict):
                continue
            owner = self._normalize_owner(maker.get("owner"))
            if self._owner_key and (not owner or owner != self._owner_key):
                continue

            side = str(maker.get("side") or trade_side or "").upper()
            size = self._to_float(maker.get("matched_amount"))
            if size is None:
                size = self._to_float(maker.get("size"))
            if size is None:
                size = trade_size
            price = self._to_float(maker.get("price"))
            if price is None:
                price = trade_price
            if side not in {"BUY", "SELL"} or size is None or price is None:
                continue
            fills.append(
                {
                    "trade_id": trade.get("id"),
                    "order_id": maker.get("order_id"),
                    "market": trade.get("market"),
                    "asset_id": maker.get("asset_id") or trade.get("asset_id"),
                    "outcome": maker.get("outcome") or trade.get("outcome"),
                    "outcome_index": maker.get("outcome_index"),
                    "side": side,
                    "size": size,
                    "price": price,
                }
            )
        return fills

    def _parse_taker_fill(self, trade: Item) -> list[dict[str, Any]]:
        owner = self._normalize_owner(trade.get("trade_owner") or trade.get("owner"))
        if self._owner_key and owner and owner != self._owner_key:
            return []

        side = str(trade.get("side") or "").upper()
        size = self._to_float(trade.get("size"))
        price = self._to_float(trade.get("price"))
        if side not in {"BUY", "SELL"} or size is None or price is None:
            return []

        return [
            {
                "trade_id": trade.get("id"),
                "order_id": trade.get("taker_order_id") or trade.get("order_id"),
                "market": trade.get("market"),
                "asset_id": trade.get("asset_id"),
                "outcome": trade.get("outcome"),
                "outcome_index": trade.get("outcome_index"),
                "side": side,
                "size": size,
                "price": price,
            }
        ]

    def on_trade(self, trade: Item) -> None:
        status = str(trade.get("status") or "").upper()
        status_bucket = self._status_bucket(status)
        if status_bucket is None:
            return

        trader_side = str(trade.get("trader_side") or "")
        maker_orders = trade.get("maker_orders") or []
        has_maker_orders = isinstance(maker_orders, list) and len(maker_orders) > 0

        if trader_side.upper() == "MAKER" or (not trader_side and has_maker_orders):
            fills = self._parse_maker_fills(trade)
            if not fills:
                return
        else:
            fills = self._parse_taker_fill(trade)

        bucket = self._dedup_bucket(status_bucket)
        for fill in fills:
            trade_id = str(fill.get("trade_id") or "")
            order_id = str(fill.get("order_id") or "")
            if trade_id:
                dedup_key = f"tid:{trade_id}:oid:{order_id}:{bucket}"
            else:
                dedup_key = (
                    f"oid:{order_id}:{bucket}:"
                    f"{fill.get('asset_id')}:{fill.get('side')}:"
                    f"{fill.get('price')}:{fill.get('size')}"
                )
            if not self._remember_dedup(dedup_key):
                continue
            self._apply_fill(fill, status_bucket)

    def _on_order(self, order: dict[str, Any]) -> None:
        # Position is no longer order-driven.
        _ = order
        return



class Fill(DataStore):
    """Fill records keyed by maker order id."""

    _KEYS = ["order_id"]

    @staticmethod
    def _from_trade(trade: dict[str, Any], maker: dict[str, Any]) -> dict[str, Any] | None:
        order_id = maker.get("order_id")
        if not order_id:
            return None

        record = {
            "order_id": order_id,
            "trade_id": trade.get("id"),
            "asset_id": maker.get("asset_id") or trade.get("asset_id"),
            "market": trade.get("market"),
            "outcome": maker.get("outcome") or trade.get("outcome"),
            "matched_amount": maker.get("matched_amount") or trade.get("size"),
            "price": maker.get("price") or trade.get("price"),
            "status": trade.get("status"),
            "match_time": trade.get("match_time") or trade.get("timestamp"),
            "maker_owner": maker.get("owner"),
            "taker_order_id": trade.get("taker_order_id"),
            "side": maker.get("side") or trade.get("side"),
        }

        for key in ("matched_amount", "price"):
            value = record.get(key)
            if value is None:
                continue
            try:
                record[key] = float(value)
            except (TypeError, ValueError):
                pass

        return record

    def _on_trade(self, trade: dict[str, Any]) -> None:
        status = str(trade.get("status") or "").upper()
        if status != "MATCHED":
            return
        maker_orders = trade.get("maker_orders") or []
        upserts: list[dict[str, Any]] = []
        for maker in maker_orders:
            record = self._from_trade(trade, maker)
            if not record:
                continue
            upserts.append(record)

        if not upserts:
            return

        for record in upserts:
            key = {"order_id": record["order_id"]}
            if self.get(key):
                self._update([record])
            else:
                self._insert([record])


class Order(DataStore):
    """User orders keyed by order id (REST + WS)."""

    _KEYS = ["id"]

    @staticmethod
    def _normalize(entry: dict[str, Any]) -> dict[str, Any] | None:
        oid = entry.get("id")
        if not oid:
            return None
        normalized = dict(entry)
        # numeric fields
        for field in ("price", "original_size", "size_matched"):
            val = normalized.get(field)
            try:
                if val is not None:
                    normalized[field] = float(val)
            except (TypeError, ValueError):
                pass
        return normalized

    def _on_response(self, items: list[dict[str, Any]] | dict[str, Any]) -> None:
        """增量同步：insert新增、update变更、delete消失的订单"""
        rows: list[dict[str, Any]] = []
        if isinstance(items, dict):
            items = [items]
        for it in items or []:
            norm = self._normalize(it)
            if norm:
                rows.append(norm)

        # 构建新订单id集合
        new_ids = {r["id"] for r in rows}

        # 删除不再存在的订单（传入完整状态）
        to_delete = [dict(item) for item in self if item["id"] not in new_ids]
        if to_delete:
            self._delete(to_delete)

        # 插入或更新
        for row in rows:
            existing = self.get({"id": row["id"]})
            if existing:
                # 有变化才update
                if any(existing.get(k) != row.get(k) for k in row):
                    self._update([row])
            else:
                self._insert([row])

    def _on_message(self, msg: dict[str, Any]) -> None:
        status = str(msg.get("status") or "").upper()
        # CANCELED MATCHED 删除
        order = self.get({"id": msg.get("id")})
        if not order:
            self._insert([msg])

        if status in {"CANCELED", "MATCHED"}:
            self._delete([msg])

class MyTrade(DataStore):
    """User trades keyed by trade id."""

    _KEYS = ["id"]

    @staticmethod
    def _normalize(entry: dict[str, Any]) -> dict[str, Any] | None:
        trade_id = entry.get("id")
        if not trade_id:
            return None
        normalized = dict(entry)
        for field in ("price", "size", "fee_rate_bps"):
            value = normalized.get(field)
            if value is None:
                continue
            try:
                normalized[field] = float(value)
            except (TypeError, ValueError):
                pass
        return normalized

    def _on_message(self, msg: dict[str, Any]) -> None:
        normalized = self._normalize(msg) or {}
        trade_id = normalized.get("id")
        if not trade_id:
            return
        if self.get({"id": trade_id}):
            self._update([normalized])
        else:
            self._insert([normalized])

class Trade(DataStore):
    """User trades keyed by trade id."""

    _KEYS = ["hash"]
    _MAXLEN = 500

    def _on_message(self, msg: dict[str, Any]) -> None:
        payload = msg or {}
        if payload:
            if payload.get("event_type") == "last_trade_price":
                transaction_hash = payload.get("transaction_hash")
                if transaction_hash:
                    payload.update({"hash": transaction_hash})
                    payload.pop("transaction_hash", None)
            else:
                if payload.get("transactionHash"):
                    payload.update({"hash": payload.get("transactionHash")})
                    payload.pop("transactionHash", None)

            self._insert([payload])

class Book(DataStore):
    """Full depth order book keyed by Polymarket token id."""

    _KEYS = ["s", "S", "p"]

    def _init(self) -> None:
        self.id_to_alias: dict[str, str] = {}

    def update_aliases(self, mapping: dict[str, str]) -> None:
        if not mapping:
            return
        self.id_to_alias.update(mapping)

    def _alias(self, asset_id: str | None) -> tuple[str, str | None] | tuple[None, None]:
        if asset_id is None:
            return None, None
        alias = self.id_to_alias.get(asset_id)
        return asset_id, alias

    def _normalize_levels(
        self,
        entries: Iterable[dict[str, Any]] | None,
        *,
        side: str,
        symbol: str,
        alias: str | None,
    ) -> list[dict[str, Any]]:
        if not entries:
            return []
        normalized: list[dict[str, Any]] = []
        for entry in entries:
            try:
                price = float(entry["price"])
                size = float(entry["size"])
            except (KeyError, TypeError, ValueError):
                continue
            record = {"s": symbol, "S": side, "p": price, "q": size}
            if alias is not None:
                record["alias"] = alias
            normalized.append(record)
        return normalized

    def _purge_missing_levels(
        self, *, symbol: str, side: str, new_levels: list[dict[str, Any]]
    ) -> None:
        """Remove levels no longer present in the latest snapshot."""
        existing = self.find({"s": symbol, "S": side})
        if not existing:
            return
        new_prices = {lvl["p"] for lvl in new_levels}
        stale = [
            {"s": symbol, "S": side, "p": level["p"]}
            for level in existing
            if level.get("p") not in new_prices
        ]
        if stale:
            self._delete(stale)

    def _on_message(self, msg: dict[str, Any]) -> None:
        msg_type = msg.get("event_type")
        if msg_type not in {"book", "price_change"}:
            return

        if msg_type == "book":
            asset_id = msg.get("asset_id") or msg.get("token_id")
            symbol, alias = self._alias(asset_id)
            if symbol is None:
                return
            bids = self._normalize_levels(msg.get("bids"), side="b", symbol=symbol, alias=alias)
            asks = self._normalize_levels(msg.get("asks"), side="a", symbol=symbol, alias=alias)
            self._purge_missing_levels(symbol=symbol, side="b", new_levels=bids)
            self._purge_missing_levels(symbol=symbol, side="a", new_levels=asks)
            if bids:
                self._insert(bids)
            if asks:
                self._insert(asks)
            return

        price_changes = msg.get("price_changes") or []
        updates: list[dict[str, Any]] = []
        removals: list[dict[str, Any]] = []
        for change in price_changes:
            asset_id = change.get("asset_id") or change.get("token_id")
            symbol, alias = self._alias(asset_id)
            if symbol is None:
                continue
            side = "b" if change.get("side") == "BUY" else "a"
            try:
                price = float(change["price"])
                size = float(change["size"])
            except (KeyError, TypeError, ValueError):
                continue
            record = {"s": symbol, "S": side, "p": price}
            if alias is not None:
                record["alias"] = alias
            if size == 0:
                removals.append({"s": symbol, "S": side, "p": price})
            else:
                record["q"] = size
                updates.append(record)

        if removals:
            self._delete(removals)
        if updates:
            self._update(updates)

    def sorted(
        self, query: Item | None = None, limit: int | None = None
    ) -> dict[str, list[Item]]:
        return self._sorted(
            item_key="S",
            item_asc_key="a",
            item_desc_key="b",
            sort_key="p",
            query=query,
            limit=limit,
        )

@dataclass
class _SideBook:
    is_ask: bool
    levels: dict[float, tuple[str, str]] = field(default_factory=dict)
    heap: list[tuple[float, float]] = field(default_factory=list)

    def clear(self) -> None:
        self.levels.clear()
        self.heap.clear()

    def update_levels(
        self, updates: Iterable[dict[str, Any]] | None, *, snapshot: bool
    ) -> None:
        if updates is None:
            return

        if snapshot:
            self.clear()

        for entry in updates:
            price, size = self._extract(entry)
            price_val = self._to_float(price)
            size_val = self._to_float(size)
            if price_val is None or size_val is None:
                continue

            if size_val <= 0:
                self.levels.pop(price_val, None)
                continue

            self.levels[price_val] = (str(price), str(size))
            priority = price_val if self.is_ask else -price_val
            heappush(self.heap, (priority, price_val))

    def best(self) -> tuple[str, str] | None:
        while self.heap:
            _, price = self.heap[0]
            level = self.levels.get(price)
            if level is not None:
                return level
            heappop(self.heap)
        return None

    @staticmethod
    def _extract(entry: Any) -> tuple[Any, Any]:
        if isinstance(entry, dict):
            price = entry.get("price", entry.get("p"))
            size = entry.get("size", entry.get("q"))
            return price, size
        if isinstance(entry, (list, tuple)) and len(entry) >= 2:
            return entry[0], entry[1]
        return None, None

    @staticmethod
    def _to_float(value: Any) -> float | None:
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

class Price(DataStore):
    _KEYS = ["s"]

    def _on_message(self, msg: dict[str, Any]) -> None:
        payload = msg.get('payload') or {}
        data = payload.get('data') or {}
        symbol = payload.get('symbol')

        if not symbol:
            return
        
        _next = self.get({'s': symbol}) or {}
        _next_price = _next.get('p')
        last_price = None
        
        if data and isinstance(data, list):
            last_price = data[-1].get('value')
        if 'value' in payload:
            last_price = payload.get('value')
        
        if last_price is None:
            return

        record = {'s': symbol, 'p': last_price}
        key = {'s': symbol}
        if self.get(key):
            self._update([record])
        else:
            self._insert([record])


class BBO(DataStore):
    _KEYS = ["s", "S"]

    def _init(self) -> None:
        self._book: dict[str, dict[str, _SideBook]] = {}
        self.id_to_alias: dict[str, str] = {}

    def update_aliases(self, mapping: dict[str, str]) -> None:
        if not mapping:
            return
        self.id_to_alias.update(mapping)

    def _alias(self, asset_id: str | None) -> tuple[str, str | None] | tuple[None, None]:
        if asset_id is None:
            return None, None
        alias = self.id_to_alias.get(asset_id)
        return asset_id, alias

    def _side(self, symbol: str, side: str) -> _SideBook:
        symbol_book = self._book.setdefault(symbol, {})
        side_book = symbol_book.get(side)
        if side_book is None:
            side_book = _SideBook(is_ask=(side == "a"))
            symbol_book[side] = side_book
        return side_book

    def _sync_side(
        self, symbol: str, side: str, best: tuple[str, str] | None, alias: str | None
    ) -> None:
        key = {"s": symbol, "S": side}
        current = self.get(key)

        if best is None:
            if current:
                self._delete([key])
            return

        price, size = best
        payload = {"s": symbol, "S": side, "p": price, "q": size}
        if alias is not None:
            payload["alias"] = alias

        if current:
            cur_price = current.get("p")
            cur_size = current.get("q")
            cur_alias = current.get("alias")

            if cur_price == price:
                # price unchanged -> only update quantities / alias changes
                if cur_size != size or (alias is not None and cur_alias != alias):
                    self._update([payload])
                return

            # price changed -> delete old then insert new level to trigger change watchers
            self._delete([key])

        self._insert([payload])

    def _from_price_changes(self, msg: dict[str, Any]) -> None:
        price_changes = msg.get("price_changes") or []
        touched: dict[str, str | None] = {}
        for change in price_changes:
            asset_id = change.get("asset_id") or change.get("token_id")
            symbol, alias = self._alias(asset_id)
            if symbol is None:
                continue
            side = "b" if str(change.get("side") or "").upper() == "BUY" else "a"
            side_book = self._side(symbol, side)
            side_book.update_levels([change], snapshot=False)
            touched[symbol] = alias

        for symbol, alias in touched.items():
            asks = self._side(symbol, "a")
            bids = self._side(symbol, "b")
            self._sync_side(symbol, "a", asks.best(), alias)
            self._sync_side(symbol, "b", bids.best(), alias)

    def _from_snapshot(self, msg: dict[str, Any]) -> None:
        asset_id = msg.get("asset_id") or msg.get("token_id")
        symbol, alias = self._alias(asset_id)
        if symbol is None:
            return
        asks = self._side(symbol, "a")
        bids = self._side(symbol, "b")
        asks.update_levels(msg.get("asks"), snapshot=True)
        bids.update_levels(msg.get("bids"), snapshot=True)
        self._sync_side(symbol, "a", asks.best(), alias)
        self._sync_side(symbol, "b", bids.best(), alias)

    def _on_message(self, msg: dict[str, Any]) -> None:
        msg_type = (msg.get("event_type") or msg.get("type") or "").lower()
        if msg_type == "book":
            self._from_snapshot(msg)
        elif msg_type == "price_change":
            self._from_price_changes(msg)


class Detail(DataStore):
    """Market metadata keyed by Polymarket token id."""

    _KEYS = ["token_id"]

    @staticmethod
    def _normalize_entry(market: dict[str, Any], token: dict[str, Any]) -> dict[str, Any]:
        slug = market.get("slug")
        outcome = token.get("outcome")
        alias = slug if outcome is None else f"{slug}:{outcome}"

        tick_size = (
            market.get("minimum_tick_size")
            or market.get("orderPriceMinTickSize")
            or market.get("order_price_min_tick_size")
        )
        step_size = (
            market.get("minimum_order_size")
            or market.get("orderMinSize")
            or market.get("order_min_size")
        )

        try:
            tick_size = float(tick_size) if tick_size is not None else None
        except (TypeError, ValueError):
            tick_size = None
        try:
            step_size = float(step_size) if step_size is not None else None
        except (TypeError, ValueError):
            step_size = None

        return {
            "token_id": token.get("token_id") or token.get("id"),
            "asset_id": token.get("token_id") or token.get("id"),
            "alias": alias,
            "question": market.get("question"),
            "outcome": outcome,
            "active": market.get("active"),
            "closed": market.get("closed"),
            "neg_risk": market.get("neg_risk"),
            "tick_size": tick_size if tick_size is not None else 0.01,
            "step_size": step_size if step_size is not None else 1.0,
            "minimum_order_size": step_size if step_size is not None else 1.0,
            "minimum_tick_size": tick_size if tick_size is not None else 0.01,
        }

    def on_response(self, markets: Iterable[dict[str, Any]]) -> dict[str, str]:
        mapping: dict[str, str] = {}
        records: list[dict[str, Any]] = []
        for market in markets or []:
            tokens = market.get("tokens") or []
            if not tokens:
                token_ids = market.get("clobTokenIds") or []
                outcomes = market.get("outcomes") or []

                if isinstance(token_ids, str):
                    try:
                        token_ids = json.loads(token_ids)
                    except json.JSONDecodeError:
                        token_ids = [token_ids]
                if isinstance(outcomes, str):
                    try:
                        outcomes = json.loads(outcomes)
                    except json.JSONDecodeError:
                        outcomes = [outcomes]

                if not isinstance(token_ids, list):
                    token_ids = [token_ids]
                if not isinstance(outcomes, list):
                    outcomes = [outcomes]

                tokens = [
                    {"token_id": tid, "outcome": outcomes[idx] if idx < len(outcomes) else None}
                    for idx, tid in enumerate(token_ids)
                    if tid
                ]

            for token in tokens:
                normalized = self._normalize_entry(market, token)
                slug: str = market.get("slug")
                # 取最后一个'-'之前部分
                base_slug = slug.rsplit("-", 1)[0] if slug else slug
                # Add or update additional fields from market
                normalized.update({
                    "condition_id": market.get("conditionId"),
                    "slug": market.get("slug"),
                    "base_slug": base_slug,
                    "end_date": market.get("endDate"),
                    "start_date": market.get("startDate"),
                    "icon": market.get("icon"),
                    "image": market.get("image"),
                    "liquidity": market.get("liquidityNum") or market.get("liquidity"),
                    "volume": market.get("volumeNum") or market.get("volume"),
                    "accepting_orders": market.get("acceptingOrders"),
                    "spread": market.get("spread"),
                    "best_bid": market.get("bestBid"),
                    "best_ask": market.get("bestAsk"),
                })
                token_id = normalized.get("token_id")
                if not token_id:
                    continue
                records.append(normalized)
                mapping[token_id] = normalized.get("alias") or token_id

        self._update(records)
        return mapping


class PolymarketDataStore(DataStoreCollection):
    """Polymarket-specific DataStore aggregate."""

    def _init(self) -> None:
        self._create("book", datastore_class=Book)
        self._create("bbo", datastore_class=BBO)
        self._create("detail", datastore_class=Detail)
        self._create("position", datastore_class=Position)
        self._create("order", datastore_class=Order)
        self._create("mytrade", datastore_class=MyTrade)
        self._create("fill", datastore_class=Fill)
        self._create("trade", datastore_class=Trade)
        self._create("price", datastore_class=Price)

    def set_owner_key(self, api_key: str | None) -> None:
        self.position.set_owner_key(api_key)

    @property
    def book(self) -> Book:
        """Order Book DataStore
        _key: k (asset_id), S (side), p (price)

        .. code:: json
            [{
                "k": "asset_id",
                "S": "b" | "a",
                "p": "price",
                "q": "size"
            }]
        """
        return self._get("book")

    @property
    def detail(self) -> Detail:
        """
        Market metadata keyed by token id.

        .. code:: json
            
            [
                {
                    "token_id": "14992165475527298486519422865149275159537493330633013685269145597531945526992",
                    "asset_id": "14992165475527298486519422865149275159537493330633013685269145597531945526992",
                    "alias": "Bitcoin Up or Down - November 12, 12:30AM-12:45AM ET:Down",
                    "question": "Bitcoin Up or Down - November 12, 12:30AM-12:45AM ET",
                    "outcome": "Down",
                    "active": true,
                    "closed": false,
                    "neg_risk": null,
                    "tick_size": 0.01,
                    "step_size": 5.0,
                    "minimum_order_size": 5.0,
                    "minimum_tick_size": 0.01,
                    "condition_id": "0xb64133e5ae9710fab2533cfd3c48cba142347e4bab36822964ca4cca4b7660d2",
                    "slug": "btc-updown-15m-1762925400",
                    "end_date": "2025-11-12T05:45:00Z",
                    "start_date": "2025-11-11T05:32:59.491174Z",
                    "icon": "https://polymarket-upload.s3.us-east-2.amazonaws.com/BTC+fullsize.png",
                    "image": "https://polymarket-upload.s3.us-east-2.amazonaws.com/BTC+fullsize.png",
                    "liquidity": 59948.1793,
                    "volume": 12214.600385,
                    "accepting_orders": true,
                    "spread": 0.01,
                    "best_bid": 0.5,
                    "best_ask": 0.51
                }
            ]
        """

        return self._get("detail")
    
    @property
    def position(self) -> Position:
        """
        User inventory snapshot keyed by ``asset`` (token id), updated from
        authenticated User WS ``trade`` events only.

        Notes:
        - Data source: user WS trade events (MATCHED/MINED/CONFIRMED/FAILED).
        - Order stream and REST position sync do not drive inventory.
        - Maker fills are owner-filtered by api key; reconnect duplicates are deduped.
        - FAILED events reverse prior inventory impact.

        .. code:: json
            {
                "asset": "15425820309554596073938947961054885346747932482195187699753650361958599405318",  // token id
                "outcome": "Yes",            // 当前asset对应的outcome名称
                "size": 5.0,                 // 当前asset仓位数量（对应 yes_qty 或 no_qty）
                "avgPrice": 0.47,            // 当前asset均价
                "totalAvgPrice": 0.47,       // 与 avgPrice 同步，兼容旧字段
                "market": "0x...",           // conditionId / market id
                "yes_qty": 5.0,              // YES腿数量
                "no_qty": 3.0,               // NO腿数量
                "yes_avg_cost": 0.47,        // YES腿VWAP成本
                "no_avg_cost": 0.49,         // NO腿VWAP成本
                "net_diff": 2.0,             // 净敞口 = yes_qty - no_qty
                "portfolio_cost": 0.96,      // 组合成本 = yes_avg_cost + no_avg_cost（双腿都有仓时）
                "ts": 1772269014393,         // 本地更新时间戳(ms)
                "source": "user_ws_trade"    // 数据来源标记
            }
        """

        return self._get("position")

    @property
    def orders(self) -> Order:
        """User orders keyed by order id.

        Example row (from REST get_orders):

        .. code:: json
            {
              "id": "0xd4359d…",
              "status": "LIVE",
              "owner": "<api-key>",
              "maker_address": "0x…",
              "market": "0x…",
              "asset_id": "317234…",
              "side": "BUY",
              "original_size": 5.0,
              "size_matched": 0.0,
              "price": 0.02,
              "outcome": "Up",
              "order_type": "GTC",
              "created_at": 1762912331
            }

        """

        return self._get("order")

    @property
    def mytrade(self) -> MyTrade:
        """User trade stream keyed by trade id.

        Columns include Polymarket websocket ``trade`` payloads, e.g.

        .. code:: json
            {
                "event_type": "trade",
                "id": "28c4d2eb-bbea-40e7-a9f0-b2fdb56b2c2e",
                "market": "0xbd31…",
                "asset_id": "521143…",
                "side": "BUY",
                "price": 0.57,
                "size": 10,
                "status": "MATCHED",
                "maker_orders": [ ... ]
            }
        """

        return self._get("mytrade")
    
    @property
    def price(self) -> Price:
        """Price DataStore
        _key: s 
        """
        return self._get("price")

    @property
    def fill(self) -> Fill:
        """Maker-order fills keyed by ``order_id``.

        A row is created whenever a trade arrives with ``status == 'MATCHED'``.
        ``matched_amount`` and ``price`` are stored as floats for quick PnL math.

        .. code:: json
            {
                "order_id": "0xb46574626be7eb57a8fa643eac5623bdb2ec42104e2dc3441576a6ed8d0cc0ed",
                "owner": "1aa9c6be-02d2-c021-c5fc-0c5b64ba8fd6",
                "maker_address": "0x64A46A989363eb21DAB87CD53d57A4567Ccbc103",
                "matched_amount": "1.35",
                "price": "0.73",
                "fee_rate_bps": "0",
                "asset_id": "60833383978754019365794467018212448484210363665632025956221025028271757152271",
                "outcome": "Up",
                "outcome_index": 0,
                "side": "BUY"
            }
        """

        return self._get("fill")
    
    @property
    def bbo(self) -> BBO:
        """Best Bid and Offer DataStore
        _key: s (asset_id), S (side)

        """
        return self._get("bbo")
    
    @property
    def trade(self) -> Trade:
        """
        _key asset
        MATCHED进行快速捕捉
        .. code:: json
           {
                "asset": "12819879685513143002408869746992985182419696851931617234615358342350852997413",
                "bio": "",
                "conditionId": "0xea609d2c6bc2cb20e328be7c89f258b84b35bbe119b44e0a2cfc5f15e6642b3b",
                "eventSlug": "btc-updown-15m-1763865000",
                "icon": "https://polymarket-upload.s3.us-east-2.amazonaws.com/BTC+fullsize.png",
                "name": "infusion",
                "outcome": "Up",
                "outcomeIndex": 0,
                "price": 0.7,
                "profileImage": "",
                "proxyWallet": "0x2C060830B6F6B43174b1Cf8B4475db07703c1543",
                "pseudonym": "Frizzy-Graduate",
                "side": "BUY",
                "size": 5,
                "slug": "btc-updown-15m-1763865000",
                "timestamp": 1763865085,
                "title": "Bitcoin Up or Down - November 22, 9:30PM-9:45PM ET",
                "hash": "0xddea11d695e811686f83379d9269accf1be581fbcb542809c6c67a3cc3002488"
            }
        """
        return self._get("trade")
    

    def onmessage(self, msg: Any, ws: ClientWebSocketResponse | None = None) -> None:
        # 判定msg是否为list
        lst_msg = msg if isinstance(msg, list) else [msg]
        for m in lst_msg:
            if m == '':
                continue
            topic = m.get("topic") or ""
            if topic in {'crypto_prices_chainlink', 'crypto_prices'}:
                self.price._on_message(m)
                continue
            raw_type = m.get("event_type") or m.get("type")
            if not raw_type:
                continue
            msg_type = str(raw_type).lower()
            if msg_type in {"book", "price_change"}:
                self.book._on_message(m)
            elif msg_type == "order":
                self.orders._on_message(m)

            elif msg_type == "trade":
                self.mytrade._on_message(m)
                self.position.on_trade(m)
            elif msg_type == 'orders_matched':
                payload = m.get("payload") or {}
                if not payload:
                    continue
                trade_msg = dict(payload)
                if "asset_id" not in trade_msg and "asset" in trade_msg:
                    trade_msg["asset_id"] = trade_msg["asset"]
                self.trade._on_message(trade_msg)
    
    def onmessage_for_bbo(self, msg: Any, ws: ClientWebSocketResponse | None = None) -> None:
        # 判定msg是否为list
        lst_msg = msg if isinstance(msg, list) else [msg]
        for m in lst_msg:
            raw_type = m.get("event_type") or m.get("type")
            if not raw_type:
                continue
            msg_type = str(raw_type).lower()
            if msg_type in {"book", "price_change"}:
                self.bbo._on_message(m)

    def onmessage_for_last_trade(self, msg, ws = None):
        # 判定msg是否为list
        lst_msg = msg if isinstance(msg, list) else [msg]
        for m in lst_msg:
            raw_type = m.get("event_type") or m.get("type")
            if not raw_type:
                continue
            msg_type = str(raw_type).lower()
            if msg_type == "last_trade_price":
                self.trade._on_message(m)
