import sys
from . import xlwings_utils
xlwings_utils.main(sys.argv[1:])