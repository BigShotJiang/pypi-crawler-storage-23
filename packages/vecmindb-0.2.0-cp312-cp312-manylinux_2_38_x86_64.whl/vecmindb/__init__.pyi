from typing import List, Dict, Optional, Any, Union

class VectorDB:
    def __init__(self, path: str): ...
    
    def create_collection(self, name: str, dimension: usize, index_type: str = "hnsw") -> None: ...
    
    def insert(self, collection_name: str, id: str, vector: List[float]) -> None: ...
    
    def search(self, collection_name: str, query: List[float], k: int) -> List[Dict[str, Any]]: ...
    
    def auto_tune(
        self, 
        target: str = "balanced", 
        algorithm: str = "nsga2", 
        iterations: int = 5, 
        params: Optional[Dict[str, float]] = None
    ) -> Dict[str, Any]: ...
    
    def stats(self) -> str: ...
