from google.protobuf import empty_pb2 as _empty_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class EntityBankAccountDestroyRequest(_message.Message):
    __slots__ = ("entitybankaccount_id",)
    ENTITYBANKACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    entitybankaccount_id: str
    def __init__(self, entitybankaccount_id: _Optional[str] = ...) -> None: ...

class EntityBankAccountListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class EntityBankAccountListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[EntityBankAccountResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[EntityBankAccountResponse, _Mapping]]] = ...) -> None: ...

class EntityBankAccountPartialUpdateRequest(_message.Message):
    __slots__ = ("entitybankaccount_id", "bank", "data_extra", "_partial_update_fields", "name_account", "account_no", "iban", "bic", "description", "datetime_last_modified")
    ENTITYBANKACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    BANK_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_ACCOUNT_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_NO_FIELD_NUMBER: _ClassVar[int]
    IBAN_FIELD_NUMBER: _ClassVar[int]
    BIC_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    entitybankaccount_id: str
    bank: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_account: str
    account_no: str
    iban: str
    bic: str
    description: str
    datetime_last_modified: str
    def __init__(self, entitybankaccount_id: _Optional[str] = ..., bank: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name_account: _Optional[str] = ..., account_no: _Optional[str] = ..., iban: _Optional[str] = ..., bic: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ...) -> None: ...

class EntityBankAccountRequest(_message.Message):
    __slots__ = ("entitybankaccount_id", "bank", "data_extra", "name_account", "account_no", "iban", "bic", "description", "datetime_last_modified")
    ENTITYBANKACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    BANK_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_ACCOUNT_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_NO_FIELD_NUMBER: _ClassVar[int]
    IBAN_FIELD_NUMBER: _ClassVar[int]
    BIC_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    entitybankaccount_id: str
    bank: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name_account: str
    account_no: str
    iban: str
    bic: str
    description: str
    datetime_last_modified: str
    def __init__(self, entitybankaccount_id: _Optional[str] = ..., bank: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., name_account: _Optional[str] = ..., account_no: _Optional[str] = ..., iban: _Optional[str] = ..., bic: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ...) -> None: ...

class EntityBankAccountResponse(_message.Message):
    __slots__ = ("entitybankaccount_id", "bank", "data_extra", "name_account", "account_no", "iban", "bic", "description", "datetime_last_modified")
    ENTITYBANKACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    BANK_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_ACCOUNT_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_NO_FIELD_NUMBER: _ClassVar[int]
    IBAN_FIELD_NUMBER: _ClassVar[int]
    BIC_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    entitybankaccount_id: str
    bank: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name_account: str
    account_no: str
    iban: str
    bic: str
    description: str
    datetime_last_modified: str
    def __init__(self, entitybankaccount_id: _Optional[str] = ..., bank: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., name_account: _Optional[str] = ..., account_no: _Optional[str] = ..., iban: _Optional[str] = ..., bic: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ...) -> None: ...

class EntityBankAccountRetrieveRequest(_message.Message):
    __slots__ = ("entitybankaccount_id",)
    ENTITYBANKACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    entitybankaccount_id: str
    def __init__(self, entitybankaccount_id: _Optional[str] = ...) -> None: ...

class EntityBankAccountStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class EntityClassDestroyRequest(_message.Message):
    __slots__ = ("entityclass_id",)
    ENTITYCLASS_ID_FIELD_NUMBER: _ClassVar[int]
    entityclass_id: str
    def __init__(self, entityclass_id: _Optional[str] = ...) -> None: ...

class EntityClassListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class EntityClassListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[EntityClassResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[EntityClassResponse, _Mapping]]] = ...) -> None: ...

class EntityClassPartialUpdateRequest(_message.Message):
    __slots__ = ("entityclass_id", "_partial_update_fields", "name", "iri", "description")
    ENTITYCLASS_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    entityclass_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    iri: str
    description: str
    def __init__(self, entityclass_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class EntityClassRequest(_message.Message):
    __slots__ = ("entityclass_id", "name", "iri", "description")
    ENTITYCLASS_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    entityclass_id: str
    name: str
    iri: str
    description: str
    def __init__(self, entityclass_id: _Optional[str] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class EntityClassResponse(_message.Message):
    __slots__ = ("entityclass_id", "name", "iri", "description")
    ENTITYCLASS_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    entityclass_id: str
    name: str
    iri: str
    description: str
    def __init__(self, entityclass_id: _Optional[str] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class EntityClassRetrieveRequest(_message.Message):
    __slots__ = ("entityclass_id",)
    ENTITYCLASS_ID_FIELD_NUMBER: _ClassVar[int]
    entityclass_id: str
    def __init__(self, entityclass_id: _Optional[str] = ...) -> None: ...

class EntityClassStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class EntityDestroyRequest(_message.Message):
    __slots__ = ("entity_id",)
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    entity_id: str
    def __init__(self, entity_id: _Optional[str] = ...) -> None: ...

class EntityListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class EntityListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[EntityResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[EntityResponse, _Mapping]]] = ...) -> None: ...

class EntityPartialUpdateRequest(_message.Message):
    __slots__ = ("entity_id", "entity_class", "bank_accounts", "expertise", "interests", "work_topics", "roles", "affiliation_current", "affiliation_previous", "office_room", "laboratory", "address", "data_extra", "_partial_update_fields", "slug", "gender", "title", "name_first", "names_middle", "name_last", "name_full", "names_last_previous", "name_nick", "acronym", "url", "pid", "pac_id", "iri", "orcid", "ror", "barcode", "barcode_json", "tax_no", "vat_no", "toll_no", "interests_json", "affiliation_start", "affiliation_end", "email", "email_private", "email_permanent", "website", "phone_number_mobile", "phone_number_office", "phone_number_lab", "phone_number_home", "date_birth", "date_death", "color", "icon", "image", "datetime_last_modified", "remarks", "search_vector")
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    ENTITY_CLASS_FIELD_NUMBER: _ClassVar[int]
    BANK_ACCOUNTS_FIELD_NUMBER: _ClassVar[int]
    EXPERTISE_FIELD_NUMBER: _ClassVar[int]
    INTERESTS_FIELD_NUMBER: _ClassVar[int]
    WORK_TOPICS_FIELD_NUMBER: _ClassVar[int]
    ROLES_FIELD_NUMBER: _ClassVar[int]
    AFFILIATION_CURRENT_FIELD_NUMBER: _ClassVar[int]
    AFFILIATION_PREVIOUS_FIELD_NUMBER: _ClassVar[int]
    OFFICE_ROOM_FIELD_NUMBER: _ClassVar[int]
    LABORATORY_FIELD_NUMBER: _ClassVar[int]
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    SLUG_FIELD_NUMBER: _ClassVar[int]
    GENDER_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIRST_FIELD_NUMBER: _ClassVar[int]
    NAMES_MIDDLE_FIELD_NUMBER: _ClassVar[int]
    NAME_LAST_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    NAMES_LAST_PREVIOUS_FIELD_NUMBER: _ClassVar[int]
    NAME_NICK_FIELD_NUMBER: _ClassVar[int]
    ACRONYM_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    ORCID_FIELD_NUMBER: _ClassVar[int]
    ROR_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    TAX_NO_FIELD_NUMBER: _ClassVar[int]
    VAT_NO_FIELD_NUMBER: _ClassVar[int]
    TOLL_NO_FIELD_NUMBER: _ClassVar[int]
    INTERESTS_JSON_FIELD_NUMBER: _ClassVar[int]
    AFFILIATION_START_FIELD_NUMBER: _ClassVar[int]
    AFFILIATION_END_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    EMAIL_PRIVATE_FIELD_NUMBER: _ClassVar[int]
    EMAIL_PERMANENT_FIELD_NUMBER: _ClassVar[int]
    WEBSITE_FIELD_NUMBER: _ClassVar[int]
    PHONE_NUMBER_MOBILE_FIELD_NUMBER: _ClassVar[int]
    PHONE_NUMBER_OFFICE_FIELD_NUMBER: _ClassVar[int]
    PHONE_NUMBER_LAB_FIELD_NUMBER: _ClassVar[int]
    PHONE_NUMBER_HOME_FIELD_NUMBER: _ClassVar[int]
    DATE_BIRTH_FIELD_NUMBER: _ClassVar[int]
    DATE_DEATH_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    entity_id: str
    entity_class: str
    bank_accounts: _containers.RepeatedScalarFieldContainer[str]
    expertise: _containers.RepeatedScalarFieldContainer[str]
    interests: _containers.RepeatedScalarFieldContainer[str]
    work_topics: _containers.RepeatedScalarFieldContainer[str]
    roles: _containers.RepeatedScalarFieldContainer[str]
    affiliation_current: str
    affiliation_previous: _containers.RepeatedScalarFieldContainer[str]
    office_room: str
    laboratory: str
    address: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    slug: str
    gender: str
    title: str
    name_first: str
    names_middle: str
    name_last: str
    name_full: str
    names_last_previous: str
    name_nick: str
    acronym: str
    url: str
    pid: str
    pac_id: str
    iri: str
    orcid: str
    ror: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    tax_no: str
    vat_no: str
    toll_no: str
    interests_json: _struct_pb2.Struct
    affiliation_start: str
    affiliation_end: str
    email: str
    email_private: str
    email_permanent: str
    website: str
    phone_number_mobile: str
    phone_number_office: str
    phone_number_lab: str
    phone_number_home: str
    date_birth: str
    date_death: str
    color: str
    icon: str
    image: str
    datetime_last_modified: str
    remarks: str
    search_vector: str
    def __init__(self, entity_id: _Optional[str] = ..., entity_class: _Optional[str] = ..., bank_accounts: _Optional[_Iterable[str]] = ..., expertise: _Optional[_Iterable[str]] = ..., interests: _Optional[_Iterable[str]] = ..., work_topics: _Optional[_Iterable[str]] = ..., roles: _Optional[_Iterable[str]] = ..., affiliation_current: _Optional[str] = ..., affiliation_previous: _Optional[_Iterable[str]] = ..., office_room: _Optional[str] = ..., laboratory: _Optional[str] = ..., address: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., slug: _Optional[str] = ..., gender: _Optional[str] = ..., title: _Optional[str] = ..., name_first: _Optional[str] = ..., names_middle: _Optional[str] = ..., name_last: _Optional[str] = ..., name_full: _Optional[str] = ..., names_last_previous: _Optional[str] = ..., name_nick: _Optional[str] = ..., acronym: _Optional[str] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., iri: _Optional[str] = ..., orcid: _Optional[str] = ..., ror: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., tax_no: _Optional[str] = ..., vat_no: _Optional[str] = ..., toll_no: _Optional[str] = ..., interests_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., affiliation_start: _Optional[str] = ..., affiliation_end: _Optional[str] = ..., email: _Optional[str] = ..., email_private: _Optional[str] = ..., email_permanent: _Optional[str] = ..., website: _Optional[str] = ..., phone_number_mobile: _Optional[str] = ..., phone_number_office: _Optional[str] = ..., phone_number_lab: _Optional[str] = ..., phone_number_home: _Optional[str] = ..., date_birth: _Optional[str] = ..., date_death: _Optional[str] = ..., color: _Optional[str] = ..., icon: _Optional[str] = ..., image: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., remarks: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class EntityRequest(_message.Message):
    __slots__ = ("entity_id", "entity_class", "bank_accounts", "expertise", "interests", "work_topics", "roles", "affiliation_current", "affiliation_previous", "office_room", "laboratory", "address", "data_extra", "slug", "gender", "title", "name_first", "names_middle", "name_last", "name_full", "names_last_previous", "name_nick", "acronym", "url", "pid", "pac_id", "iri", "orcid", "ror", "barcode", "barcode_json", "tax_no", "vat_no", "toll_no", "interests_json", "affiliation_start", "affiliation_end", "email", "email_private", "email_permanent", "website", "phone_number_mobile", "phone_number_office", "phone_number_lab", "phone_number_home", "date_birth", "date_death", "color", "icon", "image", "datetime_last_modified", "remarks", "search_vector")
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    ENTITY_CLASS_FIELD_NUMBER: _ClassVar[int]
    BANK_ACCOUNTS_FIELD_NUMBER: _ClassVar[int]
    EXPERTISE_FIELD_NUMBER: _ClassVar[int]
    INTERESTS_FIELD_NUMBER: _ClassVar[int]
    WORK_TOPICS_FIELD_NUMBER: _ClassVar[int]
    ROLES_FIELD_NUMBER: _ClassVar[int]
    AFFILIATION_CURRENT_FIELD_NUMBER: _ClassVar[int]
    AFFILIATION_PREVIOUS_FIELD_NUMBER: _ClassVar[int]
    OFFICE_ROOM_FIELD_NUMBER: _ClassVar[int]
    LABORATORY_FIELD_NUMBER: _ClassVar[int]
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    SLUG_FIELD_NUMBER: _ClassVar[int]
    GENDER_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIRST_FIELD_NUMBER: _ClassVar[int]
    NAMES_MIDDLE_FIELD_NUMBER: _ClassVar[int]
    NAME_LAST_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    NAMES_LAST_PREVIOUS_FIELD_NUMBER: _ClassVar[int]
    NAME_NICK_FIELD_NUMBER: _ClassVar[int]
    ACRONYM_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    ORCID_FIELD_NUMBER: _ClassVar[int]
    ROR_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    TAX_NO_FIELD_NUMBER: _ClassVar[int]
    VAT_NO_FIELD_NUMBER: _ClassVar[int]
    TOLL_NO_FIELD_NUMBER: _ClassVar[int]
    INTERESTS_JSON_FIELD_NUMBER: _ClassVar[int]
    AFFILIATION_START_FIELD_NUMBER: _ClassVar[int]
    AFFILIATION_END_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    EMAIL_PRIVATE_FIELD_NUMBER: _ClassVar[int]
    EMAIL_PERMANENT_FIELD_NUMBER: _ClassVar[int]
    WEBSITE_FIELD_NUMBER: _ClassVar[int]
    PHONE_NUMBER_MOBILE_FIELD_NUMBER: _ClassVar[int]
    PHONE_NUMBER_OFFICE_FIELD_NUMBER: _ClassVar[int]
    PHONE_NUMBER_LAB_FIELD_NUMBER: _ClassVar[int]
    PHONE_NUMBER_HOME_FIELD_NUMBER: _ClassVar[int]
    DATE_BIRTH_FIELD_NUMBER: _ClassVar[int]
    DATE_DEATH_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    entity_id: str
    entity_class: str
    bank_accounts: _containers.RepeatedScalarFieldContainer[str]
    expertise: _containers.RepeatedScalarFieldContainer[str]
    interests: _containers.RepeatedScalarFieldContainer[str]
    work_topics: _containers.RepeatedScalarFieldContainer[str]
    roles: _containers.RepeatedScalarFieldContainer[str]
    affiliation_current: str
    affiliation_previous: _containers.RepeatedScalarFieldContainer[str]
    office_room: str
    laboratory: str
    address: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    slug: str
    gender: str
    title: str
    name_first: str
    names_middle: str
    name_last: str
    name_full: str
    names_last_previous: str
    name_nick: str
    acronym: str
    url: str
    pid: str
    pac_id: str
    iri: str
    orcid: str
    ror: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    tax_no: str
    vat_no: str
    toll_no: str
    interests_json: _struct_pb2.Struct
    affiliation_start: str
    affiliation_end: str
    email: str
    email_private: str
    email_permanent: str
    website: str
    phone_number_mobile: str
    phone_number_office: str
    phone_number_lab: str
    phone_number_home: str
    date_birth: str
    date_death: str
    color: str
    icon: str
    image: str
    datetime_last_modified: str
    remarks: str
    search_vector: str
    def __init__(self, entity_id: _Optional[str] = ..., entity_class: _Optional[str] = ..., bank_accounts: _Optional[_Iterable[str]] = ..., expertise: _Optional[_Iterable[str]] = ..., interests: _Optional[_Iterable[str]] = ..., work_topics: _Optional[_Iterable[str]] = ..., roles: _Optional[_Iterable[str]] = ..., affiliation_current: _Optional[str] = ..., affiliation_previous: _Optional[_Iterable[str]] = ..., office_room: _Optional[str] = ..., laboratory: _Optional[str] = ..., address: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., slug: _Optional[str] = ..., gender: _Optional[str] = ..., title: _Optional[str] = ..., name_first: _Optional[str] = ..., names_middle: _Optional[str] = ..., name_last: _Optional[str] = ..., name_full: _Optional[str] = ..., names_last_previous: _Optional[str] = ..., name_nick: _Optional[str] = ..., acronym: _Optional[str] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., iri: _Optional[str] = ..., orcid: _Optional[str] = ..., ror: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., tax_no: _Optional[str] = ..., vat_no: _Optional[str] = ..., toll_no: _Optional[str] = ..., interests_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., affiliation_start: _Optional[str] = ..., affiliation_end: _Optional[str] = ..., email: _Optional[str] = ..., email_private: _Optional[str] = ..., email_permanent: _Optional[str] = ..., website: _Optional[str] = ..., phone_number_mobile: _Optional[str] = ..., phone_number_office: _Optional[str] = ..., phone_number_lab: _Optional[str] = ..., phone_number_home: _Optional[str] = ..., date_birth: _Optional[str] = ..., date_death: _Optional[str] = ..., color: _Optional[str] = ..., icon: _Optional[str] = ..., image: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., remarks: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class EntityResponse(_message.Message):
    __slots__ = ("entity_id", "entity_class", "bank_accounts", "expertise", "interests", "work_topics", "roles", "affiliation_current", "affiliation_previous", "office_room", "laboratory", "address", "data_extra", "slug", "gender", "title", "name_first", "names_middle", "name_last", "name_full", "names_last_previous", "name_nick", "acronym", "url", "pid", "pac_id", "iri", "orcid", "ror", "barcode", "barcode_json", "tax_no", "vat_no", "toll_no", "interests_json", "affiliation_start", "affiliation_end", "email", "email_private", "email_permanent", "website", "phone_number_mobile", "phone_number_office", "phone_number_lab", "phone_number_home", "date_birth", "date_death", "color", "icon", "image", "datetime_last_modified", "remarks", "search_vector")
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    ENTITY_CLASS_FIELD_NUMBER: _ClassVar[int]
    BANK_ACCOUNTS_FIELD_NUMBER: _ClassVar[int]
    EXPERTISE_FIELD_NUMBER: _ClassVar[int]
    INTERESTS_FIELD_NUMBER: _ClassVar[int]
    WORK_TOPICS_FIELD_NUMBER: _ClassVar[int]
    ROLES_FIELD_NUMBER: _ClassVar[int]
    AFFILIATION_CURRENT_FIELD_NUMBER: _ClassVar[int]
    AFFILIATION_PREVIOUS_FIELD_NUMBER: _ClassVar[int]
    OFFICE_ROOM_FIELD_NUMBER: _ClassVar[int]
    LABORATORY_FIELD_NUMBER: _ClassVar[int]
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    SLUG_FIELD_NUMBER: _ClassVar[int]
    GENDER_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIRST_FIELD_NUMBER: _ClassVar[int]
    NAMES_MIDDLE_FIELD_NUMBER: _ClassVar[int]
    NAME_LAST_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    NAMES_LAST_PREVIOUS_FIELD_NUMBER: _ClassVar[int]
    NAME_NICK_FIELD_NUMBER: _ClassVar[int]
    ACRONYM_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    ORCID_FIELD_NUMBER: _ClassVar[int]
    ROR_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    TAX_NO_FIELD_NUMBER: _ClassVar[int]
    VAT_NO_FIELD_NUMBER: _ClassVar[int]
    TOLL_NO_FIELD_NUMBER: _ClassVar[int]
    INTERESTS_JSON_FIELD_NUMBER: _ClassVar[int]
    AFFILIATION_START_FIELD_NUMBER: _ClassVar[int]
    AFFILIATION_END_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    EMAIL_PRIVATE_FIELD_NUMBER: _ClassVar[int]
    EMAIL_PERMANENT_FIELD_NUMBER: _ClassVar[int]
    WEBSITE_FIELD_NUMBER: _ClassVar[int]
    PHONE_NUMBER_MOBILE_FIELD_NUMBER: _ClassVar[int]
    PHONE_NUMBER_OFFICE_FIELD_NUMBER: _ClassVar[int]
    PHONE_NUMBER_LAB_FIELD_NUMBER: _ClassVar[int]
    PHONE_NUMBER_HOME_FIELD_NUMBER: _ClassVar[int]
    DATE_BIRTH_FIELD_NUMBER: _ClassVar[int]
    DATE_DEATH_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    entity_id: str
    entity_class: str
    bank_accounts: _containers.RepeatedScalarFieldContainer[str]
    expertise: _containers.RepeatedScalarFieldContainer[str]
    interests: _containers.RepeatedScalarFieldContainer[str]
    work_topics: _containers.RepeatedScalarFieldContainer[str]
    roles: _containers.RepeatedScalarFieldContainer[str]
    affiliation_current: str
    affiliation_previous: _containers.RepeatedScalarFieldContainer[str]
    office_room: str
    laboratory: str
    address: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    slug: str
    gender: str
    title: str
    name_first: str
    names_middle: str
    name_last: str
    name_full: str
    names_last_previous: str
    name_nick: str
    acronym: str
    url: str
    pid: str
    pac_id: str
    iri: str
    orcid: str
    ror: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    tax_no: str
    vat_no: str
    toll_no: str
    interests_json: _struct_pb2.Struct
    affiliation_start: str
    affiliation_end: str
    email: str
    email_private: str
    email_permanent: str
    website: str
    phone_number_mobile: str
    phone_number_office: str
    phone_number_lab: str
    phone_number_home: str
    date_birth: str
    date_death: str
    color: str
    icon: str
    image: str
    datetime_last_modified: str
    remarks: str
    search_vector: str
    def __init__(self, entity_id: _Optional[str] = ..., entity_class: _Optional[str] = ..., bank_accounts: _Optional[_Iterable[str]] = ..., expertise: _Optional[_Iterable[str]] = ..., interests: _Optional[_Iterable[str]] = ..., work_topics: _Optional[_Iterable[str]] = ..., roles: _Optional[_Iterable[str]] = ..., affiliation_current: _Optional[str] = ..., affiliation_previous: _Optional[_Iterable[str]] = ..., office_room: _Optional[str] = ..., laboratory: _Optional[str] = ..., address: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., slug: _Optional[str] = ..., gender: _Optional[str] = ..., title: _Optional[str] = ..., name_first: _Optional[str] = ..., names_middle: _Optional[str] = ..., name_last: _Optional[str] = ..., name_full: _Optional[str] = ..., names_last_previous: _Optional[str] = ..., name_nick: _Optional[str] = ..., acronym: _Optional[str] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., iri: _Optional[str] = ..., orcid: _Optional[str] = ..., ror: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., tax_no: _Optional[str] = ..., vat_no: _Optional[str] = ..., toll_no: _Optional[str] = ..., interests_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., affiliation_start: _Optional[str] = ..., affiliation_end: _Optional[str] = ..., email: _Optional[str] = ..., email_private: _Optional[str] = ..., email_permanent: _Optional[str] = ..., website: _Optional[str] = ..., phone_number_mobile: _Optional[str] = ..., phone_number_office: _Optional[str] = ..., phone_number_lab: _Optional[str] = ..., phone_number_home: _Optional[str] = ..., date_birth: _Optional[str] = ..., date_death: _Optional[str] = ..., color: _Optional[str] = ..., icon: _Optional[str] = ..., image: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., remarks: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class EntityRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class EntityRetrieveRequest(_message.Message):
    __slots__ = ("entity_id",)
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    entity_id: str
    def __init__(self, entity_id: _Optional[str] = ...) -> None: ...

class EntityRoleDestroyRequest(_message.Message):
    __slots__ = ("entityrole_id",)
    ENTITYROLE_ID_FIELD_NUMBER: _ClassVar[int]
    entityrole_id: str
    def __init__(self, entityrole_id: _Optional[str] = ...) -> None: ...

class EntityRoleListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class EntityRoleListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[EntityRoleResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[EntityRoleResponse, _Mapping]]] = ...) -> None: ...

class EntityRolePartialUpdateRequest(_message.Message):
    __slots__ = ("entityrole_id", "_partial_update_fields", "name", "iri", "description")
    ENTITYROLE_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    entityrole_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    iri: str
    description: str
    def __init__(self, entityrole_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class EntityRoleRequest(_message.Message):
    __slots__ = ("entityrole_id", "name", "iri", "description")
    ENTITYROLE_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    entityrole_id: str
    name: str
    iri: str
    description: str
    def __init__(self, entityrole_id: _Optional[str] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class EntityRoleResponse(_message.Message):
    __slots__ = ("entityrole_id", "name", "iri", "description")
    ENTITYROLE_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    entityrole_id: str
    name: str
    iri: str
    description: str
    def __init__(self, entityrole_id: _Optional[str] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class EntityRoleRetrieveRequest(_message.Message):
    __slots__ = ("entityrole_id",)
    ENTITYROLE_ID_FIELD_NUMBER: _ClassVar[int]
    entityrole_id: str
    def __init__(self, entityrole_id: _Optional[str] = ...) -> None: ...

class EntityRoleStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class EntityStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ExtraDataDestroyRequest(_message.Message):
    __slots__ = ("extradata_id",)
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    def __init__(self, extradata_id: _Optional[str] = ...) -> None: ...

class ExtraDataListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ExtraDataListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ExtraDataResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ExtraDataResponse, _Mapping]]] = ...) -> None: ...

class ExtraDataPartialUpdateRequest(_message.Message):
    __slots__ = ("extradata_id", "data_type", "namespace", "media_type", "_partial_update_fields", "name_display", "name", "name_full", "version", "hash_sha256", "data_json", "iri", "url", "datetime_created", "datetime_last_modified", "description", "search_vector", "file", "image", "email", "office_room", "laboratory")
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    OFFICE_ROOM_FIELD_NUMBER: _ClassVar[int]
    LABORATORY_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    data_type: str
    namespace: str
    media_type: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    search_vector: str
    file: str
    image: str
    email: str
    office_room: str
    laboratory: str
    def __init__(self, extradata_id: _Optional[str] = ..., data_type: _Optional[str] = ..., namespace: _Optional[str] = ..., media_type: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., search_vector: _Optional[str] = ..., file: _Optional[str] = ..., image: _Optional[str] = ..., email: _Optional[str] = ..., office_room: _Optional[str] = ..., laboratory: _Optional[str] = ...) -> None: ...

class ExtraDataRequest(_message.Message):
    __slots__ = ("extradata_id", "data_type", "namespace", "media_type", "name_display", "name", "name_full", "version", "hash_sha256", "data_json", "iri", "url", "datetime_created", "datetime_last_modified", "description", "search_vector", "file", "image", "email", "office_room", "laboratory")
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    OFFICE_ROOM_FIELD_NUMBER: _ClassVar[int]
    LABORATORY_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    data_type: str
    namespace: str
    media_type: str
    name_display: str
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    search_vector: str
    file: str
    image: str
    email: str
    office_room: str
    laboratory: str
    def __init__(self, extradata_id: _Optional[str] = ..., data_type: _Optional[str] = ..., namespace: _Optional[str] = ..., media_type: _Optional[str] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., search_vector: _Optional[str] = ..., file: _Optional[str] = ..., image: _Optional[str] = ..., email: _Optional[str] = ..., office_room: _Optional[str] = ..., laboratory: _Optional[str] = ...) -> None: ...

class ExtraDataResponse(_message.Message):
    __slots__ = ("extradata_id", "data_type", "namespace", "media_type", "name_display", "name", "name_full", "version", "hash_sha256", "data_json", "iri", "url", "datetime_created", "datetime_last_modified", "description", "search_vector", "file", "image", "email", "office_room", "laboratory")
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    OFFICE_ROOM_FIELD_NUMBER: _ClassVar[int]
    LABORATORY_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    data_type: str
    namespace: str
    media_type: str
    name_display: str
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    search_vector: str
    file: str
    image: str
    email: str
    office_room: str
    laboratory: str
    def __init__(self, extradata_id: _Optional[str] = ..., data_type: _Optional[str] = ..., namespace: _Optional[str] = ..., media_type: _Optional[str] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., search_vector: _Optional[str] = ..., file: _Optional[str] = ..., image: _Optional[str] = ..., email: _Optional[str] = ..., office_room: _Optional[str] = ..., laboratory: _Optional[str] = ...) -> None: ...

class ExtraDataRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class ExtraDataRetrieveRequest(_message.Message):
    __slots__ = ("extradata_id",)
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    def __init__(self, extradata_id: _Optional[str] = ...) -> None: ...

class ExtraDataStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class FileDownloadChunk(_message.Message):
    __slots__ = ("filename", "data", "success")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    filename: str
    data: bytes
    success: bool
    def __init__(self, filename: _Optional[str] = ..., data: _Optional[bytes] = ..., success: bool = ...) -> None: ...

class FileDownloadInfo(_message.Message):
    __slots__ = ("item_id", "chunk_size")
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    CHUNK_SIZE_FIELD_NUMBER: _ClassVar[int]
    item_id: str
    chunk_size: int
    def __init__(self, item_id: _Optional[str] = ..., chunk_size: _Optional[int] = ...) -> None: ...

class FileUploadChunk(_message.Message):
    __slots__ = ("filename", "update_item_id", "data")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    UPDATE_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    filename: str
    update_item_id: str
    data: bytes
    def __init__(self, filename: _Optional[str] = ..., update_item_id: _Optional[str] = ..., data: _Optional[bytes] = ...) -> None: ...

class FileUploadInfo(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class GroupDestroyRequest(_message.Message):
    __slots__ = ("group_id",)
    GROUP_ID_FIELD_NUMBER: _ClassVar[int]
    group_id: str
    def __init__(self, group_id: _Optional[str] = ...) -> None: ...

class GroupListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GroupListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[GroupResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[GroupResponse, _Mapping]]] = ...) -> None: ...

class GroupPartialUpdateRequest(_message.Message):
    __slots__ = ("group_id", "namespace", "group_class", "members", "_partial_update_fields", "name", "name_full", "description", "remarks", "datetime_last_modified", "search_vector", "django_group")
    GROUP_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_CLASS_FIELD_NUMBER: _ClassVar[int]
    MEMBERS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    DJANGO_GROUP_FIELD_NUMBER: _ClassVar[int]
    group_id: str
    namespace: str
    group_class: str
    members: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    name_full: str
    description: str
    remarks: str
    datetime_last_modified: str
    search_vector: str
    django_group: int
    def __init__(self, group_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group_class: _Optional[str] = ..., members: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., search_vector: _Optional[str] = ..., django_group: _Optional[int] = ...) -> None: ...

class GroupRequest(_message.Message):
    __slots__ = ("group_id", "namespace", "group_class", "members", "name", "name_full", "description", "remarks", "datetime_last_modified", "search_vector", "django_group")
    GROUP_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_CLASS_FIELD_NUMBER: _ClassVar[int]
    MEMBERS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    DJANGO_GROUP_FIELD_NUMBER: _ClassVar[int]
    group_id: str
    namespace: str
    group_class: str
    members: _containers.RepeatedScalarFieldContainer[str]
    name: str
    name_full: str
    description: str
    remarks: str
    datetime_last_modified: str
    search_vector: str
    django_group: int
    def __init__(self, group_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group_class: _Optional[str] = ..., members: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., search_vector: _Optional[str] = ..., django_group: _Optional[int] = ...) -> None: ...

class GroupResponse(_message.Message):
    __slots__ = ("group_id", "namespace", "group_class", "members", "name", "name_full", "description", "remarks", "datetime_last_modified", "search_vector", "django_group")
    GROUP_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_CLASS_FIELD_NUMBER: _ClassVar[int]
    MEMBERS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    DJANGO_GROUP_FIELD_NUMBER: _ClassVar[int]
    group_id: str
    namespace: str
    group_class: str
    members: _containers.RepeatedScalarFieldContainer[str]
    name: str
    name_full: str
    description: str
    remarks: str
    datetime_last_modified: str
    search_vector: str
    django_group: int
    def __init__(self, group_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group_class: _Optional[str] = ..., members: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., search_vector: _Optional[str] = ..., django_group: _Optional[int] = ...) -> None: ...

class GroupRetrieveRequest(_message.Message):
    __slots__ = ("group_id",)
    GROUP_ID_FIELD_NUMBER: _ClassVar[int]
    group_id: str
    def __init__(self, group_id: _Optional[str] = ...) -> None: ...

class GroupStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ImageDownloadChunk(_message.Message):
    __slots__ = ("filename_image", "data", "success")
    FILENAME_IMAGE_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    filename_image: str
    data: bytes
    success: bool
    def __init__(self, filename_image: _Optional[str] = ..., data: _Optional[bytes] = ..., success: bool = ...) -> None: ...

class ImageDownloadInfo(_message.Message):
    __slots__ = ("item_id", "chunk_size")
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    CHUNK_SIZE_FIELD_NUMBER: _ClassVar[int]
    item_id: str
    chunk_size: int
    def __init__(self, item_id: _Optional[str] = ..., chunk_size: _Optional[int] = ...) -> None: ...

class ImageUploadChunk(_message.Message):
    __slots__ = ("filename", "update_item_id", "data")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    UPDATE_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    filename: str
    update_item_id: str
    data: bytes
    def __init__(self, filename: _Optional[str] = ..., update_item_id: _Optional[str] = ..., data: _Optional[bytes] = ...) -> None: ...

class ImageUploadInfo(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class LaraUserDestroyRequest(_message.Message):
    __slots__ = ("larauser_id",)
    LARAUSER_ID_FIELD_NUMBER: _ClassVar[int]
    larauser_id: str
    def __init__(self, larauser_id: _Optional[str] = ...) -> None: ...

class LaraUserListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class LaraUserListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[LaraUserResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[LaraUserResponse, _Mapping]]] = ...) -> None: ...

class LaraUserPartialUpdateRequest(_message.Message):
    __slots__ = ("larauser_id", "entity", "_partial_update_fields", "password", "last_login", "is_superuser", "username", "first_name", "last_name", "email", "is_staff", "is_active", "date_joined", "home_screen_url", "home_screen_layout", "ui_color_scheme", "access_token", "access_control", "confirmation_token", "email_confirmed", "email_recover", "max_logins", "failed_logins", "ip_curr_login", "ip_last_login", "messenger_configuration", "datetime_confirmed", "datetime_confirmation_sent", "namespace_default", "groups", "user_permissions")
    LARAUSER_ID_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    PASSWORD_FIELD_NUMBER: _ClassVar[int]
    LAST_LOGIN_FIELD_NUMBER: _ClassVar[int]
    IS_SUPERUSER_FIELD_NUMBER: _ClassVar[int]
    USERNAME_FIELD_NUMBER: _ClassVar[int]
    FIRST_NAME_FIELD_NUMBER: _ClassVar[int]
    LAST_NAME_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    IS_STAFF_FIELD_NUMBER: _ClassVar[int]
    IS_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    DATE_JOINED_FIELD_NUMBER: _ClassVar[int]
    HOME_SCREEN_URL_FIELD_NUMBER: _ClassVar[int]
    HOME_SCREEN_LAYOUT_FIELD_NUMBER: _ClassVar[int]
    UI_COLOR_SCHEME_FIELD_NUMBER: _ClassVar[int]
    ACCESS_TOKEN_FIELD_NUMBER: _ClassVar[int]
    ACCESS_CONTROL_FIELD_NUMBER: _ClassVar[int]
    CONFIRMATION_TOKEN_FIELD_NUMBER: _ClassVar[int]
    EMAIL_CONFIRMED_FIELD_NUMBER: _ClassVar[int]
    EMAIL_RECOVER_FIELD_NUMBER: _ClassVar[int]
    MAX_LOGINS_FIELD_NUMBER: _ClassVar[int]
    FAILED_LOGINS_FIELD_NUMBER: _ClassVar[int]
    IP_CURR_LOGIN_FIELD_NUMBER: _ClassVar[int]
    IP_LAST_LOGIN_FIELD_NUMBER: _ClassVar[int]
    MESSENGER_CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CONFIRMED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CONFIRMATION_SENT_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_DEFAULT_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    USER_PERMISSIONS_FIELD_NUMBER: _ClassVar[int]
    larauser_id: str
    entity: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    password: str
    last_login: str
    is_superuser: bool
    username: str
    first_name: str
    last_name: str
    email: str
    is_staff: bool
    is_active: bool
    date_joined: str
    home_screen_url: str
    home_screen_layout: _struct_pb2.Struct
    ui_color_scheme: _struct_pb2.Struct
    access_token: str
    access_control: _struct_pb2.Struct
    confirmation_token: str
    email_confirmed: str
    email_recover: str
    max_logins: int
    failed_logins: int
    ip_curr_login: str
    ip_last_login: str
    messenger_configuration: _struct_pb2.Struct
    datetime_confirmed: str
    datetime_confirmation_sent: str
    namespace_default: str
    groups: _containers.RepeatedScalarFieldContainer[int]
    user_permissions: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, larauser_id: _Optional[str] = ..., entity: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., password: _Optional[str] = ..., last_login: _Optional[str] = ..., is_superuser: bool = ..., username: _Optional[str] = ..., first_name: _Optional[str] = ..., last_name: _Optional[str] = ..., email: _Optional[str] = ..., is_staff: bool = ..., is_active: bool = ..., date_joined: _Optional[str] = ..., home_screen_url: _Optional[str] = ..., home_screen_layout: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., ui_color_scheme: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., access_token: _Optional[str] = ..., access_control: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., confirmation_token: _Optional[str] = ..., email_confirmed: _Optional[str] = ..., email_recover: _Optional[str] = ..., max_logins: _Optional[int] = ..., failed_logins: _Optional[int] = ..., ip_curr_login: _Optional[str] = ..., ip_last_login: _Optional[str] = ..., messenger_configuration: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_confirmed: _Optional[str] = ..., datetime_confirmation_sent: _Optional[str] = ..., namespace_default: _Optional[str] = ..., groups: _Optional[_Iterable[int]] = ..., user_permissions: _Optional[_Iterable[int]] = ...) -> None: ...

class LaraUserRequest(_message.Message):
    __slots__ = ("larauser_id", "entity", "password", "last_login", "is_superuser", "username", "first_name", "last_name", "email", "is_staff", "is_active", "date_joined", "home_screen_url", "home_screen_layout", "ui_color_scheme", "access_token", "access_control", "confirmation_token", "email_confirmed", "email_recover", "max_logins", "failed_logins", "ip_curr_login", "ip_last_login", "messenger_configuration", "datetime_confirmed", "datetime_confirmation_sent", "namespace_default", "groups", "user_permissions")
    LARAUSER_ID_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    PASSWORD_FIELD_NUMBER: _ClassVar[int]
    LAST_LOGIN_FIELD_NUMBER: _ClassVar[int]
    IS_SUPERUSER_FIELD_NUMBER: _ClassVar[int]
    USERNAME_FIELD_NUMBER: _ClassVar[int]
    FIRST_NAME_FIELD_NUMBER: _ClassVar[int]
    LAST_NAME_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    IS_STAFF_FIELD_NUMBER: _ClassVar[int]
    IS_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    DATE_JOINED_FIELD_NUMBER: _ClassVar[int]
    HOME_SCREEN_URL_FIELD_NUMBER: _ClassVar[int]
    HOME_SCREEN_LAYOUT_FIELD_NUMBER: _ClassVar[int]
    UI_COLOR_SCHEME_FIELD_NUMBER: _ClassVar[int]
    ACCESS_TOKEN_FIELD_NUMBER: _ClassVar[int]
    ACCESS_CONTROL_FIELD_NUMBER: _ClassVar[int]
    CONFIRMATION_TOKEN_FIELD_NUMBER: _ClassVar[int]
    EMAIL_CONFIRMED_FIELD_NUMBER: _ClassVar[int]
    EMAIL_RECOVER_FIELD_NUMBER: _ClassVar[int]
    MAX_LOGINS_FIELD_NUMBER: _ClassVar[int]
    FAILED_LOGINS_FIELD_NUMBER: _ClassVar[int]
    IP_CURR_LOGIN_FIELD_NUMBER: _ClassVar[int]
    IP_LAST_LOGIN_FIELD_NUMBER: _ClassVar[int]
    MESSENGER_CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CONFIRMED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CONFIRMATION_SENT_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_DEFAULT_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    USER_PERMISSIONS_FIELD_NUMBER: _ClassVar[int]
    larauser_id: str
    entity: str
    password: str
    last_login: str
    is_superuser: bool
    username: str
    first_name: str
    last_name: str
    email: str
    is_staff: bool
    is_active: bool
    date_joined: str
    home_screen_url: str
    home_screen_layout: _struct_pb2.Struct
    ui_color_scheme: _struct_pb2.Struct
    access_token: str
    access_control: _struct_pb2.Struct
    confirmation_token: str
    email_confirmed: str
    email_recover: str
    max_logins: int
    failed_logins: int
    ip_curr_login: str
    ip_last_login: str
    messenger_configuration: _struct_pb2.Struct
    datetime_confirmed: str
    datetime_confirmation_sent: str
    namespace_default: str
    groups: _containers.RepeatedScalarFieldContainer[int]
    user_permissions: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, larauser_id: _Optional[str] = ..., entity: _Optional[str] = ..., password: _Optional[str] = ..., last_login: _Optional[str] = ..., is_superuser: bool = ..., username: _Optional[str] = ..., first_name: _Optional[str] = ..., last_name: _Optional[str] = ..., email: _Optional[str] = ..., is_staff: bool = ..., is_active: bool = ..., date_joined: _Optional[str] = ..., home_screen_url: _Optional[str] = ..., home_screen_layout: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., ui_color_scheme: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., access_token: _Optional[str] = ..., access_control: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., confirmation_token: _Optional[str] = ..., email_confirmed: _Optional[str] = ..., email_recover: _Optional[str] = ..., max_logins: _Optional[int] = ..., failed_logins: _Optional[int] = ..., ip_curr_login: _Optional[str] = ..., ip_last_login: _Optional[str] = ..., messenger_configuration: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_confirmed: _Optional[str] = ..., datetime_confirmation_sent: _Optional[str] = ..., namespace_default: _Optional[str] = ..., groups: _Optional[_Iterable[int]] = ..., user_permissions: _Optional[_Iterable[int]] = ...) -> None: ...

class LaraUserResponse(_message.Message):
    __slots__ = ("larauser_id", "entity", "password", "last_login", "is_superuser", "username", "first_name", "last_name", "email", "is_staff", "is_active", "date_joined", "home_screen_url", "home_screen_layout", "ui_color_scheme", "access_token", "access_control", "confirmation_token", "email_confirmed", "email_recover", "max_logins", "failed_logins", "ip_curr_login", "ip_last_login", "messenger_configuration", "datetime_confirmed", "datetime_confirmation_sent", "namespace_default", "groups", "user_permissions")
    LARAUSER_ID_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    PASSWORD_FIELD_NUMBER: _ClassVar[int]
    LAST_LOGIN_FIELD_NUMBER: _ClassVar[int]
    IS_SUPERUSER_FIELD_NUMBER: _ClassVar[int]
    USERNAME_FIELD_NUMBER: _ClassVar[int]
    FIRST_NAME_FIELD_NUMBER: _ClassVar[int]
    LAST_NAME_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    IS_STAFF_FIELD_NUMBER: _ClassVar[int]
    IS_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    DATE_JOINED_FIELD_NUMBER: _ClassVar[int]
    HOME_SCREEN_URL_FIELD_NUMBER: _ClassVar[int]
    HOME_SCREEN_LAYOUT_FIELD_NUMBER: _ClassVar[int]
    UI_COLOR_SCHEME_FIELD_NUMBER: _ClassVar[int]
    ACCESS_TOKEN_FIELD_NUMBER: _ClassVar[int]
    ACCESS_CONTROL_FIELD_NUMBER: _ClassVar[int]
    CONFIRMATION_TOKEN_FIELD_NUMBER: _ClassVar[int]
    EMAIL_CONFIRMED_FIELD_NUMBER: _ClassVar[int]
    EMAIL_RECOVER_FIELD_NUMBER: _ClassVar[int]
    MAX_LOGINS_FIELD_NUMBER: _ClassVar[int]
    FAILED_LOGINS_FIELD_NUMBER: _ClassVar[int]
    IP_CURR_LOGIN_FIELD_NUMBER: _ClassVar[int]
    IP_LAST_LOGIN_FIELD_NUMBER: _ClassVar[int]
    MESSENGER_CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CONFIRMED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CONFIRMATION_SENT_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_DEFAULT_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    USER_PERMISSIONS_FIELD_NUMBER: _ClassVar[int]
    larauser_id: str
    entity: str
    password: str
    last_login: str
    is_superuser: bool
    username: str
    first_name: str
    last_name: str
    email: str
    is_staff: bool
    is_active: bool
    date_joined: str
    home_screen_url: str
    home_screen_layout: _struct_pb2.Struct
    ui_color_scheme: _struct_pb2.Struct
    access_token: str
    access_control: _struct_pb2.Struct
    confirmation_token: str
    email_confirmed: str
    email_recover: str
    max_logins: int
    failed_logins: int
    ip_curr_login: str
    ip_last_login: str
    messenger_configuration: _struct_pb2.Struct
    datetime_confirmed: str
    datetime_confirmation_sent: str
    namespace_default: str
    groups: _containers.RepeatedScalarFieldContainer[int]
    user_permissions: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, larauser_id: _Optional[str] = ..., entity: _Optional[str] = ..., password: _Optional[str] = ..., last_login: _Optional[str] = ..., is_superuser: bool = ..., username: _Optional[str] = ..., first_name: _Optional[str] = ..., last_name: _Optional[str] = ..., email: _Optional[str] = ..., is_staff: bool = ..., is_active: bool = ..., date_joined: _Optional[str] = ..., home_screen_url: _Optional[str] = ..., home_screen_layout: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., ui_color_scheme: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., access_token: _Optional[str] = ..., access_control: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., confirmation_token: _Optional[str] = ..., email_confirmed: _Optional[str] = ..., email_recover: _Optional[str] = ..., max_logins: _Optional[int] = ..., failed_logins: _Optional[int] = ..., ip_curr_login: _Optional[str] = ..., ip_last_login: _Optional[str] = ..., messenger_configuration: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_confirmed: _Optional[str] = ..., datetime_confirmation_sent: _Optional[str] = ..., namespace_default: _Optional[str] = ..., groups: _Optional[_Iterable[int]] = ..., user_permissions: _Optional[_Iterable[int]] = ...) -> None: ...

class LaraUserRetrieveRequest(_message.Message):
    __slots__ = ("larauser_id",)
    LARAUSER_ID_FIELD_NUMBER: _ClassVar[int]
    larauser_id: str
    def __init__(self, larauser_id: _Optional[str] = ...) -> None: ...

class LaraUserStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MeetingsCalendarDestroyRequest(_message.Message):
    __slots__ = ("meetingcalendar_id",)
    MEETINGCALENDAR_ID_FIELD_NUMBER: _ClassVar[int]
    meetingcalendar_id: str
    def __init__(self, meetingcalendar_id: _Optional[str] = ...) -> None: ...

class MeetingsCalendarListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MeetingsCalendarListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[MeetingsCalendarResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[MeetingsCalendarResponse, _Mapping]]] = ...) -> None: ...

class MeetingsCalendarPartialUpdateRequest(_message.Message):
    __slots__ = ("meetingcalendar_id", "organiser", "attendees", "_partial_update_fields", "name_display", "calendar_url", "summary", "description", "color", "ics", "datetime_start", "datetime_end", "duration", "all_day", "created", "datetime_last_modified", "timestamp", "conference_url", "range", "related", "role", "tzid", "offset_utc", "alarm_repeat_json", "event_repeat", "event_repeat_json", "search_vector", "location", "geolocation", "tags")
    MEETINGCALENDAR_ID_FIELD_NUMBER: _ClassVar[int]
    ORGANISER_FIELD_NUMBER: _ClassVar[int]
    ATTENDEES_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    CALENDAR_URL_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    ICS_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DURATION_FIELD_NUMBER: _ClassVar[int]
    ALL_DAY_FIELD_NUMBER: _ClassVar[int]
    CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    CONFERENCE_URL_FIELD_NUMBER: _ClassVar[int]
    RANGE_FIELD_NUMBER: _ClassVar[int]
    RELATED_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    TZID_FIELD_NUMBER: _ClassVar[int]
    OFFSET_UTC_FIELD_NUMBER: _ClassVar[int]
    ALARM_REPEAT_JSON_FIELD_NUMBER: _ClassVar[int]
    EVENT_REPEAT_FIELD_NUMBER: _ClassVar[int]
    EVENT_REPEAT_JSON_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    GEOLOCATION_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    meetingcalendar_id: str
    organiser: str
    attendees: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    calendar_url: str
    summary: str
    description: str
    color: str
    ics: str
    datetime_start: str
    datetime_end: str
    duration: str
    all_day: bool
    created: str
    datetime_last_modified: str
    timestamp: str
    conference_url: str
    range: str
    related: str
    role: str
    tzid: str
    offset_utc: int
    alarm_repeat_json: _struct_pb2.Struct
    event_repeat: str
    event_repeat_json: _struct_pb2.Struct
    search_vector: str
    location: str
    geolocation: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, meetingcalendar_id: _Optional[str] = ..., organiser: _Optional[str] = ..., attendees: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., calendar_url: _Optional[str] = ..., summary: _Optional[str] = ..., description: _Optional[str] = ..., color: _Optional[str] = ..., ics: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_end: _Optional[str] = ..., duration: _Optional[str] = ..., all_day: bool = ..., created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., timestamp: _Optional[str] = ..., conference_url: _Optional[str] = ..., range: _Optional[str] = ..., related: _Optional[str] = ..., role: _Optional[str] = ..., tzid: _Optional[str] = ..., offset_utc: _Optional[int] = ..., alarm_repeat_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., event_repeat: _Optional[str] = ..., event_repeat_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ..., location: _Optional[str] = ..., geolocation: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ...) -> None: ...

class MeetingsCalendarRequest(_message.Message):
    __slots__ = ("meetingcalendar_id", "organiser", "attendees", "name_display", "calendar_url", "summary", "description", "color", "ics", "datetime_start", "datetime_end", "duration", "all_day", "created", "datetime_last_modified", "timestamp", "conference_url", "range", "related", "role", "tzid", "offset_utc", "alarm_repeat_json", "event_repeat", "event_repeat_json", "search_vector", "location", "geolocation", "tags")
    MEETINGCALENDAR_ID_FIELD_NUMBER: _ClassVar[int]
    ORGANISER_FIELD_NUMBER: _ClassVar[int]
    ATTENDEES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    CALENDAR_URL_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    ICS_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DURATION_FIELD_NUMBER: _ClassVar[int]
    ALL_DAY_FIELD_NUMBER: _ClassVar[int]
    CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    CONFERENCE_URL_FIELD_NUMBER: _ClassVar[int]
    RANGE_FIELD_NUMBER: _ClassVar[int]
    RELATED_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    TZID_FIELD_NUMBER: _ClassVar[int]
    OFFSET_UTC_FIELD_NUMBER: _ClassVar[int]
    ALARM_REPEAT_JSON_FIELD_NUMBER: _ClassVar[int]
    EVENT_REPEAT_FIELD_NUMBER: _ClassVar[int]
    EVENT_REPEAT_JSON_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    GEOLOCATION_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    meetingcalendar_id: str
    organiser: str
    attendees: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    calendar_url: str
    summary: str
    description: str
    color: str
    ics: str
    datetime_start: str
    datetime_end: str
    duration: str
    all_day: bool
    created: str
    datetime_last_modified: str
    timestamp: str
    conference_url: str
    range: str
    related: str
    role: str
    tzid: str
    offset_utc: int
    alarm_repeat_json: _struct_pb2.Struct
    event_repeat: str
    event_repeat_json: _struct_pb2.Struct
    search_vector: str
    location: str
    geolocation: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, meetingcalendar_id: _Optional[str] = ..., organiser: _Optional[str] = ..., attendees: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., calendar_url: _Optional[str] = ..., summary: _Optional[str] = ..., description: _Optional[str] = ..., color: _Optional[str] = ..., ics: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_end: _Optional[str] = ..., duration: _Optional[str] = ..., all_day: bool = ..., created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., timestamp: _Optional[str] = ..., conference_url: _Optional[str] = ..., range: _Optional[str] = ..., related: _Optional[str] = ..., role: _Optional[str] = ..., tzid: _Optional[str] = ..., offset_utc: _Optional[int] = ..., alarm_repeat_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., event_repeat: _Optional[str] = ..., event_repeat_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ..., location: _Optional[str] = ..., geolocation: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ...) -> None: ...

class MeetingsCalendarResponse(_message.Message):
    __slots__ = ("meetingcalendar_id", "organiser", "attendees", "name_display", "calendar_url", "summary", "description", "color", "ics", "datetime_start", "datetime_end", "duration", "all_day", "created", "datetime_last_modified", "timestamp", "conference_url", "range", "related", "role", "tzid", "offset_utc", "alarm_repeat_json", "event_repeat", "event_repeat_json", "search_vector", "location", "geolocation", "tags")
    MEETINGCALENDAR_ID_FIELD_NUMBER: _ClassVar[int]
    ORGANISER_FIELD_NUMBER: _ClassVar[int]
    ATTENDEES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    CALENDAR_URL_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    ICS_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DURATION_FIELD_NUMBER: _ClassVar[int]
    ALL_DAY_FIELD_NUMBER: _ClassVar[int]
    CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    CONFERENCE_URL_FIELD_NUMBER: _ClassVar[int]
    RANGE_FIELD_NUMBER: _ClassVar[int]
    RELATED_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    TZID_FIELD_NUMBER: _ClassVar[int]
    OFFSET_UTC_FIELD_NUMBER: _ClassVar[int]
    ALARM_REPEAT_JSON_FIELD_NUMBER: _ClassVar[int]
    EVENT_REPEAT_FIELD_NUMBER: _ClassVar[int]
    EVENT_REPEAT_JSON_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    GEOLOCATION_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    meetingcalendar_id: str
    organiser: str
    attendees: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    calendar_url: str
    summary: str
    description: str
    color: str
    ics: str
    datetime_start: str
    datetime_end: str
    duration: str
    all_day: bool
    created: str
    datetime_last_modified: str
    timestamp: str
    conference_url: str
    range: str
    related: str
    role: str
    tzid: str
    offset_utc: int
    alarm_repeat_json: _struct_pb2.Struct
    event_repeat: str
    event_repeat_json: _struct_pb2.Struct
    search_vector: str
    location: str
    geolocation: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, meetingcalendar_id: _Optional[str] = ..., organiser: _Optional[str] = ..., attendees: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., calendar_url: _Optional[str] = ..., summary: _Optional[str] = ..., description: _Optional[str] = ..., color: _Optional[str] = ..., ics: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_end: _Optional[str] = ..., duration: _Optional[str] = ..., all_day: bool = ..., created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., timestamp: _Optional[str] = ..., conference_url: _Optional[str] = ..., range: _Optional[str] = ..., related: _Optional[str] = ..., role: _Optional[str] = ..., tzid: _Optional[str] = ..., offset_utc: _Optional[int] = ..., alarm_repeat_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., event_repeat: _Optional[str] = ..., event_repeat_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ..., location: _Optional[str] = ..., geolocation: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ...) -> None: ...

class MeetingsCalendarRetrieveRequest(_message.Message):
    __slots__ = ("meetingcalendar_id",)
    MEETINGCALENDAR_ID_FIELD_NUMBER: _ClassVar[int]
    meetingcalendar_id: str
    def __init__(self, meetingcalendar_id: _Optional[str] = ...) -> None: ...

class MeetingsCalendarStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
