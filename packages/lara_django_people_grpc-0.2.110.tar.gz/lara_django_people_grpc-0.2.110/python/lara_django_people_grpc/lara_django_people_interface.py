"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_people high_level_interface *

:details: lara_django_people high_level_interface.
         - generated with 'lara-django-dev generate_high_level_interface lara_django_people
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

import json
import asyncio
import logging
import grpc
from typing import Union

from google.protobuf.struct_pb2 import Struct
from google.protobuf.json_format import MessageToDict

import lara_django_base_grpc.v1.lara_django_base_pb2 as lara_django_base_pb2
import lara_django_base_grpc.v1.lara_django_base_pb2_grpc as lara_django_base_pb2_grpc

import lara_django_people_grpc.v1.lara_django_people_pb2 as lara_django_people_pb2
import lara_django_people_grpc.v1.lara_django_people_pb2_grpc as lara_django_people_pb2_grpc

import  lara_django_base_grpc.lara_django_base_data_model as base_dm
import  lara_django_base_grpc.lara_django_base_interface as base_if
from  lara_django_base_grpc.abstract_interface import LARAInterface, GRPCChannelSingleton, import_model_instance_from_file, export_model_instance_to_file, upload_file, download_file, update_file, upload_image, update_image, download_image, id_cache

import  lara_django_people_grpc.lara_django_people_data_model as people_dm

logger = logging.getLogger(__name__)



#_________________  ExtraData  ______________________


class ExtraDataInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.extradata_class_client = (
        #     lara_django_people_pb2_grpc.ExtraDataclassByIRIControllerStub(channel)
        # )

        self.extradata_client = lara_django_people_pb2_grpc.ExtraDataControllerStub(channel)
        
        self.item_id = None
        self.update_item_id = "extradata_id"
        self.stub = self.extradata_client

        self.file_download_info = lara_django_people_pb2.FileDownloadInfo
        self.file_upload_chunk = lara_django_people_pb2.FileUploadChunk

        self.image_upload_chunk = lara_django_people_pb2.ImageUploadChunk


        # self.extradata_full_client = lara_django_people_pb2_grpc.ExtraDataFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    @upload_file  # needed for file upload
    @upload_image  # needed for image upload
    async def create(self,  extradata:  list[people_dm.ExtraData] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[people_dm.ExtraData]]:
        """ create a list of extradata instances,
               returns a list of extradata data model objects or ids_only

        :param extradata: list of extradata data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of extradata data model objects or ids_only
        """
        extradataclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if extradata_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.extradata_class_client.Retrieve(
        #         lara_django_people_pb2.ExtraDataclassRetrieveRequest(iri=extradata_class_iri)
        #     )
        #     extradataclass_id = res.extradataclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving extradataclass_id: {e}")
        for extradatum in extradata:
            if extradatum.namespace == "" or extradatum.namespace == "default":
                    extradatum.namespace = namespace_id
            # extradata.extradata_class = extradataclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.extradata_client.Create(lara_django_people_pb2.ExtraDataRequest(**extradatum.model_dump())) for extradatum in extradata )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("extradata_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating extradata: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        extradata_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[people_dm.ExtraData]:
        """ retrieve a list of extradata instances by extradata_id, name or filter_dict,
               returns a list of extradata data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  extradata_id is not None:
            try:
                res =  await self.extradata_client.Retrieve(
                    lara_django_people_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( people_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving extradata_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.extradata_client.List(
                    lara_django_people_pb2.ExtraDataListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ people_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving extradata name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the extradata_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].extradata_id
        else:
            raise ValueError(f"Error retrieving extradata_id - no or too many results found.")
    
    @download_file  # needed for file download
    @download_image  # needed for image download
    async def get_by_id(self, extradata_id: str = None, id_only: bool = False) -> people_dm.ExtraData:
        """ retrieve a extradata data model by extradata_id """
        try:
            res = await self.extradata_client.Retrieve(
                lara_django_people_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id)
            )
            item = people_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.extradata_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving extradata_id: {e}")
    
    @download_file  # needed for file download
    @download_image  # needed for image download
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> people_dm.ExtraData | str:
        """ retrieve a extradata data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.extradata_client.RetrieveByNameNamespace(
                lara_django_people_pb2.ExtraDataRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["extradata_id"]
            if id_only:
                return self.item_id
            else:
                return people_dm.ExtraData(**item)
        except Exception as e:
            logger.error(f"Error retrieving extradata name: {e}")
   
    
    @download_file  # needed for file download
    async def get_file(self, extradata_id : str = None, id_only : bool = True ) -> bytes | None:
        """ retrieve a file by data_id """
        self.item_id = extradata_id
        
    
    async def get_file_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                filename_target : str = None,
                                as_byte_str : bool = None ) -> bytes | None:
        """ retrieve a file by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            # logger.warning(f"no namespace_uri provided, using default namespace: {namespace_uri}")
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            extradata_id = await self.get_by_name(name=name, namespace_uri=namespace_uri, id_only=True)
            return await self.get_file(extradata_id=extradata_id, filename_target=filename_target, as_byte_str=as_byte_str, get_file=True)
        except Exception as e:
            logger.error(f"Error retrieving extradata name: {e}")
        
    
    @download_image  # needed for image download
    async def get_image(self, extradata_id : str = None, id_only : bool = True) -> bytes | None:
        """ retrieve an image by data_id """
        self.item_id = extradata_id
        
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all extradatas """
        if filter_dict is None:
            res = await self.extradata_client.List(lara_django_people_pb2.ExtraDataListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.extradata_client.List(
                lara_django_people_pb2.ExtraDataListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.extradata_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all extradatas """
        if self.extradata_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.extradata_full_client.List(
                lara_django_people_pb2.ExtraDataFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.extradata_full_client.List(
                lara_django_people_pb2.ExtraDataFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    @update_file  # needed for file update
    @update_image  # needed for image update
    async def update(self, extradata : people_dm.ExtraData = None) -> None:
        """ update a extradata model instance """
        try:
            res = await self.extradata_client.Update(
                lara_django_people_pb2.ExtraDataRequest(**extradata.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating extradata_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a extradata by extradata_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.extradata_client.Destroy(lara_django_people_pb2.ExtraDataDestroyRequest(extradata_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting extradata_id: {e}")

#_________________  EntityClass  ______________________


class EntityClassInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.entityclass_client = lara_django_people_pb2_grpc.EntityClassControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  entityclasses:  list[people_dm.EntityClass] = None,  ids_only: bool = False) -> Union[list[str], list[people_dm.EntityClass]]:
        try:
            create_coroutines = ( self.entityclass_client.Create(lara_django_people_pb2.EntityClassRequest(**entityclass.model_dump())) for entityclass in entityclasses )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.entityclass_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating entityclass: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        entityclass_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[people_dm.EntityClass]:
        """ retrieve a list of entityclass instances by entityclass_id, name or filter_dict,
               returns a list of entityclass data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  entityclass_id is not None:
            try:
                res =  await self.entityclass_client.Retrieve(
                    lara_django_people_pb2.EntityClassRetrieveRequest(entityclass_id=entityclass_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( people_dm.EntityClass(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving entityclass_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.entityclass_client.List(
                    lara_django_people_pb2.EntityClassListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ people_dm.EntityClass(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving entityclass name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the entityclass_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].entityclass_id
        else:
            raise ValueError(f"Error retrieving entityclass_id - no or too many results found.")
    
    async def get_by_id(self, entityclass_id: str = None) -> people_dm.EntityClass:
        """ retrieve a entityclass data model by entityclass_id """
        try:
            res = await self.entityclass_client.Retrieve(
                lara_django_people_pb2.EntityClassRetrieveRequest(entityclass_id=entityclass_id)
            )
            return people_dm.EntityClass(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving entityclass_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> people_dm.EntityClass | str:
        """ retrieve a entityclass data model by name """
        try:
            res = await self.entityclass_client.RetrieveByNameNamespace(
                lara_django_people_pb2.EntityClassRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["entityclass_id"]
            else:
                return people_dm.EntityClass(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving entityclass name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all entityclasss """
        if filter_dict is None:
            res = await self.entityclass_client.List(lara_django_people_pb2.EntityClassListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.entityclass_client.List(
                lara_django_people_pb2.EntityClassListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.entityclass_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all entityclasss """
        if self.entityclass_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.entityclass_full_client.List(
                lara_django_people_pb2.EntityClassFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.entityclass_full_client.List(
                lara_django_people_pb2.EntityClassFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, entityclass : people_dm.EntityClass = None) -> None:
        """ update a entityclass model instance """
        try:
            res = await self.entityclass_client.Update(
                lara_django_people_pb2.EntityClassRequest(**entityclass.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating entityclass_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a entityclass by entityclass_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.entityclass_client.Destroy(lara_django_people_pb2.EntityClassDestroyRequest(entityclass_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting entityclass_id: {e}")

#_________________  EntityRole  ______________________


class EntityRoleInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.entityrole_client = lara_django_people_pb2_grpc.EntityRoleControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  entityroles:  list[people_dm.EntityRole] = None,  ids_only: bool = False) -> Union[list[str], list[people_dm.EntityRole]]:
        try:
            create_coroutines = ( self.entityrole_client.Create(lara_django_people_pb2.EntityRoleRequest(**entityrole.model_dump())) for entityrole in entityroles )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.entityrole_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating entityrole: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        entityrole_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[people_dm.EntityRole]:
        """ retrieve a list of entityrole instances by entityrole_id, name or filter_dict,
               returns a list of entityrole data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  entityrole_id is not None:
            try:
                res =  await self.entityrole_client.Retrieve(
                    lara_django_people_pb2.EntityRoleRetrieveRequest(entityrole_id=entityrole_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( people_dm.EntityRole(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving entityrole_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.entityrole_client.List(
                    lara_django_people_pb2.EntityRoleListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ people_dm.EntityRole(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving entityrole name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the entityrole_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].entityrole_id
        else:
            raise ValueError(f"Error retrieving entityrole_id - no or too many results found.")
    
    async def get_by_id(self, entityrole_id: str = None) -> people_dm.EntityRole:
        """ retrieve a entityrole data model by entityrole_id """
        try:
            res = await self.entityrole_client.Retrieve(
                lara_django_people_pb2.EntityRoleRetrieveRequest(entityrole_id=entityrole_id)
            )
            return people_dm.EntityRole(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving entityrole_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> people_dm.EntityRole | str:
        """ retrieve a entityrole data model by name """
        try:
            res = await self.entityrole_client.RetrieveByNameNamespace(
                lara_django_people_pb2.EntityRoleRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["entityrole_id"]
            else:
                return people_dm.EntityRole(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving entityrole name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all entityroles """
        if filter_dict is None:
            res = await self.entityrole_client.List(lara_django_people_pb2.EntityRoleListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.entityrole_client.List(
                lara_django_people_pb2.EntityRoleListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.entityrole_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all entityroles """
        if self.entityrole_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.entityrole_full_client.List(
                lara_django_people_pb2.EntityRoleFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.entityrole_full_client.List(
                lara_django_people_pb2.EntityRoleFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, entityrole : people_dm.EntityRole = None) -> None:
        """ update a entityrole model instance """
        try:
            res = await self.entityrole_client.Update(
                lara_django_people_pb2.EntityRoleRequest(**entityrole.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating entityrole_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a entityrole by entityrole_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.entityrole_client.Destroy(lara_django_people_pb2.EntityRoleDestroyRequest(entityrole_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting entityrole_id: {e}")

#_________________  Entity  ______________________


class EntityInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.entity_client = lara_django_people_pb2_grpc.EntityControllerStub(channel)
        
        self.item_id = None
        self.update_item_id = "entity_id"
        self.stub = self.entity_client

        self.image_upload_chunk = lara_django_people_pb2.ImageUploadChunk

    
    @import_model_instance_from_file()
    @upload_image  # needed for image upload
    async def create(self,  entities:  list[people_dm.Entity] = None,  ids_only: bool = False) -> Union[list[str], list[people_dm.Entity]]:
        try:
            create_coroutines = ( self.entity_client.Create(lara_django_people_pb2.EntityRequest(**entity.model_dump())) for entity in entities )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.entity_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating entity: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        entity_id: str = None,
        name: str = None,
        name_display: str = None,
        name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[people_dm.Entity]:
        """ retrieve a list of entity instances by entity_id, name or filter_dict,
               returns a list of entity data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  entity_id is not None:
            try:
                res =  await self.entity_client.Retrieve(
                    lara_django_people_pb2.EntityRetrieveRequest(entity_id=entity_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( people_dm.Entity(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving entity_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if name_display is not None:
           filter_dict["name_display"] = name_display
        if name_full is not None:
            filter_dict["name_full"] = name_full

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.entity_client.List(
                    lara_django_people_pb2.EntityListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ people_dm.Entity(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving entity name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          name_display: str = None,
                          name_full: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the entity_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, 
                                           name_display=name_display,
                                           name_full=name_full, 
                                           filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].entity_id
        else:
            raise ValueError(f"Error retrieving entity_id - no or too many results found.")
    
    @download_image  # needed for image download
    async def get_by_id(self, entity_id: str = None) -> people_dm.Entity:
        """ retrieve a entity data model by entity_id """
        try:
            res = await self.entity_client.Retrieve(
                lara_django_people_pb2.EntityRetrieveRequest(entity_id=entity_id)
            )
            return people_dm.Entity(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving entity_id: {e}")
    
    @download_image  # needed for image download
    async def get_by_name(self, name: str = None, id_only: bool = False) -> people_dm.Entity | str:
        """ retrieve a entity data model by name """
        try:
            res = await self.entity_client.RetrieveByNameNamespace(
                lara_django_people_pb2.EntityRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["entity_id"]
            else:
                return people_dm.Entity(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving entity name: {e}")
    
    
    
    @download_image  # needed for image download
    async def get_image(self, entity_id : str = None, id_only : bool = True) -> bytes | None:
        """ retrieve an image by data_id """
        self.item_id = entity_id
        
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all entitys """
        if filter_dict is None:
            res = await self.entity_client.List(lara_django_people_pb2.EntityListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.entity_client.List(
                lara_django_people_pb2.EntityListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.entity_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all entitys """
        if self.entity_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.entity_full_client.List(
                lara_django_people_pb2.EntityFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.entity_full_client.List(
                lara_django_people_pb2.EntityFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    @update_image  # needed for image update
    async def update(self, entity : people_dm.Entity = None) -> None:
        """ update a entity model instance """
        try:
            res = await self.entity_client.Update(
                lara_django_people_pb2.EntityRequest(**entity.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating entity_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a entity by entity_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.entity_client.Destroy(lara_django_people_pb2.EntityDestroyRequest(entity_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting entity_id: {e}")

#_________________  Group  ______________________


class GroupInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.group_class_client = (
        #     lara_django_people_pb2_grpc.GroupclassByIRIControllerStub(channel)
        # )

        self.group_client = lara_django_people_pb2_grpc.GroupControllerStub(channel)
        

        # self.group_full_client = lara_django_people_pb2_grpc.GroupFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    async def create(self,  groups:  list[people_dm.Group] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[people_dm.Group]]:
        """ create a list of group instances,
               returns a list of group data model objects or ids_only

        :param groups: list of group data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of group data model objects or ids_only
        """
        groupclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if group_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.group_class_client.Retrieve(
        #         lara_django_people_pb2.GroupclassRetrieveRequest(iri=group_class_iri)
        #     )
        #     groupclass_id = res.groupclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving groupclass_id: {e}")
        for group in groups:
            if group.namespace == "" or group.namespace == "default":
                    group.namespace = namespace_id
            # group.group_class = groupclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.group_client.Create(lara_django_people_pb2.GroupRequest(**group.model_dump())) for group in groups )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("group_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating group: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        group_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[people_dm.Group]:
        """ retrieve a list of group instances by group_id, name or filter_dict,
               returns a list of group data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  group_id is not None:
            try:
                res =  await self.group_client.Retrieve(
                    lara_django_people_pb2.GroupRetrieveRequest(group_id=group_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( people_dm.Group(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving group_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.group_client.List(
                    lara_django_people_pb2.GroupListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ people_dm.Group(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving group name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the group_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].group_id
        else:
            raise ValueError(f"Error retrieving group_id - no or too many results found.")
    
    async def get_by_id(self, group_id: str = None, id_only: bool = False) -> people_dm.Group:
        """ retrieve a group data model by group_id """
        try:
            res = await self.group_client.Retrieve(
                lara_django_people_pb2.GroupRetrieveRequest(group_id=group_id)
            )
            item = people_dm.Group(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.group_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving group_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> people_dm.Group | str:
        """ retrieve a group data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.group_client.RetrieveByNameNamespace(
                lara_django_people_pb2.GroupRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["group_id"]
            if id_only:
                return self.item_id
            else:
                return people_dm.Group(**item)
        except Exception as e:
            logger.error(f"Error retrieving group name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all groups """
        if filter_dict is None:
            res = await self.group_client.List(lara_django_people_pb2.GroupListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.group_client.List(
                lara_django_people_pb2.GroupListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.group_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all groups """
        if self.group_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.group_full_client.List(
                lara_django_people_pb2.GroupFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.group_full_client.List(
                lara_django_people_pb2.GroupFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, group : people_dm.Group = None) -> None:
        """ update a group model instance """
        try:
            res = await self.group_client.Update(
                lara_django_people_pb2.GroupRequest(**group.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating group_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a group by group_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.group_client.Destroy(lara_django_people_pb2.GroupDestroyRequest(group_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting group_id: {e}")

#_________________  EntityBankAccount  ______________________


class EntityBankAccountInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.entitybankaccount_client = lara_django_people_pb2_grpc.EntityBankAccountControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  entitybankaccounts:  list[people_dm.EntityBankAccount] = None,  ids_only: bool = False) -> Union[list[str], list[people_dm.EntityBankAccount]]:
        try:
            create_coroutines = ( self.entitybankaccount_client.Create(lara_django_people_pb2.EntityBankAccountRequest(**entitybankaccount.model_dump())) for entitybankaccount in entitybankaccounts )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.entitybankaccount_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating entitybankaccount: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        entitybankaccount_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[people_dm.EntityBankAccount]:
        """ retrieve a list of entitybankaccount instances by entitybankaccount_id, name or filter_dict,
               returns a list of entitybankaccount data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  entitybankaccount_id is not None:
            try:
                res =  await self.entitybankaccount_client.Retrieve(
                    lara_django_people_pb2.EntityBankAccountRetrieveRequest(entitybankaccount_id=entitybankaccount_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( people_dm.EntityBankAccount(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving entitybankaccount_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.entitybankaccount_client.List(
                    lara_django_people_pb2.EntityBankAccountListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ people_dm.EntityBankAccount(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving entitybankaccount name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the entitybankaccount_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].entitybankaccount_id
        else:
            raise ValueError(f"Error retrieving entitybankaccount_id - no or too many results found.")
    
    async def get_by_id(self, entitybankaccount_id: str = None) -> people_dm.EntityBankAccount:
        """ retrieve a entitybankaccount data model by entitybankaccount_id """
        try:
            res = await self.entitybankaccount_client.Retrieve(
                lara_django_people_pb2.EntityBankAccountRetrieveRequest(entitybankaccount_id=entitybankaccount_id)
            )
            return people_dm.EntityBankAccount(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving entitybankaccount_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> people_dm.EntityBankAccount | str:
        """ retrieve a entitybankaccount data model by name """
        try:
            res = await self.entitybankaccount_client.RetrieveByNameNamespace(
                lara_django_people_pb2.EntityBankAccountRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["entitybankaccount_id"]
            else:
                return people_dm.EntityBankAccount(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving entitybankaccount name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all entitybankaccounts """
        if filter_dict is None:
            res = await self.entitybankaccount_client.List(lara_django_people_pb2.EntityBankAccountListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.entitybankaccount_client.List(
                lara_django_people_pb2.EntityBankAccountListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.entitybankaccount_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all entitybankaccounts """
        if self.entitybankaccount_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.entitybankaccount_full_client.List(
                lara_django_people_pb2.EntityBankAccountFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.entitybankaccount_full_client.List(
                lara_django_people_pb2.EntityBankAccountFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, entitybankaccount : people_dm.EntityBankAccount = None) -> None:
        """ update a entitybankaccount model instance """
        try:
            res = await self.entitybankaccount_client.Update(
                lara_django_people_pb2.EntityBankAccountRequest(**entitybankaccount.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating entitybankaccount_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a entitybankaccount by entitybankaccount_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.entitybankaccount_client.Destroy(lara_django_people_pb2.EntityBankAccountDestroyRequest(entitybankaccount_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting entitybankaccount_id: {e}")

#_________________  EntitiesSubset  ______________________


class EntitiesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.entitiessubset_class_client = (
        #     lara_django_people_pb2_grpc.EntitiesSubsetclassByIRIControllerStub(channel)
        # )

        self.entitiessubset_client = lara_django_people_pb2_grpc.EntitiesSubsetControllerStub(channel)
        

        # self.entitiessubset_full_client = lara_django_people_pb2_grpc.EntitiesSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    async def create(self,  entitiessubsets:  list[people_dm.EntitiesSubset] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[people_dm.EntitiesSubset]]:
        """ create a list of entitiessubset instances,
               returns a list of entitiessubset data model objects or ids_only

        :param entitiessubsets: list of entitiessubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of entitiessubset data model objects or ids_only
        """
        entitiessubsetclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if entitiessubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.entitiessubset_class_client.Retrieve(
        #         lara_django_people_pb2.EntitiesSubsetclassRetrieveRequest(iri=entitiessubset_class_iri)
        #     )
        #     entitiessubsetclass_id = res.entitiessubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving entitiessubsetclass_id: {e}")
        for entitiessubset in entitiessubsets:
            if entitiessubset.namespace == "" or entitiessubset.namespace == "default":
                    entitiessubset.namespace = namespace_id
            # entitiessubset.entitiessubset_class = entitiessubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.entitiessubset_client.Create(lara_django_people_pb2.EntitiesSubsetRequest(**entitiessubset.model_dump())) for entitiessubset in entitiessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("entitiessubset_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating entitiessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        entitiessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[people_dm.EntitiesSubset]:
        """ retrieve a list of entitiessubset instances by entitiessubset_id, name or filter_dict,
               returns a list of entitiessubset data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  entitiessubset_id is not None:
            try:
                res =  await self.entitiessubset_client.Retrieve(
                    lara_django_people_pb2.EntitiesSubsetRetrieveRequest(entitiessubset_id=entitiessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( people_dm.EntitiesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving entitiessubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.entitiessubset_client.List(
                    lara_django_people_pb2.EntitiesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ people_dm.EntitiesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving entitiessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the entitiessubset_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].entitiessubset_id
        else:
            raise ValueError(f"Error retrieving entitiessubset_id - no or too many results found.")
    
    async def get_by_id(self, entitiessubset_id: str = None, id_only: bool = False) -> people_dm.EntitiesSubset:
        """ retrieve a entitiessubset data model by entitiessubset_id """
        try:
            res = await self.entitiessubset_client.Retrieve(
                lara_django_people_pb2.EntitiesSubsetRetrieveRequest(entitiessubset_id=entitiessubset_id)
            )
            item = people_dm.EntitiesSubset(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.entitiessubset_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving entitiessubset_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> people_dm.EntitiesSubset | str:
        """ retrieve a entitiessubset data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.entitiessubset_client.RetrieveByNameNamespace(
                lara_django_people_pb2.EntitiesSubsetRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["entitiessubset_id"]
            if id_only:
                return self.item_id
            else:
                return people_dm.EntitiesSubset(**item)
        except Exception as e:
            logger.error(f"Error retrieving entitiessubset name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all entitiessubsets """
        if filter_dict is None:
            res = await self.entitiessubset_client.List(lara_django_people_pb2.EntitiesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.entitiessubset_client.List(
                lara_django_people_pb2.EntitiesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.entitiessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all entitiessubsets """
        if self.entitiessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.entitiessubset_full_client.List(
                lara_django_people_pb2.EntitiesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.entitiessubset_full_client.List(
                lara_django_people_pb2.EntitiesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, entitiessubset : people_dm.EntitiesSubset = None) -> None:
        """ update a entitiessubset model instance """
        try:
            res = await self.entitiessubset_client.Update(
                lara_django_people_pb2.EntitiesSubsetRequest(**entitiessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating entitiessubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a entitiessubset by entitiessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.entitiessubset_client.Destroy(lara_django_people_pb2.EntitiesSubsetDestroyRequest(entitiessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting entitiessubset_id: {e}")

#_________________  OrderedEntitiesSubset  ______________________


class OrderedEntitiesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedentitiessubset_client = lara_django_people_pb2_grpc.OrderedEntitiesSubsetControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  orderedentitiessubsets:  list[people_dm.OrderedEntitiesSubset] = None,  ids_only: bool = False) -> Union[list[str], list[people_dm.OrderedEntitiesSubset]]:
        try:
            create_coroutines = ( self.orderedentitiessubset_client.Create(lara_django_people_pb2.OrderedEntitiesSubsetRequest(**orderedentitiessubset.model_dump())) for orderedentitiessubset in orderedentitiessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedentitiessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedentitiessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedentitiessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[people_dm.OrderedEntitiesSubset]:
        """ retrieve a list of orderedentitiessubset instances by orderedentitiessubset_id, name or filter_dict,
               returns a list of orderedentitiessubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  orderedentitiessubset_id is not None:
            try:
                res =  await self.orderedentitiessubset_client.Retrieve(
                    lara_django_people_pb2.OrderedEntitiesSubsetRetrieveRequest(orderedentitiessubset_id=orderedentitiessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( people_dm.OrderedEntitiesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedentitiessubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedentitiessubset_client.List(
                    lara_django_people_pb2.OrderedEntitiesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ people_dm.OrderedEntitiesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving orderedentitiessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedentitiessubset_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].orderedentitiessubset_id
        else:
            raise ValueError(f"Error retrieving orderedentitiessubset_id - no or too many results found.")
    
    async def get_by_id(self, orderedentitiessubset_id: str = None) -> people_dm.OrderedEntitiesSubset:
        """ retrieve a orderedentitiessubset data model by orderedentitiessubset_id """
        try:
            res = await self.orderedentitiessubset_client.Retrieve(
                lara_django_people_pb2.OrderedEntitiesSubsetRetrieveRequest(orderedentitiessubset_id=orderedentitiessubset_id)
            )
            return people_dm.OrderedEntitiesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedentitiessubset_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> people_dm.OrderedEntitiesSubset | str:
        """ retrieve a orderedentitiessubset data model by name """
        try:
            res = await self.orderedentitiessubset_client.RetrieveByNameNamespace(
                lara_django_people_pb2.OrderedEntitiesSubsetRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["orderedentitiessubset_id"]
            else:
                return people_dm.OrderedEntitiesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedentitiessubset name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedentitiessubsets """
        if filter_dict is None:
            res = await self.orderedentitiessubset_client.List(lara_django_people_pb2.OrderedEntitiesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedentitiessubset_client.List(
                lara_django_people_pb2.OrderedEntitiesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedentitiessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedentitiessubsets """
        if self.orderedentitiessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedentitiessubset_full_client.List(
                lara_django_people_pb2.OrderedEntitiesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedentitiessubset_full_client.List(
                lara_django_people_pb2.OrderedEntitiesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, orderedentitiessubset : people_dm.OrderedEntitiesSubset = None) -> None:
        """ update a orderedentitiessubset model instance """
        try:
            res = await self.orderedentitiessubset_client.Update(
                lara_django_people_pb2.OrderedEntitiesSubsetRequest(**orderedentitiessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedentitiessubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedentitiessubset by orderedentitiessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedentitiessubset_client.Destroy(lara_django_people_pb2.OrderedEntitiesSubsetDestroyRequest(orderedentitiessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedentitiessubset_id: {e}")

#_________________  GroupsSubset  ______________________


class GroupsSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.groupssubset_class_client = (
        #     lara_django_people_pb2_grpc.GroupsSubsetclassByIRIControllerStub(channel)
        # )

        self.groupssubset_client = lara_django_people_pb2_grpc.GroupsSubsetControllerStub(channel)
        

        # self.groupssubset_full_client = lara_django_people_pb2_grpc.GroupsSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    async def create(self,  groupssubsets:  list[people_dm.GroupsSubset] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[people_dm.GroupsSubset]]:
        """ create a list of groupssubset instances,
               returns a list of groupssubset data model objects or ids_only

        :param groupssubsets: list of groupssubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of groupssubset data model objects or ids_only
        """
        groupssubsetclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if groupssubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.groupssubset_class_client.Retrieve(
        #         lara_django_people_pb2.GroupsSubsetclassRetrieveRequest(iri=groupssubset_class_iri)
        #     )
        #     groupssubsetclass_id = res.groupssubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving groupssubsetclass_id: {e}")
        for groupssubset in groupssubsets:
            if groupssubset.namespace == "" or groupssubset.namespace == "default":
                    groupssubset.namespace = namespace_id
            # groupssubset.groupssubset_class = groupssubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.groupssubset_client.Create(lara_django_people_pb2.GroupsSubsetRequest(**groupssubset.model_dump())) for groupssubset in groupssubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("groupssubset_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating groupssubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        groupssubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[people_dm.GroupsSubset]:
        """ retrieve a list of groupssubset instances by groupssubset_id, name or filter_dict,
               returns a list of groupssubset data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  groupssubset_id is not None:
            try:
                res =  await self.groupssubset_client.Retrieve(
                    lara_django_people_pb2.GroupsSubsetRetrieveRequest(groupssubset_id=groupssubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( people_dm.GroupsSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving groupssubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.groupssubset_client.List(
                    lara_django_people_pb2.GroupsSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ people_dm.GroupsSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving groupssubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the groupssubset_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].groupssubset_id
        else:
            raise ValueError(f"Error retrieving groupssubset_id - no or too many results found.")
    
    async def get_by_id(self, groupssubset_id: str = None, id_only: bool = False) -> people_dm.GroupsSubset:
        """ retrieve a groupssubset data model by groupssubset_id """
        try:
            res = await self.groupssubset_client.Retrieve(
                lara_django_people_pb2.GroupsSubsetRetrieveRequest(groupssubset_id=groupssubset_id)
            )
            item = people_dm.GroupsSubset(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.groupssubset_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving groupssubset_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> people_dm.GroupsSubset | str:
        """ retrieve a groupssubset data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.groupssubset_client.RetrieveByNameNamespace(
                lara_django_people_pb2.GroupsSubsetRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["groupssubset_id"]
            if id_only:
                return self.item_id
            else:
                return people_dm.GroupsSubset(**item)
        except Exception as e:
            logger.error(f"Error retrieving groupssubset name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all groupssubsets """
        if filter_dict is None:
            res = await self.groupssubset_client.List(lara_django_people_pb2.GroupsSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.groupssubset_client.List(
                lara_django_people_pb2.GroupsSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.groupssubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all groupssubsets """
        if self.groupssubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.groupssubset_full_client.List(
                lara_django_people_pb2.GroupsSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.groupssubset_full_client.List(
                lara_django_people_pb2.GroupsSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, groupssubset : people_dm.GroupsSubset = None) -> None:
        """ update a groupssubset model instance """
        try:
            res = await self.groupssubset_client.Update(
                lara_django_people_pb2.GroupsSubsetRequest(**groupssubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating groupssubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a groupssubset by groupssubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.groupssubset_client.Destroy(lara_django_people_pb2.GroupsSubsetDestroyRequest(groupssubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting groupssubset_id: {e}")

#_________________  OrderedGroupsSubset  ______________________


class OrderedGroupsSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedgroupssubset_client = lara_django_people_pb2_grpc.OrderedGroupsSubsetControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  orderedgroupssubsets:  list[people_dm.OrderedGroupsSubset] = None,  ids_only: bool = False) -> Union[list[str], list[people_dm.OrderedGroupsSubset]]:
        try:
            create_coroutines = ( self.orderedgroupssubset_client.Create(lara_django_people_pb2.OrderedGroupsSubsetRequest(**orderedgroupssubset.model_dump())) for orderedgroupssubset in orderedgroupssubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedgroupssubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedgroupssubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedgroupssubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[people_dm.OrderedGroupsSubset]:
        """ retrieve a list of orderedgroupssubset instances by orderedgroupssubset_id, name or filter_dict,
               returns a list of orderedgroupssubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  orderedgroupssubset_id is not None:
            try:
                res =  await self.orderedgroupssubset_client.Retrieve(
                    lara_django_people_pb2.OrderedGroupsSubsetRetrieveRequest(orderedgroupssubset_id=orderedgroupssubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( people_dm.OrderedGroupsSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedgroupssubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedgroupssubset_client.List(
                    lara_django_people_pb2.OrderedGroupsSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ people_dm.OrderedGroupsSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving orderedgroupssubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedgroupssubset_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].orderedgroupssubset_id
        else:
            raise ValueError(f"Error retrieving orderedgroupssubset_id - no or too many results found.")
    
    async def get_by_id(self, orderedgroupssubset_id: str = None) -> people_dm.OrderedGroupsSubset:
        """ retrieve a orderedgroupssubset data model by orderedgroupssubset_id """
        try:
            res = await self.orderedgroupssubset_client.Retrieve(
                lara_django_people_pb2.OrderedGroupsSubsetRetrieveRequest(orderedgroupssubset_id=orderedgroupssubset_id)
            )
            return people_dm.OrderedGroupsSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedgroupssubset_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> people_dm.OrderedGroupsSubset | str:
        """ retrieve a orderedgroupssubset data model by name """
        try:
            res = await self.orderedgroupssubset_client.RetrieveByNameNamespace(
                lara_django_people_pb2.OrderedGroupsSubsetRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["orderedgroupssubset_id"]
            else:
                return people_dm.OrderedGroupsSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedgroupssubset name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedgroupssubsets """
        if filter_dict is None:
            res = await self.orderedgroupssubset_client.List(lara_django_people_pb2.OrderedGroupsSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedgroupssubset_client.List(
                lara_django_people_pb2.OrderedGroupsSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedgroupssubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedgroupssubsets """
        if self.orderedgroupssubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedgroupssubset_full_client.List(
                lara_django_people_pb2.OrderedGroupsSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedgroupssubset_full_client.List(
                lara_django_people_pb2.OrderedGroupsSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, orderedgroupssubset : people_dm.OrderedGroupsSubset = None) -> None:
        """ update a orderedgroupssubset model instance """
        try:
            res = await self.orderedgroupssubset_client.Update(
                lara_django_people_pb2.OrderedGroupsSubsetRequest(**orderedgroupssubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedgroupssubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedgroupssubset by orderedgroupssubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedgroupssubset_client.Destroy(lara_django_people_pb2.OrderedGroupsSubsetDestroyRequest(orderedgroupssubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedgroupssubset_id: {e}")

#_________________  LaraUser  ______________________


class LaraUserInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.larauser_client = lara_django_people_pb2_grpc.LaraUserControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  larausers:  list[people_dm.LaraUser] = None,  ids_only: bool = False) -> Union[list[str], list[people_dm.LaraUser]]:
        try:
            create_coroutines = ( self.larauser_client.Create(lara_django_people_pb2.LaraUserRequest(**larauser.model_dump())) for larauser in larausers )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.larauser_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating larauser: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        larauser_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[people_dm.LaraUser]:
        """ retrieve a list of larauser instances by larauser_id, name or filter_dict,
               returns a list of larauser data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  larauser_id is not None:
            try:
                res =  await self.larauser_client.Retrieve(
                    lara_django_people_pb2.LaraUserRetrieveRequest(larauser_id=larauser_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( people_dm.LaraUser(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving larauser_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.larauser_client.List(
                    lara_django_people_pb2.LaraUserListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ people_dm.LaraUser(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving larauser name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the larauser_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].larauser_id
        else:
            raise ValueError(f"Error retrieving larauser_id - no or too many results found.")
    
    async def get_by_id(self, larauser_id: str = None) -> people_dm.LaraUser:
        """ retrieve a larauser data model by larauser_id """
        try:
            res = await self.larauser_client.Retrieve(
                lara_django_people_pb2.LaraUserRetrieveRequest(larauser_id=larauser_id)
            )
            return people_dm.LaraUser(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving larauser_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> people_dm.LaraUser | str:
        """ retrieve a larauser data model by name """
        try:
            res = await self.larauser_client.RetrieveByNameNamespace(
                lara_django_people_pb2.LaraUserRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["larauser_id"]
            else:
                return people_dm.LaraUser(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving larauser name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all larausers """
        if filter_dict is None:
            res = await self.larauser_client.List(lara_django_people_pb2.LaraUserListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.larauser_client.List(
                lara_django_people_pb2.LaraUserListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.larauser_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all larausers """
        if self.larauser_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.larauser_full_client.List(
                lara_django_people_pb2.LaraUserFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.larauser_full_client.List(
                lara_django_people_pb2.LaraUserFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, larauser : people_dm.LaraUser = None) -> None:
        """ update a larauser model instance """
        try:
            res = await self.larauser_client.Update(
                lara_django_people_pb2.LaraUserRequest(**larauser.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating larauser_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a larauser by larauser_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.larauser_client.Destroy(lara_django_people_pb2.LaraUserDestroyRequest(larauser_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting larauser_id: {e}")

#_________________  MeetingCalendar  ______________________


class MeetingCalendarInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.meetingcalendar_client = lara_django_people_pb2_grpc.MeetingCalendarControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  meetingcalendars:  list[people_dm.MeetingCalendar] = None,  ids_only: bool = False) -> Union[list[str], list[people_dm.MeetingCalendar]]:
        try:
            create_coroutines = ( self.meetingcalendar_client.Create(lara_django_people_pb2.MeetingCalendarRequest(**meetingcalendar.model_dump())) for meetingcalendar in meetingcalendars )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.meetingcalendar_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating meetingcalendar: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        meetingcalendar_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[people_dm.MeetingCalendar]:
        """ retrieve a list of meetingcalendar instances by meetingcalendar_id, name or filter_dict,
               returns a list of meetingcalendar data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  meetingcalendar_id is not None:
            try:
                res =  await self.meetingcalendar_client.Retrieve(
                    lara_django_people_pb2.MeetingCalendarRetrieveRequest(meetingcalendar_id=meetingcalendar_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( people_dm.MeetingCalendar(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving meetingcalendar_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.meetingcalendar_client.List(
                    lara_django_people_pb2.MeetingCalendarListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ people_dm.MeetingCalendar(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving meetingcalendar name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the meetingcalendar_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].meetingcalendar_id
        else:
            raise ValueError(f"Error retrieving meetingcalendar_id - no or too many results found.")
    
    async def get_by_id(self, meetingcalendar_id: str = None) -> people_dm.MeetingCalendar:
        """ retrieve a meetingcalendar data model by meetingcalendar_id """
        try:
            res = await self.meetingcalendar_client.Retrieve(
                lara_django_people_pb2.MeetingCalendarRetrieveRequest(meetingcalendar_id=meetingcalendar_id)
            )
            return people_dm.MeetingCalendar(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving meetingcalendar_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> people_dm.MeetingCalendar | str:
        """ retrieve a meetingcalendar data model by name """
        try:
            res = await self.meetingcalendar_client.RetrieveByNameNamespace(
                lara_django_people_pb2.MeetingCalendarRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["meetingcalendar_id"]
            else:
                return people_dm.MeetingCalendar(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving meetingcalendar name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all meetingcalendars """
        if filter_dict is None:
            res = await self.meetingcalendar_client.List(lara_django_people_pb2.MeetingCalendarListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.meetingcalendar_client.List(
                lara_django_people_pb2.MeetingCalendarListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.meetingcalendar_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all meetingcalendars """
        if self.meetingcalendar_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.meetingcalendar_full_client.List(
                lara_django_people_pb2.MeetingCalendarFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.meetingcalendar_full_client.List(
                lara_django_people_pb2.MeetingCalendarFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, meetingcalendar : people_dm.MeetingCalendar = None) -> None:
        """ update a meetingcalendar model instance """
        try:
            res = await self.meetingcalendar_client.Update(
                lara_django_people_pb2.MeetingCalendarRequest(**meetingcalendar.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating meetingcalendar_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a meetingcalendar by meetingcalendar_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.meetingcalendar_client.Destroy(lara_django_people_pb2.MeetingCalendarDestroyRequest(meetingcalendar_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting meetingcalendar_id: {e}")

