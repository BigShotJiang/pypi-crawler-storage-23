"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django people relation resolver *

:details: The relation resolver is used to resolve foreign keys, e.g. by name or IRI instead of an id.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

import logging
import grpc
from typing import Any, Union, List, Dict, Tuple, Optional

from lara_django_base_grpc.relation_resolver_interface import (
    RetrMethod,
    RelationResolverBase,
)

from lara_django_base_grpc.lara_django_base_interface import AddressInterface
from lara_django_people_grpc.lara_django_people_interface import EntityInterface, EntityRoleInterface, EntityClassInterface

logger = logging.getLogger(__name__)

class EntityRelationResolver(RelationResolverBase):
    """Relation Resolver for LARA entity models"""

    def __init__(self, channel: grpc.Channel = None):
        try:
            self.address_if = AddressInterface(channel=channel)
            self.entity_class_if = EntityClassInterface(channel=channel)
        except Exception as e:
            logger.error(f"Error creating interfaces: {e}")

        self.relation_finder_dict = {
            "entity_class": [
                RetrMethod(
                    method=self.entity_class_if.retrieve_id, params={"name": "entity_class"}
                ),
            ],
            "address": [
                RetrMethod(
                    method=self.address_if.retrieve_id, params={"name": "address"}
                ),
            ],
        }

