from __future__ import annotations 

import re
import sys
from datetime import (
    date,
    datetime,
    time
)
from decimal import Decimal 
from enum import Enum 
from typing import (
    Any,
    ClassVar,
    Dict,
    List,
    Literal,
    Optional,
    Union
)

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    RootModel,
    field_validator
)


metamodel_version = "None"
version = "None"


class ConfiguredBaseModel(BaseModel):
    model_config = ConfigDict(
        validate_assignment = True,
        validate_default = True,
        extra = "forbid",
        arbitrary_types_allowed = True,
        use_enum_values = True,
        strict = False,
    )
    pass




class LinkMLMeta(RootModel):
    root: Dict[str, Any] = {}
    model_config = ConfigDict(frozen=True)

    def __getattr__(self, key:str):
        return getattr(self.root, key)

    def __getitem__(self, key:str):
        return self.root[key]

    def __setitem__(self, key:str, value):
        self.root[key] = value

    def __contains__(self, key:str) -> bool:
        return key in self.root


linkml_meta = LinkMLMeta({'default_prefix': 'lara',
     'default_range': 'string',
     'id': 'https://w3id.org/lara/lara_django_people',
     'imports': ['linkml:types'],
     'name': 'lara_django_people',
     'prefixes': {'lara': {'prefix_prefix': 'lara',
                           'prefix_reference': 'http://w3id.org/lara/'},
                  'linkml': {'prefix_prefix': 'linkml',
                             'prefix_reference': 'https://w3id.org/linkml/'},
                  'oso': {'prefix_prefix': 'oso',
                          'prefix_reference': 'http://w3id.org/oso/'}},
     'source_file': 'lara_django_people_schema.yaml',
     'types': {'FileField': {'base': 'str',
                             'description': 'A file field',
                             'from_schema': 'https://w3id.org/lara/lara_django_people',
                             'name': 'FileField',
                             'uri': 'https://w3id.org/lara/FileField'},
               'ImageField': {'base': 'str',
                              'description': 'An image field',
                              'from_schema': 'https://w3id.org/lara/lara_django_people',
                              'name': 'ImageField',
                              'uri': 'https://w3id.org/lara/ImageField'},
               'JSON': {'base': 'string',
                        'description': 'A JSON object',
                        'from_schema': 'https://w3id.org/lara/lara_django_people',
                        'name': 'JSON',
                        'repr': 'dict',
                        'uri': 'https://json.org'},
               'UUID': {'base': 'str',
                        'description': 'A UUID',
                        'from_schema': 'https://w3id.org/lara/lara_django_people',
                        'name': 'UUID',
                        'pattern': '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
                        'uri': 'https://datatracker.ietf.org/doc/html/rfc9562'}}} )


class MediaType(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.MediaType'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_people'})

    pass


class Namespace(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.Namespace'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_people'})

    pass


class Address(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.Address'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_people'})

    pass


class DataType(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.DataType'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_people'})

    pass


class Room(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.Room'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_people'})

    pass


class Location(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.Location'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_people'})

    pass


class GeoLocation(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.GeoLocation'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_people'})

    pass


class Tag(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.Tag'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_people'})

    pass


class Permission(ConfiguredBaseModel):
    """
    <class 'django.contrib.auth.models.Permission'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_people'})

    pass


class ExtraData(ConfiguredBaseModel):
    """
    \" This class can be used to extend data, by extra information,
        e.g., more telephone numbers, customer numbers, ...
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:people/ExtraData',
         'from_schema': 'https://w3id.org/lara/lara_django_people'})

    extradata_id: Optional[str] = Field(None, description="""ExtraData - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'extradata_id',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:people/ExtraData/extradata_id'} })
    data_type: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'data_type',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:base/DataType'} })
    namespace: str = Field(..., description="""namespace of data""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData', 'Group', 'EntitiesSubset', 'GroupsSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""Human readable display name or title of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'EntitiesSubset',
                       'GroupsSubset',
                       'MeetingCalendar'],
         'slot_uri': 'lara:people/ExtraData/name_display'} })
    name: Optional[str] = Field(None, description="""name of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'EntityClass',
                       'EntityRole',
                       'Group',
                       'EntitiesSubset',
                       'GroupsSubset'],
         'slot_uri': 'lara:people/ExtraData/name'} })
    name_full: Optional[str] = Field(None, description="""full name of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'name_full',
         'domain_of': ['ExtraData', 'Entity', 'Group'],
         'slot_uri': 'lara:people/ExtraData/name_full'} })
    version: Optional[str] = Field(None, description="""version of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'version',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:people/ExtraData/version'} })
    hash_sha256: Optional[str] = Field(None, description="""SHA256 hash of all data (JSON and XML)""", json_schema_extra = { "linkml_meta": {'alias': 'hash_sha256',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:people/ExtraData/hash_sha256'} })
    data_json: Optional[dict] = Field(None, description="""generic JSON field""", json_schema_extra = { "linkml_meta": {'alias': 'data_json',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:people/ExtraData/data_json'} })
    media_type: Optional[str] = Field(None, description="""IANA media type of extra data file""", json_schema_extra = { "linkml_meta": {'alias': 'media_type',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:base/MediaType'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData', 'EntityClass', 'EntityRole', 'Entity'],
         'slot_uri': 'lara:people/ExtraData/iri'} })
    url: Optional[str] = Field(None, description="""Universal Resource Locator - this can be used to link the data to external locations""", json_schema_extra = { "linkml_meta": {'alias': 'url',
         'domain_of': ['ExtraData', 'Entity'],
         'slot_uri': 'lara:people/ExtraData/url'} })
    datetime_created: Optional[str] = Field(None, description="""date and time when data was created""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_created',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:people/ExtraData/datetime_created'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Entity',
                       'Group',
                       'EntityBankAccount',
                       'EntitiesSubset',
                       'GroupsSubset',
                       'MeetingCalendar'],
         'slot_uri': 'lara:people/ExtraData/datetime_last_modified'} })
    description: Optional[str] = Field(None, description="""description of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'EntityClass',
                       'EntityRole',
                       'Group',
                       'EntityBankAccount',
                       'EntitiesSubset',
                       'GroupsSubset',
                       'MeetingCalendar'],
         'slot_uri': 'lara:people/ExtraData/description'} })
    file: Optional[str] = Field(None, description="""rel. path/filename""", json_schema_extra = { "linkml_meta": {'alias': 'file',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:people/ExtraData/file'} })
    image: Optional[str] = Field(None, description="""location room map rel. path/filename to image""", json_schema_extra = { "linkml_meta": {'alias': 'image',
         'domain_of': ['ExtraData', 'Entity'],
         'slot_uri': 'lara:people/ExtraData/image'} })
    office_room: Optional[str] = Field(None, description="""extra office""", json_schema_extra = { "linkml_meta": {'alias': 'office_room',
         'domain_of': ['ExtraData', 'Entity'],
         'slot_uri': 'lara:base/Room'} })
    laboratory: Optional[str] = Field(None, description="""extra laboratory""", json_schema_extra = { "linkml_meta": {'alias': 'laboratory',
         'domain_of': ['ExtraData', 'Entity'],
         'slot_uri': 'lara:base/Room'} })
    email: Optional[str] = Field(None, description="""extra email""", json_schema_extra = { "linkml_meta": {'alias': 'email',
         'domain_of': ['ExtraData', 'Entity', 'LaraUser'],
         'slot_uri': 'lara:people/ExtraData/email'} })


class EntityClass(ConfiguredBaseModel):
    """
    \" Entity class, like university, institute, company, organisation,
        but also guest_scientist, bachelor student, master, postdoc, group leader.
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:people/EntityClass',
         'from_schema': 'https://w3id.org/lara/lara_django_people'})

    entityclass_id: Optional[str] = Field(None, description="""EntityClass - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'entityclass_id',
         'domain_of': ['EntityClass'],
         'slot_uri': 'lara:people/EntityClass/entityclass_id'} })
    name: str = Field(..., description="""entity class, like university, institute, company, organisation""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'EntityClass',
                       'EntityRole',
                       'Group',
                       'EntitiesSubset',
                       'GroupsSubset'],
         'slot_uri': 'lara:people/EntityClass/name'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData', 'EntityClass', 'EntityRole', 'Entity'],
         'slot_uri': 'lara:people/EntityClass/iri'} })
    description: Optional[str] = Field(None, description="""description of the entity class""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'EntityClass',
                       'EntityRole',
                       'Group',
                       'EntityBankAccount',
                       'EntitiesSubset',
                       'GroupsSubset',
                       'MeetingCalendar'],
         'slot_uri': 'lara:people/EntityClass/description'} })


class EntityRole(ConfiguredBaseModel):
    """
    \" Entity role, like scientist, reviewer, developer, maintainer, student, postdoc, project leader, ...
        - remark: the CRedIT taxonomy (https://credit.niso.org/) could be used as an inspiration for roles
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:people/EntityRole',
         'from_schema': 'https://w3id.org/lara/lara_django_people'})

    entityrole_id: Optional[str] = Field(None, description="""EntityRole - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'entityrole_id',
         'domain_of': ['EntityRole'],
         'slot_uri': 'lara:people/EntityRole/entityrole_id'} })
    name: str = Field(..., description="""entity role, like guest_scientist,  bachelor student, master, postdoc, ...""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'EntityClass',
                       'EntityRole',
                       'Group',
                       'EntitiesSubset',
                       'GroupsSubset'],
         'slot_uri': 'lara:people/EntityRole/name'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData', 'EntityClass', 'EntityRole', 'Entity'],
         'slot_uri': 'lara:people/EntityRole/iri'} })
    description: Optional[str] = Field(None, description="""description of the entity role""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'EntityClass',
                       'EntityRole',
                       'Group',
                       'EntityBankAccount',
                       'EntitiesSubset',
                       'GroupsSubset',
                       'MeetingCalendar'],
         'slot_uri': 'lara:people/EntityRole/description'} })


class Entity(ConfiguredBaseModel):
    """
    \" Generic Entity Model. An Entity could be, e.g., a person or institution or company.
        The term \"entity\" encounters for this generalisation.
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:people/Entity',
         'from_schema': 'https://w3id.org/lara/lara_django_people'})

    entity_id: Optional[str] = Field(None, description="""Entity - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'entity_id',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/entity_id'} })
    slug: Optional[str] = Field(None, description="""slugs are used to display the entity in, e.g. URIs, auto generated, do not use any special characters""", json_schema_extra = { "linkml_meta": {'alias': 'slug',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/slug'} })
    entity_class: Optional[str] = Field(None, description="""class/type/position of the entity, e.g., university, institute, company""", json_schema_extra = { "linkml_meta": {'alias': 'entity_class',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/EntityClass'} })
    gender: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'gender',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/gender'} })
    title: Optional[str] = Field(None, description="""title of the person, e.g. Dr., Prof., Mr., Ms., ...""", json_schema_extra = { "linkml_meta": {'alias': 'title',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/title'} })
    name_first: Optional[str] = Field(None, description="""first name of a person or name of an institution/company""", json_schema_extra = { "linkml_meta": {'alias': 'name_first',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/name_first'} })
    names_middle: Optional[str] = Field(None, description="""list of middle names separated by space, e.g. Alfred Ernst Walter Neumann -> Ernst Walter""", json_schema_extra = { "linkml_meta": {'alias': 'names_middle',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/names_middle'} })
    name_last: Optional[str] = Field(None, description="""last name, e.g. vonSydow - aristocratic prepositions are part of the last name""", json_schema_extra = { "linkml_meta": {'alias': 'name_last',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/name_last'} })
    name_full: Optional[str] = Field(None, description="""full name, e.g. University of Greifswald, Institute for Biochemistry, Max vonSydow, is auto-generated when saved""", json_schema_extra = { "linkml_meta": {'alias': 'name_full',
         'domain_of': ['ExtraData', 'Entity', 'Group'],
         'slot_uri': 'lara:people/Entity/name_full'} })
    names_last_previous: Optional[str] = Field(None, description="""list of previous last names separated by space, e.g. changed after marriage, order: latest -> earliest""", json_schema_extra = { "linkml_meta": {'alias': 'names_last_previous',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/names_last_previous'} })
    name_nick: Optional[str] = Field(None, description="""the entities nickname, e.g., James -> Jim.""", json_schema_extra = { "linkml_meta": {'alias': 'name_nick',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/name_nick'} })
    acronym: Optional[str] = Field(None, description="""3 letter code, autogenerated, should be unique with an institution, could also be used for company acronyms""", json_schema_extra = { "linkml_meta": {'alias': 'acronym',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/acronym'} })
    url: Optional[str] = Field(None, description="""Universal Resource Locator - URL, web address of entity""", json_schema_extra = { "linkml_meta": {'alias': 'url',
         'domain_of': ['ExtraData', 'Entity'],
         'slot_uri': 'lara:people/Entity/url'} })
    pid: Optional[str] = Field(None, description="""handle URI""", json_schema_extra = { "linkml_meta": {'alias': 'pid', 'domain_of': ['Entity'], 'slot_uri': 'lara:people/Entity/pid'} })
    pac_id: Optional[str] = Field(None, description="""Publicly Addressable Content IDentifier is a globally unique identifier that operates independently of a central registry.""", json_schema_extra = { "linkml_meta": {'alias': 'pac_id',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/pac_id'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData', 'EntityClass', 'EntityRole', 'Entity'],
         'slot_uri': 'lara:people/Entity/iri'} })
    orcid: Optional[str] = Field(None, description="""ORCID is a unique researcher ID (just the ID, not the URL), s. https://orcid.org/""", json_schema_extra = { "linkml_meta": {'alias': 'orcid',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/orcid'} })
    ror: Optional[str] = Field(None, description="""ROR - Research Organization Registry s. https: // ror.readme.io/docs/ror-basics""", json_schema_extra = { "linkml_meta": {'alias': 'ror', 'domain_of': ['Entity'], 'slot_uri': 'lara:people/Entity/ror'} })
    barcode: Optional[str] = Field(None, description="""text representation of a barcode of the sample.""", json_schema_extra = { "linkml_meta": {'alias': 'barcode',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/barcode'} })
    barcode_json: Optional[dict] = Field(None, description="""Advanced barcodes in JSON for multiple barcode representations, like QR codes etc.""", json_schema_extra = { "linkml_meta": {'alias': 'barcode_json',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/barcode_json'} })
    tax_no: Optional[str] = Field(None, description="""Tax number""", json_schema_extra = { "linkml_meta": {'alias': 'tax_no',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/tax_no'} })
    vat_no: Optional[str] = Field(None, description="""Value Added Tax number""", json_schema_extra = { "linkml_meta": {'alias': 'vat_no',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/vat_no'} })
    toll_no: Optional[str] = Field(None, description="""Toll/EORI number""", json_schema_extra = { "linkml_meta": {'alias': 'toll_no',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/toll_no'} })
    interests_json: Optional[dict] = Field(None, description="""scientific interests and expertise, keywords with categories, in JSON(-LD) format""", json_schema_extra = { "linkml_meta": {'alias': 'interests_json',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/interests_json'} })
    affiliation_current: Optional[str] = Field(None, description="""affiliation of the entity""", json_schema_extra = { "linkml_meta": {'alias': 'affiliation_current',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity'} })
    affiliation_start: Optional[str] = Field(None, description="""start date at this affiliation, default: date of today""", json_schema_extra = { "linkml_meta": {'alias': 'affiliation_start',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/affiliation_start'} })
    affiliation_end: Optional[str] = Field(None, description="""end date at this affiliation, default: 9.9.9999""", json_schema_extra = { "linkml_meta": {'alias': 'affiliation_end',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/affiliation_end'} })
    office_room: Optional[str] = Field(None, description="""office""", json_schema_extra = { "linkml_meta": {'alias': 'office_room',
         'domain_of': ['ExtraData', 'Entity'],
         'slot_uri': 'lara:base/Room'} })
    laboratory: Optional[str] = Field(None, description="""laboratory""", json_schema_extra = { "linkml_meta": {'alias': 'laboratory',
         'domain_of': ['ExtraData', 'Entity'],
         'slot_uri': 'lara:base/Room'} })
    email: Optional[str] = Field(None, description="""entity's current official email address""", json_schema_extra = { "linkml_meta": {'alias': 'email',
         'domain_of': ['ExtraData', 'Entity', 'LaraUser'],
         'slot_uri': 'lara:people/Entity/email'} })
    email_private: Optional[str] = Field(None, description="""entity's email address""", json_schema_extra = { "linkml_meta": {'alias': 'email_private',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/email_private'} })
    email_permanent: Optional[str] = Field(None, description="""entity's permanents email address""", json_schema_extra = { "linkml_meta": {'alias': 'email_permanent',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/email_permanent'} })
    website: Optional[str] = Field(None, description="""entity's website URL""", json_schema_extra = { "linkml_meta": {'alias': 'website',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/website'} })
    phone_number_mobile: Optional[str] = Field(None, description="""entity's mobile phone number, if possible add the +Country code notation, e.g., +44 3834 420 4411""", json_schema_extra = { "linkml_meta": {'alias': 'phone_number_mobile',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/phone_number_mobile'} })
    phone_number_office: Optional[str] = Field(None, description="""entity's office phone number, if possible add the +Country code notation, e.g., +44 3834 420 4411""", json_schema_extra = { "linkml_meta": {'alias': 'phone_number_office',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/phone_number_office'} })
    phone_number_lab: Optional[str] = Field(None, description="""entity's lab phone number, if possible add the +Country code notation,e.g., +44 3834 420 4411""", json_schema_extra = { "linkml_meta": {'alias': 'phone_number_lab',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/phone_number_lab'} })
    phone_number_home: Optional[str] = Field(None, description="""entity's phone number at home, if possible add the +Country code notation,e.g., +44 3834 420 4411""", json_schema_extra = { "linkml_meta": {'alias': 'phone_number_home',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/phone_number_home'} })
    address: Optional[str] = Field(None, description="""reference to an address""", json_schema_extra = { "linkml_meta": {'alias': 'address', 'domain_of': ['Entity'], 'slot_uri': 'lara:base/Address'} })
    date_birth: Optional[str] = Field(None, description="""date of birth of the person, could also be the founding date of an institution.""", json_schema_extra = { "linkml_meta": {'alias': 'date_birth',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/date_birth'} })
    date_death: Optional[str] = Field(None, description="""date of death, could also be the closing date of an institution.""", json_schema_extra = { "linkml_meta": {'alias': 'date_death',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/date_death'} })
    color: Optional[str] = Field(None, description="""GUI colour representation of the entity, can be used in calendars, or gui elements""", json_schema_extra = { "linkml_meta": {'alias': 'color',
         'domain_of': ['Entity', 'MeetingCalendar'],
         'slot_uri': 'lara:people/Entity/color'} })
    icon: Optional[str] = Field(None, description="""XML/SVG icon/logo/avatar/drawing of the entity""", json_schema_extra = { "linkml_meta": {'alias': 'icon',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity/icon'} })
    image: Optional[str] = Field(None, description="""entity's image, rel. path/filename to image""", json_schema_extra = { "linkml_meta": {'alias': 'image',
         'domain_of': ['ExtraData', 'Entity'],
         'slot_uri': 'lara:people/Entity/image'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Entity',
                       'Group',
                       'EntityBankAccount',
                       'EntitiesSubset',
                       'GroupsSubset',
                       'MeetingCalendar'],
         'slot_uri': 'lara:people/Entity/datetime_last_modified'} })
    remarks: Optional[str] = Field(None, description="""remarks about the entity""", json_schema_extra = { "linkml_meta": {'alias': 'remarks',
         'domain_of': ['Entity', 'Group'],
         'slot_uri': 'lara:people/Entity/remarks'} })
    bank_accounts: Optional[List[str]] = Field(None, description="""expertise/skills/profession, keywords""", json_schema_extra = { "linkml_meta": {'alias': 'bank_accounts',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/EntityBankAccount'} })
    expertise: Optional[List[str]] = Field(None, description="""expertise/skills/profession, keywords""", json_schema_extra = { "linkml_meta": {'alias': 'expertise', 'domain_of': ['Entity'], 'slot_uri': 'lara:base/Tag'} })
    interests: Optional[List[str]] = Field(None, description="""scientific interests, keywords""", json_schema_extra = { "linkml_meta": {'alias': 'interests', 'domain_of': ['Entity'], 'slot_uri': 'lara:base/Tag'} })
    work_topics: Optional[List[str]] = Field(None, description="""work/research topics, keywords, e.g. transaminases, electrochemistry, fuel cell development""", json_schema_extra = { "linkml_meta": {'alias': 'work_topics', 'domain_of': ['Entity'], 'slot_uri': 'lara:base/Tag'} })
    roles: Optional[List[str]] = Field(None, description="""roles of the entity, e.g. project leader, postdoc, bachelor student, master student, guest scientist, ...""", json_schema_extra = { "linkml_meta": {'alias': 'roles',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/EntityRole'} })
    affiliation_previous: Optional[List[str]] = Field(None, description="""previous affiliations of the entity""", json_schema_extra = { "linkml_meta": {'alias': 'affiliation_previous',
         'domain_of': ['Entity'],
         'slot_uri': 'lara:people/Entity'} })
    data_extra: Optional[List[str]] = Field(None, description="""e.g. ResearcherID, Scopus Author ID, extra laboratories ...""", json_schema_extra = { "linkml_meta": {'alias': 'data_extra',
         'domain_of': ['Entity', 'EntityBankAccount'],
         'slot_uri': 'lara:people/ExtraData'} })


class Group(ConfiguredBaseModel):
    """
    \" A group is a collection of entities, e.g. a working group, a project group, a group of developers, ... \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:people/Group',
         'from_schema': 'https://w3id.org/lara/lara_django_people'})

    group_id: Optional[str] = Field(None, description="""Group - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'group_id',
         'domain_of': ['Group'],
         'slot_uri': 'lara:people/Group/group_id'} })
    namespace: Optional[str] = Field(None, description="""namespace of group""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData', 'Group', 'EntitiesSubset', 'GroupsSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    group_class: Optional[str] = Field(None, description="""class/type/position of the group, e.g., administrators, developers, ...""", json_schema_extra = { "linkml_meta": {'alias': 'group_class',
         'domain_of': ['Group'],
         'slot_uri': 'lara:people/EntityClass'} })
    name: str = Field(..., description="""name of group""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'EntityClass',
                       'EntityRole',
                       'Group',
                       'EntitiesSubset',
                       'GroupsSubset'],
         'slot_uri': 'lara:people/Group/name'} })
    name_full: Optional[str] = Field(None, description="""full name, is auto-generated when saved""", json_schema_extra = { "linkml_meta": {'alias': 'name_full',
         'domain_of': ['ExtraData', 'Entity', 'Group'],
         'slot_uri': 'lara:people/Group/name_full'} })
    django_group: Optional[str] = Field(None, description="""Django group""", json_schema_extra = { "linkml_meta": {'alias': 'django_group',
         'domain_of': ['Group'],
         'slot_uri': 'lara:people/Group'} })
    description: Optional[str] = Field(None, description="""description of group""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'EntityClass',
                       'EntityRole',
                       'Group',
                       'EntityBankAccount',
                       'EntitiesSubset',
                       'GroupsSubset',
                       'MeetingCalendar'],
         'slot_uri': 'lara:people/Group/description'} })
    remarks: Optional[str] = Field(None, description="""remarks about the group""", json_schema_extra = { "linkml_meta": {'alias': 'remarks',
         'domain_of': ['Entity', 'Group'],
         'slot_uri': 'lara:people/Group/remarks'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Entity',
                       'Group',
                       'EntityBankAccount',
                       'EntitiesSubset',
                       'GroupsSubset',
                       'MeetingCalendar'],
         'slot_uri': 'lara:people/Group/datetime_last_modified'} })
    members: Optional[List[str]] = Field(None, description="""members of group""", json_schema_extra = { "linkml_meta": {'alias': 'members', 'domain_of': ['Group'], 'slot_uri': 'lara:people/Entity'} })


class EntityBankAccount(ConfiguredBaseModel):
    """
    \" Bank account of an Entity. \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:people/EntityBankAccount',
         'from_schema': 'https://w3id.org/lara/lara_django_people'})

    entitybankaccount_id: Optional[str] = Field(None, description="""EntityBankAccount - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'entitybankaccount_id',
         'domain_of': ['EntityBankAccount'],
         'slot_uri': 'lara:people/EntityBankAccount/entitybankaccount_id'} })
    name_account: str = Field(..., description="""label/name of bank account - not name of account holder !""", json_schema_extra = { "linkml_meta": {'alias': 'name_account',
         'domain_of': ['EntityBankAccount'],
         'slot_uri': 'lara:people/EntityBankAccount/name_account'} })
    account_no: str = Field(..., description="""Account Number - for flexibility this is a text field""", json_schema_extra = { "linkml_meta": {'alias': 'account_no',
         'domain_of': ['EntityBankAccount'],
         'slot_uri': 'lara:people/EntityBankAccount/account_no'} })
    iban: str = Field(..., description="""iban of account""", json_schema_extra = { "linkml_meta": {'alias': 'iban',
         'domain_of': ['EntityBankAccount'],
         'slot_uri': 'lara:people/EntityBankAccount/iban'} })
    bic: str = Field(..., description="""bic of account""", json_schema_extra = { "linkml_meta": {'alias': 'bic',
         'domain_of': ['EntityBankAccount'],
         'slot_uri': 'lara:people/EntityBankAccount/bic'} })
    bank: Optional[str] = Field(None, description="""bank entity""", json_schema_extra = { "linkml_meta": {'alias': 'bank',
         'domain_of': ['EntityBankAccount'],
         'slot_uri': 'lara:people/Entity'} })
    description: Optional[str] = Field(None, description="""description/remarks of account""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'EntityClass',
                       'EntityRole',
                       'Group',
                       'EntityBankAccount',
                       'EntitiesSubset',
                       'GroupsSubset',
                       'MeetingCalendar'],
         'slot_uri': 'lara:people/EntityBankAccount/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Entity',
                       'Group',
                       'EntityBankAccount',
                       'EntitiesSubset',
                       'GroupsSubset',
                       'MeetingCalendar'],
         'slot_uri': 'lara:people/EntityBankAccount/datetime_last_modified'} })
    data_extra: Optional[List[str]] = Field(None, description="""additions to bank account ...""", json_schema_extra = { "linkml_meta": {'alias': 'data_extra',
         'domain_of': ['Entity', 'EntityBankAccount'],
         'slot_uri': 'lara:people/ExtraData'} })


class EntitiesSubset(ConfiguredBaseModel):
    """
    \" Entities subset - a selection of entities, e.g. for orders, projects, ... \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:people/EntitiesSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_people'})

    namespace: Optional[str] = Field(None, description="""namespace of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData', 'Group', 'EntitiesSubset', 'GroupsSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""display name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'EntitiesSubset',
                       'GroupsSubset',
                       'MeetingCalendar'],
         'slot_uri': 'lara:people/EntitiesSubset/name_display'} })
    name: Optional[str] = Field(None, description="""name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'EntityClass',
                       'EntityRole',
                       'Group',
                       'EntitiesSubset',
                       'GroupsSubset'],
         'slot_uri': 'lara:people/EntitiesSubset/name'} })
    entity: Optional[str] = Field(None, description="""user who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['EntitiesSubset',
                       'OrderedEntitiesSubset',
                       'GroupsSubset',
                       'LaraUser'],
         'slot_uri': 'lara:people/Entity'} })
    group: Optional[str] = Field(None, description="""group who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'group',
         'domain_of': ['EntitiesSubset', 'GroupsSubset', 'OrderedGroupsSubset'],
         'slot_uri': 'lara:people/Group'} })
    description: Optional[str] = Field(None, description="""description of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'EntityClass',
                       'EntityRole',
                       'Group',
                       'EntityBankAccount',
                       'EntitiesSubset',
                       'GroupsSubset',
                       'MeetingCalendar'],
         'slot_uri': 'lara:people/EntitiesSubset/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last modification of the selection""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Entity',
                       'Group',
                       'EntityBankAccount',
                       'EntitiesSubset',
                       'GroupsSubset',
                       'MeetingCalendar'],
         'slot_uri': 'lara:people/EntitiesSubset/datetime_last_modified'} })
    entitysubset_id: Optional[str] = Field(None, description="""EntitiesSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'entitysubset_id',
         'domain_of': ['EntitiesSubset'],
         'slot_uri': 'lara:people/EntitiesSubset/entitysubset_id'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['EntitiesSubset', 'GroupsSubset', 'MeetingCalendar'],
         'slot_uri': 'lara:base/Tag'} })
    entities: Optional[List[str]] = Field(None, description="""entities in subset""", json_schema_extra = { "linkml_meta": {'alias': 'entities',
         'domain_of': ['EntitiesSubset'],
         'slot_uri': 'lara:people/Entity'} })


class OrderedEntitiesSubset(ConfiguredBaseModel):
    """
    \" Through model for the many-to-many relationship between EntitiesSubset and Entity. \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:people/OrderedEntitiesSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_people'})

    orderedentitiessubset_id: Optional[str] = Field(None, description="""OrderedEntitiesSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'orderedentitiessubset_id',
         'domain_of': ['OrderedEntitiesSubset'],
         'slot_uri': 'lara:people/OrderedEntitiesSubset/orderedentitiessubset_id'} })
    entity: str = Field(..., description="""entity in subset""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['EntitiesSubset',
                       'OrderedEntitiesSubset',
                       'GroupsSubset',
                       'LaraUser'],
         'slot_uri': 'lara:people/Entity'} })
    entities_subset: str = Field(..., description="""subset of entities""", json_schema_extra = { "linkml_meta": {'alias': 'entities_subset',
         'domain_of': ['OrderedEntitiesSubset'],
         'slot_uri': 'lara:people/EntitiesSubset'} })
    order: int = Field(..., description="""order of entity in subset""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedEntitiesSubset', 'OrderedGroupsSubset'],
         'slot_uri': 'lara:people/OrderedEntitiesSubset/order'} })


class GroupsSubset(ConfiguredBaseModel):
    """
    \" Groups subset - a selection of groups, e.g. for orders, projects, ... \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:people/GroupsSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_people'})

    namespace: Optional[str] = Field(None, description="""namespace of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData', 'Group', 'EntitiesSubset', 'GroupsSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""display name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'EntitiesSubset',
                       'GroupsSubset',
                       'MeetingCalendar'],
         'slot_uri': 'lara:people/GroupsSubset/name_display'} })
    name: Optional[str] = Field(None, description="""name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'EntityClass',
                       'EntityRole',
                       'Group',
                       'EntitiesSubset',
                       'GroupsSubset'],
         'slot_uri': 'lara:people/GroupsSubset/name'} })
    entity: Optional[str] = Field(None, description="""user who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['EntitiesSubset',
                       'OrderedEntitiesSubset',
                       'GroupsSubset',
                       'LaraUser'],
         'slot_uri': 'lara:people/Entity'} })
    group: Optional[str] = Field(None, description="""group who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'group',
         'domain_of': ['EntitiesSubset', 'GroupsSubset', 'OrderedGroupsSubset'],
         'slot_uri': 'lara:people/Group'} })
    description: Optional[str] = Field(None, description="""description of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'EntityClass',
                       'EntityRole',
                       'Group',
                       'EntityBankAccount',
                       'EntitiesSubset',
                       'GroupsSubset',
                       'MeetingCalendar'],
         'slot_uri': 'lara:people/GroupsSubset/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last modification of the selection""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Entity',
                       'Group',
                       'EntityBankAccount',
                       'EntitiesSubset',
                       'GroupsSubset',
                       'MeetingCalendar'],
         'slot_uri': 'lara:people/GroupsSubset/datetime_last_modified'} })
    groupsubset_id: Optional[str] = Field(None, description="""GroupsSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'groupsubset_id',
         'domain_of': ['GroupsSubset'],
         'slot_uri': 'lara:people/GroupsSubset/groupsubset_id'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['EntitiesSubset', 'GroupsSubset', 'MeetingCalendar'],
         'slot_uri': 'lara:base/Tag'} })
    groups: Optional[List[str]] = Field(None, description="""groups in subset""", json_schema_extra = { "linkml_meta": {'alias': 'groups',
         'domain_of': ['GroupsSubset', 'LaraUser', 'Container'],
         'slot_uri': 'lara:people/Group'} })


class OrderedGroupsSubset(ConfiguredBaseModel):
    """
    \" Through model for the many-to-many relationship between GroupsSubset and Group. \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:people/OrderedGroupsSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_people'})

    orderedgroupssubset_id: Optional[str] = Field(None, description="""OrderedGroupsSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'orderedgroupssubset_id',
         'domain_of': ['OrderedGroupsSubset'],
         'slot_uri': 'lara:people/OrderedGroupsSubset/orderedgroupssubset_id'} })
    group: str = Field(..., description="""group in subset""", json_schema_extra = { "linkml_meta": {'alias': 'group',
         'domain_of': ['EntitiesSubset', 'GroupsSubset', 'OrderedGroupsSubset'],
         'slot_uri': 'lara:people/Group'} })
    groups_subset: str = Field(..., description="""subset of groups""", json_schema_extra = { "linkml_meta": {'alias': 'groups_subset',
         'domain_of': ['OrderedGroupsSubset'],
         'slot_uri': 'lara:people/GroupsSubset'} })
    order: int = Field(..., description="""order of group in subset""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedEntitiesSubset', 'OrderedGroupsSubset'],
         'slot_uri': 'lara:people/OrderedGroupsSubset/order'} })


class LaraUser(ConfiguredBaseModel):
    """
    \" lara user: an extension of the default django user model to cover entity information
        it extends the django.contrib.auth.models AbstractUser model by an Entity.
        It is used for authentication and authorisation in the (local) LARA system.
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:people/LaraUser',
         'from_schema': 'https://w3id.org/lara/lara_django_people'})

    password: str = Field(..., json_schema_extra = { "linkml_meta": {'alias': 'password',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/password'} })
    last_login: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'last_login',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/last_login'} })
    is_superuser: bool = Field(..., description="""Designates that this user has all permissions without explicitly assigning them.""", json_schema_extra = { "linkml_meta": {'alias': 'is_superuser',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/is_superuser'} })
    username: str = Field(..., description="""Required. 150 characters or fewer. Letters, digits and @/./+/-/_ only.""", json_schema_extra = { "linkml_meta": {'alias': 'username',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/username'} })
    first_name: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'first_name',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/first_name'} })
    last_name: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'last_name',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/last_name'} })
    email: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'email',
         'domain_of': ['ExtraData', 'Entity', 'LaraUser'],
         'slot_uri': 'lara:people/LaraUser/email'} })
    is_staff: bool = Field(..., description="""Designates whether the user can log into this admin site.""", json_schema_extra = { "linkml_meta": {'alias': 'is_staff',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/is_staff'} })
    is_active: bool = Field(..., description="""Designates whether this user should be treated as active. Unselect this instead of deleting accounts.""", json_schema_extra = { "linkml_meta": {'alias': 'is_active',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/is_active'} })
    date_joined: str = Field(..., json_schema_extra = { "linkml_meta": {'alias': 'date_joined',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/date_joined'} })
    larauser_id: Optional[str] = Field(None, description="""LaraUser - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'larauser_id',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/larauser_id'} })
    entity: Optional[str] = Field(None, description="""related Entity - storing the complete Affiliation info etc.""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['EntitiesSubset',
                       'OrderedEntitiesSubset',
                       'GroupsSubset',
                       'LaraUser'],
         'slot_uri': 'lara:people/Entity'} })
    home_screen_url: Optional[str] = Field(None, description="""URL to the home screen - this is the default screen after login and can be changed by the user""", json_schema_extra = { "linkml_meta": {'alias': 'home_screen_url',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/home_screen_url'} })
    home_screen_layout: Optional[dict] = Field(None, description="""layout = what to see on the home screen""", json_schema_extra = { "linkml_meta": {'alias': 'home_screen_layout',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/home_screen_layout'} })
    ui_color_scheme: Optional[dict] = Field(None, description="""color scheme for the user interface""", json_schema_extra = { "linkml_meta": {'alias': 'ui_color_scheme',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/ui_color_scheme'} })
    namespace_default: Optional[str] = Field(None, description="""default namespace for the user""", json_schema_extra = { "linkml_meta": {'alias': 'namespace_default',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:base/Namespace'} })
    access_token: Optional[str] = Field(None, description="""LARA-django (API) access token""", json_schema_extra = { "linkml_meta": {'alias': 'access_token',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/access_token'} })
    access_control: Optional[dict] = Field(None, description="""Access control, similar to Linux ACL""", json_schema_extra = { "linkml_meta": {'alias': 'access_control',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/access_control'} })
    confirmation_token: Optional[str] = Field(None, description="""LARA-django e-mail confirmation token""", json_schema_extra = { "linkml_meta": {'alias': 'confirmation_token',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/confirmation_token'} })
    email_confirmed: Optional[str] = Field(None, description="""LARA user confirmed e-mail""", json_schema_extra = { "linkml_meta": {'alias': 'email_confirmed',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/email_confirmed'} })
    email_recover: Optional[str] = Field(None, description="""LARA user account recovering e-mail""", json_schema_extra = { "linkml_meta": {'alias': 'email_recover',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/email_recover'} })
    max_logins: Optional[int] = Field(None, description="""max number of logins""", json_schema_extra = { "linkml_meta": {'alias': 'max_logins',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/max_logins'} })
    failed_logins: Optional[int] = Field(None, description="""number of failed login attempts""", json_schema_extra = { "linkml_meta": {'alias': 'failed_logins',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/failed_logins'} })
    ip_curr_login: Optional[str] = Field(None, description="""IP address of current  login""", json_schema_extra = { "linkml_meta": {'alias': 'ip_curr_login',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/ip_curr_login'} })
    ip_last_login: Optional[str] = Field(None, description="""IP address of last login""", json_schema_extra = { "linkml_meta": {'alias': 'ip_last_login',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/ip_last_login'} })
    messenger_configuration: Optional[dict] = Field(None, description="""configuration of messengers, like matrix, email, ...""", json_schema_extra = { "linkml_meta": {'alias': 'messenger_configuration',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/messenger_configuration'} })
    datetime_confirmed: Optional[str] = Field(None, description="""datetime of confirmation""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_confirmed',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/datetime_confirmed'} })
    datetime_confirmation_sent: Optional[str] = Field(None, description="""datetime of confirmation was sent to the user""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_confirmation_sent',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/LaraUser/datetime_confirmation_sent'} })
    groups: Optional[List[str]] = Field(None, description="""The groups this user belongs to. A user will get all permissions granted to each of their groups.""", json_schema_extra = { "linkml_meta": {'alias': 'groups',
         'domain_of': ['GroupsSubset', 'LaraUser', 'Container'],
         'slot_uri': 'lara:people/Group'} })
    user_permissions: Optional[List[str]] = Field(None, description="""Specific permissions for this user.""", json_schema_extra = { "linkml_meta": {'alias': 'user_permissions',
         'domain_of': ['LaraUser'],
         'slot_uri': 'lara:people/Permission'} })


class MeetingCalendar(ConfiguredBaseModel):
    """
    \" Meeting Calendar \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:people/MeetingsCalendar',
         'from_schema': 'https://w3id.org/lara/lara_django_people'})

    name_display: str = Field(..., description="""title of the calendar entry""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'EntitiesSubset',
                       'GroupsSubset',
                       'MeetingCalendar'],
         'slot_uri': 'lara:people/MeetingsCalendar/name_display'} })
    calendar_url: Optional[str] = Field(None, description="""Universal Resource Locator (URL), to google calendar, iCalendar, .... """, json_schema_extra = { "linkml_meta": {'alias': 'calendar_url',
         'domain_of': ['MeetingCalendar'],
         'slot_uri': 'lara:people/MeetingsCalendar/calendar_url'} })
    summary: Optional[str] = Field(None, description="""short summary text of the calendar entry""", json_schema_extra = { "linkml_meta": {'alias': 'summary',
         'domain_of': ['MeetingCalendar'],
         'slot_uri': 'lara:people/MeetingsCalendar/summary'} })
    description: Optional[str] = Field(None, description="""text of the calendar entry""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'EntityClass',
                       'EntityRole',
                       'Group',
                       'EntityBankAccount',
                       'EntitiesSubset',
                       'GroupsSubset',
                       'MeetingCalendar'],
         'slot_uri': 'lara:people/MeetingsCalendar/description'} })
    color: Optional[str] = Field(None, description="""text of the calendar entry""", json_schema_extra = { "linkml_meta": {'alias': 'color',
         'domain_of': ['Entity', 'MeetingCalendar'],
         'slot_uri': 'lara:people/MeetingsCalendar/color'} })
    ics: Optional[str] = Field(None, description="""iCalendar entry in (RFC 5545) file format""", json_schema_extra = { "linkml_meta": {'alias': 'ics',
         'domain_of': ['MeetingCalendar'],
         'slot_uri': 'lara:people/MeetingsCalendar/ics'} })
    datetime_start: str = Field(..., description="""start date & time of the event. RFC 5545 - DTSTART""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_start',
         'domain_of': ['MeetingCalendar'],
         'slot_uri': 'lara:people/MeetingsCalendar/datetime_start'} })
    datetime_end: str = Field(..., description="""end datetime of the event. RFC 5545 - DTEND""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_end',
         'domain_of': ['MeetingCalendar'],
         'slot_uri': 'lara:people/MeetingsCalendar/datetime_end'} })
    duration: Optional[str] = Field(None, description=""" This value type is used to identify properties that contain a duration of time. RFC 5545 - DURATION""", json_schema_extra = { "linkml_meta": {'alias': 'duration',
         'domain_of': ['MeetingCalendar'],
         'slot_uri': 'lara:people/MeetingsCalendar/duration'} })
    all_day: bool = Field(..., description="""All day event ? (boolean)""", json_schema_extra = { "linkml_meta": {'alias': 'all_day',
         'domain_of': ['MeetingCalendar'],
         'slot_uri': 'lara:people/MeetingsCalendar/all_day'} })
    created: str = Field(..., description="""end datetime of the event""", json_schema_extra = { "linkml_meta": {'alias': 'created',
         'domain_of': ['MeetingCalendar'],
         'slot_uri': 'lara:people/MeetingsCalendar/created'} })
    datetime_last_modified: str = Field(..., description="""date and time when calendar entry was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Entity',
                       'Group',
                       'EntityBankAccount',
                       'EntitiesSubset',
                       'GroupsSubset',
                       'MeetingCalendar'],
         'slot_uri': 'lara:people/MeetingsCalendar/datetime_last_modified'} })
    timestamp: str = Field(..., description="""timestamp of the event""", json_schema_extra = { "linkml_meta": {'alias': 'timestamp',
         'domain_of': ['MeetingCalendar'],
         'slot_uri': 'lara:people/MeetingsCalendar/timestamp'} })
    location: Optional[str] = Field(None, description="""location""", json_schema_extra = { "linkml_meta": {'alias': 'location',
         'domain_of': ['MeetingCalendar'],
         'slot_uri': 'lara:base/Location'} })
    geolocation: Optional[str] = Field(None, description="""GEO location""", json_schema_extra = { "linkml_meta": {'alias': 'geolocation',
         'domain_of': ['MeetingCalendar'],
         'slot_uri': 'lara:base/GeoLocation'} })
    conference_url: Optional[str] = Field(None, description="""audio/video conference/meeting Universal Resource Locator (URL), e.g. zoom, jitsi, meet, ...""", json_schema_extra = { "linkml_meta": {'alias': 'conference_url',
         'domain_of': ['MeetingCalendar'],
         'slot_uri': 'lara:people/MeetingsCalendar/conference_url'} })
    range: Optional[str] = Field(None, description="""To specify the effective range of recurrence instances from the instance specified by the recurrence identifier specified by the property. RFC 5545 - RANGE """, json_schema_extra = { "linkml_meta": {'alias': 'range',
         'domain_of': ['MeetingCalendar'],
         'slot_uri': 'lara:people/MeetingsCalendar/range'} })
    related: Optional[str] = Field(None, description="""To specify the relationship of the alarm trigger with respect to the start or end of the calendar component. RFC 5545 - RELATED""", json_schema_extra = { "linkml_meta": {'alias': 'related',
         'domain_of': ['MeetingCalendar'],
         'slot_uri': 'lara:people/MeetingsCalendar/related'} })
    role: Optional[str] = Field(None, description="""To specify the participation role for the calendar user specified by the property. RFC 5545 - ROLE""", json_schema_extra = { "linkml_meta": {'alias': 'role',
         'domain_of': ['MeetingCalendar'],
         'slot_uri': 'lara:people/MeetingsCalendar/role'} })
    tzid: Optional[str] = Field(None, description="""To specify the identifier for the time zone definition for a time component in the property value. RFC 5545 - TZID""", json_schema_extra = { "linkml_meta": {'alias': 'tzid',
         'domain_of': ['MeetingCalendar'],
         'slot_uri': 'lara:people/MeetingsCalendar/tzid'} })
    offset_utc: Optional[int] = Field(None, description=""" This value type is used to identify properties that contain an offset from UTC to local time (+ or - num. hours) . RFC 5545 -  UTC-OFFSET""", json_schema_extra = { "linkml_meta": {'alias': 'offset_utc',
         'domain_of': ['MeetingCalendar'],
         'slot_uri': 'lara:people/MeetingsCalendar/offset_utc'} })
    alarm_repeat_json: Optional[dict] = Field(None, description="""advanced alarm repeat expressions possible, e.g. for uneven occurrences""", json_schema_extra = { "linkml_meta": {'alias': 'alarm_repeat_json',
         'domain_of': ['MeetingCalendar'],
         'slot_uri': 'lara:people/MeetingsCalendar/alarm_repeat_json'} })
    event_repeat: Optional[str] = Field(None, description="""apache airflow ('@daily', '@weekly') or cron expression like entry: '12 23 * * *' : every day at 23:12h do this task""", json_schema_extra = { "linkml_meta": {'alias': 'event_repeat',
         'domain_of': ['MeetingCalendar'],
         'slot_uri': 'lara:people/MeetingsCalendar/event_repeat'} })
    event_repeat_json: Optional[dict] = Field(None, description="""advanced event repeat expressions possible, e.g. for uneven occurrences""", json_schema_extra = { "linkml_meta": {'alias': 'event_repeat_json',
         'domain_of': ['MeetingCalendar'],
         'slot_uri': 'lara:people/MeetingsCalendar/event_repeat_json'} })
    meetingcalendar_id: Optional[str] = Field(None, description="""MeetingCalendar - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'meetingcalendar_id',
         'domain_of': ['MeetingCalendar'],
         'slot_uri': 'lara:people/MeetingsCalendar/meetingcalendar_id'} })
    organiser: Optional[str] = Field(None, description="""LARA User, who created the calendar entry""", json_schema_extra = { "linkml_meta": {'alias': 'organiser',
         'domain_of': ['MeetingCalendar'],
         'slot_uri': 'lara:people/LaraUser'} })
    tags: Optional[List[str]] = Field(None, description="""tags of calendar entry""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['EntitiesSubset', 'GroupsSubset', 'MeetingCalendar'],
         'slot_uri': 'lara:base/Tag'} })
    attendees: Optional[List[str]] = Field(None, description="""attendees of the meeting""", json_schema_extra = { "linkml_meta": {'alias': 'attendees',
         'domain_of': ['MeetingCalendar'],
         'slot_uri': 'lara:people/LaraUser'} })


class Container(ConfiguredBaseModel):
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_people', 'tree_root': True})

    extradatas: Optional[List[ExtraData]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'extradatas', 'domain_of': ['Container']} })
    entityclasss: Optional[List[EntityClass]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'entityclasss', 'domain_of': ['Container']} })
    entityroles: Optional[List[EntityRole]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'entityroles', 'domain_of': ['Container']} })
    entitys: Optional[List[Entity]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'entitys', 'domain_of': ['Container']} })
    groups: Optional[List[Group]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'groups', 'domain_of': ['GroupsSubset', 'LaraUser', 'Container']} })
    entitybankaccounts: Optional[List[EntityBankAccount]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'entitybankaccounts', 'domain_of': ['Container']} })
    entitiessubsets: Optional[List[EntitiesSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'entitiessubsets', 'domain_of': ['Container']} })
    orderedentitiessubsets: Optional[List[OrderedEntitiesSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'orderedentitiessubsets', 'domain_of': ['Container']} })
    groupssubsets: Optional[List[GroupsSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'groupssubsets', 'domain_of': ['Container']} })
    orderedgroupssubsets: Optional[List[OrderedGroupsSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'orderedgroupssubsets', 'domain_of': ['Container']} })
    larausers: Optional[List[LaraUser]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'larausers', 'domain_of': ['Container']} })
    meetingcalendars: Optional[List[MeetingCalendar]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'meetingcalendars', 'domain_of': ['Container']} })


# Model rebuild
# see https://pydantic-docs.helpmanual.io/usage/models/#rebuilding-a-model
MediaType.model_rebuild()
Namespace.model_rebuild()
Address.model_rebuild()
DataType.model_rebuild()
Room.model_rebuild()
Location.model_rebuild()
GeoLocation.model_rebuild()
Tag.model_rebuild()
Permission.model_rebuild()
ExtraData.model_rebuild()
EntityClass.model_rebuild()
EntityRole.model_rebuild()
Entity.model_rebuild()
Group.model_rebuild()
EntityBankAccount.model_rebuild()
EntitiesSubset.model_rebuild()
OrderedEntitiesSubset.model_rebuild()
GroupsSubset.model_rebuild()
OrderedGroupsSubset.model_rebuild()
LaraUser.model_rebuild()
MeetingCalendar.model_rebuild()
Container.model_rebuild()

