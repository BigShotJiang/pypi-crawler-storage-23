"""Allow running wuzup as ``python -m wuzup``."""

from wuzup.cli import main

if __name__ == "__main__":
    main()
