"""
────────────────────────────────────────────────────────
    ```python
    from suitkaise import Circuit
    from suitkaise.circuits import Circuit
    ```
────────────────────────────────────────────────────────\n

Circuits - Circuit Breaker for Controlled Failure Handling

This module provides a circuit breaker pattern implementation for 
controlled failure handling and resource management in loops.

Philosophy: Prevent runaway processes and provide graceful degradation.
"""

# Import all API functions and classes
from .api import Circuit, BreakingCircuit

__all__ = [
    'Circuit',
    'BreakingCircuit',
]

# Module metadata
__version__ = "0.4.13"
__author__ = "Casey Eddings"

