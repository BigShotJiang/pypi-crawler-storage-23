"""
Internal implementation for sk module.
"""
