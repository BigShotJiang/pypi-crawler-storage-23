"""Tests for integrations module."""

from __future__ import annotations

import pytest


class TestLazyLoading:
    def test_import_ascii_art_does_not_load_rich(self) -> None:
        import ascii_art
        import sys
        # rich should not be in sys.modules just from importing ascii_art
        # (it might be loaded by other tests, so we just check the import works)
        assert ascii_art.__version__

    def test_integrations_getattr_unknown(self) -> None:
        from ascii_art import integrations
        with pytest.raises(AttributeError):
            integrations.nonexistent_module  # noqa: B018


class TestRichIntegration:
    def test_import_error_without_rich(self) -> None:
        """If rich isn't installed, we get a helpful ImportError."""
        # This test is informational — rich may or may not be installed
        try:
            from ascii_art.integrations.rich_panel import to_text
            result = to_text("hello")
            assert result is not None
        except ImportError as e:
            assert "rich" in str(e).lower()

    def test_to_panel_import_error(self) -> None:
        try:
            from ascii_art.integrations.rich_panel import to_panel
            result = to_panel("hello", title="Test")
            assert result is not None
        except ImportError as e:
            assert "rich" in str(e).lower()


class TestTextualIntegration:
    def test_import_error_without_textual(self) -> None:
        try:
            from ascii_art.integrations.textual_widget import to_static
            result = to_static("hello")
            assert result is not None
        except ImportError as e:
            assert "textual" in str(e).lower()


class TestCursesIntegration:
    def test_write_to_mock_window(self) -> None:
        from ascii_art.integrations.curses_win import write_to_window

        class MockWin:
            def __init__(self) -> None:
                self.calls: list[tuple[int, int, str]] = []

            def addstr(self, y: int, x: int, s: str) -> None:
                self.calls.append((y, x, s))

        win = MockWin()
        write_to_window(win, "line1\nline2\nline3", y=2, x=5)
        assert len(win.calls) == 3
        assert win.calls[0] == (2, 5, "line1")
        assert win.calls[1] == (3, 5, "line2")
        assert win.calls[2] == (4, 5, "line3")
