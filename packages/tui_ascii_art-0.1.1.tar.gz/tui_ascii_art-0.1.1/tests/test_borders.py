"""Tests for ascii_art.borders — frame, divider, and BorderBuilder."""

from ascii_art._types import BorderStyle
from ascii_art.borders import BorderBuilder, divider, frame


# ── frame: single-line text ──────────────────────────────────────────

class TestFrameSingleLine:
    def test_default_single_style(self):
        result = frame("hello")
        lines = result.split("\n")
        assert lines[0] == "┌───────┐"   # 5 + 2*1 padding = 7 inner
        assert lines[1] == "│ hello │"
        assert lines[2] == "└───────┘"

    def test_auto_width(self):
        result = frame("ab")
        lines = result.split("\n")
        # inner = 2 + 2*1 = 4, width = 6
        assert len(lines[0]) == 6

    def test_empty_string(self):
        result = frame("")
        lines = result.split("\n")
        assert len(lines) == 3
        assert lines[1].startswith("│")


# ── frame: multi-line text ───────────────────────────────────────────

class TestFrameMultiLine:
    def test_two_lines(self):
        result = frame("hi\nthere")
        lines = result.split("\n")
        assert len(lines) == 4  # top + 2 content + bottom
        # both content lines same width
        assert len(lines[1]) == len(lines[2])

    def test_lines_padded_to_longest(self):
        result = frame("a\nlong line")
        lines = result.split("\n")
        assert len(lines[1]) == len(lines[2])


# ── frame: custom width ─────────────────────────────────────────────

class TestFrameCustomWidth:
    def test_explicit_width(self):
        result = frame("hi", width=20)
        lines = result.split("\n")
        assert len(lines[0]) == 20

    def test_truncation_when_width_too_small(self):
        result = frame("abcdef", width=8, padding=1)
        lines = result.split("\n")
        # inner=6, content_width=4 -> truncated to 4 chars
        assert "abcd" in lines[1]
        assert "ef" not in lines[1]


# ── frame: padding ───────────────────────────────────────────────────

class TestFramePadding:
    def test_zero_padding(self):
        result = frame("hi", padding=0)
        lines = result.split("\n")
        assert lines[1] == "│hi│"

    def test_large_padding(self):
        result = frame("x", padding=3)
        lines = result.split("\n")
        assert lines[1] == "│   x   │"


# ── frame: title ─────────────────────────────────────────────────────

class TestFrameTitle:
    def test_title_in_top_border(self):
        result = frame("hello", title="Test")
        top = result.split("\n")[0]
        assert "Test" in top
        assert top.startswith("┌")
        assert top.endswith("┐")

    def test_title_does_not_affect_content(self):
        result = frame("hello", title="T")
        lines = result.split("\n")
        assert "hello" in lines[1]


# ── frame: border styles ────────────────────────────────────────────

class TestFrameStyles:
    def test_single(self):
        top = frame("x", style=BorderStyle.SINGLE).split("\n")[0]
        assert top[0] == "┌"

    def test_double(self):
        result = frame("x", style=BorderStyle.DOUBLE)
        lines = result.split("\n")
        assert lines[0][0] == "╔"
        assert lines[1][0] == "║"
        assert lines[2][0] == "╚"

    def test_rounded(self):
        top = frame("x", style=BorderStyle.ROUNDED).split("\n")[0]
        assert top[0] == "╭"

    def test_ascii(self):
        result = frame("x", style=BorderStyle.ASCII)
        lines = result.split("\n")
        assert lines[0][0] == "+"
        assert lines[1][0] == "|"

    def test_shadow_extra_chars(self):
        result = frame("hi", style=BorderStyle.SHADOW)
        lines = result.split("\n")
        # shadow adds a column on the right and a row at the bottom
        assert len(lines) == 4  # top + content + bottom + shadow row
        assert lines[0].endswith("░")
        assert lines[-1].strip().replace("░", "") == ""


# ── divider ──────────────────────────────────────────────────────────

class TestDivider:
    def test_plain(self):
        result = divider(width=20)
        assert result == "─" * 20

    def test_with_label(self):
        result = divider(label="Section", width=30)
        assert "Section" in result
        assert len(result) == 30

    def test_default_width(self):
        result = divider()
        assert len(result) == 80

    def test_style_double(self):
        result = divider(style=BorderStyle.DOUBLE, width=10)
        assert result == "═" * 10

    def test_label_centered(self):
        result = divider(label="Hi", width=20)
        idx = result.index("Hi")
        # should be roughly centered
        assert 5 <= idx <= 11


# ── BorderBuilder ────────────────────────────────────────────────────

class TestBorderBuilder:
    def test_default_render(self):
        result = BorderBuilder().render()
        lines = result.split("\n")
        assert lines[0].startswith("┌")

    def test_fluent_chaining(self):
        result = (
            BorderBuilder()
            .text("hi")
            .style(BorderStyle.DOUBLE)
            .padding(0)
            .render()
        )
        lines = result.split("\n")
        assert lines[0][0] == "╔"
        assert "hi" in lines[1]

    def test_all_settings(self):
        result = (
            BorderBuilder()
            .text("ok")
            .style(BorderStyle.ROUNDED)
            .width(20)
            .padding(2)
            .title("T")
            .render()
        )
        lines = result.split("\n")
        assert len(lines[0]) == 20
        assert "T" in lines[0]
        assert lines[0][0] == "╭"

    def test_chaining_returns_builder(self):
        b = BorderBuilder()
        assert b.text("x") is b
