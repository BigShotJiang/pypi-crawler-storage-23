"""Tests for tables module."""

from __future__ import annotations

import pytest

from ascii_art._types import Alignment, BorderStyle
from ascii_art.tables import TableBuilder, table


class TestTableFunction:
    """Tests for the table() function."""

    def test_basic_2d_data(self) -> None:
        data = [["a", "b"], ["c", "d"]]
        result = table(data)
        lines = result.split("\n")
        # top border, 2 data rows, bottom border
        assert len(lines) == 4
        assert "a" in lines[1]
        assert "d" in lines[2]

    def test_with_headers(self) -> None:
        data = [["1", "2"]]
        result = table(data, headers=["X", "Y"])
        lines = result.split("\n")
        # top border, header row, separator, 1 data row, bottom border
        assert len(lines) == 5
        assert "X" in lines[1]
        assert "Y" in lines[1]
        # separator line between header and data
        assert "─" in lines[2] or "-" in lines[2] or "┼" in lines[2]

    def test_auto_column_widths(self) -> None:
        data = [["short", "x"], ["y", "longer"]]
        result = table(data)
        lines = result.split("\n")
        # First data row: "short" should be padded to 5, "longer" to 6
        row1 = lines[1]
        # The cell for "short" should occupy 5 chars (left-aligned)
        assert " short " in row1
        assert " x      " in lines[1] or " x " not in lines[1]
        # Verify "longer" width is used
        assert " longer " in lines[2]

    def test_auto_width_considers_headers(self) -> None:
        data = [["a", "b"]]
        result = table(data, headers=["Header1", "H2"])
        lines = result.split("\n")
        # "a" should be padded to width of "Header1" (7)
        assert " a       " in lines[3] or "a" in lines[3]
        # Check that header cell is at least as wide as header text
        assert " Header1 " in lines[1]

    def test_custom_col_widths(self) -> None:
        data = [["ab", "cd"]]
        result = table(data, col_widths=[10, 10])
        lines = result.split("\n")
        # Each cell should be padded to 10 chars
        assert " ab         " in lines[1] or len(lines[1]) > 20

    def test_custom_col_widths_pads_content(self) -> None:
        data = [["x"]]
        result = table(data, col_widths=[8])
        row = result.split("\n")[1]
        # "x" left-aligned in 8-wide field => " x        "
        assert " x       " in row

    def test_alignment_left(self) -> None:
        data = [["hi"]]
        result = table(data, col_widths=[6], alignments=[Alignment.LEFT])
        row = result.split("\n")[1]
        assert " hi     " in row

    def test_alignment_right(self) -> None:
        data = [["hi"]]
        result = table(data, col_widths=[6], alignments=[Alignment.RIGHT])
        row = result.split("\n")[1]
        assert "     hi " in row

    def test_alignment_center(self) -> None:
        data = [["hi"]]
        result = table(data, col_widths=[6], alignments=[Alignment.CENTER])
        row = result.split("\n")[1]
        # "hi".center(6) == "  hi  "
        assert "  hi  " in row

    def test_per_column_alignment(self) -> None:
        data = [["a", "b", "c"]]
        aligns = [Alignment.LEFT, Alignment.CENTER, Alignment.RIGHT]
        result = table(data, col_widths=[5, 5, 5], alignments=aligns)
        row = result.split("\n")[1]
        # Check each cell
        assert " a     " in row  # left
        assert "   b   " in row  # center
        assert "     c " in row  # right

    def test_border_style_single(self) -> None:
        data = [["x"]]
        result = table(data, style=BorderStyle.SINGLE)
        assert "┌" in result
        assert "┐" in result
        assert "└" in result
        assert "┘" in result
        assert "─" in result
        assert "│" in result

    def test_border_style_double(self) -> None:
        data = [["x"]]
        result = table(data, style=BorderStyle.DOUBLE)
        assert "╔" in result
        assert "╗" in result
        assert "╚" in result
        assert "╝" in result
        assert "═" in result
        assert "║" in result

    def test_border_style_ascii(self) -> None:
        data = [["x"]]
        result = table(data, style=BorderStyle.ASCII)
        lines = result.split("\n")
        assert lines[0].startswith("+")
        assert lines[0].endswith("+")
        assert "|" in lines[1]

    def test_border_style_bold(self) -> None:
        data = [["x"]]
        result = table(data, style=BorderStyle.BOLD)
        assert "┏" in result
        assert "┓" in result
        assert "━" in result
        assert "┃" in result

    def test_border_style_rounded(self) -> None:
        data = [["x"]]
        result = table(data, style=BorderStyle.ROUNDED)
        assert "╭" in result
        assert "╮" in result
        assert "╰" in result
        assert "╯" in result

    def test_empty_data_no_headers(self) -> None:
        result = table([])
        # Should produce a minimal empty table
        assert result  # non-empty string

    def test_empty_data_with_headers(self) -> None:
        result = table([], headers=["A", "B"])
        lines = result.split("\n")
        # top, header, separator, bottom (no data rows)
        assert len(lines) == 4
        assert "A" in lines[1]

    def test_single_column(self) -> None:
        data = [["one"], ["two"], ["three"]]
        result = table(data)
        lines = result.split("\n")
        assert len(lines) == 5  # top + 3 rows + bottom
        assert "three" in result

    def test_single_row(self) -> None:
        data = [["a", "b", "c"]]
        result = table(data)
        lines = result.split("\n")
        assert len(lines) == 3  # top + 1 row + bottom

    def test_header_separator_uses_cross_pieces(self) -> None:
        data = [["1", "2"]]
        result = table(data, headers=["A", "B"], style=BorderStyle.SINGLE)
        lines = result.split("\n")
        sep = lines[2]
        assert "├" in sep
        assert "┤" in sep
        assert "┼" in sep

    def test_top_border_uses_top_t(self) -> None:
        data = [["1", "2"]]
        result = table(data, style=BorderStyle.SINGLE)
        top = result.split("\n")[0]
        assert "┬" in top

    def test_bottom_border_uses_bottom_t(self) -> None:
        data = [["1", "2"]]
        result = table(data, style=BorderStyle.SINGLE)
        bottom = result.split("\n")[-1]
        assert "┴" in bottom

    def test_double_cross_pieces(self) -> None:
        data = [["1", "2"]]
        result = table(data, headers=["A", "B"], style=BorderStyle.DOUBLE)
        lines = result.split("\n")
        assert "╦" in lines[0]
        assert "╬" in lines[2]
        assert "╩" in lines[-1]

    def test_numeric_data_converted_to_str(self) -> None:
        data = [[1, 2.5], [True, None]]
        result = table(data)
        assert "1" in result
        assert "2.5" in result
        assert "True" in result
        assert "None" in result


class TestTableBuilder:
    """Tests for the TableBuilder fluent API."""

    def test_defaults(self) -> None:
        b = TableBuilder()
        assert b._settings["data"] == []
        assert b._settings["headers"] is None
        assert b._settings["style"] is BorderStyle.SINGLE
        assert b._settings["col_widths"] is None
        assert b._settings["alignments"] is None

    def test_fluent_chaining(self) -> None:
        b = TableBuilder()
        result = b.data([["a", "b"]]).headers(["X", "Y"])
        assert result is b

    def test_render_basic(self) -> None:
        result = TableBuilder().data([["hello", "world"]]).render()
        assert "hello" in result
        assert "world" in result

    def test_render_with_all_settings(self) -> None:
        result = (
            TableBuilder()
            .data([["x", "y"]])
            .headers(["A", "B"])
            .style(BorderStyle.ASCII)
            .col_widths([5, 5])
            .alignments([Alignment.RIGHT, Alignment.LEFT])
            .render()
        )
        assert "+" in result
        assert "|" in result
        assert "A" in result

    def test_render_matches_function(self) -> None:
        data_val = [["1", "2"], ["3", "4"]]
        headers_val = ["Col1", "Col2"]
        expected = table(data_val, headers=headers_val, style=BorderStyle.DOUBLE)
        actual = (
            TableBuilder()
            .data(data_val)
            .headers(headers_val)
            .style(BorderStyle.DOUBLE)
            .render()
        )
        assert actual == expected

    def test_unknown_setting_raises(self) -> None:
        b = TableBuilder()
        with pytest.raises(AttributeError):
            b.nonexistent("value")

    def test_render_empty(self) -> None:
        result = TableBuilder().render()
        assert isinstance(result, str)
        assert len(result) > 0
