"""Shared fixtures for ascii_art tests."""

from __future__ import annotations

import pytest


@pytest.fixture
def sample_text() -> str:
    return "Hello"


@pytest.fixture
def multiline_text() -> str:
    return "Line 1\nLine 2\nLine 3"
