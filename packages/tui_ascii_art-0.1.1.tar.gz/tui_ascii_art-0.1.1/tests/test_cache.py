"""Tests for _cache module."""

from __future__ import annotations

from ascii_art._cache import cached


class TestCached:
    def test_caches_return_value(self) -> None:
        call_count = 0

        @cached
        def expensive(x: int) -> int:
            nonlocal call_count
            call_count += 1
            return x * 2

        assert expensive(5) == 10
        assert expensive(5) == 10
        assert call_count == 1

    def test_different_args_not_cached(self) -> None:
        call_count = 0

        @cached
        def add(a: int, b: int) -> int:
            nonlocal call_count
            call_count += 1
            return a + b

        assert add(1, 2) == 3
        assert add(3, 4) == 7
        assert call_count == 2

    def test_cache_clear(self) -> None:
        call_count = 0

        @cached
        def val(x: int) -> int:
            nonlocal call_count
            call_count += 1
            return x

        val(1)
        val(1)
        assert call_count == 1
        val.cache_clear()
        val(1)
        assert call_count == 2

    def test_with_maxsize(self) -> None:
        @cached(maxsize=2)
        def double(x: int) -> int:
            return x * 2

        assert double(1) == 2
        assert double(2) == 4
        assert double(3) == 6
        # 1 should be evicted
        assert double(1) == 2
