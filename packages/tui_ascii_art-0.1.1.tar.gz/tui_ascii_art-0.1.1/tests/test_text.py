"""Tests for ascii_art.text module."""

from __future__ import annotations

import pyfiglet
import pytest

from ascii_art._types import Alignment
from ascii_art.text import TextBuilder, list_fonts, render


# ---------------------------------------------------------------------------
# render() tests
# ---------------------------------------------------------------------------


class TestRender:
    """Tests for the render() function."""

    def test_basic_render_returns_multiline_string(self) -> None:
        result = render("Hello")
        assert isinstance(result, str)
        assert "\n" in result
        assert len(result.splitlines()) > 1

    @pytest.mark.parametrize("font", ["standard", "slant", "banner"])
    def test_different_fonts(self, font: str) -> None:
        result = render("Hi", font=font)
        assert isinstance(result, str)
        assert len(result.strip()) > 0
        # Each font should produce a different rendering.
        if font != "standard":
            assert result != render("Hi", font="standard")

    def test_width_parameter(self) -> None:
        wide = render("Test", width=200)
        narrow = render("Test", width=40)
        # Both should produce valid output; wide should not exceed width.
        for line in wide.splitlines():
            assert len(line) <= 200
        for line in narrow.splitlines():
            assert len(line) <= 40

    def test_alignment_left(self) -> None:
        result = render("A", align=Alignment.LEFT)
        lines = [l for l in result.splitlines() if l.strip()]
        # Left-aligned lines should not start with leading spaces (or at
        # most very few from the font glyph itself).
        for line in lines:
            # The line should equal its lstrip OR start with very few spaces.
            assert len(line) - len(line.lstrip()) < 5

    def test_alignment_center(self) -> None:
        result = render("A", width=120, align=Alignment.CENTER)
        lines = [l for l in result.splitlines() if l.strip()]
        # At least one content line should have noticeable leading whitespace
        # from centering.
        leading = [len(l) - len(l.lstrip()) for l in lines]
        assert max(leading) > 5

    def test_alignment_right(self) -> None:
        result = render("A", width=120, align=Alignment.RIGHT)
        lines = [l for l in result.splitlines() if l.strip()]
        leading = [len(l) - len(l.lstrip()) for l in lines]
        assert max(leading) > 10

    def test_empty_text_returns_empty_string(self) -> None:
        assert render("") == ""

    def test_lines_stripped_of_trailing_whitespace(self) -> None:
        result = render("Hello")
        for line in result.splitlines():
            assert line == line.rstrip(), (
                f"Line has trailing whitespace: {line!r}"
            )


# ---------------------------------------------------------------------------
# list_fonts() tests
# ---------------------------------------------------------------------------


class TestListFonts:
    """Tests for the list_fonts() function."""

    def test_returns_list_of_strings(self) -> None:
        fonts = list_fonts()
        assert isinstance(fonts, list)
        assert all(isinstance(f, str) for f in fonts)

    def test_contains_at_least_15_fonts(self) -> None:
        assert len(list_fonts()) >= 15

    def test_all_fonts_are_valid_pyfiglet_fonts(self) -> None:
        for font in list_fonts():
            # This will raise if the font is unknown to pyfiglet.
            pyfiglet.figlet_format("test", font=font)


# ---------------------------------------------------------------------------
# TextBuilder tests
# ---------------------------------------------------------------------------


class TestTextBuilder:
    """Tests for the TextBuilder fluent builder."""

    def test_defaults(self) -> None:
        builder = TextBuilder()
        assert builder._settings["text"] == ""
        assert builder._settings["font"] == "standard"
        assert builder._settings["width"] == 80
        assert builder._settings["align"] is Alignment.LEFT

    def test_fluent_setters(self) -> None:
        builder = TextBuilder()
        returned = builder.text("Hey").font("slant").width(100).align(Alignment.CENTER)
        assert returned is builder
        assert builder._settings["text"] == "Hey"
        assert builder._settings["font"] == "slant"
        assert builder._settings["width"] == 100
        assert builder._settings["align"] is Alignment.CENTER

    def test_render_calls_render_function(self) -> None:
        result = TextBuilder().text("Hi").render()
        expected = render("Hi")
        assert result == expected

    def test_render_empty_text(self) -> None:
        assert TextBuilder().render() == ""

    def test_invalid_setting_raises(self) -> None:
        with pytest.raises(AttributeError):
            TextBuilder().nonexistent("value")
