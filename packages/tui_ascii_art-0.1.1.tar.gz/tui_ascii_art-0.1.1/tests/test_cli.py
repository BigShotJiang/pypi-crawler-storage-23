"""Tests for CLI entry point."""

from __future__ import annotations

import subprocess
import sys

import pytest


def run_cli(*args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, "-m", "ascii_art", *args],
        capture_output=True,
        text=True,
        timeout=10,
    )


class TestTextCommand:
    def test_basic(self) -> None:
        r = run_cli("text", "Hi")
        assert r.returncode == 0
        assert len(r.stdout.strip()) > 0

    def test_font_flag(self) -> None:
        r = run_cli("text", "Hi", "--font", "slant")
        assert r.returncode == 0

    def test_align_center(self) -> None:
        r = run_cli("text", "Hi", "--align", "center")
        assert r.returncode == 0


class TestShapeCommand:
    def test_rectangle(self) -> None:
        r = run_cli("shape", "rectangle", "--width", "20", "--height", "10")
        assert r.returncode == 0
        assert "#" in r.stdout

    def test_circle(self) -> None:
        r = run_cli("shape", "circle", "--width", "20", "--height", "20")
        assert r.returncode == 0

    def test_diamond(self) -> None:
        r = run_cli("shape", "diamond", "--width", "20", "--height", "20")
        assert r.returncode == 0


class TestBorderCommand:
    def test_basic(self) -> None:
        r = run_cli("border", "Hello World")
        assert r.returncode == 0
        assert "Hello World" in r.stdout

    def test_with_title(self) -> None:
        r = run_cli("border", "content", "--title", "Title")
        assert r.returncode == 0
        assert "Title" in r.stdout

    def test_double_style(self) -> None:
        r = run_cli("border", "test", "--style", "double")
        assert r.returncode == 0
        assert "═" in r.stdout


class TestChartCommand:
    def test_sparkline(self) -> None:
        r = run_cli("chart", "1,3,5,2,4", "--type", "sparkline")
        assert r.returncode == 0
        assert len(r.stdout.strip()) == 5

    def test_bar(self) -> None:
        r = run_cli("chart", "10,20,30", "--type", "bar")
        assert r.returncode == 0
        lines = r.stdout.strip().split("\n")
        assert len(lines) == 3


class TestTableCommand:
    def test_csv_data(self) -> None:
        r = run_cli("table", "a,b,c\n1,2,3")
        assert r.returncode == 0

    def test_with_headers(self) -> None:
        r = run_cli("table", "Name,Age\nAlice,30", "--headers")
        assert r.returncode == 0
        assert "Name" in r.stdout


class TestHelpAndErrors:
    def test_no_args_shows_help(self) -> None:
        r = run_cli()
        assert r.returncode != 0

    def test_help_flag(self) -> None:
        r = run_cli("--help")
        assert r.returncode == 0
        assert "ascii-art" in r.stdout.lower() or "usage" in r.stdout.lower()
