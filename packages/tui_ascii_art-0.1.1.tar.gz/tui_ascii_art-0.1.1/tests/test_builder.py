"""Tests for _builder module."""

from __future__ import annotations

import pytest

from ascii_art._builder import BaseBuilder


class ConcreteBuilder(BaseBuilder):
    _defaults = {"width": 80, "height": 24, "char": "#"}

    def render(self) -> str:
        return f"{self._settings['char']} {self._settings['width']}x{self._settings['height']}"


class TestBaseBuilder:
    def test_defaults_applied(self) -> None:
        b = ConcreteBuilder()
        assert b.render() == "# 80x24"

    def test_fluent_setter(self) -> None:
        result = ConcreteBuilder().width(40).height(12).render()
        assert result == "# 40x12"

    def test_chaining_returns_self(self) -> None:
        b = ConcreteBuilder()
        assert b.width(40) is b

    def test_unknown_attr_raises(self) -> None:
        b = ConcreteBuilder()
        with pytest.raises(AttributeError):
            b.nonexistent(42)

    def test_char_override(self) -> None:
        result = ConcreteBuilder().char("*").render()
        assert result == "* 80x24"

    def test_render_is_abstract(self) -> None:
        with pytest.raises(TypeError):
            BaseBuilder()  # type: ignore[abstract]
