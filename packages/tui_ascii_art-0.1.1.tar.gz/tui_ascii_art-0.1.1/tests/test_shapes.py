"""Tests for ascii_art.shapes module."""

from __future__ import annotations

import pytest

from ascii_art.shapes import (
    Canvas,
    ShapesBuilder,
    arrow,
    circle,
    diamond,
    ellipse,
    line,
    rectangle,
    triangle,
)


# ========================================================================
# Canvas basics
# ========================================================================


class TestCanvasConstructor:
    def test_dimensions(self):
        c = Canvas(10, 5)
        assert c.width == 10
        assert c.height == 5

    def test_initial_cells_are_spaces(self):
        c = Canvas(3, 2)
        for y in range(2):
            for x in range(3):
                assert c.get(x, y) == " "


class TestCanvasSetGet:
    def test_set_and_get(self):
        c = Canvas(5, 5)
        c.set(2, 3, "X")
        assert c.get(2, 3) == "X"

    def test_set_out_of_bounds_ignored(self):
        c = Canvas(5, 5)
        # Should not raise
        c.set(-1, 0, "X")
        c.set(0, -1, "X")
        c.set(5, 0, "X")
        c.set(0, 5, "X")
        c.set(100, 100, "X")

    def test_get_out_of_bounds_returns_space(self):
        c = Canvas(5, 5)
        assert c.get(-1, 0) == " "
        assert c.get(0, -1) == " "
        assert c.get(5, 0) == " "
        assert c.get(0, 5) == " "


class TestCanvasRender:
    def test_empty_canvas_render(self):
        c = Canvas(3, 2)
        result = c.render()
        assert result == "   \n   "

    def test_render_with_chars(self):
        c = Canvas(3, 2)
        c.set(0, 0, "A")
        c.set(2, 1, "B")
        result = c.render()
        lines = result.split("\n")
        assert lines[0] == "A  "
        assert lines[1] == "  B"

    def test_to_str_same_as_render(self):
        c = Canvas(4, 3)
        c.set(1, 1, "#")
        assert c.to_str() == c.render()


class TestCanvasClear:
    def test_clear_resets_grid(self):
        c = Canvas(5, 5)
        c.set(2, 2, "#")
        c.clear()
        assert c.get(2, 2) == " "


class TestCanvasOverlay:
    def test_overlay_copies_non_space(self):
        base = Canvas(10, 10)
        overlay = Canvas(3, 3)
        overlay.set(1, 1, "X")
        base.overlay(overlay, 2, 2)
        assert base.get(3, 3) == "X"

    def test_overlay_ignores_spaces(self):
        base = Canvas(10, 10)
        base.set(2, 2, "O")
        overlay = Canvas(3, 3)
        # overlay is all spaces except (0,0)
        overlay.set(0, 0, "X")
        base.overlay(overlay, 2, 2)
        assert base.get(2, 2) == "X"  # overwritten
        assert base.get(3, 3) == " "  # overlay space didn't erase

    def test_overlay_partial_out_of_bounds(self):
        base = Canvas(5, 5)
        overlay = Canvas(3, 3)
        overlay.set(0, 0, "A")
        overlay.set(2, 2, "B")
        # Place overlay at (4, 4) — only (0,0) fits
        base.overlay(overlay, 4, 4)
        assert base.get(4, 4) == "A"

    def test_overlay_returns_canvas(self):
        base = Canvas(5, 5)
        other = Canvas(2, 2)
        result = base.overlay(other, 0, 0)
        assert result is base


# ========================================================================
# Line
# ========================================================================


class TestLine:
    def test_horizontal_line(self):
        c = Canvas(10, 5)
        line(c, 1, 2, 5, 2, "-")
        for x in range(1, 6):
            assert c.get(x, 2) == "-"
        # Above and below untouched
        assert c.get(1, 1) == " "
        assert c.get(1, 3) == " "

    def test_vertical_line(self):
        c = Canvas(5, 10)
        line(c, 2, 1, 2, 6, "|")
        for y in range(1, 7):
            assert c.get(2, y) == "|"

    def test_diagonal_line(self):
        c = Canvas(10, 10)
        line(c, 0, 0, 4, 4, "\\")
        for i in range(5):
            assert c.get(i, i) == "\\"

    def test_reverse_direction(self):
        c = Canvas(10, 5)
        line(c, 5, 2, 1, 2, "-")
        for x in range(1, 6):
            assert c.get(x, 2) == "-"

    def test_single_point(self):
        c = Canvas(5, 5)
        line(c, 2, 2, 2, 2, ".")
        assert c.get(2, 2) == "."

    def test_returns_canvas(self):
        c = Canvas(5, 5)
        result = line(c, 0, 0, 4, 0, "#")
        assert result is c


# ========================================================================
# Rectangle
# ========================================================================


class TestRectangle:
    def test_outline(self):
        c = Canvas(10, 10)
        rectangle(c, 1, 1, 5, 4, "#")
        # Top and bottom edges
        for x in range(1, 6):
            assert c.get(x, 1) == "#"
            assert c.get(x, 4) == "#"
        # Left and right edges
        for y in range(1, 5):
            assert c.get(1, y) == "#"
            assert c.get(5, y) == "#"
        # Interior should be empty
        assert c.get(3, 2) == " "
        assert c.get(3, 3) == " "

    def test_filled(self):
        c = Canvas(10, 10)
        rectangle(c, 2, 2, 3, 3, "*", fill=True)
        for y in range(2, 5):
            for x in range(2, 5):
                assert c.get(x, y) == "*"

    def test_returns_canvas(self):
        c = Canvas(10, 10)
        result = rectangle(c, 0, 0, 3, 3, "#")
        assert result is c


# ========================================================================
# Circle
# ========================================================================


class TestCircle:
    def test_circle_draws_pixels(self):
        c = Canvas(21, 21)
        circle(c, 10, 10, 5, "o")
        # Top of circle
        assert c.get(10, 5) == "o"
        # Bottom of circle
        assert c.get(10, 15) == "o"
        # Left
        assert c.get(5, 10) == "o"
        # Right
        assert c.get(15, 10) == "o"

    def test_circle_center_empty(self):
        c = Canvas(21, 21)
        circle(c, 10, 10, 5, "o")
        assert c.get(10, 10) == " "

    def test_small_circle(self):
        c = Canvas(5, 5)
        circle(c, 2, 2, 1, "#")
        # Cardinal points
        assert c.get(2, 1) == "#"
        assert c.get(2, 3) == "#"
        assert c.get(1, 2) == "#"
        assert c.get(3, 2) == "#"

    def test_returns_canvas(self):
        c = Canvas(20, 20)
        result = circle(c, 10, 10, 3, "#")
        assert result is c


# ========================================================================
# Ellipse
# ========================================================================


class TestEllipse:
    def test_ellipse_draws_extremes(self):
        c = Canvas(30, 20)
        ellipse(c, 15, 10, 8, 5, "e")
        # Top / bottom
        assert c.get(15, 5) == "e"
        assert c.get(15, 15) == "e"
        # Left / right
        assert c.get(7, 10) == "e"
        assert c.get(23, 10) == "e"

    def test_ellipse_center_empty(self):
        c = Canvas(30, 20)
        ellipse(c, 15, 10, 8, 5, "e")
        assert c.get(15, 10) == " "

    def test_returns_canvas(self):
        c = Canvas(30, 20)
        result = ellipse(c, 15, 10, 5, 3, "#")
        assert result is c


# ========================================================================
# Triangle
# ========================================================================


class TestTriangle:
    def test_triangle_vertices(self):
        c = Canvas(20, 20)
        triangle(c, 5, 2, 10, 15, 1, 10, "#")
        assert c.get(5, 2) == "#"
        assert c.get(10, 15) == "#"
        assert c.get(1, 10) == "#"

    def test_returns_canvas(self):
        c = Canvas(20, 20)
        result = triangle(c, 0, 0, 5, 0, 2, 5, "#")
        assert result is c


# ========================================================================
# Diamond
# ========================================================================


class TestDiamond:
    def test_diamond_tips(self):
        c = Canvas(20, 20)
        diamond(c, 10, 10, 3, "D")
        # Top
        assert c.get(10, 7) == "D"
        # Bottom
        assert c.get(10, 13) == "D"
        # Left
        assert c.get(7, 10) == "D"
        # Right
        assert c.get(13, 10) == "D"

    def test_diamond_edges(self):
        c = Canvas(20, 20)
        diamond(c, 10, 10, 3, "D")
        # Mid-edge points: at i=1, top-right edge goes to (11, 8), etc.
        assert c.get(11, 8) == "D"
        assert c.get(9, 8) == "D"
        assert c.get(11, 12) == "D"
        assert c.get(9, 12) == "D"

    def test_returns_canvas(self):
        c = Canvas(20, 20)
        result = diamond(c, 10, 10, 2, "#")
        assert result is c


# ========================================================================
# Arrow
# ========================================================================


class TestArrow:
    def test_arrow_horizontal_right(self):
        c = Canvas(10, 5)
        arrow(c, 1, 2, 8, 2, "-")
        # Shaft
        assert c.get(4, 2) == "-"
        # Tip should be '>' for rightward
        assert c.get(8, 2) == ">"

    def test_arrow_horizontal_left(self):
        c = Canvas(10, 5)
        arrow(c, 8, 2, 1, 2, "-")
        assert c.get(1, 2) == "<"

    def test_arrow_vertical_down(self):
        c = Canvas(5, 10)
        arrow(c, 2, 1, 2, 8, "|")
        assert c.get(2, 8) == "v"

    def test_arrow_vertical_up(self):
        c = Canvas(5, 10)
        arrow(c, 2, 8, 2, 1, "|")
        assert c.get(2, 1) == "^"

    def test_arrow_with_custom_head(self):
        c = Canvas(10, 5)
        arrow(c, 1, 2, 8, 2, "-", head_char="*")
        assert c.get(8, 2) == "*"

    def test_returns_canvas(self):
        c = Canvas(10, 5)
        result = arrow(c, 0, 0, 5, 0, "#")
        assert result is c


# ========================================================================
# ShapesBuilder
# ========================================================================


class TestShapesBuilder:
    def test_defaults(self):
        b = ShapesBuilder()
        assert b._settings["width"] == 80
        assert b._settings["height"] == 24
        assert b._settings["char"] == "#"

    def test_fluent_settings(self):
        b = ShapesBuilder()
        result = b.width(40).height(10).char("*")
        assert result is b
        assert b._settings["width"] == 40
        assert b._settings["height"] == 10
        assert b._settings["char"] == "*"

    def test_invalid_setting_raises(self):
        b = ShapesBuilder()
        with pytest.raises(AttributeError):
            b.nonexistent("value")

    def test_render_empty(self):
        b = ShapesBuilder().width(5).height(3)
        result = b.render()
        assert result == "     \n     \n     "

    def test_render_with_line(self):
        b = ShapesBuilder().width(10).height(5)
        b.add_line(0, 2, 9, 2)
        result = b.render()
        lines = result.split("\n")
        assert lines[2] == "##########"

    def test_render_with_rectangle(self):
        b = ShapesBuilder().width(10).height(5)
        b.add_rectangle(0, 0, 5, 3)
        result = b.render()
        lines = result.split("\n")
        assert lines[0][:5] == "#####"

    def test_render_uses_custom_char(self):
        b = ShapesBuilder().width(10).height(5).char("*")
        b.add_line(0, 0, 4, 0)
        result = b.render()
        lines = result.split("\n")
        assert lines[0][:5] == "*****"

    def test_add_circle(self):
        b = ShapesBuilder().width(20).height(20)
        result = b.add_circle(10, 10, 3)
        assert result is b
        output = b.render()
        assert "#" in output

    def test_add_triangle(self):
        b = ShapesBuilder().width(20).height(20)
        result = b.add_triangle(5, 2, 10, 15, 1, 10)
        assert result is b
        output = b.render()
        assert "#" in output

    def test_add_diamond(self):
        b = ShapesBuilder().width(20).height(20)
        result = b.add_diamond(10, 10, 3)
        assert result is b
        output = b.render()
        assert "#" in output

    def test_add_arrow(self):
        b = ShapesBuilder().width(20).height(5)
        result = b.add_arrow(0, 2, 15, 2)
        assert result is b
        output = b.render()
        assert ">" in output

    def test_chaining_multiple_shapes(self):
        b = (
            ShapesBuilder()
            .width(30)
            .height(15)
            .add_rectangle(0, 0, 10, 5)
            .add_line(10, 2, 20, 2)
        )
        output = b.render()
        lines = output.split("\n")
        # Rectangle top edge
        assert lines[0][:10] == "##########"
        # Line extends from rectangle
        assert lines[2][10:21] == "###########"
