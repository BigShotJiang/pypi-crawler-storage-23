"""Tests for ascii_art.image module."""

from __future__ import annotations

import tempfile
import os

import pytest
from PIL import Image

from ascii_art.image import render, ImageBuilder
from ascii_art._types import DEFAULT_CHAR_RAMP, DETAILED_CHAR_RAMP


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _gradient_image(width: int = 10, height: int = 10) -> Image.Image:
    """Create a horizontal gradient image (black on left, white on right)."""
    img = Image.new("L", (width, height))
    for y in range(height):
        for x in range(width):
            img.putpixel((x, y), int(x / (width - 1) * 255))
    return img


def _solid_image(value: int, width: int = 10, height: int = 10) -> Image.Image:
    """Create a solid grayscale image."""
    return Image.new("L", (width, height), value)


def _edge_image(width: int = 20, height: int = 20) -> Image.Image:
    """Create an image with a sharp vertical edge in the middle."""
    img = Image.new("L", (width, height))
    for y in range(height):
        for x in range(width):
            img.putpixel((x, y), 0 if x < width // 2 else 255)
    return img


# ---------------------------------------------------------------------------
# render() tests
# ---------------------------------------------------------------------------

class TestRender:
    def test_returns_string(self):
        img = _gradient_image()
        result = render(img, width=20)
        assert isinstance(result, str)

    def test_multiline_output(self):
        img = _gradient_image()
        result = render(img, width=20)
        lines = result.split("\n")
        assert len(lines) >= 1

    def test_width_controls_columns(self):
        img = _gradient_image(100, 100)
        for w in (20, 40, 60):
            result = render(img, width=w)
            lines = result.split("\n")
            assert all(len(line) == w for line in lines)

    def test_default_charset(self):
        img = _gradient_image()
        result = render(img, width=20)
        # All characters should come from DEFAULT_CHAR_RAMP
        for ch in result:
            if ch != "\n":
                assert ch in DEFAULT_CHAR_RAMP

    def test_custom_charset(self):
        img = _gradient_image()
        charset = " .#"
        result = render(img, width=20, charset=charset)
        for ch in result:
            if ch != "\n":
                assert ch in charset

    def test_invert(self):
        img = _solid_image(0, 10, 10)  # black image
        normal = render(img, width=10)
        inverted = render(img, width=10, invert=True)
        # Black pixel: normal maps to first ramp char, inverted maps to last
        normal_chars = set(normal.replace("\n", ""))
        inverted_chars = set(inverted.replace("\n", ""))
        assert normal_chars != inverted_chars

    def test_invert_reverses_mapping(self):
        img = _solid_image(255, 10, 10)  # white image
        normal = render(img, width=10)
        inverted = render(img, width=10, invert=True)
        # White: normal -> last char of ramp, inverted -> first char
        normal_ch = normal.split("\n")[0][0]
        inverted_ch = inverted.split("\n")[0][0]
        assert normal_ch == DEFAULT_CHAR_RAMP[-1]
        assert inverted_ch == DEFAULT_CHAR_RAMP[0]

    def test_edges_mode(self):
        img = _edge_image()
        result = render(img, width=20, edges=True)
        assert isinstance(result, str)
        lines = result.split("\n")
        assert len(lines) >= 1

    def test_edges_detects_edge(self):
        img = _edge_image(40, 40)
        result = render(img, width=40, edges=True)
        # The middle column area should have non-space characters (edges)
        lines = result.split("\n")
        mid = len(lines) // 2
        mid_line = lines[mid]
        # Somewhere near the center there should be edge characters
        center_region = mid_line[15:25]
        assert any(ch != " " for ch in center_region)

    def test_solid_image_no_edges(self):
        img = _solid_image(128, 20, 20)
        result = render(img, width=20, edges=True)
        lines = result.split("\n")
        # A solid image should produce mostly spaces (no edges)
        all_chars = result.replace("\n", "")
        space_ratio = all_chars.count(" ") / len(all_chars)
        assert space_ratio > 0.8

    def test_source_as_file_path(self):
        img = _gradient_image()
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
            img.save(f.name)
            path = f.name
        try:
            result = render(path, width=20)
            assert isinstance(result, str)
            lines = result.split("\n")
            assert all(len(line) == 20 for line in lines)
        finally:
            os.unlink(path)

    def test_source_as_pil_image(self):
        img = _gradient_image()
        result = render(img, width=20)
        assert isinstance(result, str)

    def test_rgb_image_accepted(self):
        """Non-grayscale images should be converted automatically."""
        img = Image.new("RGB", (10, 10), (128, 64, 200))
        result = render(img, width=20)
        assert isinstance(result, str)

    def test_gradient_produces_varied_chars(self):
        img = _gradient_image(100, 100)
        result = render(img, width=80)
        unique = set(result.replace("\n", ""))
        # A gradient should produce multiple different characters
        assert len(unique) > 3


# ---------------------------------------------------------------------------
# ImageBuilder tests
# ---------------------------------------------------------------------------

class TestImageBuilder:
    def test_defaults(self):
        builder = ImageBuilder()
        assert builder._settings["source"] is None
        assert builder._settings["width"] == 80
        assert builder._settings["charset"] is None
        assert builder._settings["invert"] is False
        assert builder._settings["edges"] is False

    def test_fluent_api(self):
        img = _gradient_image()
        builder = ImageBuilder()
        result = builder.source(img).width(20)
        # Fluent API returns the builder
        assert result is builder

    def test_render(self):
        img = _gradient_image()
        result = ImageBuilder().source(img).width(20).render()
        assert isinstance(result, str)
        lines = result.split("\n")
        assert all(len(line) == 20 for line in lines)

    def test_render_with_all_options(self):
        img = _gradient_image()
        result = (
            ImageBuilder()
            .source(img)
            .width(30)
            .charset(" .#")
            .invert(True)
            .edges(False)
            .render()
        )
        assert isinstance(result, str)
        lines = result.split("\n")
        assert all(len(line) == 30 for line in lines)

    def test_render_without_source_raises(self):
        with pytest.raises(ValueError):
            ImageBuilder().render()

    def test_render_with_edges(self):
        img = _edge_image()
        result = ImageBuilder().source(img).width(20).edges(True).render()
        assert isinstance(result, str)

    def test_invalid_setting_raises(self):
        builder = ImageBuilder()
        with pytest.raises(AttributeError):
            builder.nonexistent("value")
