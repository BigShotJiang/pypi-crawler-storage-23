"""Performance tests for ascii_art."""

from __future__ import annotations

import time

import pytest
from PIL import Image


@pytest.mark.perf
class TestPerformance:
    def test_text_render_under_50ms(self) -> None:
        from ascii_art.text import render

        start = time.perf_counter()
        for _ in range(10):
            render("Hello World", font="standard")
        elapsed = (time.perf_counter() - start) / 10
        assert elapsed < 0.05, f"text render took {elapsed:.3f}s (>50ms)"

    def test_border_frame_under_50ms(self) -> None:
        from ascii_art.borders import frame

        text = "Hello World\n" * 20
        start = time.perf_counter()
        for _ in range(10):
            frame(text)
        elapsed = (time.perf_counter() - start) / 10
        assert elapsed < 0.05, f"border frame took {elapsed:.3f}s (>50ms)"

    def test_table_under_50ms(self) -> None:
        from ascii_art.tables import table

        data = [[f"cell_{r}_{c}" for c in range(5)] for r in range(20)]
        headers = [f"Col {i}" for i in range(5)]
        start = time.perf_counter()
        for _ in range(10):
            table(data, headers=headers)
        elapsed = (time.perf_counter() - start) / 10
        assert elapsed < 0.05, f"table took {elapsed:.3f}s (>50ms)"

    def test_image_render_under_200ms(self) -> None:
        from ascii_art.image import render

        img = Image.new("L", (640, 480), color=128)
        start = time.perf_counter()
        for _ in range(5):
            render(img, width=80)
        elapsed = (time.perf_counter() - start) / 5
        assert elapsed < 0.2, f"image render took {elapsed:.3f}s (>200ms)"

    def test_shapes_canvas_under_50ms(self) -> None:
        from ascii_art.shapes import Canvas, rectangle, circle, line

        start = time.perf_counter()
        for _ in range(10):
            c = Canvas(80, 24)
            rectangle(c, 0, 0, 79, 23, "#")
            circle(c, 40, 12, 10, "*")
            line(c, 0, 0, 79, 23, ".")
            c.render()
        elapsed = (time.perf_counter() - start) / 10
        assert elapsed < 0.05, f"shapes took {elapsed:.3f}s (>50ms)"

    def test_sparkline_under_50ms(self) -> None:
        from ascii_art.charts import sparkline

        data = list(range(1000))
        start = time.perf_counter()
        for _ in range(10):
            sparkline(data)
        elapsed = (time.perf_counter() - start) / 10
        assert elapsed < 0.05, f"sparkline took {elapsed:.3f}s (>50ms)"
