"""Tests for ascii_art.charts module."""

from __future__ import annotations

import pytest

from ascii_art.charts import sparkline, bar_chart, scatter, ChartBuilder


# ── sparkline ──────────────────────────────────────────────────────────

class TestSparkline:
    def test_basic_data(self):
        result = sparkline([0, 1, 2, 3, 4, 5, 6, 7])
        assert isinstance(result, str)
        assert len(result) == 8
        # Should use the full range of block chars
        assert result[0] == "▁"
        assert result[-1] == "█"

    def test_normalizes_to_range(self):
        # All same value -> all lowest block
        result = sparkline([5, 5, 5, 5])
        assert len(result) == 4
        # When all values are equal, should use the lowest block char
        assert all(c == "▁" for c in result)

    def test_empty_data(self):
        assert sparkline([]) == ""

    def test_single_value(self):
        result = sparkline([42])
        assert len(result) == 1
        assert result == "▁"

    def test_two_values(self):
        result = sparkline([0, 100])
        assert result[0] == "▁"
        assert result[1] == "█"

    def test_width_resamples(self):
        data = list(range(100))
        result = sparkline(data, width=10)
        assert len(result) == 10

    def test_width_larger_than_data(self):
        data = [0, 10]
        result = sparkline(data, width=4)
        assert len(result) == 4

    def test_returns_single_line(self):
        result = sparkline([1, 2, 3, 4, 5])
        assert "\n" not in result


# ── bar_chart ──────────────────────────────────────────────────────────

class TestBarChart:
    def test_basic(self):
        result = bar_chart([10, 20, 30])
        lines = result.strip().split("\n")
        assert len(lines) == 3

    def test_bars_scaled_proportionally(self):
        result = bar_chart([50, 100], width=40)
        lines = result.strip().split("\n")
        # The max bar should be full width (40 chars of bar content)
        # The smaller bar should be about half
        bar_lengths = []
        for line in lines:
            bar_lengths.append(line.count("█"))
        assert bar_lengths[1] == 40
        assert bar_lengths[0] == 20

    def test_labels(self):
        result = bar_chart([10, 20], labels=["A", "B"])
        lines = result.strip().split("\n")
        assert "A" in lines[0]
        assert "B" in lines[1]

    def test_labels_right_aligned(self):
        result = bar_chart([10, 20], labels=["X", "Long"])
        lines = result.split("\n")
        # Both labels should be right-aligned to the same column width
        # "Long" is 4 chars, so "X" should be padded to 4 chars
        assert lines[0].startswith("   X ")
        assert lines[1].startswith("Long ")

    def test_custom_char(self):
        result = bar_chart([10], width=10, char="#")
        assert "#" in result

    def test_negative_values_treated_as_zero(self):
        result = bar_chart([-5, 10], width=20)
        lines = result.split("\n")
        assert lines[0] == ""  # negative -> zero length bar
        assert "█" in lines[1]

    def test_width_parameter(self):
        result = bar_chart([100], width=20)
        assert result.strip().count("█") == 20


# ── scatter ────────────────────────────────────────────────────────────

class TestScatter:
    def test_basic(self):
        points = [(0, 0), (10, 10)]
        result = scatter(points, width=20, height=10)
        lines = result.split("\n")
        assert len(lines) == 10
        assert all(len(line) == 20 for line in lines)
        assert result.count("*") == 2

    def test_empty_points_returns_empty_grid(self):
        result = scatter([], width=10, height=5)
        lines = result.split("\n")
        assert len(lines) == 5
        assert all(len(line) == 10 for line in lines)
        assert "*" not in result

    def test_custom_char(self):
        result = scatter([(5, 5)], width=20, height=10, char="o")
        assert "o" in result
        assert "*" not in result

    def test_points_mapped_to_grid(self):
        # Two points: one at origin, one at max
        result = scatter([(0, 0), (100, 100)], width=20, height=10)
        lines = result.split("\n")
        # Max point at top-right corner: first row, last column
        assert lines[0][-1] == "*"
        # Origin point at bottom-left corner: last row, first column
        assert lines[-1][0] == "*"

    def test_point_at_origin(self):
        result = scatter([(0, 0)], width=20, height=10)
        lines = result.split("\n")
        # Bottom-left corner: last row, first column
        assert lines[-1][0] == "*"


# ── ChartBuilder ───────────────────────────────────────────────────────

class TestChartBuilder:
    def test_defaults(self):
        b = ChartBuilder()
        assert b._settings["chart_type"] == "bar"
        assert b._settings["data"] == []
        assert b._settings["width"] == 40
        assert b._settings["height"] == 20
        assert b._settings["labels"] is None
        assert b._settings["char"] == "\u2588"

    def test_fluent_api(self):
        b = ChartBuilder()
        result = b.chart_type("sparkline").data([1, 2, 3]).width(10)
        assert result is b
        assert b._settings["chart_type"] == "sparkline"
        assert b._settings["data"] == [1, 2, 3]
        assert b._settings["width"] == 10

    def test_render_bar(self):
        result = ChartBuilder().data([10, 20]).chart_type("bar").render()
        assert isinstance(result, str)
        assert "\n" in result

    def test_render_sparkline(self):
        result = (
            ChartBuilder()
            .data([1, 2, 3])
            .chart_type("sparkline")
            .width(3)
            .render()
        )
        assert isinstance(result, str)
        assert len(result.strip()) == 3

    def test_render_scatter(self):
        result = (
            ChartBuilder()
            .data([(0, 0), (10, 10)])
            .chart_type("scatter")
            .width(20)
            .height(10)
            .char("*")
            .render()
        )
        assert isinstance(result, str)
        assert "*" in result

    def test_invalid_setting_raises(self):
        b = ChartBuilder()
        with pytest.raises(AttributeError):
            b.nonexistent("value")
