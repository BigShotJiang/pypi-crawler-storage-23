"""Tests for _types module."""

from __future__ import annotations

from ascii_art._types import (
    Alignment,
    BorderStyle,
    DEFAULT_CHAR_RAMP,
    DETAILED_CHAR_RAMP,
    BLOCK_CHAR_RAMP,
    Point,
    Size,
)


class TestAlignment:
    def test_members(self) -> None:
        assert Alignment.LEFT.value == "left"
        assert Alignment.CENTER.value == "center"
        assert Alignment.RIGHT.value == "right"

    def test_iterable(self) -> None:
        assert len(list(Alignment)) == 3


class TestBorderStyle:
    def test_has_required_styles(self) -> None:
        names = {s.name for s in BorderStyle}
        for expected in ("SINGLE", "DOUBLE", "ROUNDED", "BOLD", "ASCII", "DASHED", "SHADOW"):
            assert expected in names

    def test_value_is_tuple_of_strings(self) -> None:
        for style in BorderStyle:
            assert isinstance(style.value, tuple)
            # tl, tr, bl, br, h, v = 6 chars minimum
            assert len(style.value) >= 6


class TestConstants:
    def test_default_ramp_nonempty(self) -> None:
        assert len(DEFAULT_CHAR_RAMP) > 5
        assert isinstance(DEFAULT_CHAR_RAMP, str)

    def test_detailed_ramp_longer(self) -> None:
        assert len(DETAILED_CHAR_RAMP) > len(DEFAULT_CHAR_RAMP)

    def test_block_ramp(self) -> None:
        assert len(BLOCK_CHAR_RAMP) >= 4


class TestTypeAliases:
    def test_point(self) -> None:
        p: Point = (3, 4)
        assert p == (3, 4)

    def test_size(self) -> None:
        s: Size = (80, 24)
        assert s == (80, 24)
