"""Tests for the sprites module."""

from __future__ import annotations

import pytest

from ascii_art.sprites import Animation, Sprite, SpriteBuilder, SPRITES


# ---------------------------------------------------------------------------
# Sprite basics
# ---------------------------------------------------------------------------


class TestSprite:
    def test_width_and_height(self):
        s = Sprite(["abc", "de", "fghij"])
        assert s.width == 5
        assert s.height == 3

    def test_empty_sprite(self):
        s = Sprite([])
        assert s.width == 0
        assert s.height == 0

    def test_render(self):
        rows = ["AB", "CD"]
        s = Sprite(rows)
        assert s.render() == "AB\nCD"

    def test_immutability(self):
        rows = ["AB", "CD"]
        s = Sprite(rows)
        flipped = s.flip_h()
        # Original unchanged
        assert s.render() == "AB\nCD"
        assert flipped.render() != s.render()

    def test_flip_h(self):
        s = Sprite(["AB", "CD"])
        f = s.flip_h()
        assert f.render() == "BA\nDC"

    def test_flip_v(self):
        s = Sprite(["AB", "CD"])
        f = s.flip_v()
        assert f.render() == "CD\nAB"

    def test_rotate_90(self):
        s = Sprite(["AB", "CD"])
        r = s.rotate(90)
        # Transpose of [[A,B],[C,D]] is [[A,C],[B,D]]
        # Then reverse each row -> [[C,A],[D,B]]
        assert r.render() == "CA\nDB"

    def test_rotate_180(self):
        s = Sprite(["AB", "CD"])
        r = s.rotate(180)
        assert r.render() == "DC\nBA"

    def test_rotate_270(self):
        s = Sprite(["AB", "CD"])
        r = s.rotate(270)
        # Transpose -> [[A,C],[B,D]], then reverse row order -> [[B,D],[A,C]]
        assert r.render() == "BD\nAC"

    def test_rotate_360_is_identity(self):
        s = Sprite(["AB", "CD"])
        r = s.rotate(360)
        assert r.render() == s.render()

    def test_scale_2(self):
        s = Sprite(["AB", "CD"])
        sc = s.scale(2)
        assert sc.render() == "AABB\nAABB\nCCDD\nCCDD"

    def test_scale_1_identity(self):
        s = Sprite(["AB", "CD"])
        sc = s.scale(1)
        assert sc.render() == s.render()

    def test_scale_3(self):
        s = Sprite(["X"])
        sc = s.scale(3)
        assert sc.render() == "XXX\nXXX\nXXX"

    def test_transforms_return_new_instances(self):
        s = Sprite(["AB", "CD"])
        assert s.flip_h() is not s
        assert s.flip_v() is not s
        assert s.rotate(90) is not s
        assert s.scale(2) is not s


# ---------------------------------------------------------------------------
# Animation
# ---------------------------------------------------------------------------


class TestAnimation:
    def test_len(self):
        frames = [Sprite(["A"]), Sprite(["B"]), Sprite(["C"])]
        anim = Animation(frames)
        assert len(anim) == 3

    def test_iterable(self):
        frames = [Sprite(["A"]), Sprite(["B"])]
        anim = Animation(frames)
        collected = list(anim)
        assert len(collected) == 2
        assert collected[0].render() == "A"
        assert collected[1].render() == "B"

    def test_frame(self):
        frames = [Sprite(["X"]), Sprite(["Y"])]
        anim = Animation(frames)
        assert anim.frame(0).render() == "X"
        assert anim.frame(1).render() == "Y"

    def test_frames_property(self):
        frames = [Sprite(["A"])]
        anim = Animation(frames)
        assert len(anim.frames) == 1


# ---------------------------------------------------------------------------
# SpriteBuilder
# ---------------------------------------------------------------------------


class TestSpriteBuilder:
    def test_defaults(self):
        b = SpriteBuilder()
        assert b._settings == {
            "grid": [],
            "scale_factor": 1,
            "flip_horizontal": False,
            "flip_vertical": False,
            "rotation": 0,
        }

    def test_render_simple(self):
        result = SpriteBuilder().grid(["AB", "CD"]).render()
        assert result == "AB\nCD"

    def test_render_with_flip_horizontal(self):
        result = SpriteBuilder().grid(["AB", "CD"]).flip_horizontal(True).render()
        assert result == "BA\nDC"

    def test_render_with_flip_vertical(self):
        result = SpriteBuilder().grid(["AB", "CD"]).flip_vertical(True).render()
        assert result == "CD\nAB"

    def test_render_with_rotation(self):
        result = SpriteBuilder().grid(["AB", "CD"]).rotation(90).render()
        assert result == "CA\nDB"

    def test_render_with_scale(self):
        result = SpriteBuilder().grid(["AB"]).scale_factor(2).render()
        assert result == "AABB\nAABB"

    def test_fluent_chaining(self):
        b = SpriteBuilder()
        ret = b.grid(["AB", "CD"])
        assert ret is b  # fluent chaining returns self


# ---------------------------------------------------------------------------
# Bundled SPRITES dict
# ---------------------------------------------------------------------------


class TestBundledSprites:
    def test_sprites_is_dict(self):
        assert isinstance(SPRITES, dict)

    def test_has_heart(self):
        assert "heart" in SPRITES

    def test_has_star(self):
        assert "star" in SPRITES

    def test_has_arrow_right(self):
        assert "arrow_right" in SPRITES

    def test_entries_are_list_of_strings(self):
        for name, grid in SPRITES.items():
            assert isinstance(grid, list), f"{name} should be list"
            for row in grid:
                assert isinstance(row, str), f"{name} rows should be strings"

    def test_can_create_sprite_from_bundled(self):
        for name, grid in SPRITES.items():
            s = Sprite(grid)
            assert s.height > 0
            assert s.width > 0
