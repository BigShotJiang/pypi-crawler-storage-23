# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

`ascii-art` is a Python library for programmatic ASCII art generation targeting TUI applications. It provides text rendering (via pyfiglet), image-to-ASCII conversion (via Pillow), shape drawing primitives, borders/frames, tables, charts, sprites/animations, and integrations with rich/textual/curses.

## Commands

```bash
# Setup
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"

# Run all tests
pytest

# Run a single test file or specific test
pytest tests/test_shapes.py
pytest tests/test_shapes.py::test_rectangle -v

# Run perf benchmarks (marked separately)
pytest -m perf

# Type checking
mypy src/

# Linting
ruff check src/ tests/

# Build
python -m build

# CLI usage
ascii-art text "Hello" --font slant
ascii-art image photo.png --width 60
ascii-art shape circle --width 40 --height 20
ascii-art border "text" --style rounded
ascii-art table "a,b\n1,2" --headers --style double
ascii-art chart "1,4,2,8,3" --type bar
```

## Architecture

**Build system**: Hatchling with `src/` layout. Package source is at `src/ascii_art/`.

**Core internals** (prefixed with `_`):
- `_types.py` — Shared enums (`Alignment`, `BorderStyle`), type aliases (`Point`, `Size`), and character ramps (`DEFAULT_CHAR_RAMP`, `DETAILED_CHAR_RAMP`, `BLOCK_CHAR_RAMP`)
- `_builder.py` — `BaseBuilder` ABC with dynamic fluent API via `__getattr__`. Subclasses define `_defaults` dict and implement `render() -> str`
- `_cache.py` — `@cached` decorator wrapping `functools.lru_cache`

**Module pattern**: Each feature module (text, image, shapes, borders, tables, charts, sprites) exposes:
1. Standalone functions (e.g. `render()`, `frame()`, `table()`)
2. A `*Builder` subclass of `BaseBuilder` for fluent chaining

**Shapes module**: Uses a `Canvas` class (2D character grid) with drawing functions (`line`, `rectangle`, `circle`, `ellipse`, `triangle`, `diamond`, `arrow`) that mutate the canvas in-place and return it for chaining.

**Integrations** (`integrations/`): Lazy-loaded via `__getattr__` in `__init__.py`. Provides `rich_panel`, `textual_widget`, and `curses_win` adapters. These are optional dependencies (`rich` and `textual` extras in pyproject.toml).

**CLI**: `__main__.py` with argparse subcommands (text, image, shape, border, table, chart). Entry point: `ascii-art`.

## Conventions

- Python 3.10+ required; `from __future__ import annotations` used throughout
- `mypy --strict` enforced
- `ruff` for linting, target Python 3.10
- All public API re-exported from `__init__.py`
- Tests mirror source modules: `test_text.py`, `test_shapes.py`, etc. Plus `test_cli.py`, `test_integrations.py`, `test_perf.py`
- Performance tests use the `@pytest.mark.perf` marker
