"""ascii_art — Programmatic ASCII art generation for TUIs."""

__version__ = "0.1.0"

from ascii_art._types import Alignment, BorderStyle, DEFAULT_CHAR_RAMP, DETAILED_CHAR_RAMP, BLOCK_CHAR_RAMP
from ascii_art.text import render as text_render, list_fonts, TextBuilder
from ascii_art.image import render as image_render, ImageBuilder
from ascii_art.shapes import (
    Canvas, line, rectangle, circle, ellipse, triangle, diamond, arrow, ShapesBuilder,
)
from ascii_art.borders import frame, divider, BorderBuilder
from ascii_art.tables import table, TableBuilder
from ascii_art.charts import sparkline, bar_chart, scatter, ChartBuilder
from ascii_art.sprites import Sprite, Animation, SPRITES, SpriteBuilder

__all__ = [
    "__version__",
    # Types & constants
    "Alignment", "BorderStyle",
    "DEFAULT_CHAR_RAMP", "DETAILED_CHAR_RAMP", "BLOCK_CHAR_RAMP",
    # Text
    "text_render", "list_fonts", "TextBuilder",
    # Image
    "image_render", "ImageBuilder",
    # Shapes
    "Canvas", "line", "rectangle", "circle", "ellipse",
    "triangle", "diamond", "arrow", "ShapesBuilder",
    # Borders
    "frame", "divider", "BorderBuilder",
    # Tables
    "table", "TableBuilder",
    # Charts
    "sparkline", "bar_chart", "scatter", "ChartBuilder",
    # Sprites
    "Sprite", "Animation", "SPRITES", "SpriteBuilder",
]
