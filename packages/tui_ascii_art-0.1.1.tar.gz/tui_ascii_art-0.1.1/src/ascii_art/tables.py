"""ASCII table rendering."""

from __future__ import annotations

from typing import Any, List, Optional, Sequence

from ascii_art._builder import BaseBuilder
from ascii_art._types import Alignment, BorderStyle

# Cross-piece characters for each border style:
# (left_t, right_t, top_t, bottom_t, cross)
_CROSS_PIECES: dict[BorderStyle, tuple[str, str, str, str, str]] = {
    BorderStyle.SINGLE:  ("├", "┤", "┬", "┴", "┼"),
    BorderStyle.DOUBLE:  ("╠", "╣", "╦", "╩", "╬"),
    BorderStyle.ROUNDED: ("├", "┤", "┬", "┴", "┼"),
    BorderStyle.BOLD:    ("┣", "┫", "┳", "┻", "╋"),
    BorderStyle.ASCII:   ("+", "+", "+", "+", "+"),
    BorderStyle.DASHED:  ("├", "┤", "┬", "┴", "┼"),
    BorderStyle.SHADOW:  ("├", "┤", "┬", "┴", "┼"),
}


def _align(text: str, width: int, alignment: Alignment) -> str:
    if alignment == Alignment.CENTER:
        return text.center(width)
    if alignment == Alignment.RIGHT:
        return text.rjust(width)
    return text.ljust(width)


def table(
    data: Sequence[Sequence[Any]],
    headers: Optional[Sequence[str]] = None,
    style: BorderStyle = BorderStyle.SINGLE,
    col_widths: Optional[Sequence[int]] = None,
    alignments: Optional[Sequence[Alignment]] = None,
) -> str:
    """Render a 2-D table as an ASCII string.

    Parameters
    ----------
    data:
        Rows of cell values (converted to str).
    headers:
        Optional header row displayed above the data with a separator.
    style:
        Border style to use.
    col_widths:
        Explicit per-column widths. When *None*, widths are auto-computed.
    alignments:
        Per-column alignment. Defaults to LEFT for every column.
    """
    # Normalise data to list[list[str]]
    str_data: list[list[str]] = [[str(c) for c in row] for row in data]

    # Determine number of columns
    num_cols = 0
    if headers:
        num_cols = max(num_cols, len(headers))
    for row in str_data:
        num_cols = max(num_cols, len(row))

    if num_cols == 0:
        # Completely empty
        tl, tr, bl, br, h, v, *_ = style.value
        return f"{tl}{tr}\n{bl}{br}"

    # Pad rows to num_cols
    for row in str_data:
        while len(row) < num_cols:
            row.append("")

    str_headers: list[str] | None = None
    if headers is not None:
        str_headers = list(headers) + [""] * (num_cols - len(headers))

    # Compute column widths
    if col_widths is not None:
        widths = list(col_widths) + [0] * (num_cols - len(col_widths))
    else:
        widths = [0] * num_cols
        if str_headers:
            for i, h_text in enumerate(str_headers):
                widths[i] = max(widths[i], len(h_text))
        for row in str_data:
            for i, cell in enumerate(row):
                widths[i] = max(widths[i], len(cell))

    # Default alignments
    aligns: list[Alignment]
    if alignments is not None:
        aligns = list(alignments) + [Alignment.LEFT] * (num_cols - len(alignments))
    else:
        aligns = [Alignment.LEFT] * num_cols

    # Unpack border chars
    tl, tr, bl, br, h, v, *_ = style.value
    left_t, right_t, top_t, bottom_t, cross = _CROSS_PIECES[style]

    # Helper to build a horizontal rule
    def h_rule(left: str, mid: str, right: str) -> str:
        segments = [h * (w + 2) for w in widths]
        return left + mid.join(segments) + right

    # Helper to build a data row
    def data_row(cells: list[str]) -> str:
        parts = []
        for i, cell in enumerate(cells):
            parts.append(" " + _align(cell, widths[i], aligns[i]) + " ")
        return v + v.join(parts) + v

    lines: list[str] = []

    # Top border
    lines.append(h_rule(tl, top_t, tr))

    # Header
    if str_headers is not None:
        lines.append(data_row(str_headers))
        lines.append(h_rule(left_t, cross, right_t))

    # Data rows
    for row in str_data:
        lines.append(data_row(row))

    # Bottom border
    lines.append(h_rule(bl, bottom_t, br))

    return "\n".join(lines)


class TableBuilder(BaseBuilder):
    """Fluent builder for ASCII tables."""

    _defaults: dict[str, Any] = {
        "data": [],
        "headers": None,
        "style": BorderStyle.SINGLE,
        "col_widths": None,
        "alignments": None,
    }

    def render(self) -> str:
        return table(
            data=self._settings["data"],
            headers=self._settings["headers"],
            style=self._settings["style"],
            col_widths=self._settings["col_widths"],
            alignments=self._settings["alignments"],
        )
