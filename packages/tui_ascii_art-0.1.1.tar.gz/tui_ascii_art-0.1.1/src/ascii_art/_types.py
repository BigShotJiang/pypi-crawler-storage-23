"""Core types, enums, and constants for ascii_art."""

from __future__ import annotations

from enum import Enum
from typing import Tuple

# Type aliases
Point = Tuple[int, int]
Size = Tuple[int, int]


class Alignment(Enum):
    LEFT = "left"
    CENTER = "center"
    RIGHT = "right"


class BorderStyle(Enum):
    """Border characters: (tl, tr, bl, br, h, v)."""

    SINGLE = ("┌", "┐", "└", "┘", "─", "│")
    DOUBLE = ("╔", "╗", "╚", "╝", "═", "║")
    ROUNDED = ("╭", "╮", "╰", "╯", "─", "│")
    BOLD = ("┏", "┓", "┗", "┛", "━", "┃")
    ASCII = ("+", "+", "+", "+", "-", "|")
    DASHED = ("┌", "┐", "└", "┘", "╌", "╎")
    SHADOW = ("┌", "┐", "└", "┘", "─", "│", "░")


# Luminance ramps (dark → light)
DEFAULT_CHAR_RAMP = " .:-=+*#%@"
DETAILED_CHAR_RAMP = " .'`^\",:;Il!i><~+_-?][}{1)(|\\/tfjrxnuvczXYUJCLQ0OZmwqpdbkhao*#MW&8%B@$"
BLOCK_CHAR_RAMP = " ░▒▓█"
