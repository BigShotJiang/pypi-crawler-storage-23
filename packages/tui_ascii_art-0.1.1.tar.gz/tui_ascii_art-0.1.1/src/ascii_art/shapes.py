"""Shape drawing primitives on an ASCII canvas."""

from __future__ import annotations

from typing import Any, Optional

from ascii_art._builder import BaseBuilder


class Canvas:
    """A 2D grid of characters that can be drawn on and rendered to a string."""

    def __init__(self, w: int, h: int) -> None:
        self.width = w
        self.height = h
        self._grid: list[list[str]] = [[" "] * w for _ in range(h)]

    def set(self, x: int, y: int, char: str) -> None:
        """Set a character at (x, y). Out-of-bounds calls are silently ignored."""
        if 0 <= x < self.width and 0 <= y < self.height:
            self._grid[y][x] = char

    def get(self, x: int, y: int) -> str:
        """Get the character at (x, y)."""
        if 0 <= x < self.width and 0 <= y < self.height:
            return self._grid[y][x]
        return " "

    def clear(self) -> None:
        """Reset every cell to a space."""
        self._grid = [[" "] * self.width for _ in range(self.height)]

    def overlay(self, other: "Canvas", ox: int, oy: int) -> "Canvas":
        """Overlay *other* canvas onto this one at offset (ox, oy).

        Only non-space characters from *other* are copied.
        """
        for y in range(other.height):
            for x in range(other.width):
                ch = other.get(x, y)
                if ch != " ":
                    self.set(ox + x, oy + y, ch)
        return self

    def render(self) -> str:
        """Return the canvas as a multi-line string (lines joined by newlines)."""
        return "\n".join("".join(row) for row in self._grid)

    def to_str(self) -> str:
        """Alias for render()."""
        return self.render()


# ---------------------------------------------------------------------------
# Drawing functions — all mutate canvas in-place and return it for chaining.
# ---------------------------------------------------------------------------


def line(canvas: Canvas, x0: int, y0: int, x1: int, y1: int, char: str = "#") -> Canvas:
    """Draw a line using Bresenham's algorithm."""
    dx = abs(x1 - x0)
    dy = -abs(y1 - y0)
    sx = 1 if x0 < x1 else -1
    sy = 1 if y0 < y1 else -1
    err = dx + dy

    cx, cy = x0, y0
    while True:
        canvas.set(cx, cy, char)
        if cx == x1 and cy == y1:
            break
        e2 = 2 * err
        if e2 >= dy:
            err += dy
            cx += sx
        if e2 <= dx:
            err += dx
            cy += sy
    return canvas


def rectangle(
    canvas: Canvas,
    x: int,
    y: int,
    w: int,
    h: int,
    char: str = "#",
    fill: bool = False,
) -> Canvas:
    """Draw a rectangle. If *fill* is True, fill the interior."""
    for row in range(h):
        for col in range(w):
            if fill or row == 0 or row == h - 1 or col == 0 or col == w - 1:
                canvas.set(x + col, y + row, char)
    return canvas


def circle(canvas: Canvas, cx: int, cy: int, r: int, char: str = "#") -> Canvas:
    """Draw a circle using the midpoint circle algorithm."""
    x = 0
    y = r
    d = 1 - r

    def _plot8(cx: int, cy: int, x: int, y: int) -> None:
        for px, py in [
            (cx + x, cy + y),
            (cx - x, cy + y),
            (cx + x, cy - y),
            (cx - x, cy - y),
            (cx + y, cy + x),
            (cx - y, cy + x),
            (cx + y, cy - x),
            (cx - y, cy - x),
        ]:
            canvas.set(px, py, char)

    _plot8(cx, cy, x, y)
    while x < y:
        x += 1
        if d < 0:
            d += 2 * x + 1
        else:
            y -= 1
            d += 2 * (x - y) + 1
        _plot8(cx, cy, x, y)
    return canvas


def ellipse(
    canvas: Canvas, cx: int, cy: int, rx: int, ry: int, char: str = "#"
) -> Canvas:
    """Draw an ellipse using the midpoint ellipse algorithm."""
    rx2 = rx * rx
    ry2 = ry * ry

    x = 0
    y = ry
    # Region 1
    d1 = ry2 - rx2 * ry + 0.25 * rx2
    dx = 2 * ry2 * x
    dy = 2 * rx2 * y

    while dx < dy:
        canvas.set(cx + x, cy + y, char)
        canvas.set(cx - x, cy + y, char)
        canvas.set(cx + x, cy - y, char)
        canvas.set(cx - x, cy - y, char)
        x += 1
        dx += 2 * ry2
        if d1 < 0:
            d1 += dx + ry2
        else:
            y -= 1
            dy -= 2 * rx2
            d1 += dx - dy + ry2

    # Region 2
    d2 = ry2 * (x + 0.5) ** 2 + rx2 * (y - 1) ** 2 - rx2 * ry2
    while y >= 0:
        canvas.set(cx + x, cy + y, char)
        canvas.set(cx - x, cy + y, char)
        canvas.set(cx + x, cy - y, char)
        canvas.set(cx - x, cy - y, char)
        y -= 1
        dy -= 2 * rx2
        if d2 > 0:
            d2 += rx2 - dy
        else:
            x += 1
            dx += 2 * ry2
            d2 += dx - dy + rx2

    return canvas


def triangle(
    canvas: Canvas,
    x0: int,
    y0: int,
    x1: int,
    y1: int,
    x2: int,
    y2: int,
    char: str = "#",
) -> Canvas:
    """Draw a triangle by connecting three vertices with lines."""
    line(canvas, x0, y0, x1, y1, char)
    line(canvas, x1, y1, x2, y2, char)
    line(canvas, x2, y2, x0, y0, char)
    return canvas


def diamond(canvas: Canvas, cx: int, cy: int, size: int, char: str = "#") -> Canvas:
    """Draw a diamond (rhombus) centred at (cx, cy)."""
    for i in range(size + 1):
        canvas.set(cx + i, cy - size + i, char)  # top-right edge
        canvas.set(cx - i, cy - size + i, char)  # top-left edge
        canvas.set(cx + i, cy + size - i, char)  # bottom-right edge
        canvas.set(cx - i, cy + size - i, char)  # bottom-left edge
    return canvas


def arrow(
    canvas: Canvas,
    x0: int,
    y0: int,
    x1: int,
    y1: int,
    char: str = "#",
    head_char: Optional[str] = None,
) -> Canvas:
    """Draw a line from (x0,y0) to (x1,y1) with an arrowhead at the end."""
    if head_char is None:
        head_char = char

    line(canvas, x0, y0, x1, y1, char)

    # Determine arrowhead direction
    dx = x1 - x0
    dy = y1 - y0

    if abs(dx) >= abs(dy):
        # Mostly horizontal
        if dx > 0:
            canvas.set(x1, y1, ">")
        elif dx < 0:
            canvas.set(x1, y1, "<")
        else:
            canvas.set(x1, y1, head_char)
    else:
        # Mostly vertical
        if dy > 0:
            canvas.set(x1, y1, "v")
        elif dy < 0:
            canvas.set(x1, y1, "^")
        else:
            canvas.set(x1, y1, head_char)

    # Override the very tip with head_char if caller specified one explicitly
    if head_char != char:
        canvas.set(x1, y1, head_char)

    return canvas


# ---------------------------------------------------------------------------
# ShapesBuilder — fluent builder on top of Canvas + drawing primitives
# ---------------------------------------------------------------------------


class ShapesBuilder(BaseBuilder):
    """Fluent builder for composing shapes on a canvas."""

    _defaults: dict[str, Any] = {
        "width": 80,
        "height": 24,
        "char": "#",
    }

    def __init__(self) -> None:
        super().__init__()
        self._operations: list[tuple[str, tuple, dict]] = []

    # -- convenience chaining methods ---------------------------------------

    def add_line(
        self, x0: int, y0: int, x1: int, y1: int, char: str | None = None
    ) -> "ShapesBuilder":
        self._operations.append(("line", (x0, y0, x1, y1), {"char": char}))
        return self

    def add_rectangle(
        self,
        x: int,
        y: int,
        w: int,
        h: int,
        char: str | None = None,
        fill: bool = False,
    ) -> "ShapesBuilder":
        self._operations.append(
            ("rectangle", (x, y, w, h), {"char": char, "fill": fill})
        )
        return self

    def add_circle(
        self, cx: int, cy: int, r: int, char: str | None = None
    ) -> "ShapesBuilder":
        self._operations.append(("circle", (cx, cy, r), {"char": char}))
        return self

    def add_triangle(
        self,
        x0: int,
        y0: int,
        x1: int,
        y1: int,
        x2: int,
        y2: int,
        char: str | None = None,
    ) -> "ShapesBuilder":
        self._operations.append(
            ("triangle", (x0, y0, x1, y1, x2, y2), {"char": char})
        )
        return self

    def add_diamond(
        self, cx: int, cy: int, size: int, char: str | None = None
    ) -> "ShapesBuilder":
        self._operations.append(("diamond", (cx, cy, size), {"char": char}))
        return self

    def add_arrow(
        self,
        x0: int,
        y0: int,
        x1: int,
        y1: int,
        char: str | None = None,
        head_char: str | None = None,
    ) -> "ShapesBuilder":
        self._operations.append(
            ("arrow", (x0, y0, x1, y1), {"char": char, "head_char": head_char})
        )
        return self

    # -- render -------------------------------------------------------------

    def render(self) -> str:
        w = self._settings["width"]
        h = self._settings["height"]
        default_char = self._settings["char"]
        c = Canvas(w, h)

        dispatch = {
            "line": line,
            "rectangle": rectangle,
            "circle": circle,
            "triangle": triangle,
            "diamond": diamond,
            "arrow": arrow,
        }

        for op_name, args, kwargs in self._operations:
            fn = dispatch[op_name]
            # Replace None char with the builder default
            resolved = {
                k: (v if v is not None else default_char) if k == "char" else v
                for k, v in kwargs.items()
            }
            # Remove None values for optional params like head_char
            resolved = {k: v for k, v in resolved.items() if v is not None}
            fn(c, *args, **resolved)

        return c.render()
