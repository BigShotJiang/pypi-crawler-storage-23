"""Lazy-loading integrations for rich, textual, and curses."""

from __future__ import annotations

import importlib
from typing import Any

_MODULES = {
    "rich_panel": ".rich_panel",
    "textual_widget": ".textual_widget",
    "curses_win": ".curses_win",
}


def __getattr__(name: str) -> Any:
    if name in _MODULES:
        return importlib.import_module(_MODULES[name], __name__)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
