"""Curses integration — write ASCII art to curses windows."""

from __future__ import annotations

import curses
from typing import Any


def write_to_window(win: Any, content: str, y: int = 0, x: int = 0) -> None:
    """Write ASCII art string to a curses window at the given coordinates."""
    for i, line in enumerate(content.split("\n")):
        try:
            win.addstr(y + i, x, line)
        except curses.error:
            pass  # Silently skip if writing beyond window bounds
