"""Textual integration — returns Static widget."""

from __future__ import annotations

from typing import Any


def _require_textual() -> Any:
    try:
        import textual
        return textual
    except ImportError:
        raise ImportError(
            "textual is required for this integration. "
            "Install it with: pip install ascii-art[textual]"
        ) from None


def to_static(content: str) -> Any:
    """Convert ASCII art string to a Textual Static widget."""
    _require_textual()
    from textual.widgets import Static
    return Static(content)
