"""Rich integration — returns Rich Text/Panel objects."""

from __future__ import annotations

from typing import Any


def _require_rich() -> Any:
    try:
        import rich
        return rich
    except ImportError:
        raise ImportError(
            "rich is required for this integration. "
            "Install it with: pip install ascii-art[rich]"
        ) from None


def to_text(content: str) -> Any:
    """Convert ASCII art string to a Rich Text object."""
    _require_rich()
    from rich.text import Text
    return Text(content)


def to_panel(content: str, title: str | None = None) -> Any:
    """Wrap ASCII art string in a Rich Panel."""
    _require_rich()
    from rich.panel import Panel
    return Panel(content, title=title)
