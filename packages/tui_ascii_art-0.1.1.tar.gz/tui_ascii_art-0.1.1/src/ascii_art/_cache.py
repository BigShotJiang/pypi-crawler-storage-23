"""Thin caching wrapper over functools.lru_cache."""

from __future__ import annotations

import functools
from typing import Any, Callable, TypeVar, overload

F = TypeVar("F", bound=Callable[..., Any])


@overload
def cached(fn: F) -> F: ...


@overload
def cached(*, maxsize: int = 128) -> Callable[[F], F]: ...


def cached(fn: Any = None, *, maxsize: int = 128) -> Any:
    """Cache decorator. Use as @cached or @cached(maxsize=N)."""
    if fn is not None:
        return functools.lru_cache(maxsize=128)(fn)

    def decorator(func: F) -> F:
        return functools.lru_cache(maxsize=maxsize)(func)  # type: ignore[return-value]

    return decorator
