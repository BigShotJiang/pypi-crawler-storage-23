"""Convert images to ASCII art."""

from __future__ import annotations

import math
from typing import Optional, Union

from PIL import Image

from ._builder import BaseBuilder
from ._types import DEFAULT_CHAR_RAMP

# Character aspect ratio: terminal chars are taller than wide
_CHAR_ASPECT = 0.55


def _sobel(pixels: list[list[int]], width: int, height: int) -> list[list[float]]:
    """Apply Sobel edge detection, returning gradient magnitudes."""
    result: list[list[float]] = [[0.0] * width for _ in range(height)]
    for y in range(1, height - 1):
        for x in range(1, width - 1):
            # Sobel kernels
            gx = (
                -pixels[y - 1][x - 1]
                + pixels[y - 1][x + 1]
                - 2 * pixels[y][x - 1]
                + 2 * pixels[y][x + 1]
                - pixels[y + 1][x - 1]
                + pixels[y + 1][x + 1]
            )
            gy = (
                -pixels[y - 1][x - 1]
                - 2 * pixels[y - 1][x]
                - pixels[y - 1][x + 1]
                + pixels[y + 1][x - 1]
                + 2 * pixels[y + 1][x]
                + pixels[y + 1][x + 1]
            )
            result[y][x] = math.sqrt(gx * gx + gy * gy)
    return result


def render(
    source: Union[str, Image.Image],
    width: int = 80,
    charset: Optional[str] = None,
    invert: bool = False,
    edges: bool = False,
) -> str:
    """Render an image as ASCII art.

    Args:
        source: File path or PIL Image object.
        width: Number of output columns.
        charset: Character ramp (dark to light). Defaults to DEFAULT_CHAR_RAMP.
        invert: Reverse the character ramp.
        edges: Apply Sobel edge detection before mapping.

    Returns:
        Multi-line string of ASCII art.
    """
    if charset is None:
        charset = DEFAULT_CHAR_RAMP

    ramp = charset[::-1] if invert else charset
    ramp_len = len(ramp)

    # Load image
    if isinstance(source, str):
        img = Image.open(source)
    else:
        img = source

    # Convert to grayscale
    img = img.convert("L")

    # Resize: adjust height for character aspect ratio
    orig_w, orig_h = img.size
    new_width = width
    new_height = max(1, int(orig_h * (new_width / orig_w) * _CHAR_ASPECT))
    img = img.resize((new_width, new_height))

    # Extract pixel data as 2D list
    pixel_data = list(img.tobytes())
    pixels: list[list[int]] = []
    for y in range(new_height):
        row = pixel_data[y * new_width : (y + 1) * new_width]
        pixels.append(row)

    if edges:
        magnitudes = _sobel(pixels, new_width, new_height)
        # Find max magnitude for normalization
        max_mag = 0.0
        for row in magnitudes:
            for val in row:
                if val > max_mag:
                    max_mag = val
        if max_mag == 0:
            max_mag = 1.0

        lines: list[str] = []
        for y in range(new_height):
            chars: list[str] = []
            for x in range(new_width):
                normalized = magnitudes[y][x] / max_mag
                idx = int(normalized * (ramp_len - 1))
                chars.append(ramp[idx])
            lines.append("".join(chars))
    else:
        lines = []
        for y in range(new_height):
            chars = []
            for x in range(new_width):
                luminance = pixels[y][x]
                idx = int(luminance / 255 * (ramp_len - 1))
                chars.append(ramp[idx])
            lines.append("".join(chars))

    return "\n".join(lines)


class ImageBuilder(BaseBuilder):
    """Fluent builder for image-to-ASCII conversion."""

    _defaults = {
        "source": None,
        "width": 80,
        "charset": None,
        "invert": False,
        "edges": False,
    }

    def render(self) -> str:
        source = self._settings["source"]
        if source is None:
            raise ValueError("source must be set before rendering")
        return render(
            source=source,
            width=self._settings["width"],
            charset=self._settings["charset"],
            invert=self._settings["invert"],
            edges=self._settings["edges"],
        )
