"""Base builder with fluent API generated from _defaults dict."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class BaseBuilder(ABC):
    """Abstract builder. Subclasses define _defaults dict and implement render()."""

    _defaults: dict[str, Any] = {}

    def __init__(self) -> None:
        self._settings: dict[str, Any] = dict(self._defaults)

    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            raise AttributeError(name)
        if name not in self._defaults:
            raise AttributeError(
                f"'{type(self).__name__}' has no setting '{name}'"
            )

        def setter(value: Any) -> "BaseBuilder":
            self._settings[name] = value
            return self

        return setter

    @abstractmethod
    def render(self) -> str: ...
