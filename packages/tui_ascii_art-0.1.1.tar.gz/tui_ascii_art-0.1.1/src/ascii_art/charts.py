"""Chart drawing: sparkline, bar_chart, scatter, and ChartBuilder."""

from __future__ import annotations

from typing import Any, List, Optional, Sequence, Tuple

from ascii_art._builder import BaseBuilder

# Unicode block characters for sparkline (8 levels, low to high)
_SPARK_BLOCKS = "▁▂▃▄▅▆▇█"


def sparkline(data: Sequence[float], width: Optional[int] = None) -> str:
    """Single-line spark chart using Unicode block characters.

    Args:
        data: Sequence of numeric values.
        width: If given, resample data to this many characters.

    Returns:
        A single-line string of block characters.
    """
    if not data:
        return ""

    values: list[float] = list(data)

    # Resample if width is specified
    if width is not None and width > 0 and len(values) != width:
        resampled: list[float] = []
        n = len(values)
        for i in range(width):
            # Map output index to input index (linear interpolation of index)
            src = i * (n - 1) / (width - 1) if width > 1 else 0
            lo = int(src)
            hi = min(lo + 1, n - 1)
            frac = src - lo
            resampled.append(values[lo] * (1 - frac) + values[hi] * frac)
        values = resampled

    lo = min(values)
    hi = max(values)
    span = hi - lo

    chars: list[str] = []
    for v in values:
        if span == 0:
            idx = 0
        else:
            normalized = (v - lo) / span
            idx = int(normalized * (len(_SPARK_BLOCKS) - 1))
            idx = min(idx, len(_SPARK_BLOCKS) - 1)
        chars.append(_SPARK_BLOCKS[idx])

    return "".join(chars)


def bar_chart(
    data: Sequence[float],
    width: int = 40,
    labels: Optional[Sequence[str]] = None,
    char: str = "█",
) -> str:
    """Horizontal bar chart.

    Args:
        data: Sequence of numeric values (one bar per value).
        width: Maximum bar length in characters.
        labels: Optional labels shown on the left, right-aligned.
        char: Character used for the bar.

    Returns:
        Multi-line string with one bar per data item.
    """
    values = [max(0, v) for v in data]
    max_val = max(values) if values else 1

    label_width = 0
    if labels:
        label_width = max(len(l) for l in labels)

    lines: list[str] = []
    for i, v in enumerate(values):
        bar_len = int(v / max_val * width) if max_val > 0 else 0
        bar = char * bar_len

        if labels and i < len(labels):
            lbl = labels[i].rjust(label_width)
            lines.append(f"{lbl} {bar}")
        else:
            lines.append(bar)

    return "\n".join(lines)


def scatter(
    points: Sequence[Tuple[float, float]],
    width: int = 60,
    height: int = 20,
    char: str = "*",
) -> str:
    """Scatter plot on a character grid.

    Args:
        points: Sequence of (x, y) tuples.
        width: Grid width in characters.
        height: Grid height in characters.
        char: Character used for each point.

    Returns:
        Multi-line string representing the scatter plot.
    """
    # Build empty grid
    grid: list[list[str]] = [[" "] * width for _ in range(height)]

    if points:
        xs = [p[0] for p in points]
        ys = [p[1] for p in points]
        x_min, x_max = min(xs), max(xs)
        y_min, y_max = min(ys), max(ys)
        x_span = x_max - x_min if x_max != x_min else 1
        y_span = y_max - y_min if y_max != y_min else 1

        for x, y in points:
            col = int((x - x_min) / x_span * (width - 1))
            row = int((y - y_min) / y_span * (height - 1))
            col = min(max(col, 0), width - 1)
            row = min(max(row, 0), height - 1)
            # Invert row: high y -> top of grid (row 0)
            grid[height - 1 - row][col] = char

    return "\n".join("".join(row) for row in grid)


class ChartBuilder(BaseBuilder):
    """Fluent builder for charts."""

    _defaults: dict[str, Any] = {
        "chart_type": "bar",
        "data": [],
        "width": 40,
        "height": 20,
        "labels": None,
        "char": "█",
    }

    def render(self) -> str:
        s = self._settings
        ct = s["chart_type"]

        if ct == "sparkline":
            return sparkline(s["data"], width=s["width"])
        elif ct == "scatter":
            return scatter(
                s["data"],
                width=s["width"],
                height=s["height"],
                char=s["char"],
            )
        else:  # bar
            return bar_chart(
                s["data"],
                width=s["width"],
                labels=s["labels"],
                char=s["char"],
            )
