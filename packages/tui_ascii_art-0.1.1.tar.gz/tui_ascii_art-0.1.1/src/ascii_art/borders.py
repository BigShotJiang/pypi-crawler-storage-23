"""Border framing, dividers, and a fluent BorderBuilder."""

from __future__ import annotations

from ascii_art._builder import BaseBuilder
from ascii_art._types import BorderStyle


def frame(
    text: str,
    style: BorderStyle = BorderStyle.SINGLE,
    width: int | None = None,
    padding: int = 1,
    title: str | None = None,
) -> str:
    """Wrap *text* in a border box and return the resulting string."""
    chars = style.value
    tl, tr, bl, br, h, v = chars[0], chars[1], chars[2], chars[3], chars[4], chars[5]
    shadow_char = chars[6] if len(chars) > 6 else None

    lines = text.split("\n")
    pad = " " * padding

    if width is None:
        inner = max(len(line) for line in lines) + 2 * padding
        width = inner + 2  # +2 for border chars
    else:
        inner = width - 2  # space inside the border chars

    # Build top border, optionally embedding a title
    if title:
        # title sits after the first horizontal char with a space on each side
        title_segment = f" {title} "
        remaining = inner - len(title_segment)
        top = tl + title_segment + h * remaining + tr
    else:
        top = tl + h * inner + tr

    # Build bottom border
    bottom = bl + h * inner + br

    # Build content lines
    content_lines: list[str] = []
    content_width = inner - 2 * padding  # usable text width
    for line in lines:
        if len(line) > content_width:
            line = line[:content_width]
        padded = pad + line + " " * (content_width - len(line)) + pad
        content_lines.append(f"{v}{padded}{v}")

    if shadow_char:
        # Shadow on right side (+1 col) and bottom row
        shadow_top = top + shadow_char
        shadow_content = [cl + shadow_char for cl in content_lines]
        shadow_bottom = bottom + shadow_char
        shadow_row = " " + shadow_char * (width)
        return "\n".join([shadow_top, *shadow_content, shadow_bottom, shadow_row])

    return "\n".join([top, *content_lines, bottom])


def divider(
    label: str | None = None,
    style: BorderStyle = BorderStyle.SINGLE,
    width: int = 80,
) -> str:
    """Return a horizontal divider line, optionally with a centered label."""
    h = style.value[4]
    if label:
        segment = f" {label} "
        remaining = width - len(segment)
        left = remaining // 2
        right = remaining - left
        return h * left + segment + h * right
    return h * width


class BorderBuilder(BaseBuilder):
    """Fluent builder for frame()."""

    _defaults: dict = {
        "text": "",
        "style": BorderStyle.SINGLE,
        "width": None,
        "padding": 1,
        "title": None,
    }

    def render(self) -> str:
        return frame(**self._settings)
