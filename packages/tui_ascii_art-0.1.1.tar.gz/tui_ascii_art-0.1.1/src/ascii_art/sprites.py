"""Sprite and Animation classes for ASCII art."""

from __future__ import annotations

from typing import Any, Iterator

from ascii_art._builder import BaseBuilder


class Sprite:
    """Immutable ASCII sprite stored as a tuple of strings."""

    __slots__ = ("_grid",)

    def __init__(self, grid: list[str]) -> None:
        self._grid: tuple[str, ...] = tuple(grid)

    # -- properties ----------------------------------------------------------

    @property
    def width(self) -> int:
        return max((len(row) for row in self._grid), default=0)

    @property
    def height(self) -> int:
        return len(self._grid)

    # -- rendering ------------------------------------------------------------

    def render(self) -> str:
        return "\n".join(self._grid)

    # -- transforms (all return new Sprite) -----------------------------------

    def flip_h(self) -> Sprite:
        """Reverse each row (horizontal mirror)."""
        return Sprite([row[::-1] for row in self._grid])

    def flip_v(self) -> Sprite:
        """Reverse row order (vertical mirror)."""
        return Sprite(list(self._grid[::-1]))

    def rotate(self, degrees: int) -> Sprite:
        """Rotate by 90, 180, or 270 degrees clockwise. Returns new Sprite."""
        degrees = degrees % 360
        if degrees == 0:
            return Sprite(list(self._grid))
        if degrees == 180:
            return self.flip_h().flip_v()
        # Pad rows to equal width for transpose
        w = self.width
        rows = [row.ljust(w) for row in self._grid]
        if degrees == 90:
            # Transpose then reverse each row
            transposed = [
                "".join(rows[r][c] for r in range(len(rows)))
                for c in range(w)
            ]
            return Sprite([row[::-1] for row in transposed])
        if degrees == 270:
            # Transpose then reverse row order
            transposed = [
                "".join(rows[r][c] for r in range(len(rows)))
                for c in range(w)
            ]
            return Sprite(list(reversed(transposed)))
        raise ValueError(f"degrees must be 0, 90, 180, or 270; got {degrees}")

    def scale(self, factor: int) -> Sprite:
        """Scale by integer factor. Each char becomes factor x factor block."""
        new_rows: list[str] = []
        for row in self._grid:
            scaled_row = "".join(ch * factor for ch in row)
            for _ in range(factor):
                new_rows.append(scaled_row)
        return Sprite(new_rows)


class Animation:
    """Simple ordered container of Sprite frames."""

    def __init__(self, frames: list[Sprite]) -> None:
        self._frames = list(frames)

    @property
    def frames(self) -> list[Sprite]:
        return list(self._frames)

    def __len__(self) -> int:
        return len(self._frames)

    def __iter__(self) -> Iterator[Sprite]:
        return iter(self._frames)

    def frame(self, n: int) -> Sprite:
        return self._frames[n]


class SpriteBuilder(BaseBuilder):
    """Fluent builder for Sprite creation with transforms."""

    _defaults: dict[str, Any] = {
        "grid": [],
        "scale_factor": 1,
        "flip_horizontal": False,
        "flip_vertical": False,
        "rotation": 0,
    }

    def render(self) -> str:
        sprite = Sprite(self._settings["grid"])
        if self._settings["scale_factor"] != 1:
            sprite = sprite.scale(self._settings["scale_factor"])
        if self._settings["flip_horizontal"]:
            sprite = sprite.flip_h()
        if self._settings["flip_vertical"]:
            sprite = sprite.flip_v()
        if self._settings["rotation"]:
            sprite = sprite.rotate(self._settings["rotation"])
        return sprite.render()


# -- bundled sprites ----------------------------------------------------------

SPRITES: dict[str, list[str]] = {
    "heart": [
        " ** ** ",
        "*******",
        "*******",
        " ***** ",
        "  ***  ",
        "   *   ",
    ],
    "star": [
        "  *  ",
        " *** ",
        "*****",
        " *** ",
        "  *  ",
    ],
    "arrow_right": [
        "  *  ",
        "  ** ",
        "*****",
        "  ** ",
        "  *  ",
    ],
    "smiley": [
        " *** ",
        "* * *",
        "*   *",
        "* * *",
        " *** ",
    ],
}
