"""CLI entry point for ascii_art."""

from __future__ import annotations

import argparse
import sys


def _cmd_text(args: argparse.Namespace) -> None:
    from ascii_art.text import render
    from ascii_art._types import Alignment

    align = Alignment(args.align)
    print(render(args.text, font=args.font, width=args.width, align=align))


def _cmd_image(args: argparse.Namespace) -> None:
    from ascii_art.image import render

    print(render(args.path, width=args.width, invert=args.invert, edges=args.edges))


def _cmd_shape(args: argparse.Namespace) -> None:
    from ascii_art.shapes import Canvas, rectangle, circle, diamond

    c = Canvas(args.width, args.height)
    shape = args.shape
    char = args.char
    if shape == "rectangle":
        rectangle(c, 1, 1, args.width - 2, args.height - 2, char)
    elif shape == "circle":
        r = min(args.width, args.height) // 2 - 1
        circle(c, args.width // 2, args.height // 2, r, char)
    elif shape == "diamond":
        size = min(args.width, args.height) // 2 - 1
        diamond(c, args.width // 2, args.height // 2, size, char)
    else:
        print(f"Unknown shape: {shape}", file=sys.stderr)
        sys.exit(1)
    print(c.render())


def _cmd_border(args: argparse.Namespace) -> None:
    from ascii_art.borders import frame
    from ascii_art._types import BorderStyle

    style = BorderStyle[args.style.upper()]
    text = args.text if args.text else sys.stdin.read()
    print(frame(text, style=style, width=args.width, title=args.title))


def _cmd_table(args: argparse.Namespace) -> None:
    from ascii_art.tables import table
    from ascii_art._types import BorderStyle

    import csv
    import io

    style = BorderStyle[args.style.upper()]
    raw = args.data if args.data else sys.stdin.read()
    reader = csv.reader(io.StringIO(raw))
    rows = list(reader)
    if not rows:
        return
    if args.headers:
        headers = rows[0]
        data = rows[1:]
    else:
        headers = None
        data = rows
    print(table(data, headers=headers, style=style))


def _cmd_chart(args: argparse.Namespace) -> None:
    from ascii_art.charts import sparkline, bar_chart

    values = [float(v) for v in args.values.split(",")]
    if args.type == "sparkline":
        print(sparkline(values))
    elif args.type == "bar":
        print(bar_chart(values, width=args.width))


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="ascii-art",
        description="Programmatic ASCII art generation for TUIs",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # text
    p_text = sub.add_parser("text", help="Render figlet text")
    p_text.add_argument("text", help="Text to render")
    p_text.add_argument("--font", default="standard", help="Font name")
    p_text.add_argument("--width", type=int, default=80)
    p_text.add_argument("--align", default="left", choices=["left", "center", "right"])
    p_text.set_defaults(func=_cmd_text)

    # image
    p_img = sub.add_parser("image", help="Convert image to ASCII")
    p_img.add_argument("path", help="Image file path")
    p_img.add_argument("--width", type=int, default=80)
    p_img.add_argument("--invert", action="store_true")
    p_img.add_argument("--edges", action="store_true")
    p_img.set_defaults(func=_cmd_image)

    # shape
    p_shape = sub.add_parser("shape", help="Draw a shape")
    p_shape.add_argument("shape", choices=["rectangle", "circle", "diamond"])
    p_shape.add_argument("--width", type=int, default=40)
    p_shape.add_argument("--height", type=int, default=20)
    p_shape.add_argument("--char", default="#")
    p_shape.set_defaults(func=_cmd_shape)

    # border
    p_border = sub.add_parser("border", help="Frame text in a border")
    p_border.add_argument("text", nargs="?", default=None, help="Text (or stdin)")
    p_border.add_argument("--style", default="single")
    p_border.add_argument("--width", type=int, default=None)
    p_border.add_argument("--title", default=None)
    p_border.set_defaults(func=_cmd_border)

    # table
    p_table = sub.add_parser("table", help="Render CSV as table")
    p_table.add_argument("data", nargs="?", default=None, help="CSV data (or stdin)")
    p_table.add_argument("--style", default="single")
    p_table.add_argument("--headers", action="store_true", help="First row is headers")
    p_table.set_defaults(func=_cmd_table)

    # chart
    p_chart = sub.add_parser("chart", help="Render a chart")
    p_chart.add_argument("values", help="Comma-separated numbers")
    p_chart.add_argument("--type", default="bar", choices=["sparkline", "bar"])
    p_chart.add_argument("--width", type=int, default=40)
    p_chart.set_defaults(func=_cmd_chart)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
