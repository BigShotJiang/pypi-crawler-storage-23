"""Text-to-ASCII-art rendering powered by pyfiglet."""

from __future__ import annotations

import pyfiglet

from ._builder import BaseBuilder
from ._cache import cached
from ._types import Alignment

# Curated list of well-known, widely-available pyfiglet fonts.
CURATED_FONTS: list[str] = [
    "banner",
    "banner3",
    "big",
    "block",
    "bubble",
    "digital",
    "isometric1",
    "lean",
    "mini",
    "script",
    "shadow",
    "slant",
    "small",
    "speed",
    "standard",
    "starwars",
    "stop",
    "thin",
    "threepoint",
]


@cached
def _load_font(font: str, width: int) -> pyfiglet.Figlet:
    """Return a cached Figlet instance for *font* at *width*."""
    return pyfiglet.Figlet(font=font, width=width)


def _align_line(line: str, width: int, align: Alignment) -> str:
    """Align a single line within *width* columns."""
    if align is Alignment.CENTER:
        return line.center(width)
    if align is Alignment.RIGHT:
        return line.rjust(width)
    return line  # LEFT – no padding needed


def render(
    text: str,
    font: str = "standard",
    width: int = 80,
    align: Alignment = Alignment.LEFT,
) -> str:
    """Render *text* as ASCII art and return the resulting string.

    Parameters
    ----------
    text:
        The text to render.  If empty, an empty string is returned.
    font:
        Pyfiglet font name (default ``"standard"``).
    width:
        Maximum output width passed to pyfiglet (default 80).
    align:
        How each output line is aligned within *width*.
    """
    if not text:
        return ""

    fig = _load_font(font, width)
    raw = fig.renderText(text)

    # Strip trailing whitespace from every line, then re-join.
    lines = [line.rstrip() for line in raw.splitlines()]

    # Remove trailing blank lines produced by pyfiglet.
    while lines and not lines[-1]:
        lines.pop()

    if align is not Alignment.LEFT:
        lines = [_align_line(line, width, align) for line in lines]

    return "\n".join(lines) + "\n"


def list_fonts() -> list[str]:
    """Return the curated list of recommended fonts."""
    return list(CURATED_FONTS)


class TextBuilder(BaseBuilder):
    """Fluent builder for ASCII-art text rendering."""

    _defaults: dict[str, object] = {
        "text": "",
        "font": "standard",
        "width": 80,
        "align": Alignment.LEFT,
    }

    def render(self) -> str:
        return render(
            text=self._settings["text"],
            font=self._settings["font"],
            width=self._settings["width"],
            align=self._settings["align"],
        )
