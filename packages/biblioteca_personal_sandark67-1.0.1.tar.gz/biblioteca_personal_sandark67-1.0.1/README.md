# Documentación Oficial

### ReadTheDocs

https://biblioteca-personal-sandark67.readthedocs.io/es/latest/

### Pypi

https://pypi.org/project/biblioteca-personal-sandark67/

### Github

https://github.com/AlexandreSinisterra/Trabajo_Final_DI_Oficial

Puedes instalar este projeto diretamente del PyPI usando el siguinte comando, los requisitos estan en la Documentacion de ReadTheDocs:

```bash
pip install biblioteca-personal-sandark67