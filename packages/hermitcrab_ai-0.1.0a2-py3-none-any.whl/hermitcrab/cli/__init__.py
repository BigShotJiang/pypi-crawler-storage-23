"""CLI module for hermitcrab."""
