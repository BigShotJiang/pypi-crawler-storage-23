from setuptools import setup, find_packages

setup(
    name="noviceml",
    version="0.6",
    packages=find_packages(),
    install_requires=["requests"],
    author="Mithun Kulal",
    description="Download Machine Learning lab notebooks from GitHub",
    url="https://github.com/KulalMithun/labpgmml",
)