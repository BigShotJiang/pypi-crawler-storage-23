"""
instaharvest_v2 Agent
==============
AI-powered agent for instaharvest_v2 — natural language to Instagram actions.

Usage:
    from instaharvest_v2.agent import InstaAgent, Permission

    ig = Instagram.from_env(".env")
    agent = InstaAgent(ig, provider="gemini", api_key="...")
    result = agent.ask("Get Cristiano's follower count")

Multi-agent:
    from instaharvest_v2.agent import AgentCoordinator

    coord = AgentCoordinator(ig, provider="gemini", api_key="...")
    results = coord.run_parallel(["task1", "task2"])
"""

from .core import InstaAgent, AgentResult
from .permissions import Permission, ActionType, PermissionManager
from .executor import SafeExecutor, ExecutionResult
from .coordinator import AgentCoordinator, CoordinatorResult

__all__ = [
    "InstaAgent",
    "AgentResult",
    "Permission",
    "ActionType",
    "PermissionManager",
    "SafeExecutor",
    "ExecutionResult",
    "AgentCoordinator",
    "CoordinatorResult",
]
