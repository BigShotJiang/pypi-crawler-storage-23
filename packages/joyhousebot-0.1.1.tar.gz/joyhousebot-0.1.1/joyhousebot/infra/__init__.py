"""Infrastructure utilities (device identity, pairing storage, etc.)."""
