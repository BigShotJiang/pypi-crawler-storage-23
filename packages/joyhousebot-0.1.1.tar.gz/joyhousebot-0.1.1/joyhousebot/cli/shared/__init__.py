"""Shared helpers for CLI command modules."""

