"""Unified CLI command groups."""

