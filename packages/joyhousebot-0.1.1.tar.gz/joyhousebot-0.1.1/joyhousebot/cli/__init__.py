"""CLI module for joyhousebot."""
