"""Chat domain services shared by protocol adapters."""

