"""Shared domain services for HTTP/RPC/CLI adapters."""

