"""API server for joyhousebot client integration."""

from joyhousebot.api.server import create_app

__all__ = ["create_app"]
