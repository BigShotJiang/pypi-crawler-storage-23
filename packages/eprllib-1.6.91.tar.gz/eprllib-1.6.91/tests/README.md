# Tests

To run the tests you need to install `pytest` and then run in the terminal.
Previously, be sure to install the lastest version of `eprllib` in your
system. To run `pytest` just execute the following code:

```
pytest
```
