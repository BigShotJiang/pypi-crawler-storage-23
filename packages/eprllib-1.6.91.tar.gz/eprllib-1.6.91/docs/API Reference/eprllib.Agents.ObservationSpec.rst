﻿eprllib.Agents.ObservationSpec
==============================

.. automodule:: eprllib.Agents.ObservationSpec

   
   .. rubric:: Classes

   .. autosummary::
   
      ObservationSpec
   