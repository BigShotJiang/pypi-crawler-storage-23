﻿eprllib.Agents.Filters.FilterSpec
=================================

.. automodule:: eprllib.Agents.Filters.FilterSpec

   
   .. rubric:: Classes

   .. autosummary::
   
      FilterSpec
   