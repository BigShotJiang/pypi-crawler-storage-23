﻿eprllib.Agents.Filters.BaseFilter
=================================

.. automodule:: eprllib.Agents.Filters.BaseFilter

   
   .. rubric:: Classes

   .. autosummary::
   
      BaseFilter
   