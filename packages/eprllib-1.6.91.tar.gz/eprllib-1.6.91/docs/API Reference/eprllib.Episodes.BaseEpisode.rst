eprllib.Episodes.BaseEpisode
============================

.. automodule:: eprllib.Episodes.BaseEpisode

   
   .. rubric:: Classes

   .. autosummary::
   
      BaseEpisode
   