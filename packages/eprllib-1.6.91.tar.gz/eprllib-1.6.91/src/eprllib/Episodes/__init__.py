"""
Episode Functions
=================

This module contains the methods necesary to modify during runtime the environment for 
each episode. This allow to program different training steps like requiered by
curriculum learning.
"""
