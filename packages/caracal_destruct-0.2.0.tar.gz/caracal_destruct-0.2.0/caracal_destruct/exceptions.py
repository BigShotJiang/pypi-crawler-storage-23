class DistributionException(Exception):
    pass
