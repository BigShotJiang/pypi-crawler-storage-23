import copy
from typing import Any, Dict, List, Optional

from django.core.management import call_command
from django.db import transaction
from django.db.models.signals import post_save
from nwon_baseline import directory_helper, print_helper
from nwon_django_toolbox.signals import disable_signals, enable_signals

from nwon_django_seeding.helper.load_seeds_from_file import load_seeds_from_file
from nwon_django_seeding.helper.parse_info_from_seed_file_name import (
    parse_info_from_seed_file_name,
)
from nwon_django_seeding.nwon_django_seeding_settings import NWON_DJANGO_SEED_SETTINGS


def load_seed_data(environment: str, app_name: Optional[str] = None):
    """
    Loads seed files for a specific environment.

    We always load the default seed files first and then the environment specific ones.
    """

    directories = NWON_DJANGO_SEED_SETTINGS.directories_for_environment(environment)

    """ Disable signals for the following models in order to prevent
    race conditions between seeding and signals """
    disable_signals_for_models = (
        NWON_DJANGO_SEED_SETTINGS.disable_signals_before_seeding_model()
    )

    for directory in [directories.default_directory, directories.environment_directory]:
        print_helper.print_green(f"Loading seed files from {directory}")

        file_paths = directory_helper.file_paths_in_directory(directory, ["json"])
        file_paths.sort()

        for file in file_paths:
            print_helper.print_green(f"Loading seed from {file}")

            # Make sure to commit all pending transactions before loading the seed
            if transaction.get_autocommit():
                transaction.commit()

            model_name, app_name_to_use, _ = parse_info_from_seed_file_name(
                file, app_name
            )
            disable_signal = model_name in [
                m.__name__.lower() for m in disable_signals_for_models
            ]

            if disable_signal:
                disable_signals([post_save])

            __load_seed_file(file, app_name_to_use)

            # Commit all pending transactions stemming from the seed file
            if transaction.get_autocommit():
                transaction.commit()

            # reenable signals if they were disabled
            if disable_signal:
                enable_signals([post_save])


def __load_seed_file(file: str, app: str):
    """
    For most seed files we just use the builtin Django mechanism to load the data.

    But for some models we create/update the data manually by using get_or_create in
    order to prevent constraint clashes.
    """

    _, app_name_to_use, model_class = parse_info_from_seed_file_name(file, app)

    custom_seed_map = NWON_DJANGO_SEED_SETTINGS.custom_seed_map()
    custom_seed_map_for_model_class = next(
        (seed_map for seed_map in custom_seed_map if seed_map.model == model_class),
        None,
    )
    if custom_seed_map_for_model_class is not None:
        seeds = load_seeds_from_file(file)

        for seed in seeds:
            fields = copy.deepcopy(seed.fields)

            for (
                key_in_seed_file
            ) in custom_seed_map_for_model_class.find_by_keys.values():
                del fields[key_in_seed_file]

            for key in custom_seed_map_for_model_class.exclude_keys or []:
                del fields[key]

            for key in custom_seed_map_for_model_class.relationship_keys or []:
                del fields[key]

            find_by_keys: Dict[str, Any] = {}
            for (
                database_field_name,
                key_in_seed_file,
            ) in custom_seed_map_for_model_class.find_by_keys.items():
                extracted_value = __value_from_seed_file(seed.fields[key_in_seed_file])
                if extracted_value is not None:
                    find_by_keys = {
                        **find_by_keys,
                        database_field_name: extracted_value,
                    }

            transformed_fields = {}
            for key, value in fields.items():
                extracted_value = __value_from_seed_file(value)
                if extracted_value is not None:
                    transformed_fields[key] = extracted_value

            instance = model_class.objects.update_or_create(
                **find_by_keys, defaults={**transformed_fields}
            )[0]

            for key in custom_seed_map_for_model_class.relationship_keys or []:
                relationship = getattr(instance, key)
                if relationship:
                    relationship.add(__value_from_seed_file(fields[key]))
    else:
        call_command(
            "loaddata",
            file,
            app_label=app_name_to_use,
        )


def __value_from_seed_file(value: str | int | List[str | int]):
    if isinstance(value, list) and len(value) > 0:
        return value[0]
    elif isinstance(value, int) or isinstance(value, str):
        return value

    return None
