-- AlterTable
ALTER TABLE "LiteLLM_MCPServerTable" ADD COLUMN     "available_on_public_internet" BOOLEAN NOT NULL DEFAULT false;

