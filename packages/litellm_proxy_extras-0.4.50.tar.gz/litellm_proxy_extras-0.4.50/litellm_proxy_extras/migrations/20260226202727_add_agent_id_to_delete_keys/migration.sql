-- AlterTable
ALTER TABLE "LiteLLM_DeletedVerificationToken" ADD COLUMN     "agent_id" TEXT;

