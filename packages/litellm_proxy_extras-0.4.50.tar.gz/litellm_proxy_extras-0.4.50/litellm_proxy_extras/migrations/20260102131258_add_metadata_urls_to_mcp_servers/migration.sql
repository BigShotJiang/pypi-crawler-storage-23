-- AlterTable
ALTER TABLE "LiteLLM_MCPServerTable" ADD COLUMN     "authorization_url" TEXT,
ADD COLUMN     "registration_url" TEXT,
ADD COLUMN     "token_url" TEXT;

