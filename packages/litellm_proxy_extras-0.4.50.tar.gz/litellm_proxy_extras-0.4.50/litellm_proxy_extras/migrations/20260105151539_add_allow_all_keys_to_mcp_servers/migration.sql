-- AlterTable
ALTER TABLE "LiteLLM_MCPServerTable" ADD COLUMN     "allow_all_keys" BOOLEAN NOT NULL DEFAULT false;

