-- AlterTable
ALTER TABLE "LiteLLM_GuardrailsTable" ADD COLUMN     "team_id" TEXT;

