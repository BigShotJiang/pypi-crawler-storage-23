-- AlterTable
ALTER TABLE "LiteLLM_MCPServerTable" ADD COLUMN     "static_headers" JSONB DEFAULT '{}';
