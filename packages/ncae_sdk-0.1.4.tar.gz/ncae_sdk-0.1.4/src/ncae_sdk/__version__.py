from importlib.metadata import version

__title__ = "ncae-sdk"
__description__ = "Python SDK for Netcloud Automation Engine"
__version__ = version("ncae-sdk")
