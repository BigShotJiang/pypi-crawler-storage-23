from typing import Any

from typing_extensions import TypeAlias

ServiceConfig: TypeAlias = dict[str, Any]
