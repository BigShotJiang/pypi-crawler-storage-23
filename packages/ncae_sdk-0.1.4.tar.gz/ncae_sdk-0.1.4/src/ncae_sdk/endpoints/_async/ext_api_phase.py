from collections.abc import AsyncIterator
from typing import Final, Optional

from typing_extensions import Unpack

from ncae_sdk._async.endpoint import AsyncEndpoint
from ncae_sdk._resource import ResourceId
from ncae_sdk._util import map_async
from ncae_sdk.resources._schema import (
    ExtApiPhase,
    ExtApiPhaseCreate,
    ExtApiPhaseCreateModel,
    ExtApiPhaseFilter,
    ExtApiPhaseFilterModel,
    ExtApiPhaseUpdate,
    ExtApiPhaseUpdateModel,
)


class AsyncExtApiPhaseEndpoint(AsyncEndpoint):
    BASE_PATH: Final[str] = "automation/v1/phase/ext-api-phase"

    async def list(self, **filters: Unpack[ExtApiPhaseFilter]) -> AsyncIterator[ExtApiPhase]:
        results = self._list(self.BASE_PATH, ExtApiPhaseFilterModel, filters)
        return map_async(ExtApiPhase.parse_api, results)

    async def find(self, **filters: Unpack[ExtApiPhaseFilter]) -> Optional[ExtApiPhase]:
        result = await self._get_by_filters(self.BASE_PATH, ExtApiPhaseFilterModel, filters)
        return ExtApiPhase.parse_api(result) if result else None

    async def get(self, rid: ResourceId) -> Optional[ExtApiPhase]:
        result = await self._get_by_id(self.BASE_PATH, rid)
        return ExtApiPhase.parse_api(result) if result else None

    async def create(self, **payload: Unpack[ExtApiPhaseCreate]) -> ExtApiPhase:
        result = await self._create(self.BASE_PATH, ExtApiPhaseCreateModel, payload)
        return ExtApiPhase.parse_api(result)

    async def update(self, rid: ResourceId, /, **payload: Unpack[ExtApiPhaseUpdate]) -> ExtApiPhase:
        result = await self._update(self.BASE_PATH, rid, ExtApiPhaseUpdateModel, payload)
        return ExtApiPhase.parse_api(result)

    async def delete(self, rid: ResourceId) -> bool:
        return await self._delete(self.BASE_PATH, rid)
