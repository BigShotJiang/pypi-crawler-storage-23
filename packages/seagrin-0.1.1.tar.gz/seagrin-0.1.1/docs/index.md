# Seagrin

[![PyPI - Python](https://img.shields.io/pypi/pyversions/Seagrin.svg?logo=Python&label=Python&style=flat-square)](https://pypi.python.org/pypi/Seagrin/)
[![PyPI - Status](https://img.shields.io/pypi/status/Seagrin.svg?logo=Python&label=Status&style=flat-square)](https://pypi.python.org/pypi/Seagrin/)
[![PyPI - Version](https://img.shields.io/pypi/v/Seagrin.svg?logo=Python&label=Version&style=flat-square)](https://pypi.python.org/pypi/Seagrin/)
[![PyPI - License](https://img.shields.io/pypi/l/Seagrin.svg?logo=Python&label=License&style=flat-square)](https://opensource.org/licenses/MIT)

[![pre-commit](https://img.shields.io/badge/pre--commit-enabled-informational?logo=pre-commit&style=flat-square)](https://github.com/pre-commit/pre-commit)
[![Ruff](https://img.shields.io/badge/ruff-enabled-informational?logo=ruff&style=flat-square)](https://github.com/astral-sh/ruff)

[![status-badge](https://ci.codeberg.org/api/badges/16378/status.svg)](https://ci.codeberg.org/repos/16378)
[![Read the Docs](https://img.shields.io/readthedocs/seagrin?label=Read-the-Docs&logo=Read-the-Docs)](https://seagrin.readthedocs.io/en/stable)

A [Python](https://www.python.org/) wrapper for the [Metron API](https://metron.cloud/).

## Installation

```sh
pip install seagrin
```

### Example Usage

```python
from datetime import timedelta

from seagrin.metron import Metron
from seagrin.cache import SQLiteCache, CachePolicy

policy = Cache(percent=0.1, expiry=timedelta(days=14))
# Policy defaults to 10% and 14 days
session = Metron(username="Username", password="Password", cache=SQLiteCache(), policy=policy)

# Get all Marvel comics for the week of 2026-01-19
this_week = session.list_issues(
    params={
        "store_date_range_after": "2026-01-19",
        "store_date_range_before": "2026-01-26",
        "publisher_name": "marvel",
    }
)

# Print the results
for iss in this_week:
    print(f"{iss.id} {iss.issue_name}")

# Retrieve the detail for an individual issue
asm_68 = session.issue(issue_id=31660)

# Print the issue Description
print(asm_68.desc)
```

## Documentation

- [Seagrin](https://seagrin.readthedocs.io/en/stable)
- [Metron API](https://metron.cloud/docs/)

## Bugs/Requests

Please use the [issue tracker](https://codeberg.org/BuriedInCode/Seagrin/issues) to submit bugs or request features.
