# Errors

::: seagrin.errors.AuthenticationError
::: seagrin.errors.RateLimitError
::: seagrin.errors.ServiceError
