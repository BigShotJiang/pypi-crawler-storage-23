# Base

::: seagrin.schemas._base.BaseModel
::: seagrin.schemas._base.BaseResource
