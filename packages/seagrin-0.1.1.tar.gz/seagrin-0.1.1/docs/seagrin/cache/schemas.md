# Schemas

::: seagrin.cache.schemas.EndpointType
::: seagrin.cache.schemas.CachePolicy
::: seagrin.cache.schemas.CacheData
