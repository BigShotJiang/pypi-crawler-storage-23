import os

import pytest

from seagrin.cache import SQLiteCache
from seagrin.metron import Metron


@pytest.fixture(scope="session")
def username() -> str:
    return os.getenv("METRON__USERNAME", "UNSET")


@pytest.fixture(scope="session")
def password() -> str:
    return os.getenv("METRON__PASSWORD", "UNSET")


@pytest.fixture(scope="session")
def session(username: str, password: str) -> Metron:
    return Metron(
        username=username, password=password, cache=SQLiteCache("tests/cache.sqlite"), policy=None
    )
