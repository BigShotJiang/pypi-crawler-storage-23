import pytest
from pytest_httpx import HTTPXMock

from seagrin.errors import ServiceError
from seagrin.metron import Metron


def test_get_publisher(session: Metron) -> None:
    result = session.get_publisher(publisher_id=1)
    assert result.name == "Marvel"
    assert str(result.image) == "https://static.metron.cloud/media/publisher/2018/11/11/marvel.jpg"
    assert result.founded == 1939
    assert result.country == "US"
    assert str(result.resource_url) == "https://metron.cloud/publisher/marvel/"


def test_list_publishers(session: Metron) -> None:
    results = session.list_publishers()
    results_iter = iter(results)
    assert next(results_iter).name == "10 Ton Press"
    assert next(results_iter).name == "12-Gauge Comics"
    assert next(results_iter).name == "AAA Pop Comics"
    assert len(results) == 161
    assert results[2].name == "AAA Pop Comics"


def test_bad_publisher(httpx_mock: HTTPXMock, session: Metron) -> None:
    httpx_mock.add_response(
        url="https://metron.cloud/api/publisher/-1/",
        status_code=404,
        json={"response_code": 404, "detail": "Not found."},
        is_optional=True,
    )
    with pytest.raises(ServiceError):
        session.get_publisher(publisher_id=-1)


def test_bad_publisher_validation(httpx_mock: HTTPXMock, session: Metron) -> None:
    data = {
        "id": 15,
        "name": 150,
        "founded": 1993,
        "desc": "Foo Bar",
        "image": "https://static.metron.cloud/media/publisher/2018/12/02/bongo.png",
        "modified": "2019-06-23T15:13:23.581612-04:00",
    }

    httpx_mock.add_response(
        url="https://metron.cloud/api/publisher/15/", json=data, is_optional=True
    )
    with pytest.raises(ServiceError):
        session.get_publisher(publisher_id=15)
