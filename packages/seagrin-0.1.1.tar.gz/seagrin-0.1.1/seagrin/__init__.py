__all__ = ["__version__", "get_cache_root"]
__version__ = "0.1.1"

import os
from pathlib import Path


def get_cache_root() -> Path:
    """Create and return the path to the cache for Seagrin, supports XDG_CACHE_HOME env.

    Returns:
        The path to the Seagrin cache folder.
    """
    cache_home = os.getenv("XDG_CACHE_HOME", default=str(Path.home() / ".cache"))
    folder = Path(cache_home) / "seagrin"
    folder.mkdir(parents=True, exist_ok=True)
    return folder
