__all__ = ["BaseModel", "BaseResource"]

from datetime import datetime

from pydantic import BaseModel as PydanticModel


class BaseModel(
    PydanticModel,
    populate_by_name=True,
    str_strip_whitespace=True,
    validate_assignment=True,
    revalidate_instances="always",
    extra="ignore",
):
    """Base model for seagrin resources."""


class BaseResource(BaseModel):
    """A data model representing a base resource.

    Attributes:
        id: The unique identifier of the resource.
        name: The name of the resource.
        modified: The datetime when the resource was last modified.
    """

    id: int
    name: str
    modified: datetime
