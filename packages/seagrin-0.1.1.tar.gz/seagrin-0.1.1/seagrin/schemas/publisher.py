__all__ = ["Publisher"]

from typing import Annotated

from pydantic import HttpUrl

from seagrin.schemas._base import BaseResource

COUNTY_CODE_LENGTH = 2


def ensure_country_code_length(value: str) -> str:
    if not value:
        return value
    if len(value) != COUNTY_CODE_LENGTH:
        raise ValueError(f"Country code must be {COUNTY_CODE_LENGTH} characters long.")
    return value.upper()


class Publisher(BaseResource):
    """A data model representing a publisher that extends BaseResource.

    Attributes:
        founded: The year the publisher was founded.
        country: An ISO 3166-1 2-letter country code.
        desc: The description of the publisher.
        image: The image URL of the publisher.
        cv_id: The Comic Vine ID of the publisher.
        gcd_id: The Grand Comics Database ID of the publisher.
        resource_url: The URL of the publisher resource.
    """

    founded: int | None = None
    country: Annotated[str, ensure_country_code_length]
    desc: str
    image: HttpUrl | None = None
    cv_id: int | None = None
    gcd_id: int | None = None
    resource_url: HttpUrl
