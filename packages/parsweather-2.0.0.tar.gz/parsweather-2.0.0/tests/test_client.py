"""Tests for WeatherClient"""

import pytest
import pytest_asyncio
from unittest.mock import patch, AsyncMock, MagicMock

from weather import WeatherClient
from weather.exceptions import CityNotFoundError


@pytest_asyncio.fixture
async def client():
    """Create a WeatherClient instance for testing"""
    async with WeatherClient() as client:
        yield client


@pytest.mark.asyncio
async def test_get_city_key_success(client):
    """Test successful city key retrieval"""
    mock_response = [{"key": "12345"}]
    
    with patch.object(client, "_make_request", new_callable=AsyncMock) as mock_request:
        mock_request.return_value = str(mock_response)  # Mock response
        
        # Mock session.get
        mock_session = AsyncMock()
        mock_resp = AsyncMock()
        mock_resp.status = 200
        mock_resp.json = AsyncMock(return_value=mock_response)
        mock_session.get.return_value.__aenter__.return_value = mock_resp
        client._session = mock_session
        
        result = await client.get_city_key("Tehran")
        assert result == "12345"


@pytest.mark.asyncio
async def test_get_city_key_not_found(client):
    """Test city not found"""
    with patch.object(client, "_make_request", new_callable=AsyncMock) as mock_request:
        mock_request.return_value = "[]"
        
        mock_session = AsyncMock()
        mock_resp = AsyncMock()
        mock_resp.status = 200
        mock_resp.json = AsyncMock(return_value=[])
        mock_session.get.return_value.__aenter__.return_value = mock_resp
        client._session = mock_session
        
        with pytest.raises(CityNotFoundError):
            await client.get_city_key("NonexistentCity")


@pytest.mark.asyncio
async def test_get_current_temperature(client):
    """Test getting current temperature"""
    mock_html = """
    <html>
        <body>
            <div class="temp">25°C</div>
        </body>
    </html>
    """
    
    with patch.object(client, "get_city_key", new_callable=AsyncMock) as mock_key:
        mock_key.return_value = "12345"
        
        with patch.object(client, "get_weather_forecast_url", new_callable=AsyncMock) as mock_url:
            mock_url.return_value = "http://example.com"
            
            with patch.object(client, "_make_request", new_callable=AsyncMock) as mock_request:
                mock_request.return_value = mock_html
                
                result = await client.get_current_temperature("Tehran")
                assert result.current == "25°C"