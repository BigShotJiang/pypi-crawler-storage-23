"""Custom exceptions for the weather library"""

from typing import Optional


class WeatherError(Exception):
    """Base exception for all weather library errors"""
    
    def __init__(self, message: str, original_error: Optional[Exception] = None) -> None:
        self.message = message
        self.original_error = original_error
        super().__init__(message)


class CityNotFoundError(WeatherError):
    """Raised when a city cannot be found"""
    
    def __init__(self, city_name: str) -> None:
        self.city_name = city_name
        super().__init__(f"City '{city_name}' not found")


class ApiError(WeatherError):
    """Raised when the API returns an error response"""
    
    def __init__(self, status_code: int, message: str) -> None:
        self.status_code = status_code
        super().__init__(f"API error {status_code}: {message}")


class ParseError(WeatherError):
    """Raised when parsing HTML data fails"""
    
    def __init__(self, element: str, reason: str) -> None:
        self.element = element
        super().__init__(f"Failed to parse {element}: {reason}")


class RateLimitError(WeatherError):
    """Raised when rate limit is exceeded"""
    
    def __init__(self, retry_after: Optional[int] = None) -> None:
        self.retry_after = retry_after
        message = "Rate limit exceeded"
        if retry_after:
            message += f", retry after {retry_after} seconds"
        super().__init__(message)


class NetworkError(WeatherError):
    """Raised when network communication fails"""
    
    def __init__(self, reason: str) -> None:
        super().__init__(f"Network error: {reason}")


class ConfigError(WeatherError):
    """Raised when there's a configuration error"""
    
    def __init__(self, message: str) -> None:
        super().__init__(f"Configuration error: {message}")