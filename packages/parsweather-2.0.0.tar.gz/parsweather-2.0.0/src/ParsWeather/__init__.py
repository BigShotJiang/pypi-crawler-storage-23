"""
Weather Library - Async client for AccuWeather data
"""

from ParsWeather.client import WeatherClient
from ParsWeather.models import (
    City,
    Temperature,
    AirQuality,
    WeatherForecast,
    PollutantInfo,
    HealthActivity,
    SunTimes,
    WeatherForecastDay
)
from ParsWeather.exceptions import (
    WeatherError,
    CityNotFoundError,
    ApiError,
    ParseError,
    RateLimitError
)

__version__ = "0.1.0"
__all__ = [
    "WeatherClient",
    "City",
    "Temperature",
    "AirQuality",
    "WeatherForecast",
    "PollutantInfo",
    "HealthActivity",
    "SunTimes",
    "WeatherForecastDay",
    "WeatherError",
    "CityNotFoundError",
    "ApiError",
    "ParseError",
    "RateLimitError"
]