"""Utility functions for the weather library"""

import random
import time
from typing import Optional
from urllib.parse import urljoin, urlparse


def add_cache_buster(url: str) -> str:
    """Add cache busting parameter to URL"""
    timestamp = int(time.time())
    random_num = random.randint(1000, 9999)
    separator = "&" if "?" in url else "?"
    return f"{url}{separator}t={timestamp}_{random_num}"


def normalize_url(base_url: str, relative_url: str) -> str:
    """Normalize URL by joining base and relative parts"""
    if relative_url.startswith(("http://", "https://")):
        return relative_url
    return urljoin(base_url, relative_url)


def extract_numeric(text: str) -> Optional[float]:
    """Extract numeric value from text"""
    if not text:
        return None
    try:
        # Remove non-numeric characters except decimal point and minus
        cleaned = "".join(c for c in text if c.isdigit() or c in ".-")
        return float(cleaned)
    except (ValueError, TypeError):
        return None


def safe_get_text(element, default: str = "") -> str:
    """Safely get text from BeautifulSoup element"""
    if element:
        return element.get_text(strip=True)
    return default


def safe_get_attr(element, attr: str, default: str = "") -> str:
    """Safely get attribute from BeautifulSoup element"""
    if element and element.has_attr(attr):
        return element[attr]
    return default


def to_farsi_digits(text: str) -> str:
    """Convert English digits to Farsi digits"""
    if not text:
        return text
    
    english_digits = "0123456789"
    farsi_digits = "۰۱۲۳۴۵۶۷۸۹"
    translation_table = str.maketrans(english_digits, farsi_digits)
    return text.translate(translation_table)


def from_farsi_digits(text: str) -> str:
    """Convert Farsi digits to English digits"""
    if not text:
        return text
    
    farsi_digits = "۰۱۲۳۴۵۶۷۸۹"
    english_digits = "0123456789"
    translation_table = str.maketrans(farsi_digits, english_digits)
    return text.translate(translation_table)