"""Pydantic models for weather data"""

from pydantic import BaseModel, Field
from typing import Optional, Dict, List
from datetime import date, datetime


class City(BaseModel):
    """City information model"""
    
    name: str
    key: str
    country: Optional[str] = None
    full_title: Optional[str] = None


class Temperature(BaseModel):
    """Temperature information model"""
    
    current: Optional[str] = None
    realfeel: Optional[str] = None
    high: Optional[str] = None
    low: Optional[str] = None
    
    @property
    def current_celsius(self) -> Optional[float]:
        """Extract Celsius value from current temperature string"""
        if self.current:
            try:
                return float(self.current.replace("°", "").replace("C", "").strip())
            except (ValueError, AttributeError):
                return None
        return None


class Wind(BaseModel):
    """Wind information model"""
    
    speed: Optional[str] = None
    direction: Optional[str] = None
    
    @property
    def speed_value(self) -> Optional[float]:
        """Extract numeric wind speed value"""
        if self.speed:
            try:
                return float(self.speed.split()[0])
            except (ValueError, IndexError, AttributeError):
                return None
        return None


class AirQuality(BaseModel):
    """Air quality information model"""
    
    index: Optional[str] = None
    unit: Optional[str] = None
    category: Optional[str] = None
    statement: Optional[str] = None
    value: Optional[int] = None


class PollutantInfo(BaseModel):
    """Pollutant information model"""
    
    name: str
    concentration: str
    statement: str


class WeatherForecastDay(BaseModel):
    """Single day weather forecast model"""
    
    date: str
    high_temp: str
    low_temp: str
    condition: Optional[str] = None
    precipitation: Optional[str] = None
    wind_speed: Optional[str] = None
    icon_url: Optional[str] = None


class WeatherForecast(BaseModel):
    """Complete weather forecast model"""
    
    city: City
    current_temperature: Optional[Temperature] = None
    daily_forecast: List[WeatherForecastDay] = Field(default_factory=list)
    air_quality: Optional[AirQuality] = None
    wind: Optional[Wind] = None
    sun_times: Optional[Dict[str, Dict[str, str]]] = None
    health_activities: List[str] = Field(default_factory=list)
    pollutants: Dict[str, PollutantInfo] = Field(default_factory=dict)


class HealthActivity(BaseModel):
    """Health activity information model"""
    
    name: str
    status: str


class SunTimes(BaseModel):
    """Sun and moon times model"""
    
    sunrise: Optional[str] = None
    sunset: Optional[str] = None
    moonrise: Optional[str] = None
    moonset: Optional[str] = None
    moon_phase: Optional[str] = None


class DailyAirQuality(BaseModel):
    """Daily air quality forecast model"""
    
    day_of_week: str
    date: date
    aqi: int