"""Configuration management for the weather library"""

from dataclasses import dataclass
from typing import Optional, Dict, Any
import os


@dataclass(frozen=True)
class WeatherConfig:
    """Immutable configuration for the weather client"""
    
    base_url: str = "https://www.accuweather.com"
    api_url: str = "https://www.accuweather.com/web-api"
    timeout_seconds: int = 10
    max_retries: int = 3
    retry_delay_seconds: int = 1
    user_agent: str = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    
    @classmethod
    def from_env(cls) -> "WeatherConfig":
        """Create configuration from environment variables"""
        return cls(
            timeout_seconds=int(os.getenv("WEATHER_TIMEOUT", "10")),
            max_retries=int(os.getenv("WEATHER_MAX_RETRIES", "3")),
            retry_delay_seconds=int(os.getenv("WEATHER_RETRY_DELAY", "1")),
        )
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert config to dictionary"""
        return {
            "base_url": self.base_url,
            "api_url": self.api_url,
            "timeout_seconds": self.timeout_seconds,
            "max_retries": self.max_retries,
            "retry_delay_seconds": self.retry_delay_seconds,
            "user_agent": self.user_agent,
        }