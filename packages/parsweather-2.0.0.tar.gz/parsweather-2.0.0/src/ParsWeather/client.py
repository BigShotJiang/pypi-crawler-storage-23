"""Async HTTP client for AccuWeather"""

import asyncio
import logging
from typing import Optional, List, Dict, Any, Tuple
from urllib.parse import quote

import aiohttp
from bs4 import BeautifulSoup
from aiohttp import ClientTimeout, ClientResponseError

from ParsWeather.config import WeatherConfig
from ParsWeather.models import (
    City, Temperature, Wind, AirQuality, WeatherForecast,
    WeatherForecastDay, PollutantInfo, SunTimes, HealthActivity
)
from ParsWeather.exceptions import (
    CityNotFoundError, ApiError, ParseError, NetworkError,
    RateLimitError
)
from ParsWeather.utils import (
    add_cache_buster, normalize_url, safe_get_text,
    safe_get_attr, from_farsi_digits
)

logger = logging.getLogger(__name__)


class WeatherClient:
    """Async client for AccuWeather data"""
    
    def __init__(self, config: Optional[WeatherConfig] = None) -> None:
        """
        Initialize weather client
        
        Args:
            config: Optional configuration, uses default if not provided
        """
        self.config = config or WeatherConfig()
        self._session: Optional[aiohttp.ClientSession] = None
        self._headers = {
            "User-Agent": self.config.user_agent,
            "Accept-Language": "en-US,en;q=0.9",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9",
        }
    
    async def __aenter__(self) -> "WeatherClient":
        """Enter async context manager"""
        await self._ensure_session()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Exit async context manager"""
        await self.close()
    
    async def _ensure_session(self) -> None:
        """Ensure aiohttp session exists"""
        if self._session is None or self._session.closed:
            timeout = ClientTimeout(total=self.config.timeout_seconds)
            self._session = aiohttp.ClientSession(
                timeout=timeout,
                headers=self._headers
            )
    
    async def close(self) -> None:
        """Close the HTTP session"""
        if self._session and not self._session.closed:
            await self._session.close()
    
    async def _make_request(
        self, 
        url: str, 
        retry_count: int = 0
    ) -> str:
        """
        Make HTTP request with retry logic
        
        Args:
            url: URL to request
            retry_count: Current retry attempt
            
        Returns:
            Response text
            
        Raises:
            NetworkError: On network issues
            ApiError: On API errors
            RateLimitError: On rate limiting
        """
        await self._ensure_session()
        
        try:
            async with self._session.get(url) as response:
                if response.status == 429:
                    retry_after = int(response.headers.get("Retry-After", "60"))
                    raise RateLimitError(retry_after)
                
                if response.status != 200:
                    raise ApiError(response.status, await response.text())
                
                return await response.text()
                
        except ClientResponseError as e:
            raise ApiError(e.status, str(e))
        except aiohttp.ClientError as e:
            if retry_count < self.config.max_retries:
                await asyncio.sleep(self.config.retry_delay_seconds * (retry_count + 1))
                return await self._make_request(url, retry_count + 1)
            raise NetworkError(str(e))
    
    async def get_city_key(self, city_name: str) -> str:
        """
        Get city key from AccuWeather autocomplete API
        
        Args:
            city_name: Name of the city
            
        Returns:
            City key
            
        Raises:
            CityNotFoundError: If city not found
            ApiError: On API error
        """
        url = f"{self.config.api_url}/autocomplete?query={quote(city_name)}&language=en-us"
        
        try:
            response_text = await self._make_request(url)
            data = await self._session.get(url)  # Re-fetch for JSON
            async with data as resp:
                if resp.status != 200:
                    raise ApiError(resp.status, await resp.text())
                
                json_data = await resp.json()
                
                if not json_data or not isinstance(json_data, list):
                    raise CityNotFoundError(city_name)
                
                if "key" not in json_data[0]:
                    raise CityNotFoundError(city_name)
                
                return json_data[0]["key"]
                
        except aiohttp.ClientError as e:
            raise NetworkError(str(e))
    
    async def _get_redirected_url(self, city_key: str, path_type: str = "weather-forecast") -> str:
        """
        Get redirected URL for specific path type
        
        Args:
            city_key: City key
            path_type: Type of path (weather-forecast, air-quality-index, etc.)
            
        Returns:
            Redirected URL
        """
        url = f"{self.config.api_url}/three-day-redirect?key={city_key}&postalCode="
        
        async with self._session.get(url, allow_redirects=True) as response:
            redirected_url = str(response.url)
            
            # Convert to Farsi version
            translated_url = redirected_url.replace("/en/", "/fa/")
            
            if path_type != "weather-forecast":
                translated_url = translated_url.replace(
                    "/weather-forecast/", 
                    f"/{path_type}/"
                )
            
            return translated_url
    
    async def get_weather_forecast_url(self, city_key: str) -> str:
        """Get weather forecast URL for city"""
        return await self._get_redirected_url(city_key, "weather-forecast")
    
    async def get_air_quality_url(self, city_key: str) -> str:
        """Get air quality URL for city"""
        return await self._get_redirected_url(city_key, "air-quality-index")
    
    async def get_health_activities_url(self, city_key: str) -> str:
        """Get health activities URL for city"""
        return await self._get_redirected_url(city_key, "health-activities")
    
    async def get_daily_weather_url(self, city_key: str) -> str:
        """Get daily weather URL for city"""
        return await self._get_redirected_url(city_key, "daily-weather-forecast")
    
    async def get_current_temperature(self, city_name: str) -> Temperature:
        """
        Get current temperature for a city
        
        Args:
            city_name: Name of the city
            
        Returns:
            Temperature object
            
        Raises:
            CityNotFoundError: If city not found
            ParseError: If data parsing fails
        """
        city_key = await self.get_city_key(city_name)
        url = await self.get_weather_forecast_url(city_key)
        
        html = await self._make_request(url)
        soup = BeautifulSoup(html, "lxml")
        
        temp_element = soup.find(class_="temp")
        if not temp_element:
            raise ParseError("temperature", "Temperature element not found")
        
        current_temp = safe_get_text(temp_element)
        
        return Temperature(current=current_temp)
    
    async def get_realfeel(self, city_name: str) -> Optional[str]:
        """
        Get RealFeel temperature for a city
        
        Args:
            city_name: Name of the city
            
        Returns:
            RealFeel temperature string or None
        """
        city_key = await self.get_city_key(city_name)
        url = await self.get_weather_forecast_url(city_key)
        
        html = await self._make_request(url)
        soup = BeautifulSoup(html, "lxml")
        
        realfeel_div = soup.find("div", class_="real-feel")
        if realfeel_div:
            realfeel_text = realfeel_div.get_text(strip=True)
            return realfeel_text.replace("RealFeel®", "").strip()
        
        return None
    
    async def get_wind(self, city_name: str) -> Optional[Wind]:
        """
        Get wind information for a city
        
        Args:
            city_name: Name of the city
            
        Returns:
            Wind object or None
        """
        city_key = await self.get_city_key(city_name)
        url = await self.get_weather_forecast_url(city_key)
        
        html = await self._make_request(url)
        soup = BeautifulSoup(html, "lxml")
        
        wind_label = soup.find("span", class_="label", string="باد")
        if wind_label:
            value_tag = wind_label.find_next("span", class_="value")
            if value_tag:
                wind_speed = safe_get_text(value_tag)
                return Wind(speed=wind_speed)
        
        return None
    
    async def get_air_quality(self, city_name: str) -> Optional[AirQuality]:
        """
        Get air quality information for a city
        
        Args:
            city_name: Name of the city
            
        Returns:
            AirQuality object or None
        """
        city_key = await self.get_city_key(city_name)
        url = await self.get_weather_forecast_url(city_key)
        
        html = await self._make_request(url)
        soup = BeautifulSoup(html, "lxml")
        
        air_quality_label = soup.find("span", class_="label", string="کیفیت هوا")
        if air_quality_label:
            value_tag = air_quality_label.find_next("span", class_="value")
            if value_tag:
                value = safe_get_text(value_tag)
                return AirQuality(statement=value)
        
        return None
    
    async def get_radar_image_url(self, city_name: str) -> Optional[str]:
        """
        Get radar image URL for a city
        
        Args:
            city_name: Name of the city
            
        Returns:
            Radar image URL or None
        """
        city_key = await self.get_city_key(city_name)
        url = await self.get_weather_forecast_url(city_key)
        
        html = await self._make_request(url)
        soup = BeautifulSoup(html, "lxml")
        
        radar_link = soup.find("a", class_="base-map-cta card static-radar-map-recommended")
        if radar_link:
            img_tag = radar_link.find("img")
            if img_tag:
                image_url = safe_get_attr(img_tag, "data-src")
                if image_url:
                    return add_cache_buster(image_url)
        
        return None
    
    async def get_sun_times(self, city_name: str) -> Dict[str, Dict[str, str]]:
        """
        Get sun and moon times for a city
        
        Args:
            city_name: Name of the city
            
        Returns:
            Dictionary of sun/moon times
        """
        city_key = await self.get_city_key(city_name)
        url = await self.get_weather_forecast_url(city_key)
        
        html = await self._make_request(url)
        soup = BeautifulSoup(html, "lxml")
        
        items = soup.find_all("div", class_="sunrise-sunset__item")
        sun_times = {}
        
        for item in items:
            phrase_elem = item.find("span", class_="sunrise-sunset__phrase")
            if not phrase_elem:
                continue
                
            phrase = safe_get_text(phrase_elem)
            
            if "ساعت" in phrase:
                times_div = item.find("div", class_="sunrise-sunset__times")
                if times_div:
                    time_items = times_div.find_all("div", class_="sunrise-sunset__times-item")
                    time_dict = {}
                    
                    for time_item in time_items:
                        label_elem = time_item.find("span", class_="sunrise-sunset__times-label")
                        value_elem = time_item.find("span", class_="sunrise-sunset__times-value")
                        
                        if label_elem and value_elem:
                            label = safe_get_text(label_elem)
                            value = safe_get_text(value_elem)
                            time_dict[label] = value
                    
                    sun_times[phrase] = time_dict
        
        return sun_times
    
    async def get_weather_forecast(self, city_name: str) -> List[WeatherForecastDay]:
        """
        Get multi-day weather forecast for a city
        
        Args:
            city_name: Name of the city
            
        Returns:
            List of WeatherForecastDay objects
        """
        city_key = await self.get_city_key(city_name)
        url = await self.get_weather_forecast_url(city_key)
        
        html = await self._make_request(url)
        soup = BeautifulSoup(html, "lxml")
        
        daily_list = soup.find("div", class_="daily-list content-module")
        if not daily_list:
            return []
        
        daily_items = daily_list.find_all("a", class_="daily-list-item")
        forecast_data = []
        
        for item in daily_items:
            date_elem = item.find("div", class_="date")
            temp_hi_elem = item.find("span", class_="temp-hi")
            temp_lo_elem = item.find("span", class_="temp-lo")
            icon_elem = item.find("img", class_="icon")
            
            date = safe_get_text(date_elem) if date_elem else ""
            temp_hi = safe_get_text(temp_hi_elem) if temp_hi_elem else ""
            temp_lo = safe_get_text(temp_lo_elem) if temp_lo_elem else ""
            icon_url = safe_get_attr(icon_elem, "src") if icon_elem else ""
            
            forecast_data.append(
                WeatherForecastDay(
                    date=date,
                    high_temp=temp_hi,
                    low_temp=temp_lo,
                    icon_url=icon_url
                )
            )
        
        return forecast_data
    
    async def get_health_activities(self, city_name: str) -> List[str]:
        """
        Get health activities information for a city
        
        Args:
            city_name: Name of the city
            
        Returns:
            List of health activity strings
        """
        city_key = await self.get_city_key(city_name)
        url = await self.get_health_activities_url(city_key)
        
        html = await self._make_request(url)
        soup = BeautifulSoup(html, "lxml")
        
        health_cards = soup.find_all("a", class_="index-list-card")
        if not health_cards:
            return []
        
        results = []
        for card in health_cards:
            title_tag = card.find("div", class_="index-name")
            status_tag = card.find("div", class_="index-status-text")
            
            if title_tag and status_tag:
                title = safe_get_text(title_tag)
                status = safe_get_text(status_tag)
                results.append(f"{title}: {status}")
        
        return results
    
    async def get_air_quality_detailed(self, city_name: str) -> Tuple[Optional[AirQuality], Dict[str, PollutantInfo]]:
        """
        Get detailed air quality information including pollutants
        
        Args:
            city_name: Name of the city
            
        Returns:
            Tuple of (AirQuality object, dict of pollutant info)
        """
        city_key = await self.get_city_key(city_name)
        url = await self.get_air_quality_url(city_key)
        
        html = await self._make_request(url)
        soup = BeautifulSoup(html, "lxml")
        
        # Get main AQI
        air_quality_div = soup.find("div", class_="aq-number-wrapper")
        air_quality_details = soup.find("h3", class_="air-quality-data")
        
        air_quality = None
        if air_quality_div and air_quality_details:
            aq_value = air_quality_div.find("div", class_="aq-number")
            aq_unit = air_quality_div.find("div", class_="aq-unit")
            category_text = air_quality_details.find("p", class_="category-text")
            statement = air_quality_details.find("p", class_="statement")
            
            air_quality = AirQuality(
                index=safe_get_text(aq_value) if aq_value else None,
                unit=safe_get_text(aq_unit) if aq_unit else None,
                category=safe_get_text(category_text) if category_text else None,
                statement=safe_get_text(statement) if statement else None
            )
        
        # Get pollutants
        pollutants = {}
        pollutant_divs = soup.find_all("div", class_="air-quality-pollutant")
        
        for pollutant in pollutant_divs:
            name_elem = pollutant.find("h3")
            concentration_elem = pollutant.find("div", class_="pollutant-concentration")
            statement_elem = pollutant.find("div", class_="statement")
            
            if name_elem and concentration_elem:
                name = safe_get_text(name_elem)
                concentration = safe_get_text(concentration_elem)
                statement = safe_get_text(statement_elem) if statement_elem else ""
                
                pollutants[name] = PollutantInfo(
                    name=name,
                    concentration=concentration,
                    statement=statement
                )
        
        return air_quality, pollutants
    
    async def get_daily_weather_info(self, city_name: str, target_date: str) -> Optional[WeatherForecastDay]:
        """
        Get weather information for a specific date
        
        Args:
            city_name: Name of the city
            target_date: Target date string
            
        Returns:
            WeatherForecastDay object or None
        """
        city_key = await self.get_city_key(city_name)
        url = await self.get_daily_weather_url(city_key)
        
        html = await self._make_request(url)
        soup = BeautifulSoup(html, "lxml")
        
        daily_cards = soup.find_all("div", class_="daily-wrapper")
        
        for card in daily_cards:
            date_element = card.find("span", class_="module-header sub date")
            if date_element and safe_get_text(date_element) == target_date:
                high_temp = card.find("span", class_="high")
                low_temp = card.find("span", class_="low")
                precip = card.find("div", class_="precip")
                condition = card.find("div", class_="phrase")
                
                wind_speed = None
                panel_items = card.find_all("p", class_="panel-item")
                for item in panel_items:
                    if "باد" in safe_get_text(item):
                        wind_speed = safe_get_text(item).replace("باد", "").strip()
                        break
                
                return WeatherForecastDay(
                    date=target_date,
                    high_temp=safe_get_text(high_temp) if high_temp else "",
                    low_temp=safe_get_text(low_temp) if low_temp else "",
                    condition=safe_get_text(condition) if condition else "",
                    precipitation=safe_get_text(precip) if precip else "",
                    wind_speed=wind_speed
                )
        
        return None
    
    async def get_title(self, city_name: str) -> Optional[str]:
        """
        Get page title for city weather page
        
        Args:
            city_name: Name of the city
            
        Returns:
            Page title or None
        """
        city_key = await self.get_city_key(city_name)
        url = await self.get_weather_forecast_url(city_key)
        
        html = await self._make_request(url)
        soup = BeautifulSoup(html, "lxml")
        
        title = soup.find("title")
        return safe_get_text(title) if title else None
    
    async def get_forecast_summary(self, city_name: str) -> Tuple[str, str]:
        """
        Get weather forecast summary
        
        Args:
            city_name: Name of the city
            
        Returns:
            Tuple of (title, description)
        """
        city_key = await self.get_city_key(city_name)
        url = await self.get_weather_forecast_url(city_key)
        
        html = await self._make_request(url)
        soup = BeautifulSoup(html, "lxml")
        
        forecast_link = soup.find("a", class_="local-forecast-summary")
        
        if forecast_link:
            title_elem = forecast_link.find("h2")
            desc_elem = forecast_link.find("p")
            
            title = safe_get_text(title_elem) if title_elem else "عنوان پیدا نشد"
            description = safe_get_text(desc_elem) if desc_elem else "توضیح پیدا نشد"
            
            return title, description
        
        return "خبر ندارم", ""
    
    async def get_complete_forecast(self, city_name: str) -> WeatherForecast:
        """
        Get complete weather forecast for a city
        
        Args:
            city_name: Name of the city
            
        Returns:
            Complete WeatherForecast object
        """
        # Get city key
        city_key = await self.get_city_key(city_name)
        
        # Create city object
        city = City(name=city_name, key=city_key)
        
        # Get all data concurrently
        temperature_task = self.get_current_temperature(city_name)
        realfeel_task = self.get_realfeel(city_name)
        wind_task = self.get_wind(city_name)
        air_quality_task = self.get_air_quality(city_name)
        forecast_task = self.get_weather_forecast(city_name)
        sun_times_task = self.get_sun_times(city_name)
        health_activities_task = self.get_health_activities(city_name)
        air_quality_detailed_task = self.get_air_quality_detailed(city_name)
        
        # Gather results
        results = await asyncio.gather(
            temperature_task,
            realfeel_task,
            wind_task,
            air_quality_task,
            forecast_task,
            sun_times_task,
            health_activities_task,
            air_quality_detailed_task,
            return_exceptions=True
        )
        
        # Process results
        temperature = results[0] if not isinstance(results[0], Exception) else Temperature()
        realfeel = results[1] if not isinstance(results[1], Exception) else None
        wind = results[2] if not isinstance(results[2], Exception) else None
        air_quality = results[3] if not isinstance(results[3], Exception) else None
        daily_forecast = results[4] if not isinstance(results[4], Exception) else []
        sun_times = results[5] if not isinstance(results[5], Exception) else {}
        health_activities = results[6] if not isinstance(results[6], Exception) else []
        air_quality_detailed = results[7] if not isinstance(results[7], Exception) else (None, {})
        
        # Update temperature with realfeel
        if realfeel and not isinstance(temperature, Exception):
            temperature.realfeel = realfeel
        
        # Get detailed air quality
        detailed_aq, pollutants = air_quality_detailed if not isinstance(air_quality_detailed, Exception) else (None, {})
        
        # Create final forecast object
        forecast = WeatherForecast(
            city=city,
            current_temperature=temperature if not isinstance(temperature, Exception) else None,
            daily_forecast=daily_forecast,
            air_quality=detailed_aq or air_quality,
            wind=wind,
            sun_times=sun_times,
            health_activities=health_activities,
            pollutants=pollutants
        )
        
        return forecast
    
    async def get_satellite_image(self) -> Optional[str]:
        """
        Get animated satellite image URL
        
        Returns:
            Satellite image URL or None
        """
        url = "https://www.havajanah.ir/"
        
        html = await self._make_request(url)
        soup = BeautifulSoup(html, "lxml")
        
        img_tag = soup.find("img", alt="تصویر ماهواره ای متحرک")
        if img_tag and img_tag.has_attr("src"):
            return normalize_url(url, img_tag["src"])
        
        return None
    
    async def get_earth_satellite_image(self) -> Optional[str]:
        """
        Get Earth satellite image URL
        
        Returns:
            Earth satellite image URL or None
        """
        url = "https://www.havajanah.ir/sat-pic/%d8%aa%d8%b5%d9%88%db%8c%d8%b1-%d8%a8%d8%a7%da%a9%db%8c%d9%81%db%8c%d8%aa-%d9%88-%d9%88%d8%a7%d9%82%d8%b9%db%8c-%da%a9%d8%b1%d9%87-%d8%b2%d9%85%db%8c%d9%86/"
        
        html = await self._make_request(url)
        soup = BeautifulSoup(html, "lxml")
        
        image_div = soup.find("div", class_="wp-caption aligncenter")
        if image_div:
            image_tag = image_div.find("img")
            if image_tag and image_tag.has_attr("src"):
                return image_tag["src"]
        
        return None