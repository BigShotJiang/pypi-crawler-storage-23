"""Framework adapters for automatic trace capture."""

from .base import BaseAdapter

__all__ = ["BaseAdapter"]
