//! SAV/ZSAV file writer.
//!
//! Writes Arrow RecordBatch + SpssMetadata to SPSS .sav/.zsav binary format.
//! Supports uncompressed, bytecode-compressed (.sav), and zlib-compressed (.zsav) output.

use std::collections::HashSet;
use std::fs::File;
use std::io::{BufWriter, Seek, SeekFrom, Write};
use std::path::Path;

use arrow::array::{
    Array, BooleanArray, Date32Array, DurationMicrosecondArray, Float64Array, Int16Array,
    Int32Array, Int64Array, Int8Array, LargeStringArray, StringViewArray,
    TimestampMicrosecondArray,
};
use arrow::datatypes::{DataType, TimeUnit};
use arrow::record_batch::RecordBatch;
use indexmap::IndexMap;

use crate::compression::bytecode_encoder::BytecodeEncoder;
use crate::constants::*;
use crate::error::{Result, SpssError};
use crate::io_utils::{self, SavWriteExt};
use crate::metadata::{specs_to_missing, MissingSpec, MrType, SpssMetadata, Value};
use crate::variable::MissingValues;

// ---------------------------------------------------------------------------
// Internal layout types
// ---------------------------------------------------------------------------

/// Write descriptor for one visible variable.
struct WriteVariable {
    long_name: String,
    short_name: String,
    format: SpssFormat,
    var_type: VarType,
    label: Option<String>,
    #[allow(dead_code)]
    missing_values: MissingValues,
    measure: Measure,
    alignment: Alignment,
    display_width: u32,
    /// Number of 8-byte slots this variable occupies (single segment).
    n_slots: usize,
    /// For VLS (width > 255): number of segments.
    n_segments: usize,
    /// Total storage width in bytes (may exceed 255 for VLS).
    storage_width: usize,
    /// Index of this variable in the RecordBatch columns.
    col_index: usize,
}

/// A single Type-2 record to emit (may be a primary, ghost, or segment record).
struct SlotRecord {
    raw_type: i32,
    short_name: String,
    label: Option<Vec<u8>>,
    print_format: SpssFormat,
    write_format: SpssFormat,
    missing_values: MissingValues,
    /// True if this is a continuation/ghost record (raw_type = -1).
    is_ghost: bool,
}

/// Pre-computed layout of the entire file.
struct CaseLayout {
    /// Visible variable descriptors (one per Arrow column).
    write_vars: Vec<WriteVariable>,
    /// All Type-2 records to emit (including ghosts and segments).
    slot_records: Vec<SlotRecord>,
    /// Total 8-byte slots per case.
    slots_per_row: usize,
    /// Short→long name mappings for subtype 13.
    short_to_long: IndexMap<String, String>,
    /// VLS declarations for subtype 14: (short_name, true_width).
    very_long_strings: Vec<(String, usize)>,
}

// ---------------------------------------------------------------------------
// Short name generation
// ---------------------------------------------------------------------------

/// Generate a unique 8-char short name from a long name.
fn generate_short_name(long_name: &str, used: &mut HashSet<String>) -> String {
    // Convert to uppercase ASCII, replace non-alnum with '_'
    let clean: String = long_name
        .chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() || c == '_' {
                c.to_ascii_uppercase()
            } else {
                '_'
            }
        })
        .collect();

    // Ensure starts with a letter
    let clean = if clean.is_empty() || !clean.chars().next().unwrap().is_ascii_alphabetic() {
        format!("V{clean}")
    } else {
        clean
    };

    // Try truncated name first
    let candidate = if clean.len() <= 8 {
        clean.clone()
    } else {
        clean[..8].to_string()
    };

    if !used.contains(&candidate) {
        used.insert(candidate.clone());
        return candidate;
    }

    // Collision: try stem + numeric suffix
    for i in 0..10000 {
        let suffix = format!("{i}");
        let stem_len = 8 - suffix.len();
        let stem = &clean[..stem_len.min(clean.len())];
        let candidate = format!("{stem}{suffix}");
        if !used.contains(&candidate) {
            used.insert(candidate.clone());
            return candidate;
        }
    }
    panic!("exhausted short name space");
}

/// Generate segment short names for VLS (segments 1+).
fn generate_segment_names(
    primary_short: &str,
    n_segments: usize,
    used: &mut HashSet<String>,
) -> Vec<String> {
    let mut names = Vec::new();
    let stem5 = &primary_short[..5.min(primary_short.len())];
    for i in 1..n_segments {
        // Try stem + 3-digit segment index (readstat convention)
        let suffix = format!("{i:03}");
        let stem_len = (8 - suffix.len()).min(primary_short.len());
        let candidate = format!("{}{suffix}", &primary_short[..stem_len]);
        let mut final_name = candidate;
        // If collision, use incrementing counter to guarantee termination
        let mut counter = 0u32;
        while used.contains(&final_name) {
            counter += 1;
            let num = format!("{counter}");
            let stem_len = (8 - num.len()).min(stem5.len());
            final_name = format!("{}{num}", &stem5[..stem_len]);
        }
        used.insert(final_name.clone());
        names.push(final_name);
    }
    names
}

// ---------------------------------------------------------------------------
// Layout computation
// ---------------------------------------------------------------------------

fn compute_layout(batch: &RecordBatch, meta: &SpssMetadata) -> Result<CaseLayout> {
    let schema = batch.schema();
    let mut write_vars = Vec::new();
    let mut slot_records = Vec::new();
    let mut used_short_names = HashSet::new();
    let mut short_to_long = IndexMap::new();
    let mut very_long_strings = Vec::new();
    let mut slot_index = 0;

    for (col_index, field) in schema.fields().iter().enumerate() {
        let name = field.name();

        // Resolve format from metadata or infer from Arrow type
        let format = meta
            .variable_formats
            .get(name.as_str())
            .and_then(|s| SpssFormat::from_string(s))
            .unwrap_or_else(|| infer_format(field.data_type()));

        // Determine variable type and storage width.
        // Use the format string's declared width (not storage_width) to decide VLS vs non-VLS,
        // because storage_width is 8-byte rounded (e.g., 254 → 256) and would falsely trigger VLS.
        // For true VLS (format width > 255), use storage_width from metadata.
        let (var_type, storage_width) = if format.format_type.is_string() {
            // Parse the original format string for the declared width (not u8-capped).
            // E.g., "A254" → 254 (non-VLS), "A2000" → 2000 (VLS).
            let declared_width = meta
                .variable_formats
                .get(name.as_str())
                .and_then(|s| {
                    let rest = s.trim_start_matches(|c: char| !c.is_ascii_digit());
                    rest.split('.').next().and_then(|w| w.parse::<usize>().ok())
                })
                .unwrap_or(format.width as usize)
                .max(1);

            if declared_width > 255 {
                // True VLS: use storage_width from metadata for the actual byte count
                let w = meta
                    .variable_storage_widths
                    .get(name.as_str())
                    .copied()
                    .unwrap_or(declared_width);
                (VarType::String(w), w)
            } else {
                // Non-VLS: use format's declared width
                (VarType::String(declared_width), declared_width)
            }
        } else {
            (VarType::Numeric, 8)
        };

        // Compute segments for VLS (255 useful bytes per segment)
        let n_segments = match &var_type {
            VarType::String(width) if *width > 255 => (*width + 251) / 252,
            _ => 1,
        };

        // Slots per segment
        let n_slots = match &var_type {
            VarType::Numeric => 1,
            VarType::String(width) => {
                if n_segments > 1 {
                    // VLS: each segment is 255 bytes = ceil(255/8) = 32 slots
                    32
                } else {
                    (width + 7) / 8
                }
            }
        };

        let label = meta.variable_labels.get(name.as_str()).cloned();
        let missing_values = meta
            .variable_missing_values
            .get(name.as_str())
            .map(|specs| {
                // Validate missing value type matches variable type
                let is_string_var = matches!(var_type, VarType::String(_));
                let has_numeric = specs.iter().any(|s| {
                    matches!(s, MissingSpec::Value(_) | MissingSpec::Range { .. })
                });
                let has_string = specs.iter().any(|s| matches!(s, MissingSpec::StringValue(_)));
                if is_string_var && has_numeric {
                    return Err(SpssError::WriteError(format!(
                        "variable '{}': numeric missing values cannot be applied to a string variable",
                        name
                    )));
                }
                if !is_string_var && has_string {
                    return Err(SpssError::WriteError(format!(
                        "variable '{}': string missing values cannot be applied to a numeric variable",
                        name
                    )));
                }
                Ok(specs_to_missing(specs))
            })
            .transpose()?
            .unwrap_or(MissingValues::None);
        let measure = meta
            .variable_measures
            .get(name.as_str())
            .copied()
            .unwrap_or(Measure::Unknown);
        let alignment = meta
            .variable_alignments
            .get(name.as_str())
            .copied()
            .unwrap_or(Alignment::Right);
        let display_width = meta
            .variable_display_widths
            .get(name.as_str())
            .copied()
            .unwrap_or(format.width as u32);

        // Generate short name for this variable
        let short_name = generate_short_name(name, &mut used_short_names);
        short_to_long.insert(short_name.clone(), name.clone());

        // VLS subtype 14 declaration
        if n_segments > 1 {
            very_long_strings.push((short_name.clone(), storage_width));
        }

        // Build WriteVariable
        write_vars.push(WriteVariable {
            long_name: name.clone(),
            short_name: short_name.clone(),
            format: format.clone(),
            var_type: var_type.clone(),
            label,
            missing_values: missing_values.clone(),
            measure,
            alignment,
            display_width,
            n_slots,
            n_segments,
            storage_width,
            col_index,
        });

        // Emit slot records for this variable
        if n_segments == 1 {
            // Simple variable: one type-2 record
            let raw_type = match &var_type {
                VarType::Numeric => 0,
                VarType::String(w) => (*w).min(255) as i32,
            };
            slot_records.push(SlotRecord {
                raw_type,
                short_name: short_name.clone(),
                label: write_vars.last().unwrap().label.as_ref().map(|s| s.as_bytes().to_vec()),
                print_format: format.clone(),
                write_format: format.clone(),
                // Strings > 8 bytes: missing values go in subtype 22 only, not type-2 record
                missing_values: if matches!(&var_type, VarType::String(w) if *w > 8) {
                    MissingValues::None
                } else {
                    missing_values.clone()
                },
                is_ghost: false,
            });
            slot_index += 1;

            // String continuation ghosts (for width > 8)
            if let VarType::String(width) = &var_type {
                let extra_slots = n_slots - 1;
                for _ in 0..extra_slots {
                    slot_records.push(SlotRecord {
                        raw_type: -1,
                        short_name: String::new(),
                        label: None,
                        print_format: SpssFormat {
                            format_type: FormatType::A,
                            width: 0,
                            decimals: 0,
                        },
                        write_format: SpssFormat {
                            format_type: FormatType::A,
                            width: 0,
                            decimals: 0,
                        },
                        missing_values: MissingValues::None,
                        is_ghost: true,
                    });
                    slot_index += 1;
                }
                let _ = width; // suppress unused
            }
        } else {
            // VLS: n_segments segments, each with 32 slots (255 bytes + 1 padding)
            let segment_names =
                generate_segment_names(&short_name, n_segments, &mut used_short_names);

            for seg in 0..n_segments {
                let seg_short_name = if seg == 0 {
                    short_name.clone()
                } else {
                    let seg_name = segment_names[seg - 1].clone();
                    seg_name
                };

                // Each segment declares width=255 in its type-2 record
                let seg_format = SpssFormat {
                    format_type: FormatType::A,
                    width: 255,
                    decimals: 0,
                };

                // Primary segment gets label; others don't.
                // VLS strings (width > 8): missing values go in subtype 22 only.
                let (seg_label, seg_missing) = if seg == 0 {
                    (
                        write_vars.last().unwrap().label.as_ref().map(|s| s.as_bytes().to_vec()),
                        MissingValues::None,
                    )
                } else {
                    (None, MissingValues::None)
                };

                // Primary record for this segment
                slot_records.push(SlotRecord {
                    raw_type: 255,
                    short_name: seg_short_name,
                    label: seg_label,
                    print_format: seg_format.clone(),
                    write_format: seg_format,
                    missing_values: seg_missing,
                    is_ghost: false,
                });
                slot_index += 1;

                // 31 ghost records per segment (32 slots total: 1 named + 31 ghosts)
                for _ in 0..31 {
                    slot_records.push(SlotRecord {
                        raw_type: -1,
                        short_name: String::new(),
                        label: None,
                        print_format: SpssFormat {
                            format_type: FormatType::A,
                            width: 0,
                            decimals: 0,
                        },
                        write_format: SpssFormat {
                            format_type: FormatType::A,
                            width: 0,
                            decimals: 0,
                        },
                        missing_values: MissingValues::None,
                        is_ghost: true,
                    });
                    slot_index += 1;
                }
            }
        }
    }

    Ok(CaseLayout {
        write_vars,
        slot_records,
        slots_per_row: slot_index,
        short_to_long,
        very_long_strings,
    })
}

fn infer_format(dt: &DataType) -> SpssFormat {
    match dt {
        DataType::Float64 | DataType::Int64 | DataType::Int32 | DataType::Int16 | DataType::Int8 => {
            SpssFormat {
                format_type: FormatType::F,
                width: 8,
                decimals: 2,
            }
        }
        DataType::Boolean => SpssFormat {
            format_type: FormatType::F,
            width: 1,
            decimals: 0,
        },
        DataType::Date32 => SpssFormat {
            format_type: FormatType::Date,
            width: 11,
            decimals: 0,
        },
        DataType::Timestamp(TimeUnit::Microsecond, _) => SpssFormat {
            format_type: FormatType::DateTime,
            width: 23,
            decimals: 2,
        },
        DataType::Duration(TimeUnit::Microsecond) => SpssFormat {
            format_type: FormatType::Time,
            width: 11,
            decimals: 2,
        },
        DataType::Utf8 | DataType::Utf8View | DataType::LargeUtf8 => SpssFormat {
            format_type: FormatType::A,
            width: 255,
            decimals: 0,
        },
        _ => SpssFormat {
            format_type: FormatType::F,
            width: 8,
            decimals: 2,
        },
    }
}

// ---------------------------------------------------------------------------
// Dictionary writers
// ---------------------------------------------------------------------------

fn write_header<W: Write>(
    w: &mut W,
    layout: &CaseLayout,
    meta: &SpssMetadata,
    compression: Compression,
    nrows: i32,
) -> Result<()> {
    // Magic: "$FL2" for sav, "$FL3" for zsav
    let magic = if compression == Compression::Zlib {
        b"$FL3"
    } else {
        b"$FL2"
    };
    w.write_all(magic)?;

    // Product name (60 bytes, space-padded)
    let product = format!("@(#) SPSS DATA FILE ambers {}", env!("CARGO_PKG_VERSION"));
    w.write_fixed_string(&product, 60)?;

    // Layout code (2 = little-endian)
    w.write_i32_le(2)?;

    // Nominal case size (total slots per row)
    w.write_i32_le(layout.slots_per_row as i32)?;

    // Compression
    w.write_i32_le(compression.to_i32())?;

    // Weight index (0 = no weight, else 1-based slot index)
    let weight_index = meta
        .weight_variable
        .as_ref()
        .and_then(|wv| {
            layout
                .write_vars
                .iter()
                .scan(0usize, |slot, var| {
                    let this_slot = *slot;
                    *slot += var.n_slots * var.n_segments;
                    Some((var, this_slot))
                })
                .find(|(v, _)| v.long_name == *wv)
                .map(|(_, slot)| (slot + 1) as i32) // 1-based
        })
        .unwrap_or(0);
    w.write_i32_le(weight_index)?;

    // Number of cases
    w.write_i32_le(nrows)?;

    // Bias
    w.write_f64_le(DEFAULT_BIAS)?;

    // SPSS header: date (9 bytes "DD MMM YY") + time (8 bytes "HH:MM:SS").
    // meta.creation_time is now a full datetime like "2026-02-21 12:38:47".
    // Preserve on roundtrip; use current UTC for new files.
    let (date_now, time_now) = current_date_time();
    if let Some((date_part, time_part)) =
        crate::metadata::parse_iso_to_spss_parts(&meta.creation_time)
    {
        w.write_fixed_string(&date_part, 9)?;
        w.write_fixed_string(&time_part, 8)?;
    } else {
        w.write_fixed_string(&date_now, 9)?;
        w.write_fixed_string(&time_now, 8)?;
    }

    // File label (64 bytes, space-padded)
    w.write_fixed_string(&meta.file_label, 64)?;

    // Padding (3 bytes)
    w.write_zero_padding(3)?;

    Ok(())
}

fn write_variable_records<W: Write>(w: &mut W, layout: &CaseLayout) -> Result<()> {
    for rec in &layout.slot_records {
        // Record type = 2
        w.write_i32_le(RECORD_TYPE_VARIABLE)?;

        // Raw type
        w.write_i32_le(rec.raw_type)?;

        // Has variable label
        let has_label = if rec.label.is_some() && !rec.is_ghost { 1 } else { 0 };
        w.write_i32_le(has_label)?;

        // Number of missing values
        let n_missing = missing_count(&rec.missing_values);
        w.write_i32_le(n_missing)?;

        // Print format and write format
        if rec.is_ghost {
            w.write_i32_le(0)?;
            w.write_i32_le(0)?;
        } else {
            w.write_i32_le(rec.print_format.to_packed())?;
            w.write_i32_le(rec.write_format.to_packed())?;
        }

        // Short name (8 bytes)
        if rec.is_ghost {
            w.write_all(&[b' '; 8])?;
        } else {
            w.write_fixed_string(&rec.short_name, 8)?;
        }

        // Variable label (if present and not ghost)
        if has_label == 1 {
            let label_bytes = rec.label.as_ref().unwrap();
            let label_len = label_bytes.len();
            w.write_i32_le(label_len as i32)?;
            w.write_all(label_bytes)?;
            // Pad to 4-byte boundary
            let padded_len = io_utils::round_up(label_len, 4);
            if padded_len > label_len {
                w.write_zero_padding(padded_len - label_len)?;
            }
        }

        // Missing values
        write_missing_values(w, &rec.missing_values)?;
    }
    Ok(())
}

fn missing_count(mv: &MissingValues) -> i32 {
    match mv {
        MissingValues::None => 0,
        MissingValues::DiscreteNumeric(vals) => vals.len() as i32,
        MissingValues::Range { .. } => -2,
        MissingValues::RangeAndValue { .. } => -3,
        MissingValues::DiscreteString(vals) => vals.len() as i32,
    }
}

fn write_missing_values<W: Write>(w: &mut W, mv: &MissingValues) -> Result<()> {
    match mv {
        MissingValues::None => {}
        MissingValues::DiscreteNumeric(vals) => {
            for &v in vals {
                w.write_f64_le(v)?;
            }
        }
        MissingValues::Range { low, high } => {
            w.write_f64_le(*low)?;
            w.write_f64_le(*high)?;
        }
        MissingValues::RangeAndValue { low, high, value } => {
            w.write_f64_le(*low)?;
            w.write_f64_le(*high)?;
            w.write_f64_le(*value)?;
        }
        MissingValues::DiscreteString(vals) => {
            for v in vals {
                let mut buf = [b' '; 8];
                let len = v.len().min(8);
                buf[..len].copy_from_slice(&v[..len]);
                w.write_all(&buf)?;
            }
        }
    }
    Ok(())
}

fn write_value_label_records<W: Write>(
    w: &mut W,
    layout: &CaseLayout,
    meta: &SpssMetadata,
) -> Result<()> {
    // Track cumulative slot index for each variable
    let mut var_slot_indices: Vec<(usize, &WriteVariable)> = Vec::new();
    let mut slot_idx = 0usize;
    for var in &layout.write_vars {
        var_slot_indices.push((slot_idx, var));
        slot_idx += var.n_slots * var.n_segments;
    }

    // Group variables that share the same value label set
    // For SPSS, Type 3+4 pairs can reference multiple variables with the same labels.
    // For simplicity (and correctness), emit one Type 3+4 pair per variable.
    for &(slot, var) in &var_slot_indices {
        let labels = match meta.variable_value_labels.get(&var.long_name) {
            Some(labels) if !labels.is_empty() => labels,
            _ => continue,
        };

        // Type 3+4 only works for short strings (width <= 8) and numerics.
        // Long string value labels go to subtype 21.
        let is_long_string = matches!(&var.var_type, VarType::String(w) if *w > 8);
        if is_long_string {
            continue;
        }

        // Type 3: value labels
        w.write_i32_le(RECORD_TYPE_VALUE_LABEL)?;
        w.write_i32_le(labels.len() as i32)?;

        for (val, label) in labels {
            // Write 8-byte value
            match val {
                Value::Numeric(v) => {
                    w.write_f64_le(*v)?;
                }
                Value::String(s) => {
                    let mut buf = [b' '; 8];
                    let bytes = s.as_bytes();
                    let len = bytes.len().min(8);
                    buf[..len].copy_from_slice(&bytes[..len]);
                    w.write_all(&buf)?;
                }
            }

            // Label length (1 byte) + label text + padding to 8-byte boundary
            let label_bytes = label.as_bytes();
            let label_len = label_bytes.len().min(120); // SPSS caps at 120
            w.write_all(&[label_len as u8])?;
            w.write_all(&label_bytes[..label_len])?;
            // Pad: total = 1 + label_len, round up to nearest multiple of 8
            let total = 1 + label_len;
            let padded = io_utils::round_up(total, 8);
            if padded > total {
                w.write_zero_padding(padded - total)?;
            }
        }

        // Type 4: variable indices
        w.write_i32_le(RECORD_TYPE_VALUE_LABEL_VARS)?;
        w.write_i32_le(1)?; // one variable
        w.write_i32_le((slot + 1) as i32)?; // 1-based slot index
    }

    Ok(())
}

fn write_document_record<W: Write>(w: &mut W, meta: &SpssMetadata) -> Result<()> {
    if meta.notes.is_empty() {
        return Ok(());
    }

    // Split notes into 80-byte lines
    let mut lines: Vec<String> = Vec::new();
    for note in &meta.notes {
        // Each note can be one line
        lines.push(note.clone());
    }

    w.write_i32_le(RECORD_TYPE_DOCUMENT)?;
    w.write_i32_le(lines.len() as i32)?;

    for line in &lines {
        w.write_fixed_string(line, 80)?;
    }

    Ok(())
}

fn write_info_record_header<W: Write>(
    w: &mut W,
    subtype: i32,
    elem_size: i32,
    count: i32,
) -> Result<()> {
    w.write_i32_le(RECORD_TYPE_INFO)?;
    w.write_i32_le(subtype)?;
    w.write_i32_le(elem_size)?;
    w.write_i32_le(count)?;
    Ok(())
}

fn write_info_integer<W: Write>(w: &mut W, compression: Compression) -> Result<()> {
    write_info_record_header(w, INFO_INTEGER, 4, 8)?;
    w.write_i32_le(28)?; // version_major
    w.write_i32_le(0)?; // version_minor
    w.write_i32_le(0)?; // version_revision
    w.write_i32_le(-1)?; // machine_code
    w.write_i32_le(1)?; // floating_point_rep (IEEE 754)
    w.write_i32_le(compression.to_i32())?;
    w.write_i32_le(2)?; // endianness (LE)
    w.write_i32_le(65001)?; // UTF-8 code page
    Ok(())
}

fn write_info_float<W: Write>(w: &mut W) -> Result<()> {
    write_info_record_header(w, INFO_FLOAT, 8, 3)?;
    w.write_f64_le(f64::from_bits(SYSMIS_BITS))?;
    w.write_f64_le(f64::from_bits(HIGHEST_BITS))?;
    w.write_f64_le(f64::from_bits(LOWEST_BITS))?;
    Ok(())
}

fn write_info_var_display<W: Write>(w: &mut W, layout: &CaseLayout) -> Result<()> {
    // Count non-ghost slot records
    let n_vars = layout.slot_records.iter().filter(|r| !r.is_ghost).count();
    write_info_record_header(w, INFO_VAR_DISPLAY, 4, (n_vars * 3) as i32)?;

    // Emit measure/width/alignment for each non-ghost record
    let mut var_idx = 0;
    for rec in &layout.slot_records {
        if rec.is_ghost {
            continue;
        }
        // Find the corresponding WriteVariable for this non-ghost record
        // For VLS segments beyond the first, use defaults
        let (measure, display_width, alignment) = if var_idx < layout.write_vars.len() {
            let var = &layout.write_vars[var_idx];
            // Only advance var_idx for the primary segment
            if rec.short_name == var.short_name {
                var_idx += 1;
                (var.measure, var.display_width, var.alignment)
            } else {
                // VLS continuation segment
                (Measure::Unknown, 255, Alignment::Left)
            }
        } else {
            (Measure::Unknown, 8, Alignment::Left)
        };
        w.write_i32_le(measure.to_i32())?;
        w.write_i32_le(display_width as i32)?;
        w.write_i32_le(alignment.to_i32())?;
    }
    Ok(())
}

fn write_info_long_names<W: Write>(w: &mut W, layout: &CaseLayout) -> Result<()> {
    // Format: "SHORT=LongName\tSHORT2=LongName2\t..."
    let mut payload = String::new();
    for (short, long) in &layout.short_to_long {
        if !payload.is_empty() {
            payload.push('\t');
        }
        payload.push_str(short);
        payload.push('=');
        payload.push_str(long);
    }

    if payload.is_empty() {
        return Ok(());
    }

    write_info_record_header(w, INFO_LONG_NAMES, 1, payload.len() as i32)?;
    w.write_all(payload.as_bytes())?;
    Ok(())
}

fn write_info_very_long_strings<W: Write>(w: &mut W, layout: &CaseLayout) -> Result<()> {
    if layout.very_long_strings.is_empty() {
        return Ok(());
    }

    // Format: "SHORTNAME=WIDTH\0\tSHORTNAME2=WIDTH2\0\t"
    let mut payload = String::new();
    for (short_name, width) in &layout.very_long_strings {
        payload.push_str(short_name);
        payload.push('=');
        payload.push_str(&format!("{:05}", width));
        payload.push('\0');
        payload.push('\t');
    }

    write_info_record_header(w, INFO_VERY_LONG_STRINGS, 1, payload.len() as i32)?;
    w.write_all(payload.as_bytes())?;
    Ok(())
}

fn write_info_encoding<W: Write>(w: &mut W) -> Result<()> {
    let encoding = b"UTF-8";
    write_info_record_header(w, INFO_ENCODING, 1, encoding.len() as i32)?;
    w.write_all(encoding)?;
    Ok(())
}

fn write_info_long_string_labels<W: Write>(
    w: &mut W,
    layout: &CaseLayout,
    meta: &SpssMetadata,
) -> Result<()> {
    // Collect long string variables (width > 8) that have value labels
    let mut entries: Vec<(&str, &IndexMap<Value, String>)> = Vec::new();
    for var in &layout.write_vars {
        if matches!(&var.var_type, VarType::String(w) if *w > 8) {
            if let Some(labels) = meta.variable_value_labels.get(&var.long_name) {
                if !labels.is_empty() {
                    entries.push((&var.short_name, labels));
                }
            }
        }
    }
    if entries.is_empty() {
        return Ok(());
    }

    // Build payload in pascal-string format
    let mut payload = Vec::new();
    for (var_name, labels) in &entries {
        // Variable name: length-prefixed
        let name_bytes = var_name.as_bytes();
        payload.extend_from_slice(&(name_bytes.len() as i32).to_le_bytes());
        payload.extend_from_slice(name_bytes);

        // Width placeholder (stored as i32, use storage width)
        let var_width = layout
            .write_vars
            .iter()
            .find(|v| v.short_name == **var_name)
            .map(|v| v.storage_width as i32)
            .unwrap_or(0);
        payload.extend_from_slice(&var_width.to_le_bytes());

        // Number of labels
        payload.extend_from_slice(&(labels.len() as i32).to_le_bytes());

        for (val, label) in *labels {
            // Value: length-prefixed
            let val_str = match val {
                Value::String(s) => s.clone(),
                Value::Numeric(n) => n.to_string(),
            };
            let val_bytes = val_str.as_bytes();
            payload.extend_from_slice(&(val_bytes.len() as i32).to_le_bytes());
            payload.extend_from_slice(val_bytes);

            // Label: length-prefixed
            let label_bytes = label.as_bytes();
            payload.extend_from_slice(&(label_bytes.len() as i32).to_le_bytes());
            payload.extend_from_slice(label_bytes);
        }
    }

    write_info_record_header(w, INFO_LONG_STRING_LABELS, 1, payload.len() as i32)?;
    w.write_all(&payload)?;
    Ok(())
}

fn write_info_long_string_missing<W: Write>(
    w: &mut W,
    layout: &CaseLayout,
    meta: &SpssMetadata,
) -> Result<()> {
    // Collect long string variables (width > 8) that have missing values.
    // Per PSPP spec: use SHORT name, value_len = 8, each value is 8 bytes space-padded.
    let mut entries: Vec<(&str, &Vec<MissingSpec>)> = Vec::new();
    for var in &layout.write_vars {
        if matches!(&var.var_type, VarType::String(w) if *w > 8) {
            if let Some(specs) = meta.variable_missing_values.get(&var.long_name) {
                if !specs.is_empty() {
                    entries.push((&var.short_name, specs));
                }
            }
        }
    }
    if entries.is_empty() {
        return Ok(());
    }

    // Build payload
    let mut payload = Vec::new();
    for (var_name, specs) in &entries {
        let name_bytes = var_name.as_bytes();
        payload.extend_from_slice(&(name_bytes.len() as i32).to_le_bytes());
        payload.extend_from_slice(name_bytes);

        // Number of missing values
        let n_missing: u8 = specs.len() as u8;
        payload.push(n_missing);

        // Value width: always 8 per PSPP spec (string missing values are max 8 chars)
        payload.extend_from_slice(&8_i32.to_le_bytes());

        for spec in *specs {
            if let MissingSpec::StringValue(s) = spec {
                // Each value is exactly 8 bytes, space-padded
                let val_bytes = s.as_bytes();
                let mut buf = [b' '; 8];
                let len = val_bytes.len().min(8);
                buf[..len].copy_from_slice(&val_bytes[..len]);
                payload.extend_from_slice(&buf);
            }
        }
    }

    write_info_record_header(w, INFO_LONG_STRING_MISSING, 1, payload.len() as i32)?;
    w.write_all(&payload)?;
    Ok(())
}

fn write_info_mr_sets<W: Write>(
    w: &mut W,
    meta: &SpssMetadata,
    layout: &CaseLayout,
) -> Result<()> {
    if meta.mr_sets.is_empty() {
        return Ok(());
    }

    // Build long → short name map (inverted from layout.short_to_long)
    let long_to_short: IndexMap<String, String> = layout
        .short_to_long
        .iter()
        .map(|(short, long)| (long.clone(), short.clone()))
        .collect();

    // Format per line (one set per line):
    //   $NAME=Dn counted_value label_len label var1 var2 ...\n  (dichotomy)
    //   $NAME=C label_len label var1 var2 ...\n                  (category)
    // Where n = ASCII length of counted_value, label_len = ASCII byte length of label.
    // Variable names must be SHORT names (8 char max).
    let mut payload = String::new();
    for (name, mr) in &meta.mr_sets {
        payload.push('$');
        payload.push_str(name);
        payload.push('=');
        match mr.mr_type {
            MrType::MultipleDichotomy => {
                payload.push('D');
                if let Some(ref cv) = mr.counted_value {
                    // Write length of counted_value + space + counted_value
                    payload.push_str(&cv.len().to_string());
                    payload.push(' ');
                    payload.push_str(cv);
                } else {
                    // No counted value — write "1 1" as default (common for dichotomy)
                    payload.push_str("1 1");
                }
            }
            MrType::MultipleCategory => {
                payload.push('C');
            }
        }
        payload.push(' ');

        // Write label_len + space + label
        let label_bytes = mr.label.as_bytes().len();
        payload.push_str(&label_bytes.to_string());
        payload.push(' ');
        payload.push_str(&mr.label);

        // Write space-separated short variable names
        for var_long in &mr.variables {
            let short = long_to_short
                .get(var_long)
                .unwrap_or(var_long);
            payload.push(' ');
            payload.push_str(short);
        }
        payload.push('\n');
    }

    write_info_record_header(w, INFO_MR_SETS, 1, payload.len() as i32)?;
    w.write_all(payload.as_bytes())?;
    Ok(())
}

/// Write subtype 19 MR sets with LONG variable names.
/// Modern SPSS (14+) writes MR sets to subtype 19 alongside subtype 7.
/// Writing both ensures full roundtrip fidelity.
fn write_info_mr_sets_v2<W: Write>(
    w: &mut W,
    meta: &SpssMetadata,
) -> Result<()> {
    if meta.mr_sets.is_empty() {
        return Ok(());
    }

    // Same text format as subtype 7, but with long variable names directly
    let mut payload = String::new();
    for (name, mr) in &meta.mr_sets {
        payload.push('$');
        payload.push_str(name);
        payload.push('=');
        match mr.mr_type {
            MrType::MultipleDichotomy => {
                payload.push('D');
                if let Some(ref cv) = mr.counted_value {
                    payload.push_str(&cv.len().to_string());
                    payload.push(' ');
                    payload.push_str(cv);
                } else {
                    payload.push_str("1 1");
                }
            }
            MrType::MultipleCategory => {
                payload.push('C');
            }
        }
        payload.push(' ');

        let label_bytes = mr.label.as_bytes().len();
        payload.push_str(&label_bytes.to_string());
        payload.push(' ');
        payload.push_str(&mr.label);

        // Write space-separated LONG variable names (no short-name mapping)
        for var in &mr.variables {
            payload.push(' ');
            payload.push_str(var);
        }
        payload.push('\n');
    }

    write_info_record_header(w, INFO_MR_SETS_V2, 1, payload.len() as i32)?;
    w.write_all(payload.as_bytes())?;
    Ok(())
}

fn write_info_var_attributes<W: Write>(
    w: &mut W,
    meta: &SpssMetadata,
) -> Result<()> {
    if meta.variable_roles.is_empty() && meta.variable_attributes.is_empty() {
        return Ok(());
    }

    // Collect all variable names that have either a role or custom attributes
    let mut all_vars: IndexMap<&str, ()> = IndexMap::new();
    for name in meta.variable_roles.keys() {
        all_vars.insert(name.as_str(), ());
    }
    for name in meta.variable_attributes.keys() {
        all_vars.insert(name.as_str(), ());
    }

    // Build text payload in subtype 18 format (uses LONG names per PSPP spec):
    //   varname:CustomAttr('val'\n)$@Role('code'\n)/varname2:...
    let mut payload = String::new();
    for (long_name, _) in &all_vars {
        if !payload.is_empty() {
            payload.push('/');
        }
        payload.push_str(long_name);
        payload.push(':');

        // Write custom attributes first
        if let Some(attrs) = meta.variable_attributes.get(*long_name) {
            for (attr_name, values) in attrs {
                if values.is_empty() {
                    continue; // Empty value list is invalid per PSPP grammar (value+)
                }
                payload.push_str(attr_name);
                payload.push('(');
                for val in values {
                    payload.push('\'');
                    payload.push_str(val);
                    payload.push_str("'\n");
                }
                payload.push(')');
            }
        }

        // Write $@Role
        if let Some(role) = meta.variable_roles.get(*long_name) {
            payload.push_str("$@Role('");
            payload.push_str(role.to_code());
            payload.push_str("'\n)");
        }
    }

    write_info_record_header(w, INFO_VAR_ATTRIBUTES, 1, payload.len() as i32)?;
    w.write_all(payload.as_bytes())?;
    Ok(())
}

fn write_dict_termination<W: Write>(w: &mut W) -> Result<()> {
    w.write_i32_le(RECORD_TYPE_DICT_TERMINATION)?;
    w.write_i32_le(0)?; // filler
    Ok(())
}

/// Extract a string value from any Arrow string array type.
/// Handles StringViewArray (Utf8View), StringArray (Utf8), and LargeStringArray (LargeUtf8).
/// Polars exports LargeUtf8 via PyCapsule, so all three must be supported.
#[inline]
fn get_string_value<'a>(col: &'a dyn Array, row: usize) -> &'a str {
    col.as_any()
        .downcast_ref::<StringViewArray>()
        .map(|a| a.value(row))
        .or_else(|| {
            col.as_any()
                .downcast_ref::<arrow::array::StringArray>()
                .map(|a| a.value(row))
        })
        .or_else(|| {
            col.as_any()
                .downcast_ref::<LargeStringArray>()
                .map(|a| a.value(row))
        })
        .unwrap_or("")
}

/// Convert temporal Arrow arrays back to SPSS float values.
/// Returns a new Float64Array with SPSS epoch-based seconds.
fn temporal_to_spss_float(arr: &dyn Array, kind: TemporalKind) -> Float64Array {
    match kind {
        TemporalKind::Date => {
            let date_arr = arr.as_any().downcast_ref::<Date32Array>().unwrap();
            let null_buf = date_arr.nulls().cloned();
            let values: Vec<f64> = date_arr
                .values()
                .iter()
                .map(|&d| (d as f64 + SPSS_EPOCH_OFFSET_DAYS as f64) * SECONDS_PER_DAY)
                .collect();
            Float64Array::new(values.into(), null_buf)
        }
        TemporalKind::Timestamp => {
            let ts_arr = arr
                .as_any()
                .downcast_ref::<TimestampMicrosecondArray>()
                .unwrap();
            let null_buf = ts_arr.nulls().cloned();
            let values: Vec<f64> = ts_arr
                .values()
                .iter()
                .map(|&us| (us as f64 / MICROS_PER_SECOND) + SPSS_EPOCH_OFFSET_SECONDS)
                .collect();
            Float64Array::new(values.into(), null_buf)
        }
        TemporalKind::Duration => {
            let dur_arr = arr
                .as_any()
                .downcast_ref::<DurationMicrosecondArray>()
                .unwrap();
            let null_buf = dur_arr.nulls().cloned();
            let values: Vec<f64> = dur_arr
                .values()
                .iter()
                .map(|&us| us as f64 / MICROS_PER_SECOND)
                .collect();
            Float64Array::new(values.into(), null_buf)
        }
    }
}

/// Get a numeric f64 value from various Arrow numeric types.
fn get_numeric_f64(arr: &dyn Array, row: usize) -> Option<f64> {
    if arr.is_null(row) {
        return None;
    }
    let dt = arr.data_type();
    match dt {
        DataType::Float64 => {
            let a = arr.as_any().downcast_ref::<Float64Array>().unwrap();
            Some(a.value(row))
        }
        DataType::Int64 => {
            let a = arr.as_any().downcast_ref::<Int64Array>().unwrap();
            Some(a.value(row) as f64)
        }
        DataType::Int32 => {
            let a = arr.as_any().downcast_ref::<Int32Array>().unwrap();
            Some(a.value(row) as f64)
        }
        DataType::Int16 => {
            let a = arr.as_any().downcast_ref::<Int16Array>().unwrap();
            Some(a.value(row) as f64)
        }
        DataType::Int8 => {
            let a = arr.as_any().downcast_ref::<Int8Array>().unwrap();
            Some(a.value(row) as f64)
        }
        DataType::Boolean => {
            let a = arr.as_any().downcast_ref::<BooleanArray>().unwrap();
            Some(if a.value(row) { 1.0 } else { 0.0 })
        }
        _ => None,
    }
}

// ---------------------------------------------------------------------------
// Shared row-building helpers (used by all three data writers)
// ---------------------------------------------------------------------------

/// Pre-convert temporal Arrow columns to SPSS Float64 values.
fn preconvert_temporal_columns(
    batch: &RecordBatch,
    layout: &CaseLayout,
) -> Vec<Option<Float64Array>> {
    let mut temporal_arrays = Vec::with_capacity(layout.write_vars.len());
    for var in &layout.write_vars {
        let col = batch.column(var.col_index);
        if let Some(kind) = var.format.format_type.temporal_kind() {
            temporal_arrays.push(Some(temporal_to_spss_float(col.as_ref(), kind)));
        } else {
            temporal_arrays.push(None);
        }
    }
    temporal_arrays
}

/// Fill a pre-allocated row buffer with data from one row of the RecordBatch.
/// `row_buf` must be pre-filled with spaces (0x20) before calling.
fn fill_row_buffer(
    row_buf: &mut [u8],
    row: usize,
    batch: &RecordBatch,
    layout: &CaseLayout,
    temporal_arrays: &[Option<Float64Array>],
) {
    let mut slot_offset = 0;
    for (var_idx, var) in layout.write_vars.iter().enumerate() {
        let col: &dyn Array = if let Some(ref arr) = temporal_arrays[var_idx] {
            arr
        } else {
            batch.column(var.col_index).as_ref()
        };

        match &var.var_type {
            VarType::Numeric => {
                let val = if col.is_null(row) {
                    f64::from_bits(SYSMIS_BITS)
                } else {
                    get_numeric_f64(col, row).unwrap_or(f64::from_bits(SYSMIS_BITS))
                };
                row_buf[slot_offset * 8..(slot_offset + 1) * 8]
                    .copy_from_slice(&val.to_le_bytes());
                slot_offset += 1;
            }
            VarType::String(width) => {
                let str_val = if col.is_null(row) {
                    ""
                } else {
                    get_string_value(col, row)
                };

                let str_bytes = str_val.as_bytes();
                let total_slots = var.n_slots * var.n_segments;

                if var.n_segments == 1 {
                    let total_slot_bytes = total_slots * 8;
                    let start = slot_offset * 8;
                    let copy_len = str_bytes.len().min(total_slot_bytes);
                    row_buf[start..start + copy_len]
                        .copy_from_slice(&str_bytes[..copy_len]);
                } else {
                    // VLS: distribute across segments
                    let mut str_pos = 0;
                    for seg in 0..var.n_segments {
                        let seg_start = (slot_offset + seg * 32) * 8;
                        let useful = if seg < var.n_segments - 1 {
                            255
                        } else {
                            width.saturating_sub((var.n_segments - 1) * 255)
                        };
                        let copy_len = str_bytes.len().saturating_sub(str_pos).min(useful);
                        if copy_len > 0 {
                            row_buf[seg_start..seg_start + copy_len]
                                .copy_from_slice(&str_bytes[str_pos..str_pos + copy_len]);
                        }
                        str_pos += useful;
                    }
                }
                slot_offset += total_slots;
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Data writers
// ---------------------------------------------------------------------------

fn write_data_uncompressed<W: Write>(
    w: &mut W,
    batch: &RecordBatch,
    layout: &CaseLayout,
) -> Result<()> {
    let nrows = batch.num_rows();
    let row_bytes = layout.slots_per_row * 8;
    let temporal_arrays = preconvert_temporal_columns(batch, layout);
    let mut row_buf = vec![b' '; row_bytes];

    for row in 0..nrows {
        row_buf.iter_mut().for_each(|b| *b = b' ');
        fill_row_buffer(&mut row_buf, row, batch, layout, &temporal_arrays);
        w.write_all(&row_buf)?;
    }

    Ok(())
}

/// Drain threshold: flush encoder to disk when accumulated output exceeds ~1MB.
const BYTECODE_DRAIN_THRESHOLD: usize = 1 << 20;

fn write_data_bytecode<W: Write>(
    w: &mut W,
    batch: &RecordBatch,
    layout: &CaseLayout,
) -> Result<()> {
    let nrows = batch.num_rows();
    let row_bytes = layout.slots_per_row * 8;
    let temporal_arrays = preconvert_temporal_columns(batch, layout);
    let mut encoder = BytecodeEncoder::new(DEFAULT_BIAS);
    let mut row_buf = vec![b' '; row_bytes];

    for row in 0..nrows {
        row_buf.iter_mut().for_each(|b| *b = b' ');
        fill_row_buffer(&mut row_buf, row, batch, layout, &temporal_arrays);
        encoder.encode_row(&row_buf, layout.slots_per_row);

        // Periodically drain to disk to keep memory bounded
        if encoder.output_len() >= BYTECODE_DRAIN_THRESHOLD {
            let chunk = encoder.drain_output();
            w.write_all(&chunk)?;
        }
    }

    // Finalize: write EOF and flush remaining
    encoder.write_eof();
    let remaining = encoder.drain_output();
    w.write_all(&remaining)?;

    Ok(())
}

/// Default ZSAV block size (0x3FF000 = ~4MB uncompressed bytecode per block).
const ZSAV_BLOCK_SIZE: usize = 0x3FF000;

/// Drain threshold for encoder within ZSAV writer (~64KB).
const ZSAV_DRAIN_THRESHOLD: usize = 64 * 1024;

struct ZsavBlockInfo {
    uncompressed_offset: i64,
    compressed_offset: i64,
    uncompressed_size: i32,
    compressed_size: i32,
}

/// Compress a byte slice with zlib.
fn zlib_compress(data: &[u8]) -> Result<Vec<u8>> {
    use flate2::write::ZlibEncoder;
    let mut zlib_enc = ZlibEncoder::new(Vec::new(), flate2::Compression::default());
    zlib_enc
        .write_all(data)
        .map_err(|e| SpssError::Zlib(format!("zlib compression error: {e}")))?;
    zlib_enc
        .finish()
        .map_err(|e| SpssError::Zlib(format!("zlib finish error: {e}")))
}

/// Flush completed ZSAV blocks from the block buffer to disk.
/// Writes full ZSAV_BLOCK_SIZE chunks, keeps any remainder in `block_buf`.
fn flush_zsav_blocks<W: Write + Seek>(
    w: &mut W,
    block_buf: &mut Vec<u8>,
    blocks: &mut Vec<ZsavBlockInfo>,
    bytecode_offset: &mut i64,
) -> Result<()> {
    while block_buf.len() >= ZSAV_BLOCK_SIZE {
        let compressed = zlib_compress(&block_buf[..ZSAV_BLOCK_SIZE])?;
        let compressed_offset = w.stream_position().map_err(SpssError::Io)? as i64;
        w.write_all(&compressed)?;

        blocks.push(ZsavBlockInfo {
            uncompressed_offset: *bytecode_offset,
            compressed_offset,
            uncompressed_size: ZSAV_BLOCK_SIZE as i32,
            compressed_size: compressed.len() as i32,
        });

        *bytecode_offset += ZSAV_BLOCK_SIZE as i64;

        // Remove the flushed portion
        let remaining = block_buf[ZSAV_BLOCK_SIZE..].to_vec();
        *block_buf = remaining;
    }
    Ok(())
}

fn write_data_zsav<W: Write + Seek>(
    w: &mut W,
    batch: &RecordBatch,
    layout: &CaseLayout,
) -> Result<()> {
    let nrows = batch.num_rows();
    let row_bytes = layout.slots_per_row * 8;
    let temporal_arrays = preconvert_temporal_columns(batch, layout);

    // Write zheader placeholder (will backpatch later)
    let zheader_offset = w.stream_position().map_err(SpssError::Io)? as i64;
    w.write_all(&[0u8; 24])?;

    let mut blocks: Vec<ZsavBlockInfo> = Vec::new();
    let mut bytecode_offset: i64 = 0;
    let mut block_buf = Vec::with_capacity(ZSAV_BLOCK_SIZE + ZSAV_DRAIN_THRESHOLD);

    let mut encoder = BytecodeEncoder::new(DEFAULT_BIAS);
    let mut row_buf = vec![b' '; row_bytes];

    for row in 0..nrows {
        row_buf.iter_mut().for_each(|b| *b = b' ');
        fill_row_buffer(&mut row_buf, row, batch, layout, &temporal_arrays);
        encoder.encode_row(&row_buf, layout.slots_per_row);

        // Drain encoder output into block accumulator
        if encoder.output_len() >= ZSAV_DRAIN_THRESHOLD {
            let chunk = encoder.drain_output();
            block_buf.extend_from_slice(&chunk);
        }

        // Flush completed blocks to disk
        if block_buf.len() >= ZSAV_BLOCK_SIZE {
            flush_zsav_blocks(w, &mut block_buf, &mut blocks, &mut bytecode_offset)?;
        }
    }

    // Finalize encoder: write EOF and drain remaining bytecode
    encoder.write_eof();
    let final_chunk = encoder.drain_output();
    block_buf.extend_from_slice(&final_chunk);

    // Flush any remaining full blocks
    flush_zsav_blocks(w, &mut block_buf, &mut blocks, &mut bytecode_offset)?;

    // Write remaining partial block (if any)
    if !block_buf.is_empty() {
        let compressed = zlib_compress(&block_buf)?;
        let compressed_offset = w.stream_position().map_err(SpssError::Io)? as i64;
        w.write_all(&compressed)?;

        blocks.push(ZsavBlockInfo {
            uncompressed_offset: bytecode_offset,
            compressed_offset,
            uncompressed_size: block_buf.len() as i32,
            compressed_size: compressed.len() as i32,
        });
    }

    // Write ztrailer
    let ztrailer_offset = w.stream_position().map_err(SpssError::Io)? as i64;
    w.write_all(&(DEFAULT_BIAS as i64).to_le_bytes())?;
    w.write_all(&0_i64.to_le_bytes())?;
    w.write_i32_le(ZSAV_BLOCK_SIZE as i32)?;
    w.write_i32_le(blocks.len() as i32)?;

    for block in &blocks {
        w.write_all(&block.uncompressed_offset.to_le_bytes())?;
        w.write_all(&block.compressed_offset.to_le_bytes())?;
        w.write_i32_le(block.uncompressed_size)?;
        w.write_i32_le(block.compressed_size)?;
    }

    let ztrailer_end = w.stream_position().map_err(SpssError::Io)? as i64;
    let ztrailer_length = ztrailer_end - ztrailer_offset;

    // Backpatch zheader
    w.seek(SeekFrom::Start(zheader_offset as u64))
        .map_err(SpssError::Io)?;
    w.write_all(&zheader_offset.to_le_bytes())?;
    w.write_all(&ztrailer_offset.to_le_bytes())?;
    w.write_all(&ztrailer_length.to_le_bytes())?;

    // Seek back to end
    w.seek(SeekFrom::Start(ztrailer_end as u64))
        .map_err(SpssError::Io)?;

    Ok(())
}

// ---------------------------------------------------------------------------
// Date/time helpers
// ---------------------------------------------------------------------------

/// Return the current date and time in SPSS header format.
/// Date: "DD MMM YY" (9 bytes), Time: "HH:MM:SS" (8 bytes).
fn current_date_time() -> (String, String) {
    use std::time::{SystemTime, UNIX_EPOCH};

    let secs = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs();

    // Convert epoch seconds to date/time components.
    // Simple civil-time calculation (no leap seconds, good enough for timestamps).
    let secs_per_day = 86400u64;
    let time_of_day = secs % secs_per_day;
    let hh = time_of_day / 3600;
    let mm = (time_of_day % 3600) / 60;
    let ss = time_of_day % 60;

    // Days since 1970-01-01
    let mut days = (secs / secs_per_day) as i64;

    // Compute year/month/day from days since epoch
    let mut year = 1970i32;
    loop {
        let days_in_year = if is_leap(year) { 366 } else { 365 };
        if days < days_in_year {
            break;
        }
        days -= days_in_year;
        year += 1;
    }
    let months_days: [i64; 12] = if is_leap(year) {
        [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    } else {
        [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    };
    let mut month = 0usize;
    for (i, &md) in months_days.iter().enumerate() {
        if days < md {
            month = i;
            break;
        }
        days -= md;
    }
    let day = days + 1;

    const MONTH_ABBR: [&str; 12] = [
        "Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
    ];

    let yy = year % 100;
    let date = format!("{:02} {} {:02}", day, MONTH_ABBR[month], yy);
    let time = format!("{:02}:{:02}:{:02}", hh, mm, ss);
    (date, time)
}

fn is_leap(y: i32) -> bool {
    (y % 4 == 0 && y % 100 != 0) || y % 400 == 0
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/// Write an Arrow RecordBatch to an SPSS .sav file.
///
/// If `metadata` is provided, it controls variable labels, value labels,
/// formats, and other SPSS metadata. If default metadata is used, types
/// are inferred from the Arrow schema.
///
/// # Compression
/// - `Compression::None` — uncompressed .sav
/// - `Compression::Bytecode` — row-compressed .sav
/// - `Compression::Zlib` — block-compressed .zsav
pub fn write_sav(
    path: impl AsRef<Path>,
    batch: &RecordBatch,
    metadata: &SpssMetadata,
    compression: Compression,
) -> Result<()> {
    let file = File::create(path)?;
    let writer = BufWriter::new(file);
    write_sav_to_writer(writer, batch, metadata, compression)
}

/// Write to any writer that implements Write + Seek.
///
/// Seek is required for zsav (zlib) compression to backpatch the zheader.
/// For non-zsav files, `std::io::Cursor<Vec<u8>>` is a convenient seekable wrapper.
/// Fill missing metadata fields from the Arrow schema with sensible defaults.
///
/// For each column in the schema, if the metadata is missing a field
/// (format, measure, alignment, display_width, role, storage_width),
/// it is filled using the same type-based logic as `from_arrow_schema()`.
/// User-set fields are never overwritten.
fn fill_defaults_from_schema(meta: &mut SpssMetadata, schema: &arrow::datatypes::Schema) {
    for field in schema.fields() {
        let name = field.name();

        // Infer defaults from Arrow type (same logic as SpssMetadata::from_arrow_schema)
        let (default_fmt, default_measure, default_alignment) = match field.data_type() {
            DataType::Float64 => ("F8.2", Measure::Scale, Alignment::Right),
            DataType::Int64 | DataType::Int32 | DataType::Int16 | DataType::Int8 => {
                ("F8.0", Measure::Scale, Alignment::Right)
            }
            DataType::Boolean => ("F1.0", Measure::Nominal, Alignment::Right),
            DataType::Date32 => ("DATE11", Measure::Scale, Alignment::Right),
            DataType::Timestamp(TimeUnit::Microsecond, _) => {
                ("DATETIME23.2", Measure::Scale, Alignment::Right)
            }
            DataType::Duration(TimeUnit::Microsecond) => {
                ("TIME11.2", Measure::Scale, Alignment::Right)
            }
            DataType::Utf8 | DataType::Utf8View | DataType::LargeUtf8 => {
                ("A255", Measure::Nominal, Alignment::Left)
            }
            _ => ("F8.2", Measure::Scale, Alignment::Right),
        };

        if !meta.variable_formats.contains_key(name.as_str()) {
            meta.variable_formats
                .insert(name.clone(), default_fmt.to_string());
        }

        if !meta.variable_measures.contains_key(name.as_str()) {
            meta.variable_measures
                .insert(name.clone(), default_measure);
        }

        if !meta.variable_alignments.contains_key(name.as_str()) {
            meta.variable_alignments
                .insert(name.clone(), default_alignment);
        }

        if !meta.variable_display_widths.contains_key(name.as_str()) {
            // Use the format width (already set above or by user)
            let fmt_str = meta.variable_formats.get(name.as_str()).unwrap();
            let w = SpssFormat::from_string(fmt_str)
                .map(|f| f.width as u32)
                .unwrap_or(8);
            meta.variable_display_widths.insert(name.clone(), w);
        }

        if !meta.variable_roles.contains_key(name.as_str()) {
            meta.variable_roles.insert(name.clone(), Role::Input);
        }

        if !meta.variable_storage_widths.contains_key(name.as_str()) {
            let fmt_str = meta.variable_formats.get(name.as_str()).unwrap();
            let sw = if fmt_str.starts_with('A') {
                fmt_str[1..]
                    .split('.')
                    .next()
                    .and_then(|w| w.parse::<usize>().ok())
                    .unwrap_or(255)
            } else {
                8
            };
            meta.variable_storage_widths.insert(name.clone(), sw);
        }
    }
}

pub fn write_sav_to_writer<W: Write + Seek>(
    mut writer: W,
    batch: &RecordBatch,
    metadata: &SpssMetadata,
    compression: Compression,
) -> Result<()> {
    // Fill any missing metadata fields from the schema
    let mut meta = metadata.clone();
    fill_defaults_from_schema(&mut meta, batch.schema().as_ref());
    let metadata = &meta;

    let layout = compute_layout(batch, metadata)?;
    let nrows = batch.num_rows() as i32;

    // Write dictionary
    write_header(&mut writer, &layout, metadata, compression, nrows)?;
    write_variable_records(&mut writer, &layout)?;
    write_value_label_records(&mut writer, &layout, metadata)?;
    write_document_record(&mut writer, metadata)?;
    write_info_integer(&mut writer, compression)?;
    write_info_float(&mut writer)?;
    write_info_var_display(&mut writer, &layout)?;
    write_info_long_names(&mut writer, &layout)?;
    write_info_very_long_strings(&mut writer, &layout)?;
    write_info_encoding(&mut writer)?;
    write_info_long_string_labels(&mut writer, &layout, metadata)?;
    write_info_long_string_missing(&mut writer, &layout, metadata)?;
    write_info_mr_sets(&mut writer, metadata, &layout)?;
    write_info_mr_sets_v2(&mut writer, metadata)?;
    write_info_var_attributes(&mut writer, metadata)?;
    write_dict_termination(&mut writer)?;

    // Write data
    match compression {
        Compression::None => write_data_uncompressed(&mut writer, batch, &layout)?,
        Compression::Bytecode => write_data_bytecode(&mut writer, batch, &layout)?,
        Compression::Zlib => write_data_zsav(&mut writer, batch, &layout)?,
    }

    writer.flush()?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use arrow::array::{Float64Builder, StringBuilder};
    use arrow::datatypes::{Field, Schema};
    use std::io::Cursor;
    use std::sync::Arc;

    fn make_simple_batch() -> RecordBatch {
        let schema = Arc::new(Schema::new(vec![
            Field::new("age", DataType::Float64, true),
            Field::new("name", DataType::Utf8, true),
        ]));
        let mut age_builder = Float64Builder::new();
        age_builder.append_value(25.0);
        age_builder.append_value(30.0);
        age_builder.append_null();
        let mut name_builder = StringBuilder::new();
        name_builder.append_value("Alice");
        name_builder.append_value("Bob");
        name_builder.append_null();
        RecordBatch::try_new(
            schema,
            vec![
                Arc::new(age_builder.finish()),
                Arc::new(name_builder.finish()),
            ],
        )
        .unwrap()
    }

    #[test]
    fn test_write_header_size() {
        let batch = make_simple_batch();
        let meta = SpssMetadata::from_arrow_schema(batch.schema().as_ref());
        let layout = compute_layout(&batch, &meta).unwrap();
        let mut cursor = Cursor::new(Vec::new());
        write_header(&mut cursor, &layout, &meta, Compression::None, 3).unwrap();
        assert_eq!(cursor.into_inner().len(), 176);
    }

    #[test]
    fn test_write_and_read_back() {
        let batch = make_simple_batch();
        let meta = SpssMetadata::from_arrow_schema(batch.schema().as_ref());

        let mut cursor = Cursor::new(Vec::new());
        write_sav_to_writer(&mut cursor, &batch, &meta, Compression::None).unwrap();

        // Verify it's a valid SAV file by reading back
        let reader = Cursor::new(cursor.into_inner());
        let (batch2, meta2) = crate::read_sav_from_reader(reader).unwrap();

        assert_eq!(batch2.num_rows(), 3);
        assert_eq!(batch2.num_columns(), 2);
        assert_eq!(meta2.variable_names.len(), 2);
    }

    #[test]
    fn test_format_roundtrip() {
        let formats = ["F8.2", "A50", "DATE11", "DATETIME23.2", "TIME11.2", "F1.0", "N5"];
        for fmt_str in &formats {
            let fmt = SpssFormat::from_string(fmt_str);
            assert!(fmt.is_some(), "failed to parse {fmt_str}");
            let fmt = fmt.unwrap();
            let packed = fmt.to_packed();
            let unpacked = SpssFormat::from_packed(packed);
            assert!(unpacked.is_some(), "failed to unpack {fmt_str}");
            let unpacked = unpacked.unwrap();
            assert_eq!(fmt.format_type, unpacked.format_type, "type mismatch for {fmt_str}");
            assert_eq!(fmt.width, unpacked.width, "width mismatch for {fmt_str}");
            assert_eq!(fmt.decimals, unpacked.decimals, "decimals mismatch for {fmt_str}");
        }
    }

    #[test]
    fn test_short_name_generation() {
        let mut used = HashSet::new();
        let name1 = generate_short_name("variable_long_name_1", &mut used);
        assert!(name1.len() <= 8);
        assert!(used.contains(&name1));

        let name2 = generate_short_name("variable_long_name_2", &mut used);
        assert!(name2.len() <= 8);
        assert_ne!(name1, name2);
    }

    #[test]
    fn test_missing_values_roundtrip() {
        let specs = vec![MissingSpec::Value(99.0), MissingSpec::Value(-1.0)];
        let mv = specs_to_missing(&specs);
        match &mv {
            MissingValues::DiscreteNumeric(vals) => {
                assert_eq!(vals.len(), 2);
                assert_eq!(vals[0], 99.0);
                assert_eq!(vals[1], -1.0);
            }
            _ => panic!("expected DiscreteNumeric"),
        }
    }

    // -----------------------------------------------------------------------
    // Real-file round-trip tests
    // -----------------------------------------------------------------------

    /// Helper: read a real file, write it back, read the result, compare shapes.
    fn roundtrip_file(path: &str) {
        let (batch, meta) = crate::read_sav(path).unwrap();
        let orig_rows = batch.num_rows();
        let orig_cols = batch.num_columns();

        let mut cursor = Cursor::new(Vec::new());
        write_sav_to_writer(&mut cursor, &batch, &meta, Compression::None).unwrap();

        let reader = Cursor::new(cursor.into_inner());
        let (batch2, meta2) = crate::read_sav_from_reader(reader).unwrap();

        assert_eq!(
            batch2.num_rows(),
            orig_rows,
            "row count mismatch for {path}"
        );
        assert_eq!(
            batch2.num_columns(),
            orig_cols,
            "column count mismatch for {path}"
        );
        assert_eq!(
            meta2.variable_names.len(),
            meta.variable_names.len(),
            "variable name count mismatch for {path}"
        );

        // Verify numeric data matches for the first column
        for col_idx in 0..orig_cols.min(5) {
            let col1 = batch.column(col_idx);
            let col2 = batch2.column(col_idx);
            assert_eq!(
                col1.null_count(),
                col2.null_count(),
                "null count mismatch for column {} in {path}",
                col_idx,
            );
        }
    }

    #[test]
    fn test_roundtrip_test1_small() {
        let path = "test_data/test_1_small.sav";
        if std::path::Path::new(path).exists() {
            roundtrip_file(path);
        }
    }

    #[test]
    fn test_roundtrip_test4_small() {
        let path = "test_data/test_4_small.sav";
        if std::path::Path::new(path).exists() {
            roundtrip_file(path);
        }
    }

    #[test]
    fn test_roundtrip_test5_small() {
        let path = "test_data/test_5_small.sav";
        if std::path::Path::new(path).exists() {
            roundtrip_file(path);
        }
    }

    #[test]
    fn test_roundtrip_test7_nulls() {
        let path = "test_data/test7_null_column.sav";
        if std::path::Path::new(path).exists() {
            roundtrip_file(path);
        }
    }

    #[test]
    fn test_roundtrip_test9_empty_metadata() {
        // This file has 0 data rows with bytecode compression, which
        // triggers a pre-existing reader panic. Skip until reader is fixed.
        let path = "test_data/test9_empty_file_with_metadata.sav";
        if std::path::Path::new(path).exists() {
            let result = std::panic::catch_unwind(|| crate::read_sav(path));
            if let Ok(Ok((_batch, meta))) = result {
                let _batch_empty = RecordBatch::new_empty(Arc::new(
                    Schema::new(Vec::<Field>::new()),
                ));
                // At minimum, verify we can read metadata from this file
                assert!(!meta.variable_names.is_empty());
            }
        }
    }

    #[test]
    fn test_write_with_value_labels() {
        let schema = Arc::new(Schema::new(vec![
            Field::new("gender", DataType::Float64, true),
        ]));
        let mut builder = Float64Builder::new();
        builder.append_value(1.0);
        builder.append_value(2.0);
        builder.append_value(1.0);
        let batch = RecordBatch::try_new(schema, vec![Arc::new(builder.finish())]).unwrap();

        let mut meta = SpssMetadata::from_arrow_schema(batch.schema().as_ref());
        let mut labels = IndexMap::new();
        labels.insert(Value::Numeric(1.0), "Male".to_string());
        labels.insert(Value::Numeric(2.0), "Female".to_string());
        meta.variable_value_labels
            .insert("gender".to_string(), labels);
        meta.variable_labels
            .insert("gender".to_string(), "Respondent gender".to_string());

        let mut cursor = Cursor::new(Vec::new());
        write_sav_to_writer(&mut cursor, &batch, &meta, Compression::None).unwrap();

        let reader = Cursor::new(cursor.into_inner());
        let (batch2, meta2) = crate::read_sav_from_reader(reader).unwrap();

        assert_eq!(batch2.num_rows(), 3);
        // Verify value labels survived
        let gender_labels = meta2.variable_value_labels.get("gender");
        assert!(gender_labels.is_some(), "value labels missing");
        let labels = gender_labels.unwrap();
        assert_eq!(labels.len(), 2);
        assert_eq!(
            labels.get(&Value::Numeric(1.0)),
            Some(&"Male".to_string())
        );
        // Verify variable label survived
        assert_eq!(
            meta2.variable_labels.get("gender"),
            Some(&"Respondent gender".to_string())
        );
    }

    #[test]
    fn test_write_numeric_data_accuracy() {
        let schema = Arc::new(Schema::new(vec![
            Field::new("x", DataType::Float64, true),
        ]));
        let values = vec![0.0, 1.0, -1.0, 3.14159, 1e10, -1e10, 0.001];
        let mut builder = Float64Builder::new();
        for &v in &values {
            builder.append_value(v);
        }
        let batch = RecordBatch::try_new(schema, vec![Arc::new(builder.finish())]).unwrap();
        let meta = SpssMetadata::from_arrow_schema(batch.schema().as_ref());

        let mut cursor = Cursor::new(Vec::new());
        write_sav_to_writer(&mut cursor, &batch, &meta, Compression::None).unwrap();

        let reader = Cursor::new(cursor.into_inner());
        let (batch2, _) = crate::read_sav_from_reader(reader).unwrap();

        let col = batch2
            .column(0)
            .as_any()
            .downcast_ref::<Float64Array>()
            .unwrap();
        for (i, &expected) in values.iter().enumerate() {
            let actual = col.value(i);
            assert!(
                (actual - expected).abs() < 1e-15,
                "row {i}: expected {expected}, got {actual}"
            );
        }
    }

    // -----------------------------------------------------------------------
    // Bytecode compression tests
    // -----------------------------------------------------------------------

    #[test]
    fn test_bytecode_write_and_read_back() {
        let batch = make_simple_batch();
        let meta = SpssMetadata::from_arrow_schema(batch.schema().as_ref());

        let mut cursor = Cursor::new(Vec::new());
        write_sav_to_writer(&mut cursor, &batch, &meta, Compression::Bytecode).unwrap();

        let reader = Cursor::new(cursor.into_inner());
        let (batch2, meta2) = crate::read_sav_from_reader(reader).unwrap();

        assert_eq!(batch2.num_rows(), 3);
        assert_eq!(batch2.num_columns(), 2);
        assert_eq!(meta2.variable_names.len(), 2);
        assert_eq!(meta2.compression, Compression::Bytecode);
    }

    #[test]
    fn test_bytecode_numeric_accuracy() {
        let schema = Arc::new(Schema::new(vec![
            Field::new("x", DataType::Float64, true),
        ]));
        let values = vec![0.0, 1.0, -1.0, 3.14159, 1e10, -1e10, 0.001, -99.0, 42.0, 151.0];
        let mut builder = Float64Builder::new();
        for &v in &values {
            builder.append_value(v);
        }
        let batch = RecordBatch::try_new(schema, vec![Arc::new(builder.finish())]).unwrap();
        let meta = SpssMetadata::from_arrow_schema(batch.schema().as_ref());

        let mut cursor = Cursor::new(Vec::new());
        write_sav_to_writer(&mut cursor, &batch, &meta, Compression::Bytecode).unwrap();

        let reader = Cursor::new(cursor.into_inner());
        let (batch2, _) = crate::read_sav_from_reader(reader).unwrap();

        let col = batch2
            .column(0)
            .as_any()
            .downcast_ref::<Float64Array>()
            .unwrap();
        for (i, &expected) in values.iter().enumerate() {
            let actual = col.value(i);
            assert!(
                (actual - expected).abs() < 1e-15,
                "row {i}: expected {expected}, got {actual}"
            );
        }
    }

    #[test]
    fn test_bytecode_with_nulls() {
        let schema = Arc::new(Schema::new(vec![
            Field::new("a", DataType::Float64, true),
            Field::new("b", DataType::Utf8, true),
        ]));
        let mut a_builder = Float64Builder::new();
        a_builder.append_value(1.0);
        a_builder.append_null();
        a_builder.append_value(3.0);
        a_builder.append_null();
        let mut b_builder = StringBuilder::new();
        b_builder.append_value("hello");
        b_builder.append_null();
        b_builder.append_null();
        b_builder.append_value("world");

        let batch = RecordBatch::try_new(
            schema,
            vec![Arc::new(a_builder.finish()), Arc::new(b_builder.finish())],
        )
        .unwrap();
        let meta = SpssMetadata::from_arrow_schema(batch.schema().as_ref());

        let mut cursor = Cursor::new(Vec::new());
        write_sav_to_writer(&mut cursor, &batch, &meta, Compression::Bytecode).unwrap();

        let reader = Cursor::new(cursor.into_inner());
        let (batch2, _) = crate::read_sav_from_reader(reader).unwrap();

        assert_eq!(batch2.num_rows(), 4);
        let col_a = batch2
            .column(0)
            .as_any()
            .downcast_ref::<Float64Array>()
            .unwrap();
        assert!(!col_a.is_null(0));
        assert!(col_a.is_null(1));
        assert!(!col_a.is_null(2));
        assert!(col_a.is_null(3));
    }

    #[test]
    fn test_bytecode_with_value_labels() {
        let schema = Arc::new(Schema::new(vec![
            Field::new("gender", DataType::Float64, true),
        ]));
        let mut builder = Float64Builder::new();
        builder.append_value(1.0);
        builder.append_value(2.0);
        builder.append_value(1.0);
        let batch = RecordBatch::try_new(schema, vec![Arc::new(builder.finish())]).unwrap();

        let mut meta = SpssMetadata::from_arrow_schema(batch.schema().as_ref());
        let mut labels = IndexMap::new();
        labels.insert(Value::Numeric(1.0), "Male".to_string());
        labels.insert(Value::Numeric(2.0), "Female".to_string());
        meta.variable_value_labels
            .insert("gender".to_string(), labels);

        let mut cursor = Cursor::new(Vec::new());
        write_sav_to_writer(&mut cursor, &batch, &meta, Compression::Bytecode).unwrap();

        let reader = Cursor::new(cursor.into_inner());
        let (batch2, meta2) = crate::read_sav_from_reader(reader).unwrap();

        assert_eq!(batch2.num_rows(), 3);
        let gender_labels = meta2.variable_value_labels.get("gender").unwrap();
        assert_eq!(gender_labels.len(), 2);
        assert_eq!(
            gender_labels.get(&Value::Numeric(1.0)),
            Some(&"Male".to_string())
        );
    }

    #[test]
    fn test_bytecode_smaller_than_uncompressed() {
        // Bytecode should produce smaller output for typical data
        let schema = Arc::new(Schema::new(vec![
            Field::new("x", DataType::Float64, true),
        ]));
        let mut builder = Float64Builder::new();
        // Many small integers that will compress to 1-byte opcodes
        for i in 0..100 {
            builder.append_value((i % 50) as f64);
        }
        let batch = RecordBatch::try_new(schema, vec![Arc::new(builder.finish())]).unwrap();
        let meta = SpssMetadata::from_arrow_schema(batch.schema().as_ref());

        let mut c_none = Cursor::new(Vec::new());
        write_sav_to_writer(&mut c_none, &batch, &meta, Compression::None).unwrap();

        let mut c_bytecode = Cursor::new(Vec::new());
        write_sav_to_writer(&mut c_bytecode, &batch, &meta, Compression::Bytecode).unwrap();

        let len_none = c_none.into_inner().len();
        let len_bytecode = c_bytecode.into_inner().len();
        assert!(
            len_bytecode < len_none,
            "bytecode ({len_bytecode}) should be smaller than uncompressed ({len_none})",
        );
    }

    /// Helper: read a real file, write as bytecode, read back, compare shapes + data.
    fn roundtrip_file_bytecode(path: &str) {
        let (batch, meta) = crate::read_sav(path).unwrap();
        let orig_rows = batch.num_rows();
        let orig_cols = batch.num_columns();

        let mut cursor = Cursor::new(Vec::new());
        write_sav_to_writer(&mut cursor, &batch, &meta, Compression::Bytecode).unwrap();

        let reader = Cursor::new(cursor.into_inner());
        let (batch2, meta2) = crate::read_sav_from_reader(reader).unwrap();

        assert_eq!(
            batch2.num_rows(),
            orig_rows,
            "row count mismatch for {path}"
        );
        assert_eq!(
            batch2.num_columns(),
            orig_cols,
            "column count mismatch for {path}"
        );
        assert_eq!(
            meta2.variable_names.len(),
            meta.variable_names.len(),
            "variable name count mismatch for {path}"
        );
        assert_eq!(
            meta2.compression,
            Compression::Bytecode,
            "compression should be bytecode for {path}"
        );

        // Verify null counts match for first 5 columns
        for col_idx in 0..orig_cols.min(5) {
            let col1 = batch.column(col_idx);
            let col2 = batch2.column(col_idx);
            assert_eq!(
                col1.null_count(),
                col2.null_count(),
                "null count mismatch for column {} in {path}",
                col_idx,
            );
        }
    }

    #[test]
    fn test_bytecode_roundtrip_test1_small() {
        let path = "test_data/test_1_small.sav";
        if std::path::Path::new(path).exists() {
            roundtrip_file_bytecode(path);
        }
    }

    #[test]
    fn test_bytecode_roundtrip_test4_small() {
        let path = "test_data/test_4_small.sav";
        if std::path::Path::new(path).exists() {
            roundtrip_file_bytecode(path);
        }
    }

    #[test]
    fn test_bytecode_roundtrip_test5_small() {
        let path = "test_data/test_5_small.sav";
        if std::path::Path::new(path).exists() {
            roundtrip_file_bytecode(path);
        }
    }

    #[test]
    fn test_bytecode_roundtrip_test7_nulls() {
        let path = "test_data/test7_null_column.sav";
        if std::path::Path::new(path).exists() {
            roundtrip_file_bytecode(path);
        }
    }

    // -----------------------------------------------------------------------
    // Zlib/ZSAV compression tests
    // -----------------------------------------------------------------------

    #[test]
    fn test_zsav_write_and_read_back() {
        let batch = make_simple_batch();
        let meta = SpssMetadata::from_arrow_schema(batch.schema().as_ref());

        let mut cursor = Cursor::new(Vec::new());
        write_sav_to_writer(&mut cursor, &batch, &meta, Compression::Zlib).unwrap();

        let reader = Cursor::new(cursor.into_inner());
        let (batch2, meta2) = crate::read_sav_from_reader(reader).unwrap();

        assert_eq!(batch2.num_rows(), 3);
        assert_eq!(batch2.num_columns(), 2);
        assert_eq!(meta2.variable_names.len(), 2);
        assert_eq!(meta2.compression, Compression::Zlib);
    }

    #[test]
    fn test_zsav_numeric_accuracy() {
        let schema = Arc::new(Schema::new(vec![
            Field::new("x", DataType::Float64, true),
        ]));
        let values = vec![0.0, 1.0, -1.0, 3.14159, 1e10, -1e10, 0.001, -99.0, 42.0, 151.0];
        let mut builder = Float64Builder::new();
        for &v in &values {
            builder.append_value(v);
        }
        let batch = RecordBatch::try_new(schema, vec![Arc::new(builder.finish())]).unwrap();
        let meta = SpssMetadata::from_arrow_schema(batch.schema().as_ref());

        let mut cursor = Cursor::new(Vec::new());
        write_sav_to_writer(&mut cursor, &batch, &meta, Compression::Zlib).unwrap();

        let reader = Cursor::new(cursor.into_inner());
        let (batch2, _) = crate::read_sav_from_reader(reader).unwrap();

        let col = batch2
            .column(0)
            .as_any()
            .downcast_ref::<Float64Array>()
            .unwrap();
        for (i, &expected) in values.iter().enumerate() {
            let actual = col.value(i);
            assert!(
                (actual - expected).abs() < 1e-15,
                "row {i}: expected {expected}, got {actual}"
            );
        }
    }

    #[test]
    fn test_zsav_with_nulls() {
        let schema = Arc::new(Schema::new(vec![
            Field::new("a", DataType::Float64, true),
            Field::new("b", DataType::Utf8, true),
        ]));
        let mut a_builder = Float64Builder::new();
        a_builder.append_value(1.0);
        a_builder.append_null();
        a_builder.append_value(3.0);
        a_builder.append_null();
        let mut b_builder = StringBuilder::new();
        b_builder.append_value("hello");
        b_builder.append_null();
        b_builder.append_null();
        b_builder.append_value("world");

        let batch = RecordBatch::try_new(
            schema,
            vec![Arc::new(a_builder.finish()), Arc::new(b_builder.finish())],
        )
        .unwrap();
        let meta = SpssMetadata::from_arrow_schema(batch.schema().as_ref());

        let mut cursor = Cursor::new(Vec::new());
        write_sav_to_writer(&mut cursor, &batch, &meta, Compression::Zlib).unwrap();

        let reader = Cursor::new(cursor.into_inner());
        let (batch2, _) = crate::read_sav_from_reader(reader).unwrap();

        assert_eq!(batch2.num_rows(), 4);
        let col_a = batch2
            .column(0)
            .as_any()
            .downcast_ref::<Float64Array>()
            .unwrap();
        assert!(!col_a.is_null(0));
        assert!(col_a.is_null(1));
        assert!(!col_a.is_null(2));
        assert!(col_a.is_null(3));
    }

    #[test]
    fn test_zsav_smaller_than_uncompressed() {
        let schema = Arc::new(Schema::new(vec![
            Field::new("x", DataType::Float64, true),
        ]));
        let mut builder = Float64Builder::new();
        for i in 0..100 {
            builder.append_value((i % 50) as f64);
        }
        let batch = RecordBatch::try_new(schema, vec![Arc::new(builder.finish())]).unwrap();
        let meta = SpssMetadata::from_arrow_schema(batch.schema().as_ref());

        let mut c_none = Cursor::new(Vec::new());
        write_sav_to_writer(&mut c_none, &batch, &meta, Compression::None).unwrap();

        let mut c_zlib = Cursor::new(Vec::new());
        write_sav_to_writer(&mut c_zlib, &batch, &meta, Compression::Zlib).unwrap();

        let len_none = c_none.into_inner().len();
        let len_zlib = c_zlib.into_inner().len();
        assert!(
            len_zlib < len_none,
            "zsav ({len_zlib}) should be smaller than uncompressed ({len_none})",
        );
    }

    /// Helper: read a real file, write as zsav, read back, compare.
    fn roundtrip_file_zsav(path: &str) {
        let (batch, meta) = crate::read_sav(path).unwrap();
        let orig_rows = batch.num_rows();
        let orig_cols = batch.num_columns();

        let mut cursor = Cursor::new(Vec::new());
        write_sav_to_writer(&mut cursor, &batch, &meta, Compression::Zlib).unwrap();

        let reader = Cursor::new(cursor.into_inner());
        let (batch2, meta2) = crate::read_sav_from_reader(reader).unwrap();

        assert_eq!(
            batch2.num_rows(),
            orig_rows,
            "row count mismatch for {path}"
        );
        assert_eq!(
            batch2.num_columns(),
            orig_cols,
            "column count mismatch for {path}"
        );
        assert_eq!(
            meta2.variable_names.len(),
            meta.variable_names.len(),
            "variable name count mismatch for {path}"
        );
        assert_eq!(
            meta2.compression,
            Compression::Zlib,
            "compression should be zlib for {path}"
        );

        for col_idx in 0..orig_cols.min(5) {
            let col1 = batch.column(col_idx);
            let col2 = batch2.column(col_idx);
            assert_eq!(
                col1.null_count(),
                col2.null_count(),
                "null count mismatch for column {} in {path}",
                col_idx,
            );
        }
    }

    #[test]
    fn test_zsav_roundtrip_test1_small() {
        let path = "test_data/test_1_small.sav";
        if std::path::Path::new(path).exists() {
            roundtrip_file_zsav(path);
        }
    }

    #[test]
    fn test_zsav_roundtrip_test4_small() {
        let path = "test_data/test_4_small.sav";
        if std::path::Path::new(path).exists() {
            roundtrip_file_zsav(path);
        }
    }

    #[test]
    fn test_zsav_roundtrip_test5_small() {
        let path = "test_data/test_5_small.sav";
        if std::path::Path::new(path).exists() {
            roundtrip_file_zsav(path);
        }
    }

    #[test]
    fn test_zsav_roundtrip_test7_nulls() {
        let path = "test_data/test7_null_column.sav";
        if std::path::Path::new(path).exists() {
            roundtrip_file_zsav(path);
        }
    }

    // -----------------------------------------------------------------------
    // Medium file round-trip tests (streaming validation)
    // -----------------------------------------------------------------------

    #[test]
    fn test_roundtrip_test2_medium() {
        let path = "test_data/test_2_medium.sav";
        if std::path::Path::new(path).exists() {
            roundtrip_file(path);
        }
    }

    #[test]
    fn test_bytecode_roundtrip_test2_medium() {
        let path = "test_data/test_2_medium.sav";
        if std::path::Path::new(path).exists() {
            roundtrip_file_bytecode(path);
        }
    }

    #[test]
    fn test_zsav_roundtrip_test2_medium() {
        let path = "test_data/test_2_medium.sav";
        if std::path::Path::new(path).exists() {
            roundtrip_file_zsav(path);
        }
    }

    // -----------------------------------------------------------------------
    // Large file round-trip tests (VLS segment correctness)
    // -----------------------------------------------------------------------

    #[test]
    fn test_roundtrip_test3_large() {
        let path = "test_data/test_3_medium.sav";
        if std::path::Path::new(path).exists() {
            roundtrip_file(path);
        }
    }

    #[test]
    fn test_bytecode_roundtrip_test3_large() {
        let path = "test_data/test_3_medium.sav";
        if std::path::Path::new(path).exists() {
            roundtrip_file_bytecode(path);
        }
    }

    #[test]
    fn test_zsav_roundtrip_test3_large() {
        let path = "test_data/test_3_medium.sav";
        if std::path::Path::new(path).exists() {
            roundtrip_file_zsav(path);
        }
    }

    /// Detailed metadata comparison for VLS-heavy files.
    #[test]
    fn test_roundtrip_test3_metadata() {
        let path = "test_data/test_3_medium.sav";
        if !std::path::Path::new(path).exists() {
            return;
        }

        let (batch, meta) = crate::read_sav(path).unwrap();

        let mut cursor = Cursor::new(Vec::new());
        write_sav_to_writer(&mut cursor, &batch, &meta, Compression::Bytecode).unwrap();

        let reader = Cursor::new(cursor.into_inner());
        let (_batch2, meta2) = crate::read_sav_from_reader(reader).unwrap();

        // Column names must match exactly
        assert_eq!(
            meta.variable_names, meta2.variable_names,
            "variable_names mismatch"
        );

        // Value labels count must match
        assert_eq!(
            meta.variable_value_labels.len(),
            meta2.variable_value_labels.len(),
            "variable_value_labels count mismatch: orig={}, written={}",
            meta.variable_value_labels.len(),
            meta2.variable_value_labels.len(),
        );

        // Each variable's value labels must match
        for (var, labels) in &meta.variable_value_labels {
            let labels2 = meta2.variable_value_labels.get(var);
            assert!(
                labels2.is_some(),
                "missing value labels for variable: {var}"
            );
            assert_eq!(
                labels.len(),
                labels2.unwrap().len(),
                "value label count mismatch for {var}"
            );
        }

        // Variable labels must match
        assert_eq!(
            meta.variable_labels.len(),
            meta2.variable_labels.len(),
            "variable_labels count mismatch"
        );
    }
}
