"""
TimeVault - Time Machine-style personal backup orchestrated by Python & uv.

Snapshot what matters, remember how to rebuild the rest.
"""

__version__ = "0.1.0"
