# FILE TO SET DECAY NAME

sample_decay = 'Bu2JpsiK_ee'
from Configurables import DaVinci
DaVinci().TupleFile=sample_decay
