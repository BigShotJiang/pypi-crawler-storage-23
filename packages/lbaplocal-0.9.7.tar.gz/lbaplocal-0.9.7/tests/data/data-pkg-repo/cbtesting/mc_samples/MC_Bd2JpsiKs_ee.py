# FILE TO SET DECAY NAME

sample_decay = 'Bd2KsJpsee'
from Configurables import DaVinci
DaVinci().TupleFile=sample_decay
