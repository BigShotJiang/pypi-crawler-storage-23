# FILE TO SET DECAY NAME

sample_decay = 'Lb2LJpsmm'
from Configurables import DaVinci
DaVinci().TupleFile=sample_decay
