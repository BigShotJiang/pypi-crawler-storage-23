from Configurables import DaVinci

DaVinci().DataType = '2016'
