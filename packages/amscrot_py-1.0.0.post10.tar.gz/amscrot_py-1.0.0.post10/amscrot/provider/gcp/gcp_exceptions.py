from amscrot.exceptions import AmSCROTException


class GcpException(AmSCROTException):
    """Base class for other exceptions"""
    pass
