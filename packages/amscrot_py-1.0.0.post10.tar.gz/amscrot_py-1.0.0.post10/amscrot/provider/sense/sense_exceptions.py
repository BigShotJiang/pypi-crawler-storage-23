from amscrot.exceptions import AmSCROTException


class SenseException(AmSCROTException):
    """Base class for other exceptions"""
    pass
