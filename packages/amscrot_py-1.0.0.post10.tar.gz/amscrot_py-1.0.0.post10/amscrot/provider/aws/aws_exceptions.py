from amscrot.exceptions import AmSCROTException


class AwsException(AmSCROTException):
    """Base class for other exceptions"""
    pass
