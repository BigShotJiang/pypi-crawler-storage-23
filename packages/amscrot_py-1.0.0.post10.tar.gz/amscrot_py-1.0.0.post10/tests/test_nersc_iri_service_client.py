import unittest
import pytest
import os
from pathlib import Path
from amscrot.client.job import JobSpec, JobState
from amscrot.serviceclient import ServiceClient, PlanError
from amscrot.util.constants import Constants


# Check if credentials file exists
CREDENTIALS_FILE = os.path.join(str(Path.home()), '.amscrot', 'credentials.yml')
HAS_CREDENTIALS = os.path.exists(CREDENTIALS_FILE)


class TestNerscIriServiceClient(unittest.TestCase):
    """Test NERSC IRI ServiceClient integration."""
    
    @pytest.mark.integration
    @pytest.mark.skipif(not HAS_CREDENTIALS, reason="Requires ~/.amscrot/credentials.yml")
    def test_nersc_iri_job_lifecycle(self):
        """Test the full lifecycle of a NERSC IRI job: plan -> create -> status -> destroy.
        
        This is an integration test that makes real API calls to NERSC IRI.
        It first discovers available compute resources from the API, then uses one to test job submission.
        """
        
        # Create the service client (will load credentials automatically)
        iri_client = ServiceClient.create(
            type=Constants.ServiceType.NERSC_IRI,
            name="nersc-iri-compute",
            profile="nersc-iri"
        )
        
        # Verify client was created successfully
        self.assertIsNotNone(iri_client)
        self.assertTrue(iri_client._available, "NERSC IRI client should be available with valid credentials")
        
        # Discover available compute resources using the client interface
        print("\n--- Discovering Resources ---")
        try:
            # discover() returns a DiscoveryResult container
            all_resources = iri_client.discover()

            # Filter for compute resources using typed accessor
            compute_resources = all_resources.compute
            print(f"Response type: {type(all_resources)}")

            if not compute_resources:
                self.skipTest("No compute resources available.")

            # Locate the compute resource with group "perlmutter" and named "compute"
            target_resource = None
            for resource in compute_resources:
                data = resource.data
                if data.get('group') == 'perlmutter' and data.get('name') == 'compute':
                    target_resource = resource
                    break

            if not target_resource:
                self.skipTest("Target compute resource (perlmutter/compute) not found.")

            resource_data = target_resource.data
            resource_id = resource_data.get('id')
            
            if resource_id:
                print(f"Found target compute resource: {resource_data}")
                print(f"Using resource ID: {resource_id}")
            else:
                self.skipTest("Target compute resource found but ID is missing.")
                
        except Exception as e:
            import traceback
            error_msg = str(e)
            if "401" in error_msg or "403" in error_msg or "Unauthorized" in error_msg or "Forbidden" in error_msg:
                 print(f"Authentication failed (expected if token is invalid): {e}")
                 self.skipTest(f"Skipping test due to authentication failure: {e}")
            
            print(f"Exception details: {traceback.format_exc()}")
            self.skipTest(f"Failed to discover resources: {e}")

        # Create a job spec with resource_id in attributes
        spec = JobSpec(
            executable=["/bin/echo", "Hello AmSC"],
            resources={
                "node_count": 1,
                "process_count": 1,
                "processes_per_node": 1,
                "cpu_cores_per_process": 1,
                "gpu_cores_per_process": None,
                "exclusive_node_use": False,
                "memory": 268435456
            },
            attributes={
                "resource_id": resource_id,
                "directory": "/tmp",
                "duration": 600,
                "queue_name": "debug",
                "account": "amsc013",
                "pre_launch": ""
            }
        )
        
        job_name = "nersc-iri-test-job"
        
        try:
            # 1. Test Plan
            print("\n--- Test Plan ---")
            plan_result = iri_client.plan(spec, job_name)
            print(f"Plan result: {plan_result}")
            self.assertEqual(plan_result["status"], "PLANNED")

            # 2. Test Create (Real API call)
            print("\n--- Test Create ---")
            iri_client.create(spec, job_name)
            
            # Verify job was submitted
            if job_name not in iri_client._submitted_jobs:
                self.skipTest(f"Job '{job_name}' was not submitted (check logs for API errors). Skipping remaining assertions.")
            
            self.assertIn(job_name, iri_client._submitted_jobs)
            tracked_resource_id, job_id = iri_client._submitted_jobs[job_name]
            self.assertIsNotNone(job_id, "Job ID should be returned from API")
            self.assertEqual(tracked_resource_id, resource_id)
            print(f"Job submitted with ID: {job_id}")
            
            print("\n--- Test Status (Polling) ---")
            import time
            max_retries = 300
            for i in range(max_retries):
                status_result = iri_client.status(job_name)
                print(f"Attempt {i+1}/{max_retries}: Status = {status_result.state}")
                
                if status_result.state in [JobState.COMPLETED, JobState.FAILED, JobState.CANCELED]:
                    break
                
                time.sleep(2)

            self.assertEqual(status_result.state, JobState.COMPLETED, f"Job failed or timed out. Details: {status_result.state}")
            print(f"Job completed successfully. Status: {status_result.state}")

            # Verify exit code if available in the raw response
            if status_result.provider_status:
                print(f"Raw IRI response: {status_result.provider_status}")
            self.assertEqual(status_result.job_id, job_id)

        except PlanError as e:
            if any("not available" in err or "credentials" in err.lower() for err in e.errors):
                self.skipTest(f"Skipping test - NERSC IRI client not available: {e}")
            raise

        except Exception as e:
            # If there's an error, print it but still try to clean up
            print(f"\n!!! Test failed with error: {e}")
            raise
            
        finally:
            # 4. Test Destroy (Real API call) - Always try to clean up
            print("\n--- Test Destroy ---")
            try:
                if job_name in iri_client._submitted_jobs:
                    iri_client.destroy(job_name)
                    
                    # Verify job was removed from tracking
                    self.assertNotIn(job_name, iri_client._submitted_jobs)
                    print("Job destroyed successfully")
            except Exception as cleanup_error:
                print(f"Warning: Failed to clean up job: {cleanup_error}")

    
    def test_nersc_iri_client_creation(self):
        """Test NERSC IRI ServiceClient creation."""
        iri_client = ServiceClient.create(
            type=Constants.ServiceType.NERSC_IRI,
            name="test-nersc-iri"
        )
        
        self.assertIsNotNone(iri_client)
        self.assertEqual(iri_client.type, Constants.ServiceType.NERSC_IRI)
        self.assertEqual(iri_client.name, "test-nersc-iri")
        
        # Client may or may not be available depending on credentials
        # Just verify it was created without errors
    
    @pytest.mark.skipif(not HAS_CREDENTIALS, reason="Requires ~/.amscrot/credentials.yml")
    def test_resource_id_extraction(self):
        """Test that resource_id is correctly extracted from JobSpec attributes.
        
        This is a unit test but requires the client to be initialized.
        """
        iri_client = ServiceClient.create(
            type="nersc-iri",
            name="test-nersc-iri",
            profile="nersc-iri"
        )
        
        # Test with resource_id in attributes
        spec = JobSpec(
            executable=["echo", "test"],
            attributes={"resource_id": "custom-resource-id"}
        )
        
        resource_id = iri_client._get_resource_id(spec)
        self.assertEqual(resource_id, "custom-resource-id")


if __name__ == "__main__":
    unittest.main()
