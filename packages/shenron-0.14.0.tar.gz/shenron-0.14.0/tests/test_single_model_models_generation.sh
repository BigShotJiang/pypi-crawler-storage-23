#!/usr/bin/env bash
set -euo pipefail

workdir="$(mktemp -d)"
trap 'rm -rf "$workdir"' EXIT

cat > "$workdir/single-model.yml" <<'YAML'
cuda_version: 126
tensor_parallel_size: 1
shenron_version: latest
onwards_version: latest
engine: sglang
onwards_port: 3000
prometheus_port: 9090
prometheus_version: v2.51.2
scouter_version: latest
scouter_collector_instance: host.docker.internal
scouter_reporter_interval: 10
scouter_ingest_api_key: api-key
sglangmux_listen_port: 8100
models:
- model_name: Qwen/Qwen3-0.6B
  api_key: sk-model-a
  engine_port: 8100
  engine_envs:
  - VLLM_ENABLE_RESPONSES_API_STORE
  - -1
  engine_use_cuda_ipc_transport: true
  engine_args:
  - --tp
  - 2
YAML

shenron "$workdir/single-model.yml" --output-dir "$workdir"

required=(
  "$workdir/docker-compose.yml"
  "$workdir/.generated/onwards_config.json"
  "$workdir/.generated/prometheus.yml"
  "$workdir/.generated/scouter_reporter.env"
  "$workdir/.generated/engine_start.sh"
)

for f in "${required[@]}"; do
  if [ ! -f "$f" ]; then
    echo "expected generated file not found: $f" >&2
    exit 1
  fi
done

for forbidden in "$workdir/.generated/engine_start_1.sh" "$workdir/.generated/sglangmux_start.sh"; do
  if [ -f "$forbidden" ]; then
    echo "unexpected generated file present: $forbidden" >&2
    exit 1
  fi
done

engine_script="$workdir/.generated/engine_start.sh"
onwards="$workdir/.generated/onwards_config.json"
compose="$workdir/docker-compose.yml"
scouter="$workdir/.generated/scouter_reporter.env"

if ! grep -q "sglang.launch_server" "$engine_script"; then
  echo "engine_start.sh missing sglang launch command" >&2
  exit 1
fi

if ! grep -q "Qwen/Qwen3-0.6B" "$engine_script"; then
  echo "engine_start.sh missing model name" >&2
  exit 1
fi

if ! grep -q -- "--port" "$engine_script" || ! grep -q "8100" "$engine_script"; then
  echo "engine_start.sh missing expected model port" >&2
  exit 1
fi

if ! grep -q "SGLANG_USE_CUDA_IPC_TRANSPORT=1" "$engine_script"; then
  echo "engine_start.sh missing CUDA IPC export" >&2
  exit 1
fi

if ! grep -q "VLLM_ENABLE_RESPONSES_API_STORE=-1" "$engine_script"; then
  echo "engine_start.sh missing custom env export" >&2
  exit 1
fi

if ! grep -q "http://vllm:8100/v1" "$onwards"; then
  echo "onwards_config.json missing single-model upstream URL" >&2
  exit 1
fi

if ! grep -q "Qwen/Qwen3-0.6B" "$onwards"; then
  echo "onwards_config.json missing model target" >&2
  exit 1
fi

if ! grep -q "/generated/engine_start.sh" "$compose"; then
  echo "docker-compose.yml missing single engine startup command" >&2
  exit 1
fi

if grep -q "/generated/sglangmux_start.sh" "$compose"; then
  echo "docker-compose.yml should not use mux startup command" >&2
  exit 1
fi

if ! grep -q "MODEL_NAME=Qwen/Qwen3-0.6B" "$scouter"; then
  echo "scouter_reporter.env missing single model name" >&2
  exit 1
fi

echo "single-model models: generation produced single engine startup without mux"
