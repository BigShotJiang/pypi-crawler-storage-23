import os, time, sys, platform

def process(co):
    co = co
    print(co)

def command(jakie="echo ."):
    """Główna funkcja wywoływana jako command()"""
    os.system(jakie)
    
def clear_func():
    """To jest nasza funkcja wewnątrz, która będzie dostępna jako .clear()"""
    if platform.system() == "Windows":
        os.system("cls")
    else:
        os.system("clear")
            
    # Przypisujemy wewnętrzną funkcję do atrybutu głównej funkcji
    command.clear = clear_func

# Uruchamiamy konfigurację
clear_func()