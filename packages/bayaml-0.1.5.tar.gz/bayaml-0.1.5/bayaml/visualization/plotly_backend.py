class PlotlyBackend:
    def available(self) -> bool:
        return True
