from .core import BayamlError


class PluginError(BayamlError):
    pass
