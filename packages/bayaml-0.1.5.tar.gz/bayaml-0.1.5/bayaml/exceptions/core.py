class BayamlError(Exception):
    """Base framework exception."""
