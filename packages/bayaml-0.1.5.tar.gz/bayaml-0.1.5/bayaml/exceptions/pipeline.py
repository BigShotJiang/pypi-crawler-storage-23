from .core import BayamlError


class PipelineError(BayamlError):
    pass
