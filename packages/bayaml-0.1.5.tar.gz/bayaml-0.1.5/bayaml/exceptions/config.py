from .core import BayamlError


class ConfigError(BayamlError):
    pass
