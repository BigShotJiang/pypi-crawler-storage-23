TEMPLATE = "def predict(payload):\n    return payload\n"
