import logging


def stream_handler() -> logging.Handler:
    return logging.StreamHandler()
