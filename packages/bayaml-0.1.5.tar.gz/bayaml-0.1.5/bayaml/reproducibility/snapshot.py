def project_snapshot_hash(path) -> str:
    return "snapshot-stub"
