"""
Version information for Bayaml.

This file is used by Hatch to dynamically determine
the package version during build time.
"""

from __future__ import annotations

__all__ = ["__version__"]

# Follow Semantic Versioning: MAJOR.MINOR.PATCH
__version__ = "0.1.5"
