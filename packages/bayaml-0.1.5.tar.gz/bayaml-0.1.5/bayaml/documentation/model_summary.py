def summarize_model(model) -> str:
    return f"Model: {type(model).__name__}"
