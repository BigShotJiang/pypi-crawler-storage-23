from __future__ import annotations


def visualize_pipeline(steps: list[str]) -> str:
    return " -> ".join(steps)
