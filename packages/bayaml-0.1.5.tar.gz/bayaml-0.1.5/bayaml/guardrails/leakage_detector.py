def detect_leakage(columns: list[str], target: str) -> bool:
    return target in columns
