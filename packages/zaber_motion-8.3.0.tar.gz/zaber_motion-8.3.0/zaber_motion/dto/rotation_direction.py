# This file is generated. Do not modify by hand.
from enum import Enum


class RotationDirection(Enum):
    """
    Direction of rotation.
    """

    CLOCKWISE = 0
    """Rotate in the clockwise direction."""

    COUNTERCLOCKWISE = 1
    """Rotate in the counterclockwise direction."""

    CW = 0
    """Shorthand alias for Clockwise."""

    CCW = 1
    """Shorthand alias for Counterclockwise."""
