# This file is generated. Do not modify by hand.
from enum import Enum


class TriggerAction(Enum):
    """
    Trigger action identifier.
    """

    ALL = 0
    """Refers to all trigger actions."""

    A = 1
    """Action A on a trigger."""

    B = 2
    """Action B on a trigger."""
