# This file is generated. Do not modify by hand.
from enum import Enum


class DeviceType(Enum):

    ANY = 0

    PROCESS_CONTROLLER = 1
