# This file is generated. Do not modify by hand.
from enum import Enum


class AxisMoveType(Enum):

    ABS = 0

    REL = 1

    VEL = 2

    MAX = 3

    MIN = 4

    INDEX = 5
