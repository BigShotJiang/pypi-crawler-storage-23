﻿# ===== THIS FILE IS GENERATED FROM A TEMPLATE ===== #
# ============== DO NOT EDIT DIRECTLY ============== #

from .motion_lib_exception import MotionLibException


class NoValueForKeyException(MotionLibException):
    """
    Thrown when trying to access a key that has not been set.
    """
