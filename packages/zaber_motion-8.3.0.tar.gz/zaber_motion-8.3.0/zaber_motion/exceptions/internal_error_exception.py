﻿# ===== THIS FILE IS GENERATED FROM A TEMPLATE ===== #
# ============== DO NOT EDIT DIRECTLY ============== #

from .motion_lib_exception import MotionLibException


class InternalErrorException(MotionLibException):
    """
    Used for internal error handling. Please report an issue if observed.
    """
