﻿# ===== THIS FILE IS GENERATED FROM A TEMPLATE ===== #
# ============== DO NOT EDIT DIRECTLY ============== #

from .motion_lib_exception import MotionLibException


class IoFailedException(MotionLibException):
    """
    Thrown when the library cannot perform an operation on a file.
    """
