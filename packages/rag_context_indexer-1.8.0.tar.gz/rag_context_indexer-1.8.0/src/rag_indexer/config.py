"""
@RAG_CONTEXT
{
  "archivo": "src/rag_indexer/config.py",
  "lineas": 38,
  "tokens_estimados": 372,
  "hash_contenido": "d5fd5e1e374039d789270d787d3f9ea1281c7b815c3527050299649c5563bd27",
  "creacion": "2026-03-04",
  "modificacion": "2026-03-05",
  "tags": [
    "os",
    "dotenv",
    "load_dotenv"
  ],
  "descripcion_corta": "",
  "descripcion_larga": ""
}
"""
import os
from dotenv import load_dotenv

load_dotenv(os.path.join(os.getcwd(), '.env'))

ACTIVE_LLM = os.environ.get("ACTIVE_LLM", "openai").lower()
USE_CODE_MODEL = os.environ.get("USE_CODE_MODEL", "false").lower() == "true"

API_KEYS = {
    "openai": os.environ.get("OPENAI_API_KEY", ""),
    "anthropic": os.environ.get("ANTHROPIC_API_KEY", ""),
    "gemini": os.environ.get("GEMINI_API_KEY", ""),
    "deepseek": os.environ.get("DEEPSEEK_API_KEY", "")
}

MODELS = {
    "openai": {"default": "gpt-4o-mini", "code": "gpt-4o"},
    "anthropic": {"default": "claude-3-haiku-20240307", "code": "claude-3-5-sonnet-latest"},
    "gemini": {"default": "gemini-2.5-flash", "code": "gemini-2.5-pro"},
    "deepseek": {"default": "deepseek-chat", "code": "deepseek-coder"}
}

DEFAULT_EXCLUDES = {
    '.png', '.jpg', '.jpeg', '.gif', '.ico', '.pdf',
    '.zip', '.tar', '.gz', '.mp4', '.mp3', '.wav',
    '.pyc', '.pyd', '.so', '.dll', '.exe', '.bin'
}

# Extensiones de datos puros: nunca inyectar bloques @RAG_CONTEXT en su interior.
# La información se guarda únicamente en el índice maestro (rag-indexer.json).
DATA_ONLY_EXTENSIONS = {'.json', '.csv', '.lock', '.tsv', '.parquet'}

COMMENT_SYNTAX = {
    '.py':   {'start': '"""\n@RAG_CONTEXT\n', 'end': '\n"""\n'},
    '.js':   {'start': '/*\n@RAG_CONTEXT\n',  'end': '\n*/\n'},
    '.ts':   {'start': '/*\n@RAG_CONTEXT\n',  'end': '\n*/\n'},
    '.jsx':  {'start': '/*\n@RAG_CONTEXT\n',  'end': '\n*/\n'},
    '.tsx':  {'start': '/*\n@RAG_CONTEXT\n',  'end': '\n*/\n'},
    '.css':  {'start': '/*\n@RAG_CONTEXT\n',  'end': '\n*/\n'},
    '.html': {'start': '<!--\n@RAG_CONTEXT\n', 'end': '\n-->\n'},
    '.md':   {'start': '<!--\n@RAG_CONTEXT\n', 'end': '\n-->\n'},
}
