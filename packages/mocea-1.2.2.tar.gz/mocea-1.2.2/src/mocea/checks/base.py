"""Abstract base class for idle detection checks."""

from abc import ABC, abstractmethod


class BaseCheck(ABC):
    """Base class for idle detection checks.

    Each check answers one question: is the system idle from this check's perspective?
    """

    name: str

    def __init__(self, params: dict):
        self.params = params

    @abstractmethod
    def is_idle(self) -> bool:
        """Return True if this check considers the system idle."""
        ...

    @abstractmethod
    def describe(self) -> str:
        """Human-readable status string for display/logging."""
        ...
