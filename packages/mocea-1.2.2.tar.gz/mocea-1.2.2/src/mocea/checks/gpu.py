"""GPU utilization check via nvidia-smi."""

import logging
import shutil
import subprocess

from .base import BaseCheck

log = logging.getLogger(__name__)


class GpuCheck(BaseCheck):
    name = "gpu"

    def __init__(self, params: dict):
        super().__init__(params)
        self.threshold = params.get("threshold", 5.0)
        self._last_util: float | None = None
        self._available = shutil.which("nvidia-smi") is not None
        if not self._available:
            log.debug("nvidia-smi not found, GPU check will always report idle")

    def is_idle(self) -> bool:
        if not self._available:
            return True

        try:
            result = subprocess.run(
                ["nvidia-smi", "--query-gpu=utilization.gpu", "--format=csv,noheader,nounits"],
                capture_output=True,
                text=True,
                timeout=10,
                check=True,
            )
            # Take max across all GPUs
            values = [float(line.strip()) for line in result.stdout.strip().splitlines() if line.strip()]
            self._last_util = max(values) if values else 0.0
        except (subprocess.SubprocessError, ValueError) as exc:
            log.warning("nvidia-smi failed, treating GPU as active: %s", exc)
            self._last_util = None
            return False

        return self._last_util < self.threshold

    def describe(self) -> str:
        if not self._available:
            return "gpu: idle (nvidia-smi not found)"
        if self._last_util is None:
            return "gpu: active (nvidia-smi error)"
        idle = self._last_util < self.threshold
        status = "idle" if idle else "active"
        return f"gpu: {status} ({self._last_util:.1f}% {'<' if idle else '>='} {self.threshold}%)"
