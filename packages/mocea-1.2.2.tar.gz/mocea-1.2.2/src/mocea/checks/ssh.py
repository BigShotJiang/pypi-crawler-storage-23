"""Active SSH session detection check."""

import psutil

from .base import BaseCheck


class SshCheck(BaseCheck):
    name = "ssh"

    def __init__(self, params: dict):
        super().__init__(params)
        self._session_count: int = 0

    def is_idle(self) -> bool:
        self._session_count = 0
        try:
            for conn in psutil.net_connections(kind="tcp"):
                if conn.laddr and conn.laddr.port == 22 and conn.status == "ESTABLISHED":
                    self._session_count += 1
        except psutil.AccessDenied:
            # If we can't read connections, assume not idle (fail safe)
            self._session_count = -1
            return False
        return self._session_count == 0

    def describe(self) -> str:
        if self._session_count < 0:
            return "ssh: active (access denied, assuming not idle)"
        if self._session_count == 0:
            return "ssh: idle (no SSH sessions)"
        return f"ssh: active ({self._session_count} SSH session{'s' if self._session_count != 1 else ''})"
