"""File-based heartbeat check.

Any process can touch the heartbeat file to signal "I'm busy".
If the file is fresh (updated within stale_minutes), the system is NOT idle.
If the file is stale or missing, the system IS idle from this check's perspective.
"""

import time
from pathlib import Path

from .base import BaseCheck


class HeartbeatCheck(BaseCheck):
    name = "heartbeat"

    def __init__(self, params: dict):
        super().__init__(params)
        self.file = Path(params.get("file", "/tmp/mocea-heartbeat"))
        self.stale_minutes = params.get("stale_minutes", 15)
        self._age_seconds: float | None = None

    def is_idle(self) -> bool:
        if not self.file.exists():
            self._age_seconds = None
            return True

        mtime = self.file.stat().st_mtime
        self._age_seconds = time.time() - mtime
        return self._age_seconds > (self.stale_minutes * 60)

    def describe(self) -> str:
        if self._age_seconds is None:
            return f"heartbeat: idle (file not found: {self.file})"
        age_min = self._age_seconds / 60
        idle = self._age_seconds > (self.stale_minutes * 60)
        status = "idle" if idle else "active"
        return f"heartbeat: {status} (age {age_min:.1f}m, stale after {self.stale_minutes}m)"
