"""CPU utilization check."""

import psutil

from .base import BaseCheck


class CpuCheck(BaseCheck):
    name = "cpu"

    def __init__(self, params: dict):
        super().__init__(params)
        self.threshold = params.get("threshold", 5.0)
        self._last_percent: float | None = None

    def is_idle(self) -> bool:
        self._last_percent = psutil.cpu_percent(interval=1)
        return self._last_percent < self.threshold

    def describe(self) -> str:
        if self._last_percent is None:
            return "cpu: not yet sampled"
        idle = self._last_percent < self.threshold
        status = "idle" if idle else "active"
        return f"cpu: {status} ({self._last_percent:.1f}% {'<' if idle else '>='} {self.threshold}%)"
