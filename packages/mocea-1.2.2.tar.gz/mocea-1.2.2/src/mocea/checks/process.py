"""Named process detection check."""

import os

import psutil

from .base import BaseCheck

_OWN_PID = os.getpid()


class ProcessCheck(BaseCheck):
    name = "process"

    def __init__(self, params: dict):
        super().__init__(params)
        self.names: list[str] = params.get("names", [])
        self._matched: list[str] = []

    def is_idle(self) -> bool:
        if not self.names:
            return True

        self._matched = []
        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                if proc.info["pid"] == _OWN_PID:
                    continue
                pname = (proc.info["name"] or "").lower()
                cmdline = [c.lower() for c in (proc.info["cmdline"] or [])]
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

            for target in self.names:
                target_lower = target.lower()
                if target_lower == pname or any(target_lower in c for c in cmdline):
                    self._matched.append(target)
                    break

        return len(self._matched) == 0

    def describe(self) -> str:
        if self._matched:
            return f"process: active (matched: {', '.join(sorted(set(self._matched)))})"
        return f"process: idle (no matching: {', '.join(self.names)})"
