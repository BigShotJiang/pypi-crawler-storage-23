"""Cloud-init user-data template generation."""

from mocea.config import Config

TEMPLATE = """\
#cloud-config
packages:
  - python3-venv

write_files:
  - path: /etc/mocea/config.toml
    content: |
{config_toml}

runcmd:
  - python3 -m venv /opt/mocea
  - /opt/mocea/bin/pip install mocea
  - /opt/mocea/bin/mocea install --config /etc/mocea/config.toml
"""


def generate_cloudinit(config: Config) -> str:
    """Generate cloud-init user-data YAML from a Config object."""
    toml_lines = _config_to_toml(config)
    # Indent for YAML block scalar (6 spaces for content under write_files)
    indented = "\n".join(f"      {line}" for line in toml_lines.splitlines())
    return TEMPLATE.format(config_toml=indented)


def _config_to_toml(config: Config) -> str:
    """Serialize the active config back to TOML format."""
    lines = [
        f"idle_minutes = {config.idle_minutes}",
        f"check_interval = {config.check_interval}",
        f"min_uptime_minutes = {config.min_uptime_minutes}",
        "",
    ]

    for name, cc in config.checks.items():
        lines.append(f"[checks.{name}]")
        lines.append(f"enabled = {'true' if cc.enabled else 'false'}")
        for key, val in cc.params.items():
            lines.append(f"{key} = {_toml_value(val)}")
        lines.append("")

    lines.append("[action]")
    lines.append(f'type = "{config.action_type}"')
    lines.append("")

    lines.append("[logging]")
    lines.append(f'level = "{config.log_level}"')
    if config.log_file:
        lines.append(f'file = "{config.log_file}"')

    return "\n".join(lines)


def _toml_value(val) -> str:
    """Format a Python value as a TOML literal."""
    if isinstance(val, bool):
        return "true" if val else "false"
    if isinstance(val, (int, float)):
        return str(val)
    if isinstance(val, str):
        return f'"{val}"'
    if isinstance(val, list):
        items = ", ".join(f'"{v}"' if isinstance(v, str) else str(v) for v in val)
        return f"[{items}]"
    if val is None:
        return '""'
    return f'"{val}"'
