"""Direct DO API action - snapshot then destroy via pydo."""

import logging
import os
import re
import time
from datetime import datetime

from ..metadata import fetch_metadata
from .base import BaseAction

log = logging.getLogger(__name__)


def _snapshot_base_name(name: str) -> str:
    """Strip DO size suffix and prior timestamp from a droplet name."""
    match = re.search(r"-s-\d+vcpu-", name)
    if match:
        name = name[: match.start()]
    match = re.search(r"-\d{8}-\d{6}", name)
    if match:
        name = name[: match.start()]
    return name


class ApiAction(BaseAction):
    name = "api"

    def __init__(self, params: dict, dry_run: bool = False):
        super().__init__(params, dry_run)
        api_params = params.get("api", {})
        self.snapshot_before_destroy = api_params.get("snapshot_before_destroy", True)
        self._token = os.environ.get("DO_API_TOKEN", "")
        self._meta = None

    def validate(self) -> list[str]:
        warnings = []
        if not self._token:
            warnings.append("DO_API_TOKEN not set. API action will fail without it.")
        try:
            import pydo  # noqa: F401
        except ImportError:
            warnings.append("pydo is not installed. Install with: pip install mocea")
        return warnings

    def _get_droplet_id(self) -> int | None:
        if self._meta is None:
            self._meta = fetch_metadata()
        return self._meta.droplet_id if self._meta else None

    def _get_client(self):
        if not self._token:
            raise RuntimeError("DO_API_TOKEN not set. Required for API action.")

        try:
            from pydo import Client
        except ImportError:
            raise RuntimeError("pydo is not installed. Install with: pip install mocea") from None

        return Client(token=self._token)

    def execute(self) -> None:
        droplet_id = self._get_droplet_id()
        if droplet_id is None:
            raise RuntimeError("Cannot determine droplet ID from metadata API. Not on a DO droplet?")

        if self.dry_run:
            log.warning("DRY RUN: would %s droplet %d via API", self._action_desc(), droplet_id)
            return

        client = self._get_client()

        if self.snapshot_before_destroy:
            self._snapshot_and_destroy(client, droplet_id)
        else:
            self._destroy(client, droplet_id)

    def _action_desc(self) -> str:
        return "snapshot + destroy" if self.snapshot_before_destroy else "destroy"

    def _snapshot_and_destroy(self, client, droplet_id: int) -> None:
        hostname = self._meta.hostname if self._meta else f"droplet-{droplet_id}"
        snapshot_name = f"{_snapshot_base_name(hostname)}-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        log.warning("Creating snapshot %r for droplet %d", snapshot_name, droplet_id)

        client.droplet_actions.post(
            droplet_id=droplet_id,
            body={"type": "snapshot", "name": snapshot_name},
        )

        # Wait for snapshot to complete
        log.info("Waiting for snapshot to complete...")
        for _ in range(120):  # up to 20 minutes
            time.sleep(10)
            actions = client.droplet_actions.list(droplet_id=droplet_id)
            latest = actions["actions"][0] if actions.get("actions") else None
            if latest and latest.get("type") == "snapshot":
                if latest.get("status") == "completed":
                    log.info("Snapshot complete")
                    break
                if latest.get("status") == "errored":
                    raise RuntimeError("Snapshot failed")
        else:
            raise RuntimeError("Snapshot timed out after 20 minutes")

        self._destroy(client, droplet_id)

    def _destroy(self, client, droplet_id: int) -> None:
        log.warning("Destroying droplet %d", droplet_id)
        client.droplets.destroy(droplet_id=droplet_id)
