"""Actions to execute when idle timeout is reached."""

import logging

from .api import ApiAction
from .base import BaseAction
from .shutdown import ShutdownAction

log = logging.getLogger(__name__)

REGISTRY: dict[str, type[BaseAction]] = {
    "shutdown": ShutdownAction,
    "api": ApiAction,
}

_DEFAULT_FALLBACKS: dict[str, list[str]] = {
    "api": ["shutdown"],
    "shutdown": [],
}


class FallbackAction(BaseAction):
    """Wraps a primary action with a chain of fallbacks."""

    def __init__(self, primary: BaseAction, fallbacks: list[BaseAction]):
        super().__init__(primary.params, dry_run=primary.dry_run)
        self.name = primary.name
        self.primary = primary
        self.fallbacks = fallbacks

    def validate(self) -> list[str]:
        return self.primary.validate()

    def execute(self) -> None:
        try:
            self.primary.execute()
            return
        except Exception as exc:
            log.warning("Primary action %r failed (%s), trying fallbacks", self.primary.name, exc)
            log.debug("Primary action traceback:", exc_info=True)

        for fb in self.fallbacks:
            try:
                log.warning("Attempting fallback action: %s", fb.name)
                fb.execute()
                return
            except Exception as exc:
                log.warning("Fallback action %r failed (%s)", fb.name, exc)
                log.debug("Fallback action traceback:", exc_info=True)

        log.critical(
            "All actions failed (primary=%r, fallbacks=%s). Droplet may still be running!",
            self.primary.name,
            [fb.name for fb in self.fallbacks],
        )


def _instantiate(action_type: str, params: dict, dry_run: bool) -> BaseAction:
    """Create a single action instance by type name."""
    cls = REGISTRY.get(action_type)
    if cls is None:
        raise ValueError(f"Unknown action type: {action_type!r}. Available: {list(REGISTRY)}")
    return cls(params, dry_run=dry_run)


def load_action(config) -> BaseAction:
    """Instantiate the configured action, optionally wrapped with fallbacks."""
    primary = _instantiate(config.action_type, config.action_params, config.dry_run)

    # Explicit opt-out
    if config.fallback_action_type == "none":
        return primary

    # Build fallback chain
    if config.fallback_action_type:
        fallback_types = [config.fallback_action_type]
    else:
        fallback_types = _DEFAULT_FALLBACKS.get(config.action_type, [])

    if not fallback_types:
        return primary

    fallbacks = []
    for ft in fallback_types:
        try:
            fallbacks.append(_instantiate(ft, config.action_params, config.dry_run))
        except ValueError:
            log.warning("Unknown fallback action type %r, skipping", ft)

    if fallbacks:
        return FallbackAction(primary, fallbacks)
    return primary
