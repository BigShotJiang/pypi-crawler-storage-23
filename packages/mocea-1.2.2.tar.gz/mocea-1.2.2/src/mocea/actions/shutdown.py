"""Simple shutdown action."""

import logging
import subprocess

from .base import BaseAction

log = logging.getLogger(__name__)


class ShutdownAction(BaseAction):
    name = "shutdown"

    def execute(self) -> None:
        if self.dry_run:
            log.warning("DRY RUN: would execute 'shutdown -h now'")
            return
        log.warning("Executing system shutdown")
        subprocess.run(["shutdown", "-h", "now"], check=True)
