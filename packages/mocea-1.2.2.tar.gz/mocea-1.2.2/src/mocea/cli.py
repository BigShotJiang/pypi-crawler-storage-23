"""mocea CLI - idle droplet terminator."""

import logging
import sys

import click
from rich.console import Console
from rich.table import Table

from mocea import __version__
from mocea.agent import Agent
from mocea.config import Config

log = logging.getLogger(__name__)


def setup_logging(level: str = "INFO", log_file: str | None = None):
    logformat = "[%(asctime)s] %(levelname)s %(name)s: %(message)s"
    handlers: list[logging.Handler] = [logging.StreamHandler(sys.stderr)]
    if log_file:
        handlers.append(logging.FileHandler(log_file))
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format=logformat,
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=handlers,
    )


@click.group(invoke_without_command=True)
@click.version_option(__version__, "--version")
@click.pass_context
def cli(ctx):
    """mocea - idle droplet terminator."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@cli.command()
@click.option("--config", "-c", "config_path", type=click.Path(), help="Config file path")
@click.option("--idle-minutes", type=int, help="Override idle timeout (minutes)")
@click.option("--dry-run", is_flag=True, default=False, help="Log actions but don't execute")
@click.option("--log-level", type=click.Choice(["DEBUG", "INFO", "WARNING"], case_sensitive=False), default=None)
@click.option("-v", "--verbose", count=True, help="Increase verbosity (-v INFO, -vv DEBUG)")
def run(config_path, idle_minutes, dry_run, log_level, verbose):
    """Start the monitoring agent."""
    config = Config.load(config_path, idle_minutes=idle_minutes, dry_run=dry_run)
    if log_level:
        level = log_level
    elif verbose >= 2:
        level = "DEBUG"
    elif verbose == 1:
        level = "INFO"
    else:
        level = config.log_level
    setup_logging(level, log_file=config.log_file)
    agent = Agent(config)
    agent.run()


@cli.command()
@click.option("--config", "-c", "config_path", type=click.Path(), help="Config file path")
def check(config_path):
    """Run all checks once and display results."""
    setup_logging("WARNING")
    config = Config.load(config_path)
    agent = Agent(config)

    console = Console()
    table = Table(title="mocea check results", show_header=True)
    table.add_column("Check", style="bold")
    table.add_column("Status")
    table.add_column("Details")

    results = agent.run_once()
    descriptions = agent.describe_checks()

    for (name, idle), desc in zip(results.items(), descriptions, strict=True):
        status = "[green]idle[/green]" if idle else "[red]active[/red]"
        detail = desc.split("(", 1)[1].rstrip(")") if "(" in desc else ""
        table.add_row(name, status, detail)

    console.print(table)

    all_idle = all(results.values())
    if all_idle:
        console.print("\n[green]All checks report idle.[/green]")
    else:
        active = [n for n, idle in results.items() if not idle]
        console.print(f"\n[yellow]Active checks: {', '.join(active)}[/yellow]")


@cli.command()
@click.option("--user", is_flag=True, default=False, help="Show user service instead of system")
@click.option("--config", "-c", "config_path", type=click.Path(), help="Config file path")
def status(user, config_path):
    """Show agent status and current check results."""
    from mocea.install import service_status

    setup_logging("WARNING")
    console = Console()

    svc_status = service_status(user=user)
    if svc_status:
        console.print("[bold]Service status:[/bold]")
        console.print(svc_status)
    else:
        console.print("[dim]mocea.service not installed[/dim]")

    console.print()
    config = Config.load(config_path)
    agent = Agent(config)

    results = agent.run_once()
    descriptions = agent.describe_checks()

    table = Table(title="Current check results", show_header=True)
    table.add_column("Check", style="bold")
    table.add_column("Status")
    table.add_column("Details")

    for (name, idle), desc in zip(results.items(), descriptions, strict=True):
        st = "[green]idle[/green]" if idle else "[red]active[/red]"
        detail = desc.split("(", 1)[1].rstrip(")") if "(" in desc else ""
        table.add_row(name, st, detail)

    console.print(table)


@cli.command("config")
@click.option("--config", "-c", "config_path", type=click.Path(), help="Config file path")
def show_config(config_path):
    """Show active configuration."""
    setup_logging("WARNING")
    config = Config.load(config_path)
    console = Console()

    console.print("[bold]General[/bold]")
    console.print(f"  idle_minutes:      {config.idle_minutes}")
    console.print(f"  check_interval:    {config.check_interval}s")
    console.print(f"  min_uptime_minutes:{config.min_uptime_minutes}")
    console.print(f"  dry_run:           {config.dry_run}")
    console.print()

    console.print("[bold]Action[/bold]")
    console.print(f"  type: {config.action_type}")
    console.print()

    console.print("[bold]Logging[/bold]")
    console.print(f"  level: {config.log_level}")
    console.print(f"  file:  {config.log_file or '(stderr only)'}")
    console.print()

    table = Table(title="Checks", show_header=True)
    table.add_column("Check", style="bold")
    table.add_column("Enabled")
    table.add_column("Parameters")

    for name, cc in config.checks.items():
        enabled = "[green]yes[/green]" if cc.enabled else "[dim]no[/dim]"
        params = ", ".join(f"{k}={v}" for k, v in cc.params.items()) if cc.params else ""
        table.add_row(name, enabled, params)

    console.print(table)


@cli.command()
@click.option("--config", "-c", "config_path", type=click.Path(), help="Config file path")
def cloudinit(config_path):
    """Generate cloud-init user-data for bootstrapping mocea on a droplet."""
    from mocea.cloudinit import generate_cloudinit

    config = Config.load(config_path)
    click.echo(generate_cloudinit(config))


@cli.command()
@click.option("--user", is_flag=True, default=False, help="Install as user service instead of system")
@click.option("--env-file", type=click.Path(), help="Path to environment file (e.g., /etc/mocea/env)")
def install(user, env_file):
    """Install mocea as a systemd service."""
    from mocea.install import install_service

    setup_logging("INFO")
    path = install_service(user=user, env_file=env_file)
    click.echo(f"Installed and started {path}")


@cli.command()
@click.option("--user", is_flag=True, default=False, help="Remove user service instead of system")
def uninstall(user):
    """Remove mocea systemd service."""
    from mocea.install import uninstall_service

    setup_logging("INFO")
    uninstall_service(user=user)
    click.echo("mocea service uninstalled")
