"""Main agent loop: check idle status, track duration, trigger action."""

import atexit
import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path

import psutil

from .actions import load_action
from .checks import load_checks
from .config import Config

log = logging.getLogger(__name__)

LOCK_FILE = Path("/var/run/mocea.lock")
LOCK_FILE_FALLBACK = Path("/tmp/mocea.lock")


class Agent:
    def __init__(self, config: Config):
        self.config = config
        self.checks = load_checks(config)
        self.action = load_action(config)
        self.idle_since: datetime | None = None
        self._boot_time: datetime = datetime.fromtimestamp(psutil.boot_time(), tz=timezone.utc)

        if not self.checks:
            raise RuntimeError("No checks enabled. Enable at least one check in config.")

        self._validate_action()

    def run(self) -> None:
        """Main loop: check, track idle duration, act."""
        self._acquire_lock()

        check_names = ", ".join(c.name for c in self.checks)
        log.info("Starting mocea agent")
        log.info("Checks: %s", check_names)
        log.info("Idle timeout: %d minutes", self.config.idle_minutes)
        log.info("Min uptime: %d minutes", self.config.min_uptime_minutes)
        log.info("Check interval: %ds", self.config.check_interval)
        if self.config.dry_run:
            log.info("DRY RUN mode enabled")

        while True:
            # Safety: don't terminate too soon after boot
            if not self._uptime_sufficient():
                time.sleep(self.config.check_interval)
                continue

            all_idle = self._evaluate_checks()

            if all_idle:
                if self.idle_since is None:
                    self.idle_since = datetime.now(timezone.utc)
                    log.info("System appears idle, starting countdown")

                elapsed = (datetime.now(timezone.utc) - self.idle_since).total_seconds()
                remaining = (self.config.idle_minutes * 60) - elapsed

                if remaining <= 0:
                    log.warning("Idle for %dm, executing action: %s", self.config.idle_minutes, self.action.name)
                    self.action.execute()
                    break
                else:
                    log.info("Idle for %ds, %ds until action", int(elapsed), int(remaining))
            else:
                if self.idle_since is not None:
                    log.info("Activity detected, resetting idle timer")
                self.idle_since = None

            time.sleep(self.config.check_interval)

    def run_once(self) -> dict[str, bool]:
        """Single check pass. Returns {check_name: is_idle}."""
        return {check.name: check.is_idle() for check in self.checks}

    def describe_checks(self) -> list[str]:
        """Run all checks and return human-readable descriptions."""
        for check in self.checks:
            check.is_idle()
        return [check.describe() for check in self.checks]

    def _evaluate_checks(self) -> bool:
        """Run all checks, log results, return True if ALL idle."""
        results = {}
        for check in self.checks:
            try:
                results[check.name] = check.is_idle()
            except Exception:
                log.exception("Check %s failed, treating as active (fail-safe)", check.name)
                results[check.name] = False

        for check in self.checks:
            log.debug("%s", check.describe())

        return all(results.values())

    def _validate_action(self) -> None:
        """Log warnings from action validation (never prevents startup)."""
        for warning in self.action.validate():
            log.warning("Action validation: %s", warning)

        fallbacks = getattr(self.action, "fallbacks", None)
        if fallbacks:
            for fb in fallbacks:
                for warning in fb.validate():
                    log.info("Fallback %r validation: %s", fb.name, warning)

    def _uptime_sufficient(self) -> bool:
        """Return True if system has been up long enough."""
        uptime_seconds = (datetime.now(timezone.utc) - self._boot_time).total_seconds()
        required = self.config.min_uptime_minutes * 60
        if uptime_seconds < required:
            remaining = int(required - uptime_seconds)
            log.debug("Minimum uptime not reached (%ds remaining), skipping checks", remaining)
            return False
        return True

    def _acquire_lock(self) -> None:
        """Create a PID lock file to prevent multiple instances."""
        lock_path = LOCK_FILE if _can_write(LOCK_FILE.parent) else LOCK_FILE_FALLBACK

        if lock_path.exists():
            try:
                old_pid = int(lock_path.read_text().strip())
                if psutil.pid_exists(old_pid):
                    raise RuntimeError(f"Another mocea instance is running (PID {old_pid}, lock: {lock_path})")
                log.warning("Stale lock file found (PID %d not running), removing", old_pid)
            except ValueError:
                log.warning("Corrupt lock file, removing")
            lock_path.unlink(missing_ok=True)

        lock_path.write_text(str(os.getpid()))
        atexit.register(lambda: lock_path.unlink(missing_ok=True))
        log.debug("Lock acquired: %s (PID %d)", lock_path, os.getpid())


def _can_write(path: Path) -> bool:
    """Check if we can write to a directory."""
    try:
        return path.exists() and os.access(path, os.W_OK)
    except OSError:
        return False
