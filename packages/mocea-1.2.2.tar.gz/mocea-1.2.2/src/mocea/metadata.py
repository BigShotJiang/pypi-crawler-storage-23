"""DigitalOcean droplet metadata via the link-local metadata API.

Every DO droplet can query http://169.254.169.254/metadata/v1/ for
its own identity without any credentials.
"""

import logging
from dataclasses import dataclass
from urllib.error import URLError
from urllib.request import Request, urlopen

log = logging.getLogger(__name__)

METADATA_BASE = "http://169.254.169.254/metadata/v1"
TIMEOUT = 3  # seconds


@dataclass(frozen=True)
class DropletMeta:
    droplet_id: int
    hostname: str
    region: str


def fetch_metadata() -> DropletMeta | None:
    """Query the DO metadata API and return droplet info, or None if unavailable."""
    try:
        droplet_id = int(_get(f"{METADATA_BASE}/id"))
        hostname = _get(f"{METADATA_BASE}/hostname")
        region = _get(f"{METADATA_BASE}/region")
    except (URLError, OSError, ValueError) as exc:
        log.warning("Could not fetch DO metadata (not on a droplet?): %s", exc)
        return None

    meta = DropletMeta(droplet_id=droplet_id, hostname=hostname, region=region)
    log.info("Droplet: id=%d hostname=%s region=%s", meta.droplet_id, meta.hostname, meta.region)
    return meta


def _get(url: str) -> str:
    """GET a metadata endpoint, return stripped text."""
    req = Request(url, headers={"Metadata-Token": "true"})
    with urlopen(req, timeout=TIMEOUT) as resp:
        return resp.read().decode().strip()
