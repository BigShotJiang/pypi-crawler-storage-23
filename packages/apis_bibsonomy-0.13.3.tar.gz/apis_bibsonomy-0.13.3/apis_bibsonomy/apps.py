from django.apps import AppConfig


class EntitiesConfig(AppConfig):
    default_auto_field = "django.db.models.AutoField"
    name = "apis_bibsonomy"
