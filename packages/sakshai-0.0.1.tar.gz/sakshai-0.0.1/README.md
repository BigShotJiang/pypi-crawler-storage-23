# Sakshai

Formal verification for AI outputs.

https://saksh.ai
