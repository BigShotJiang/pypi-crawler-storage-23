"""Sakshai — Formal verification for AI outputs."""

__version__ = "0.0.1"
