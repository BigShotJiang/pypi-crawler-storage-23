"""Deprecated: Use voicerun_completions request types instead."""

from typing import Any, Dict, Literal, Optional, TypeAlias, Union
from enum import StrEnum
from dataclasses import dataclass

from .messages import ConversationHistory
from .cache import CacheBreakpoint


class CompletionsProvider(StrEnum):
    """Deprecated: Use voicerun_completions instead."""
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    GOOGLE = "google"
    VERTEX_ANTHROPIC = "vertex_anthropic"


@dataclass
class FunctionDefinition:
    """Deprecated: Use voicerun_completions instead."""
    name: str
    description: str
    parameters: Dict[str, Any]
    strict: Optional[bool] = None

    @classmethod
    def deserialize(cls, data: dict) -> "FunctionDefinition":
        return cls(
            name=data["name"],
            description=data["description"],
            parameters=data["parameters"],
            strict=data.get("strict", None),
        )


@dataclass
class ToolDefinition:
    """Deprecated: Use voicerun_completions instead."""
    type: Literal["function"]
    function: FunctionDefinition
    cache_breakpoint: Optional[CacheBreakpoint] = None

    @classmethod
    def deserialize(cls, data: dict) -> "ToolDefinition":
        cache_breakpoint = None
        if data.get("cache_breakpoint"):
            cache_breakpoint = CacheBreakpoint.deserialize(data.get("cache_breakpoint"))
        return cls(
            type=data["type"],
            function=FunctionDefinition.deserialize(data["function"]),
            cache_breakpoint=cache_breakpoint,
        )


ToolChoice: TypeAlias = Union[Literal["none", "auto", "required"], str]
"""Deprecated: Use voicerun_completions instead."""


def normalize_tools(tools: list[Union[dict, ToolDefinition]]) -> list[ToolDefinition]:
    """Deprecated: Use voicerun_completions instead."""
    normalized_tools: list[ToolDefinition] = []

    for tool in tools:
        if isinstance(tool, ToolDefinition):
            normalized_tools.append(tool)
        elif isinstance(tool, dict):
            normalized_tools.append(ToolDefinition.deserialize(tool))
        else:
            raise TypeError(f"Tools must be dict or ToolDefinition, got {type(tool)}")

    return normalized_tools


@dataclass
class StreamOptions:
    """Deprecated: Use voicerun_completions instead."""
    stream_sentences: bool = False
    clean_sentences: bool = True
    min_sentence_length: int = 6
    punctuation_marks: Optional[list[str]] = None
    punctuation_language: Optional[str] = None

    @classmethod
    def deserialize(cls, data: dict) -> "StreamOptions":
        return cls(
            stream_sentences=data.get("stream_sentences", False),
            clean_sentences=data.get("clean_sentences", True),
            min_sentence_length=data.get("min_sentence_length", 6),
            punctuation_marks=data.get("punctuation_marks", None),
            punctuation_language=data.get("punctuation_language", None),
        )


@dataclass
class ChatCompletionRequest:
    """Deprecated: Use voicerun_completions instead."""
    provider: CompletionsProvider
    api_key: str
    model: str
    messages: ConversationHistory
    temperature: Optional[float] = None
    tools: Optional[list[ToolDefinition]] = None
    tool_choice: Optional[ToolChoice] = None
    streaming: bool = False
    stream_options: Optional[StreamOptions] = None
    timeout: Optional[float] = None
    max_tokens: Optional[int] = None
    vendor_kwargs: Optional[Dict[str, Any]] = None
