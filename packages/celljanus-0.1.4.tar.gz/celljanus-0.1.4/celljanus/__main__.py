"""Allow running: python -m celljanus"""

from celljanus.cli import main

if __name__ == "__main__":
    main()
