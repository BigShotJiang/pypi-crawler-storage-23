"""ComprehendSDK - main entry point for comprehend.dev telemetry."""

from typing import Union, Optional, Callable, List

from .wire_protocol import CustomMetricSpecification, InitAck, parse_custom_metric_spec
from .websocket_connection import WebSocketConnection
from .span_processor import ComprehendDevSpanProcessor
from .metrics_exporter import ComprehendMetricsExporter

LogFn = Callable[[str], None]


class ComprehendSDK:
    """Main entry point for comprehend.dev telemetry integration.

    Owns a shared WebSocketConnection used by both the span processor
    and the metrics exporter.
    """

    def __init__(
        self,
        organization: str,
        token: str,
        debug: Union[bool, LogFn, None] = None,
    ):
        if debug is True:
            logger = print
        elif callable(debug):
            logger = debug
        else:
            logger = None

        self._custom_metric_listeners: List[Callable[[List[CustomMetricSpecification]], None]] = []
        self._span_processor: Optional[ComprehendDevSpanProcessor] = None
        self._metrics_exporter: Optional[ComprehendMetricsExporter] = None

        self.connection = WebSocketConnection(
            organization=organization,
            token=token,
            logger=logger,
            on_authorized=self._handle_authorized,
            on_custom_metric_change=self._distribute_custom_metrics,
        )

    def _handle_authorized(self, ack: InitAck) -> None:
        raw_specs = ack.customMetrics
        specs = []
        for s in raw_specs:
            if isinstance(s, dict):
                specs.append(parse_custom_metric_spec(s))
            else:
                specs.append(s)
        self._distribute_custom_metrics(specs)

    def _distribute_custom_metrics(self, specs: List[CustomMetricSpecification]) -> None:
        for listener in self._custom_metric_listeners:
            listener(specs)

    def get_span_processor(self) -> ComprehendDevSpanProcessor:
        if not self._span_processor:
            self._span_processor = ComprehendDevSpanProcessor(self.connection)
            self._custom_metric_listeners.append(
                lambda specs: self._span_processor.update_custom_metrics(specs)
            )
        return self._span_processor

    def get_metrics_exporter(self) -> ComprehendMetricsExporter:
        if not self._metrics_exporter:
            self._metrics_exporter = ComprehendMetricsExporter(self.connection)
            self._custom_metric_listeners.append(
                lambda specs: self._metrics_exporter.update_custom_metrics(specs)
            )
        return self._metrics_exporter

    def shutdown(self) -> None:
        if self._span_processor:
            self._span_processor.shutdown()
        if self._metrics_exporter:
            self._metrics_exporter.shutdown()
        self.connection.close()
