"""ComprehendDev span processor for OpenTelemetry Python SDK (V2)."""

import hashlib
from typing import Dict, List, Optional, Callable, Union, Set
from urllib.parse import urlparse
from dataclasses import dataclass

from opentelemetry.sdk.trace import ReadableSpan, Span, SpanProcessor
from opentelemetry.trace import Context, SpanKind, StatusCode

from .websocket_connection import WebSocketConnection
from .wire_protocol import (
    AttributeType,
    CustomMetricSpecification,
    CustomObservation,
    CustomSpanObservationSpecification,
    DatabaseQueryMessage,
    NewObservedServiceMessage,
    NewObservedHttpRouteMessage,
    NewObservedDatabaseMessage,
    NewObservedHttpServiceMessage,
    NewObservedHttpRequestMessage,
    NewObservedDatabaseConnectionMessage,
    ObservationMessage,
    HttpServerObservation,
    HttpClientObservation,
    TraceSpansMessage,
    TraceSpan,
    SpanMatcherRule,
)


@dataclass
class ObservedService:
    name: str
    namespace: Optional[str]
    environment: Optional[str]
    hash: str
    http_routes: List['ObservedHTTPRoute']


@dataclass
class ObservedHTTPRoute:
    method: str
    route: str
    hash: str


@dataclass
class ObservedDatabase:
    system: str
    connection: Optional[str]
    host: Optional[str]
    port: Optional[int]
    name: Optional[str]
    hash: str


@dataclass
class ObservedHttpService:
    protocol: str
    host: str
    port: Optional[int]
    hash: str


@dataclass
class ObservedHttpRequest:
    hash: str


@dataclass
class ObservedDatabaseConnection:
    hash: str
    connection: Optional[str]
    user: Optional[str]


SQL_DB_SYSTEMS: Set[str] = {
    'mysql', 'postgresql', 'mssql', 'oracle', 'db2', 'sqlite', 'hsqldb', 'h2',
    'informix', 'cockroachdb', 'redshift', 'tidb', 'trino', 'greenplum', 'clickhouse'
}


def hash_id_string(id_string: str) -> str:
    return hashlib.sha256(id_string.encode('utf-8')).hexdigest()


def parse_database_connection_string(conn: str) -> Dict[str, Optional[str]]:
    """Parse database connection string and scrub sensitive info."""
    try:
        parsed = urlparse(conn)
        if parsed.scheme:
            user = parsed.username
            host = parsed.hostname
            port = str(parsed.port) if parsed.port else None
            db_name = parsed.path.lstrip('/') if parsed.path else None

            scrubbed_url = f"{parsed.scheme}://{host}"
            if port:
                scrubbed_url += f":{port}"
            if db_name:
                scrubbed_url += f"/{db_name}"
            if parsed.query:
                scrubbed_url += f"?{parsed.query}"

            return {
                'scrubbed': scrubbed_url,
                'user': user,
                'host': host,
                'port': port,
                'name': db_name
            }
    except Exception:
        pass

    parts = conn.split(';')
    kv: Dict[str, str] = {}
    for part in parts:
        if '=' in part:
            k, v = part.split('=', 1)
            kv[k.strip().lower()] = v.strip()

    user = kv.get('user id') or kv.get('uid')
    host = kv.get('server') or kv.get('data source') or kv.get('address')
    port = kv.get('port')
    name = kv.get('database') or kv.get('initial catalog')

    scrubbed_parts = []
    for k, v in kv.items():
        if k not in ['user id', 'uid', 'password', 'pwd']:
            scrubbed_parts.append(f"{k}={v}")
    scrubbed = ';'.join(scrubbed_parts)

    return {
        'scrubbed': scrubbed,
        'user': user,
        'host': host,
        'port': port,
        'name': name
    }


def extract_error_info(span: ReadableSpan) -> Dict[str, Optional[str]]:
    """Extract error information from span."""
    for event in span.events:
        if event.name == 'exception' and event.attributes:
            message = event.attributes.get('exception.message')
            error_type = event.attributes.get('exception.type')
            stack = event.attributes.get('exception.stacktrace')
            if message or error_type or stack:
                return {
                    'message': str(message) if message else None,
                    'type': str(error_type) if error_type else None,
                    'stack': str(stack) if stack else None
                }

    attrs = span.attributes
    is_error = span.status.status_code == StatusCode.ERROR

    message = (
        attrs.get('exception.message') or
        attrs.get('http.error_message') or
        attrs.get('db.response.status_code') or
        (span.status.description if is_error else None)
    )

    error_type = (
        attrs.get('exception.type') or
        attrs.get('error.type') or
        attrs.get('http.error_name')
    )

    stack = attrs.get('exception.stacktrace')

    return {
        'message': str(message) if message else None,
        'type': str(error_type) if error_type else None,
        'stack': str(stack) if stack else None
    }


def get_span_context(span: ReadableSpan) -> Dict[str, str]:
    """Get traceId and spanId from a span."""
    ctx = span.context
    if ctx:
        return {
            'traceId': format(ctx.trace_id, '032x'),
            'spanId': format(ctx.span_id, '016x'),
        }
    return {'traceId': '', 'spanId': ''}


def get_parent_span_id(span: ReadableSpan) -> str:
    """Get parent span ID."""
    parent = getattr(span, 'parent', None)
    if parent and hasattr(parent, 'span_id') and parent.span_id:
        return format(parent.span_id, '016x')
    return ''


def flatten_resource_attributes(attrs: Dict) -> Dict[str, AttributeType]:
    """Flatten resource attributes to string values."""
    result: Dict[str, AttributeType] = {}
    for key, value in attrs.items():
        if value is not None:
            result[str(key)] = str(value)
    return result


def match_span_rule(span: ReadableSpan, rule: SpanMatcherRule) -> bool:
    """Check if a span matches a custom span matcher rule."""
    kind = rule.kind
    if kind == 'type':
        kind_map = {
            'client': SpanKind.CLIENT,
            'server': SpanKind.SERVER,
            'internal': SpanKind.INTERNAL,
        }
        return span.kind == kind_map.get(rule.value)
    elif kind == 'attribute-present':
        return rule.key in span.attributes
    elif kind == 'attribute-absent':
        return rule.key not in span.attributes
    elif kind == 'attribute-equals':
        return str(span.attributes.get(rule.key, '')) == rule.value
    elif kind == 'attribute-not-equals':
        return str(span.attributes.get(rule.key, '')) != rule.value
    elif kind == 'all':
        return all(match_span_rule(span, r) for r in (rule.rules or []))
    elif kind == 'any':
        return any(match_span_rule(span, r) for r in (rule.rules or []))
    return False


class ComprehendDevSpanProcessor(SpanProcessor):
    """Span processor that sends telemetry data to comprehend.dev (V2)."""

    def __init__(self, connection: WebSocketConnection):
        self.connection = connection
        self.observed_services: List[ObservedService] = []
        self.observed_databases: List[ObservedDatabase] = []
        self.observed_http_services: List[ObservedHttpService] = []
        self.observed_interactions: Dict[str, Dict[str, Dict]] = {}
        self._process_context_set = False
        self._span_observation_specs: List[CustomSpanObservationSpecification] = []

    def update_custom_metrics(self, specs: List[CustomMetricSpecification]) -> None:
        self._span_observation_specs = [
            s for s in specs
            if isinstance(s, CustomSpanObservationSpecification) or
            (hasattr(s, 'type') and s.type == 'span')
        ]

    def on_start(self, span: Span, parent_context: Optional[Context] = None) -> None:
        pass

    def on_end(self, span: ReadableSpan) -> None:
        current_service = self._discover_service(span)
        if not current_service:
            return

        attrs = span.attributes

        if span.kind == SpanKind.SERVER:
            if attrs.get('http.route') and attrs.get('http.method'):
                self._process_http_route(
                    current_service,
                    str(attrs['http.route']),
                    str(attrs['http.method']),
                    span
                )

        elif span.kind == SpanKind.CLIENT:
            if attrs.get('http.url'):
                self._process_http_request(
                    current_service,
                    str(attrs['http.url']),
                    span
                )

        if attrs.get('db.system'):
            self._process_database_operation(current_service, span)

        # Report trace span for every span
        self._report_trace_span(span)

        # Check custom span observation matching
        self._check_custom_span_matching(span)

    def _discover_service(self, span: ReadableSpan) -> Optional[ObservedService]:
        res_attrs = span.resource.attributes
        name = res_attrs.get('service.name')
        if not name:
            return None

        name = str(name)
        namespace = str(res_attrs['service.namespace']) if res_attrs.get('service.namespace') else None
        environment = str(res_attrs['deployment.environment']) if res_attrs.get('deployment.environment') else None

        for existing in self.observed_services:
            if (existing.name == name and
                existing.namespace == namespace and
                existing.environment == environment):
                return existing

        id_string = f"service:{name}:{namespace or ''}:{environment or ''}"
        hash_val = hash_id_string(id_string)
        new_service = ObservedService(
            name=name,
            namespace=namespace,
            environment=environment,
            hash=hash_val,
            http_routes=[]
        )
        self.observed_services.append(new_service)

        message = NewObservedServiceMessage(
            event='new-entity',
            type='service',
            hash=hash_val,
            name=name
        )
        if namespace:
            message.namespace = namespace
        if environment:
            message.environment = environment

        self._ingest_message(message)

        # Set process context on first service discovery
        if not self._process_context_set:
            self._process_context_set = True
            resources = flatten_resource_attributes(res_attrs)
            self.connection.set_process_context(hash_val, resources)

        return new_service

    def _process_http_route(
        self,
        service: ObservedService,
        route: str,
        method: str,
        span: ReadableSpan
    ) -> None:
        observed_route = None
        for r in service.http_routes:
            if r.route == route and r.method == method:
                observed_route = r
                break

        if not observed_route:
            id_string = f"http-route:{service.hash}:{method}:{route}"
            hash_val = hash_id_string(id_string)
            observed_route = ObservedHTTPRoute(
                method=method,
                route=route,
                hash=hash_val
            )
            service.http_routes.append(observed_route)

            message = NewObservedHttpRouteMessage(
                event='new-entity',
                type='http-route',
                hash=hash_val,
                parent=service.hash,
                method=method,
                route=route
            )
            self._ingest_message(message)

        attrs = span.attributes
        path = '/'

        if attrs.get('http.target'):
            try:
                target = str(attrs['http.target'])
                from urllib.parse import urljoin
                full_url = urljoin('http://placeholder', target)
                parsed = urlparse(full_url)
                path = parsed.path
            except Exception:
                path = '/'
        elif attrs.get('http.url'):
            try:
                url = str(attrs['http.url'])
                parsed = urlparse(url)
                path = parsed.path or '/'
            except Exception:
                path = '/'

        status = int(attrs.get('http.status_code', 0))
        duration_ns = span.end_time - span.start_time if span.end_time else 0
        http_version = str(attrs['http.flavor']) if attrs.get('http.flavor') else None
        user_agent = str(attrs['http.user_agent']) if attrs.get('http.user_agent') else None
        request_bytes = int(attrs['http.request_content_length']) if attrs.get('http.request_content_length') else None
        response_bytes = int(attrs['http.response_content_length']) if attrs.get('http.response_content_length') else None

        error_info = extract_error_info(span)
        span_ctx = get_span_context(span)

        observation = HttpServerObservation(
            type='http-server',
            subject=observed_route.hash,
            spanId=span_ctx['spanId'],
            traceId=span_ctx['traceId'],
            timestamp=span.start_time,
            path=path,
            status=status,
            duration=duration_ns
        )

        if http_version:
            observation.httpVersion = http_version
        if user_agent:
            observation.userAgent = user_agent
        if request_bytes is not None:
            observation.requestBytes = request_bytes
        if response_bytes is not None:
            observation.responseBytes = response_bytes
        if error_info['message']:
            observation.errorMessage = error_info['message']
        if error_info['type']:
            observation.errorType = error_info['type']
        if error_info['stack']:
            observation.stack = error_info['stack']

        self._ingest_message(ObservationMessage(
            event='observations',
            seq=self.connection.next_seq(),
            observations=[observation]
        ))

    def _process_http_request(
        self,
        current_service: ObservedService,
        url: str,
        span: ReadableSpan
    ) -> None:
        try:
            parsed = urlparse(url)
            protocol = parsed.scheme
            host = parsed.hostname
            port = parsed.port

            if not host:
                return

            if port is None:
                port = 443 if protocol == 'https' else 80

        except Exception:
            return

        http_service = None
        for service in self.observed_http_services:
            if (service.protocol == protocol and
                service.host == host and
                service.port == port):
                http_service = service
                break

        if not http_service:
            id_string = f"http-service:{protocol}:{host}:{port}"
            hash_val = hash_id_string(id_string)
            http_service = ObservedHttpService(
                protocol=protocol,
                host=host,
                port=port,
                hash=hash_val
            )
            self.observed_http_services.append(http_service)

            message = NewObservedHttpServiceMessage(
                event='new-entity',
                type='http-service',
                hash=hash_val,
                protocol=protocol,
                host=host,
                port=port
            )
            self._ingest_message(message)

        interactions = self._get_interactions(current_service.hash, http_service.hash)
        if not interactions.get('httpRequest'):
            id_string = f"http-request:{current_service.hash}:{http_service.hash}"
            hash_val = hash_id_string(id_string)
            http_request = ObservedHttpRequest(hash=hash_val)
            interactions['httpRequest'] = http_request

            message = NewObservedHttpRequestMessage(
                event='new-interaction',
                type='http-request',
                hash=hash_val,
                from_=current_service.hash,
                to=http_service.hash
            )
            self._ingest_message(message)

        attrs = span.attributes
        path = parsed.path or '/'
        method = str(attrs.get('http.method', ''))
        if not method:
            return

        status = int(attrs['http.status_code']) if attrs.get('http.status_code') else None
        duration_ns = span.end_time - span.start_time if span.end_time else 0
        http_version = str(attrs['http.flavor']) if attrs.get('http.flavor') else None
        request_bytes = int(attrs['http.request_content_length']) if attrs.get('http.request_content_length') else None
        response_bytes = int(attrs['http.response_content_length']) if attrs.get('http.response_content_length') else None

        error_info = extract_error_info(span)
        span_ctx = get_span_context(span)

        observation = HttpClientObservation(
            type='http-client',
            subject=interactions['httpRequest'].hash,
            spanId=span_ctx['spanId'],
            traceId=span_ctx['traceId'],
            timestamp=span.start_time,
            path=path,
            method=method,
            duration=duration_ns
        )

        if status is not None:
            observation.status = status
        if http_version:
            observation.httpVersion = http_version
        if request_bytes is not None:
            observation.requestBytes = request_bytes
        if response_bytes is not None:
            observation.responseBytes = response_bytes
        if error_info['message']:
            observation.errorMessage = error_info['message']
        if error_info['type']:
            observation.errorType = error_info['type']
        if error_info['stack']:
            observation.stack = error_info['stack']

        self._ingest_message(ObservationMessage(
            event='observations',
            seq=self.connection.next_seq(),
            observations=[observation]
        ))

    def _process_database_operation(
        self,
        current_service: ObservedService,
        span: ReadableSpan
    ) -> None:
        attrs = span.attributes
        system = str(attrs['db.system'])

        raw_connection = str(attrs['db.connection_string']) if attrs.get('db.connection_string') else None
        if raw_connection:
            parsed = parse_database_connection_string(raw_connection)
        else:
            host_attr = attrs.get('server.address') or attrs.get('net.peer.name') or attrs.get('net.peer.ip')
            port_attr = attrs.get('server.port') or attrs.get('net.peer.port')
            name_attr = attrs.get('db.namespace') or attrs.get('db.name')

            parsed = {
                'scrubbed': '',
                'user': None,
                'host': str(host_attr) if host_attr else None,
                'port': str(port_attr) if port_attr else None,
                'name': str(name_attr) if name_attr else None
            }

        port_str = str(parsed['port']) if parsed['port'] else ''
        db_hash = hash_id_string(f"database:{system}:{parsed['host'] or ''}:{port_str}:{parsed['name'] or ''}")
        observed_database = None
        for db in self.observed_databases:
            if db.hash == db_hash:
                observed_database = db
                break

        if not observed_database:
            observed_database = ObservedDatabase(
                system=system,
                host=parsed['host'],
                port=int(parsed['port']) if parsed['port'] else None,
                name=parsed['name'],
                hash=db_hash,
                connection=parsed['scrubbed']
            )
            self.observed_databases.append(observed_database)

            message = NewObservedDatabaseMessage(
                event='new-entity',
                type='database',
                hash=db_hash,
                system=system
            )
            if parsed['name']:
                message.name = parsed['name']
            if parsed['host']:
                message.host = parsed['host']
            if parsed['port']:
                message.port = int(parsed['port'])

            self._ingest_message(message)

        interactions = self._get_interactions(current_service.hash, observed_database.hash)
        db_connections = interactions.setdefault('dbConnections', [])

        connection_interaction = None
        for conn in db_connections:
            if (conn.connection == parsed['scrubbed'] and
                conn.user == parsed['user']):
                connection_interaction = conn
                break

        if not connection_interaction:
            conn_hash = hash_id_string(f"db-connection:{current_service.hash}:{observed_database.hash}:{parsed['scrubbed'] or ''}:{parsed['user'] or ''}")
            connection_interaction = ObservedDatabaseConnection(
                hash=conn_hash,
                connection=parsed['scrubbed'],
                user=parsed['user']
            )
            db_connections.append(connection_interaction)

            message = NewObservedDatabaseConnectionMessage(
                event='new-interaction',
                type='db-connection',
                hash=conn_hash,
                from_=current_service.hash,
                to=observed_database.hash
            )
            if parsed['scrubbed']:
                message.connection = parsed['scrubbed']
            if parsed['user']:
                message.user = parsed['user']

            self._ingest_message(message)

        # For SQL databases, send raw query to server for analysis (V2: no client-side SQL analysis)
        if system in SQL_DB_SYSTEMS and attrs.get('db.statement'):
            statement = str(attrs['db.statement'])
            duration_ns = span.end_time - span.start_time if span.end_time else 0
            returned_rows = (
                int(attrs['db.response.returned_rows']) if attrs.get('db.response.returned_rows') else
                int(attrs['db.sql.rows']) if attrs.get('db.sql.rows') else None
            )
            error_info = extract_error_info(span)
            span_ctx = get_span_context(span)

            db_query_message = DatabaseQueryMessage(
                event='db-query',
                seq=self.connection.next_seq(),
                query=statement,
                from_=current_service.hash,
                to=observed_database.hash,
                timestamp=span.start_time,
                duration=duration_ns,
                traceId=span_ctx['traceId'],
                spanId=span_ctx['spanId'],
            )
            if error_info['message']:
                db_query_message.errorMessage = error_info['message']
            if error_info['type']:
                db_query_message.errorType = error_info['type']
            if error_info['stack']:
                db_query_message.stack = error_info['stack']
            if returned_rows is not None:
                db_query_message.returnedRows = returned_rows

            self._ingest_message(db_query_message)

    def _report_trace_span(self, span: ReadableSpan) -> None:
        span_ctx = get_span_context(span)
        parent = get_parent_span_id(span)
        trace_span_message = TraceSpansMessage(
            event='tracespans',
            seq=self.connection.next_seq(),
            data=[TraceSpan(
                trace=span_ctx['traceId'],
                span=span_ctx['spanId'],
                parent=parent,
                name=span.name,
                timestamp=span.start_time,
            )]
        )
        self._ingest_message(trace_span_message)

    def _check_custom_span_matching(self, span: ReadableSpan) -> None:
        for spec in self._span_observation_specs:
            if spec.rule and match_span_rule(span, spec.rule):
                span_ctx = get_span_context(span)
                error_info = extract_error_info(span)
                collected_attrs: Dict[str, AttributeType] = {}
                for key, value in span.attributes.items():
                    if value is not None:
                        collected_attrs[key] = value

                observation = CustomObservation(
                    type='custom',
                    subject=spec.subject,
                    id=spec.subject,
                    spanId=span_ctx['spanId'],
                    traceId=span_ctx['traceId'],
                    timestamp=span.start_time,
                    attributes=collected_attrs,
                )
                if error_info['message']:
                    observation.errorMessage = error_info['message']
                if error_info['type']:
                    observation.errorType = error_info['type']
                if error_info['stack']:
                    observation.stack = error_info['stack']

                self._ingest_message(ObservationMessage(
                    event='observations',
                    seq=self.connection.next_seq(),
                    observations=[observation]
                ))

    def _get_interactions(self, from_hash: str, to_hash: str) -> Dict:
        from_map = self.observed_interactions.setdefault(from_hash, {})
        interactions = from_map.setdefault(to_hash, {
            'httpRequest': None,
            'dbConnections': [],
        })
        return interactions

    def _ingest_message(self, message) -> None:
        self.connection.send_message(message)

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return True

    def shutdown(self) -> bool:
        self.connection.close()
        return True
