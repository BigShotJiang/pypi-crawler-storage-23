"""Tests for ComprehendMetricsExporter."""

from unittest.mock import Mock, MagicMock
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
from comprehend_telemetry.metrics_exporter import (
    ComprehendMetricsExporter,
    KNOWN_GAUGE_METRICS,
    KNOWN_CUMULATIVE_METRICS,
)
from comprehend_telemetry.wire_protocol import (
    TimeSeriesMetricsMessage,
    CumulativeMetricsMessage,
    CustomCumulativeMetricSpecification,
    CustomTimeSeriesMetricSpecification,
)
from opentelemetry.sdk.metrics.export import MetricExportResult


def make_data_point(value=1.0, time_unix_nano=1000000000000000000, attributes=None):
    dp = Mock()
    dp.value = value
    dp.time_unix_nano = time_unix_nano
    dp.attributes = attributes or {}
    return dp


def make_metric(name, unit='', data_type='gauge', data_points=None):
    from opentelemetry.sdk.metrics.export import Gauge, Sum, Histogram
    metric = Mock()
    metric.name = name
    metric.unit = unit
    data = Mock()
    data.data_points = data_points or []

    if data_type == 'gauge':
        data.__class__ = Gauge
        # Make isinstance work
        metric.data = data
        metric.data.__class__ = Gauge
    elif data_type == 'sum':
        data.__class__ = Sum
        metric.data = data
        metric.data.__class__ = Sum
    elif data_type == 'histogram':
        from opentelemetry.sdk.metrics.export import Histogram as H
        metric.data = data
        metric.data.__class__ = H
    else:
        metric.data = data

    return metric


def make_metrics_data(metrics, service_name='test-service', namespace='', environment=''):
    """Build a MetricsData-like structure."""
    resource = Mock()
    resource.attributes = {
        'service.name': service_name,
        'service.namespace': namespace,
        'deployment.environment': environment,
    }

    scope_metrics = Mock()
    scope_metrics.metrics = metrics

    resource_metrics = Mock()
    resource_metrics.resource = resource
    resource_metrics.scope_metrics = [scope_metrics]

    metrics_data = Mock()
    metrics_data.resource_metrics = [resource_metrics]
    return metrics_data


class TestComprehendMetricsExporter:
    def setup_method(self):
        self.sent_messages = []
        self.mock_connection = Mock()
        self.mock_connection.send_message = Mock(side_effect=lambda msg: self.sent_messages.append(msg))
        self.mock_connection.next_seq = Mock(side_effect=iter(range(1, 1000)))

    def test_known_gauge_metric(self):
        exporter = ComprehendMetricsExporter(self.mock_connection)
        dp = make_data_point(value=0.75)
        metric = make_metric('process.cpu.utilization', unit='1', data_type='gauge', data_points=[dp])
        data = make_metrics_data([metric])

        result = exporter.export(data)
        assert result == MetricExportResult.SUCCESS

        ts_msgs = [m for m in self.sent_messages if isinstance(m, TimeSeriesMetricsMessage)]
        assert len(ts_msgs) == 1
        assert ts_msgs[0].data[0].type == 'process.cpu.utilization'
        assert ts_msgs[0].data[0].value == 0.75

    def test_known_cumulative_metric(self):
        exporter = ComprehendMetricsExporter(self.mock_connection)
        dp = make_data_point(value=100.5)
        metric = make_metric('process.cpu.time', unit='s', data_type='sum', data_points=[dp])
        data = make_metrics_data([metric])

        result = exporter.export(data)
        assert result == MetricExportResult.SUCCESS

        cum_msgs = [m for m in self.sent_messages if isinstance(m, CumulativeMetricsMessage)]
        assert len(cum_msgs) == 1
        assert cum_msgs[0].data[0].type == 'process.cpu.time'
        assert cum_msgs[0].data[0].value == 100.5

    def test_unknown_metric_ignored(self):
        exporter = ComprehendMetricsExporter(self.mock_connection)
        dp = make_data_point(value=42.0)
        metric = make_metric('unknown.metric.name', data_type='gauge', data_points=[dp])
        data = make_metrics_data([metric])

        exporter.export(data)
        assert len(self.sent_messages) == 0

    def test_histogram_skipped(self):
        exporter = ComprehendMetricsExporter(self.mock_connection)
        dp = make_data_point()
        metric = make_metric('process.cpu.utilization', data_type='histogram', data_points=[dp])
        data = make_metrics_data([metric])

        exporter.export(data)
        assert len(self.sent_messages) == 0

    def test_no_service_name_returns_no_subject(self):
        exporter = ComprehendMetricsExporter(self.mock_connection)
        dp = make_data_point(value=0.5)
        metric = make_metric('process.cpu.utilization', data_type='gauge', data_points=[dp])
        data = make_metrics_data([metric], service_name=None)

        exporter.export(data)
        # No subject means well-known metrics won't be sent
        assert len(self.sent_messages) == 0

    def test_custom_timeseries_metric(self):
        exporter = ComprehendMetricsExporter(self.mock_connection)
        exporter.update_custom_metrics([
            CustomTimeSeriesMetricSpecification(
                id='my.custom.gauge', attributes=['env'], subject='custom-hash'
            )
        ])

        dp = make_data_point(value=99.0, attributes={'env': 'prod', 'extra': 'ignored'})
        metric = make_metric('my.custom.gauge', unit='count', data_type='gauge', data_points=[dp])
        data = make_metrics_data([metric])

        exporter.export(data)

        ts_msgs = [m for m in self.sent_messages if isinstance(m, TimeSeriesMetricsMessage)]
        assert len(ts_msgs) == 1
        point = ts_msgs[0].data[0]
        assert point.subject == 'custom-hash'
        assert point.type == 'my.custom.gauge'
        # Only 'env' should be in attributes (filtered)
        assert point.attributes == {'env': 'prod'}

    def test_custom_cumulative_metric(self):
        exporter = ComprehendMetricsExporter(self.mock_connection)
        exporter.update_custom_metrics([
            CustomCumulativeMetricSpecification(
                id='my.custom.counter', attributes=[], subject='custom-hash'
            )
        ])

        dp = make_data_point(value=500.0)
        metric = make_metric('my.custom.counter', unit='1', data_type='sum', data_points=[dp])
        data = make_metrics_data([metric])

        exporter.export(data)

        cum_msgs = [m for m in self.sent_messages if isinstance(m, CumulativeMetricsMessage)]
        assert len(cum_msgs) == 1
        assert cum_msgs[0].data[0].subject == 'custom-hash'

    def test_multiple_data_points(self):
        exporter = ComprehendMetricsExporter(self.mock_connection)
        dp1 = make_data_point(value=0.5, time_unix_nano=1000)
        dp2 = make_data_point(value=0.8, time_unix_nano=2000)
        metric = make_metric('process.cpu.utilization', data_type='gauge', data_points=[dp1, dp2])
        data = make_metrics_data([metric])

        exporter.export(data)

        ts_msgs = [m for m in self.sent_messages if isinstance(m, TimeSeriesMetricsMessage)]
        assert len(ts_msgs) == 1
        assert len(ts_msgs[0].data) == 2

    def test_service_subject_hash(self):
        exporter = ComprehendMetricsExporter(self.mock_connection)
        dp = make_data_point()
        metric = make_metric('process.cpu.utilization', data_type='gauge', data_points=[dp])

        data1 = make_metrics_data([metric], service_name='svc-a')
        data2 = make_metrics_data([metric], service_name='svc-b')

        exporter.export(data1)
        exporter.export(data2)

        ts_msgs = [m for m in self.sent_messages if isinstance(m, TimeSeriesMetricsMessage)]
        assert ts_msgs[0].data[0].subject != ts_msgs[1].data[0].subject

    def test_force_flush(self):
        exporter = ComprehendMetricsExporter(self.mock_connection)
        assert exporter.force_flush() is True

    def test_shutdown(self):
        exporter = ComprehendMetricsExporter(self.mock_connection)
        exporter.shutdown()  # should not raise

    def test_all_known_gauge_metrics(self):
        """Verify all known gauge metrics are forwarded."""
        exporter = ComprehendMetricsExporter(self.mock_connection)
        for name in KNOWN_GAUGE_METRICS:
            self.sent_messages.clear()
            dp = make_data_point(value=1.0)
            metric = make_metric(name, data_type='gauge', data_points=[dp])
            data = make_metrics_data([metric])
            exporter.export(data)
            ts_msgs = [m for m in self.sent_messages if isinstance(m, TimeSeriesMetricsMessage)]
            assert len(ts_msgs) == 1, f"Expected timeseries for {name}"

    def test_all_known_cumulative_metrics(self):
        """Verify all known cumulative metrics are forwarded."""
        exporter = ComprehendMetricsExporter(self.mock_connection)
        for name in KNOWN_CUMULATIVE_METRICS:
            self.sent_messages.clear()
            dp = make_data_point(value=1.0)
            metric = make_metric(name, data_type='sum', data_points=[dp])
            data = make_metrics_data([metric])
            exporter.export(data)
            cum_msgs = [m for m in self.sent_messages if isinstance(m, CumulativeMetricsMessage)]
            assert len(cum_msgs) == 1, f"Expected cumulative for {name}"

    def test_meter_provider_integration(self):
        """PeriodicExportingMetricReader must accept the exporter without raising.

        Regression test: previously preferred_temporality used data point types
        (Gauge, Sum, Histogram from sdk.metrics.export) instead of instrument
        classes, causing 'Invalid instrument class found' at MeterProvider init.
        """
        exporter = ComprehendMetricsExporter(self.mock_connection)
        reader = PeriodicExportingMetricReader(exporter, export_interval_millis=60000)
        provider = MeterProvider(metric_readers=[reader])
        provider.shutdown()
