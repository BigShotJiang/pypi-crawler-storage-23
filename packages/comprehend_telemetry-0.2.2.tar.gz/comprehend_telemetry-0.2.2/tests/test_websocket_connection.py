"""Tests for WebSocketConnection V2."""

import json
from unittest.mock import Mock, patch

from comprehend_telemetry.websocket_connection import WebSocketConnection, SeqQueue
from comprehend_telemetry.wire_protocol import (
    NewObservedServiceMessage,
    NewObservedHttpRouteMessage,
    ObservationMessage,
    HttpServerObservation,
    TimeSeriesMetricsMessage,
    TimeSeriesDataPoint,
    CumulativeMetricsMessage,
    CumulativeDataPoint,
    TraceSpansMessage,
    TraceSpan,
    DatabaseQueryMessage,
)


class TestSeqQueue:
    def test_add_and_ack(self):
        q = SeqQueue('ack-observations')
        msg = Mock(seq=1)
        q.add(msg)
        assert list(q.values()) == [msg]
        q.ack(1)
        assert list(q.values()) == []

    def test_ack_nonexistent(self):
        q = SeqQueue('ack-observations')
        q.ack(999)  # should not raise


class TestWebSocketConnection:
    def setup_method(self):
        self.log_messages = []
        self.mock_logger = Mock(side_effect=lambda msg: self.log_messages.append(msg))
        self.mock_socket = Mock()
        self.mock_socket_class = Mock(return_value=self.mock_socket)
        self.mock_thread = Mock()
        self.mock_thread_class = Mock(return_value=self.mock_thread)
        self.mock_timer = Mock()
        self.mock_timer_class = Mock(return_value=self.mock_timer)

    def _create_connection(self, **kwargs):
        with patch('comprehend_telemetry.websocket_connection.websocket.WebSocketApp', self.mock_socket_class), \
             patch('comprehend_telemetry.websocket_connection.threading.Thread', self.mock_thread_class):
            return WebSocketConnection('test-org', 'test-token', self.mock_logger, **kwargs)

    def test_connection_url(self):
        conn = self._create_connection()
        call_args = self.mock_socket_class.call_args
        assert call_args[0][0] == 'wss://ingestion.comprehend.dev/test-org/observations'
        conn.close()

    def test_on_open_sends_v2_init(self):
        conn = self._create_connection()
        on_open = self.mock_socket_class.call_args[1]['on_open']
        on_open(self.mock_socket)

        sent_data = self.mock_socket.send.call_args[0][0]
        sent_message = json.loads(sent_data)
        assert sent_message['event'] == 'init'
        assert sent_message['protocolVersion'] == 2
        assert sent_message['token'] == 'test-token'
        conn.close()

    def test_authorization_with_custom_metrics(self):
        authorized_acks = []
        conn = self._create_connection(
            on_authorized=lambda ack: authorized_acks.append(ack)
        )

        on_message = self.mock_socket_class.call_args[1]['on_message']
        auth_ack = json.dumps({
            'type': 'ack-authorized',
            'customMetrics': [{'type': 'cumulative', 'id': 'test', 'attributes': [], 'subject': 'h1'}]
        })
        on_message(self.mock_socket, auth_ack)

        assert conn.authorized is True
        assert len(authorized_acks) == 1
        assert len(authorized_acks[0].customMetrics) == 1
        conn.close()

    def test_next_seq_increments(self):
        conn = self._create_connection()
        assert conn.next_seq() == 1
        assert conn.next_seq() == 2
        assert conn.next_seq() == 3
        conn.close()

    def test_message_queuing_by_event_type(self):
        conn = self._create_connection()

        # Entity
        entity = NewObservedServiceMessage(hash='h1', name='svc')
        conn.send_message(entity)
        assert 'h1' in conn.unacknowledged_observed

        # Observations
        obs = ObservationMessage(seq=1, observations=[])
        conn.send_message(obs)
        assert list(conn.observations_queue.values()) == [obs]

        # Timeseries
        ts = TimeSeriesMetricsMessage(seq=2, data=[])
        conn.send_message(ts)
        assert list(conn.timeseries_queue.values()) == [ts]

        # Cumulative
        cum = CumulativeMetricsMessage(seq=3, data=[])
        conn.send_message(cum)
        assert list(conn.cumulative_queue.values()) == [cum]

        # Trace spans
        tsp = TraceSpansMessage(seq=4, data=[])
        conn.send_message(tsp)
        assert list(conn.trace_spans_queue.values()) == [tsp]

        # DB query
        dbq = DatabaseQueryMessage(seq=5, query="SELECT 1", from_="a", to="b", timestamp=0, duration=0)
        conn.send_message(dbq)
        assert list(conn.db_query_queue.values()) == [dbq]

        conn.close()

    def test_seq_based_ack_dispatch(self):
        conn = self._create_connection()
        on_message = self.mock_socket_class.call_args[1]['on_message']

        # Auth first
        on_message(self.mock_socket, json.dumps({'type': 'ack-authorized', 'customMetrics': []}))

        # Add messages
        obs = ObservationMessage(seq=1, observations=[])
        conn.send_message(obs)
        ts = TimeSeriesMetricsMessage(seq=2, data=[])
        conn.send_message(ts)

        # Ack observations
        on_message(self.mock_socket, json.dumps({'type': 'ack-observations', 'seq': 1}))
        assert list(conn.observations_queue.values()) == []

        # Ack timeseries
        on_message(self.mock_socket, json.dumps({'type': 'ack-timeseries', 'seq': 2}))
        assert list(conn.timeseries_queue.values()) == []

        conn.close()

    def test_entity_ack(self):
        conn = self._create_connection()
        on_message = self.mock_socket_class.call_args[1]['on_message']

        entity = NewObservedServiceMessage(hash='h1', name='svc')
        conn.send_message(entity)
        assert 'h1' in conn.unacknowledged_observed

        on_message(self.mock_socket, json.dumps({'type': 'ack-observed', 'hash': 'h1'}))
        assert 'h1' not in conn.unacknowledged_observed
        conn.close()

    def test_custom_metric_change_callback(self):
        changes = []
        conn = self._create_connection(
            on_custom_metric_change=lambda specs: changes.append(specs)
        )
        on_message = self.mock_socket_class.call_args[1]['on_message']

        on_message(self.mock_socket, json.dumps({
            'type': 'custom-metric-change',
            'customMetrics': [{'type': 'timeseries', 'id': 'new.metric', 'attributes': [], 'subject': 'h'}]
        }))

        assert len(changes) == 1
        assert len(changes[0]) == 1
        conn.close()

    def test_replay_on_reconnect(self):
        conn = self._create_connection()

        # Queue messages before auth
        entity = NewObservedServiceMessage(hash='h1', name='svc')
        conn.send_message(entity)
        obs = ObservationMessage(seq=1, observations=[])
        conn.send_message(obs)

        self.mock_socket.send.reset_mock()

        # Authorize
        on_message = self.mock_socket_class.call_args[1]['on_message']
        on_message(self.mock_socket, json.dumps({'type': 'ack-authorized', 'customMetrics': []}))

        # Should replay both
        assert self.mock_socket.send.call_count == 2
        conn.close()

    def test_process_context_sent_on_auth(self):
        conn = self._create_connection()

        # Set process context before auth
        conn.set_process_context('hash1', {'service.name': 'test'})

        self.mock_socket.send.reset_mock()

        # Authorize
        on_message = self.mock_socket_class.call_args[1]['on_message']
        on_message(self.mock_socket, json.dumps({'type': 'ack-authorized', 'customMetrics': []}))

        # Context should be sent first
        calls = self.mock_socket.send.call_args_list
        assert len(calls) >= 1
        first_msg = json.loads(calls[0][0][0])
        assert first_msg['event'] == 'context-start'
        assert first_msg['type'] == 'process'
        assert first_msg['serviceEntityHash'] == 'hash1'
        conn.close()

    def test_process_context_sent_immediately_if_authorized(self):
        conn = self._create_connection()

        # Authorize first
        on_message = self.mock_socket_class.call_args[1]['on_message']
        on_message(self.mock_socket, json.dumps({'type': 'ack-authorized', 'customMetrics': []}))
        self.mock_socket.send.reset_mock()

        # Set process context after auth
        conn.set_process_context('hash1', {'service.name': 'test'})

        # Should send immediately
        assert self.mock_socket.send.call_count == 1
        sent = json.loads(self.mock_socket.send.call_args[0][0])
        assert sent['event'] == 'context-start'
        conn.close()

    def test_reconnection_on_close(self):
        with patch('comprehend_telemetry.websocket_connection.websocket.WebSocketApp', self.mock_socket_class), \
             patch('comprehend_telemetry.websocket_connection.threading.Thread', self.mock_thread_class), \
             patch('comprehend_telemetry.websocket_connection.threading.Timer', self.mock_timer_class):

            conn = WebSocketConnection('test-org', 'test-token', self.mock_logger)

            on_close = self.mock_socket_class.call_args[1]['on_close']
            on_close(self.mock_socket, 1000, 'Normal closure')

            assert conn.authorized is False
            self.mock_timer_class.assert_called_once()
            self.mock_timer.start.assert_called_once()
            conn.close()

    def test_no_reconnect_after_explicit_close(self):
        with patch('comprehend_telemetry.websocket_connection.websocket.WebSocketApp', self.mock_socket_class), \
             patch('comprehend_telemetry.websocket_connection.threading.Thread', self.mock_thread_class), \
             patch('comprehend_telemetry.websocket_connection.threading.Timer', self.mock_timer_class):

            conn = WebSocketConnection('test-org', 'test-token', self.mock_logger)
            conn.close()

            on_close = self.mock_socket_class.call_args[1]['on_close']
            on_close(self.mock_socket, 1000, 'Explicit close')

            self.mock_timer_class.assert_not_called()

    def test_malformed_message_handling(self):
        conn = self._create_connection()
        on_message = self.mock_socket_class.call_args[1]['on_message']
        on_message(self.mock_socket, '{invalid json}')

        error_logged = any('Error parsing message' in msg for msg in self.log_messages)
        assert error_logged
        conn.close()

    def test_send_when_socket_errors(self):
        conn = self._create_connection()
        conn.authorized = True
        self.mock_socket.send.side_effect = Exception('Connection closed')

        entity = NewObservedServiceMessage(hash='h1', name='svc')
        conn.send_message(entity)  # should not raise
        conn.close()
