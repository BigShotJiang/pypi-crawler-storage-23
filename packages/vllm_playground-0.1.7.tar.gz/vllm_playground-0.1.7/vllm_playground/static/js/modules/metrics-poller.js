/**
 * MetricsPoller -- single shared polling loop for all metric consumers.
 *
 * Makes one HTTP request per poll cycle (/api/vllm/metrics/all) and
 * derives the legacy flat dict client-side using the key map from
 * metrics-registry.js.
 *
 * Usage:
 *   import { metricsPoller } from './metrics-poller.js';
 *   metricsPoller.subscribe(data => { ... });
 *   metricsPoller.start();
 */

import { toLegacyDict } from './metrics-registry.js';

class MetricsPoller {
    constructor(interval = 3000) {
        this._interval = interval;
        this._timer = null;
        this._subscribers = new Set();
        this._latestAll = null;
        this._latestLegacy = null;
    }

    /**
     * Subscribe to metric updates.
     * @param {function} callback - called with { all, legacy } on each poll
     *   all:    structured dict from /api/vllm/metrics/all
     *   legacy: flat dict derived client-side (backward compat)
     * @returns {function} unsubscribe function
     */
    subscribe(callback) {
        this._subscribers.add(callback);
        if (this._latestAll) {
            try { callback({ all: this._latestAll, legacy: this._latestLegacy }); } catch {}
        }
        return () => this._subscribers.delete(callback);
    }

    unsubscribe(callback) {
        this._subscribers.delete(callback);
    }

    start() {
        if (this._timer) return;
        this._poll();
        this._timer = setInterval(() => this._poll(), this._interval);
    }

    stop() {
        if (this._timer) {
            clearInterval(this._timer);
            this._timer = null;
        }
    }

    get latest() {
        return { all: this._latestAll, legacy: this._latestLegacy };
    }

    async _poll() {
        try {
            const resp = await fetch('/api/vllm/metrics/all');
            if (!resp.ok) {
                this._notify(null, null);
                return;
            }
            const data = await resp.json();
            this._latestAll = data;
            this._latestLegacy = data?.metrics ? toLegacyDict(data.metrics) : null;

            this._notify(data, this._latestLegacy);
        } catch {
            this._notify(null, null);
        }
    }

    _notify(all, legacy) {
        const payload = { all, legacy };
        for (const cb of this._subscribers) {
            try { cb(payload); } catch {}
        }
    }

    /**
     * Fetch time-series history for charting.
     * @param {number} [minutes] - optional window in minutes
     * @param {number} [seconds] - optional window in seconds (takes precedence)
     * @returns {Promise<Array>}
     */
    async getHistory(minutes, seconds) {
        let url = '/api/vllm/metrics/history';
        if (seconds != null) url += `?seconds=${seconds}`;
        else if (minutes != null) url += `?minutes=${minutes}`;
        try {
            const resp = await fetch(url);
            return resp.ok ? await resp.json() : [];
        } catch {
            return [];
        }
    }

    async getHistorySummary() {
        try {
            const resp = await fetch('/api/vllm/metrics/history/summary');
            return resp.ok ? await resp.json() : null;
        } catch {
            return null;
        }
    }
}

export const metricsPoller = new MetricsPoller(3000);
