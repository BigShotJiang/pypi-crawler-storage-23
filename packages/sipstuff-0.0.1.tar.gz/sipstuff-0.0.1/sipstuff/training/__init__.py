"""Piper TTS training dataset recording tools (GUI and CLI)."""
