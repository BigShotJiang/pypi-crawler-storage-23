"""Live transcription of incoming SIP calls with VAD-based chunking."""
