"""Tests for the project scaffold generator."""

from pathlib import Path

from ase.scaffold.detector import ScaffoldStatus, detect
from ase.scaffold.generator import scaffold_project


def test_detect_empty_project(tmp_path: Path) -> None:
    status = detect(tmp_path)
    assert not status.db_exists
    assert not status.config_exists
    assert not status.is_initialized
    assert status.needs_scaffold


def test_scaffold_project(tmp_path: Path) -> None:
    project_path = tmp_path / "myproject"
    status = scaffold_project(project_path, "myproject")
    assert status.is_initialized
    assert not status.needs_scaffold
    assert (project_path / "ase.toml").exists()
    assert (project_path / ".ase" / "ase.db").exists()


def test_scaffold_idempotent(tmp_path: Path) -> None:
    project_path = tmp_path / "myproject"
    scaffold_project(project_path, "myproject")
    status2 = scaffold_project(project_path, "myproject")
    assert status2.is_initialized


def test_scaffold_creates_env_example(tmp_path: Path) -> None:
    project_path = tmp_path / "myproject"
    scaffold_project(project_path, "myproject")
    assert (project_path / ".env.example").exists()


def test_scaffold_config_contains_project_name(tmp_path: Path) -> None:
    project_path = tmp_path / "myproject"
    scaffold_project(project_path, "myproject")
    content = (project_path / "ase.toml").read_text()
    assert "myproject" in content
