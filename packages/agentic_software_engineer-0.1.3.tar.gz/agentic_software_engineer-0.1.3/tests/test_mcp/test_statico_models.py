"""Tests for the MCP Statico Pydantic models."""

from ase.mcp.statico.models import (
    AccessRegistry,
    Architecture,
    Blueprint,
    CompanyProfile,
    Conventions,
    DataSchema,
    DomainModel,
    Environment,
    ExternalDependency,
    FullContext,
    KnowledgeEntry,
    Service,
    TeamMember,
    TechStack,
)


def test_company_profile() -> None:
    cp = CompanyProfile(name="TestCo", purpose="Testing")
    assert cp.name == "TestCo"


def test_team_member() -> None:
    tm = TeamMember(id="tm1", name="Alice", role="Dev")
    assert tm.name == "Alice"
    assert tm.responsibilities == []
    assert tm.department == ""
    assert tm.title == ""
    assert tm.email == ""
    assert tm.location == ""
    assert tm.skills == []
    assert tm.availability == ""
    assert tm.notes == ""


def test_tech_stack() -> None:
    ts = TechStack(languages=["Python"], frameworks=["FastAPI"])
    assert "Python" in ts.languages


def test_architecture() -> None:
    a = Architecture(type="microservices", description="Distributed system")
    assert a.type == "microservices"
    assert a.diagrams == []
    assert a.decisions == []
    assert a.components == []
    assert a.constraints == []
    assert a.principles == []


def test_service() -> None:
    s = Service(id="s1", name="auth-service", description="Authentication")
    assert s.name == "auth-service"


def test_conventions() -> None:
    c = Conventions(branching_strategy="gitflow")
    assert c.branching_strategy == "gitflow"


def test_environment() -> None:
    e = Environment(name="production", url="https://api.prod.com")
    assert e.name == "production"
    assert e.config == {}
    assert e.description == ""
    assert e.cloud_region == ""
    assert e.infra_notes == ""
    assert e.monitoring_url == ""
    assert e.access_level == ""
    assert e.services_deployed == []


def test_blueprint() -> None:
    b = Blueprint(id="bp1", name="REST API", description="Standard REST API template")
    assert b.name == "REST API"
    assert b.agent_sequence == []


def test_access_registry() -> None:
    ar = AccessRegistry(id="ar1", system_name="Jira", system_type="issue_tracker")
    assert ar.system_name == "Jira"
    assert ar.tags == []
    assert ar.owner is None
    assert ar.auth_reference == ""


def test_domain_model() -> None:
    dm = DomainModel(description="E-commerce domain")
    assert dm.description == "E-commerce domain"
    assert dm.ubiquitous_language == {}
    assert dm.entities == []
    assert dm.business_rules == []
    assert dm.bounded_contexts == []


def test_external_dependency() -> None:
    ed = ExternalDependency(id="ed1", name="Stripe", category="payment")
    assert ed.name == "Stripe"
    assert ed.rate_limits == {}
    assert ed.tags == []
    assert ed.owner is None


def test_data_schema() -> None:
    ds = DataSchema(id="ds1", name="orders_db", database_type="PostgreSQL")
    assert ds.name == "orders_db"
    assert ds.tables == []
    assert ds.service_id is None
    assert ds.connection_reference == ""


def test_knowledge_entry() -> None:
    ke = KnowledgeEntry(id="ke1", title="Never use SELECT *", category="forbidden_pattern")
    assert ke.title == "Never use SELECT *"
    assert ke.related_services == []
    assert ke.author is None
    assert ke.severity == ""


def test_full_context_defaults() -> None:
    fc = FullContext()
    assert fc.company_profile is None
    assert fc.team == []
    assert fc.services == []
    assert fc.access_registry == []
    assert fc.domain_model is None
    assert fc.external_dependencies == []
    assert fc.data_schemas == []
    assert fc.knowledge_base == []
