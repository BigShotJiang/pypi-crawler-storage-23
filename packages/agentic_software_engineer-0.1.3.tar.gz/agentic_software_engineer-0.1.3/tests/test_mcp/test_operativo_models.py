"""Tests for the MCP Operativo Pydantic models."""

from ase.mcp.operativo.models import Ticket, AgentAssignment, Event, Artifact


def test_ticket_defaults() -> None:
    t = Ticket(source="text", raw_content="Fix the bug", project_id="p1")
    assert t.status == "received"
    assert t.priority == "medium"
    assert t.retry_count == 0
    assert t.escalation_level == "none"
    assert t.id is not None


def test_agent_assignment_defaults() -> None:
    a = AgentAssignment(ticket_id="t1", agent_type="backend")
    assert a.status == "pending"
    assert a.id is not None


def test_artifact_defaults() -> None:
    a = Artifact(
        ticket_id="t1",
        agent_type="backend",
        artifact_type="file",
        path="src/main.py",
    )
    assert a.id is not None
    assert a.artifact_type == "file"


def test_event_defaults() -> None:
    e = Event(
        event_type="agent_spawned",
        source_agent="orchestrator",
        ticket_id="t1",
    )
    assert e.consumed_by == "[]"
    assert e.payload == "{}"
