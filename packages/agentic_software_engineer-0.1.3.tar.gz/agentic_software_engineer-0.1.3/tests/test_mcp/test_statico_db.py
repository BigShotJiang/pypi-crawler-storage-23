"""Tests for the MCP Statico SQLite CRUD layer."""

import pytest

from ase.mcp.statico.db import StaticoDB
from ase.mcp.statico.models import (
    AccessRegistry,
    Architecture,
    DataSchema,
    DomainModel,
    Environment,
    ExternalDependency,
    KnowledgeEntry,
    Service,
    TeamMember,
)


@pytest.fixture()
def db(tmp_path):
    """Create a fresh StaticoDB backed by a temporary file."""
    return StaticoDB(tmp_path / "test_statico.db")


# ------------------------------------------------------------------
# TeamMember (expanded)
# ------------------------------------------------------------------


class TestTeamMemberExpanded:
    def test_add_and_get_with_new_fields(self, db: StaticoDB) -> None:
        member = TeamMember(
            id="tm1", name="Alice", role="Dev",
            department="Engineering", title="Senior Dev",
            email="alice@co.com", location="Milan, CET",
            skills=["Python", "Go"], availability="full-time",
        )
        db.add_team_member(member)
        result = db.get_team_member("tm1")
        assert result is not None
        assert result.department == "Engineering"
        assert result.skills == ["Python", "Go"]
        assert result.email == "alice@co.com"

    def test_backward_compat_defaults(self, db: StaticoDB) -> None:
        member = TeamMember(id="tm2", name="Bob", role="QA")
        db.add_team_member(member)
        result = db.get_team_member("tm2")
        assert result is not None
        assert result.department == ""
        assert result.skills == []
        assert result.notes == ""

    def test_upsert_updates_new_fields(self, db: StaticoDB) -> None:
        db.add_team_member(TeamMember(id="tm3", name="Carol", role="PM"))
        db.add_team_member(TeamMember(
            id="tm3", name="Carol", role="PM",
            department="Product", skills=["Agile"],
        ))
        result = db.get_team_member("tm3")
        assert result is not None
        assert result.department == "Product"
        assert result.skills == ["Agile"]

    def test_get_team_returns_all(self, db: StaticoDB) -> None:
        db.add_team_member(TeamMember(id="a", name="Alpha", role="Dev"))
        db.add_team_member(TeamMember(id="b", name="Beta", role="QA"))
        team = db.get_team()
        assert len(team) == 2


# ------------------------------------------------------------------
# Architecture (expanded)
# ------------------------------------------------------------------


class TestArchitectureExpanded:
    def test_set_and_get_with_new_fields(self, db: StaticoDB) -> None:
        arch = Architecture(
            type="microservices",
            description="Distributed system",
            diagrams=["https://example.com/diagram.png"],
            decisions=[{"title": "Use gRPC", "status": "accepted"}],
            components=[{"name": "api-gateway", "type": "proxy"}],
            constraints=["No vendor lock-in"],
            principles=["Loose coupling"],
        )
        db.set_architecture(arch)
        result = db.get_architecture()
        assert result is not None
        assert result.diagrams == ["https://example.com/diagram.png"]
        assert result.decisions[0]["title"] == "Use gRPC"
        assert result.components[0]["name"] == "api-gateway"
        assert result.constraints == ["No vendor lock-in"]
        assert result.principles == ["Loose coupling"]

    def test_upsert_replaces(self, db: StaticoDB) -> None:
        db.set_architecture(Architecture(type="monolith"))
        db.set_architecture(Architecture(type="microservices", principles=["DDD"]))
        result = db.get_architecture()
        assert result is not None
        assert result.type == "microservices"
        assert result.principles == ["DDD"]


# ------------------------------------------------------------------
# Environment (expanded)
# ------------------------------------------------------------------


class TestEnvironmentExpanded:
    def test_set_and_get_with_new_fields(self, db: StaticoDB) -> None:
        env = Environment(
            name="production",
            url="https://api.prod.com",
            description="Production environment",
            cloud_region="eu-west-1",
            infra_notes="3 node K8s cluster",
            monitoring_url="https://grafana.prod.com",
            access_level="ops-only",
            services_deployed=["svc-auth", "svc-orders"],
        )
        db.set_environment(env)
        envs = db.get_environments()
        assert len(envs) == 1
        result = envs[0]
        assert result.cloud_region == "eu-west-1"
        assert result.services_deployed == ["svc-auth", "svc-orders"]
        assert result.access_level == "ops-only"


# ------------------------------------------------------------------
# AccessRegistry
# ------------------------------------------------------------------


class TestAccessRegistry:
    def test_add_and_list(self, db: StaticoDB) -> None:
        entry = AccessRegistry(
            id="ar1", system_name="Jira", system_type="issue_tracker",
            url="https://jira.company.com", auth_method="api_token",
            auth_reference="JIRA_TOKEN env var",
            tags=["project_management"],
        )
        db.add_access_registry(entry)
        entries = db.get_access_registry_entries()
        assert len(entries) == 1
        assert entries[0].system_name == "Jira"
        assert entries[0].tags == ["project_management"]

    def test_get_by_id(self, db: StaticoDB) -> None:
        db.add_access_registry(AccessRegistry(
            id="ar2", system_name="AWS Console", system_type="cloud",
        ))
        result = db.get_access_registry_entry("ar2")
        assert result is not None
        assert result.system_name == "AWS Console"

    def test_get_missing_returns_none(self, db: StaticoDB) -> None:
        assert db.get_access_registry_entry("nonexistent") is None

    def test_upsert(self, db: StaticoDB) -> None:
        db.add_access_registry(AccessRegistry(id="ar3", system_name="GitLab"))
        db.add_access_registry(AccessRegistry(
            id="ar3", system_name="GitLab", auth_method="ssh_key",
        ))
        result = db.get_access_registry_entry("ar3")
        assert result is not None
        assert result.auth_method == "ssh_key"


# ------------------------------------------------------------------
# DomainModel
# ------------------------------------------------------------------


class TestDomainModel:
    def test_set_and_get(self, db: StaticoDB) -> None:
        dm = DomainModel(
            description="E-commerce platform",
            ubiquitous_language={"Order": "A customer purchase", "SKU": "Stock keeping unit"},
            entities=[{"name": "Order", "attributes": ["id", "total", "status"]}],
            business_rules=[{"id": "br1", "name": "No refund after 30 days"}],
            bounded_contexts=[{"name": "Ordering", "services": ["order-svc"]}],
        )
        db.set_domain_model(dm)
        result = db.get_domain_model()
        assert result is not None
        assert result.ubiquitous_language["Order"] == "A customer purchase"
        assert len(result.entities) == 1
        assert len(result.business_rules) == 1
        assert result.bounded_contexts[0]["name"] == "Ordering"

    def test_get_unset_returns_none(self, db: StaticoDB) -> None:
        assert db.get_domain_model() is None

    def test_upsert_replaces(self, db: StaticoDB) -> None:
        db.set_domain_model(DomainModel(description="v1"))
        db.set_domain_model(DomainModel(description="v2"))
        result = db.get_domain_model()
        assert result is not None
        assert result.description == "v2"


# ------------------------------------------------------------------
# ExternalDependency
# ------------------------------------------------------------------


class TestExternalDependency:
    def test_add_and_list(self, db: StaticoDB) -> None:
        dep = ExternalDependency(
            id="ed1", name="Stripe", category="payment",
            api_url="https://api.stripe.com",
            rate_limits={"requests_per_minute": "100"},
            tags=["billing"],
        )
        db.add_external_dependency(dep)
        deps = db.get_external_dependencies()
        assert len(deps) == 1
        assert deps[0].rate_limits["requests_per_minute"] == "100"

    def test_get_by_id(self, db: StaticoDB) -> None:
        db.add_external_dependency(ExternalDependency(
            id="ed2", name="Twilio", category="messaging",
        ))
        result = db.get_external_dependency("ed2")
        assert result is not None
        assert result.name == "Twilio"

    def test_get_missing_returns_none(self, db: StaticoDB) -> None:
        assert db.get_external_dependency("nonexistent") is None


# ------------------------------------------------------------------
# DataSchema
# ------------------------------------------------------------------


class TestDataSchema:
    def test_add_and_list(self, db: StaticoDB) -> None:
        schema = DataSchema(
            id="ds1", name="orders_db", database_type="PostgreSQL",
            tables=[{"name": "orders", "columns": [{"name": "id", "type": "uuid"}]}],
            migrations_tool="Alembic",
        )
        db.add_data_schema(schema)
        schemas = db.get_data_schemas()
        assert len(schemas) == 1
        assert schemas[0].tables[0]["name"] == "orders"

    def test_get_by_id(self, db: StaticoDB) -> None:
        db.add_data_schema(DataSchema(id="ds2", name="analytics_dw"))
        result = db.get_data_schema("ds2")
        assert result is not None
        assert result.name == "analytics_dw"

    def test_get_missing_returns_none(self, db: StaticoDB) -> None:
        assert db.get_data_schema("nonexistent") is None

    def test_fk_to_service(self, db: StaticoDB) -> None:
        db.add_service(Service(id="svc1", name="order-service"))
        db.add_data_schema(DataSchema(
            id="ds3", name="orders_db", service_id="svc1",
        ))
        result = db.get_data_schema("ds3")
        assert result is not None
        assert result.service_id == "svc1"


# ------------------------------------------------------------------
# KnowledgeEntry
# ------------------------------------------------------------------


class TestKnowledgeEntry:
    def test_add_and_list(self, db: StaticoDB) -> None:
        entry = KnowledgeEntry(
            id="ke1", title="Never deploy on Friday",
            category="gotcha", severity="critical",
            content="Production deploys on Friday have caused incidents 3 times.",
            tags=["ops", "deploy"],
        )
        db.add_knowledge_entry(entry)
        entries = db.get_knowledge_entries()
        assert len(entries) == 1
        assert entries[0].severity == "critical"
        assert entries[0].tags == ["ops", "deploy"]

    def test_get_by_id(self, db: StaticoDB) -> None:
        db.add_knowledge_entry(KnowledgeEntry(
            id="ke2", title="Use connection pooling",
        ))
        result = db.get_knowledge_entry("ke2")
        assert result is not None
        assert result.title == "Use connection pooling"

    def test_get_missing_returns_none(self, db: StaticoDB) -> None:
        assert db.get_knowledge_entry("nonexistent") is None


# ------------------------------------------------------------------
# FullContext (with new entities)
# ------------------------------------------------------------------


class TestFullContext:
    def test_includes_all_new_entities(self, db: StaticoDB) -> None:
        db.add_access_registry(AccessRegistry(id="ar1", system_name="Jira"))
        db.set_domain_model(DomainModel(description="Test domain"))
        db.add_external_dependency(ExternalDependency(id="ed1", name="Stripe"))
        db.add_data_schema(DataSchema(id="ds1", name="main_db"))
        db.add_knowledge_entry(KnowledgeEntry(id="ke1", title="Tip"))

        ctx = db.get_full_context()
        assert len(ctx.access_registry) == 1
        assert ctx.domain_model is not None
        assert ctx.domain_model.description == "Test domain"
        assert len(ctx.external_dependencies) == 1
        assert len(ctx.data_schemas) == 1
        assert len(ctx.knowledge_base) == 1

    def test_empty_context(self, db: StaticoDB) -> None:
        ctx = db.get_full_context()
        assert ctx.company_profile is None
        assert ctx.team == []
        assert ctx.access_registry == []
        assert ctx.domain_model is None
        assert ctx.external_dependencies == []
        assert ctx.data_schemas == []
        assert ctx.knowledge_base == []
