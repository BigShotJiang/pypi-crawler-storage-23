"""Tests for the FaultHandler."""

from ase.orchestrator.fault import PEER_ESCALATION_MAP, FaultHandler
from ase.config.schema import FaultToleranceConfig


def test_peer_escalation_map_covers_all_agents() -> None:
    expected = {
        "backend", "frontend", "testing", "devops", "security",
        "database", "docs", "platform", "cloud", "analyzer", "triage",
    }
    assert set(PEER_ESCALATION_MAP.keys()) == expected


def test_peer_escalation_map_values_are_lists() -> None:
    for agent, peers in PEER_ESCALATION_MAP.items():
        assert isinstance(peers, list), f"{agent} peers is not a list"
        assert len(peers) > 0, f"{agent} has no peers"


def test_fault_handler_init() -> None:
    config = FaultToleranceConfig()
    handler = FaultHandler(
        config=config,
        bridge=None,
        event_bus=None,
    )
    assert handler._config.max_self_retries == 3
    assert handler._config.max_peer_escalations == 2


def test_fault_handler_reset() -> None:
    config = FaultToleranceConfig()
    handler = FaultHandler(config=config, bridge=None, event_bus=None)
    handler._state["test"] = {"retries": 2, "peer_attempts": 1}
    handler.reset("test")
    assert "test" not in handler._state


def test_fault_handler_reset_all() -> None:
    config = FaultToleranceConfig()
    handler = FaultHandler(config=config, bridge=None, event_bus=None)
    handler._state["a"] = {"retries": 1, "peer_attempts": 0}
    handler._state["b"] = {"retries": 2, "peer_attempts": 1}
    handler.reset()
    assert handler._state == {}


def test_fault_handler_get_state_default() -> None:
    config = FaultToleranceConfig()
    handler = FaultHandler(config=config, bridge=None, event_bus=None)
    state = handler.get_state("nonexistent")
    assert state == {"retries": 0, "peer_attempts": 0}
