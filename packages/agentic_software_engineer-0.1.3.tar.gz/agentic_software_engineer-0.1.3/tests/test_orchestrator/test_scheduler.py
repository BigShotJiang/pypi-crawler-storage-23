"""Tests for the execution scheduler."""

import pytest

from ase.orchestrator.scheduler import CyclicDependencyError, Scheduler


@pytest.fixture()
def scheduler() -> Scheduler:
    return Scheduler()


def test_empty_plan(scheduler: Scheduler) -> None:
    groups = scheduler.build_groups({"steps": []})
    assert groups == []


def test_single_step(scheduler: Scheduler) -> None:
    plan = {
        "steps": [
            {"agent_type": "backend", "description": "Implement API"},
        ]
    }
    groups = scheduler.build_groups(plan)
    assert len(groups) == 1
    assert groups[0].agent_types == ["backend"]


def test_parallel_independent_steps(scheduler: Scheduler) -> None:
    plan = {
        "steps": [
            {"agent_type": "backend", "description": "Backend"},
            {"agent_type": "frontend", "description": "Frontend"},
        ]
    }
    groups = scheduler.build_groups(plan)
    assert len(groups) == 1
    assert set(groups[0].agent_types) == {"backend", "frontend"}


def test_sequential_dependencies(scheduler: Scheduler) -> None:
    plan = {
        "steps": [
            {"agent_type": "backend", "description": "Backend"},
            {"agent_type": "testing", "description": "Tests", "depends_on": ["backend"]},
        ]
    }
    groups = scheduler.build_groups(plan)
    assert len(groups) == 2
    assert groups[0].agent_types == ["backend"]
    assert groups[1].agent_types == ["testing"]


def test_complex_dependency_graph(scheduler: Scheduler) -> None:
    plan = {
        "steps": [
            {"agent_type": "database", "description": "Schema"},
            {"agent_type": "backend", "description": "API", "depends_on": ["database"]},
            {"agent_type": "frontend", "description": "UI", "depends_on": ["backend"]},
            {"agent_type": "testing", "description": "Tests", "depends_on": ["backend"]},
        ]
    }
    groups = scheduler.build_groups(plan)
    assert len(groups) == 3
    assert groups[0].agent_types == ["database"]
    assert groups[1].agent_types == ["backend"]
    assert set(groups[2].agent_types) == {"frontend", "testing"}


def test_cyclic_dependency_raises(scheduler: Scheduler) -> None:
    plan = {
        "steps": [
            {"agent_type": "a", "description": "A", "depends_on": ["b"]},
            {"agent_type": "b", "description": "B", "depends_on": ["a"]},
        ]
    }
    with pytest.raises(CyclicDependencyError):
        scheduler.build_groups(plan)


def test_unknown_dependency_raises(scheduler: Scheduler) -> None:
    plan = {
        "steps": [
            {"agent_type": "a", "description": "A", "depends_on": ["nonexistent"]},
        ]
    }
    with pytest.raises(ValueError, match="nonexistent"):
        scheduler.build_groups(plan)


def test_max_parallelism(scheduler: Scheduler) -> None:
    plan = {
        "steps": [
            {"agent_type": "a", "description": "A"},
            {"agent_type": "b", "description": "B"},
            {"agent_type": "c", "description": "C"},
        ]
    }
    groups = scheduler.build_groups(plan)
    assert Scheduler.max_parallelism(groups) == 3


def test_critical_path_length(scheduler: Scheduler) -> None:
    plan = {
        "steps": [
            {"agent_type": "a", "description": "A"},
            {"agent_type": "b", "description": "B", "depends_on": ["a"]},
            {"agent_type": "c", "description": "C", "depends_on": ["b"]},
        ]
    }
    groups = scheduler.build_groups(plan)
    assert Scheduler.critical_path_length(groups) == 3
