"""Tests for the EventHandlerRegistry."""

import asyncio

import pytest

from ase.events.handlers import EventHandlerRegistry
from ase.events.types import Event, EventType


@pytest.fixture()
def registry() -> EventHandlerRegistry:
    return EventHandlerRegistry()


def test_register_handler(registry: EventHandlerRegistry) -> None:
    async def handler(event: Event) -> None:
        pass

    registry.register(EventType.AGENT_SPAWNED, handler)
    assert len(registry.get_handlers(EventType.AGENT_SPAWNED)) == 1


def test_decorator_registration(registry: EventHandlerRegistry) -> None:
    @registry.on(EventType.TEST_PASSED)
    async def on_test_passed(event: Event) -> None:
        pass

    assert len(registry.get_handlers(EventType.TEST_PASSED)) == 1


def test_unregister_handler(registry: EventHandlerRegistry) -> None:
    async def handler(event: Event) -> None:
        pass

    registry.register(EventType.BLOCKED, handler)
    registry.unregister(EventType.BLOCKED, handler)
    assert len(registry.get_handlers(EventType.BLOCKED)) == 0


@pytest.mark.asyncio
async def test_dispatch(registry: EventHandlerRegistry) -> None:
    results: list[str] = []

    @registry.on(EventType.ARTIFACT_CREATED)
    async def handler(event: Event) -> None:
        results.append("handled")

    event = Event(
        event_type=EventType.ARTIFACT_CREATED,
        source_agent="backend",
        ticket_id=1,
    )
    outcomes = await registry.dispatch(event)
    assert len(outcomes) == 1
    assert outcomes[0] is None
    assert results == ["handled"]


def test_handler_count(registry: EventHandlerRegistry) -> None:
    async def h1(event: Event) -> None:
        pass

    async def h2(event: Event) -> None:
        pass

    registry.register(EventType.AGENT_SPAWNED, h1)
    registry.register(EventType.AGENT_COMPLETED, h2)
    assert registry.handler_count == 2
