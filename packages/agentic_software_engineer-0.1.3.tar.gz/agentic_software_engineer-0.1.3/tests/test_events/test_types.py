"""Tests for event types and payload models."""

from ase.events.types import (
    ArtifactCreatedPayload,
    BlockedPayload,
    Event,
    EventType,
    TestResultPayload,
)


def test_event_type_values() -> None:
    assert EventType.ARTIFACT_CREATED.value == "artifact_created"
    assert EventType.BLOCKED.value == "blocked"
    assert EventType.HUMAN_REQUIRED.value == "human_required"


def test_artifact_payload() -> None:
    p = ArtifactCreatedPayload(
        artifact_type="source_file",
        file_path="src/main.py",
        language="python",
    )
    assert p.artifact_type == "source_file"
    assert p.metadata == {}


def test_test_result_payload() -> None:
    p = TestResultPayload(
        test_suite="tests/",
        total_tests=10,
        passed=8,
        failed=2,
    )
    assert p.passed + p.failed == p.total_tests


def test_blocked_payload() -> None:
    p = BlockedPayload(reason="missing API")
    assert p.escalation_level == 0


def test_event_envelope() -> None:
    e = Event(
        event_type=EventType.AGENT_SPAWNED,
        source_agent="orchestrator",
        ticket_id=1,
        payload={"agent_type": "backend"},
    )
    assert e.event_type == EventType.AGENT_SPAWNED
    assert e.target_agents == []
