"""Tests for the specialized agent registry."""

from ase.agents.specialized import AGENT_REGISTRY
from ase.agents.base import BaseAgent


def test_agent_registry_has_all_types() -> None:
    expected = {
        "analyzer", "triage", "backend", "frontend", "testing",
        "devops", "security", "database", "docs", "platform", "cloud",
    }
    assert set(AGENT_REGISTRY.keys()) == expected


def test_all_agents_extend_base_agent() -> None:
    for name, cls in AGENT_REGISTRY.items():
        assert issubclass(cls, BaseAgent), f"{name} does not extend BaseAgent"


def test_all_agents_have_system_prompt() -> None:
    """Verify each agent class overrides get_system_prompt (not directly callable
    without context, but we can check it's not abstract)."""
    for name, cls in AGENT_REGISTRY.items():
        assert hasattr(cls, "get_system_prompt"), f"{name} missing get_system_prompt"
        # The method should not be abstract
        assert "get_system_prompt" in cls.__dict__, (
            f"{name} does not override get_system_prompt"
        )
