"""Tests for the MCPBridge."""

from ase.agents.bridge import MCPBridge, SEPARATOR


def test_bridge_init() -> None:
    bridge = MCPBridge()
    assert bridge.registered_servers == []
    assert bridge.registered_tools == []


def test_bridge_separator() -> None:
    assert SEPARATOR == "__"


def test_bridge_repr() -> None:
    bridge = MCPBridge()
    r = repr(bridge)
    assert "MCPBridge" in r
    assert "servers=0" in r
    assert "tools=0" in r
