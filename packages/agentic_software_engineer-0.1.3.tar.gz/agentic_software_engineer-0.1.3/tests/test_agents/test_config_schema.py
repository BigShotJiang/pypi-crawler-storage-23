"""Tests for the Pydantic config schema."""

from pathlib import Path

from ase.config.schema import (
    ASEConfig,
    AgentsConfig,
    FaultToleranceConfig,
    HILConfig,
    LLMConfig,
    LLMRetryConfig,
    MCPConfig,
    MCPTransport,
    NotificationMethod,
    ReviewMethod,
    TimeoutConfig,
)


def test_llm_retry_defaults() -> None:
    cfg = LLMRetryConfig()
    assert cfg.max_retries == 3
    assert cfg.base_delay_seconds == 1.0
    assert cfg.max_delay_seconds == 30.0


def test_llm_config_defaults() -> None:
    cfg = LLMConfig()
    assert "claude" in cfg.default_model
    assert cfg.cost_limit_per_ticket_usd == 5.0
    assert cfg.cost_limit_daily_usd == 100.0


def test_mcp_transport_enum() -> None:
    assert MCPTransport.STDIO.value == "stdio"
    assert MCPTransport.SSE.value == "sse"


def test_mcp_config_defaults() -> None:
    cfg = MCPConfig()
    assert cfg.transport == MCPTransport.STDIO
    assert "operativo" in cfg.operativo_command
    assert "statico" in cfg.statico_command


def test_fault_tolerance_defaults() -> None:
    cfg = FaultToleranceConfig()
    assert cfg.max_self_retries == 3
    assert cfg.max_peer_escalations == 2


def test_hil_config_defaults() -> None:
    cfg = HILConfig()
    assert cfg.review_method == ReviewMethod.PR
    assert cfg.notification_method == NotificationMethod.STDOUT


def test_agents_config_defaults() -> None:
    cfg = AgentsConfig()
    assert "triage" in cfg.enabled
    assert "backend" in cfg.enabled


def test_ase_config_full() -> None:
    cfg = ASEConfig(
        project={
            "name": "test",
            "root_path": "/tmp/test",
            "db_path": "/tmp/test/ase.db",
        }
    )
    assert cfg.project.name == "test"
    assert cfg.llm.default_model is not None
    assert cfg.mcp.transport == MCPTransport.STDIO
