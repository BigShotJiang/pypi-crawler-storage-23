"""Tests for the SQLite connection manager."""

import sqlite3
from pathlib import Path

from ase.db.connection import create_connection


def test_create_connection_creates_file(tmp_path: Path) -> None:
    db_path = tmp_path / "test.db"
    conn = create_connection(db_path)
    assert db_path.exists()
    conn.close()


def test_create_connection_wal_mode(tmp_path: Path) -> None:
    db_path = tmp_path / "test.db"
    conn = create_connection(db_path)
    mode = conn.execute("PRAGMA journal_mode").fetchone()[0]
    assert mode == "wal"
    conn.close()


def test_create_connection_foreign_keys_on(tmp_path: Path) -> None:
    db_path = tmp_path / "test.db"
    conn = create_connection(db_path)
    fk = conn.execute("PRAGMA foreign_keys").fetchone()[0]
    assert fk == 1
    conn.close()


def test_create_connection_row_factory(tmp_path: Path) -> None:
    db_path = tmp_path / "test.db"
    conn = create_connection(db_path)
    assert conn.row_factory == sqlite3.Row
    conn.close()


def test_create_connection_creates_parent_dirs(tmp_path: Path) -> None:
    db_path = tmp_path / "nested" / "dirs" / "test.db"
    conn = create_connection(db_path)
    assert db_path.exists()
    conn.close()
