"""Tests for the SQL schema."""

import sqlite3
from pathlib import Path

SCHEMA_SQL = (Path(__file__).parent.parent.parent / "src" / "ase" / "db" / "schema.sql").read_text()


def test_schema_creates_all_tables(tmp_path: Path) -> None:
    db = sqlite3.connect(str(tmp_path / "test.db"))
    db.executescript(SCHEMA_SQL)

    tables = {
        row[0]
        for row in db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        ).fetchall()
    }

    expected = {
        "schema_version",
        "tickets",
        "agent_assignments",
        "artifacts",
        "events",
        "decision_log",
        "human_feedback",
        "cost_log",
        "company_profile",
        "team_members",
        "tech_stack",
        "architecture",
        "services",
        "api_contracts",
        "conventions",
        "environments",
        "blueprints",
    }
    assert expected.issubset(tables), f"Missing tables: {expected - tables}"
    db.close()


def test_schema_idempotent(tmp_path: Path) -> None:
    db = sqlite3.connect(str(tmp_path / "test.db"))
    db.executescript(SCHEMA_SQL)
    db.executescript(SCHEMA_SQL)  # Should not raise
    db.close()
