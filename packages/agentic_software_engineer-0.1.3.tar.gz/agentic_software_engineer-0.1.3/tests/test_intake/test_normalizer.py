"""Tests for the intake normaliser."""

from ase.intake.normalizer import normalize


def test_normalize_strips_whitespace() -> None:
    assert normalize("  hello  ") == "hello"


def test_normalize_empty_string() -> None:
    assert normalize("") == ""


def test_normalize_whitespace_only() -> None:
    assert normalize("   \n\t  ") == ""


def test_normalize_collapse_horizontal_whitespace() -> None:
    assert normalize("hello   world") == "hello world"


def test_normalize_collapse_blank_lines() -> None:
    result = normalize("a\n\n\n\n\nb")
    assert result == "a\n\nb"


def test_normalize_removes_control_chars() -> None:
    result = normalize("hello\x00world")
    assert result == "helloworld"


def test_normalize_preserves_newlines() -> None:
    result = normalize("line1\nline2")
    assert "\n" in result


def test_normalize_unicode_nfc() -> None:
    # e + combining accent -> single char
    import unicodedata
    composed = unicodedata.normalize("NFC", "e\u0301")
    result = normalize("e\u0301")
    assert result == composed
