"""Tests for the TextSource intake."""

from ase.intake.sources.text import NormalizedInput, TextSource


def test_text_source_normalizes() -> None:
    source = TextSource("  Fix the login bug  ")
    ni = source.to_normalized_input()
    assert isinstance(ni, NormalizedInput)
    assert ni.normalized == "Fix the login bug"
    assert ni.raw == "  Fix the login bug  "


def test_text_source_source_type() -> None:
    ni = TextSource("test").to_normalized_input()
    assert ni.source_type == "text"


def test_text_source_callable() -> None:
    source = TextSource("hello")
    ni = source()
    assert ni.normalized == "hello"
