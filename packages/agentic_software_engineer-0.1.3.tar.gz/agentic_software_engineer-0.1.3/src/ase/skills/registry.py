"""
Skill registry -- in-memory index of loaded skills.

Provides fast lookup by name, tag and agent-type mapping.
The ``SkillsConfig`` in ``ase.config.schema`` declares which skills
are preloaded into which agents.
"""

from __future__ import annotations

import logging
from typing import Iterable

from ase.skills.loader import Skill, SkillLoader

logger = logging.getLogger(__name__)


class SkillRegistry:
    """Central store for all discovered skills.

    Typical lifecycle::

        loader   = SkillLoader(project_root / ".ase" / "skills")
        registry = SkillRegistry()
        registry.load_from(loader)

        # Preload skills into an agent's system prompt
        blocks = registry.get_prompt_blocks(["docker-best-practices", "api-design"])
    """

    def __init__(self) -> None:
        self._skills: dict[str, Skill] = {}

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------

    def load_from(self, loader: SkillLoader) -> int:
        """Discover and register all skills from a :class:`SkillLoader`.

        Returns the number of newly registered skills.
        """
        loaded = loader.load_all()
        count = 0
        for skill in loaded:
            if skill.name in self._skills:
                logger.warning(
                    "Skill '%s' already registered (from %s), "
                    "overwriting with %s",
                    skill.name,
                    self._skills[skill.name].source_path,
                    skill.source_path,
                )
            self._skills[skill.name] = skill
            count += 1
        return count

    def register(self, skill: Skill) -> None:
        """Register a single skill (e.g. built-in or programmatic)."""
        self._skills[skill.name] = skill

    # ------------------------------------------------------------------
    # Lookups
    # ------------------------------------------------------------------

    def get(self, name: str) -> Skill | None:
        """Get a skill by exact name."""
        return self._skills.get(name)

    def get_by_tag(self, tag: str) -> list[Skill]:
        """Return all skills that have a given tag."""
        return [s for s in self._skills.values() if tag in s.tags]

    def get_invocable(self) -> list[Skill]:
        """Return all user-invocable skills (not agent-only)."""
        return [s for s in self._skills.values() if s.user_invocable]

    def list_all(self) -> list[Skill]:
        """Return all registered skills, sorted by name."""
        return sorted(self._skills.values(), key=lambda s: s.name)

    # ------------------------------------------------------------------
    # Prompt injection
    # ------------------------------------------------------------------

    def get_prompt_blocks(self, skill_names: Iterable[str]) -> str:
        """Build a combined prompt block for the given skill names.

        Skills that are not found are silently skipped (with a warning).
        """
        blocks: list[str] = []
        for name in skill_names:
            skill = self._skills.get(name)
            if skill is None:
                logger.warning("Skill '%s' requested but not found in registry", name)
                continue
            blocks.append(skill.to_prompt_block())

        if not blocks:
            return ""
        return "\n\n---\n\n".join(blocks)

    # ------------------------------------------------------------------
    # Dunder
    # ------------------------------------------------------------------

    def __len__(self) -> int:
        return len(self._skills)

    def __contains__(self, name: str) -> bool:
        return name in self._skills

    def __repr__(self) -> str:
        return f"<SkillRegistry skills={len(self._skills)}>"
