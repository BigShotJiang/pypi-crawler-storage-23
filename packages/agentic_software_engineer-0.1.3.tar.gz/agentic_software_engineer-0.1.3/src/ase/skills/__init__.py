"""
Skill system -- reusable knowledge modules for agents.

Skills are shareable blocks of domain knowledge, procedures, or best
practices that can be:

- **Preloaded** into an agent at startup (agent skill -- injected into
  the system prompt automatically)
- **Invoked on-demand** by the orchestrator or another agent when a
  specific capability is needed

This decouples *knowledge* from *agents*: the same ``docker-best-practices``
skill can be preloaded into both the DevOpsAgent and the BackendAgent
without duplicating the prompt text.

Example ``skills/`` directory::

    .ase/skills/
    ├── docker-best-practices/
    │   └── SKILL.md
    ├── api-design/
    │   └── SKILL.md
    └── testing-strategy/
        └── SKILL.md

Each skill is a Markdown file at ``<skill_dir>/SKILL.md`` with optional
YAML front-matter (name, description, tags).
"""

from ase.skills.loader import Skill, SkillLoader
from ase.skills.registry import SkillRegistry

__all__ = [
    "Skill",
    "SkillLoader",
    "SkillRegistry",
]
