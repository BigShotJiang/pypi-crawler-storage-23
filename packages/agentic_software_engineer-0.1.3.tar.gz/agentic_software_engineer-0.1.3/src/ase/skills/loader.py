"""
Skill loader -- reads SKILL.md files from disk and parses front-matter.

A skill file looks like::

    ---
    name: docker-best-practices
    description: Container image guidelines for production workloads
    tags: [docker, devops, backend]
    ---

    # Docker Best Practices
    ...body text...

If no front-matter is present, the directory name is used as the skill
name and the entire file is treated as body.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_FRONT_MATTER_RE = re.compile(
    r"\A---\s*\n(.*?)\n---\s*\n(.*)",
    re.DOTALL,
)


@dataclass(frozen=True)
class Skill:
    """A single loaded skill.

    Attributes
    ----------
    name:
        Human-readable identifier.  Comes from front-matter ``name:``
        or falls back to the directory name.
    description:
        Optional one-liner shown in listings.
    tags:
        Free-form tags for filtering / matching (e.g. ``["docker", "devops"]``).
    body:
        The Markdown body that will be injected into the agent's prompt.
    source_path:
        Absolute path to the SKILL.md file on disk.
    user_invocable:
        If ``True`` (default), can be invoked on-demand.  If ``False``,
        the skill is intended only for agent preloading.
    """

    name: str
    body: str
    source_path: Path
    description: str = ""
    tags: list[str] = field(default_factory=list)
    user_invocable: bool = True

    def to_prompt_block(self) -> str:
        """Format the skill for injection into a system prompt."""
        header = f"## Skill: {self.name}"
        if self.description:
            header += f"\n> {self.description}"
        return f"{header}\n\n{self.body}"


class SkillLoader:
    """Loads skills from a directory tree.

    Expected layout::

        skills_dir/
        ├── docker-best-practices/
        │   └── SKILL.md
        ├── api-design/
        │   └── SKILL.md
        └── testing-strategy.md        # flat file (name = stem)
    """

    SKILL_FILENAME = "SKILL.md"

    def __init__(self, skills_dir: Path) -> None:
        self._skills_dir = skills_dir

    @property
    def skills_dir(self) -> Path:
        return self._skills_dir

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load_all(self) -> list[Skill]:
        """Discover and load every skill under ``skills_dir``."""
        if not self._skills_dir.exists():
            logger.debug("Skills directory does not exist: %s", self._skills_dir)
            return []

        skills: list[Skill] = []

        # Pattern 1: subdirectory with SKILL.md
        for child in sorted(self._skills_dir.iterdir()):
            if child.is_dir():
                skill_file = child / self.SKILL_FILENAME
                if skill_file.is_file():
                    skill = self._load_skill_file(skill_file, default_name=child.name)
                    if skill:
                        skills.append(skill)
            elif child.is_file() and child.suffix == ".md":
                # Pattern 2: flat Markdown file
                skill = self._load_skill_file(child, default_name=child.stem)
                if skill:
                    skills.append(skill)

        logger.info("Loaded %d skill(s) from %s", len(skills), self._skills_dir)
        return skills

    def load_one(self, name: str) -> Skill | None:
        """Load a single skill by name.

        Looks for ``skills_dir/<name>/SKILL.md`` first, then
        ``skills_dir/<name>.md``.
        """
        # Validate name to prevent path traversal
        if not re.fullmatch(r"[a-zA-Z0-9_-]+", name):
            logger.warning("Invalid skill name (path traversal attempt?): %s", name)
            return None

        # Try subdirectory first
        subdir = self._skills_dir / name / self.SKILL_FILENAME
        if subdir.is_file():
            return self._load_skill_file(subdir, default_name=name)

        # Try flat file
        flat = self._skills_dir / f"{name}.md"
        if flat.is_file():
            return self._load_skill_file(flat, default_name=name)

        logger.warning("Skill not found: %s", name)
        return None

    # ------------------------------------------------------------------
    # Parsing
    # ------------------------------------------------------------------

    def _load_skill_file(self, path: Path, *, default_name: str) -> Skill | None:
        """Read a single SKILL.md and return a ``Skill`` instance."""
        try:
            raw = path.read_text(encoding="utf-8")
        except OSError as exc:
            logger.error("Cannot read skill file %s: %s", path, exc)
            return None

        front_matter, body = self._split_front_matter(raw)

        name = front_matter.get("name", default_name)
        description = front_matter.get("description", "")
        tags = front_matter.get("tags", [])
        user_invocable = front_matter.get("user-invocable", True)

        if isinstance(tags, str):
            tags = [t.strip() for t in tags.split(",")]

        return Skill(
            name=name,
            description=description,
            tags=tags,
            body=body.strip(),
            source_path=path.resolve(),
            user_invocable=user_invocable,
        )

    @staticmethod
    def _split_front_matter(text: str) -> tuple[dict[str, Any], str]:
        """Split YAML front-matter from the Markdown body.

        Returns (front_matter_dict, body_string).  If no front-matter is
        found, returns ({}, full_text).

        Uses a minimal YAML subset parser to avoid a PyYAML dependency:
        supports ``key: value``, ``key: [a, b, c]``, and booleans.
        """
        match = _FRONT_MATTER_RE.match(text)
        if not match:
            return {}, text

        raw_fm = match.group(1)
        body = match.group(2)

        fm: dict[str, Any] = {}
        for line in raw_fm.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if ":" not in line:
                continue
            key, _, value = line.partition(":")
            key = key.strip()
            value = value.strip()

            # Parse [a, b, c] list syntax
            if value.startswith("[") and value.endswith("]"):
                inner = value[1:-1]
                fm[key] = [v.strip().strip("\"'") for v in inner.split(",") if v.strip()]
            # Parse booleans
            elif value.lower() in ("true", "yes"):
                fm[key] = True
            elif value.lower() in ("false", "no"):
                fm[key] = False
            else:
                fm[key] = value.strip("\"'")

        return fm, body
