"""Onboarding -- context discovery, completeness detection, and memory consolidation."""
