"""
Memory Consolidator -- learns from completed work and enriches the knowledge base.

After each ticket is completed, the consolidator:
1. Reads the ticket history (what was done, decisions made, code produced).
2. Asks the LLM to extract "important learnings" — patterns discovered,
   gotchas encountered, conventions inferred, architecture decisions.
3. De-duplicates against existing knowledge entries.
4. Persists high-value insights to Statico's KnowledgeBase.

This mimics long-term memory consolidation: only truly useful information
is retained, preventing noise accumulation.
"""

from __future__ import annotations

import json
import logging
import uuid
from datetime import datetime, timezone
from typing import Any

from ase.agents.bridge import MCPBridge
from ase.llm.client import LLMClient

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

_EXTRACTION_PROMPT = """\
You are the ASE Memory Consolidator.  You have just completed work on a
software engineering ticket.  Your job is to extract ONLY the information
worth remembering for future work.

WHAT TO EXTRACT:
- Architectural decisions and their rationale
- Gotchas / pitfalls discovered (things that broke or were tricky)
- New conventions established or discovered
- Patterns that worked well
- Important domain knowledge learned
- External dependency quirks or version constraints
- Performance insights
- Security considerations discovered

WHAT TO SKIP:
- Routine implementation details ("I created file X")
- Obvious best practices everyone knows
- Temporary workarounds that won't matter again
- Information already present in the existing knowledge base

Return a JSON array of knowledge entries.  Each entry must have:
{
    "title": "Short descriptive title",
    "category": "one of: gotcha, convention, architecture, pattern, domain, dependency, performance, security",
    "content": "Detailed description of the learning",
    "related_services": ["service IDs if applicable"],
    "tags": ["relevant", "tags"],
    "severity": "one of: info, warning, critical"
}

If there is NOTHING worth remembering, return an empty array: []
Be selective — quality over quantity.  Consolidate, don't hoard.
"""

_DEDUP_PROMPT = """\
Compare these NEW knowledge entries against EXISTING entries in the knowledge base.

For each new entry, decide:
- "add" — genuinely new information, not covered by existing entries.
- "update" — refines or extends an existing entry (provide the existing ID to update).
- "skip" — already covered by existing entries or too trivial.

Return a JSON array where each element is:
{
    "action": "add" | "update" | "skip",
    "entry": { ... the entry to add/update ... },
    "existing_id": "ID of existing entry to update (only for 'update' action)",
    "reason": "brief reason for the decision"
}
"""


# ---------------------------------------------------------------------------
# Consolidator
# ---------------------------------------------------------------------------

class MemoryConsolidator:
    """Extracts and persists important learnings from completed tickets.

    Parameters
    ----------
    bridge:
        Connected MCPBridge.
    llm_client:
        LLM client for extraction and dedup.
    """

    def __init__(self, bridge: MCPBridge, llm_client: LLMClient) -> None:
        self._bridge = bridge
        self._llm = llm_client

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def consolidate(self, ticket_id: str | int) -> list[dict[str, Any]]:
        """Extract and persist learnings from a completed ticket.

        Parameters
        ----------
        ticket_id:
            ID of the completed ticket.

        Returns
        -------
        list[dict]
            The knowledge entries that were actually persisted.
        """
        logger.info("Consolidating memory for ticket %s", ticket_id)

        # 1. Gather ticket history
        history = await self._gather_ticket_history(str(ticket_id))
        if not history:
            logger.info("No history found for ticket %s — skipping", ticket_id)
            return []

        # 2. Extract learnings via LLM
        raw_entries = await self._extract_learnings(history)
        if not raw_entries:
            logger.info(
                "No significant learnings extracted from ticket %s", ticket_id
            )
            return []

        logger.info("Extracted %d candidate learnings", len(raw_entries))

        # 3. De-duplicate against existing knowledge base
        existing = await self._fetch_existing_knowledge()
        actions = await self._deduplicate(raw_entries, existing)

        # 4. Persist
        persisted = await self._apply_actions(actions, str(ticket_id))

        logger.info(
            "Consolidated %d new knowledge entries from ticket %s",
            len(persisted),
            ticket_id,
        )

        return persisted

    async def periodic_sweep(self, max_tickets: int = 10) -> int:
        """Check recent completed tickets and consolidate any that haven't been processed.

        Returns the number of tickets processed.
        """
        logger.info("Running periodic memory sweep (max %d tickets)", max_tickets)

        # Get recent completed tickets
        try:
            result = await self._bridge.execute_tool_call(
                "operativo__list_tickets",
                {"status": "done", "limit": max_tickets},
            )
        except Exception as exc:
            logger.warning("Failed to list completed tickets: %s", exc)
            return 0

        tickets = self._parse_mcp_result(result)
        if not isinstance(tickets, list):
            tickets = tickets.get("tickets", []) if isinstance(tickets, dict) else []

        processed = 0
        for ticket in tickets:
            tid = ticket.get("id") if isinstance(ticket, dict) else None
            if tid is None:
                continue

            # Check if we already consolidated this ticket
            if await self._already_consolidated(str(tid)):
                continue

            await self.consolidate(str(tid))
            processed += 1

        logger.info("Periodic sweep processed %d tickets", processed)
        return processed

    # ------------------------------------------------------------------
    # Step 1: Gather history
    # ------------------------------------------------------------------

    async def _gather_ticket_history(self, ticket_id: str) -> dict[str, Any]:
        """Collect all available data about a completed ticket."""
        history: dict[str, Any] = {}

        # Get ticket details
        try:
            ticket = await self._bridge.execute_tool_call(
                "operativo__get_ticket", {"ticket_id": ticket_id}
            )
            history["ticket"] = self._parse_mcp_result(ticket)
        except Exception as exc:
            logger.debug("Could not fetch ticket %s: %s", ticket_id, exc)

        # Get assignments
        try:
            assignments = await self._bridge.execute_tool_call(
                "operativo__get_assignments", {"ticket_id": ticket_id}
            )
            history["assignments"] = self._parse_mcp_result(assignments)
        except Exception:
            pass

        # Get decision log
        try:
            decisions = await self._bridge.execute_tool_call(
                "operativo__get_decision_log", {"ticket_id": ticket_id}
            )
            history["decisions"] = self._parse_mcp_result(decisions)
        except Exception:
            pass

        # Get artifacts
        try:
            artifacts = await self._bridge.execute_tool_call(
                "operativo__list_artifacts", {"ticket_id": ticket_id}
            )
            history["artifacts"] = self._parse_mcp_result(artifacts)
        except Exception:
            pass

        return history

    # ------------------------------------------------------------------
    # Step 2: LLM extraction
    # ------------------------------------------------------------------

    async def _extract_learnings(
        self, history: dict[str, Any]
    ) -> list[dict[str, Any]]:
        """Ask the LLM to extract important learnings from ticket history."""
        history_text = json.dumps(history, indent=2, default=str)

        # Truncate if very long
        if len(history_text) > 30_000:
            history_text = history_text[:30_000] + "\n... [truncated]"

        messages = [
            {"role": "system", "content": _EXTRACTION_PROMPT},
            {
                "role": "user",
                "content": (
                    f"## Completed ticket history\n\n"
                    f"```json\n{history_text}\n```\n\n"
                    "Extract the important learnings as a JSON array."
                ),
            },
        ]

        response = await self._llm.chat(messages=messages, temperature=0.1)

        if not response.content:
            return []

        parsed = self._extract_json_array(response.content)
        return parsed if isinstance(parsed, list) else []

    # ------------------------------------------------------------------
    # Step 3: De-duplication
    # ------------------------------------------------------------------

    async def _deduplicate(
        self,
        new_entries: list[dict[str, Any]],
        existing_entries: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Ask the LLM to compare new entries against existing knowledge."""
        if not existing_entries:
            # Nothing to dedup against — add everything
            return [
                {"action": "add", "entry": e, "reason": "no existing knowledge"}
                for e in new_entries
            ]

        messages = [
            {"role": "system", "content": _DEDUP_PROMPT},
            {
                "role": "user",
                "content": (
                    f"## NEW entries\n```json\n"
                    f"{json.dumps(new_entries, indent=2)}\n```\n\n"
                    f"## EXISTING knowledge base\n```json\n"
                    f"{json.dumps(existing_entries, indent=2)}\n```\n\n"
                    "Decide which new entries to add, update, or skip."
                ),
            },
        ]

        response = await self._llm.chat(messages=messages, temperature=0.1)

        if not response.content:
            # Fallback: add everything
            return [
                {"action": "add", "entry": e, "reason": "dedup failed"}
                for e in new_entries
            ]

        parsed = self._extract_json_array(response.content)
        return parsed if isinstance(parsed, list) else []

    # ------------------------------------------------------------------
    # Step 4: Persistence
    # ------------------------------------------------------------------

    async def _apply_actions(
        self, actions: list[dict[str, Any]], ticket_id: str
    ) -> list[dict[str, Any]]:
        """Persist the de-duplicated knowledge entries."""
        persisted: list[dict[str, Any]] = []
        now = datetime.now(timezone.utc).isoformat()

        for action_item in actions:
            action = action_item.get("action", "skip")
            entry = action_item.get("entry", {})

            if action == "skip":
                logger.debug(
                    "Skipping entry '%s': %s",
                    entry.get("title", "?"),
                    action_item.get("reason", ""),
                )
                continue

            if action in ("add", "update"):
                # Ensure required fields
                entry_id = action_item.get("existing_id") or str(uuid.uuid4())[:8]
                params = {
                    "id": entry_id,
                    "title": entry.get("title", "Untitled learning"),
                    "category": entry.get("category", "general"),
                    "content": entry.get("content", ""),
                    "related_services": entry.get("related_services", []),
                    "author": f"consolidator/ticket-{ticket_id}",
                    "tags": entry.get("tags", []),
                    "severity": entry.get("severity", "info"),
                    "created_date": now,
                }

                try:
                    await self._bridge.execute_tool_call(
                        "statico__add_knowledge_entry", params
                    )
                    persisted.append(params)
                    logger.info(
                        "%s knowledge entry: %s",
                        "Updated" if action == "update" else "Added",
                        params["title"],
                    )
                except Exception as exc:
                    logger.warning(
                        "Failed to persist entry '%s': %s",
                        params["title"],
                        exc,
                    )

        return persisted

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    async def _fetch_existing_knowledge(self) -> list[dict[str, Any]]:
        """Get all current knowledge entries from Statico."""
        try:
            result = await self._bridge.execute_tool_call(
                "statico__get_knowledge_entries", {}
            )
            parsed = self._parse_mcp_result(result)
            return parsed if isinstance(parsed, list) else []
        except Exception:
            return []

    async def _already_consolidated(self, ticket_id: str) -> bool:
        """Check if this ticket has already had its memory consolidated."""
        existing = await self._fetch_existing_knowledge()
        author_tag = f"consolidator/ticket-{ticket_id}"
        return any(
            e.get("author") == author_tag
            for e in existing
            if isinstance(e, dict)
        )

    @staticmethod
    def _parse_mcp_result(result: Any) -> Any:
        """Parse an MCP tool result into a Python object."""
        if isinstance(result, (dict, list)):
            return result

        if hasattr(result, "content"):
            for block in result.content:
                if hasattr(block, "text"):
                    try:
                        return json.loads(block.text)
                    except (json.JSONDecodeError, AttributeError):
                        continue

        return result

    @staticmethod
    def _extract_json_array(text: str) -> list[Any] | None:
        """Extract a JSON array from LLM text output."""
        import re

        # Direct parse
        try:
            parsed = json.loads(text)
            if isinstance(parsed, list):
                return parsed
            return None
        except json.JSONDecodeError:
            pass

        # Markdown code block
        patterns = [
            r"```json\s*\n(.*?)\n```",
            r"```\s*\n(.*?)\n```",
            r"\[.*\]",
        ]
        for pattern in patterns:
            match = re.search(pattern, text, re.DOTALL)
            if match:
                try:
                    candidate = match.group(1) if match.lastindex else match.group(0)
                    parsed = json.loads(candidate)
                    if isinstance(parsed, list):
                        return parsed
                except (json.JSONDecodeError, IndexError):
                    continue

        return None
