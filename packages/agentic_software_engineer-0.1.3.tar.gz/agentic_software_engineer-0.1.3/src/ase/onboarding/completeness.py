"""
Completeness checker for MCP Statico context.

Inspects the current state of the Statico knowledge base and scores how
ready the system is to operate autonomously.  Returns a structured report
listing which sections are populated and which have gaps.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Severity of a missing section
# ---------------------------------------------------------------------------

class Criticality(str, Enum):
    """How critical a missing section is to agent operation."""

    CRITICAL = "critical"      # agents cannot work without this
    IMPORTANT = "important"    # agents will produce sub-par work
    NICE_TO_HAVE = "nice"      # improves quality but not required


# ---------------------------------------------------------------------------
# Gap model
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ContextGap:
    """Describes one piece of missing context."""

    section: str
    criticality: Criticality
    description: str
    questions: list[str] = field(default_factory=list)
    auto_discoverable: bool = False
    auto_discovery_hint: str = ""


@dataclass
class CompletenessReport:
    """Overall report of how complete the Statico context is."""

    score: float                      # 0.0 – 1.0
    total_sections: int
    populated_sections: int
    gaps: list[ContextGap]
    populated: list[str]              # names of filled-in sections

    @property
    def is_ready(self) -> bool:
        """True if no CRITICAL gaps remain."""
        return not any(g.criticality == Criticality.CRITICAL for g in self.gaps)

    @property
    def critical_gaps(self) -> list[ContextGap]:
        return [g for g in self.gaps if g.criticality == Criticality.CRITICAL]

    @property
    def important_gaps(self) -> list[ContextGap]:
        return [g for g in self.gaps if g.criticality == Criticality.IMPORTANT]


# ---------------------------------------------------------------------------
# Section definitions
# ---------------------------------------------------------------------------

# Each section maps to a key in FullContext and defines how to check whether
# it is considered "populated" and what questions to ask to fill it.

SECTIONS: list[dict[str, Any]] = [
    {
        "key": "company_profile",
        "label": "Company Profile",
        "criticality": Criticality.CRITICAL,
        "description": "Who is the company, what they do, and their domain.",
        "is_populated": lambda v: v is not None and bool(v.get("name")),
        "questions": [
            "What is the company name?",
            "What does the company do (core business purpose)?",
            "What domain/industry does it operate in?",
        ],
        "auto_discoverable": True,
        "auto_discovery_hint": "Check README.md, package.json, or any 'about' page.",
    },
    {
        "key": "tech_stack",
        "label": "Tech Stack",
        "criticality": Criticality.CRITICAL,
        "description": "Languages, frameworks, databases, cloud, and CI/CD tooling.",
        "is_populated": lambda v: v is not None and (
            bool(v.get("languages")) or bool(v.get("frameworks"))
        ),
        "questions": [
            "What programming languages are used?",
            "What frameworks are used (e.g. FastAPI, React, Django)?",
            "Which database(s) are in use?",
            "Which cloud provider do you use?",
            "What CI/CD tool is configured?",
        ],
        "auto_discoverable": True,
        "auto_discovery_hint": (
            "Scan for package.json, requirements.txt, Cargo.toml, go.mod, "
            "Dockerfile, docker-compose.yml, .github/workflows, Jenkinsfile, etc."
        ),
    },
    {
        "key": "architecture",
        "label": "Architecture",
        "criticality": Criticality.IMPORTANT,
        "description": "High-level architecture type, data flow, components, and constraints.",
        "is_populated": lambda v: v is not None and bool(v.get("type") or v.get("description")),
        "questions": [
            "What architecture pattern is used (monolith, microservices, modular monolith)?",
            "Can you describe the high-level data flow?",
            "What are the main components/modules?",
        ],
        "auto_discoverable": True,
        "auto_discovery_hint": "Look for docker-compose.yml, k8s manifests, or architecture docs.",
    },
    {
        "key": "team",
        "label": "Team Members",
        "criticality": Criticality.IMPORTANT,
        "description": "Who works on this project, their roles, and communication channels.",
        "is_populated": lambda v: isinstance(v, list) and len(v) > 0,
        "questions": [
            "Who are the key team members and their roles?",
            "Who is the tech lead or project owner?",
            "What communication channels does the team use (Slack, Teams)?",
        ],
        "auto_discoverable": False,
    },
    {
        "key": "conventions",
        "label": "Engineering Conventions",
        "criticality": Criticality.IMPORTANT,
        "description": "Branching strategy, naming conventions, code style, and PR process.",
        "is_populated": lambda v: v is not None and (
            bool(v.get("branching_strategy"))
            or bool(v.get("code_style"))
            or bool(v.get("naming_conventions"))
        ),
        "questions": [
            "What branching strategy do you follow (GitFlow, trunk-based)?",
            "Are there naming conventions for files, classes, or variables?",
            "What code style / linter is used?",
            "How does the PR review process work?",
        ],
        "auto_discoverable": True,
        "auto_discovery_hint": (
            "Check .editorconfig, .eslintrc, .prettierrc, ruff.toml, "
            "CONTRIBUTING.md, or CI linting steps."
        ),
    },
    {
        "key": "services",
        "label": "Services",
        "criticality": Criticality.NICE_TO_HAVE,
        "description": "Deployed services / microservices with owners and tech.",
        "is_populated": lambda v: isinstance(v, list) and len(v) > 0,
        "questions": [
            "What services/microservices are part of this system?",
            "For each service, what tech stack does it use?",
        ],
        "auto_discoverable": True,
        "auto_discovery_hint": "Scan docker-compose.yml, k8s manifests, or monorepo subdirs.",
    },
    {
        "key": "api_contracts",
        "label": "API Contracts",
        "criticality": Criticality.NICE_TO_HAVE,
        "description": "Defined API endpoints, schemas, versions.",
        "is_populated": lambda v: isinstance(v, list) and len(v) > 0,
        "questions": [
            "Are there any API contracts defined (OpenAPI specs, GraphQL schemas)?",
        ],
        "auto_discoverable": True,
        "auto_discovery_hint": "Look for openapi.yaml, swagger.json, schema.graphql.",
    },
    {
        "key": "environments",
        "label": "Deployment Environments",
        "criticality": Criticality.NICE_TO_HAVE,
        "description": "Development, staging, production environments and their config.",
        "is_populated": lambda v: isinstance(v, list) and len(v) > 0,
        "questions": [
            "What environments exist (dev, staging, prod)?",
            "Are there specific URLs or regions for each?",
        ],
        "auto_discoverable": True,
        "auto_discovery_hint": "Check .env files, terraform/infra configs, CI deploy steps.",
    },
    {
        "key": "domain_model",
        "label": "Domain Model",
        "criticality": Criticality.IMPORTANT,
        "description": "Ubiquitous language, entities, business rules, bounded contexts.",
        "is_populated": lambda v: v is not None and (
            bool(v.get("description"))
            or bool(v.get("entities"))
            or bool(v.get("ubiquitous_language"))
        ),
        "questions": [
            "What are the core domain entities (User, Order, Product, etc.)?",
            "Are there specific business terms the team uses (ubiquitous language)?",
            "What are the key business rules or invariants?",
        ],
        "auto_discoverable": True,
        "auto_discovery_hint": "Scan model classes, DB schemas, or domain docs.",
    },
    {
        "key": "external_dependencies",
        "label": "External Dependencies",
        "criticality": Criticality.NICE_TO_HAVE,
        "description": "Third-party APIs and integrations.",
        "is_populated": lambda v: isinstance(v, list) and len(v) > 0,
        "questions": [
            "What third-party services or APIs does the system integrate with?",
        ],
        "auto_discoverable": True,
        "auto_discovery_hint": "Scan environment variables for API keys, check package lists.",
    },
    {
        "key": "data_schemas",
        "label": "Data Schemas",
        "criticality": Criticality.NICE_TO_HAVE,
        "description": "Database schemas, tables, migration tools.",
        "is_populated": lambda v: isinstance(v, list) and len(v) > 0,
        "questions": [
            "What databases does the project use and how are schemas managed?",
        ],
        "auto_discoverable": True,
        "auto_discovery_hint": "Look for migrations/, alembic/, flyway/, prisma/schema.prisma.",
    },
    {
        "key": "knowledge_base",
        "label": "Knowledge Base",
        "criticality": Criticality.NICE_TO_HAVE,
        "description": "Tribal knowledge, lessons learned, gotchas, and best practices.",
        "is_populated": lambda v: isinstance(v, list) and len(v) > 0,
        "questions": [
            "Are there known gotchas, forbidden patterns, or lessons learned?",
        ],
        "auto_discoverable": False,
    },
    {
        "key": "access_registry",
        "label": "Access Registry",
        "criticality": Criticality.NICE_TO_HAVE,
        "description": "System access metadata (URLs, auth methods — no secrets).",
        "is_populated": lambda v: isinstance(v, list) and len(v) > 0,
        "questions": [
            "What systems does the team need access to (Jira, AWS, GitHub, etc.)?",
        ],
        "auto_discoverable": False,
    },
    {
        "key": "blueprints",
        "label": "Blueprints",
        "criticality": Criticality.NICE_TO_HAVE,
        "description": "Reusable templates for common tasks.",
        "is_populated": lambda v: isinstance(v, list) and len(v) > 0,
        "questions": [],
        "auto_discoverable": False,
    },
]


# ---------------------------------------------------------------------------
# Checker
# ---------------------------------------------------------------------------

def check_completeness(full_context: dict[str, Any]) -> CompletenessReport:
    """Analyse a ``FullContext`` dict and return a completeness report.

    Parameters
    ----------
    full_context:
        The result of calling ``get_full_context()`` on MCP Statico,
        i.e. ``FullContext.model_dump()``.

    Returns
    -------
    CompletenessReport
        Scored report with listed gaps and suggested questions.
    """
    gaps: list[ContextGap] = []
    populated: list[str] = []

    for section in SECTIONS:
        value = full_context.get(section["key"])
        checker = section["is_populated"]

        if checker(value):
            populated.append(section["label"])
        else:
            gaps.append(
                ContextGap(
                    section=section["label"],
                    criticality=section["criticality"],
                    description=section["description"],
                    questions=section.get("questions", []),
                    auto_discoverable=section.get("auto_discoverable", False),
                    auto_discovery_hint=section.get("auto_discovery_hint", ""),
                )
            )

    total = len(SECTIONS)
    score = len(populated) / total if total > 0 else 0.0

    report = CompletenessReport(
        score=score,
        total_sections=total,
        populated_sections=len(populated),
        gaps=gaps,
        populated=populated,
    )

    logger.info(
        "Completeness: %.0f%% (%d/%d sections) — %d gaps (%d critical)",
        score * 100,
        len(populated),
        total,
        len(gaps),
        len(report.critical_gaps),
    )

    return report
