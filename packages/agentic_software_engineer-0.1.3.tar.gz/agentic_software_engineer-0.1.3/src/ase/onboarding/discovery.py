"""
Context Discovery Agent -- interactive onboarding for empty or incomplete projects.

When Statico has gaps, this agent:
1. Runs the completeness checker to identify what's missing.
2. For auto-discoverable sections, asks the LLM to scan the project repo
   and infer context (tech stack from package files, architecture from
   docker-compose, etc.).
3. For sections requiring human input, generates focused questions and
   presents them via Human-in-the-Loop.
4. Persists every answer back into Statico via MCP.

Optionally connects to external MCP servers (e.g. a company knowledge base
or a Jira instance) to pull additional context automatically.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ase.agents.bridge import MCPBridge
from ase.llm.client import LLMClient
from ase.onboarding.completeness import (
    CompletenessReport,
    ContextGap,
    Criticality,
    check_completeness,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

_DISCOVERY_SYSTEM_PROMPT = """\
You are the ASE Context Discovery Agent.  Your job is to populate the
company knowledge base so that the other development agents have the context
they need to produce high-quality code.

You will be given:
- A list of GAPS (missing sections in the knowledge base).
- For auto-discoverable gaps, FILE CONTENTS from the project repository.

Your task:
1. Analyse the provided files and infer as much context as possible.
2. Return a JSON object where each key is the Statico section name
   (snake_case) and the value is the data to store.
3. Only include sections for which you have confident information.
4. Use the exact field names expected by the Statico models.

Be precise and factual — do NOT hallucinate information.  If you cannot
determine something from the files, omit it.
"""

_QUESTION_SYSTEM_PROMPT = """\
You are the ASE Context Discovery Agent conducting an interactive onboarding
interview.  Your goal is to gather company context efficiently.

Rules:
- Ask one focused topic at a time.
- After receiving an answer, acknowledge it and ask the next question.
- When all questions are answered, reply with the JSON command:
  {"action": "done", "collected": { ... }}
  where "collected" is a dict mapping statico section keys to their values.
- Be conversational but professional.
- Never ask for secrets, passwords, or API keys.
"""

# ---------------------------------------------------------------------------
# File patterns to scan for auto-discovery
# ---------------------------------------------------------------------------

_DISCOVERY_FILES: list[str] = [
    "README.md",
    "README.rst",
    "package.json",
    "pyproject.toml",
    "setup.py",
    "setup.cfg",
    "Cargo.toml",
    "go.mod",
    "pom.xml",
    "build.gradle",
    "docker-compose.yml",
    "docker-compose.yaml",
    "Dockerfile",
    ".github/workflows/*.yml",
    ".gitlab-ci.yml",
    "Jenkinsfile",
    ".editorconfig",
    ".eslintrc.json",
    ".prettierrc",
    "ruff.toml",
    "CONTRIBUTING.md",
    ".ase/config.toml",
    "Makefile",
    "Taskfile.yml",
    "terraform/*.tf",
    "infrastructure/*.tf",
    "k8s/*.yaml",
]


# ---------------------------------------------------------------------------
# Discovery Agent
# ---------------------------------------------------------------------------

class ContextDiscoveryAgent:
    """Discovers and populates missing context in MCP Statico.

    Parameters
    ----------
    bridge:
        Connected MCPBridge with Statico tools available.
    llm_client:
        LLM client for inference.
    project_path:
        Root path of the project to scan for auto-discovery.
    """

    def __init__(
        self,
        bridge: MCPBridge,
        llm_client: LLMClient,
        project_path: Path,
    ) -> None:
        self._bridge = bridge
        self._llm = llm_client
        self._project_path = Path(project_path).resolve()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def run(self, interactive: bool = True) -> CompletenessReport:
        """Run the full discovery pipeline.

        1. Check current completeness.
        2. Auto-discover what we can from repo files.
        3. If interactive, ask the human for the rest.
        4. Re-check and return the final report.

        Parameters
        ----------
        interactive:
            If True, present questions via stdout for human answers.
            If False, only auto-discover and skip human questions.
        """
        logger.info("Starting context discovery for %s", self._project_path)

        # Step 1 — baseline check
        full_ctx = await self._fetch_full_context()
        report = check_completeness(full_ctx)

        if report.score == 1.0:
            logger.info("Context is 100%% complete — nothing to do")
            return report

        logger.info(
            "Completeness %.0f%% — %d gaps found (%d critical)",
            report.score * 100,
            len(report.gaps),
            len(report.critical_gaps),
        )

        # Step 2 — auto-discover from project files
        auto_gaps = [g for g in report.gaps if g.auto_discoverable]
        if auto_gaps:
            await self._auto_discover(auto_gaps)
            # Re-check after auto-discovery
            full_ctx = await self._fetch_full_context()
            report = check_completeness(full_ctx)
            logger.info(
                "After auto-discovery: %.0f%% complete (%d gaps remain)",
                report.score * 100,
                len(report.gaps),
            )

        # Step 3 — interactive questions for remaining gaps
        if interactive and report.gaps:
            remaining = [g for g in report.gaps if g.questions]
            if remaining:
                await self._interactive_onboarding(remaining)
                # Final re-check
                full_ctx = await self._fetch_full_context()
                report = check_completeness(full_ctx)

        logger.info("Discovery complete — final score %.0f%%", report.score * 100)
        return report

    async def check(self) -> CompletenessReport:
        """Check completeness without modifying anything."""
        full_ctx = await self._fetch_full_context()
        return check_completeness(full_ctx)

    # ------------------------------------------------------------------
    # Auto-discovery: scan project files → LLM → Statico
    # ------------------------------------------------------------------

    async def _auto_discover(self, gaps: list[ContextGap]) -> None:
        """Scan project files and ask the LLM to infer context."""
        logger.info("Auto-discovering context from project files...")

        # Collect relevant files
        file_contents = self._scan_project_files()

        if not file_contents:
            logger.warning("No project files found for auto-discovery")
            return

        # Build the prompt
        gaps_desc = "\n".join(
            f"- **{g.section}**: {g.description}\n  Hint: {g.auto_discovery_hint}"
            for g in gaps
        )

        files_desc = "\n\n".join(
            f"### {path}\n```\n{content}\n```"
            for path, content in file_contents.items()
        )

        messages = [
            {"role": "system", "content": _DISCOVERY_SYSTEM_PROMPT},
            {
                "role": "user",
                "content": (
                    f"## Gaps to fill\n{gaps_desc}\n\n"
                    f"## Project files\n{files_desc}\n\n"
                    "Return a JSON object with the inferred context."
                ),
            },
        ]

        response = await self._llm.chat(messages=messages, temperature=0.1)

        if not response.content:
            logger.warning("LLM returned empty content for auto-discovery")
            return

        # Parse JSON from response
        discovered = self._extract_json(response.content)
        if not discovered:
            logger.warning("Could not extract JSON from LLM auto-discovery response")
            return

        logger.info("Auto-discovered %d sections", len(discovered))

        # Persist each discovered section to Statico
        await self._persist_discovered(discovered)

    def _scan_project_files(self) -> dict[str, str]:
        """Read project files that are relevant for context discovery."""
        contents: dict[str, str] = {}
        max_file_size = 50_000  # 50 KB per file

        for pattern in _DISCOVERY_FILES:
            if "*" in pattern:
                matches = list(self._project_path.glob(pattern))
            else:
                candidate = self._project_path / pattern
                matches = [candidate] if candidate.exists() else []

            for fpath in matches:
                if fpath.is_file() and fpath.stat().st_size <= max_file_size:
                    try:
                        rel = fpath.relative_to(self._project_path)
                        text = fpath.read_text(encoding="utf-8", errors="replace")
                        contents[str(rel)] = text[:max_file_size]
                    except Exception as exc:
                        logger.debug("Skipping %s: %s", fpath, exc)

        return contents

    # ------------------------------------------------------------------
    # Interactive onboarding
    # ------------------------------------------------------------------

    async def _interactive_onboarding(self, gaps: list[ContextGap]) -> None:
        """Ask the human questions one-by-one and persist answers."""
        logger.info("Starting interactive onboarding (%d sections)", len(gaps))

        all_questions: list[tuple[ContextGap, str]] = []
        for gap in gaps:
            for q in gap.questions:
                all_questions.append((gap, q))

        if not all_questions:
            return

        # Build a conversational flow using the LLM
        messages: list[dict[str, Any]] = [
            {"role": "system", "content": _QUESTION_SYSTEM_PROMPT},
            {
                "role": "user",
                "content": (
                    "I need you to help me fill in project context. "
                    "Here are the sections with gaps:\n\n"
                    + "\n".join(
                        f"- **{g.section}** ({g.criticality.value}): {g.description}\n"
                        f"  Questions: {'; '.join(g.questions)}"
                        for g in gaps
                    )
                    + "\n\nPlease start asking me questions one at a time."
                ),
            },
        ]

        # Get first LLM question
        resp = await self._llm.chat(messages=messages, temperature=0.3)
        if not resp.content:
            return

        messages.append({"role": "assistant", "content": resp.content})

        # Conversation loop
        max_turns = len(all_questions) * 2 + 5  # generous upper bound
        for _ in range(max_turns):
            # Display the LLM's question
            print(f"\n🤖 ASE: {resp.content}")

            # Check if the LLM says it's done
            if resp.content and '"action": "done"' in resp.content:
                collected = self._extract_json(resp.content)
                if collected and "collected" in collected:
                    await self._persist_discovered(collected["collected"])
                elif collected:
                    await self._persist_discovered(collected)
                break

            # Get human input
            try:
                human_input = input("\n👤 You: ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\n[Onboarding interrupted]")
                break

            if not human_input:
                continue

            if human_input.lower() in ("skip", "done", "quit", "exit"):
                break

            messages.append({"role": "user", "content": human_input})

            resp = await self._llm.chat(messages=messages, temperature=0.3)
            if not resp.content:
                break

            messages.append({"role": "assistant", "content": resp.content})

    # ------------------------------------------------------------------
    # External source discovery
    # ------------------------------------------------------------------

    async def discover_from_external_mcp(
        self,
        server_name: str,
        tool_name: str,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Pull context from an external MCP server already connected to the bridge.

        This allows the system to connect to company-wide knowledge bases,
        Jira instances, wiki servers, or any other MCP data source.

        Parameters
        ----------
        server_name:
            Name of the external MCP server registered in the bridge.
        tool_name:
            Tool to invoke on the external server.
        params:
            Parameters to pass to the tool.

        Returns
        -------
        dict
            The raw result from the external MCP tool.
        """
        qualified_name = f"{server_name}__{tool_name}"
        logger.info("Querying external MCP: %s(%s)", qualified_name, params)

        try:
            result = await self._bridge.execute_tool_call(
                qualified_name,
                params or {},
            )
            return result if isinstance(result, dict) else {"raw": str(result)}
        except Exception as exc:
            logger.warning("External MCP query failed: %s", exc)
            return {"error": str(exc)}

    # ------------------------------------------------------------------
    # Persistence helpers
    # ------------------------------------------------------------------

    async def _persist_discovered(self, data: dict[str, Any]) -> None:
        """Write discovered context sections to Statico via MCP tools."""
        section_tool_map: dict[str, tuple[str, bool]] = {
            # key → (tool_name, is_replacement_style)
            "company_profile": ("statico__set_company_profile", True),
            "tech_stack": ("statico__set_tech_stack", True),
            "architecture": ("statico__set_architecture", True),
            "conventions": ("statico__set_conventions", True),
            "domain_model": ("statico__set_domain_model", True),
        }

        # List-type sections that need item-by-item adding
        list_section_tools: dict[str, str] = {
            "team": "statico__add_team_member",
            "services": "statico__add_service",
            "api_contracts": "statico__add_api_contract",
            "environments": "statico__set_environment",
            "external_dependencies": "statico__add_external_dependency",
            "data_schemas": "statico__add_data_schema",
            "knowledge_base": "statico__add_knowledge_entry",
            "access_registry": "statico__add_access_registry",
            "blueprints": "statico__add_blueprint",
        }

        for key, value in data.items():
            if not value:
                continue

            # Replacement-style (single object)
            if key in section_tool_map:
                tool_name, _ = section_tool_map[key]
                params = value if isinstance(value, dict) else {}
                try:
                    await self._bridge.execute_tool_call(tool_name, params)
                    logger.info("Persisted section: %s", key)
                except Exception as exc:
                    logger.warning("Failed to persist %s: %s", key, exc)

            # List-style (multiple items)
            elif key in list_section_tools:
                tool_name = list_section_tools[key]
                items = value if isinstance(value, list) else [value]
                for item in items:
                    if isinstance(item, dict):
                        try:
                            await self._bridge.execute_tool_call(tool_name, item)
                        except Exception as exc:
                            logger.warning(
                                "Failed to persist %s item: %s", key, exc
                            )
                logger.info("Persisted %d items for section: %s", len(items), key)

    async def _fetch_full_context(self) -> dict[str, Any]:
        """Fetch the full Statico context via MCP."""
        try:
            result = await self._bridge.execute_tool_call(
                "statico__get_full_context", {}
            )
            if isinstance(result, dict):
                return result
            # Handle MCP CallToolResult
            if hasattr(result, "content"):
                for block in result.content:
                    if hasattr(block, "text"):
                        return json.loads(block.text)
            return {}
        except Exception as exc:
            logger.warning("Failed to fetch full context: %s", exc)
            return {}

    # ------------------------------------------------------------------
    # JSON extraction
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_json(text: str) -> dict[str, Any] | None:
        """Try to extract a JSON object from LLM text output."""
        # Try direct parse
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass

        # Try extracting from markdown code block
        import re

        patterns = [
            r"```json\s*\n(.*?)\n```",
            r"```\s*\n(.*?)\n```",
            r"\{.*\}",
        ]
        for pattern in patterns:
            match = re.search(pattern, text, re.DOTALL)
            if match:
                try:
                    candidate = match.group(1) if match.lastindex else match.group(0)
                    return json.loads(candidate)
                except (json.JSONDecodeError, IndexError):
                    continue

        return None
