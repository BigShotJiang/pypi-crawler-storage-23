"""Plain-text intake source."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone

from ase.intake.normalizer import normalize


@dataclass(frozen=True)
class NormalizedInput:
    """Immutable container for text that has been through the normaliser."""

    raw: str
    normalized: str
    source_type: str = "text"
    received_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class TextSource:
    """Intake source that accepts raw text and produces a ``NormalizedInput``.

    Usage::

        source = TextSource("  Fix the login bug  ")
        ni = source.to_normalized_input()
        print(ni.normalized)  # "Fix the login bug"
    """

    def __init__(self, raw_text: str) -> None:
        self._raw = raw_text

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def to_normalized_input(self) -> NormalizedInput:
        """Normalise the raw text and wrap it in a ``NormalizedInput``."""
        return NormalizedInput(
            raw=self._raw,
            normalized=normalize(self._raw),
        )

    # Convenience alias
    __call__ = to_normalized_input
