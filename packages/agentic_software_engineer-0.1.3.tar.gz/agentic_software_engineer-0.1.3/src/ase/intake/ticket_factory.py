"""Factory that turns normalised input into Operativo tickets via MCP."""

from __future__ import annotations

import logging
from typing import Any, TYPE_CHECKING

from ase.intake.normalizer import normalize

if TYPE_CHECKING:
    from ase.agents.bridge import MCPBridge  # noqa: F401 – forward ref

logger = logging.getLogger(__name__)


class TicketFactory:
    """Create Operativo tickets from raw text input.

    Parameters
    ----------
    bridge:
        An initialised ``MCPBridge`` instance used to call MCP tools.
    """

    def __init__(self, bridge: "MCPBridge") -> None:
        self._bridge = bridge

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def create_from_text(
        self,
        text: str,
        project_id: str,
        priority: str = "medium",
    ) -> dict[str, Any]:
        """Normalise *text* and create a ticket via ``operativo__create_ticket``.

        Parameters
        ----------
        text:
            Raw user input describing the work to be done.
        project_id:
            Identifier for the project this ticket belongs to.
        priority:
            One of ``"low"``, ``"medium"``, ``"high"``, ``"critical"``.

        Returns
        -------
        dict
            The ticket payload returned by Operativo.
        """
        cleaned = normalize(text)

        if not cleaned:
            raise ValueError("Cannot create a ticket from empty input.")

        logger.info(
            "Creating ticket for project=%s priority=%s len=%d",
            project_id,
            priority,
            len(cleaned),
        )

        result: dict[str, Any] = await self._bridge.execute_tool_call(
            "operativo__create_ticket",
            {
                "title": _derive_title(cleaned),
                "description": cleaned,
                "project_id": project_id,
                "priority": priority,
                "status": "open",
            },
        )

        logger.info("Ticket created: %s", result.get("id", "<unknown>"))
        return result


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _derive_title(text: str, max_length: int = 120) -> str:
    """Extract a short title from the first sentence / line of *text*."""
    first_line = text.split("\n", maxsplit=1)[0]
    if len(first_line) <= max_length:
        return first_line
    return first_line[: max_length - 3].rsplit(" ", maxsplit=1)[0] + "..."
