"""Input normalisation utilities for the ASE intake pipeline."""

from __future__ import annotations

import re
import unicodedata


# Pre-compiled patterns for performance
_CONTROL_CHARS_RE = re.compile(
    r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]",
)
_WHITESPACE_COLLAPSE_RE = re.compile(r"[^\S\n]+")  # horizontal whitespace only
_BLANK_LINES_RE = re.compile(r"\n{3,}")

# Maximum input length (100 KB) to prevent memory exhaustion
MAX_INPUT_LENGTH = 100_000


def normalize(raw_input: str) -> str:
    """Clean raw user input into a normalised string.

    Steps performed (in order):
    1. Unicode NFC normalisation (canonical composition).
    2. Strip leading / trailing whitespace.
    3. Remove ASCII and Latin-1 control characters (preserves newlines and tabs).
    4. Collapse runs of horizontal whitespace into a single space.
    5. Collapse three-or-more consecutive newlines into two (one blank line).

    Parameters
    ----------
    raw_input:
        Arbitrary text coming from any intake source.

    Returns
    -------
    str
        The cleaned, normalised string.  Returns ``""`` for empty / whitespace-only input.
    """
    if not raw_input:
        return ""

    if len(raw_input) > MAX_INPUT_LENGTH:
        raise ValueError(
            f"Input too long ({len(raw_input)} chars, max {MAX_INPUT_LENGTH})"
        )

    # 1. Unicode NFC
    text = unicodedata.normalize("NFC", raw_input)

    # 2. Strip outer whitespace
    text = text.strip()

    if not text:
        return ""

    # 3. Remove control characters (keep \n and \t)
    text = _CONTROL_CHARS_RE.sub("", text)

    # 4. Collapse horizontal whitespace
    text = _WHITESPACE_COLLAPSE_RE.sub(" ", text)

    # 5. Collapse excessive blank lines
    text = _BLANK_LINES_RE.sub("\n\n", text)

    return text
