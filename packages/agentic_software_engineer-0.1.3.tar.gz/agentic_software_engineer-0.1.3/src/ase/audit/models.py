"""Pydantic models for the ASE audit trail.

Covers every event type an agent can produce during its lifecycle:
LLM calls, tool invocations, decisions, errors, and completion summaries.
"""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


# ── Event types ───────────────────────────────────────────────────────


class AuditEventType(str, Enum):
    """Exhaustive list of auditable events."""

    AGENT_STARTED = "agent_started"
    AGENT_COMPLETED = "agent_completed"
    AGENT_FAILED = "agent_failed"
    AGENT_TIMEOUT = "agent_timeout"
    AGENT_SPAWNED = "agent_spawned"
    AGENT_CANCELLED = "agent_cancelled"

    LLM_REQUEST = "llm_request"
    LLM_RESPONSE = "llm_response"

    TOOL_CALL_START = "tool_call_start"
    TOOL_CALL_SUCCESS = "tool_call_success"
    TOOL_CALL_ERROR = "tool_call_error"

    DECISION = "decision"
    COST_WARNING = "cost_warning"
    COST_LIMIT_HIT = "cost_limit_hit"


# ── Base event ────────────────────────────────────────────────────────


class AuditEvent(BaseModel):
    """Base audit record.  Every event carries a trace and span ID so
    the full lifecycle of an agent run can be reconstructed."""

    trace_id: str = Field(
        ...,
        description="Unique ID for the entire agent run (shared across all events in one run).",
    )
    span_id: str = Field(
        default="",
        description="Sub-identifier for a specific step within the run (e.g. iteration number).",
    )
    event_type: AuditEventType
    agent_type: str = Field(default="", description="e.g. 'triage', 'backend'")
    agent_instance_id: str = Field(default="", description="UUID of the agent instance.")
    ticket_id: str = Field(default="")
    assignment_id: str = Field(default="")
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: dict[str, Any] = Field(default_factory=dict)

    def to_log_dict(self) -> dict[str, Any]:
        """Serialise for structured logging (JSON lines)."""
        d = self.model_dump(mode="json")
        d["timestamp"] = self.timestamp.isoformat()
        return d


# ── Specialised events ───────────────────────────────────────────────


class AgentStartedEvent(AuditEvent):
    event_type: AuditEventType = AuditEventType.AGENT_STARTED
    model: str = ""
    tools_available: int = 0


class AgentCompletedEvent(AuditEvent):
    event_type: AuditEventType = AuditEventType.AGENT_COMPLETED
    iterations: int = 0
    total_tokens_in: int = 0
    total_tokens_out: int = 0
    total_cost_usd: float = 0.0
    final_text_length: int = 0


class AgentFailedEvent(AuditEvent):
    event_type: AuditEventType = AuditEventType.AGENT_FAILED
    error_type: str = ""
    error_message: str = ""
    iteration: int = 0


class AgentSpawnedEvent(AuditEvent):
    event_type: AuditEventType = AuditEventType.AGENT_SPAWNED
    timeout_seconds: int = 0


class AgentCancelledEvent(AuditEvent):
    event_type: AuditEventType = AuditEventType.AGENT_CANCELLED
    reason: str = ""


class LLMRequestEvent(AuditEvent):
    event_type: AuditEventType = AuditEventType.LLM_REQUEST
    model: str = ""
    iteration: int = 0
    message_count: int = 0
    tools_provided: int = 0


class LLMResponseEvent(AuditEvent):
    event_type: AuditEventType = AuditEventType.LLM_RESPONSE
    model: str = ""
    iteration: int = 0
    tokens_in: int = 0
    tokens_out: int = 0
    cost_usd: float = 0.0
    tool_calls_count: int = 0
    has_final_text: bool = False


class ToolCallStartEvent(AuditEvent):
    event_type: AuditEventType = AuditEventType.TOOL_CALL_START
    tool_name: str = ""
    arguments_summary: str = Field(
        default="",
        description="Truncated/sanitised summary of the tool arguments.",
    )
    iteration: int = 0


class ToolCallSuccessEvent(AuditEvent):
    event_type: AuditEventType = AuditEventType.TOOL_CALL_SUCCESS
    tool_name: str = ""
    duration_ms: float = 0.0
    output_length: int = 0
    iteration: int = 0


class ToolCallErrorEvent(AuditEvent):
    event_type: AuditEventType = AuditEventType.TOOL_CALL_ERROR
    tool_name: str = ""
    error_message: str = ""
    duration_ms: float = 0.0
    iteration: int = 0


class DecisionLogEntry(AuditEvent):
    """A decision-log record capturing *why* an agent took an action."""

    event_type: AuditEventType = AuditEventType.DECISION
    action: str = Field(default="", description="Short action label.")
    reasoning: str = Field(default="", description="Why the agent chose this action.")
    outcome: str = Field(default="", description="Result of the action.")


class CostWarningEvent(AuditEvent):
    event_type: AuditEventType = AuditEventType.COST_WARNING
    current_cost_usd: float = 0.0
    limit_usd: float = 0.0
    percent_used: float = 0.0


class CostLimitHitEvent(AuditEvent):
    event_type: AuditEventType = AuditEventType.COST_LIMIT_HIT
    spent_usd: float = 0.0
    limit_usd: float = 0.0
