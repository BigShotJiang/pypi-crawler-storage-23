"""Structured JSON formatter for ASE audit logs.

Provides a ``logging.Formatter`` that outputs one JSON object per line,
making logs machine-parseable while keeping Python's standard logging
infrastructure.

Log files use a **rotating file handler** (ring-buffer style):
- Each file grows up to ``max_bytes`` (default 10 MB)
- Old files are rotated and at most ``backup_count`` backups are kept
- Total disk usage is bounded: ``max_bytes * (1 + backup_count)``

Usage::

    from ase.audit.formatter import setup_structured_logging
    setup_structured_logging(
        level="DEBUG",
        log_file=".ase/logs/audit.jsonl",
        max_bytes=10_000_000,
        backup_count=5,
    )
"""

from __future__ import annotations

import json
import logging
import logging.handlers
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class JSONFormatter(logging.Formatter):
    """Emit each log record as a single JSON line.

    Fields included:
    - ``timestamp`` (ISO 8601 UTC)
    - ``level``
    - ``logger`` (logger name)
    - ``message``
    - ``module``, ``funcName``, ``lineno``
    - Any extra fields attached via ``extra={}`` on the log call

    Extra fields with an ``ase_`` prefix are promoted to top-level keys
    (with the prefix stripped) so audit data is easy to query.
    """

    # Keys that are part of the standard LogRecord — we skip these when
    # looking for extra fields set by the caller.
    _BUILTIN_ATTRS = frozenset(
        vars(logging.LogRecord("", 0, "", 0, "", (), None)).keys()
        | {"message", "asctime"}
    )

    def format(self, record: logging.LogRecord) -> str:
        obj: dict[str, Any] = {
            "timestamp": datetime.fromtimestamp(
                record.created, tz=timezone.utc
            ).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "func": record.funcName,
            "line": record.lineno,
        }

        # Promote extra fields
        for key, val in record.__dict__.items():
            if key in self._BUILTIN_ATTRS:
                continue
            if key.startswith("ase_"):
                obj[key[4:]] = val  # strip prefix
            elif key not in ("args", "exc_info", "exc_text", "stack_info"):
                obj[key] = val

        # Exception info
        if record.exc_info and record.exc_info[1]:
            obj["exception"] = self.formatException(record.exc_info)

        return json.dumps(obj, default=str, ensure_ascii=False)


def setup_structured_logging(
    level: str = "INFO",
    log_file: str | Path | None = None,
    console: bool = True,
    max_bytes: int = 10 * 1024 * 1024,  # 10 MB
    backup_count: int = 5,
) -> None:
    """Configure the ``ase`` root logger with structured JSON output.

    Parameters
    ----------
    level:
        Minimum log level (``DEBUG``, ``INFO``, ``WARNING``, etc.).
    log_file:
        Optional path to a ``.jsonl`` file.  Parent dirs are created
        automatically.  The file is **rotated** when it exceeds
        *max_bytes*; at most *backup_count* old files are kept.
    console:
        If ``True`` (default), also log JSON to stderr.
    max_bytes:
        Maximum size (bytes) of a single log file before rotation.
        Default: 10 MB.
    backup_count:
        Number of rotated backup files to keep.  Default: 5.
        Total maximum disk usage = ``max_bytes * (1 + backup_count)``.
    """
    root = logging.getLogger("ase")
    root.setLevel(getattr(logging, level.upper(), logging.INFO))

    fmt = JSONFormatter()

    # Remove existing handlers to avoid duplicates on repeated calls
    root.handlers.clear()

    if console:
        sh = logging.StreamHandler(sys.stderr)
        sh.setFormatter(fmt)
        root.addHandler(sh)

    if log_file:
        path = Path(log_file)
        path.parent.mkdir(parents=True, exist_ok=True)
        # Restrict log file permissions (owner read/write only)
        if not path.exists():
            path.touch(mode=0o600)
        fh = logging.handlers.RotatingFileHandler(
            str(path),
            maxBytes=max_bytes,
            backupCount=backup_count,
            encoding="utf-8",
        )
        fh.setFormatter(fmt)
        root.addHandler(fh)

    # Prevent propagation to the root Python logger
    root.propagate = False


def cleanup_old_logs(
    log_dir: str | Path,
    retention_days: int = 90,
    pattern: str = "*.jsonl*",
) -> int:
    """Delete rotated log files older than *retention_days*.

    Parameters
    ----------
    log_dir:
        Directory containing log files.
    retention_days:
        Files older than this many days are deleted.
    pattern:
        Glob pattern to match log files (default matches
        ``audit.jsonl``, ``audit.jsonl.1``, etc.).

    Returns
    -------
    int
        Number of files deleted.
    """
    log_path = Path(log_dir)
    if not log_path.exists():
        return 0

    cutoff = time.time() - (retention_days * 86400)
    deleted = 0

    for f in log_path.glob(pattern):
        if f.is_file() and f.stat().st_mtime < cutoff:
            f.unlink()
            deleted += 1

    return deleted

    # Prevent propagation to the root Python logger
    root.propagate = False
