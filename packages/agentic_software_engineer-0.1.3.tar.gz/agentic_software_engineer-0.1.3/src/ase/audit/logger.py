"""Audit logger -- unified observability for every agent action.

Dual output:
1. Python ``logging`` (structured JSON via ``ase.audit.formatter``)
2. Persistent storage via MCP Operativo ``log_decision`` tool

Every agent run gets a **trace_id** so all events in a single run can
be correlated.  Each step within a run gets a **span_id**.
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any, TYPE_CHECKING
from uuid import uuid4

from ase.audit.models import (
    AgentCompletedEvent,
    AgentFailedEvent,
    AgentStartedEvent,
    AuditEvent,
    CostLimitHitEvent,
    CostWarningEvent,
    DecisionLogEntry,
    LLMRequestEvent,
    LLMResponseEvent,
    ToolCallErrorEvent,
    ToolCallStartEvent,
    ToolCallSuccessEvent,
)

if TYPE_CHECKING:
    from ase.agents.bridge import MCPBridge  # noqa: F401

logger = logging.getLogger("ase.audit")


class AuditLogger:
    """Centralised audit facility for an agent run.

    Parameters
    ----------
    trace_id:
        Correlation ID shared by every event in this run.  If not
        supplied a new UUID is generated.
    agent_type:
        Logical agent name (``"triage"``, ``"backend"``, …).
    agent_instance_id:
        UUID of the specific agent instance.
    ticket_id:
        Ticket being worked on.
    assignment_id:
        Assignment identifier.
    bridge:
        Optional ``MCPBridge`` for persisting events to Operativo.
        When ``None`` events are only emitted via Python logging.
    persist:
        If ``False``, skip Operativo persistence even when a bridge
        is available (useful in tests).
    """

    def __init__(
        self,
        *,
        trace_id: str | None = None,
        agent_type: str = "",
        agent_instance_id: str = "",
        ticket_id: str = "",
        assignment_id: str = "",
        bridge: "MCPBridge | None" = None,
        persist: bool = True,
    ) -> None:
        self.trace_id = trace_id or str(uuid4())
        self.agent_type = agent_type
        self.agent_instance_id = agent_instance_id
        self.ticket_id = ticket_id
        self.assignment_id = assignment_id
        self._bridge = bridge
        self._persist = persist and bridge is not None

        self._span_counter = 0

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _next_span(self) -> str:
        self._span_counter += 1
        return f"{self.trace_id}:{self._span_counter}"

    def _base_fields(self) -> dict[str, Any]:
        return dict(
            trace_id=self.trace_id,
            agent_type=self.agent_type,
            agent_instance_id=self.agent_instance_id,
            ticket_id=self.ticket_id,
            assignment_id=self.assignment_id,
        )

    async def _emit(self, event: AuditEvent) -> None:
        """Log via Python logging and optionally persist to Operativo."""
        log_data = event.to_log_dict()

        # Structured Python log -- extra fields prefixed with ase_ so
        # the JSONFormatter promotes them to top-level.
        logger.info(
            "[%s] %s | %s",
            event.event_type.value,
            event.agent_type,
            event.span_id or "-",
            extra={f"ase_{k}": v for k, v in log_data.items()},
        )

        # Persist to Operativo
        if self._persist:
            try:
                assert self._bridge is not None
                await self._bridge.execute_tool_call(
                    "operativo__log_decision",
                    {
                        "ticket_id": event.ticket_id,
                        "agent_type": event.agent_type,
                        "action": event.event_type.value,
                        "reasoning": json.dumps(log_data, default=str),
                        "outcome": "",
                        "metadata": json.dumps(event.metadata, default=str),
                    },
                )
            except Exception as exc:
                logger.warning(
                    "Failed to persist audit event to Operativo: %s", exc
                )

    # ------------------------------------------------------------------
    # Public API -- Agent lifecycle
    # ------------------------------------------------------------------

    async def log_agent_started(
        self, *, model: str = "", tools_available: int = 0
    ) -> None:
        await self._emit(
            AgentStartedEvent(
                **self._base_fields(),
                span_id=self._next_span(),
                model=model,
                tools_available=tools_available,
            )
        )

    async def log_agent_completed(
        self,
        *,
        iterations: int = 0,
        total_tokens_in: int = 0,
        total_tokens_out: int = 0,
        total_cost_usd: float = 0.0,
        final_text_length: int = 0,
    ) -> None:
        await self._emit(
            AgentCompletedEvent(
                **self._base_fields(),
                span_id=self._next_span(),
                iterations=iterations,
                total_tokens_in=total_tokens_in,
                total_tokens_out=total_tokens_out,
                total_cost_usd=total_cost_usd,
                final_text_length=final_text_length,
            )
        )

    async def log_agent_failed(
        self, *, error_type: str = "", error_message: str = "", iteration: int = 0
    ) -> None:
        await self._emit(
            AgentFailedEvent(
                **self._base_fields(),
                span_id=self._next_span(),
                error_type=error_type,
                error_message=error_message,
                iteration=iteration,
            )
        )

    # ------------------------------------------------------------------
    # Public API -- LLM calls
    # ------------------------------------------------------------------

    async def log_llm_request(
        self,
        *,
        model: str = "",
        iteration: int = 0,
        message_count: int = 0,
        tools_provided: int = 0,
    ) -> None:
        await self._emit(
            LLMRequestEvent(
                **self._base_fields(),
                span_id=self._next_span(),
                model=model,
                iteration=iteration,
                message_count=message_count,
                tools_provided=tools_provided,
            )
        )

    async def log_llm_response(
        self,
        *,
        model: str = "",
        iteration: int = 0,
        tokens_in: int = 0,
        tokens_out: int = 0,
        cost_usd: float = 0.0,
        tool_calls_count: int = 0,
        has_final_text: bool = False,
    ) -> None:
        await self._emit(
            LLMResponseEvent(
                **self._base_fields(),
                span_id=self._next_span(),
                model=model,
                iteration=iteration,
                tokens_in=tokens_in,
                tokens_out=tokens_out,
                cost_usd=cost_usd,
                tool_calls_count=tool_calls_count,
                has_final_text=has_final_text,
            )
        )

    # ------------------------------------------------------------------
    # Public API -- Tool calls
    # ------------------------------------------------------------------

    async def log_tool_call_start(
        self,
        *,
        tool_name: str,
        arguments_summary: str = "",
        iteration: int = 0,
    ) -> float:
        """Log tool invocation start.  Returns ``time.monotonic()`` for
        duration tracking."""
        await self._emit(
            ToolCallStartEvent(
                **self._base_fields(),
                span_id=self._next_span(),
                tool_name=tool_name,
                arguments_summary=arguments_summary,
                iteration=iteration,
            )
        )
        return time.monotonic()

    async def log_tool_call_success(
        self,
        *,
        tool_name: str,
        start_time: float,
        output_length: int = 0,
        iteration: int = 0,
    ) -> None:
        duration_ms = (time.monotonic() - start_time) * 1000
        await self._emit(
            ToolCallSuccessEvent(
                **self._base_fields(),
                span_id=self._next_span(),
                tool_name=tool_name,
                duration_ms=round(duration_ms, 2),
                output_length=output_length,
                iteration=iteration,
            )
        )

    async def log_tool_call_error(
        self,
        *,
        tool_name: str,
        start_time: float,
        error_message: str = "",
        iteration: int = 0,
    ) -> None:
        duration_ms = (time.monotonic() - start_time) * 1000
        await self._emit(
            ToolCallErrorEvent(
                **self._base_fields(),
                span_id=self._next_span(),
                tool_name=tool_name,
                duration_ms=round(duration_ms, 2),
                error_message=error_message,
                iteration=iteration,
            )
        )

    # ------------------------------------------------------------------
    # Public API -- Decisions & cost
    # ------------------------------------------------------------------

    async def log_decision(
        self,
        *,
        action: str,
        reasoning: str = "",
        outcome: str = "",
        extra_metadata: dict[str, Any] | None = None,
    ) -> None:
        await self._emit(
            DecisionLogEntry(
                **self._base_fields(),
                span_id=self._next_span(),
                action=action,
                reasoning=reasoning,
                outcome=outcome,
                metadata=extra_metadata or {},
            )
        )

    async def log_cost_warning(
        self, *, current_cost_usd: float, limit_usd: float
    ) -> None:
        pct = (current_cost_usd / limit_usd * 100) if limit_usd else 0
        await self._emit(
            CostWarningEvent(
                **self._base_fields(),
                span_id=self._next_span(),
                current_cost_usd=current_cost_usd,
                limit_usd=limit_usd,
                percent_used=round(pct, 1),
            )
        )

    async def log_cost_limit_hit(
        self, *, spent_usd: float, limit_usd: float
    ) -> None:
        await self._emit(
            CostLimitHitEvent(
                **self._base_fields(),
                span_id=self._next_span(),
                spent_usd=spent_usd,
                limit_usd=limit_usd,
            )
        )
