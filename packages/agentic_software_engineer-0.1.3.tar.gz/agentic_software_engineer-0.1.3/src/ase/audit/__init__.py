"""ASE Audit -- observability for every agent action.

Public API::

    from ase.audit import AuditLogger, setup_structured_logging

    setup_structured_logging(level="DEBUG", log_file=".ase/logs/audit.jsonl")

    audit = AuditLogger(agent_type="backend", ticket_id="T-42", bridge=bridge)
    await audit.log_agent_started(model="claude-sonnet-4-20250514", tools_available=12)
"""

from ase.audit.formatter import JSONFormatter, cleanup_old_logs, setup_structured_logging
from ase.audit.logger import AuditLogger
from ase.audit.models import AuditEvent, AuditEventType

__all__ = [
    "AuditLogger",
    "AuditEvent",
    "AuditEventType",
    "JSONFormatter",
    "cleanup_old_logs",
    "setup_structured_logging",
]