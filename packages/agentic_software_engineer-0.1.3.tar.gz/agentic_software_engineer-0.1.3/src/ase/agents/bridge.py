"""
MCP Bridge -- routes tool calls to the correct MCP server by prefix.

Every tool exposed to the LLM is qualified with a server prefix:
    operativo__create_ticket, statico__get_tech_stack, ...

The bridge keeps a registry that maps each qualified name back to the
server name so `execute_tool_call` can route transparently.
"""

from __future__ import annotations

import logging
from typing import Any

from mcp import ClientSession

logger = logging.getLogger(__name__)

SEPARATOR = "__"


class MCPBridge:
    """Manages N MCP server ClientSessions behind a single tool surface.

    Tools are namespaced: ``<server_name>__<tool_name>`` so the LLM sees
    a flat list while the bridge routes internally.
    """

    def __init__(self) -> None:
        # server_name -> ClientSession
        self._sessions: dict[str, ClientSession] = {}

        # qualified_name -> server_name
        self._tool_registry: dict[str, str] = {}

        # qualified_name -> MCP tool schema (raw dict from list_tools)
        self._tool_schemas: dict[str, dict[str, Any]] = {}

    # ------------------------------------------------------------------
    # Connection management
    # ------------------------------------------------------------------

    async def connect(self, name: str, session: ClientSession) -> None:
        """Register a server and index all its tools under *name__<tool>*."""
        if name in self._sessions:
            logger.warning("Server '%s' already registered -- replacing", name)

        self._sessions[name] = session

        # Discover available tools
        result = await session.list_tools()
        tools = result.tools if hasattr(result, "tools") else result

        registered = 0
        for tool in tools:
            qualified = f"{name}{SEPARATOR}{tool.name}"
            self._tool_registry[qualified] = name
            self._tool_schemas[qualified] = {
                "name": tool.name,
                "description": tool.description or "",
                "input_schema": tool.inputSchema if hasattr(tool, "inputSchema") else {},
            }
            registered += 1

        logger.info(
            "Connected MCP server '%s' -- %d tools indexed",
            name,
            registered,
        )

    async def disconnect(self, name: str) -> None:
        """Remove a server and all its tool registrations."""
        if name not in self._sessions:
            return

        # Purge tool entries belonging to this server
        to_remove = [qn for qn, sn in self._tool_registry.items() if sn == name]
        for qn in to_remove:
            del self._tool_registry[qn]
            self._tool_schemas.pop(qn, None)

        del self._sessions[name]
        logger.info("Disconnected MCP server '%s' (%d tools removed)", name, len(to_remove))

    async def disconnect_all(self) -> None:
        """Disconnect every registered server."""
        for name in list(self._sessions):
            await self.disconnect(name)

    # ------------------------------------------------------------------
    # Tool surface -- what the LLM sees
    # ------------------------------------------------------------------

    def get_openai_tools(self) -> list[dict[str, Any]]:
        """Return all registered tools in OpenAI function-calling format.

        Each entry follows the shape::

            {
                "type": "function",
                "function": {
                    "name": "operativo__create_ticket",
                    "description": "...",
                    "parameters": { ... }
                }
            }
        """
        tools: list[dict[str, Any]] = []
        for qualified_name, schema in self._tool_schemas.items():
            parameters = schema.get("input_schema", {})
            # Ensure parameters has a valid JSON Schema wrapper
            if not parameters or not isinstance(parameters, dict):
                parameters = {"type": "object", "properties": {}}

            tools.append(
                {
                    "type": "function",
                    "function": {
                        "name": qualified_name,
                        "description": schema.get("description", ""),
                        "parameters": parameters,
                    },
                }
            )
        return tools

    def get_tools_for_server(self, server_name: str) -> list[str]:
        """Return all qualified tool names belonging to *server_name*."""
        return [qn for qn, sn in self._tool_registry.items() if sn == server_name]

    # ------------------------------------------------------------------
    # Execution -- route a qualified tool call to the right server
    # ------------------------------------------------------------------

    async def execute_tool_call(
        self,
        tool_name: str,
        arguments: dict[str, Any] | None = None,
    ) -> Any:
        """Dispatch a tool call to the correct MCP server.

        Parameters
        ----------
        tool_name:
            The qualified name, e.g. ``operativo__create_ticket``.
        arguments:
            JSON-serialisable dict of parameters.

        Returns
        -------
        The raw result returned by the MCP server.

        Raises
        ------
        ValueError
            If the tool name is unknown or the prefix cannot be resolved.
        RuntimeError
            If the corresponding server session is no longer available.
        """
        if arguments is None:
            arguments = {}

        server_name = self._tool_registry.get(tool_name)
        if server_name is None:
            raise ValueError(
                f"Unknown tool '{tool_name}'. "
                f"Registered tools: {sorted(self._tool_registry.keys())}"
            )

        session = self._sessions.get(server_name)
        if session is None:
            raise RuntimeError(
                f"MCP server '{server_name}' is registered but its session is gone"
            )

        # Derive the original (un-prefixed) tool name
        original_name = tool_name.split(SEPARATOR, 1)[1]

        logger.debug("Calling %s.%s(%s)", server_name, original_name, arguments)

        result = await session.call_tool(original_name, arguments=arguments)
        return result

    # ------------------------------------------------------------------
    # Introspection helpers
    # ------------------------------------------------------------------

    @property
    def registered_servers(self) -> list[str]:
        return list(self._sessions.keys())

    @property
    def registered_tools(self) -> list[str]:
        return sorted(self._tool_registry.keys())

    def __repr__(self) -> str:
        return (
            f"<MCPBridge servers={len(self._sessions)} "
            f"tools={len(self._tool_registry)}>"
        )
