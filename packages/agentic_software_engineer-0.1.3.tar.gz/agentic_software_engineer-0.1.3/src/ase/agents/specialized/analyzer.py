"""Analyzer Agent -- analyses raw tickets to extract intent, complexity, priority."""

from __future__ import annotations

from ase.agents.base import BaseAgent
from ase.agents.prompts.analyzer import ANALYZER_SYSTEM_PROMPT


class AnalyzerAgent(BaseAgent):
    """First-pass agent: reads raw ticket content and enriches it with
    structured metadata (intent, complexity, entities, suggested priority)."""

    def get_system_prompt(self) -> str:
        return ANALYZER_SYSTEM_PROMPT

    def get_available_tool_names(self) -> list[str] | None:
        return [
            "operativo__get_ticket",
            "operativo__update_ticket",
            "operativo__log_decision",
            "operativo__publish_event",
            "statico__get_full_context",
            "statico__get_tech_stack",
            "statico__get_architecture",
        ]
