"""Specialized agent implementations and the AGENT_REGISTRY.

Every agent subclasses ``BaseAgent``, providing a system prompt and
optionally restricting the tool surface.  The ``AGENT_REGISTRY`` dict maps
agent-type strings to their concrete classes so that the ``AgentLifecycleManager``
can instantiate them dynamically.
"""

from ase.agents.specialized.analyzer import AnalyzerAgent
from ase.agents.specialized.backend import BackendAgent
from ase.agents.specialized.cloud import CloudAgent
from ase.agents.specialized.database import DatabaseAgent
from ase.agents.specialized.devops import DevOpsAgent
from ase.agents.specialized.docs import DocsAgent
from ase.agents.specialized.frontend import FrontendAgent
from ase.agents.specialized.platform_agent import PlatformAgent
from ase.agents.specialized.security import SecurityAgent
from ase.agents.specialized.testing import TestingAgent
from ase.agents.specialized.triage import TriageAgent

AGENT_REGISTRY: dict[str, type] = {
    "analyzer": AnalyzerAgent,
    "triage": TriageAgent,
    "backend": BackendAgent,
    "frontend": FrontendAgent,
    "testing": TestingAgent,
    "devops": DevOpsAgent,
    "security": SecurityAgent,
    "database": DatabaseAgent,
    "docs": DocsAgent,
    "platform": PlatformAgent,
    "cloud": CloudAgent,
}

__all__ = [
    "AGENT_REGISTRY",
    "AnalyzerAgent",
    "BackendAgent",
    "CloudAgent",
    "DatabaseAgent",
    "DevOpsAgent",
    "DocsAgent",
    "FrontendAgent",
    "PlatformAgent",
    "SecurityAgent",
    "TestingAgent",
    "TriageAgent",
]
