"""Triage Agent -- routes tickets to the correct agents with a plan."""

from __future__ import annotations

from ase.agents.base import BaseAgent
from ase.agents.prompts.triage import TRIAGE_SYSTEM_PROMPT


class TriageAgent(BaseAgent):
    """Long-lived agent that watches for analyzed tickets and produces
    execution plans: which agents, in what order, with what dependencies."""

    def get_system_prompt(self) -> str:
        return TRIAGE_SYSTEM_PROMPT

    def get_model_tier(self) -> str:
        return "fast"

    def get_available_tool_names(self) -> list[str] | None:
        return [
            "operativo__get_ticket",
            "operativo__update_ticket",
            "operativo__assign_agent",
            "operativo__log_decision",
            "operativo__publish_event",
            "operativo__list_tickets",
            "statico__get_full_context",
            "statico__get_architecture",
            "statico__get_conventions",
            "statico__get_blueprints",
            "statico__get_api_contracts",
        ]
