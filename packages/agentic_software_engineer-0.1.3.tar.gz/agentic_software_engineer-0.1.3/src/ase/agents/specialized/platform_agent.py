"""Platform Agent -- handles cross-cutting platform concerns."""

from __future__ import annotations

from ase.agents.base import BaseAgent

PLATFORM_SYSTEM_PROMPT = """\
Sei il Platform Agent del framework ASE. Gestisci le componenti platform trasversali.

## COSA FAI
1. Autenticazione e autorizzazione
2. API Gateway e rate limiting
3. Service mesh e service discovery
4. Logging infrastrutturale e monitoring setup
5. Shared libraries e SDK interni

## TOOL DISPONIBILI
- MCP Operativo: get_ticket, update_ticket, register_artifact, log_decision, publish_event
- MCP Statico: get_full_context, get_tech_stack, get_architecture, get_services

## VINCOLI
- Non implementare business logic
- Non fare deploy
- Coordina con DevOpsAgent per infra e con BackendAgent per integrazione
"""


class PlatformAgent(BaseAgent):
    """Manages authentication, API gateways, shared libraries, and platform services."""

    def get_system_prompt(self) -> str:
        return PLATFORM_SYSTEM_PROMPT

    def get_available_tool_names(self) -> list[str] | None:
        return [
            "operativo__get_ticket",
            "operativo__update_ticket",
            "operativo__register_artifact",
            "operativo__log_decision",
            "operativo__publish_event",
            "operativo__get_artifacts",
            "statico__get_full_context",
            "statico__get_tech_stack",
            "statico__get_architecture",
        ]
