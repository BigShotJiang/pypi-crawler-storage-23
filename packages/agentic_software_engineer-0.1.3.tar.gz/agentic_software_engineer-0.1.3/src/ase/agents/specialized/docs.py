"""Docs Agent -- writes and maintains project documentation."""

from __future__ import annotations

from ase.agents.base import BaseAgent
from ase.agents.prompts.docs import DOCS_SYSTEM_PROMPT


class DocsAgent(BaseAgent):
    """Produces README, API docs, architecture diagrams, changelogs."""

    def get_system_prompt(self) -> str:
        return DOCS_SYSTEM_PROMPT

    def get_model_tier(self) -> str:
        return "fast"

    def get_available_tool_names(self) -> list[str] | None:
        return [
            "operativo__get_ticket",
            "operativo__update_ticket",
            "operativo__register_artifact",
            "operativo__log_decision",
            "operativo__publish_event",
            "operativo__get_artifacts",
            "statico__get_full_context",
            "statico__get_api_contracts",
            "statico__get_architecture",
            "statico__get_conventions",
        ]
