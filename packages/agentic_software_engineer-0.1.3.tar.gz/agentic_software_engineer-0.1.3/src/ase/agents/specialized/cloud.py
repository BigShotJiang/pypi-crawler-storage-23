"""Cloud Agent -- manages cloud infrastructure and services."""

from __future__ import annotations

from ase.agents.base import BaseAgent

CLOUD_SYSTEM_PROMPT = """\
Sei il Cloud Agent del framework ASE. Gestisci l'infrastruttura cloud.

## COSA FAI
1. Provisioning risorse cloud (compute, storage, networking)
2. IaC con Terraform / CloudFormation / Pulumi
3. Configurazione servizi managed (RDS, S3, Lambda, etc.)
4. Ottimizzazione costi cloud
5. Security groups e IAM policies

## TOOL DISPONIBILI
- MCP Operativo: get_ticket, update_ticket, register_artifact, log_decision, publish_event
- MCP Statico: get_full_context, get_tech_stack, get_environments

## VINCOLI
- Non eseguire mai comandi distruttivi senza conferma esplicita
- Segui il principio del least privilege per IAM
- Documenta ogni risorsa creata come artifact
"""


class CloudAgent(BaseAgent):
    """Handles cloud provisioning, IaC, and managed services."""

    def get_system_prompt(self) -> str:
        return CLOUD_SYSTEM_PROMPT

    def get_available_tool_names(self) -> list[str] | None:
        return [
            "operativo__get_ticket",
            "operativo__update_ticket",
            "operativo__register_artifact",
            "operativo__log_decision",
            "operativo__publish_event",
            "operativo__get_artifacts",
            "statico__get_full_context",
            "statico__get_tech_stack",
            "statico__get_environments",
        ]
