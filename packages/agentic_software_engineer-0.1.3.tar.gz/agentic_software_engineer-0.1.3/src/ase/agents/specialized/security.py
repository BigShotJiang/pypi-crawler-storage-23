"""Security Agent -- reviews code for vulnerabilities and best practices."""

from __future__ import annotations

from ase.agents.base import BaseAgent
from ase.agents.prompts.security import SECURITY_SYSTEM_PROMPT


class SecurityAgent(BaseAgent):
    """Audits code for OWASP top-10, dependency vulnerabilities, and secrets."""

    def get_system_prompt(self) -> str:
        return SECURITY_SYSTEM_PROMPT

    def get_model_tier(self) -> str:
        return "deep"

    def get_available_tool_names(self) -> list[str] | None:
        return [
            "operativo__get_ticket",
            "operativo__update_ticket",
            "operativo__register_artifact",
            "operativo__log_decision",
            "operativo__publish_event",
            "operativo__get_artifacts",
            "statico__get_full_context",
            "statico__get_tech_stack",
            "statico__get_conventions",
        ]
