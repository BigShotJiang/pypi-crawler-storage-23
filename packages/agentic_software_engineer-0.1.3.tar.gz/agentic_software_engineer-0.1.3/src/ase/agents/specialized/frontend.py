"""Frontend Agent -- implements client-side UI code."""

from __future__ import annotations

from ase.agents.base import BaseAgent
from ase.agents.prompts.frontend import FRONTEND_SYSTEM_PROMPT


class FrontendAgent(BaseAgent):
    """Writes frontend code: components, pages, state management, API integration."""

    def get_system_prompt(self) -> str:
        return FRONTEND_SYSTEM_PROMPT

    def get_available_tool_names(self) -> list[str] | None:
        return [
            "operativo__get_ticket",
            "operativo__update_ticket",
            "operativo__register_artifact",
            "operativo__log_decision",
            "operativo__publish_event",
            "operativo__get_artifacts",
            "statico__get_full_context",
            "statico__get_tech_stack",
            "statico__get_conventions",
            "statico__get_api_contracts",
        ]
