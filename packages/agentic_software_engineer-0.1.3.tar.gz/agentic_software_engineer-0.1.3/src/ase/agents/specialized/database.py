"""Database Agent -- handles schema design, migrations, and data modelling."""

from __future__ import annotations

from ase.agents.base import BaseAgent
from ase.agents.prompts.database import DATABASE_SYSTEM_PROMPT


class DatabaseAgent(BaseAgent):
    """Designs schemas, writes migrations, optimises queries."""

    def get_system_prompt(self) -> str:
        return DATABASE_SYSTEM_PROMPT

    def get_available_tool_names(self) -> list[str] | None:
        return [
            "operativo__get_ticket",
            "operativo__update_ticket",
            "operativo__register_artifact",
            "operativo__log_decision",
            "operativo__publish_event",
            "operativo__get_artifacts",
            "statico__get_full_context",
            "statico__get_tech_stack",
            "statico__get_architecture",
        ]
