"""
Agent Lifecycle Manager -- spawns, tracks, and cancels agent tasks.

Each agent runs as an ``asyncio.Task`` wrapped with a timeout guard.
The manager keeps a registry of active tasks so the orchestrator can
monitor and cancel agents if needed.  Every lifecycle event is
recorded via :class:`~ase.audit.logger.AuditLogger`.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from ase.agents.base import AgentContext, BaseAgent
from ase.agents.bridge import MCPBridge
from ase.audit.logger import AuditLogger
from ase.audit.models import AgentCancelledEvent, AgentSpawnedEvent
from ase.config.schema import ASEConfig
from ase.llm.client import LLMClient
from ase.skills.registry import SkillRegistry

logger = logging.getLogger(__name__)


class AgentLifecycleManager:
    """Spawns and supervises agent asyncio tasks."""

    def __init__(
        self,
        config: ASEConfig,
        bridge: MCPBridge,
        llm_client: LLMClient,
        *,
        skill_registry: SkillRegistry | None = None,
    ) -> None:
        self._config = config
        self._bridge = bridge
        self._llm_client = llm_client
        self._skill_registry = skill_registry

        # assignment_id -> asyncio.Task
        self._active_tasks: dict[str, asyncio.Task[str]] = {}

    # ------------------------------------------------------------------
    # Spawn
    # ------------------------------------------------------------------

    async def spawn_agent(
        self,
        agent_type: str,
        ticket_id: str,
        assignment_id: str,
        static_context: dict[str, Any] | None = None,
        ticket_data: dict[str, Any] | None = None,
    ) -> asyncio.Task[str]:
        """Create and launch an agent as a background task.

        Parameters
        ----------
        agent_type:
            Logical name of the agent (e.g. ``"analyzer"``, ``"backend"``).
            Must be registered in ``AGENT_REGISTRY``.
        ticket_id:
            The ticket this agent will work on.
        assignment_id:
            Unique identifier for this assignment (used for status tracking).
        static_context:
            Pre-fetched project context (tech stack, conventions, etc.).
        ticket_data:
            Parsed ticket payload (title, description, labels, ...).

        Returns
        -------
        asyncio.Task
            The background task running the agent.

        Raises
        ------
        ValueError
            If *agent_type* is not found in the registry.
        RuntimeError
            If an agent with the same *assignment_id* is already running.
        """
        # Late import to avoid circular dependency
        from ase.agents.specialized import AGENT_REGISTRY

        if agent_type not in AGENT_REGISTRY:
            available = sorted(AGENT_REGISTRY.keys())
            raise ValueError(
                f"Unknown agent type '{agent_type}'. "
                f"Available: {available}"
            )

        if assignment_id in self._active_tasks:
            existing = self._active_tasks[assignment_id]
            if not existing.done():
                raise RuntimeError(
                    f"Agent for assignment '{assignment_id}' is already running"
                )
            # Stale entry -- clean up
            del self._active_tasks[assignment_id]

        # Build context
        context = AgentContext(
            ticket_id=ticket_id,
            assignment_id=assignment_id,
            agent_type=agent_type,
            config=self._config,
            static_context=static_context or {},
            ticket_data=ticket_data or {},
        )

        # Instantiate the specialised agent class
        agent_cls: type[BaseAgent] = AGENT_REGISTRY[agent_type]
        agent = agent_cls(
            context=context,
            bridge=self._bridge,
            llm_client=self._llm_client,
            skill_registry=self._skill_registry,
        )

        # Launch as a supervised task
        task = asyncio.create_task(
            self._run_with_timeout(agent),
            name=f"agent-{agent_type}-{assignment_id[:8]}",
        )
        task.add_done_callback(lambda t: self._on_task_done(assignment_id, t))
        self._active_tasks[assignment_id] = task

        # ── Audit: agent spawned ──
        spawn_audit = AuditLogger(
            agent_type=agent_type,
            agent_instance_id=agent.instance_id,
            ticket_id=ticket_id,
            assignment_id=assignment_id,
            bridge=self._bridge,
            persist=self._config.logging.audit_log_enabled,
        )
        await spawn_audit._emit(
            AgentSpawnedEvent(
                trace_id=spawn_audit.trace_id,
                span_id="spawn",
                agent_type=agent_type,
                agent_instance_id=agent.instance_id,
                ticket_id=ticket_id,
                assignment_id=assignment_id,
                timeout_seconds=self._config.timeouts.agent_single_retry_seconds,
            )
        )

        logger.info(
            "Spawned agent '%s' for ticket %s (assignment %s)",
            agent_type,
            ticket_id,
            assignment_id,
        )
        return task

    # ------------------------------------------------------------------
    # Timeout wrapper
    # ------------------------------------------------------------------

    async def _run_with_timeout(self, agent: BaseAgent) -> str:
        """Run ``agent.run()`` with the configured timeout."""
        timeout = self._config.timeouts.agent_single_retry_seconds
        try:
            return await asyncio.wait_for(agent.run(), timeout=timeout)
        except asyncio.TimeoutError:
            logger.error(
                "Agent %s timed out after %ds on ticket %s",
                agent.context.agent_type,
                timeout,
                agent.context.ticket_id,
            )
            await agent._handle_failure(
                f"Agent timed out after {timeout}s"
            )
            raise

    # ------------------------------------------------------------------
    # Task lifecycle callbacks
    # ------------------------------------------------------------------

    def _on_task_done(self, assignment_id: str, task: asyncio.Task[str]) -> None:
        """Callback fired when an agent task completes or fails."""
        # Clean up from active set
        self._active_tasks.pop(assignment_id, None)

        if task.cancelled():
            logger.info("Agent task for assignment %s was cancelled", assignment_id)
        elif task.exception():
            logger.error(
                "Agent task for assignment %s failed: %s",
                assignment_id,
                task.exception(),
            )
        else:
            logger.info(
                "Agent task for assignment %s completed successfully",
                assignment_id,
            )

    # ------------------------------------------------------------------
    # Cancellation
    # ------------------------------------------------------------------

    def cancel_agent(self, assignment_id: str) -> bool:
        """Cancel a running agent task.

        Returns ``True`` if a task was found and cancelled.
        """
        task = self._active_tasks.get(assignment_id)
        if task is None or task.done():
            return False

        task.cancel()
        logger.info("Cancelled agent task for assignment %s", assignment_id)

        # Fire-and-forget audit (we're in sync context via callback, so
        # we can't await; the event is still emitted via Python logging)
        cancel_audit = AuditLogger(
            assignment_id=assignment_id,
            bridge=self._bridge,
            persist=False,  # can't await in sync context
        )
        # Emit synchronously via Python logging only
        import json as _json
        cancel_event = AgentCancelledEvent(
            trace_id=cancel_audit.trace_id,
            span_id="cancel",
            assignment_id=assignment_id,
            reason="manual_cancel",
        )
        logger.info(
            "[agent_cancelled] assignment=%s",
            assignment_id,
            extra={f"ase_{k}": v for k, v in cancel_event.to_log_dict().items()},
        )

        return True

    def cancel_all(self) -> int:
        """Cancel every active agent. Returns the count of tasks cancelled."""
        count = 0
        for aid in list(self._active_tasks):
            if self.cancel_agent(aid):
                count += 1
        return count

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    def get_active_agents(self) -> dict[str, bool]:
        """Return ``{assignment_id: is_running}`` for all tracked tasks."""
        return {
            aid: not task.done()
            for aid, task in self._active_tasks.items()
        }

    @property
    def active_count(self) -> int:
        return sum(1 for t in self._active_tasks.values() if not t.done())

    def __repr__(self) -> str:
        return f"<AgentLifecycleManager active={self.active_count}>"
