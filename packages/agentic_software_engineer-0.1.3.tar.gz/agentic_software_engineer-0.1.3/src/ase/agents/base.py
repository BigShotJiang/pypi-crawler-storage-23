"""
Base Agent -- the think-loop engine that every specialised agent inherits.

Subclasses override ``get_system_prompt()`` and optionally
``get_available_tool_names()`` to restrict which tools the LLM can see.

Every action the agent takes is recorded via :class:`~ase.audit.logger.AuditLogger`
so the full lifecycle can be replayed and audited.
"""

from __future__ import annotations

import json
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any
from uuid import uuid4

from ase.agents.bridge import MCPBridge
from ase.audit.logger import AuditLogger
from ase.config.schema import ASEConfig
from ase.llm.client import LLMClient, LLMResponse
from ase.memory import AgentMemory
from ase.skills.registry import SkillRegistry

logger = logging.getLogger(__name__)


# ── Exceptions ────────────────────────────────────────────────────────


class CostLimitExceeded(Exception):
    """The per-ticket cost ceiling has been reached."""

    def __init__(self, spent: float, limit: float, ticket_id: str) -> None:
        self.spent = spent
        self.limit = limit
        self.ticket_id = ticket_id
        super().__init__(
            f"Ticket {ticket_id} cost limit exceeded: "
            f"${spent:.4f} / ${limit:.2f}"
        )


# ── Data classes ──────────────────────────────────────────────────────


@dataclass
class ThinkResult:
    """Outcome of a single think iteration."""

    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    tool_results: list[dict[str, Any]] = field(default_factory=list)
    text_response: str | None = None
    is_final: bool = False


@dataclass
class AgentContext:
    """Everything an agent needs to begin work on a ticket."""

    ticket_id: str
    assignment_id: str
    agent_type: str
    config: ASEConfig
    static_context: dict[str, Any] = field(default_factory=dict)
    ticket_data: dict[str, Any] = field(default_factory=dict)


# ── Base Agent ────────────────────────────────────────────────────────


class BaseAgent(ABC):
    """Abstract base for all ASE agents.

    The ``run()`` method drives the full think-loop:

    1. Update assignment status to *running*.
    2. Build the initial message from ticket data and static context.
    3. Loop: call the LLM, execute any tool calls, feed results back.
    4. When the LLM produces a final text response (no tool calls),
       log completion and update the assignment to *completed*.

    Cost and iteration guards prevent runaway agents.
    """

    MAX_ITERATIONS: int = 50
    TOOLS_PER_TURN_LIMIT: int = 10

    def __init__(
        self,
        context: AgentContext,
        bridge: MCPBridge,
        llm_client: LLMClient,
        *,
        skill_registry: SkillRegistry | None = None,
    ) -> None:
        self.context = context
        self.bridge = bridge
        self.llm_client = llm_client
        self.skill_registry = skill_registry

        # Identity
        self.instance_id: str = str(uuid4())

        # Conversation state
        self.messages: list[dict[str, Any]] = []

        # Telemetry
        self.total_tokens_in: int = 0
        self.total_tokens_out: int = 0
        self.total_cost: float = 0.0
        self._cost_warning_sent: bool = False

        # Unified audit logger -- trace_id ties all events in this run
        self.audit = AuditLogger(
            agent_type=context.agent_type,
            agent_instance_id=self.instance_id,
            ticket_id=context.ticket_id,
            assignment_id=context.assignment_id,
            bridge=bridge,
            persist=context.config.logging.audit_log_enabled,
        )

        # Cross-session memory
        mem_cfg = context.config.memory
        if mem_cfg.scope.value != "disabled":
            from pathlib import Path
            mem_dir = (
                Path(mem_cfg.project_dir)
                if mem_cfg.scope.value == "project"
                else Path(mem_cfg.local_dir)
            )
            self.memory = AgentMemory(mem_dir, context.agent_type)
        else:
            self.memory = None

    # ------------------------------------------------------------------
    # Abstract / overrideable hooks
    # ------------------------------------------------------------------

    @abstractmethod
    def get_system_prompt(self) -> str:
        """Return the system prompt for this agent type.

        Must be overridden by every specialised agent.
        """

    def get_available_tool_names(self) -> list[str] | None:
        """Return the qualified tool names this agent is allowed to use.

        Return ``None`` (the default) to expose *all* registered tools.
        Override in specialised agents to restrict the tool surface.
        """
        return None

    # ------------------------------------------------------------------
    # Model selection
    # ------------------------------------------------------------------

    def get_model_tier(self) -> str:
        """Return the tier name for this agent (fast / balanced / deep).

        Override in specialised agents to change the default tier.
        """
        return "balanced"

    def get_model(self) -> str:
        """Resolve which model to use for this agent type.

        Resolution order:
        1. ``config.agents.model_overrides[agent_type]`` (explicit model ID)
        2. ``config.agents.model_tiers[agent_type]`` -> tier -> model ID
        3. ``self.get_model_tier()`` -> tier -> model ID
        4. ``config.llm.default_model`` (ultimate fallback)
        """
        agent_type = self.context.agent_type
        cfg = self.context.config

        # 1. Explicit model override
        explicit = cfg.agents.model_overrides.get(agent_type)
        if explicit:
            return explicit

        # 2. Tier from config, or 3. from agent class default
        tier_name = cfg.agents.model_tiers.get(agent_type, self.get_model_tier())

        try:
            return cfg.model_tiers.resolve(tier_name)
        except (KeyError, ValueError):
            logger.warning(
                "[%s] Unknown model tier '%s', falling back to default_model",
                self.instance_id[:8],
                tier_name,
            )
            return cfg.llm.default_model

    # ------------------------------------------------------------------
    # Main think loop
    # ------------------------------------------------------------------

    async def run(self) -> str:
        """Execute the full agent lifecycle and return the final text.

        Raises
        ------
        CostLimitExceeded
            When the per-ticket spend ceiling is hit.
        """
        ticket_id = self.context.ticket_id
        assignment_id = self.context.assignment_id

        # 1. Mark assignment as running
        await self._update_assignment_status("running")

        # 2. Build initial messages (prompt + preloaded skills + memory)
        system_prompt = self._build_system_prompt()
        self.messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": self._build_initial_message()},
        ]

        # 3. Get available tools
        tools = self._get_filtered_tools()
        model = self.get_model()

        # ── Audit: agent started ──
        await self.audit.log_agent_started(
            model=model,
            tools_available=len(tools),
        )

        # 4. Think loop
        final_text: str | None = None
        iteration = 0

        for iteration in range(1, self.MAX_ITERATIONS + 1):
            # ── Audit: LLM request ──
            await self.audit.log_llm_request(
                model=model,
                iteration=iteration,
                message_count=len(self.messages),
                tools_provided=len(tools),
            )

            # Call the LLM
            response: LLMResponse = await self.llm_client.chat(
                model=model,
                messages=self.messages,
                tools=tools if tools else None,
                temperature=self.context.config.llm.temperature,
                max_tokens=self.context.config.llm.max_tokens,
            )

            # Track costs
            self.total_tokens_in += response.usage.prompt_tokens
            self.total_tokens_out += response.usage.completion_tokens
            self.total_cost += response.cost_usd

            # ── Audit: LLM response ──
            await self.audit.log_llm_response(
                model=model,
                iteration=iteration,
                tokens_in=response.usage.prompt_tokens,
                tokens_out=response.usage.completion_tokens,
                cost_usd=response.cost_usd,
                tool_calls_count=len(response.tool_calls) if response.tool_calls else 0,
                has_final_text=not bool(response.tool_calls),
            )

            # Cost warning at 80%
            cost_limit = self.context.config.llm.cost_limit_per_ticket_usd
            if (
                not self._cost_warning_sent
                and cost_limit > 0
                and self.total_cost >= cost_limit * 0.8
            ):
                self._cost_warning_sent = True
                await self.audit.log_cost_warning(
                    current_cost_usd=self.total_cost,
                    limit_usd=cost_limit,
                )

            # Cost guard
            if self.total_cost >= cost_limit:
                await self.audit.log_cost_limit_hit(
                    spent_usd=self.total_cost,
                    limit_usd=cost_limit,
                )
                await self._handle_failure(
                    f"Cost limit exceeded: ${self.total_cost:.4f} / ${cost_limit:.2f}"
                )
                raise CostLimitExceeded(self.total_cost, cost_limit, ticket_id)

            # Append assistant message to conversation
            self.messages.append(response.to_message())

            # ── Branch: tool calls vs. final text ──
            if response.tool_calls:
                think = await self._execute_tool_calls(
                    response.tool_calls, iteration=iteration
                )
                if think.is_final:
                    final_text = think.text_response
                    break
            else:
                # No tool calls -> this is the final answer
                final_text = response.content or ""
                break
        else:
            # Exhausted iterations
            msg = f"Max iterations ({self.MAX_ITERATIONS}) reached"
            await self.audit.log_agent_failed(
                error_type="timeout",
                error_message=msg,
                iteration=iteration,
            )
            await self._handle_failure(msg)
            final_text = f"[AGENT TIMEOUT] {msg}"

        # 5. Audit: agent completed
        await self.audit.log_agent_completed(
            iterations=iteration,
            total_tokens_in=self.total_tokens_in,
            total_tokens_out=self.total_tokens_out,
            total_cost_usd=self.total_cost,
            final_text_length=len(final_text or ""),
        )

        # 6. Update assignment to completed
        await self._update_assignment_status("completed")

        return final_text or ""

    # ------------------------------------------------------------------
    # Message building
    # ------------------------------------------------------------------

    def _build_system_prompt(self) -> str:
        """Compose the full system prompt: base + preloaded skills + memory."""
        parts: list[str] = [self.get_system_prompt()]

        # Inject preloaded skills
        if self.skill_registry is not None:
            preloads = self.context.config.skills.preloads.get(
                self.context.agent_type, []
            )
            if preloads:
                skill_block = self.skill_registry.get_prompt_blocks(preloads)
                if skill_block:
                    parts.append("\n\n# Preloaded Skills\n")
                    parts.append(skill_block)

        # Inject cross-session memory
        if self.memory and len(self.memory) > 0:
            memory_block = self.memory.to_prompt_block()
            if memory_block:
                parts.append("\n\n")
                parts.append(memory_block)

        return "\n".join(parts)

    def _build_initial_message(self) -> str:
        """Compose the first user message from ticket data + static context."""
        parts: list[str] = []

        # Static project context
        if self.context.static_context:
            parts.append("## Project Context")
            for key, value in self.context.static_context.items():
                parts.append(f"### {key}")
                parts.append(str(value) if not isinstance(value, str) else value)
            parts.append("")

        # Ticket data
        if self.context.ticket_data:
            parts.append("## Ticket")
            for key, value in self.context.ticket_data.items():
                if isinstance(value, (dict, list)):
                    parts.append(f"**{key}:**\n```json\n{json.dumps(value, indent=2)}\n```")
                else:
                    parts.append(f"**{key}:** {value}")
            parts.append("")

        parts.append(
            "Please analyse the above and proceed according to your instructions."
        )
        return "\n".join(parts)

    # ------------------------------------------------------------------
    # Tool filtering
    # ------------------------------------------------------------------

    def _get_filtered_tools(self) -> list[dict[str, Any]]:
        """Return OpenAI-formatted tools, optionally restricted."""
        all_tools = self.bridge.get_openai_tools()
        allowed = self.get_available_tool_names()

        if allowed is None:
            return all_tools

        allowed_set = set(allowed)
        return [t for t in all_tools if t["function"]["name"] in allowed_set]

    # ------------------------------------------------------------------
    # Tool execution
    # ------------------------------------------------------------------

    async def _execute_tool_calls(
        self, tool_calls: list[Any], *, iteration: int = 0
    ) -> ThinkResult:
        """Run up to ``TOOLS_PER_TURN_LIMIT`` tool calls and append results
        to the message history.  Each call is individually audited."""
        result = ThinkResult()

        calls_to_run = tool_calls[: self.TOOLS_PER_TURN_LIMIT]
        if len(tool_calls) > self.TOOLS_PER_TURN_LIMIT:
            logger.warning(
                "[%s] Truncated tool calls from %d to %d",
                self.instance_id[:8],
                len(tool_calls),
                self.TOOLS_PER_TURN_LIMIT,
            )

        for tc in calls_to_run:
            fn_name = tc.function.name
            try:
                arguments = json.loads(tc.function.arguments)
            except (json.JSONDecodeError, TypeError):
                arguments = {}

            result.tool_calls.append(
                {"name": fn_name, "arguments": arguments, "id": tc.id}
            )

            # Sanitise arguments for audit (truncate large values)
            args_summary = json.dumps(arguments, default=str)[:500]

            # ── Audit: tool call start ──
            start_time = await self.audit.log_tool_call_start(
                tool_name=fn_name,
                arguments_summary=args_summary,
                iteration=iteration,
            )

            try:
                tool_result = await self.bridge.execute_tool_call(fn_name, arguments)

                # Normalise the MCP result to a string for the LLM
                if hasattr(tool_result, "content"):
                    # MCP CallToolResult
                    content_parts = []
                    for block in tool_result.content:
                        if hasattr(block, "text"):
                            content_parts.append(block.text)
                        else:
                            content_parts.append(str(block))
                    tool_output = "\n".join(content_parts)
                else:
                    tool_output = json.dumps(tool_result) if not isinstance(tool_result, str) else tool_result

                # ── Audit: tool call success ──
                await self.audit.log_tool_call_success(
                    tool_name=fn_name,
                    start_time=start_time,
                    output_length=len(tool_output),
                    iteration=iteration,
                )

            except Exception as exc:
                tool_output = f"ERROR: {exc}"

                # ── Audit: tool call error ──
                await self.audit.log_tool_call_error(
                    tool_name=fn_name,
                    start_time=start_time,
                    error_message=str(exc),
                    iteration=iteration,
                )

            result.tool_results.append(
                {"name": fn_name, "id": tc.id, "output": tool_output}
            )

            # Append to conversation as tool-result message
            self.messages.append(
                {
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": tool_output,
                }
            )

        return result

    # ------------------------------------------------------------------
    # Operativo helpers
    # ------------------------------------------------------------------

    async def _update_assignment_status(self, status: str) -> None:
        """Update the assignment status via the operativo MCP server."""
        try:
            await self.bridge.execute_tool_call(
                "operativo__update_assignment",
                {
                    "assignment_id": self.context.assignment_id,
                    "status": status,
                },
            )
        except Exception as exc:
            logger.warning(
                "[%s] Failed to update assignment status to '%s': %s",
                self.instance_id[:8],
                status,
                exc,
            )

    async def _handle_failure(self, reason: str) -> None:
        """Mark the assignment as failed and publish a blocked event."""
        # Audit the failure
        await self.audit.log_agent_failed(
            error_type="agent_failure",
            error_message=reason,
        )

        # Update assignment to failed
        try:
            await self.bridge.execute_tool_call(
                "operativo__update_assignment",
                {
                    "assignment_id": self.context.assignment_id,
                    "status": "failed",
                    "failure_reason": reason,
                },
            )
        except Exception as exc:
            logger.warning(
                "[%s] Could not update assignment to failed: %s",
                self.instance_id[:8],
                exc,
            )

        # Publish a blocked event so the orchestrator can react
        try:
            await self.bridge.execute_tool_call(
                "operativo__publish_event",
                {
                    "event_type": "agent_blocked",
                    "ticket_id": self.context.ticket_id,
                    "assignment_id": self.context.assignment_id,
                    "agent_type": self.context.agent_type,
                    "reason": reason,
                },
            )
        except Exception as exc:
            logger.warning(
                "[%s] Could not publish blocked event: %s",
                self.instance_id[:8],
                exc,
            )
