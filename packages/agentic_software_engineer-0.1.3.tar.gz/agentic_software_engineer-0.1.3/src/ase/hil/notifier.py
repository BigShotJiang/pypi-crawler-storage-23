"""Notification dispatcher for Human-in-the-Loop alerts.

Supports multiple notification methods configured via ``HILConfig``.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ase.config.schema import HILConfig

logger = logging.getLogger(__name__)


class Notifier:
    """Send notifications to humans via the configured channel.

    Parameters
    ----------
    config:
        The ``HILConfig`` that determines which notification method to use.
    """

    def __init__(self, config: "HILConfig") -> None:
        self._config = config

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def notify(self, title: str, body: str) -> None:
        """Dispatch a notification using the configured method.

        Parameters
        ----------
        title:
            Short summary / heading for the notification.
        body:
            Detailed notification content.
        """
        method = self._config.notification_method.value

        if method == "stdout":
            self._notify_stdout(title, body)
        elif method == "webhook":
            await self._notify_webhook(title, body)
        elif method == "slack":
            await self._notify_slack(title, body)
        else:
            logger.warning("Unknown notification method: %s", method)

    # ------------------------------------------------------------------
    # STDOUT
    # ------------------------------------------------------------------

    @staticmethod
    def _notify_stdout(title: str, body: str) -> None:
        """Print a formatted notification to stdout."""
        border = "=" * 60
        print(f"\n{border}")
        print(f"  {title}")
        print(border)
        print(body)
        print(f"{border}\n")

    # ------------------------------------------------------------------
    # Webhook (stub)
    # ------------------------------------------------------------------

    async def _notify_webhook(self, title: str, body: str) -> None:
        """Send notification via a generic webhook.

        .. note:: This is a stub.  A future implementation will POST JSON
           to ``self._config.notification_webhook_url``.
        """
        url = self._config.notification_webhook_url
        logger.info(
            "WEBHOOK stub: would POST to %s -- title=%r",
            url or "<not configured>",
            title,
        )
        # TODO: implement actual HTTP POST
        # async with httpx.AsyncClient() as client:
        #     await client.post(url, json={"title": title, "body": body})

    # ------------------------------------------------------------------
    # Slack (stub)
    # ------------------------------------------------------------------

    async def _notify_slack(self, title: str, body: str) -> None:
        """Send notification to a Slack channel.

        .. note:: This is a stub.  A future implementation will use the
           Slack Web API or incoming webhooks.
        """
        logger.info("SLACK stub: would send -- title=%r", title)
        # TODO: implement Slack integration
