"""PR review integration stub.

This module will eventually integrate with GitHub / GitLab PR review flows.
For now it publishes events so that other components can react to review
lifecycle changes.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Event types published by this module
# ---------------------------------------------------------------------------

EVENT_PR_REVIEW_REQUESTED = "pr_review_requested"
EVENT_PR_REVIEW_APPROVED = "pr_review_approved"
EVENT_PR_REVIEW_CHANGES_REQUESTED = "pr_review_changes_requested"


async def request_review(
    ticket_id: int,
    pr_url: str,
    reviewers: list[str] | None = None,
    *,
    event_bus: Any = None,
) -> dict[str, Any]:
    """Publish a ``pr_review_requested`` event.

    Parameters
    ----------
    ticket_id:
        The ticket this PR is associated with.
    pr_url:
        URL of the pull request.
    reviewers:
        Optional list of reviewer handles.
    event_bus:
        Optional event bus instance to publish events to.

    Returns
    -------
    dict
        The event payload that was published.
    """
    payload: dict[str, Any] = {
        "ticket_id": ticket_id,
        "pr_url": pr_url,
        "reviewers": reviewers or [],
    }

    logger.info("PR review requested for ticket=%d url=%s", ticket_id, pr_url)

    if event_bus is not None:
        await event_bus.publish(EVENT_PR_REVIEW_REQUESTED, payload)

    return payload


async def record_approval(
    ticket_id: int,
    pr_url: str,
    reviewer: str,
    *,
    event_bus: Any = None,
) -> dict[str, Any]:
    """Publish a ``pr_review_approved`` event.

    Parameters
    ----------
    ticket_id:
        The ticket this PR is associated with.
    pr_url:
        URL of the pull request.
    reviewer:
        Handle of the reviewer who approved.
    event_bus:
        Optional event bus instance.

    Returns
    -------
    dict
        The event payload that was published.
    """
    payload: dict[str, Any] = {
        "ticket_id": ticket_id,
        "pr_url": pr_url,
        "reviewer": reviewer,
    }

    logger.info(
        "PR approved for ticket=%d by=%s url=%s",
        ticket_id,
        reviewer,
        pr_url,
    )

    if event_bus is not None:
        await event_bus.publish(EVENT_PR_REVIEW_APPROVED, payload)

    return payload


async def record_changes_requested(
    ticket_id: int,
    pr_url: str,
    reviewer: str,
    comments: str = "",
    *,
    event_bus: Any = None,
) -> dict[str, Any]:
    """Publish a ``pr_review_changes_requested`` event.

    Parameters
    ----------
    ticket_id:
        The ticket this PR is associated with.
    pr_url:
        URL of the pull request.
    reviewer:
        Handle of the reviewer who requested changes.
    comments:
        Review comments / description of requested changes.
    event_bus:
        Optional event bus instance.

    Returns
    -------
    dict
        The event payload that was published.
    """
    payload: dict[str, Any] = {
        "ticket_id": ticket_id,
        "pr_url": pr_url,
        "reviewer": reviewer,
        "comments": comments,
    }

    logger.info(
        "Changes requested for ticket=%d by=%s url=%s",
        ticket_id,
        reviewer,
        pr_url,
    )

    if event_bus is not None:
        await event_bus.publish(EVENT_PR_REVIEW_CHANGES_REQUESTED, payload)

    return payload
