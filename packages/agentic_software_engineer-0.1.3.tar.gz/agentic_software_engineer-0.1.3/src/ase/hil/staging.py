"""Staging feedback handler -- Human-in-the-Loop feedback processing.

Analyses feedback from staging environments, determines sentiment, and takes
the appropriate action: creating a child ticket for negative feedback or
marking the ticket as done for positive feedback.
"""

from __future__ import annotations

import logging
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from ase.agents.bridge import MCPBridge  # noqa: F401

logger = logging.getLogger(__name__)


# Signals that indicate negative / critical feedback
_NEGATIVE_SIGNALS: list[str] = [
    "bug",
    "broken",
    "crash",
    "error",
    "fail",
    "incorrect",
    "issue",
    "missing",
    "not working",
    "problem",
    "regression",
    "wrong",
]


class StagingFeedbackHandler:
    """Process human feedback from staging environments.

    Parameters
    ----------
    bridge:
        An initialised ``MCPBridge`` for calling MCP tools.
    event_bus:
        Optional event bus for publishing ``feedback_received`` events.
    """

    def __init__(
        self,
        bridge: "MCPBridge",
        event_bus: Any = None,
    ) -> None:
        self._bridge = bridge
        self._event_bus = event_bus

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def process_feedback(
        self,
        ticket_id: int,
        feedback_content: str,
        author: str,
    ) -> dict[str, Any]:
        """Analyse *feedback_content* and act on it.

        Parameters
        ----------
        ticket_id:
            The parent ticket that the feedback is about.
        feedback_content:
            Free-form text feedback from a human reviewer.
        author:
            Identifier (name or handle) of the person giving feedback.

        Returns
        -------
        dict
            Summary of what happened: ``{"sentiment", "action", "detail"}``.
        """
        sentiment = self._determine_sentiment(feedback_content)

        logger.info(
            "Feedback on ticket=%d from=%s sentiment=%s",
            ticket_id,
            author,
            sentiment,
        )

        if sentiment == "negative":
            result = await self._handle_negative(ticket_id, feedback_content, author)
        else:
            result = await self._handle_positive(ticket_id, feedback_content, author)

        # Publish event regardless of sentiment
        await self._publish_event(ticket_id, feedback_content, author, sentiment)

        return result

    # ------------------------------------------------------------------
    # Sentiment detection
    # ------------------------------------------------------------------

    @staticmethod
    def _determine_sentiment(text: str) -> str:
        """Return ``"negative"`` if *text* contains any negative signal, else ``"positive"``."""
        lower = text.lower()
        for signal in _NEGATIVE_SIGNALS:
            if signal in lower:
                return "negative"
        return "positive"

    # ------------------------------------------------------------------
    # Handlers
    # ------------------------------------------------------------------

    async def _handle_negative(
        self,
        ticket_id: int,
        feedback: str,
        author: str,
    ) -> dict[str, Any]:
        """Create a child ticket to address the negative feedback."""
        child_ticket: dict[str, Any] = await self._bridge.execute_tool_call(
            "operativo__create_ticket",
            {
                "title": f"Feedback fix: {feedback[:80]}",
                "description": (
                    f"Negative feedback from {author} on ticket #{ticket_id}:\n\n"
                    f"{feedback}"
                ),
                "parent_id": ticket_id,
                "priority": "high",
                "status": "open",
            },
        )

        logger.info(
            "Created child ticket %s for negative feedback on ticket=%d",
            child_ticket.get("id", "<unknown>"),
            ticket_id,
        )

        return {
            "sentiment": "negative",
            "action": "child_ticket_created",
            "detail": child_ticket,
        }

    async def _handle_positive(
        self,
        ticket_id: int,
        feedback: str,
        author: str,
    ) -> dict[str, Any]:
        """Mark the ticket as done when feedback is positive."""
        updated: dict[str, Any] = await self._bridge.execute_tool_call(
            "operativo__update_ticket",
            {
                "ticket_id": ticket_id,
                "status": "done",
            },
        )

        logger.info(
            "Marked ticket=%d as done after positive feedback from %s",
            ticket_id,
            author,
        )

        return {
            "sentiment": "positive",
            "action": "ticket_marked_done",
            "detail": updated,
        }

    # ------------------------------------------------------------------
    # Event publishing
    # ------------------------------------------------------------------

    async def _publish_event(
        self,
        ticket_id: int,
        feedback: str,
        author: str,
        sentiment: str,
    ) -> None:
        """Publish a ``feedback_received`` event if an event bus is available."""
        if self._event_bus is None:
            return

        await self._event_bus.publish(
            "feedback_received",
            {
                "ticket_id": ticket_id,
                "author": author,
                "sentiment": sentiment,
                "feedback": feedback,
            },
        )
