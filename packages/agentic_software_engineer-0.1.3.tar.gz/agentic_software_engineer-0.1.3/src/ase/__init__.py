"""ASE — Agentic Software Engineer Framework."""

__version__ = "0.1.3"
