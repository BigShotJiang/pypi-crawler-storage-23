"""
Agent memory -- cross-session persistence for agent observations.

When an agent completes work on a project, it can store observations
(e.g. "this project uses JWT, not session cookies") so that future
runs skip re-analysis.

Memory is scoped per-project + per-agent-type and stored as simple
JSON files under ``.ase/memory/<agent_type>.json``.  This keeps it
human-readable, git-friendly, and zero-dependency.

Two scopes are supported:

- **project** -- stored in ``.ase/memory/`` inside the project root,
  shared by the team (committed to git)
- **local** -- stored in ``.ase/memory-local/``, personal and
  git-ignored
"""

from __future__ import annotations

import json
import logging
import os
import re
import stat
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

_SAFE_NAME_RE = re.compile(r"^[a-zA-Z0-9_-]+$")

logger = logging.getLogger(__name__)


class AgentMemory:
    """Read/write persistent memory for a single agent type.

    Each memory entry is a ``{"key": ..., "value": ..., "updated": ...}``
    dict.  Keys are unique per agent.

    Usage::

        mem = AgentMemory(project_root / ".ase" / "memory", "security")
        mem.remember("auth_strategy", "JWT with refresh tokens")
        auth = mem.recall("auth_strategy")  # -> "JWT with refresh tokens"
    """

    def __init__(self, memory_dir: Path, agent_type: str) -> None:
        if not _SAFE_NAME_RE.match(agent_type):
            raise ValueError(
                f"Unsafe agent_type '{agent_type}': must match [a-zA-Z0-9_-]+"
            )
        self._memory_dir = memory_dir
        self._agent_type = agent_type
        self._file = memory_dir / f"{agent_type}.json"
        self._data: dict[str, dict[str, Any]] = {}
        self._load()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def remember(self, key: str, value: Any, *, source: str = "") -> None:
        """Store or update a memory entry.

        Parameters
        ----------
        key:
            Unique identifier for this observation.
        value:
            Any JSON-serialisable value.
        source:
            Optional provenance string (e.g. ticket ID that caused this
            observation).
        """
        self._data[key] = {
            "value": value,
            "updated": datetime.now(timezone.utc).isoformat(),
            "source": source,
        }
        self._save()
        logger.debug("[%s] remembered '%s'", self._agent_type, key)

    def recall(self, key: str, default: Any = None) -> Any:
        """Retrieve a previously stored value, or *default*."""
        entry = self._data.get(key)
        return entry["value"] if entry else default

    def recall_all(self) -> dict[str, Any]:
        """Return all stored entries as ``{key: value}``."""
        return {k: v["value"] for k, v in self._data.items()}

    def forget(self, key: str) -> bool:
        """Remove an entry. Returns ``True`` if it existed."""
        if key in self._data:
            del self._data[key]
            self._save()
            return True
        return False

    def clear(self) -> int:
        """Remove all entries. Returns how many were deleted."""
        count = len(self._data)
        self._data.clear()
        self._save()
        return count

    def to_prompt_block(self) -> str:
        """Format all memories as a Markdown block for prompt injection.

        Returns an empty string if no memories exist.
        """
        if not self._data:
            return ""

        lines = [f"## Agent Memory ({self._agent_type})"]
        lines.append("> Previous observations from prior runs.\n")
        for key, entry in self._data.items():
            val = entry["value"]
            if isinstance(val, (dict, list)):
                val_str = json.dumps(val, indent=2)
                lines.append(f"- **{key}:**\n```json\n{val_str}\n```")
            else:
                lines.append(f"- **{key}:** {val}")
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _load(self) -> None:
        """Load from disk if the file exists."""
        if not self._file.is_file():
            self._data = {}
            return
        try:
            raw = self._file.read_text(encoding="utf-8")
            self._data = json.loads(raw)
            logger.debug(
                "[%s] loaded %d memory entries from %s",
                self._agent_type,
                len(self._data),
                self._file,
            )
        except (OSError, json.JSONDecodeError) as exc:
            logger.warning(
                "[%s] could not load memory from %s: %s",
                self._agent_type,
                self._file,
                exc,
            )
            self._data = {}

    def _save(self) -> None:
        """Persist to disk with restricted permissions (0o600)."""
        try:
            self._memory_dir.mkdir(parents=True, exist_ok=True)
            content = json.dumps(self._data, indent=2, ensure_ascii=False) + "\n"
            # Write with restricted permissions (owner read/write only)
            fd = os.open(
                str(self._file),
                os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
                stat.S_IRUSR | stat.S_IWUSR,  # 0o600
            )
            try:
                os.write(fd, content.encode("utf-8"))
            finally:
                os.close(fd)
        except OSError as exc:
            logger.error(
                "[%s] could not save memory to %s: %s",
                self._agent_type,
                self._file,
                exc,
            )

    # ------------------------------------------------------------------
    # Dunder
    # ------------------------------------------------------------------

    def __len__(self) -> int:
        return len(self._data)

    def __contains__(self, key: str) -> bool:
        return key in self._data

    def __repr__(self) -> str:
        return (
            f"<AgentMemory agent={self._agent_type!r} "
            f"entries={len(self._data)} file={self._file}>"
        )
