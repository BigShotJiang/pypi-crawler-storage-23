"""
Model configuration helpers -- convenience re-exports from the config schema.

This module exists so that other parts of the codebase can do::

    from ase.llm.models import LLMConfig, LLMRetryConfig

without reaching into the config package directly.
"""

from __future__ import annotations

from ase.config.schema import LLMConfig, LLMRetryConfig

# Well-known model identifiers used across the framework
DEFAULT_MODEL = "anthropic/claude-sonnet-4-20250514"
THINKING_MODEL = "anthropic/claude-sonnet-4-20250514"

# Model capability tiers -- helps agents pick the right model
FAST_MODELS = [
    "anthropic/claude-haiku-3-20240307",
]

STANDARD_MODELS = [
    "anthropic/claude-sonnet-4-20250514",
]

ADVANCED_MODELS = [
    "anthropic/claude-sonnet-4-20250514",
]


def get_model_for_task(
    config: LLMConfig,
    agent_type: str | None = None,
    overrides: dict[str, str] | None = None,
) -> str:
    """Resolve the model to use for a given agent type.

    Priority:
    1. Explicit *overrides* dict (``agent_type -> model``).
    2. ``config.default_model``.
    """
    if overrides and agent_type and agent_type in overrides:
        return overrides[agent_type]
    return config.default_model


__all__ = [
    "LLMConfig",
    "LLMRetryConfig",
    "DEFAULT_MODEL",
    "THINKING_MODEL",
    "FAST_MODELS",
    "STANDARD_MODELS",
    "ADVANCED_MODELS",
    "get_model_for_task",
]
