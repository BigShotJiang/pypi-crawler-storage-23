"""
LLM Client -- async wrapper around litellm with cost tracking,
retry logic, and daily spend limits.
"""

from __future__ import annotations

import logging
import time
import asyncio
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

import litellm
from litellm.exceptions import RateLimitError, ServiceUnavailableError

from ase.config.schema import LLMConfig

logger = logging.getLogger(__name__)


# ── Exceptions ────────────────────────────────────────────────────────


class DailyCostLimitExceeded(Exception):
    """Raised when the rolling 24-hour spend cap is hit."""

    def __init__(self, spent: float, limit: float) -> None:
        self.spent = spent
        self.limit = limit
        super().__init__(
            f"Daily LLM cost limit exceeded: ${spent:.4f} / ${limit:.2f}"
        )


# ── Data classes ──────────────────────────────────────────────────────


@dataclass(frozen=True)
class Usage:
    """Token usage for a single LLM call."""

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


@dataclass
class LLMResponse:
    """Normalised response from any litellm-supported model."""

    content: str | None
    tool_calls: list[Any] | None
    usage: Usage
    cost_usd: float
    model: str
    duration_ms: int

    def to_message(self) -> dict[str, Any]:
        """Convert back to an OpenAI-style assistant message for the
        conversation history."""
        msg: dict[str, Any] = {"role": "assistant"}

        if self.content:
            msg["content"] = self.content

        if self.tool_calls:
            msg["tool_calls"] = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.function.name,
                        "arguments": tc.function.arguments,
                    },
                }
                for tc in self.tool_calls
            ]
            # OpenAI spec: content may be null when tool_calls present
            if "content" not in msg:
                msg["content"] = None

        return msg


# ── Client ────────────────────────────────────────────────────────────


class LLMClient:
    """Async LLM client powered by ``litellm.acompletion``.

    Features
    --------
    * Automatic retry with exponential back-off on rate-limit / 503.
    * Per-call cost calculation via ``litellm.completion_cost``.
    * Rolling 24-hour daily cost ceiling.
    """

    def __init__(self, config: LLMConfig) -> None:
        self._config = config

        # Rolling 24-hour spend tracking
        self._daily_cost: float = 0.0
        self._daily_cost_reset_at: datetime = datetime.now(timezone.utc)

        # Suppress litellm's own verbose logging
        litellm.suppress_debug_info = True

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def chat(
        self,
        model: str | None = None,
        messages: list[dict[str, Any]] | None = None,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
    ) -> LLMResponse:
        """Send a chat completion request and return a normalised response.

        Parameters
        ----------
        model:
            Model identifier (litellm format, e.g. ``anthropic/claude-sonnet-4-20250514``).
            Falls back to ``config.default_model``.
        messages:
            Conversation history in OpenAI message format.
        tools:
            Optional list of tool definitions (OpenAI function calling schema).
        temperature:
            Sampling temperature override.
        max_tokens:
            Max completion tokens override.
        """
        model = model or self._config.default_model
        messages = messages or []
        temperature = temperature if temperature is not None else self._config.temperature
        max_tokens = max_tokens or self._config.max_tokens

        # Pre-flight cost guard
        self._check_daily_limit()

        # Build kwargs
        kwargs: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if tools:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = "auto"

        # Call with retry
        response = await self._call_with_retry(**kwargs)

        # Parse response
        choice = response.choices[0]
        message = choice.message

        # Token usage
        raw_usage = response.usage
        usage = Usage(
            prompt_tokens=raw_usage.prompt_tokens or 0,
            completion_tokens=raw_usage.completion_tokens or 0,
            total_tokens=raw_usage.total_tokens or 0,
        )

        # Cost
        cost_usd = self._calculate_cost(response)
        self._record_cost(cost_usd)

        return LLMResponse(
            content=message.content,
            tool_calls=message.tool_calls if message.tool_calls else None,
            usage=usage,
            cost_usd=cost_usd,
            model=response.model or model,
            duration_ms=int(getattr(response, "_response_ms", 0)),
        )

    # ------------------------------------------------------------------
    # Cost tracking
    # ------------------------------------------------------------------

    def _check_daily_limit(self) -> None:
        """Reset the rolling window if 24 h have passed, then check."""
        now = datetime.now(timezone.utc)
        elapsed = (now - self._daily_cost_reset_at).total_seconds()
        if elapsed >= 86_400:  # 24 hours
            logger.info(
                "Daily cost window reset (previous spend: $%.4f)",
                self._daily_cost,
            )
            self._daily_cost = 0.0
            self._daily_cost_reset_at = now

        if self._daily_cost >= self._config.cost_limit_daily_usd:
            raise DailyCostLimitExceeded(
                self._daily_cost, self._config.cost_limit_daily_usd
            )

    def _record_cost(self, cost_usd: float) -> None:
        """Add to the daily running total."""
        self._daily_cost += cost_usd
        logger.debug(
            "LLM call cost $%.6f -- daily total $%.4f / $%.2f",
            cost_usd,
            self._daily_cost,
            self._config.cost_limit_daily_usd,
        )

    @staticmethod
    def _calculate_cost(response: Any) -> float:
        """Derive the USD cost of a response via litellm."""
        try:
            return float(litellm.completion_cost(completion_response=response))
        except Exception:
            logger.warning("Could not calculate cost -- defaulting to 0.0")
            return 0.0

    # ------------------------------------------------------------------
    # Retry logic
    # ------------------------------------------------------------------

    async def _call_with_retry(self, **kwargs: Any) -> Any:
        """Call ``litellm.acompletion`` with exponential back-off on
        transient errors (429 / 503)."""
        retries = self._config.retry.max_retries
        delay = self._config.retry.base_delay_seconds
        max_delay = self._config.retry.max_delay_seconds

        last_err: Exception | None = None
        for attempt in range(1, retries + 1):
            try:
                t0 = time.monotonic()
                response = await litellm.acompletion(**kwargs)
                elapsed_ms = int((time.monotonic() - t0) * 1000)

                # Stash timing on the response for the caller
                response._response_ms = elapsed_ms  # type: ignore[attr-defined]
                return response

            except (RateLimitError, ServiceUnavailableError) as exc:
                last_err = exc
                if attempt < retries:
                    sleep_for = min(delay * (2 ** (attempt - 1)), max_delay)
                    logger.warning(
                        "LLM call failed (attempt %d/%d): %s -- retrying in %.1fs",
                        attempt,
                        retries,
                        exc,
                        sleep_for,
                    )
                    await asyncio.sleep(sleep_for)
                else:
                    logger.error(
                        "LLM call failed after %d attempts: %s", retries, exc
                    )

        # All retries exhausted
        raise last_err  # type: ignore[misc]

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    @property
    def daily_cost(self) -> float:
        return self._daily_cost

    @property
    def daily_limit(self) -> float:
        return self._config.cost_limit_daily_usd

    def __repr__(self) -> str:
        return (
            f"<LLMClient model={self._config.default_model!r} "
            f"daily=${self._daily_cost:.4f}/${self._config.cost_limit_daily_usd:.2f}>"
        )
