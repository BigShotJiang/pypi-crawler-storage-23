"""
Cost tracking utility -- logs LLM spend to the ``cost_log`` SQLite table.

Every LLM call, tool invocation, and agent completion can be recorded so
the system has a full audit trail of spend per ticket and per day.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

import aiosqlite

logger = logging.getLogger(__name__)


# ── Data classes ──────────────────────────────────────────────────────


@dataclass
class CostEntry:
    """A single cost log row."""

    ticket_id: str
    assignment_id: str
    agent_type: str
    agent_instance_id: str
    model: str
    prompt_tokens: int
    completion_tokens: int
    cost_usd: float
    event_type: str = "llm_call"  # llm_call | tool_call | completion
    metadata: str = "{}"
    created_at: str = ""

    def __post_init__(self) -> None:
        if not self.created_at:
            self.created_at = datetime.now(timezone.utc).isoformat()


# ── Table schema ──────────────────────────────────────────────────────

CREATE_COST_LOG_TABLE = """\
CREATE TABLE IF NOT EXISTS cost_log (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id       TEXT    NOT NULL,
    assignment_id   TEXT    NOT NULL,
    agent_type      TEXT    NOT NULL,
    agent_instance_id TEXT  NOT NULL,
    model           TEXT    NOT NULL DEFAULT '',
    prompt_tokens   INTEGER NOT NULL DEFAULT 0,
    completion_tokens INTEGER NOT NULL DEFAULT 0,
    cost_usd        REAL    NOT NULL DEFAULT 0.0,
    event_type      TEXT    NOT NULL DEFAULT 'llm_call',
    metadata        TEXT    NOT NULL DEFAULT '{}',
    created_at      TEXT    NOT NULL
);
"""

CREATE_COST_LOG_INDEXES = """\
CREATE INDEX IF NOT EXISTS idx_cost_log_ticket    ON cost_log(ticket_id);
CREATE INDEX IF NOT EXISTS idx_cost_log_date      ON cost_log(created_at);
CREATE INDEX IF NOT EXISTS idx_cost_log_agent     ON cost_log(agent_type);
"""


# ── Cost tracker ──────────────────────────────────────────────────────


class CostTracker:
    """Async utility that writes cost entries to the ``cost_log`` table."""

    def __init__(self, db_path: str) -> None:
        self._db_path = db_path
        self._initialised = False

    async def _ensure_table(self, db: aiosqlite.Connection) -> None:
        """Create the cost_log table and indexes if they don't exist."""
        if self._initialised:
            return
        await db.executescript(CREATE_COST_LOG_TABLE + CREATE_COST_LOG_INDEXES)
        await db.commit()
        self._initialised = True

    async def log(self, entry: CostEntry) -> None:
        """Persist a single cost entry."""
        async with aiosqlite.connect(self._db_path) as db:
            await self._ensure_table(db)
            await db.execute(
                """\
                INSERT INTO cost_log
                    (ticket_id, assignment_id, agent_type, agent_instance_id,
                     model, prompt_tokens, completion_tokens, cost_usd,
                     event_type, metadata, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    entry.ticket_id,
                    entry.assignment_id,
                    entry.agent_type,
                    entry.agent_instance_id,
                    entry.model,
                    entry.prompt_tokens,
                    entry.completion_tokens,
                    entry.cost_usd,
                    entry.event_type,
                    entry.metadata,
                    entry.created_at,
                ),
            )
            await db.commit()

    async def log_many(self, entries: list[CostEntry]) -> None:
        """Persist multiple cost entries in a single transaction."""
        if not entries:
            return
        async with aiosqlite.connect(self._db_path) as db:
            await self._ensure_table(db)
            await db.executemany(
                """\
                INSERT INTO cost_log
                    (ticket_id, assignment_id, agent_type, agent_instance_id,
                     model, prompt_tokens, completion_tokens, cost_usd,
                     event_type, metadata, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                [
                    (
                        e.ticket_id,
                        e.assignment_id,
                        e.agent_type,
                        e.agent_instance_id,
                        e.model,
                        e.prompt_tokens,
                        e.completion_tokens,
                        e.cost_usd,
                        e.event_type,
                        e.metadata,
                        e.created_at,
                    )
                    for e in entries
                ],
            )
            await db.commit()

    # ------------------------------------------------------------------
    # Query helpers
    # ------------------------------------------------------------------

    async def get_ticket_cost(self, ticket_id: str) -> float:
        """Return the total USD spent on a ticket."""
        async with aiosqlite.connect(self._db_path) as db:
            await self._ensure_table(db)
            cursor = await db.execute(
                "SELECT COALESCE(SUM(cost_usd), 0) FROM cost_log WHERE ticket_id = ?",
                (ticket_id,),
            )
            row = await cursor.fetchone()
            return float(row[0]) if row else 0.0

    async def get_daily_cost(self, date_str: str | None = None) -> float:
        """Return total USD spent on a given day (defaults to today UTC)."""
        if date_str is None:
            date_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")

        async with aiosqlite.connect(self._db_path) as db:
            await self._ensure_table(db)
            cursor = await db.execute(
                "SELECT COALESCE(SUM(cost_usd), 0) FROM cost_log "
                "WHERE created_at LIKE ?",
                (f"{date_str}%",),
            )
            row = await cursor.fetchone()
            return float(row[0]) if row else 0.0

    async def get_agent_cost_summary(self) -> list[dict[str, Any]]:
        """Return per-agent-type cost summary.

        Returns a list of dicts with keys:
        ``agent_type``, ``total_cost``, ``total_calls``,
        ``total_prompt_tokens``, ``total_completion_tokens``.
        """
        async with aiosqlite.connect(self._db_path) as db:
            await self._ensure_table(db)
            cursor = await db.execute(
                """\
                SELECT
                    agent_type,
                    SUM(cost_usd)            AS total_cost,
                    COUNT(*)                 AS total_calls,
                    SUM(prompt_tokens)       AS total_prompt_tokens,
                    SUM(completion_tokens)   AS total_completion_tokens
                FROM cost_log
                GROUP BY agent_type
                ORDER BY total_cost DESC
                """
            )
            rows = await cursor.fetchall()
            return [
                {
                    "agent_type": row[0],
                    "total_cost": row[1],
                    "total_calls": row[2],
                    "total_prompt_tokens": row[3],
                    "total_completion_tokens": row[4],
                }
                for row in rows
            ]
