"""Entry point: python -m ase."""

from ase.cli.main import app

app()
