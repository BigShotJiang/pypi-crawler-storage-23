"""ASE CLI -- Typer + Rich powered command-line interface.

Commands
--------
init      Initialise ASE in the current project directory.
start     Launch MCP servers and event loop.
submit    Submit a work request to the agents.
status    Show ticket and agent status.
metrics   Display cost and throughput metrics.
audit     Browse decision logs.
guide     Interactive framework guide.
onboard   Discover and populate project context.
version   Print version.
"""

from __future__ import annotations

import asyncio
import logging
import sys
from pathlib import Path
from typing import Optional

import click
import typer
from rich.console import Console
from rich.logging import RichHandler
from rich.panel import Panel
from rich.table import Table

app = typer.Typer(
    name="ase",
    help="ASE -- Agentic Software Engineer Framework",
    add_completion=False,
)
console = Console()

# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _setup_logging(verbose: bool = False) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(message)s",
        datefmt="[%X]",
        handlers=[RichHandler(rich_tracebacks=True, console=console)],
    )


def _project_root() -> Path:
    """Return the current working directory as the project root."""
    return Path.cwd().resolve()


def _require_init() -> Path:
    """Return CWD if ASE is initialised here, otherwise exit with error."""
    root = _project_root()
    if not (root / ".ase" / "config.toml").exists():
        console.print(
            "[red]ASE not initialised in this directory.[/red]\n"
            "Run [bold]ase init[/bold] first."
        )
        raise typer.Exit(code=1)
    return root


def _run(coro):  # noqa: ANN001
    """Run an async coroutine from the sync CLI."""
    return asyncio.run(coro)


# ---------------------------------------------------------------------------
# init
# ---------------------------------------------------------------------------


@app.command()
def init(
    name: Optional[str] = typer.Option(
        None, "--name", "-n", help="Project name (default: directory name)."
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Initialise ASE in the current directory.

    Creates a .ase/ folder with database and config, and adds .ase/ to .gitignore.
    Run this inside your project root.
    """
    _setup_logging(verbose)

    from ase.scaffold.generator import scaffold_project

    project_path = _project_root()
    project_name = name or project_path.name

    console.print(f"\n[bold blue]Initialising ASE in:[/] {project_path}")
    console.print(f"[dim]Project name: {project_name}[/dim]\n")

    status = scaffold_project(project_path, project_name)

    if status.is_initialized:
        console.print(
            Panel(
                f"[green]ASE initialised for '{project_name}'[/green]\n\n"
                f"  Data:    {project_path / '.ase'}\n"
                f"  Config:  {project_path / '.ase' / 'config.toml'}\n"
                f"  DB:      {project_path / '.ase' / 'ase.db'}\n\n"
                "[dim]Edit .ase/config.toml to customise, then run:[/dim]\n"
                "  [bold]ase submit \"your work request\"[/bold]",
                title="[bold green]Ready[/bold green]",
            )
        )
    else:
        console.print("[red]Scaffolding incomplete. Check logs above.[/red]")
        raise typer.Exit(code=1)


# ---------------------------------------------------------------------------
# start
# ---------------------------------------------------------------------------


@app.command()
def start(
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Launch MCP servers and the event loop (persistent mode)."""
    _setup_logging(verbose)

    project_path = _require_init()

    console.print(f"\n[bold blue]Starting ASE in:[/] {project_path}\n")

    _run(_start_project(project_path))


async def _start_project(project_path: Path) -> None:
    """Async entrypoint: boot the full ASE runtime (MCP + agents + event loop)."""
    from ase.runtime import ASERuntime

    runtime = ASERuntime(project_path)

    console.print("[dim]Launching MCP servers and agent infrastructure...[/dim]")
    await runtime.start()

    config = runtime.config
    console.print(
        Panel(
            f"[bold]Project:[/bold]  {config.project.name}\n"
            f"[bold]DB:[/bold]       {config.project.db_path}\n"
            f"[bold]Model:[/bold]    {config.llm.default_model}\n"
            f"[bold]Agents:[/bold]   {', '.join(config.agents.enabled)}\n"
            f"[bold]Tools:[/bold]    {len(runtime.bridge.registered_tools)} loaded\n"
            f"[bold]Servers:[/bold]  {', '.join(runtime.bridge.registered_servers)}\n\n"
            "[dim]Use [bold]ase submit[/bold] to create tickets.\n"
            "Press Ctrl+C to stop.[/dim]",
            title="[bold green]Runtime Active[/bold green]",
        )
    )

    # Show completeness warning if context is incomplete
    if runtime.completeness and not runtime.completeness.is_ready:
        console.print(
            f"\n[yellow]⚠ Context incomplete ({runtime.completeness.score:.0%}). "
            f"Run [bold]ase onboard[/bold] to populate.[/yellow]"
        )

    # Keep alive until interrupted
    try:
        while True:
            await asyncio.sleep(1)
    except (KeyboardInterrupt, asyncio.CancelledError):
        console.print("\n[yellow]Shutting down...[/yellow]")
        await runtime.stop()
        console.print("[green]Stopped.[/green]")


# ---------------------------------------------------------------------------
# submit
# ---------------------------------------------------------------------------


@app.command()
def submit(
    request: str = typer.Argument(..., help="Work request text."),
    priority: str = typer.Option("medium", "--priority", "-P", help="low|medium|high|critical",
        click_type=click.Choice(["low", "medium", "high", "critical"]),
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Submit a work request that creates a ticket and triggers the pipeline."""
    _setup_logging(verbose)

    project_path = _require_init()

    console.print(f"\n[bold blue]Submitting request[/]")
    console.print(f"[dim]Priority: {priority}[/dim]")
    console.print(f"[dim]Request:  {request[:200]}{'...' if len(request) > 200 else ''}[/dim]\n")

    _run(_submit_request(project_path, request, priority))


async def _submit_request(project_path: Path, request: str, priority: str) -> None:
    """Create a ticket and trigger the full agent pipeline."""
    from ase.runtime import ASERuntime

    runtime = ASERuntime(project_path)

    console.print("[dim]Booting runtime...[/dim]")
    await runtime.start()

    try:
        console.print(
            Panel(
                f"[bold]Project:[/bold]  {runtime.config.project.name}\n"
                f"[bold]Priority:[/bold] {priority}\n"
                f"[bold]Content:[/bold]\n{request[:500]}",
                title="[bold cyan]Submitting Ticket[/bold cyan]",
            )
        )

        ticket = await runtime.submit(request, priority=priority)
        ticket_id = ticket.get("id", "unknown")

        console.print(
            f"\n[bold green]Ticket created:[/bold green] {ticket_id}\n"
            f"[dim]Pipeline: intake → analyze → triage → plan → execute → review[/dim]\n"
        )

        # Wait for agents to finish (with a generous timeout)
        console.print("[yellow]Waiting for agents to complete...[/yellow]")
        await runtime.wait_idle(timeout=600.0)

        console.print("[bold green]Pipeline complete.[/bold green]")

    finally:
        await runtime.stop()


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------


@app.command()
def status(
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Show the current state of tickets and agents."""
    _setup_logging(verbose)

    project_path = _require_init()

    _run(_show_status(project_path))


async def _show_status(project_path: Path) -> None:
    """Query the DB and display ticket / agent status."""
    import sqlite3

    from ase.config.loader import load_config

    config = load_config(project_path)
    db_path = config.project.db_path

    if not db_path.exists():
        console.print("[yellow]No database found. Project may not have any activity yet.[/yellow]")
        return

    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row

    # Tickets summary
    table = Table(title=f"Tickets -- {config.project.name}")
    table.add_column("ID", style="cyan", justify="right")
    table.add_column("Title", style="white", max_width=50)
    table.add_column("Priority", style="yellow")
    table.add_column("Status", style="green")
    table.add_column("Created", style="dim")

    try:
        rows = conn.execute(
            "SELECT id, title, priority, status, created_at "
            "FROM tickets ORDER BY created_at DESC LIMIT 20"
        ).fetchall()
        for r in rows:
            table.add_row(
                str(r["id"]),
                r["title"][:50],
                r["priority"],
                r["status"],
                r["created_at"],
            )
    except sqlite3.OperationalError:
        table.add_row("-", "No tickets table found", "-", "-", "-")

    console.print(table)
    conn.close()


# ---------------------------------------------------------------------------
# metrics
# ---------------------------------------------------------------------------


@app.command()
def metrics(
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Display cost and throughput metrics."""
    _setup_logging(verbose)

    project_path = _require_init()

    _run(_show_metrics(project_path))


async def _show_metrics(project_path: Path) -> None:
    """Query cost_log and display metrics."""
    import sqlite3

    from ase.config.loader import load_config

    config = load_config(project_path)
    db_path = config.project.db_path

    if not db_path.exists():
        console.print("[yellow]No database found.[/yellow]")
        return

    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row

    table = Table(title=f"Metrics -- {config.project.name}")
    table.add_column("Metric", style="bold")
    table.add_column("Value", justify="right")

    # Ticket counts by status
    try:
        rows = conn.execute(
            "SELECT status, COUNT(*) as cnt FROM tickets GROUP BY status"
        ).fetchall()
        for r in rows:
            table.add_row(f"Tickets ({r['status']})", str(r["cnt"]))
    except sqlite3.OperationalError:
        table.add_row("Tickets", "N/A")

    # Cost summary
    try:
        row = conn.execute(
            "SELECT COALESCE(SUM(cost_usd), 0) as total FROM cost_log"
        ).fetchone()
        table.add_row("Total LLM Cost (USD)", f"${row['total']:.4f}")
    except sqlite3.OperationalError:
        table.add_row("Total LLM Cost (USD)", "N/A")

    # Decision log count
    try:
        row = conn.execute("SELECT COUNT(*) as cnt FROM decision_log").fetchone()
        table.add_row("Decision Log Entries", str(row["cnt"]))
    except sqlite3.OperationalError:
        table.add_row("Decision Log Entries", "N/A")

    console.print(table)
    conn.close()


# ---------------------------------------------------------------------------
# version
# ---------------------------------------------------------------------------


@app.command()
def version() -> None:
    """Print the ASE version."""
    from ase import __version__

    console.print(f"ASE v{__version__}")


# ---------------------------------------------------------------------------
# audit
# ---------------------------------------------------------------------------


@app.command()
def audit(
    trace_id: Optional[str] = typer.Option(
        None, "--trace", "-t", help="Filter by trace ID (or prefix)."
    ),
    agent_type: Optional[str] = typer.Option(
        None, "--agent", "-a", help="Filter by agent type (e.g. backend, triage)."
    ),
    event_type: Optional[str] = typer.Option(
        None, "--event", "-e", help="Filter by event type (e.g. tool_call_error, llm_response)."
    ),
    ticket_id: Optional[str] = typer.Option(
        None, "--ticket", "-T", help="Filter by ticket ID."
    ),
    last: int = typer.Option(
        50, "--last", "-n", help="Show the last N events (default: 50)."
    ),
    follow: bool = typer.Option(
        False, "--follow", "-f", help="Follow mode: stream new events as they arrive."
    ),
    stats: bool = typer.Option(
        False, "--stats", help="Show summary statistics instead of individual events."
    ),
    cleanup: bool = typer.Option(
        False, "--cleanup", help="Delete log files older than retention period."
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Browse, filter, and manage audit logs.

    Examples::

        ase audit                           # last 50 events
        ase audit -n 200                    # last 200 events
        ase audit --agent backend           # only backend agent events
        ase audit --event tool_call_error   # only tool errors
        ase audit --trace abc123            # single run
        ase audit --stats                   # summary table
        ase audit -f                        # live tail
        ase audit --cleanup                 # purge old logs
    """
    _setup_logging(verbose)

    project_path = _require_init()

    from ase.config.loader import load_config

    config = load_config(project_path)
    log_dir = project_path / config.logging.audit_log_dir
    log_file = log_dir / "audit.jsonl"

    if cleanup:
        _audit_cleanup(log_dir, config.logging.events_retention_days)
        return

    if not log_file.exists():
        console.print(
            "[yellow]No audit logs found.[/yellow]\n"
            f"[dim]Expected at: {log_file}[/dim]\n"
            "[dim]Logs are created when agents run.[/dim]"
        )
        raise typer.Exit(code=0)

    if stats:
        _audit_stats(log_file, trace_id=trace_id, agent_type=agent_type)
        return

    if follow:
        _audit_follow(log_file, agent_type=agent_type, event_type=event_type)
        return

    _audit_list(
        log_file,
        last=last,
        trace_id=trace_id,
        agent_type=agent_type,
        event_type=event_type,
        ticket_id=ticket_id,
    )


def _parse_log_lines(
    log_file: Path,
    *,
    trace_id: Optional[str] = None,
    agent_type: Optional[str] = None,
    event_type: Optional[str] = None,
    ticket_id: Optional[str] = None,
) -> list[dict]:
    """Read all JSON lines from log_file + rotated backups, apply filters."""
    import json as _json

    files: list[Path] = []
    # Collect rotated files: audit.jsonl.5, .4, .3, .2, .1, audit.jsonl
    for i in range(9, 0, -1):
        rotated = log_file.parent / f"{log_file.name}.{i}"
        if rotated.exists():
            files.append(rotated)
    files.append(log_file)

    events: list[dict] = []
    for f in files:
        with open(f, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = _json.loads(line)
                except _json.JSONDecodeError:
                    continue

                # Apply filters
                if trace_id and not obj.get("trace_id", "").startswith(trace_id):
                    continue
                if agent_type and obj.get("agent_type") != agent_type:
                    continue
                if event_type and obj.get("event_type") != event_type:
                    continue
                if ticket_id and obj.get("ticket_id") != ticket_id:
                    continue

                events.append(obj)

    return events


def _audit_list(
    log_file: Path,
    *,
    last: int,
    trace_id: Optional[str],
    agent_type: Optional[str],
    event_type: Optional[str],
    ticket_id: Optional[str],
) -> None:
    """Display audit events in a Rich table."""
    events = _parse_log_lines(
        log_file,
        trace_id=trace_id,
        agent_type=agent_type,
        event_type=event_type,
        ticket_id=ticket_id,
    )

    # Take the last N
    events = events[-last:]

    if not events:
        console.print("[yellow]No matching audit events found.[/yellow]")
        return

    table = Table(title=f"Audit Log ({len(events)} events)")
    table.add_column("Time", style="dim", max_width=19)
    table.add_column("Trace", style="cyan", max_width=8)
    table.add_column("Event", style="bold")
    table.add_column("Agent", style="green")
    table.add_column("Ticket", style="yellow")
    table.add_column("Details", max_width=60)

    # Color map for event types
    event_colors = {
        "agent_started": "bold green",
        "agent_completed": "bold green",
        "agent_failed": "bold red",
        "agent_timeout": "bold red",
        "llm_request": "blue",
        "llm_response": "blue",
        "tool_call_start": "magenta",
        "tool_call_success": "green",
        "tool_call_error": "red",
        "decision": "cyan",
        "cost_warning": "yellow",
        "cost_limit_hit": "bold red",
    }

    for ev in events:
        ts = ev.get("timestamp", "")[:19]  # trim to seconds
        trace = ev.get("trace_id", "")[:8]
        evt = ev.get("event_type", ev.get("message", ""))
        agent = ev.get("agent_type", "")
        tkt = ev.get("ticket_id", "")

        # Build details string based on event type
        details = _event_details(ev)

        color = event_colors.get(evt, "white")
        table.add_row(ts, trace, f"[{color}]{evt}[/{color}]", agent, tkt, details)

    console.print(table)

    # Disk usage info
    log_dir = log_file.parent
    total_bytes = sum(f.stat().st_size for f in log_dir.glob("*.jsonl*") if f.is_file())
    console.print(
        f"\n[dim]Log storage: {total_bytes / 1024 / 1024:.1f} MB "
        f"in {log_dir}[/dim]"
    )


def _event_details(ev: dict) -> str:
    """Extract a human-readable summary from an audit event dict."""
    evt = ev.get("event_type", "")

    if evt == "llm_response":
        return (
            f"tokens: {ev.get('tokens_in', 0)}→{ev.get('tokens_out', 0)} "
            f"${ev.get('cost_usd', 0):.4f} "
            f"tools: {ev.get('tool_calls_count', 0)}"
        )
    if evt in ("tool_call_start", "tool_call_success", "tool_call_error"):
        name = ev.get("tool_name", "")
        duration = ev.get("duration_ms", "")
        err = ev.get("error_message", "")
        if err:
            return f"{name} ERR: {err[:40]}"
        if duration:
            return f"{name} ({duration:.0f}ms)"
        return name
    if evt == "agent_completed":
        return (
            f"iters: {ev.get('iterations', 0)} "
            f"tokens: {ev.get('total_tokens_in', 0)}+{ev.get('total_tokens_out', 0)} "
            f"${ev.get('total_cost_usd', 0):.4f}"
        )
    if evt == "agent_failed":
        return ev.get("error_message", "")[:60]
    if evt == "agent_started":
        return f"model: {ev.get('model', '')} tools: {ev.get('tools_available', 0)}"
    if evt == "decision":
        return f"{ev.get('action', '')}: {ev.get('reasoning', '')[:40]}"
    if evt in ("cost_warning", "cost_limit_hit"):
        return f"${ev.get('current_cost_usd', ev.get('spent_usd', 0)):.4f} / ${ev.get('limit_usd', 0):.2f}"

    return ev.get("message", "")[:60]


def _audit_stats(
    log_file: Path,
    *,
    trace_id: Optional[str] = None,
    agent_type: Optional[str] = None,
) -> None:
    """Show summary statistics of audit events."""
    events = _parse_log_lines(log_file, trace_id=trace_id, agent_type=agent_type)

    if not events:
        console.print("[yellow]No audit events found.[/yellow]")
        return

    # Aggregate
    by_type: dict[str, int] = {}
    by_agent: dict[str, int] = {}
    total_cost = 0.0
    total_tokens_in = 0
    total_tokens_out = 0
    tool_errors = 0
    agent_failures = 0
    unique_traces = set()

    for ev in events:
        evt = ev.get("event_type", "unknown")
        by_type[evt] = by_type.get(evt, 0) + 1

        ag = ev.get("agent_type", "")
        if ag:
            by_agent[ag] = by_agent.get(ag, 0) + 1

        if evt == "llm_response":
            total_cost += ev.get("cost_usd", 0)
            total_tokens_in += ev.get("tokens_in", 0)
            total_tokens_out += ev.get("tokens_out", 0)
        elif evt == "tool_call_error":
            tool_errors += 1
        elif evt == "agent_failed":
            agent_failures += 1

        tid = ev.get("trace_id", "")
        if tid:
            unique_traces.add(tid)

    # Summary table
    table = Table(title="Audit Statistics")
    table.add_column("Metric", style="bold")
    table.add_column("Value", justify="right")

    table.add_row("Total events", str(len(events)))
    table.add_row("Unique agent runs", str(len(unique_traces)))
    table.add_row("Total LLM cost", f"${total_cost:.4f}")
    table.add_row("Total tokens in", f"{total_tokens_in:,}")
    table.add_row("Total tokens out", f"{total_tokens_out:,}")
    table.add_row("Tool call errors", f"[red]{tool_errors}[/red]" if tool_errors else "0")
    table.add_row("Agent failures", f"[red]{agent_failures}[/red]" if agent_failures else "0")
    console.print(table)

    # Events by type
    type_table = Table(title="Events by Type")
    type_table.add_column("Event Type", style="cyan")
    type_table.add_column("Count", justify="right")
    for evt, cnt in sorted(by_type.items(), key=lambda x: -x[1]):
        type_table.add_row(evt, str(cnt))
    console.print(type_table)

    # Events by agent
    if by_agent:
        agent_table = Table(title="Events by Agent")
        agent_table.add_column("Agent", style="green")
        agent_table.add_column("Count", justify="right")
        for ag, cnt in sorted(by_agent.items(), key=lambda x: -x[1]):
            agent_table.add_row(ag, str(cnt))
        console.print(agent_table)


def _audit_follow(
    log_file: Path,
    *,
    agent_type: Optional[str] = None,
    event_type: Optional[str] = None,
) -> None:
    """Tail the log file like 'tail -f', with optional filters."""
    import json as _json
    import time as _time

    console.print(
        f"[dim]Following {log_file} (Ctrl+C to stop)...[/dim]\n"
    )

    try:
        with open(log_file, encoding="utf-8") as fh:
            # Seek to end
            fh.seek(0, 2)

            while True:
                line = fh.readline()
                if not line:
                    _time.sleep(0.3)
                    continue

                line = line.strip()
                if not line:
                    continue

                try:
                    obj = _json.loads(line)
                except _json.JSONDecodeError:
                    continue

                if agent_type and obj.get("agent_type") != agent_type:
                    continue
                if event_type and obj.get("event_type") != event_type:
                    continue

                ts = obj.get("timestamp", "")[:19]
                evt = obj.get("event_type", "?")
                agent = obj.get("agent_type", "")
                details = _event_details(obj)

                console.print(
                    f"[dim]{ts}[/dim] "
                    f"[cyan]{obj.get('trace_id', '')[:8]}[/cyan] "
                    f"[bold]{evt}[/bold] "
                    f"[green]{agent}[/green] "
                    f"{details}"
                )

    except KeyboardInterrupt:
        console.print("\n[yellow]Stopped following.[/yellow]")


def _audit_cleanup(log_dir: Path, retention_days: int) -> None:
    """Delete old log files and report what was cleaned."""
    from ase.audit.formatter import cleanup_old_logs

    if not log_dir.exists():
        console.print("[yellow]No log directory found.[/yellow]")
        return

    # Show current usage
    total_bytes = sum(f.stat().st_size for f in log_dir.glob("*.jsonl*") if f.is_file())
    file_count = len(list(log_dir.glob("*.jsonl*")))

    console.print(
        f"[dim]Log directory: {log_dir}[/dim]\n"
        f"[dim]Files: {file_count} | Size: {total_bytes / 1024 / 1024:.1f} MB[/dim]\n"
        f"[dim]Retention: {retention_days} days[/dim]\n"
    )

    deleted = cleanup_old_logs(log_dir, retention_days=retention_days)

    if deleted:
        console.print(f"[green]Cleaned up {deleted} old log file(s).[/green]")
    else:
        console.print("[dim]Nothing to clean up.[/dim]")


# ---------------------------------------------------------------------------
# guide
# ---------------------------------------------------------------------------

_GUIDE_SECTIONS: dict[str, tuple[str, str]] = {
    "overview": (
        "ASE Framework Overview",
        """\
[bold]ASE (Agentic Software Engineer)[/bold] è un framework Python che
trasforma ticket di lavoro in codice, test, docs e deploy tramite agenti
LLM specializzati.

[bold cyan]Flusso principale:[/bold cyan]
  1. [yellow]ase init myproject[/yellow]   → scaffolda progetto + DB + config
  2. [yellow]ase start myproject[/yellow]  → avvia MCP servers (operativo + statico)
  3. [yellow]ase submit myproject "Aggiungi endpoint /users"[/yellow]
     → crea ticket → TriageAgent smista → agenti specializzati eseguono
  4. [yellow]ase status myproject[/yellow] → mostra avanzamento
  5. [yellow]ase audit myproject[/yellow]  → ispeziona log di ogni azione

[bold cyan]Concetti chiave:[/bold cyan]
  • [bold]Agents[/bold]      → LLM workers specializzati (backend, frontend, testing, ...)
  • [bold]MCP Servers[/bold] → Operativo (stato/DB) + Statico (analisi codice)
  • [bold]Skills[/bold]      → Knowledge modules riutilizzabili tra agenti
  • [bold]Memory[/bold]      → Persistenza cross-sessione delle osservazioni
  • [bold]Model Tiers[/bold] → Routing LLM per costo (fast/balanced/deep)
  • [bold]Audit[/bold]       → Ogni azione tracciata con trace_id + span_id

Digita [yellow]ase guide --topic <nome>[/yellow] per dettagli:
  agents, skills, memory, tiers, mcp, audit, config, flow""",
    ),
    "agents": (
        "Agents",
        """\
Gli [bold]agenti[/bold] sono worker LLM specializzati. Ogni agente:
• Eredita da [cyan]BaseAgent[/cyan] (think-loop: LLM → tool calls → loop)
• Ha un [bold]system prompt[/bold] dedicato ([cyan]agents/prompts/<tipo>.py[/cyan])
• Può avere [bold]skills preloaded[/bold] (knowledge iniettato nel prompt)
• Può avere [bold]memory[/bold] (osservazioni persistenti da run precedenti)
• Ha un [bold]model tier[/bold] (fast/balanced/deep)

[bold cyan]Agenti disponibili:[/bold cyan]
  [yellow]triage[/yellow]    → Smista ticket, crea piano di esecuzione           [dim](fast)[/dim]
  [yellow]analyzer[/yellow]  → Analizza codebase, identifica impatti             [dim](balanced)[/dim]
  [yellow]backend[/yellow]   → Scrive codice server-side                         [dim](balanced)[/dim]
  [yellow]frontend[/yellow]  → Scrive codice client-side                         [dim](balanced)[/dim]
  [yellow]testing[/yellow]   → Scrive e esegue test                              [dim](balanced)[/dim]
  [yellow]security[/yellow]  → Audit OWASP, dependency check, secrets            [dim](deep)[/dim]
  [yellow]database[/yellow]  → Schema, migrations, query optimization            [dim](balanced)[/dim]
  [yellow]devops[/yellow]    → CI/CD, Docker, K8s, infra-as-code                 [dim](balanced)[/dim]
  [yellow]docs[/yellow]      → README, API docs, changelog                       [dim](fast)[/dim]
  [yellow]cloud[/yellow]     → Cloud architecture, deployment                    [dim](balanced)[/dim]
  [yellow]platform[/yellow]  → Platform-level concerns                           [dim](balanced)[/dim]

[bold cyan]Lifecycle:[/bold cyan]
  AgentLifecycleManager.spawn_agent() → asyncio.Task con timeout guard
  Ogni agente gira isolato, con il proprio trace_id di audit.

[bold cyan]Config:[/bold cyan]
  [dim].ase/config.toml → [agents] enabled = ["analyzer", "triage", "backend", "testing"][/dim]
  [dim].ase/config.toml → [agents.model_overrides] backend = "anthropic/claude-opus-4-20250514"[/dim]""",
    ),
    "skills": (
        "Skills System",
        """\
Le [bold]skills[/bold] sono moduli di knowledge riutilizzabili tra agenti.
Disaccoppiano la [italic]conoscenza[/italic] dall'[italic]agente[/italic]:
la stessa skill può essere preloaded in più agenti senza duplicare.

[bold cyan]Due pattern:[/bold cyan]
  1. [bold]Agent Skill[/bold] (preloaded) → iniettata nel system prompt al boot
  2. [bold]Skill on-demand[/bold] → invocabile dall'orchestrator quando serve

[bold cyan]Layout su disco:[/bold cyan]
  [dim].ase/skills/[/dim]
  ├── [yellow]docker-best-practices/[/yellow]
  │   └── SKILL.md
  ├── [yellow]api-design/[/yellow]
  │   └── SKILL.md
  └── [yellow]testing-strategy.md[/yellow]     [dim](flat file)[/dim]

[bold cyan]SKILL.md con front-matter:[/bold cyan]
  [dim]---
  name: docker-best-practices
  description: Container image guidelines
  tags: [docker, devops, backend]
  user-invocable: false
  ---
  # Docker Best Practices
  - Use multi-stage builds
  - Pin base image versions[/dim]

[bold cyan]Config (.ase/config.toml):[/bold cyan]
  [dim][skills]
  skills_dir = ".ase/skills"
  [skills.preloads]
  backend = ["api-design", "docker-best-practices"]
  devops = ["docker-best-practices"]
  security = ["owasp-top-10"][/dim]""",
    ),
    "memory": (
        "Agent Memory",
        """\
La [bold]memory[/bold] permette agli agenti di ricordare tra sessioni.
Se il SecurityAgent scopre "questo progetto usa JWT", lo salva e nei
run successivi lo sa già senza ri-analizzare.

[bold cyan]API:[/bold cyan]
  [yellow]memory.remember(key, value, source="TK-001")[/yellow]  → salva
  [yellow]memory.recall(key)[/yellow]                             → recupera
  [yellow]memory.forget(key)[/yellow]                             → elimina
  [yellow]memory.to_prompt_block()[/yellow]                       → inietta nel prompt

[bold cyan]Storage:[/bold cyan]
  [dim].ase/memory/<agent_type>.json[/dim]    → scope "project" (committato, team)
  [dim].ase/memory-local/<agent_type>.json[/dim] → scope "local" (git-ignored)

[bold cyan]Formato:[/bold cyan]
  [dim]{
    "auth_strategy": {
      "value": "JWT with refresh tokens",
      "updated": "2026-03-04T10:30:00Z",
      "source": "TK-042"
    }
  }[/dim]

[bold cyan]Config (.ase/config.toml):[/bold cyan]
  [dim][memory]
  scope = "project"         # project | local | disabled
  project_dir = ".ase/memory"
  local_dir = ".ase/memory-local"[/dim]""",
    ),
    "tiers": (
        "Model Tiering",
        """\
Il [bold]model tiering[/bold] assegna modelli LLM diversi per ruolo,
ottimizzando costo vs. qualità.

[bold cyan]Tre livelli:[/bold cyan]
  [green]fast[/green]      → haiku     [dim]($0.25/MTok)[/dim]  Triage, docs, smistamento rapido
  [yellow]balanced[/yellow]  → sonnet    [dim]($3/MTok)[/dim]    Backend, frontend, testing, standard
  [red]deep[/red]      → opus/deep [dim]($15/MTok)[/dim]   Security audit, architettura complessa

[bold cyan]Risoluzione modello (priorità):[/bold cyan]
  1. [bold]model_overrides[/bold]  → override esplicito per agente [dim](config)[/dim]
  2. [bold]model_tiers[/bold]      → tier assegnato per agente   [dim](config)[/dim]
  3. [bold]get_model_tier()[/bold]  → tier di default della classe [dim](codice)[/dim]
  4. [bold]default_model[/bold]    → fallback globale             [dim](config)[/dim]

[bold cyan]Config (.ase/config.toml):[/bold cyan]
  [dim][model_tiers]
  fast = "anthropic/claude-haiku-3-20250414"
  balanced = "anthropic/claude-sonnet-4-20250514"
  deep = "anthropic/claude-sonnet-4-20250514"

  [agents.model_tiers]
  triage = "fast"
  backend = "balanced"
  security = "deep"
  docs = "fast"

  [agents.model_overrides]
  backend = "anthropic/claude-opus-4-20250514"  # forza un modello specifico[/dim]""",
    ),
    "mcp": (
        "MCP Servers",
        """\
ASE usa due [bold]MCP (Model Context Protocol)[/bold] servers locali,
avviati come sotto-processi per ogni progetto.

[bold cyan]Operativo[/bold cyan] → stato runtime, DB, side-effects
  Tools: get_ticket, update_ticket, assign_agent, register_artifact,
         log_decision, publish_event, list_tickets, get_artifacts,
         update_assignment

[bold cyan]Statico[/bold cyan] → analisi codebase read-only
  Tools: get_full_context, get_tech_stack, get_conventions,
         get_api_contracts, get_architecture, get_blueprints,
         get_environments

[bold cyan]Naming convention:[/bold cyan]
  [yellow]operativo__get_ticket[/yellow]   → server "operativo", tool "get_ticket"
  [yellow]statico__get_tech_stack[/yellow] → server "statico", tool "get_tech_stack"

[bold cyan]Transport:[/bold cyan]  stdio (sub-process locale, nessun network)
[bold cyan]Bridge:[/bold cyan]     MCPBridge gestisce connessione, discovery, e routing

[bold cyan]Config (.ase/config.toml):[/bold cyan]
  [dim][mcp]
  transport = "stdio"
  operativo_command = "python -m ase.mcp.operativo.server"
  statico_command = "python -m ase.mcp.statico.server"[/dim]""",
    ),
    "audit": (
        "Audit & Logging",
        """\
Ogni azione degli agenti è tracciata con [bold]14 tipi di evento[/bold]:

[bold cyan]Agent lifecycle:[/bold cyan]
  agent_started, agent_completed, agent_failed, agent_timeout
  agent_spawned, agent_cancelled

[bold cyan]LLM:[/bold cyan]
  llm_request, llm_response

[bold cyan]Tool calls:[/bold cyan]
  tool_call_start, tool_call_success, tool_call_error

[bold cyan]Decisions & cost:[/bold cyan]
  decision, cost_warning, cost_limit_hit

[bold cyan]Correlazione:[/bold cyan]
  Ogni run ha un [yellow]trace_id[/yellow] (UUID) che lega tutti gli eventi.
  Ogni azione ha uno [yellow]span_id[/yellow] incrementale (s001, s002, ...).

[bold cyan]Dual output:[/bold cyan]
  1. Python logging → JSON lines (.jsonl) con RotatingFileHandler
  2. Operativo MCP → persistenza nel DB di progetto

[bold cyan]Storage:[/bold cyan]
  Ring buffer: [yellow]10 MB × 6 file = ~60 MB max[/yellow]
  Retention: [yellow]90 giorni[/yellow] (configurabile)

[bold cyan]CLI:[/bold cyan]
  [yellow]ase audit[/yellow]                     → ultimi 50 eventi
  [yellow]ase audit --trace abc123[/yellow]       → filtra per trace
  [yellow]ase audit --agent backend[/yellow]      → filtra per agente
  [yellow]ase audit --stats[/yellow]              → aggregati (costi, token, errori)
  [yellow]ase audit --follow[/yellow]             → tail -f live
  [yellow]ase audit --cleanup[/yellow]            → pulisci log vecchi""",
    ),
    "config": (
        "Configuration",
        """\
ASE si configura tramite [bold].ase/config.toml[/bold] nella directory del progetto.

[bold cyan]Sezioni principali:[/bold cyan]
  [yellow][project][/yellow]          → name, description
  [yellow][llm][/yellow]              → default_model, max_tokens, temperature, cost limits
  [yellow][llm.retry][/yellow]        → max_retries, base_delay, max_delay
  [yellow][mcp][/yellow]              → transport, operativo_command, statico_command
  [yellow][timeouts][/yellow]         → agent timeouts, escalation, human reminders
  [yellow][fault_tolerance][/yellow]  → max_self_retries, max_peer_escalations, backoff
  [yellow][agents][/yellow]           → enabled list, model_overrides, model_tiers
  [yellow][logging][/yellow]          → level, audit_log_enabled, rotation, retention
  [yellow][hil][/yellow]              → review_method (pr/manual/auto-approve), notifications
  [yellow][model_tiers][/yellow]      → fast/balanced/deep → concrete model IDs
  [yellow][skills][/yellow]           → skills_dir, preloads per agent
  [yellow][memory][/yellow]           → scope (project/local/disabled), dirs

[bold cyan]Esempio minimo:[/bold cyan]
  [dim][project]
  name = "my-api"
  description = "REST API per gestione utenti"

  [llm]
  default_model = "anthropic/claude-sonnet-4-20250514"
  cost_limit_per_ticket_usd = 5.00

  [agents]
  enabled = ["analyzer", "triage", "backend", "testing"]

  [skills.preloads]
  backend = ["api-design"][/dim]""",
    ),
    "flow": (
        "Request Flow (Ticket Lifecycle)",
        """\
[bold cyan]1. Submit[/bold cyan]
  [yellow]ase submit "Aggiungi endpoint PUT /users/:id"[/yellow]
  → Normalizer pulisce il testo
  → TicketFactory crea ticket nel DB (status: open)

[bold cyan]2. Triage[/bold cyan]  [dim](fast model)[/dim]
  → TriageAgent analizza il ticket
  → Consulta contesto statico (architettura, convenzioni, API)
  → Produce un piano: quali agenti, in che ordine, con quali dependency
  → Ticket status: triaged

[bold cyan]3. Orchestration[/bold cyan]
  → Scheduler legge il piano
  → Spawna agenti nell'ordine (rispettando dipendenze)
  → Ogni agente gira come asyncio.Task con timeout

[bold cyan]4. Execution[/bold cyan]  [dim](balanced/deep model)[/dim]
  → Agente riceve: system prompt + skills + memory + ticket + contesto
  → Think-loop: LLM → tool calls (MCP) → risultati → LLM → ...
  → Registra artifacts (file creati/modificati)
  → Pubblica eventi (api_contract_defined, schema_changed, ...)

[bold cyan]5. Review[/bold cyan]
  → HIL (Human-in-the-Loop) attivato
  → Staging environment per validazione
  → PR review / manual approval / auto-approve (configurabile)

[bold cyan]6. Completion[/bold cyan]
  → Ticket status: completed
  → Audit trail completo disponibile
  → Memory aggiornata con osservazioni""",
    ),
}

_TOPIC_NAMES = sorted(_GUIDE_SECTIONS.keys())


@app.command()
def guide(
    topic: Optional[str] = typer.Option(
        None,
        "--topic",
        "-t",
        help=f"Specific topic: {', '.join(_TOPIC_NAMES)}",
    ),
) -> None:
    """Interactive guide to the ASE framework.

    Without --topic shows the full overview.
    With --topic <name> shows details about a specific component.

    Topics: overview, agents, skills, memory, tiers, mcp, audit, config, flow
    """
    if topic is None:
        # Show overview
        title, body = _GUIDE_SECTIONS["overview"]
        console.print(Panel(body, title=f"[bold]{title}[/bold]", border_style="cyan", padding=(1, 2)))
        return

    topic = topic.lower().strip()
    if topic not in _GUIDE_SECTIONS:
        console.print(f"[red]Unknown topic '{topic}'.[/red]")
        console.print(f"Available: [yellow]{', '.join(_TOPIC_NAMES)}[/yellow]")
        raise typer.Exit(1)

    title, body = _GUIDE_SECTIONS[topic]
    console.print(Panel(body, title=f"[bold]{title}[/bold]", border_style="cyan", padding=(1, 2)))


# ---------------------------------------------------------------------------
# onboard
# ---------------------------------------------------------------------------


@app.command()
def onboard(
    auto_only: bool = typer.Option(
        False,
        "--auto-only",
        help="Only auto-discover from files, skip interactive questions.",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Discover and populate project context (interactive onboarding).

    Checks what's missing in the Statico knowledge base and:
    1. Auto-discovers context from project files (README, package.json, etc.).
    2. Asks you focused questions for anything it couldn't infer.
    3. Persists all answers into MCP Statico.

    Run this after 'ase init' or when context is incomplete.
    """
    _setup_logging(verbose)

    project_path = _require_init()

    console.print(f"\n[bold blue]Onboarding[/]")
    console.print(f"[dim]Mode: {'auto-discover only' if auto_only else 'interactive'}[/dim]\n")

    _run(_onboard_project(project_path, interactive=not auto_only))


async def _onboard_project(project_path: Path, interactive: bool) -> None:
    """Run discovery agent for context onboarding."""
    from ase.runtime import ASERuntime

    runtime = ASERuntime(project_path)

    console.print("[dim]Booting runtime...[/dim]")
    await runtime.start()

    try:
        # Show initial completeness
        report = runtime.completeness
        if report:
            _print_completeness(report)

            if report.score == 1.0:
                console.print("\n[bold green]Context is already 100% complete![/bold green]")
                return

        # Run onboarding
        console.print("\n[bold]Starting context discovery...[/bold]\n")
        final_report = await runtime.onboard(interactive=interactive)
        _print_completeness(final_report)

        if final_report.is_ready:
            console.print(
                "\n[bold green]Onboarding complete — all critical context is populated.[/bold green]"
            )
        else:
            console.print(
                "\n[yellow]Some critical gaps remain. "
                "Run 'ase onboard' again to continue.[/yellow]"
            )

    finally:
        await runtime.stop()


def _print_completeness(report: "CompletenessReport") -> None:
    """Pretty-print a completeness report."""
    from ase.onboarding.completeness import Criticality

    # Score bar
    bar_width = 30
    filled = int(report.score * bar_width)
    bar = "█" * filled + "░" * (bar_width - filled)
    color = "green" if report.score >= 0.7 else ("yellow" if report.score >= 0.4 else "red")
    console.print(
        f"\n[{color}]Context completeness: {bar} {report.score:.0%}[/{color}]"
        f"  ({report.populated_sections}/{report.total_sections} sections)"
    )

    if report.populated:
        console.print(f"[green]  Populated:[/green] {', '.join(report.populated)}")

    if report.gaps:
        table = Table(title="Missing Context", show_lines=False)
        table.add_column("Section", style="bold")
        table.add_column("Criticality")
        table.add_column("Auto-discover?", justify="center")
        table.add_column("Description", max_width=45)

        crit_styles = {
            Criticality.CRITICAL: "[bold red]CRITICAL[/bold red]",
            Criticality.IMPORTANT: "[yellow]important[/yellow]",
            Criticality.NICE_TO_HAVE: "[dim]nice-to-have[/dim]",
        }

        for gap in report.gaps:
            table.add_row(
                gap.section,
                crit_styles.get(gap.criticality, str(gap.criticality)),
                "✓" if gap.auto_discoverable else "—",
                gap.description,
            )

        console.print(table)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    app()
