"""
SQLite connection factory for the ASE framework.

Provides a pre-configured connection with:
- WAL journal mode     (concurrent readers + single writer)
- busy_timeout = 5000  (wait up to 5 s when the DB is locked)
- synchronous = NORMAL (good durability / performance trade-off with WAL)
- foreign_keys = ON    (enforce referential integrity)
- cache_size = -64000  (64 MB page cache)
- Row factory          (rows accessible by column name)
"""

from __future__ import annotations

import sqlite3
from pathlib import Path


def create_connection(db_path: str | Path) -> sqlite3.Connection:
    """Create and return a fully configured SQLite connection.

    Parameters
    ----------
    db_path:
        Filesystem path to the SQLite database file.
        Parent directories are created automatically if they do not exist.

    Returns
    -------
    sqlite3.Connection
        A connection with WAL mode, busy timeout, foreign keys,
        synchronous = NORMAL, cache_size = -64000, and
        ``sqlite3.Row`` as the row factory.
    """
    db_path = Path(db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row

    # Enable WAL mode for concurrent read access
    conn.execute("PRAGMA journal_mode = WAL;")

    # Wait up to 5 000 ms when the database is locked by another connection
    conn.execute("PRAGMA busy_timeout = 5000;")

    # NORMAL synchronous is safe with WAL and faster than FULL
    conn.execute("PRAGMA synchronous = NORMAL;")

    # Enforce foreign-key constraints
    conn.execute("PRAGMA foreign_keys = ON;")

    # 64 MB page cache (negative value = kibibytes)
    conn.execute("PRAGMA cache_size = -64000;")

    return conn
