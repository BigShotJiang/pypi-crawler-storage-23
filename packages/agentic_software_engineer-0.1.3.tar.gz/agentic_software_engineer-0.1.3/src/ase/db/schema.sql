-- =============================================================================
-- ASE Framework — Complete SQL Schema
-- Covers both MCP Operativo (runtime) and MCP Statico (project knowledge) tables.
-- =============================================================================

-- ---------------------------------------------------------------------------
-- Schema version tracking
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS schema_version (
    version     INTEGER     NOT NULL,
    applied_at  TEXT        NOT NULL DEFAULT (datetime('now'))
);

-- =============================================================================
-- MCP OPERATIVO — Runtime / Orchestration Tables
-- =============================================================================

-- ---------------------------------------------------------------------------
-- tickets
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tickets (
    id                  TEXT        PRIMARY KEY,
    source              TEXT        NOT NULL,
    raw_content         TEXT        NOT NULL,
    intent              TEXT,
    project_id          TEXT,
    priority            TEXT        NOT NULL DEFAULT 'medium',
    complexity          TEXT,
    status              TEXT        NOT NULL DEFAULT 'open'
                        CHECK (status IN (
                            'open',
                            'triaged',
                            'in_progress',
                            'review',
                            'staging',
                            'done',
                            'failed',
                            'blocked',
                            'cancelled'
                        )),
    parent_ticket_id    TEXT        REFERENCES tickets(id),
    retry_count         INTEGER     NOT NULL DEFAULT 0,
    escalation_level    INTEGER     NOT NULL DEFAULT 0,
    execution_plan      TEXT,
    created_at          TEXT        NOT NULL DEFAULT (datetime('now')),
    updated_at          TEXT        NOT NULL DEFAULT (datetime('now')),
    triaged_at          TEXT,
    started_at          TEXT,
    completed_at        TEXT
);

-- ---------------------------------------------------------------------------
-- agent_assignments
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS agent_assignments (
    id              TEXT        PRIMARY KEY,
    ticket_id       TEXT        NOT NULL REFERENCES tickets(id),
    agent_type      TEXT        NOT NULL,
    status          TEXT        NOT NULL DEFAULT 'pending'
                    CHECK (status IN (
                        'pending',
                        'running',
                        'success',
                        'failed',
                        'retrying',
                        'escalated',
                        'cancelled'
                    )),
    depends_on      TEXT,
    error_detail    TEXT,
    attempts        INTEGER     NOT NULL DEFAULT 0,
    created_at      TEXT        NOT NULL DEFAULT (datetime('now')),
    updated_at      TEXT        NOT NULL DEFAULT (datetime('now')),
    started_at      TEXT,
    completed_at    TEXT
);

-- ---------------------------------------------------------------------------
-- artifacts
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS artifacts (
    id              TEXT        PRIMARY KEY,
    ticket_id       TEXT        NOT NULL REFERENCES tickets(id),
    assignment_id   TEXT        REFERENCES agent_assignments(id),
    artifact_type   TEXT        NOT NULL,
    file_path       TEXT,
    content         TEXT,
    content_hash    TEXT,
    metadata        TEXT,
    created_at      TEXT        NOT NULL DEFAULT (datetime('now'))
);

-- ---------------------------------------------------------------------------
-- events
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS events (
    id              INTEGER     PRIMARY KEY AUTOINCREMENT,
    event_type      TEXT        NOT NULL,
    source_agent    TEXT,
    target_agents   TEXT,
    ticket_id       TEXT        REFERENCES tickets(id),
    payload         TEXT,
    consumed_by     TEXT,
    created_at      TEXT        NOT NULL DEFAULT (datetime('now'))
);

-- ---------------------------------------------------------------------------
-- decision_log
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS decision_log (
    id              TEXT        PRIMARY KEY,
    ticket_id       TEXT        REFERENCES tickets(id),
    assignment_id   TEXT        REFERENCES agent_assignments(id),
    agent_type      TEXT        NOT NULL,
    action          TEXT        NOT NULL,
    reasoning       TEXT,
    model_used      TEXT,
    prompt_tokens   INTEGER,
    completion_tokens INTEGER,
    cost_usd        REAL,
    duration_ms     INTEGER,
    retry_of        TEXT        REFERENCES decision_log(id),
    created_at      TEXT        NOT NULL DEFAULT (datetime('now'))
);

-- ---------------------------------------------------------------------------
-- human_feedback
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS human_feedback (
    id              TEXT        PRIMARY KEY,
    ticket_id       TEXT        NOT NULL REFERENCES tickets(id),
    assignment_id   TEXT        REFERENCES agent_assignments(id),
    feedback_type   TEXT        NOT NULL,
    content         TEXT        NOT NULL,
    sentiment       TEXT,
    reviewer        TEXT,
    child_ticket_id TEXT        REFERENCES tickets(id),
    created_at      TEXT        NOT NULL DEFAULT (datetime('now'))
);

-- ---------------------------------------------------------------------------
-- cost_log
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cost_log (
    id              TEXT        PRIMARY KEY,
    ticket_id       TEXT        REFERENCES tickets(id),
    assignment_id   TEXT        REFERENCES agent_assignments(id),
    model           TEXT        NOT NULL,
    prompt_tokens   INTEGER     NOT NULL DEFAULT 0,
    completion_tokens INTEGER   NOT NULL DEFAULT 0,
    cost_usd        REAL        NOT NULL DEFAULT 0.0,
    created_at      TEXT        NOT NULL DEFAULT (datetime('now'))
);

-- =============================================================================
-- MCP STATICO — Project Knowledge Base Tables
-- =============================================================================

-- ---------------------------------------------------------------------------
-- company_profile (singleton — exactly one row, id must be 1)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS company_profile (
    id              INTEGER     PRIMARY KEY CHECK (id = 1),
    name            TEXT        NOT NULL,
    purpose         TEXT        NOT NULL DEFAULT '',
    domain          TEXT        NOT NULL DEFAULT ''
);

-- ---------------------------------------------------------------------------
-- team_member
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS team_member (
    id                      TEXT    PRIMARY KEY,
    name                    TEXT    NOT NULL,
    role                    TEXT    NOT NULL,
    responsibilities        TEXT    NOT NULL DEFAULT '[]',
    reports_to              TEXT,
    communication_channels  TEXT    NOT NULL DEFAULT '{}',
    department              TEXT    NOT NULL DEFAULT '',
    title                   TEXT    NOT NULL DEFAULT '',
    email                   TEXT    NOT NULL DEFAULT '',
    location                TEXT    NOT NULL DEFAULT '',
    skills                  TEXT    NOT NULL DEFAULT '[]',
    availability            TEXT    NOT NULL DEFAULT '',
    notes                   TEXT    NOT NULL DEFAULT ''
);

-- ---------------------------------------------------------------------------
-- tech_stack (singleton)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tech_stack (
    id              INTEGER     PRIMARY KEY CHECK (id = 1),
    languages       TEXT        NOT NULL DEFAULT '[]',
    frameworks      TEXT        NOT NULL DEFAULT '[]',
    databases       TEXT        NOT NULL DEFAULT '[]',
    cloud_provider  TEXT        NOT NULL DEFAULT '',
    ci_cd           TEXT        NOT NULL DEFAULT '',
    monitoring      TEXT        NOT NULL DEFAULT '',
    additional      TEXT        NOT NULL DEFAULT '{}'
);

-- ---------------------------------------------------------------------------
-- architecture (singleton)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS architecture (
    id              INTEGER     PRIMARY KEY CHECK (id = 1),
    type            TEXT        NOT NULL DEFAULT '',
    description     TEXT        NOT NULL DEFAULT '',
    data_flow       TEXT        NOT NULL DEFAULT '',
    diagrams        TEXT        NOT NULL DEFAULT '[]',
    decisions       TEXT        NOT NULL DEFAULT '[]',
    components      TEXT        NOT NULL DEFAULT '[]',
    constraints     TEXT        NOT NULL DEFAULT '[]',
    principles      TEXT        NOT NULL DEFAULT '[]'
);

-- ---------------------------------------------------------------------------
-- service
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS service (
    id              TEXT        PRIMARY KEY,
    name            TEXT        NOT NULL,
    description     TEXT        NOT NULL DEFAULT '',
    repo_url        TEXT        NOT NULL DEFAULT '',
    tech            TEXT        NOT NULL DEFAULT '[]',
    owner           TEXT,
    FOREIGN KEY (owner) REFERENCES team_member(id)
);

-- ---------------------------------------------------------------------------
-- api_contract
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS api_contract (
    id              TEXT        PRIMARY KEY,
    service_id      TEXT        NOT NULL,
    endpoint        TEXT        NOT NULL,
    method          TEXT        NOT NULL DEFAULT 'GET',
    request_schema  TEXT,
    response_schema TEXT,
    description     TEXT        NOT NULL DEFAULT '',
    version         TEXT        NOT NULL DEFAULT 'v1',
    FOREIGN KEY (service_id) REFERENCES service(id)
);

-- ---------------------------------------------------------------------------
-- conventions (singleton)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS conventions (
    id                  INTEGER     PRIMARY KEY CHECK (id = 1),
    branching_strategy  TEXT        NOT NULL DEFAULT '',
    naming_conventions  TEXT        NOT NULL DEFAULT '{}',
    code_style          TEXT        NOT NULL DEFAULT '',
    testing_strategy    TEXT        NOT NULL DEFAULT '',
    pr_review_process   TEXT        NOT NULL DEFAULT '',
    deploy_pipeline     TEXT        NOT NULL DEFAULT '',
    additional          TEXT        NOT NULL DEFAULT '{}'
);

-- ---------------------------------------------------------------------------
-- environment
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS environment (
    name              TEXT        PRIMARY KEY,
    config            TEXT        NOT NULL DEFAULT '{}',
    url               TEXT        NOT NULL DEFAULT '',
    description       TEXT        NOT NULL DEFAULT '',
    cloud_region      TEXT        NOT NULL DEFAULT '',
    infra_notes       TEXT        NOT NULL DEFAULT '',
    monitoring_url    TEXT        NOT NULL DEFAULT '',
    access_level      TEXT        NOT NULL DEFAULT '',
    services_deployed TEXT        NOT NULL DEFAULT '[]'
);

-- ---------------------------------------------------------------------------
-- blueprint
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS blueprint (
    id              TEXT        PRIMARY KEY,
    name            TEXT        NOT NULL,
    description     TEXT        NOT NULL DEFAULT '',
    template        TEXT        NOT NULL DEFAULT '{}',
    agent_sequence  TEXT        NOT NULL DEFAULT '[]'
);

-- ---------------------------------------------------------------------------
-- access_registry
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS access_registry (
    id              TEXT        PRIMARY KEY,
    system_name     TEXT        NOT NULL,
    system_type     TEXT        NOT NULL DEFAULT '',
    url             TEXT        NOT NULL DEFAULT '',
    auth_method     TEXT        NOT NULL DEFAULT '',
    auth_reference  TEXT        NOT NULL DEFAULT '',
    owner           TEXT,
    notes           TEXT        NOT NULL DEFAULT '',
    tags            TEXT        NOT NULL DEFAULT '[]',
    FOREIGN KEY (owner) REFERENCES team_member(id)
);

-- ---------------------------------------------------------------------------
-- domain_model (singleton)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS domain_model (
    id                    INTEGER     PRIMARY KEY CHECK (id = 1),
    description           TEXT        NOT NULL DEFAULT '',
    ubiquitous_language   TEXT        NOT NULL DEFAULT '{}',
    entities              TEXT        NOT NULL DEFAULT '[]',
    business_rules        TEXT        NOT NULL DEFAULT '[]',
    bounded_contexts      TEXT        NOT NULL DEFAULT '[]'
);

-- ---------------------------------------------------------------------------
-- external_dependency
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS external_dependency (
    id              TEXT        PRIMARY KEY,
    name            TEXT        NOT NULL,
    category        TEXT        NOT NULL DEFAULT '',
    description     TEXT        NOT NULL DEFAULT '',
    api_url         TEXT        NOT NULL DEFAULT '',
    docs_url        TEXT        NOT NULL DEFAULT '',
    auth_reference  TEXT        NOT NULL DEFAULT '',
    rate_limits     TEXT        NOT NULL DEFAULT '{}',
    sla             TEXT        NOT NULL DEFAULT '',
    contract_notes  TEXT        NOT NULL DEFAULT '',
    owner           TEXT,
    tags            TEXT        NOT NULL DEFAULT '[]',
    FOREIGN KEY (owner) REFERENCES team_member(id)
);

-- ---------------------------------------------------------------------------
-- data_schema
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS data_schema (
    id                    TEXT        PRIMARY KEY,
    name                  TEXT        NOT NULL,
    database_type         TEXT        NOT NULL DEFAULT '',
    description           TEXT        NOT NULL DEFAULT '',
    service_id            TEXT,
    connection_reference  TEXT        NOT NULL DEFAULT '',
    tables_def            TEXT        NOT NULL DEFAULT '[]',
    migrations_tool       TEXT        NOT NULL DEFAULT '',
    notes                 TEXT        NOT NULL DEFAULT '',
    FOREIGN KEY (service_id) REFERENCES service(id)
);

-- ---------------------------------------------------------------------------
-- knowledge_entry
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS knowledge_entry (
    id                TEXT        PRIMARY KEY,
    title             TEXT        NOT NULL,
    category          TEXT        NOT NULL DEFAULT '',
    content           TEXT        NOT NULL DEFAULT '',
    related_services  TEXT        NOT NULL DEFAULT '[]',
    author            TEXT,
    tags              TEXT        NOT NULL DEFAULT '[]',
    severity          TEXT        NOT NULL DEFAULT '',
    created_date      TEXT        NOT NULL DEFAULT '',
    FOREIGN KEY (author) REFERENCES team_member(id)
);

-- =============================================================================
-- INDEXES
-- =============================================================================

-- tickets
CREATE INDEX IF NOT EXISTS idx_tickets_status          ON tickets(status);
CREATE INDEX IF NOT EXISTS idx_tickets_priority        ON tickets(priority);
CREATE INDEX IF NOT EXISTS idx_tickets_project_id      ON tickets(project_id);
CREATE INDEX IF NOT EXISTS idx_tickets_parent_ticket_id ON tickets(parent_ticket_id);
CREATE INDEX IF NOT EXISTS idx_tickets_created_at      ON tickets(created_at);

-- agent_assignments
CREATE INDEX IF NOT EXISTS idx_assignments_ticket_id   ON agent_assignments(ticket_id);
CREATE INDEX IF NOT EXISTS idx_assignments_agent_type  ON agent_assignments(agent_type);
CREATE INDEX IF NOT EXISTS idx_assignments_status      ON agent_assignments(status);

-- artifacts
CREATE INDEX IF NOT EXISTS idx_artifacts_ticket_id     ON artifacts(ticket_id);
CREATE INDEX IF NOT EXISTS idx_artifacts_assignment_id ON artifacts(assignment_id);
CREATE INDEX IF NOT EXISTS idx_artifacts_type          ON artifacts(artifact_type);

-- events
CREATE INDEX IF NOT EXISTS idx_events_ticket_id        ON events(ticket_id);
CREATE INDEX IF NOT EXISTS idx_events_event_type       ON events(event_type);
CREATE INDEX IF NOT EXISTS idx_events_created_at       ON events(created_at);

-- decision_log
CREATE INDEX IF NOT EXISTS idx_decisions_ticket_id     ON decision_log(ticket_id);
CREATE INDEX IF NOT EXISTS idx_decisions_assignment_id ON decision_log(assignment_id);
CREATE INDEX IF NOT EXISTS idx_decisions_agent_type    ON decision_log(agent_type);

-- human_feedback
CREATE INDEX IF NOT EXISTS idx_feedback_ticket_id      ON human_feedback(ticket_id);

-- cost_log
CREATE INDEX IF NOT EXISTS idx_cost_ticket_id          ON cost_log(ticket_id);
CREATE INDEX IF NOT EXISTS idx_cost_assignment_id      ON cost_log(assignment_id);
CREATE INDEX IF NOT EXISTS idx_cost_created_at         ON cost_log(created_at);

-- service
CREATE INDEX IF NOT EXISTS idx_service_owner            ON service(owner);

-- api_contract
CREATE INDEX IF NOT EXISTS idx_api_contract_service_id  ON api_contract(service_id);

-- access_registry
CREATE INDEX IF NOT EXISTS idx_access_registry_owner    ON access_registry(owner);

-- external_dependency
CREATE INDEX IF NOT EXISTS idx_ext_dep_owner            ON external_dependency(owner);

-- data_schema
CREATE INDEX IF NOT EXISTS idx_data_schema_service_id   ON data_schema(service_id);

-- knowledge_entry
CREATE INDEX IF NOT EXISTS idx_knowledge_entry_author   ON knowledge_entry(author);

-- Insert initial schema version
INSERT INTO schema_version (version) VALUES (1);
