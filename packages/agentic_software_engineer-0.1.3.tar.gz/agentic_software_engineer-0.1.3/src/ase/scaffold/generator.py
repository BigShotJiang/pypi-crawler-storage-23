"""Project scaffolding: create .ase/ directory, DB, config, and gitignore entry."""

from __future__ import annotations

import logging
import sqlite3
from pathlib import Path

from ase.scaffold.detector import ScaffoldStatus, detect

logger = logging.getLogger(__name__)

_TEMPLATES_DIR = Path(__file__).parent / "templates"


def scaffold_project(project_path: Path | str, project_name: str | None = None) -> ScaffoldStatus:
    """Bootstrap ASE inside an existing project directory.

    Creates (idempotently):
    - ``<project_path>/.ase/``              (hidden data directory)
    - ``<project_path>/.ase/ase.db``        (SQLite database with schema)
    - ``<project_path>/.ase/config.toml``   (configuration from template)
    - Appends ``.ase/`` to ``<project_path>/.gitignore``

    Parameters
    ----------
    project_path:
        Root of the client project (usually CWD).
    project_name:
        Human-readable name.  Defaults to the directory name.

    Returns
    -------
    ScaffoldStatus
        Result of ``detect()`` after scaffolding is complete.
    """
    project_path = Path(project_path).resolve()
    if project_name is None:
        project_name = project_path.name

    ase_dir = project_path / ".ase"

    # ---- 1. Create .ase/ directory ----------------------------------------
    ase_dir.mkdir(parents=True, exist_ok=True)
    logger.info("Ensured directory: %s", ase_dir)

    # ---- 2. Create SQLite DB with schema ----------------------------------
    db_path = ase_dir / "ase.db"
    _init_database(db_path)
    logger.info("Database ready: %s", db_path)

    # ---- 3. Write config.toml from template -------------------------------
    config_dest = ase_dir / "config.toml"
    if not config_dest.exists():
        _write_config(config_dest, project_name)
        logger.info("Config written: %s", config_dest)
    else:
        logger.info("Config already exists, skipping: %s", config_dest)

    # ---- 4. Add .ase/ to .gitignore ---------------------------------------
    _ensure_gitignore(project_path)

    # ---- 5. Seed default static data --------------------------------------
    _seed_defaults(db_path, project_name)
    logger.info("Default data seeded.")

    return detect(project_path)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _init_database(db_path: Path) -> None:
    """Create the SQLite DB and apply the schema."""
    schema_file = _TEMPLATES_DIR / "schema.sql"
    if not schema_file.exists():
        raise FileNotFoundError(f"Schema template not found: {schema_file}")

    schema_sql = schema_file.read_text(encoding="utf-8")
    conn = sqlite3.connect(str(db_path))
    try:
        conn.executescript(schema_sql)
        conn.commit()
    finally:
        conn.close()


def _write_config(dest: Path, name: str) -> None:
    """Render the config.toml template with the project name."""
    template_file = _TEMPLATES_DIR / "context.toml"
    if not template_file.exists():
        raise FileNotFoundError(f"Config template not found: {template_file}")

    content = template_file.read_text(encoding="utf-8")
    safe_name = name.replace('\\', '\\\\').replace('"', '\\"').replace('\n', ' ')
    content = content.replace("{{PROJECT_NAME}}", safe_name)
    dest.write_text(content, encoding="utf-8")


def _ensure_gitignore(project_path: Path) -> None:
    """Ensure .ase/ is listed in the project's .gitignore."""
    gitignore = project_path / ".gitignore"

    if gitignore.exists():
        existing = gitignore.read_text(encoding="utf-8")
        # Check if .ase is already ignored (various formats)
        for line in existing.splitlines():
            stripped = line.strip()
            if stripped in (".ase", ".ase/", "/.ase", "/.ase/"):
                logger.info(".ase/ already in .gitignore")
                return
        # Append
        separator = "" if existing.endswith("\n") else "\n"
        gitignore.write_text(
            existing + separator + "\n# ASE framework data (auto-added)\n.ase/\n",
            encoding="utf-8",
        )
        logger.info("Appended .ase/ to .gitignore")
    else:
        gitignore.write_text(
            "# ASE framework data (auto-added)\n.ase/\n",
            encoding="utf-8",
        )
        logger.info("Created .gitignore with .ase/")


def _seed_defaults(db_path: Path, project_name: str) -> None:
    """Insert default seed data into the database (idempotent)."""
    conn = sqlite3.connect(str(db_path))
    try:
        cur = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='projects'"
        )
        if cur.fetchone():
            existing = conn.execute(
                "SELECT 1 FROM projects WHERE name = ?", (project_name,)
            ).fetchone()
            if not existing:
                conn.execute(
                    "INSERT INTO projects (name, status) VALUES (?, ?)",
                    (project_name, "active"),
                )
                conn.commit()
                logger.info("Seeded project row: %s", project_name)
    finally:
        conn.close()
