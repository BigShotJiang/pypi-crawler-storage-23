"""Detect the scaffold status of an ASE project directory."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ScaffoldStatus:
    """Snapshot of what scaffold artefacts exist for a project.

    Attributes
    ----------
    db_exists:
        ``True`` if the SQLite database file is present.
    config_exists:
        ``True`` if ``.ase/config.toml`` is present.
    is_initialized:
        ``True`` when *both* db and config exist.
    needs_scaffold:
        ``True`` when one or more required artefacts are missing.
    """

    db_exists: bool
    config_exists: bool
    is_initialized: bool
    needs_scaffold: bool


def detect(project_path: Path) -> ScaffoldStatus:
    """Inspect *project_path* and report which scaffold artefacts exist.

    Parameters
    ----------
    project_path:
        Root directory of the project to inspect.

    Returns
    -------
    ScaffoldStatus
    """
    project_path = Path(project_path).resolve()

    db_exists = (project_path / ".ase" / "ase.db").exists()
    config_exists = (project_path / ".ase" / "config.toml").exists()
    is_initialized = db_exists and config_exists
    needs_scaffold = not is_initialized

    return ScaffoldStatus(
        db_exists=db_exists,
        config_exists=config_exists,
        is_initialized=is_initialized,
        needs_scaffold=needs_scaffold,
    )
