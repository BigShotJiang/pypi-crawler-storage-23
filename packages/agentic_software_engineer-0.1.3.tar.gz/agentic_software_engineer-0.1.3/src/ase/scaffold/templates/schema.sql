-- ASE Scaffold Schema
-- This is the canonical schema applied when a new project is scaffolded.
-- It mirrors the tables that MCP Operativo manages at runtime.

-- ============================================================
-- Projects
-- ============================================================
CREATE TABLE IF NOT EXISTS projects (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT    NOT NULL UNIQUE,
    description TEXT    DEFAULT '',
    status      TEXT    DEFAULT 'active',
    created_at  TEXT    DEFAULT (datetime('now')),
    updated_at  TEXT    DEFAULT (datetime('now'))
);

-- ============================================================
-- Tickets
-- ============================================================
CREATE TABLE IF NOT EXISTS tickets (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id    INTEGER NOT NULL REFERENCES projects(id),
    parent_id     INTEGER REFERENCES tickets(id),
    title         TEXT    NOT NULL,
    description   TEXT    DEFAULT '',
    priority      TEXT    DEFAULT 'medium',
    status        TEXT    DEFAULT 'open',
    assigned_agent TEXT   DEFAULT NULL,
    created_at    TEXT    DEFAULT (datetime('now')),
    updated_at    TEXT    DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_tickets_project ON tickets(project_id);
CREATE INDEX IF NOT EXISTS idx_tickets_status  ON tickets(status);

-- ============================================================
-- Decision log (audit trail)
-- ============================================================
CREATE TABLE IF NOT EXISTS decision_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id   INTEGER REFERENCES tickets(id),
    agent_type  TEXT    NOT NULL,
    action      TEXT    NOT NULL,
    reasoning   TEXT    DEFAULT '',
    outcome     TEXT    DEFAULT '',
    metadata    TEXT    DEFAULT '{}',
    created_at  TEXT    DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_decision_log_ticket ON decision_log(ticket_id);

-- ============================================================
-- Events
-- ============================================================
CREATE TABLE IF NOT EXISTS events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type  TEXT    NOT NULL,
    payload     TEXT    DEFAULT '{}',
    created_at  TEXT    DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_events_type ON events(event_type);

-- ============================================================
-- Metrics
-- ============================================================
CREATE TABLE IF NOT EXISTS metrics (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id   INTEGER REFERENCES tickets(id),
    metric_name TEXT    NOT NULL,
    value       REAL    NOT NULL,
    unit        TEXT    DEFAULT '',
    recorded_at TEXT    DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_metrics_ticket ON metrics(ticket_id);
