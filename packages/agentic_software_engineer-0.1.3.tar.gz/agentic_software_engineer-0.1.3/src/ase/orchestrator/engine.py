"""
Orchestrator engine -- drives the execution of a ticket's plan.

The ``Orchestrator`` receives an execution plan (a list of steps with
dependency edges), resolves the dependency graph, spawns agents in parallel
once their dependencies are satisfied, and polls for completion.  On
failure it delegates to the ``FaultHandler`` for tiered escalation.

Lifecycle:
    1. ``execute_plan`` is called with a ticket_id and the plan dict.
    2. Steps are parsed; dependency edges are resolved by ``agent_type`` name.
    3. Ready steps (all deps met) are spawned concurrently.
    4. A 2-second poll loop checks step statuses via the MCP bridge.
    5. When every step reaches ``completed`` the ticket moves to ``review``.
    6. If a step fails and fault recovery is exhausted, the ticket is blocked.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from enum import Enum
from typing import Any

from ase.events.bus import EventBus
from ase.events.types import EventType

logger = logging.getLogger(__name__)


class StepStatus(str, Enum):
    """Execution status of a single plan step."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"


class PlanStep:
    """Internal representation of one step in the execution plan."""

    def __init__(
        self,
        agent_type: str,
        description: str,
        depends_on: list[str] | None = None,
        config: dict[str, Any] | None = None,
    ) -> None:
        self.agent_type = agent_type
        self.description = description
        self.depends_on: list[str] = depends_on or []
        self.config: dict[str, Any] = config or {}
        self.status: StepStatus = StepStatus.PENDING
        self.assignment_id: int | None = None
        self.result: dict[str, Any] | None = None
        self.started_at: datetime | None = None
        self.completed_at: datetime | None = None

    def __repr__(self) -> str:
        return f"<PlanStep agent={self.agent_type} status={self.status.value}>"


class Orchestrator:
    """Drives the execution of a ticket's plan through agent spawning.

    Parameters
    ----------
    config:
        ``ASEConfig`` instance (used for timeouts and fault-tolerance params).
    bridge:
        ``MCPBridge`` for calling Operativo MCP tools.
    lifecycle:
        ``AgentLifecycle`` manager for spawning / querying agent assignments.
    event_bus:
        ``EventBus`` for publishing workflow events.
    fault_handler:
        ``FaultHandler`` for tiered failure recovery.
    """

    def __init__(
        self,
        config: Any,
        bridge: Any,
        lifecycle: Any,
        event_bus: EventBus,
        fault_handler: Any,
    ) -> None:
        self._config = config
        self._bridge = bridge
        self._lifecycle = lifecycle
        self._event_bus = event_bus
        self._fault_handler = fault_handler

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def execute_plan(
        self,
        ticket_id: int,
        execution_plan: dict[str, Any],
    ) -> dict[str, Any]:
        """Execute an entire plan for *ticket_id*.

        Parameters
        ----------
        ticket_id:
            The ticket whose plan is being executed.
        execution_plan:
            A dict with a ``"steps"`` key containing a list of step dicts.
            Each step dict has at minimum ``agent_type``, ``description``,
            and optionally ``depends_on`` (list of agent_type names) and
            ``config``.

        Returns
        -------
        dict
            Summary of the execution: ``{"status": ..., "steps": [...]}``.
        """
        steps = self._parse_steps(execution_plan)
        if not steps:
            logger.warning("Empty execution plan for ticket %d", ticket_id)
            return {"status": "completed", "steps": []}

        logger.info(
            "Starting execution plan for ticket %d with %d step(s)",
            ticket_id,
            len(steps),
        )

        # Build a lookup from agent_type -> PlanStep for dependency resolution.
        step_map: dict[str, PlanStep] = {s.agent_type: s for s in steps}

        # Validate that all depends_on references point to known steps.
        self._validate_dependencies(steps, step_map)

        # Main execution loop
        poll_interval = 2.0
        while True:
            # 1. Determine which steps can be spawned (deps met, still pending).
            ready = self._get_ready_steps(steps, step_map)
            for step in ready:
                await self._spawn_step(ticket_id, step)

            # 2. Check running steps for completion / failure.
            await self._poll_running_steps(ticket_id, steps)

            # 3. Evaluate terminal conditions.
            all_completed = all(s.status == StepStatus.COMPLETED for s in steps)
            any_blocked = any(s.status == StepStatus.BLOCKED for s in steps)
            any_still_active = any(
                s.status in (StepStatus.PENDING, StepStatus.RUNNING) for s in steps
            )

            if all_completed:
                logger.info("All steps completed for ticket %d", ticket_id)
                await self._update_ticket_status(ticket_id, "review")
                return self._build_summary(steps, "completed")

            if any_blocked and not any_still_active:
                logger.warning(
                    "Ticket %d is blocked -- no active steps remain", ticket_id
                )
                await self._update_ticket_status(ticket_id, "blocked")
                return self._build_summary(steps, "blocked")

            # 4. Sleep before next poll cycle.
            await asyncio.sleep(poll_interval)

    # ------------------------------------------------------------------
    # Plan parsing
    # ------------------------------------------------------------------

    def _parse_steps(self, execution_plan: dict[str, Any]) -> list[PlanStep]:
        """Convert raw plan dict into a list of ``PlanStep`` objects."""
        raw_steps: list[dict[str, Any]] = execution_plan.get("steps", [])
        steps: list[PlanStep] = []
        for raw in raw_steps:
            step = PlanStep(
                agent_type=raw["agent_type"],
                description=raw.get("description", ""),
                depends_on=raw.get("depends_on", []),
                config=raw.get("config", {}),
            )
            steps.append(step)
        return steps

    @staticmethod
    def _validate_dependencies(
        steps: list[PlanStep], step_map: dict[str, PlanStep]
    ) -> None:
        """Raise if any ``depends_on`` reference is not a known step."""
        for step in steps:
            for dep in step.depends_on:
                if dep not in step_map:
                    raise ValueError(
                        f"Step '{step.agent_type}' depends on unknown "
                        f"agent_type '{dep}'"
                    )

    # ------------------------------------------------------------------
    # Dependency resolution & spawning
    # ------------------------------------------------------------------

    def _get_ready_steps(
        self,
        steps: list[PlanStep],
        step_map: dict[str, PlanStep],
    ) -> list[PlanStep]:
        """Return steps whose dependencies are all completed and that are
        still pending."""
        ready: list[PlanStep] = []
        for step in steps:
            if step.status != StepStatus.PENDING:
                continue
            deps_met = all(
                step_map[dep].status == StepStatus.COMPLETED
                for dep in step.depends_on
            )
            if deps_met:
                ready.append(step)
        return ready

    async def _spawn_step(self, ticket_id: int, step: PlanStep) -> None:
        """Spawn an agent for *step* via the lifecycle manager."""
        logger.info(
            "Spawning agent '%s' for ticket %d", step.agent_type, ticket_id
        )
        step.status = StepStatus.RUNNING
        step.started_at = datetime.now(timezone.utc)

        try:
            result = await self._lifecycle.spawn_agent(
                ticket_id=ticket_id,
                agent_type=step.agent_type,
                config=step.config,
            )
            step.assignment_id = result.get("assignment_id")

            # Publish AGENT_SPAWNED event
            await self._event_bus.publish(
                event_type=EventType.AGENT_SPAWNED,
                source_agent="orchestrator",
                ticket_id=ticket_id,
                payload={
                    "agent_type": step.agent_type,
                    "assignment_id": step.assignment_id,
                },
            )
        except Exception:
            logger.exception(
                "Failed to spawn agent '%s' for ticket %d",
                step.agent_type,
                ticket_id,
            )
            step.status = StepStatus.FAILED
            await self._handle_step_failure(ticket_id, step)

    # ------------------------------------------------------------------
    # Status polling
    # ------------------------------------------------------------------

    async def _poll_running_steps(
        self, ticket_id: int, steps: list[PlanStep]
    ) -> None:
        """Check the status of all currently running steps."""
        for step in steps:
            if step.status != StepStatus.RUNNING:
                continue
            if step.assignment_id is None:
                continue

            try:
                status_result = await self._bridge.execute_tool_call(
                    "operativo__get_assignment_status",
                    {"assignment_id": step.assignment_id},
                )
                remote_status = status_result.get("status", "running")

                if remote_status == "completed":
                    await self._on_step_complete(ticket_id, step, status_result)
                elif remote_status in ("failed", "error"):
                    step.status = StepStatus.FAILED
                    step.result = status_result
                    await self._handle_step_failure(ticket_id, step)

            except Exception:
                logger.exception(
                    "Error polling status for agent '%s' (assignment %s)",
                    step.agent_type,
                    step.assignment_id,
                )

    # ------------------------------------------------------------------
    # Completion / failure callbacks
    # ------------------------------------------------------------------

    async def _on_step_complete(
        self,
        ticket_id: int,
        step: PlanStep,
        result: dict[str, Any],
    ) -> None:
        """Handle successful completion of a plan step."""
        step.status = StepStatus.COMPLETED
        step.completed_at = datetime.now(timezone.utc)
        step.result = result

        logger.info(
            "Agent '%s' completed for ticket %d (assignment %s)",
            step.agent_type,
            ticket_id,
            step.assignment_id,
        )

        await self._event_bus.publish(
            event_type=EventType.AGENT_COMPLETED,
            source_agent=step.agent_type,
            ticket_id=ticket_id,
            payload={
                "agent_type": step.agent_type,
                "assignment_id": step.assignment_id,
                "result_summary": result.get("summary", ""),
            },
        )

    async def _handle_step_failure(
        self, ticket_id: int, step: PlanStep
    ) -> None:
        """Delegate failure recovery to the FaultHandler.

        If the fault handler successfully recovers (e.g. via retry or peer
        escalation) the step is moved back to RUNNING.  Otherwise it is
        marked BLOCKED.
        """
        logger.warning(
            "Agent '%s' failed for ticket %d -- invoking fault handler",
            step.agent_type,
            ticket_id,
        )

        await self._event_bus.publish(
            event_type=EventType.AGENT_FAILED,
            source_agent=step.agent_type,
            ticket_id=ticket_id,
            payload={
                "agent_type": step.agent_type,
                "assignment_id": step.assignment_id,
                "error": step.result.get("error", "unknown") if step.result else "spawn_failure",
            },
        )

        recovered = await self._fault_handler.handle_failure(
            ticket_id=ticket_id,
            agent_type=step.agent_type,
            assignment_id=step.assignment_id,
        )

        if recovered:
            # Fault handler re-spawned; reset step to running and update
            # assignment_id if the handler provides a new one.
            step.status = StepStatus.RUNNING
            step.started_at = datetime.now(timezone.utc)
            logger.info(
                "Fault handler recovered agent '%s' for ticket %d",
                step.agent_type,
                ticket_id,
            )
        else:
            step.status = StepStatus.BLOCKED
            logger.error(
                "Fault handler exhausted for agent '%s' on ticket %d",
                step.agent_type,
                ticket_id,
            )

    # ------------------------------------------------------------------
    # Ticket helpers
    # ------------------------------------------------------------------

    async def _update_ticket_status(self, ticket_id: int, status: str) -> None:
        """Update the ticket status via the MCP bridge."""
        try:
            await self._bridge.execute_tool_call(
                "operativo__update_ticket",
                {"ticket_id": ticket_id, "status": status},
            )
            await self._event_bus.publish(
                event_type=EventType.STATUS_CHANGED,
                source_agent="orchestrator",
                ticket_id=ticket_id,
                payload={"new_status": status},
            )
        except Exception:
            logger.exception(
                "Failed to update ticket %d status to '%s'", ticket_id, status
            )

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------

    @staticmethod
    def _build_summary(
        steps: list[PlanStep], overall_status: str
    ) -> dict[str, Any]:
        """Build a summary dict describing the plan execution outcome."""
        return {
            "status": overall_status,
            "steps": [
                {
                    "agent_type": s.agent_type,
                    "status": s.status.value,
                    "assignment_id": s.assignment_id,
                    "started_at": (
                        s.started_at.isoformat() if s.started_at else None
                    ),
                    "completed_at": (
                        s.completed_at.isoformat() if s.completed_at else None
                    ),
                }
                for s in steps
            ],
        }
