"""Fault tolerance -- 3-level failure recovery for the ASE orchestrator.

Level 1 (Self-Retry):
    Exponential backoff retry of the same agent.  Up to ``max_self_retries``
    attempts with increasing delays.

Level 2 (Peer Escalation):
    Route the task to a *peer* agent -- a different agent type that can
    attempt the same class of work from a different angle.

Level 3 (Human Escalation):
    Notify a human and wait for manual intervention.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from ase.config.schema import FaultToleranceConfig
from ase.events.bus import EventBus
from ase.events.types import EventType

logger = logging.getLogger(__name__)

# Maps agent types to their peer escalation candidates.
PEER_ESCALATION_MAP: dict[str, list[str]] = {
    "backend": ["database", "platform"],
    "frontend": ["backend"],
    "testing": ["backend", "frontend"],
    "devops": ["cloud", "platform"],
    "security": ["backend", "devops"],
    "database": ["backend"],
    "docs": ["backend", "frontend"],
    "platform": ["devops", "backend"],
    "cloud": ["devops", "platform"],
    "analyzer": ["triage"],
    "triage": ["analyzer"],
}


class FaultHandler:
    """Three-level failure recovery for agent execution.

    Parameters
    ----------
    config:
        ``FaultToleranceConfig`` with retry / escalation limits.
    bridge:
        ``MCPBridge`` for calling MCP tools (update status, publish events).
    event_bus:
        ``EventBus`` for publishing escalation events.
    notifier:
        Optional ``Notifier`` for L3 human escalation.
    """

    def __init__(
        self,
        config: FaultToleranceConfig,
        bridge: Any,
        event_bus: EventBus,
        notifier: Any = None,
    ) -> None:
        self._config = config
        self._bridge = bridge
        self._event_bus = event_bus
        self._notifier = notifier

        # Track retry / escalation state per assignment
        # assignment_id -> {"retries": int, "peer_attempts": int}
        self._state: dict[str, dict[str, int]] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def handle_failure(
        self,
        ticket_id: int,
        agent_type: str,
        assignment_id: int | None,
        error: str = "",
    ) -> bool:
        """Attempt to recover from a failure.

        Returns ``True`` if recovery was initiated (retry or peer spawned),
        ``False`` if all levels are exhausted and the step should be blocked.
        """
        key = str(assignment_id or f"{ticket_id}:{agent_type}")
        state = self._state.setdefault(key, {"retries": 0, "peer_attempts": 0})

        # ── Level 1: Self-Retry ──────────────────────────────────────
        if state["retries"] < self._config.max_self_retries:
            return await self._level1_retry(
                ticket_id, agent_type, assignment_id, key, state, error
            )

        # ── Level 2: Peer Escalation ─────────────────────────────────
        if state["peer_attempts"] < self._config.max_peer_escalations:
            return await self._level2_peer(
                ticket_id, agent_type, assignment_id, key, state, error
            )

        # ── Level 3: Human Escalation ────────────────────────────────
        await self._level3_human(ticket_id, agent_type, assignment_id, error)
        return False

    # ------------------------------------------------------------------
    # Level 1: Self-Retry with exponential backoff
    # ------------------------------------------------------------------

    async def _level1_retry(
        self,
        ticket_id: int,
        agent_type: str,
        assignment_id: int | None,
        key: str,
        state: dict[str, int],
        error: str,
    ) -> bool:
        attempt = state["retries"] + 1
        delay = min(
            self._config.backoff_base_seconds * (2 ** (attempt - 1)),
            self._config.backoff_max_seconds,
        )

        logger.info(
            "L1 self-retry %d/%d for %s on ticket %d (delay=%.1fs)",
            attempt,
            self._config.max_self_retries,
            agent_type,
            ticket_id,
            delay,
        )

        state["retries"] = attempt

        # Log the retry decision
        await self._log_decision(
            ticket_id,
            agent_type,
            f"L1 self-retry attempt {attempt}/{self._config.max_self_retries}",
            error,
        )

        # Wait before retry
        await asyncio.sleep(delay)

        # Publish event so orchestrator can re-spawn
        await self._event_bus.publish(
            event_type=EventType.BLOCKED,
            source_agent="fault_handler",
            ticket_id=ticket_id,
            payload={
                "level": 1,
                "action": "retry",
                "agent_type": agent_type,
                "assignment_id": assignment_id,
                "attempt": attempt,
                "error": error,
            },
        )

        return True

    # ------------------------------------------------------------------
    # Level 2: Peer Escalation
    # ------------------------------------------------------------------

    async def _level2_peer(
        self,
        ticket_id: int,
        agent_type: str,
        assignment_id: int | None,
        key: str,
        state: dict[str, int],
        error: str,
    ) -> bool:
        peers = PEER_ESCALATION_MAP.get(agent_type, [])
        attempt = state["peer_attempts"]

        if attempt >= len(peers):
            logger.warning(
                "L2 peer escalation exhausted for %s on ticket %d (no more peers)",
                agent_type,
                ticket_id,
            )
            return False

        peer_agent = peers[attempt]
        state["peer_attempts"] = attempt + 1

        logger.info(
            "L2 peer escalation: %s -> %s for ticket %d",
            agent_type,
            peer_agent,
            ticket_id,
        )

        await self._log_decision(
            ticket_id,
            agent_type,
            f"L2 peer escalation to {peer_agent}",
            error,
        )

        # Publish event so orchestrator knows to spawn the peer
        await self._event_bus.publish(
            event_type=EventType.BLOCKED,
            source_agent="fault_handler",
            ticket_id=ticket_id,
            payload={
                "level": 2,
                "action": "peer_escalation",
                "original_agent": agent_type,
                "peer_agent": peer_agent,
                "assignment_id": assignment_id,
                "error": error,
            },
        )

        return True

    # ------------------------------------------------------------------
    # Level 3: Human Escalation
    # ------------------------------------------------------------------

    async def _level3_human(
        self,
        ticket_id: int,
        agent_type: str,
        assignment_id: int | None,
        error: str,
    ) -> None:
        logger.error(
            "L3 human escalation for %s on ticket %d -- all automated recovery exhausted",
            agent_type,
            ticket_id,
        )

        await self._log_decision(
            ticket_id,
            agent_type,
            "L3 human escalation",
            error,
        )

        # Publish human-required event
        await self._event_bus.publish(
            event_type=EventType.HUMAN_REQUIRED,
            source_agent="fault_handler",
            ticket_id=ticket_id,
            payload={
                "level": 3,
                "action": "human_escalation",
                "agent_type": agent_type,
                "assignment_id": assignment_id,
                "error": error,
                "message": (
                    f"Agent '{agent_type}' has exhausted all automated recovery on "
                    f"ticket #{ticket_id}. Human intervention required."
                ),
            },
        )

        # Notify human if notifier is available
        if self._notifier is not None:
            await self._notifier.notify(
                title=f"[ASE] Human escalation -- ticket #{ticket_id}",
                body=(
                    f"Agent: {agent_type}\n"
                    f"Error: {error}\n\n"
                    f"All automated recovery (L1 retry + L2 peer) has been exhausted.\n"
                    f"Please investigate ticket #{ticket_id}."
                ),
            )

        # Update ticket status to blocked
        try:
            await self._bridge.execute_tool_call(
                "operativo__update_ticket",
                {"ticket_id": ticket_id, "status": "blocked"},
            )
        except Exception as exc:
            logger.warning("Failed to update ticket to blocked: %s", exc)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    async def _log_decision(
        self,
        ticket_id: int,
        agent_type: str,
        action: str,
        error: str,
    ) -> None:
        """Log a fault-handling decision via the MCP bridge."""
        try:
            await self._bridge.execute_tool_call(
                "operativo__log_decision",
                {
                    "ticket_id": ticket_id,
                    "agent_type": agent_type,
                    "decision_type": "fault_recovery",
                    "summary": action,
                    "details": f'{{"error": "{error}"}}',
                },
            )
        except Exception as exc:
            logger.warning("Failed to log fault decision: %s", exc)

    def reset(self, assignment_id: str | None = None) -> None:
        """Reset retry/escalation state.

        If *assignment_id* is given, reset only that entry.
        Otherwise, reset all state.
        """
        if assignment_id:
            self._state.pop(assignment_id, None)
        else:
            self._state.clear()

    def get_state(self, assignment_id: str) -> dict[str, int]:
        """Return the current retry/escalation state for an assignment."""
        return self._state.get(assignment_id, {"retries": 0, "peer_attempts": 0})
