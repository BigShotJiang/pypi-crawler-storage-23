"""
Scheduler -- manages parallel execution groups for the orchestrator.

The scheduler takes a list of plan steps with dependency edges and produces
an ordered sequence of **execution groups**.  Each group contains steps that
can run in parallel (all their dependencies belong to prior groups).

This is a simple topological-sort-based scheduler:

1. Build an adjacency list from ``depends_on`` edges.
2. Identify all steps with zero in-degree -- these form the first group.
3. Remove them from the graph, decrement in-degrees, and repeat.
4. If the graph is not empty after processing, a cycle exists.

The ``Orchestrator`` can use the scheduler to pre-compute the execution
order, or it can resolve dependencies on the fly (as the engine currently
does).  The scheduler is provided as a complementary utility.
"""

from __future__ import annotations

import logging
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class ScheduledStep:
    """A step tagged with its parallel execution group index."""

    agent_type: str
    description: str
    depends_on: list[str] = field(default_factory=list)
    config: dict[str, Any] = field(default_factory=dict)
    group: int = 0


class ExecutionGroup:
    """A set of steps that can execute concurrently."""

    def __init__(self, index: int, steps: list[ScheduledStep]) -> None:
        self.index = index
        self.steps = steps

    @property
    def agent_types(self) -> list[str]:
        return [s.agent_type for s in self.steps]

    def __repr__(self) -> str:
        agents = ", ".join(self.agent_types)
        return f"<ExecutionGroup {self.index}: [{agents}]>"

    def __len__(self) -> int:
        return len(self.steps)


class CyclicDependencyError(Exception):
    """Raised when the execution plan contains a dependency cycle."""


class Scheduler:
    """Computes parallel execution groups from a dependency graph.

    Example::

        scheduler = Scheduler()
        groups = scheduler.build_groups(execution_plan)
        for group in groups:
            # spawn all steps in group concurrently
            await asyncio.gather(*(spawn(s) for s in group.steps))
    """

    def build_groups(
        self, execution_plan: dict[str, Any]
    ) -> list[ExecutionGroup]:
        """Parse an execution plan and return ordered execution groups.

        Parameters
        ----------
        execution_plan:
            Dict with a ``"steps"`` key; each step has ``agent_type``,
            ``description``, optional ``depends_on`` and ``config``.

        Returns
        -------
        list[ExecutionGroup]
            Ordered groups where each group's dependencies are satisfied by
            earlier groups.

        Raises
        ------
        CyclicDependencyError
            If the dependency graph contains a cycle.
        ValueError
            If a ``depends_on`` reference points to a non-existent step.
        """
        raw_steps: list[dict[str, Any]] = execution_plan.get("steps", [])
        if not raw_steps:
            return []

        # Build ScheduledStep objects
        steps: dict[str, ScheduledStep] = {}
        for raw in raw_steps:
            agent_type = raw["agent_type"]
            steps[agent_type] = ScheduledStep(
                agent_type=agent_type,
                description=raw.get("description", ""),
                depends_on=raw.get("depends_on", []),
                config=raw.get("config", {}),
            )

        # Validate references
        for step in steps.values():
            for dep in step.depends_on:
                if dep not in steps:
                    raise ValueError(
                        f"Step '{step.agent_type}' depends on unknown "
                        f"agent_type '{dep}'"
                    )

        # Topological sort via Kahn's algorithm
        in_degree: dict[str, int] = defaultdict(int)
        dependents: dict[str, list[str]] = defaultdict(list)

        for agent_type, step in steps.items():
            if agent_type not in in_degree:
                in_degree[agent_type] = 0
            for dep in step.depends_on:
                in_degree[agent_type] += 1
                dependents[dep].append(agent_type)

        # Seed with zero-in-degree nodes
        queue: deque[str] = deque(
            agent for agent, deg in in_degree.items() if deg == 0
        )

        groups: list[ExecutionGroup] = []
        processed = 0

        while queue:
            # All nodes currently in the queue form one parallel group.
            current_batch: list[str] = list(queue)
            queue.clear()

            group_steps: list[ScheduledStep] = []
            group_index = len(groups)

            for agent_type in current_batch:
                step = steps[agent_type]
                step.group = group_index
                group_steps.append(step)
                processed += 1

                for dependent in dependents[agent_type]:
                    in_degree[dependent] -= 1
                    if in_degree[dependent] == 0:
                        queue.append(dependent)

            groups.append(ExecutionGroup(index=group_index, steps=group_steps))

        if processed != len(steps):
            remaining = [a for a, d in in_degree.items() if d > 0]
            raise CyclicDependencyError(
                f"Dependency cycle detected among: {remaining}"
            )

        logger.info(
            "Scheduled %d step(s) into %d parallel group(s)",
            len(steps),
            len(groups),
        )
        return groups

    # ------------------------------------------------------------------
    # Convenience helpers
    # ------------------------------------------------------------------

    @staticmethod
    def max_parallelism(groups: list[ExecutionGroup]) -> int:
        """Return the largest group size (peak concurrency)."""
        if not groups:
            return 0
        return max(len(g) for g in groups)

    @staticmethod
    def total_steps(groups: list[ExecutionGroup]) -> int:
        """Return the total number of steps across all groups."""
        return sum(len(g) for g in groups)

    @staticmethod
    def critical_path_length(groups: list[ExecutionGroup]) -> int:
        """Return the number of sequential groups (critical-path length)."""
        return len(groups)
