"""
ASE Runtime -- the central engine that wires all components and runs the loop.

This is the missing connector that closes the circle:
    Config → MCP servers → Bridge → LLM → Agents → Orchestrator → Output

Usage from CLI::

    runtime = ASERuntime(project_path)
    await runtime.start()          # launches MCP, event bus, triage
    await runtime.submit("Build a REST API for users")
    # ... agents work autonomously ...
    await runtime.stop()
"""

from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Any

from ase.agents.bridge import MCPBridge
from ase.agents.lifecycle import AgentLifecycleManager
from ase.config.loader import load_config
from ase.config.schema import ASEConfig
from ase.events.bus import EventBus
from ase.events.handlers import EventHandlerRegistry
from ase.events.types import Event, EventType
from ase.intake.normalizer import normalize
from ase.intake.ticket_factory import TicketFactory
from ase.llm.client import LLMClient
from ase.mcp.process import MCPProcessManager
from ase.onboarding.completeness import CompletenessReport, check_completeness
from ase.onboarding.consolidator import MemoryConsolidator
from ase.onboarding.discovery import ContextDiscoveryAgent
from ase.orchestrator.engine import Orchestrator
from ase.orchestrator.fault import FaultHandler

logger = logging.getLogger(__name__)


class ASERuntime:
    """Wires all ASE components together and drives the agent loop.

    Lifecycle::

        runtime = ASERuntime(project_path)
        await runtime.start()      # MCP servers + event polling + triage
        ticket = await runtime.submit("Implement feature X")
        await runtime.wait_idle()   # optional: block until no work left
        await runtime.stop()       # graceful shutdown

    Parameters
    ----------
    project_path:
        Root directory of an ``ase init``-ed project.
    """

    def __init__(self, project_path: Path | str) -> None:
        self._project_path = Path(project_path).resolve()
        self._config: ASEConfig | None = None

        # Components (created lazily in start())
        self._bridge: MCPBridge | None = None
        self._llm_client: LLMClient | None = None
        self._event_bus: EventBus | None = None
        self._lifecycle: AgentLifecycleManager | None = None
        self._orchestrator: Orchestrator | None = None
        self._fault_handler: FaultHandler | None = None
        self._process_manager: MCPProcessManager | None = None
        self._ticket_factory: TicketFactory | None = None
        self._handler_registry: EventHandlerRegistry | None = None

        self._running = False
        self._triage_task: asyncio.Task[None] | None = None
        self._discovery: ContextDiscoveryAgent | None = None
        self._consolidator: MemoryConsolidator | None = None
        self._completeness: CompletenessReport | None = None

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def config(self) -> ASEConfig:
        if self._config is None:
            raise RuntimeError("Runtime not started -- call start() first")
        return self._config

    @property
    def bridge(self) -> MCPBridge:
        if self._bridge is None:
            raise RuntimeError("Runtime not started")
        return self._bridge

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def completeness(self) -> CompletenessReport | None:
        """Last completeness report (populated after start)."""
        return self._completeness

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Initialize all components and start the agent event loop."""
        if self._running:
            logger.warning("Runtime already running")
            return

        logger.info("Starting ASE runtime for project: %s", self._project_path)

        # 1. Load config
        self._config = load_config(self._project_path)
        logger.info("Config loaded: project=%s", self._config.project.name)

        # 2. Create core components
        self._bridge = MCPBridge()
        self._llm_client = LLMClient(self._config.llm)
        self._event_bus = EventBus(self._bridge)

        # 3. Launch MCP server subprocesses and connect to bridge
        self._process_manager = MCPProcessManager(self._config, self._bridge)
        await self._process_manager.start()

        logger.info(
            "Bridge connected: %d tools across %s",
            len(self._bridge.registered_tools),
            self._bridge.registered_servers,
        )

        # 4. Create agent infrastructure
        self._lifecycle = AgentLifecycleManager(
            config=self._config,
            bridge=self._bridge,
            llm_client=self._llm_client,
        )

        self._fault_handler = FaultHandler(
            config=self._config.fault_tolerance,
            bridge=self._bridge,
            event_bus=self._event_bus,
        )

        self._orchestrator = Orchestrator(
            config=self._config,
            bridge=self._bridge,
            lifecycle=self._lifecycle,
            event_bus=self._event_bus,
            fault_handler=self._fault_handler,
        )

        self._ticket_factory = TicketFactory(self._bridge)

        # 5. Wire event handlers for the core pipeline
        self._handler_registry = EventHandlerRegistry()
        self._register_pipeline_handlers()
        self._handler_registry.bind(self._event_bus)

        # 6. Start event bus polling
        self._event_bus.start_polling()

        # 7. Create onboarding & memory components
        self._discovery = ContextDiscoveryAgent(
            bridge=self._bridge,
            llm_client=self._llm_client,
            project_path=self._project_path,
        )
        self._consolidator = MemoryConsolidator(
            bridge=self._bridge,
            llm_client=self._llm_client,
        )

        # 8. Check context completeness (non-blocking)
        self._completeness = await self._discovery.check()
        if not self._completeness.is_ready:
            logger.warning(
                "Context incomplete (%.0f%%) — %d critical gaps. "
                "Run 'ase onboard <project>' to fill them.",
                self._completeness.score * 100,
                len(self._completeness.critical_gaps),
            )

        self._running = True
        logger.info(
            "ASE runtime started -- project=%s, tools=%d, agents=%s",
            self._config.project.name,
            len(self._bridge.registered_tools),
            self._config.agents.enabled,
        )

    async def stop(self) -> None:
        """Gracefully shut down all components."""
        if not self._running:
            return

        logger.info("Shutting down ASE runtime...")

        # Cancel triage loop if running
        if self._triage_task and not self._triage_task.done():
            self._triage_task.cancel()
            try:
                await self._triage_task
            except asyncio.CancelledError:
                pass

        # Cancel all agents
        if self._lifecycle:
            cancelled = self._lifecycle.cancel_all()
            if cancelled:
                logger.info("Cancelled %d agent tasks", cancelled)

        # Stop event polling
        if self._event_bus:
            await self._event_bus.stop_polling()

        # Unbind handlers
        if self._handler_registry:
            self._handler_registry.unbind()

        # Stop MCP processes
        if self._process_manager:
            await self._process_manager.stop()

        self._running = False
        logger.info("ASE runtime stopped")

    # ------------------------------------------------------------------
    # Submit work
    # ------------------------------------------------------------------

    async def submit(
        self,
        request: str,
        priority: str = "medium",
    ) -> dict[str, Any]:
        """Submit a work request -- creates a ticket and triggers the pipeline.

        This is the main entry point for new work.  The pipeline is:
        ``intake → triage → analyze → plan → execute → review``

        Parameters
        ----------
        request:
            Free-text description of the work to be done.
        priority:
            One of ``"low"``, ``"medium"``, ``"high"``, ``"critical"``.

        Returns
        -------
        dict
            The created ticket data from MCP Operativo.
        """
        if not self._running or self._bridge is None or self._config is None:
            raise RuntimeError("Runtime not started -- call start() first")
        assert self._event_bus is not None
        assert self._lifecycle is not None

        bridge = self._bridge
        config = self._config
        event_bus = self._event_bus
        lifecycle = self._lifecycle

        cleaned = normalize(request)
        if not cleaned:
            raise ValueError("Empty request after normalisation")

        logger.info("Submitting work request (priority=%s): %s", priority, cleaned[:120])

        # Create ticket via MCP Operativo
        ticket = await bridge.execute_tool_call(
            "operativo__create_ticket",
            {
                "source": "cli",
                "raw_content": cleaned,
                "project_id": config.project.name,
                "priority": priority,
            },
        )

        # Extract ticket ID from MCP response
        ticket_id = self._extract_ticket_id(ticket)

        logger.info("Ticket created: %s", ticket_id)

        # Publish event to trigger the pipeline
        try:
            tid_int = int(ticket_id)
        except (ValueError, TypeError):
            tid_int = 0
        await event_bus.publish(
            event_type=EventType.STATUS_CHANGED,
            source_agent="runtime",
            ticket_id=tid_int,
            payload={"old_status": None, "new_status": "open", "priority": priority},
        )

        # Immediately trigger triage for this ticket
        await self._trigger_triage(ticket_id, cleaned, priority)

        return ticket if isinstance(ticket, dict) else {"id": ticket_id}

    # ------------------------------------------------------------------
    # Pipeline: Triage → Analyze → Execute
    # ------------------------------------------------------------------

    async def _trigger_triage(
        self,
        ticket_id: str,
        content: str,
        priority: str,
    ) -> None:
        """Spawn the triage agent for a new ticket.

        The triage agent reads the ticket, analyzes the request, and produces
        an execution plan with agent assignments.
        """
        logger.info("Triggering triage for ticket %s", ticket_id)
        assert self._config is not None
        assert self._lifecycle is not None
        assert self._event_bus is not None

        try:
            # First, run the analyzer to understand the request
            if "analyzer" in self._config.agents.enabled:
                analyzer_task = await self._lifecycle.spawn_agent(
                    agent_type="analyzer",
                    ticket_id=ticket_id,
                    assignment_id=f"analyze-{ticket_id}",
                    ticket_data={
                        "id": ticket_id,
                        "raw_content": content,
                        "priority": priority,
                    },
                )
                # Wait for analysis to complete before triage
                try:
                    await analyzer_task
                except Exception as exc:
                    logger.warning("Analyzer failed for ticket %s: %s", ticket_id, exc)

            # Then, run triage to create the execution plan
            if "triage" in self._config.agents.enabled:
                triage_task = await self._lifecycle.spawn_agent(
                    agent_type="triage",
                    ticket_id=ticket_id,
                    assignment_id=f"triage-{ticket_id}",
                    ticket_data={
                        "id": ticket_id,
                        "raw_content": content,
                        "priority": priority,
                    },
                )
                # Wait for triage to produce the plan
                try:
                    await triage_task
                except Exception as exc:
                    logger.warning("Triage failed for ticket %s: %s", ticket_id, exc)
                    return

            # After triage, check if an execution plan was set and execute it
            await self._execute_plan_if_ready(ticket_id)

        except Exception as exc:
            logger.error("Pipeline failed for ticket %s: %s", ticket_id, exc)
            # Publish failure event
            try:
                tid = int(ticket_id)
            except (ValueError, TypeError):
                tid = 0
            await self._event_bus.publish(
                event_type=EventType.AGENT_FAILED,
                source_agent="runtime",
                ticket_id=tid,
                payload={"error": str(exc), "stage": "triage"},
            )

    async def _execute_plan_if_ready(self, ticket_id: str) -> None:
        """Check if the ticket has an execution plan and run it."""
        assert self._bridge is not None
        assert self._orchestrator is not None

        try:
            ticket_data = await self._bridge.execute_tool_call(
                "operativo__get_ticket",
                {"ticket_id": ticket_id},
            )

            # Extract execution plan
            plan_raw = None
            if isinstance(ticket_data, dict):
                plan_raw = ticket_data.get("execution_plan")
            elif hasattr(ticket_data, "content"):
                # MCP CallToolResult
                for block in ticket_data.content:
                    if hasattr(block, "text"):
                        try:
                            parsed = json.loads(block.text)
                            plan_raw = parsed.get("execution_plan")
                        except (json.JSONDecodeError, AttributeError):
                            pass

            if not plan_raw:
                logger.info(
                    "No execution plan found for ticket %s -- "
                    "triage may not have produced one yet",
                    ticket_id,
                )
                return

            # Parse the plan (could be JSON string or dict)
            if isinstance(plan_raw, str):
                plan = json.loads(plan_raw)
            else:
                plan = plan_raw

            logger.info("Executing plan for ticket %s with %d steps",
                       ticket_id, len(plan.get("steps", [])))

            # Drive the orchestrator
            result = await self._orchestrator.execute_plan(
                ticket_id=int(ticket_id) if ticket_id.isdigit() else 0,
                execution_plan=plan,
            )

            logger.info("Plan execution result for ticket %s: %s",
                       ticket_id, result.get("status", "unknown"))

        except Exception as exc:
            logger.error("Plan execution failed for ticket %s: %s", ticket_id, exc)

    # ------------------------------------------------------------------
    # Event handler wiring
    # ------------------------------------------------------------------

    def _register_pipeline_handlers(self) -> None:
        """Register event handlers for the core agent pipeline."""
        assert self._handler_registry is not None
        registry = self._handler_registry

        @registry.on(EventType.AGENT_COMPLETED)
        async def on_agent_completed(event: Event) -> None:
            """When an agent completes, check if downstream work is ready."""
            payload = event.payload or {}
            agent_type = payload.get("agent_type", "")
            ticket_id = str(event.ticket_id) if event.ticket_id else ""

            logger.info(
                "Agent %s completed on ticket %s",
                agent_type, ticket_id,
            )

            # If triage completed, execute the plan
            if agent_type == "triage" and ticket_id:
                await self._execute_plan_if_ready(ticket_id)

        @registry.on(EventType.AGENT_FAILED)
        async def on_agent_failed(event: Event) -> None:
            """Trigger fault handling when an agent fails."""
            payload = event.payload or {}
            ticket_id = event.ticket_id
            agent_type = payload.get("agent_type", "unknown")
            error = payload.get("error", "Unknown error")

            logger.warning(
                "Agent %s failed on ticket %s: %s",
                agent_type, ticket_id, error,
            )

            if self._fault_handler and ticket_id:
                recovered = await self._fault_handler.handle_failure(
                    ticket_id=ticket_id,
                    agent_type=agent_type,
                    assignment_id=payload.get("assignment_id"),
                    error=error,
                )
                if not recovered:
                    logger.error(
                        "All recovery levels exhausted -- ticket %s blocked",
                        ticket_id,
                    )

        @registry.on(EventType.HUMAN_REQUIRED)
        async def on_human_required(event: Event) -> None:
            """Log when human intervention is needed."""
            logger.warning(
                "HUMAN INTERVENTION REQUIRED for ticket %s: %s",
                event.ticket_id,
                event.payload,
            )

        @registry.on(EventType.COST_WARNING)
        async def on_cost_warning(event: Event) -> None:
            """Log cost warnings."""
            logger.warning("COST WARNING: %s", event.payload)

        @registry.on(EventType.COMPLETED)
        async def on_ticket_completed(event: Event) -> None:
            """After a ticket is fully done, consolidate memory."""
            ticket_id = event.ticket_id
            if self._consolidator and ticket_id:
                logger.info(
                    "Ticket %s completed — triggering memory consolidation",
                    ticket_id,
                )
                try:
                    entries = await self._consolidator.consolidate(str(ticket_id))
                    if entries:
                        logger.info(
                            "Consolidated %d learnings from ticket %s",
                            len(entries),
                            ticket_id,
                        )
                except Exception as exc:
                    logger.warning(
                        "Memory consolidation failed for ticket %s: %s",
                        ticket_id,
                        exc,
                    )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _extract_ticket_id(self, result: Any) -> str:
        """Extract ticket ID from an MCP tool result."""
        if isinstance(result, dict):
            return str(result.get("id", result.get("ticket_id", "unknown")))

        # MCP CallToolResult
        if hasattr(result, "content"):
            for block in result.content:
                if hasattr(block, "text"):
                    try:
                        parsed = json.loads(block.text)
                        return str(parsed.get("id", parsed.get("ticket_id", "unknown")))
                    except (json.JSONDecodeError, AttributeError):
                        continue
            return "unknown"

        return str(result)

    async def wait_idle(self, timeout: float = 300.0) -> None:
        """Block until no agents are running (or timeout)."""
        if not self._lifecycle:
            return

        elapsed = 0.0
        poll = 2.0
        while elapsed < timeout:
            if not self._lifecycle._active_tasks:
                logger.info("All agents idle")
                return
            await asyncio.sleep(poll)
            elapsed += poll

        logger.warning("wait_idle timed out after %.0fs", timeout)

    async def onboard(self, interactive: bool = True) -> CompletenessReport:
        """Run the context discovery agent to fill gaps in Statico.

        Parameters
        ----------
        interactive:
            If True, prompt the human for answers when auto-discovery
            cannot resolve a gap.  If False, only auto-discover.

        Returns
        -------
        CompletenessReport
            Final completeness report after onboarding.
        """
        if not self._running or self._discovery is None:
            raise RuntimeError("Runtime not started -- call start() first")

        report = await self._discovery.run(interactive=interactive)
        self._completeness = report
        return report

    async def consolidate_memory(self, ticket_id: str | int) -> list[dict]:
        """Manually trigger memory consolidation for a specific ticket.

        Returns the list of knowledge entries that were persisted.
        """
        if not self._running or self._consolidator is None:
            raise RuntimeError("Runtime not started -- call start() first")
        return await self._consolidator.consolidate(ticket_id)
