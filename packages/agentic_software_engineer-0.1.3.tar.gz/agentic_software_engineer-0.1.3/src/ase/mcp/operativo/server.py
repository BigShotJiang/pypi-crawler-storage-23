"""
MCP Operativo Server — stdio transport.

Exposes all operational tools (tickets, assignments, artifacts, events,
decisions, feedback, metrics) via the Model Context Protocol using
FastMCP from the `mcp` library. Agents never hit SQLite directly;
every mutation passes through these tools.

Usage:
    python -m ase.mcp.operativo.server [db_path]
    ASE_DB_PATH=project.db python -m ase.mcp.operativo.server
"""

from __future__ import annotations

import json
import os
import sys
from typing import Any

from mcp.server.fastmcp import FastMCP

from ase.mcp.operativo.db import OperativoDB

# ── Server instance ───────────────────────────────────────────────────

mcp = FastMCP("ase-operativo")

# The OperativoDB is initialised lazily on first use (see _get_db()).
_db: OperativoDB | None = None
_db_path: str = ":memory:"


def _get_db() -> OperativoDB:
    """Return the shared OperativoDB, creating it on first call."""
    global _db
    if _db is None:
        _db = OperativoDB(_db_path)
    return _db


# ── Ticket Management ────────────────────────────────────────────────


@mcp.tool()
def create_ticket(
    source: str,
    raw_content: str,
    project_id: str,
    priority: str = "medium",
    parent_ticket_id: str | None = None,
) -> dict[str, Any]:
    """Create a new ticket. Returns the ticket with a generated UUID."""
    return _get_db().create_ticket(
        source=source,
        raw_content=raw_content,
        project_id=project_id,
        priority=priority,
        parent_ticket_id=parent_ticket_id,
    )


@mcp.tool()
def update_ticket(
    ticket_id: str,
    status: str | None = None,
    intent: str | None = None,
    priority: str | None = None,
    complexity: str | None = None,
    execution_plan: str | None = None,
    escalation_level: str | None = None,
) -> dict[str, Any]:
    """Update fields on a ticket. Automatically sets the timestamp matching the new status."""
    return _get_db().update_ticket(
        ticket_id,
        status=status,
        intent=intent,
        priority=priority,
        complexity=complexity,
        execution_plan=execution_plan,
        escalation_level=escalation_level,
    )


@mcp.tool()
def get_ticket(ticket_id: str) -> dict[str, Any]:
    """Return a complete ticket by ID."""
    return _get_db().get_ticket(ticket_id)


@mcp.tool()
def list_tickets(
    status: str | None = None,
    priority: str | None = None,
    project_id: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> list[dict[str, Any]]:
    """List tickets with optional filters."""
    return _get_db().list_tickets(
        status=status,
        priority=priority,
        project_id=project_id,
        limit=limit,
        offset=offset,
    )


@mcp.tool()
def get_ticket_history(ticket_id: str) -> list[dict[str, Any]]:
    """Return the full decision log for a ticket, ordered chronologically."""
    return _get_db().get_ticket_history(ticket_id)


# ── Agent Assignment ─────────────────────────────────────────────────


@mcp.tool()
def assign_agent(
    ticket_id: str,
    agent_type: str,
    depends_on: list[str] | None = None,
) -> dict[str, Any]:
    """Assign an agent to a ticket. Returns the assignment."""
    return _get_db().assign_agent(
        ticket_id=ticket_id,
        agent_type=agent_type,
        depends_on=depends_on,
    )


@mcp.tool()
def update_assignment(
    assignment_id: str,
    status: str | None = None,
    agent_instance_id: str | None = None,
    error_detail: str | None = None,
) -> dict[str, Any]:
    """Update the status of an agent assignment."""
    return _get_db().update_assignment(
        assignment_id,
        status=status,
        agent_instance_id=agent_instance_id,
        error_detail=error_detail,
    )


@mcp.tool()
def get_assignments(
    ticket_id: str,
    status: str | None = None,
) -> list[dict[str, Any]]:
    """List assignments for a ticket, optionally filtered by status."""
    return _get_db().get_assignments(ticket_id, status=status)


@mcp.tool()
def get_pending_assignments(agent_type: str) -> list[dict[str, Any]]:
    """Return pending assignments with all dependencies resolved, for the given agent type."""
    return _get_db().get_pending_assignments(agent_type)


# ── Event Bus ────────────────────────────────────────────────────────


@mcp.tool()
def publish_event(
    event_type: str,
    source_agent: str,
    ticket_id: str,
    payload: dict[str, Any] | None = None,
    target_agents: list[str] | None = None,
) -> dict[str, Any]:
    """Publish an event to the persistence-first event bus. Returns the event with its ID."""
    return _get_db().publish_event(
        event_type=event_type,
        source_agent=source_agent,
        ticket_id=ticket_id,
        payload=payload,
        target_agents=target_agents,
    )


@mcp.tool()
def get_events(
    since_id: int = 0,
    event_type: str | None = None,
    ticket_id: str | None = None,
    target_agent: str | None = None,
    limit: int = 100,
) -> list[dict[str, Any]]:
    """Poll events with ID > since_id. Supports filtering by type, ticket, and target agent."""
    return _get_db().get_events(
        since_id=since_id,
        event_type=event_type,
        ticket_id=ticket_id,
        target_agent=target_agent,
        limit=limit,
    )


@mcp.tool()
def mark_event_consumed(event_id: int, agent_type: str) -> dict[str, Any]:
    """Mark an event as consumed by the given agent."""
    return _get_db().mark_event_consumed(event_id, agent_type)


# ── Artifacts ────────────────────────────────────────────────────────


@mcp.tool()
def register_artifact(
    ticket_id: str,
    agent_type: str,
    artifact_type: str,
    path: str,
    content_hash: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Register an artifact produced by an agent."""
    return _get_db().register_artifact(
        ticket_id=ticket_id,
        agent_type=agent_type,
        artifact_type=artifact_type,
        path=path,
        content_hash=content_hash,
        metadata=metadata,
    )


@mcp.tool()
def get_artifacts(
    ticket_id: str,
    artifact_type: str | None = None,
) -> list[dict[str, Any]]:
    """List artifacts for a ticket, optionally filtered by type."""
    return _get_db().get_artifacts(ticket_id, artifact_type=artifact_type)


# ── Decision Log ─────────────────────────────────────────────────────


@mcp.tool()
def log_decision(
    ticket_id: str,
    agent_type: str,
    action: str,
    reasoning: str,
    outcome: str,
    context_consulted: list[str] | None = None,
    artifacts_produced: list[str] | None = None,
    error_detail: str | None = None,
    retry_of: int | None = None,
    llm_model: str | None = None,
    tokens_in: int | None = None,
    tokens_out: int | None = None,
    cost_usd: float | None = None,
    duration_ms: int | None = None,
    agent_instance_id: str | None = None,
) -> dict[str, Any]:
    """Log an immutable decision entry. Automatically mirrors cost data to cost_log if present."""
    return _get_db().log_decision(
        ticket_id=ticket_id,
        agent_type=agent_type,
        action=action,
        reasoning=reasoning,
        outcome=outcome,
        context_consulted=context_consulted,
        artifacts_produced=artifacts_produced,
        error_detail=error_detail,
        retry_of=retry_of,
        llm_model=llm_model,
        tokens_in=tokens_in,
        tokens_out=tokens_out,
        cost_usd=cost_usd,
        duration_ms=duration_ms,
        agent_instance_id=agent_instance_id,
    )


# ── Human Feedback ───────────────────────────────────────────────────


@mcp.tool()
def submit_feedback(
    ticket_id: str,
    feedback_type: str,
    content: str,
    sentiment: str | None = None,
    author: str | None = None,
) -> dict[str, Any]:
    """Submit human feedback. Automatically creates a child ticket if sentiment is 'negative'."""
    return _get_db().submit_feedback(
        ticket_id=ticket_id,
        feedback_type=feedback_type,
        content=content,
        sentiment=sentiment,
        author=author,
    )


# ── Metrics ──────────────────────────────────────────────────────────


@mcp.tool()
def get_metrics(
    project_id: str | None = None,
    since: str | None = None,
) -> dict[str, Any]:
    """
    Return aggregated metrics: tickets_by_status, avg_completion_time_hours,
    retry_rate, escalation_rate, total_cost_usd, cost_by_agent, throughput_per_day.
    """
    return _get_db().get_metrics(project_id=project_id, since=since)


# ── Entrypoint ───────────────────────────────────────────────────────


def main() -> None:
    """Start the MCP Operativo server over stdio."""
    global _db_path

    # Resolve db_path: CLI arg > env var > in-memory
    if len(sys.argv) > 1:
        _db_path = sys.argv[1]
    else:
        _db_path = os.environ.get("ASE_DB_PATH", ":memory:")

    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
