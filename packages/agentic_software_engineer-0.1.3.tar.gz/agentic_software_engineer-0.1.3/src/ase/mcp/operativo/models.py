"""
Pydantic models for MCP Operativo entities.

These models define the shape of all operational data flowing through the system:
tickets, agent assignments, artifacts, events, decision log, and human feedback.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, Field


def _utcnow() -> str:
    """Return current UTC time as ISO-8601 string with millisecond precision."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def _uuid() -> str:
    return str(uuid4())


# ── Ticket ────────────────────────────────────────────────────────────

class Ticket(BaseModel):
    """A work unit flowing through the ASE pipeline."""

    id: str = Field(default_factory=_uuid)
    source: str  # text | slack | webhook | github | staging_feedback
    raw_content: str
    intent: str | None = None  # feature | bugfix | refactor | infra | docs
    project_id: str
    priority: str = "medium"  # critical | high | medium | low
    complexity: str | None = None  # trivial | simple | moderate | complex | epic
    status: str = "received"  # received | analyzed | triaged | assigned | in_progress | review | staging | feedback | done | failed | blocked
    parent_ticket_id: str | None = None
    retry_count: int = 0
    escalation_level: str = "none"  # none | agent_retry | agent_escalation | human_escalation
    execution_plan: str | None = None  # JSON string

    # Timestamps
    created_at: str = Field(default_factory=_utcnow)
    analyzed_at: str | None = None
    triaged_at: str | None = None
    assigned_at: str | None = None
    started_at: str | None = None
    review_at: str | None = None
    staging_at: str | None = None
    completed_at: str | None = None
    updated_at: str = Field(default_factory=_utcnow)


# ── Agent Assignment ──────────────────────────────────────────────────

class AgentAssignment(BaseModel):
    """An agent assigned to work on a ticket."""

    id: str = Field(default_factory=_uuid)
    ticket_id: str
    agent_type: str  # triage | analyzer | backend | frontend | testing | devops | security | database | docs
    agent_instance_id: str | None = None
    status: str = "pending"  # pending | running | completed | failed | blocked
    depends_on: str | None = None  # JSON array of assignment IDs
    started_at: str | None = None
    completed_at: str | None = None
    error_detail: str | None = None
    created_at: str = Field(default_factory=_utcnow)


# ── Artifact ──────────────────────────────────────────────────────────

class Artifact(BaseModel):
    """An artifact produced by an agent (file, branch, PR, etc.)."""

    id: str = Field(default_factory=_uuid)
    ticket_id: str
    agent_type: str
    artifact_type: str  # file | branch | pr | deploy | config | migration
    path: str | None = None
    content_hash: str | None = None  # SHA256
    metadata: str | None = None  # JSON string
    created_at: str = Field(default_factory=_utcnow)


# ── Event ─────────────────────────────────────────────────────────────

class Event(BaseModel):
    """An event on the persistence-first event bus."""

    id: int | None = None  # Auto-incremented by SQLite
    event_type: str  # artifact_created | api_contract_defined | schema_changed | test_failed | test_passed | blocked | completed | status_changed | human_required
    source_agent: str
    target_agents: str | None = None  # JSON array or None for broadcast
    ticket_id: str
    payload: str = "{}"  # JSON string
    consumed_by: str = "[]"  # JSON array
    created_at: str = Field(default_factory=_utcnow)


# ── Decision Log ─────────────────────────────────────────────────────

class DecisionLog(BaseModel):
    """Immutable audit trail entry for an agent decision."""

    id: int | None = None  # Auto-incremented by SQLite
    ticket_id: str
    agent_type: str
    agent_instance_id: str | None = None
    action: str
    reasoning: str
    context_consulted: str = "[]"  # JSON array
    artifacts_produced: str = "[]"  # JSON array
    outcome: str  # success | failure | partial | blocked | skipped
    error_detail: str | None = None
    retry_of: int | None = None  # References decision_log(id)
    llm_model: str | None = None
    tokens_in: int | None = None
    tokens_out: int | None = None
    cost_usd: float | None = None
    duration_ms: int | None = None
    created_at: str = Field(default_factory=_utcnow)


# ── Human Feedback ───────────────────────────────────────────────────

class HumanFeedback(BaseModel):
    """Feedback from a human reviewer (staging, PR, escalation, manual)."""

    id: str = Field(default_factory=_uuid)
    ticket_id: str
    feedback_type: str  # staging_review | pr_comment | escalation_response | manual
    content: str
    sentiment: str | None = None  # positive | negative | neutral
    child_ticket_id: str | None = None
    author: str | None = None
    created_at: str = Field(default_factory=_utcnow)


# ── Cost Log ─────────────────────────────────────────────────────────

class CostLog(BaseModel):
    """LLM cost tracking entry."""

    id: int | None = None  # Auto-incremented by SQLite
    ticket_id: str | None = None
    agent_type: str
    llm_model: str
    tokens_in: int
    tokens_out: int
    cost_usd: float
    created_at: str = Field(default_factory=_utcnow)


# ── Metrics ──────────────────────────────────────────────────────────

class Metrics(BaseModel):
    """Aggregated operational metrics."""

    tickets_by_status: dict[str, int] = Field(default_factory=dict)
    avg_completion_time_hours: float | None = None
    retry_rate: float = 0.0
    escalation_rate: float = 0.0
    total_cost_usd: float = 0.0
    cost_by_agent: dict[str, float] = Field(default_factory=dict)
    throughput_per_day: float = 0.0
