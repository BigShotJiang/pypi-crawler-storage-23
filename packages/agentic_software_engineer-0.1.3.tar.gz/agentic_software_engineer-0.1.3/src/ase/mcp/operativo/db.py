"""
SQLite query layer for MCP Operativo.

All CRUD operations for tickets, assignments, artifacts, events,
decisions, feedback, and cost tracking. Uses sqlite3.Row for dict-like
access. All write operations use explicit transactions.
"""

from __future__ import annotations

import json
import sqlite3
from typing import Any
from uuid import uuid4


def _uuid() -> str:
    return str(uuid4())


# ── Schema DDL ────────────────────────────────────────────────────────

SCHEMA_SQL = """\
PRAGMA journal_mode = WAL;
PRAGMA busy_timeout = 5000;
PRAGMA synchronous = NORMAL;
PRAGMA foreign_keys = ON;
PRAGMA cache_size = -64000;

CREATE TABLE IF NOT EXISTS tickets (
    id              TEXT PRIMARY KEY,
    source          TEXT NOT NULL,
    raw_content     TEXT NOT NULL,
    intent          TEXT,
    project_id      TEXT NOT NULL,
    priority        TEXT NOT NULL DEFAULT 'medium',
    complexity      TEXT,
    status          TEXT NOT NULL DEFAULT 'received',
    parent_ticket_id TEXT REFERENCES tickets(id),
    retry_count     INTEGER NOT NULL DEFAULT 0,
    escalation_level TEXT NOT NULL DEFAULT 'none',
    execution_plan  TEXT,
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    analyzed_at     TEXT,
    triaged_at      TEXT,
    assigned_at     TEXT,
    started_at      TEXT,
    review_at       TEXT,
    staging_at      TEXT,
    completed_at    TEXT,
    updated_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_tickets_status ON tickets(status);
CREATE INDEX IF NOT EXISTS idx_tickets_priority ON tickets(priority);
CREATE INDEX IF NOT EXISTS idx_tickets_parent ON tickets(parent_ticket_id);
CREATE INDEX IF NOT EXISTS idx_tickets_project ON tickets(project_id);

CREATE TABLE IF NOT EXISTS agent_assignments (
    id              TEXT PRIMARY KEY,
    ticket_id       TEXT NOT NULL REFERENCES tickets(id),
    agent_type      TEXT NOT NULL,
    agent_instance_id TEXT,
    status          TEXT NOT NULL DEFAULT 'pending',
    depends_on      TEXT,
    started_at      TEXT,
    completed_at    TEXT,
    error_detail    TEXT,
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_assignments_ticket ON agent_assignments(ticket_id);
CREATE INDEX IF NOT EXISTS idx_assignments_status ON agent_assignments(status);

CREATE TABLE IF NOT EXISTS artifacts (
    id              TEXT PRIMARY KEY,
    ticket_id       TEXT NOT NULL REFERENCES tickets(id),
    agent_type      TEXT NOT NULL,
    artifact_type   TEXT NOT NULL,
    path            TEXT,
    content_hash    TEXT,
    metadata        TEXT,
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_artifacts_ticket ON artifacts(ticket_id);

CREATE TABLE IF NOT EXISTS events (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type      TEXT NOT NULL,
    source_agent    TEXT NOT NULL,
    target_agents   TEXT,
    ticket_id       TEXT NOT NULL REFERENCES tickets(id),
    payload         TEXT NOT NULL DEFAULT '{}',
    consumed_by     TEXT NOT NULL DEFAULT '[]',
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_events_type ON events(event_type);
CREATE INDEX IF NOT EXISTS idx_events_ticket ON events(ticket_id);
CREATE INDEX IF NOT EXISTS idx_events_created ON events(created_at);

CREATE TABLE IF NOT EXISTS decision_log (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id       TEXT NOT NULL REFERENCES tickets(id),
    agent_type      TEXT NOT NULL,
    agent_instance_id TEXT,
    action          TEXT NOT NULL,
    reasoning       TEXT NOT NULL,
    context_consulted TEXT NOT NULL DEFAULT '[]',
    artifacts_produced TEXT NOT NULL DEFAULT '[]',
    outcome         TEXT NOT NULL,
    error_detail    TEXT,
    retry_of        INTEGER REFERENCES decision_log(id),
    llm_model       TEXT,
    tokens_in       INTEGER,
    tokens_out      INTEGER,
    cost_usd        REAL,
    duration_ms     INTEGER,
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_decisions_ticket ON decision_log(ticket_id);
CREATE INDEX IF NOT EXISTS idx_decisions_agent ON decision_log(agent_type);
CREATE INDEX IF NOT EXISTS idx_decisions_outcome ON decision_log(outcome);

CREATE TABLE IF NOT EXISTS human_feedback (
    id              TEXT PRIMARY KEY,
    ticket_id       TEXT NOT NULL REFERENCES tickets(id),
    feedback_type   TEXT NOT NULL,
    content         TEXT NOT NULL,
    sentiment       TEXT,
    child_ticket_id TEXT REFERENCES tickets(id),
    author          TEXT,
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_feedback_ticket ON human_feedback(ticket_id);

CREATE TABLE IF NOT EXISTS cost_log (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id       TEXT REFERENCES tickets(id),
    agent_type      TEXT NOT NULL,
    llm_model       TEXT NOT NULL,
    tokens_in       INTEGER NOT NULL,
    tokens_out      INTEGER NOT NULL,
    cost_usd        REAL NOT NULL,
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_cost_ticket ON cost_log(ticket_id);
CREATE INDEX IF NOT EXISTS idx_cost_date ON cost_log(created_at);
"""


def _row_to_dict(row: sqlite3.Row) -> dict[str, Any]:
    """Convert a sqlite3.Row to a plain dict."""
    return dict(row)


# ── Status → timestamp mapping ────────────────────────────────────────

_STATUS_TIMESTAMP_MAP: dict[str, str] = {
    "analyzed": "analyzed_at",
    "triaged": "triaged_at",
    "assigned": "assigned_at",
    "in_progress": "started_at",
    "review": "review_at",
    "staging": "staging_at",
    "done": "completed_at",
    "failed": "completed_at",
}


class OperativoDB:
    """Synchronous SQLite query layer for all Operativo entities."""

    def __init__(self, db_path: str = ":memory:"):
        self._conn = sqlite3.connect(db_path)
        self._conn.row_factory = sqlite3.Row
        self._apply_schema()

    def _apply_schema(self) -> None:
        """Execute DDL to create all tables and indices."""
        self._conn.executescript(SCHEMA_SQL)

    def close(self) -> None:
        self._conn.close()

    # ── Tickets ───────────────────────────────────────────────────────

    def create_ticket(
        self,
        source: str,
        raw_content: str,
        project_id: str,
        priority: str = "medium",
        parent_ticket_id: str | None = None,
    ) -> dict[str, Any]:
        ticket_id = _uuid()
        with self._conn:
            self._conn.execute(
                """
                INSERT INTO tickets (id, source, raw_content, project_id, priority, parent_ticket_id)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (ticket_id, source, raw_content, project_id, priority, parent_ticket_id),
            )
        return self.get_ticket(ticket_id)

    def update_ticket(
        self,
        ticket_id: str,
        *,
        status: str | None = None,
        intent: str | None = None,
        priority: str | None = None,
        complexity: str | None = None,
        execution_plan: str | None = None,
        escalation_level: str | None = None,
        retry_count: int | None = None,
    ) -> dict[str, Any]:
        sets: list[str] = []
        params: list[Any] = []

        for col, val in [
            ("status", status),
            ("intent", intent),
            ("priority", priority),
            ("complexity", complexity),
            ("execution_plan", execution_plan),
            ("escalation_level", escalation_level),
            ("retry_count", retry_count),
        ]:
            if val is not None:
                sets.append(f"{col} = ?")
                params.append(val)

        # Auto-set the timestamp corresponding to the new status
        if status and status in _STATUS_TIMESTAMP_MAP:
            ts_col = _STATUS_TIMESTAMP_MAP[status]
            sets.append(f"{ts_col} = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')")

        # Always bump updated_at
        sets.append("updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')")

        if not sets:
            return self.get_ticket(ticket_id)

        params.append(ticket_id)
        sql = f"UPDATE tickets SET {', '.join(sets)} WHERE id = ?"

        with self._conn:
            self._conn.execute(sql, params)
        return self.get_ticket(ticket_id)

    def get_ticket(self, ticket_id: str) -> dict[str, Any]:
        row = self._conn.execute(
            "SELECT * FROM tickets WHERE id = ?", (ticket_id,)
        ).fetchone()
        if row is None:
            raise ValueError(f"Ticket {ticket_id} not found")
        return _row_to_dict(row)

    def list_tickets(
        self,
        *,
        status: str | None = None,
        priority: str | None = None,
        project_id: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        clauses: list[str] = []
        params: list[Any] = []

        if status:
            clauses.append("status = ?")
            params.append(status)
        if priority:
            clauses.append("priority = ?")
            params.append(priority)
        if project_id:
            clauses.append("project_id = ?")
            params.append(project_id)

        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.extend([limit, offset])

        rows = self._conn.execute(
            f"SELECT * FROM tickets {where} ORDER BY created_at DESC LIMIT ? OFFSET ?",
            params,
        ).fetchall()
        return [_row_to_dict(r) for r in rows]

    def get_ticket_history(self, ticket_id: str) -> list[dict[str, Any]]:
        """Return the full decision log for a ticket, ordered chronologically."""
        rows = self._conn.execute(
            "SELECT * FROM decision_log WHERE ticket_id = ? ORDER BY created_at ASC",
            (ticket_id,),
        ).fetchall()
        return [_row_to_dict(r) for r in rows]

    # ── Agent Assignments ─────────────────────────────────────────────

    def assign_agent(
        self,
        ticket_id: str,
        agent_type: str,
        depends_on: list[str] | None = None,
    ) -> dict[str, Any]:
        assignment_id = _uuid()
        depends_json = json.dumps(depends_on) if depends_on else None
        with self._conn:
            self._conn.execute(
                """
                INSERT INTO agent_assignments (id, ticket_id, agent_type, depends_on)
                VALUES (?, ?, ?, ?)
                """,
                (assignment_id, ticket_id, agent_type, depends_json),
            )
        return self._get_assignment(assignment_id)

    def update_assignment(
        self,
        assignment_id: str,
        *,
        status: str | None = None,
        agent_instance_id: str | None = None,
        error_detail: str | None = None,
    ) -> dict[str, Any]:
        sets: list[str] = []
        params: list[Any] = []

        if status is not None:
            sets.append("status = ?")
            params.append(status)
            if status == "running":
                sets.append("started_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')")
            elif status in ("completed", "failed"):
                sets.append("completed_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')")

        if agent_instance_id is not None:
            sets.append("agent_instance_id = ?")
            params.append(agent_instance_id)

        if error_detail is not None:
            sets.append("error_detail = ?")
            params.append(error_detail)

        if not sets:
            return self._get_assignment(assignment_id)

        params.append(assignment_id)
        sql = f"UPDATE agent_assignments SET {', '.join(sets)} WHERE id = ?"

        with self._conn:
            self._conn.execute(sql, params)
        return self._get_assignment(assignment_id)

    def _get_assignment(self, assignment_id: str) -> dict[str, Any]:
        row = self._conn.execute(
            "SELECT * FROM agent_assignments WHERE id = ?", (assignment_id,)
        ).fetchone()
        if row is None:
            raise ValueError(f"Assignment {assignment_id} not found")
        return _row_to_dict(row)

    def get_assignments(
        self, ticket_id: str, *, status: str | None = None
    ) -> list[dict[str, Any]]:
        if status:
            rows = self._conn.execute(
                "SELECT * FROM agent_assignments WHERE ticket_id = ? AND status = ? ORDER BY created_at ASC",
                (ticket_id, status),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM agent_assignments WHERE ticket_id = ? ORDER BY created_at ASC",
                (ticket_id,),
            ).fetchall()
        return [_row_to_dict(r) for r in rows]

    def get_pending_assignments(self, agent_type: str) -> list[dict[str, Any]]:
        """
        Return pending assignments for the given agent type whose
        dependencies are all completed (or that have no dependencies).
        """
        rows = self._conn.execute(
            """
            SELECT * FROM agent_assignments
            WHERE agent_type = ? AND status = 'pending'
            ORDER BY created_at ASC
            """,
            (agent_type,),
        ).fetchall()

        result: list[dict[str, Any]] = []
        for row in rows:
            d = _row_to_dict(row)
            deps_json = d.get("depends_on")
            if deps_json:
                dep_ids: list[str] = json.loads(deps_json)
                if dep_ids:
                    # Check all dependencies are completed
                    placeholders = ",".join("?" for _ in dep_ids)
                    count = self._conn.execute(
                        f"""
                        SELECT COUNT(*) FROM agent_assignments
                        WHERE id IN ({placeholders}) AND status = 'completed'
                        """,
                        dep_ids,
                    ).fetchone()[0]
                    if count < len(dep_ids):
                        continue  # Not all deps completed
            result.append(d)
        return result

    # ── Events ────────────────────────────────────────────────────────

    def publish_event(
        self,
        event_type: str,
        source_agent: str,
        ticket_id: str,
        payload: dict[str, Any] | None = None,
        target_agents: list[str] | None = None,
    ) -> dict[str, Any]:
        payload_json = json.dumps(payload) if payload else "{}"
        targets_json = json.dumps(target_agents) if target_agents else None

        with self._conn:
            cursor = self._conn.execute(
                """
                INSERT INTO events (event_type, source_agent, ticket_id, payload, target_agents)
                VALUES (?, ?, ?, ?, ?)
                """,
                (event_type, source_agent, ticket_id, payload_json, targets_json),
            )
            event_id = cursor.lastrowid

        return self._get_event(event_id)

    def _get_event(self, event_id: int) -> dict[str, Any]:
        row = self._conn.execute(
            "SELECT * FROM events WHERE id = ?", (event_id,)
        ).fetchone()
        if row is None:
            raise ValueError(f"Event {event_id} not found")
        return _row_to_dict(row)

    def get_events(
        self,
        *,
        since_id: int = 0,
        event_type: str | None = None,
        ticket_id: str | None = None,
        target_agent: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        clauses: list[str] = ["id > ?"]
        params: list[Any] = [since_id]

        if event_type:
            clauses.append("event_type = ?")
            params.append(event_type)
        if ticket_id:
            clauses.append("ticket_id = ?")
            params.append(ticket_id)

        where = " AND ".join(clauses)
        params.append(limit)

        rows = self._conn.execute(
            f"SELECT * FROM events WHERE {where} ORDER BY id ASC LIMIT ?",
            params,
        ).fetchall()

        results = [_row_to_dict(r) for r in rows]

        # Filter by target_agent in Python (JSON array check)
        if target_agent:
            filtered: list[dict[str, Any]] = []
            for evt in results:
                targets = evt.get("target_agents")
                if targets is None:
                    # Broadcast event — include it
                    filtered.append(evt)
                else:
                    agent_list = json.loads(targets) if isinstance(targets, str) else targets
                    if target_agent in agent_list or "all" in agent_list:
                        filtered.append(evt)
            results = filtered

        return results

    def mark_event_consumed(self, event_id: int, agent_type: str) -> dict[str, Any]:
        row = self._conn.execute(
            "SELECT consumed_by FROM events WHERE id = ?", (event_id,)
        ).fetchone()
        if row is None:
            raise ValueError(f"Event {event_id} not found")

        consumed: list[str] = json.loads(row["consumed_by"])
        if agent_type not in consumed:
            consumed.append(agent_type)
            with self._conn:
                self._conn.execute(
                    "UPDATE events SET consumed_by = ? WHERE id = ?",
                    (json.dumps(consumed), event_id),
                )
        return self._get_event(event_id)

    # ── Artifacts ─────────────────────────────────────────────────────

    def register_artifact(
        self,
        ticket_id: str,
        agent_type: str,
        artifact_type: str,
        path: str,
        content_hash: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        artifact_id = _uuid()
        metadata_json = json.dumps(metadata) if metadata else None
        with self._conn:
            self._conn.execute(
                """
                INSERT INTO artifacts (id, ticket_id, agent_type, artifact_type, path, content_hash, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (artifact_id, ticket_id, agent_type, artifact_type, path, content_hash, metadata_json),
            )
        row = self._conn.execute(
            "SELECT * FROM artifacts WHERE id = ?", (artifact_id,)
        ).fetchone()
        return _row_to_dict(row)

    def get_artifacts(
        self, ticket_id: str, *, artifact_type: str | None = None
    ) -> list[dict[str, Any]]:
        if artifact_type:
            rows = self._conn.execute(
                "SELECT * FROM artifacts WHERE ticket_id = ? AND artifact_type = ? ORDER BY created_at ASC",
                (ticket_id, artifact_type),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM artifacts WHERE ticket_id = ? ORDER BY created_at ASC",
                (ticket_id,),
            ).fetchall()
        return [_row_to_dict(r) for r in rows]

    # ── Decision Log ──────────────────────────────────────────────────

    def log_decision(
        self,
        ticket_id: str,
        agent_type: str,
        action: str,
        reasoning: str,
        outcome: str,
        *,
        context_consulted: list[str] | None = None,
        artifacts_produced: list[str] | None = None,
        error_detail: str | None = None,
        retry_of: int | None = None,
        llm_model: str | None = None,
        tokens_in: int | None = None,
        tokens_out: int | None = None,
        cost_usd: float | None = None,
        duration_ms: int | None = None,
        agent_instance_id: str | None = None,
    ) -> dict[str, Any]:
        ctx_json = json.dumps(context_consulted) if context_consulted else "[]"
        art_json = json.dumps(artifacts_produced) if artifacts_produced else "[]"

        with self._conn:
            cursor = self._conn.execute(
                """
                INSERT INTO decision_log (
                    ticket_id, agent_type, agent_instance_id, action, reasoning,
                    context_consulted, artifacts_produced, outcome, error_detail,
                    retry_of, llm_model, tokens_in, tokens_out, cost_usd, duration_ms
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    ticket_id, agent_type, agent_instance_id, action, reasoning,
                    ctx_json, art_json, outcome, error_detail,
                    retry_of, llm_model, tokens_in, tokens_out, cost_usd, duration_ms,
                ),
            )
            decision_id = cursor.lastrowid

        # Also insert into cost_log if cost data is available
        if cost_usd is not None and llm_model is not None:
            self._log_cost(
                ticket_id=ticket_id,
                agent_type=agent_type,
                llm_model=llm_model,
                tokens_in=tokens_in or 0,
                tokens_out=tokens_out or 0,
                cost_usd=cost_usd,
            )

        row = self._conn.execute(
            "SELECT * FROM decision_log WHERE id = ?", (decision_id,)
        ).fetchone()
        return _row_to_dict(row)

    # ── Human Feedback ────────────────────────────────────────────────

    def submit_feedback(
        self,
        ticket_id: str,
        feedback_type: str,
        content: str,
        *,
        sentiment: str | None = None,
        author: str | None = None,
    ) -> dict[str, Any]:
        feedback_id = _uuid()
        child_ticket_id: str | None = None

        with self._conn:
            # If negative sentiment, auto-create a child ticket
            if sentiment == "negative":
                # Look up the parent ticket to get project_id
                parent = self._conn.execute(
                    "SELECT project_id FROM tickets WHERE id = ?", (ticket_id,)
                ).fetchone()
                if parent is None:
                    raise ValueError(f"Ticket {ticket_id} not found")

                child_ticket_id = _uuid()
                self._conn.execute(
                    """
                    INSERT INTO tickets (id, source, raw_content, project_id, priority, parent_ticket_id)
                    VALUES (?, 'staging_feedback', ?, ?, 'high', ?)
                    """,
                    (child_ticket_id, content, parent["project_id"], ticket_id),
                )

            self._conn.execute(
                """
                INSERT INTO human_feedback (id, ticket_id, feedback_type, content, sentiment, child_ticket_id, author)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (feedback_id, ticket_id, feedback_type, content, sentiment, child_ticket_id, author),
            )

        row = self._conn.execute(
            "SELECT * FROM human_feedback WHERE id = ?", (feedback_id,)
        ).fetchone()
        return _row_to_dict(row)

    # ── Cost Log ──────────────────────────────────────────────────────

    def _log_cost(
        self,
        ticket_id: str | None,
        agent_type: str,
        llm_model: str,
        tokens_in: int,
        tokens_out: int,
        cost_usd: float,
    ) -> None:
        """Insert a cost tracking entry (called internally from log_decision)."""
        with self._conn:
            self._conn.execute(
                """
                INSERT INTO cost_log (ticket_id, agent_type, llm_model, tokens_in, tokens_out, cost_usd)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (ticket_id, agent_type, llm_model, tokens_in, tokens_out, cost_usd),
            )

    # ── Metrics ───────────────────────────────────────────────────────

    def get_metrics(
        self,
        *,
        project_id: str | None = None,
        since: str | None = None,
    ) -> dict[str, Any]:
        """Return aggregated operational metrics."""

        # Build optional WHERE fragments for tickets
        ticket_clauses: list[str] = []
        ticket_params: list[Any] = []
        if project_id:
            ticket_clauses.append("project_id = ?")
            ticket_params.append(project_id)
        if since:
            ticket_clauses.append("created_at >= ?")
            ticket_params.append(since)
        ticket_where = f"WHERE {' AND '.join(ticket_clauses)}" if ticket_clauses else ""

        # Build optional WHERE fragments for cost_log
        cost_clauses: list[str] = []
        cost_params: list[Any] = []
        if since:
            cost_clauses.append("created_at >= ?")
            cost_params.append(since)
        cost_where = f"WHERE {' AND '.join(cost_clauses)}" if cost_clauses else ""

        # 1. Tickets by status
        rows = self._conn.execute(
            f"SELECT status, COUNT(*) as cnt FROM tickets {ticket_where} GROUP BY status",
            ticket_params,
        ).fetchall()
        tickets_by_status = {r["status"]: r["cnt"] for r in rows}

        # 2. Average completion time (received -> done), in hours
        avg_row = self._conn.execute(
            f"""
            SELECT AVG(
                (julianday(completed_at) - julianday(created_at)) * 24
            ) as avg_hours
            FROM tickets
            {ticket_where + (' AND' if ticket_where else 'WHERE')} status = 'done' AND completed_at IS NOT NULL
            """,
            ticket_params,
        ).fetchone()
        avg_completion_time_hours = avg_row["avg_hours"] if avg_row and avg_row["avg_hours"] else None

        # 3. Total ticket count for rate calculations
        total_row = self._conn.execute(
            f"SELECT COUNT(*) as total FROM tickets {ticket_where}",
            ticket_params,
        ).fetchone()
        total_tickets = total_row["total"] if total_row else 0

        # 4. Retry rate
        retry_row = self._conn.execute(
            f"SELECT COUNT(*) as cnt FROM tickets {ticket_where + (' AND' if ticket_where else 'WHERE')} retry_count > 0",
            ticket_params,
        ).fetchone()
        retry_count_val = retry_row["cnt"] if retry_row else 0
        retry_rate = (retry_count_val / total_tickets) if total_tickets > 0 else 0.0

        # 5. Escalation rate (human_escalation)
        esc_row = self._conn.execute(
            f"SELECT COUNT(*) as cnt FROM tickets {ticket_where + (' AND' if ticket_where else 'WHERE')} escalation_level = 'human_escalation'",
            ticket_params,
        ).fetchone()
        esc_count = esc_row["cnt"] if esc_row else 0
        escalation_rate = (esc_count / total_tickets) if total_tickets > 0 else 0.0

        # 6. Total cost
        cost_row = self._conn.execute(
            f"SELECT COALESCE(SUM(cost_usd), 0) as total FROM cost_log {cost_where}",
            cost_params,
        ).fetchone()
        total_cost_usd = cost_row["total"] if cost_row else 0.0

        # 7. Cost by agent
        cost_by_agent_rows = self._conn.execute(
            f"SELECT agent_type, SUM(cost_usd) as total FROM cost_log {cost_where} GROUP BY agent_type",
            cost_params,
        ).fetchall()
        cost_by_agent = {r["agent_type"]: r["total"] for r in cost_by_agent_rows}

        # 8. Throughput per day (completed tickets / number of distinct days with completed tickets)
        throughput_row = self._conn.execute(
            f"""
            SELECT
                COUNT(*) as completed_count,
                CAST(
                    MAX(1, julianday(MAX(completed_at)) - julianday(MIN(created_at)))
                AS REAL) as span_days
            FROM tickets
            {ticket_where + (' AND' if ticket_where else 'WHERE')} status = 'done' AND completed_at IS NOT NULL
            """,
            ticket_params,
        ).fetchone()
        if throughput_row and throughput_row["completed_count"] and throughput_row["span_days"]:
            throughput_per_day = throughput_row["completed_count"] / throughput_row["span_days"]
        else:
            throughput_per_day = 0.0

        return {
            "tickets_by_status": tickets_by_status,
            "avg_completion_time_hours": avg_completion_time_hours,
            "retry_rate": round(retry_rate, 4),
            "escalation_rate": round(escalation_rate, 4),
            "total_cost_usd": round(total_cost_usd, 6),
            "cost_by_agent": cost_by_agent,
            "throughput_per_day": round(throughput_per_day, 2),
        }
