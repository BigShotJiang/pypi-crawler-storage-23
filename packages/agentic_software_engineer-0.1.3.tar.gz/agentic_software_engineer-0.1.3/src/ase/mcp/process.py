"""
MCP Process Manager -- launch MCP servers as subprocesses and connect
them to the MCPBridge via stdio transport.

Each server is started as a child process (stdin/stdout JSON-RPC).
The ``MCPProcessManager`` handles:
- Spawning processes with the correct db_path env var
- Creating ``ClientSession`` instances over stdio
- Connecting them to the ``MCPBridge``
- Clean shutdown with graceful + forced kill
"""

from __future__ import annotations

import asyncio
import logging
import os
import sys
from pathlib import Path
from typing import Any

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

from ase.agents.bridge import MCPBridge
from ase.config.schema import ASEConfig

logger = logging.getLogger(__name__)


class MCPProcessManager:
    """Manages MCP server subprocesses and their bridge connections.

    Parameters
    ----------
    config:
        ASE configuration (for MCP commands and project paths).
    bridge:
        The ``MCPBridge`` that will receive the connected sessions.
    """

    def __init__(self, config: ASEConfig, bridge: MCPBridge) -> None:
        self._config = config
        self._bridge = bridge

        # Context managers returned by stdio_client (needed for cleanup)
        self._stdio_contexts: dict[str, Any] = {}
        # Session contexts from __aenter__
        self._session_contexts: dict[str, Any] = {}
        # Active read/write streams
        self._streams: dict[str, tuple[Any, Any]] = {}

        self._running = False

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Launch both MCP servers and connect them to the bridge."""
        if self._running:
            logger.warning("MCP processes already running")
            return

        db_path = str(self._config.project.db_path)
        python_exe = sys.executable

        # Launch Operativo
        await self._launch_server(
            name="operativo",
            command=python_exe,
            args=["-m", "ase.mcp.operativo.server", db_path],
            env={"ASE_DB_PATH": db_path},
        )

        # Launch Statico
        statico_db = str(self._config.project.db_path.parent / "statico.db")
        await self._launch_server(
            name="statico",
            command=python_exe,
            args=["-m", "ase.mcp.statico.server"],
            env={"ASE_STATICO_DB": statico_db},
        )

        self._running = True
        logger.info(
            "MCP servers started (operativo + statico), bridge has %d tools",
            len(self._bridge.registered_tools),
        )

    async def stop(self) -> None:
        """Disconnect all servers and terminate subprocesses."""
        if not self._running:
            return

        logger.info("Stopping MCP servers...")
        await self._bridge.disconnect_all()

        # The stdio_client context managers handle process cleanup
        # We trigger this by exiting the async context managers
        for name in list(self._session_contexts.keys()):
            try:
                ctx = self._session_contexts.pop(name)
                await ctx.__aexit__(None, None, None)
            except Exception as exc:
                logger.warning("Error closing session for '%s': %s", name, exc)

        for name in list(self._stdio_contexts.keys()):
            try:
                ctx = self._stdio_contexts.pop(name)
                await ctx.__aexit__(None, None, None)
            except Exception as exc:
                logger.warning("Error closing stdio for '%s': %s", name, exc)

        self._streams.clear()
        self._running = False
        logger.info("MCP servers stopped")

    @property
    def is_running(self) -> bool:
        return self._running

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    # Environment variables that are safe to pass to MCP subprocesses.
    _ENV_ALLOWLIST = {
        "PATH", "PATHEXT", "SYSTEMROOT", "TEMP", "TMP",  # Windows essentials
        "HOME", "USER", "LANG", "LC_ALL", "LC_CTYPE",     # POSIX essentials
        "PYTHONPATH", "PYTHONHOME", "VIRTUAL_ENV",          # Python
        "COMSPEC", "WINDIR",                                 # Windows shell
    }

    async def _launch_server(
        self,
        name: str,
        command: str,
        args: list[str],
        env: dict[str, str] | None = None,
    ) -> None:
        """Launch a single MCP server subprocess and connect to the bridge."""
        # Build minimal environment: only allowlisted vars + explicit overrides.
        # This prevents leaking API keys, cloud credentials, etc.
        server_env = {
            k: v for k, v in os.environ.items()
            if k in self._ENV_ALLOWLIST
        }
        if env:
            server_env.update(env)

        server_params = StdioServerParameters(
            command=command,
            args=args,
            env=server_env,
        )

        logger.info("Launching MCP server '%s': %s %s", name, command, " ".join(args))

        # stdio_client returns an async context manager yielding (read, write)
        stdio_ctx = stdio_client(server_params)
        streams = await stdio_ctx.__aenter__()
        self._stdio_contexts[name] = stdio_ctx

        read_stream, write_stream = streams

        # Create a ClientSession over the streams
        session_ctx = ClientSession(read_stream, write_stream)
        session = await session_ctx.__aenter__()
        self._session_contexts[name] = session_ctx

        # Initialize the session (JSON-RPC handshake)
        await session.initialize()

        # Register in the bridge (discovers and indexes all tools)
        await self._bridge.connect(name, session)

        logger.info("MCP server '%s' connected and tools indexed", name)
