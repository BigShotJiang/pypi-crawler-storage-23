"""MCP Statico server -- stable reference data over stdio transport.

Run as:  python -m ase.mcp.statico.server
"""

from __future__ import annotations

import os
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from .db import StaticoDB
from .models import (
    AccessRegistry,
    APIContract,
    Architecture,
    Blueprint,
    CompanyProfile,
    Conventions,
    DataSchema,
    DomainModel,
    Environment,
    ExternalDependency,
    KnowledgeEntry,
    Service,
    TeamMember,
    TechStack,
)

# ---------------------------------------------------------------------------
# Initialisation
# ---------------------------------------------------------------------------

mcp = FastMCP("ase-statico", instructions=(
    "MCP Statico: read/write stable reference data -- company profile, team, "
    "tech stack, architecture, services, API contracts, conventions, "
    "environments, blueprints, access registry, domain model, "
    "external dependencies, data schemas, and knowledge base."
))

_db_path = Path(os.environ.get("ASE_STATICO_DB", Path(__file__).resolve().parent / "statico.db"))
_db = StaticoDB(_db_path)

# ---------------------------------------------------------------------------
# Company profile
# ---------------------------------------------------------------------------


@mcp.tool()
def get_company_profile() -> dict:
    """Return the company profile (name, purpose, domain)."""
    profile = _db.get_company_profile()
    if profile is None:
        return {"error": "Company profile not set."}
    return profile.model_dump()


@mcp.tool()
def set_company_profile(name: str, purpose: str = "", domain: str = "") -> dict:
    """Create or update the company profile."""
    profile = CompanyProfile(name=name, purpose=purpose, domain=domain)
    return _db.set_company_profile(profile).model_dump()


# ---------------------------------------------------------------------------
# Team
# ---------------------------------------------------------------------------


@mcp.tool()
def add_team_member(
    id: str,
    name: str,
    role: str,
    responsibilities: list[str] | None = None,
    reports_to: str | None = None,
    communication_channels: dict[str, str] | None = None,
    department: str = "",
    title: str = "",
    email: str = "",
    location: str = "",
    skills: list[str] | None = None,
    availability: str = "",
    notes: str = "",
) -> dict:
    """Add or update a team member."""
    member = TeamMember(
        id=id,
        name=name,
        role=role,
        responsibilities=responsibilities or [],
        reports_to=reports_to,
        communication_channels=communication_channels or {},
        department=department,
        title=title,
        email=email,
        location=location,
        skills=skills or [],
        availability=availability,
        notes=notes,
    )
    return _db.add_team_member(member).model_dump()


@mcp.tool()
def get_team() -> list[dict]:
    """Return every team member."""
    return [m.model_dump() for m in _db.get_team()]


@mcp.tool()
def get_team_member(member_id: str) -> dict:
    """Return a single team member by id."""
    member = _db.get_team_member(member_id)
    if member is None:
        return {"error": f"Team member '{member_id}' not found."}
    return member.model_dump()


# ---------------------------------------------------------------------------
# Tech stack
# ---------------------------------------------------------------------------


@mcp.tool()
def get_tech_stack() -> dict:
    """Return the tech stack."""
    stack = _db.get_tech_stack()
    if stack is None:
        return {"error": "Tech stack not set."}
    return stack.model_dump()


@mcp.tool()
def set_tech_stack(
    languages: list[str] | None = None,
    frameworks: list[str] | None = None,
    databases: list[str] | None = None,
    cloud_provider: str = "",
    ci_cd: str = "",
    monitoring: str = "",
    additional: dict[str, str] | None = None,
) -> dict:
    """Create or replace the tech stack definition."""
    stack = TechStack(
        languages=languages or [],
        frameworks=frameworks or [],
        databases=databases or [],
        cloud_provider=cloud_provider,
        ci_cd=ci_cd,
        monitoring=monitoring,
        additional=additional or {},
    )
    return _db.set_tech_stack(stack).model_dump()


# ---------------------------------------------------------------------------
# Architecture
# ---------------------------------------------------------------------------


@mcp.tool()
def get_architecture() -> dict:
    """Return the architecture description."""
    arch = _db.get_architecture()
    if arch is None:
        return {"error": "Architecture not set."}
    return arch.model_dump()


@mcp.tool()
def set_architecture(
    type: str = "",
    description: str = "",
    data_flow: str = "",
    diagrams: list[str] | None = None,
    decisions: list[dict] | None = None,
    components: list[dict] | None = None,
    constraints: list[str] | None = None,
    principles: list[str] | None = None,
) -> dict:
    """Create or replace the architecture description."""
    arch = Architecture(
        type=type,
        description=description,
        data_flow=data_flow,
        diagrams=diagrams or [],
        decisions=decisions or [],
        components=components or [],
        constraints=constraints or [],
        principles=principles or [],
    )
    return _db.set_architecture(arch).model_dump()


# ---------------------------------------------------------------------------
# Services
# ---------------------------------------------------------------------------


@mcp.tool()
def add_service(
    id: str,
    name: str,
    description: str = "",
    repo_url: str = "",
    tech: list[str] | None = None,
    owner: str | None = None,
) -> dict:
    """Add or update a service."""
    svc = Service(
        id=id,
        name=name,
        description=description,
        repo_url=repo_url,
        tech=tech or [],
        owner=owner,
    )
    return _db.add_service(svc).model_dump()


# ---------------------------------------------------------------------------
# API contracts
# ---------------------------------------------------------------------------


@mcp.tool()
def get_api_contracts(service_id: str | None = None) -> list[dict]:
    """Return API contracts, optionally filtered by service_id."""
    return [c.model_dump() for c in _db.get_api_contracts(service_id)]


@mcp.tool()
def add_api_contract(
    id: str,
    service_id: str,
    endpoint: str,
    method: str = "GET",
    request_schema: dict | None = None,
    response_schema: dict | None = None,
    description: str = "",
    version: str = "v1",
) -> dict:
    """Add or update an API contract."""
    contract = APIContract(
        id=id,
        service_id=service_id,
        endpoint=endpoint,
        method=method,
        request_schema=request_schema,
        response_schema=response_schema,
        description=description,
        version=version,
    )
    return _db.add_api_contract(contract).model_dump()


# ---------------------------------------------------------------------------
# Conventions
# ---------------------------------------------------------------------------


@mcp.tool()
def get_conventions() -> dict:
    """Return engineering conventions."""
    conv = _db.get_conventions()
    if conv is None:
        return {"error": "Conventions not set."}
    return conv.model_dump()


@mcp.tool()
def set_conventions(
    branching_strategy: str = "",
    naming_conventions: dict[str, str] | None = None,
    code_style: str = "",
    testing_strategy: str = "",
    pr_review_process: str = "",
    deploy_pipeline: str = "",
    additional: dict[str, str] | None = None,
) -> dict:
    """Create or replace engineering conventions."""
    conv = Conventions(
        branching_strategy=branching_strategy,
        naming_conventions=naming_conventions or {},
        code_style=code_style,
        testing_strategy=testing_strategy,
        pr_review_process=pr_review_process,
        deploy_pipeline=deploy_pipeline,
        additional=additional or {},
    )
    return _db.set_conventions(conv).model_dump()


# ---------------------------------------------------------------------------
# Environments
# ---------------------------------------------------------------------------


@mcp.tool()
def get_environments() -> list[dict]:
    """Return all deployment environments."""
    return [e.model_dump() for e in _db.get_environments()]


@mcp.tool()
def set_environment(
    name: str,
    config: dict[str, str] | None = None,
    url: str = "",
    description: str = "",
    cloud_region: str = "",
    infra_notes: str = "",
    monitoring_url: str = "",
    access_level: str = "",
    services_deployed: list[str] | None = None,
) -> dict:
    """Create or update a deployment environment."""
    env = Environment(
        name=name,
        config=config or {},
        url=url,
        description=description,
        cloud_region=cloud_region,
        infra_notes=infra_notes,
        monitoring_url=monitoring_url,
        access_level=access_level,
        services_deployed=services_deployed or [],
    )
    return _db.set_environment(env).model_dump()


# ---------------------------------------------------------------------------
# Blueprints
# ---------------------------------------------------------------------------


@mcp.tool()
def get_blueprints() -> list[dict]:
    """Return all blueprints."""
    return [b.model_dump() for b in _db.get_blueprints()]


@mcp.tool()
def get_blueprint(blueprint_id: str) -> dict:
    """Return a single blueprint by id."""
    bp = _db.get_blueprint(blueprint_id)
    if bp is None:
        return {"error": f"Blueprint '{blueprint_id}' not found."}
    return bp.model_dump()


@mcp.tool()
def add_blueprint(
    id: str,
    name: str,
    description: str = "",
    template: dict | None = None,
    agent_sequence: list[str] | None = None,
) -> dict:
    """Add or update a blueprint."""
    bp = Blueprint(
        id=id,
        name=name,
        description=description,
        template=template or {},
        agent_sequence=agent_sequence or [],
    )
    return _db.add_blueprint(bp).model_dump()


# ---------------------------------------------------------------------------
# Access Registry
# ---------------------------------------------------------------------------


@mcp.tool()
def add_access_registry(
    id: str,
    system_name: str,
    system_type: str = "",
    url: str = "",
    auth_method: str = "",
    auth_reference: str = "",
    owner: str | None = None,
    notes: str = "",
    tags: list[str] | None = None,
) -> dict:
    """Add or update an access registry entry (system access metadata, not secrets)."""
    entry = AccessRegistry(
        id=id,
        system_name=system_name,
        system_type=system_type,
        url=url,
        auth_method=auth_method,
        auth_reference=auth_reference,
        owner=owner,
        notes=notes,
        tags=tags or [],
    )
    return _db.add_access_registry(entry).model_dump()


@mcp.tool()
def get_access_registry_entries() -> list[dict]:
    """Return all access registry entries."""
    return [e.model_dump() for e in _db.get_access_registry_entries()]


@mcp.tool()
def get_access_registry(entry_id: str) -> dict:
    """Return a single access registry entry by id."""
    entry = _db.get_access_registry_entry(entry_id)
    if entry is None:
        return {"error": f"Access registry entry '{entry_id}' not found."}
    return entry.model_dump()


# ---------------------------------------------------------------------------
# Domain Model
# ---------------------------------------------------------------------------


@mcp.tool()
def get_domain_model() -> dict:
    """Return the domain model (ubiquitous language, entities, business rules, bounded contexts)."""
    dm = _db.get_domain_model()
    if dm is None:
        return {"error": "Domain model not set."}
    return dm.model_dump()


@mcp.tool()
def set_domain_model(
    description: str = "",
    ubiquitous_language: dict[str, str] | None = None,
    entities: list[dict] | None = None,
    business_rules: list[dict] | None = None,
    bounded_contexts: list[dict] | None = None,
) -> dict:
    """Create or replace the domain model."""
    dm = DomainModel(
        description=description,
        ubiquitous_language=ubiquitous_language or {},
        entities=entities or [],
        business_rules=business_rules or [],
        bounded_contexts=bounded_contexts or [],
    )
    return _db.set_domain_model(dm).model_dump()


# ---------------------------------------------------------------------------
# External Dependencies
# ---------------------------------------------------------------------------


@mcp.tool()
def add_external_dependency(
    id: str,
    name: str,
    category: str = "",
    description: str = "",
    api_url: str = "",
    docs_url: str = "",
    auth_reference: str = "",
    rate_limits: dict[str, str] | None = None,
    sla: str = "",
    contract_notes: str = "",
    owner: str | None = None,
    tags: list[str] | None = None,
) -> dict:
    """Add or update an external dependency (third-party integration)."""
    dep = ExternalDependency(
        id=id,
        name=name,
        category=category,
        description=description,
        api_url=api_url,
        docs_url=docs_url,
        auth_reference=auth_reference,
        rate_limits=rate_limits or {},
        sla=sla,
        contract_notes=contract_notes,
        owner=owner,
        tags=tags or [],
    )
    return _db.add_external_dependency(dep).model_dump()


@mcp.tool()
def get_external_dependencies() -> list[dict]:
    """Return all external dependencies."""
    return [d.model_dump() for d in _db.get_external_dependencies()]


@mcp.tool()
def get_external_dependency(dep_id: str) -> dict:
    """Return a single external dependency by id."""
    dep = _db.get_external_dependency(dep_id)
    if dep is None:
        return {"error": f"External dependency '{dep_id}' not found."}
    return dep.model_dump()


# ---------------------------------------------------------------------------
# Data Schemas
# ---------------------------------------------------------------------------


@mcp.tool()
def add_data_schema(
    id: str,
    name: str,
    database_type: str = "",
    description: str = "",
    service_id: str | None = None,
    connection_reference: str = "",
    tables: list[dict] | None = None,
    migrations_tool: str = "",
    notes: str = "",
) -> dict:
    """Add or update a data schema definition."""
    schema = DataSchema(
        id=id,
        name=name,
        database_type=database_type,
        description=description,
        service_id=service_id,
        connection_reference=connection_reference,
        tables=tables or [],
        migrations_tool=migrations_tool,
        notes=notes,
    )
    return _db.add_data_schema(schema).model_dump()


@mcp.tool()
def get_data_schemas() -> list[dict]:
    """Return all data schema definitions."""
    return [s.model_dump() for s in _db.get_data_schemas()]


@mcp.tool()
def get_data_schema(schema_id: str) -> dict:
    """Return a single data schema by id."""
    schema = _db.get_data_schema(schema_id)
    if schema is None:
        return {"error": f"Data schema '{schema_id}' not found."}
    return schema.model_dump()


# ---------------------------------------------------------------------------
# Knowledge Base
# ---------------------------------------------------------------------------


@mcp.tool()
def add_knowledge_entry(
    id: str,
    title: str,
    category: str = "",
    content: str = "",
    related_services: list[str] | None = None,
    author: str | None = None,
    tags: list[str] | None = None,
    severity: str = "",
    created_date: str = "",
) -> dict:
    """Add or update a knowledge base entry (lesson learned, gotcha, best practice)."""
    entry = KnowledgeEntry(
        id=id,
        title=title,
        category=category,
        content=content,
        related_services=related_services or [],
        author=author,
        tags=tags or [],
        severity=severity,
        created_date=created_date,
    )
    return _db.add_knowledge_entry(entry).model_dump()


@mcp.tool()
def get_knowledge_entries() -> list[dict]:
    """Return all knowledge base entries."""
    return [e.model_dump() for e in _db.get_knowledge_entries()]


@mcp.tool()
def get_knowledge_entry(entry_id: str) -> dict:
    """Return a single knowledge base entry by id."""
    entry = _db.get_knowledge_entry(entry_id)
    if entry is None:
        return {"error": f"Knowledge entry '{entry_id}' not found."}
    return entry.model_dump()


# ---------------------------------------------------------------------------
# Full context
# ---------------------------------------------------------------------------


@mcp.tool()
def get_full_context() -> dict:
    """Return ALL reference data in a single payload."""
    return _db.get_full_context().model_dump()


# ---------------------------------------------------------------------------
# Entry point (stdio transport)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    mcp.run(transport="stdio")
