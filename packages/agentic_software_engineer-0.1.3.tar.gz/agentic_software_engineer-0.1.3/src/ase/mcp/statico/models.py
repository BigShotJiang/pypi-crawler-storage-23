"""Pydantic models for MCP Statico -- stable reference data."""

from __future__ import annotations

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Company profile (singleton)
# ---------------------------------------------------------------------------

class CompanyProfile(BaseModel):
    """Single-row company identity."""

    name: str
    purpose: str = ""
    domain: str = ""


# ---------------------------------------------------------------------------
# Team
# ---------------------------------------------------------------------------

class TeamMember(BaseModel):
    """A person in the engineering organisation."""

    id: str
    name: str
    role: str
    responsibilities: list[str] = Field(default_factory=list)
    reports_to: str | None = None
    communication_channels: dict[str, str] = Field(default_factory=dict)
    # --- expanded ---
    department: str = ""
    title: str = ""
    email: str = ""
    location: str = ""
    skills: list[str] = Field(default_factory=list)
    availability: str = ""
    notes: str = ""


# ---------------------------------------------------------------------------
# Tech stack (singleton)
# ---------------------------------------------------------------------------

class TechStack(BaseModel):
    """Technology choices for the organisation / project."""

    languages: list[str] = Field(default_factory=list)
    frameworks: list[str] = Field(default_factory=list)
    databases: list[str] = Field(default_factory=list)
    cloud_provider: str = ""
    ci_cd: str = ""
    monitoring: str = ""
    additional: dict[str, str] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Architecture (singleton)
# ---------------------------------------------------------------------------

class Architecture(BaseModel):
    """High-level architecture description."""

    type: str = ""
    description: str = ""
    data_flow: str = ""
    # --- expanded ---
    diagrams: list[str] = Field(default_factory=list)
    decisions: list[dict] = Field(default_factory=list)
    components: list[dict] = Field(default_factory=list)
    constraints: list[str] = Field(default_factory=list)
    principles: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Services & API contracts
# ---------------------------------------------------------------------------

class Service(BaseModel):
    """A deployable service / microservice."""

    id: str
    name: str
    description: str = ""
    repo_url: str = ""
    tech: list[str] = Field(default_factory=list)
    owner: str | None = None  # FK -> TeamMember.id


class APIContract(BaseModel):
    """A single REST endpoint contract for a service."""

    id: str
    service_id: str
    endpoint: str
    method: str = "GET"
    request_schema: dict | None = None
    response_schema: dict | None = None
    description: str = ""
    version: str = "v1"


# ---------------------------------------------------------------------------
# Conventions (singleton)
# ---------------------------------------------------------------------------

class Conventions(BaseModel):
    """Engineering conventions and processes."""

    branching_strategy: str = ""
    naming_conventions: dict[str, str] = Field(default_factory=dict)
    code_style: str = ""
    testing_strategy: str = ""
    pr_review_process: str = ""
    deploy_pipeline: str = ""
    additional: dict[str, str] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Environments
# ---------------------------------------------------------------------------

class Environment(BaseModel):
    """A deployment environment (PK = name)."""

    name: str  # PK
    config: dict[str, str] = Field(default_factory=dict)
    url: str = ""
    # --- expanded ---
    description: str = ""
    cloud_region: str = ""
    infra_notes: str = ""
    monitoring_url: str = ""
    access_level: str = ""
    services_deployed: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Blueprints
# ---------------------------------------------------------------------------

class Blueprint(BaseModel):
    """Reusable scaffolding / workflow blueprint."""

    id: str
    name: str
    description: str = ""
    template: dict = Field(default_factory=dict)
    agent_sequence: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Access Registry
# ---------------------------------------------------------------------------

class AccessRegistry(BaseModel):
    """Metadata about a system/tool and how to access it (no secrets)."""

    id: str
    system_name: str
    system_type: str = ""
    url: str = ""
    auth_method: str = ""
    auth_reference: str = ""
    owner: str | None = None  # FK -> TeamMember.id
    notes: str = ""
    tags: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Domain Model (singleton)
# ---------------------------------------------------------------------------

class DomainModel(BaseModel):
    """Core business domain: ubiquitous language, entities, rules, bounded contexts."""

    description: str = ""
    ubiquitous_language: dict[str, str] = Field(default_factory=dict)
    entities: list[dict] = Field(default_factory=list)
    business_rules: list[dict] = Field(default_factory=list)
    bounded_contexts: list[dict] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# External Dependencies
# ---------------------------------------------------------------------------

class ExternalDependency(BaseModel):
    """A third-party service or integration."""

    id: str
    name: str
    category: str = ""
    description: str = ""
    api_url: str = ""
    docs_url: str = ""
    auth_reference: str = ""
    rate_limits: dict[str, str] = Field(default_factory=dict)
    sla: str = ""
    contract_notes: str = ""
    owner: str | None = None  # FK -> TeamMember.id
    tags: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Data Schemas
# ---------------------------------------------------------------------------

class DataSchema(BaseModel):
    """A database schema managed by the project."""

    id: str
    name: str
    database_type: str = ""
    description: str = ""
    service_id: str | None = None  # FK -> Service.id
    connection_reference: str = ""
    tables: list[dict] = Field(default_factory=list)
    migrations_tool: str = ""
    notes: str = ""


# ---------------------------------------------------------------------------
# Knowledge Base
# ---------------------------------------------------------------------------

class KnowledgeEntry(BaseModel):
    """Tribal knowledge, lessons learned, gotchas, forbidden patterns."""

    id: str
    title: str
    category: str = ""
    content: str = ""
    related_services: list[str] = Field(default_factory=list)
    author: str | None = None  # FK -> TeamMember.id
    tags: list[str] = Field(default_factory=list)
    severity: str = ""
    created_date: str = ""


# ---------------------------------------------------------------------------
# Aggregate payload
# ---------------------------------------------------------------------------

class FullContext(BaseModel):
    """Everything MCP Statico knows, in one payload."""

    company_profile: CompanyProfile | None = None
    team: list[TeamMember] = Field(default_factory=list)
    tech_stack: TechStack | None = None
    architecture: Architecture | None = None
    services: list[Service] = Field(default_factory=list)
    api_contracts: list[APIContract] = Field(default_factory=list)
    conventions: Conventions | None = None
    environments: list[Environment] = Field(default_factory=list)
    blueprints: list[Blueprint] = Field(default_factory=list)
    access_registry: list[AccessRegistry] = Field(default_factory=list)
    domain_model: DomainModel | None = None
    external_dependencies: list[ExternalDependency] = Field(default_factory=list)
    data_schemas: list[DataSchema] = Field(default_factory=list)
    knowledge_base: list[KnowledgeEntry] = Field(default_factory=list)
