"""SQLite persistence layer for MCP Statico reference data."""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from .models import (
    AccessRegistry,
    APIContract,
    Architecture,
    Blueprint,
    CompanyProfile,
    Conventions,
    DataSchema,
    DomainModel,
    Environment,
    ExternalDependency,
    FullContext,
    KnowledgeEntry,
    Service,
    TeamMember,
    TechStack,
)

_DEFAULT_DB = Path(__file__).resolve().parent / "statico.db"


class StaticoDB:
    """Synchronous SQLite CRUD for every Statico entity."""

    def __init__(self, db_path: str | Path = _DEFAULT_DB) -> None:
        self._path = str(db_path)
        self._conn = sqlite3.connect(self._path)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._create_tables()
        self._migrate_tables()

    # ------------------------------------------------------------------
    # DDL
    # ------------------------------------------------------------------

    def _create_tables(self) -> None:
        stmts = [
            """
            CREATE TABLE IF NOT EXISTS company_profile (
                id          INTEGER PRIMARY KEY CHECK (id = 1),
                name        TEXT NOT NULL,
                purpose     TEXT NOT NULL DEFAULT '',
                domain      TEXT NOT NULL DEFAULT ''
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS team_member (
                id                      TEXT PRIMARY KEY,
                name                    TEXT NOT NULL,
                role                    TEXT NOT NULL,
                responsibilities        TEXT NOT NULL DEFAULT '[]',
                reports_to              TEXT,
                communication_channels  TEXT NOT NULL DEFAULT '{}',
                department              TEXT NOT NULL DEFAULT '',
                title                   TEXT NOT NULL DEFAULT '',
                email                   TEXT NOT NULL DEFAULT '',
                location                TEXT NOT NULL DEFAULT '',
                skills                  TEXT NOT NULL DEFAULT '[]',
                availability            TEXT NOT NULL DEFAULT '',
                notes                   TEXT NOT NULL DEFAULT ''
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS tech_stack (
                id              INTEGER PRIMARY KEY CHECK (id = 1),
                languages       TEXT NOT NULL DEFAULT '[]',
                frameworks      TEXT NOT NULL DEFAULT '[]',
                databases       TEXT NOT NULL DEFAULT '[]',
                cloud_provider  TEXT NOT NULL DEFAULT '',
                ci_cd           TEXT NOT NULL DEFAULT '',
                monitoring      TEXT NOT NULL DEFAULT '',
                additional      TEXT NOT NULL DEFAULT '{}'
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS architecture (
                id          INTEGER PRIMARY KEY CHECK (id = 1),
                type        TEXT NOT NULL DEFAULT '',
                description TEXT NOT NULL DEFAULT '',
                data_flow   TEXT NOT NULL DEFAULT '',
                diagrams    TEXT NOT NULL DEFAULT '[]',
                decisions   TEXT NOT NULL DEFAULT '[]',
                components  TEXT NOT NULL DEFAULT '[]',
                constraints TEXT NOT NULL DEFAULT '[]',
                principles  TEXT NOT NULL DEFAULT '[]'
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS service (
                id          TEXT PRIMARY KEY,
                name        TEXT NOT NULL,
                description TEXT NOT NULL DEFAULT '',
                repo_url    TEXT NOT NULL DEFAULT '',
                tech        TEXT NOT NULL DEFAULT '[]',
                owner       TEXT,
                FOREIGN KEY (owner) REFERENCES team_member(id)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS api_contract (
                id              TEXT PRIMARY KEY,
                service_id      TEXT NOT NULL,
                endpoint        TEXT NOT NULL,
                method          TEXT NOT NULL DEFAULT 'GET',
                request_schema  TEXT,
                response_schema TEXT,
                description     TEXT NOT NULL DEFAULT '',
                version         TEXT NOT NULL DEFAULT 'v1',
                FOREIGN KEY (service_id) REFERENCES service(id)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS conventions (
                id                  INTEGER PRIMARY KEY CHECK (id = 1),
                branching_strategy  TEXT NOT NULL DEFAULT '',
                naming_conventions  TEXT NOT NULL DEFAULT '{}',
                code_style          TEXT NOT NULL DEFAULT '',
                testing_strategy    TEXT NOT NULL DEFAULT '',
                pr_review_process   TEXT NOT NULL DEFAULT '',
                deploy_pipeline     TEXT NOT NULL DEFAULT '',
                additional          TEXT NOT NULL DEFAULT '{}'
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS environment (
                name              TEXT PRIMARY KEY,
                config            TEXT NOT NULL DEFAULT '{}',
                url               TEXT NOT NULL DEFAULT '',
                description       TEXT NOT NULL DEFAULT '',
                cloud_region      TEXT NOT NULL DEFAULT '',
                infra_notes       TEXT NOT NULL DEFAULT '',
                monitoring_url    TEXT NOT NULL DEFAULT '',
                access_level      TEXT NOT NULL DEFAULT '',
                services_deployed TEXT NOT NULL DEFAULT '[]'
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS blueprint (
                id              TEXT PRIMARY KEY,
                name            TEXT NOT NULL,
                description     TEXT NOT NULL DEFAULT '',
                template        TEXT NOT NULL DEFAULT '{}',
                agent_sequence  TEXT NOT NULL DEFAULT '[]'
            )
            """,
            # --- new tables ---
            """
            CREATE TABLE IF NOT EXISTS access_registry (
                id              TEXT PRIMARY KEY,
                system_name     TEXT NOT NULL,
                system_type     TEXT NOT NULL DEFAULT '',
                url             TEXT NOT NULL DEFAULT '',
                auth_method     TEXT NOT NULL DEFAULT '',
                auth_reference  TEXT NOT NULL DEFAULT '',
                owner           TEXT,
                notes           TEXT NOT NULL DEFAULT '',
                tags            TEXT NOT NULL DEFAULT '[]',
                FOREIGN KEY (owner) REFERENCES team_member(id)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS domain_model (
                id                    INTEGER PRIMARY KEY CHECK (id = 1),
                description           TEXT NOT NULL DEFAULT '',
                ubiquitous_language   TEXT NOT NULL DEFAULT '{}',
                entities              TEXT NOT NULL DEFAULT '[]',
                business_rules        TEXT NOT NULL DEFAULT '[]',
                bounded_contexts      TEXT NOT NULL DEFAULT '[]'
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS external_dependency (
                id              TEXT PRIMARY KEY,
                name            TEXT NOT NULL,
                category        TEXT NOT NULL DEFAULT '',
                description     TEXT NOT NULL DEFAULT '',
                api_url         TEXT NOT NULL DEFAULT '',
                docs_url        TEXT NOT NULL DEFAULT '',
                auth_reference  TEXT NOT NULL DEFAULT '',
                rate_limits     TEXT NOT NULL DEFAULT '{}',
                sla             TEXT NOT NULL DEFAULT '',
                contract_notes  TEXT NOT NULL DEFAULT '',
                owner           TEXT,
                tags            TEXT NOT NULL DEFAULT '[]',
                FOREIGN KEY (owner) REFERENCES team_member(id)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS data_schema (
                id                    TEXT PRIMARY KEY,
                name                  TEXT NOT NULL,
                database_type         TEXT NOT NULL DEFAULT '',
                description           TEXT NOT NULL DEFAULT '',
                service_id            TEXT,
                connection_reference  TEXT NOT NULL DEFAULT '',
                tables_def            TEXT NOT NULL DEFAULT '[]',
                migrations_tool       TEXT NOT NULL DEFAULT '',
                notes                 TEXT NOT NULL DEFAULT '',
                FOREIGN KEY (service_id) REFERENCES service(id)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS knowledge_entry (
                id                TEXT PRIMARY KEY,
                title             TEXT NOT NULL,
                category          TEXT NOT NULL DEFAULT '',
                content           TEXT NOT NULL DEFAULT '',
                related_services  TEXT NOT NULL DEFAULT '[]',
                author            TEXT,
                tags              TEXT NOT NULL DEFAULT '[]',
                severity          TEXT NOT NULL DEFAULT '',
                created_date      TEXT NOT NULL DEFAULT '',
                FOREIGN KEY (author) REFERENCES team_member(id)
            )
            """,
        ]
        with self._conn:
            for sql in stmts:
                self._conn.execute(sql)

    # ------------------------------------------------------------------
    # Migrations (backward compat for existing DBs)
    # ------------------------------------------------------------------

    def _migrate_tables(self) -> None:
        """Add columns that may be missing from older schemas."""
        migrations = [
            ("team_member", "department", "TEXT NOT NULL DEFAULT ''"),
            ("team_member", "title", "TEXT NOT NULL DEFAULT ''"),
            ("team_member", "email", "TEXT NOT NULL DEFAULT ''"),
            ("team_member", "location", "TEXT NOT NULL DEFAULT ''"),
            ("team_member", "skills", "TEXT NOT NULL DEFAULT '[]'"),
            ("team_member", "availability", "TEXT NOT NULL DEFAULT ''"),
            ("team_member", "notes", "TEXT NOT NULL DEFAULT ''"),
            ("architecture", "diagrams", "TEXT NOT NULL DEFAULT '[]'"),
            ("architecture", "decisions", "TEXT NOT NULL DEFAULT '[]'"),
            ("architecture", "components", "TEXT NOT NULL DEFAULT '[]'"),
            ("architecture", "constraints", "TEXT NOT NULL DEFAULT '[]'"),
            ("architecture", "principles", "TEXT NOT NULL DEFAULT '[]'"),
            ("environment", "description", "TEXT NOT NULL DEFAULT ''"),
            ("environment", "cloud_region", "TEXT NOT NULL DEFAULT ''"),
            ("environment", "infra_notes", "TEXT NOT NULL DEFAULT ''"),
            ("environment", "monitoring_url", "TEXT NOT NULL DEFAULT ''"),
            ("environment", "access_level", "TEXT NOT NULL DEFAULT ''"),
            ("environment", "services_deployed", "TEXT NOT NULL DEFAULT '[]'"),
        ]
        with self._conn:
            for table, column, defn in migrations:
                existing = {
                    row[1]
                    for row in self._conn.execute(
                        f"PRAGMA table_info({table})"
                    ).fetchall()
                }
                if column not in existing:
                    self._conn.execute(
                        f"ALTER TABLE {table} ADD COLUMN {column} {defn}"
                    )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _j(value: object) -> str:
        """Serialize a Python object to a JSON string for storage."""
        return json.dumps(value, ensure_ascii=False)

    @staticmethod
    def _lj(raw: str | None) -> list:
        """Load a JSON array from a stored string."""
        if not raw:
            return []
        return json.loads(raw)  # type: ignore[no-any-return]

    @staticmethod
    def _dj(raw: str | None) -> dict:
        """Load a JSON object from a stored string."""
        if not raw:
            return {}
        return json.loads(raw)  # type: ignore[no-any-return]

    @staticmethod
    def _dj_or_none(raw: str | None) -> dict | None:
        """Load a JSON object, returning None when the column is NULL."""
        if raw is None:
            return None
        return json.loads(raw)  # type: ignore[no-any-return]

    # ------------------------------------------------------------------
    # Company profile (singleton)
    # ------------------------------------------------------------------

    def get_company_profile(self) -> CompanyProfile | None:
        row = self._conn.execute("SELECT * FROM company_profile WHERE id=1").fetchone()
        if not row:
            return None
        return CompanyProfile(name=row["name"], purpose=row["purpose"], domain=row["domain"])

    def set_company_profile(self, profile: CompanyProfile) -> CompanyProfile:
        with self._conn:
            self._conn.execute(
                """
                INSERT INTO company_profile (id, name, purpose, domain) VALUES (1, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET name=excluded.name,
                    purpose=excluded.purpose, domain=excluded.domain
                """,
                (profile.name, profile.purpose, profile.domain),
            )
        return profile

    # ------------------------------------------------------------------
    # Team members
    # ------------------------------------------------------------------

    def _row_to_team_member(self, r: sqlite3.Row) -> TeamMember:
        return TeamMember(
            id=r["id"],
            name=r["name"],
            role=r["role"],
            responsibilities=self._lj(r["responsibilities"]),
            reports_to=r["reports_to"],
            communication_channels=self._dj(r["communication_channels"]),
            department=r["department"],
            title=r["title"],
            email=r["email"],
            location=r["location"],
            skills=self._lj(r["skills"]),
            availability=r["availability"],
            notes=r["notes"],
        )

    def add_team_member(self, member: TeamMember) -> TeamMember:
        with self._conn:
            self._conn.execute(
                """
                INSERT INTO team_member (id, name, role, responsibilities, reports_to,
                    communication_channels, department, title, email, location,
                    skills, availability, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    name=excluded.name, role=excluded.role,
                    responsibilities=excluded.responsibilities,
                    reports_to=excluded.reports_to,
                    communication_channels=excluded.communication_channels,
                    department=excluded.department, title=excluded.title,
                    email=excluded.email, location=excluded.location,
                    skills=excluded.skills, availability=excluded.availability,
                    notes=excluded.notes
                """,
                (
                    member.id,
                    member.name,
                    member.role,
                    self._j(member.responsibilities),
                    member.reports_to,
                    self._j(member.communication_channels),
                    member.department,
                    member.title,
                    member.email,
                    member.location,
                    self._j(member.skills),
                    member.availability,
                    member.notes,
                ),
            )
        return member

    def get_team(self) -> list[TeamMember]:
        rows = self._conn.execute("SELECT * FROM team_member ORDER BY name").fetchall()
        return [self._row_to_team_member(r) for r in rows]

    def get_team_member(self, member_id: str) -> TeamMember | None:
        row = self._conn.execute(
            "SELECT * FROM team_member WHERE id=?", (member_id,)
        ).fetchone()
        if not row:
            return None
        return self._row_to_team_member(row)

    # ------------------------------------------------------------------
    # Tech stack (singleton)
    # ------------------------------------------------------------------

    def get_tech_stack(self) -> TechStack | None:
        row = self._conn.execute("SELECT * FROM tech_stack WHERE id=1").fetchone()
        if not row:
            return None
        return TechStack(
            languages=self._lj(row["languages"]),
            frameworks=self._lj(row["frameworks"]),
            databases=self._lj(row["databases"]),
            cloud_provider=row["cloud_provider"],
            ci_cd=row["ci_cd"],
            monitoring=row["monitoring"],
            additional=self._dj(row["additional"]),
        )

    def set_tech_stack(self, stack: TechStack) -> TechStack:
        with self._conn:
            self._conn.execute(
                """
                INSERT INTO tech_stack (id, languages, frameworks, databases,
                    cloud_provider, ci_cd, monitoring, additional)
                VALUES (1, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    languages=excluded.languages, frameworks=excluded.frameworks,
                    databases=excluded.databases, cloud_provider=excluded.cloud_provider,
                    ci_cd=excluded.ci_cd, monitoring=excluded.monitoring,
                    additional=excluded.additional
                """,
                (
                    self._j(stack.languages),
                    self._j(stack.frameworks),
                    self._j(stack.databases),
                    stack.cloud_provider,
                    stack.ci_cd,
                    stack.monitoring,
                    self._j(stack.additional),
                ),
            )
        return stack

    # ------------------------------------------------------------------
    # Architecture (singleton)
    # ------------------------------------------------------------------

    def get_architecture(self) -> Architecture | None:
        row = self._conn.execute("SELECT * FROM architecture WHERE id=1").fetchone()
        if not row:
            return None
        return Architecture(
            type=row["type"],
            description=row["description"],
            data_flow=row["data_flow"],
            diagrams=self._lj(row["diagrams"]),
            decisions=self._lj(row["decisions"]),
            components=self._lj(row["components"]),
            constraints=self._lj(row["constraints"]),
            principles=self._lj(row["principles"]),
        )

    def set_architecture(self, arch: Architecture) -> Architecture:
        with self._conn:
            self._conn.execute(
                """
                INSERT INTO architecture (id, type, description, data_flow,
                    diagrams, decisions, components, constraints, principles)
                VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    type=excluded.type, description=excluded.description,
                    data_flow=excluded.data_flow, diagrams=excluded.diagrams,
                    decisions=excluded.decisions, components=excluded.components,
                    constraints=excluded.constraints, principles=excluded.principles
                """,
                (
                    arch.type,
                    arch.description,
                    arch.data_flow,
                    self._j(arch.diagrams),
                    self._j(arch.decisions),
                    self._j(arch.components),
                    self._j(arch.constraints),
                    self._j(arch.principles),
                ),
            )
        return arch

    # ------------------------------------------------------------------
    # Services
    # ------------------------------------------------------------------

    def add_service(self, svc: Service) -> Service:
        with self._conn:
            self._conn.execute(
                """
                INSERT INTO service (id, name, description, repo_url, tech, owner)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    name=excluded.name, description=excluded.description,
                    repo_url=excluded.repo_url, tech=excluded.tech, owner=excluded.owner
                """,
                (svc.id, svc.name, svc.description, svc.repo_url, self._j(svc.tech), svc.owner),
            )
        return svc

    def get_services(self) -> list[Service]:
        rows = self._conn.execute("SELECT * FROM service ORDER BY name").fetchall()
        return [
            Service(
                id=r["id"],
                name=r["name"],
                description=r["description"],
                repo_url=r["repo_url"],
                tech=self._lj(r["tech"]),
                owner=r["owner"],
            )
            for r in rows
        ]

    # ------------------------------------------------------------------
    # API contracts
    # ------------------------------------------------------------------

    def add_api_contract(self, contract: APIContract) -> APIContract:
        with self._conn:
            self._conn.execute(
                """
                INSERT INTO api_contract (id, service_id, endpoint, method,
                    request_schema, response_schema, description, version)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    service_id=excluded.service_id, endpoint=excluded.endpoint,
                    method=excluded.method, request_schema=excluded.request_schema,
                    response_schema=excluded.response_schema,
                    description=excluded.description, version=excluded.version
                """,
                (
                    contract.id,
                    contract.service_id,
                    contract.endpoint,
                    contract.method,
                    self._j(contract.request_schema) if contract.request_schema else None,
                    self._j(contract.response_schema) if contract.response_schema else None,
                    contract.description,
                    contract.version,
                ),
            )
        return contract

    def get_api_contracts(self, service_id: str | None = None) -> list[APIContract]:
        if service_id:
            rows = self._conn.execute(
                "SELECT * FROM api_contract WHERE service_id=? ORDER BY endpoint",
                (service_id,),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM api_contract ORDER BY service_id, endpoint"
            ).fetchall()
        return [
            APIContract(
                id=r["id"],
                service_id=r["service_id"],
                endpoint=r["endpoint"],
                method=r["method"],
                request_schema=self._dj_or_none(r["request_schema"]),
                response_schema=self._dj_or_none(r["response_schema"]),
                description=r["description"],
                version=r["version"],
            )
            for r in rows
        ]

    # ------------------------------------------------------------------
    # Conventions (singleton)
    # ------------------------------------------------------------------

    def get_conventions(self) -> Conventions | None:
        row = self._conn.execute("SELECT * FROM conventions WHERE id=1").fetchone()
        if not row:
            return None
        return Conventions(
            branching_strategy=row["branching_strategy"],
            naming_conventions=self._dj(row["naming_conventions"]),
            code_style=row["code_style"],
            testing_strategy=row["testing_strategy"],
            pr_review_process=row["pr_review_process"],
            deploy_pipeline=row["deploy_pipeline"],
            additional=self._dj(row["additional"]),
        )

    def set_conventions(self, conv: Conventions) -> Conventions:
        with self._conn:
            self._conn.execute(
                """
                INSERT INTO conventions (id, branching_strategy, naming_conventions,
                    code_style, testing_strategy, pr_review_process, deploy_pipeline,
                    additional)
                VALUES (1, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    branching_strategy=excluded.branching_strategy,
                    naming_conventions=excluded.naming_conventions,
                    code_style=excluded.code_style,
                    testing_strategy=excluded.testing_strategy,
                    pr_review_process=excluded.pr_review_process,
                    deploy_pipeline=excluded.deploy_pipeline,
                    additional=excluded.additional
                """,
                (
                    conv.branching_strategy,
                    self._j(conv.naming_conventions),
                    conv.code_style,
                    conv.testing_strategy,
                    conv.pr_review_process,
                    conv.deploy_pipeline,
                    self._j(conv.additional),
                ),
            )
        return conv

    # ------------------------------------------------------------------
    # Environments (PK = name)
    # ------------------------------------------------------------------

    def get_environments(self) -> list[Environment]:
        rows = self._conn.execute("SELECT * FROM environment ORDER BY name").fetchall()
        return [
            Environment(
                name=r["name"],
                config=self._dj(r["config"]),
                url=r["url"],
                description=r["description"],
                cloud_region=r["cloud_region"],
                infra_notes=r["infra_notes"],
                monitoring_url=r["monitoring_url"],
                access_level=r["access_level"],
                services_deployed=self._lj(r["services_deployed"]),
            )
            for r in rows
        ]

    def set_environment(self, env: Environment) -> Environment:
        with self._conn:
            self._conn.execute(
                """
                INSERT INTO environment (name, config, url, description, cloud_region,
                    infra_notes, monitoring_url, access_level, services_deployed)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(name) DO UPDATE SET
                    config=excluded.config, url=excluded.url,
                    description=excluded.description, cloud_region=excluded.cloud_region,
                    infra_notes=excluded.infra_notes, monitoring_url=excluded.monitoring_url,
                    access_level=excluded.access_level,
                    services_deployed=excluded.services_deployed
                """,
                (
                    env.name,
                    self._j(env.config),
                    env.url,
                    env.description,
                    env.cloud_region,
                    env.infra_notes,
                    env.monitoring_url,
                    env.access_level,
                    self._j(env.services_deployed),
                ),
            )
        return env

    # ------------------------------------------------------------------
    # Blueprints
    # ------------------------------------------------------------------

    def add_blueprint(self, bp: Blueprint) -> Blueprint:
        with self._conn:
            self._conn.execute(
                """
                INSERT INTO blueprint (id, name, description, template, agent_sequence)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    name=excluded.name, description=excluded.description,
                    template=excluded.template, agent_sequence=excluded.agent_sequence
                """,
                (bp.id, bp.name, bp.description, self._j(bp.template), self._j(bp.agent_sequence)),
            )
        return bp

    def get_blueprints(self) -> list[Blueprint]:
        rows = self._conn.execute("SELECT * FROM blueprint ORDER BY name").fetchall()
        return [
            Blueprint(
                id=r["id"],
                name=r["name"],
                description=r["description"],
                template=self._dj(r["template"]),
                agent_sequence=self._lj(r["agent_sequence"]),
            )
            for r in rows
        ]

    def get_blueprint(self, blueprint_id: str) -> Blueprint | None:
        row = self._conn.execute(
            "SELECT * FROM blueprint WHERE id=?", (blueprint_id,)
        ).fetchone()
        if not row:
            return None
        return Blueprint(
            id=row["id"],
            name=row["name"],
            description=row["description"],
            template=self._dj(row["template"]),
            agent_sequence=self._lj(row["agent_sequence"]),
        )

    # ------------------------------------------------------------------
    # Access Registry
    # ------------------------------------------------------------------

    def add_access_registry(self, entry: AccessRegistry) -> AccessRegistry:
        with self._conn:
            self._conn.execute(
                """
                INSERT INTO access_registry (id, system_name, system_type, url,
                    auth_method, auth_reference, owner, notes, tags)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    system_name=excluded.system_name, system_type=excluded.system_type,
                    url=excluded.url, auth_method=excluded.auth_method,
                    auth_reference=excluded.auth_reference, owner=excluded.owner,
                    notes=excluded.notes, tags=excluded.tags
                """,
                (
                    entry.id,
                    entry.system_name,
                    entry.system_type,
                    entry.url,
                    entry.auth_method,
                    entry.auth_reference,
                    entry.owner,
                    entry.notes,
                    self._j(entry.tags),
                ),
            )
        return entry

    def get_access_registry_entries(self) -> list[AccessRegistry]:
        rows = self._conn.execute(
            "SELECT * FROM access_registry ORDER BY system_name"
        ).fetchall()
        return [
            AccessRegistry(
                id=r["id"],
                system_name=r["system_name"],
                system_type=r["system_type"],
                url=r["url"],
                auth_method=r["auth_method"],
                auth_reference=r["auth_reference"],
                owner=r["owner"],
                notes=r["notes"],
                tags=self._lj(r["tags"]),
            )
            for r in rows
        ]

    def get_access_registry_entry(self, entry_id: str) -> AccessRegistry | None:
        row = self._conn.execute(
            "SELECT * FROM access_registry WHERE id=?", (entry_id,)
        ).fetchone()
        if not row:
            return None
        return AccessRegistry(
            id=row["id"],
            system_name=row["system_name"],
            system_type=row["system_type"],
            url=row["url"],
            auth_method=row["auth_method"],
            auth_reference=row["auth_reference"],
            owner=row["owner"],
            notes=row["notes"],
            tags=self._lj(row["tags"]),
        )

    # ------------------------------------------------------------------
    # Domain Model (singleton)
    # ------------------------------------------------------------------

    def get_domain_model(self) -> DomainModel | None:
        row = self._conn.execute("SELECT * FROM domain_model WHERE id=1").fetchone()
        if not row:
            return None
        return DomainModel(
            description=row["description"],
            ubiquitous_language=self._dj(row["ubiquitous_language"]),
            entities=self._lj(row["entities"]),
            business_rules=self._lj(row["business_rules"]),
            bounded_contexts=self._lj(row["bounded_contexts"]),
        )

    def set_domain_model(self, dm: DomainModel) -> DomainModel:
        with self._conn:
            self._conn.execute(
                """
                INSERT INTO domain_model (id, description, ubiquitous_language,
                    entities, business_rules, bounded_contexts)
                VALUES (1, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    description=excluded.description,
                    ubiquitous_language=excluded.ubiquitous_language,
                    entities=excluded.entities,
                    business_rules=excluded.business_rules,
                    bounded_contexts=excluded.bounded_contexts
                """,
                (
                    dm.description,
                    self._j(dm.ubiquitous_language),
                    self._j(dm.entities),
                    self._j(dm.business_rules),
                    self._j(dm.bounded_contexts),
                ),
            )
        return dm

    # ------------------------------------------------------------------
    # External Dependencies
    # ------------------------------------------------------------------

    def add_external_dependency(self, dep: ExternalDependency) -> ExternalDependency:
        with self._conn:
            self._conn.execute(
                """
                INSERT INTO external_dependency (id, name, category, description,
                    api_url, docs_url, auth_reference, rate_limits, sla,
                    contract_notes, owner, tags)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    name=excluded.name, category=excluded.category,
                    description=excluded.description, api_url=excluded.api_url,
                    docs_url=excluded.docs_url, auth_reference=excluded.auth_reference,
                    rate_limits=excluded.rate_limits, sla=excluded.sla,
                    contract_notes=excluded.contract_notes, owner=excluded.owner,
                    tags=excluded.tags
                """,
                (
                    dep.id,
                    dep.name,
                    dep.category,
                    dep.description,
                    dep.api_url,
                    dep.docs_url,
                    dep.auth_reference,
                    self._j(dep.rate_limits),
                    dep.sla,
                    dep.contract_notes,
                    dep.owner,
                    self._j(dep.tags),
                ),
            )
        return dep

    def get_external_dependencies(self) -> list[ExternalDependency]:
        rows = self._conn.execute(
            "SELECT * FROM external_dependency ORDER BY name"
        ).fetchall()
        return [
            ExternalDependency(
                id=r["id"],
                name=r["name"],
                category=r["category"],
                description=r["description"],
                api_url=r["api_url"],
                docs_url=r["docs_url"],
                auth_reference=r["auth_reference"],
                rate_limits=self._dj(r["rate_limits"]),
                sla=r["sla"],
                contract_notes=r["contract_notes"],
                owner=r["owner"],
                tags=self._lj(r["tags"]),
            )
            for r in rows
        ]

    def get_external_dependency(self, dep_id: str) -> ExternalDependency | None:
        row = self._conn.execute(
            "SELECT * FROM external_dependency WHERE id=?", (dep_id,)
        ).fetchone()
        if not row:
            return None
        return ExternalDependency(
            id=row["id"],
            name=row["name"],
            category=row["category"],
            description=row["description"],
            api_url=row["api_url"],
            docs_url=row["docs_url"],
            auth_reference=row["auth_reference"],
            rate_limits=self._dj(row["rate_limits"]),
            sla=row["sla"],
            contract_notes=row["contract_notes"],
            owner=row["owner"],
            tags=self._lj(row["tags"]),
        )

    # ------------------------------------------------------------------
    # Data Schemas
    # ------------------------------------------------------------------

    def add_data_schema(self, schema: DataSchema) -> DataSchema:
        with self._conn:
            self._conn.execute(
                """
                INSERT INTO data_schema (id, name, database_type, description,
                    service_id, connection_reference, tables_def, migrations_tool, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    name=excluded.name, database_type=excluded.database_type,
                    description=excluded.description, service_id=excluded.service_id,
                    connection_reference=excluded.connection_reference,
                    tables_def=excluded.tables_def,
                    migrations_tool=excluded.migrations_tool, notes=excluded.notes
                """,
                (
                    schema.id,
                    schema.name,
                    schema.database_type,
                    schema.description,
                    schema.service_id,
                    schema.connection_reference,
                    self._j(schema.tables),
                    schema.migrations_tool,
                    schema.notes,
                ),
            )
        return schema

    def get_data_schemas(self) -> list[DataSchema]:
        rows = self._conn.execute(
            "SELECT * FROM data_schema ORDER BY name"
        ).fetchall()
        return [
            DataSchema(
                id=r["id"],
                name=r["name"],
                database_type=r["database_type"],
                description=r["description"],
                service_id=r["service_id"],
                connection_reference=r["connection_reference"],
                tables=self._lj(r["tables_def"]),
                migrations_tool=r["migrations_tool"],
                notes=r["notes"],
            )
            for r in rows
        ]

    def get_data_schema(self, schema_id: str) -> DataSchema | None:
        row = self._conn.execute(
            "SELECT * FROM data_schema WHERE id=?", (schema_id,)
        ).fetchone()
        if not row:
            return None
        return DataSchema(
            id=row["id"],
            name=row["name"],
            database_type=row["database_type"],
            description=row["description"],
            service_id=row["service_id"],
            connection_reference=row["connection_reference"],
            tables=self._lj(row["tables_def"]),
            migrations_tool=row["migrations_tool"],
            notes=row["notes"],
        )

    # ------------------------------------------------------------------
    # Knowledge Base
    # ------------------------------------------------------------------

    def add_knowledge_entry(self, entry: KnowledgeEntry) -> KnowledgeEntry:
        with self._conn:
            self._conn.execute(
                """
                INSERT INTO knowledge_entry (id, title, category, content,
                    related_services, author, tags, severity, created_date)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    title=excluded.title, category=excluded.category,
                    content=excluded.content, related_services=excluded.related_services,
                    author=excluded.author, tags=excluded.tags,
                    severity=excluded.severity, created_date=excluded.created_date
                """,
                (
                    entry.id,
                    entry.title,
                    entry.category,
                    entry.content,
                    self._j(entry.related_services),
                    entry.author,
                    self._j(entry.tags),
                    entry.severity,
                    entry.created_date,
                ),
            )
        return entry

    def get_knowledge_entries(self) -> list[KnowledgeEntry]:
        rows = self._conn.execute(
            "SELECT * FROM knowledge_entry ORDER BY title"
        ).fetchall()
        return [
            KnowledgeEntry(
                id=r["id"],
                title=r["title"],
                category=r["category"],
                content=r["content"],
                related_services=self._lj(r["related_services"]),
                author=r["author"],
                tags=self._lj(r["tags"]),
                severity=r["severity"],
                created_date=r["created_date"],
            )
            for r in rows
        ]

    def get_knowledge_entry(self, entry_id: str) -> KnowledgeEntry | None:
        row = self._conn.execute(
            "SELECT * FROM knowledge_entry WHERE id=?", (entry_id,)
        ).fetchone()
        if not row:
            return None
        return KnowledgeEntry(
            id=row["id"],
            title=row["title"],
            category=row["category"],
            content=row["content"],
            related_services=self._lj(row["related_services"]),
            author=row["author"],
            tags=self._lj(row["tags"]),
            severity=row["severity"],
            created_date=row["created_date"],
        )

    # ------------------------------------------------------------------
    # Full context
    # ------------------------------------------------------------------

    def get_full_context(self) -> FullContext:
        return FullContext(
            company_profile=self.get_company_profile(),
            team=self.get_team(),
            tech_stack=self.get_tech_stack(),
            architecture=self.get_architecture(),
            services=self.get_services(),
            api_contracts=self.get_api_contracts(),
            conventions=self.get_conventions(),
            environments=self.get_environments(),
            blueprints=self.get_blueprints(),
            access_registry=self.get_access_registry_entries(),
            domain_model=self.get_domain_model(),
            external_dependencies=self.get_external_dependencies(),
            data_schemas=self.get_data_schemas(),
            knowledge_base=self.get_knowledge_entries(),
        )

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        self._conn.close()
