from pydantic import BaseModel, Field
from pathlib import Path
from enum import Enum


class LLMRetryConfig(BaseModel):
    max_retries: int = 3
    base_delay_seconds: float = 1.0
    max_delay_seconds: float = 30.0


class LLMConfig(BaseModel):
    default_model: str = "anthropic/claude-sonnet-4-20250514"
    thinking_model: str = "anthropic/claude-sonnet-4-20250514"
    max_tokens: int = 8192
    temperature: float = 0.0
    max_context_tokens: int = 180_000
    cost_limit_per_ticket_usd: float = 5.00
    cost_limit_daily_usd: float = 100.00
    retry: LLMRetryConfig = LLMRetryConfig()


class MCPTransport(str, Enum):
    STDIO = "stdio"
    SSE = "sse"


class MCPConfig(BaseModel):
    transport: MCPTransport = MCPTransport.STDIO
    operativo_command: str = "python -m ase.mcp.operativo.server"
    statico_command: str = "python -m ase.mcp.statico.server"


class TimeoutConfig(BaseModel):
    agent_single_retry_seconds: int = 300
    agent_self_retry_total_seconds: int = 900
    agent_escalation_seconds: int = 900
    human_reminder_interval_seconds: int = 14_400
    task_warning_hours: int = 24


class FaultToleranceConfig(BaseModel):
    max_self_retries: int = 3
    max_peer_escalations: int = 2
    backoff_base_seconds: float = 5.0
    backoff_max_seconds: float = 60.0


class ReviewMethod(str, Enum):
    PR = "pr"
    MANUAL = "manual"
    AUTO_APPROVE = "auto-approve"


class NotificationMethod(str, Enum):
    STDOUT = "stdout"
    WEBHOOK = "webhook"
    SLACK = "slack"


class HILConfig(BaseModel):
    review_method: ReviewMethod = ReviewMethod.PR
    staging_feedback_enabled: bool = True
    notification_method: NotificationMethod = NotificationMethod.STDOUT
    notification_webhook_url: str = ""


class LoggingConfig(BaseModel):
    level: str = "INFO"
    audit_log_enabled: bool = True
    cost_tracking_enabled: bool = True
    events_retention_days: int = 90
    # Log file rotation (ring-buffer style)
    audit_log_dir: str = ".ase/logs"
    max_log_file_bytes: int = 10 * 1024 * 1024  # 10 MB per file
    max_log_backup_count: int = 5  # keep 5 rotated files (total ~60 MB max)


class ProjectConfig(BaseModel):
    name: str
    description: str = ""
    # root_path and db_path are set by the loader based on CWD
    root_path: Path = Path(".")
    db_path: Path = Path(".ase/ase.db")


class ModelTier(str, Enum):
    """Well-known model capability levels for tiered routing."""
    FAST = "fast"        # cheap / low-latency  (e.g. haiku)
    BALANCED = "balanced"  # default (e.g. sonnet)
    DEEP = "deep"        # high-reasoning      (e.g. opus)


class ModelTieringConfig(BaseModel):
    """Map capability tiers to concrete model IDs.

    Agents declare which *tier* they need; this config resolves it to a
    real model string passed to litellm.
    """
    fast: str = "anthropic/claude-haiku-3-20250414"
    balanced: str = "anthropic/claude-sonnet-4-20250514"
    deep: str = "anthropic/claude-sonnet-4-20250514"

    def resolve(self, tier: ModelTier | str) -> str:
        """Return the concrete model for a tier name."""
        if isinstance(tier, str):
            tier = ModelTier(tier)
        return {ModelTier.FAST: self.fast, ModelTier.BALANCED: self.balanced, ModelTier.DEEP: self.deep}[tier]


class SkillsConfig(BaseModel):
    """Where to find skill files and which skills to preload per agent."""
    skills_dir: str = ".ase/skills"
    preloads: dict[str, list[str]] = {
        # agent_type -> [skill_name, ...]
        # e.g. "backend": ["api-design", "docker-best-practices"]
    }


class MemoryScope(str, Enum):
    PROJECT = "project"  # .ase/memory/  (committed, team-shared)
    LOCAL = "local"      # .ase/memory-local/  (git-ignored, personal)
    DISABLED = "disabled"


class MemoryConfig(BaseModel):
    """Agent cross-session memory settings."""
    scope: MemoryScope = MemoryScope.PROJECT
    project_dir: str = ".ase/memory"
    local_dir: str = ".ase/memory-local"


class AgentsConfig(BaseModel):
    enabled: list[str] = ["analyzer", "triage", "backend", "testing"]
    model_overrides: dict[str, str] = {}
    # Per-agent tier assignment (agent_type -> tier name)
    model_tiers: dict[str, str] = {
        "triage": "fast",
        "analyzer": "balanced",
        "backend": "balanced",
        "frontend": "balanced",
        "testing": "balanced",
        "security": "balanced",
        "devops": "balanced",
        "database": "balanced",
        "docs": "fast",
        "platform": "balanced",
        "cloud": "balanced",
    }


class ASEConfig(BaseModel):
    """Root config -- validated from .ase/config.toml"""
    project: ProjectConfig
    llm: LLMConfig = LLMConfig()
    mcp: MCPConfig = MCPConfig()
    timeouts: TimeoutConfig = TimeoutConfig()
    fault_tolerance: FaultToleranceConfig = FaultToleranceConfig()
    agents: AgentsConfig = AgentsConfig()
    logging: LoggingConfig = LoggingConfig()
    hil: HILConfig = HILConfig()
    model_tiers: ModelTieringConfig = ModelTieringConfig()
    skills: SkillsConfig = SkillsConfig()
    memory: MemoryConfig = MemoryConfig()
