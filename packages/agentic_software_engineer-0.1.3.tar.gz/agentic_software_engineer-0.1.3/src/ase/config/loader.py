"""
Config loader for ASE framework.

Loads configuration from:
1. defaults.toml (bundled defaults)
2. .ase/config.toml (project-level overrides)
3. .env (environment variable overrides via python-dotenv)

Validates the merged configuration with the Pydantic ASEConfig schema.
"""

from __future__ import annotations

import tomllib
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

from ase.config.schema import ASEConfig


_DEFAULTS_TOML = Path(__file__).parent / "defaults.toml"


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """Recursively merge *override* into *base*, returning a new dict.

    Nested dicts are merged; all other values are replaced.
    """
    merged = base.copy()
    for key, value in override.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def _load_toml(path: Path) -> dict[str, Any]:
    """Read and parse a TOML file, returning an empty dict if it does not exist."""
    if not path.exists():
        return {}
    with open(path, "rb") as fh:
        return tomllib.load(fh)


def load_config(project_path: Path) -> ASEConfig:
    """Load, merge and validate ASE configuration.

    Parameters
    ----------
    project_path:
        Root directory of the project.  The loader expects an optional
        ``.ase/config.toml`` and ``.env`` in this directory.

    Returns
    -------
    ASEConfig
        Fully validated configuration object.

    Raises
    ------
    pydantic.ValidationError
        If the merged configuration does not satisfy the schema.
    FileNotFoundError
        If *project_path* does not exist.
    """
    project_path = Path(project_path).resolve()

    if not project_path.exists():
        raise FileNotFoundError(f"Project path does not exist: {project_path}")

    # 1. Load bundled defaults
    defaults = _load_toml(_DEFAULTS_TOML)

    # 2. Load project-level overrides (.ase/config.toml)
    project_toml = project_path / ".ase" / "config.toml"
    overrides = _load_toml(project_toml)

    # 3. Merge: overrides win over defaults
    merged = _deep_merge(defaults, overrides)

    # 4. Load .env so that os.environ is populated for any downstream code
    env_file = project_path / ".env"
    if env_file.exists():
        # override=False prevents a project .env from overwriting
        # critical env vars like PATH, HOME, LD_PRELOAD, etc.
        load_dotenv(dotenv_path=env_file, override=False)

    # 5. Ensure project section has required paths if not explicitly set
    if "project" not in merged:
        merged["project"] = {}

    project_section = merged["project"]

    if "name" not in project_section:
        project_section["name"] = project_path.name

    # Always set root_path and db_path from the resolved project path
    project_section["root_path"] = str(project_path)
    project_section["db_path"] = str(project_path / ".ase" / "ase.db")

    # 6. Validate with Pydantic
    return ASEConfig(**merged)
