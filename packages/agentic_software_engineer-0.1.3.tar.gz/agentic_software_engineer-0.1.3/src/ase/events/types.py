"""
Event types and payload models for the ASE event system.

Every inter-agent communication flows through typed events.  The EventType
enum defines the full catalogue; the Pydantic payload models carry the
structured data that accompanies each event.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# EventType enum
# ---------------------------------------------------------------------------

class EventType(str, Enum):
    """Canonical event types emitted and consumed by ASE agents."""

    # Artifact lifecycle
    ARTIFACT_CREATED = "artifact_created"
    API_CONTRACT_DEFINED = "api_contract_defined"
    SCHEMA_CHANGED = "schema_changed"

    # Testing
    TEST_PASSED = "test_passed"
    TEST_FAILED = "test_failed"

    # Ticket / workflow state
    STATUS_CHANGED = "status_changed"
    BLOCKED = "blocked"
    COMPLETED = "completed"

    # Human-in-the-loop
    HUMAN_REQUIRED = "human_required"
    FEEDBACK_RECEIVED = "feedback_received"

    # Agent lifecycle
    AGENT_SPAWNED = "agent_spawned"
    AGENT_COMPLETED = "agent_completed"
    AGENT_FAILED = "agent_failed"

    # Cost governance
    COST_WARNING = "cost_warning"


# ---------------------------------------------------------------------------
# Payload models
# ---------------------------------------------------------------------------

class ArtifactCreatedPayload(BaseModel):
    """Payload for ARTIFACT_CREATED events."""

    artifact_type: str = Field(
        ...,
        description="Kind of artifact (e.g. 'source_file', 'migration', 'config').",
    )
    file_path: str = Field(
        ...,
        description="Relative path of the created artifact within the project.",
    )
    language: str = Field(
        default="",
        description="Programming language or format of the artifact.",
    )
    summary: str = Field(
        default="",
        description="Brief human-readable description of what was created.",
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Arbitrary key-value metadata about the artifact.",
    )


class APIContractPayload(BaseModel):
    """Payload for API_CONTRACT_DEFINED events."""

    contract_format: str = Field(
        ...,
        description="Format of the contract (e.g. 'openapi', 'graphql', 'grpc').",
    )
    contract_path: str = Field(
        ...,
        description="Path to the contract file relative to the project root.",
    )
    endpoints: list[dict[str, Any]] = Field(
        default_factory=list,
        description="List of endpoint summaries defined in this contract.",
    )
    version: str = Field(
        default="1.0.0",
        description="Semantic version of the API contract.",
    )
    breaking_changes: bool = Field(
        default=False,
        description="Whether this contract revision contains breaking changes.",
    )


class SchemaChangedPayload(BaseModel):
    """Payload for SCHEMA_CHANGED events."""

    schema_type: str = Field(
        ...,
        description="Type of schema that changed (e.g. 'database', 'pydantic', 'protobuf').",
    )
    migration_path: str = Field(
        default="",
        description="Path to the migration file, if applicable.",
    )
    changes: list[dict[str, Any]] = Field(
        default_factory=list,
        description="List of individual schema changes (add column, rename, etc.).",
    )
    backward_compatible: bool = Field(
        default=True,
        description="Whether the change is backward-compatible.",
    )


class TestResultPayload(BaseModel):
    """Payload for TEST_PASSED and TEST_FAILED events."""

    test_suite: str = Field(
        ...,
        description="Name or path of the test suite that was executed.",
    )
    total_tests: int = Field(default=0, description="Total number of tests executed.")
    passed: int = Field(default=0, description="Number of tests that passed.")
    failed: int = Field(default=0, description="Number of tests that failed.")
    skipped: int = Field(default=0, description="Number of tests that were skipped.")
    error_output: str = Field(
        default="",
        description="Captured stderr / traceback for failing tests.",
    )
    duration_seconds: float = Field(
        default=0.0,
        description="Wall-clock time the test suite took to run.",
    )
    coverage_percent: float | None = Field(
        default=None,
        description="Code-coverage percentage, if measured.",
    )


class BlockedPayload(BaseModel):
    """Payload for BLOCKED and HUMAN_REQUIRED events."""

    reason: str = Field(
        ...,
        description="Why the agent is blocked.",
    )
    blocked_agent: str = Field(
        default="",
        description="Agent type that is blocked.",
    )
    assignment_id: int | None = Field(
        default=None,
        description="ID of the agent assignment that hit the blocker.",
    )
    escalation_level: int = Field(
        default=0,
        description="Current escalation level (0=self, 1=self-retry, 2=peer, 3=human).",
    )
    attempted_fixes: list[str] = Field(
        default_factory=list,
        description="Summary of fixes attempted before escalation.",
    )
    suggested_action: str = Field(
        default="",
        description="What the system recommends the human should do.",
    )


# ---------------------------------------------------------------------------
# Event envelope  (used by EventBus for serialisation / deserialisation)
# ---------------------------------------------------------------------------

class Event(BaseModel):
    """Full event envelope as stored / transmitted."""

    id: int | None = Field(default=None, description="Server-assigned event ID.")
    event_type: EventType
    source_agent: str = Field(..., description="Agent type that published the event.")
    ticket_id: int = Field(..., description="Ticket this event belongs to.")
    payload: dict[str, Any] = Field(default_factory=dict)
    target_agents: list[str] = Field(
        default_factory=list,
        description="Agent types this event is addressed to (empty = broadcast).",
    )
    created_at: datetime | None = Field(
        default=None,
        description="Server-assigned timestamp.",
    )
