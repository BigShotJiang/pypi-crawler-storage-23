"""
EventBus -- publish / subscribe backbone for the ASE event system.

All events flow through the MCP Operativo server:

* **publish** calls ``operativo__publish_event`` to persist an event.
* **poll** calls ``operativo__get_events`` with a ``since_id`` cursor to
  retrieve events that arrived after the last seen ID and dispatches them
  to registered handlers.

The bus runs a background polling loop (``start_polling`` / ``stop_polling``)
that can be cancelled cleanly at shutdown.
"""

from __future__ import annotations

import asyncio
import logging
from collections import defaultdict
from typing import Any, Callable, Coroutine

from ase.events.types import Event, EventType

logger = logging.getLogger(__name__)

# Type alias for an async event handler: async def handler(event: Event) -> None
EventHandler = Callable[[Event], Coroutine[Any, Any, None]]


class EventBus:
    """Central pub/sub bus backed by the MCP Operativo event store.

    Parameters
    ----------
    bridge:
        An ``MCPBridge`` instance used to call Operativo MCP tools.
    poll_interval_seconds:
        How often the background poller queries for new events.
    """

    def __init__(self, bridge: Any, poll_interval_seconds: float = 2.0) -> None:
        self._bridge = bridge
        self._poll_interval = poll_interval_seconds

        # event_type -> list of async handlers
        self._handlers: dict[EventType, list[EventHandler]] = defaultdict(list)

        # Integer-based cursor -- only events with id > _last_seen_id are new.
        self._last_seen_id: int = 0

        # Background polling task handle
        self._poll_task: asyncio.Task[None] | None = None
        self._running: bool = False

    # ------------------------------------------------------------------
    # Subscribe
    # ------------------------------------------------------------------

    def subscribe(self, event_type: EventType, handler: EventHandler) -> None:
        """Register *handler* to be called for every event of *event_type*.

        Handlers are async callables with signature ``async (Event) -> None``.
        Multiple handlers can be registered for the same event type; they will
        be invoked concurrently when an event arrives.
        """
        self._handlers[event_type].append(handler)
        logger.debug("Subscribed handler %s to %s", handler.__name__, event_type.value)

    def unsubscribe(self, event_type: EventType, handler: EventHandler) -> None:
        """Remove a previously registered handler."""
        try:
            self._handlers[event_type].remove(handler)
            logger.debug("Unsubscribed handler %s from %s", handler.__name__, event_type.value)
        except ValueError:
            logger.warning(
                "Handler %s was not registered for %s", handler.__name__, event_type.value
            )

    # ------------------------------------------------------------------
    # Publish
    # ------------------------------------------------------------------

    async def publish(
        self,
        event_type: EventType,
        source_agent: str,
        ticket_id: int,
        payload: dict[str, Any] | None = None,
        target_agents: list[str] | None = None,
    ) -> dict[str, Any]:
        """Publish an event via the Operativo MCP server.

        Returns the raw response dict from the MCP tool call.
        """
        arguments: dict[str, Any] = {
            "event_type": event_type.value,
            "source_agent": source_agent,
            "ticket_id": ticket_id,
            "payload": payload or {},
        }
        if target_agents:
            arguments["target_agents"] = target_agents

        logger.info(
            "Publishing %s from %s for ticket %d",
            event_type.value,
            source_agent,
            ticket_id,
        )

        result = await self._bridge.execute_tool_call(
            "operativo__publish_event", arguments
        )
        return result  # type: ignore[return-value]

    # ------------------------------------------------------------------
    # Polling loop
    # ------------------------------------------------------------------

    async def _poll_once(self) -> None:
        """Fetch new events since ``_last_seen_id`` and dispatch them."""
        try:
            result = await self._bridge.execute_tool_call(
                "operativo__get_events",
                {"since_id": self._last_seen_id},
            )

            events_raw: list[dict[str, Any]] = result.get("events", [])
            if not events_raw:
                return

            for raw in events_raw:
                try:
                    event = Event(**raw)
                except Exception:
                    logger.exception("Failed to parse event: %s", raw)
                    continue

                # Advance cursor
                if event.id is not None and event.id > self._last_seen_id:
                    self._last_seen_id = event.id

                # Dispatch to handlers
                await self._dispatch(event)

        except Exception:
            logger.exception("Error during event poll cycle")

    async def _dispatch(self, event: Event) -> None:
        """Invoke all handlers registered for *event.event_type*."""
        handlers = self._handlers.get(event.event_type, [])
        if not handlers:
            return

        logger.debug(
            "Dispatching %s (id=%s) to %d handler(s)",
            event.event_type.value,
            event.id,
            len(handlers),
        )

        # Run handlers concurrently; isolate failures so one bad handler
        # does not prevent others from executing.
        tasks = [asyncio.create_task(h(event)) for h in handlers]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        for idx, res in enumerate(results):
            if isinstance(res, Exception):
                logger.error(
                    "Handler %s raised %s for event %s",
                    handlers[idx].__name__,
                    res,
                    event.id,
                )

    async def _poll_loop(self) -> None:
        """Long-running loop that polls for events at the configured interval."""
        logger.info(
            "Event polling started (interval=%.1fs, since_id=%d)",
            self._poll_interval,
            self._last_seen_id,
        )
        while self._running:
            await self._poll_once()
            await asyncio.sleep(self._poll_interval)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start_polling(self) -> asyncio.Task[None]:
        """Start the background polling task.

        Returns the ``asyncio.Task`` so the caller can await or cancel it.
        """
        if self._poll_task is not None and not self._poll_task.done():
            logger.warning("Polling is already running")
            return self._poll_task

        self._running = True
        self._poll_task = asyncio.create_task(self._poll_loop(), name="event-bus-poll")
        return self._poll_task

    async def stop_polling(self) -> None:
        """Gracefully stop the background polling task."""
        self._running = False
        if self._poll_task is not None and not self._poll_task.done():
            self._poll_task.cancel()
            try:
                await self._poll_task
            except asyncio.CancelledError:
                pass
            logger.info("Event polling stopped")
        self._poll_task = None

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    @property
    def last_seen_id(self) -> int:
        """The most recently seen event ID."""
        return self._last_seen_id

    @property
    def is_polling(self) -> bool:
        """Whether the background polling loop is currently active."""
        return self._running and self._poll_task is not None and not self._poll_task.done()
