"""
EventHandlerRegistry -- declarative registration and dispatch of event handlers.

This module provides a higher-level convenience layer on top of ``EventBus``.
Agent implementations and orchestrator components can use the registry to
declare which event types they care about, and the registry takes care of
wiring everything into the bus.

Usage example::

    registry = EventHandlerRegistry()

    @registry.on(EventType.ARTIFACT_CREATED)
    async def handle_artifact(event: Event) -> None:
        print(f"New artifact: {event.payload}")

    # Later, bind the registry to a live EventBus
    registry.bind(event_bus)
"""

from __future__ import annotations

import logging
from collections import defaultdict
from typing import Any, Callable, Coroutine

from ase.events.bus import EventBus, EventHandler
from ase.events.types import Event, EventType

logger = logging.getLogger(__name__)


class EventHandlerRegistry:
    """Collects event handlers and wires them into an ``EventBus``.

    The registry serves two purposes:

    1. **Decoupled registration** -- handlers can be registered at import time
       (via the ``@on`` decorator) before the ``EventBus`` exists.
    2. **Bulk dispatch** -- ``dispatch`` can be called directly for unit-testing
       handlers without needing a live bus.
    """

    def __init__(self) -> None:
        self._handlers: dict[EventType, list[EventHandler]] = defaultdict(list)
        self._bound_bus: EventBus | None = None

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(self, event_type: EventType, handler: EventHandler) -> None:
        """Register an async handler for *event_type*.

        If the registry is already bound to a bus, the handler is also
        subscribed on the bus immediately.
        """
        self._handlers[event_type].append(handler)
        logger.debug("Registered handler %s for %s", handler.__name__, event_type.value)

        if self._bound_bus is not None:
            self._bound_bus.subscribe(event_type, handler)

    def on(
        self, event_type: EventType
    ) -> Callable[[EventHandler], EventHandler]:
        """Decorator form of :meth:`register`.

        Example::

            @registry.on(EventType.TEST_FAILED)
            async def on_test_failed(event: Event) -> None:
                ...
        """

        def _decorator(fn: EventHandler) -> EventHandler:
            self.register(event_type, fn)
            return fn

        return _decorator

    def unregister(self, event_type: EventType, handler: EventHandler) -> None:
        """Remove a previously registered handler."""
        try:
            self._handlers[event_type].remove(handler)
        except ValueError:
            logger.warning(
                "Handler %s was not registered for %s",
                handler.__name__,
                event_type.value,
            )
            return

        if self._bound_bus is not None:
            self._bound_bus.unsubscribe(event_type, handler)

    # ------------------------------------------------------------------
    # Binding to an EventBus
    # ------------------------------------------------------------------

    def bind(self, bus: EventBus) -> None:
        """Subscribe all registered handlers on *bus*.

        This should be called once during application startup after both the
        registry and the bus are constructed.  Handlers registered *after*
        ``bind`` is called are automatically subscribed on the bus as well.
        """
        self._bound_bus = bus
        for event_type, handlers in self._handlers.items():
            for handler in handlers:
                bus.subscribe(event_type, handler)
        logger.info(
            "Bound %d handler(s) across %d event type(s) to EventBus",
            sum(len(h) for h in self._handlers.values()),
            len(self._handlers),
        )

    def unbind(self) -> None:
        """Unsubscribe all handlers from the currently bound bus."""
        if self._bound_bus is None:
            return

        for event_type, handlers in self._handlers.items():
            for handler in handlers:
                self._bound_bus.unsubscribe(event_type, handler)

        logger.info("Unbound all handlers from EventBus")
        self._bound_bus = None

    # ------------------------------------------------------------------
    # Direct dispatch (useful for testing)
    # ------------------------------------------------------------------

    async def dispatch(self, event: Event) -> list[Exception | None]:
        """Invoke all handlers registered for *event.event_type*.

        Returns a list with one entry per handler: ``None`` on success or the
        exception instance on failure.  This is intentionally synchronous in
        terms of error collection so callers can inspect failures.
        """
        import asyncio

        handlers = self._handlers.get(event.event_type, [])
        if not handlers:
            return []

        tasks = [asyncio.create_task(h(event)) for h in handlers]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        outcomes: list[Exception | None] = []
        for idx, res in enumerate(results):
            if isinstance(res, Exception):
                logger.error(
                    "Handler %s raised %s for event %s",
                    handlers[idx].__name__,
                    res,
                    event.event_type.value,
                )
                outcomes.append(res)
            else:
                outcomes.append(None)

        return outcomes

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    def get_handlers(self, event_type: EventType) -> list[EventHandler]:
        """Return a copy of the handler list for *event_type*."""
        return list(self._handlers.get(event_type, []))

    @property
    def registered_event_types(self) -> list[EventType]:
        """Return the event types that have at least one handler."""
        return [et for et, handlers in self._handlers.items() if handlers]

    @property
    def handler_count(self) -> int:
        """Total number of registered handlers across all event types."""
        return sum(len(h) for h in self._handlers.values())

    def __repr__(self) -> str:
        bound = "bound" if self._bound_bus is not None else "unbound"
        return (
            f"<EventHandlerRegistry {bound} "
            f"types={len(self._handlers)} handlers={self.handler_count}>"
        )
