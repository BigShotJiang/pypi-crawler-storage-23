import httpx
from django.core.cache import cache
from django.http import HttpRequest
from django.utils.text import slugify


def get_client_ip(request: HttpRequest):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        return x_forwarded_for.split(',')[0].strip()
    return request.META.get('REMOTE_ADDR')


IPAPI_URL = 'https://ipapi.co/{ip}/json/'
CACHE_TIMEOUT = 60 * 60 * 24 * 7  # 1 week


def get_location_from_ip(ip: str) -> dict:
    if not ip:
        return {'country': '', 'city': ''}

    # Use a slugified key to avoid unsafe characters
    cache_key = f'ip-location:{slugify(ip)}'

    if cached := cache.get(cache_key):
        print(f'Cache hit for {cache_key}')
        return cached

    try:
        with httpx.Client(timeout=3.0) as client:
            response = client.get(IPAPI_URL.format(ip=ip))
            if response.status_code == 200:
                data = response.json()
                location = {
                    'country': data.get('country_name', ''),
                    'city': data.get('city', ''),
                }
                cache.set(cache_key, location, CACHE_TIMEOUT)
                return location
    except httpx.RequestError:
        pass

    return {'country': '', 'city': ''}
