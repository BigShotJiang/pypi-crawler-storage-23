import datetime

from django.contrib.admin.utils import quote
from django.http import Http404
from django.urls import include, path, reverse
from django.utils.functional import cached_property
from django.utils.translation import gettext_lazy as _
from django.views import View
from wagtail.admin.ui.tables import TitleColumn
from wagtail.admin.views.generic import (
    EditView,
    IndexView,
    InspectView,
)
from wagtail.admin.viewsets.model import ModelViewSet
from wagtail.admin.widgets.button import (
    Button,
    ButtonWithDropdown,
    HeaderButton,
    ListingButton,
)

from .models import Form, FormSubmission


class NotFoundView(View):
    def dispatch(self, request, *args, **kwargs):
        # return HttpResponseNotFound("Page not found")
        raise Http404()


class SubmissionIndexView(IndexView):
    page_title = 'Submissions'
    list_export = [
        'pk',
        'form',
        'submitted_at',
        'ip_address',
        'referer',
        'user_agent',
        'form_data_json',
    ]

    export_headings = {
        'pk': _('ID'),
        'form': _('Form'),
        'submitted_at': _('Submitted At'),
        'ip_address': _('IP Address'),
        'referer': _('Referer'),
        'user_agent': _('User Agent'),
        'form_data_json': _('Data'),
    }

    @cached_property
    def header_buttons(self):
        buttons = []

        return buttons

    def setup(self, request, *args, **kwargs):
        super().setup(request, *args, **kwargs)
        self.form_id = kwargs.get('form_id', None)

    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)

    def get_filename(self):
        filename = super().get_filename()
        return f'{filename}-{datetime.datetime.today().strftime("%Y-%m-%d_%H-%M-%S")}'

    def _get_title_column(self, field_name, column_class=TitleColumn, **kwargs):
        column_class = self._get_title_column_class(column_class)

        def get_url(instance):
            """Return the URL for the instance, either edit or inspect."""
            return self.get_inspect_url(instance)

        if not self.model:
            return column_class(
                'name',  # type: ignore
                label=_('Name'),
                accessor=str,
                get_url=get_url,
            )
        return self._get_custom_column(field_name, column_class, get_url=get_url, **kwargs)  # type: ignore

    def get_list_more_buttons(self, instance):
        buttons = []

        if inspect_url := self.get_inspect_url(instance):
            buttons.append(
                ListingButton(
                    _('View'),
                    url=inspect_url,
                    icon_name='view',
                    attrs={'aria-label': _("View '%(title)s'") % {'title': str(instance)}},
                    priority=20,
                )
            )
        if delete_url := self.get_delete_url(instance):
            buttons.append(
                ListingButton(
                    _('Delete'),
                    url=delete_url,
                    icon_name='bin',
                    attrs={'aria-label': _("Delete '%(title)s'") % {'title': str(instance)}},
                    priority=30,
                )
            )
        return buttons

    def get_list_buttons(self, instance):
        more_buttons = self.get_list_more_buttons(instance)
        buttons = []
        if more_buttons:
            buttons.append(
                ButtonWithDropdown(
                    buttons=more_buttons,
                    icon_name='dots-horizontal',
                    attrs={
                        'aria-label': _("More options for '%(title)s'") % {'title': str(instance)},
                    },
                )
            )
        return buttons

    def get_breadcrumbs_items(self):
        return self.breadcrumbs_items + [
            {
                'url': reverse('wtforms:index'),
                'label': _('Forms'),
            },
            {
                'url': '',
                'label': self.get_page_title(),
                'sublabel': self.get_page_subtitle(),
            },
        ]

    def get_edit_url(self):
        return None

    def get_add_url(self):
        return None

    def get_queryset(self):
        """Return the base queryset, ensuring it has a default order to avoid pagination issues."""
        queryset = super().get_queryset()

        if self.form_id:
            fm = Form.objects.filter(id=self.form_id)
            # if not fm.exists():
            if not fm:
                raise Http404(_("Form with ID '%s' does not exist.") % self.form_id)
            # queryset = queryset.filter(form__id=self.form_id)
            queryset = queryset.filter(form=self.form_id)
        if not self.request.user.is_staff:
            queryset = queryset.filter(created_by=self.request.user)
        return queryset

    def get_context_data(self, *args, **kwargs):
        context = super().get_context_data(*args, **kwargs)

        return context


class SubmissionInspectView(InspectView):
    # template_name = "wagtailadmin/generic/inspect.html"
    template_name = 'wtforms/submissions/view.html'
    page_title = _('Entry')

    @cached_property
    def header_buttons(self):
        buttons = []

        buttons.append(
            HeaderButton(
                label=_('Submissions'),
                url=reverse('wtforms:submissions:index', query={'form': quote(self.object.form.pk)}),
                icon_name='view',
            )
        )
        return buttons

    @cached_property
    def header_more_buttons(self):
        buttons = []

        if delete_url := self.get_delete_url():
            buttons.append(Button(_('Delete'), url=delete_url, icon_name='bin', priority=20))
        return buttons

    def get_object(self, queryset=None):
        obj = super().get_object(queryset=queryset)
        if obj.is_read is False:
            obj.is_read = True
            obj.save(update_fields=['is_read'])
        return obj

    def get_page_subtitle(self):
        return f'#{self.object.pk}'

    def get_breadcrumbs_items(self):
        return self.breadcrumbs_items + [
            {
                'url': reverse('wtforms:index'),
                'label': _('Forms'),
            },
            {
                'url': reverse('wtforms:submissions:index'),
                'label': _('Submissions'),
            },
            {
                'url': reverse('wtforms:submissions:index', query={'form': quote(self.object.form.pk)}),
                'label': self.object.form,
            },
            {
                'url': '',
                'label': self.get_page_title(),
                'sublabel': self.get_page_subtitle(),
            },
        ]

    def get_edit_url(self):
        return None  # Not implemented, as per original code


class SubmissionViewSet(ModelViewSet):
    model = FormSubmission
    page_title = _('Submissions')
    icon = 'form'
    copy_view_enabled = False
    inspect_view_enabled = True
    index_view_class = SubmissionIndexView
    inspect_view_class = SubmissionInspectView
    # add_view_class = NotFoundView
    form_fields = ['ip_address', 'user_agent', 'referer']

    @cached_property
    def name(self) -> str:
        return 'wtforms/submissions'

    @cached_property
    def list_display(self) -> list[str]:
        fields = [
            # '__str__',
            'id',
            'form',
            'is_read',
            'ip_address',
            'referer',
            'browser',
            'device',
            'submitted_at',
        ]

        return fields

    @cached_property
    def list_filter(self) -> list[str]:
        return [
            'form',
            'submitted_at',
            'is_read',
            'ip_address',
            'referer',
            'user_agent',
            # 'submissions__form_data__icontains',
        ]

    @cached_property
    def search_fields(self) -> list[str]:
        return [
            'form__label',
            'form__id',
            'submitted_at',
            'ip_address',
            'referer',
            'user_agent',
            'form_data',
        ]

    def get_urlpatterns(self) -> list:
        # urlpatterns = super().get_urlpatterns()
        urlpatterns = [
            path('', self.index_view, name='index'),
            path('results/', self.index_results_view, name='index_results'),
            path('view/<str:pk>/', self.inspect_view, name='inspect'),
            path('delete/<str:pk>/', self.delete_view, name='delete'),
        ]

        return urlpatterns


class FormIndexView(IndexView):
    submission_url_name = 'wtforms:submissions:index'

    @cached_property
    def header_buttons(self):
        # buttons = super().header_buttons
        buttons = []

        buttons.append(
            HeaderButton(
                label=_('Submissions'),
                url=reverse('wtforms:submissions:index'),
                icon_name='view',
            )
        )
        return buttons

    def get_submission_url(self, instance):
        query = {
            'form': quote(instance.pk),
        }
        return reverse(self.submission_url_name, query=query)

    def get_list_more_buttons(self, instance):
        buttons = super().get_list_more_buttons(instance)

        buttons.append(
            ListingButton(
                _('Submissions'),
                url=self.get_submission_url(instance),
                icon_name='view',
                attrs={'aria-label': _("Submissions '%(title)s'") % {'title': str(instance)}},
                priority=5,
            )
        )

        return buttons

    def get_queryset(self):
        """Return the base queryset, ensuring it has a default order to avoid pagination issues."""
        queryset = super().get_queryset()

        if not self.request.user.is_staff:
            queryset = queryset.filter(created_by=self.request.user)
        return queryset


class FormEditView(EditView):
    submission_url_name = 'wtforms:submissions:index'

    @cached_property
    def header_buttons(self):
        buttons = []

        buttons.append(
            HeaderButton(
                label=_('Submissions'),
                url=reverse('wtforms:submissions:index', query={'form': quote(self.object.pk)}),
                icon_name='view',
            )
        )
        return buttons

    @cached_property
    def header_more_buttons(self):
        buttons = super().header_more_buttons
        buttons.append(
            Button(
                _('Submissions'),
                url=self.get_submission_url(),
                icon_name='view',
                attrs={'aria-label': _("Submissions '%(title)s'") % {'title': str(self.object)}},
                priority=5,
            )
        )

        return buttons

    def get_submission_url(self):
        query = {
            'form': quote(self.object.pk),
        }
        return reverse(self.submission_url_name, query=query)


class FormViewSet(ModelViewSet):
    model = Form
    page_title = 'Forms'
    page_subtitle = 'WT Forms'
    paginate_by = 10
    # menu_name = 'wtforms'
    add_to_admin_menu = True
    add_to_reference_index = True
    icon = 'form'
    form_fields = ['label']
    index_view_class = FormIndexView
    edit_view_class = FormEditView
    submission_view_class = SubmissionViewSet
    submission_url_name = 'wtforms:submissions:index'

    @cached_property
    def name(self) -> str:
        return 'wtforms'

    @cached_property
    def menu_label(self) -> str:
        return _('WT Forms')

    @cached_property
    def list_display(self) -> list:
        return [
            # 'label',
            TitleColumn(
                name='label',
                get_url=self.get_submission_url,
                label=_('Form'),
                accessor='label',
                width='50%',
            ),
            TitleColumn(
                name='submissions_count',
                get_url=self.get_submission_url,
                label=_('Submissions'),
                accessor='submissions_count',
                width='50%',
            ),
        ]

    @cached_property
    def list_filter(self) -> list[str]:
        return [
            'label',
        ]

    @cached_property
    def search_fields(self) -> list[str]:
        return [
            'label',
        ]

    @property
    def submission_view(self):
        return self.construct_view(self.submission_view_class, **self.get_submission_view_kwargs())

    def get_submission_url(self, instance):
        query = {
            'form': quote(instance.pk),
        }
        return reverse(self.submission_url_name, query=query)

    def get_submission_view_kwargs(self, **kwargs):
        view_kwargs = {
            **kwargs,
        }

        return view_kwargs

    def get_urlpatterns(self):
        urlpatterns = super().get_urlpatterns()
        urlpatterns += [
            path(
                'submissions/',
                include(
                    (self.submission_view_class().get_urlpatterns(), 'wagtail_forms'),
                    namespace='submissions',
                ),
            ),
        ]

        return urlpatterns
