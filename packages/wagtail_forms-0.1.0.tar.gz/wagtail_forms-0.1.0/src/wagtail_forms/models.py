import json

import ua_parser
from django import forms
from django.conf import settings
from django.core.serializers.json import DjangoJSONEncoder
from django.db import models
from django.http import HttpRequest
from django.utils.translation import gettext_lazy as _
from wagtail.admin.panels import (
    FieldPanel,
)

from .mixins import SubmissionMetadataMixin
from .utils import get_client_ip


class Form(models.Model):
    """Represents a form type created dynamically in the admin."""

    label = models.CharField(
        verbose_name=_('label'),
        max_length=255,
        help_text=_('The label of the form, used to identify it.'),
        blank=False,
        null=False,
        unique=True,
        db_index=True,
    )

    def __str__(self):
        """Return the label of the form."""
        return self.label

    @property
    def submissions_count(self):
        """Get the number of submissions for this form."""
        # return self.get_submissions().count()
        return self.submissions.count()  # type: ignore

    def get_submissions(self):
        """Get all submissions for this form."""
        return self.get_submission_class().objects.filter(form=self)

    def get_submission_class(self):
        return FormSubmission

    def process(self, *, request: HttpRequest, form: forms.Form, **kwargs):
        """Accept form instance with submitted data.

        Creates submission instance.

        You can override this method if you want to have custom creation logic.
        For example, if you want to save reference to a user.
        """
        form_class = f'{form.__module__}.{form.__class__.__name__}'
        return self.get_submission_class().objects.create(
            ip_address=get_client_ip(request),
            user_agent=request.META.get('HTTP_USER_AGENT', None),
            referer=request.META.get('HTTP_REFERER', None),
            form_data=form.cleaned_data,
            form=self,
            form_class=form_class,
            user=request.user if request.user.is_authenticated else None,
        )

    @classmethod
    def submit(cls, *, request: HttpRequest, label: str, form: forms.Form, **kwargs) -> 'FormSubmission':
        """Create or get a form instance by label and process the form submission."""
        fm, _ = cls.objects.get_or_create(
            label=label,
        )
        submission = fm.process(
            request=request,
            form=form,
        )

        return submission

    class Meta:
        verbose_name = _('Form')
        verbose_name_plural = _('Forms')


class FormSubmission(SubmissionMetadataMixin, models.Model):
    """Abstract base for custom form submissions (Contact, Quote, Subscribe).

    Mimics Wagtail form submission behavior without requiring a page.
    """

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='+'
    )
    form = models.ForeignKey(Form, on_delete=models.CASCADE, related_name='submissions')
    form_data = models.JSONField(encoder=DjangoJSONEncoder)
    form_class = models.TextField(
        verbose_name=_('Form Class'),
        # max_length=255,
        help_text=_('The django forms class used to create this form.'),
        blank=True,
        null=True,
    )
    is_read = models.BooleanField(verbose_name='Read', default=False)
    # read_at = models.DateTimeField(null=True, blank=True)

    @property
    def form_data_humanized(self):
        """Return the form data as a dictionary with human-readable keys."""
        form_data = {}

        form_instance = self.get_form_instance()
        if form_instance and form_instance.is_valid():
            for name, field in form_instance.fields.items():
                label = field.label or self.humanize_key(name)
                value = form_instance.cleaned_data.get(name, '')
                if isinstance(value, list):
                    value = ', '.join(value)
                form_data[label] = value
        else:
            for field, value in self.form_data.items():
                val = value
                if isinstance(val, list):
                    val = ', '.join(val)
                form_data[self.humanize_key(field)] = val

        return form_data

    @property
    def form_data_json(self):
        """Return the form data as a JSON string."""
        return json.dumps(self.form_data, ensure_ascii=False)

    @property
    def ua(self) -> ua_parser.Result | None:
        return ua_parser.parse(self.user_agent) if self.user_agent else None

    @property
    def browser(self) -> str | None:
        return self.ua.user_agent.family if self.ua and self.ua.user_agent else None

    @property
    def device(self) -> str | None:
        return self.ua.os.family if self.ua and self.ua.os else None

    @property
    def location(self) -> str | None:
        """Get the location from the IP address using a utility function."""
        from .utils import get_location_from_ip

        location = get_location_from_ip(self.ip_address) if self.ip_address else None
        if location and location.get('city') and location.get('country'):
            return f'{location["city"]}, {location["country"]}'

        return None

    panels = [
        FieldPanel('submitted_at', read_only=True),
        FieldPanel('ip_address', read_only=True),
        FieldPanel('referer', read_only=True),
        FieldPanel('user_agent', read_only=True),
        FieldPanel('form_data', read_only=True),
    ]

    def __str__(self):
        return f'{self.form.label} #{self.pk}'

    def get_data(self):
        data = super().get_data()
        data['form_data'] = self.form_data

        for key, value in self.form_data.items():
            if isinstance(value, list):
                # Convert lists to comma-separated strings for better readability
                data[key] = ', '.join(value)
            else:
                data[key] = value

        return data

    def humanize_key(self, value):
        if not isinstance(value, str):
            return value
        return value.replace('_', ' ').title()

    def get_form_class(self):
        """Dynamically import the form class from the path."""
        from importlib import import_module

        if not self.form_class:
            return None
        module_path, class_name = self.form_class.rsplit('.', 1)
        module = import_module(module_path)
        return getattr(module, class_name)

    def get_form_instance(self) -> forms.Form | None:
        """Return a bound form instance using stored data."""
        form_class = self.get_form_class()
        if not form_class:
            return None
        return form_class(data=self.form_data)

    class Meta:
        verbose_name = _('Submission')
        verbose_name_plural = _('Submissions')
        ordering = ['-submitted_at']
