from django import forms
from django.http import HttpRequest

from .models import Form as FormModel
from .models import FormSubmission


class Form(forms.Form):
    _label = None

    def submit(self, *, request: HttpRequest, **kwargs) -> 'FormSubmission':
        """Create or get a form instance by label and process the form submission."""
        if hasattr(self, '_label') and isinstance(self._label, str):
            label = self._label
        else:
            label = self.__class__.__name__

        submission = FormModel.submit(
            request=request,
            label=label,
            form=self,
        )

        return submission
