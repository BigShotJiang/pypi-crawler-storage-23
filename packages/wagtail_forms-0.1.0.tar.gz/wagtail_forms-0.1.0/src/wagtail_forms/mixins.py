from django.db import models
from django.utils.timezone import now
from django.utils.translation import gettext_lazy as _


class SubmissionMetadataMixin(models.Model):
    """Mixin to store metadata for form submissions.

    This abstract model adds commonly needed metadata to any form submission,
    including the submission timestamp, IP address of the user, browser user agent,
    and the HTTP referer (i.e., the page from which the form was submitted).
    """

    submitted_at = models.DateTimeField(
        verbose_name=_('Submitted At'),
        help_text=_('The date and time when the form was submitted.'),
        default=now,
        editable=False,
    )
    ip_address = models.GenericIPAddressField(
        verbose_name=_('IP Address'),
        help_text=_('The IP address of the user who submitted the form.'),
        blank=True,
        null=True,
    )
    referer = models.URLField(
        verbose_name=_('Referer'),
        help_text=_('The URL of the page from which the form was submitted.'),
        blank=True,
        null=True,
    )
    user_agent = models.TextField(
        verbose_name=_('User Agent'),
        help_text=_('The browser or client software used to submit the form.'),
        blank=True,
        null=True,
    )

    def get_data(self):
        return {
            'submitted_at': self.submitted_at,
            'ip_address': self.ip_address,
            'referer': self.referer,
            'user_agent': self.user_agent,
        }

    class Meta:
        abstract = True
