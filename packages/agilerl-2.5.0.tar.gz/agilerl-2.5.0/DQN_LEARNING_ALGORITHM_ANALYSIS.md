# DQN Learning Algorithm Analysis

## Overview
Detailed analysis of the DQN learning algorithm implementation, focusing on the `learn()`, `update()`, and `soft_update()` methods.

## Algorithm Flow

### 1. `learn()` Method (lines 338-359)

```python
def learn(self, experiences: ExperiencesType) -> float:
    obs = experiences["obs"]
    actions = experiences["action"]
    rewards = experiences["reward"]
    next_obs = experiences["next_obs"]
    dones = experiences["done"]

    obs = self.preprocess_observation(obs)
    next_obs = self.preprocess_observation(next_obs)

    loss = self.update(obs, actions, rewards, next_obs, dones)

    # soft update target network
    self.soft_update()
    return loss.item()
```

**Analysis**: ✅ Looks correct
- Extracts experiences correctly
- Preprocesses observations
- Calls `update()` to compute loss and backpropagate
- Calls `soft_update()` after each learning step
- Returns scalar loss value

### 2. `update()` Method (lines 286-336)

```python
def update(self, obs, actions, rewards, next_obs, dones) -> torch.Tensor:
    with torch.no_grad():
        if self.double:  # Double Q-learning
            q_idx = self.actor(next_obs).argmax(dim=1).unsqueeze(1)
            q_target = (
                self.actor_target(next_obs).gather(dim=1, index=q_idx).detach()
            )
        else:
            q_target = self.actor_target(next_obs).max(axis=1)[0].unsqueeze(1)

        # target, if terminal then y_j = rewards
        y_j = rewards + self.gamma * q_target * (1 - dones)

    if actions.ndim == 1:
        actions = actions.unsqueeze(-1)

    # Compute Q-values for actions taken and loss
    q_eval = self.actor(obs).gather(1, actions.long())
    loss: torch.Tensor = self.criterion(q_eval, y_j)

    # zero gradients, perform a backward pass, and update the weights
    self.optimizer.zero_grad()
    if self.accelerator is not None:
        self.accelerator.backward(loss)
    else:
        loss.backward()

    self.optimizer.step()
    return loss.detach()
```

## Issues Found

### ⚠️ Issue 1: Inconsistent `max()` Usage (Line 316)

**Problem**: Uses `axis=1` instead of `dim=1`

```python
q_target = self.actor_target(next_obs).max(axis=1)[0].unsqueeze(1)
```

**Impact**: 
- PyTorch's `max()` accepts `axis` but it's deprecated
- Should use `dim=1` for consistency
- **However**: This shouldn't prevent learning, just causes deprecation warning

**Comparison**:
- Line 311: Uses `.argmax(dim=1)` ✅ (correct)
- Line 316: Uses `.max(axis=1)` ❌ (should be `dim=1`)

**Fix**:
```python
q_target = self.actor_target(next_obs).max(dim=1)[0].unsqueeze(1)
```

### ⚠️ Issue 2: Target Network Initialization Method

**Problem**: DQN uses a complex TensorDict-based initialization via `init_hook()`, while other algorithms use simple `load_state_dict()`

**DQN Approach** (lines 185-203):
```python
def init_hook(self) -> None:
    param_vals: TensorDict = from_module(self.actor).detach()
    target_params: TensorDict = param_vals.clone().lock_()
    try:
        target_params.to_module(self.actor_target)
    except KeyError:
        pass
    finally:
        self.param_vals = param_vals
        self.target_params = target_params
```

**RainbowDQN/CQN Approach**:
```python
self.actor_target.load_state_dict(self.actor.state_dict())
```

**Potential Issues**:
1. The `lock_()` creates a locked TensorDict that's detached from computation graph
2. If `to_module()` fails silently (caught by `except KeyError: pass`), target network might not be initialized
3. The locked TensorDict might interfere with `soft_update()` parameter updates

**Impact**: 
- If `to_module()` fails, target network starts with random weights instead of copying from actor
- This would cause incorrect Q-targets and prevent learning
- The silent exception handling makes this hard to detect

**Recommendation**: Add logging or assertion to verify target network is initialized:
```python
def init_hook(self) -> None:
    param_vals: TensorDict = from_module(self.actor).detach()
    target_params: TensorDict = param_vals.clone().lock_()
    try:
        target_params.to_module(self.actor_target)
    except KeyError as e:
        # Log the error instead of silently passing
        warnings.warn(f"Failed to initialize target network: {e}. Using load_state_dict fallback.")
        self.actor_target.load_state_dict(self.actor.state_dict())
    finally:
        self.param_vals = param_vals
        self.target_params = target_params
```

### ⚠️ Issue 3: Missing Gradient Clipping

**Problem**: DQN doesn't clip gradients, while RainbowDQN does

**RainbowDQN** (line 442):
```python
clip_grad_norm_(self.actor.parameters(), 10.0)
```

**DQN**: No gradient clipping

**Impact**: 
- Could lead to gradient explosion in some cases
- Not necessarily a bug, but could cause instability

**Recommendation**: Consider adding gradient clipping:
```python
from torch.nn.utils import clip_grad_norm_

# After loss.backward(), before optimizer.step()
clip_grad_norm_(self.actor.parameters(), max_norm=10.0)
self.optimizer.step()
```

### ✅ Correct Implementations

1. **Q-Learning Update Formula** (line 319): ✅ Correct
   ```python
   y_j = rewards + self.gamma * q_target * (1 - dones)
   ```

2. **Double Q-Learning** (lines 310-314): ✅ Correct
   - Uses actor to select action, target to evaluate

3. **Loss Computation** (line 326): ✅ Correct
   ```python
   q_eval = self.actor(obs).gather(1, actions.long())
   loss = self.criterion(q_eval, y_j)
   ```

4. **Gradient Flow** (lines 329-335): ✅ Correct
   - Zero gradients
   - Backward pass
   - Optimizer step

5. **Soft Update** (lines 361-368): ✅ Correct formula
   ```python
   target_param.data.copy_(
       self.tau * eval_param.data + (1.0 - self.tau) * target_param.data
   )
   ```

## Potential Learning Issues

### 1. Target Network Not Initialized Properly

**Most Likely Issue**: If `init_hook()` fails silently, target network has random weights, causing:
- Incorrect Q-targets
- No learning signal
- Random behavior

**How to Verify**:
```python
# After initialization, check if target network matches actor
actor_params = list(agent.actor.parameters())
target_params = list(agent.actor_target.parameters())
for a, t in zip(actor_params, target_params):
    if not torch.allclose(a.data, t.data, atol=1e-6):
        print("WARNING: Target network not initialized correctly!")
```

### 2. Tau Too Small

**Config**: `TAU: 0.001` (line 18)

**Impact**: 
- Very slow target network updates
- Target network stays close to initial values for a long time
- Slower learning convergence

**Typical Values**: 
- DQN papers often use `tau=0.01` or `tau=0.005`
- `tau=0.001` means only 0.1% update per step

**Recommendation**: Try `tau=0.01` or `tau=0.005`

### 3. Learning Rate

**Config**: `LR: 0.001` (line 12)

**Impact**: 
- Might be too high for some environments
- Could cause instability

**Typical Values**: 
- DQN often uses `lr=1e-4` to `lr=5e-4`
- `lr=0.001` is on the higher side

**Recommendation**: Try `lr=5e-4` or `lr=1e-4`

### 4. Learn Step Frequency

**Config**: `LEARN_STEP: 1` (line 17)

**Impact**: 
- Learning every step (with 16 parallel envs, that's 16 steps per environment step)
- Very frequent learning might cause instability
- Typical DQN learns every 4-5 steps

**Recommendation**: Try `LEARN_STEP: 4` or `LEARN_STEP: 5`

## Summary of Critical Issues

1. **🔴 HIGH PRIORITY**: Target network initialization might fail silently
   - Check if `init_hook()` actually initializes target network
   - Add fallback to `load_state_dict()` if TensorDict method fails

2. **🟡 MEDIUM PRIORITY**: Inconsistent `max()` usage
   - Change `axis=1` to `dim=1` for consistency

3. **🟡 MEDIUM PRIORITY**: Consider adding gradient clipping
   - Prevents gradient explosion

4. **🟡 MEDIUM PRIORITY**: Hyperparameter tuning
   - `tau=0.001` might be too small
   - `lr=0.001` might be too high
   - `learn_step=1` might be too frequent

## Recommended Fixes

### Fix 1: Improve Target Network Initialization

```python
def init_hook(self) -> None:
    """Resets module parameters for the detached and target networks."""
    param_vals: TensorDict = from_module(self.actor).detach()
    target_params: TensorDict = param_vals.clone().lock_()
    
    try:
        target_params.to_module(self.actor_target)
        # Verify initialization succeeded
        actor_first_param = next(self.actor.parameters()).data
        target_first_param = next(self.actor_target.parameters()).data
        if not torch.allclose(actor_first_param, target_first_param, atol=1e-5):
            raise RuntimeError("Target network initialization verification failed")
    except (KeyError, RuntimeError) as e:
        warnings.warn(f"TensorDict initialization failed ({e}), using load_state_dict fallback")
        self.actor_target.load_state_dict(self.actor.state_dict())
    finally:
        self.param_vals = param_vals
        self.target_params = target_params
```

### Fix 2: Fix max() Usage

```python
# Line 316
q_target = self.actor_target(next_obs).max(dim=1)[0].unsqueeze(1)
```

### Fix 3: Add Gradient Clipping (Optional)

```python
# After line 333 (loss.backward())
from torch.nn.utils import clip_grad_norm_
clip_grad_norm_(self.actor.parameters(), max_norm=10.0)
self.optimizer.step()
```
