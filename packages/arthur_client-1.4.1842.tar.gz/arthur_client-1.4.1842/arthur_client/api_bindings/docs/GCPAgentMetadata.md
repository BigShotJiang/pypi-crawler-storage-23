# GCPAgentMetadata


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**project_id** | **str** | Project ID of the agent. | 
**region** | **str** | Region of the agent. | 
**resource_id** | **str** | Resource ID of the agent. | 

## Example

```python
from arthur_client.api_bindings.models.gcp_agent_metadata import GCPAgentMetadata

# TODO update the JSON string below
json = "{}"
# create an instance of GCPAgentMetadata from a JSON string
gcp_agent_metadata_instance = GCPAgentMetadata.from_json(json)
# print the JSON string representation of the object
print(GCPAgentMetadata.to_json())

# convert the object into a dict
gcp_agent_metadata_dict = gcp_agent_metadata_instance.to_dict()
# create an instance of GCPAgentMetadata from a dict
gcp_agent_metadata_from_dict = GCPAgentMetadata.from_dict(gcp_agent_metadata_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


