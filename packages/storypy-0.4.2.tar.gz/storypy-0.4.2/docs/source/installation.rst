Installing StoryPy
==================
