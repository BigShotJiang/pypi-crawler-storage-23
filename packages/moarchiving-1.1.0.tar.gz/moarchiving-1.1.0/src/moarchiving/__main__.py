print('use ``python -m moarchiving.test`` to test the moarchiving module')
