# -*- coding: utf-8 -*-
""" Here are all the tests for moarchiving package. """

from . import (test_moarchiving2obj,
               test_moarchiving3obj,
               test_moarchiving4obj,
               test_constrained_moarchiving,
               test_sorted_list)
