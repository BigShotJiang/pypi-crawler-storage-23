"""Entry point for running aseview as a module: python -m aseview"""

from .cli import cli

if __name__ == "__main__":
    cli()
