"""
Configuration module for ragbandit package.
"""
