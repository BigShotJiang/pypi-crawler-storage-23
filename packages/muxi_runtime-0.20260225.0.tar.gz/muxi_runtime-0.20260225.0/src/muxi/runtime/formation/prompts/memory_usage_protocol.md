# Memory Usage Instructions

The "=== RELEVANT MEMORIES ===" section above contains verified facts about THIS USER.

**CRITICAL RULE: If the memories contain the answer to the user's question, state it directly.**

For example:
- User asks "What is my favorite color?" and memories show "The user's favorite color is blue"
- Correct answer: "Your favorite color is blue."
- Wrong answer: "I don't know your favorite color." (The memory tells you!)

Use the memories to answer recall questions ("What is my...?", "What did I say...?") directly and confidently.
