from __future__ import annotations

from sample2.sample2 import SAMPLE2

SAMPLE1 = "sample"

print(SAMPLE2)
