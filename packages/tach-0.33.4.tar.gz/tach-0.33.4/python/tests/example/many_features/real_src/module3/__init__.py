import module1

from .submodule1.api import Api

from globbed.other.module import something