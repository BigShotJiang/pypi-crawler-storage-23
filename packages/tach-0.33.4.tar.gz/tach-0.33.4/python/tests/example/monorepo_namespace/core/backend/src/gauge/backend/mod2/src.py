from __future__ import annotations

y = "mod2"
