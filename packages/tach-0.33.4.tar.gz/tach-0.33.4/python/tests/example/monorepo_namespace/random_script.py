from __future__ import annotations

print(""shouldnt matter!")
aasdfasdf
