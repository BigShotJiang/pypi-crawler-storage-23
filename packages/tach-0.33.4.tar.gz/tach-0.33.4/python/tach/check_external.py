from __future__ import annotations

from tach.extension import check_external_dependencies as check_external

__all__ = ["check_external"]
