This input visualizer is intended for use with BAPCtools' `bt generate`.
The visualizer should be invoked as `./visualizer <input_file_path> <answer_file_path> <...input_visualizer_args>` and should write a `testcase.<ext>` file.
