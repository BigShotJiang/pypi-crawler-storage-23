#!/usr/bin/env python3
import math

n = float(input())
print(4 * math.sqrt(n))
