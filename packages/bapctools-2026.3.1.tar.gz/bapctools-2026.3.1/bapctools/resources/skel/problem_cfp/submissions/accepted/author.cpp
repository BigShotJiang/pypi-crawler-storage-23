#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

// TODO: Remove this file and replace it by actual solutions.

int main() {
    int n;
    cin >> n;
    cout << fixed << setprecision(10) << 4*sqrt(n) << endl;
    return 0;
}
