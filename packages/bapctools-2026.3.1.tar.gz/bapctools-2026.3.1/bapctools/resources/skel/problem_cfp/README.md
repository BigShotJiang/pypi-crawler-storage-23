# Problem:

Print the perimeter of a square with a given area $a$.

NOTE: Please put possible variants of the problem in the problem statement
itself.
