#!/usr/bin/env python3
import sys

print(sys.stdin.read().strip())
