#!/usr/bin/env python3
# This should give CORRECT on the default problem 'hello'.
#
# Note that by default the extension .py is (currently) associated to
# Python2. The code below should also work with Python3, though.

print("Hello world!")
