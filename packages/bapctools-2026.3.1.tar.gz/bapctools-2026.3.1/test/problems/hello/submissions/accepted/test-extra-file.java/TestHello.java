/*
* This should give CORRECT on the default problem 'hello',
 * since the random extra file will not be passed to javac.
 */

import java.io.*;

class TestHello {
  public static void main(String[] args) throws Exception {
    System.out.print("Hello world!\n");
  }
}
