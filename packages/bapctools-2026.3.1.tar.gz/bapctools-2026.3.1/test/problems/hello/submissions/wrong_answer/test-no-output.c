/*
 * This should fail with NO-OUTPUT.
 */

int main()
{
	return 0;
}
