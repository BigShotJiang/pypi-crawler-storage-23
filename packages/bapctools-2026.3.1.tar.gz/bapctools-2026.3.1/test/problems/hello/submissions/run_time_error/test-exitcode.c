/*
 * This should fail with RUN-ERROR (due to exitcode != 0)
 */

int main()
{
	return 1;
}
