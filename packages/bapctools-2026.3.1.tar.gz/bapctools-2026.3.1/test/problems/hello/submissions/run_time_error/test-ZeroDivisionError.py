print(3 / 0)
