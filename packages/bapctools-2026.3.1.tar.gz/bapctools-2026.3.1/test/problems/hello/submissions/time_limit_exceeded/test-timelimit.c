/*
 * This should give a TIMELIMIT.
 */

int main()
{
	int a = 0;

	while ( 1 ) a++;

	return 0;
}
