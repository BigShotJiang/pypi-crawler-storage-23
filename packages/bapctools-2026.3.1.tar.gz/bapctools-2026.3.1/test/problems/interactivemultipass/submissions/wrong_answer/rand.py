#!/usr/bin/env python3
# very likely WA after second pass since the answer is random
import random

print(random.randrange(1000))
