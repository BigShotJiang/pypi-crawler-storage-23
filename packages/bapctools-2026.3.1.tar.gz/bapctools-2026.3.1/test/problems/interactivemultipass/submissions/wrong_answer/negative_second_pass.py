#!/usr/bin/env python3
# WA after second pass since number gets negative
print(-int(input()))
