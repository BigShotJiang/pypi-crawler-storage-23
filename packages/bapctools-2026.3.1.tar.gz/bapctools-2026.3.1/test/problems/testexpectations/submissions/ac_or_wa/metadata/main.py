import sys

print("wrong entry point!")
sys.exit(1)
