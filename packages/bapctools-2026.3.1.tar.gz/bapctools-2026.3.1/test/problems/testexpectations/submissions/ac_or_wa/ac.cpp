#include <string>
#include <iostream>
#include <ostream>

using namespace std;

int main() {
	string s;
	cin >> s;
	cout << s << endl;
}
