print(int(input()) & ~1)
