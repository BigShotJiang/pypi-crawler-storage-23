#!/usr/bin/env python3

print(42.0)
