#include <cstdlib>
int main() { exit(1); }
