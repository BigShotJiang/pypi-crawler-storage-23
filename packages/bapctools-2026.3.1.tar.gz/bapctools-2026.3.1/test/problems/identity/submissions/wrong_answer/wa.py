#!/usr/bin/env python3
print(int(input()) + 1)
