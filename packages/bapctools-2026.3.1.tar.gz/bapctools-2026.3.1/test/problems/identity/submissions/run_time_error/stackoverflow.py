#!/usr/bin/env python3
def f():
    f()


f()
