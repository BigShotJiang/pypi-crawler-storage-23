#include "lib.h"

int main(int argc, char** argv) {
	output(argv[1]);
	return 0;
}
