#include "stdio.h"

void output(char* s) { printf("%s\n", s); }
