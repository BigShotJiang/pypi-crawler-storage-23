print(input().split()[1])
