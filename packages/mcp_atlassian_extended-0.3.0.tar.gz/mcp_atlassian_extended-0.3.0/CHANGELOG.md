# Changelog

## [0.3.0] - 2026-02-23

### Other


## [0.2.1] - 2026-02-23

### Bug Fixes
- fix(ci): use temp files for blob creation to avoid ARG_MAX (#18) (606a858)
- fix(ci): include uv.lock and CHANGELOG.md in release commits (#17) (8be8ffb)

