"""
Hypervisor Integration Adapters

Bridges between the Hypervisor and other Agent-OS modules:
- Nexus (trust scoring) → ring assignment
- Verification (behavioral verification) → drift-triggered penalty
- IATP (capability manifests) → reversibility + trust enrichment
"""
