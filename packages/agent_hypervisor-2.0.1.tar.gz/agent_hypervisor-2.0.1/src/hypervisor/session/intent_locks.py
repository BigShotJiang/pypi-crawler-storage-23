# Community Edition — basic implementation
"""
Resource Locks — stub implementation.

Community edition: locks are not enforced. All acquire calls succeed.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional
import uuid


class LockIntent(str, Enum):
    """Types of lock intent."""

    READ = "read"
    WRITE = "write"
    EXCLUSIVE = "exclusive"


@dataclass
class IntentLock:
    """A declared resource lock on a resource."""

    lock_id: str = field(default_factory=lambda: f"lock:{uuid.uuid4().hex[:8]}")
    agent_did: str = ""
    session_id: str = ""
    resource_path: str = ""
    intent: LockIntent = LockIntent.READ
    acquired_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    is_active: bool = True
    saga_step_id: Optional[str] = None


class LockContentionError(Exception):
    """Raised when lock contention is detected."""


class DeadlockError(Exception):
    """Raised when a deadlock is detected."""


class IntentLockManager:
    """
    Resource lock stub (community edition: all locks succeed, no contention).
    """

    def __init__(self) -> None:
        self._locks: dict[str, IntentLock] = {}

    def acquire(
        self,
        agent_did: str,
        session_id: str,
        resource_path: str,
        intent: LockIntent,
        saga_step_id: Optional[str] = None,
    ) -> IntentLock:
        """Acquire a lock (community edition: always succeeds)."""
        lock = IntentLock(
            agent_did=agent_did,
            session_id=session_id,
            resource_path=resource_path,
            intent=intent,
            saga_step_id=saga_step_id,
        )
        self._locks[lock.lock_id] = lock
        return lock

    def release(self, lock_id: str) -> None:
        """Release a lock."""
        lock = self._locks.get(lock_id)
        if lock:
            lock.is_active = False

    def release_agent_locks(self, agent_did: str, session_id: str) -> int:
        count = 0
        for lock in list(self._locks.values()):
            if lock.agent_did == agent_did and lock.session_id == session_id and lock.is_active:
                lock.is_active = False
                count += 1
        return count

    def release_session_locks(self, session_id: str) -> int:
        count = 0
        for lock in list(self._locks.values()):
            if lock.session_id == session_id and lock.is_active:
                lock.is_active = False
                count += 1
        return count

    def get_agent_locks(self, agent_did: str, session_id: str) -> list[IntentLock]:
        return [
            l for l in self._locks.values()
            if l.agent_did == agent_did
            and l.session_id == session_id
            and l.is_active
        ]

    def get_resource_locks(self, resource_path: str) -> list[IntentLock]:
        return [
            l for l in self._locks.values()
            if l.resource_path == resource_path
            and l.is_active
        ]

    @property
    def active_lock_count(self) -> int:
        return sum(1 for l in self._locks.values() if l.is_active)

    @property
    def contention_points(self) -> list[str]:
        return []
