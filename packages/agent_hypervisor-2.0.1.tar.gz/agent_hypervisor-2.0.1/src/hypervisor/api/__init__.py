"""Hypervisor REST API package."""

from hypervisor.api.server import create_app

__all__ = ["create_app"]
