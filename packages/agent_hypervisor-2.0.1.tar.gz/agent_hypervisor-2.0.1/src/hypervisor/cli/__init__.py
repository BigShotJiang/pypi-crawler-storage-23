"""CLI for inspecting hypervisor session state."""
