from graph_mcp.server import main

main()
