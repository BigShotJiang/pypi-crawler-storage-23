"""Thin shim kept for backward compatibility. All metadata lives in pyproject.toml."""

from setuptools import setup

setup()
