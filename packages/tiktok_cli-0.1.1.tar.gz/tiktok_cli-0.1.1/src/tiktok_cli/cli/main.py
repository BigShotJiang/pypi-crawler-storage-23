from __future__ import annotations

import typer
from click import Option
from click.core import ParameterSource

from tiktok_cli._runtime.core.database.manager import init_db
from tiktok_cli.cli.options import CliContext
from tiktok_cli.cli.runtime import run_sync_command
from tiktok_cli.domain.errors import DependencyMissingError
from tiktok_cli.infra.logger import setup_cli_logger
from tiktok_cli.infra.paths import configure_legacy_data_paths, ensure_runtime_dirs
from tiktok_cli.infra.platforms import TIKTOK_PLATFORM

APP_HELP = """
TikTok CLI（非驻留，一次命令一次进程）。

接口形态与 rednote-cli 对齐，便于 Agent 复用同一套编排。
当前平台适配器尚未实现，业务命令会返回 `DEPENDENCY_MISSING`（退出码 7）。

推荐调用约定：
- `--format json`
- `--trace-id <id>`
- 依赖 `stderr` 日志与 `stdout` 结构化结果分离
""".strip()

app = typer.Typer(help=APP_HELP, add_completion=True, no_args_is_help=True)
auth_app = typer.Typer(help="认证与登录态管理", no_args_is_help=True)
account_app = typer.Typer(help="账号池管理", no_args_is_help=True)
note_app = typer.Typer(help="笔记详情查询", no_args_is_help=False)
user_app = typer.Typer(help="用户详情查询", no_args_is_help=False)
search_app = typer.Typer(help="统一搜索入口（笔记/用户）", no_args_is_help=True)
search_note_app = typer.Typer(help="搜索笔记", no_args_is_help=False)
search_user_app = typer.Typer(help="搜索用户", no_args_is_help=False)
publish_app = typer.Typer(help="发布相关命令", no_args_is_help=True)
doctor_app = typer.Typer(help="环境诊断", no_args_is_help=True)
init_app = typer.Typer(help="初始化运行环境", no_args_is_help=True)


def _not_implemented(feature: str):
    raise DependencyMissingError(f"{TIKTOK_PLATFORM} adapter not implemented yet: {feature}")


def _all_cli_params_are_default(*, ctx: typer.Context) -> bool:
    for param in ctx.command.params:
        if not isinstance(param, Option):
            continue
        if ctx.get_parameter_source(param.name) != ParameterSource.DEFAULT:
            return False
    return True


@auth_app.command("login")
def auth_login(ctx: typer.Context):
    """登录（当前为占位实现）。"""
    cli_ctx: CliContext = ctx.obj
    run_sync_command(ctx=cli_ctx, command="auth.login", func=lambda: _not_implemented("auth.login"))


@auth_app.command("logout")
def auth_logout(ctx: typer.Context, account: str = typer.Option(..., "--account", help="账号唯一标识（user_id）")):
    """登出指定账号（当前为占位实现）。"""
    cli_ctx: CliContext = ctx.obj
    run_sync_command(
        ctx=cli_ctx,
        command="auth.logout",
        func=lambda: _not_implemented("auth.logout"),
        account_uid=account,
    )


@auth_app.command("status")
def auth_status(ctx: typer.Context, account: str | None = typer.Option(None, "--account", help="账号唯一标识（user_id）")):
    """查询登录状态（当前为占位实现）。"""
    cli_ctx: CliContext = ctx.obj
    run_sync_command(
        ctx=cli_ctx,
        command="auth.status",
        func=lambda: _not_implemented("auth.status"),
        account_uid=account,
    )


@account_app.command("list")
def account_list(ctx: typer.Context):
    """列出账号池（当前为占位实现）。"""
    cli_ctx: CliContext = ctx.obj
    run_sync_command(ctx=cli_ctx, command="account.list", func=lambda: _not_implemented("account.list"))


@account_app.command("activate")
def account_activate(ctx: typer.Context, account: str = typer.Option(..., "--account", help="账号唯一标识（user_id）")):
    """激活账号（当前为占位实现）。"""
    cli_ctx: CliContext = ctx.obj
    run_sync_command(
        ctx=cli_ctx,
        command="account.activate",
        func=lambda: _not_implemented("account.activate"),
        account_uid=account,
    )


@account_app.command("deactivate")
def account_deactivate(ctx: typer.Context, account: str = typer.Option(..., "--account", help="账号唯一标识（user_id）")):
    """停用账号（当前为占位实现）。"""
    cli_ctx: CliContext = ctx.obj
    run_sync_command(
        ctx=cli_ctx,
        command="account.deactivate",
        func=lambda: _not_implemented("account.deactivate"),
        account_uid=account,
    )


@account_app.command("delete")
def account_delete(ctx: typer.Context, account: str = typer.Option(..., "--account", help="账号唯一标识（user_id）")):
    """删除账号（当前为占位实现）。"""
    cli_ctx: CliContext = ctx.obj
    run_sync_command(
        ctx=cli_ctx,
        command="account.delete",
        func=lambda: _not_implemented("account.delete"),
        account_uid=account,
    )


@note_app.callback(invoke_without_command=True)
def note_get(ctx: typer.Context, note_id: str | None = typer.Option(None, "--note-id", help="笔记 ID")):
    """获取笔记详情（当前为占位实现）。"""
    if _all_cli_params_are_default(ctx=ctx):
        typer.echo(ctx.get_help())
        raise typer.Exit(code=0)

    cli_ctx: CliContext = ctx.obj
    run_sync_command(ctx=cli_ctx, command="note.get", func=lambda: _not_implemented("note.get"))


@search_note_app.callback(invoke_without_command=True)
def note_search(ctx: typer.Context, keyword: str | None = typer.Option(None, "--keyword", help="搜索关键词")):
    """搜索笔记（当前为占位实现）。"""
    if _all_cli_params_are_default(ctx=ctx):
        typer.echo(ctx.get_help())
        raise typer.Exit(code=0)

    cli_ctx: CliContext = ctx.obj
    run_sync_command(ctx=cli_ctx, command="note.search", func=lambda: _not_implemented("note.search"))


@user_app.callback(invoke_without_command=True)
def user_get(ctx: typer.Context, user_id: str | None = typer.Option(None, "--user-id", help="用户 ID")):
    """获取用户详情（当前为占位实现）。"""
    if ctx.invoked_subcommand:
        return
    if _all_cli_params_are_default(ctx=ctx):
        typer.echo(ctx.get_help())
        raise typer.Exit(code=0)

    cli_ctx: CliContext = ctx.obj
    run_sync_command(ctx=cli_ctx, command="user.get", func=lambda: _not_implemented("user.get"))


@search_user_app.callback(invoke_without_command=True)
def user_search(ctx: typer.Context, keyword: str | None = typer.Option(None, "--keyword", help="搜索关键词")):
    """搜索用户（当前为占位实现）。"""
    if _all_cli_params_are_default(ctx=ctx):
        typer.echo(ctx.get_help())
        raise typer.Exit(code=0)

    cli_ctx: CliContext = ctx.obj
    run_sync_command(ctx=cli_ctx, command="user.search", func=lambda: _not_implemented("user.search"))


@user_app.command("self")
def user_self(ctx: typer.Context):
    """获取当前账号信息（当前为占位实现）。"""
    cli_ctx: CliContext = ctx.obj
    run_sync_command(ctx=cli_ctx, command="user.self", func=lambda: _not_implemented("user.self"))


@publish_app.command("note")
def publish_note(ctx: typer.Context, target: str = typer.Option(..., "--target", help="发布类型 image|video|article")):
    """发布笔记（当前为占位实现）。"""
    cli_ctx: CliContext = ctx.obj
    run_sync_command(ctx=cli_ctx, command="publish.note", func=lambda: _not_implemented("publish.note"))


@doctor_app.command("run")
def doctor_run(ctx: typer.Context):
    """环境自检（当前为占位实现）。"""
    cli_ctx: CliContext = ctx.obj
    run_sync_command(ctx=cli_ctx, command="doctor.run", func=lambda: _not_implemented("doctor.run"))


@init_app.command("runtime")
def init_runtime(ctx: typer.Context):
    """初始化运行目录（当前为占位实现）。"""
    cli_ctx: CliContext = ctx.obj
    run_sync_command(ctx=cli_ctx, command="init.runtime", func=lambda: _not_implemented("init.runtime"))


app.add_typer(init_app, name="init")
app.add_typer(doctor_app, name="doctor")
app.add_typer(auth_app, name="auth")
app.add_typer(account_app, name="account")
app.add_typer(note_app, name="note")
app.add_typer(user_app, name="user")
app.add_typer(search_app, name="search")
app.add_typer(publish_app, name="publish")

search_app.add_typer(search_note_app, name="note")
search_app.add_typer(search_user_app, name="user")


@app.callback()
def main(
    ctx: typer.Context,
    format: str = typer.Option("table", "--format", help="输出格式：json|jsonl|table"),
    out: str | None = typer.Option(None, "--out", help="输出文件路径"),
    quiet: bool = typer.Option(False, "--quiet", help="静默日志，仅输出结果"),
    trace_id: str | None = typer.Option(None, "--trace-id", help="请求链路 ID"),
    timeout: int = typer.Option(120, "--timeout", help="命令超时（秒）"),
):
    if format not in {"json", "jsonl", "table"}:
        raise typer.BadParameter("--format 仅支持 json|jsonl|table")

    ensure_runtime_dirs()
    configure_legacy_data_paths()
    init_db()
    setup_cli_logger(quiet=quiet)

    ctx.obj = CliContext(
        platform_name=TIKTOK_PLATFORM,
        output_format=format,
        out_file=out,
        quiet=quiet,
        trace_id=trace_id,
        timeout=timeout,
    )


def run() -> None:
    app()


if __name__ == "__main__":
    run()
