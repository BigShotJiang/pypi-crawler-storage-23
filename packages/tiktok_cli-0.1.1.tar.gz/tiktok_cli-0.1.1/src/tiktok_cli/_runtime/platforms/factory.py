from __future__ import annotations

from dataclasses import dataclass

from tiktok_cli._runtime.common.enums import Platform


@dataclass(frozen=True)
class PlatformLoginProfile:
    login_url: str
    login_selector: str
    qr_selector: str
    account_id_field: str = "user_no"
    nickname_field: str = "nickname"
    guest_field: str = "guest"


class PlatformFactory:
    """Factory for creating platform-specific runtime objects."""

    _extractor_registry: dict[Platform, type] = {}
    _login_profile_registry: dict[Platform, PlatformLoginProfile] = {}

    @classmethod
    def register_extractor(cls, platform_enum: Platform, extractor_cls: type) -> None:
        cls._extractor_registry[platform_enum] = extractor_cls

    @classmethod
    def register_login_profile(cls, platform_enum: Platform, profile: PlatformLoginProfile) -> None:
        cls._login_profile_registry[platform_enum] = profile

    @classmethod
    def register_platform(
        cls,
        platform_enum: Platform,
        *,
        extractor_cls: type,
        login_profile: PlatformLoginProfile,
    ) -> None:
        cls.register_extractor(platform_enum, extractor_cls)
        cls.register_login_profile(platform_enum, login_profile)

    @classmethod
    def get_extractor(cls, platform_enum: Platform, page):
        extractor_cls = cls._extractor_registry.get(platform_enum)
        if extractor_cls is None:
            raise ValueError(f"Unsupported platform: {platform_enum}")
        return extractor_cls(page)

    @classmethod
    def get_login_profile(cls, platform_enum: Platform) -> PlatformLoginProfile:
        profile = cls._login_profile_registry.get(platform_enum)
        if profile is None:
            raise ValueError(f"Unsupported platform: {platform_enum}")
        return profile
