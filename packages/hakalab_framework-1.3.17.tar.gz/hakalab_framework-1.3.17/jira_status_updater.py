"""
Actualizador de Estado en Jira para Behave
Permite actualizar un campo personalizado "Estado" en issues de Jira
basado en el resultado de los escenarios de Behave.

Uso:
    from jira_status_updater import JiraStatusUpdater
    
    updater = JiraStatusUpdater()
    updater.update_issue_status("PROJ-123", "Passed")
"""

import os
import requests
import base64
import re
import json
from typing import Optional, List
from enum import Enum


class TestStatus(Enum):
    """Estados posibles de las pruebas"""
    PASSED = "Passed"
    FAILED = "Failed"
    TODO = "Todo"


class JiraStatusUpdater:
    """Clase para actualizar el estado de issues en Jira"""
    
    def __init__(self):
        """Inicializar el actualizador con variables de entorno"""
        self.jira_url = os.getenv('JIRA_URL', '').rstrip('/')
        self.jira_email = os.getenv('JIRA_EMAIL')
        self.jira_token = os.getenv('JIRA_TOKEN')
        self.jira_enabled = os.getenv('JIRA_ENABLED', 'false').lower() == 'true'
        
        # Permitir configurar el ID del campo directamente
        self.custom_field_id = os.getenv('JIRA_ESTADO_FIELD_ID', None)
        
        self.is_configured = self._validate_configuration()
        self.session = None
        
        if self.is_configured:
            self._setup_session()
            # Solo buscar el campo si no está configurado directamente
            if not self.custom_field_id:
                self._find_custom_field()
            else:
                print(f"✅ Usando campo configurado: {self.custom_field_id}")
    
    def _validate_configuration(self) -> bool:
        """Validar que todas las variables de entorno necesarias estén configuradas"""
        if not self.jira_enabled:
            print("⚠️ Jira está deshabilitado (JIRA_ENABLED=false)")
            return False
        
        required_vars = [self.jira_url, self.jira_email, self.jira_token]
        
        if not all(required_vars):
            missing = []
            if not self.jira_url:
                missing.append('JIRA_URL')
            if not self.jira_email:
                missing.append('JIRA_EMAIL')
            if not self.jira_token:
                missing.append('JIRA_TOKEN')
            
            print(f"❌ Jira no configurado. Variables faltantes: {', '.join(missing)}")
            return False
        
        return True
    
    def _setup_session(self):
        """Configurar la sesión HTTP con autenticación básica"""
        self.session = requests.Session()
        
        # Crear credenciales básicas
        credentials = f"{self.jira_email}:{self.jira_token}"
        encoded_credentials = base64.b64encode(credentials.encode()).decode()
        
        self.session.headers.update({
            'Authorization': f'Basic {encoded_credentials}',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        })
    
    def _find_custom_field(self) -> bool:
        """Buscar el ID del campo personalizado 'Estado' (combobox)"""
        if not self.is_configured:
            return False
        
        try:
            response = self.session.get(f"{self.jira_url}/rest/api/3/field")
            
            if response.status_code == 200:
                fields = response.json()
                
                # Buscar el campo "Estado" - debe ser un custom field de tipo select/combobox
                candidates = []
                
                for field in fields:
                    field_name = field.get('name', '').strip()
                    field_id = field.get('id', '')
                    field_type = field.get('schema', {}).get('type', 'unknown')
                    is_custom = field_id.startswith('customfield_')
                    
                    # Buscar coincidencia exacta de nombre (case-insensitive)
                    if field_name.lower() == 'estado' and is_custom:
                        candidates.append({
                            'id': field_id,
                            'name': field_name,
                            'type': field_type,
                            'is_custom': is_custom,
                            'full_field': field
                        })
                
                if candidates:
                    # Si hay múltiples, preferir 'option' o 'select' type
                    selected = None
                    for candidate in candidates:
                        if candidate['type'] in ['option', 'select', 'array']:
                            selected = candidate
                            break
                    
                    if not selected:
                        selected = candidates[0]
                    
                    self.custom_field_id = selected['id']
                    print(f"✅ Campo 'Estado' encontrado: {selected['id']} ({selected['name']})")
                    print(f"   Tipo: {selected['type']}")
                    print(f"   Es custom field: {selected['is_custom']}")
                    
                    if len(candidates) > 1:
                        print(f"   Nota: Se encontraron {len(candidates)} campos con nombre 'Estado'")
                    
                    return True
                else:
                    print(f"❌ Campo personalizado 'Estado' no encontrado")
                    print(f"\n   Campos personalizados disponibles:")
                    custom_count = 0
                    for field in fields:
                        field_id = field.get('id', '')
                        if field_id.startswith('customfield_'):
                            field_name = field.get('name', '')
                            field_type = field.get('schema', {}).get('type', 'unknown')
                            print(f"   - {field_id}: {field_name} [{field_type}]")
                            custom_count += 1
                            if custom_count >= 20:
                                print(f"   ... y más")
                                break
                    
                    print(f"\n   💡 Soluciones:")
                    print(f"   1. Verifica que el campo existe en Jira con nombre exacto 'Estado'")
                    print(f"   2. Configura manualmente: JIRA_ESTADO_FIELD_ID=customfield_XXXXX")
                    return False
                
                print("⚠️ Campo 'Estado' no encontrado en Jira")
                print("   Campos personalizados disponibles:")
                for field in fields:
                    if field.get('custom'):
                        print(f"   - {field.get('name')} ({field.get('id')})")
                return False
            else:
                print(f"❌ Error al obtener campos: {response.status_code}")
                return False
        except Exception as e:
            print(f"❌ Error al buscar campo personalizado: {str(e)}")
            return False
    
    def test_connection(self) -> bool:
        """Probar la conexión con Jira"""
        if not self.is_configured:
            return False
        
        try:
            response = self.session.get(f"{self.jira_url}/rest/api/3/myself")
            
            if response.status_code == 200:
                user_info = response.json()
                print(f"✅ Conexión exitosa con Jira. Usuario: {user_info.get('displayName', 'N/A')}")
                return True
            elif response.status_code == 401:
                print(f"❌ Error: 401 - Credenciales inválidas")
                return False
            else:
                print(f"❌ Error de conexión: {response.status_code}")
                return False
        except Exception as e:
            print(f"❌ Error al conectar: {str(e)}")
            return False
    
    def list_all_fields(self):
        """Listar todos los campos disponibles en Jira (para debugging)"""
        if not self.is_configured:
            print("❌ Jira no configurado")
            return
        
        try:
            response = self.session.get(f"{self.jira_url}/rest/api/3/field")
            
            if response.status_code == 200:
                fields = response.json()
                print(f"\n📋 Total de campos disponibles: {len(fields)}\n")
                
                # Separar campos custom y system
                custom_fields = []
                system_fields = []
                
                for field in fields:
                    field_id = field.get('id', '')
                    field_name = field.get('name', '')
                    field_type = field.get('schema', {}).get('type', 'unknown')
                    
                    field_info = {
                        'id': field_id,
                        'name': field_name,
                        'type': field_type
                    }
                    
                    if field_id.startswith('customfield_'):
                        custom_fields.append(field_info)
                    else:
                        system_fields.append(field_info)
                
                print("🔧 CAMPOS PERSONALIZADOS (Custom Fields):")
                for field in custom_fields:
                    print(f"  {field['id']}: {field['name']} [{field['type']}]")
                
                print("\n⚙️ CAMPOS DE SISTEMA (System Fields):")
                for field in system_fields[:30]:  # Mostrar solo los primeros 30
                    print(f"  {field['id']}: {field['name']} [{field['type']}]")
                
                if len(system_fields) > 30:
                    print(f"  ... y {len(system_fields) - 30} campos más")
                
            else:
                print(f"❌ Error al obtener campos: {response.status_code}")
        except Exception as e:
            print(f"❌ Error: {str(e)}")
    
    def issue_exists(self, issue_key: str) -> bool:
        """Verificar si una issue existe en Jira"""
        if not self.is_configured:
            return False
        
        try:
            response = self.session.get(f"{self.jira_url}/rest/api/3/issue/{issue_key}")
            return response.status_code == 200
        except Exception:
            return False
    
    def _get_field_options(self, issue_key: str) -> dict:
        """Obtener las opciones válidas para el campo 'Estado' de una issue específica
        
        Esto es importante porque Jira necesita el ID de la opción, no el nombre.
        """
        if not self.is_configured or not self.custom_field_id:
            return {}
        
        try:
            # Obtener la issue para ver qué opciones están disponibles
            response = self.session.get(
                f"{self.jira_url}/rest/api/3/issue/{issue_key}/editmeta"
            )
            
            if response.status_code == 200:
                edit_meta = response.json()
                fields = edit_meta.get('fields', {})
                
                if self.custom_field_id in fields:
                    field_meta = fields[self.custom_field_id]
                    allowed_values = field_meta.get('allowedValues', [])
                    
                    # Crear un mapeo de nombre -> id
                    options_map = {}
                    for option in allowed_values:
                        option_name = option.get('value', option.get('name', ''))
                        option_id = option.get('id', option_name)
                        options_map[option_name] = {
                            'id': option_id,
                            'name': option_name,
                            'full_option': option
                        }
                    
                    print(f"📋 Opciones disponibles para {self.custom_field_id}:")
                    for name, data in options_map.items():
                        print(f"   - {name} (ID: {data['id']})")
                    
                    return options_map
            
            return {}
        except Exception as e:
            print(f"⚠️ Error obteniendo opciones del campo: {e}")
            return {}
    
    def update_issue_status(self, issue_key: str, status: str) -> bool:
        """Actualizar el estado de una issue en Jira
        
        Args:
            issue_key: Clave de la issue (ej: "PROJ-123")
            status: Estado a establecer ("Passed", "Failed", "Todo")
        
        Returns:
            True si la actualización fue exitosa, False en caso contrario
        """
        if not self.is_configured:
            print(f"⚠️ Jira deshabilitado, no se actualiza {issue_key}")
            return False
        
        if not self.custom_field_id:
            print(f"⚠️ Campo 'Estado' no configurado, no se puede actualizar {issue_key}")
            return False
        
        # Validar que el estado sea válido
        valid_statuses = [s.value for s in TestStatus]
        if status not in valid_statuses:
            print(f"❌ Estado inválido: {status}. Valores válidos: {valid_statuses}")
            return False
        
        try:
            # Verificar que la issue existe
            if not self.issue_exists(issue_key):
                print(f"⚠️ Issue {issue_key} no encontrada en Jira")
                return False
            
            # Obtener las opciones válidas del campo
            options_map = self._get_field_options(issue_key)
            
            if not options_map:
                print(f"⚠️ No se pudieron obtener las opciones del campo 'Estado'")
                # Intentar con el valor directo como fallback
                field_value = status
            else:
                # Buscar la opción que coincida con el estado
                field_value = None
                for option_name, option_data in options_map.items():
                    if option_name.lower() == status.lower():
                        field_value = option_data['full_option']
                        print(f"✓ Usando opción: {option_name}")
                        break
                
                if not field_value:
                    print(f"❌ No se encontró opción '{status}' en el campo 'Estado'")
                    print(f"   Opciones disponibles: {list(options_map.keys())}")
                    return False
            
            # Preparar datos para actualizar
            update_data = {
                "fields": {
                    self.custom_field_id: field_value
                }
            }
            
            print(f"📤 Enviando actualización: {update_data}")
            
            # Enviar actualización
            response = self.session.put(
                f"{self.jira_url}/rest/api/3/issue/{issue_key}",
                json=update_data
            )
            
            if response.status_code == 204:
                print(f"✅ Issue {issue_key} actualizada a estado: {status}")
                return True
            elif response.status_code == 400:
                print(f"❌ Error 400: Solicitud inválida")
                print(f"   Respuesta: {response.text}")
                print(f"   Datos enviados: {json.dumps(update_data, indent=2)}")
                return False
            elif response.status_code == 403:
                print(f"❌ Error 403: Sin permisos para actualizar {issue_key}")
                return False
            elif response.status_code == 404:
                print(f"❌ Error 404: Issue {issue_key} no encontrada")
                return False
            else:
                print(f"❌ Error al actualizar {issue_key}: {response.status_code}")
                print(f"   Respuesta: {response.text}")
                return False
        except Exception as e:
            print(f"❌ Error al actualizar {issue_key}: {str(e)}")
            return False
    
    def extract_issue_key_from_tag(self, tag: str) -> Optional[str]:
        """Extraer clave de issue de un tag de Behave
        
        Soporta formatos como:
        - @PROJ-123
        - @proj-123
        - PROJ-123
        
        Args:
            tag: Tag de Behave
        
        Returns:
            Clave de issue en formato correcto o None
        """
        # Remover @ si está presente
        clean_tag = tag.lstrip('@').strip()
        
        # Buscar patrón PROJECT-NUMBER
        match = re.match(r'^([A-Z]+)-(\d+)$', clean_tag.upper())
        if match:
            return clean_tag.upper()
        
        return None
    
    def update_from_scenario_tags(self, tags: List[str], status: str) -> dict:
        """Actualizar issues basado en tags de escenario
        
        Args:
            tags: Lista de tags del escenario (ej: ["@PROJ-123", "@smoke"])
            status: Estado a establecer ("Passed", "Failed", "Todo")
        
        Returns:
            Diccionario con resultados de actualización
        """
        results = {}
        
        if not self.is_configured:
            print("⚠️ Jira deshabilitado, no se actualizan issues")
            return results
        
        for tag in tags:
            issue_key = self.extract_issue_key_from_tag(tag)
            if issue_key:
                print(f"🔍 Actualizando issue {issue_key} a estado: {status}")
                success = self.update_issue_status(issue_key, status)
                results[issue_key] = success
        
        return results


# Función auxiliar para usar en hooks de Behave
def update_jira_status_after_scenario(scenario, status: str):
    """Función auxiliar para actualizar Jira después de un escenario
    
    Uso en environment.py:
        def after_scenario(context, scenario):
            if scenario.status == 'passed':
                update_jira_status_after_scenario(scenario, "Passed")
            elif scenario.status == 'failed':
                update_jira_status_after_scenario(scenario, "Failed")
    
    Args:
        scenario: Objeto de escenario de Behave
        status: Estado a establecer
    """
    updater = JiraStatusUpdater()
    
    if not updater.is_configured:
        return
    
    # Obtener tags del escenario
    tags = [tag for tag in scenario.tags] if hasattr(scenario, 'tags') else []
    
    if tags:
        print(f"\n📋 Procesando tags del escenario: {tags}")
        results = updater.update_from_scenario_tags(tags, status)
        
        if results:
            passed = sum(1 for v in results.values() if v)
            total = len(results)
            print(f"📊 Resultado: {passed}/{total} issues actualizadas")
    else:
        print("⚠️ El escenario no tiene tags con issue keys")
