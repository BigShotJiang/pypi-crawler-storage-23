#!/usr/bin/env python3
"""
Runner para ejecutar tests con filtro de tags específico
"""
import subprocess
import sys
from pathlib import Path
from dotenv import load_dotenv
from hakalab_framework import get_features_selection

def run_behave_tests(tags='@PROD-145'):
    # 1. Cargar entorno
    if Path('.env').exists():
        load_dotenv('.env')
    
    # 2. Obtener features (local o sharded) CON FILTRO DE TAG
    features_to_run = get_features_selection(tag=tags)
    
    if not features_to_run:
        print(f"[INFO] No hay features con el tag {tags}")
        return 0
    
    # 3. Construir comando de Behave
    command = ['python', '-m', 'behave', '--no-capture', '--no-skipped']
    command.extend(features_to_run)
    
    print(f"[RUNNER] Ejecutando: {' '.join(command)}")
    print(f"[RUNNER] Filtro de tag: {tags}")
    print("-" * 50)
    
    try:
        return subprocess.run(command).returncode
    except Exception as e:
        print(f"[ERROR] Error crítico: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(run_behave_tests())
