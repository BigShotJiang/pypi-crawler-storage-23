#!/usr/bin/env python3
"""
Script de diagnóstico para verificar la configuración de Jira/Xray localmente
"""
import os
import sys
from pathlib import Path

# Agregar el directorio padre al path
sys.path.insert(0, str(Path(__file__).parent.parent))

from dotenv import load_dotenv

def main():
    print("🔍 DIAGNÓSTICO LOCAL DE CONFIGURACIÓN JIRA/XRAY")
    print("=" * 50)
    
    # Cambiar al directorio de testing
    os.chdir(Path(__file__).parent)
    
    # Cargar .env local
    load_dotenv()
    
    # Variables que busca el framework
    jira_vars = {
        'JIRA_ENABLED': os.getenv('JIRA_ENABLED'),
        'JIRA_URL': os.getenv('JIRA_URL'),
        'JIRA_EMAIL': os.getenv('JIRA_EMAIL'),
        'JIRA_TOKEN': os.getenv('JIRA_TOKEN'),
        'JIRA_PROJECT': os.getenv('JIRA_PROJECT'),
        'JIRA_COMMENT_MESSAGE': os.getenv('JIRA_COMMENT_MESSAGE'),
    }
    
    xray_vars = {
        'XRAY_AUTHORIZATION_TOKEN': os.getenv('XRAY_AUTHORIZATION_TOKEN'),
        'XRAY_BASE_URL': os.getenv('XRAY_BASE_URL'),
    }
    
    print("\n📋 VARIABLES DE JIRA:")
    for var, value in jira_vars.items():
        if value and 'TU_' not in value:
            # Mostrar solo los primeros y últimos caracteres para tokens
            if 'TOKEN' in var and len(value) > 10:
                display_value = f"{value[:10]}...{value[-10:]}"
            elif 'EMAIL' in var:
                display_value = value
            else:
                display_value = value
            print(f"  ✅ {var}: {display_value}")
        else:
            print(f"  ❌ {var}: NO CONFIGURADA")
    
    print("\n🧪 VARIABLES DE XRAY:")
    for var, value in xray_vars.items():
        if value and 'TU_' not in value:
            if 'TOKEN' in var and len(value) > 10:
                display_value = f"{value[:10]}...{value[-10:]}"
            else:
                display_value = value
            print(f"  ✅ {var}: {display_value}")
        else:
            print(f"  ❌ {var}: NO CONFIGURADA")
    
    print("\n🔧 VERIFICACIÓN DE CONFIGURACIÓN:")
    
    # Verificar si Jira está habilitado
    jira_enabled = os.getenv('JIRA_ENABLED', 'false').lower() == 'true'
    print(f"  JIRA_ENABLED: {jira_enabled}")
    
    if jira_enabled:
        # Verificar variables requeridas
        required_vars = ['JIRA_URL', 'JIRA_EMAIL', 'JIRA_TOKEN', 'JIRA_PROJECT']
        missing_vars = [var for var in required_vars if not os.getenv(var) or 'TU_' in os.getenv(var, '')]
        
        if missing_vars:
            print(f"  ❌ Variables faltantes o no configuradas: {', '.join(missing_vars)}")
            print("  💡 Edita testing/.env con tus datos reales")
        else:
            print("  ✅ Todas las variables requeridas están configuradas")
            
            # Probar conexión
            print("\n🔗 PROBANDO CONEXIÓN CON JIRA...")
            try:
                from hakalab_framework.integrations.jira_integration import JiraIntegration
                jira = JiraIntegration()
                
                if jira.is_configured:
                    success = jira.test_connection()
                    if success:
                        print("  ✅ Conexión exitosa con Jira")
                        
                        # Probar obtener tipos de relaciones
                        print("\n🔗 PROBANDO XRAY...")
                        try:
                            from hakalab_framework.integrations.xray_integration import XrayIntegration
                            xray = XrayIntegration(jira)
                            if xray.is_configured:
                                print("  ✅ Xray configurado correctamente")
                                
                                # Obtener tipos de relaciones
                                link_types = xray.get_available_link_types()
                                if link_types:
                                    print("  ✅ Tipos de relaciones obtenidos correctamente")
                                else:
                                    print("  ⚠️ No se pudieron obtener tipos de relaciones")
                            else:
                                print("  ❌ Xray no está configurado")
                        except Exception as e:
                            print(f"  ❌ Error probando Xray: {e}")
                    else:
                        print("  ❌ Error de conexión con Jira")
                else:
                    print("  ❌ Jira no está configurado correctamente")
                    
            except Exception as e:
                print(f"  ❌ Error al probar conexión: {e}")
    else:
        print("  ℹ️ Jira está deshabilitado")
    
    print("\n" + "=" * 50)
    print("🔍 DIAGNÓSTICO COMPLETADO")
    
    if jira_enabled and not missing_vars:
        print("\n🚀 TODO LISTO PARA TESTING!")
        print("   Ejecuta: python test_local.py")
    else:
        print("\n⚠️ CONFIGURACIÓN INCOMPLETA")
        print("   1. Edita testing/.env con tus datos reales")
        print("   2. Ejecuta: python debug_jira_local.py")

if __name__ == "__main__":
    main()