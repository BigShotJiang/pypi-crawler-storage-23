#!/usr/bin/env python
"""
Test del VariableManager con variables de entorno.
"""

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from hakalab_framework.core.variable_manager import VariableManager


def test_env_variables():
    """Test de resolución de variables de entorno."""
    print("🧪 Test: Resolución de variables de entorno\n")
    
    # Configurar variable de entorno
    os.environ['BASE_URL'] = 'https://mi-app.com'
    os.environ['API_KEY'] = 'secret123'
    
    vm = VariableManager()
    
    # Test 1: Variable con prefijo ENV.
    print("1️⃣  Test: ${ENV.BASE_URL}")
    result = vm.resolve_variables("${ENV.BASE_URL}")
    print(f"   Entrada: ${{ENV.BASE_URL}}")
    print(f"   Resultado: {result}")
    assert result == "https://mi-app.com", f"Esperado 'https://mi-app.com', obtenido '{result}'"
    print("   ✅ Correcto\n")
    
    # Test 2: Variable sin prefijo (busca en variables del manager primero, luego en ENV)
    print("2️⃣  Test: ${BASE_URL}")
    result = vm.resolve_variables("${BASE_URL}")
    print(f"   Entrada: ${{BASE_URL}}")
    print(f"   Resultado: {result}")
    assert result == "https://mi-app.com", f"Esperado 'https://mi-app.com', obtenido '{result}'"
    print("   ✅ Correcto\n")
    
    # Test 3: Variable en medio de texto
    print("3️⃣  Test: Texto con variable")
    result = vm.resolve_variables("La URL es ${ENV.BASE_URL}/login")
    print(f"   Entrada: La URL es ${{ENV.BASE_URL}}/login")
    print(f"   Resultado: {result}")
    assert result == "La URL es https://mi-app.com/login", f"Esperado 'La URL es https://mi-app.com/login', obtenido '{result}'"
    print("   ✅ Correcto\n")
    
    # Test 4: Múltiples variables
    print("4️⃣  Test: Múltiples variables")
    result = vm.resolve_variables("${ENV.BASE_URL}/api?key=${ENV.API_KEY}")
    print(f"   Entrada: ${{ENV.BASE_URL}}/api?key=${{ENV.API_KEY}}")
    print(f"   Resultado: {result}")
    assert result == "https://mi-app.com/api?key=secret123", f"Esperado 'https://mi-app.com/api?key=secret123', obtenido '{result}'"
    print("   ✅ Correcto\n")
    
    # Test 5: Variable que no existe
    print("5️⃣  Test: Variable inexistente")
    result = vm.resolve_variables("${ENV.NO_EXISTE}")
    print(f"   Entrada: ${{ENV.NO_EXISTE}}")
    print(f"   Resultado: {result}")
    assert result == "${ENV.NO_EXISTE}", f"Esperado '${{ENV.NO_EXISTE}}', obtenido '{result}'"
    print("   ✅ Correcto (mantiene texto original)\n")
    
    # Test 6: Variable del manager tiene prioridad
    print("6️⃣  Test: Prioridad de variables del manager")
    vm.set_variable('BASE_URL', 'https://override.com')
    result = vm.resolve_variables("${BASE_URL}")
    print(f"   Variable manager: BASE_URL = 'https://override.com'")
    print(f"   Variable ENV: BASE_URL = 'https://mi-app.com'")
    print(f"   Entrada: ${{BASE_URL}}")
    print(f"   Resultado: {result}")
    assert result == "https://override.com", f"Esperado 'https://override.com', obtenido '{result}'"
    print("   ✅ Correcto (manager tiene prioridad)\n")
    
    # Test 7: ENV. fuerza búsqueda en entorno
    print("7️⃣  Test: ENV. fuerza búsqueda en entorno")
    result = vm.resolve_variables("${ENV.BASE_URL}")
    print(f"   Variable manager: BASE_URL = 'https://override.com'")
    print(f"   Variable ENV: BASE_URL = 'https://mi-app.com'")
    print(f"   Entrada: ${{ENV.BASE_URL}}")
    print(f"   Resultado: {result}")
    assert result == "https://mi-app.com", f"Esperado 'https://mi-app.com', obtenido '{result}'"
    print("   ✅ Correcto (ENV. fuerza búsqueda en entorno)\n")
    
    print("✅ Todos los tests pasaron!")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(test_env_variables())
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
