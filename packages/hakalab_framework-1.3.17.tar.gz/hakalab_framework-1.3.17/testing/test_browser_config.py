#!/usr/bin/env python3
"""
Test runner específico para validación de configuración del navegador
Ejecuta todas las pruebas de configuración del navegador y genera reportes
"""

import os
import sys
import subprocess
import json
import time
from pathlib import Path

# Añadir el directorio padre al path para importar el framework
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

def setup_test_environment():
    """Configura el entorno de testing"""
    print("🔧 Configurando entorno de testing...")
    
    # Crear directorios necesarios
    directories = [
        'reports',
        'reports/html-reports',
        'reports/screenshots',
        'test_downloads',
        'complex_downloads'
    ]
    
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
        print(f"  ✓ Directorio creado: {directory}")
    
    # Limpiar archivos de configuración de prueba anteriores
    test_files = [
        'test_custom_config.json',
        'non_existent_config.json'
    ]
    
    for test_file in test_files:
        if os.path.exists(test_file):
            os.remove(test_file)
            print(f"  ✓ Archivo de prueba eliminado: {test_file}")

def run_browser_config_tests():
    """Ejecuta las pruebas de configuración del navegador"""
    print("\n🧪 Ejecutando pruebas de configuración del navegador...")
    
    # Configurar variables de entorno para las pruebas
    test_env = os.environ.copy()
    test_env.update({
        'BROWSER': 'chromium',
        'HEADLESS': 'true',
        'TIMEOUT': '10000',
        'AUTO_SCREENSHOT_ON_FAILURE': 'true',
        'HTML_REPORT_CAPTURE_ALL_STEPS': 'false',  # Reducir capturas para pruebas rápidas
        'HAKALAB_DEBUG': 'true'
    })
    
    # Comando base de behave
    cmd = [
        'python', '-m', 'behave',
        '--no-capture',
        '--no-skipped',
        '--tags', '@browser_config',
        '--format', 'pretty',
        '--format', 'json:reports/browser_config_results.json',
        'features/browser_configuration.feature'
    ]
    
    try:
        # Ejecutar pruebas
        result = subprocess.run(
            cmd,
            cwd='testing',
            env=test_env,
            capture_output=True,
            text=True,
            timeout=300  # 5 minutos timeout
        )
        
        print(f"Código de salida: {result.returncode}")
        
        if result.stdout:
            print("\n📋 Salida estándar:")
            print(result.stdout)
        
        if result.stderr:
            print("\n⚠️ Errores:")
            print(result.stderr)
        
        return result.returncode == 0
        
    except subprocess.TimeoutExpired:
        print("❌ Las pruebas excedieron el tiempo límite de 5 minutos")
        return False
    except Exception as e:
        print(f"❌ Error ejecutando pruebas: {e}")
        return False

def run_specific_test_categories():
    """Ejecuta categorías específicas de pruebas"""
    print("\n🎯 Ejecutando categorías específicas de pruebas...")
    
    categories = [
        ('smoke', 'Pruebas básicas de configuración'),
        ('chrome_flags', 'Configuración de banderas de Chrome'),
        ('preferences', 'Configuración de preferencias del navegador'),
        ('preset_performance', 'Configuración predefinida de rendimiento'),
        ('config_file_performance', 'Configuración desde archivo JSON'),
        ('error_handling', 'Manejo de errores')
    ]
    
    results = {}
    
    for tag, description in categories:
        print(f"\n🔍 Ejecutando: {description}")
        
        cmd = [
            'python', '-m', 'behave',
            '--no-capture',
            '--no-skipped',
            '--tags', f'@{tag}',
            '--format', 'pretty',
            'features/browser_configuration.feature'
        ]
        
        try:
            result = subprocess.run(
                cmd,
                cwd='testing',
                capture_output=True,
                text=True,
                timeout=60
            )
            
            success = result.returncode == 0
            results[tag] = success
            
            status = "✅ PASÓ" if success else "❌ FALLÓ"
            print(f"  {status}: {description}")
            
            if not success and result.stderr:
                print(f"    Error: {result.stderr[:200]}...")
        
        except Exception as e:
            results[tag] = False
            print(f"  ❌ ERROR: {description} - {e}")
    
    return results

def generate_test_report(category_results):
    """Genera un reporte de las pruebas ejecutadas"""
    print("\n📊 Generando reporte de pruebas...")
    
    report = {
        'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
        'total_categories': len(category_results),
        'passed_categories': sum(1 for result in category_results.values() if result),
        'failed_categories': sum(1 for result in category_results.values() if not result),
        'results': category_results
    }
    
    # Guardar reporte JSON
    with open('testing/reports/browser_config_report.json', 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    
    # Mostrar resumen
    print(f"  ✓ Total de categorías: {report['total_categories']}")
    print(f"  ✅ Categorías exitosas: {report['passed_categories']}")
    print(f"  ❌ Categorías fallidas: {report['failed_categories']}")
    
    success_rate = (report['passed_categories'] / report['total_categories']) * 100
    print(f"  📈 Tasa de éxito: {success_rate:.1f}%")
    
    # Mostrar detalles de fallos
    failed_categories = [cat for cat, result in category_results.items() if not result]
    if failed_categories:
        print(f"\n❌ Categorías que fallaron:")
        for category in failed_categories:
            print(f"  - {category}")
    
    return report

def validate_browser_config_files():
    """Valida que los archivos de configuración del navegador existan y sean válidos"""
    print("\n🔍 Validando archivos de configuración del navegador...")
    
    config_files = [
        'hakalab_framework/templates/browser_configs/chrome_performance.json',
        'hakalab_framework/templates/browser_configs/chrome_mobile.json',
        'hakalab_framework/templates/browser_configs/chrome_cicd.json',
        'hakalab_framework/templates/browser_configs/chrome_security_disabled.json',
        'hakalab_framework/templates/browser_configs/firefox_standard.json'
    ]
    
    valid_files = 0
    
    for config_file in config_files:
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                config = json.load(f)
            
            # Validar estructura básica
            required_keys = ['name', 'description', 'args']
            has_required_keys = all(key in config for key in required_keys)
            
            if has_required_keys:
                print(f"  ✅ {config_file}: Válido ({len(config['args'])} argumentos)")
                valid_files += 1
            else:
                print(f"  ❌ {config_file}: Estructura inválida")
        
        except FileNotFoundError:
            print(f"  ❌ {config_file}: Archivo no encontrado")
        except json.JSONDecodeError as e:
            print(f"  ❌ {config_file}: JSON inválido - {e}")
        except Exception as e:
            print(f"  ❌ {config_file}: Error - {e}")
    
    print(f"\n📋 Archivos de configuración válidos: {valid_files}/{len(config_files)}")
    return valid_files == len(config_files)

def cleanup_test_environment():
    """Limpia el entorno de testing"""
    print("\n🧹 Limpiando entorno de testing...")
    
    # Limpiar archivos temporales de prueba
    temp_files = [
        'testing/test_custom_config.json',
        'testing/complex_downloads',
        'testing/test_downloads'
    ]
    
    for temp_file in temp_files:
        try:
            if os.path.isfile(temp_file):
                os.remove(temp_file)
                print(f"  ✓ Archivo eliminado: {temp_file}")
            elif os.path.isdir(temp_file):
                import shutil
                shutil.rmtree(temp_file)
                print(f"  ✓ Directorio eliminado: {temp_file}")
        except Exception as e:
            print(f"  ⚠️ No se pudo eliminar {temp_file}: {e}")

def main():
    """Función principal del test runner"""
    print("🚀 Iniciando validación de configuración del navegador")
    print("=" * 60)
    
    try:
        # 1. Configurar entorno
        setup_test_environment()
        
        # 2. Validar archivos de configuración
        config_files_valid = validate_browser_config_files()
        if not config_files_valid:
            print("❌ Algunos archivos de configuración son inválidos")
            return False
        
        # 3. Ejecutar pruebas por categorías
        category_results = run_specific_test_categories()
        
        # 4. Ejecutar todas las pruebas juntas
        all_tests_passed = run_browser_config_tests()
        
        # 5. Generar reporte
        report = generate_test_report(category_results)
        
        # 6. Limpiar entorno
        cleanup_test_environment()
        
        # 7. Mostrar resultado final
        print("\n" + "=" * 60)
        if all_tests_passed and report['failed_categories'] == 0:
            print("🎉 ¡Todas las pruebas de configuración del navegador PASARON!")
            return True
        else:
            print("❌ Algunas pruebas de configuración del navegador FALLARON")
            return False
    
    except KeyboardInterrupt:
        print("\n⚠️ Pruebas interrumpidas por el usuario")
        return False
    except Exception as e:
        print(f"\n❌ Error inesperado: {e}")
        return False

if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)