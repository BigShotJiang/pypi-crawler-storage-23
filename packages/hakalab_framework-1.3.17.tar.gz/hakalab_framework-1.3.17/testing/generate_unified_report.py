#!/usr/bin/env python
"""
Script para generar un reporte unificado desde múltiples JSONs de ejecuciones paralelas.

Uso:
    python testing/generate_unified_report.py
    python testing/generate_unified_report.py --json-dir ./html-reports --output-dir ./reports
"""

import sys
from pathlib import Path

# Agregar el directorio raíz al path
sys.path.insert(0, str(Path(__file__).parent.parent))

from hakalab_framework.core.unified_report_generator import UnifiedReportGenerator


def main():
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Genera un reporte HTML unificado desde múltiples JSONs"
    )
    
    parser.add_argument(
        "--json-dir",
        type=str,
        default="html-reports",
        help="Directorio con los JSONs (default: html-reports)",
    )
    
    parser.add_argument(
        "--output-dir",
        type=str,
        default="html-reports",
        help="Directorio de salida (default: html-reports)",
    )
    
    parser.add_argument(
        "--output-file",
        type=str,
        default="unified_report.html",
        help="Nombre del archivo (default: unified_report.html)",
    )
    
    args = parser.parse_args()
    
    try:
        print(f"📊 Generando reporte unificado...")
        print(f"   📁 Entrada: {args.json_dir}")
        print(f"   📁 Salida: {args.output_dir}")
        
        generator = UnifiedReportGenerator(output_dir=args.output_dir)
        generator.load_json_reports(args.json_dir)
        
        print(f"   ✓ {len(generator.reports_data)} reportes cargados")
        
        output_file = generator.save_report(filename=args.output_file)
        
        print(f"   ✓ Reporte guardado: {output_file}")
        print(f"\n✅ Éxito!")
        
        return 0
        
    except FileNotFoundError as e:
        print(f"❌ Error: {e}")
        return 1
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
