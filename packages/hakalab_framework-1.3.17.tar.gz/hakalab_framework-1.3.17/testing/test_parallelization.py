#!/usr/bin/env python3
"""
Script de prueba para validar el módulo ParallelizationManager.

Uso:
    python testing/test_parallelization.py
"""

import os
import sys
from pathlib import Path

# Cambiar al directorio testing para que busque features localmente
os.chdir(Path(__file__).parent)

# Agregar el directorio padre al path
sys.path.insert(0, str(Path(__file__).parent.parent))

from hakalab_framework.core.parallelization_manager import ParallelizationManager


def test_get_scenario_tags():
    """Test: Obtener tags de escenarios"""
    print("\n" + "="*60)
    print("TEST 1: get_scenario_tags()")
    print("="*60)
    
    scenarios = ParallelizationManager.get_scenario_tags()
    
    print(f"\n✅ Se encontraron {len(scenarios)} escenarios")
    
    if scenarios:
        print("\nPrimeros 3 escenarios:")
        for i, scenario in enumerate(scenarios[:3], 1):
            print(f"\n  {i}. {scenario['scenario_name']}")
            print(f"     Archivo: {scenario['file']}")
            print(f"     Tags: {scenario['scenario_tags']}")
            print(f"     Ejecuciones: {scenario['executions']}")
    
    return len(scenarios) > 0


def test_get_scenario_count():
    """Test: Obtener conteo de escenarios"""
    print("\n" + "="*60)
    print("TEST 2: get_scenario_count()")
    print("="*60)
    
    count = ParallelizationManager.get_scenario_count()
    print(f"\n✅ Total de ejecuciones: {count}")
    
    return count >= 0


def test_get_scenario_info():
    """Test: Obtener información de escenarios"""
    print("\n" + "="*60)
    print("TEST 3: get_scenario_info()")
    print("="*60)
    
    info = ParallelizationManager.get_scenario_info()
    
    print(f"\n✅ Información de escenarios:")
    print(f"   Total de escenarios: {info['total_scenarios']}")
    print(f"   Total de ejecuciones: {info['total_executions']}")
    print(f"   Tags únicos: {len(info['unique_tags'])}")
    
    if info['unique_tags']:
        print(f"   Tags: {', '.join(info['unique_tags'][:5])}")
        if len(info['unique_tags']) > 5:
            print(f"          ... y {len(info['unique_tags']) - 5} más")
    
    return True


def test_get_features_selection_local():
    """Test: Selección de features en modo local"""
    print("\n" + "="*60)
    print("TEST 4: get_features_selection() - Modo Local")
    print("="*60)
    
    # Limpiar variables de entorno
    os.environ.pop('SHARD_INDEX', None)
    os.environ.pop('TOTAL_SHARDS', None)
    
    features = ParallelizationManager.get_features_selection()
    
    print(f"\n✅ Modo local (sin sharding)")
    print(f"   Comando: behave {' '.join(features)}")
    
    return features == ['features']


def test_get_features_selection_ci():
    """Test: Selección de features en modo CI"""
    print("\n" + "="*60)
    print("TEST 5: get_features_selection() - Modo CI")
    print("="*60)
    
    # Configurar variables de entorno
    os.environ['SHARD_INDEX'] = '1'
    os.environ['TOTAL_SHARDS'] = '2'
    
    features = ParallelizationManager.get_features_selection()
    
    print(f"\n✅ Modo CI (Shard 1/2)")
    print(f"   Comando: behave {' '.join(features)}")
    
    # Limpiar
    os.environ.pop('SHARD_INDEX', None)
    os.environ.pop('TOTAL_SHARDS', None)
    
    return len(features) >= 1


def test_get_features_selection_multiple_shards():
    """Test: Selección de features con múltiples shards"""
    print("\n" + "="*60)
    print("TEST 6: get_features_selection() - Múltiples Shards")
    print("="*60)
    
    for shard in range(1, 4):
        os.environ['SHARD_INDEX'] = str(shard)
        os.environ['TOTAL_SHARDS'] = '3'
        
        features = ParallelizationManager.get_features_selection()
        print(f"\n✅ Shard {shard}/3")
        print(f"   Comando: behave {' '.join(features)}")
    
    # Limpiar
    os.environ.pop('SHARD_INDEX', None)
    os.environ.pop('TOTAL_SHARDS', None)
    
    return True


def main():
    """Ejecutar todos los tests"""
    print("\n" + "="*60)
    print("VALIDACIÓN DE ParallelizationManager")
    print("="*60)
    
    tests = [
        ("get_scenario_tags", test_get_scenario_tags),
        ("get_scenario_count", test_get_scenario_count),
        ("get_scenario_info", test_get_scenario_info),
        ("get_features_selection (local)", test_get_features_selection_local),
        ("get_features_selection (CI)", test_get_features_selection_ci),
        ("get_features_selection (múltiples shards)", test_get_features_selection_multiple_shards),
    ]
    
    results = []
    
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"\n❌ Error en {test_name}: {e}")
            results.append((test_name, False))
    
    # Resumen
    print("\n" + "="*60)
    print("RESUMEN DE TESTS")
    print("="*60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        icon = "✅" if result else "❌"
        print(f"{icon} {test_name}")
    
    print(f"\n{'='*60}")
    print(f"Resultado: {passed}/{total} tests pasados")
    print(f"{'='*60}\n")
    
    return 0 if passed == total else 1


if __name__ == '__main__':
    sys.exit(main())
