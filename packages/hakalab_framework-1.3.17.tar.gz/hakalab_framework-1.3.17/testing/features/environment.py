"""
Environment.py SIMPLE para testing del Hakalab Framework
Configuración automática de todas las integraciones + Auto-instalación inteligente
"""
import sys
import os

# Agregar el directorio padre al path para importar el framework local
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from hakalab_framework import (
    setup_framework_context,
    setup_scenario_context
)
from hakalab_framework.core.screenshot_manager import take_screenshot_on_failure, take_screenshot
from hakalab_framework.core.behave_html_integration import (
    setup_html_reporting,
    before_feature_html,
    after_feature_html,
    before_scenario_html,
    after_scenario_html,
    after_step_html,
    generate_html_report
)
from hakalab_framework.core.environment_config import (
    auto_before_feature,
    auto_after_scenario,
    auto_after_feature,
    auto_after_all
)
from hakalab_framework.steps import *

# Auto-instalador inteligente
try:
    from hakalab_framework.core.auto_installer import auto_installer
    AUTO_INSTALLER_AVAILABLE = True
except ImportError:
    AUTO_INSTALLER_AVAILABLE = False


def before_all(context):
    """Configuración inicial - Framework + HTML Reporter + Auto Jira/Xray + Auto-instalación"""
    try:
        from hakalab_framework.core.screenshot_manager import cleanup_directories
        cleanup_directories()
        
        # Auto-instalación inteligente
        if AUTO_INSTALLER_AVAILABLE:
            print("🔧 Verificando dependencias opcionales...")
            try:
                feature_dir = os.path.join(os.path.dirname(__file__), '.')
                for root, dirs, files in os.walk(feature_dir):
                    for file in files:
                        if file.endswith('.feature'):
                            feature_path = os.path.join(root, file)
                            with open(feature_path, 'r', encoding='utf-8') as f:
                                content = f.read()
                            auto_installer.auto_install_for_feature(content, quiet=True)
            except Exception as e:
                print(f"⚠️ Error en auto-instalación: {e}")
        
        # Configurar framework (incluye auto-detección de Jira/Xray)
        setup_framework_context(context)
        setup_html_reporting(context)
        
        print("✅ Framework configurado correctamente para testing")
    except Exception as e:
        print(f"❌ Error en before_all: {e}")
        raise


def before_feature(context, feature):
    try:
        before_feature_html(context, feature)
        auto_before_feature(context, feature)  # Auto Jira/Xray
    except Exception as e:
        print(f"⚠️ Error en before_feature: {e}")


def before_scenario(context, scenario):
    try:
        setup_scenario_context(context, scenario)
        before_scenario_html(context, scenario)
        print(f"🚀 Iniciando escenario: {scenario.name}")
    except Exception as e:
        print(f"❌ Error en before_scenario: {e}")
        raise


def after_step(context, step):
    try:
        after_step_html(context, step)
        import os
        capture_framework_steps = os.getenv('CAPTURE_FRAMEWORK_STEPS', 'false').lower() == 'true'
        if capture_framework_steps and hasattr(context, 'page') and context.page:
            step_name = step.name.replace(' ', '_').replace('"', '').replace("'", '')
            screenshot_name = f"framework_step_{step.line}_{step_name[:50]}"
            take_screenshot(context, screenshot_name)
    except Exception as e:
        print(f"⚠️ Error en after_step: {e}")


def after_scenario(context, scenario):
    try:
        after_scenario_html(context, scenario)
        take_screenshot_on_failure(context, scenario)
        auto_after_scenario(context, scenario)  # Auto Jira/Xray
    except Exception as e:
        print(f"⚠️ Error en after_scenario: {e}")

    try:
        if hasattr(context, 'page') and context.page:
            context.page.close()
            context.page = None
    except:
        pass


def after_feature(context, feature):
    try:
        after_feature_html(context, feature)
        auto_after_feature(context, feature)  # Auto Jira/Xray
    except Exception as e:
        print(f"⚠️ Error en after_feature: {e}")


def after_all(context):
    try:
        if hasattr(context, 'framework_config') and context.framework_config:
            context.framework_config.cleanup()
            print("✅ Playwright cerrado correctamente")
    except Exception as e:
        print(f"⚠️ Error cerrando Playwright: {e}")

    try:
        report_path = generate_html_report(context)
        if report_path:
            print(f"🎨 Reporte HTML personalizado: {report_path}")
            context.html_report_path = report_path
    except Exception as e:
        print(f"⚠️ Error generando reporte HTML: {e}")

    try:
        from hakalab_framework.core.screenshot_manager import get_screenshots_summary
        summary = get_screenshots_summary()
        if summary["total"] > 0:
            print(f"📸 Screenshots generados: {summary['total']} total, {summary['failed']} fallos")
    except Exception as e:
        print(f"⚠️ Error obteniendo resumen de screenshots: {e}")

    auto_after_all(context)  # Auto Jira/Xray