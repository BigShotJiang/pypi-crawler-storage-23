"""
Step definitions for browser configuration validation tests
"""

from behave import step, given, when, then
import os
import json
import tempfile

@given('I set environment variable "{var_name}" to "{var_value}"')
def step_set_environment_variable(context, var_name, var_value):
    """Sets an environment variable for testing"""
    os.environ[var_name] = var_value
    print(f"✓ Environment variable set: {var_name} = {var_value}")

@when('I load browser configuration from preset')
def step_load_browser_config_from_preset(context):
    """Loads browser configuration from environment preset"""
    preset = os.getenv('BROWSER_CONFIG_PRESET', '')
    if preset:
        # Simulate loading preset configuration
        if preset == 'performance':
            context.execute_steps('''
                When I enable browser performance mode
            ''')
        elif preset == 'mobile':
            context.execute_steps('''
                When I configure browser for mobile testing
            ''')
        elif preset == 'cicd':
            context.execute_steps('''
                When I configure browser for CI/CD environment
            ''')
        elif preset == 'security_disabled':
            context.execute_steps('''
                When I disable browser security features
            ''')
        print(f"✓ Preset configuration loaded: {preset}")
    else:
        print("✓ No preset configuration specified")

@when('I load browser configuration from environment variables')
def step_load_browser_config_from_env_vars(context):
    """Loads browser configuration from environment variables"""
    # Load BROWSER_ARGS
    browser_args = os.getenv('BROWSER_ARGS', '')
    if browser_args:
        context.execute_steps(f'''
            When I set browser arguments from list "{browser_args}"
        ''')
    
    # Load BROWSER_MEMORY_LIMIT
    memory_limit = os.getenv('BROWSER_MEMORY_LIMIT', '')
    if memory_limit:
        context.execute_steps(f'''
            When I set browser memory limit to "{memory_limit}" MB
        ''')
    
    # Load BROWSER_PROXY
    proxy = os.getenv('BROWSER_PROXY', '')
    if proxy:
        context.execute_steps(f'''
            When I set browser proxy to "{proxy}"
        ''')
    
    print("✓ Environment variable configuration loaded")

@when('I try to load browser configuration from file "{config_file}"')
def step_try_load_browser_config_from_file(context, config_file):
    """Tries to load browser configuration from file (for error testing)"""
    try:
        context.execute_steps(f'''
            When I load browser configuration from file "{config_file}"
        ''')
        context.config_load_error = None
    except Exception as e:
        context.config_load_error = str(e)
        print(f"✓ Expected error caught: {e}")

@then('the browser should have {count:d} arguments configured')
def step_verify_browser_arguments_count(context, count):
    """Verifies the number of browser arguments configured"""
    if hasattr(context, 'browser_args'):
        actual_count = len(context.browser_args)
        assert actual_count == count, f"Expected {count} arguments, but found {actual_count}"
        print(f"✓ Browser has {count} arguments configured")
    else:
        assert count == 0, f"Expected {count} arguments, but no arguments are configured"
        print("✓ No browser arguments configured (as expected)")

@then('the browser should have Chrome flags configured correctly')
def step_verify_chrome_flags_configured(context):
    """Verifies Chrome flags are configured correctly"""
    if hasattr(context, 'browser_args'):
        # Check for disable-web-security flag
        has_security_flag = any('--disable-web-security' in arg for arg in context.browser_args)
        # Check for log-level flag
        has_log_level_flag = any('--log-level=INFO' in arg for arg in context.browser_args)
        
        assert has_security_flag, "Chrome security flag not found"
        assert has_log_level_flag, "Chrome log level flag not found"
        print("✓ Chrome flags configured correctly")
    else:
        assert False, "No browser arguments configured"

@then('the browser should have experimental features configured')
def step_verify_experimental_features_configured(context):
    """Verifies experimental features are configured"""
    if hasattr(context, 'browser_args'):
        # Check for enabled feature
        has_enabled_feature = any('--enable-features=WebUIDarkMode' in arg for arg in context.browser_args)
        # Check for disabled feature
        has_disabled_feature = any('--disable-features=AutofillServerCommunication' in arg for arg in context.browser_args)
        
        assert has_enabled_feature, "Enabled experimental feature not found"
        assert has_disabled_feature, "Disabled experimental feature not found"
        print("✓ Experimental features configured correctly")
    else:
        assert False, "No browser arguments configured"

@then('the browser should have {count:d} preferences configured')
def step_verify_browser_preferences_count(context, count):
    """Verifies the number of browser preferences configured"""
    if hasattr(context, 'browser_prefs'):
        actual_count = len(context.browser_prefs)
        assert actual_count == count, f"Expected {count} preferences, but found {actual_count}"
        print(f"✓ Browser has {count} preferences configured")
    else:
        assert count == 0, f"Expected {count} preferences, but no preferences are configured"
        print("✓ No browser preferences configured (as expected)")

@then('the browser should have download configuration set')
def step_verify_download_configuration_set(context):
    """Verifies download configuration is set"""
    if hasattr(context, 'browser_prefs'):
        has_download_dir = 'download.default_directory' in context.browser_prefs
        has_prompt_setting = 'download.prompt_for_download' in context.browser_prefs
        
        assert has_download_dir, "Download directory preference not found"
        assert has_prompt_setting, "Download prompt preference not found"
        print("✓ Download configuration set correctly")
    else:
        assert False, "No browser preferences configured"

@then('the browser should have proxy configured')
def step_verify_proxy_configured(context):
    """Verifies proxy configuration is set"""
    if hasattr(context, 'browser_args'):
        has_proxy = any('--proxy-server=' in arg for arg in context.browser_args)
        assert has_proxy, "Proxy configuration not found"
        print("✓ Proxy configuration set correctly")
    else:
        assert False, "No browser arguments configured"

@then('the browser should have security features disabled')
def step_verify_security_features_disabled(context):
    """Verifies security features are disabled"""
    if hasattr(context, 'browser_args'):
        security_args = [
            '--disable-web-security',
            '--ignore-certificate-errors',
            '--ignore-ssl-errors'
        ]
        
        for security_arg in security_args:
            has_arg = any(security_arg in arg for arg in context.browser_args)
            assert has_arg, f"Security argument not found: {security_arg}"
        
        print("✓ Security features disabled correctly")
    else:
        assert False, "No browser arguments configured"

@then('the browser should have performance optimizations enabled')
def step_verify_performance_optimizations_enabled(context):
    """Verifies performance optimizations are enabled"""
    if hasattr(context, 'browser_args'):
        performance_args = [
            '--no-sandbox',
            '--disable-dev-shm-usage',
            '--disable-gpu'
        ]
        
        for perf_arg in performance_args:
            has_arg = any(perf_arg in arg for arg in context.browser_args)
            assert has_arg, f"Performance argument not found: {perf_arg}"
        
        print("✓ Performance optimizations enabled correctly")
    else:
        assert False, "No browser arguments configured"

@then('the browser should have memory limit configured')
def step_verify_memory_limit_configured(context):
    """Verifies memory limit is configured"""
    if hasattr(context, 'browser_args'):
        has_memory_limit = any('--max_old_space_size=' in arg for arg in context.browser_args)
        assert has_memory_limit, "Memory limit configuration not found"
        print("✓ Memory limit configured correctly")
    else:
        assert False, "No browser arguments configured"

@then('the browser should be configured for mobile testing')
def step_verify_mobile_testing_configured(context):
    """Verifies mobile testing configuration"""
    if hasattr(context, 'browser_args'):
        mobile_args = [
            '--use-mobile-user-agent',
            '--touch-events=enabled',
            '--enable-viewport-meta'
        ]
        
        for mobile_arg in mobile_args:
            has_arg = any(mobile_arg in arg for arg in context.browser_args)
            assert has_arg, f"Mobile argument not found: {mobile_arg}"
        
        print("✓ Mobile testing configuration set correctly")
    else:
        assert False, "No browser arguments configured"

@then('the browser should be configured for CI/CD')
def step_verify_cicd_configured(context):
    """Verifies CI/CD configuration"""
    if hasattr(context, 'browser_args'):
        cicd_args = [
            '--no-sandbox',
            '--disable-dev-shm-usage',
            '--disable-extensions',
            '--disable-plugins'
        ]
        
        for cicd_arg in cicd_args:
            has_arg = any(cicd_arg in arg for arg in context.browser_args)
            assert has_arg, f"CI/CD argument not found: {cicd_arg}"
        
        print("✓ CI/CD configuration set correctly")
    else:
        assert False, "No browser arguments configured"

@then('the browser should have {preset} preset applied')
def step_verify_preset_applied(context, preset):
    """Verifies specific preset is applied"""
    if preset == "performance":
        context.execute_steps('''
            Then the browser should have performance optimizations enabled
        ''')
    elif preset == "mobile":
        context.execute_steps('''
            Then the browser should be configured for mobile testing
        ''')
    elif preset == "CI/CD":
        context.execute_steps('''
            Then the browser should be configured for CI/CD
        ''')
    elif preset == "security disabled":
        context.execute_steps('''
            Then the browser should have security features disabled
        ''')
    
    print(f"✓ {preset} preset applied correctly")

@then('the browser should have configuration loaded from {config_type} file')
def step_verify_config_loaded_from_file(context, config_type):
    """Verifies configuration loaded from specific file type"""
    if config_type == "performance":
        # Verify performance-specific configurations
        context.execute_steps('''
            Then the browser should have performance optimizations enabled
        ''')
        # Also check for performance-specific preferences
        if hasattr(context, 'browser_prefs'):
            assert 'profile.default_content_setting_values.notifications' in context.browser_prefs
    
    elif config_type == "mobile":
        context.execute_steps('''
            Then the browser should be configured for mobile testing
        ''')
    
    elif config_type == "CI/CD":
        context.execute_steps('''
            Then the browser should be configured for CI/CD
        ''')
    
    elif config_type == "security disabled":
        context.execute_steps('''
            Then the browser should have security features disabled
        ''')
    
    elif config_type == "Firefox":
        # Firefox-specific validations would go here
        print("✓ Firefox configuration loaded (basic validation)")
    
    print(f"✓ Configuration loaded from {config_type} file correctly")

@then('the browser should have custom configuration restored')
def step_verify_custom_config_restored(context):
    """Verifies custom configuration is restored"""
    # Check for custom argument
    if hasattr(context, 'browser_args'):
        has_custom_arg = any('--custom-test-arg' in arg for arg in context.browser_args)
        assert has_custom_arg, "Custom argument not restored"
    
    # Check for custom preference
    if hasattr(context, 'browser_prefs'):
        has_custom_pref = 'test.custom.setting' in context.browser_prefs
        assert has_custom_pref, "Custom preference not restored"
        assert context.browser_prefs['test.custom.setting'] == True, "Custom preference value incorrect"
    
    print("✓ Custom configuration restored correctly")

@then('the browser should have environment variable configuration applied')
def step_verify_env_var_config_applied(context):
    """Verifies environment variable configuration is applied"""
    if hasattr(context, 'browser_args'):
        # Check for environment args
        has_env_arg1 = any('--test-env-arg1' in arg for arg in context.browser_args)
        has_env_arg2 = any('--test-env-arg2' in arg for arg in context.browser_args)
        has_memory_limit = any('--max_old_space_size=3072' in arg for arg in context.browser_args)
        has_proxy = any('--proxy-server=http://env-proxy:9090' in arg for arg in context.browser_args)
        
        assert has_env_arg1, "Environment argument 1 not found"
        assert has_env_arg2, "Environment argument 2 not found"
        assert has_memory_limit, "Environment memory limit not found"
        assert has_proxy, "Environment proxy not found"
        
        print("✓ Environment variable configuration applied correctly")
    else:
        assert False, "No browser arguments configured"

@then('the browser should have complex configuration applied')
def step_verify_complex_config_applied(context):
    """Verifies complex configuration scenario"""
    # Verify arguments
    if hasattr(context, 'browser_args'):
        expected_args = [
            '--no-sandbox',
            '--disable-web-security',
            '--enable-features=WebUIDarkMode',
            '--proxy-server=http://complex-proxy:8080',
            '--max_old_space_size=4096'
        ]
        
        for expected_arg in expected_args:
            has_arg = any(expected_arg in arg for arg in context.browser_args)
            assert has_arg, f"Complex configuration argument not found: {expected_arg}"
    
    # Verify preferences
    if hasattr(context, 'browser_prefs'):
        expected_prefs = [
            'profile.default_content_setting_values.notifications',
            'download.default_directory',
            'download.prompt_for_download'
        ]
        
        for expected_pref in expected_prefs:
            assert expected_pref in context.browser_prefs, f"Complex configuration preference not found: {expected_pref}"
    
    print("✓ Complex configuration applied correctly")

@then('I should get an error about missing configuration file')
def step_verify_missing_config_file_error(context):
    """Verifies error handling for missing configuration file"""
    assert hasattr(context, 'config_load_error'), "No error was captured"
    assert context.config_load_error is not None, "Expected error but none occurred"
    assert "no encontrado" in context.config_load_error.lower() or "not found" in context.config_load_error.lower(), \
        f"Error message doesn't indicate missing file: {context.config_load_error}"
    print("✓ Missing configuration file error handled correctly")

@then('the browser should have no configuration set')
def step_verify_no_configuration_set(context):
    """Verifies no configuration is set"""
    # Check arguments
    if hasattr(context, 'browser_args'):
        assert len(context.browser_args) == 0, f"Expected no arguments, but found {len(context.browser_args)}"
    
    # Check preferences
    if hasattr(context, 'browser_prefs'):
        assert len(context.browser_prefs) == 0, f"Expected no preferences, but found {len(context.browser_prefs)}"
    
    print("✓ No configuration set (as expected)")