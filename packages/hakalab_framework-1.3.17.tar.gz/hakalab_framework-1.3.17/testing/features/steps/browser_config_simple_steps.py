"""
Simple step definitions for basic browser configuration testing
"""

from behave import step, then

@then('I should see browser configuration output')
def step_should_see_browser_config_output(context):
    """Verifies that browser configuration output is displayed"""
    # This is a simple validation step that just checks if the configuration steps ran
    # The actual validation is done by the "show current browser configuration" step
    # which prints the configuration to the console
    print("✓ Browser configuration test completed successfully")
    
    # Optional: Add basic validation that some configuration exists
    has_args = hasattr(context, 'browser_args') and len(getattr(context, 'browser_args', [])) > 0
    has_prefs = hasattr(context, 'browser_prefs') and len(getattr(context, 'browser_prefs', {})) > 0
    
    if has_args or has_prefs:
        print("✓ Browser configuration is present")
    else:
        print("ℹ️ No browser configuration set (this may be expected for some tests)")