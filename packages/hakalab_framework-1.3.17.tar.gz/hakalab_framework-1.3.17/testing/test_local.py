#!/usr/bin/env python3
"""
Script para probar la integración Jira/Xray localmente
"""
import os
import sys
import subprocess
from pathlib import Path

# Agregar el directorio padre al path
sys.path.insert(0, str(Path(__file__).parent.parent))

def main():
    print("🧪 TESTING LOCAL DE INTEGRACIÓN JIRA/XRAY")
    print("=" * 50)
    
    # Cambiar al directorio de testing
    os.chdir(Path(__file__).parent)
    
    print("📁 Directorio actual:", os.getcwd())
    
    # Verificar que existe .env
    if not os.path.exists('.env'):
        print("❌ Archivo .env no encontrado")
        print("💡 Copia tu .env real a testing/.env")
        return
    
    # Verificar variables de Jira
    from dotenv import load_dotenv
    load_dotenv()
    
    jira_enabled = os.getenv('JIRA_ENABLED', 'false').lower() == 'true'
    jira_url = os.getenv('JIRA_URL')
    
    print(f"🔍 JIRA_ENABLED: {jira_enabled}")
    print(f"🔍 JIRA_URL: {jira_url}")
    
    if not jira_enabled or not jira_url or 'TU_' in jira_url:
        print("⚠️ Variables de Jira no configuradas correctamente")
        print("💡 Actualiza el archivo .env con tus variables reales")
        return
    
    print("\n🚀 Ejecutando pruebas con Behave...")
    print("-" * 30)
    
    # Ejecutar behave
    try:
        result = subprocess.run([
            'behave', 
            '--no-capture', 
            '--no-skipped',
            'features'
        ], check=False)
        
        print(f"\n📊 Resultado: Exit code {result.returncode}")
        
    except FileNotFoundError:
        print("❌ Behave no encontrado. Instala con: pip install behave")
    except Exception as e:
        print(f"❌ Error ejecutando pruebas: {e}")

if __name__ == "__main__":
    main()