#!/usr/bin/env python
"""
Test rápido del generador de reportes unificados.
"""

import json
import sys
from pathlib import Path
import tempfile

sys.path.insert(0, str(Path(__file__).parent.parent))

from hakalab_framework.core.unified_report_generator import UnifiedReportGenerator


def create_sample_json(worker_id: int) -> dict:
    """Crea un JSON de ejemplo para testing."""
    return {
        "execution_info": {
            "start_time": f"2026-01-13 16:48:{20+worker_id}",
            "end_time": f"2026-01-13 16:50:{2+worker_id}",
            "duration": 98.76 + worker_id,
            "browser": "chromium",
            "environment": "test"
        },
        "summary": {
            "features": {"total": 2, "passed": 2-worker_id%2, "failed": worker_id%2, "skipped": 0},
            "scenarios": {"total": 5, "passed": 5-worker_id, "failed": worker_id, "skipped": 0},
            "steps": {"total": 47, "passed": 47-worker_id*2, "failed": worker_id*2, "skipped": 0, "undefined": 0}
        },
        "features": [
            {
                "name": f"Feature {worker_id}",
                "description": f"Test feature from worker {worker_id}",
                "tags": ["PROD-145"],
                "status": "passed" if worker_id % 2 == 0 else "failed",
                "scenarios": [
                    {
                        "name": f"Scenario {worker_id}-1",
                        "tags": ["PROD-91"],
                        "status": "passed",
                        "steps": [
                            {
                                "name": f"Given step {worker_id}",
                                "status": "passed",
                                "error_message": None,
                                "screenshot": None
                            },
                            {
                                "name": f"When step {worker_id}",
                                "status": "passed",
                                "error_message": None,
                                "screenshot": None
                            }
                        ]
                    }
                ]
            }
        ]
    }


def test_unified_report():
    """Test del generador de reportes unificados."""
    print("🧪 Iniciando test del generador de reportes unificados...\n")
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # 1. Crear JSONs de ejemplo en subdirectorios (como en CI/CD)
        print("1️⃣  Creando JSONs de ejemplo en subdirectorios...")
        json_dir = Path(tmpdir) / "artifacts"
        json_dir.mkdir()
        
        # Simular estructura de artifacts descargados
        for i in range(1, 4):
            worker_dir = json_dir / f"test-results-worker_{i}"
            worker_dir.mkdir()
            json_file = worker_dir / f"test_report_worker_{i}.json"
            with open(json_file, "w") as f:
                json.dump(create_sample_json(i), f)
            print(f"   ✓ Creado: {worker_dir.name}/test_report_worker_{i}.json")
        
        # 2. Generar reporte unificado
        print("\n2️⃣  Generando reporte unificado...")
        output_dir = Path(tmpdir) / "reports"
        generator = UnifiedReportGenerator(output_dir=str(output_dir))
        generator.load_json_reports(str(json_dir))
        print(f"   ✓ Cargados {len(generator.reports_data)} reportes (búsqueda recursiva)")
        
        # 3. Guardar reporte
        print("\n3️⃣  Guardando reporte...")
        output_file = generator.save_report("test_report.html")
        print(f"   ✓ Guardado en: {output_file}")
        
        # 4. Validar
        print("\n4️⃣  Validando reporte...")
        assert output_file.exists(), "El archivo no fue creado"
        assert output_file.stat().st_size > 0, "El archivo está vacío"
        
        with open(output_file, "r", encoding="utf-8") as f:
            content = f.read()
            assert "<!DOCTYPE html>" in content, "No es un HTML válido"
            assert "Reporte Unificado" in content, "Falta el título"
            assert "Worker" in content, "Falta información de workers"
            assert "featuresChart" in content, "Faltan gráficos"
        
        print(f"   ✓ Tamaño: {output_file.stat().st_size / 1024:.2f} KB")
        print(f"   ✓ HTML válido")
        print(f"   ✓ Contiene datos esperados")
        
        # 5. Resumen
        print("\n5️⃣  Resumen del reporte:")
        print(f"   Features: {generator.unified_summary['features']}")
        print(f"   Scenarios: {generator.unified_summary['scenarios']}")
        print(f"   Steps: {generator.unified_summary['steps']}")
        
        print("\n✅ Test completado exitosamente!")
        return 0


if __name__ == "__main__":
    try:
        sys.exit(test_unified_report())
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
