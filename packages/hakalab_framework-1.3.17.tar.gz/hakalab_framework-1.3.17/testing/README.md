# 🧪 Testing Local - Integración Jira/Xray

Este directorio contiene un entorno de testing completo para probar la integración Jira/Xray del framework localmente sin necesidad de subir cambios a Git.

## 📁 Estructura

```
testing/
├── .env                    # Variables de entorno (CONFIGURAR)
├── behave.ini             # Configuración de Behave
├── test_local.py          # Script de testing Jira/Xray
├── test_browser_config.py # Script completo de testing de configuración del navegador
├── test_browser_config_quick.py # Script rápido de testing de configuración del navegador
├── README.md              # Esta guía
└── features/
    ├── environment.py     # Environment con integración automática
    ├── test_jira_xray.feature  # Feature de prueba Jira/Xray
    ├── browser_configuration.feature  # Feature completo de configuración del navegador
    ├── browser_config_simple.feature  # Feature simple de configuración del navegador
    └── steps/
        ├── browser_config_steps.py  # Steps completos para configuración del navegador
        └── browser_config_simple_steps.py  # Steps simples para configuración del navegador
```

## ⚙️ Configuración

### 1. Configurar Variables de Entorno

Edita `testing/.env` y reemplaza las variables con tus datos reales:

```env
# Reemplazar estas variables:
JIRA_ENABLED=true
JIRA_URL=https://tu-empresa.atlassian.net
JIRA_EMAIL=tu-email@empresa.com
JIRA_TOKEN=tu_token_real_aqui
JIRA_PROJECT=TU_PROYECTO
XRAY_AUTHORIZATION_TOKEN=tu_token_xray_real
```

### 2. Crear Issues de Prueba en Jira

Crea estas issues en tu proyecto:
- **PROD-145**: Historia de Usuario (Story/Epic)
- **PROD-146**: Test (tipo Test)
- **PROD-147**: Test (tipo Test)  
- **PROD-148**: Test (tipo Test)

## 🚀 Ejecutar Pruebas

### Opción 1: Script Automático (Jira/Xray)
```bash
cd testing
python test_local.py
```

### Opción 2: Behave Directo
```bash
cd testing
python -m behave --no-capture --no-skipped features
```

### Opción 3: Testing Específico
```bash
cd testing
python -m behave --no-capture --tags @PROD-146 features
```

### Opción 4: Pruebas de Configuración del Navegador
```bash
# Prueba rápida de configuración del navegador
cd testing
python test_browser_config_quick.py

# Pruebas completas de configuración del navegador
cd testing
python test_browser_config.py

# Pruebas específicas por categoría
cd testing
python -m behave --no-capture --tags @browser_config features/browser_configuration.feature
python -m behave --no-capture --tags @simple features/browser_config_simple.feature
```

## 🔍 Qué Verificar

### Pruebas Jira/Xray
Después de ejecutar las pruebas, verifica en Jira:

1. **Test Execution creado**: Debería aparecer un nuevo Test Execution
2. **Tests incluidos**: Los 3 tests (PROD-146, 147, 148) deberían estar en el execution
3. **Estados actualizados**: passed/failed según el resultado
4. **Vinculación a HU**: 
   - Test Execution vinculado a PROD-145 (en "Is tested by")
   - **NUEVO**: Tests individuales vinculados a PROD-145 (en "Cobertura de Tests")

### Pruebas de Configuración del Navegador
Después de ejecutar las pruebas de configuración del navegador:

1. **Configuración básica**: Argumentos y preferencias se establecen correctamente
2. **Presets predefinidos**: performance, mobile, cicd, security_disabled funcionan
3. **Archivos JSON**: Configuraciones se cargan desde archivos template
4. **Variables de entorno**: Configuración desde .env funciona
5. **Manejo de errores**: Errores se manejan apropiadamente
6. **Limpieza**: Configuración se puede limpiar correctamente

## 📋 Logs Esperados

Deberías ver logs como:
```
🔍 Verificando tipos de relaciones disponibles...
📋 Relación de test encontrada: Tests (tests / is tested by)
🔗 Vinculando Tests individuales a HU PROD-145...
  ✅ PROD-146 -> PROD-145 (Tests)
  ✅ PROD-147 -> PROD-145 (Tests)
  ✅ PROD-148 -> PROD-145 (Tests)
📊 Tests vinculados a HU: 3/3
```

## 🐛 Troubleshooting

- **Error 401**: Token de Jira expirado, genera uno nuevo
- **Issues no encontradas**: Verifica que existan en tu proyecto
- **Sin relaciones de test**: El framework usará "Relates" como fallback
- **Import errors**: Verifica que estés en el directorio `testing/`

## 📝 Modificar Pruebas

Para probar con tus propias issues:
1. Edita `features/test_jira_xray.feature`
2. Cambia los tags `@PROD-XXX` por tus issues reales
3. Ejecuta las pruebas

¡Listo para testing local sin Git! 🎉