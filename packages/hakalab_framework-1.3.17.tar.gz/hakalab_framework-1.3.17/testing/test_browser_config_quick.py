#!/usr/bin/env python3
"""
Quick test runner for browser configuration validation
Tests basic functionality to ensure everything works
"""

import os
import sys
import subprocess

# Añadir el directorio padre al path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

def run_quick_browser_config_test():
    """Ejecuta una prueba rápida de configuración del navegador"""
    print("🚀 Ejecutando prueba rápida de configuración del navegador...")
    
    # Configurar variables de entorno para prueba rápida
    test_env = os.environ.copy()
    test_env.update({
        'BROWSER': 'chromium',
        'HEADLESS': 'true',
        'TIMEOUT': '5000',
        'AUTO_SCREENSHOT_ON_FAILURE': 'false',
        'HTML_REPORT_CAPTURE_ALL_STEPS': 'false',
        'HAKALAB_DEBUG': 'true'
    })
    
    # Comando para ejecutar solo las pruebas simples
    cmd = [
        'python', '-m', 'behave',
        '--no-capture',
        '--no-skipped',
        '--tags', '@simple',
        '--format', 'pretty',
        'features/browser_config_simple.feature'
    ]
    
    try:
        print("Ejecutando comando:", ' '.join(cmd))
        result = subprocess.run(
            cmd,
            cwd='testing',
            env=test_env,
            timeout=120  # 2 minutos timeout
        )
        
        if result.returncode == 0:
            print("✅ Prueba rápida de configuración del navegador EXITOSA")
            return True
        else:
            print("❌ Prueba rápida de configuración del navegador FALLÓ")
            return False
            
    except subprocess.TimeoutExpired:
        print("❌ La prueba excedió el tiempo límite de 2 minutos")
        return False
    except Exception as e:
        print(f"❌ Error ejecutando prueba: {e}")
        return False

def main():
    """Función principal"""
    print("🧪 Test Rápido - Configuración del Navegador")
    print("=" * 50)
    
    success = run_quick_browser_config_test()
    
    print("\n" + "=" * 50)
    if success:
        print("🎉 ¡Prueba rápida completada exitosamente!")
        print("✅ El sistema de configuración del navegador está funcionando")
    else:
        print("❌ La prueba rápida falló")
        print("🔍 Revisa los logs anteriores para más detalles")
    
    return success

if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)