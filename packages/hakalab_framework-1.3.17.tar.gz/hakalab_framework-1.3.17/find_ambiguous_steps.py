#!/usr/bin/env python3
"""
Script para encontrar pasos ambiguos en los archivos de steps
"""
import os
import re
from pathlib import Path

def extract_steps_from_file(file_path):
    """Extrae todos los decoradores @step de un archivo"""
    steps = []
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
        # Buscar todos los @step('...')
        pattern = r"@step\('([^']+)'\)"
        matches = re.findall(pattern, content)
        for match in matches:
            steps.append(match)
    return steps

def find_ambiguous_steps():
    """Encuentra pasos que son prefijos de otros"""
    steps_dir = Path('hakalab_framework/steps')
    all_steps = {}
    
    # Recolectar todos los steps
    for file_path in steps_dir.glob('*.py'):
        if file_path.name == '__init__.py':
            continue
        steps = extract_steps_from_file(file_path)
        all_steps[file_path.name] = steps
    
    # Buscar ambigüedades
    ambiguous = []
    for file_name, steps in all_steps.items():
        for i, step1 in enumerate(steps):
            for j, step2 in enumerate(steps):
                if i != j:
                    # Verificar si step1 es prefijo de step2
                    if step2.startswith(step1) and step1 != step2:
                        ambiguous.append({
                            'file': file_name,
                            'shorter': step1,
                            'longer': step2
                        })
    
    return ambiguous

if __name__ == '__main__':
    print("🔍 Buscando pasos ambiguos...")
    ambiguous = find_ambiguous_steps()
    
    if not ambiguous:
        print("✅ No se encontraron pasos ambiguos")
    else:
        print(f"\n❌ Se encontraron {len(ambiguous)} pasos ambiguos:\n")
        for item in ambiguous:
            print(f"📁 Archivo: {item['file']}")
            print(f"   Paso corto: {item['shorter']}")
            print(f"   Paso largo:  {item['longer']}")
            print()
