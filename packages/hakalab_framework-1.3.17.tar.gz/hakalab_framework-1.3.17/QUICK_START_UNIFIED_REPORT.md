# Quick Start: Reporte Unificado

## En 30 segundos

```bash
# 1. Ejecutar pruebas (genera reportes)
behave --processes 4 --format json --outdir html-reports

# 2. Generar reporte unificado
python -m hakalab_framework.generate_unified_report \
  --artifacts-dir ./html-reports

# 3. Abrir en navegador
open consolidated-reports/unified_report.html
```

## Opciones

```bash
# Con directorio personalizado
python -m hakalab_framework.generate_unified_report \
  --artifacts-dir ./html-reports \
  --output-dir ./consolidated-reports \
  --output-file my_report.html

# Para CI/CD (busca recursivamente en artifacts/)
python -m hakalab_framework.generate_unified_report \
  --artifacts-dir ./artifacts \
  --output-dir ./consolidated-reports \
  --output-file unified_report.html
```

## Desde Python

```python
from hakalab_framework.core.unified_report_generator import UnifiedReportGenerator

generator = UnifiedReportGenerator(output_dir="html-reports")
generator.load_json_reports("html-reports")
generator.save_report("unified_report.html")
```

## Características

✅ Un único archivo HTML portable  
✅ Sin dependencias externas  
✅ Gráficos interactivos  
✅ Screenshots embebidos  
✅ Agrupación por worker  
✅ Responsive (móvil, tablet, desktop)  

## Documentación Completa

- **Guía de Uso**: `.kiro/REPORTE_UNIFICADO_GUIA.md`
- **Documentación Técnica**: `.kiro/IMPLEMENTACION_REPORTE_UNIFICADO.md`
- **Resumen**: `.kiro/RESUMEN_REPORTE_UNIFICADO.md`

## Troubleshooting

**Error: "No se encontraron archivos test_report_*.json"**
- Verifica que los JSONs estén en el directorio especificado
- Asegúrate que los nombres sigan el patrón `test_report_*.json`

**El reporte está vacío**
- Verifica que los JSONs tengan la estructura correcta
- Revisa que contengan la clave `features`

---

¡Listo! Tu reporte unificado está creado. 🎉
