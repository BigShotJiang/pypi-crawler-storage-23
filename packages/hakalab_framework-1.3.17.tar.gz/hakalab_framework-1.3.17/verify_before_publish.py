#!/usr/bin/env python3
"""
Script de verificación pre-publicación
Verifica que todo esté listo antes de publicar en PyPI
"""

import os
import sys
from pathlib import Path

# ============================================================================
# VERSIÓN GLOBAL - CAMBIAR SOLO AQUÍ
# ============================================================================
VERSION = "1.3.12"
# ============================================================================

def check_file_exists(filepath, description):
    """Verifica que un archivo exista"""
    if os.path.exists(filepath):
        print(f"✅ {description}: {filepath}")
        return True
    else:
        print(f"❌ {description} NO ENCONTRADO: {filepath}")
        return False

def check_version_in_file(filepath, version, description):
    """Verifica que la versión esté en un archivo"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
            if version in content:
                print(f"✅ {description}: Versión {version} encontrada")
                return True
            else:
                print(f"❌ {description}: Versión {version} NO encontrada")
                return False
    except Exception as e:
        print(f"❌ Error leyendo {filepath}: {e}")
        return False

def check_requirements():
    """Verifica que requirements.txt tenga las dependencias correctas"""
    required_deps = [
        'playwright>=1.57.0',
        'behave>=1.3.3',
        'google-genai>=0.1.0',
        'transformers>=4.30.0',
        'torch>=2.0.0',
        'deepdiff>=6.7.0',
    ]
    
    try:
        with open('requirements.txt', 'r', encoding='utf-8') as f:
            content = f.read()
            
        missing = []
        for dep in required_deps:
            if dep.split('>=')[0] not in content:
                missing.append(dep)
        
        if missing:
            print(f"❌ Dependencias faltantes en requirements.txt:")
            for dep in missing:
                print(f"   - {dep}")
            return False
        else:
            print(f"✅ Todas las dependencias principales están en requirements.txt")
            return True
    except Exception as e:
        print(f"❌ Error leyendo requirements.txt: {e}")
        return False

def check_documentation():
    """Verifica que la documentación esté completa"""
    docs = [
        'hakalab_framework/documentacion/GUIA_TESTING_GEMINI_COMPLETA.txt',
        'hakalab_framework/documentacion/REFERENCIA_RAPIDA_GEMINI.txt',
        'hakalab_framework/documentacion/GUIA_API_TESTING_NotebookLM.txt',
        'hakalab_framework/documentacion/REFERENCIA_RAPIDA_API_TESTING.txt',
        'hakalab_framework/documentacion/GUIA_VALIDACION_SEMANTICA_IA.txt',
        'hakalab_framework/documentacion/REFERENCIA_RAPIDA_NLP.txt',
        'hakalab_framework/documentacion/INVENTARIO_STEPS_FRAMEWORK.txt',
    ]
    
    all_exist = True
    for doc in docs:
        if not os.path.exists(doc):
            print(f"❌ Documentación faltante: {doc}")
            all_exist = False
    
    if all_exist:
        print(f"✅ Toda la documentación principal está presente")
    
    return all_exist

def check_examples():
    """Verifica que los ejemplos estén completos"""
    examples = [
        'hakalab_framework/examples/gemini_evaluation_example.feature',
        'hakalab_framework/examples/gemini_technical_docs_example.feature',
        'hakalab_framework/examples/api_testing_advanced_example.feature',
        'hakalab_framework/examples/semantic_nlp_example.feature',
        'hakalab_framework/examples/context/api_specification_example.txt',
        'hakalab_framework/examples/context/customer_service_rules.txt',
        'hakalab_framework/examples/context/tech_support_rules.txt',
    ]
    
    all_exist = True
    for example in examples:
        if not os.path.exists(example):
            print(f"❌ Ejemplo faltante: {example}")
            all_exist = False
    
    if all_exist:
        print(f"✅ Todos los ejemplos principales están presentes")
    
    return all_exist

def check_steps_modules():
    """Verifica que los módulos de steps estén presentes"""
    steps = [
        'hakalab_framework/steps/genai_evaluation_steps.py',
        'hakalab_framework/steps/api_json_validation_steps.py',
        'hakalab_framework/steps/semantic_validation_steps.py',
        'hakalab_framework/steps/semantic_advanced_steps.py',
        'hakalab_framework/steps/semantic_nlp_steps.py',
    ]
    
    all_exist = True
    for step in steps:
        if not os.path.exists(step):
            print(f"❌ Módulo de steps faltante: {step}")
            all_exist = False
    
    if all_exist:
        print(f"✅ Todos los módulos de steps v{VERSION} están presentes")
    
    return all_exist

def main():
    """Función principal"""
    print("="*70)
    print(f"🔍 VERIFICACIÓN PRE-PUBLICACIÓN - HAKALAB FRAMEWORK v{VERSION}")
    print("="*70)
    
    checks = []
    
    # Verificar archivos principales
    print("\n📄 Verificando archivos principales...")
    checks.append(check_file_exists('setup.py', 'setup.py'))
    checks.append(check_file_exists('pyproject.toml', 'pyproject.toml'))
    checks.append(check_file_exists('README.md', 'README.md'))
    checks.append(check_file_exists('CHANGELOG.md', 'CHANGELOG.md'))
    checks.append(check_file_exists('requirements.txt', 'requirements.txt'))
    checks.append(check_file_exists('MANIFEST.in', 'MANIFEST.in'))
    checks.append(check_file_exists('LICENSE', 'LICENSE'))
    
    # Verificar versión
    print(f"\n🔢 Verificando versión {VERSION}...")
    checks.append(check_version_in_file('setup.py', VERSION, 'setup.py'))
    checks.append(check_version_in_file('pyproject.toml', VERSION, 'pyproject.toml'))
    checks.append(check_version_in_file('CHANGELOG.md', f'[{VERSION}]', 'CHANGELOG.md'))
    
    # Verificar dependencias
    print("\n📦 Verificando dependencias...")
    checks.append(check_requirements())
    
    # Verificar documentación
    print("\n📚 Verificando documentación...")
    checks.append(check_documentation())
    
    # Verificar ejemplos
    print("\n📁 Verificando ejemplos...")
    checks.append(check_examples())
    
    # Verificar módulos de steps
    print("\n🔧 Verificando módulos de steps...")
    checks.append(check_steps_modules())
    
    # Resumen
    print("\n" + "="*70)
    print("📊 RESUMEN DE VERIFICACIÓN")
    print("="*70)
    
    passed = sum(checks)
    total = len(checks)
    
    print(f"\nVerificaciones pasadas: {passed}/{total}")
    
    if passed == total:
        print("\n✅ ¡TODO LISTO PARA PUBLICAR!")
        print("\nPuedes proceder con:")
        print("  python publish_to_pypi.py")
        return 0
    else:
        print(f"\n❌ Faltan {total - passed} verificaciones")
        print("\nCorrige los errores antes de publicar")
        return 1

if __name__ == "__main__":
    sys.exit(main())
