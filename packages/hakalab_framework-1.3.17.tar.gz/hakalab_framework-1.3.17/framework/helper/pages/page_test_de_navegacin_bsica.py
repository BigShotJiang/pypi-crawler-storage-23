from selenium.webdriver.common.by import By

class TestdeNavegacinBsicaPage:
    def __init__(self, browser):
        self.browser = browser

    titulo_pagina = (By.XPATH, "//title")
    body_pagina = (By.TAG_NAME, "body")
