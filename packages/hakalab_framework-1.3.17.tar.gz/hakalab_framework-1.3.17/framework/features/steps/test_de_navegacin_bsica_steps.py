import os
import time
from behave import given, when, then
from assertpy import soft_assertions
from helper.plugins.AllurePlugin import attach_text
from helper.pages.testdenavegacinbsicapage import TestdeNavegacinBsicaPage


@given(u'que abro el navegador')
def que_abro_el_navegador(context):
    """
    Step: que abro el navegador
    """
    # TODO: Implementar la lógica del step
    pass


@when(u"navego a 'https://example.com'")
def navego_a_httpsexamplecom(context):
    """
    Step: navego a 'https://example.com'
    """
    # TODO: Implementar la lógica del step
    pass


@then(u'debería ver el título de la página')
def debera_ver_el_ttulo_de_la_pgina(context):
    """
    Step: debería ver el título de la página
    """
    # TODO: Implementar la lógica del step
    pass

