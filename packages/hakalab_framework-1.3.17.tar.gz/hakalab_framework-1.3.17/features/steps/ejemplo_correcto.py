"""
Ejemplo correcto de steps personalizados para Hakalab Framework.

Este archivo muestra cómo usar correctamente el ElementLocator y otros
componentes del framework.
"""

from behave import step, given, when, then
from playwright.sync_api import expect
from hakalab_framework.core.screenshot_manager import take_screenshot
from hakalab_framework.core.variable_manager import get_variable, set_variable


# ============================================================================
# EJEMPLO 1: Uso correcto del ElementLocator
# ============================================================================

@step('hago click en el elemento JSON "{identifier}"')
def click_elemento_json(context, identifier):
    """
    Click en un elemento usando el localizador JSON del framework.
    
    Args:
        context: Contexto de Behave (contiene page, element_locator, etc.)
        identifier: Identificador en formato $.ARCHIVO.elemento
        
    Ejemplo:
        When hago click en el elemento JSON "$.LOGIN.submit_button"
    """
    try:
        # El ElementLocator ya está disponible en context.element_locator
        element = context.element_locator.find(context.page, identifier)
        element.click()
        
        print(f"✓ Click exitoso en: {identifier}")
        
    except Exception as e:
        take_screenshot(context, f"error_click_{identifier.replace('.', '_')}")
        raise AssertionError(f"Error al hacer click en {identifier}: {str(e)}")


@step('escribo "{texto}" en el campo JSON "{identifier}"')
def escribir_campo_json(context, texto, identifier):
    """
    Escribe texto en un campo usando el localizador JSON.
    
    Args:
        context: Contexto de Behave
        texto: Texto a escribir
        identifier: Identificador en formato $.ARCHIVO.elemento
        
    Ejemplo:
        When escribo "admin@example.com" en el campo JSON "$.LOGIN.email_field"
    """
    try:
        element = context.element_locator.find(context.page, identifier)
        element.fill(texto)
        
        print(f"✓ Texto escrito en {identifier}: {texto}")
        
    except Exception as e:
        take_screenshot(context, f"error_escribir_{identifier.replace('.', '_')}")
        raise AssertionError(f"Error al escribir en {identifier}: {str(e)}")


# ============================================================================
# EJEMPLO 2: Uso de selectores CSS directos con Playwright
# ============================================================================

@step('hago click en el selector CSS "{selector}"')
def click_selector_css(context, selector):
    """
    Click usando selector CSS directamente con Playwright.
    
    Args:
        context: Contexto de Behave
        selector: Selector CSS del elemento
        
    Ejemplo:
        When hago click en el selector CSS "#submit-button"
    """
    try:
        page = context.page
        element = page.locator(selector)
        
        # Esperar a que sea visible
        element.wait_for(state="visible", timeout=10000)
        
        # Hacer click
        element.click()
        
        print(f"✓ Click exitoso en selector: {selector}")
        
    except Exception as e:
        take_screenshot(context, f"error_css_{selector.replace('#', '').replace('.', '_')}")
        raise AssertionError(f"Error al hacer click en {selector}: {str(e)}")


# ============================================================================
# EJEMPLO 3: Extracción de datos y uso de variables
# ============================================================================

@step('extraigo el texto del elemento JSON "{identifier}" y lo guardo como "{variable_name}"')
def extraer_texto_json(context, identifier, variable_name):
    """
    Extrae texto de un elemento y lo guarda en una variable.
    
    Args:
        context: Contexto de Behave
        identifier: Identificador en formato $.ARCHIVO.elemento
        variable_name: Nombre de la variable donde guardar el texto
        
    Ejemplo:
        When extraigo el texto del elemento JSON "$.PRODUCT.price" y lo guardo como "precio_producto"
    """
    try:
        element = context.element_locator.find(context.page, identifier)
        texto = element.inner_text()
        
        # Guardar en variable del framework
        set_variable(context, variable_name, texto)
        
        print(f"✓ Texto extraído de {identifier}: {texto}")
        print(f"✓ Guardado en variable: {variable_name}")
        
    except Exception as e:
        take_screenshot(context, f"error_extraer_{identifier.replace('.', '_')}")
        raise AssertionError(f"Error al extraer texto de {identifier}: {str(e)}")


@step('uso la variable "{variable_name}" en el campo JSON "{identifier}"')
def usar_variable_en_campo(context, variable_name, identifier):
    """
    Usa una variable previamente guardada en un campo.
    
    Args:
        context: Contexto de Behave
        variable_name: Nombre de la variable a usar
        identifier: Identificador del campo en formato $.ARCHIVO.elemento
        
    Ejemplo:
        When uso la variable "precio_producto" en el campo JSON "$.CART.price_field"
    """
    try:
        # Obtener valor de la variable
        valor = get_variable(context, variable_name)
        
        if valor is None:
            raise Exception(f"Variable '{variable_name}' no encontrada")
        
        # Escribir en el campo
        element = context.element_locator.find(context.page, identifier)
        element.fill(str(valor))
        
        print(f"✓ Variable '{variable_name}' usada en {identifier}: {valor}")
        
    except Exception as e:
        raise AssertionError(f"Error al usar variable {variable_name}: {str(e)}")


# ============================================================================
# EJEMPLO 4: Validaciones personalizadas
# ============================================================================

@then('el elemento JSON "{identifier}" debe contener el texto "{texto_esperado}"')
def validar_texto_elemento_json(context, identifier, texto_esperado):
    """
    Valida que un elemento contenga cierto texto.
    
    Args:
        context: Contexto de Behave
        identifier: Identificador en formato $.ARCHIVO.elemento
        texto_esperado: Texto que debe contener el elemento
        
    Ejemplo:
        Then el elemento JSON "$.MESSAGE.success" debe contener el texto "Operación exitosa"
    """
    try:
        element = context.element_locator.find(context.page, identifier)
        
        # Usar expect de Playwright para validación
        expect(element).to_contain_text(texto_esperado, timeout=10000)
        
        print(f"✓ Validación exitosa: {identifier} contiene '{texto_esperado}'")
        
    except Exception as e:
        take_screenshot(context, f"error_validacion_{identifier.replace('.', '_')}")
        raise AssertionError(f"Error en validación de {identifier}: {str(e)}")


@then('el elemento JSON "{identifier}" debe estar visible')
def validar_elemento_visible(context, identifier):
    """
    Valida que un elemento esté visible.
    
    Args:
        context: Contexto de Behave
        identifier: Identificador en formato $.ARCHIVO.elemento
        
    Ejemplo:
        Then el elemento JSON "$.MODAL.confirmation" debe estar visible
    """
    try:
        element = context.element_locator.find(context.page, identifier)
        
        # Validar visibilidad
        expect(element).to_be_visible(timeout=10000)
        
        print(f"✓ Elemento visible: {identifier}")
        
    except Exception as e:
        take_screenshot(context, f"error_visibilidad_{identifier.replace('.', '_')}")
        raise AssertionError(f"Elemento no visible: {identifier} - {str(e)}")


# ============================================================================
# EJEMPLO 5: Interacción compleja con múltiples elementos
# ============================================================================

@when('completo el formulario de login con usuario "{usuario}" y contraseña "{password}"')
def completar_formulario_login(context, usuario, password):
    """
    Completa un formulario de login completo.
    
    Este es un ejemplo de step que encapsula múltiples interacciones.
    
    Args:
        context: Contexto de Behave
        usuario: Usuario para el login
        password: Contraseña para el login
        
    Ejemplo:
        When completo el formulario de login con usuario "admin" y contraseña "secret123"
    """
    try:
        page = context.page
        locator = context.element_locator
        
        # 1. Escribir usuario
        usuario_field = locator.find(page, "$.LOGIN.username_field")
        usuario_field.fill(usuario)
        print(f"  ✓ Usuario ingresado: {usuario}")
        
        # 2. Escribir contraseña
        password_field = locator.find(page, "$.LOGIN.password_field")
        password_field.fill(password)
        print(f"  ✓ Contraseña ingresada")
        
        # 3. Hacer click en submit
        submit_button = locator.find(page, "$.LOGIN.submit_button")
        submit_button.click()
        print(f"  ✓ Formulario enviado")
        
        # 4. Esperar navegación
        page.wait_for_load_state("networkidle", timeout=10000)
        print(f"✓ Login completado")
        
    except Exception as e:
        take_screenshot(context, "error_login")
        raise AssertionError(f"Error en formulario de login: {str(e)}")


# ============================================================================
# EJEMPLO 6: Manejo de tablas y listas
# ============================================================================

@step('extraigo todos los productos de la tabla')
def extraer_productos_tabla(context):
    """
    Extrae todos los productos de una tabla y los guarda en el contexto.
    
    Este ejemplo muestra cómo trabajar con múltiples elementos.
    
    Ejemplo:
        When extraigo todos los productos de la tabla
    """
    try:
        page = context.page
        locator = context.element_locator
        
        # Obtener todas las filas
        rows_selector = locator.get_locator("$.PRODUCTS.table_rows")
        rows = page.locator(rows_selector).all()
        
        productos = []
        for i, row in enumerate(rows, 1):
            # Extraer datos de cada fila
            name_sel = locator.get_locator("$.PRODUCTS.product_name")
            price_sel = locator.get_locator("$.PRODUCTS.product_price")
            
            nombre = row.locator(name_sel).inner_text()
            precio = row.locator(price_sel).inner_text()
            
            productos.append({
                'nombre': nombre,
                'precio': precio
            })
            
            print(f"  ✓ Producto {i}: {nombre} - {precio}")
        
        # Guardar en contexto
        context.productos_extraidos = productos
        set_variable(context, "total_productos", len(productos))
        
        print(f"✓ Total productos extraídos: {len(productos)}")
        
    except Exception as e:
        take_screenshot(context, "error_extraer_productos")
        raise AssertionError(f"Error extrayendo productos: {str(e)}")


# ============================================================================
# NOTAS IMPORTANTES
# ============================================================================

"""
RESUMEN DE USO CORRECTO:

1. ElementLocator:
   - Ya está disponible en: context.element_locator
   - NO importar: from hakalab_framework.core.element_locator import locate_element
   - Métodos disponibles:
     * context.element_locator.find(page, identifier) - Retorna elemento Playwright
     * context.element_locator.get_locator(identifier) - Retorna solo el selector string
     * context.element_locator.get_element(page, identifier) - Alias de find()

2. Formato de identificadores JSON:
   - Siempre usar: $.ARCHIVO.elemento
   - Ejemplo: $.LOGIN.username_field
   - Los archivos JSON deben estar en la carpeta configurada en JSON_POMS_PATH

3. Playwright page:
   - Disponible en: context.page
   - Métodos útiles:
     * page.locator(selector) - Localizar elemento
     * page.goto(url) - Navegar
     * page.wait_for_selector(selector) - Esperar elemento
     * page.screenshot(path) - Capturar pantalla

4. Variables del framework:
   - Guardar: set_variable(context, nombre, valor)
   - Obtener: get_variable(context, nombre, default=None)

5. Screenshots:
   - Usar: take_screenshot(context, nombre)
   - Se guardan automáticamente en la carpeta configurada

6. Mejores prácticas:
   - Siempre usar try/except
   - Capturar screenshots en errores
   - Usar logging con print() para seguimiento
   - Validar precondiciones antes de interactuar
   - Documentar bien cada step con docstrings
"""
