#!/usr/bin/env python3
"""
Script mejorado para detectar TODOS los pasos ambiguos en el framework
"""

import re
import os
from pathlib import Path
from collections import defaultdict

def extract_steps(file_path):
    """Extrae todos los decoradores @step() de un archivo"""
    steps = []
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            for i, line in enumerate(lines, 1):
                if '@step(' in line:
                    # Extraer el patrón del step
                    match = re.search(r"@step\('([^']+)'\)", line)
                    if not match:
                        match = re.search(r'@step\("([^"]+)"\)', line)
                    if match:
                        steps.append({
                            'pattern': match.group(1),
                            'line': i,
                            'file': os.path.basename(file_path)
                        })
    except Exception as e:
        print(f"Error leyendo {file_path}: {e}")
    return steps

def find_duplicates(all_steps):
    """Encuentra pasos duplicados exactos"""
    step_map = defaultdict(list)
    for step in all_steps:
        step_map[step['pattern']].append(step)
    
    duplicates = {k: v for k, v in step_map.items() if len(v) > 1}
    return duplicates

def normalize_pattern(pattern):
    """Normaliza un patrón reemplazando parámetros por placeholder"""
    # Reemplazar {param}, {param:d}, {param:f}, etc. por {PARAM}
    normalized = re.sub(r'\{[^}]+\}', '{PARAM}', pattern)
    return normalized

def is_prefix(short, long):
    """Verifica si short es prefijo de long considerando parámetros"""
    short_norm = normalize_pattern(short)
    long_norm = normalize_pattern(long)
    
    # El paso corto es prefijo si el largo empieza con él y son diferentes
    return long_norm.startswith(short_norm) and short_norm != long_norm

def find_prefixes(all_steps):
    """Encuentra pasos donde uno es prefijo de otro"""
    prefixes = []
    patterns = list(set(s['pattern'] for s in all_steps))
    
    # Ordenar por longitud para comparar cortos con largos
    patterns.sort(key=len)
    
    for i, short in enumerate(patterns):
        for long in patterns[i+1:]:
            if is_prefix(short, long):
                # Encontrar ubicaciones
                short_locs = [s for s in all_steps if s['pattern'] == short]
                long_locs = [s for s in all_steps if s['pattern'] == long]
                
                prefixes.append({
                    'short': short,
                    'long': long,
                    'short_locations': short_locs,
                    'long_locations': long_locs
                })
    
    return prefixes

def main():
    """Función principal"""
    print("="*70)
    print("🔍 ANÁLISIS COMPLETO DE PASOS AMBIGUOS")
    print("="*70)
    
    # Buscar todos los archivos *_steps.py
    steps_dir = Path('hakalab_framework/steps')
    if not steps_dir.exists():
        print(f"❌ Error: No se encuentra el directorio {steps_dir}")
        return 1
    
    step_files = list(steps_dir.glob('*_steps.py'))
    print(f"\n📂 Analizando {len(step_files)} archivos...")
    
    # Extraer todos los steps
    all_steps = []
    for file_path in step_files:
        steps = extract_steps(file_path)
        all_steps.extend(steps)
        print(f"  ✓ {file_path.name}: {len(steps)} steps")
    
    print(f"\n📊 Total de decoradores @step encontrados: {len(all_steps)}")
    
    # Buscar duplicados exactos
    print("\n" + "="*70)
    print("🔍 DUPLICADOS EXACTOS")
    print("="*70)
    
    duplicates = find_duplicates(all_steps)
    
    if duplicates:
        print(f"\n❌ Se encontraron {len(duplicates)} pasos duplicados:\n")
        for pattern, locations in duplicates.items():
            print(f"📍 Paso: '{pattern}'")
            print(f"   Definido en {len(locations)} lugares:")
            for loc in locations:
                print(f"   - {loc['file']}:{loc['line']}")
            print()
    else:
        print("\n✅ No se encontraron duplicados exactos")
    
    # Buscar prefijos
    print("\n" + "="*70)
    print("🔍 PASOS PREFIJOS (uno es prefijo de otro)")
    print("="*70)
    
    prefixes = find_prefixes(all_steps)
    
    if prefixes:
        print(f"\n❌ Se encontraron {len(prefixes)} casos de prefijos:\n")
        for i, prefix in enumerate(prefixes, 1):
            print(f"📍 Caso {i}:")
            print(f"   Paso CORTO: '{prefix['short']}'")
            for loc in prefix['short_locations']:
                print(f"     - {loc['file']}:{loc['line']}")
            print(f"   Paso LARGO:  '{prefix['long']}'")
            for loc in prefix['long_locations']:
                print(f"     - {loc['file']}:{loc['line']}")
            print()
    else:
        print("\n✅ No se encontraron pasos prefijos")
    
    # Resumen
    print("\n" + "="*70)
    print("📊 RESUMEN")
    print("="*70)
    total_issues = len(duplicates) + len(prefixes)
    print(f"\nDuplicados exactos: {len(duplicates)}")
    print(f"Pasos prefijos: {len(prefixes)}")
    print(f"Total de problemas: {total_issues}")
    
    if total_issues == 0:
        print("\n✅ ¡No se encontraron pasos ambiguos!")
        return 0
    else:
        print(f"\n❌ Se encontraron {total_issues} problemas que deben corregirse")
        return 1

if __name__ == "__main__":
    exit(main())
