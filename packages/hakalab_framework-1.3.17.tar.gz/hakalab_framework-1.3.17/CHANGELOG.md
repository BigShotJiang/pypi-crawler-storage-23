# Changelog

Todos los cambios notables de este proyecto serán documentados en este archivo.


## [1.3.17] - 2026-02-16

### 🔧 Mejoras

**Se añade ASSERTION_TIMEOUT para configurar la espera de timeout desde el .env, por defecto
se establece en 30 segundos si es que no se personaliza


## [1.3.16] - 2026-02-15

### 🔧 Mejoras

**Se mejora la espera de ventanas nuevas en el modo Headless la solucion es esperar con context.expect_page()

## [1.3.12] - 2026-02-14

### 🔧 Mejoras

**Tag @no_browser para Pruebas sin Navegador** ⭐ NUEVO
- Nuevo tag `@no_browser` para desactivar el navegador en escenarios específicos
- Soluciona el problema de hooks que intentaban cerrar navegadores no inicializados
- Uso: Agregar `@no_browser` antes del escenario en lugar del step `desactivo el navegador`
- Ejemplo:
  ```gherkin
  @no_browser
  Scenario: Validar respuesta con Gemini
    Given cargo el contexto de negocio "support" desde el archivo "context/support.txt"
    When establezco la respuesta del SUT como "Respuesta de prueba"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8
  ```
- Actualizado `environment.py` template para detectar el tag automáticamente
- Todos los ejemplos actualizados para usar el tag en lugar del step

### 🔄 Migraciones

**Migración a google-genai (Nueva API de Gemini)** ⭐ IMPORTANTE
- Migrado de `google-generativeai` (deprecado) a `google-genai` (nueva API oficial)
- Actualizado `genai_evaluation_steps.py` para usar la nueva API
- Cambios en la dependencia:
  - ❌ `google-generativeai>=0.3.0` (deprecado)
  - ✅ `google-genai>=0.1.0` (nueva API)
- Actualizados todos los archivos de documentación y requirements
- La funcionalidad se mantiene igual, solo cambia la implementación interna
- **Acción requerida**: Reinstalar dependencias con `pip install -U google-genai`

### ✨ Nuevas Funcionalidades

**Generación Automática de Respuestas con Gemini** ⭐ NUEVO
- Nuevo paso: `Gemini genera la respuesta para el prompt "{user_query}"`
- Gemini genera respuestas automáticamente basándose en el contexto de negocio cargado
- Casos de uso:
  - **Golden Answers**: Generar respuestas de referencia para testing
  - **Testing de RAG**: Comparar tu IA vs Gemini
  - **Datasets de Entrenamiento**: Crear pares pregunta-respuesta automáticamente
  - **Validación de Consistencia**: Verificar que preguntas similares obtienen respuestas consistentes
- Usa Context Caching para eficiencia en múltiples generaciones
- Ejemplo completo en `gemini_generate_answers_example.feature`

**Validación Directa de Pregunta-Respuesta con Gemini** ⭐ NUEVO
- Nuevos pasos para validar pregunta y respuesta en un solo paso:
  - `valido con Gemini que según el contexto para la pregunta "{pregunta}" la respuesta "{respuesta}" es válida con umbral {threshold}`
  - `el Juez Gemini valida que para la pregunta "{pregunta}" la respuesta "{respuesta}" es correcta con umbral {threshold}`
- Simplifica el testing de múltiples pares pregunta-respuesta
- Ideal para validar FAQs, documentación técnica, y respuestas de chatbots
- Evita tener que usar pasos separados para establecer pregunta y respuesta
- Ejemplo completo en `gemini_evaluation_example.feature` (Ejemplo 9)

**Steps Avanzados para Testing de IA Generativa** ⭐ NUEVO (20 nuevos steps)
- Nuevo archivo: `genai_advanced_steps.py` con capacidades avanzadas de testing
- **Validación de Idioma** (2 steps):
  - `valido que la respuesta del SUT está en idioma "{language}"`
  - Detecta automáticamente el idioma y valida contra el esperado
- **Validación de Estructura JSON** (4 steps):
  - `valido que la respuesta del SUT es un JSON válido`
  - `valido que el JSON de respuesta tiene la estructura "{schema_file}"`
  - Valida estructura y tipos de datos contra esquemas
- **Detección de Intencionalidad** (2 steps):
  - `valido que la intención de la respuesta es "{expected_intent}"`
  - Detecta intención: informativa, persuasiva, empática, etc.
- **Testing Adversarial / Jailbreaking** (2 steps):
  - `valido que la respuesta rechaza el prompt adversarial`
  - Valida que la IA rechaza intentos de manipulación
- **Detección de Hallucinations** (2 steps):
  - `valido que la respuesta no contiene alucinaciones según el contexto`
  - Detecta información inventada que no está en el contexto
- **Detección de Bias (Sesgos)** (2 steps):
  - `valido que la respuesta no contiene sesgos de "{bias_type}"`
  - Detecta sesgos de género, edad, raza, etc.
- **Detección de Toxicidad** (2 steps):
  - `valido que la respuesta no contiene lenguaje tóxico`
  - Detecta lenguaje ofensivo, agresivo o inapropiado
- **Validación de Consistencia** (2 steps):
  - `valido que las respuestas "{var1}" y "{var2}" son consistentes`
  - Valida que múltiples respuestas no se contradicen
- **Validación de Citación de Fuentes** (2 steps):
  - `valido que la respuesta cita fuentes correctamente`
  - Valida citación para sistemas RAG

**Ejemplos Completos de Testing Avanzado** ⭐ NUEVO
- `gemini_advanced_testing_example.feature`: 9 features con 25+ escenarios
  - Validación de idioma (español, inglés, detección de errores)
  - Validación de JSON y esquemas
  - Detección de intencionalidad
  - Testing adversarial y jailbreaking
  - Detección de hallucinations
  - Detección de bias (género, edad, raza)
  - Detección de toxicidad
  - Validación de consistencia
  - Validación de citación de fuentes (RAG)
- `gemini_api_integration_example.feature`: 10 escenarios de integración
  - Testing combinado de API + IA
  - Validación de respuestas JSON de APIs con IA
  - Testing de chatbots con captura de respuestas del frontend
  - Validación de APIs de traducción, resumen, sentimiento
  - Testing de moderación de contenido
  - Validación de sesgos en APIs
  - Testing adversarial en APIs

**Umbral de Caching Configurable** ⭐ NUEVO
- El umbral de tokens para activar Context Caching ahora es configurable
- Variable de entorno: `GEMINI_CACHE_THRESHOLD` (por defecto: 32000)
- Opciones recomendadas:
  - `1000`: Siempre usar caching (máximo ahorro)
  - `10000`: Balance (documentos medianos)
  - `32000`: Solo documentos grandes (recomendado por Google)
- Permite ajustar según tus necesidades de costo vs latencia

**Datos Estructurados en Reportes HTML para Steps sin Navegador** ⭐ NUEVO
- Los steps de API, semántica y Gemini ahora adjuntan información estructurada al reporte HTML
- Cuando no hay navegador activo, se muestra información JSON en lugar de screenshots
- Información incluida:
  - **Gemini**: Score, razonamiento, errores críticos, fortalezas, sugerencias
  - **Semántica**: Similitud, umbral, modelo, textos comparados, resultado
  - **NLP**: Entidades extraídas, resúmenes, traducciones, análisis de toxicidad
- Los datos se muestran con estilos CSS diferenciados según el estado (passed/failed)
- Mejora significativa en la trazabilidad de pruebas sin interfaz visual

**Modelo Gemini Configurable** ⭐ NUEVO
- El modelo de Gemini ahora es configurable vía variable de entorno `GEMINI_JUDGE_MODEL`
- Soporta cualquier modelo de Gemini disponible (gemini-1.5-pro-002, gemini-2.0-flash-exp, etc.)
- Valor por defecto: `gemini-1.5-pro-002`
- Configuración en `.env`:
  ```
  GEMINI_JUDGE_MODEL=gemini-2.0-flash-exp
  ```

### 🔧 Correcciones

**Archivos Feature de Ejemplos Actualizados**
- Corregidos todos los pasos en `gemini_evaluation_example.feature`
- Corregidos todos los pasos en `gemini_technical_docs_example.feature`
- Cambios realizados:
  - ❌ `cargo el contexto de negocio` → ✅ `el contexto de reglas de negocio ... está cargado`
  - ❌ `guardo la evaluación en el archivo` → ✅ `guardo la evaluación del Juez en el archivo`
  - ❌ `el score de evaluación debe ser al menos` → ✅ `el score de la última evaluación debe ser mayor o igual a`
- Todos los pasos ahora coinciden exactamente con los implementados en el código
- Verificación: 0 pasos ambiguos en 1518 decoradores @step ✅

## [1.3.6] - 2026-02-13

### 🔧 Correcciones Críticas

**Corrección Sistemática de Pasos Ambiguos**
- Eliminados todos los pasos duplicados y ambiguos del framework
- Corregido paso ambiguo final en `wait_steps.py`:
  - `I wait for the element to have attribute in identifier` → `I wait for the element to have the attribute in identifier`
  - Agregada palabra "the" para diferenciar del paso con valor
- Sistema de detección mejorado con script `find_all_ambiguous_steps.py`
- Verificación completa: 0 pasos ambiguos en 1518 decoradores @step ✅

**Corrección de Importaciones de Steps Semánticos** ⭐ NUEVO
- Agregadas importaciones faltantes en `hakalab_framework/steps/__init__.py`:
  - `semantic_validation_steps.py` - Validación semántica básica
  - `semantic_advanced_steps.py` - Validación semántica avanzada
  - `semantic_nlp_steps.py` - Procesamiento de lenguaje natural
  - `genai_evaluation_steps.py` - Evaluación con Gemini
  - `api_json_validation_steps.py` - Validación avanzada de JSON
  - `ocr_steps.py` - Reconocimiento óptico de caracteres
- Los steps ahora están disponibles al importar el framework ✅

**Decoradores Faltantes Agregados** ⭐ NUEVO
- Agregados decoradores en `variable_steps.py`:
  - `muestro en consola el valor de la variable` - Variante del step existente
  - `I print the value of variable` - Variante en inglés
- Mejora la usabilidad con sintaxis más natural

**Nueva Funcionalidad: Desactivar Navegador** ⭐ NUEVO
- Agregados steps para desactivar el navegador en pruebas que no lo necesitan:
  - `desactivo el navegador para esta prueba` / `I disable browser for this test`
  - `no necesito navegador para esta prueba` / `I do not need browser for this test`
  - `reactivo el navegador` / `I re-enable the browser`
  - `necesito el navegador ahora` / `I need the browser now`
- Casos de uso:
  - Pruebas de validación semántica/NLP (sin UI)
  - Pruebas de API REST (sin UI)
  - Pruebas de base de datos (sin UI)
  - Pruebas de procesamiento de archivos CSV
- Beneficios:
  - No abre ventana del navegador innecesariamente
  - No captura screenshots en blanco
  - Mejora el rendimiento de pruebas sin UI
  - Reduce consumo de recursos

**Control de Mensajes de Logging** ⭐ NUEVO
- Agregadas variables de entorno para ocultar warnings:
  - `HIDE_TRANSFORMERS_WARNINGS=true` - Oculta warnings de transformers/sentence-transformers
  - `HIDE_HF_WARNINGS=true` - Oculta warnings de Hugging Face Hub
  - `HIDE_BEHAVE_WARNINGS=true` - Oculta warnings de Behave context masking
- Configuración automática al inicio del framework
- Mejora la legibilidad de la salida de consola

**Data Snapshots para Reportes** ⭐ NUEVO
- Nuevo sistema de captura de información para pruebas sin UI
- Genera archivos JSON y HTML visuales en lugar de screenshots
- Tipos de snapshots soportados:
  - Validación semántica: textos comparados, similitud, umbral, modelo
  - Evaluación Gemini: respuesta SUT, contexto, score, detalles
  - API requests: método, URL, headers, body, response, tiempo
  - Análisis NLP: texto, tipo de análisis, resultados
- Snapshots se guardan en `reports/data_snapshots/`
- HTML visuales con diseño profesional y colores
- Integración automática cuando el navegador está desactivado

**Pasos Corregidos en Versiones Anteriores**
- v1.3.2: Pasos ambiguos en español corregidos
- v1.3.3: Pasos ambiguos en inglés corregidos
- v1.3.4: Corrección final y verificación sistemática completa

**Sistema de Versiones Centralizado**
- Variable global `VERSION` en `publish_to_pypi.py` y `verify_before_publish.py`
- Cambio de versión simplificado en un solo lugar

**Archivos Modificados**
- `hakalab_framework/steps/__init__.py` - Importaciones de steps semánticos agregadas ⭐
- `hakalab_framework/steps/variable_steps.py` - Decoradores adicionales agregados ⭐
- `hakalab_framework/steps/browser_control_steps.py` - Steps para desactivar navegador ⭐
- `hakalab_framework/steps/semantic_validation_steps.py` - Integración con data snapshots ⭐
- `hakalab_framework/core/environment_config.py` - Soporte para navegador desactivado, control de warnings y data snapshots ⭐
- `hakalab_framework/core/data_snapshot_manager.py` - Nuevo módulo para captura de datos ⭐
- `hakalab_framework/examples/.env.example` - Variables para control de warnings agregadas ⭐
- `hakalab_framework/steps/wait_steps.py` - Paso final corregido
- `hakalab_framework/steps/navigation_steps.py` - Duplicado eliminado
- `hakalab_framework/steps/timing_steps.py` - Duplicado eliminado
- `hakalab_framework/steps/iframe_steps.py` - Prefijos corregidos
- `hakalab_framework/steps/assertion_steps.py` - Prefijos corregidos
- `publish_to_pypi.py` - Sistema de versiones centralizado
- `verify_before_publish.py` - Sistema de versiones centralizado

**Scripts de Utilidad Agregados**
- `find_all_ambiguous_steps.py` - Detecta duplicados exactos y prefijos
- Análisis completo de 41 archivos de steps
- Reporte detallado con ubicaciones exactas

### 📝 Mejoras en Calidad
- Framework completamente libre de pasos ambiguos
- Steps de IA y validación semántica ahora disponibles ⭐
- Mejor experiencia de desarrollo sin errores `AmbiguousStep`
- Documentación actualizada con reglas para evitar ambigüedades futuras

### 📚 Documentación y Ejemplos Actualizados
- `semantic_validation_example.feature` - Agregado uso de desactivar navegador
- `semantic_nlp_example.feature` - Agregado uso de desactivar navegador
- `INICIO_RAPIDO_VALIDACION_SEMANTICA.txt` - Nueva sección de optimización
- `GUIA_TESTING_GEMINI_COMPLETA.txt` - Ejemplos actualizados con desactivar navegador

## [1.3.2] - 2026-02-13

### 🔧 Mejoras en Validación Semántica

**Configuración desde Variables de Entorno**
- El step `uso la configuración semántica por defecto` ahora lee desde variables de entorno (.env)
- Variables agregadas: `SEMANTIC_MODEL` y `SEMANTIC_THRESHOLD`
- Valores por defecto si no están configuradas:
  - SEMANTIC_MODEL: paraphrase-multilingual-MiniLM-L12-v2
  - SEMANTIC_THRESHOLD: 0.75
- Permite centralizar configuración en .env para consistencia en todos los tests
- Los steps manuales (`configuro el modelo semántico como...`) siguen funcionando para sobrescribir valores

**Documentación Agregada**
- `GUIA_STEPS_SEMANTICOS_PERSONALIZADOS.txt` - Guía completa para crear steps personalizados
- 5 ejemplos prácticos de steps personalizados:
  1. Validación contra múltiples opciones
  2. Validación contra todos los textos esperados
  3. Steps con umbrales personalizados (muy similar / vagamente similar)
  4. Extracción y validación en un solo paso
  5. Umbral dinámico especificado en el paso
- Funciones auxiliares documentadas: `_ensure_semantic_config()` y `_calculate_similarity()`
- Template básico para crear steps personalizados
- Mejores prácticas y troubleshooting

**Archivos Modificados**
- `hakalab_framework/steps/semantic_validation_steps.py` - Step actualizado para leer desde .env
- `hakalab_framework/examples/.env.example` - Variables SEMANTIC_MODEL y SEMANTIC_THRESHOLD agregadas
- `hakalab_framework/documentacion/INICIO_RAPIDO_VALIDACION_SEMANTICA.txt` - Documentación actualizada
- `hakalab_framework/documentacion/GUIA_STEPS_SEMANTICOS_PERSONALIZADOS.txt` - Nueva guía (NUEVO)

### 📝 Mejoras en Documentación
- Sección de configuración inicial expandida con instrucciones para .env
- Ejemplos actualizados mostrando dos opciones: configurar en .env vs configurar en feature
- Tips actualizados para enfatizar el uso de .env como mejor práctica

## [1.3.0] - 2026-02-12

### 🚀 Nuevas Funcionalidades - NLP Avanzado

Esta versión introduce un conjunto completo de funcionalidades de Procesamiento de Lenguaje Natural (NLP) usando modelos de Hugging Face Transformers.

#### 📦 Nuevo Módulo: `semantic_nlp_steps.py`

**1. Extracción de Entidades (NER)**
- `extraigo las entidades del texto "{text}" y las guardo en "{var_name}"`
- `el texto "{text}" debe contener la entidad "{entity}" de tipo "{entity_type}"`
- Extrae personas (PER), organizaciones (ORG), lugares (LOC) y otros (MISC)
- Casos de uso: Análisis de formularios, tickets de soporte, documentos legales

**2. Resumen Automático**
- `resumo el texto "{text}" y lo guardo en "{var_name}"`
- `resumo el texto "{text}" con longitud máxima de {max_length} palabras y lo guardo en "{var_name}"`
- Genera resúmenes automáticos de textos largos
- Casos de uso: Resumir artículos, generar previews, resumir conversaciones

**3. Traducción Automática**
- `traduzco el texto "{text}" de "{source_lang}" a "{target_lang}" y lo guardo en "{var_name}"`
- `el texto "{text}" traducido de "{source_lang}" a "{target_lang}" debe ser semánticamente similar a "{expected}"`
- Idiomas soportados: es, en, fr, de, pt
- Casos de uso: Testing de localización (i18n), validar traducciones

**4. Generación de Texto**
- `genero texto a partir del prompt "{prompt}" y lo guardo en "{var_name}"`
- `genero texto a partir del prompt "{prompt}" con longitud máxima de {max_length} palabras y lo guardo en "{var_name}"`
- Genera texto automáticamente basado en prompts
- Casos de uso: Respuestas automáticas, contenido de prueba, testing de chatbots

**5. Análisis de Toxicidad**
- `el texto "{text}" no debe ser tóxico`
- `el texto "{text}" debe ser tóxico`
- `calculo la toxicidad del texto "{text}" y la guardo en "{var_name}"`
- Detecta contenido ofensivo o inapropiado
- Casos de uso: Moderación de comentarios, filtrado de contenido

**6. Extracción de Keywords**
- `extraigo las keywords del texto "{text}" y las guardo en "{var_name}"`
- `extraigo {num_keywords} keywords del texto "{text}" y las guardo en "{var_name}"`
- Identifica palabras clave más importantes
- Casos de uso: Generar tags, indexar documentos, SEO

**7. Clustering de Textos**
- `agrupo los textos "{texts}" en {num_clusters} clusters y guardo el resultado en "{var_name}"`
- Agrupa textos similares automáticamente
- Casos de uso: Agrupar tickets, organizar documentos, detectar patrones

**8. Question Answering (QA)**
- `respondo la pregunta "{question}" basándome en el contexto "{context}" y guardo la respuesta en "{var_name}"`
- Responde preguntas basándose en un contexto
- Casos de uso: Extraer información de documentos, FAQs automáticas

#### 📦 Nuevo Módulo: `api_json_validation_steps.py` ⭐ NUEVO

**Validación Avanzada de JSON para APIs REST**

**1. Validación de Esquemas JSON Schema (Draft 7)**
- `verifico que el JSON de respuesta API coincide con el esquema del archivo "{schema_file}"`
- Validación completa usando JSON Schema Draft 7
- Soporta tipos, formatos, rangos, enums, required, additionalProperties

**2. Comparación con Archivos**
- `verifico que el JSON de respuesta API coincide exactamente con el archivo "{expected_file}"`
- `verifico que el JSON de respuesta API coincide con el archivo "{expected_file}" ignorando orden`
- `verifico que el JSON de respuesta API coincide con el archivo "{expected_file}" ignorando campos "{ignored_fields}"`
- Comparación exacta, ignorando orden de arrays, o ignorando campos específicos

**3. Validación de Tipos**
- `verifico que el JSON de respuesta API tiene el campo "{field_path}" con tipo "{expected_type}"`
- Tipos soportados: string, number, integer, boolean, array, object, null

**4. Validación con Regex**
- `verifico que el campo "{field_path}" del JSON de respuesta API coincide con el patrón "{pattern}"`
- Validación de emails, teléfonos, UUIDs, fechas, URLs, etc.

**5. Validación de Rangos**
- `verifico que el campo "{field_path}" del JSON de respuesta API está en el rango {min_value} a {max_value}`
- Validación de rangos numéricos (edad, precio, rating, etc.)

**6. Validación de Arrays**
- `verifico que el array "{array_path}" del JSON de respuesta API contiene un elemento con "{field}" igual a "{value}"`
- `verifico que todos los elementos del array "{array_path}" del JSON de respuesta API tienen el campo "{field}"`
- Validación de contenido y estructura de arrays

**7. Validación de Valores Nulos**
- `verifico que el JSON de respuesta API no tiene valores nulos`
- Búsqueda recursiva de valores null en toda la respuesta

**8. Gestión de Archivos**
- `guardo el JSON de respuesta API en el archivo "{file_path}"`
- `cargo JSON del archivo "{file_path}" y envío POST a "{url}" guardando respuesta en variable "{variable_name}"`
- Guardar respuestas y cargar payloads desde archivos

#### 📚 Documentación Actualizada
- `GUIA_VALIDACION_SEMANTICA_IA.txt` expandida con 5 nuevas secciones (16-20)
- `GUIA_API_TESTING_NotebookLM.txt` expandida con 8 nuevas secciones (7-15)
- `GUIA_TESTING_GEMINI_COMPLETA.txt` - Guía completa de testing con Gemini como Juez (11 secciones) ⭐ NUEVO
- Nueva guía: `REFERENCIA_RAPIDA_NLP.txt` con referencia completa de steps NLP

#### 📝 Ejemplos de Uso
- Nuevo archivo: `semantic_nlp_example.feature` con 8 escenarios completos
- Nuevo archivo: `api_testing_advanced_example.feature` con 8 escenarios de validación avanzada
- Nuevo archivo: `gemini_evaluation_example.feature` con 8 features de testing con Gemini ⭐ NUEVO
- Archivos de ejemplo: esquemas JSON Schema, payloads, respuestas esperadas
- Archivos de contexto: `customer_service_rules.txt`, `tech_support_rules.txt` para Gemini

#### 🔧 Dependencias Actualizadas
- `transformers>=4.30.0` - Modelos de Hugging Face
- `torch>=2.0.0` - Backend para modelos
- `keybert>=0.8.0` - Extracción de keywords
- `scikit-learn>=1.3.0` - Clustering de textos
- `deepdiff>=6.7.0` - Comparación profunda de JSON
- `google-genai>=0.1.0` - API de Gemini para evaluación de IA ⭐ NUEVO

#### 💡 Casos de Uso Destacados

**NLP:**
1. Procesamiento completo de tickets: NER + Sentimiento + Toxicidad + Keywords + Clasificación + Resumen
2. Moderación multilingüe: Detección de idioma + Toxicidad + Sentimiento
3. Respuestas automáticas: Question Answering + Generación de texto
4. Análisis de documentos legales: NER + QA + Keywords
5. Testing de localización: Traducción + Validación semántica

**API Testing:**
1. Validación con JSON Schema: Esquemas completos con tipos, formatos, rangos
2. Comparación con archivos: Exacta, ignorando orden, ignorando campos dinámicos
3. Validación de tipos y patrones: Regex para emails, UUIDs, fechas, URLs
4. Validación de arrays: Contenido, estructura, campos requeridos
5. Testing de paginación: Estructura completa de respuestas paginadas

**Gemini como Juez:** ⭐ NUEVO
1. Testing de chatbots: Validar respuestas contra reglas de negocio
2. Evaluación de LLMs: Validar calidad de respuestas de GPT, Claude, etc.
3. Testing de contenido generado: Validar guías de estilo y tono de marca
4. Validación de restricciones: Asegurar cumplimiento de políticas
5. Testing multilingüe: Validar respuestas en múltiples idiomas

#### ⚙️ Requisitos de Sistema
- RAM: Mínimo 8GB (recomendado 16GB)
- Disco: ~5GB para todos los modelos NLP
- GPU: Opcional (acelera procesamiento 10-50x)
- Internet: Requerido para primera descarga de modelos

### 📝 Notas de Migración
- Las funcionalidades NLP son completamente opcionales
- Los modelos se descargan automáticamente la primera vez (~5GB total)
- La validación avanzada de JSON requiere deepdiff>=6.7.0
- Compatible con todas las funcionalidades existentes del framework
- Se puede combinar con validación semántica existente

## [1.2.32] - 2026-02-12

### 🔧 Correcciones Críticas
- **Fix reintentos de escenarios abriendo múltiples ventanas**: Corregido problema donde los reintentos creaban nuevas ventanas
  - Ahora los reintentos reutilizan la página existente en lugar de cerrarla y crear una nueva
  - La página se limpia navegando a `about:blank` en lugar de cerrarla
  - Solo crea una nueva página si la limpieza falla
  - Agregada limpieza de `current_frame` para evitar problemas con iframes en reintentos
  - Mensaje más claro: "♻️ Página limpiada para reintento (navegada a about:blank)"
  - Evita acumulación de ventanas/tabs durante reintentos automáticos

### 📝 Mejoras
- Mejor manejo de estado entre reintentos de escenarios
- Limpieza más completa del contexto (variables, API listeners, iframes)
- Fallback automático: si la limpieza falla, entonces sí crea una nueva página

## [1.2.31] - 2026-02-11

### 🔧 Correcciones Críticas
- **Fix reutilización de páginas entre escenarios**: Corregido problema donde se abrían múltiples ventanas
  - Mejorada lógica de `setup_scenario_context` para verificar primero `context.page`
  - Ahora verifica si la página en `context.page` está activa antes de buscar en el browser
  - Agregado limpieza de `context.page = None` en `auto_after_feature`
  - Mensajes más claros: "♻️ Reutilizando página existente" vs "🆕 Nueva página creada"
  - Evita abrir ventanas innecesarias entre escenarios del mismo feature

### 📝 Mejoras
- Mejor logging para diagnosticar reutilización de páginas
- Limpieza más explícita de referencias a páginas al finalizar features

## [1.2.30] - 2026-02-11

### 🔧 Correcciones Críticas
- **Soporte de iframes en steps de interacción**: Corregidos steps de click y fill que no usaban `_get_element()`
  - `hago click en el elemento` - Ahora funciona dentro de iframes
  - `hago doble click en el elemento` - Ahora funciona dentro de iframes
  - `hago click derecho en el elemento` - Ahora funciona dentro de iframes
  - `hago click en el select` - Ahora funciona dentro de iframes
  - `paso el mouse sobre el elemento` - Ahora funciona dentro de iframes
  - `relleno el campo` - Ahora funciona dentro de iframes
  - `relleno el campo de fecha` - Ahora funciona dentro de iframes
  - `limpio el campo` - Ahora funciona dentro de iframes
  - Todos ahora usan `_get_element()` que detecta automáticamente si estás en un iframe

### 📝 Mejoras
- Consistencia total: todos los steps de interacción ahora soportan iframes correctamente
- Los steps detectan automáticamente el contexto (página principal o iframe) y actúan en consecuencia

## [1.2.29] - 2026-02-11

### 🔧 Correcciones Críticas
- **Soporte de iframes en steps de verificación de texto**: Corregidos steps que verifican texto directamente en la página
  - `debería ver el texto "{text}"` - Ahora busca dentro del iframe si está activo
  - `debería ver el texto que contiene "{text}"` - Ahora busca dentro del iframe si está activo
  - `debería ver en la página el texto ${variable}` - Ahora busca dentro del iframe si está activo
  - `no debería ver el texto "{text}"` - Ahora busca dentro del iframe si está activo
  - Todos usan `page_or_frame = getattr(context, 'current_frame', None) or context.page`
  - Completamente retrocompatible con código existente

### 📝 Mejoras
- Consistencia total en soporte de iframes: todos los steps de verificación de texto ahora funcionan igual
- Los steps detectan automáticamente si estás dentro de un iframe y buscan en el contexto correcto

## [1.2.28] - 2026-02-11

### 🔧 Correcciones Críticas
- **Fix step duplicado**: Eliminado step duplicado `I switch to main content` en `iframe_steps.py`
  - El step estaba definido tanto en `window_steps.py` como en `iframe_steps.py`
  - Causaba error `AmbiguousStep` al cargar el framework
  - Ahora solo existe en `window_steps.py` con todos los decoradores necesarios

## [1.2.27] - 2026-02-11

### 🔧 Correcciones Críticas
- **Soporte completo para iframes**: Todos los steps ahora soportan trabajar dentro de iframes
  - Modificada función `_get_element` en todos los archivos de steps
  - Detecta automáticamente si estás dentro de un iframe (`context.current_frame`)
  - Busca elementos dentro del iframe cuando está activo
  - Completamente retrocompatible con código existente

### ✨ Nuevas Funcionalidades
- **Step para salir de iframes**: Agregados steps `salgo del frame` / `cambio al contenido principal`
  - Permite volver al contenido principal después de trabajar en un iframe
  - Limpia `context.current_frame` para volver a buscar en la página principal

### 📝 Mejoras
- Soporte de iframes en 15+ archivos de steps:
  - `interaction_steps.py`, `assertion_steps.py`, `validation_steps.py`
  - `form_handling_steps.py`, `wait_steps.py`, `data_extraction_steps.py`
  - `combobox_steps.py`, `web_elements_steps.py`, `variable_steps.py`
  - `timing_steps.py`, `table_steps.py`, `scroll_steps.py`
  - `modal_steps.py`, `keyboard_mouse_steps.py`, `iframe_steps.py`
  - `drag_drop_steps.py`, `advanced_input_steps.py`, `window_steps.py`

### 🔄 Flujo de Trabajo con Iframes
```gherkin
# Entrar al iframe
And cambio al frame "del PDF" con identificador "$.TGR.iframe_pdf"

# Trabajar dentro del iframe
And hago click en el elemento "Botón" con identificador "$.TGR.boton"

# Salir del iframe
And salgo del frame

# Continuar en la página principal
And hago click en el elemento "Cerrar" con identificador "$.TGR.cerrar"
```

## [1.2.26] - 2026-02-11

### 🔧 Correcciones Críticas
- **Fix iframe switching**: Corregido error `'FrameLocator' object is not callable` en `step_switch_to_frame`
  - Cambiado de `frame_element.content_frame()` a `page.frame_locator()`
  - Ahora funciona correctamente con iframes
- **Debug mejorado**: Agregado mensaje de debug para variable `HEADLESS`
  - Muestra `🔍 DEBUG: Variable HEADLESS leída = '...'` en consola
  - Ayuda a diagnosticar problemas de configuración en CI/CD

### 📝 Mejoras
- Mejor diagnóstico de configuración de navegador en GitHub Actions
- Mensajes más claros para troubleshooting

## [1.2.25] - 2026-02-11

### ✨ Nuevas Funcionalidades
- **Soporte para Google Chrome**: Ahora puedes usar Chrome instalado en el sistema con `BROWSER=chrome`
- **Reintentos de Escenarios**: Sistema completo de reintentos automáticos para escenarios fallidos
  - Variable `RETRY_FAILED_SCENARIOS=true/false` para habilitar/deshabilitar
  - Variable `MAX_SCENARIO_RETRIES=1-5` para controlar cantidad de reintentos
  - Limpieza automática de estado entre reintentos
  - Mensajes informativos en consola (🔄, ✅, ❌)
- **Modo Stealth**: Integración de `playwright-stealth` para evitar detección de bots
  - Variable `STEALTH_MODE=true/false` para activar/desactivar
  - Oculta propiedades como `navigator.webdriver`, `navigator.plugins`, etc.
  - Instalación automática con el framework

### 🔧 Correcciones Críticas
- **CLI Browser Override**: Corregido bug donde `--browser` siempre sobrescribía el `.env` con `chromium`
  - Ahora `--browser` es opcional y solo sobrescribe si se especifica explícitamente
  - Respeta el valor de `BROWSER` en el archivo `.env`
- **Variables de Entorno**: Mejorado soporte para sintaxis `${variable}` en steps de variables
  - Los steps ahora aceptan tanto `"variable"` como `"${variable}"`
  - Resolución automática de valores de variables

### 📝 Mejoras
- **Mensajes de Debug**: Agregados mensajes informativos para diagnosticar configuración de navegador
  - `🔍 DEBUG: Variable BROWSER leída = '...'`
  - `🔧 Configurando navegador: ...`
  - `🌐 Usando Google Chrome instalado en el sistema` / `🌐 Usando Chromium`
- **Documentación**: Actualizada guía de configuración del navegador con diferencias Chrome vs Chromium
- **Fallback Automático**: Si Chrome no está instalado, usa Chromium automáticamente sin fallar

### 📚 Documentación Agregada
- `GUIA_REINTENTOS_ESCENARIOS.txt` - Guía completa sobre reintentos automáticos
- `GUIA_MODO_STEALTH.txt` - Guía sobre modo anti-detección
- Actualizada `GUIA_CONFIGURACION_NAVEGADOR_NotebookLM.txt` con info Chrome vs Chromium

### 🔄 Archivos Modificados
- `hakalab_framework/core/environment_config.py` - Soporte Chrome, reintentos, stealth, debug
- `hakalab_framework/core/scenario_retry_runner.py` - Sistema de reintentos (nuevo)
- `hakalab_framework/cli.py` - Corregido override de BROWSER
- `hakalab_framework/steps/variable_steps.py` - Soporte sintaxis ${}
- `requirements.txt` - Agregado playwright-stealth

## [1.2.24] - 2026-01-27

### 🔧 Correcciones Críticas
- **Manejo de Alertas/Diálogos**: Reemplazado sistema de listeners con `page.expect_dialog()` context manager
- **Steps de Alertas**: Corregidos todos los steps para usar la API correcta de Playwright
- **Validación de Alertas**: Implementados steps para verificar mensajes exactos y parciales
- **Listener de Diálogos**: Corregido listener para ACEPTAR automáticamente diálogos (evita que se quede pegado)
- **Step de Extracción**: Corregido step `extraigo el texto del diálogo...` para capturar ANTES de aceptar
- **Orden de Operaciones**: Cambio crítico en el flujo: capturar → esperar → aceptar

### 📝 Steps Nuevos/Corregidos
- `acepto la alerta` - Acepta alertas/confirmaciones
- `rechazo la alerta` - Rechaza confirmaciones
- `acepto la alerta con texto "valor"` - Maneja prompts
- `obtengo el texto de la alerta y lo guardo en la variable "var"` - Captura mensaje
- `extraigo el texto del diálogo lo guardo en la variable "var" y cierro el diálogo` - **NUEVO** - Captura con listener (CORREGIDO)
- `el mensaje de la alerta debería ser "texto"` - Verifica exactitud
- `el mensaje de la alerta debería contener "texto"` - Verifica parcialmente
- `guardo el mensaje de la alerta en la variable "var"` - Almacena mensaje
- `evito que se cierren automáticamente los diálogos` - Acepta diálogos automáticamente (CORREGIDO)

### 📚 Documentación Agregada
- `GUIA_MANEJO_ALERTAS.md` - Guía completa sobre manejo de alertas y diálogos
- `REFERENCIA_RAPIDA_ALERTAS.md` - Referencia rápida con cheat sheet
- `QUICK_REFERENCE_DIALOGS.md` - Quick reference para decisiones rápidas

### 🎯 Cambios Técnicos
- Reemplazado sistema de listeners con `expect_dialog()` para mejor control
- Todos los steps de alertas ahora usan context managers
- Listener de diálogos ahora ACEPTA automáticamente en lugar de solo escuchar
- Mejor manejo de timeouts y errores en diálogos
- Nuevo step para capturar texto antes de cerrar diálogo usando listener + `wait_for_function()`
- Removido step duplicado de `modal_steps.py`
- **CRÍTICO:** Cambio en orden de operaciones: capturar → esperar → aceptar (no aceptar inmediatamente)

## [1.2.23] - 2026-01-09

### 🎯 Funcionalidades Principales Agregadas
- **Integración Completa con Jira**: Adjunto automático de reportes HTML a issues de Jira
- **Integración Optimizada con Xray Cloud**: Creación automática de Test Executions con flujo optimizado
- **Flujo Xray Optimizado**: Una sola llamada API crea Test Execution, adjunta todos los tests y actualiza estados
- **Vinculación Automática**: Test Executions se vinculan automáticamente a Historias de Usuario
- **Steps Específicos Jira/Xray**: 12+ steps para gestión manual de integraciones

### 🔧 Componentes Nuevos
- `hakalab_framework/integrations/jira_integration.py` - Integración completa con Jira
- `hakalab_framework/integrations/xray_integration.py` - Integración optimizada con Xray Cloud
- `hakalab_framework/integrations/behave_hooks.py` - Hooks automáticos para Behave
- `hakalab_framework/steps/jira_xray_steps.py` - Steps específicos para Jira/Xray

### 📚 Documentación Agregada
- `ARQUITECTURA_FRAMEWORK_NotebookLM.txt` - Guía técnica completa de arquitectura
- `GUIA_INTEGRACION_JIRA_XRAY.md` - Guía completa de integración Jira/Xray
- `GUIA_INTEGRACION_JIRA_XRAY_NotebookLM.txt` - Versión optimizada para IA
- `GUIA_PARALELIZACION_CI_CD_NotebookLM.txt` - Versión optimizada para IA

### ⚙️ Variables de Entorno Nuevas
- `JIRA_ENABLED` - Control maestro de integración con Jira
- `JIRA_URL`, `JIRA_EMAIL`, `JIRA_TOKEN`, `JIRA_PROJECT` - Configuración de Jira
- `JIRA_COMMENT_MESSAGE` - Mensaje personalizable para comentarios
- `XRAY_ENABLED` - Control de integración con Xray
- `XRAY_AUTHORIZATION_TOKEN` - Token directo de Xray Cloud
- `XRAY_BASE_URL` - URL base de Xray Cloud API
- `XRAY_TEST_PLAN` - Test Plan opcional para asociar executions

### 🧪 Scripts de Prueba Agregados
- `test_jira_connection.py` - Script de prueba de conexión con Jira
- `test_xray_connection.py` - Script de prueba de conexión con Xray

### 🔄 Archivos Actualizados
- `features/environment.py` - Hooks automáticos de Jira/Xray integrados
- `.env` y `.env.example` - Variables de configuración de Jira/Xray
- `README.md` y `README_NotebookLM.txt` - Documentación actualizada

### 🎨 Mejoras en Funcionalidades Existentes
- **Sistema de Variables**: Resolución mejorada de variables dinámicas
- **Reportes HTML**: Integración con información de Jira/Xray
- **Screenshots**: Captura automática mejorada para integraciones
- **Logging**: Información detallada de procesos de integración

### 🐛 Correcciones
- Mapeo correcto de estados Xray (passed/failed/skipped)
- Validación robusta de tipos de issues en Jira
- Manejo mejorado de errores en integraciones
- Timeouts configurables para APIs externas

### 📦 Dependencias Actualizadas
- `requests>=2.31.0` - Para integraciones HTTP con Jira/Xray
- `pandas>=2.0.0` - Procesamiento de datos CSV (funcionalidad existente)

## [1.2.12] - 2026-01-06

### Agregado
- **Manejo Avanzado de CSV**: 15+ steps para procesamiento completo de archivos CSV
- **Variables Dinámicas**: 20+ steps para generación y manipulación automática de variables
- **Control de Tiempos**: 15+ steps para cronómetros, esperas inteligentes y medición de rendimiento
- **Entrada Avanzada**: 25+ steps para simulación de escritura humana
- **Drag & Drop Mejorado**: Sistema completamente rediseñado con múltiples métodos de fallback

### Archivos Nuevos
- `hakalab_framework/steps/csv_file_steps.py` - Procesamiento de CSV
- `hakalab_framework/steps/timing_steps.py` - Control avanzado de tiempos
- `hakalab_framework/steps/advanced_input_steps.py` - Entrada sofisticada
- `hakalab_framework/steps/variable_steps.py` - Variables dinámicas

### Mejorado
- `hakalab_framework/steps/drag_drop_steps.py` - Drag & drop completamente rediseñado

## [1.1.19] - 2025-01-01

### Agregado
- Soporte para Playwright 1.57.0
- Soporte para Behave 1.3.3
- Wrapper para cleanup_error
- Allure-Behave 2.15.3

### Corregido
- Problema de cleanup en Behave + Playwright
- Mejoras en performance de reportes
- Correcciones menores en steps

## [1.1.18] - 2024-12-15

### Agregado
- Versión inicial estable
- 200+ steps de automatización
- Reportes HTML personalizados
- Integración con Allure
- Soporte multi-navegador
- Page Object Models en JSON

### Dependencias Iniciales
- Playwright 1.40.0
- Behave 1.2.6
- Allure-Behave 2.13.2

---

## Tipos de Cambios
- `Agregado` para nuevas funcionalidades
- `Cambiado` para cambios en funcionalidades existentes
- `Deprecado` para funcionalidades que serán removidas pronto
- `Removido` para funcionalidades removidas
- `Corregido` para corrección de bugs
- `Seguridad` para vulnerabilidades


## [1.2.25] - 2026-01-13

### Added
- **Reporte Unificado**: Nuevo sistema para consolidar múltiples reportes JSON en un único HTML portable
  - `UnifiedReportGenerator`: Clase principal para generar reportes unificados
  - `cli_unified_report.py`: Interfaz CLI para usar desde terminal
  - `generate_unified_report.py`: Script de ejemplo en testing
  - Soporte para múltiples workers paralelos
  - Gráficos interactivos con Chart.js
  - Screenshots embebidos en base64
  - Agrupación automática por worker

### Features
- ✅ Portabilidad: Un único archivo HTML sin dependencias
- ✅ Escalabilidad: Soporta N workers paralelos
- ✅ Interactividad: Expandir/contraer features y scenarios
- ✅ Responsive: Funciona en móvil, tablet y desktop
- ✅ Rendimiento: Generación instantánea (~1 segundo)
- ✅ Personalización: Mantiene diseño actual

### Documentation
- Guía completa de uso: `.kiro/REPORTE_UNIFICADO_GUIA.md`
- Documentación técnica: `.kiro/IMPLEMENTACION_REPORTE_UNIFICADO.md`

### Testing
- Test completo del generador: `testing/test_unified_report.py`
- Validación de HTML y datos
- Verificación de portabilidad

### Integration
- Integración en GitHub Actions workflow
- Paso "Generar reporte unificado" en job "reports"
- Descarga automática de artifacts y consolidación

### Changed
- Actualizado `hakalab_framework/__init__.py` para exportar `UnifiedReportGenerator`
- Actualizado `.github/workflows/hakalab-ci.yml` para usar nuevo generador

### Removed
- Dependencia de `merge_reports` para reportes unificados (reemplazado por `UnifiedReportGenerator`)
