"""
Steps para testing de email
Incluye envío, recepción, validación y manipulación de emails
"""

from behave import step
import smtplib
import imaplib
import email
import json
import time
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

@step('I send email to "{recipient}" with subject "{subject}" and body "{body}" using SMTP "{smtp_server}" port "{port}"')
@step('envío email a "{recipient}" con asunto "{subject}" y cuerpo "{body}" usando SMTP "{smtp_server}" puerto "{port}"')
def step_send_email(context, recipient, subject, body, smtp_server, port):
    """Envía un email usando SMTP"""
    resolved_recipient = context.variable_manager.resolve_variables(recipient)
    resolved_subject = context.variable_manager.resolve_variables(subject)
    resolved_body = context.variable_manager.resolve_variables(body)
    resolved_server = context.variable_manager.resolve_variables(smtp_server)
    
    # Obtener credenciales de variables de entorno o contexto
    sender_email = getattr(context, 'email_sender', 'test@example.com')
    sender_password = getattr(context, 'email_password', 'password')
    
    try:
        # Crear mensaje
        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = resolved_recipient
        msg['Subject'] = resolved_subject
        
        msg.attach(MIMEText(resolved_body, 'plain'))
        
        # Conectar y enviar
        server = smtplib.SMTP(resolved_server, int(port))
        server.starttls()
        server.login(sender_email, sender_password)
        
        text = msg.as_string()
        server.sendmail(sender_email, resolved_recipient, text)
        server.quit()
        
        print(f"✓ Email enviado a {resolved_recipient}")
        print(f"  Asunto: {resolved_subject}")
        
    except Exception as e:
        print(f"✗ Error enviando email: {e}")
        raise

@step('I set email credentials sender="{sender}" password="{password}"')
@step('establezco las credenciales de email remitente="{sender}" contraseña="{password}"')
def step_set_email_credentials(context, sender, password):
    """Establece las credenciales para envío de email"""
    context.email_sender = context.variable_manager.resolve_variables(sender)
    context.email_password = context.variable_manager.resolve_variables(password)
    
    print(f"✓ Credenciales de email establecidas para {context.email_sender}")

@step('I connect to IMAP server "{imap_server}" port "{port}" with username "{username}" password "{password}"')
@step('me conecto al servidor IMAP "{imap_server}" puerto "{port}" con usuario "{username}" contraseña "{password}"')
def step_connect_imap(context, imap_server, port, username, password):
    """Conecta a un servidor IMAP para leer emails"""
    resolved_server = context.variable_manager.resolve_variables(imap_server)
    resolved_username = context.variable_manager.resolve_variables(username)
    resolved_password = context.variable_manager.resolve_variables(password)
    
    try:
        context.imap_connection = imaplib.IMAP4_SSL(resolved_server, int(port))
        context.imap_connection.login(resolved_username, resolved_password)
        
        print(f"✓ Conectado a servidor IMAP {resolved_server}")
        
    except Exception as e:
        print(f"✗ Error conectando a IMAP: {e}")
        raise

@step('I select email folder "{folder}"')
@step('selecciono la carpeta de email "{folder}"')
def step_select_email_folder(context, folder):
    """Selecciona una carpeta de email (INBOX, SENT, etc.)"""
    if not hasattr(context, 'imap_connection'):
        raise AssertionError("No hay conexión IMAP disponible")
    
    try:
        context.imap_connection.select(folder)
        print(f"✓ Carpeta '{folder}' seleccionada")
        
    except Exception as e:
        print(f"✗ Error seleccionando carpeta: {e}")
        raise

@step('I search emails with subject containing "{subject_text}" and store count in variable "{variable_name}"')
@step('busco emails con asunto que contiene "{subject_text}" y guardo el conteo en la variable "{variable_name}"')
def step_search_emails_by_subject(context, subject_text, variable_name):
    """Busca emails por asunto y guarda el conteo"""
    if not hasattr(context, 'imap_connection'):
        raise AssertionError("No hay conexión IMAP disponible")
    
    resolved_subject = context.variable_manager.resolve_variables(subject_text)
    
    try:
        # Buscar emails
        status, messages = context.imap_connection.search(None, f'SUBJECT "{resolved_subject}"')
        
        if status == 'OK':
            email_ids = messages[0].split()
            count = len(email_ids)
            
            context.variable_manager.set_variable(variable_name, str(count))
            context.last_email_search = email_ids
            
            print(f"✓ Encontrados {count} emails con asunto que contiene '{resolved_subject}'")
        else:
            print(f"✗ Error buscando emails")
            raise AssertionError("Error buscando emails")
            
    except Exception as e:
        print(f"✗ Error en búsqueda de emails: {e}")
        raise

@step('I get latest email content and store in variable "{variable_name}"')
@step('obtengo el contenido del email más reciente y lo guardo en la variable "{variable_name}"')
def step_get_latest_email_content(context, variable_name):
    """Obtiene el contenido del email más reciente"""
    if not hasattr(context, 'imap_connection'):
        raise AssertionError("No hay conexión IMAP disponible")
    
    try:
        # Buscar todos los emails
        status, messages = context.imap_connection.search(None, 'ALL')
        
        if status == 'OK' and messages[0]:
            email_ids = messages[0].split()
            latest_email_id = email_ids[-1]  # Último email
            
            # Obtener el email
            status, msg_data = context.imap_connection.fetch(latest_email_id, '(RFC822)')
            
            if status == 'OK':
                email_body = msg_data[0][1]
                email_message = email.message_from_bytes(email_body)
                
                # Extraer información del email
                email_info = {
                    'subject': email_message['Subject'],
                    'from': email_message['From'],
                    'to': email_message['To'],
                    'date': email_message['Date'],
                    'body': ''
                }
                
                # Obtener el cuerpo del email
                if email_message.is_multipart():
                    for part in email_message.walk():
                        if part.get_content_type() == "text/plain":
                            email_info['body'] = part.get_payload(decode=True).decode()
                            break
                else:
                    email_info['body'] = email_message.get_payload(decode=True).decode()
                
                context.variable_manager.set_variable(variable_name, json.dumps(email_info))
                print(f"✓ Contenido del email más reciente guardado en variable '{variable_name}'")
                
            else:
                raise AssertionError("Error obteniendo contenido del email")
        else:
            raise AssertionError("No se encontraron emails")
            
    except Exception as e:
        print(f"✗ Error obteniendo email: {e}")
        raise

@step('I verify email with subject "{subject}" was received within "{timeout}" seconds')
@step('verifico que se recibió un email con asunto "{subject}" dentro de "{timeout}" segundos')
def step_verify_email_received(context, subject, timeout):
    """Verifica que se recibió un email con un asunto específico dentro del tiempo límite"""
    if not hasattr(context, 'imap_connection'):
        raise AssertionError("No hay conexión IMAP disponible")
    
    resolved_subject = context.variable_manager.resolve_variables(subject)
    timeout_seconds = int(timeout)
    
    start_time = time.time()
    
    while time.time() - start_time < timeout_seconds:
        try:
            status, messages = context.imap_connection.search(None, f'SUBJECT "{resolved_subject}"')
            
            if status == 'OK' and messages[0]:
                email_ids = messages[0].split()
                if len(email_ids) > 0:
                    print(f"✓ Email con asunto '{resolved_subject}' recibido")
                    return
            
            time.sleep(2)  # Esperar 2 segundos antes de verificar de nuevo
            
        except Exception as e:
            print(f"⚠ Error verificando email: {e}")
            time.sleep(2)
    
    print(f"✗ Email con asunto '{resolved_subject}' no recibido en {timeout_seconds} segundos")
    raise AssertionError(f"Email con asunto '{resolved_subject}' no recibido en {timeout_seconds} segundos")

@step('I delete emails with subject containing "{subject_text}"')
@step('elimino emails con asunto que contiene "{subject_text}"')
def step_delete_emails_by_subject(context, subject_text):
    """Elimina emails que contienen un texto específico en el asunto"""
    if not hasattr(context, 'imap_connection'):
        raise AssertionError("No hay conexión IMAP disponible")
    
    resolved_subject = context.variable_manager.resolve_variables(subject_text)
    
    try:
        # Buscar emails
        status, messages = context.imap_connection.search(None, f'SUBJECT "{resolved_subject}"')
        
        if status == 'OK' and messages[0]:
            email_ids = messages[0].split()
            
            for email_id in email_ids:
                context.imap_connection.store(email_id, '+FLAGS', '\\Deleted')
            
            context.imap_connection.expunge()
            
            print(f"✓ {len(email_ids)} emails eliminados con asunto que contiene '{resolved_subject}'")
        else:
            print(f"⚠ No se encontraron emails para eliminar")
            
    except Exception as e:
        print(f"✗ Error eliminando emails: {e}")
        raise

@step('I close email connection')
@step('cierro la conexión de email')
def step_close_email_connection(context):
    """Cierra la conexión IMAP"""
    if hasattr(context, 'imap_connection'):
        try:
            context.imap_connection.close()
            context.imap_connection.logout()
            delattr(context, 'imap_connection')
            
            print("✓ Conexión de email cerrada")
        except:
            print("⚠ Error cerrando conexión de email")
    else:
        print("⚠ No hay conexión de email para cerrar")

@step('I extract verification code from email body and store in variable "{variable_name}"')
@step('extraigo el código de verificación del cuerpo del email y lo guardo en la variable "{variable_name}"')
def step_extract_verification_code(context, variable_name):
    """Extrae un código de verificación del último email recibido"""
    if not hasattr(context, 'imap_connection'):
        raise AssertionError("No hay conexión IMAP disponible")
    
    try:
        # Obtener el último email
        status, messages = context.imap_connection.search(None, 'ALL')
        
        if status == 'OK' and messages[0]:
            email_ids = messages[0].split()
            latest_email_id = email_ids[-1]
            
            status, msg_data = context.imap_connection.fetch(latest_email_id, '(RFC822)')
            
            if status == 'OK':
                email_body = msg_data[0][1]
                email_message = email.message_from_bytes(email_body)
                
                # Obtener el cuerpo del email
                body_text = ""
                if email_message.is_multipart():
                    for part in email_message.walk():
                        if part.get_content_type() == "text/plain":
                            body_text = part.get_payload(decode=True).decode()
                            break
                else:
                    body_text = email_message.get_payload(decode=True).decode()
                
                # Buscar código de verificación (patrones comunes)
                import re
                patterns = [
                    r'código[:\s]+(\d{4,8})',  # código: 123456
                    r'verification code[:\s]+(\d{4,8})',  # verification code: 123456
                    r'(\d{6})',  # 6 dígitos
                    r'(\d{4})',  # 4 dígitos
                ]
                
                verification_code = ""
                for pattern in patterns:
                    match = re.search(pattern, body_text, re.IGNORECASE)
                    if match:
                        verification_code = match.group(1)
                        break
                
                if verification_code:
                    context.variable_manager.set_variable(variable_name, verification_code)
                    print(f"✓ Código de verificación extraído: {verification_code}")
                else:
                    print("⚠ No se encontró código de verificación en el email")
                    context.variable_manager.set_variable(variable_name, "")
                    
            else:
                raise AssertionError("Error obteniendo contenido del email")
        else:
            raise AssertionError("No se encontraron emails")
            
    except Exception as e:
        print(f"✗ Error extrayendo código de verificación: {e}")
        raise