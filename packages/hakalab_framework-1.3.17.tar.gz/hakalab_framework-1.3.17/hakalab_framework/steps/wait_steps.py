from behave import step


def _get_element(context, selector, dynamic_value=None):
    """
    Función auxiliar para obtener elementos.
    Soporta tanto selectores CSS como identificadores JSON ($.ARCHIVO.elemento)
    Soporta placeholders dinámicos: $.ARCHIVO.elemento=valor
    Soporta iframes: Si context.current_frame existe, busca dentro del iframe
    """
    # Determinar si estamos dentro de un iframe
    page_or_frame = getattr(context, 'current_frame', None) or context.page
    
    if selector.startswith('$.') and hasattr(context, 'element_locator'):
        return context.element_locator.find(page_or_frame, selector, dynamic_value)
    else:
        return page_or_frame.locator(selector)

from playwright.sync_api import TimeoutError

@step('I wait for the element "{element_name}" to be visible with identifier "{identifier}"')
@step('espero a que el elemento "{element_name}" sea visible con identificador "{identifier}"')
@step('que espero a que el elemento "{element_name}" sea visible con identificador "{identifier}"')
def step_wait_element_visible(context, element_name, identifier):
    """Espera a que un elemento sea visible"""
    locator = context.element_locator.get_locator(identifier)
    context.page.wait_for_selector(locator, state='visible')

@step('I wait for the element "{element_name}" to be hidden with identifier "{identifier}"')
@step('espero a que el elemento "{element_name}" esté oculto con identificador "{identifier}"')
@step('que espero a que el elemento "{element_name}" esté oculto con identificador "{identifier}"')
def step_wait_element_hidden(context, element_name, identifier):
    """Espera a que un elemento esté oculto"""
    locator = context.element_locator.get_locator(identifier)
    context.page.wait_for_selector(locator, state='hidden')

@step('I wait for the element "{element_name}" to be enabled with identifier "{identifier}"')
@step('espero a que el elemento "{element_name}" esté habilitado con identificador "{identifier}"')
@step('que espero a que el elemento "{element_name}" esté habilitado con identificador "{identifier}"')
def step_wait_element_enabled(context, element_name, identifier):
    """Espera a que un elemento esté habilitado"""
    locator = context.element_locator.get_locator(identifier)
    context.page.locator(locator).wait_for(state='attached')
    context.page.wait_for_function(f"document.querySelector('{locator}') && !document.querySelector('{locator}').disabled")

@step('I wait for the element "{element_name}" to contain text "{text}" with identifier "{identifier}"')
@step('espero a que el elemento "{element_name}" contenga el texto "{text}" con identificador "{identifier}"')
@step('que espero a que el elemento "{element_name}" contenga el texto "{text}" con identificador "{identifier}"')
def step_wait_element_contains_text(context, element_name, text, identifier):
    """Espera a que un elemento contenga un texto específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_text = context.variable_manager.resolve_variables(text)
    context.page.locator(locator).wait_for(state='attached')
    context.page.wait_for_function(
        f"document.querySelector('{locator}') && document.querySelector('{locator}').textContent.includes('{resolved_text}')"
    )

@step('I wait for the page url to contain "{url_part}"')
@step('espero a que la url de la página contenga "{url_part}"')
@step('que espero a que la url de la página contenga "{url_part}"')
def step_wait_url_contains(context, url_part):
    """Espera a que la URL contenga una parte específica"""
    resolved_url_part = context.variable_manager.resolve_variables(url_part)
    context.page.wait_for_url(f"**/*{resolved_url_part}*")

@step('I wait for the page title to be "{title}"')
@step('espero a que el título de la página sea "{title}"')
@step('que espero a que el título de la página sea "{title}"')
def step_wait_page_title(context, title):
    """Espera a que el título de la página sea específico"""
    resolved_title = context.variable_manager.resolve_variables(title)
    context.page.wait_for_function(f"document.title === '{resolved_title}'")

@step('I wait for network to be idle')
@step('espero a que la red esté inactiva')
@step('que espero a que la red esté inactiva')
def step_wait_network_idle(context):
    """Espera a que la red esté inactiva"""
    context.page.wait_for_load_state('networkidle')

@step('I wait for dom content to be loaded')
@step('espero a que el contenido del DOM esté cargado')
@step('que espero a que el contenido del DOM esté cargado')
def step_wait_dom_content_loaded(context):
    """Espera a que el contenido del DOM esté cargado"""
    context.page.wait_for_load_state('domcontentloaded')

@step('I wait for the element "{element_name}" to be clickable with identifier "{identifier}"')
@step('espero a que el elemento "{element_name}" sea clickeable con identificador "{identifier}"')
@step('que espero a que el elemento "{element_name}" sea clickeable con identificador "{identifier}"')
def step_wait_element_clickable(context, element_name, identifier):
    """Espera a que un elemento sea clickeable"""
    locator = context.element_locator.get_locator(identifier)
    element = context.page.locator(locator)
    element.wait_for(state='visible')
    element.wait_for(state='attached')
    context.page.wait_for_function(
        f"document.querySelector('{locator}') && !document.querySelector('{locator}').disabled"
    )


# ============================================================================
# ESPERAS PARA ELEMENTOS CON DATOS
# ============================================================================

@step('I wait for the select "{element_name}" to have options with identifier "{identifier}"')
@step('espero a que el select "{element_name}" tenga opciones con identificador "{identifier}"')
@step('que espero a que el select "{element_name}" tenga opciones con identificador "{identifier}"')
def step_wait_select_has_options(context, element_name, identifier):
    """Espera a que un select tenga opciones cargadas (más de la opción por defecto)
    
    Útil cuando un combobox se carga pero sus opciones tardan en aparecer.
    Espera hasta que haya al menos 2 opciones (asumiendo que la primera es placeholder).
    """
    locator = context.element_locator.get_locator(identifier)
    element = context.page.locator(locator)
    
    # Esperar a que el select esté visible
    element.wait_for(state='visible', timeout=10000)
    
    # Esperar a que tenga al menos 2 opciones
    def check_options():
        options = element.locator('option').count()
        return options >= 2
    
    context.page.wait_for_function(
        f"""() => {{
            const select = document.querySelector('{locator}');
            return select && select.options.length >= 2;
        }}""",
        timeout=10000
    )
    print(f"✓ El select '{element_name}' tiene opciones cargadas")

@step('I wait for the select "{element_name}" to have at least {count:d} options with identifier "{identifier}"')
@step('espero a que el select "{element_name}" tenga al menos {count:d} opciones con identificador "{identifier}"')
@step('que espero a que el select "{element_name}" tenga al menos {count:d} opciones con identificador "{identifier}"')
def step_wait_select_has_min_options(context, element_name, count, identifier):
    """Espera a que un select tenga al menos N opciones cargadas"""
    locator = context.element_locator.get_locator(identifier)
    element = context.page.locator(locator)
    
    element.wait_for(state='visible', timeout=10000)
    
    context.page.wait_for_function(
        f"""() => {{
            const select = document.querySelector('{locator}');
            return select && select.options.length >= {count};
        }}""",
        timeout=15000
    )
    print(f"✓ El select '{element_name}' tiene al menos {count} opciones")

@step('I wait for the table "{element_name}" to have rows with identifier "{identifier}"')
@step('espero a que la tabla "{element_name}" tenga filas con identificador "{identifier}"')
@step('que espero a que la tabla "{element_name}" tenga filas con identificador "{identifier}"')
def step_wait_table_has_rows(context, element_name, identifier):
    """Espera a que una tabla tenga filas cargadas (al menos 1 fila de datos)"""
    locator = context.element_locator.get_locator(identifier)
    element = context.page.locator(locator)
    
    element.wait_for(state='visible', timeout=10000)
    
    # Esperar a que tenga al menos 1 fila (tbody tr)
    context.page.wait_for_function(
        f"""() => {{
            const table = document.querySelector('{locator}');
            const tbody = table ? table.querySelector('tbody') : null;
            const rows = tbody ? tbody.querySelectorAll('tr') : [];
            return rows.length >= 1;
        }}""",
        timeout=15000
    )
    print(f"✓ La tabla '{element_name}' tiene filas cargadas")

@step('I wait for the table "{element_name}" to have at least {count:d} rows with identifier "{identifier}"')
@step('espero a que la tabla "{element_name}" tenga al menos {count:d} filas con identificador "{identifier}"')
@step('que espero a que la tabla "{element_name}" tenga al menos {count:d} filas con identificador "{identifier}"')
def step_wait_table_has_min_rows(context, element_name, count, identifier):
    """Espera a que una tabla tenga al menos N filas de datos"""
    locator = context.element_locator.get_locator(identifier)
    element = context.page.locator(locator)
    
    element.wait_for(state='visible', timeout=10000)
    
    context.page.wait_for_function(
        f"""() => {{
            const table = document.querySelector('{locator}');
            const tbody = table ? table.querySelector('tbody') : null;
            const rows = tbody ? tbody.querySelectorAll('tr') : [];
            return rows.length >= {count};
        }}""",
        timeout=15000
    )
    print(f"✓ La tabla '{element_name}' tiene al menos {count} filas")

@step('I wait for the list "{element_name}" to have items with identifier "{identifier}"')
@step('espero a que la lista "{element_name}" tenga elementos con identificador "{identifier}"')
@step('que espero a que la lista "{element_name}" tenga elementos con identificador "{identifier}"')
def step_wait_list_has_items(context, element_name, identifier):
    """Espera a que una lista (ul/ol) tenga elementos li cargados"""
    locator = context.element_locator.get_locator(identifier)
    element = context.page.locator(locator)
    
    element.wait_for(state='visible', timeout=10000)
    
    context.page.wait_for_function(
        f"""() => {{
            const list = document.querySelector('{locator}');
            const items = list ? list.querySelectorAll('li') : [];
            return items.length >= 1;
        }}""",
        timeout=15000
    )
    print(f"✓ La lista '{element_name}' tiene elementos cargados")

@step('I wait for the element "{element_name}" to have child elements with identifier "{identifier}"')
@step('espero a que el elemento "{element_name}" tenga elementos hijos con identificador "{identifier}"')
@step('que espero a que el elemento "{element_name}" tenga elementos hijos con identificador "{identifier}"')
def step_wait_element_has_children(context, element_name, identifier):
    """Espera a que un elemento tenga elementos hijos cargados"""
    locator = context.element_locator.get_locator(identifier)
    element = context.page.locator(locator)
    
    element.wait_for(state='visible', timeout=10000)
    
    context.page.wait_for_function(
        f"""() => {{
            const element = document.querySelector('{locator}');
            return element && element.children.length > 0;
        }}""",
        timeout=15000
    )
    print(f"✓ El elemento '{element_name}' tiene elementos hijos cargados")


# ============================================================================
# ESPERAS PARA ATRIBUTOS Y VALORES
# ============================================================================

@step('I wait for the element "{element_name}" to have the attribute "{attribute}" in identifier "{identifier}"')
@step('espero a que el elemento "{element_name}" tenga el atributo "{attribute}" en identificador "{identifier}"')
@step('que espero a que el elemento "{element_name}" tenga el atributo "{attribute}" en identificador "{identifier}"')
def step_wait_element_has_attribute(context, element_name, attribute, identifier):
    """Espera a que un elemento tenga un atributo específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_attr = context.variable_manager.resolve_variables(attribute)
    element = context.page.locator(locator)
    
    element.wait_for(state='attached', timeout=10000)
    
    context.page.wait_for_function(
        f"""() => {{
            const element = document.querySelector('{locator}');
            return element && element.hasAttribute('{resolved_attr}');
        }}""",
        timeout=15000
    )
    print(f"✓ El elemento '{element_name}' tiene el atributo '{resolved_attr}'")

@step('I wait for the element "{element_name}" to have attribute "{attribute}" with value "{value}" with identifier "{identifier}"')
@step('espero a que el elemento "{element_name}" tenga el atributo "{attribute}" con valor "{value}" con identificador "{identifier}"')
@step('que espero a que el elemento "{element_name}" tenga el atributo "{attribute}" con valor "{value}" con identificador "{identifier}"')
def step_wait_element_attribute_value(context, element_name, attribute, value, identifier):
    """Espera a que un atributo tenga un valor específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_attr = context.variable_manager.resolve_variables(attribute)
    resolved_value = context.variable_manager.resolve_variables(value)
    element = context.page.locator(locator)
    
    element.wait_for(state='attached', timeout=10000)
    
    context.page.wait_for_function(
        f"""() => {{
            const element = document.querySelector('{locator}');
            return element && element.getAttribute('{resolved_attr}') === '{resolved_value}';
        }}""",
        timeout=15000
    )
    print(f"✓ El elemento '{element_name}' tiene {resolved_attr}='{resolved_value}'")

@step('I wait for the field "{element_name}" to have value with identifier "{identifier}"')
@step('espero a que el campo "{element_name}" tenga valor con identificador "{identifier}"')
@step('que espero a que el campo "{element_name}" tenga valor con identificador "{identifier}"')
def step_wait_field_has_value(context, element_name, identifier):
    """Espera a que un campo tenga algún valor (no esté vacío)"""
    locator = context.element_locator.get_locator(identifier)
    element = context.page.locator(locator)
    
    element.wait_for(state='visible', timeout=10000)
    
    context.page.wait_for_function(
        f"""() => {{
            const element = document.querySelector('{locator}');
            return element && element.value && element.value.trim() !== '';
        }}""",
        timeout=15000
    )
    print(f"✓ El campo '{element_name}' tiene valor")

@step('I wait for the field "{element_name}" to have value "{value}" with identifier "{identifier}"')
@step('espero a que el campo "{element_name}" tenga el valor "{value}" con identificador "{identifier}"')
@step('que espero a que el campo "{element_name}" tenga el valor "{value}" con identificador "{identifier}"')
def step_wait_field_has_specific_value(context, element_name, value, identifier):
    """Espera a que un campo tenga un valor específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_value = context.variable_manager.resolve_variables(value)
    element = context.page.locator(locator)
    
    element.wait_for(state='visible', timeout=10000)
    
    context.page.wait_for_function(
        f"""() => {{
            const element = document.querySelector('{locator}');
            return element && element.value === '{resolved_value}';
        }}""",
        timeout=15000
    )
    print(f"✓ El campo '{element_name}' tiene el valor '{resolved_value}'")

@step('I wait for the element "{element_name}" to have class "{css_class}" with identifier "{identifier}"')
@step('espero a que el elemento "{element_name}" tenga la clase "{css_class}" con identificador "{identifier}"')
@step('que espero a que el elemento "{element_name}" tenga la clase "{css_class}" con identificador "{identifier}"')
def step_wait_element_has_class(context, element_name, css_class, identifier):
    """Espera a que un elemento tenga una clase CSS específica"""
    locator = context.element_locator.get_locator(identifier)
    resolved_class = context.variable_manager.resolve_variables(css_class)
    element = context.page.locator(locator)
    
    element.wait_for(state='attached', timeout=10000)
    
    context.page.wait_for_function(
        f"""() => {{
            const element = document.querySelector('{locator}');
            return element && element.classList.contains('{resolved_class}');
        }}""",
        timeout=15000
    )
    print(f"✓ El elemento '{element_name}' tiene la clase '{resolved_class}'")

@step('I wait for the element "{element_name}" to not have class "{css_class}" with identifier "{identifier}"')
@step('espero a que el elemento "{element_name}" no tenga la clase "{css_class}" con identificador "{identifier}"')
@step('que espero a que el elemento "{element_name}" no tenga la clase "{css_class}" con identificador "{identifier}"')
def step_wait_element_not_has_class(context, element_name, css_class, identifier):
    """Espera a que un elemento NO tenga una clase CSS específica (útil para esperar fin de loading)"""
    locator = context.element_locator.get_locator(identifier)
    resolved_class = context.variable_manager.resolve_variables(css_class)
    element = context.page.locator(locator)
    
    element.wait_for(state='attached', timeout=10000)
    
    context.page.wait_for_function(
        f"""() => {{
            const element = document.querySelector('{locator}');
            return element && !element.classList.contains('{resolved_class}');
        }}""",
        timeout=15000
    )
    print(f"✓ El elemento '{element_name}' NO tiene la clase '{resolved_class}'")


# ============================================================================
# ESPERAS PARA CONTEO Y MÚLTIPLES ELEMENTOS
# ============================================================================

@step('I wait for at least {count:d} elements matching "{element_name}" with identifier "{identifier}"')
@step('espero a que haya al menos {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"')
@step('que espero a que haya al menos {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"')
def step_wait_min_elements_count(context, count, element_name, identifier):
    """Espera a que haya al menos N elementos que coincidan con el selector"""
    locator = context.element_locator.get_locator(identifier)
    
    context.page.wait_for_function(
        f"""() => {{
            const elements = document.querySelectorAll('{locator}');
            return elements.length >= {count};
        }}""",
        timeout=15000
    )
    print(f"✓ Hay al menos {count} elementos '{element_name}'")

@step('I wait for exactly {count:d} elements matching "{element_name}" with identifier "{identifier}"')
@step('espero a que haya exactamente {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"')
@step('que espero a que haya exactamente {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"')
def step_wait_exact_elements_count(context, count, element_name, identifier):
    """Espera a que haya exactamente N elementos que coincidan con el selector"""
    locator = context.element_locator.get_locator(identifier)
    
    context.page.wait_for_function(
        f"""() => {{
            const elements = document.querySelectorAll('{locator}');
            return elements.length === {count};
        }}""",
        timeout=15000
    )
    print(f"✓ Hay exactamente {count} elementos '{element_name}'")


# ============================================================================
# ESPERAS PARA CONDICIONES DE CARGA ESPECÍFICAS
# ============================================================================

@step('I wait for the element "{element_name}" to not be empty with identifier "{identifier}"')
@step('espero a que el elemento "{element_name}" no esté vacío con identificador "{identifier}"')
@step('que espero a que el elemento "{element_name}" no esté vacío con identificador "{identifier}"')
def step_wait_element_not_empty(context, element_name, identifier):
    """Espera a que un elemento tenga contenido (textContent no vacío)"""
    locator = context.element_locator.get_locator(identifier)
    element = context.page.locator(locator)
    
    element.wait_for(state='attached', timeout=10000)
    
    context.page.wait_for_function(
        f"""() => {{
            const element = document.querySelector('{locator}');
            return element && element.textContent && element.textContent.trim() !== '';
        }}""",
        timeout=15000
    )
    print(f"✓ El elemento '{element_name}' tiene contenido")

@step('I wait for the element "{element_name}" to stop changing with identifier "{identifier}"')
@step('espero a que el elemento "{element_name}" deje de cambiar con identificador "{identifier}"')
@step('que espero a que el elemento "{element_name}" deje de cambiar con identificador "{identifier}"')
def step_wait_element_stable(context, element_name, identifier):
    """Espera a que un elemento deje de cambiar (útil para contadores, loaders dinámicos)
    
    Verifica que el textContent se mantenga igual durante 500ms
    """
    locator = context.element_locator.get_locator(identifier)
    element = context.page.locator(locator)
    
    element.wait_for(state='visible', timeout=10000)
    
    # Esperar a que el contenido se estabilice
    context.page.wait_for_function(
        f"""() => {{
            return new Promise((resolve) => {{
                const element = document.querySelector('{locator}');
                if (!element) return resolve(false);
                
                let lastContent = element.textContent;
                let stableCount = 0;
                
                const interval = setInterval(() => {{
                    const currentContent = element.textContent;
                    if (currentContent === lastContent) {{
                        stableCount++;
                        if (stableCount >= 5) {{ // 5 checks * 100ms = 500ms estable
                            clearInterval(interval);
                            resolve(true);
                        }}
                    }} else {{
                        stableCount = 0;
                        lastContent = currentContent;
                    }}
                }}, 100);
                
                // Timeout después de 10 segundos
                setTimeout(() => {{
                    clearInterval(interval);
                    resolve(false);
                }}, 10000);
            }});
        }}""",
        timeout=15000
    )
    print(f"✓ El elemento '{element_name}' se ha estabilizado")

@step('I wait for loading spinner to disappear with identifier "{identifier}"')
@step('espero a que el spinner de carga desaparezca con identificador "{identifier}"')
@step('que espero a que el spinner de carga desaparezca con identificador "{identifier}"')
def step_wait_spinner_disappear(context, identifier):
    """Espera a que un spinner/loader desaparezca"""
    locator = context.element_locator.get_locator(identifier)
    
    try:
        # Esperar a que aparezca primero (opcional)
        context.page.wait_for_selector(locator, state='visible', timeout=2000)
    except TimeoutError:
        # Si no aparece, está bien
        pass
    
    # Esperar a que desaparezca
    context.page.wait_for_selector(locator, state='hidden', timeout=30000)
    print(f"✓ El spinner de carga ha desaparecido")

@step('I wait for the element "{element_name}" to be detached with identifier "{identifier}"')
@step('espero a que el elemento "{element_name}" sea removido del DOM con identificador "{identifier}"')
@step('que espero a que el elemento "{element_name}" sea removido del DOM con identificador "{identifier}"')
def step_wait_element_detached(context, element_name, identifier):
    """Espera a que un elemento sea removido del DOM"""
    locator = context.element_locator.get_locator(identifier)
    element = context.page.locator(locator)
    
    element.wait_for(state='detached', timeout=15000)
    print(f"✓ El elemento '{element_name}' fue removido del DOM")

@step('I wait {seconds:d} seconds')
@step('espero {seconds:d} segundos')
@step('que espero {seconds:d} segundos')
def step_wait_seconds(context, seconds):
    """Espera un número específico de segundos (usar solo cuando sea necesario)"""
    import time
    time.sleep(seconds)
    print(f"✓ Esperé {seconds} segundos")

@step('I wait {milliseconds:d} milliseconds')
@step('espero {milliseconds:d} milisegundos')
@step('que espero {milliseconds:d} milisegundos')
def step_wait_milliseconds(context, milliseconds):
    """Espera un número específico de milisegundos"""
    import time
    time.sleep(milliseconds / 1000)
    print(f"✓ Esperé {milliseconds} milisegundos")