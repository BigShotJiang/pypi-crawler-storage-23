"""
Todos los pasos del framework Hakalab
Importación automática de todos los steps disponibles
"""
import os

# Steps básicos existentes
from .navigation_steps import *
from .interaction_steps import *
from .assertion_steps import *
from .scroll_steps import *
from .wait_steps import *
from .data_extraction_steps import *
from .variable_steps import *
from .window_steps import *
from .advanced_steps import *

# Nuevos steps avanzados
from .drag_drop_steps import *
from .combobox_steps import *
from .iframe_steps import *
from .modal_steps import *
from .file_steps import *
from .table_steps import *
from .keyboard_mouse_steps import *

# Steps específicos para Salesforce
from .salesforce_steps import *

# Steps para variables de entorno
from .environment_steps import *

# Nuevos steps avanzados v1.2.12
from .csv_file_steps import *
from .timing_steps import *
from .advanced_input_steps import *

# Steps de validación y accesibilidad
from .validation_steps import *
from .accessibility_steps import *
from .combobox_validation_steps import *
from .performance_steps import *
from .responsive_steps import *

# Steps de integración Jira/Xray
from .jira_xray_steps import *

# Nuevos steps v1.3.0 - Expansión mayor
from .web_elements_steps import *
from .form_handling_steps import *
from .browser_control_steps import *
from .browser_advanced_config_steps import *
from .api_testing_steps import *
from .database_steps import *
from .email_steps import *

# Steps para PDF
from .pdf_steps import *

# Steps de OCR
from .ocr_steps import *

# Steps de IA y Validación Semántica v1.3.0
from .genai_evaluation_steps import *
from .api_json_validation_steps import *
from .semantic_validation_steps import *
from .semantic_advanced_steps import *
from .semantic_nlp_steps import *

# Solo mostrar mensajes si está habilitado explícitamente
if os.getenv('HAKALAB_SHOW_STEPS') == 'true':
    print("✅ Hakalab Framework Steps cargados:")
    print("   📍 Navigation Steps - Navegación y URLs")
    print("   🖱️ Interaction Steps - Clicks, hover, fill")
    print("   ✅ Assertion Steps - Verificaciones y validaciones")
    print("   📜 Scroll Steps - Desplazamiento de página")
    print("   ⏱️ Wait Steps - Esperas y timeouts")
    print("   📊 Data Extraction Steps - Extracción de datos")
    print("   🔤 Variable Steps - Manejo de variables")
    print("   🪟 Window Steps - Manejo de ventanas y tabs")
    print("   🔧 Advanced Steps - JavaScript y screenshots")
    print("   🎯 Drag & Drop Steps - Arrastrar y soltar")
    print("   📋 Combobox Steps - Selects y dropdowns avanzados")
    print("   🖼️ iFrame Steps - Interacción con iframes")
    print("   💬 Modal Steps - Modales y diálogos")
    print("   📁 File Steps - Upload, download y verificación")
    print("   📊 Table Steps - Tablas avanzadas")
    print("   ⌨️ Keyboard/Mouse Steps - Interacciones avanzadas")
    print("   ☁️ Salesforce Steps - Automatización específica de Salesforce")
    print("   🌍 Environment Steps - Manejo de variables de entorno")
    print("   📊 CSV File Steps - Manejo y análisis de archivos CSV")
    print("   ⏱️ Timing Steps - Control de tiempos y esperas avanzadas")
    print("   ⌨️ Advanced Input Steps - Interacción avanzada con campos de entrada")
    print("   🔍 Validation Steps - Validaciones avanzadas de elementos")
    print("   ♿ Accessibility Steps - Testing de accesibilidad")
    print("   📋 Combobox Validation Steps - Validaciones específicas de combobox")
    print("   ⚡ Performance Steps - Medición de rendimiento")
    print("   📱 Responsive Steps - Testing responsive")
    print("   🎫 Jira/Xray Steps - Integración con Jira y Xray")
    print("   🌐 Web Elements Steps - Manipulación avanzada de elementos")
    print("   📝 Form Handling Steps - Manejo completo de formularios")
    print("   🌐 Browser Control Steps - Control del navegador")
    print("   🔧 Browser Advanced Config Steps - Configuración avanzada del navegador")
    print("   🔌 API Testing Steps - Testing de APIs REST")
    print("   🗄️ Database Steps - Testing de bases de datos")
    print("   📧 Email Steps - Testing de emails")
    print("   📄 PDF Steps - Validación de contenido de PDFs")
    print("   👁️ OCR Steps - Reconocimiento óptico de caracteres")
    print("   🤖 GenAI Evaluation Steps - Evaluación con Gemini como Juez")
    print("   🔍 API JSON Validation Steps - Validación avanzada de JSON")
    print("   🧠 Semantic Validation Steps - Validación semántica con IA")
    print("   🎯 Semantic Advanced Steps - Validación semántica avanzada")
    print("   📝 Semantic NLP Steps - Procesamiento de lenguaje natural")