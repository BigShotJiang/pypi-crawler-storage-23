#!/usr/bin/env python3
"""
Steps avanzados para validaciones de elementos web
Incluye validaciones de formato, patrones, estado y comportamiento
"""
import re
import time
from datetime import datetime
from behave import step


def _get_element(context, selector, dynamic_value=None):
    """
    Función auxiliar para obtener elementos.
    Soporta tanto selectores CSS como identificadores JSON ($.ARCHIVO.elemento)
    Soporta placeholders dinámicos: $.ARCHIVO.elemento=valor
    Soporta iframes: Si context.current_frame existe, busca dentro del iframe
    """
    # Determinar si estamos dentro de un iframe
    page_or_frame = getattr(context, 'current_frame', None) or context.page
    
    if selector.startswith('$.') and hasattr(context, 'element_locator'):
        return context.element_locator.find(page_or_frame, selector, dynamic_value)
    else:
        return page_or_frame.locator(selector)

from playwright.sync_api import expect

@step('I verify element "{element_name}" has CSS class "{css_class}" with identifier "{identifier}"')
@step('verifico que el elemento "{element_name}" tiene la clase CSS "{css_class}" con identificador "{identifier}"')
def step_verify_element_has_css_class(context, element_name, css_class, identifier):
    """Verifica que un elemento tiene una clase CSS específica"""
    locator = context.element_locator.get_locator(identifier)
    resolved_class = context.variable_manager.resolve_variables(css_class)
    
    element = context.page.locator(locator)
    class_attr = element.get_attribute('class') or ""
    
    assert resolved_class in class_attr.split(), f"Elemento no tiene la clase '{resolved_class}'. Clases actuales: {class_attr}"

@step('I verify element "{element_name}" does not have CSS class "{css_class}" with identifier "{identifier}"')
@step('verifico que el elemento "{element_name}" no tiene la clase CSS "{css_class}" con identificador "{identifier}"')
def step_verify_element_not_has_css_class(context, element_name, css_class, identifier):
    """Verifica que un elemento NO tiene una clase CSS específica"""
    locator = context.element_locator.get_locator(identifier)
    resolved_class = context.variable_manager.resolve_variables(css_class)
    
    element = context.page.locator(locator)
    class_attr = element.get_attribute('class') or ""
    
    assert resolved_class not in class_attr.split(), f"Elemento tiene la clase '{resolved_class}' cuando no debería"

@step('I verify element "{element_name}" has attribute "{attribute}" with value "{expected_value}" with identifier "{identifier}"')
@step('verifico que el elemento "{element_name}" tiene el atributo "{attribute}" con valor "{expected_value}" con identificador "{identifier}"')
def step_verify_element_attribute_value(context, element_name, attribute, expected_value, identifier):
    """Verifica que un elemento tiene un atributo con valor específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_value = context.variable_manager.resolve_variables(expected_value)
    
    element = context.page.locator(locator)
    actual_value = element.get_attribute(attribute)
    
    assert actual_value == resolved_value, f"Atributo '{attribute}' tiene valor '{actual_value}', esperado '{resolved_value}'"

@step('I verify element "{element_name}" attribute "{attribute}" matches pattern "{pattern}" with identifier "{identifier}"')
@step('verifico que el atributo "{attribute}" del elemento "{element_name}" coincide con el patrón "{pattern}" con identificador "{identifier}"')
def step_verify_element_attribute_pattern(context, element_name, attribute, pattern, identifier):
    """Verifica que un atributo de elemento coincide con un patrón regex"""
    locator = context.element_locator.get_locator(identifier)
    resolved_pattern = context.variable_manager.resolve_variables(pattern)
    
    element = context.page.locator(locator)
    actual_value = element.get_attribute(attribute) or ""
    
    assert re.match(resolved_pattern, actual_value), f"Atributo '{attribute}' con valor '{actual_value}' no coincide con patrón '{resolved_pattern}'"

@step('I verify element "{element_name}" text matches pattern "{pattern}" with identifier "{identifier}"')
@step('verifico que el texto del elemento "{element_name}" coincide con el patrón "{pattern}" con identificador "{identifier}"')
def step_verify_element_text_pattern(context, element_name, pattern, identifier):
    """Verifica que el texto de un elemento coincide con un patrón regex"""
    locator = context.element_locator.get_locator(identifier)
    resolved_pattern = context.variable_manager.resolve_variables(pattern)
    
    element = context.page.locator(locator)
    actual_text = element.text_content() or ""
    
    assert re.match(resolved_pattern, actual_text), f"Texto '{actual_text}' no coincide con patrón '{resolved_pattern}'"

@step('I verify element "{element_name}" text is valid email format with identifier "{identifier}"')
@step('verifico que el texto del elemento "{element_name}" tiene formato de email válido con identificador "{identifier}"')
def step_verify_element_text_email_format(context, element_name, identifier):
    """Verifica que el texto de un elemento tiene formato de email válido"""
    locator = context.element_locator.get_locator(identifier)
    
    element = context.page.locator(locator)
    actual_text = element.text_content() or ""
    
    email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    assert re.match(email_pattern, actual_text), f"Texto '{actual_text}' no tiene formato de email válido"

@step('I verify element "{element_name}" text is valid phone format with identifier "{identifier}"')
@step('verifico que el texto del elemento "{element_name}" tiene formato de teléfono válido con identificador "{identifier}"')
def step_verify_element_text_phone_format(context, element_name, identifier):
    """Verifica que el texto de un elemento tiene formato de teléfono válido"""
    locator = context.element_locator.get_locator(identifier)
    
    element = context.page.locator(locator)
    actual_text = element.text_content() or ""
    
    # Patrón flexible para teléfonos (permite varios formatos)
    phone_pattern = r'^[\+]?[1-9][\d]{0,15}$|^[\+]?[(]?[\d\s\-\(\)]{10,}$'
    assert re.search(phone_pattern, actual_text.replace(' ', '').replace('-', '').replace('(', '').replace(')', '')), f"Texto '{actual_text}' no tiene formato de teléfono válido"

@step('I verify element "{element_name}" text is valid date format "{date_format}" with identifier "{identifier}"')
@step('verifico que el texto del elemento "{element_name}" tiene formato de fecha válido "{date_format}" con identificador "{identifier}"')
def step_verify_element_text_date_format(context, element_name, date_format, identifier):
    """Verifica que el texto de un elemento tiene formato de fecha válido"""
    locator = context.element_locator.get_locator(identifier)
    resolved_format = context.variable_manager.resolve_variables(date_format)
    
    element = context.page.locator(locator)
    actual_text = element.text_content() or ""
    
    try:
        datetime.strptime(actual_text, resolved_format)
    except ValueError:
        raise AssertionError(f"Texto '{actual_text}' no tiene formato de fecha válido '{resolved_format}'")

@step('I verify element "{element_name}" text is numeric with identifier "{identifier}"')
@step('verifico que el texto del elemento "{element_name}" es numérico con identificador "{identifier}"')
def step_verify_element_text_numeric(context, element_name, identifier):
    """Verifica que el texto de un elemento es numérico"""
    locator = context.element_locator.get_locator(identifier)
    
    element = context.page.locator(locator)
    actual_text = element.text_content() or ""
    
    # Limpiar texto (remover espacios, comas, símbolos de moneda)
    clean_text = re.sub(r'[^\d.-]', '', actual_text)
    
    try:
        float(clean_text)
    except ValueError:
        raise AssertionError(f"Texto '{actual_text}' no es numérico")

@step('I verify element "{element_name}" text length is "{expected_length}" with identifier "{identifier}"')
@step('verifico que la longitud del texto del elemento "{element_name}" es "{expected_length}" con identificador "{identifier}"')
def step_verify_element_text_length(context, element_name, expected_length, identifier):
    """Verifica que el texto de un elemento tiene una longitud específica
    
    Funciona con elementos de texto normales, inputs y textareas.
    """
    locator = context.element_locator.get_locator(identifier)
    expected_len = int(expected_length)
    
    element = context.page.locator(locator)
    
    # Intentar obtener el valor como input/textarea primero
    try:
        actual_text = element.input_value() or ""
    except Exception:
        # Si falla, es un elemento de texto normal
        actual_text = element.text_content() or ""
    
    actual_len = len(actual_text)
    
    assert actual_len == expected_len, f"Longitud del texto es {actual_len}, esperado {expected_len}"

@step('I verify element "{element_name}" text length is between "{min_length}" and "{max_length}" with identifier "{identifier}"')
@step('verifico que la longitud del texto del elemento "{element_name}" está entre "{min_length}" y "{max_length}" con identificador "{identifier}"')
def step_verify_element_text_length_range(context, element_name, min_length, max_length, identifier):
    """Verifica que el texto de un elemento tiene una longitud dentro de un rango
    
    Funciona con elementos de texto normales, inputs y textareas.
    """
    locator = context.element_locator.get_locator(identifier)
    min_len = int(min_length)
    max_len = int(max_length)
    
    element = context.page.locator(locator)
    
    # Intentar obtener el valor como input/textarea primero
    try:
        actual_text = element.input_value() or ""
    except Exception:
        # Si falla, es un elemento de texto normal
        actual_text = element.text_content() or ""
    
    actual_len = len(actual_text)
    
    assert min_len <= actual_len <= max_len, f"Longitud del texto es {actual_len}, debe estar entre {min_len} y {max_len}"

@step('I verify element "{element_name}" is within viewport with identifier "{identifier}"')
@step('verifico que el elemento "{element_name}" está dentro del viewport con identificador "{identifier}"')
def step_verify_element_in_viewport(context, element_name, identifier):
    """Verifica que un elemento está visible dentro del viewport"""
    locator = context.element_locator.get_locator(identifier)
    
    element = context.page.locator(locator)
    expect(element).to_be_in_viewport()

@step('I verify element "{element_name}" has focus with identifier "{identifier}"')
@step('verifico que el elemento "{element_name}" tiene el foco con identificador "{identifier}"')
def step_verify_element_has_focus(context, element_name, identifier):
    """Verifica que un elemento tiene el foco"""
    locator = context.element_locator.get_locator(identifier)
    
    element = context.page.locator(locator)
    expect(element).to_be_focused()

@step('I verify element "{element_name}" background color is "{expected_color}" with identifier "{identifier}"')
@step('verifico que el color de fondo del elemento "{element_name}" es "{expected_color}" con identificador "{identifier}"')
def step_verify_element_background_color(context, element_name, expected_color, identifier):
    """Verifica que un elemento tiene un color de fondo específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_color = context.variable_manager.resolve_variables(expected_color)
    
    element = context.page.locator(locator)
    actual_color = element.evaluate("element => getComputedStyle(element).backgroundColor")
    
    # Normalizar colores (convertir rgb a hex si es necesario)
    if resolved_color.startswith('#'):
        # Convertir RGB a hex para comparar
        if actual_color.startswith('rgb'):
            rgb_values = re.findall(r'\d+', actual_color)
            if len(rgb_values) >= 3:
                hex_color = '#{:02x}{:02x}{:02x}'.format(int(rgb_values[0]), int(rgb_values[1]), int(rgb_values[2]))
                actual_color = hex_color
    
    assert actual_color.lower() == resolved_color.lower(), f"Color de fondo es '{actual_color}', esperado '{resolved_color}'"

@step('I verify element "{element_name}" text color is "{expected_color}" with identifier "{identifier}"')
@step('verifico que el color del texto del elemento "{element_name}" es "{expected_color}" con identificador "{identifier}"')
def step_verify_element_text_color(context, element_name, expected_color, identifier):
    """Verifica que un elemento tiene un color de texto específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_color = context.variable_manager.resolve_variables(expected_color)
    
    element = context.page.locator(locator)
    actual_color = element.evaluate("element => getComputedStyle(element).color")
    
    # Normalizar colores
    if resolved_color.startswith('#'):
        if actual_color.startswith('rgb'):
            rgb_values = re.findall(r'\d+', actual_color)
            if len(rgb_values) >= 3:
                hex_color = '#{:02x}{:02x}{:02x}'.format(int(rgb_values[0]), int(rgb_values[1]), int(rgb_values[2]))
                actual_color = hex_color
    
    assert actual_color.lower() == resolved_color.lower(), f"Color del texto es '{actual_color}', esperado '{resolved_color}'"

@step('I verify element "{element_name}" font size is "{expected_size}" with identifier "{identifier}"')
@step('verifico que el tamaño de fuente del elemento "{element_name}" es "{expected_size}" con identificador "{identifier}"')
def step_verify_element_font_size(context, element_name, expected_size, identifier):
    """Verifica que un elemento tiene un tamaño de fuente específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_size = context.variable_manager.resolve_variables(expected_size)
    
    element = context.page.locator(locator)
    actual_size = element.evaluate("element => getComputedStyle(element).fontSize")
    
    assert actual_size == resolved_size, f"Tamaño de fuente es '{actual_size}', esperado '{resolved_size}'"

@step('I verify element "{element_name}" width is "{expected_width}" pixels with identifier "{identifier}"')
@step('verifico que el ancho del elemento "{element_name}" es "{expected_width}" píxeles con identificador "{identifier}"')
def step_verify_element_width(context, element_name, expected_width, identifier):
    """Verifica que un elemento tiene un ancho específico"""
    locator = context.element_locator.get_locator(identifier)
    expected_w = int(expected_width)
    
    element = context.page.locator(locator)
    bounding_box = element.bounding_box()
    actual_width = int(bounding_box['width'])
    
    assert actual_width == expected_w, f"Ancho del elemento es {actual_width}px, esperado {expected_w}px"

@step('I verify element "{element_name}" height is "{expected_height}" pixels with identifier "{identifier}"')
@step('verifico que la altura del elemento "{element_name}" es "{expected_height}" píxeles con identificador "{identifier}"')
def step_verify_element_height(context, element_name, expected_height, identifier):
    """Verifica que un elemento tiene una altura específica"""
    locator = context.element_locator.get_locator(identifier)
    expected_h = int(expected_height)
    
    element = context.page.locator(locator)
    bounding_box = element.bounding_box()
    actual_height = int(bounding_box['height'])
    
    assert actual_height == expected_h, f"Altura del elemento es {actual_height}px, esperado {expected_h}px"

@step('I verify element "{element_name}" is positioned at x="{expected_x}" y="{expected_y}" with identifier "{identifier}"')
@step('verifico que el elemento "{element_name}" está posicionado en x="{expected_x}" y="{expected_y}" con identificador "{identifier}"')
def step_verify_element_position(context, element_name, expected_x, expected_y, identifier):
    """Verifica que un elemento está en una posición específica"""
    locator = context.element_locator.get_locator(identifier)
    expected_x_pos = int(expected_x)
    expected_y_pos = int(expected_y)
    
    element = context.page.locator(locator)
    bounding_box = element.bounding_box()
    actual_x = int(bounding_box['x'])
    actual_y = int(bounding_box['y'])
    
    tolerance = 5  # Tolerancia de 5 píxeles
    assert abs(actual_x - expected_x_pos) <= tolerance, f"Posición X es {actual_x}, esperado {expected_x_pos} (±{tolerance})"
    assert abs(actual_y - expected_y_pos) <= tolerance, f"Posición Y es {actual_y}, esperado {expected_y_pos} (±{tolerance})"


@step('I verify element "{element_name}" CSS property "{property}" is "{expected_value}" with identifier "{identifier}"')
@step('verifico que la propiedad CSS "{property}" del elemento "{element_name}" es "{expected_value}" con identificador "{identifier}"')
def step_verify_element_css_property(context, element_name, property, expected_value, identifier):
    """Verifica que un elemento tiene una propiedad CSS específica con un valor exacto
    
    Ejemplo:
        verifico que la propiedad CSS "color" del elemento "button" es "rgb(255, 255, 255)" con identificador "$.ELEMENTO.button"
    """
    locator = context.element_locator.get_locator(identifier)
    resolved_value = context.variable_manager.resolve_variables(expected_value)
    
    element = context.page.locator(locator)
    actual_value = element.evaluate(f"element => getComputedStyle(element).{property}")
    
    assert actual_value == resolved_value, f"Propiedad CSS '{property}' es '{actual_value}', esperado '{resolved_value}'"
    print(f"✓ Propiedad CSS '{property}' verificada: {actual_value}")

@step('I verify element "{element_name}" CSS property "{property}" contains "{expected_value}" with identifier "{identifier}"')
@step('verifico que la propiedad CSS "{property}" del elemento "{element_name}" contiene "{expected_value}" con identificador "{identifier}"')
def step_verify_element_css_property_contains(context, element_name, property, expected_value, identifier):
    """Verifica que una propiedad CSS de un elemento contiene un valor específico
    
    Ejemplo:
        verifico que la propiedad CSS "font-family" del elemento "text" contiene "Arial" con identificador "$.ELEMENTO.text"
    """
    locator = context.element_locator.get_locator(identifier)
    resolved_value = context.variable_manager.resolve_variables(expected_value)
    
    element = context.page.locator(locator)
    actual_value = element.evaluate(f"element => getComputedStyle(element).{property}")
    
    assert resolved_value in actual_value, f"Propiedad CSS '{property}' con valor '{actual_value}' no contiene '{resolved_value}'"
    print(f"✓ Propiedad CSS '{property}' contiene: {resolved_value}")

@step('I verify element "{element_name}" CSS property "{property}" does not exist with identifier "{identifier}"')
@step('verifico que la propiedad CSS "{property}" del elemento "{element_name}" no existe con identificador "{identifier}"')
def step_verify_element_css_property_not_exists(context, element_name, property, identifier):
    """Verifica que un elemento NO tiene una propiedad CSS específica
    
    Ejemplo:
        verifico que la propiedad CSS "custom-prop" del elemento "div" no existe con identificador "$.ELEMENTO.div"
    """
    locator = context.element_locator.get_locator(identifier)
    
    element = context.page.locator(locator)
    
    # Obtener el atributo style directo (no computed)
    style_attr = element.get_attribute('style') or ""
    
    assert property not in style_attr, f"Propiedad CSS '{property}' existe en el elemento cuando no debería"
    print(f"✓ Propiedad CSS '{property}' no existe en el elemento")

@step('I store CSS property "{property}" of element "{element_name}" in variable "{variable_name}" with identifier "{identifier}"')
@step('guardo en la variable "{variable_name}" el valor de la propiedad CSS "{property}" del elemento "{element_name}" con identificador "{identifier}"')
def step_store_element_css_property(context, variable_name, property, element_name, identifier):
    """Guarda el valor de una propiedad CSS en una variable
    
    Ejemplo:
        guardo en la variable "color_boton" el valor de la propiedad CSS "color" del elemento "button" con identificador "$.ELEMENTO.button"
    """
    locator = context.element_locator.get_locator(identifier)
    
    element = context.page.locator(locator)
    css_value = element.evaluate(f"element => getComputedStyle(element).{property}")
    
    # Guardar en variable
    context.variable_manager.set_variable(variable_name, css_value)
    
    print(f"✓ Propiedad CSS '{property}' guardada en variable '{variable_name}': {css_value}")

@step('I verify element "{element_name}" CSS property "{property}" matches pattern "{pattern}" with identifier "{identifier}"')
@step('verifico que la propiedad CSS "{property}" del elemento "{element_name}" coincide con el patrón "{pattern}" con identificador "{identifier}"')
def step_verify_element_css_property_pattern(context, element_name, property, pattern, identifier):
    """Verifica que una propiedad CSS de un elemento coincide con un patrón regex
    
    Ejemplo:
        verifico que la propiedad CSS "background-color" del elemento "div" coincide con el patrón "rgb\\(\\d+,\\s*\\d+,\\s*\\d+\\)" con identificador "$.ELEMENTO.div"
    """
    locator = context.element_locator.get_locator(identifier)
    resolved_pattern = context.variable_manager.resolve_variables(pattern)
    
    element = context.page.locator(locator)
    actual_value = element.evaluate(f"element => getComputedStyle(element).{property}")
    
    assert re.match(resolved_pattern, actual_value), f"Propiedad CSS '{property}' con valor '{actual_value}' no coincide con patrón '{resolved_pattern}'"
    print(f"✓ Propiedad CSS '{property}' coincide con patrón: {resolved_pattern}")


@step('I verify element "{element_name}" has CSS property "{property}" with identifier "{identifier}"')
@step('verifico que el elemento "{element_name}" tiene la propiedad CSS "{property}" con identificador "{identifier}"')
def step_verify_element_has_css_property(context, element_name, property, identifier):
    """Verifica que un elemento tiene una propiedad CSS específica (sin importar el valor)
    
    Ejemplo:
        verifico que el elemento "button" tiene la propiedad CSS "color" con identificador "$.ELEMENTO.button"
    """
    locator = context.element_locator.get_locator(identifier)
    
    element = context.page.locator(locator)
    
    # Obtener el atributo style directo
    style_attr = element.get_attribute('style') or ""
    
    # También verificar en computed styles
    computed_value = element.evaluate(f"element => getComputedStyle(element).{property}")
    
    # La propiedad existe si está en el style directo o tiene un valor computed
    has_property = property in style_attr or (computed_value and computed_value != "")
    
    assert has_property, f"Elemento no tiene la propiedad CSS '{property}'"
    print(f"✓ Elemento tiene la propiedad CSS '{property}'")

@step('I verify element "{element_name}" does not have CSS property "{property}" with identifier "{identifier}"')
@step('verifico que el elemento "{element_name}" no tiene la propiedad CSS "{property}" con identificador "{identifier}"')
def step_verify_element_not_has_css_property(context, element_name, property, identifier):
    """Verifica que un elemento NO tiene una propiedad CSS específica
    
    Ejemplo:
        verifico que el elemento "div" no tiene la propiedad CSS "display" con identificador "$.ELEMENTO.div"
    """
    locator = context.element_locator.get_locator(identifier)
    
    element = context.page.locator(locator)
    
    # Obtener el atributo style directo
    style_attr = element.get_attribute('style') or ""
    
    # Verificar que la propiedad NO está en el style directo
    has_property = property in style_attr
    
    assert not has_property, f"Elemento tiene la propiedad CSS '{property}' cuando no debería"
    print(f"✓ Elemento no tiene la propiedad CSS '{property}'")
