"""
Steps para testing de bases de datos - Versión mejorada
Incluye conexiones, consultas SQL, validaciones y manipulación de datos
Soporta SQLite, MySQL y PostgreSQL con configuración desde .env
"""

from behave import step
import json
import os
from hakalab_framework.core.database_manager import DatabaseManager

@step('I connect to database "{db_name}"')
@step('me conecto a la base de datos "{db_name}"')
def step_connect_database(context, db_name):
    """Conecta a una base de datos usando configuración del .env o nombre específico"""
    if not hasattr(context, 'db_manager'):
        context.db_manager = DatabaseManager()
    
    resolved_name = context.variable_manager.resolve_variables(db_name)
    
    # Si es un archivo SQLite, conectar directamente
    if resolved_name.endswith('.db') or resolved_name.endswith('.sqlite'):
        success = context.db_manager.connect_sqlite(resolved_name)
    else:
        # Usar configuración del .env
        success = context.db_manager.connect_from_env(resolved_name)
    
    if success:
        print(f"✓ Conectado a base de datos: {resolved_name}")
    else:
        raise Exception(f"No se pudo conectar a la base de datos: {resolved_name}")

@step('I connect to SQLite database "{db_path}"')
@step('me conecto a la base de datos SQLite "{db_path}"')
def step_connect_sqlite_database(context, db_path):
    """Conecta a una base de datos SQLite específica"""
    if not hasattr(context, 'db_manager'):
        context.db_manager = DatabaseManager()
    
    resolved_path = context.variable_manager.resolve_variables(db_path)
    
    success = context.db_manager.connect_sqlite(resolved_path)
    if success:
        print(f"✓ Conectado a base de datos SQLite: {resolved_path}")
    else:
        raise Exception(f"No se pudo conectar a SQLite: {resolved_path}")

@step('I connect to database using environment configuration')
@step('me conecto a la base de datos usando configuración del entorno')
def step_connect_database_from_env(context):
    """Conecta a la base de datos usando la configuración del archivo .env"""
    if not hasattr(context, 'db_manager'):
        context.db_manager = DatabaseManager()
    
    success = context.db_manager.connect_from_env()
    if success:
        db_type = os.getenv('DB_TYPE', 'sqlite')
        print(f"✓ Conectado a base de datos {db_type} usando configuración del entorno")
    else:
        raise Exception("No se pudo conectar usando configuración del entorno")

@step('I create test database with sample data')
@step('creo base de datos de prueba con datos de ejemplo')
def step_create_test_database(context):
    """Crea una base de datos de prueba con datos de ejemplo"""
    if not hasattr(context, 'db_manager') or not context.db_manager.connection:
        raise AssertionError("No hay conexión a base de datos disponible")
    
    context.db_manager.create_test_database()
    print("✓ Base de datos de prueba creada con datos de ejemplo")

@step('I execute SQL query "{query}" and store result in variable "{variable_name}"')
@step('ejecuto la consulta SQL "{query}" y guardo el resultado en la variable "{variable_name}"')
def step_execute_sql_query(context, query, variable_name):
    """Ejecuta una consulta SQL y guarda el resultado"""
    if not hasattr(context, 'db_manager') or not context.db_manager.connection:
        raise AssertionError("No hay conexión a base de datos disponible")
    
    resolved_query = context.variable_manager.resolve_variables(query)
    
    try:
        results = context.db_manager.execute_query(resolved_query)
        
        context.variable_manager.set_variable(variable_name, json.dumps(results))
        context.last_db_results = results
        
        print(f"✓ Consulta SQL ejecutada: {len(results)} filas obtenidas")
        
    except Exception as e:
        print(f"✗ Error ejecutando consulta SQL: {e}")
        raise

@step('I execute SQL update "{query}"')
@step('ejecuto la actualización SQL "{query}"')
def step_execute_sql_update(context, query):
    """Ejecuta una consulta SQL de actualización (INSERT, UPDATE, DELETE)"""
    if not hasattr(context, 'db_manager') or not context.db_manager.connection:
        raise AssertionError("No hay conexión a base de datos disponible")
    
    resolved_query = context.variable_manager.resolve_variables(query)
    
    try:
        rows_affected = context.db_manager.execute_update(resolved_query)
        print(f"✓ Consulta SQL de actualización ejecutada: {rows_affected} filas afectadas")
        
    except Exception as e:
        print(f"✗ Error ejecutando actualización SQL: {e}")
        raise

@step('I verify SQL query result has "{expected_count}" rows')
@step('verifico que el resultado de la consulta SQL tiene "{expected_count}" filas')
def step_verify_sql_result_count(context, expected_count):
    """Verifica el número de filas en el último resultado SQL"""
    if not hasattr(context, 'last_db_results'):
        raise AssertionError("No hay resultados de consulta SQL disponibles")
    
    actual_count = len(context.last_db_results)
    expected_count_int = int(expected_count)
    
    if actual_count == expected_count_int:
        print(f"✓ Número de filas correcto: {actual_count}")
    else:
        print(f"✗ Número de filas incorrecto. Esperado: {expected_count_int}, Actual: {actual_count}")
        raise AssertionError(f"Número de filas incorrecto. Esperado: {expected_count_int}, Actual: {actual_count}")

@step('I verify SQL result contains row with "{column}" equal to "{expected_value}"')
@step('verifico que el resultado SQL contiene una fila con "{column}" igual a "{expected_value}"')
def step_verify_sql_result_contains(context, column, expected_value):
    """Verifica que el resultado SQL contiene una fila con un valor específico"""
    if not hasattr(context, 'last_db_results'):
        raise AssertionError("No hay resultados de consulta SQL disponibles")
    
    resolved_expected = context.variable_manager.resolve_variables(expected_value)
    
    found = False
    for row in context.last_db_results:
        if column in row and str(row[column]) == str(resolved_expected):
            found = True
            break
    
    if found:
        print(f"✓ Fila encontrada con {column} = '{resolved_expected}'")
    else:
        print(f"✗ No se encontró fila con {column} = '{resolved_expected}'")
        raise AssertionError(f"No se encontró fila con {column} = '{resolved_expected}'")

@step('I get SQL result value from column "{column}" row "{row_index}" and store in variable "{variable_name}"')
@step('obtengo el valor del resultado SQL de la columna "{column}" fila "{row_index}" y lo guardo en la variable "{variable_name}"')
def step_get_sql_result_value(context, column, row_index, variable_name):
    """Obtiene un valor específico del resultado SQL"""
    if not hasattr(context, 'last_db_results'):
        raise AssertionError("No hay resultados de consulta SQL disponibles")
    
    row_idx = int(row_index)
    
    if row_idx >= len(context.last_db_results):
        raise AssertionError(f"Índice de fila {row_idx} fuera de rango (total: {len(context.last_db_results)})")
    
    row = context.last_db_results[row_idx]
    
    if column not in row:
        raise AssertionError(f"Columna '{column}' no encontrada en el resultado")
    
    value = str(row[column])
    context.variable_manager.set_variable(variable_name, value)
    
    print(f"✓ Valor obtenido de {column}[{row_idx}]: '{value}' guardado en variable '{variable_name}'")

@step('I create table "{table_name}" with columns "{columns_definition}"')
@step('creo la tabla "{table_name}" con columnas "{columns_definition}"')
def step_create_table(context, table_name, columns_definition):
    """Crea una tabla con la definición de columnas especificada"""
    if not hasattr(context, 'db_cursor'):
        raise AssertionError("No hay conexión a base de datos disponible")
    
    resolved_columns = context.variable_manager.resolve_variables(columns_definition)
    
    query = f"CREATE TABLE IF NOT EXISTS {table_name} ({resolved_columns})"
    
    try:
        context.db_cursor.execute(query)
        context.db_connection.commit()
        
        print(f"✓ Tabla '{table_name}' creada con columnas: {resolved_columns}")
        
    except Exception as e:
        print(f"✗ Error creando tabla: {e}")
        raise

@step('I insert test data into table "{table_name}" with values "{values}"')
@step('inserto datos de prueba en la tabla "{table_name}" con valores "{values}"')
def step_insert_test_data(context, table_name, values):
    """Inserta datos de prueba en una tabla"""
    if not hasattr(context, 'db_cursor'):
        raise AssertionError("No hay conexión a base de datos disponible")
    
    resolved_values = context.variable_manager.resolve_variables(values)
    
    # Asumir que los valores están en formato JSON
    try:
        values_data = json.loads(resolved_values)
        
        if isinstance(values_data, list):
            # Múltiples filas
            for row_data in values_data:
                columns = ', '.join(row_data.keys())
                placeholders = ', '.join(['?' for _ in row_data.values()])
                query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
                
                context.db_cursor.execute(query, list(row_data.values()))
        else:
            # Una sola fila
            columns = ', '.join(values_data.keys())
            placeholders = ', '.join(['?' for _ in values_data.values()])
            query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
            
            context.db_cursor.execute(query, list(values_data.values()))
        
        context.db_connection.commit()
        print(f"✓ Datos de prueba insertados en tabla '{table_name}'")
        
    except Exception as e:
        print(f"✗ Error insertando datos de prueba: {e}")
        raise

@step('I drop table "{table_name}"')
@step('elimino la tabla "{table_name}"')
def step_drop_table(context, table_name):
    """Elimina una tabla"""
    if not hasattr(context, 'db_cursor'):
        raise AssertionError("No hay conexión a base de datos disponible")
    
    try:
        context.db_cursor.execute(f"DROP TABLE IF EXISTS {table_name}")
        context.db_connection.commit()
        
        print(f"✓ Tabla '{table_name}' eliminada")
        
    except Exception as e:
        print(f"✗ Error eliminando tabla: {e}")
        raise

@step('I close database connection')
@step('cierro la conexión a la base de datos')
def step_close_database_connection(context):
    """Cierra la conexión a la base de datos"""
    if hasattr(context, 'db_manager') and context.db_manager.connection:
        context.db_manager.close()
        print("✓ Conexión a base de datos cerrada")
    else:
        print("⚠ No hay conexión a base de datos para cerrar")

@step('I backup database to file "{backup_file}"')
@step('hago backup de la base de datos al archivo "{backup_file}"')
def step_backup_database(context, backup_file):
    """Hace backup de la base de datos"""
    if not hasattr(context, 'db_manager') or not context.db_manager.connection:
        raise AssertionError("No hay conexión a base de datos disponible")
    
    resolved_file = context.variable_manager.resolve_variables(backup_file)
    
    try:
        context.db_manager.backup_database(resolved_file)
        print(f"✓ Backup de base de datos guardado en '{resolved_file}'")
        
    except Exception as e:
        print(f"✗ Error haciendo backup: {e}")
        raise