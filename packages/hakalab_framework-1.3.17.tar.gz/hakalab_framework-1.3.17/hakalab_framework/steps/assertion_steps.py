from behave import step
import os


def _get_element(context, selector, dynamic_value=None):
    """
    Función auxiliar para obtener elementos.
    Soporta tanto selectores CSS como identificadores JSON ($.ARCHIVO.elemento)
    Soporta placeholders dinámicos: $.ARCHIVO.elemento=valor
    Soporta iframes: Si context.current_frame existe, busca dentro del iframe
    """
    # Determinar si estamos dentro de un iframe
    page_or_frame = getattr(context, 'current_frame', None) or context.page
    
    if selector.startswith('$.') and hasattr(context, 'element_locator'):
        return context.element_locator.find(page_or_frame, selector, dynamic_value)
    else:
        return page_or_frame.locator(selector)

from playwright.sync_api import expect

# Timeout configurable para assertions (en milisegundos)
# En modo headless, las páginas pueden tardar más en cargar
def _get_assertion_timeout():
    """Obtiene el timeout para assertions desde variable de entorno o usa 30s por defecto"""
    return int(os.getenv('ASSERTION_TIMEOUT', '30000'))

@step('I should see text "{text}"')
@step('debería ver el texto "{text}"')
@step('que debería ver el texto "{text}"')
def step_should_see_text(context, text):
    """Verifica que un texto sea visible en la página (búsqueda exacta)"""
    resolved_text = context.variable_manager.resolve_variables(text)
    page_or_frame = getattr(context, 'current_frame', None) or context.page
    timeout = _get_assertion_timeout()
    expect(page_or_frame.locator(f'text="{resolved_text}"')).to_be_visible(timeout=timeout)

@step('I should see text containing "{text}"')
@step('debería ver el texto que contiene "{text}"')
@step('que debería ver el texto que contiene "{text}"')
def step_should_see_text_containing(context, text):
    """Verifica que un texto parcial sea visible en la página (búsqueda parcial)"""
    resolved_text = context.variable_manager.resolve_variables(text)
    page_or_frame = getattr(context, 'current_frame', None) or context.page
    timeout = _get_assertion_timeout()
    
    # Escapar comillas simples y dobles correctamente para XPath
    # Si contiene ambas, usar concat()
    if "'" in resolved_text and '"' in resolved_text:
        # Dividir por comillas simples y usar concat
        parts = resolved_text.split("'")
        xpath_parts = [f"'{part}'" if part else "\"'\"" for part in parts]
        xpath_text = "concat(" + ", \"'\", ".join(xpath_parts) + ")"
        xpath = f"//*[contains(text(), {xpath_text})]"
    elif "'" in resolved_text:
        # Usar comillas dobles
        xpath = f'//*[contains(text(), "{resolved_text}")]'
    else:
        # Usar comillas simples (más seguro)
        xpath = f"//*[contains(text(), '{resolved_text}')]"
    
    expect(page_or_frame.locator(xpath)).to_be_visible(timeout=timeout)

@step('debería ver en la página el texto {text_with_variable}')
@step('que debería ver en la página el texto {text_with_variable}')
def step_should_see_text_containing_variable(context, text_with_variable):
    """Verifica que un texto parcial sea visible (soporta variables sin comillas)
    
    Permite usar variables sin necesidad de comillas:
    - debería ver en la página el texto ${variable_name}
    - debería ver en la página el texto ${porcentaje}
    
    Ejemplos:
        extraigo el valor de la respuesta interceptada de la API "disponibilidad" en la ruta "data.resumen.porcentaje_disponibilidad" y lo guardo en la variable "porcentaje"
        debería ver en la página el texto ${porcentaje}
    """
    # Resolver la variable
    resolved_text = context.variable_manager.resolve_variables(text_with_variable)
    page_or_frame = getattr(context, 'current_frame', None) or context.page
    timeout = _get_assertion_timeout()
    
    # Escapar comillas simples y dobles correctamente para XPath
    if "'" in resolved_text and '"' in resolved_text:
        parts = resolved_text.split("'")
        xpath_parts = [f"'{part}'" if part else "\"'\"" for part in parts]
        xpath_text = "concat(" + ", \"'\", ".join(xpath_parts) + ")"
        xpath = f"//*[contains(text(), {xpath_text})]"
    elif "'" in resolved_text:
        xpath = f'//*[contains(text(), "{resolved_text}")]'
    else:
        xpath = f"//*[contains(text(), '{resolved_text}')]"
    
    expect(page_or_frame.locator(xpath)).to_be_visible(timeout=timeout)
    print(f"✓ Se encontró el texto: '{resolved_text}'")

@step('I should not see text "{text}"')
@step('no debería ver el texto "{text}"')
@step('que no debería ver el texto "{text}"')
def step_should_not_see_text(context, text):
    """Verifica que un texto no sea visible en la página"""
    resolved_text = context.variable_manager.resolve_variables(text)
    page_or_frame = getattr(context, 'current_frame', None) or context.page
    timeout = _get_assertion_timeout()
    expect(page_or_frame.locator(f'text="{resolved_text}"')).not_to_be_visible(timeout=timeout)

@step('the page title should be "{title}"')
@step('el título de la página debería ser "{title}"')
@step('que el título de la página debería ser "{title}"')
def step_page_title_should_be(context, title):
    """Verifica que el título de la página sea exacto"""
    resolved_title = context.variable_manager.resolve_variables(title)
    timeout = _get_assertion_timeout()
    expect(context.page).to_have_title(resolved_title, timeout=timeout)

@step('the page title should contain "{text}"')
@step('el título de la página debería contener "{text}"')
@step('que el título de la página debería contener "{text}"')
def step_page_title_should_contain(context, text):
    """Verifica que el título de la página contenga un texto"""
    resolved_text = context.variable_manager.resolve_variables(text)
    timeout = _get_assertion_timeout()
    expect(context.page).to_have_title(f".*{resolved_text}.*", timeout=timeout)

@step('the element "{element_name}" should exist with identifier "{identifier}" and value "{value}"')
@step('el elemento "{element_name}" debería existir con identificador "{identifier}" y valor "{value}"')
@step('que el elemento "{element_name}" debería existir con identificador "{identifier}" y valor "{value}"')
def step_element_should_exist_with_value(context, element_name, identifier, value):
    """Verifica que un elemento existe en el DOM usando un localizador dinámico
    
    Soporta localizadores dinámicos con placeholders que se reemplazan con el valor.
    
    Ejemplos:
    - el elemento "Fila" debería existir con identificador "$.TABLE.row" y valor "1"
    - el elemento "Item" debería existir con identificador "$.LIST.item" y valor "producto_123"
    - el elemento "Botón" debería existir con identificador "$.BUTTONS.action" y valor "delete"
    """
    # Resolver variables en el valor
    resolved_value = context.variable_manager.resolve_variables(value) if hasattr(context, 'variable_manager') else value
    
    # Obtener el localizador con el valor dinámico
    locator = context.element_locator.get_locator(identifier, resolved_value)
    
    # Verificar que el elemento existe en el DOM (attached)
    try:
        context.page.locator(locator).wait_for(state='attached', timeout=5000)
        print(f"✓ El elemento '{element_name}' existe con identificador '{identifier}' y valor '{resolved_value}'")
    except:
        raise AssertionError(f"❌ El elemento '{element_name}' no existe con identificador '{identifier}' y valor '{resolved_value}'")

@step('the element "{element_name}" should exist in identifier "{identifier}"')
@step('el elemento "{element_name}" debería existir en identificador "{identifier}"')
@step('que el elemento "{element_name}" debería existir en identificador "{identifier}"')
def step_element_should_exist(context, element_name, identifier):
    """Verifica que un elemento existe en el DOM (sin importar si es visible)
    
    Soporta localizadores dinámicos con placeholders:
    - $.ARCHIVO.elemento
    - $.ARCHIVO.elemento=valor (con placeholder)
    
    Ejemplos:
    - el elemento "Usuario" debería existir con identificador "$.SELECTORS.user_element"
    - el elemento "Fila" debería existir con identificador "$.TABLE.row=1"
    """
    locator = context.element_locator.get_locator(identifier)
    
    # Verificar que el elemento existe en el DOM (attached)
    try:
        context.page.locator(locator).wait_for(state='attached', timeout=5000)
        print(f"✓ El elemento '{element_name}' existe con identificador '{identifier}'")
    except:
        raise AssertionError(f"❌ El elemento '{element_name}' no existe con identificador '{identifier}'")

@step('the element "{element_name}" should not exist with identifier "{identifier}" and value "{value}"')
@step('el elemento "{element_name}" no debería existir con identificador "{identifier}" y valor "{value}"')
@step('que el elemento "{element_name}" no debería existir con identificador "{identifier}" y valor "{value}"')
def step_element_should_not_exist_with_value(context, element_name, identifier, value):
    """Verifica que un elemento NO existe en el DOM usando un localizador dinámico
    
    Soporta localizadores dinámicos con placeholders que se reemplazan con el valor.
    
    Ejemplos:
    - el elemento "Error" no debería existir con identificador "$.FORM.error" y valor "email"
    - el elemento "Fila" no debería existir con identificador "$.TABLE.row" y valor "999"
    - el elemento "Item" no debería existir con identificador "$.LIST.item" y valor "deleted_123"
    """
    # Resolver variables en el valor
    resolved_value = context.variable_manager.resolve_variables(value) if hasattr(context, 'variable_manager') else value
    
    # Obtener el localizador con el valor dinámico
    locator = context.element_locator.get_locator(identifier, resolved_value)
    
    # Verificar que el elemento NO existe en el DOM
    try:
        context.page.locator(locator).wait_for(state='attached', timeout=2000)
        raise AssertionError(f"❌ El elemento '{element_name}' existe pero no debería con identificador '{identifier}' y valor '{resolved_value}'")
    except:
        print(f"✓ El elemento '{element_name}' no existe con identificador '{identifier}' y valor '{resolved_value}'")

@step('the element "{element_name}" should not exist in identifier "{identifier}"')
@step('el elemento "{element_name}" no debería existir en identificador "{identifier}"')
@step('que el elemento "{element_name}" no debería existir en identificador "{identifier}"')
def step_element_should_not_exist(context, element_name, identifier):
    """Verifica que un elemento NO existe en el DOM
    
    Soporta localizadores dinámicos con placeholders:
    - $.ARCHIVO.elemento
    - $.ARCHIVO.elemento=valor (con placeholder)
    
    Ejemplos:
    - el elemento "Error" no debería existir con identificador "$.SELECTORS.error_message"
    - el elemento "Fila" no debería existir con identificador "$.TABLE.row=999"
    """
    locator = context.element_locator.get_locator(identifier)
    
    # Verificar que el elemento NO existe en el DOM
    try:
        context.page.locator(locator).wait_for(state='attached', timeout=2000)
        raise AssertionError(f"❌ El elemento '{element_name}' existe pero no debería con identificador '{identifier}'")
    except:
        print(f"✓ El elemento '{element_name}' no existe con identificador '{identifier}'")

@step('I should see the element "{element_name}" with identifier "{identifier}"')
@step('debería ver el elemento "{element_name}" con identificador "{identifier}"')
@step('que debería ver el elemento "{element_name}" con identificador "{identifier}"')
def step_should_see_element(context, element_name, identifier):
    """Verifica que un elemento sea visible
    
    Soporta variables en el identificador usando ${variable_name}
    
    Ejemplos:
        debería ver el elemento "Nombre" con identificador "$.KIBERPRO_SOLICITUD.modal_acept_empl=${empleado}"
        debería ver el elemento "Botón" con identificador "$.SEARCH.result_by_text=Hola"
    """
    # Resolver variables en el identificador (soporta ${variable_name})
    resolved_identifier = context.variable_manager.resolve_variables(identifier)
    locator = context.element_locator.get_locator(resolved_identifier)
    expect(context.page.locator(locator)).to_be_visible()

@step('I should not see the element "{element_name}" with identifier "{identifier}"')
@step('no debería ver el elemento "{element_name}" con identificador "{identifier}"')
@step('que no debería ver el elemento "{element_name}" con identificador "{identifier}"')
def step_should_not_see_element(context, element_name, identifier):
    """Verifica que un elemento no sea visible
    
    Soporta variables en el identificador usando ${variable_name}
    """
    # Resolver variables en el identificador
    resolved_identifier = context.variable_manager.resolve_variables(identifier)
    locator = context.element_locator.get_locator(resolved_identifier)
    expect(context.page.locator(locator)).not_to_be_visible()

@step('the element "{element_name}" should contain the text "{text}" with identifier "{identifier}"')
@step('el elemento "{element_name}" debería contener el texto "{text}" con identificador "{identifier}"')
@step('que el elemento "{element_name}" debería contener el texto "{text}" con identificador "{identifier}"')
def step_element_should_contain_text(context, element_name, text, identifier):
    """Verifica que un elemento contenga un texto específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_text = context.variable_manager.resolve_variables(text)
    expect(context.page.locator(locator)).to_contain_text(resolved_text)

@step('the element "{element_name}" should have the exact text "{text}" with identifier "{identifier}"')
@step('el elemento "{element_name}" debería tener el texto exacto "{text}" con identificador "{identifier}"')
@step('que el elemento "{element_name}" debería tener el texto exacto "{text}" con identificador "{identifier}"')
def step_element_should_have_text(context, element_name, text, identifier):
    """Verifica que un elemento tenga un texto exacto"""
    locator = context.element_locator.get_locator(identifier)
    resolved_text = context.variable_manager.resolve_variables(text)
    expect(context.page.locator(locator)).to_have_text(resolved_text)

@step('the field "{field_name}" should have the value "{value}" with identifier "{identifier}"')
@step('el campo "{field_name}" debería tener el valor "{value}" con identificador "{identifier}"')
@step('que el campo "{field_name}" debería tener el valor "{value}" con identificador "{identifier}"')
def step_field_should_have_value(context, field_name, value, identifier):
    """Verifica que un campo tenga un valor específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_value = context.variable_manager.resolve_variables(value)
    expect(context.page.locator(locator)).to_have_value(resolved_value)

@step('the field "{field_name}" should not have the value "{value}" with identifier "{identifier}"')
@step('el campo "{field_name}" no debería tener el valor "{value}" con identificador "{identifier}"')
@step('que el campo "{field_name}" no debería tener el valor "{value}" con identificador "{identifier}"')
def step_field_should_not_have_value(context, field_name, value, identifier):
    """Verifica que un campo NO tenga un valor específico
    
    Ejemplos:
    - el campo "Email" no debería tener el valor "test@example.com" con identificador "$.SELECTORS.email_input"
    - el campo "Nombre" no debería tener el valor "Juan" con identificador "$.SELECTORS.name_input"
    """
    locator = context.element_locator.get_locator(identifier)
    resolved_value = context.variable_manager.resolve_variables(value)
    element = context.page.locator(locator)
    
    # Obtener el valor actual
    current_value = element.input_value()
    
    assert current_value != resolved_value, f"❌ El campo '{field_name}' tiene el valor '{resolved_value}' pero no debería tenerlo"
    print(f"✓ El campo '{field_name}' NO tiene el valor '{resolved_value}' (valor actual: '{current_value}')")

@step('the field "{field_name}" should be empty with identifier "{identifier}"')
@step('el campo "{field_name}" debería estar vacío con identificador "{identifier}"')
@step('que el campo "{field_name}" debería estar vacío con identificador "{identifier}"')
def step_field_should_be_empty(context, field_name, identifier):
    """Verifica que un campo esté vacío (sin valor)
    
    Ejemplos:
    - el campo "Email" debería estar vacío con identificador "$.SELECTORS.email_input"
    - el campo "Nombre" debería estar vacío con identificador "$.SELECTORS.name_input"
    """
    locator = context.element_locator.get_locator(identifier)
    expect(context.page.locator(locator)).to_have_value("")
    print(f"✓ El campo '{field_name}' está vacío")

@step('the field "{field_name}" should not be empty with identifier "{identifier}"')
@step('el campo "{field_name}" no debería estar vacío con identificador "{identifier}"')
@step('que el campo "{field_name}" no debería estar vacío con identificador "{identifier}"')
def step_field_should_not_be_empty(context, field_name, identifier):
    """Verifica que un campo NO esté vacío (tiene algún valor)
    
    Ejemplos:
    - el campo "Email" no debería estar vacío con identificador "$.SELECTORS.email_input"
    - el campo "Nombre" no debería estar vacío con identificador "$.SELECTORS.name_input"
    """
    locator = context.element_locator.get_locator(identifier)
    element = context.page.locator(locator)
    
    # Obtener el valor actual
    current_value = element.input_value()
    
    assert current_value != "", f"❌ El campo '{field_name}' está vacío pero no debería estarlo"
    print(f"✓ El campo '{field_name}' tiene valor: '{current_value}'")

@step('the element "{element_name}" should be enabled with identifier "{identifier}"')
@step('el elemento "{element_name}" debería estar habilitado con identificador "{identifier}"')
@step('que el elemento "{element_name}" debería estar habilitado con identificador "{identifier}"')
def step_element_should_be_enabled(context, element_name, identifier):
    """Verifica que un elemento esté habilitado"""
    locator = context.element_locator.get_locator(identifier)
    expect(context.page.locator(locator)).to_be_enabled()

@step('the element "{element_name}" should be disabled with identifier "{identifier}"')
@step('el elemento "{element_name}" debería estar deshabilitado con identificador "{identifier}"')
@step('que el elemento "{element_name}" debería estar deshabilitado con identificador "{identifier}"')
def step_element_should_be_disabled(context, element_name, identifier):
    """Verifica que un elemento esté deshabilitado"""
    locator = context.element_locator.get_locator(identifier)
    expect(context.page.locator(locator)).to_be_disabled()

@step('the checkbox "{checkbox_name}" should be checked with identifier "{identifier}"')
@step('el checkbox "{checkbox_name}" debería estar marcado con identificador "{identifier}"')
@step('que el checkbox "{checkbox_name}" debería estar marcado con identificador "{identifier}"')
def step_checkbox_should_be_checked(context, checkbox_name, identifier):
    """Verifica que un checkbox esté marcado"""
    locator = context.element_locator.get_locator(identifier)
    expect(context.page.locator(locator)).to_be_checked()

@step('the checkbox "{checkbox_name}" should not be checked with identifier "{identifier}"')
@step('el checkbox "{checkbox_name}" no debería estar marcado con identificador "{identifier}"')
@step('que el checkbox "{checkbox_name}" no debería estar marcado con identificador "{identifier}"')
def step_checkbox_should_not_be_checked(context, checkbox_name, identifier):
    """Verifica que un checkbox no esté marcado"""
    locator = context.element_locator.get_locator(identifier)
    expect(context.page.locator(locator)).not_to_be_checked()

@step('the current url should be "{url}"')
@step('la url actual debería ser "{url}"')
@step('que la url actual debería ser "{url}"')
def step_current_url_should_be(context, url):
    """Verifica la URL actual"""
    resolved_url = context.variable_manager.resolve_variables(url)
    expect(context.page).to_have_url(resolved_url)

@step('the current url should contain "{url_part}"')
@step('la url actual debería contener "{url_part}"')
@step('que la url actual debería contener "{url_part}"')
def step_current_url_should_contain(context, url_part):
    """Verifica que la URL actual contenga una parte específica"""
    resolved_url_part = context.variable_manager.resolve_variables(url_part)
    current_url = context.page.url
    assert resolved_url_part in current_url, f"La URL actual '{current_url}' no es correcta"


@step('a new window should have opened with url containing "{url_part}"')
@step('debería haberse abierto una nueva ventana con url que contiene "{url_part}"')
@step('que debería haberse abierto una nueva ventana con url que contiene "{url_part}"')
def step_new_window_opened_with_url(context, url_part):
    """Verifica que se abrió una nueva ventana/tab con una URL particular"""
    resolved_url_part = context.variable_manager.resolve_variables(url_part)
    
    # Obtener todas las páginas del contexto
    pages = context.page.context.pages
    
    # Buscar una página que contenga la URL
    for page in pages:
        if resolved_url_part in page.url:
            print(f"✓ Nueva ventana encontrada con URL: {page.url}")
            return
    
    # Si no encuentra, mostrar error con las URLs disponibles
    urls = [p.url for p in pages]
    raise AssertionError(
        f"No se encontró una ventana con URL que contenga '{resolved_url_part}'. "
        f"URLs disponibles: {urls}"
    )

@step('a new window should have opened with title containing "{title}"')
@step('debería haberse abierto una nueva ventana con título que contiene "{title}"')
@step('que debería haberse abierto una nueva ventana con título que contiene "{title}"')
def step_new_window_opened_with_title(context, title):
    """Verifica que se abrió una nueva ventana/tab con un título particular"""
    resolved_title = context.variable_manager.resolve_variables(title)
    
    # Obtener todas las páginas del contexto
    pages = context.page.context.pages
    
    # Buscar una página que contenga el título
    for page in pages:
        try:
            if resolved_title.lower() in page.title().lower():
                print(f"✓ Nueva ventana encontrada con título: {page.title()}")
                return
        except Exception:
            continue
    
    # Si no encuentra, mostrar error con los títulos disponibles
    titles = [p.title() for p in pages]
    raise AssertionError(
        f"No se encontró una ventana con título que contenga '{resolved_title}'. "
        f"Títulos disponibles: {titles}"
    )

@step('there should be {count:d} windows open')
@step('debería haber {count:d} ventanas abiertas')
@step('que debería haber {count:d} ventanas abiertas')
def step_verify_window_count(context, count):
    """Verifica que hay un número específico de ventanas abiertas"""
    pages = context.page.context.pages
    actual_count = len(pages)
    
    assert actual_count == count, (
        f"Se esperaban {count} ventanas, pero hay {actual_count}. "
        f"URLs: {[p.url for p in pages]}"
    )
    print(f"✓ Hay {actual_count} ventanas abiertas")


# ============================================================================
# VALIDACIONES DE CLASES CSS
# ============================================================================

@step('the element "{element_name}" should have the class "{css_class}" with identifier "{identifier}"')
@step('el elemento "{element_name}" debería tener la clase "{css_class}" con identificador "{identifier}"')
@step('que el elemento "{element_name}" debería tener la clase "{css_class}" con identificador "{identifier}"')
def step_element_should_have_class(context, element_name, css_class, identifier):
    """Verifica que un elemento tenga una clase CSS específica"""
    locator = context.element_locator.get_locator(identifier)
    resolved_class = context.variable_manager.resolve_variables(css_class)
    element = context.page.locator(locator)
    
    class_attr = element.get_attribute('class')
    classes = class_attr.split() if class_attr else []
    
    assert resolved_class in classes, f"❌ El elemento '{element_name}' no tiene la clase '{resolved_class}'. Clases actuales: {classes}"
    print(f"✓ El elemento '{element_name}' tiene la clase '{resolved_class}'")

@step('the element "{element_name}" should not have the class "{css_class}" with identifier "{identifier}"')
@step('el elemento "{element_name}" no debería tener la clase "{css_class}" con identificador "{identifier}"')
@step('que el elemento "{element_name}" no debería tener la clase "{css_class}" con identificador "{identifier}"')
def step_element_should_not_have_class(context, element_name, css_class, identifier):
    """Verifica que un elemento NO tenga una clase CSS específica"""
    locator = context.element_locator.get_locator(identifier)
    resolved_class = context.variable_manager.resolve_variables(css_class)
    element = context.page.locator(locator)
    
    class_attr = element.get_attribute('class')
    classes = class_attr.split() if class_attr else []
    
    assert resolved_class not in classes, f"❌ El elemento '{element_name}' tiene la clase '{resolved_class}' pero no debería"
    print(f"✓ El elemento '{element_name}' NO tiene la clase '{resolved_class}'")


# ============================================================================
# VALIDACIONES DE ATRIBUTOS HTML
# ============================================================================

@step('the element "{element_name}" should have the attribute "{attribute}" in identifier "{identifier}"')
@step('el elemento "{element_name}" debería tener el atributo "{attribute}" en identificador "{identifier}"')
@step('que el elemento "{element_name}" debería tener el atributo "{attribute}" en identificador "{identifier}"')
def step_element_should_have_attribute(context, element_name, attribute, identifier):
    """Verifica que un elemento tenga un atributo específico (sin importar su valor)"""
    locator = context.element_locator.get_locator(identifier)
    resolved_attr = context.variable_manager.resolve_variables(attribute)
    element = context.page.locator(locator)
    
    attr_value = element.get_attribute(resolved_attr)
    assert attr_value is not None, f"❌ El elemento '{element_name}' no tiene el atributo '{resolved_attr}'"
    print(f"✓ El elemento '{element_name}' tiene el atributo '{resolved_attr}' con valor: '{attr_value}'")

@step('the element "{element_name}" should not have the attribute "{attribute}" in identifier "{identifier}"')
@step('el elemento "{element_name}" no debería tener el atributo "{attribute}" con identificador "{identifier}"')
@step('que el elemento "{element_name}" no debería tener el atributo "{attribute}" con identificador "{identifier}"')
def step_element_should_not_have_attribute(context, element_name, attribute, identifier):
    """Verifica que un elemento NO tenga un atributo específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_attr = context.variable_manager.resolve_variables(attribute)
    element = context.page.locator(locator)
    
    attr_value = element.get_attribute(resolved_attr)
    assert attr_value is None, f"❌ El elemento '{element_name}' tiene el atributo '{resolved_attr}' con valor '{attr_value}'"
    print(f"✓ El elemento '{element_name}' NO tiene el atributo '{resolved_attr}'")

@step('the element "{element_name}" should have attribute "{attribute}" with value "{value}" with identifier "{identifier}"')
@step('el elemento "{element_name}" debería tener el atributo "{attribute}" con valor "{value}" con identificador "{identifier}"')
@step('que el elemento "{element_name}" debería tener el atributo "{attribute}" con valor "{value}" con identificador "{identifier}"')
def step_element_attribute_should_have_value(context, element_name, attribute, value, identifier):
    """Verifica que un atributo tenga un valor específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_attr = context.variable_manager.resolve_variables(attribute)
    resolved_value = context.variable_manager.resolve_variables(value)
    element = context.page.locator(locator)
    
    attr_value = element.get_attribute(resolved_attr)
    assert attr_value == resolved_value, f"❌ El atributo '{resolved_attr}' tiene valor '{attr_value}', se esperaba '{resolved_value}'"
    print(f"✓ El elemento '{element_name}' tiene el atributo '{resolved_attr}' con valor '{resolved_value}'")

@step('the element "{element_name}" should have attribute "{attribute}" containing "{value}" with identifier "{identifier}"')
@step('el elemento "{element_name}" debería tener el atributo "{attribute}" que contiene "{value}" con identificador "{identifier}"')
@step('que el elemento "{element_name}" debería tener el atributo "{attribute}" que contiene "{value}" con identificador "{identifier}"')
def step_element_attribute_should_contain_value(context, element_name, attribute, value, identifier):
    """Verifica que un atributo contenga un valor específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_attr = context.variable_manager.resolve_variables(attribute)
    resolved_value = context.variable_manager.resolve_variables(value)
    element = context.page.locator(locator)
    
    attr_value = element.get_attribute(resolved_attr)
    assert attr_value and resolved_value in attr_value, f"❌ El atributo '{resolved_attr}' con valor '{attr_value}' no contiene '{resolved_value}'"
    print(f"✓ El atributo '{resolved_attr}' contiene '{resolved_value}'")


# ============================================================================
# VALIDACIONES DE ESTADO DE ELEMENTOS
# ============================================================================

@step('the element "{element_name}" should be readonly with identifier "{identifier}"')
@step('el elemento "{element_name}" debería ser de solo lectura con identificador "{identifier}"')
@step('que el elemento "{element_name}" debería ser de solo lectura con identificador "{identifier}"')
def step_element_should_be_readonly(context, element_name, identifier):
    """Verifica que un elemento sea de solo lectura (readonly)"""
    locator = context.element_locator.get_locator(identifier)
    element = context.page.locator(locator)
    
    readonly_attr = element.get_attribute('readonly')
    assert readonly_attr is not None, f"❌ El elemento '{element_name}' no es de solo lectura"
    print(f"✓ El elemento '{element_name}' es de solo lectura")

@step('the element "{element_name}" should not be readonly with identifier "{identifier}"')
@step('el elemento "{element_name}" no debería ser de solo lectura con identificador "{identifier}"')
@step('que el elemento "{element_name}" no debería ser de solo lectura con identificador "{identifier}"')
def step_element_should_not_be_readonly(context, element_name, identifier):
    """Verifica que un elemento NO sea de solo lectura"""
    locator = context.element_locator.get_locator(identifier)
    element = context.page.locator(locator)
    
    readonly_attr = element.get_attribute('readonly')
    assert readonly_attr is None, f"❌ El elemento '{element_name}' es de solo lectura pero no debería"
    print(f"✓ El elemento '{element_name}' NO es de solo lectura")

@step('the element "{element_name}" should be required with identifier "{identifier}"')
@step('el elemento "{element_name}" debería ser requerido con identificador "{identifier}"')
@step('que el elemento "{element_name}" debería ser requerido con identificador "{identifier}"')
def step_element_should_be_required(context, element_name, identifier):
    """Verifica que un elemento sea requerido (required)"""
    locator = context.element_locator.get_locator(identifier)
    element = context.page.locator(locator)
    
    required_attr = element.get_attribute('required')
    assert required_attr is not None, f"❌ El elemento '{element_name}' no es requerido"
    print(f"✓ El elemento '{element_name}' es requerido")

@step('the element "{element_name}" should not be required with identifier "{identifier}"')
@step('el elemento "{element_name}" no debería ser requerido con identificador "{identifier}"')
@step('que el elemento "{element_name}" no debería ser requerido con identificador "{identifier}"')
def step_element_should_not_be_required(context, element_name, identifier):
    """Verifica que un elemento NO sea requerido"""
    locator = context.element_locator.get_locator(identifier)
    element = context.page.locator(locator)
    
    required_attr = element.get_attribute('required')
    assert required_attr is None, f"❌ El elemento '{element_name}' es requerido pero no debería"
    print(f"✓ El elemento '{element_name}' NO es requerido")

@step('the element "{element_name}" should be hidden with identifier "{identifier}"')
@step('el elemento "{element_name}" debería estar oculto con identificador "{identifier}"')
@step('que el elemento "{element_name}" debería estar oculto con identificador "{identifier}"')
def step_element_should_be_hidden(context, element_name, identifier):
    """Verifica que un elemento esté oculto (hidden o display:none)"""
    locator = context.element_locator.get_locator(identifier)
    expect(context.page.locator(locator)).to_be_hidden()
    print(f"✓ El elemento '{element_name}' está oculto")

@step('the element "{element_name}" should be attached to DOM with identifier "{identifier}"')
@step('el elemento "{element_name}" debería estar adjunto al DOM con identificador "{identifier}"')
@step('que el elemento "{element_name}" debería estar adjunto al DOM con identificador "{identifier}"')
def step_element_should_be_attached(context, element_name, identifier):
    """Verifica que un elemento esté adjunto al DOM"""
    locator = context.element_locator.get_locator(identifier)
    expect(context.page.locator(locator)).to_be_attached()
    print(f"✓ El elemento '{element_name}' está adjunto al DOM")

@step('the element "{element_name}" should be editable with identifier "{identifier}"')
@step('el elemento "{element_name}" debería ser editable con identificador "{identifier}"')
@step('que el elemento "{element_name}" debería ser editable con identificador "{identifier}"')
def step_element_should_be_editable(context, element_name, identifier):
    """Verifica que un elemento sea editable"""
    locator = context.element_locator.get_locator(identifier)
    expect(context.page.locator(locator)).to_be_editable()
    print(f"✓ El elemento '{element_name}' es editable")


# ============================================================================
# VALIDACIONES DE ATRIBUTOS DE INPUTS (min, max, maxlength, pattern, etc.)
# ============================================================================

@step('the input "{element_name}" should have min value "{min_value}" with identifier "{identifier}"')
@step('el input "{element_name}" debería tener valor mínimo "{min_value}" con identificador "{identifier}"')
@step('que el input "{element_name}" debería tener valor mínimo "{min_value}" con identificador "{identifier}"')
def step_input_should_have_min(context, element_name, min_value, identifier):
    """Verifica que un input tenga un valor mínimo específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_min = context.variable_manager.resolve_variables(min_value)
    element = context.page.locator(locator)
    
    min_attr = element.get_attribute('min')
    assert min_attr == resolved_min, f"❌ El input '{element_name}' tiene min='{min_attr}', se esperaba '{resolved_min}'"
    print(f"✓ El input '{element_name}' tiene min='{resolved_min}'")

@step('the input "{element_name}" should have max value "{max_value}" with identifier "{identifier}"')
@step('el input "{element_name}" debería tener valor máximo "{max_value}" con identificador "{identifier}"')
@step('que el input "{element_name}" debería tener valor máximo "{max_value}" con identificador "{identifier}"')
def step_input_should_have_max(context, element_name, max_value, identifier):
    """Verifica que un input tenga un valor máximo específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_max = context.variable_manager.resolve_variables(max_value)
    element = context.page.locator(locator)
    
    max_attr = element.get_attribute('max')
    assert max_attr == resolved_max, f"❌ El input '{element_name}' tiene max='{max_attr}', se esperaba '{resolved_max}'"
    print(f"✓ El input '{element_name}' tiene max='{resolved_max}'")

@step('the input "{element_name}" should have maxlength "{maxlength}" with identifier "{identifier}"')
@step('el input "{element_name}" debería tener longitud máxima "{maxlength}" con identificador "{identifier}"')
@step('que el input "{element_name}" debería tener longitud máxima "{maxlength}" con identificador "{identifier}"')
def step_input_should_have_maxlength(context, element_name, maxlength, identifier):
    """Verifica que un input tenga una longitud máxima específica"""
    locator = context.element_locator.get_locator(identifier)
    resolved_maxlength = context.variable_manager.resolve_variables(maxlength)
    element = context.page.locator(locator)
    
    maxlength_attr = element.get_attribute('maxlength')
    assert maxlength_attr == resolved_maxlength, f"❌ El input '{element_name}' tiene maxlength='{maxlength_attr}', se esperaba '{resolved_maxlength}'"
    print(f"✓ El input '{element_name}' tiene maxlength='{resolved_maxlength}'")

@step('the input "{element_name}" should have pattern "{pattern}" with identifier "{identifier}"')
@step('el input "{element_name}" debería tener patrón "{pattern}" con identificador "{identifier}"')
@step('que el input "{element_name}" debería tener patrón "{pattern}" con identificador "{identifier}"')
def step_input_should_have_pattern(context, element_name, pattern, identifier):
    """Verifica que un input tenga un patrón de validación específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_pattern = context.variable_manager.resolve_variables(pattern)
    element = context.page.locator(locator)
    
    pattern_attr = element.get_attribute('pattern')
    assert pattern_attr == resolved_pattern, f"❌ El input '{element_name}' tiene pattern='{pattern_attr}', se esperaba '{resolved_pattern}'"
    print(f"✓ El input '{element_name}' tiene pattern='{resolved_pattern}'")

@step('the input "{element_name}" should have placeholder "{placeholder}" with identifier "{identifier}"')
@step('el input "{element_name}" debería tener placeholder "{placeholder}" con identificador "{identifier}"')
@step('que el input "{element_name}" debería tener placeholder "{placeholder}" con identificador "{identifier}"')
def step_input_should_have_placeholder(context, element_name, placeholder, identifier):
    """Verifica que un input tenga un placeholder específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_placeholder = context.variable_manager.resolve_variables(placeholder)
    element = context.page.locator(locator)
    
    placeholder_attr = element.get_attribute('placeholder')
    assert placeholder_attr == resolved_placeholder, f"❌ El input '{element_name}' tiene placeholder='{placeholder_attr}', se esperaba '{resolved_placeholder}'"
    print(f"✓ El input '{element_name}' tiene placeholder='{resolved_placeholder}'")

@step('the input "{element_name}" should have type "{input_type}" with identifier "{identifier}"')
@step('el input "{element_name}" debería tener tipo "{input_type}" con identificador "{identifier}"')
@step('que el input "{element_name}" debería tener tipo "{input_type}" con identificador "{identifier}"')
def step_input_should_have_type(context, element_name, input_type, identifier):
    """Verifica que un input tenga un tipo específico (text, email, number, etc.)"""
    locator = context.element_locator.get_locator(identifier)
    resolved_type = context.variable_manager.resolve_variables(input_type)
    element = context.page.locator(locator)
    
    type_attr = element.get_attribute('type')
    assert type_attr == resolved_type, f"❌ El input '{element_name}' tiene type='{type_attr}', se esperaba '{resolved_type}'"
    print(f"✓ El input '{element_name}' tiene type='{resolved_type}'")


# ============================================================================
# VALIDACIONES DE CONTEO DE ELEMENTOS
# ============================================================================

@step('there should be exactly {count:d} elements matching "{element_name}" with identifier "{identifier}"')
@step('debería haber exactamente {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"')
@step('que debería haber exactamente {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"')
def step_should_have_exact_count(context, count, element_name, identifier):
    """Verifica que haya un número exacto de elementos que coincidan con el selector"""
    locator = context.element_locator.get_locator(identifier)
    expect(context.page.locator(locator)).to_have_count(count)
    print(f"✓ Hay exactamente {count} elementos '{element_name}'")

@step('there should be at least {count:d} elements matching "{element_name}" with identifier "{identifier}"')
@step('debería haber al menos {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"')
@step('que debería haber al menos {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"')
def step_should_have_at_least_count(context, count, element_name, identifier):
    """Verifica que haya al menos un número mínimo de elementos"""
    locator = context.element_locator.get_locator(identifier)
    actual_count = context.page.locator(locator).count()
    assert actual_count >= count, f"❌ Se esperaban al menos {count} elementos, pero hay {actual_count}"
    print(f"✓ Hay al menos {count} elementos '{element_name}' (total: {actual_count})")

@step('there should be at most {count:d} elements matching "{element_name}" with identifier "{identifier}"')
@step('debería haber como máximo {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"')
@step('que debería haber como máximo {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"')
def step_should_have_at_most_count(context, count, element_name, identifier):
    """Verifica que haya como máximo un número de elementos"""
    locator = context.element_locator.get_locator(identifier)
    actual_count = context.page.locator(locator).count()
    assert actual_count <= count, f"❌ Se esperaban como máximo {count} elementos, pero hay {actual_count}"
    print(f"✓ Hay como máximo {count} elementos '{element_name}' (total: {actual_count})")


# ============================================================================
# VALIDACIONES DE ATRIBUTOS ARIA (Accesibilidad)
# ============================================================================

@step('the element "{element_name}" should have aria-label "{aria_label}" with identifier "{identifier}"')
@step('el elemento "{element_name}" debería tener aria-label "{aria_label}" con identificador "{identifier}"')
@step('que el elemento "{element_name}" debería tener aria-label "{aria_label}" con identificador "{identifier}"')
def step_element_should_have_aria_label(context, element_name, aria_label, identifier):
    """Verifica que un elemento tenga un aria-label específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_label = context.variable_manager.resolve_variables(aria_label)
    element = context.page.locator(locator)
    
    aria_attr = element.get_attribute('aria-label')
    assert aria_attr == resolved_label, f"❌ El elemento '{element_name}' tiene aria-label='{aria_attr}', se esperaba '{resolved_label}'"
    print(f"✓ El elemento '{element_name}' tiene aria-label='{resolved_label}'")

@step('the element "{element_name}" should have role "{role}" with identifier "{identifier}"')
@step('el elemento "{element_name}" debería tener rol "{role}" con identificador "{identifier}"')
@step('que el elemento "{element_name}" debería tener rol "{role}" con identificador "{identifier}"')
def step_element_should_have_role(context, element_name, role, identifier):
    """Verifica que un elemento tenga un rol ARIA específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_role = context.variable_manager.resolve_variables(role)
    element = context.page.locator(locator)
    
    role_attr = element.get_attribute('role')
    assert role_attr == resolved_role, f"❌ El elemento '{element_name}' tiene role='{role_attr}', se esperaba '{resolved_role}'"
    print(f"✓ El elemento '{element_name}' tiene role='{resolved_role}'")

@step('the element "{element_name}" should have aria-expanded "{state}" with identifier "{identifier}"')
@step('el elemento "{element_name}" debería tener aria-expanded "{state}" con identificador "{identifier}"')
@step('que el elemento "{element_name}" debería tener aria-expanded "{state}" con identificador "{identifier}"')
def step_element_should_have_aria_expanded(context, element_name, state, identifier):
    """Verifica que un elemento tenga aria-expanded con un estado específico (true/false)"""
    locator = context.element_locator.get_locator(identifier)
    resolved_state = context.variable_manager.resolve_variables(state)
    element = context.page.locator(locator)
    
    aria_attr = element.get_attribute('aria-expanded')
    assert aria_attr == resolved_state, f"❌ El elemento '{element_name}' tiene aria-expanded='{aria_attr}', se esperaba '{resolved_state}'"
    print(f"✓ El elemento '{element_name}' tiene aria-expanded='{resolved_state}'")


# ============================================================================
# VALIDACIONES DE DATA ATTRIBUTES
# ============================================================================

@step('the element "{element_name}" should have data attribute "{data_attr}" with value "{value}" with identifier "{identifier}"')
@step('el elemento "{element_name}" debería tener atributo data "{data_attr}" con valor "{value}" con identificador "{identifier}"')
@step('que el elemento "{element_name}" debería tener atributo data "{data_attr}" con valor "{value}" con identificador "{identifier}"')
def step_element_should_have_data_attribute(context, element_name, data_attr, value, identifier):
    """Verifica que un elemento tenga un data-attribute específico con un valor
    
    Ejemplos:
    - el elemento "Card" debería tener atributo data "id" con valor "123" con identificador "$.CARDS.main"
    - el elemento "Button" debería tener atributo data "action" con valor "submit" con identificador "$.BUTTONS.save"
    """
    locator = context.element_locator.get_locator(identifier)
    resolved_attr = context.variable_manager.resolve_variables(data_attr)
    resolved_value = context.variable_manager.resolve_variables(value)
    element = context.page.locator(locator)
    
    # Construir el nombre completo del atributo data-*
    full_attr = f"data-{resolved_attr}"
    attr_value = element.get_attribute(full_attr)
    
    assert attr_value == resolved_value, f"❌ El elemento '{element_name}' tiene {full_attr}='{attr_value}', se esperaba '{resolved_value}'"
    print(f"✓ El elemento '{element_name}' tiene {full_attr}='{resolved_value}'")


# ============================================================================
# VALIDACIONES DE ATRIBUTOS COMUNES (href, src, alt, title, name, id)
# ============================================================================

@step('the link "{element_name}" should have href "{href}" with identifier "{identifier}"')
@step('el enlace "{element_name}" debería tener href "{href}" con identificador "{identifier}"')
@step('que el enlace "{element_name}" debería tener href "{href}" con identificador "{identifier}"')
def step_link_should_have_href(context, element_name, href, identifier):
    """Verifica que un enlace tenga un href específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_href = context.variable_manager.resolve_variables(href)
    element = context.page.locator(locator)
    
    href_attr = element.get_attribute('href')
    assert href_attr == resolved_href, f"❌ El enlace '{element_name}' tiene href='{href_attr}', se esperaba '{resolved_href}'"
    print(f"✓ El enlace '{element_name}' tiene href='{resolved_href}'")

@step('the link "{element_name}" should have href containing "{href_part}" with identifier "{identifier}"')
@step('el enlace "{element_name}" debería tener href que contiene "{href_part}" con identificador "{identifier}"')
@step('que el enlace "{element_name}" debería tener href que contiene "{href_part}" con identificador "{identifier}"')
def step_link_should_have_href_containing(context, element_name, href_part, identifier):
    """Verifica que un enlace tenga un href que contenga una parte específica"""
    locator = context.element_locator.get_locator(identifier)
    resolved_href_part = context.variable_manager.resolve_variables(href_part)
    element = context.page.locator(locator)
    
    href_attr = element.get_attribute('href')
    assert href_attr and resolved_href_part in href_attr, f"❌ El href '{href_attr}' no contiene '{resolved_href_part}'"
    print(f"✓ El enlace '{element_name}' tiene href que contiene '{resolved_href_part}'")

@step('the image "{element_name}" should have src "{src}" with identifier "{identifier}"')
@step('la imagen "{element_name}" debería tener src "{src}" con identificador "{identifier}"')
@step('que la imagen "{element_name}" debería tener src "{src}" con identificador "{identifier}"')
def step_image_should_have_src(context, element_name, src, identifier):
    """Verifica que una imagen tenga un src específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_src = context.variable_manager.resolve_variables(src)
    element = context.page.locator(locator)
    
    src_attr = element.get_attribute('src')
    assert src_attr == resolved_src, f"❌ La imagen '{element_name}' tiene src='{src_attr}', se esperaba '{resolved_src}'"
    print(f"✓ La imagen '{element_name}' tiene src='{resolved_src}'")

@step('the image "{element_name}" should have alt "{alt}" with identifier "{identifier}"')
@step('la imagen "{element_name}" debería tener alt "{alt}" con identificador "{identifier}"')
@step('que la imagen "{element_name}" debería tener alt "{alt}" con identificador "{identifier}"')
def step_image_should_have_alt(context, element_name, alt, identifier):
    """Verifica que una imagen tenga un texto alternativo específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_alt = context.variable_manager.resolve_variables(alt)
    element = context.page.locator(locator)
    
    alt_attr = element.get_attribute('alt')
    assert alt_attr == resolved_alt, f"❌ La imagen '{element_name}' tiene alt='{alt_attr}', se esperaba '{resolved_alt}'"
    print(f"✓ La imagen '{element_name}' tiene alt='{resolved_alt}'")

@step('the element "{element_name}" should have title "{title}" with identifier "{identifier}"')
@step('el elemento "{element_name}" debería tener título "{title}" con identificador "{identifier}"')
@step('que el elemento "{element_name}" debería tener título "{title}" con identificador "{identifier}"')
def step_element_should_have_title_attr(context, element_name, title, identifier):
    """Verifica que un elemento tenga un atributo title específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_title = context.variable_manager.resolve_variables(title)
    element = context.page.locator(locator)
    
    title_attr = element.get_attribute('title')
    assert title_attr == resolved_title, f"❌ El elemento '{element_name}' tiene title='{title_attr}', se esperaba '{resolved_title}'"
    print(f"✓ El elemento '{element_name}' tiene title='{resolved_title}'")

@step('the element "{element_name}" should have name "{name}" with identifier "{identifier}"')
@step('el elemento "{element_name}" debería tener nombre "{name}" con identificador "{identifier}"')
@step('que el elemento "{element_name}" debería tener nombre "{name}" con identificador "{identifier}"')
def step_element_should_have_name(context, element_name, name, identifier):
    """Verifica que un elemento tenga un atributo name específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_name = context.variable_manager.resolve_variables(name)
    element = context.page.locator(locator)
    
    name_attr = element.get_attribute('name')
    assert name_attr == resolved_name, f"❌ El elemento '{element_name}' tiene name='{name_attr}', se esperaba '{resolved_name}'"
    print(f"✓ El elemento '{element_name}' tiene name='{resolved_name}'")

@step('the element "{element_name}" should have id "{element_id}" with identifier "{identifier}"')
@step('el elemento "{element_name}" debería tener id "{element_id}" con identificador "{identifier}"')
@step('que el elemento "{element_name}" debería tener id "{element_id}" con identificador "{identifier}"')
def step_element_should_have_id(context, element_name, element_id, identifier):
    """Verifica que un elemento tenga un id específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_id = context.variable_manager.resolve_variables(element_id)
    element = context.page.locator(locator)
    
    id_attr = element.get_attribute('id')
    assert id_attr == resolved_id, f"❌ El elemento '{element_name}' tiene id='{id_attr}', se esperaba '{resolved_id}'"
    print(f"✓ El elemento '{element_name}' tiene id='{resolved_id}'")


# ============================================================================
# VALIDACIONES DE SELECT/OPTIONS
# ============================================================================

@step('the select "{element_name}" should have selected option "{option_text}" with identifier "{identifier}"')
@step('el select "{element_name}" debería tener la opción seleccionada "{option_text}" con identificador "{identifier}"')
@step('que el select "{element_name}" debería tener la opción seleccionada "{option_text}" con identificador "{identifier}"')
def step_select_should_have_selected_option(context, element_name, option_text, identifier):
    """Verifica que un select tenga una opción específica seleccionada"""
    locator = context.element_locator.get_locator(identifier)
    resolved_option = context.variable_manager.resolve_variables(option_text)
    element = context.page.locator(locator)
    
    # Obtener el texto de la opción seleccionada
    selected_option = element.locator('option:checked')
    expect(selected_option).to_have_text(resolved_option)
    print(f"✓ El select '{element_name}' tiene seleccionada la opción '{resolved_option}'")

@step('the select "{element_name}" should have {count:d} options with identifier "{identifier}"')
@step('el select "{element_name}" debería tener {count:d} opciones con identificador "{identifier}"')
@step('que el select "{element_name}" debería tener {count:d} opciones con identificador "{identifier}"')
def step_select_should_have_options_count(context, element_name, count, identifier):
    """Verifica que un select tenga un número específico de opciones"""
    locator = context.element_locator.get_locator(identifier)
    element = context.page.locator(locator)
    
    options = element.locator('option')
    expect(options).to_have_count(count)
    print(f"✓ El select '{element_name}' tiene {count} opciones")
