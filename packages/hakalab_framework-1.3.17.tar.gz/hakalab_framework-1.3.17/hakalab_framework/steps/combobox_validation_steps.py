#!/usr/bin/env python3
"""
Steps avanzados para validación de combobox y elementos de selección
Incluye validaciones de opciones, estado y comportamiento
"""
from behave import step
from playwright.sync_api import expect

@step('I verify combobox "{element_name}" contains exactly "{expected_options}" options with identifier "{identifier}"')
@step('verifico que el combobox "{element_name}" contiene exactamente "{expected_options}" opciones con identificador "{identifier}"')
def step_verify_combobox_exact_options(context, element_name, expected_options, identifier):
    """Verifica que un combobox contiene exactamente las opciones especificadas"""
    locator = context.element_locator.get_locator(identifier)
    expected_list = [opt.strip() for opt in expected_options.split(',')]
    
    # Obtener todas las opciones del select
    option_elements = context.page.locator(f'{locator} option')
    actual_options = []
    
    for i in range(option_elements.count()):
        option_text = option_elements.nth(i).text_content().strip()
        if option_text:  # Ignorar opciones vacías
            actual_options.append(option_text)
    
    # Verificar que las listas son idénticas
    assert set(actual_options) == set(expected_list), f"Opciones actuales {actual_options} no coinciden con esperadas {expected_list}"
    assert len(actual_options) == len(expected_list), f"Número de opciones diferente: actual {len(actual_options)}, esperado {len(expected_list)}"

@step('I verify combobox "{element_name}" has "{expected_count}" options with identifier "{identifier}"')
@step('verifico que el combobox "{element_name}" tiene "{expected_count}" opciones con identificador "{identifier}"')
def step_verify_combobox_options_count(context, element_name, expected_count, identifier):
    """Verifica que un combobox tiene un número específico de opciones"""
    locator = context.element_locator.get_locator(identifier)
    expected_num = int(expected_count)
    
    option_elements = context.page.locator(f'{locator} option')
    actual_count = 0
    
    for i in range(option_elements.count()):
        option_text = option_elements.nth(i).text_content().strip()
        if option_text:  # Contar solo opciones no vacías
            actual_count += 1
    
    assert actual_count == expected_num, f"Combobox tiene {actual_count} opciones, esperado {expected_num}"

@step('I verify combobox "{element_name}" first option is "{expected_option}" with identifier "{identifier}"')
@step('verifico que la primera opción del combobox "{element_name}" es "{expected_option}" con identificador "{identifier}"')
def step_verify_combobox_first_option(context, element_name, expected_option, identifier):
    """Verifica que la primera opción de un combobox es específica"""
    locator = context.element_locator.get_locator(identifier)
    resolved_option = context.variable_manager.resolve_variables(expected_option)
    
    first_option = context.page.locator(f'{locator} option').first
    first_text = first_option.text_content().strip()
    
    assert first_text == resolved_option, f"Primera opción es '{first_text}', esperado '{resolved_option}'"

@step('I verify combobox "{element_name}" last option is "{expected_option}" with identifier "{identifier}"')
@step('verifico que la última opción del combobox "{element_name}" es "{expected_option}" con identificador "{identifier}"')
def step_verify_combobox_last_option(context, element_name, expected_option, identifier):
    """Verifica que la última opción de un combobox es específica"""
    locator = context.element_locator.get_locator(identifier)
    resolved_option = context.variable_manager.resolve_variables(expected_option)
    
    last_option = context.page.locator(f'{locator} option').last
    last_text = last_option.text_content().strip()
    
    assert last_text == resolved_option, f"Última opción es '{last_text}', esperado '{resolved_option}'"

@step('I verify combobox "{element_name}" options are sorted alphabetically with identifier "{identifier}"')
@step('verifico que las opciones del combobox "{element_name}" están ordenadas alfabéticamente con identificador "{identifier}"')
def step_verify_combobox_options_sorted(context, element_name, identifier):
    """Verifica que las opciones de un combobox están ordenadas alfabéticamente"""
    locator = context.element_locator.get_locator(identifier)
    
    option_elements = context.page.locator(f'{locator} option')
    options = []
    
    for i in range(option_elements.count()):
        option_text = option_elements.nth(i).text_content().strip()
        if option_text:  # Ignorar opciones vacías
            options.append(option_text)
    
    sorted_options = sorted(options)
    assert options == sorted_options, f"Opciones no están ordenadas alfabéticamente: {options}"

@step('I verify combobox "{element_name}" has no duplicate options with identifier "{identifier}"')
@step('verifico que el combobox "{element_name}" no tiene opciones duplicadas con identificador "{identifier}"')
def step_verify_combobox_no_duplicates(context, element_name, identifier):
    """Verifica que un combobox no tiene opciones duplicadas"""
    locator = context.element_locator.get_locator(identifier)
    
    option_elements = context.page.locator(f'{locator} option')
    options = []
    
    for i in range(option_elements.count()):
        option_text = option_elements.nth(i).text_content().strip()
        if option_text:
            options.append(option_text)
    
    unique_options = list(set(options))
    assert len(options) == len(unique_options), f"Combobox tiene opciones duplicadas: {options}"

@step('I verify combobox "{element_name}" contains option "{expected_option}" with identifier "{identifier}"')
@step('verifico que el combobox "{element_name}" contiene la opción "{expected_option}" con identificador "{identifier}"')
def step_verify_combobox_contains_option(context, element_name, expected_option, identifier):
    """Verifica que un combobox contiene una opción específica"""
    locator = context.element_locator.get_locator(identifier)
    resolved_option = context.variable_manager.resolve_variables(expected_option)
    
    # Usar el locator directamente sin concatenar strings
    # Esto evita problemas con comillas en XPath
    try:
        option_elements = context.page.locator(locator).locator('option')
    except:
        # Si falla, intentar con CSS selector
        option_elements = context.page.locator(f'{locator} option')
    
    found = False
    
    try:
        for i in range(option_elements.count()):
            option_text = option_elements.nth(i).text_content().strip()
            if option_text == resolved_option:
                found = True
                break
    except Exception as e:
        # Si hay error con el locator, intentar búsqueda alternativa
        print(f"⚠️ Error buscando opciones: {e}")
        # Intentar buscar por texto directamente
        try:
            context.page.locator(f'text="{resolved_option}"').wait_for(state='visible', timeout=2000)
            found = True
        except:
            found = False
    
    assert found, f"Combobox no contiene la opción '{resolved_option}'"

@step('I verify combobox "{element_name}" does not contain option "{unexpected_option}" with identifier "{identifier}"')
@step('verifico que el combobox "{element_name}" no contiene la opción "{unexpected_option}" con identificador "{identifier}"')
def step_verify_combobox_not_contains_option(context, element_name, unexpected_option, identifier):
    """Verifica que un combobox NO contiene una opción específica"""
    locator = context.element_locator.get_locator(identifier)
    resolved_option = context.variable_manager.resolve_variables(unexpected_option)
    
    # Usar el locator directamente sin concatenar strings
    try:
        option_elements = context.page.locator(locator).locator('option')
    except:
        option_elements = context.page.locator(f'{locator} option')
    
    try:
        for i in range(option_elements.count()):
            option_text = option_elements.nth(i).text_content().strip()
            assert option_text != resolved_option, f"Combobox contiene la opción '{resolved_option}' cuando no debería"
    except Exception as e:
        print(f"⚠️ Error verificando opciones: {e}")

@step('I verify combobox "{element_name}" default selection is "{expected_selection}" with identifier "{identifier}"')
@step('verifico que la selección por defecto del combobox "{element_name}" es "{expected_selection}" con identificador "{identifier}"')
def step_verify_combobox_default_selection(context, element_name, expected_selection, identifier):
    """Verifica que la selección por defecto de un combobox es específica"""
    locator = context.element_locator.get_locator(identifier)
    resolved_selection = context.variable_manager.resolve_variables(expected_selection)
    
    selected_option = context.page.locator(f'{locator} option:checked, {locator} option[selected]')
    
    if selected_option.count() > 0:
        selected_text = selected_option.text_content().strip()
        assert selected_text == resolved_selection, f"Selección por defecto es '{selected_text}', esperado '{resolved_selection}'"
    else:
        # Verificar por valor del select
        select_value = context.page.locator(locator).input_value()
        assert select_value == resolved_selection, f"Valor por defecto es '{select_value}', esperado '{resolved_selection}'"

@step('I verify combobox "{element_name}" allows multiple selection with identifier "{identifier}"')
@step('verifico que el combobox "{element_name}" permite selección múltiple con identificador "{identifier}"')
def step_verify_combobox_multiple_selection(context, element_name, identifier):
    """Verifica que un combobox permite selección múltiple"""
    locator = context.element_locator.get_locator(identifier)
    
    multiple_attr = context.page.locator(locator).get_attribute('multiple')
    assert multiple_attr is not None, f"Combobox '{element_name}' no permite selección múltiple"

@step('I verify combobox "{element_name}" does not allow multiple selection with identifier "{identifier}"')
@step('verifico que el combobox "{element_name}" no permite selección múltiple con identificador "{identifier}"')
def step_verify_combobox_single_selection(context, element_name, identifier):
    """Verifica que un combobox NO permite selección múltiple"""
    locator = context.element_locator.get_locator(identifier)
    
    multiple_attr = context.page.locator(locator).get_attribute('multiple')
    assert multiple_attr is None, f"Combobox '{element_name}' permite selección múltiple cuando no debería"

@step('I verify combobox "{element_name}" is required field with identifier "{identifier}"')
@step('verifico que el combobox "{element_name}" es campo requerido con identificador "{identifier}"')
def step_verify_combobox_required(context, element_name, identifier):
    """Verifica que un combobox es un campo requerido"""
    locator = context.element_locator.get_locator(identifier)
    
    required_attr = context.page.locator(locator).get_attribute('required')
    assert required_attr is not None, f"Combobox '{element_name}' no es campo requerido"

@step('I verify combobox "{element_name}" placeholder is "{expected_placeholder}" with identifier "{identifier}"')
@step('verifico que el placeholder del combobox "{element_name}" es "{expected_placeholder}" con identificador "{identifier}"')
def step_verify_combobox_placeholder(context, element_name, expected_placeholder, identifier):
    """Verifica que un combobox tiene un placeholder específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_placeholder = context.variable_manager.resolve_variables(expected_placeholder)
    
    # Buscar placeholder en diferentes formas
    placeholder_selectors = [
        f'{locator}[placeholder]',
        f'{locator} option[value=""]',
        f'{locator} option:first-child'
    ]
    
    for selector in placeholder_selectors:
        element = context.page.locator(selector)
        if element.count() > 0:
            if 'placeholder' in selector:
                actual_placeholder = element.get_attribute('placeholder')
            else:
                actual_placeholder = element.text_content().strip()
            
            if actual_placeholder == resolved_placeholder:
                return
    
    raise AssertionError(f"Placeholder del combobox no es '{resolved_placeholder}'")

@step('I verify combobox "{element_name}" options contain values "{expected_values}" with identifier "{identifier}"')
@step('verifico que las opciones del combobox "{element_name}" contienen los valores "{expected_values}" con identificador "{identifier}"')
def step_verify_combobox_option_values(context, element_name, expected_values, identifier):
    """Verifica que las opciones de un combobox tienen valores específicos"""
    locator = context.element_locator.get_locator(identifier)
    expected_list = [val.strip() for val in expected_values.split(',')]
    
    option_elements = context.page.locator(f'{locator} option')
    actual_values = []
    
    for i in range(option_elements.count()):
        option_value = option_elements.nth(i).get_attribute('value') or ""
        if option_value:
            actual_values.append(option_value)
    
    for expected_val in expected_list:
        assert expected_val in actual_values, f"Valor '{expected_val}' no encontrado en opciones del combobox"

@step('I verify combobox "{element_name}" can be filtered by typing "{filter_text}" with identifier "{identifier}"')
@step('verifico que el combobox "{element_name}" se puede filtrar escribiendo "{filter_text}" con identificador "{identifier}"')
def step_verify_combobox_filterable(context, element_name, filter_text, identifier):
    """Verifica que un combobox se puede filtrar escribiendo texto"""
    locator = context.element_locator.get_locator(identifier)
    resolved_text = context.variable_manager.resolve_variables(filter_text)
    
    # Contar opciones antes del filtro
    initial_count = context.page.locator(f'{locator} option').count()
    
    # Escribir texto para filtrar
    context.page.locator(locator).fill(resolved_text)
    context.page.wait_for_timeout(500)  # Esperar que se aplique el filtro
    
    # Contar opciones después del filtro
    filtered_count = context.page.locator(f'{locator} option:visible').count()
    
    # Debería haber menos opciones después del filtro (o al menos no más)
    assert filtered_count <= initial_count, f"Filtro no funcionó: {filtered_count} opciones después vs {initial_count} antes"