#!/usr/bin/env python3
"""
Steps para interacción avanzada con tablas
"""
from behave import step
import re
from datetime import datetime


def _get_element(context, selector, dynamic_value=None):
    """
    Función auxiliar para obtener elementos.
    Soporta tanto selectores CSS como identificadores JSON ($.ARCHIVO.elemento)
    Soporta placeholders dinámicos: $.ARCHIVO.elemento=valor
    Soporta iframes: Si context.current_frame existe, busca dentro del iframe
    """
    # Determinar si estamos dentro de un iframe
    page_or_frame = getattr(context, 'current_frame', None) or context.page
    
    if selector.startswith('$.') and hasattr(context, 'element_locator'):
        return context.element_locator.find(page_or_frame, selector, dynamic_value)
    else:
        return page_or_frame.locator(selector)

from playwright.sync_api import expect

@step('I verify table "{table_name}" has "{expected_rows}" rows with identifier "{identifier}"')
@step('verifico que la tabla "{table_name}" tiene "{expected_rows}" filas con identificador "{identifier}"')
def step_verify_table_rows(context, table_name, expected_rows, identifier):
    """Verifica que una tabla tiene un número específico de filas
    
    Soporta valores directos o variables con ${variable_name}
    
    Ejemplos:
        verifico que la tabla "Pendientes" tiene "5" filas con identificador "$.KIBERPRO_SOLICITUD.tabla_pendientes"
        verifico que la tabla "Pendientes" tiene "${num_pendientes}" filas con identificador "$.KIBERPRO_SOLICITUD.tabla_pendientes"
    """
    locator = context.element_locator.get_locator(identifier)
    
    # Resolver variables si existen (soporta ${variable_name})
    resolved_rows = context.variable_manager.resolve_variables(expected_rows)
    expected_count = int(resolved_rows)
    
    # Contar filas (excluyendo header)
    rows = context.page.locator(f'{locator}/tbody/tr')
    actual_count = rows.count()
    
    assert actual_count == expected_count, f"Tabla tiene {actual_count} filas, esperado {expected_count}"

@step('I verify table "{table_name}" has "{expected_columns}" columns with identifier "{identifier}"')
@step('verifico que la tabla "{table_name}" tiene "{expected_columns}" columnas con identificador "{identifier}"')
def step_verify_table_columns(context, table_name, expected_columns, identifier):
    """Verifica que una tabla tiene un número específico de columnas"""
    locator = context.element_locator.get_locator(identifier)
    expected_count = int(expected_columns)
    
    # Contar columnas del header
    headers = context.page.locator(f'{locator} thead th, {locator} tr:first-child td')
    actual_count = headers.count()
    
    assert actual_count == expected_count, f"Tabla tiene {actual_count} columnas, esperado {expected_count}"

@step('I click on table cell at row "{row}" column "{column}" in table "{table_name}" with identifier "{identifier}"')
@step('hago click en la celda de la fila "{row}" columna "{column}" de la tabla "{table_name}" con identificador "{identifier}"')
def step_click_table_cell(context, row, column, table_name, identifier):
    """Hace click en una celda específica de la tabla"""
    locator = context.element_locator.get_locator(identifier)
    row_index = int(row)
    col_index = int(column)
    
    # Hacer click en la celda específica (índices basados en 1)
    cell = context.page.locator(f'{locator} tbody tr:nth-child({row_index}) td:nth-child({col_index})')
    expect(cell).to_be_visible()
    cell.click()

@step('I verify table cell at row "{row}" column "{column}" contains "{expected_text}" in table "{table_name}" with identifier "{identifier}"')
@step('verifico que la celda de la fila "{row}" columna "{column}" contiene "{expected_text}" en la tabla "{table_name}" con identificador "{identifier}"')
def step_verify_table_cell_text(context, row, column, expected_text, table_name, identifier):
    """Verifica que una celda específica contiene un texto"""
    locator = context.element_locator.get_locator(identifier)
    row_index = int(row)
    col_index = int(column)
    resolved_text = context.variable_manager.resolve_variables(expected_text)
    
    # Verificar contenido de la celda
    cell = context.page.locator(f'{locator} tbody tr:nth-child({row_index}) td:nth-child({col_index})')
    expect(cell).to_contain_text(resolved_text)

@step('I sort table "{table_name}" by column "{column_name}" with identifier "{identifier}"')
@step('ordeno la tabla "{table_name}" por la columna "{column_name}" con identificador "{identifier}"')
def step_sort_table_by_column(context, table_name, column_name, identifier):
    """Ordena una tabla haciendo click en el header de una columna"""
    locator = context.element_locator.get_locator(identifier)
    resolved_column = context.variable_manager.resolve_variables(column_name)
    
    # Buscar el header de la columna y hacer click
    header_selectors = [
        f'{locator} thead th:has-text("{resolved_column}")',
        f'{locator} th:has-text("{resolved_column}")',
        f'{locator} .sortable:has-text("{resolved_column}")'
    ]
    
    header_clicked = False
    for selector in header_selectors:
        header = context.page.locator(selector)
        if header.count() > 0:
            header.first.click()
            header_clicked = True
            break
    
    assert header_clicked, f"Header de columna '{resolved_column}' no encontrado"

@step('I filter table "{table_name}" by column "{column_name}" with value "{filter_value}" with identifier "{identifier}"')
@step('filtro la tabla "{table_name}" por la columna "{column_name}" con valor "{filter_value}" con identificador "{identifier}"')
def step_filter_table(context, table_name, column_name, filter_value, identifier):
    """Filtra una tabla por una columna específica"""
    locator = context.element_locator.get_locator(identifier)
    resolved_column = context.variable_manager.resolve_variables(column_name)
    resolved_value = context.variable_manager.resolve_variables(filter_value)
    
    # Buscar campo de filtro para la columna
    filter_selectors = [
        f'{locator} .filter-{resolved_column.lower()}',
        f'{locator} input[data-column="{resolved_column}"]',
        f'{locator} .column-filter input',
        f'input[placeholder*="{resolved_column}"]'
    ]
    
    filter_found = False
    for selector in filter_selectors:
        filter_input = context.page.locator(selector)
        if filter_input.count() > 0:
            filter_input.first.fill(resolved_value)
            filter_input.first.press('Enter')
            filter_found = True
            break
    
    assert filter_found, f"Campo de filtro para columna '{resolved_column}' no encontrado"

@step('I select row "{row_number}" in table "{table_name}" with identifier "{identifier}"')
@step('selecciono la fila "{row_number}" en la tabla "{table_name}" con identificador "{identifier}"')
def step_select_table_row(context, row_number, table_name, identifier):
    """Selecciona una fila específica de la tabla"""
    locator = context.element_locator.get_locator(identifier)
    row_index = int(row_number)
    
    # Buscar checkbox o elemento seleccionable en la fila
    row_selector = f'{locator} tbody tr:nth-child({row_index})'
    
    # Intentar diferentes métodos de selección
    selection_selectors = [
        f'{row_selector} input[type="checkbox"]',
        f'{row_selector} input[type="radio"]',
        f'{row_selector} .select-row',
        row_selector  # Hacer click en la fila completa
    ]
    
    for selector in selection_selectors:
        element = context.page.locator(selector)
        if element.count() > 0:
            element.first.click()
            return
    
    raise AssertionError(f"No se pudo seleccionar la fila {row_index}")

@step('I verify table "{table_name}" row "{row_number}" is selected with identifier "{identifier}"')
@step('verifico que la fila "{row_number}" de la tabla "{table_name}" está seleccionada con identificador "{identifier}"')
def step_verify_row_selected(context, table_name, row_number, identifier):
    """Verifica que una fila específica está seleccionada"""
    locator = context.element_locator.get_locator(identifier)
    row_index = int(row_number)
    
    # Verificar diferentes indicadores de selección
    row_selector = f'{locator} tbody tr:nth-child({row_index})'
    
    selection_indicators = [
        f'{row_selector} input[type="checkbox"]:checked',
        f'{row_selector} input[type="radio"]:checked',
        f'{row_selector}.selected',
        f'{row_selector}.active'
    ]
    
    is_selected = False
    for selector in selection_indicators:
        if context.page.locator(selector).count() > 0:
            is_selected = True
            break
    
    assert is_selected, f"Fila {row_index} no está seleccionada"

@step('I get table cell value at row "{row}" column "{column}" and store in variable "{variable_name}" from table "{table_name}" with identifier "{identifier}"')
@step('obtengo el valor de la celda fila "{row}" columna "{column}" y lo guardo en la variable "{variable_name}" de la tabla "{table_name}" con identificador "{identifier}"')
def step_get_table_cell_value(context, row, column, variable_name, table_name, identifier):
    """Obtiene el valor de una celda y lo guarda en una variable"""
    locator = context.element_locator.get_locator(identifier)
    row_index = int(row)
    col_index = int(column)
    
    # Obtener texto de la celda
    cell = context.page.locator(f'{locator} tbody tr:nth-child({row_index}) td:nth-child({col_index})')
    cell_text = cell.text_content()
    
    # Guardar en variable
    context.variable_manager.set_variable(variable_name, cell_text.strip())

@step('I verify table "{table_name}" row "{row_number}" has the following data with identifier "{identifier}"')
@step('verifico que la fila "{row_number}" de la tabla "{table_name}" tiene los siguientes datos con identificador "{identifier}"')
def step_verify_table_row_data(context, table_name, row_number, identifier):
    """Verifica que una fila completa tiene los datos esperados
    
    Usa una tabla de datos en el feature para especificar los valores esperados.
    
    Ejemplo:
        verifico que la fila "1" de la tabla "Usuarios" tiene los siguientes datos con identificador "$.TABLE.users"
          | datos |
          | 1     |
          | Juan  |
          | admin |
          | activo|
    """
    if not context.table:
        raise AssertionError("Se requiere una tabla de datos para este paso")
    
    locator = context.element_locator.get_locator(identifier)
    row_index = int(row_number)
    
    # Obtener los datos esperados de la tabla
    expected_values = []
    for row in context.table:
        expected_values.append(row['datos'].strip())
    
    # Obtener la fila de la tabla - usar >> para evitar problemas con XPath complejo
    row_selector = f'({locator}) >> tbody tr:nth-child({row_index})'
    cells = context.page.locator(f'{row_selector} >> td')
    
    # Si no encuentra en tbody, intentar directamente en tr
    if cells.count() == 0:
        row_selector = f'({locator}) >> tr:nth-child({row_index})'
        cells = context.page.locator(f'{row_selector} >> td')
    
    if cells.count() != len(expected_values):
        raise AssertionError(
            f"Fila {row_index}: Se esperaban {len(expected_values)} columnas, "
            f"pero la tabla tiene {cells.count()}"
        )
    
    # Verificar cada celda
    actual_values = []
    for i in range(cells.count()):
        cell_text = cells.nth(i).text_content().strip()
        actual_values.append(cell_text)
        
        if cell_text != expected_values[i]:
            raise AssertionError(
                f"Fila {row_index}, Columna {i+1}: "
                f"Se esperaba '{expected_values[i]}', pero se encontró '{cell_text}'"
            )
    
    print(f"✓ Fila {row_index} verificada correctamente: {actual_values}")

@step('I verify table "{table_name}" header has the following columns with identifier "{identifier}"')
@step('verifico que el header de la tabla "{table_name}" tiene las siguientes columnas con identificador "{identifier}"')
def step_verify_table_header(context, table_name, identifier):
    """Verifica que el header de la tabla tiene las columnas esperadas
    
    Usa una tabla de datos en el feature para especificar los nombres de columnas.
    
    Ejemplo:
        verifico que el header de la tabla "Usuarios" tiene las siguientes columnas con identificador "$.TABLE.users"
          | columnas |
          | ID       |
          | Nombre   |
          | Rol      |
          | Estado   |
    """
    if not context.table:
        raise AssertionError("Se requiere una tabla de datos para este paso")
    
    locator = context.element_locator.get_locator(identifier)
    
    # Obtener los nombres de columnas esperados
    expected_columns = []
    for row in context.table:
        expected_columns.append(row['columnas'].strip())
    
    # Obtener headers de la tabla - usar selectores separados para evitar problemas con XPath
    # Primero intentar con thead th
    headers = context.page.locator(f'({locator}) >> thead th')
    
    # Si no encuentra en thead, intentar con tr:first-child th
    if headers.count() == 0:
        headers = context.page.locator(f'({locator}) >> tr:first-child th')
    
    # Si aún no encuentra, intentar con td en la primera fila
    if headers.count() == 0:
        headers = context.page.locator(f'({locator}) >> tr:first-child td')
    
    if headers.count() != len(expected_columns):
        raise AssertionError(
            f"Se esperaban {len(expected_columns)} columnas, "
            f"pero la tabla tiene {headers.count()}"
        )
    
    # Verificar cada header
    actual_columns = []
    for i in range(headers.count()):
        header_text = headers.nth(i).text_content().strip()
        actual_columns.append(header_text)
        
        if header_text != expected_columns[i]:
            raise AssertionError(
                f"Columna {i+1}: "
                f"Se esperaba '{expected_columns[i]}', pero se encontró '{header_text}'"
            )
    
    print(f"✓ Header verificado correctamente: {actual_columns}")

@step('I verify table "{table_name}" row "{row_number}" has data with formats with identifier "{identifier}"')
@step('verifico que la fila "{row_number}" de la tabla "{table_name}" tiene datos con formato con identificador "{identifier}"')
def step_verify_table_row_data_formats(context, row_number, table_name, identifier):
    """Verifica que una fila tiene datos que coinciden con formatos específicos.
    
    Soporta dos tipos de validaciones:
    
    1. VALIDACIÓN DE TIPO DE ELEMENTO HTML:
       - button, a, link, span, div, p, label, input, textarea, select, strong, em, h1-h6
       - Verifica que la celda contiene el tipo de elemento HTML especificado
    
    2. VALIDACIÓN DE FORMATO DE DATOS:
       - vacio: Celda vacía
       - no_vacio: Celda con contenido
       - numero: Formato numérico
       - string/texto: Texto no vacío
       - fecha: Formato de fecha (DD/MM/YYYY, DD-MM-YYYY, YYYY-MM-DD)
       - email: Formato de email válido
       - url: URL que empieza con http:// o https://
       - cualquiera: Acepta cualquier valor
    
    3. MÚLTIPLES FORMATOS (NUEVO):
       - Usa el separador / para aceptar múltiples formatos
       - Ejemplo: "button/div" acepta button O div
       - Ejemplo: "string/numero" acepta texto O número
       - Funciona con cualquier combinación de formatos
    
    Ejemplos:
        # Validar tipos de elementos HTML
        verifico que la fila "1" de la tabla "Solicitudes" tiene datos con formato con identificador "$.TABLA.solicitudes"
          | formato  |
          | button   |  # Verifica que hay un <button>
          | string   |  # Verifica que hay texto
          | a        |  # Verifica que hay un <a> (link)
        
        # Validar formatos de datos
        verifico que la fila "1" de la tabla "Usuarios" tiene datos con formato con identificador "$.TABLA.usuarios"
          | formato  |
          | numero   |
          | email    |
          | fecha    |
        
        # Usar múltiples formatos (acepta cualquiera de las opciones)
        verifico que la fila "1" de la tabla "Mixta" tiene datos con formato con identificador "$.TABLA.mixta"
          | formato       |
          | button/div    |  # Acepta <button> O <div>
          | string/numero |  # Acepta texto O número
          | a/button      |  # Acepta <a> O <button>
    """
    
    if not context.table:
        raise AssertionError("Se requiere una tabla de datos para este paso")
    
    # 1. Obtener el localizador base y limpiar barras finales
    locator = context.element_locator.get_locator(identifier).rstrip('/')
    row_index = int(row_number)
    
    # 2. Construir el selector final (XPath o CSS)
    if locator.startswith('//') or locator.startswith('('):
        # Usamos /tr para que sea hijo directo de tbody y evite confusiones
        final_selector = f"{locator}/tr[{row_index}]/td"
    else:
        final_selector = f"{locator} tr:nth-child({row_index}) td"
    
    
    # 3. Localizar elementos y esperar a que estén presentes
    cells = context.page.locator(final_selector)
    
    try:
        # Esperar un máximo de 5s a que aparezca la primera celda
        cells.first.wait_for(state="attached", timeout=5000)
    except Exception:
        pass # Si falla, el AssertionError de abajo dará el detalle
    
    actual_count = cells.count()
    
    # Si detecta solo 1, veamos qué tiene adentro para diagnosticar
    if actual_count == 1:
        print(f"DEBUG - CONTENIDO UNICA CELDA: {cells.first.inner_text()}")
    print("="*60 + "\n")
    # -----------------------

    # 4. Obtener los formatos esperados de la tabla Gherkin
    expected_formats = [row['formato'].strip().lower() for row in context.table]
    
    # 5. Validar que hay suficientes celdas para los formatos esperados
    if actual_count < len(expected_formats):
        raise AssertionError(
            f"Fila {row_index}: Se esperaban validar {len(expected_formats)} columnas, "
            f"pero la tabla solo tiene {actual_count}"
        )

    # 6. Verificar cada celda contra su formato (solo las que pasaste)
    for i in range(len(expected_formats)):
        cell = cells.nth(i)
        
        # MEJORA: Intentar obtener texto de elementos internos primero
        # Buscar elementos comunes dentro de la celda
        cell_text = ""
        detected_element_type = None  # Para detectar el tipo de elemento HTML
        
        try:
            # Intentar obtener texto de elementos específicos dentro de la celda
            inner_elements = [
                'button', 'a', 'span', 'div', 'p', 'label', 
                'input', 'textarea', 'select', 'strong', 'em', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'
            ]
            
            for element_type in inner_elements:
                inner_element = cell.locator(element_type).first
                if inner_element.count() > 0:
                    detected_element_type = element_type  # Guardar el tipo detectado
                    # Para inputs, obtener el valor
                    if element_type in ['input', 'textarea']:
                        try:
                            cell_text = inner_element.input_value()
                            if cell_text:
                                break
                        except:
                            pass
                    # Para otros elementos, obtener el texto
                    try:
                        text = inner_element.inner_text().strip()
                        if text:
                            cell_text = text
                            break
                    except:
                        pass
            
            # Si no encontró texto en elementos internos, usar el texto de la celda completa
            if not cell_text:
                cell_text = cell.inner_text().strip()
                
        except Exception:
            # Fallback: usar inner_text de la celda
            cell_text = cell.inner_text().strip()
        
        expected_format = expected_formats[i]
        
        # NUEVO: Soportar múltiples formatos con separador /
        # Ejemplo: "button/div" busca button O div
        format_options = [fmt.strip() for fmt in expected_format.split('/')]
        
        # DEBUG: Ver qué formatos se están procesando
        
        is_valid = False
        error_msg = ""
        matched_format = None  # Para saber qué formato coincidió
        
        # Iterar sobre cada opción de formato (soporta formato1|formato2|formato3)
        for format_option in format_options:
            format_option_lower = format_option.lower()
            
            # VALIDACIONES DE TIPO DE ELEMENTO HTML
            if format_option_lower in ['button', 'a', 'span', 'div', 'p', 'label', 
                                   'input', 'textarea', 'select', 'strong', 'em', 
                                   'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'link']:
                # Validar que la celda contiene el tipo de elemento HTML especificado
                # Normalizar 'link' a 'a'
                element_to_check = 'a' if format_option_lower == 'link' else format_option_lower
                
                if detected_element_type == element_to_check:
                    is_valid = True
                    matched_format = format_option
                    break
                else:
                    # Verificar directamente en el DOM si no se detectó antes
                    element_exists = cell.locator(element_to_check).count() > 0
                    if element_exists:
                        is_valid = True
                        matched_format = format_option
                        break
            
            # VALIDACIONES DE FORMATO DE DATOS
            elif format_option_lower == "vacio":
                if cell_text == "":
                    is_valid = True
                    matched_format = format_option
                    break
            
            elif format_option_lower == "no_vacio":
                if cell_text != "":
                    is_valid = True
                    matched_format = format_option
                    break
            
            elif format_option_lower == "numero":
                try:
                    # Limpiar símbolos comunes de dinero o miles
                    clean_num = cell_text.replace("$", "").replace(".", "").replace(",", ".").strip()
                    float(clean_num)
                    is_valid = True
                    matched_format = format_option
                    break
                except ValueError:
                    continue
            
            elif format_option_lower in ["string", "texto"]:
                if len(cell_text) > 0:
                    is_valid = True
                    matched_format = format_option
                    break
            
            elif format_option_lower == "fecha":
                date_formats = ["%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d", "%d/%m/%y"]
                for df in date_formats:
                    try:
                        datetime.strptime(cell_text, df)
                        is_valid = True
                        matched_format = format_option
                        break
                    except ValueError:
                        continue
                if is_valid:
                    break
            
            elif format_option_lower == "email":
                if re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', cell_text) is not None:
                    is_valid = True
                    matched_format = format_option
                    break
            
            elif format_option_lower == "url":
                if cell_text.startswith(("http://", "https://")):
                    is_valid = True
                    matched_format = format_option
                    break
            
            elif format_option_lower == "cualquiera":
                # Acepta cualquier valor (solo verifica que la celda existe)
                is_valid = True
                matched_format = format_option
                break
            
            else:
                # Formato desconocido, continuar con la siguiente opción
                continue
        
        # Si ninguna opción coincidió, generar error
        if not is_valid:
            if len(format_options) > 1:
                # Múltiples opciones
                if detected_element_type:
                    error_msg = f"Se esperaba alguno de [{expected_format}], pero se encontró <{detected_element_type}> con texto '{cell_text}'"
                else:
                    error_msg = f"Se esperaba alguno de [{expected_format}], pero no coincidió ninguno. Contenido: '{cell_text}'"
            else:
                # Una sola opción
                format_option = format_options[0].lower()
                if format_option in ['button', 'a', 'span', 'div', 'p', 'label', 
                                      'input', 'textarea', 'select', 'strong', 'em', 
                                      'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'link']:
                    element_to_check = 'a' if format_option == 'link' else format_option
                    if detected_element_type:
                        error_msg = f"Se esperaba elemento <{element_to_check}>, pero se encontró <{detected_element_type}>"
                    else:
                        error_msg = f"Se esperaba elemento <{element_to_check}>, pero no se encontró ningún elemento HTML específico"
                elif format_option == "vacio":
                    error_msg = f"Se esperaba campo vacío, pero contiene '{cell_text}'"
                elif format_option == "no_vacio":
                    error_msg = f"Se esperaba campo con contenido"
                elif format_option == "numero":
                    error_msg = f"Se esperaba número, pero contiene '{cell_text}'"
                elif format_option in ["string", "texto"]:
                    error_msg = "El campo está vacío"
                elif format_option == "fecha":
                    error_msg = f"Formato de fecha inválido: '{cell_text}'"
                elif format_option == "email":
                    error_msg = f"Email inválido: '{cell_text}'"
                elif format_option == "url":
                    error_msg = f"URL inválida: '{cell_text}'"
                else:
                    # Formato desconocido
                    formatos_datos = [
                        'vacio', 'no_vacio', 'numero', 'string', 'texto', 
                        'fecha', 'email', 'url', 'cualquiera'
                    ]
                    formatos_html = [
                        'button', 'a', 'link', 'span', 'div', 'p', 'label',
                        'input', 'textarea', 'select', 'strong', 'em',
                        'h1', 'h2', 'h3', 'h4', 'h5', 'h6'
                    ]
                    raise AssertionError(
                        f"Formato configurado desconocido: '{format_option}'\n"
                        f"Formatos de datos válidos: {', '.join(formatos_datos)}\n"
                        f"Formatos de elementos HTML válidos: {', '.join(formatos_html)}\n"
                        f"Puedes combinar formatos con /, ejemplo: 'button/div'"
                    )
            
            raise AssertionError(f"Fila {row_index}, Columna {i+1}: {error_msg}")
        
        # Si coincidió, mostrar qué formato se usó (útil para debug)
        if len(format_options) > 1:
            print(f"  Columna {i+1}: Coincidió con formato '{matched_format}' de [{expected_format}]")

    print(f"✓ Fila {row_index} de '{table_name}' verificada correctamente.")    


@step('I store in variable "{variable_name}" the value of column "{column}" row "{row}" in table with identifier "{identifier}"')
@step('guardo en la variable "{variable_name}" el valor de la columna "{column}" de la fila "{row}" en la tabla con identificador "{identifier}"')
def step_store_table_cell_value(context, variable_name, column, row, identifier):
    """Guarda el valor de una celda en una variable
    
    El identificador puede ser un localizador directo o un $.ARCHIVO.elemento que incluya /tbody.
    
    Ejemplo:
        guardo en la variable "valor_celda" el valor de la columna "1" de la fila "1" en la tabla con identificador "$.KIBERPRO_ESTADO_SOL.tabla_aprobadas"
    """
    row_index = int(row)
    col_index = int(column)
    
    # Obtener el localizador (soporta $.ARCHIVO.elemento y XPath directo)
    locator = context.element_locator.get_locator(identifier).rstrip('/')
    
    # Construir el selector final (XPath o CSS)
    if locator.startswith('//') or locator.startswith('('):
        # XPath
        final_selector = f"{locator}/tr[{row_index}]/td[{col_index}]"
    else:
        # CSS
        final_selector = f"{locator} tr:nth-child({row_index}) td:nth-child({col_index})"
    
    # Obtener la celda
    cell = context.page.locator(final_selector)
    
    # Esperar a que esté presente
    try:
        cell.first.wait_for(state="attached", timeout=5000)
    except Exception:
        pass
    
    # Obtener el valor
    cell_value = cell.inner_text().strip()
    print("---- Valor de la Celda -----")
    print(cell_value)
    
    # Guardar en variable
    context.variable_manager.set_variable(variable_name, cell_value)
    
    print(f"✓ Valor guardado en variable '{variable_name}': {cell_value}")

@step('I edit table cell at row "{row}" column "{column}" with value "{new_value}" in table "{table_name}" with identifier "{identifier}"')
@step('edito la celda de la fila "{row}" columna "{column}" con valor "{new_value}" en la tabla "{table_name}" con identificador "{identifier}"')
def step_edit_table_cell(context, row, column, new_value, table_name, identifier):
    """Edita el valor de una celda de la tabla"""
    locator = context.element_locator.get_locator(identifier)
    row_index = int(row)
    col_index = int(column)
    resolved_value = context.variable_manager.resolve_variables(new_value)
    
    # Hacer doble click en la celda para editarla
    cell = context.page.locator(f'{locator} tbody tr:nth-child({row_index}) td:nth-child({col_index})')
    cell.dblclick()
    
    # Buscar campo de edición
    edit_selectors = [
        f'{locator} tbody tr:nth-child({row_index}) td:nth-child({col_index}) input',
        f'{locator} tbody tr:nth-child({row_index}) td:nth-child({col_index}) textarea',
        f'{locator} .edit-cell input',
        f'{locator} .editable input'
    ]
    
    edit_found = False
    for selector in edit_selectors:
        edit_field = context.page.locator(selector)
        if edit_field.count() > 0:
            edit_field.first.fill(resolved_value)
            edit_field.first.press('Enter')
            edit_found = True
            break
    
    if not edit_found:
        # Intentar edición directa si la celda es contenteditable
        if cell.get_attribute('contenteditable'):
            cell.fill(resolved_value)
        else:
            raise AssertionError("No se pudo editar la celda")

@step('I export table "{table_name}" data and store in variable "{variable_name}" with identifier "{identifier}"')
@step('exporto los datos de la tabla "{table_name}" y los guardo en la variable "{variable_name}" con identificador "{identifier}"')
def step_export_table_data(context, table_name, variable_name, identifier):
    """Exporta todos los datos de la tabla como lista de diccionarios"""
    locator = context.element_locator.get_locator(identifier)
    
    # Obtener headers
    headers = context.page.locator(f'{locator} thead th, {locator} tr:first-child th')
    header_texts = []
    for i in range(headers.count()):
        header_text = headers.nth(i).text_content().strip()
        header_texts.append(header_text)
    
    # Obtener filas de datos
    rows = context.page.locator(f'{locator} tbody tr')
    table_data = []
    
    for i in range(rows.count()):
        row = rows.nth(i)
        cells = row.locator('td')
        row_data = {}
        
        for j in range(min(cells.count(), len(header_texts))):
            cell_text = cells.nth(j).text_content().strip()
            row_data[header_texts[j]] = cell_text
        
        table_data.append(row_data)
    
    # Guardar en variable
    context.variable_manager.set_variable(variable_name, table_data)
