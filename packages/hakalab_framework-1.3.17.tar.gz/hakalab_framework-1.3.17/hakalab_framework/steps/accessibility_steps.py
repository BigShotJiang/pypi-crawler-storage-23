#!/usr/bin/env python3
"""
Steps para validaciones de accesibilidad web
Incluye verificaciones ARIA, navegación por teclado y estándares de accesibilidad
"""
from behave import step
from playwright.sync_api import expect

@step('I verify element "{element_name}" has ARIA label "{expected_label}" with identifier "{identifier}"')
@step('verifico que el elemento "{element_name}" tiene etiqueta ARIA "{expected_label}" con identificador "{identifier}"')
def step_verify_aria_label(context, element_name, expected_label, identifier):
    """Verifica que un elemento tiene una etiqueta ARIA específica"""
    locator = context.element_locator.get_locator(identifier)
    resolved_label = context.variable_manager.resolve_variables(expected_label)
    
    element = context.page.locator(locator)
    aria_label = element.get_attribute('aria-label')
    
    assert aria_label == resolved_label, f"ARIA label es '{aria_label}', esperado '{resolved_label}'"

@step('I verify element "{element_name}" has ARIA role "{expected_role}" with identifier "{identifier}"')
@step('verifico que el elemento "{element_name}" tiene rol ARIA "{expected_role}" con identificador "{identifier}"')
def step_verify_aria_role(context, element_name, expected_role, identifier):
    """Verifica que un elemento tiene un rol ARIA específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_role = context.variable_manager.resolve_variables(expected_role)
    
    element = context.page.locator(locator)
    aria_role = element.get_attribute('role')
    
    assert aria_role == resolved_role, f"ARIA role es '{aria_role}', esperado '{resolved_role}'"

@step('I verify element "{element_name}" is accessible by keyboard with identifier "{identifier}"')
@step('verifico que el elemento "{element_name}" es accesible por teclado con identificador "{identifier}"')
def step_verify_keyboard_accessible(context, element_name, identifier):
    """Verifica que un elemento es accesible por teclado"""
    locator = context.element_locator.get_locator(identifier)
    
    element = context.page.locator(locator)
    
    # Verificar que el elemento puede recibir foco
    element.focus()
    expect(element).to_be_focused()
    
    # Verificar que tiene tabindex apropiado (no negativo)
    tabindex = element.get_attribute('tabindex')
    if tabindex is not None:
        tabindex_value = int(tabindex)
        assert tabindex_value >= 0, f"Elemento tiene tabindex negativo ({tabindex_value}), no es accesible por teclado"

@step('I verify element "{element_name}" has alt text "{expected_alt}" with identifier "{identifier}"')
@step('verifico que el elemento "{element_name}" tiene texto alt "{expected_alt}" con identificador "{identifier}"')
def step_verify_alt_text(context, element_name, expected_alt, identifier):
    """Verifica que una imagen tiene texto alternativo específico"""
    locator = context.element_locator.get_locator(identifier)
    resolved_alt = context.variable_manager.resolve_variables(expected_alt)
    
    element = context.page.locator(locator)
    alt_text = element.get_attribute('alt')
    
    assert alt_text == resolved_alt, f"Texto alt es '{alt_text}', esperado '{resolved_alt}'"

@step('I verify element "{element_name}" has proper heading hierarchy with identifier "{identifier}"')
@step('verifico que el elemento "{element_name}" tiene jerarquía de encabezados correcta con identificador "{identifier}"')
def step_verify_heading_hierarchy(context, element_name, identifier):
    """Verifica que los encabezados siguen una jerarquía correcta"""
    locator = context.element_locator.get_locator(identifier)
    
    # Obtener todos los encabezados en la página
    headings = context.page.locator('h1, h2, h3, h4, h5, h6').all()
    
    previous_level = 0
    for heading in headings:
        tag_name = heading.evaluate("element => element.tagName.toLowerCase()")
        current_level = int(tag_name[1])  # Extraer número del h1, h2, etc.
        
        # Verificar que no se salte más de un nivel
        if previous_level > 0:
            assert current_level <= previous_level + 1, f"Jerarquía de encabezados incorrecta: salto de h{previous_level} a h{current_level}"
        
        previous_level = current_level

@step('I verify form has proper labels for all inputs')
@step('verifico que el formulario tiene etiquetas apropiadas para todos los campos')
def step_verify_form_labels(context):
    """Verifica que todos los campos de formulario tienen etiquetas apropiadas"""
    # Obtener todos los inputs, selects y textareas
    form_elements = context.page.locator('input, select, textarea').all()
    
    for element in form_elements:
        element_id = element.get_attribute('id')
        element_name = element.get_attribute('name')
        aria_label = element.get_attribute('aria-label')
        aria_labelledby = element.get_attribute('aria-labelledby')
        
        # Verificar que tiene alguna forma de etiqueta
        has_label = False
        
        if aria_label or aria_labelledby:
            has_label = True
        elif element_id:
            # Buscar label asociado por 'for'
            label = context.page.locator(f'label[for="{element_id}"]')
            if label.count() > 0:
                has_label = True
        
        # También verificar si está dentro de un label
        parent_label = element.locator('xpath=ancestor::label')
        if parent_label.count() > 0:
            has_label = True
        
        assert has_label, f"Campo de formulario sin etiqueta apropiada: {element_name or element_id or 'elemento sin identificar'}"

@step('I verify element "{element_name}" has sufficient color contrast with identifier "{identifier}"')
@step('verifico que el elemento "{element_name}" tiene contraste de color suficiente con identificador "{identifier}"')
def step_verify_color_contrast(context, element_name, identifier):
    """Verifica que un elemento tiene contraste de color suficiente"""
    locator = context.element_locator.get_locator(identifier)
    
    element = context.page.locator(locator)
    
    # Obtener colores del elemento
    colors = element.evaluate("""
        element => {
            const style = getComputedStyle(element);
            return {
                color: style.color,
                backgroundColor: style.backgroundColor
            };
        }
    """)
    
    # Función básica para calcular contraste (simplificada)
    def get_luminance(rgb_string):
        """Extrae valores RGB y calcula luminancia básica"""
        if not rgb_string or rgb_string == 'rgba(0, 0, 0, 0)':
            return 1  # Transparente, asumir blanco
        
        import re
        rgb_values = re.findall(r'\d+', rgb_string)
        if len(rgb_values) >= 3:
            r, g, b = [int(x) / 255.0 for x in rgb_values[:3]]
            return 0.299 * r + 0.587 * g + 0.114 * b
        return 0.5  # Valor por defecto
    
    text_luminance = get_luminance(colors['color'])
    bg_luminance = get_luminance(colors['backgroundColor'])
    
    # Calcular ratio de contraste básico
    if text_luminance > bg_luminance:
        contrast_ratio = (text_luminance + 0.05) / (bg_luminance + 0.05)
    else:
        contrast_ratio = (bg_luminance + 0.05) / (text_luminance + 0.05)
    
    # WCAG AA requiere al menos 4.5:1 para texto normal
    assert contrast_ratio >= 4.5, f"Contraste insuficiente: {contrast_ratio:.2f}:1, mínimo requerido 4.5:1"

@step('I verify page has proper document structure')
@step('verifico que la página tiene estructura de documento apropiada')
def step_verify_document_structure(context):
    """Verifica que la página tiene una estructura de documento apropiada"""
    # Verificar que hay un título
    title = context.page.title()
    assert title and len(title.strip()) > 0, "Página no tiene título"
    
    # Verificar que hay al menos un h1
    h1_elements = context.page.locator('h1')
    assert h1_elements.count() >= 1, "Página no tiene encabezado h1"
    
    # Verificar que no hay más de un h1
    assert h1_elements.count() == 1, f"Página tiene {h1_elements.count()} encabezados h1, debería tener solo uno"
    
    # Verificar que hay elementos de navegación principales
    nav_elements = context.page.locator('nav, [role="navigation"]')
    main_elements = context.page.locator('main, [role="main"]')
    
    # Al menos debería haber contenido principal
    assert main_elements.count() >= 1, "Página no tiene elemento main o role='main'"

@step('I verify element "{element_name}" is announced by screen reader with identifier "{identifier}"')
@step('verifico que el elemento "{element_name}" es anunciado por lector de pantalla con identificador "{identifier}"')
def step_verify_screen_reader_announcement(context, element_name, identifier):
    """Verifica que un elemento será anunciado apropiadamente por lectores de pantalla"""
    locator = context.element_locator.get_locator(identifier)
    
    element = context.page.locator(locator)
    
    # Verificar que el elemento es visible o tiene contenido accesible
    is_visible = element.is_visible()
    aria_hidden = element.get_attribute('aria-hidden')
    
    if not is_visible:
        # Si no es visible, debe tener contenido accesible
        aria_label = element.get_attribute('aria-label')
        text_content = element.text_content()
        
        assert aria_label or text_content, f"Elemento '{element_name}' no es visible y no tiene contenido accesible"
    
    # Verificar que no está oculto para lectores de pantalla
    assert aria_hidden != 'true', f"Elemento '{element_name}' está oculto para lectores de pantalla (aria-hidden='true')"

@step('I verify interactive elements have focus indicators')
@step('verifico que los elementos interactivos tienen indicadores de foco')
def step_verify_focus_indicators(context):
    """Verifica que los elementos interactivos tienen indicadores de foco visibles"""
    # Elementos interactivos comunes
    interactive_selectors = [
        'button', 'a[href]', 'input', 'select', 'textarea',
        '[tabindex]:not([tabindex="-1"])', '[role="button"]'
    ]
    
    for selector in interactive_selectors:
        elements = context.page.locator(selector).all()
        
        for element in elements:
            if element.is_visible():
                # Hacer foco en el elemento
                element.focus()
                
                # Verificar que tiene algún indicador de foco
                focus_styles = element.evaluate("""
                    element => {
                        const style = getComputedStyle(element);
                        return {
                            outline: style.outline,
                            outlineWidth: style.outlineWidth,
                            boxShadow: style.boxShadow,
                            border: style.border
                        };
                    }
                """)
                
                has_focus_indicator = (
                    focus_styles['outline'] != 'none' or
                    focus_styles['outlineWidth'] != '0px' or
                    'inset' in focus_styles['boxShadow'] or
                    focus_styles['boxShadow'] != 'none'
                )
                
                # Nota: Esta es una verificación básica, en producción se podría hacer más sofisticada
                if not has_focus_indicator:
                    print(f"⚠️ Elemento interactivo puede no tener indicador de foco visible: {selector}")

@step('I verify element "{element_name}" has descriptive link text with identifier "{identifier}"')
@step('verifico que el elemento "{element_name}" tiene texto de enlace descriptivo con identificador "{identifier}"')
def step_verify_descriptive_link_text(context, element_name, identifier):
    """Verifica que un enlace tiene texto descriptivo (no genérico)"""
    locator = context.element_locator.get_locator(identifier)
    
    element = context.page.locator(locator)
    link_text = element.text_content().strip().lower()
    
    # Textos genéricos que no son descriptivos
    generic_texts = [
        'click here', 'haz click aquí', 'aquí', 'here', 'more', 'más',
        'read more', 'leer más', 'continue', 'continuar', 'next', 'siguiente'
    ]
    
    assert link_text not in generic_texts, f"Enlace tiene texto genérico no descriptivo: '{link_text}'"
    assert len(link_text) > 2, f"Texto del enlace es demasiado corto: '{link_text}'"

@step('I verify images have appropriate alt text')
@step('verifico que las imágenes tienen texto alternativo apropiado')
def step_verify_images_alt_text(context):
    """Verifica que todas las imágenes tienen texto alternativo apropiado"""
    images = context.page.locator('img').all()
    
    for img in images:
        alt_text = img.get_attribute('alt')
        src = img.get_attribute('src')
        
        # Todas las imágenes deben tener atributo alt (puede estar vacío para decorativas)
        assert alt_text is not None, f"Imagen sin atributo alt: {src}"
        
        # Si tiene contenido, verificar que no sea solo el nombre del archivo
        if alt_text and len(alt_text.strip()) > 0:
            # No debería ser solo el nombre del archivo
            filename_patterns = ['.jpg', '.jpeg', '.png', '.gif', '.svg', '.webp']
            is_filename = any(pattern in alt_text.lower() for pattern in filename_patterns)
            assert not is_filename, f"Texto alt parece ser nombre de archivo: '{alt_text}'"