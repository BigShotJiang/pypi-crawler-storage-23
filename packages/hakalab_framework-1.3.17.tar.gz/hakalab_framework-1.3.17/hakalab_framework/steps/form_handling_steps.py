"""
Steps avanzados para manejo de formularios
Incluye validación, envío, reseteo y manipulación compleja de formularios
"""

from behave import step


def _get_element(context, selector, dynamic_value=None):
    """
    Función auxiliar para obtener elementos.
    Soporta tanto selectores CSS como identificadores JSON ($.ARCHIVO.elemento)
    Soporta placeholders dinámicos: $.ARCHIVO.elemento=valor
    Soporta iframes: Si context.current_frame existe, busca dentro del iframe
    """
    # Determinar si estamos dentro de un iframe
    page_or_frame = getattr(context, 'current_frame', None) or context.page
    
    if selector.startswith('$.') and hasattr(context, 'element_locator'):
        return context.element_locator.find(page_or_frame, selector, dynamic_value)
    else:
        return page_or_frame.locator(selector)

import time
import json

@step('I submit form "{form_name}" with identifier "{identifier}"')
@step('envío el formulario "{form_name}" con identificador "{identifier}"')
def step_submit_form(context, form_name, identifier):
    """Envía un formulario específico"""
    locator = context.element_locator.get_locator(identifier)
    
    form = context.page.locator(locator)
    form.evaluate("form => form.submit()")
    
    print(f"✓ Formulario '{form_name}' enviado")

@step('I reset form "{form_name}" with identifier "{identifier}"')
@step('reseteo el formulario "{form_name}" con identificador "{identifier}"')
def step_reset_form(context, form_name, identifier):
    """Resetea un formulario a sus valores por defecto"""
    locator = context.element_locator.get_locator(identifier)
    
    form = context.page.locator(locator)
    form.evaluate("form => form.reset()")
    
    print(f"✓ Formulario '{form_name}' reseteado")

@step('I fill form with data from variable "{data_variable}" for form "{form_name}" with identifier "{identifier}"')
@step('relleno el formulario con datos de la variable "{data_variable}" para formulario "{form_name}" con identificador "{identifier}"')
def step_fill_form_with_data(context, data_variable, form_name, identifier):
    """Rellena un formulario con datos de una variable JSON"""
    form_locator = context.element_locator.get_locator(identifier)
    
    # Obtener datos de la variable
    data_json = context.variable_manager.get_variable(data_variable)
    try:
        form_data = json.loads(data_json)
    except:
        form_data = json.loads(f'"{data_json}"') if isinstance(data_json, str) else data_json
    
    # Rellenar cada campo
    for field_name, value in form_data.items():
        try:
            # Intentar diferentes selectores para el campo
            selectors = [
                f"input[name='{field_name}']",
                f"select[name='{field_name}']",
                f"textarea[name='{field_name}']",
                f"#{field_name}",
                f".{field_name}"
            ]
            
            for selector in selectors:
                try:
                    element = context.page.locator(f"{form_locator} {selector}")
                    if element.count() > 0:
                        element_type = element.evaluate("el => el.tagName.toLowerCase()")
                        
                        if element_type == 'select':
                            element.select_option(str(value))
                        elif element_type in ['input', 'textarea']:
                            element.fill(str(value))
                        
                        print(f"  ✓ Campo '{field_name}' rellenado con '{value}'")
                        break
                except:
                    continue
        except Exception as e:
            print(f"  ⚠ No se pudo rellenar el campo '{field_name}': {e}")
    
    print(f"✓ Formulario '{form_name}' rellenado con datos")

@step('I get form data and store in variable "{variable_name}" for form "{form_name}" with identifier "{identifier}"')
@step('obtengo los datos del formulario y los guardo en la variable "{variable_name}" para formulario "{form_name}" con identificador "{identifier}"')
def step_get_form_data(context, variable_name, form_name, identifier):
    """Extrae todos los datos de un formulario y los guarda como JSON"""
    locator = context.element_locator.get_locator(identifier)
    
    form_data = context.page.evaluate(f"""
        const form = document.querySelector('{locator}');
        const formData = new FormData(form);
        const data = {{}};
        for (let [key, value] of formData.entries()) {{
            data[key] = value;
        }}
        return JSON.stringify(data);
    """)
    
    context.variable_manager.set_variable(variable_name, form_data)
    print(f"✓ Datos del formulario '{form_name}' guardados en variable '{variable_name}'")

@step('I validate form "{form_name}" with identifier "{identifier}"')
@step('valido el formulario "{form_name}" con identificador "{identifier}"')
def step_validate_form(context, form_name, identifier):
    """Valida un formulario usando la validación HTML5 nativa"""
    locator = context.element_locator.get_locator(identifier)
    
    is_valid = context.page.evaluate(f"""
        const form = document.querySelector('{locator}');
        return form.checkValidity();
    """)
    
    if is_valid:
        print(f"✓ Formulario '{form_name}' es válido")
    else:
        print(f"✗ Formulario '{form_name}' tiene errores de validación")
        raise AssertionError(f"Formulario '{form_name}' no es válido")

@step('I check required fields in form "{form_name}" with identifier "{identifier}"')
@step('verifico los campos requeridos en el formulario "{form_name}" con identificador "{identifier}"')
def step_check_required_fields(context, form_name, identifier):
    """Verifica que todos los campos requeridos estén completados"""
    locator = context.element_locator.get_locator(identifier)
    
    empty_required = context.page.evaluate(f"""
        const form = document.querySelector('{locator}');
        const requiredFields = form.querySelectorAll('[required]');
        const emptyFields = [];
        
        requiredFields.forEach(field => {{
            if (!field.value.trim()) {{
                emptyFields.push(field.name || field.id || field.className);
            }}
        }});
        
        return emptyFields;
    """)
    
    if empty_required:
        print(f"✗ Campos requeridos vacíos: {', '.join(empty_required)}")
        raise AssertionError(f"Campos requeridos vacíos en formulario '{form_name}': {', '.join(empty_required)}")
    else:
        print(f"✓ Todos los campos requeridos están completados en formulario '{form_name}'")

@step('I set form field "{field_name}" to readonly in form "{form_name}" with form identifier "{form_id}" and field identifier "{field_id}"')
@step('establezco el campo "{field_name}" como solo lectura en formulario "{form_name}" con identificador de formulario "{form_id}" y identificador de campo "{field_id}"')
def step_set_field_readonly(context, field_name, form_name, form_id, field_id):
    """Establece un campo como solo lectura"""
    field_locator = context.element_locator.get_locator(field_id)
    
    context.page.evaluate(f"""
        const field = document.querySelector('{field_locator}');
        field.readOnly = true;
    """)
    
    print(f"✓ Campo '{field_name}' establecido como solo lectura")

@step('I enable form field "{field_name}" in form "{form_name}" with form identifier "{form_id}" and field identifier "{field_id}"')
@step('habilito el campo "{field_name}" en formulario "{form_name}" con identificador de formulario "{form_id}" y identificador de campo "{field_id}"')
def step_enable_field(context, field_name, form_name, form_id, field_id):
    """Habilita un campo de formulario"""
    field_locator = context.element_locator.get_locator(field_id)
    
    context.page.evaluate(f"""
        const field = document.querySelector('{field_locator}');
        field.disabled = false;
        field.readOnly = false;
    """)
    
    print(f"✓ Campo '{field_name}' habilitado")

@step('I disable form field "{field_name}" in form "{form_name}" with form identifier "{form_id}" and field identifier "{field_id}"')
@step('deshabilito el campo "{field_name}" en formulario "{form_name}" con identificador de formulario "{form_id}" y identificador de campo "{field_id}"')
def step_disable_field(context, field_name, form_name, form_id, field_id):
    """Deshabilita un campo de formulario"""
    field_locator = context.element_locator.get_locator(field_id)
    
    context.page.evaluate(f"""
        const field = document.querySelector('{field_locator}');
        field.disabled = true;
    """)
    
    print(f"✓ Campo '{field_name}' deshabilitado")

@step('I auto-fill form "{form_name}" with test data using identifier "{identifier}"')
@step('auto-relleno el formulario "{form_name}" con datos de prueba usando identificador "{identifier}"')
def step_auto_fill_form(context, form_name, identifier):
    """Auto-rellena un formulario con datos de prueba comunes"""
    locator = context.element_locator.get_locator(identifier)
    
    # Datos de prueba por defecto
    test_data = {
        'email': 'test@example.com',
        'name': 'Test User',
        'firstname': 'Test',
        'lastname': 'User',
        'phone': '+1234567890',
        'address': '123 Test Street',
        'city': 'Test City',
        'zipcode': '12345',
        'country': 'Test Country'
    }
    
    context.page.evaluate(f"""
        const form = document.querySelector('{locator}');
        const testData = {json.dumps(test_data)};
        
        Object.keys(testData).forEach(key => {{
            const selectors = [
                `input[name*="${{key}}"]`,
                `input[id*="${{key}}"]`,
                `select[name*="${{key}}"]`,
                `textarea[name*="${{key}}"]`
            ];
            
            selectors.forEach(selector => {{
                const elements = form.querySelectorAll(selector);
                elements.forEach(element => {{
                    if (element.type === 'email' && key === 'email') {{
                        element.value = testData[key];
                    }} else if (element.tagName === 'SELECT') {{
                        // Seleccionar primera opción válida
                        if (element.options.length > 1) {{
                            element.selectedIndex = 1;
                        }}
                    }} else if (element.type !== 'hidden' && element.type !== 'submit') {{
                        element.value = testData[key];
                    }}
                }});
            }});
        }});
    """)
    
    print(f"✓ Formulario '{form_name}' auto-rellenado con datos de prueba")

@step('I clear all form fields in form "{form_name}" with identifier "{identifier}"')
@step('limpio todos los campos del formulario "{form_name}" con identificador "{identifier}"')
def step_clear_all_form_fields(context, form_name, identifier):
    """Limpia todos los campos de un formulario"""
    locator = context.element_locator.get_locator(identifier)
    
    context.page.evaluate(f"""
        const form = document.querySelector('{locator}');
        const fields = form.querySelectorAll('input, select, textarea');
        
        fields.forEach(field => {{
            if (field.type === 'checkbox' || field.type === 'radio') {{
                field.checked = false;
            }} else if (field.tagName === 'SELECT') {{
                field.selectedIndex = 0;
            }} else if (field.type !== 'hidden' && field.type !== 'submit') {{
                field.value = '';
            }}
        }});
    """)
    
    print(f"✓ Todos los campos del formulario '{form_name}' limpiados")