#!/usr/bin/env python3
"""
Steps avanzados para validación semántica con IA
Incluye: análisis de sentimiento, clasificación, detección de idioma, y más
"""
from behave import step, given, when, then
import logging

logger = logging.getLogger(__name__)


# ==========================================
# ANÁLISIS DE SENTIMIENTO
# ==========================================

@then('el sentimiento del texto "{text}" debe ser "{expected_sentiment}"')
def step_verify_text_sentiment(context, text, expected_sentiment):
    """
    Analiza el sentimiento de un texto y verifica que coincida con el esperado.
    
    Sentimientos válidos: positivo, negativo, neutral
    
    Ejemplo:
        Then el sentimiento del texto "Me encanta este producto" debe ser "positivo"
        Then el sentimiento del texto "Esto es terrible" debe ser "negativo"
    
    Args:
        text: Texto a analizar
        expected_sentiment: Sentimiento esperado (positivo/negativo/neutral)
    """
    from sentence_transformers import util
    
    _ensure_semantic_config(context)
    
    # Resolver variables
    text = context.variable_manager.resolve_variables(text)
    expected_sentiment = expected_sentiment.lower()
    
    if expected_sentiment not in ['positivo', 'negativo', 'neutral']:
        raise ValueError(f"Sentimiento inválido: {expected_sentiment}. Usa: positivo, negativo, neutral")
    
    # Textos de referencia para cada sentimiento
    sentiment_references = {
        'positivo': "Excelente, maravilloso, fantástico, me encanta, perfecto, increíble",
        'negativo': "Terrible, horrible, pésimo, odio, malo, desastre",
        'neutral': "Normal, regular, está bien, aceptable, estándar"
    }
    
    # Calcular similitud con cada sentimiento
    similarities = {}
    for sentiment, reference in sentiment_references.items():
        vec_text = context.semantic_model.encode(text, convert_to_tensor=True)
        vec_ref = context.semantic_model.encode(reference, convert_to_tensor=True)
        similarity = util.cos_sim(vec_text, vec_ref).item()
        similarities[sentiment] = similarity
    
    # Determinar el sentimiento detectado
    detected_sentiment = max(similarities, key=similarities.get)
    confidence = similarities[detected_sentiment]
    
    # Logging
    logger.info(f"📝 Texto analizado: {text}")
    logger.info(f"🎭 Sentimiento esperado: {expected_sentiment}")
    logger.info(f"🎭 Sentimiento detectado: {detected_sentiment}")
    logger.info(f"📊 Confianza: {confidence:.4f}")
    logger.info(f"📊 Similitudes: {similarities}")
    
    print(f"\n{'='*60}")
    print(f"🎭 Análisis de Sentimiento")
    print(f"{'='*60}")
    print(f"Texto:               {text}")
    print(f"Sentimiento esperado: {expected_sentiment}")
    print(f"Sentimiento detectado: {detected_sentiment}")
    print(f"Confianza:           {confidence:.4f}")
    print(f"Similitudes:")
    for sent, sim in similarities.items():
        marker = "✓" if sent == detected_sentiment else " "
        print(f"  {marker} {sent}: {sim:.4f}")
    
    if detected_sentiment == expected_sentiment:
        print(f"✅ PASS - Sentimiento correcto")
        print(f"{'='*60}\n")
    else:
        print(f"❌ FAIL - Sentimiento incorrecto")
        print(f"{'='*60}\n")
        raise AssertionError(
            f"Sentimiento incorrecto.\n"
            f"Esperado: {expected_sentiment}\n"
            f"Detectado: {detected_sentiment}\n"
            f"Confianza: {confidence:.4f}\n"
            f"Texto: {text}"
        )


@then('el sentimiento de la variable "{var_name}" debe ser "{expected_sentiment}"')
def step_verify_variable_sentiment(context, var_name, expected_sentiment):
    """
    Analiza el sentimiento del texto en una variable.
    
    Ejemplo:
        Then el sentimiento de la variable "comentario_usuario" debe ser "positivo"
    
    Args:
        var_name: Nombre de la variable
        expected_sentiment: Sentimiento esperado (positivo/negativo/neutral)
    """
    text = context.variable_manager.get_variable(var_name)
    if not text:
        raise ValueError(f"La variable '{var_name}' no existe o está vacía")
    
    context.execute_steps(f'''
        Then el sentimiento del texto "{text}" debe ser "{expected_sentiment}"
    ''')


# ==========================================
# CLASIFICACIÓN DE TEXTO
# ==========================================

@then('clasifico el texto "{text}" en las categorías "{categories}" y guardo el resultado en "{var_name}"')
def step_classify_text(context, text, categories, var_name):
    """
    Clasifica un texto en una de las categorías proporcionadas.
    
    Ejemplo:
        Then clasifico el texto "No se pudo procesar el pago" en las categorías "error,éxito,advertencia" y guardo el resultado en "categoria"
    
    Args:
        text: Texto a clasificar
        categories: Categorías separadas por comas
        var_name: Variable donde guardar la categoría detectada
    """
    from sentence_transformers import util
    
    _ensure_semantic_config(context)
    
    # Resolver variables
    text = context.variable_manager.resolve_variables(text)
    
    # Parsear categorías
    category_list = [cat.strip() for cat in categories.split(',')]
    
    if len(category_list) < 2:
        raise ValueError("Debes proporcionar al menos 2 categorías separadas por comas")
    
    # Calcular similitud con cada categoría
    vec_text = context.semantic_model.encode(text, convert_to_tensor=True)
    
    similarities = {}
    for category in category_list:
        vec_cat = context.semantic_model.encode(category, convert_to_tensor=True)
        similarity = util.cos_sim(vec_text, vec_cat).item()
        similarities[category] = similarity
    
    # Determinar la categoría más similar
    detected_category = max(similarities, key=similarities.get)
    confidence = similarities[detected_category]
    
    # Guardar resultado
    context.variable_manager.set_variable(var_name, detected_category)
    context.variable_manager.set_variable(f"{var_name}_confidence", str(confidence))
    
    # Logging
    logger.info(f"📝 Texto clasificado: {text}")
    logger.info(f"📂 Categorías: {category_list}")
    logger.info(f"📂 Categoría detectada: {detected_category}")
    logger.info(f"📊 Confianza: {confidence:.4f}")
    
    print(f"\n{'='*60}")
    print(f"📂 Clasificación de Texto")
    print(f"{'='*60}")
    print(f"Texto:              {text}")
    print(f"Categorías:         {', '.join(category_list)}")
    print(f"Categoría detectada: {detected_category}")
    print(f"Confianza:          {confidence:.4f}")
    print(f"Similitudes:")
    for cat, sim in sorted(similarities.items(), key=lambda x: x[1], reverse=True):
        marker = "✓" if cat == detected_category else " "
        print(f"  {marker} {cat}: {sim:.4f}")
    print(f"💾 Guardado en: {var_name}")
    print(f"{'='*60}\n")


@then('el texto "{text}" debe pertenecer a la categoría "{expected_category}" de "{categories}"')
def step_verify_text_category(context, text, expected_category, categories):
    """
    Verifica que un texto pertenezca a una categoría específica.
    
    Ejemplo:
        Then el texto "Error al procesar" debe pertenecer a la categoría "error" de "error,éxito,advertencia"
    
    Args:
        text: Texto a clasificar
        expected_category: Categoría esperada
        categories: Todas las categorías posibles separadas por comas
    """
    from sentence_transformers import util
    
    _ensure_semantic_config(context)
    
    # Resolver variables
    text = context.variable_manager.resolve_variables(text)
    
    # Parsear categorías
    category_list = [cat.strip() for cat in categories.split(',')]
    
    if expected_category not in category_list:
        raise ValueError(f"La categoría esperada '{expected_category}' no está en la lista de categorías")
    
    # Calcular similitud con cada categoría
    vec_text = context.semantic_model.encode(text, convert_to_tensor=True)
    
    similarities = {}
    for category in category_list:
        vec_cat = context.semantic_model.encode(category, convert_to_tensor=True)
        similarity = util.cos_sim(vec_text, vec_cat).item()
        similarities[category] = similarity
    
    # Determinar la categoría más similar
    detected_category = max(similarities, key=similarities.get)
    confidence = similarities[detected_category]
    
    # Logging
    logger.info(f"📝 Texto: {text}")
    logger.info(f"📂 Categoría esperada: {expected_category}")
    logger.info(f"📂 Categoría detectada: {detected_category}")
    logger.info(f"📊 Confianza: {confidence:.4f}")
    
    print(f"\n{'='*60}")
    print(f"📂 Verificación de Categoría")
    print(f"{'='*60}")
    print(f"Texto:               {text}")
    print(f"Categoría esperada:  {expected_category}")
    print(f"Categoría detectada: {detected_category}")
    print(f"Confianza:           {confidence:.4f}")
    print(f"Similitudes:")
    for cat, sim in sorted(similarities.items(), key=lambda x: x[1], reverse=True):
        marker = "✓" if cat == detected_category else " "
        print(f"  {marker} {cat}: {sim:.4f}")
    
    if detected_category == expected_category:
        print(f"✅ PASS - Categoría correcta")
        print(f"{'='*60}\n")
    else:
        print(f"❌ FAIL - Categoría incorrecta")
        print(f"{'='*60}\n")
        raise AssertionError(
            f"Categoría incorrecta.\n"
            f"Esperada: {expected_category}\n"
            f"Detectada: {detected_category}\n"
            f"Confianza: {confidence:.4f}\n"
            f"Texto: {text}"
        )


# ==========================================
# DETECCIÓN DE IDIOMA
# ==========================================

@then('detecto el idioma del texto "{text}" y lo guardo en "{var_name}"')
def step_detect_language(context, text, var_name):
    """
    Detecta el idioma de un texto usando similitud semántica.
    
    Ejemplo:
        Then detecto el idioma del texto "Hello world" y lo guardo en "idioma"
    
    Args:
        text: Texto a analizar
        var_name: Variable donde guardar el idioma detectado
    """
    from sentence_transformers import util
    
    _ensure_semantic_config(context)
    
    # Resolver variables
    text = context.variable_manager.resolve_variables(text)
    
    # Textos de referencia para cada idioma
    language_references = {
        'español': "Hola, buenos días, gracias, por favor, cómo estás",
        'inglés': "Hello, good morning, thank you, please, how are you",
        'portugués': "Olá, bom dia, obrigado, por favor, como está",
        'francés': "Bonjour, merci, s'il vous plaît, comment allez-vous",
        'alemán': "Hallo, guten Morgen, danke, bitte, wie geht es dir"
    }
    
    # Calcular similitud con cada idioma
    vec_text = context.semantic_model.encode(text, convert_to_tensor=True)
    
    similarities = {}
    for language, reference in language_references.items():
        vec_ref = context.semantic_model.encode(reference, convert_to_tensor=True)
        similarity = util.cos_sim(vec_text, vec_ref).item()
        similarities[language] = similarity
    
    # Determinar el idioma detectado
    detected_language = max(similarities, key=similarities.get)
    confidence = similarities[detected_language]
    
    # Guardar resultado
    context.variable_manager.set_variable(var_name, detected_language)
    context.variable_manager.set_variable(f"{var_name}_confidence", str(confidence))
    
    # Logging
    logger.info(f"📝 Texto analizado: {text}")
    logger.info(f"🌍 Idioma detectado: {detected_language}")
    logger.info(f"📊 Confianza: {confidence:.4f}")
    
    print(f"\n{'='*60}")
    print(f"🌍 Detección de Idioma")
    print(f"{'='*60}")
    print(f"Texto:            {text}")
    print(f"Idioma detectado: {detected_language}")
    print(f"Confianza:        {confidence:.4f}")
    print(f"Similitudes:")
    for lang, sim in sorted(similarities.items(), key=lambda x: x[1], reverse=True):
        marker = "✓" if lang == detected_language else " "
        print(f"  {marker} {lang}: {sim:.4f}")
    print(f"💾 Guardado en: {var_name}")
    print(f"{'='*60}\n")


@then('el idioma del texto "{text}" debe ser "{expected_language}"')
def step_verify_text_language(context, text, expected_language):
    """
    Verifica que un texto esté en el idioma esperado.
    
    Ejemplo:
        Then el idioma del texto "Hello world" debe ser "inglés"
    
    Args:
        text: Texto a analizar
        expected_language: Idioma esperado (español, inglés, portugués, francés, alemán)
    """
    from sentence_transformers import util
    
    _ensure_semantic_config(context)
    
    # Resolver variables
    text = context.variable_manager.resolve_variables(text)
    expected_language = expected_language.lower()
    
    # Textos de referencia para cada idioma
    language_references = {
        'español': "Hola, buenos días, gracias, por favor, cómo estás",
        'inglés': "Hello, good morning, thank you, please, how are you",
        'portugués': "Olá, bom dia, obrigado, por favor, como está",
        'francés': "Bonjour, merci, s'il vous plaît, comment allez-vous",
        'alemán': "Hallo, guten Morgen, danke, bitte, wie geht es dir"
    }
    
    if expected_language not in language_references:
        raise ValueError(f"Idioma no soportado: {expected_language}. Usa: español, inglés, portugués, francés, alemán")
    
    # Calcular similitud con cada idioma
    vec_text = context.semantic_model.encode(text, convert_to_tensor=True)
    
    similarities = {}
    for language, reference in language_references.items():
        vec_ref = context.semantic_model.encode(reference, convert_to_tensor=True)
        similarity = util.cos_sim(vec_text, vec_ref).item()
        similarities[language] = similarity
    
    # Determinar el idioma detectado
    detected_language = max(similarities, key=similarities.get)
    confidence = similarities[detected_language]
    
    # Logging
    logger.info(f"📝 Texto: {text}")
    logger.info(f"🌍 Idioma esperado: {expected_language}")
    logger.info(f"🌍 Idioma detectado: {detected_language}")
    logger.info(f"📊 Confianza: {confidence:.4f}")
    
    print(f"\n{'='*60}")
    print(f"🌍 Verificación de Idioma")
    print(f"{'='*60}")
    print(f"Texto:            {text}")
    print(f"Idioma esperado:  {expected_language}")
    print(f"Idioma detectado: {detected_language}")
    print(f"Confianza:        {confidence:.4f}")
    print(f"Similitudes:")
    for lang, sim in sorted(similarities.items(), key=lambda x: x[1], reverse=True):
        marker = "✓" if lang == detected_language else " "
        print(f"  {marker} {lang}: {sim:.4f}")
    
    if detected_language == expected_language:
        print(f"✅ PASS - Idioma correcto")
        print(f"{'='*60}\n")
    else:
        print(f"❌ FAIL - Idioma incorrecto")
        print(f"{'='*60}\n")
        raise AssertionError(
            f"Idioma incorrecto.\n"
            f"Esperado: {expected_language}\n"
            f"Detectado: {detected_language}\n"
            f"Confianza: {confidence:.4f}\n"
            f"Texto: {text}"
        )


# ==========================================
# BÚSQUEDA SEMÁNTICA
# ==========================================

@then('busco el texto más similar a "{query}" en la lista "{text_list}" y lo guardo en "{var_name}"')
def step_semantic_search(context, query, text_list, var_name):
    """
    Busca el texto más similar a una consulta en una lista de textos.
    
    Ejemplo:
        Then busco el texto más similar a "error de conexión" en la lista "error de red,problema de servidor,fallo de autenticación" y lo guardo en "resultado"
    
    Args:
        query: Texto de búsqueda
        text_list: Lista de textos separados por comas
        var_name: Variable donde guardar el resultado
    """
    from sentence_transformers import util
    
    _ensure_semantic_config(context)
    
    # Resolver variables
    query = context.variable_manager.resolve_variables(query)
    
    # Parsear lista de textos
    texts = [text.strip() for text in text_list.split(',')]
    
    if len(texts) < 2:
        raise ValueError("Debes proporcionar al menos 2 textos separados por comas")
    
    # Calcular similitud con cada texto
    vec_query = context.semantic_model.encode(query, convert_to_tensor=True)
    
    similarities = {}
    for text in texts:
        vec_text = context.semantic_model.encode(text, convert_to_tensor=True)
        similarity = util.cos_sim(vec_query, vec_text).item()
        similarities[text] = similarity
    
    # Encontrar el texto más similar
    most_similar = max(similarities, key=similarities.get)
    similarity_score = similarities[most_similar]
    
    # Guardar resultado
    context.variable_manager.set_variable(var_name, most_similar)
    context.variable_manager.set_variable(f"{var_name}_similarity", str(similarity_score))
    
    # Logging
    logger.info(f"🔍 Consulta: {query}")
    logger.info(f"📝 Textos: {texts}")
    logger.info(f"✓ Más similar: {most_similar}")
    logger.info(f"📊 Similitud: {similarity_score:.4f}")
    
    print(f"\n{'='*60}")
    print(f"🔍 Búsqueda Semántica")
    print(f"{'='*60}")
    print(f"Consulta:      {query}")
    print(f"Más similar:   {most_similar}")
    print(f"Similitud:     {similarity_score:.4f}")
    print(f"\nTodos los resultados:")
    for text, sim in sorted(similarities.items(), key=lambda x: x[1], reverse=True):
        marker = "✓" if text == most_similar else " "
        print(f"  {marker} {sim:.4f} - {text}")
    print(f"💾 Guardado en: {var_name}")
    print(f"{'='*60}\n")


# ==========================================
# COMPARACIÓN MÚLTIPLE
# ==========================================

@then('comparo el texto "{text}" con múltiples referencias "{references}" y muestro las similitudes')
def step_compare_multiple(context, text, references):
    """
    Compara un texto con múltiples referencias y muestra todas las similitudes.
    
    Ejemplo:
        Then comparo el texto "Error de conexión" con múltiples referencias "error de red,problema de servidor,fallo de autenticación" y muestro las similitudes
    
    Args:
        text: Texto a comparar
        references: Referencias separadas por comas
    """
    from sentence_transformers import util
    
    _ensure_semantic_config(context)
    
    # Resolver variables
    text = context.variable_manager.resolve_variables(text)
    
    # Parsear referencias
    ref_list = [ref.strip() for ref in references.split(',')]
    
    # Calcular similitud con cada referencia
    vec_text = context.semantic_model.encode(text, convert_to_tensor=True)
    
    similarities = {}
    for ref in ref_list:
        vec_ref = context.semantic_model.encode(ref, convert_to_tensor=True)
        similarity = util.cos_sim(vec_text, vec_ref).item()
        similarities[ref] = similarity
    
    # Logging
    logger.info(f"📝 Texto: {text}")
    logger.info(f"📊 Similitudes: {similarities}")
    
    print(f"\n{'='*60}")
    print(f"📊 Comparación Múltiple")
    print(f"{'='*60}")
    print(f"Texto: {text}")
    print(f"\nSimilitudes:")
    for ref, sim in sorted(similarities.items(), key=lambda x: x[1], reverse=True):
        bar = "█" * int(sim * 20)
        print(f"  {sim:.4f} {bar} {ref}")
    print(f"{'='*60}\n")


# ==========================================
# FUNCIONES AUXILIARES
# ==========================================

def _ensure_semantic_config(context):
    """Asegura que el modelo y umbral estén configurados"""
    if not hasattr(context, 'semantic_model'):
        logger.warning("⚠️ Modelo semántico no configurado, usando configuración por defecto")
        context.execute_steps('''
            Given uso la configuración semántica por defecto
        ''')
    
    if not hasattr(context, 'semantic_threshold'):
        context.semantic_threshold = 0.75
        logger.warning(f"⚠️ Umbral no configurado, usando por defecto: {context.semantic_threshold}")
