"""
Steps para evaluación de IA Generativa usando Gemini como Juez
Incluye Context Caching y RAG para optimización de tokens

NOTA: Las librerías de Google Gemini se importan de forma lazy (solo cuando se usan)
      para no requerir instalación si no usas estas funcionalidades.
"""

from behave import step
import json
import os
import time
from datetime import datetime, timedelta
import hashlib

# Importaciones lazy de Google Gemini (solo cuando se usan)
# from google import genai
# from google.genai import types

# ============================================================================
# CONFIGURACIÓN Y HELPERS INTERNOS
# ============================================================================

def _attach_evaluation_to_report(context, data, title="Evaluación"):
    """Adjunta información de evaluación al reporte HTML de Behave
    
    Args:
        context: Contexto de Behave
        data: Diccionario con los datos a adjuntar
        title: Título para la sección en el reporte
    
    Returns:
        dict: Los datos formateados para el reporte
    """
    try:
        # Guardar en el contexto para que behave_html_integration lo capture
        if not hasattr(context, 'current_step_data'):
            context.current_step_data = {}
        
        context.current_step_data = {
            'title': title,
            'data': data
        }
        
        # Imprimir en consola también
        print(f"\n{'='*70}")
        print(f"📊 {title}")
        print(f"{'='*70}")
        print(json.dumps(data, indent=2, ensure_ascii=False))
        print(f"{'='*70}\n")
        
        return context.current_step_data
        
    except Exception as e:
        print(f"⚠ Error adjuntando datos al reporte: {e}")
        return None


def _get_gemini_client(context):
    """Inicializa y retorna el cliente Gemini
    
    Usa el modelo configurado en GEMINI_JUDGE_MODEL o gemini-2.5-pro por defecto
    """
    # Importación lazy de Google Gemini
    try:
        from google import genai
    except ImportError:
        raise ImportError(
            "La librería 'google-genai' no está instalada.\n"
            "Para usar Gemini, instálala con: pip install google-genai\n"
            "Si no usas funcionalidades de Gemini, puedes ignorar este error."
        )
    
    # Obtener API Key
    api_key = None
    if hasattr(context, 'config') and hasattr(context.config, 'userdata'):
        api_key = context.config.userdata.get('GEMINI_API_KEY')
    
    if not api_key:
        api_key = os.environ.get('GEMINI_API_KEY')
    
    if not api_key:
        raise ValueError(
            "GEMINI_API_KEY no encontrada. "
            "Configúrala en .env o en behave.ini [behave.userdata]"
        )
    
    # Crear cliente
    client = genai.Client(api_key=api_key)
    
    return client
    
    return client


def _get_gemini_model(context):
    """Obtiene el nombre del modelo Gemini configurado
    
    Returns:
        str: Nombre del modelo (ej: 'gemini-2.5-pro', 'gemini-2.5-flash', 'gemini-3-pro-preview')
    """
    # Intentar obtener desde userdata de behave
    model = None
    if hasattr(context, 'config') and hasattr(context.config, 'userdata'):
        model = context.config.userdata.get('GEMINI_JUDGE_MODEL')
    
    # Si no está en userdata, intentar desde variables de entorno
    if not model:
        model = os.environ.get('GEMINI_JUDGE_MODEL')
    
    # Valor por defecto (actualizado a modelos 2.5)
    if not model:
        model = 'gemini-2.5-pro'
    
    return model


def _count_tokens(text, model_name=None):
    """Cuenta tokens aproximados de un texto
    
    Usa estimación aproximada (1 token ≈ 4 caracteres)
    """
    # Fallback: estimación aproximada (1 token ≈ 4 caracteres)
    return len(text) // 4


def _create_cache_key(content):
    """Crea una clave única para el contenido del caché"""
    return hashlib.md5(content.encode('utf-8')).hexdigest()


def _load_context_file(file_path):
    """Carga el contenido de un archivo de contexto"""
    resolved_path = file_path
    
    try:
        with open(resolved_path, 'r', encoding='utf-8') as file:
            content = file.read()
        return content
    except FileNotFoundError:
        raise FileNotFoundError(f"Archivo de contexto no encontrado: {resolved_path}")
    except Exception as e:
        raise Exception(f"Error leyendo archivo de contexto: {e}")


# ============================================================================
# STEPS - CONFIGURACIÓN DE CONTEXTO
# ============================================================================

@step('el contexto de reglas de negocio "{context_name}" está cargado desde el archivo "{file_path}"')
@step('que el contexto de reglas de negocio "{context_name}" está cargado desde el archivo "{file_path}"')
def step_load_business_context(context, context_name, file_path):
    """Carga el contexto de reglas de negocio usando Context Caching o System Instruction
    
    Si el archivo supera 32k tokens, usa Context Caching de Gemini.
    Si es menor, lo almacena como system_instruction.
    
    Ejemplo:
        Given que el contexto de reglas de negocio "politicas_atencion" está cargado desde el archivo "contexts/politicas.txt"
    """
    # Importación lazy de tipos de Gemini
    try:
        from google.genai import types
    except ImportError:
        raise ImportError(
            "La librería 'google-genai' no está instalada.\n"
            "Para usar Gemini, instálala con: pip install google-genai"
        )
    
    resolved_path = context.variable_manager.resolve_variables(file_path)
    
    # Inicializar cliente
    client = _get_gemini_client(context)
    
    # Cargar contenido del archivo
    print(f"📄 Cargando contexto desde: {resolved_path}")
    content = _load_context_file(resolved_path)
    
    # Contar tokens
    token_count = _count_tokens(content)
    print(f"📊 Tokens del contexto: {token_count}")
    
    # Inicializar estructura de contextos si no existe
    if not hasattr(context, 'genai_contexts'):
        context.genai_contexts = {}
    
    if not hasattr(context, 'genai_caches'):
        context.genai_caches = {}
    
    if not hasattr(context, 'genai_client'):
        context.genai_client = client
    
    # Obtener modelo configurado
    model_name = _get_gemini_model(context)
    
    # Obtener umbral de caching configurado
    cache_threshold = int(os.environ.get('GEMINI_CACHE_THRESHOLD', '32000'))
    
    # Decidir estrategia según tamaño
    if token_count >= cache_threshold:
        # Usar Context Caching
        print(f"🔄 Usando Context Caching (tokens >= {cache_threshold})")
        print(f"🤖 Modelo: {model_name}")
        
        # Verificar si ya existe un caché para este contenido
        cache_key = _create_cache_key(content)
        
        if cache_key in context.genai_caches:
            print(f"✓ Reutilizando caché existente: {cache_key[:8]}...")
            cached_content = context.genai_caches[cache_key]
        else:
            try:
                # Crear nuevo caché
                print(f"⏳ Creando nuevo caché...")
                
                cached_content = client.caches.create(
                    model=model_name,
                    config=types.CreateCachedContentConfig(
                        display_name=f'context_{context_name}',
                        system_instruction=(
                            "Eres un Auditor de Calidad estricto. "
                            "Tu trabajo es evaluar respuestas de IA contra el contexto de negocio proporcionado. "
                            "Debes ser objetivo, preciso y crítico."
                        ),
                        contents=[
                            types.Content(
                                role='user',
                                parts=[types.Part(text=content)]
                            )
                        ],
                        ttl='3600s',  # Caché válido por 1 hora
                    )
                )
                
                # Guardar referencia del caché
                context.genai_caches[cache_key] = cached_content
                
                print(f"✓ Caché creado exitosamente")
                print(f"  Cache name: {cached_content.name}")
                print(f"  Expira: {cached_content.expire_time}")
                
            except Exception as e:
                print(f"✗ Error creando caché: {e}")
                raise Exception(f"Error creando Context Cache: {e}")
        
        # Guardar referencia del contexto con caché
        context.genai_contexts[context_name] = {
            'type': 'cache',
            'cache': cached_content,
            'cache_key': cache_key,
            'token_count': token_count,
            'file_path': resolved_path
        }
        
    else:
        # Usar System Instruction (sin caché)
        print(f"📝 Usando System Instruction (tokens < {cache_threshold})")
        print(f"🤖 Modelo: {model_name}")
        
        context.genai_contexts[context_name] = {
            'type': 'system_instruction',
            'content': content,
            'token_count': token_count,
            'file_path': resolved_path
        }
        
        print(f"✓ Contexto cargado como System Instruction")
    
    # Establecer contexto activo
    context.active_context_name = context_name
    print(f"✓ Contexto '{context_name}' activado")


@step('cambio al contexto de reglas de negocio "{context_name}"')
def step_switch_context(context, context_name):
    """Cambia al contexto de reglas de negocio especificado
    
    Ejemplo:
        When cambio al contexto de reglas de negocio "politicas_devoluciones"
    """
    if not hasattr(context, 'genai_contexts'):
        raise AssertionError("No hay contextos cargados. Usa 'el contexto de reglas de negocio está cargado' primero.")
    
    if context_name not in context.genai_contexts:
        available = ', '.join(context.genai_contexts.keys())
        raise AssertionError(f"Contexto '{context_name}' no encontrado. Disponibles: {available}")
    
    context.active_context_name = context_name
    print(f"✓ Cambiado a contexto: {context_name}")


@step('limpio todos los cachés de contexto')
def step_clear_caches(context):
    """Limpia todos los cachés de contexto creados
    
    Ejemplo:
        When limpio todos los cachés de contexto
    """
    if not hasattr(context, 'genai_caches') or not hasattr(context, 'genai_client'):
        print("⚠ No hay cachés para limpiar")
        return
    
    deleted_count = 0
    for cache_key, cached_content in context.genai_caches.items():
        try:
            context.genai_client.caches.delete(name=cached_content.name)
            deleted_count += 1
        except Exception as e:
            print(f"⚠ Error eliminando caché {cache_key[:8]}: {e}")
    
    context.genai_caches = {}
    print(f"✓ {deleted_count} cachés eliminados")


# ============================================================================
# STEPS - INTERACCIÓN CON EL SUT (System Under Test)
# ============================================================================

@step('interactúo con la IA con el prompt "{user_query}"')
@step('envío el prompt "{user_query}" a la IA')
def step_interact_with_sut(context, user_query):
    """Interactúa con el Sistema Bajo Prueba (SUT) y guarda la respuesta
    
    NOTA: Este es un placeholder. Debes implementar la llamada real a tu aplicación.
    
    Ejemplo:
        When interactúo con la IA con el prompt "¿Cuál es la política de devoluciones?"
    """
    resolved_query = context.variable_manager.resolve_variables(user_query)
    
    print(f"💬 Prompt enviado al SUT: {resolved_query}")
    
    # ========================================================================
    # PLACEHOLDER: Implementa aquí la llamada a tu aplicación real
    # ========================================================================
    # Ejemplo:
    # response = your_ai_app.generate(resolved_query)
    # context.sut_response = response
    # context.sut_prompt = resolved_query
    # ========================================================================
    
    # Por ahora, guardamos el prompt para que puedas implementar la lógica
    context.sut_prompt = resolved_query
    
    # Si ya hay una respuesta guardada manualmente, la usamos
    if not hasattr(context, 'sut_response'):
        print("⚠ PLACEHOLDER: Implementa la llamada a tu aplicación en este step")
        print("⚠ Por ahora, usa 'establezco la respuesta del SUT como' para simular")
        context.sut_response = None


@step('establezco la respuesta del SUT como "{response_text}"')
@step('la respuesta del SUT es "{response_text}"')
def step_set_sut_response(context, response_text):
    """Establece manualmente la respuesta del SUT (útil para testing)
    
    Ejemplo:
        And establezco la respuesta del SUT como "Puedes devolver productos dentro de 30 días"
    """
    resolved_response = context.variable_manager.resolve_variables(response_text)
    context.sut_response = resolved_response
    print(f"✓ Respuesta del SUT establecida: {resolved_response[:100]}...")


@step('cargo la respuesta del SUT desde el archivo "{file_path}"')
def step_load_sut_response_from_file(context, file_path):
    """Carga la respuesta del SUT desde un archivo
    
    Ejemplo:
        And cargo la respuesta del SUT desde el archivo "responses/chatbot_response.txt"
    """
    resolved_path = context.variable_manager.resolve_variables(file_path)
    
    try:
        with open(resolved_path, 'r', encoding='utf-8') as file:
            response = file.read()
        
        context.sut_response = response
        print(f"✓ Respuesta del SUT cargada desde: {resolved_path}")
        print(f"  Longitud: {len(response)} caracteres")
        
    except FileNotFoundError:
        raise FileNotFoundError(f"Archivo de respuesta no encontrado: {resolved_path}")
    except Exception as e:
        raise Exception(f"Error leyendo archivo de respuesta: {e}")


@step('Gemini genera la respuesta para el prompt "{user_query}"')
@step('genero la respuesta con Gemini para el prompt "{user_query}"')
def step_generate_response_with_gemini(context, user_query):
    """Genera una respuesta usando Gemini basándose en el contexto de negocio cargado
    
    Útil para:
    - Generar respuestas de referencia (golden answers)
    - Testing de RAG (comparar tu IA vs Gemini)
    - Crear datasets de entrenamiento
    - Validar que tu chatbot responde similar a Gemini
    
    Ejemplo:
        Given el contexto de reglas de negocio "policies" está cargado desde el archivo "context/policies.txt"
        When Gemini genera la respuesta para el prompt "¿Cuál es la política de devoluciones?"
        Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.9
    """
    # Importación lazy de tipos de Gemini
    try:
        from google.genai import types
    except ImportError:
        raise ImportError(
            "La librería 'google-genai' no está instalada.\n"
            "Para usar Gemini, instálala con: pip install google-genai"
        )
    
    # Validar que hay contexto activo
    if not hasattr(context, 'active_context_name'):
        raise AssertionError("No hay contexto activo. Usa 'el contexto de reglas de negocio está cargado' primero.")
    
    # Resolver variables
    resolved_query = context.variable_manager.resolve_variables(user_query)
    
    # Obtener contexto activo
    context_name = context.active_context_name
    context_data = context.genai_contexts[context_name]
    
    print(f"🤖 Generando respuesta con Gemini")
    print(f"  Contexto: {context_name}")
    print(f"  Tipo: {context_data['type']}")
    print(f"  Prompt: {resolved_query}")
    
    # Preparar system instruction para generación
    generation_system_prompt = """Eres un asistente experto que responde preguntas basándose en el contexto de negocio proporcionado.

Tu trabajo es:
1. Responder de forma precisa y completa basándote SOLO en el contexto proporcionado
2. Usar un tono profesional y amigable
3. Ser conciso pero completo
4. Si la información no está en el contexto, indicarlo claramente
5. No inventar información que no esté en el contexto

Responde directamente a la pregunta del usuario."""
    
    try:
        # Obtener cliente y modelo
        client = context.genai_client
        model_name = _get_gemini_model(context)
        
        # Generar respuesta según el tipo de contexto
        if context_data['type'] == 'cache':
            # Usar modelo con caché
            print(f"  Usando Context Cache")
            print(f"  Modelo: {model_name}")
            
            response = client.models.generate_content(
                model=model_name,
                contents=resolved_query,
                config=types.GenerateContentConfig(
                    cached_content=context_data['cache'].name,
                    temperature=0.7,  # Más creativo para generación
                )
            )
        else:
            # Usar modelo con system instruction
            print(f"  Usando System Instruction")
            print(f"  Modelo: {model_name}")
            full_system_instruction = f"""{generation_system_prompt}

**CONTEXTO DE NEGOCIO:**
{context_data['content']}"""
            
            response = client.models.generate_content(
                model=model_name,
                contents=resolved_query,
                config=types.GenerateContentConfig(
                    system_instruction=full_system_instruction,
                    temperature=0.7,
                )
            )
        
        # Verificar si la respuesta fue bloqueada
        if not response.text:
            raise AssertionError("Gemini no devolvió respuesta (posible bloqueo de seguridad)")
        
        # Guardar respuesta generada
        generated_response = response.text.strip()
        context.sut_response = generated_response
        context.sut_prompt = resolved_query
        
        # Mostrar respuesta generada
        print(f"\n{'='*70}")
        print(f"🤖 RESPUESTA GENERADA POR GEMINI")
        print(f"{'='*70}")
        print(f"Prompt: {resolved_query}")
        print(f"\nRespuesta:")
        print(f"{generated_response}")
        print(f"{'='*70}\n")
        
        print(f"✓ Respuesta generada y guardada ({len(generated_response)} caracteres)")
        
    except Exception as e:
        if "AssertionError" in str(type(e)):
            raise
        raise AssertionError(f"Error generando respuesta con Gemini: {e}")


# ============================================================================
# STEPS - EVALUACIÓN CON GEMINI COMO JUEZ
# ============================================================================

@step('el Juez Gemini debe validar la respuesta con un umbral mínimo de {threshold:f}')
@step('el Juez Gemini valida la respuesta con umbral {threshold:f}')
@step('el Juez Gemini debe validar la respuesta')
def step_gemini_judge_validation(context, threshold=None):
    """Evalúa la respuesta del SUT usando Gemini como Juez
    
    Evalúa múltiples dimensiones:
    1. Precisión de datos
    2. Cumplimiento de restricciones
    3. Tono de marca
    4. Coherencia con el contexto
    5. Context Relevance (RAG): ¿El contexto recuperado es útil?
    6. Faithfulness (Fidelidad): ¿La respuesta se basa solo en el contexto?
    7. Answer Relevance: ¿La respuesta aborda la pregunta?
    
    El threshold se puede configurar de 3 formas (en orden de prioridad):
    1. En el step: "con un umbral mínimo de 0.85"
    2. En .env: GEMINI_JUDGE_THRESHOLD=0.85
    3. Por defecto: 0.80
    
    Ejemplos:
        Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8
        Then el Juez Gemini debe validar la respuesta
    """
    # Importación lazy de tipos de Gemini
    try:
        from google.genai import types
    except ImportError:
        raise ImportError(
            "La librería 'google-genai' no está instalada.\n"
            "Para usar Gemini, instálala con: pip install google-genai"
        )
    
    # Obtener threshold (prioridad: parámetro > .env > default)
    if threshold is None:
        threshold = float(os.environ.get('GEMINI_JUDGE_THRESHOLD', '0.80'))
        print(f"📊 Usando threshold desde configuración: {threshold}")
    
    # Validar que hay contexto activo
    if not hasattr(context, 'active_context_name'):
        raise AssertionError("No hay contexto activo. Usa 'el contexto de reglas de negocio está cargado' primero.")
    
    # Validar que hay respuesta del SUT
    if not hasattr(context, 'sut_response') or context.sut_response is None:
        raise AssertionError("No hay respuesta del SUT. Usa 'interactúo con la IA' o 'establezco la respuesta del SUT' primero.")
    
    # Obtener contexto activo
    context_name = context.active_context_name
    context_data = context.genai_contexts[context_name]
    
    print(f"⚖️ Iniciando evaluación con Juez Gemini")
    print(f"  Contexto: {context_name}")
    print(f"  Tipo: {context_data['type']}")
    print(f"  Umbral: {threshold}")
    
    # Preparar prompt del juez
    judge_system_prompt = """Actúa como un Auditor de Calidad estricto y objetivo especializado en sistemas RAG (Retrieval Augmented Generation).

Tu trabajo es evaluar la respuesta del sistema contra el Contexto de Negocio proporcionado.

Evalúa las siguientes dimensiones:

**DIMENSIONES BÁSICAS:**
1. **Precisión de datos**: ¿La información es correcta según el contexto?
2. **Cumplimiento de restricciones**: ¿Se respetan todas las reglas y políticas?
3. **Tono de marca**: ¿El tono es apropiado y profesional?
4. **Coherencia**: ¿La respuesta es coherente con el contexto?

**DIMENSIONES RAG (Retrieval Augmented Generation):**
5. **Context Relevance**: ¿El contexto proporcionado es realmente útil y relevante para responder la pregunta del usuario?
6. **Faithfulness (Fidelidad)**: ¿La respuesta se basa EXCLUSIVAMENTE en el contexto proporcionado o está inventando/alucinando información?
7. **Answer Relevance**: ¿La respuesta realmente aborda lo que el usuario preguntó?

Debes responder EXCLUSIVAMENTE en formato JSON con esta estructura:
{
  "score": 0.85,
  "reasoning": "Explicación detallada de la evaluación general",
  "critical_errors": ["Error 1", "Error 2"],
  "strengths": ["Fortaleza 1", "Fortaleza 2"],
  "suggestions": ["Sugerencia 1", "Sugerencia 2"],
  "dimensions": {
    "precision": 0.9,
    "compliance": 0.8,
    "tone": 0.85,
    "coherence": 0.9,
    "context_relevance": 0.85,
    "faithfulness": 0.95,
    "answer_relevance": 0.9
  },
  "dimension_details": {
    "context_relevance": "El contexto proporcionado contiene toda la información necesaria para responder",
    "faithfulness": "La respuesta se basa completamente en el contexto, sin inventar información",
    "answer_relevance": "La respuesta aborda directamente la pregunta del usuario"
  }
}

Donde:
- score: Puntuación GENERAL de 0.0 a 1.0 (promedio ponderado de todas las dimensiones)
- reasoning: Explicación detallada de la evaluación general
- critical_errors: Lista de errores críticos encontrados (vacía si no hay)
- strengths: Lista de aspectos positivos
- suggestions: Lista de sugerencias de mejora
- dimensions: Score individual de cada dimensión (0.0 a 1.0)
- dimension_details: Explicación específica de las dimensiones RAG

**CRITERIOS DE EVALUACIÓN:**

Context Relevance (0.0-1.0):
- 1.0: El contexto contiene toda la información necesaria y es altamente relevante
- 0.5: El contexto es parcialmente relevante pero falta información
- 0.0: El contexto no es relevante para la pregunta

Faithfulness/Fidelidad (0.0-1.0):
- 1.0: La respuesta se basa 100% en el contexto, sin inventar nada
- 0.5: La respuesta mezcla información del contexto con suposiciones
- 0.0: La respuesta inventa información no presente en el contexto (alucinación)

Answer Relevance (0.0-1.0):
- 1.0: La respuesta aborda completamente la pregunta del usuario
- 0.5: La respuesta es parcialmente relevante pero no completa
- 0.0: La respuesta no aborda la pregunta del usuario

Sé estricto pero justo. Un score general de 0.8+ indica excelencia."""
    
    # Preparar el prompt de evaluación
    user_prompt = context.sut_prompt if hasattr(context, 'sut_prompt') else "N/A"
    
    evaluation_prompt = f"""**PROMPT DEL USUARIO:**
{user_prompt}

**RESPUESTA A EVALUAR:**
{context.sut_response}

Evalúa esta respuesta contra el contexto de negocio proporcionado y responde en formato JSON."""
    
    try:
        # Obtener cliente y modelo
        client = context.genai_client
        model_name = _get_gemini_model(context)
        
        # Preparar configuración según el tipo de contexto
        if context_data['type'] == 'cache':
            # Usar modelo con caché
            print(f"  Usando Context Cache")
            print(f"  Modelo: {model_name}")
            
            response = client.models.generate_content(
                model=model_name,
                contents=evaluation_prompt,
                config=types.GenerateContentConfig(
                    cached_content=context_data['cache'].name,
                    temperature=0.1,
                )
            )
        else:
            # Usar modelo con system instruction
            print(f"  Usando System Instruction")
            print(f"  Modelo: {model_name}")
            full_system_instruction = f"""{judge_system_prompt}

**CONTEXTO DE NEGOCIO:**
{context_data['content']}"""
            
            response = client.models.generate_content(
                model=model_name,
                contents=evaluation_prompt,
                config=types.GenerateContentConfig(
                    system_instruction=full_system_instruction,
                    temperature=0.1,
                )
            )
        
        # Generar evaluación
        print(f"⏳ Generando evaluación...")
        
        # Verificar si la respuesta fue bloqueada
        if not response.text:
            raise AssertionError("Gemini no devolvió respuesta (posible bloqueo de seguridad)")
        
        # Parsear respuesta JSON
        response_text = response.text.strip()
        
        # Limpiar markdown si existe
        if response_text.startswith('```json'):
            response_text = response_text.replace('```json', '').replace('```', '').strip()
        elif response_text.startswith('```'):
            response_text = response_text.replace('```', '').strip()
        
        try:
            evaluation = json.loads(response_text)
        except json.JSONDecodeError as e:
            print(f"✗ Error parseando JSON de Gemini:")
            print(f"  Respuesta: {response_text[:500]}")
            raise AssertionError(f"Gemini no devolvió JSON válido: {e}")
        
        # Extraer score y datos básicos
        if 'score' not in evaluation:
            raise AssertionError(f"Respuesta de Gemini no contiene 'score': {evaluation}")
        
        score = float(evaluation['score'])
        reasoning = evaluation.get('reasoning', 'No se proporcionó razonamiento')
        critical_errors = evaluation.get('critical_errors', [])
        strengths = evaluation.get('strengths', [])
        suggestions = evaluation.get('suggestions', [])
        
        # Extraer dimensiones RAG (nuevas)
        dimensions = evaluation.get('dimensions', {})
        dimension_details = evaluation.get('dimension_details', {})
        
        # Guardar evaluación en contexto con dimensiones RAG
        context.last_evaluation = {
            'score': score,
            'reasoning': reasoning,
            'critical_errors': critical_errors,
            'strengths': strengths,
            'suggestions': suggestions,
            'threshold': threshold,
            'passed': score >= threshold,
            'timestamp': datetime.now().isoformat(),
            # Nuevas dimensiones RAG
            'dimensions': dimensions,
            'dimension_details': dimension_details
        }
        
        # Adjuntar evaluación al reporte
        _attach_evaluation_to_report(context, context.last_evaluation, "Evaluación del Juez Gemini")
        
        # Mostrar resultados
        print(f"\n{'='*70}")
        print(f"📊 EVALUACIÓN DEL JUEZ GEMINI")
        print(f"{'='*70}")
        print(f"Score General: {score:.2f} / 1.00 (Umbral: {threshold:.2f})")
        
        # Mostrar dimensiones RAG si existen
        if dimensions:
            print(f"\n📐 Dimensiones Evaluadas:")
            if 'precision' in dimensions:
                print(f"  • Precisión de datos: {dimensions['precision']:.2f}")
            if 'compliance' in dimensions:
                print(f"  • Cumplimiento: {dimensions['compliance']:.2f}")
            if 'tone' in dimensions:
                print(f"  • Tono: {dimensions['tone']:.2f}")
            if 'coherence' in dimensions:
                print(f"  • Coherencia: {dimensions['coherence']:.2f}")
            if 'context_relevance' in dimensions:
                print(f"  • Context Relevance (RAG): {dimensions['context_relevance']:.2f}")
            if 'faithfulness' in dimensions:
                print(f"  • Faithfulness/Fidelidad: {dimensions['faithfulness']:.2f}")
            if 'answer_relevance' in dimensions:
                print(f"  • Answer Relevance: {dimensions['answer_relevance']:.2f}")
        
        # Mostrar detalles de dimensiones RAG si existen
        if dimension_details:
            print(f"\n🔍 Detalles de Dimensiones RAG:")
            if 'context_relevance' in dimension_details:
                print(f"  • Context Relevance: {dimension_details['context_relevance']}")
            if 'faithfulness' in dimension_details:
                print(f"  • Faithfulness: {dimension_details['faithfulness']}")
            if 'answer_relevance' in dimension_details:
                print(f"  • Answer Relevance: {dimension_details['answer_relevance']}")
        
        print(f"\n💭 Razonamiento General:")
        print(f"  {reasoning}")
        
        if critical_errors:
            print(f"\n❌ Errores Críticos:")
            for error in critical_errors:
                print(f"  • {error}")
        
        if strengths:
            print(f"\n✅ Fortalezas:")
            for strength in strengths:
                print(f"  • {strength}")
        
        if suggestions:
            print(f"\n💡 Sugerencias:")
            for suggestion in suggestions:
                print(f"  • {suggestion}")
                print(f"  • {suggestion}")
        
        print(f"{'='*70}\n")
        
        # Validar umbral
        if score >= threshold:
            print(f"✓ EVALUACIÓN APROBADA (Score: {score:.2f} >= {threshold:.2f})")
        else:
            # Formatear errores críticos
            errores_str = '\n'.join(f'• {e}' for e in critical_errors) if critical_errors else 'Ninguno'
            
            # Formatear sugerencias
            sugerencias_str = '\n'.join(f'• {s}' for s in suggestions) if suggestions else 'Ninguna'
            
            error_msg = (
                "EVALUACIÓN REPROBADA\n\n"
                f"Score obtenido: {score:.2f}\n"
                f"Umbral requerido: {threshold:.2f}\n"
                f"Diferencia: {threshold - score:.2f}\n\n"
                f"Razonamiento del Juez:\n{reasoning}\n\n"
                f"Errores Críticos:\n{errores_str}\n\n"
                f"Sugerencias de Mejora:\n{sugerencias_str}"
            )
            
            print(f"✗ {error_msg}")
            raise AssertionError(error_msg)
        
    except json.JSONDecodeError as e:
        raise AssertionError(f"Error parseando respuesta de Gemini: {e}")
    except Exception as e:
        if "AssertionError" in str(type(e)):
            raise
        raise AssertionError(f"Error en evaluación de Gemini: {e}")


@step('el Juez Gemini debe validar la respuesta con criterios personalizados "{criteria}" y umbral {threshold:f}')
def step_gemini_judge_custom_criteria(context, criteria, threshold):
    """Evalúa la respuesta del SUT con criterios personalizados
    
    Ejemplo:
        Then el Juez Gemini debe validar la respuesta con criterios personalizados "tono empático,respuesta en menos de 50 palabras" y umbral 0.85
    """
    # Similar al step anterior pero con criterios personalizados
    criteria_list = [c.strip() for c in criteria.split(',')]
    
    # Modificar el system prompt para incluir criterios personalizados
    # (Implementación similar al step anterior con criterios adicionales)
    print(f"⚖️ Evaluación con criterios personalizados: {', '.join(criteria_list)}")
    
    # Por ahora, delegar al step principal
    # TODO: Implementar lógica de criterios personalizados
    step_gemini_judge_validation(context, threshold)


@step('valido con Gemini que según el contexto para la pregunta "{pregunta}" la respuesta "{respuesta}" es válida con umbral {threshold:f}')
@step('el Juez Gemini valida que para la pregunta "{pregunta}" la respuesta "{respuesta}" es correcta con umbral {threshold:f}')
def step_gemini_validate_question_answer_direct(context, pregunta, respuesta, threshold):
    """Valida una pregunta y respuesta directamente en un solo paso
    
    Este paso combina establecer la pregunta, la respuesta y validar en una sola operación.
    Es útil cuando quieres validar múltiples pares pregunta-respuesta sin pasos intermedios.
    
    Ejemplo:
        Then valido con Gemini que según el contexto para la pregunta "¿Cuál es el horario?" la respuesta "9am a 5pm" es válida con umbral 0.8
        Then el Juez Gemini valida que para la pregunta "¿Aceptan devoluciones?" la respuesta "Sí, dentro de 30 días" es correcta con umbral 0.85
    """
    # Establecer la pregunta y respuesta en el contexto
    context.sut_prompt = pregunta
    context.sut_response = respuesta
    
    print(f"📝 Pregunta: {pregunta}")
    print(f"📝 Respuesta: {respuesta}")
    
    # Llamar a la validación estándar
    step_gemini_judge_validation(context, threshold)


@step('guardo la evaluación del Juez en el archivo "{file_path}"')
def step_save_evaluation(context, file_path):
    """Guarda la última evaluación del Juez en un archivo JSON
    
    Ejemplo:
        And guardo la evaluación del Juez en el archivo "evaluations/test_001.json"
    """
    if not hasattr(context, 'last_evaluation'):
        raise AssertionError("No hay evaluación disponible. Ejecuta 'el Juez Gemini debe validar' primero.")
    
    resolved_path = context.variable_manager.resolve_variables(file_path)
    
    try:
        # Crear directorio si no existe
        os.makedirs(os.path.dirname(resolved_path), exist_ok=True)
        
        # Guardar evaluación
        with open(resolved_path, 'w', encoding='utf-8') as file:
            json.dump(context.last_evaluation, file, indent=2, ensure_ascii=False)
        
        print(f"✓ Evaluación guardada en: {resolved_path}")
        
    except Exception as e:
        raise Exception(f"Error guardando evaluación: {e}")


@step('el score de la última evaluación debe ser mayor o igual a {min_score:f}')
def step_verify_evaluation_score(context, min_score):
    """Verifica que el score de la última evaluación cumple con el mínimo
    
    Ejemplo:
        And el score de la última evaluación debe ser mayor o igual a 0.9
    """
    if not hasattr(context, 'last_evaluation'):
        raise AssertionError("No hay evaluación disponible.")
    
    score = context.last_evaluation['score']
    
    if score >= min_score:
        print(f"✓ Score {score:.2f} >= {min_score:.2f}")
    else:
        raise AssertionError(f"Score {score:.2f} < {min_score:.2f}")
