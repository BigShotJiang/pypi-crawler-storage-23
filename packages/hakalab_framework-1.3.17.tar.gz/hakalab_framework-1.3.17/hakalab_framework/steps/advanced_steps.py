from behave import step
import json
import os
from datetime import datetime

@step('I take a screenshot simple')
@step('tomo una captura de pantalla simple')
@step('que tomo una captura de pantalla simple')
def step_take_screenshot_simple(context):
    """Toma una captura de pantalla con nombre automático"""
    return step_take_screenshot_with_name(context, filename=None)

@step('I take a screenshot with name "{filename}"')
@step('tomo una captura de pantalla con nombre "{filename}"')
@step('que tomo una captura de pantalla con nombre "{filename}"')
def step_take_screenshot_with_name(context, filename=None):
    """Toma una captura de pantalla"""
    try:
        # Obtener directorio de screenshots desde variables de entorno
        screenshot_dir = os.getenv('SCREENSHOTS_DIR', 'screenshots')
        
        # Crear directorio si no existe
        os.makedirs(screenshot_dir, exist_ok=True)
        
        # Generar nombre de archivo si no se proporciona
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"screenshot_{timestamp}.png"
        elif not filename.endswith('.png'):
            filename += '.png'
        
        # Tomar screenshot con configuración de página completa
        screenshot_path = os.path.join(screenshot_dir, filename)
        full_page = os.getenv('SCREENSHOT_FULL_PAGE', 'true').lower() == 'true'
        context.page.screenshot(path=screenshot_path, full_page=full_page, type='png')
        
        if hasattr(context, 'logger'):
            context.logger.info(f"Screenshot guardado: {screenshot_path}")
        
        return screenshot_path
    except Exception as e:
        if hasattr(context, 'logger'):
            context.logger.error(f"Error tomando screenshot: {e}")
        raise

@step('I drag element "{source_element}" to element "{target_element}" with source identifier "{source_id}" and target identifier "{target_id}"')
@step('arrastro el elemento "{source_element}" al elemento "{target_element}" con identificador origen "{source_id}" e identificador destino "{target_id}"')
@step('que arrastro el elemento "{source_element}" al elemento "{target_element}" con identificador origen "{source_id}" e identificador destino "{target_id}"')
def step_drag_and_drop(context, source_element, target_element, source_id, target_id):
    """Arrastra un elemento y lo suelta en otro"""
    source_locator = context.element_locator.get_locator(source_id)
    target_locator = context.element_locator.get_locator(target_id)
    context.page.drag_and_drop(source_locator, target_locator)

@step('I simulate key combination "{keys}"')
@step('simulo la combinación de teclas "{keys}"')
@step('que simulo la combinación de teclas "{keys}"')
def step_key_combination(context, keys):
    """Simula una combinación de teclas"""
    resolved_keys = context.variable_manager.resolve_variables(keys)
    context.page.keyboard.press(resolved_keys)

@step('I set browser geolocation to latitude {latitude:f} and longitude {longitude:f}')
@step('establezco la geolocalización del navegador a latitud {latitude:f} y longitud {longitude:f}')
@step('que establezco la geolocalización del navegador a latitud {latitude:f} y longitud {longitude:f}')
def step_set_geolocation(context, latitude, longitude):
    """Establece la geolocalización del navegador"""
    context.page.context.set_geolocation({"latitude": latitude, "longitude": longitude})

@step('I emulate device "{device_name}"')
@step('emulo el dispositivo "{device_name}"')
@step('que emulo el dispositivo "{device_name}"')
def step_emulate_device(context, device_name):
    """Emula un dispositivo específico"""
    from playwright.sync_api import devices
    if device_name in devices:
        device = devices[device_name]
        context.page.set_viewport_size(device['viewport'])
        context.page.set_extra_http_headers(device.get('extraHTTPHeaders', {}))
    else:
        raise Exception(f"Dispositivo '{device_name}' no encontrado")