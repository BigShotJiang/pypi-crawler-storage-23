"""
Steps para configuración avanzada del navegador
Incluye opciones de Chrome, Firefox, WebKit y configuraciones específicas
"""

from behave import step
import json
import os

@step('I set browser argument "{argument}"')
@step('establezco el argumento del navegador "{argument}"')
def step_set_browser_argument(context, argument):
    """Añade un argumento específico al navegador"""
    if not hasattr(context, 'browser_args'):
        context.browser_args = []
    
    resolved_argument = context.variable_manager.resolve_variables(argument)
    context.browser_args.append(resolved_argument)
    
    print(f"✓ Argumento del navegador añadido: {resolved_argument}")

@step('I set browser arguments from list "{arguments_list}"')
@step('establezco los argumentos del navegador desde la lista "{arguments_list}"')
def step_set_browser_arguments_list(context, arguments_list):
    """Establece múltiples argumentos del navegador desde una lista separada por comas"""
    if not hasattr(context, 'browser_args'):
        context.browser_args = []
    
    resolved_list = context.variable_manager.resolve_variables(arguments_list)
    arguments = [arg.strip() for arg in resolved_list.split(',')]
    
    context.browser_args.extend(arguments)
    
    print(f"✓ {len(arguments)} argumentos del navegador añadidos")
    for arg in arguments:
        print(f"  - {arg}")

@step('I set Chrome flag "{flag}" to "{value}"')
@step('establezco la bandera de Chrome "{flag}" con valor "{value}"')
def step_set_chrome_flag(context, flag, value):
    """Establece una bandera específica de Chrome"""
    if not hasattr(context, 'browser_args'):
        context.browser_args = []
    
    resolved_flag = context.variable_manager.resolve_variables(flag)
    resolved_value = context.variable_manager.resolve_variables(value)
    
    # Formatear como argumento de Chrome
    if resolved_value.lower() in ['true', 'false']:
        # Para banderas booleanas
        if resolved_value.lower() == 'true':
            argument = f"--{resolved_flag}"
        else:
            argument = f"--no-{resolved_flag}"
    else:
        # Para banderas con valor
        argument = f"--{resolved_flag}={resolved_value}"
    
    context.browser_args.append(argument)
    
    print(f"✓ Bandera de Chrome establecida: {argument}")

@step('I enable Chrome experimental feature "{feature}"')
@step('habilito la característica experimental de Chrome "{feature}"')
def step_enable_chrome_experimental_feature(context, feature):
    """Habilita una característica experimental de Chrome"""
    if not hasattr(context, 'browser_args'):
        context.browser_args = []
    
    resolved_feature = context.variable_manager.resolve_variables(feature)
    argument = f"--enable-features={resolved_feature}"
    
    context.browser_args.append(argument)
    
    print(f"✓ Característica experimental habilitada: {resolved_feature}")

@step('I disable Chrome experimental feature "{feature}"')
@step('deshabilito la característica experimental de Chrome "{feature}"')
def step_disable_chrome_experimental_feature(context, feature):
    """Deshabilita una característica experimental de Chrome"""
    if not hasattr(context, 'browser_args'):
        context.browser_args = []
    
    resolved_feature = context.variable_manager.resolve_variables(feature)
    argument = f"--disable-features={resolved_feature}"
    
    context.browser_args.append(argument)
    
    print(f"✓ Característica experimental deshabilitada: {resolved_feature}")

@step('I set browser preference "{preference}" to "{value}"')
@step('establezco la preferencia del navegador "{preference}" con valor "{value}"')
def step_set_browser_preference(context, preference, value):
    """Establece una preferencia específica del navegador"""
    if not hasattr(context, 'browser_prefs'):
        context.browser_prefs = {}
    
    resolved_preference = context.variable_manager.resolve_variables(preference)
    resolved_value = context.variable_manager.resolve_variables(value)
    
    # Intentar convertir el valor al tipo apropiado
    try:
        if resolved_value.lower() in ['true', 'false']:
            resolved_value = resolved_value.lower() == 'true'
        elif resolved_value.isdigit():
            resolved_value = int(resolved_value)
        elif '.' in resolved_value and resolved_value.replace('.', '').isdigit():
            resolved_value = float(resolved_value)
    except:
        pass  # Mantener como string si no se puede convertir
    
    context.browser_prefs[resolved_preference] = resolved_value
    
    print(f"✓ Preferencia del navegador establecida: {resolved_preference} = {resolved_value}")

@step('I set browser download behavior to "{behavior}" with path "{download_path}"')
@step('establezco el comportamiento de descarga del navegador a "{behavior}" con ruta "{download_path}"')
def step_set_download_behavior(context, behavior, download_path):
    """Configura el comportamiento de descarga del navegador"""
    if not hasattr(context, 'browser_prefs'):
        context.browser_prefs = {}
    
    resolved_behavior = context.variable_manager.resolve_variables(behavior)
    resolved_path = context.variable_manager.resolve_variables(download_path)
    
    # Crear directorio si no existe
    os.makedirs(resolved_path, exist_ok=True)
    
    # Configurar preferencias de descarga para Chrome
    download_prefs = {
        'download.default_directory': os.path.abspath(resolved_path),
        'download.prompt_for_download': resolved_behavior.lower() == 'prompt',
        'download.directory_upgrade': True,
        'safebrowsing.enabled': True
    }
    
    context.browser_prefs.update(download_prefs)
    
    print(f"✓ Comportamiento de descarga configurado: {resolved_behavior}")
    print(f"  Directorio: {resolved_path}")

@step('I set browser proxy to "{proxy_server}"')
@step('establezco el proxy del navegador a "{proxy_server}"')
def step_set_browser_proxy(context, proxy_server):
    """Configura un servidor proxy para el navegador"""
    if not hasattr(context, 'browser_args'):
        context.browser_args = []
    
    resolved_proxy = context.variable_manager.resolve_variables(proxy_server)
    argument = f"--proxy-server={resolved_proxy}"
    
    context.browser_args.append(argument)
    
    print(f"✓ Proxy del navegador configurado: {resolved_proxy}")

@step('I disable browser security features')
@step('deshabilito las características de seguridad del navegador')
def step_disable_browser_security(context):
    """Deshabilita características de seguridad del navegador (solo para testing)"""
    if not hasattr(context, 'browser_args'):
        context.browser_args = []
    
    security_args = [
        '--disable-web-security',
        '--disable-features=VizDisplayCompositor',
        '--disable-ipc-flooding-protection',
        '--disable-xss-auditor',
        '--disable-bundled-ppapi-flash',
        '--disable-plugins-discovery',
        '--ignore-certificate-errors',
        '--ignore-ssl-errors',
        '--ignore-certificate-errors-spki-list'
    ]
    
    context.browser_args.extend(security_args)
    
    print("⚠️ Características de seguridad del navegador deshabilitadas")
    print("  ADVERTENCIA: Solo usar en entornos de testing")

@step('I enable browser performance mode')
@step('habilito el modo de rendimiento del navegador')
def step_enable_performance_mode(context):
    """Habilita configuraciones para máximo rendimiento"""
    if not hasattr(context, 'browser_args'):
        context.browser_args = []
    
    performance_args = [
        '--no-sandbox',
        '--disable-dev-shm-usage',
        '--disable-gpu',
        '--disable-software-rasterizer',
        '--disable-background-timer-throttling',
        '--disable-backgrounding-occluded-windows',
        '--disable-renderer-backgrounding',
        '--disable-field-trial-config',
        '--disable-back-forward-cache',
        '--disable-ipc-flooding-protection',
        '--max_old_space_size=4096'
    ]
    
    context.browser_args.extend(performance_args)
    
    print("✓ Modo de rendimiento habilitado")
    print("  Optimizado para ejecución rápida y paralelismo")

@step('I set browser memory limit to "{memory_mb}" MB')
@step('establezco el límite de memoria del navegador a "{memory_mb}" MB')
def step_set_memory_limit(context, memory_mb):
    """Establece un límite de memoria para el navegador"""
    if not hasattr(context, 'browser_args'):
        context.browser_args = []
    
    resolved_memory = context.variable_manager.resolve_variables(memory_mb)
    
    memory_args = [
        f'--max_old_space_size={resolved_memory}',
        f'--memory-pressure-off',
        '--aggressive-cache-discard'
    ]
    
    context.browser_args.extend(memory_args)
    
    print(f"✓ Límite de memoria establecido: {resolved_memory} MB")

@step('I configure browser for mobile testing')
@step('configuro el navegador para testing móvil')
def step_configure_mobile_testing(context):
    """Configura el navegador específicamente para testing móvil"""
    if not hasattr(context, 'browser_args'):
        context.browser_args = []
    
    mobile_args = [
        '--use-mobile-user-agent',
        '--touch-events=enabled',
        '--enable-viewport-meta',
        '--disable-desktop-notifications'
    ]
    
    context.browser_args.extend(mobile_args)
    
    print("✓ Navegador configurado para testing móvil")

@step('I configure browser for CI/CD environment')
@step('configuro el navegador para entorno CI/CD')
def step_configure_cicd_environment(context):
    """Configura el navegador para entornos de CI/CD"""
    if not hasattr(context, 'browser_args'):
        context.browser_args = []
    
    cicd_args = [
        '--no-sandbox',
        '--disable-dev-shm-usage',
        '--disable-gpu',
        '--disable-software-rasterizer',
        '--disable-background-timer-throttling',
        '--disable-backgrounding-occluded-windows',
        '--disable-renderer-backgrounding',
        '--disable-extensions',
        '--disable-plugins',
        '--disable-default-apps',
        '--disable-sync',
        '--metrics-recording-only',
        '--no-first-run',
        '--safebrowsing-disable-auto-update',
        '--disable-background-networking'
    ]
    
    context.browser_args.extend(cicd_args)
    
    print("✓ Navegador configurado para CI/CD")
    print("  Optimizado para entornos sin interfaz gráfica")

@step('I load browser configuration from file "{config_file}"')
@step('cargo la configuración del navegador desde el archivo "{config_file}"')
def step_load_browser_config_from_file(context, config_file):
    """Carga configuración del navegador desde un archivo JSON"""
    resolved_file = context.variable_manager.resolve_variables(config_file)
    
    try:
        with open(resolved_file, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        # Aplicar argumentos si existen
        if 'args' in config:
            if not hasattr(context, 'browser_args'):
                context.browser_args = []
            context.browser_args.extend(config['args'])
            print(f"  ✓ {len(config['args'])} argumentos cargados")
        
        # Aplicar preferencias si existen
        if 'prefs' in config:
            if not hasattr(context, 'browser_prefs'):
                context.browser_prefs = {}
            context.browser_prefs.update(config['prefs'])
            print(f"  ✓ {len(config['prefs'])} preferencias cargadas")
        
        # Aplicar configuraciones específicas
        if 'viewport' in config:
            viewport = config['viewport']
            if hasattr(context, 'page'):
                context.page.set_viewport_size(viewport)
                print(f"  ✓ Viewport establecido: {viewport['width']}x{viewport['height']}")
        
        print(f"✓ Configuración del navegador cargada desde: {resolved_file}")
        
    except FileNotFoundError:
        print(f"✗ Archivo de configuración no encontrado: {resolved_file}")
        raise AssertionError(f"Archivo de configuración no encontrado: {resolved_file}")
    except json.JSONDecodeError as e:
        print(f"✗ Error parseando JSON: {e}")
        raise AssertionError(f"Error en formato JSON: {e}")
    except Exception as e:
        print(f"✗ Error cargando configuración: {e}")
        raise

@step('I save current browser configuration to file "{config_file}"')
@step('guardo la configuración actual del navegador en el archivo "{config_file}"')
def step_save_browser_config_to_file(context, config_file):
    """Guarda la configuración actual del navegador en un archivo JSON"""
    resolved_file = context.variable_manager.resolve_variables(config_file)
    
    config = {}
    
    # Guardar argumentos si existen
    if hasattr(context, 'browser_args'):
        config['args'] = context.browser_args
    
    # Guardar preferencias si existen
    if hasattr(context, 'browser_prefs'):
        config['prefs'] = context.browser_prefs
    
    # Guardar viewport actual si existe
    if hasattr(context, 'page'):
        try:
            viewport = context.page.viewport_size
            config['viewport'] = viewport
        except:
            pass
    
    try:
        # Crear directorio si no existe
        os.makedirs(os.path.dirname(resolved_file), exist_ok=True)
        
        with open(resolved_file, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
        
        print(f"✓ Configuración del navegador guardada en: {resolved_file}")
        
    except Exception as e:
        print(f"✗ Error guardando configuración: {e}")
        raise

@step('I clear all browser arguments')
@step('limpio todos los argumentos del navegador')
def step_clear_browser_arguments(context):
    """Limpia todos los argumentos del navegador configurados"""
    if hasattr(context, 'browser_args'):
        count = len(context.browser_args)
        context.browser_args = []
        print(f"✓ {count} argumentos del navegador eliminados")
    else:
        print("✓ No hay argumentos del navegador para limpiar")

@step('I clear all browser preferences')
@step('limpio todas las preferencias del navegador')
def step_clear_browser_preferences(context):
    """Limpia todas las preferencias del navegador configuradas"""
    if hasattr(context, 'browser_prefs'):
        count = len(context.browser_prefs)
        context.browser_prefs = {}
        print(f"✓ {count} preferencias del navegador eliminadas")
    else:
        print("✓ No hay preferencias del navegador para limpiar")

@step('I show current browser configuration')
@step('muestro la configuración actual del navegador')
def step_show_browser_configuration(context):
    """Muestra la configuración actual del navegador"""
    print("📋 Configuración actual del navegador:")
    
    # Mostrar argumentos
    if hasattr(context, 'browser_args') and context.browser_args:
        print(f"  Argumentos ({len(context.browser_args)}):")
        for i, arg in enumerate(context.browser_args, 1):
            print(f"    {i}. {arg}")
    else:
        print("  Argumentos: Ninguno")
    
    # Mostrar preferencias
    if hasattr(context, 'browser_prefs') and context.browser_prefs:
        print(f"  Preferencias ({len(context.browser_prefs)}):")
        for key, value in context.browser_prefs.items():
            print(f"    {key}: {value}")
    else:
        print("  Preferencias: Ninguna")
    
    # Mostrar viewport actual
    if hasattr(context, 'page'):
        try:
            viewport = context.page.viewport_size
            print(f"  Viewport: {viewport['width']}x{viewport['height']}")
        except:
            print("  Viewport: No disponible")