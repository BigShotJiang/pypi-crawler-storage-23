#!/usr/bin/env python3
"""
Steps de NLP avanzado: NER, Resumen, Traducción, Generación, Toxicidad, Keywords, Clustering, QA
Funcionalidades de procesamiento de lenguaje natural con IA
"""
from behave import step, given, when, then
import logging
import json
from datetime import datetime

logger = logging.getLogger(__name__)


# ==========================================
# HELPERS PARA REPORTES
# ==========================================

def _attach_nlp_data_to_report(context, data, title="Procesamiento NLP"):
    """Adjunta información de procesamiento NLP al reporte HTML de Behave
    
    Args:
        context: Contexto de Behave
        data: Diccionario con los datos a adjuntar
        title: Título para la sección en el reporte
    
    Returns:
        dict: Los datos formateados para el reporte
    """
    try:
        # Guardar en el contexto para que behave_html_integration lo capture
        if not hasattr(context, 'current_step_data'):
            context.current_step_data = {}
        
        context.current_step_data = {
            'title': title,
            'data': data
        }
        
        # Imprimir en consola también
        print(f"\n{'='*70}")
        print(f"🤖 {title}")
        print(f"{'='*70}")
        print(json.dumps(data, indent=2, ensure_ascii=False))
        print(f"{'='*70}\n")
        
        return context.current_step_data
        
    except Exception as e:
        print(f"⚠ Error adjuntando datos al reporte: {e}")
        return None


# ==========================================
# EXTRACCIÓN DE ENTIDADES (NER)
# ==========================================

@then('extraigo las entidades del texto "{text}" y las guardo en "{var_name}"')
def step_extract_entities(context, text, var_name):
    """
    Extrae entidades nombradas (personas, lugares, organizaciones, fechas, etc.) de un texto.
    
    Ejemplo:
        Then extraigo las entidades del texto "Juan García visitó Madrid el 15 de enero" y las guardo en "entidades"
    
    Args:
        text: Texto a analizar
        var_name: Variable donde guardar las entidades (formato JSON)
    """
    try:
        from transformers import pipeline
    except ImportError:
        raise ImportError(
            "La librería 'transformers' no está instalada.\n"
            "Instálala con: pip install transformers"
        )
    
    # Resolver variables
    text = context.variable_manager.resolve_variables(text)
    
    # Inicializar pipeline de NER si no existe
    if not hasattr(context, 'ner_pipeline'):
        logger.info("🤖 Cargando modelo de NER...")
        context.ner_pipeline = pipeline(
            "ner",
            model="Davlan/bert-base-multilingual-cased-ner-hrl",
            aggregation_strategy="simple"
        )
    
    # Extraer entidades
    entities = context.ner_pipeline(text)
    
    # Formatear resultados
    formatted_entities = {}
    for entity in entities:
        entity_type = entity['entity_group']
        entity_text = entity['word']
        confidence = entity['score']
        
        if entity_type not in formatted_entities:
            formatted_entities[entity_type] = []
        
        formatted_entities[entity_type].append({
            'text': entity_text,
            'confidence': round(confidence, 4)
        })
    
    # Guardar en variable
    import json
    context.variable_manager.set_variable(var_name, json.dumps(formatted_entities, ensure_ascii=False))
    
    # Adjuntar al reporte
    report_data = {
        'texto_analizado': text,
        'entidades_encontradas': formatted_entities,
        'total_entidades': sum(len(v) for v in formatted_entities.values())
    }
    _attach_nlp_data_to_report(context, report_data, "Extracción de Entidades (NER)")
    
    # Logging
    logger.info(f"📝 Texto analizado: {text}")
    logger.info(f"🏷️ Entidades encontradas: {formatted_entities}")


@then('verifico que el texto "{text}" contiene una entidad de tipo "{entity_type}"')
def step_verify_entity_exists(context, text, entity_type):
    """
    Verifica que un texto contenga al menos una entidad del tipo especificado.
    
    Tipos comunes: PER (persona), LOC (lugar), ORG (organización), DATE (fecha)
    
    Ejemplo:
        Then verifico que el texto "Juan visitó Madrid" contiene una entidad de tipo "PER"
    
    Args:
        text: Texto a analizar
        entity_type: Tipo de entidad esperada
    """
    try:
        from transformers import pipeline
    except ImportError:
        raise ImportError("Instala transformers: pip install transformers")
    
    # Resolver variables
    text = context.variable_manager.resolve_variables(text)
    
    # Inicializar pipeline de NER si no existe
    if not hasattr(context, 'ner_pipeline'):
        context.ner_pipeline = pipeline(
            "ner",
            model="Davlan/bert-base-multilingual-cased-ner-hrl",
            aggregation_strategy="simple"
        )
    
    # Extraer entidades
    entities = context.ner_pipeline(text)
    
    # Buscar entidad del tipo especificado
    found_entities = [e for e in entities if e['entity_group'] == entity_type]
    
    # Logging
    logger.info(f"📝 Texto: {text}")
    logger.info(f"🏷️ Tipo buscado: {entity_type}")
    logger.info(f"🏷️ Entidades encontradas: {found_entities}")
    
    print(f"\n{'='*60}")
    print(f"🏷️ Verificación de Entidad")
    print(f"{'='*60}")
    print(f"Texto:        {text}")
    print(f"Tipo buscado: {entity_type}")
    
    if found_entities:
        print(f"✅ Entidades encontradas:")
        for ent in found_entities:
            print(f"  - {ent['word']} (confianza: {ent['score']:.4f})")
        print(f"{'='*60}\n")
    else:
        print(f"❌ No se encontraron entidades de tipo {entity_type}")
        print(f"{'='*60}\n")
        raise AssertionError(
            f"No se encontró ninguna entidad de tipo '{entity_type}' en el texto.\n"
            f"Texto: {text}"
        )


# ==========================================
# RESUMEN AUTOMÁTICO
# ==========================================

@then('genero un resumen del texto "{text}" y lo guardo en "{var_name}"')
def step_generate_summary(context, text, var_name):
    """
    Genera un resumen automático de un texto largo.
    
    Ejemplo:
        Then genero un resumen del texto "Texto muy largo..." y lo guardo en "resumen"
    
    Args:
        text: Texto a resumir
        var_name: Variable donde guardar el resumen
    """
    try:
        from transformers import pipeline
    except ImportError:
        raise ImportError("Instala transformers: pip install transformers")
    
    # Resolver variables
    text = context.variable_manager.resolve_variables(text)
    
    # Inicializar pipeline de resumen si no existe
    if not hasattr(context, 'summarization_pipeline'):
        logger.info("🤖 Cargando modelo de resumen...")
        context.summarization_pipeline = pipeline(
            "summarization",
            model="facebook/bart-large-cnn"
        )
    
    # Generar resumen
    # Limitar longitud del texto de entrada
    max_input_length = 1024
    if len(text) > max_input_length:
        text = text[:max_input_length]
    
    summary = context.summarization_pipeline(
        text,
        max_length=130,
        min_length=30,
        do_sample=False
    )
    
    summary_text = summary[0]['summary_text']
    
    # Guardar en variable
    context.variable_manager.set_variable(var_name, summary_text)
    
    # Logging
    logger.info(f"📝 Texto original (primeros 200 chars): {text[:200]}...")
    logger.info(f"📄 Resumen generado: {summary_text}")
    
    print(f"\n{'='*60}")
    print(f"📄 Resumen Automático")
    print(f"{'='*60}")
    print(f"Texto original ({len(text)} caracteres):")
    print(f"{text[:200]}...")
    print(f"\nResumen generado ({len(summary_text)} caracteres):")
    print(f"{summary_text}")
    print(f"\n💾 Guardado en: {var_name}")
    print(f"{'='*60}\n")


@then('genero un resumen de la variable "{var_name}" con máximo {max_words:d} palabras y lo guardo en "{output_var}"')
def step_generate_summary_from_variable(context, var_name, max_words, output_var):
    """
    Genera un resumen de un texto almacenado en una variable con longitud máxima.
    
    Ejemplo:
        Then genero un resumen de la variable "articulo" con máximo 50 palabras y lo guardo en "resumen"
    
    Args:
        var_name: Variable con el texto original
        max_words: Número máximo de palabras en el resumen
        output_var: Variable donde guardar el resumen
    """
    text = context.variable_manager.get_variable(var_name)
    if not text:
        raise ValueError(f"La variable '{var_name}' no existe o está vacía")
    
    try:
        from transformers import pipeline
    except ImportError:
        raise ImportError("Instala transformers: pip install transformers")
    
    # Inicializar pipeline de resumen si no existe
    if not hasattr(context, 'summarization_pipeline'):
        context.summarization_pipeline = pipeline(
            "summarization",
            model="facebook/bart-large-cnn"
        )
    
    # Calcular longitud máxima en tokens (aproximadamente)
    max_length = min(max_words * 2, 130)
    min_length = max(max_words // 2, 10)
    
    # Limitar longitud del texto de entrada
    max_input_length = 1024
    if len(text) > max_input_length:
        text = text[:max_input_length]
    
    # Generar resumen
    summary = context.summarization_pipeline(
        text,
        max_length=max_length,
        min_length=min_length,
        do_sample=False
    )
    
    summary_text = summary[0]['summary_text']
    
    # Guardar en variable
    context.variable_manager.set_variable(output_var, summary_text)
    
    # Logging
    word_count = len(summary_text.split())
    logger.info(f"📝 Variable original: {var_name}")
    logger.info(f"📄 Resumen generado: {summary_text}")
    logger.info(f"📊 Palabras en resumen: {word_count}")
    
    print(f"\n{'='*60}")
    print(f"📄 Resumen con Longitud Controlada")
    print(f"{'='*60}")
    print(f"Variable original: {var_name}")
    print(f"Máximo de palabras: {max_words}")
    print(f"\nResumen generado ({word_count} palabras):")
    print(f"{summary_text}")
    print(f"\n💾 Guardado en: {output_var}")
    print(f"{'='*60}\n")


# ==========================================
# TRADUCCIÓN AUTOMÁTICA
# ==========================================

@then('traduzco el texto "{text}" de "{source_lang}" a "{target_lang}" y lo guardo en "{var_name}"')
def step_translate_text(context, text, source_lang, target_lang, var_name):
    """
    Traduce un texto de un idioma a otro.
    
    Idiomas soportados: es (español), en (inglés), fr (francés), de (alemán), pt (portugués)
    
    Ejemplo:
        Then traduzco el texto "Hello world" de "en" a "es" y lo guardo en "traduccion"
    
    Args:
        text: Texto a traducir
        source_lang: Idioma origen (código de 2 letras)
        target_lang: Idioma destino (código de 2 letras)
        var_name: Variable donde guardar la traducción
    """
    try:
        from transformers import pipeline
    except ImportError:
        raise ImportError("Instala transformers: pip install transformers")
    
    # Resolver variables
    text = context.variable_manager.resolve_variables(text)
    
    # Mapeo de códigos de idioma a modelos
    translation_models = {
        ('en', 'es'): "Helsinki-NLP/opus-mt-en-es",
        ('es', 'en'): "Helsinki-NLP/opus-mt-es-en",
        ('en', 'fr'): "Helsinki-NLP/opus-mt-en-fr",
        ('fr', 'en'): "Helsinki-NLP/opus-mt-fr-en",
        ('en', 'de'): "Helsinki-NLP/opus-mt-en-de",
        ('de', 'en'): "Helsinki-NLP/opus-mt-de-en",
        ('en', 'pt'): "Helsinki-NLP/opus-mt-en-pt",
        ('pt', 'en'): "Helsinki-NLP/opus-mt-pt-en",
    }
    
    model_key = (source_lang, target_lang)
    if model_key not in translation_models:
        raise ValueError(
            f"Traducción no soportada: {source_lang} → {target_lang}\n"
            f"Pares soportados: {list(translation_models.keys())}"
        )
    
    # Inicializar pipeline de traducción
    pipeline_key = f"translation_{source_lang}_{target_lang}"
    if not hasattr(context, pipeline_key):
        logger.info(f"🤖 Cargando modelo de traducción {source_lang} → {target_lang}...")
        translator = pipeline("translation", model=translation_models[model_key])
        setattr(context, pipeline_key, translator)
    else:
        translator = getattr(context, pipeline_key)
    
    # Traducir
    translation = translator(text, max_length=512)
    translated_text = translation[0]['translation_text']
    
    # Guardar en variable
    context.variable_manager.set_variable(var_name, translated_text)
    
    # Logging
    logger.info(f"📝 Texto original ({source_lang}): {text}")
    logger.info(f"🌍 Traducción ({target_lang}): {translated_text}")
    
    print(f"\n{'='*60}")
    print(f"🌍 Traducción Automática")
    print(f"{'='*60}")
    print(f"Idioma origen:  {source_lang}")
    print(f"Idioma destino: {target_lang}")
    print(f"\nTexto original:")
    print(f"{text}")
    print(f"\nTraducción:")
    print(f"{translated_text}")
    print(f"\n💾 Guardado en: {var_name}")
    print(f"{'='*60}\n")


# ==========================================
# GENERACIÓN DE TEXTO
# ==========================================

@then('genero una respuesta para "{prompt}" y la guardo en "{var_name}"')
def step_generate_text(context, prompt, var_name):
    """
    Genera texto automáticamente basado en un prompt.
    
    Ejemplo:
        Then genero una respuesta para "¿Cuál es la capital de Francia?" y la guardo en "respuesta"
    
    Args:
        prompt: Texto inicial/pregunta
        var_name: Variable donde guardar la respuesta generada
    """
    try:
        from transformers import pipeline
    except ImportError:
        raise ImportError("Instala transformers: pip install transformers")
    
    # Resolver variables
    prompt = context.variable_manager.resolve_variables(prompt)
    
    # Inicializar pipeline de generación si no existe
    if not hasattr(context, 'text_generation_pipeline'):
        logger.info("🤖 Cargando modelo de generación de texto...")
        context.text_generation_pipeline = pipeline(
            "text-generation",
            model="gpt2"
        )
    
    # Generar texto
    generated = context.text_generation_pipeline(
        prompt,
        max_length=100,
        num_return_sequences=1,
        temperature=0.7
    )
    
    generated_text = generated[0]['generated_text']
    
    # Extraer solo la parte generada (sin el prompt)
    if generated_text.startswith(prompt):
        response = generated_text[len(prompt):].strip()
    else:
        response = generated_text
    
    # Guardar en variable
    context.variable_manager.set_variable(var_name, response)
    
    # Logging
    logger.info(f"📝 Prompt: {prompt}")
    logger.info(f"🤖 Respuesta generada: {response}")
    
    print(f"\n{'='*60}")
    print(f"🤖 Generación de Texto")
    print(f"{'='*60}")
    print(f"Prompt:")
    print(f"{prompt}")
    print(f"\nRespuesta generada:")
    print(f"{response}")
    print(f"\n💾 Guardado en: {var_name}")
    print(f"{'='*60}\n")


# ==========================================
# ANÁLISIS DE TOXICIDAD
# ==========================================

@then('analizo la toxicidad del texto "{text}" y guardo el resultado en "{var_name}"')
def step_analyze_toxicity(context, text, var_name):
    """
    Analiza si un texto contiene contenido tóxico u ofensivo.
    
    Ejemplo:
        Then analizo la toxicidad del texto "Este es un comentario normal" y guardo el resultado en "es_toxico"
    
    Args:
        text: Texto a analizar
        var_name: Variable donde guardar el resultado (true/false)
    """
    try:
        from transformers import pipeline
    except ImportError:
        raise ImportError("Instala transformers: pip install transformers")
    
    # Resolver variables
    text = context.variable_manager.resolve_variables(text)
    
    # Inicializar pipeline de clasificación si no existe
    if not hasattr(context, 'toxicity_pipeline'):
        logger.info("🤖 Cargando modelo de detección de toxicidad...")
        context.toxicity_pipeline = pipeline(
            "text-classification",
            model="unitary/toxic-bert"
        )
    
    # Analizar toxicidad
    result = context.toxicity_pipeline(text)[0]
    is_toxic = result['label'] == 'toxic'
    confidence = result['score']
    
    # Guardar en variable
    context.variable_manager.set_variable(var_name, str(is_toxic).lower())
    context.variable_manager.set_variable(f"{var_name}_confidence", str(confidence))
    
    # Logging
    logger.info(f"📝 Texto analizado: {text}")
    logger.info(f"☠️ Es tóxico: {is_toxic}")
    logger.info(f"📊 Confianza: {confidence:.4f}")
    
    print(f"\n{'='*60}")
    print(f"☠️ Análisis de Toxicidad")
    print(f"{'='*60}")
    print(f"Texto: {text}")
    print(f"\nResultado: {'TÓXICO' if is_toxic else 'NO TÓXICO'}")
    print(f"Confianza: {confidence:.4f}")
    print(f"\n💾 Guardado en: {var_name}")
    print(f"{'='*60}\n")


@then('verifico que el texto "{text}" no es tóxico')
def step_verify_not_toxic(context, text):
    """
    Verifica que un texto NO contenga contenido tóxico.
    
    Ejemplo:
        Then verifico que el texto "Gracias por tu ayuda" no es tóxico
    
    Args:
        text: Texto a verificar
    """
    try:
        from transformers import pipeline
    except ImportError:
        raise ImportError("Instala transformers: pip install transformers")
    
    # Resolver variables
    text = context.variable_manager.resolve_variables(text)
    
    # Inicializar pipeline de clasificación si no existe
    if not hasattr(context, 'toxicity_pipeline'):
        context.toxicity_pipeline = pipeline(
            "text-classification",
            model="unitary/toxic-bert"
        )
    
    # Analizar toxicidad
    result = context.toxicity_pipeline(text)[0]
    is_toxic = result['label'] == 'toxic'
    confidence = result['score']
    
    # Logging
    logger.info(f"📝 Texto: {text}")
    logger.info(f"☠️ Es tóxico: {is_toxic}")
    logger.info(f"📊 Confianza: {confidence:.4f}")
    
    print(f"\n{'='*60}")
    print(f"☠️ Verificación de Toxicidad")
    print(f"{'='*60}")
    print(f"Texto: {text}")
    print(f"Resultado: {'TÓXICO' if is_toxic else 'NO TÓXICO'}")
    print(f"Confianza: {confidence:.4f}")
    
    if not is_toxic:
        print(f"✅ PASS - El texto no es tóxico")
        print(f"{'='*60}\n")
    else:
        print(f"❌ FAIL - El texto es tóxico")
        print(f"{'='*60}\n")
        raise AssertionError(
            f"El texto contiene contenido tóxico.\n"
            f"Confianza: {confidence:.4f}\n"
            f"Texto: {text}"
        )


# ==========================================
# EXTRACCIÓN DE KEYWORDS
# ==========================================

@then('extraigo las palabras clave del texto "{text}" y las guardo en "{var_name}"')
def step_extract_keywords(context, text, var_name):
    """
    Extrae las palabras clave más importantes de un texto.
    
    Ejemplo:
        Then extraigo las palabras clave del texto "Python es un lenguaje de programación" y las guardo en "keywords"
    
    Args:
        text: Texto a analizar
        var_name: Variable donde guardar las keywords (separadas por comas)
    """
    try:
        from keybert import KeyBERT
    except ImportError:
        raise ImportError(
            "La librería 'keybert' no está instalada.\n"
            "Instálala con: pip install keybert"
        )
    
    # Resolver variables
    text = context.variable_manager.resolve_variables(text)
    
    # Inicializar KeyBERT si no existe
    if not hasattr(context, 'keybert_model'):
        logger.info("🤖 Cargando modelo de extracción de keywords...")
        context.keybert_model = KeyBERT()
    
    # Extraer keywords
    keywords = context.keybert_model.extract_keywords(
        text,
        keyphrase_ngram_range=(1, 2),
        stop_words='english',
        top_n=5
    )
    
    # Formatear resultados
    keyword_list = [kw[0] for kw in keywords]
    keyword_scores = {kw[0]: round(kw[1], 4) for kw in keywords}
    
    # Guardar en variable
    context.variable_manager.set_variable(var_name, ', '.join(keyword_list))
    
    # Logging
    logger.info(f"📝 Texto analizado: {text}")
    logger.info(f"🔑 Keywords: {keyword_list}")
    
    print(f"\n{'='*60}")
    print(f"🔑 Extracción de Palabras Clave")
    print(f"{'='*60}")
    print(f"Texto: {text}")
    print(f"\nPalabras clave encontradas:")
    for kw, score in keyword_scores.items():
        print(f"  - {kw} (relevancia: {score})")
    print(f"\n💾 Guardado en: {var_name}")
    print(f"{'='*60}\n")


# ==========================================
# CLUSTERING DE TEXTOS
# ==========================================

@then('agrupo los textos "{text_list}" en {num_clusters:d} clusters y guardo los resultados en "{var_name}"')
def step_cluster_texts(context, text_list, num_clusters, var_name):
    """
    Agrupa textos similares en clusters.
    
    Ejemplo:
        Then agrupo los textos "Error de red,Fallo de conexión,Pago exitoso,Transacción aprobada" en 2 clusters y guardo los resultados en "grupos"
    
    Args:
        text_list: Textos separados por comas
        num_clusters: Número de clusters a crear
        var_name: Variable donde guardar los resultados
    """
    from sentence_transformers import SentenceTransformer
    from sklearn.cluster import KMeans
    import numpy as np
    
    _ensure_semantic_config(context)
    
    # Parsear textos
    texts = [text.strip() for text in text_list.split(',')]
    
    if len(texts) < num_clusters:
        raise ValueError(f"Necesitas al menos {num_clusters} textos para crear {num_clusters} clusters")
    
    # Generar embeddings
    embeddings = context.semantic_model.encode(texts)
    
    # Aplicar K-Means clustering
    kmeans = KMeans(n_clusters=num_clusters, random_state=42)
    clusters = kmeans.fit_predict(embeddings)
    
    # Organizar resultados
    clustered_texts = {}
    for i, (text, cluster_id) in enumerate(zip(texts, clusters)):
        cluster_name = f"Cluster {cluster_id + 1}"
        if cluster_name not in clustered_texts:
            clustered_texts[cluster_name] = []
        clustered_texts[cluster_name].append(text)
    
    # Guardar en variable
    import json
    context.variable_manager.set_variable(var_name, json.dumps(clustered_texts, ensure_ascii=False))
    
    # Logging
    logger.info(f"📝 Textos agrupados: {len(texts)}")
    logger.info(f"📊 Clusters creados: {num_clusters}")
    logger.info(f"📊 Resultados: {clustered_texts}")
    
    print(f"\n{'='*60}")
    print(f"📊 Clustering de Textos")
    print(f"{'='*60}")
    print(f"Textos analizados: {len(texts)}")
    print(f"Clusters creados: {num_clusters}")
    print(f"\nResultados:")
    for cluster_name, cluster_texts in clustered_texts.items():
        print(f"\n  {cluster_name}:")
        for text in cluster_texts:
            print(f"    - {text}")
    print(f"\n💾 Guardado en: {var_name}")
    print(f"{'='*60}\n")


# ==========================================
# QUESTION ANSWERING
# ==========================================

@then('respondo la pregunta "{question}" basándome en el contexto "{context_text}" y guardo la respuesta en "{var_name}"')
def step_answer_question(context, question, context_text, var_name):
    """
    Responde una pregunta basándose en un contexto proporcionado.
    
    Ejemplo:
        Then respondo la pregunta "¿Cuál es la capital?" basándome en el contexto "Francia es un país europeo. Su capital es París." y guardo la respuesta en "respuesta"
    
    Args:
        question: Pregunta a responder
        context_text: Contexto con la información
        var_name: Variable donde guardar la respuesta
    """
    try:
        from transformers import pipeline
    except ImportError:
        raise ImportError("Instala transformers: pip install transformers")
    
    # Resolver variables
    question = context.variable_manager.resolve_variables(question)
    context_text = context.variable_manager.resolve_variables(context_text)
    
    # Inicializar pipeline de QA si no existe
    if not hasattr(context, 'qa_pipeline'):
        logger.info("🤖 Cargando modelo de Question Answering...")
        context.qa_pipeline = pipeline(
            "question-answering",
            model="deepset/roberta-base-squad2"
        )
    
    # Responder pregunta
    result = context.qa_pipeline(question=question, context=context_text)
    answer = result['answer']
    confidence = result['score']
    
    # Guardar en variable
    context.variable_manager.set_variable(var_name, answer)
    context.variable_manager.set_variable(f"{var_name}_confidence", str(confidence))
    
    # Logging
    logger.info(f"❓ Pregunta: {question}")
    logger.info(f"📝 Contexto: {context_text}")
    logger.info(f"💡 Respuesta: {answer}")
    logger.info(f"📊 Confianza: {confidence:.4f}")
    
    print(f"\n{'='*60}")
    print(f"❓ Question Answering")
    print(f"{'='*60}")
    print(f"Pregunta: {question}")
    print(f"\nContexto:")
    print(f"{context_text}")
    print(f"\nRespuesta: {answer}")
    print(f"Confianza: {confidence:.4f}")
    print(f"\n💾 Guardado en: {var_name}")
    print(f"{'='*60}\n")


# ==========================================
# FUNCIONES AUXILIARES
# ==========================================

def _ensure_semantic_config(context):
    """Asegura que el modelo semántico esté configurado"""
    if not hasattr(context, 'semantic_model'):
        logger.warning("⚠️ Modelo semántico no configurado, usando configuración por defecto")
        context.execute_steps('''
            Given uso la configuración semántica por defecto
        ''')
