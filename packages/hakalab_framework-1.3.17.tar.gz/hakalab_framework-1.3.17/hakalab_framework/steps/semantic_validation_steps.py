#!/usr/bin/env python3
"""
Steps para validación semántica usando IA (Sentence Transformers)
Permite verificar similitud de textos usando embeddings y similitud de coseno
"""
from behave import step, given, when, then
import logging
import json
from datetime import datetime

logger = logging.getLogger(__name__)


# ==========================================
# HELPERS PARA REPORTES
# ==========================================

def _attach_semantic_data_to_report(context, data, title="Validación Semántica"):
    """Adjunta información de validación semántica al reporte HTML de Behave
    
    Args:
        context: Contexto de Behave
        data: Diccionario con los datos a adjuntar
        title: Título para la sección en el reporte
    
    Returns:
        dict: Los datos formateados para el reporte
    """
    try:
        # Guardar en el contexto para que behave_html_integration lo capture
        if not hasattr(context, 'current_step_data'):
            context.current_step_data = {}
        
        context.current_step_data = {
            'title': title,
            'data': data
        }
        
        # Imprimir en consola también
        print(f"\n{'='*70}")
        print(f"🔍 {title}")
        print(f"{'='*70}")
        print(json.dumps(data, indent=2, ensure_ascii=False))
        print(f"{'='*70}\n")
        
        return context.current_step_data
        
    except Exception as e:
        print(f"⚠ Error adjuntando datos al reporte: {e}")
        return None


# ==========================================
# CONFIGURACIÓN DEL MODELO Y UMBRAL
# ==========================================

@given('configuro el modelo semántico como "{model_name}"')
@when('configuro el modelo semántico como "{model_name}"')
def step_configure_semantic_model(context, model_name):
    """
    Configura el modelo de Sentence Transformers a utilizar.
    
    Modelos recomendados:
    - paraphrase-multilingual-MiniLM-L12-v2 (multilingüe, balanceado)
    - paraphrase-multilingual-mpnet-base-v2 (multilingüe, más preciso pero más lento)
    - all-MiniLM-L6-v2 (inglés, rápido)
    - all-mpnet-base-v2 (inglés, más preciso)
    
    Ejemplo:
        Given configuro el modelo semántico como "paraphrase-multilingual-MiniLM-L12-v2"
    
    Args:
        model_name: Nombre del modelo de Sentence Transformers
    """
    try:
        from sentence_transformers import SentenceTransformer
        
        # Inicializar el modelo (se descarga automáticamente si no existe)
        context.semantic_model = SentenceTransformer(model_name)
        context.semantic_model_name = model_name
        
        logger.info(f"🤖 Modelo semántico configurado: {model_name}")
        print(f"🤖 Modelo semántico configurado: {model_name}")
        
    except ImportError:
        raise ImportError(
            "La librería 'sentence-transformers' no está instalada.\n"
            "Instálala con: pip install sentence-transformers"
        )
    except Exception as e:
        raise RuntimeError(f"Error al cargar el modelo '{model_name}': {e}")


@given('establezco el umbral de similitud semántica en {threshold:f}')
@when('establezco el umbral de similitud semántica en {threshold:f}')
def step_set_semantic_threshold(context, threshold):
    """
    Establece el umbral de similitud para las validaciones semánticas.
    
    Umbrales recomendados:
    - 0.90-1.00: Textos casi idénticos
    - 0.75-0.89: Alta similitud semántica (recomendado para QA)
    - 0.60-0.74: Similitud moderada
    - 0.40-0.59: Similitud baja
    - 0.00-0.39: Textos diferentes
    
    Ejemplo:
        Given establezco el umbral de similitud semántica en 0.75
    
    Args:
        threshold: Valor entre 0.0 y 1.0
    """
    if not 0.0 <= threshold <= 1.0:
        raise ValueError(f"El umbral debe estar entre 0.0 y 1.0, recibido: {threshold}")
    
    context.semantic_threshold = threshold
    logger.info(f"📊 Umbral de similitud establecido: {threshold}")
    print(f"📊 Umbral de similitud establecido: {threshold}")


@given('uso la configuración semántica por defecto')
@when('uso la configuración semántica por defecto')
def step_use_default_semantic_config(context):
    """
    Configura el modelo y umbral por defecto para validación semántica.
    Lee la configuración desde variables de entorno (.env):
    - SEMANTIC_MODEL: Modelo a usar (default: paraphrase-multilingual-MiniLM-L12-v2)
    - SEMANTIC_THRESHOLD: Umbral de similitud (default: 0.75)
    
    Si las variables no están definidas, usa valores por defecto.
    
    Ejemplo:
        Given uso la configuración semántica por defecto
    """
    import os
    
    # Leer configuración desde .env o usar valores por defecto
    default_model = os.getenv('SEMANTIC_MODEL', 'paraphrase-multilingual-MiniLM-L12-v2')
    default_threshold = float(os.getenv('SEMANTIC_THRESHOLD', '0.75'))
    
    logger.info(f"📋 Cargando configuración semántica desde .env")
    logger.info(f"   Modelo: {default_model}")
    logger.info(f"   Umbral: {default_threshold}")
    
    context.execute_steps(f'''
        Given configuro el modelo semántico como "{default_model}"
        And establezco el umbral de similitud semántica en {default_threshold}
    ''')


# ==========================================
# VALIDACIONES SEMÁNTICAS
# ==========================================

@then('el texto "{actual_text}" debe ser semánticamente similar a "{expected_text}"')
def step_verify_semantic_similarity(context, actual_text, expected_text):
    """
    Verifica que dos textos sean semánticamente similares según el umbral configurado.
    
    Ejemplo:
        Then el texto "Tu solicitud fue aprobada exitosamente" debe ser semánticamente similar a "Gracias, tu solicitud fue exitosa"
    
    Args:
        actual_text: Texto obtenido/actual
        expected_text: Texto esperado
    """
    _ensure_semantic_config(context)
    
    # Resolver variables si existen
    actual_text = context.variable_manager.resolve_variables(actual_text)
    expected_text = context.variable_manager.resolve_variables(expected_text)
    
    similarity = _calculate_similarity(context, expected_text, actual_text)
    threshold = context.semantic_threshold
    passed = similarity >= threshold
    
    # Preparar datos para el reporte
    validation_data = {
        'texto_esperado': expected_text,
        'texto_actual': actual_text,
        'similitud': round(similarity, 4),
        'umbral': round(threshold, 4),
        'modelo': context.semantic_model_name,
        'resultado': 'PASS ✅' if passed else 'FAIL ❌'
    }
    
    # Adjuntar al reporte
    _attach_semantic_data_to_report(context, validation_data, "Validación Semántica")
    
    # Capturar data snapshot si el navegador está desactivado
    if hasattr(context, 'browser_disabled') and context.browser_disabled and hasattr(context, 'data_snapshot'):
        try:
            context.data_snapshot.capture_semantic_validation(
                step_name=f'el texto "{actual_text[:50]}..." debe ser semánticamente similar a "{expected_text[:50]}..."',
                text1=expected_text,
                text2=actual_text,
                similarity=similarity,
                threshold=threshold,
                model=context.semantic_model_name,
                passed=passed
            )
        except Exception as e:
            logger.warning(f"No se pudo capturar data snapshot: {e}")
    
    # Logging detallado
    logger.info(f"📝 Texto esperado: {expected_text}")
    logger.info(f"📝 Texto actual: {actual_text}")
    logger.info(f"📊 Similitud calculada: {similarity:.4f}")
    logger.info(f"📊 Umbral configurado: {threshold:.4f}")
    
    if not passed:
        raise AssertionError(
            f"Los textos NO son semánticamente similares.\n"
            f"Similitud: {similarity:.4f} < Umbral: {threshold:.4f}\n"
            f"Esperado: {expected_text}\n"
            f"Actual:   {actual_text}"
        )


@then('el texto de la variable "{var_name}" debe ser semánticamente similar a "{expected_text}"')
def step_verify_variable_semantic_similarity(context, var_name, expected_text):
    """
    Verifica que el texto de una variable sea semánticamente similar al texto esperado.
    
    Ejemplo:
        Then el texto de la variable "respuesta_api" debe ser semánticamente similar a "Operación exitosa"
    
    Args:
        var_name: Nombre de la variable que contiene el texto actual
        expected_text: Texto esperado
    """
    _ensure_semantic_config(context)
    
    # Obtener el texto de la variable
    actual_text = context.variable_manager.get_variable(var_name)
    if not actual_text:
        raise ValueError(f"La variable '{var_name}' no existe o está vacía")
    
    # Resolver variables en el texto esperado
    expected_text = context.variable_manager.resolve_variables(expected_text)
    
    similarity = _calculate_similarity(context, expected_text, actual_text)
    threshold = context.semantic_threshold
    
    # Logging detallado
    logger.info(f"📝 Variable: {var_name}")
    logger.info(f"📝 Texto esperado: {expected_text}")
    logger.info(f"📝 Texto actual: {actual_text}")
    logger.info(f"📊 Similitud calculada: {similarity:.4f}")
    logger.info(f"📊 Umbral configurado: {threshold:.4f}")
    
    print(f"\n{'='*60}")
    print(f"📝 Validación Semántica de Variable")
    print(f"{'='*60}")
    print(f"Variable:       {var_name}")
    print(f"Texto esperado: {expected_text}")
    print(f"Texto actual:   {actual_text}")
    print(f"Similitud:      {similarity:.4f} (umbral: {threshold:.4f})")
    
    if similarity >= threshold:
        print(f"✅ PASS - Los textos son semánticamente similares")
        print(f"{'='*60}\n")
    else:
        print(f"❌ FAIL - Los textos NO son semánticamente similares")
        print(f"{'='*60}\n")
        raise AssertionError(
            f"Los textos NO son semánticamente similares.\n"
            f"Similitud: {similarity:.4f} < Umbral: {threshold:.4f}\n"
            f"Variable: {var_name}\n"
            f"Esperado: {expected_text}\n"
            f"Actual:   {actual_text}"
        )


@then('calculo la similitud semántica entre "{text1}" y "{text2}" y la guardo en "{var_name}"')
def step_calculate_and_store_similarity(context, text1, text2, var_name):
    """
    Calcula la similitud semántica entre dos textos y guarda el resultado en una variable.
    No realiza validación, solo calcula y almacena.
    
    Ejemplo:
        Then calculo la similitud semántica entre "Hola mundo" y "Hello world" y la guardo en "similitud"
    
    Args:
        text1: Primer texto
        text2: Segundo texto
        var_name: Nombre de la variable donde guardar el resultado
    """
    _ensure_semantic_config(context)
    
    # Resolver variables si existen
    text1 = context.variable_manager.resolve_variables(text1)
    text2 = context.variable_manager.resolve_variables(text2)
    
    similarity = _calculate_similarity(context, text1, text2)
    
    # Guardar en variable
    context.variable_manager.set_variable(var_name, str(similarity))
    
    logger.info(f"📊 Similitud calculada: {similarity:.4f}")
    logger.info(f"💾 Guardada en variable: {var_name}")
    
    print(f"📊 Similitud calculada: {similarity:.4f}")
    print(f"💾 Guardada en variable: {var_name}")


@then('el texto del elemento "{element_name}" con identificador "{locator}" debe ser semánticamente similar a "{expected_text}"')
def step_verify_element_semantic_similarity(context, element_name, locator, expected_text):
    """
    Verifica que el texto de un elemento web sea semánticamente similar al texto esperado.
    
    Ejemplo:
        Then el texto del elemento "Mensaje de éxito" con identificador "$.HOME.success_message" debe ser semánticamente similar a "Operación completada"
    
    Args:
        element_name: Nombre descriptivo del elemento
        locator: Localizador del elemento (JSON path)
        expected_text: Texto esperado
    """
    _ensure_semantic_config(context)
    
    # Obtener el elemento
    page_or_frame = getattr(context, 'current_frame', None) or context.page
    element = context.element_locator.get_element(page_or_frame, locator)
    
    if not element:
        raise ValueError(f"No se encontró el elemento '{element_name}' con localizador '{locator}'")
    
    # Obtener el texto del elemento
    actual_text = element.inner_text().strip()
    
    # Resolver variables en el texto esperado
    expected_text = context.variable_manager.resolve_variables(expected_text)
    
    similarity = _calculate_similarity(context, expected_text, actual_text)
    threshold = context.semantic_threshold
    
    # Logging detallado
    logger.info(f"📝 Elemento: {element_name}")
    logger.info(f"📝 Localizador: {locator}")
    logger.info(f"📝 Texto esperado: {expected_text}")
    logger.info(f"📝 Texto actual: {actual_text}")
    logger.info(f"📊 Similitud calculada: {similarity:.4f}")
    logger.info(f"📊 Umbral configurado: {threshold:.4f}")
    
    print(f"\n{'='*60}")
    print(f"📝 Validación Semántica de Elemento Web")
    print(f"{'='*60}")
    print(f"Elemento:       {element_name}")
    print(f"Localizador:    {locator}")
    print(f"Texto esperado: {expected_text}")
    print(f"Texto actual:   {actual_text}")
    print(f"Similitud:      {similarity:.4f} (umbral: {threshold:.4f})")
    
    if similarity >= threshold:
        print(f"✅ PASS - Los textos son semánticamente similares")
        print(f"{'='*60}\n")
    else:
        print(f"❌ FAIL - Los textos NO son semánticamente similares")
        print(f"{'='*60}\n")
        raise AssertionError(
            f"Los textos NO son semánticamente similares.\n"
            f"Similitud: {similarity:.4f} < Umbral: {threshold:.4f}\n"
            f"Elemento: {element_name}\n"
            f"Esperado: {expected_text}\n"
            f"Actual:   {actual_text}"
        )


# ==========================================
# FUNCIONES AUXILIARES
# ==========================================

def _ensure_semantic_config(context):
    """Asegura que el modelo y umbral estén configurados"""
    if not hasattr(context, 'semantic_model'):
        logger.warning("⚠️ Modelo semántico no configurado, usando configuración por defecto")
        context.execute_steps('''
            Given uso la configuración semántica por defecto
        ''')
    
    if not hasattr(context, 'semantic_threshold'):
        context.semantic_threshold = 0.75
        logger.warning(f"⚠️ Umbral no configurado, usando por defecto: {context.semantic_threshold}")


def _calculate_similarity(context, text1, text2):
    """
    Calcula la similitud de coseno entre dos textos.
    
    Args:
        context: Contexto de Behave
        text1: Primer texto
        text2: Segundo texto
    
    Returns:
        float: Similitud entre 0.0 y 1.0
    """
    from sentence_transformers import util
    
    # Generar embeddings
    vec1 = context.semantic_model.encode(text1, convert_to_tensor=True)
    vec2 = context.semantic_model.encode(text2, convert_to_tensor=True)
    
    # Calcular similitud de coseno
    similarity = util.cos_sim(vec1, vec2).item()
    
    return similarity
