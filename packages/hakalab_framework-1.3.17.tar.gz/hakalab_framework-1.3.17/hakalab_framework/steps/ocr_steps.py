#!/usr/bin/env python3
"""
Steps para OCR (Reconocimiento Óptico de Caracteres) - Versión con Auto-instalación
Incluye extracción de texto, validación y búsqueda en imágenes usando Tesseract
"""

import os
import time
from behave import step

# Auto-instalador inteligente
from hakalab_framework.core.auto_installer import check_and_install_ocr_dependencies

# Intentar importar en orden de preferencia con auto-instalación
def get_ocr_manager():
    """Obtiene el manager de OCR con auto-instalación inteligente"""
    try:
        from hakalab_framework.core.ocr_manager import OCRManager
        print("✅ OCR Manager completo cargado")
        return OCRManager
    except ImportError:
        try:
            from hakalab_framework.core.ocr_manager_simple import OCRManagerSimple as OCRManager
            print("✅ OCR Manager simple cargado")
            return OCRManager
        except ImportError:
            # Intentar auto-instalación
            print("🔧 Dependencias de OCR no encontradas, intentando instalación automática...")
            if check_and_install_ocr_dependencies():
                try:
                    from hakalab_framework.core.ocr_manager_simple import OCRManagerSimple as OCRManager
                    print("✅ OCR Manager instalado y cargado correctamente")
                    return OCRManager
                except ImportError:
                    pass
            
            # Fallback al modo demo
            from hakalab_framework.core.ocr_manager_demo import OCRManagerDemo as OCRManager
            print("⚠️ Usando OCR Manager en modo demo (sin dependencias reales)")
            return OCRManager

# Obtener el manager apropiado
OCRManager = get_ocr_manager()


@step('I extract text from screenshot "{screenshot_name}" using OCR')
@step('extraigo texto del screenshot "{screenshot_name}" usando OCR')
def step_extract_text_from_screenshot(context, screenshot_name):
    """Extrae texto de un screenshot usando OCR"""
    if not hasattr(context, 'ocr_manager'):
        context.ocr_manager = OCRManager()
    
    # Construir path del screenshot
    screenshot_dir = os.getenv('SCREENSHOTS_DIR', 'screenshots')
    if not screenshot_name.endswith('.png'):
        screenshot_name += '.png'
    screenshot_path = os.path.join(screenshot_dir, screenshot_name)
    
    if not os.path.exists(screenshot_path):
        raise FileNotFoundError(f"Screenshot no encontrado: {screenshot_path}")
    
    # Extraer texto
    results = context.ocr_manager.extract_text_auto(screenshot_path)
    
    # Guardar resultados en contexto
    context.ocr_results = results
    context.ocr_text = '\n'.join([r.text for r in results])
    
    if hasattr(context, 'logger'):
        context.logger.info(f"OCR completado - {len(results)} textos extraídos")
        for i, result in enumerate(results):
            context.logger.info(f"  Texto {i+1}: '{result.text}' (confidence: {result.confidence:.1f}%)")


@step('I should find text "{expected_text}" in OCR results')
@step('debería encontrar el texto "{expected_text}" en los resultados OCR')
def step_should_find_text_in_ocr(context, expected_text):
    """Verifica que un texto específico esté en los resultados OCR"""
    if not hasattr(context, 'ocr_text'):
        raise AssertionError("No hay resultados OCR disponibles. Ejecuta primero un step de extracción OCR.")
    
    resolved_text = context.variable_manager.resolve_variables(expected_text)
    
    assert resolved_text.lower() in context.ocr_text.lower(), \
        f"Texto '{resolved_text}' no encontrado en OCR. Texto extraído: '{context.ocr_text}'"
    
    if hasattr(context, 'logger'):
        context.logger.info(f"✓ Texto encontrado en OCR: '{resolved_text}'")


@step('I should not find text "{unexpected_text}" in OCR results')
@step('no debería encontrar el texto "{unexpected_text}" en los resultados OCR')
def step_should_not_find_text_in_ocr(context, unexpected_text):
    """Verifica que un texto específico NO esté en los resultados OCR"""
    if not hasattr(context, 'ocr_text'):
        raise AssertionError("No hay resultados OCR disponibles. Ejecuta primero un step de extracción OCR.")
    
    resolved_text = context.variable_manager.resolve_variables(unexpected_text)
    
    assert resolved_text.lower() not in context.ocr_text.lower(), \
        f"Texto '{resolved_text}' encontrado en OCR cuando no debería estar. Texto extraído: '{context.ocr_text}'"
    
    if hasattr(context, 'logger'):
        context.logger.info(f"✓ Texto correctamente ausente en OCR: '{resolved_text}'")


@step('I verify OCR text quality is at least "{min_confidence}" percent')
@step('verifico que la calidad del texto OCR es al menos "{min_confidence}" por ciento')
def step_verify_ocr_quality(context, min_confidence):
    """Verifica que la calidad del OCR sea superior al mínimo especificado"""
    if not hasattr(context, 'ocr_results'):
        raise AssertionError("No hay resultados OCR disponibles. Ejecuta primero un step de extracción OCR.")
    
    min_conf = float(min_confidence)
    
    if not context.ocr_results:
        raise AssertionError("No se encontró texto en la imagen")
    
    confidences = [r.confidence for r in context.ocr_results]
    avg_confidence = sum(confidences) / len(confidences)
    
    assert avg_confidence >= min_conf, \
        f"Calidad OCR insuficiente: {avg_confidence:.1f}% (mínimo requerido: {min_conf}%)"
    
    if hasattr(context, 'logger'):
        context.logger.info(f"✓ Calidad OCR verificada: {avg_confidence:.1f}% (mínimo: {min_conf}%)")


@step('I take screenshot and extract text with OCR using "{engine}" engine')
@step('tomo screenshot y extraigo texto con OCR usando engine "{engine}"')
def step_screenshot_and_ocr(context, engine='auto'):
    """Toma screenshot y extrae texto en un solo paso"""
    if not hasattr(context, 'ocr_manager'):
        context.ocr_manager = OCRManager()
    
    # Tomar screenshot
    screenshot_dir = os.getenv('SCREENSHOTS_DIR', 'screenshots')
    os.makedirs(screenshot_dir, exist_ok=True)
    
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    screenshot_name = f"ocr_screenshot_{timestamp}.png"
    screenshot_path = os.path.join(screenshot_dir, screenshot_name)
    
    full_page = os.getenv('SCREENSHOT_FULL_PAGE', 'true').lower() == 'true'
    context.page.screenshot(path=screenshot_path, full_page=full_page, type='png')
    
    # Extraer texto con OCR
    if engine == 'auto':
        results = context.ocr_manager.extract_text_auto(screenshot_path)
    elif engine == 'tesseract':
        result = context.ocr_manager.extract_text_tesseract(screenshot_path)
        results = [result]
    elif engine == 'easyocr':
        results = context.ocr_manager.extract_text_easyocr(screenshot_path)
    else:
        raise ValueError(f"Engine OCR no soportado: {engine}")
    
    # Guardar resultados
    context.ocr_results = results
    context.ocr_text = '\n'.join([r.text for r in results])
    context.last_ocr_screenshot = screenshot_path
    
    if hasattr(context, 'logger'):
        context.logger.info(f"Screenshot + OCR completado: {screenshot_path}")
        context.logger.info(f"Texto extraído ({len(results)} elementos): {context.ocr_text[:100]}...")


@step('I search for text "{search_text}" in current page using OCR')
@step('busco el texto "{search_text}" en la página actual usando OCR')
def step_search_text_ocr(context, search_text):
    """Busca texto específico en la página actual usando OCR"""
    if not hasattr(context, 'ocr_manager'):
        context.ocr_manager = OCRManager()
    
    # Tomar screenshot temporal
    screenshot_dir = os.getenv('SCREENSHOTS_DIR', 'screenshots')
    os.makedirs(screenshot_dir, exist_ok=True)
    
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    temp_screenshot = os.path.join(screenshot_dir, f"temp_search_{timestamp}.png")
    
    full_page = os.getenv('SCREENSHOT_FULL_PAGE', 'true').lower() == 'true'
    context.page.screenshot(path=temp_screenshot, full_page=full_page, type='png')
    
    # Buscar texto
    resolved_text = context.variable_manager.resolve_variables(search_text)
    found_results = context.ocr_manager.find_text_in_image(temp_screenshot, resolved_text)
    
    # Limpiar screenshot temporal
    try:
        os.remove(temp_screenshot)
    except:
        pass
    
    # Verificar que se encontró
    assert found_results, f"Texto '{resolved_text}' no encontrado en la página usando OCR"
    
    context.ocr_search_results = found_results
    
    if hasattr(context, 'logger'):
        context.logger.info(f"✓ Texto encontrado con OCR: '{resolved_text}' ({len(found_results)} coincidencias)")


@step('I verify text is readable in screenshot "{screenshot_name}" with minimum confidence "{min_confidence}"')
@step('verifico que el texto es legible en screenshot "{screenshot_name}" con confianza mínima "{min_confidence}"')
def step_verify_text_readable_screenshot(context, screenshot_name, min_confidence):
    """Verifica que el texto en un screenshot sea legible usando OCR"""
    if not hasattr(context, 'ocr_manager'):
        context.ocr_manager = OCRManager()
    
    # Construir path del screenshot
    screenshot_dir = os.getenv('SCREENSHOTS_DIR', 'screenshots')
    if not screenshot_name.endswith('.png'):
        screenshot_name += '.png'
    screenshot_path = os.path.join(screenshot_dir, screenshot_name)
    
    if not os.path.exists(screenshot_path):
        raise FileNotFoundError(f"Screenshot no encontrado: {screenshot_path}")
    
    # Validar calidad del texto
    min_conf = float(min_confidence)
    quality_report = context.ocr_manager.validate_text_quality(screenshot_path, min_conf)
    
    assert quality_report['is_readable'], \
        f"Texto no es legible. Confianza promedio: {quality_report['avg_confidence']:.1f}% " \
        f"(mínimo requerido: {min_conf}%). Calidad: {quality_report['quality']}"
    
    # Guardar reporte en contexto
    context.ocr_quality_report = quality_report
    
    if hasattr(context, 'logger'):
        context.logger.info(f"✓ Texto legible verificado - Confianza: {quality_report['avg_confidence']:.1f}%")
        context.logger.info(f"  Textos encontrados: {quality_report['text_count']}")
        context.logger.info(f"  Calidad: {quality_report['quality']}")


@step('I extract and store OCR text from element "{element_name}" with identifier "{identifier}" in variable "{variable_name}"')
@step('extraigo y guardo texto OCR del elemento "{element_name}" con identificador "{identifier}" en variable "{variable_name}"')
def step_extract_ocr_from_element(context, element_name, identifier, variable_name):
    """Extrae texto OCR de un elemento específico y lo guarda en una variable"""
    if not hasattr(context, 'ocr_manager'):
        context.ocr_manager = OCRManager()
    
    # Obtener locator del elemento
    locator = context.element_locator.get_locator(identifier)
    element = context.page.locator(locator)
    
    # Tomar screenshot del elemento específico
    screenshot_dir = os.getenv('SCREENSHOTS_DIR', 'screenshots')
    os.makedirs(screenshot_dir, exist_ok=True)
    
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    element_screenshot = os.path.join(screenshot_dir, f"element_ocr_{timestamp}.png")
    
    element.screenshot(path=element_screenshot, type='png')
    
    # Extraer texto con OCR
    results = context.ocr_manager.extract_text_auto(element_screenshot)
    extracted_text = '\n'.join([r.text for r in results])
    
    # Guardar en variable
    context.variable_manager.set_variable(variable_name, extracted_text)
    
    # Limpiar screenshot temporal
    try:
        os.remove(element_screenshot)
    except:
        pass
    
    if hasattr(context, 'logger'):
        context.logger.info(f"✓ Texto OCR extraído del elemento y guardado en '{variable_name}': '{extracted_text[:50]}...'")


@step('I compare OCR text with expected text "{expected_text}" with similarity threshold "{threshold}" percent')
@step('comparo texto OCR con texto esperado "{expected_text}" con umbral de similitud "{threshold}" por ciento')
def step_compare_ocr_similarity(context, expected_text, threshold):
    """Compara texto OCR con texto esperado usando similitud"""
    if not hasattr(context, 'ocr_text'):
        raise AssertionError("No hay resultados OCR disponibles. Ejecuta primero un step de extracción OCR.")
    
    from difflib import SequenceMatcher
    
    resolved_expected = context.variable_manager.resolve_variables(expected_text)
    threshold_value = float(threshold) / 100.0
    
    # Calcular similitud
    similarity = SequenceMatcher(None, context.ocr_text.lower().strip(), resolved_expected.lower().strip()).ratio()
    
    assert similarity >= threshold_value, \
        f"Similitud insuficiente: {similarity*100:.1f}% (mínimo: {threshold}%). " \
        f"OCR: '{context.ocr_text}' vs Esperado: '{resolved_expected}'"
    
    if hasattr(context, 'logger'):
        context.logger.info(f"✓ Similitud OCR verificada: {similarity*100:.1f}% (mínimo: {threshold}%)")


@step('I save OCR results to file "{filename}"')
@step('guardo resultados OCR en archivo "{filename}"')
def step_save_ocr_results(context, filename):
    """Guarda los resultados OCR en un archivo"""
    if not hasattr(context, 'ocr_results'):
        raise AssertionError("No hay resultados OCR disponibles. Ejecuta primero un step de extracción OCR.")
    
    import json
    
    # Preparar datos para guardar
    ocr_data = {
        'timestamp': time.strftime("%Y-%m-%d %H:%M:%S"),
        'total_texts': len(context.ocr_results),
        'results': []
    }
    
    for i, result in enumerate(context.ocr_results):
        ocr_data['results'].append({
            'index': i + 1,
            'text': result.text,
            'confidence': result.confidence,
            'bbox': result.bbox
        })
    
    # Guardar archivo
    reports_dir = os.getenv('HTML_REPORTS_DIR', 'reports')
    os.makedirs(reports_dir, exist_ok=True)
    
    if not filename.endswith('.json'):
        filename += '.json'
    
    filepath = os.path.join(reports_dir, filename)
    
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(ocr_data, f, indent=2, ensure_ascii=False)
    
    if hasattr(context, 'logger'):
        context.logger.info(f"✓ Resultados OCR guardados en: {filepath}")