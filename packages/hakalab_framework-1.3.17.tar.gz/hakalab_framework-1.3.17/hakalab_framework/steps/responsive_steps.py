#!/usr/bin/env python3
"""
Steps para validaciones de diseño responsive
Incluye verificaciones de viewport, breakpoints y adaptabilidad
"""
from behave import step
from playwright.sync_api import expect

@step('I set viewport to mobile size "{width}x{height}"')
@step('establezco el viewport a tamaño móvil "{width}x{height}"')
def step_set_mobile_viewport(context, width, height):
    """Establece el viewport a un tamaño móvil específico"""
    w = int(width)
    h = int(height)
    context.page.set_viewport_size({"width": w, "height": h})

@step('I set viewport to tablet size "{width}x{height}"')
@step('establezco el viewport a tamaño tablet "{width}x{height}"')
def step_set_tablet_viewport(context, width, height):
    """Establece el viewport a un tamaño tablet específico"""
    w = int(width)
    h = int(height)
    context.page.set_viewport_size({"width": w, "height": h})

@step('I set viewport to desktop size "{width}x{height}"')
@step('establezco el viewport a tamaño desktop "{width}x{height}"')
def step_set_desktop_viewport(context, width, height):
    """Establece el viewport a un tamaño desktop específico"""
    w = int(width)
    h = int(height)
    context.page.set_viewport_size({"width": w, "height": h})

@step('I verify element "{element_name}" is visible on mobile with identifier "{identifier}"')
@step('verifico que el elemento "{element_name}" es visible en móvil con identificador "{identifier}"')
def step_verify_element_visible_mobile(context, element_name, identifier):
    """Verifica que un elemento es visible en viewport móvil"""
    # Establecer viewport móvil estándar
    context.page.set_viewport_size({"width": 375, "height": 667})  # iPhone SE
    
    locator = context.element_locator.get_locator(identifier)
    element = context.page.locator(locator)
    expect(element).to_be_visible()

@step('I verify element "{element_name}" is hidden on mobile with identifier "{identifier}"')
@step('verifico que el elemento "{element_name}" está oculto en móvil con identificador "{identifier}"')
def step_verify_element_hidden_mobile(context, element_name, identifier):
    """Verifica que un elemento está oculto en viewport móvil"""
    # Establecer viewport móvil estándar
    context.page.set_viewport_size({"width": 375, "height": 667})
    
    locator = context.element_locator.get_locator(identifier)
    element = context.page.locator(locator)
    expect(element).not_to_be_visible()

@step('I verify element "{element_name}" adapts to viewport changes with identifier "{identifier}"')
@step('verifico que el elemento "{element_name}" se adapta a cambios de viewport con identificador "{identifier}"')
def step_verify_element_adapts_viewport(context, element_name, identifier):
    """Verifica que un elemento se adapta a diferentes tamaños de viewport"""
    locator = context.element_locator.get_locator(identifier)
    element = context.page.locator(locator)
    
    # Probar diferentes tamaños
    viewports = [
        {"width": 320, "height": 568, "name": "móvil pequeño"},
        {"width": 768, "height": 1024, "name": "tablet"},
        {"width": 1920, "height": 1080, "name": "desktop"}
    ]
    
    positions = []
    
    for viewport in viewports:
        context.page.set_viewport_size({"width": viewport["width"], "height": viewport["height"]})
        context.page.wait_for_timeout(500)  # Esperar que se apliquen los cambios
        
        if element.is_visible():
            bounding_box = element.bounding_box()
            positions.append({
                "viewport": viewport["name"],
                "width": bounding_box["width"],
                "height": bounding_box["height"],
                "x": bounding_box["x"],
                "y": bounding_box["y"]
            })
    
    # Verificar que el elemento cambió de posición/tamaño entre viewports
    assert len(positions) >= 2, f"Elemento no es visible en suficientes viewports para verificar adaptabilidad"
    
    # Verificar que hay diferencias significativas
    first_pos = positions[0]
    last_pos = positions[-1]
    
    width_changed = abs(first_pos["width"] - last_pos["width"]) > 10
    position_changed = abs(first_pos["x"] - last_pos["x"]) > 10 or abs(first_pos["y"] - last_pos["y"]) > 10
    
    assert width_changed or position_changed, f"Elemento no se adapta a cambios de viewport"

@step('I verify navigation menu collapses on mobile')
@step('verifico que el menú de navegación se colapsa en móvil')
def step_verify_navigation_collapses_mobile(context):
    """Verifica que el menú de navegación se colapsa en dispositivos móviles"""
    # Establecer viewport móvil
    context.page.set_viewport_size({"width": 375, "height": 667})
    
    # Buscar elementos comunes de navegación colapsada
    mobile_menu_selectors = [
        '.navbar-toggle',
        '.menu-toggle',
        '.hamburger',
        '[aria-label*="menu"]',
        'button[aria-expanded]',
        '.mobile-menu-button'
    ]
    
    found_mobile_menu = False
    for selector in mobile_menu_selectors:
        mobile_menu = context.page.locator(selector)
        if mobile_menu.count() > 0 and mobile_menu.is_visible():
            found_mobile_menu = True
            break
    
    assert found_mobile_menu, "No se encontró menú de navegación colapsado para móvil"

@step('I verify text is readable at mobile size')
@step('verifico que el texto es legible en tamaño móvil')
def step_verify_text_readable_mobile(context):
    """Verifica que el texto es legible en dispositivos móviles"""
    # Establecer viewport móvil
    context.page.set_viewport_size({"width": 375, "height": 667})
    
    # Verificar tamaños de fuente mínimos
    text_elements = context.page.locator('p, span, div, a, button, h1, h2, h3, h4, h5, h6').all()
    
    for element in text_elements[:10]:  # Verificar primeros 10 elementos
        if element.is_visible() and element.text_content().strip():
            font_size = element.evaluate("element => getComputedStyle(element).fontSize")
            font_size_px = float(font_size.replace('px', ''))
            
            # Tamaño mínimo recomendado para móvil es 16px
            assert font_size_px >= 14, f"Texto demasiado pequeño para móvil: {font_size_px}px (mínimo recomendado: 14px)"

@step('I verify buttons are touch-friendly on mobile')
@step('verifico que los botones son amigables al tacto en móvil')
def step_verify_buttons_touch_friendly(context):
    """Verifica que los botones tienen tamaño apropiado para dispositivos táctiles"""
    # Establecer viewport móvil
    context.page.set_viewport_size({"width": 375, "height": 667})
    
    # Buscar botones y elementos clickeables
    clickable_elements = context.page.locator('button, a, input[type="button"], input[type="submit"], [role="button"]').all()
    
    for element in clickable_elements:
        if element.is_visible():
            bounding_box = element.bounding_box()
            width = bounding_box["width"]
            height = bounding_box["height"]
            
            # Tamaño mínimo recomendado para elementos táctiles es 44x44px
            min_size = 44
            assert width >= min_size or height >= min_size, f"Elemento clickeable demasiado pequeño para tacto: {width}x{height}px (mínimo: {min_size}px)"

@step('I verify horizontal scrolling is not present')
@step('verifico que no hay scroll horizontal')
def step_verify_no_horizontal_scroll(context):
    """Verifica que no hay scroll horizontal en la página"""
    # Obtener dimensiones de la página y viewport
    page_width = context.page.evaluate("document.documentElement.scrollWidth")
    viewport_width = context.page.evaluate("window.innerWidth")
    
    assert page_width <= viewport_width, f"Hay scroll horizontal: página {page_width}px vs viewport {viewport_width}px"

@step('I verify images scale properly on mobile')
@step('verifico que las imágenes se escalan apropiadamente en móvil')
def step_verify_images_scale_mobile(context):
    """Verifica que las imágenes se escalan apropiadamente en dispositivos móviles"""
    # Establecer viewport móvil
    context.page.set_viewport_size({"width": 375, "height": 667})
    
    images = context.page.locator('img').all()
    
    for img in images[:5]:  # Verificar primeras 5 imágenes
        if img.is_visible():
            bounding_box = img.bounding_box()
            viewport_width = 375
            
            # La imagen no debería ser más ancha que el viewport
            assert bounding_box["width"] <= viewport_width, f"Imagen demasiado ancha para móvil: {bounding_box['width']}px vs viewport {viewport_width}px"

@step('I verify element "{element_name}" stacks vertically on mobile with identifier "{identifier}"')
@step('verifico que el elemento "{element_name}" se apila verticalmente en móvil con identificador "{identifier}"')
def step_verify_element_stacks_mobile(context, element_name, identifier):
    """Verifica que elementos se apilan verticalmente en dispositivos móviles"""
    locator = context.element_locator.get_locator(identifier)
    
    # Comparar layout en desktop vs móvil
    # Desktop
    context.page.set_viewport_size({"width": 1200, "height": 800})
    desktop_elements = context.page.locator(locator).all()
    desktop_positions = []
    
    for element in desktop_elements:
        if element.is_visible():
            box = element.bounding_box()
            desktop_positions.append({"x": box["x"], "y": box["y"]})
    
    # Móvil
    context.page.set_viewport_size({"width": 375, "height": 667})
    context.page.wait_for_timeout(500)
    
    mobile_elements = context.page.locator(locator).all()
    mobile_positions = []
    
    for element in mobile_elements:
        if element.is_visible():
            box = element.bounding_box()
            mobile_positions.append({"x": box["x"], "y": box["y"]})
    
    # Verificar que en móvil los elementos están más apilados verticalmente
    if len(desktop_positions) >= 2 and len(mobile_positions) >= 2:
        desktop_y_diff = abs(desktop_positions[1]["y"] - desktop_positions[0]["y"])
        mobile_y_diff = abs(mobile_positions[1]["y"] - mobile_positions[0]["y"])
        
        # En móvil debería haber más diferencia vertical (elementos apilados)
        assert mobile_y_diff > desktop_y_diff, f"Elementos no se apilan verticalmente en móvil"

@step('I verify breakpoint behavior at "{width}" pixels')
@step('verifico el comportamiento del breakpoint en "{width}" píxeles')
def step_verify_breakpoint_behavior(context, width):
    """Verifica el comportamiento en un breakpoint específico"""
    breakpoint_width = int(width)
    
    # Probar justo antes y después del breakpoint
    widths_to_test = [breakpoint_width - 1, breakpoint_width + 1]
    
    layouts = []
    
    for test_width in widths_to_test:
        context.page.set_viewport_size({"width": test_width, "height": 800})
        context.page.wait_for_timeout(500)
        
        # Capturar información del layout
        layout_info = context.page.evaluate("""
            () => {
                const elements = document.querySelectorAll('*');
                let visibleElements = 0;
                let totalWidth = 0;
                
                elements.forEach(el => {
                    const style = getComputedStyle(el);
                    if (style.display !== 'none' && el.offsetWidth > 0) {
                        visibleElements++;
                        totalWidth += el.offsetWidth;
                    }
                });
                
                return { visibleElements, totalWidth };
            }
        """)
        
        layouts.append({
            "width": test_width,
            "layout": layout_info
        })
    
    # Verificar que hay diferencias en el layout
    layout1 = layouts[0]["layout"]
    layout2 = layouts[1]["layout"]
    
    elements_changed = layout1["visibleElements"] != layout2["visibleElements"]
    width_changed = abs(layout1["totalWidth"] - layout2["totalWidth"]) > 100
    
    assert elements_changed or width_changed, f"No se detectaron cambios en el breakpoint {width}px"

@step('I verify element "{element_name}" has responsive font size with identifier "{identifier}"')
@step('verifico que el elemento "{element_name}" tiene tamaño de fuente responsive con identificador "{identifier}"')
def step_verify_responsive_font_size(context, element_name, identifier):
    """Verifica que un elemento tiene tamaño de fuente que se adapta al viewport"""
    locator = context.element_locator.get_locator(identifier)
    element = context.page.locator(locator)
    
    # Probar en diferentes tamaños
    viewports = [
        {"width": 320, "height": 568},  # Móvil pequeño
        {"width": 1200, "height": 800}  # Desktop
    ]
    
    font_sizes = []
    
    for viewport in viewports:
        context.page.set_viewport_size(viewport)
        context.page.wait_for_timeout(300)
        
        if element.is_visible():
            font_size = element.evaluate("element => getComputedStyle(element).fontSize")
            font_size_px = float(font_size.replace('px', ''))
            font_sizes.append(font_size_px)
    
    # Verificar que el tamaño de fuente cambió entre viewports
    if len(font_sizes) >= 2:
        size_difference = abs(font_sizes[1] - font_sizes[0])
        assert size_difference > 0, f"Tamaño de fuente no es responsive: {font_sizes[0]}px en ambos viewports"