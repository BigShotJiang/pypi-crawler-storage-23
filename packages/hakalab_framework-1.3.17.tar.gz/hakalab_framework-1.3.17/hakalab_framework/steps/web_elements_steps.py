"""
Steps avanzados para interacción con elementos web
Incluye manipulación de atributos, estilos, eventos y estados
"""

from behave import step


def _get_element(context, selector, dynamic_value=None):
    """
    Función auxiliar para obtener elementos.
    Soporta tanto selectores CSS como identificadores JSON ($.ARCHIVO.elemento)
    Soporta placeholders dinámicos: $.ARCHIVO.elemento=valor
    Soporta iframes: Si context.current_frame existe, busca dentro del iframe
    """
    # Determinar si estamos dentro de un iframe
    page_or_frame = getattr(context, 'current_frame', None) or context.page
    
    if selector.startswith('$.') and hasattr(context, 'element_locator'):
        return context.element_locator.find(page_or_frame, selector, dynamic_value)
    else:
        return page_or_frame.locator(selector)

import time
import json
from playwright.sync_api import TimeoutError

@step('I set attribute "{attribute}" to "{value}" on element "{element_name}" with identifier "{identifier}"')
@step('establezco el atributo "{attribute}" con valor "{value}" en el elemento "{element_name}" con identificador "{identifier}"')
def step_set_element_attribute(context, attribute, value, element_name, identifier):
    """Establece un atributo específico en un elemento"""
    locator = context.element_locator.get_locator(identifier)
    resolved_value = context.variable_manager.resolve_variables(value)
    
    element = context.page.locator(locator)
    element.evaluate(f"el => el.setAttribute('{attribute}', '{resolved_value}')")
    
    print(f"✓ Atributo '{attribute}' establecido a '{resolved_value}' en elemento '{element_name}'")

@step('I remove attribute "{attribute}" from element "{element_name}" with identifier "{identifier}"')
@step('elimino el atributo "{attribute}" del elemento "{element_name}" con identificador "{identifier}"')
def step_remove_element_attribute(context, attribute, element_name, identifier):
    """Elimina un atributo específico de un elemento"""
    locator = context.element_locator.get_locator(identifier)
    
    element = context.page.locator(locator)
    element.evaluate(f"el => el.removeAttribute('{attribute}')")
    
    print(f"✓ Atributo '{attribute}' eliminado del elemento '{element_name}'")

@step('I set CSS style "{property}" to "{value}" on element "{element_name}" with identifier "{identifier}"')
@step('establezco el estilo CSS "{property}" con valor "{value}" en el elemento "{element_name}" con identificador "{identifier}"')
def step_set_element_style(context, property, value, element_name, identifier):
    """Establece una propiedad CSS en un elemento"""
    locator = context.element_locator.get_locator(identifier)
    resolved_value = context.variable_manager.resolve_variables(value)
    
    element = context.page.locator(locator)
    element.evaluate(f"el => el.style.{property} = '{resolved_value}'")
    
    print(f"✓ Estilo CSS '{property}' establecido a '{resolved_value}' en elemento '{element_name}'")

@step('I trigger event "{event}" on element "{element_name}" with identifier "{identifier}"')
@step('disparo el evento "{event}" en el elemento "{element_name}" con identificador "{identifier}"')
def step_trigger_element_event(context, event, element_name, identifier):
    """Dispara un evento específico en un elemento"""
    locator = context.element_locator.get_locator(identifier)
    
    element = context.page.locator(locator)
    element.evaluate(f"""
        el => {{
            const event = new Event('{event}', {{ bubbles: true }});
            el.dispatchEvent(event);
        }}
    """)
    
    print(f"✓ Evento '{event}' disparado en elemento '{element_name}'")

@step('I focus on element "{element_name}" with identifier "{identifier}"')
@step('enfoco el elemento "{element_name}" con identificador "{identifier}"')
def step_focus_element(context, element_name, identifier):
    """Enfoca un elemento específico"""
    locator = context.element_locator.get_locator(identifier)
    
    element = context.page.locator(locator)
    element.focus()
    
    print(f"✓ Elemento '{element_name}' enfocado")

@step('I blur element "{element_name}" with identifier "{identifier}"')
@step('desenfocar el elemento "{element_name}" con identificador "{identifier}"')
def step_blur_element(context, element_name, identifier):
    """Desenfoca un elemento específico"""
    locator = context.element_locator.get_locator(identifier)
    
    element = context.page.locator(locator)
    element.blur()
    
    print(f"✓ Elemento '{element_name}' desenfocado")

@step('I select text in element "{element_name}" with identifier "{identifier}"')
@step('selecciono el texto del elemento "{element_name}" con identificador "{identifier}"')
def step_select_text_in_element(context, element_name, identifier):
    """Selecciona todo el texto dentro de un elemento"""
    locator = context.element_locator.get_locator(identifier)
    
    element = context.page.locator(locator)
    element.select_text()
    
    print(f"✓ Texto seleccionado en elemento '{element_name}'")

@step('I clear selection in page')
@step('limpio la selección en la página')
def step_clear_selection(context):
    """Limpia cualquier selección de texto en la página"""
    context.page.evaluate("window.getSelection().removeAllRanges()")
    print("✓ Selección de texto limpiada")

@step('I simulate mouse enter on element "{element_name}" with identifier "{identifier}"')
@step('simulo mouse enter en el elemento "{element_name}" con identificador "{identifier}"')
def step_mouse_enter_element(context, element_name, identifier):
    """Simula el evento mouse enter en un elemento"""
    locator = context.element_locator.get_locator(identifier)
    
    element = context.page.locator(locator)
    element.hover()
    
    print(f"✓ Mouse enter simulado en elemento '{element_name}'")

@step('I simulate mouse leave on element "{element_name}" with identifier "{identifier}"')
@step('simulo mouse leave en el elemento "{element_name}" con identificador "{identifier}"')
def step_mouse_leave_element(context, element_name, identifier):
    """Simula el evento mouse leave moviendo el mouse fuera del elemento"""
    locator = context.element_locator.get_locator(identifier)
    
    element = context.page.locator(locator)
    box = element.bounding_box()
    
    # Mover el mouse fuera del elemento
    context.page.mouse.move(box['x'] + box['width'] + 50, box['y'] + box['height'] + 50)
    
    print(f"✓ Mouse leave simulado en elemento '{element_name}'")

@step('I get element dimensions and store in variables width="{width_var}" height="{height_var}" for element "{element_name}" with identifier "{identifier}"')
@step('obtengo las dimensiones del elemento y las guardo en variables ancho="{width_var}" alto="{height_var}" para elemento "{element_name}" con identificador "{identifier}"')
def step_get_element_dimensions(context, width_var, height_var, element_name, identifier):
    """Obtiene las dimensiones de un elemento y las guarda en variables"""
    locator = context.element_locator.get_locator(identifier)
    
    element = context.page.locator(locator)
    box = element.bounding_box()
    
    context.variable_manager.set_variable(width_var, str(int(box['width'])))
    context.variable_manager.set_variable(height_var, str(int(box['height'])))
    
    print(f"✓ Dimensiones del elemento '{element_name}': {int(box['width'])}x{int(box['height'])}")

@step('I get element position and store in variables x="{x_var}" y="{y_var}" for element "{element_name}" with identifier "{identifier}"')
@step('obtengo la posición del elemento y la guardo en variables x="{x_var}" y="{y_var}" para elemento "{element_name}" con identificador "{identifier}"')
def step_get_element_position(context, x_var, y_var, element_name, identifier):
    """Obtiene la posición de un elemento y la guarda en variables"""
    locator = context.element_locator.get_locator(identifier)
    
    element = context.page.locator(locator)
    box = element.bounding_box()
    
    context.variable_manager.set_variable(x_var, str(int(box['x'])))
    context.variable_manager.set_variable(y_var, str(int(box['y'])))
    
    print(f"✓ Posición del elemento '{element_name}': ({int(box['x'])}, {int(box['y'])})")

@step('I clone element "{source_element}" and append to "{target_element}" with identifiers "{source_id}" and "{target_id}"')
@step('clono el elemento "{source_element}" y lo añado a "{target_element}" con identificadores "{source_id}" y "{target_id}"')
def step_clone_element(context, source_element, target_element, source_id, target_id):
    """Clona un elemento y lo añade a otro elemento"""
    source_locator = context.element_locator.get_locator(source_id)
    target_locator = context.element_locator.get_locator(target_id)
    
    context.page.evaluate(f"""
        const source = document.querySelector('{source_locator}');
        const target = document.querySelector('{target_locator}');
        const clone = source.cloneNode(true);
        target.appendChild(clone);
    """)
    
    print(f"✓ Elemento '{source_element}' clonado y añadido a '{target_element}'")

@step('I remove element "{element_name}" with identifier "{identifier}"')
@step('elimino el elemento "{element_name}" con identificador "{identifier}"')
def step_remove_element(context, element_name, identifier):
    """Elimina un elemento del DOM"""
    locator = context.element_locator.get_locator(identifier)
    
    context.page.evaluate(f"""
        const element = document.querySelector('{locator}');
        if (element) element.remove();
    """)
    
    print(f"✓ Elemento '{element_name}' eliminado del DOM")