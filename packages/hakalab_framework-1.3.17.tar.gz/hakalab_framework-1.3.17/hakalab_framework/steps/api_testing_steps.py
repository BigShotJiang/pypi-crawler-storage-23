"""
Steps para testing de APIs REST
Incluye GET, POST, PUT, DELETE, validaciones y manejo de respuestas
"""

from behave import step
import requests
import json
import time

@step('I send GET request to "{url}" and store response in variable "{variable_name}"')
@step('envío petición GET a "{url}" y guardo la respuesta en la variable "{variable_name}"')
def step_send_get_request(context, url, variable_name):
    """Envía una petición GET y guarda la respuesta"""
    resolved_url = context.variable_manager.resolve_variables(url)
    
    try:
        response = requests.get(resolved_url)
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': response.text,
            'json': response.json() if response.headers.get('content-type', '').startswith('application/json') else None
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(response_data))
        context.last_api_response = response
        
        print(f"✓ GET request enviado a {resolved_url}")
        print(f"  Status: {response.status_code}")
        
    except Exception as e:
        print(f"✗ Error en GET request: {e}")
        raise

@step('I send POST request to "{url}" with body "{body}" and store response in variable "{variable_name}"')
@step('envío petición POST a "{url}" con cuerpo "{body}" y guardo la respuesta en la variable "{variable_name}"')
def step_send_post_request(context, url, body, variable_name):
    """Envía una petición POST con cuerpo y guarda la respuesta"""
    resolved_url = context.variable_manager.resolve_variables(url)
    resolved_body = context.variable_manager.resolve_variables(body)
    
    try:
        # Intentar parsear el body como JSON
        try:
            json_body = json.loads(resolved_body)
            headers = {'Content-Type': 'application/json'}
            response = requests.post(resolved_url, json=json_body, headers=headers)
        except json.JSONDecodeError:
            # Si no es JSON, enviar como texto
            headers = {'Content-Type': 'text/plain'}
            response = requests.post(resolved_url, data=resolved_body, headers=headers)
        
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': response.text,
            'json': response.json() if response.headers.get('content-type', '').startswith('application/json') else None
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(response_data))
        context.last_api_response = response
        
        print(f"✓ POST request enviado a {resolved_url}")
        print(f"  Status: {response.status_code}")
        
    except Exception as e:
        print(f"✗ Error en POST request: {e}")
        raise

@step('I send PUT request to "{url}" with body "{body}" and store response in variable "{variable_name}"')
@step('envío petición PUT a "{url}" con cuerpo "{body}" y guardo la respuesta en la variable "{variable_name}"')
def step_send_put_request(context, url, body, variable_name):
    """Envía una petición PUT con cuerpo y guarda la respuesta"""
    resolved_url = context.variable_manager.resolve_variables(url)
    resolved_body = context.variable_manager.resolve_variables(body)
    
    try:
        try:
            json_body = json.loads(resolved_body)
            headers = {'Content-Type': 'application/json'}
            response = requests.put(resolved_url, json=json_body, headers=headers)
        except json.JSONDecodeError:
            headers = {'Content-Type': 'text/plain'}
            response = requests.put(resolved_url, data=resolved_body, headers=headers)
        
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': response.text,
            'json': response.json() if response.headers.get('content-type', '').startswith('application/json') else None
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(response_data))
        context.last_api_response = response
        
        print(f"✓ PUT request enviado a {resolved_url}")
        print(f"  Status: {response.status_code}")
        
    except Exception as e:
        print(f"✗ Error en PUT request: {e}")
        raise

@step('I send DELETE request to "{url}" and store response in variable "{variable_name}"')
@step('envío petición DELETE a "{url}" y guardo la respuesta en la variable "{variable_name}"')
def step_send_delete_request(context, url, variable_name):
    """Envía una petición DELETE y guarda la respuesta"""
    resolved_url = context.variable_manager.resolve_variables(url)
    
    try:
        response = requests.delete(resolved_url)
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': response.text,
            'json': response.json() if response.headers.get('content-type', '').startswith('application/json') else None
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(response_data))
        context.last_api_response = response
        
        print(f"✓ DELETE request enviado a {resolved_url}")
        print(f"  Status: {response.status_code}")
        
    except Exception as e:
        print(f"✗ Error en DELETE request: {e}")
        raise

@step('I verify API response status code is "{expected_status}"')
@step('verifico que el código de estado de la respuesta API es "{expected_status}"')
def step_verify_api_status_code(context, expected_status):
    """Verifica el código de estado de la última respuesta API"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    actual_status = context.last_api_response.status_code
    expected_status_int = int(expected_status)
    
    if actual_status == expected_status_int:
        print(f"✓ Código de estado correcto: {actual_status}")
    else:
        print(f"✗ Código de estado incorrecto. Esperado: {expected_status_int}, Actual: {actual_status}")
        raise AssertionError(f"Código de estado incorrecto. Esperado: {expected_status_int}, Actual: {actual_status}")

@step('I verify API response contains "{key}" with value "{expected_value}"')
@step('verifico que la respuesta API contiene "{key}" con valor "{expected_value}"')
def step_verify_api_response_contains(context, key, expected_value):
    """Verifica que la respuesta API contiene una clave con un valor específico"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    try:
        response_json = context.last_api_response.json()
        resolved_expected = context.variable_manager.resolve_variables(expected_value)
        
        # Navegar por claves anidadas usando notación de punto
        keys = key.split('.')
        current_value = response_json
        
        for k in keys:
            if isinstance(current_value, dict) and k in current_value:
                current_value = current_value[k]
            else:
                raise KeyError(f"Clave '{k}' no encontrada")
        
        if str(current_value) == str(resolved_expected):
            print(f"✓ Respuesta API contiene '{key}' con valor '{resolved_expected}'")
        else:
            print(f"✗ Valor incorrecto para '{key}'. Esperado: '{resolved_expected}', Actual: '{current_value}'")
            raise AssertionError(f"Valor incorrecto para '{key}'. Esperado: '{resolved_expected}', Actual: '{current_value}'")
            
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")
    except KeyError as e:
        raise AssertionError(f"Clave no encontrada en respuesta API: {e}")

@step('I extract value from API response "{key}" and store in variable "{variable_name}"')
@step('extraigo el valor de la respuesta API "{key}" y lo guardo en la variable "{variable_name}"')
def step_extract_api_response_value(context, key, variable_name):
    """Extrae un valor de la respuesta API y lo guarda en una variable"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible")
    
    try:
        response_json = context.last_api_response.json()
        
        # Navegar por claves anidadas
        keys = key.split('.')
        current_value = response_json
        
        for k in keys:
            if isinstance(current_value, dict) and k in current_value:
                current_value = current_value[k]
            else:
                raise KeyError(f"Clave '{k}' no encontrada")
        
        context.variable_manager.set_variable(variable_name, str(current_value))
        print(f"✓ Valor extraído de '{key}': '{current_value}' guardado en variable '{variable_name}'")
        
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")
    except KeyError as e:
        raise AssertionError(f"Clave no encontrada en respuesta API: {e}")

@step('I set API header "{header_name}" to "{header_value}"')
@step('establezco el header de API "{header_name}" a "{header_value}"')
def step_set_api_header(context, header_name, header_value):
    """Establece un header para las próximas peticiones API"""
    if not hasattr(context, 'api_headers'):
        context.api_headers = {}
    
    resolved_value = context.variable_manager.resolve_variables(header_value)
    context.api_headers[header_name] = resolved_value
    
    print(f"✓ Header API '{header_name}' establecido a '{resolved_value}'")

@step('I send authenticated GET request to "{url}" with token "{token}" and store response in variable "{variable_name}"')
@step('envío petición GET autenticada a "{url}" con token "{token}" y guardo la respuesta en la variable "{variable_name}"')
def step_send_authenticated_get_request(context, url, token, variable_name):
    """Envía una petición GET autenticada con Bearer token"""
    resolved_url = context.variable_manager.resolve_variables(url)
    resolved_token = context.variable_manager.resolve_variables(token)
    
    headers = {'Authorization': f'Bearer {resolved_token}'}
    
    try:
        response = requests.get(resolved_url, headers=headers)
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': response.text,
            'json': response.json() if response.headers.get('content-type', '').startswith('application/json') else None
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(response_data))
        context.last_api_response = response
        
        print(f"✓ GET request autenticado enviado a {resolved_url}")
        print(f"  Status: {response.status_code}")
        
    except Exception as e:
        print(f"✗ Error en GET request autenticado: {e}")
        raise

@step('I verify API response time is less than "{max_seconds}" seconds')
@step('verifico que el tiempo de respuesta de la API es menor a "{max_seconds}" segundos')
def step_verify_api_response_time(context, max_seconds):
    """Verifica que el tiempo de respuesta de la API está dentro del límite"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    response_time = context.last_api_response.elapsed.total_seconds()
    max_time = float(max_seconds)
    
    if response_time <= max_time:
        print(f"✓ Tiempo de respuesta API: {response_time:.2f}s (límite: {max_time}s)")
    else:
        print(f"✗ Tiempo de respuesta API excedido: {response_time:.2f}s (límite: {max_time}s)")
        raise AssertionError(f"Tiempo de respuesta API excedido: {response_time:.2f}s")

@step('I verify API response is valid JSON')
@step('verifico que la respuesta API es JSON válido')
def step_verify_api_response_is_json(context):
    """Verifica que la respuesta API es JSON válido"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    try:
        context.last_api_response.json()
        print("✓ Respuesta API es JSON válido")
    except json.JSONDecodeError:
        print("✗ Respuesta API no es JSON válido")
        raise AssertionError("La respuesta API no es JSON válido")

@step('I send PATCH request to "{url}" with body "{body}" and store response in variable "{variable_name}"')
@step('envío petición PATCH a "{url}" con cuerpo "{body}" y guardo la respuesta en la variable "{variable_name}"')
def step_send_patch_request(context, url, body, variable_name):
    """Envía una petición PATCH con cuerpo y guarda la respuesta"""
    resolved_url = context.variable_manager.resolve_variables(url)
    resolved_body = context.variable_manager.resolve_variables(body)
    
    try:
        try:
            json_body = json.loads(resolved_body)
            headers = {'Content-Type': 'application/json'}
            response = requests.patch(resolved_url, json=json_body, headers=headers)
        except json.JSONDecodeError:
            headers = {'Content-Type': 'text/plain'}
            response = requests.patch(resolved_url, data=resolved_body, headers=headers)
        
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': response.text,
            'json': response.json() if response.headers.get('content-type', '').startswith('application/json') else None
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(response_data))
        context.last_api_response = response
        
        print(f"✓ PATCH request enviado a {resolved_url}")
        print(f"  Status: {response.status_code}")
        
    except Exception as e:
        print(f"✗ Error en PATCH request: {e}")
        raise

@step('I send HEAD request to "{url}" and store response in variable "{variable_name}"')
@step('envío petición HEAD a "{url}" y guardo la respuesta en la variable "{variable_name}"')
def step_send_head_request(context, url, variable_name):
    """Envía una petición HEAD y guarda la respuesta"""
    resolved_url = context.variable_manager.resolve_variables(url)
    
    try:
        response = requests.head(resolved_url)
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': '',  # HEAD no tiene body
            'json': None
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(response_data))
        context.last_api_response = response
        
        print(f"✓ HEAD request enviado a {resolved_url}")
        print(f"  Status: {response.status_code}")
        
    except Exception as e:
        print(f"✗ Error en HEAD request: {e}")
        raise

@step('I send OPTIONS request to "{url}" and store response in variable "{variable_name}"')
@step('envío petición OPTIONS a "{url}" y guardo la respuesta en la variable "{variable_name}"')
def step_send_options_request(context, url, variable_name):
    """Envía una petición OPTIONS y guarda la respuesta"""
    resolved_url = context.variable_manager.resolve_variables(url)
    
    try:
        response = requests.options(resolved_url)
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': response.text,
            'json': response.json() if response.headers.get('content-type', '').startswith('application/json') else None
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(response_data))
        context.last_api_response = response
        
        print(f"✓ OPTIONS request enviado a {resolved_url}")
        print(f"  Status: {response.status_code}")
        
    except Exception as e:
        print(f"✗ Error en OPTIONS request: {e}")
        raise

@step('I verify API response header "{header_name}" equals "{expected_value}"')
@step('verifico que el header de respuesta API "{header_name}" es igual a "{expected_value}"')
def step_verify_api_response_header(context, header_name, expected_value):
    """Verifica que un header de respuesta tiene un valor específico"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    resolved_expected = context.variable_manager.resolve_variables(expected_value)
    actual_value = context.last_api_response.headers.get(header_name)
    
    if actual_value == resolved_expected:
        print(f"✓ Header '{header_name}' correcto: '{actual_value}'")
    else:
        print(f"✗ Header '{header_name}' incorrecto. Esperado: '{resolved_expected}', Actual: '{actual_value}'")
        raise AssertionError(f"Header '{header_name}' incorrecto. Esperado: '{resolved_expected}', Actual: '{actual_value}'")

@step('I verify API response header "{header_name}" contains "{expected_text}"')
@step('verifico que el header de respuesta API "{header_name}" contiene "{expected_text}"')
def step_verify_api_response_header_contains(context, header_name, expected_text):
    """Verifica que un header de respuesta contiene un texto específico"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    resolved_expected = context.variable_manager.resolve_variables(expected_text)
    actual_value = context.last_api_response.headers.get(header_name, '')
    
    if resolved_expected in actual_value:
        print(f"✓ Header '{header_name}' contiene '{resolved_expected}': '{actual_value}'")
    else:
        print(f"✗ Header '{header_name}' no contiene '{resolved_expected}': '{actual_value}'")
        raise AssertionError(f"Header '{header_name}' no contiene '{resolved_expected}'")

@step('I verify API response body contains text "{expected_text}"')
@step('verifico que el cuerpo de respuesta API contiene el texto "{expected_text}"')
def step_verify_api_response_body_contains(context, expected_text):
    """Verifica que el cuerpo de respuesta contiene un texto específico"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    resolved_expected = context.variable_manager.resolve_variables(expected_text)
    response_body = context.last_api_response.text
    
    if resolved_expected in response_body:
        print(f"✓ Cuerpo de respuesta contiene '{resolved_expected}'")
    else:
        print(f"✗ Cuerpo de respuesta no contiene '{resolved_expected}'")
        raise AssertionError(f"Cuerpo de respuesta no contiene '{resolved_expected}'")

@step('I verify API response JSON array has "{expected_length}" items')
@step('verifico que el array JSON de respuesta API tiene "{expected_length}" elementos')
def step_verify_api_response_array_length(context, expected_length):
    """Verifica que un array JSON tiene una longitud específica"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    try:
        response_json = context.last_api_response.json()
        expected_len = int(expected_length)
        
        if isinstance(response_json, list):
            actual_len = len(response_json)
            if actual_len == expected_len:
                print(f"✓ Array JSON tiene {actual_len} elementos")
            else:
                print(f"✗ Array JSON tiene {actual_len} elementos, esperado: {expected_len}")
                raise AssertionError(f"Array JSON tiene {actual_len} elementos, esperado: {expected_len}")
        else:
            raise AssertionError("La respuesta no es un array JSON")
            
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")

@step('I verify API response JSON array item "{index}" has "{key}" with value "{expected_value}"')
@step('verifico que el elemento "{index}" del array JSON tiene "{key}" con valor "{expected_value}"')
def step_verify_api_response_array_item(context, index, key, expected_value):
    """Verifica que un elemento específico de un array JSON tiene un valor esperado"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    try:
        response_json = context.last_api_response.json()
        resolved_expected = context.variable_manager.resolve_variables(expected_value)
        item_index = int(index)
        
        if isinstance(response_json, list):
            if item_index < len(response_json):
                item = response_json[item_index]
                if isinstance(item, dict) and key in item:
                    actual_value = str(item[key])
                    if actual_value == str(resolved_expected):
                        print(f"✓ Array[{item_index}].{key} = '{actual_value}'")
                    else:
                        print(f"✗ Array[{item_index}].{key} = '{actual_value}', esperado: '{resolved_expected}'")
                        raise AssertionError(f"Array[{item_index}].{key} incorrecto")
                else:
                    raise AssertionError(f"Clave '{key}' no encontrada en array[{item_index}]")
            else:
                raise AssertionError(f"Índice {item_index} fuera de rango del array")
        else:
            raise AssertionError("La respuesta no es un array JSON")
            
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")

@step('I send multipart form request to "{url}" with fields "{fields}" and store response in variable "{variable_name}"')
@step('envío petición multipart form a "{url}" con campos "{fields}" y guardo la respuesta en la variable "{variable_name}"')
def step_send_multipart_form_request(context, url, fields, variable_name):
    """Envía una petición multipart/form-data"""
    resolved_url = context.variable_manager.resolve_variables(url)
    resolved_fields = context.variable_manager.resolve_variables(fields)
    
    try:
        # Parsear campos como JSON
        fields_data = json.loads(resolved_fields)
        
        response = requests.post(resolved_url, data=fields_data)
        
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': response.text,
            'json': response.json() if response.headers.get('content-type', '').startswith('application/json') else None
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(response_data))
        context.last_api_response = response
        
        print(f"✓ Multipart form request enviado a {resolved_url}")
        print(f"  Status: {response.status_code}")
        
    except Exception as e:
        print(f"✗ Error en multipart form request: {e}")
        raise

@step('I upload file "{file_path}" to API endpoint "{url}" with field name "{field_name}" and store response in variable "{variable_name}"')
@step('subo archivo "{file_path}" al endpoint API "{url}" con nombre de campo "{field_name}" y guardo la respuesta en la variable "{variable_name}"')
def step_upload_file_to_api(context, file_path, url, field_name, variable_name):
    """Sube un archivo a un endpoint API"""
    resolved_url = context.variable_manager.resolve_variables(url)
    resolved_path = context.variable_manager.resolve_variables(file_path)
    
    try:
        with open(resolved_path, 'rb') as file:
            files = {field_name: file}
            response = requests.post(resolved_url, files=files)
        
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': response.text,
            'json': response.json() if response.headers.get('content-type', '').startswith('application/json') else None
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(response_data))
        context.last_api_response = response
        
        print(f"✓ Archivo '{resolved_path}' subido a {resolved_url}")
        print(f"  Status: {response.status_code}")
        
    except Exception as e:
        print(f"✗ Error subiendo archivo: {e}")
        raise

@step('I set API timeout to "{timeout}" seconds')
@step('establezco el timeout de API a "{timeout}" segundos')
def step_set_api_timeout(context, timeout):
    """Establece el timeout para las peticiones API"""
    context.api_timeout = float(timeout)
    print(f"✓ Timeout de API establecido a {timeout} segundos")

@step('I verify API response status is in range "{min_status}" to "{max_status}"')
@step('verifico que el estado de respuesta API está en el rango "{min_status}" a "{max_status}"')
def step_verify_api_status_range(context, min_status, max_status):
    """Verifica que el código de estado está dentro de un rango"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    actual_status = context.last_api_response.status_code
    min_status_int = int(min_status)
    max_status_int = int(max_status)
    
    if min_status_int <= actual_status <= max_status_int:
        print(f"✓ Código de estado {actual_status} está en rango {min_status_int}-{max_status_int}")
    else:
        print(f"✗ Código de estado {actual_status} fuera de rango {min_status_int}-{max_status_int}")
        raise AssertionError(f"Código de estado {actual_status} fuera de rango")

@step('I verify API response content type is "{expected_content_type}"')
@step('verifico que el tipo de contenido de respuesta API es "{expected_content_type}"')
def step_verify_api_content_type(context, expected_content_type):
    """Verifica el tipo de contenido de la respuesta"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    actual_content_type = context.last_api_response.headers.get('content-type', '')
    resolved_expected = context.variable_manager.resolve_variables(expected_content_type)
    
    if resolved_expected in actual_content_type:
        print(f"✓ Tipo de contenido correcto: {actual_content_type}")
    else:
        print(f"✗ Tipo de contenido incorrecto. Esperado: {resolved_expected}, Actual: {actual_content_type}")
        raise AssertionError(f"Tipo de contenido incorrecto")

@step('I save API response body to file "{file_path}"')
@step('guardo el cuerpo de respuesta API en el archivo "{file_path}"')
def step_save_api_response_to_file(context, file_path):
    """Guarda el cuerpo de respuesta API en un archivo"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible")
    
    resolved_path = context.variable_manager.resolve_variables(file_path)
    
    try:
        with open(resolved_path, 'w', encoding='utf-8') as file:
            file.write(context.last_api_response.text)
        
        print(f"✓ Respuesta API guardada en '{resolved_path}'")
        
    except Exception as e:
        print(f"✗ Error guardando respuesta: {e}")
        raise

@step('I load API request body from file "{file_path}" and send POST to "{url}" storing response in variable "{variable_name}"')
@step('cargo el cuerpo de petición API del archivo "{file_path}" y envío POST a "{url}" guardando respuesta en variable "{variable_name}"')
def step_load_and_send_post_from_file(context, file_path, url, variable_name):
    """Carga el cuerpo de petición desde un archivo y envía POST"""
    resolved_path = context.variable_manager.resolve_variables(file_path)
    resolved_url = context.variable_manager.resolve_variables(url)
    
    try:
        with open(resolved_path, 'r', encoding='utf-8') as file:
            body_content = file.read()
        
        # Intentar parsear como JSON
        try:
            json_body = json.loads(body_content)
            headers = {'Content-Type': 'application/json'}
            response = requests.post(resolved_url, json=json_body, headers=headers)
        except json.JSONDecodeError:
            headers = {'Content-Type': 'text/plain'}
            response = requests.post(resolved_url, data=body_content, headers=headers)
        
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': response.text,
            'json': response.json() if response.headers.get('content-type', '').startswith('application/json') else None
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(response_data))
        context.last_api_response = response
        
        print(f"✓ POST request enviado con cuerpo desde '{resolved_path}'")
        print(f"  Status: {response.status_code}")
        
    except Exception as e:
        print(f"✗ Error cargando archivo o enviando request: {e}")
        raise

@step('I verify API response JSON schema matches file "{schema_file}"')
@step('verifico que el esquema JSON de respuesta API coincide con el archivo "{schema_file}"')
def step_verify_api_response_schema(context, schema_file):
    """Verifica que la respuesta JSON coincide con un esquema"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    resolved_schema_file = context.variable_manager.resolve_variables(schema_file)
    
    try:
        # Cargar esquema
        with open(resolved_schema_file, 'r', encoding='utf-8') as file:
            schema = json.load(file)
        
        # Obtener respuesta JSON
        response_json = context.last_api_response.json()
        
        # Validación básica de esquema (simplificada)
        def validate_schema(data, schema_obj):
            if 'type' in schema_obj:
                expected_type = schema_obj['type']
                if expected_type == 'object' and not isinstance(data, dict):
                    return False
                elif expected_type == 'array' and not isinstance(data, list):
                    return False
                elif expected_type == 'string' and not isinstance(data, str):
                    return False
                elif expected_type == 'number' and not isinstance(data, (int, float)):
                    return False
            
            if 'properties' in schema_obj and isinstance(data, dict):
                for prop, prop_schema in schema_obj['properties'].items():
                    if prop in data:
                        if not validate_schema(data[prop], prop_schema):
                            return False
            
            return True
        
        if validate_schema(response_json, schema):
            print(f"✓ Respuesta JSON coincide con esquema '{resolved_schema_file}'")
        else:
            print(f"✗ Respuesta JSON no coincide con esquema '{resolved_schema_file}'")
            raise AssertionError("Respuesta JSON no coincide con esquema")
            
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")
    except Exception as e:
        print(f"✗ Error validando esquema: {e}")
        raise

@step('I send batch API requests from file "{requests_file}" and store results in variable "{variable_name}"')
@step('envío peticiones API en lote desde archivo "{requests_file}" y guardo resultados en variable "{variable_name}"')
def step_send_batch_api_requests(context, requests_file, variable_name):
    """Envía múltiples peticiones API desde un archivo de configuración"""
    resolved_file = context.variable_manager.resolve_variables(requests_file)
    
    try:
        with open(resolved_file, 'r', encoding='utf-8') as file:
            requests_config = json.load(file)
        
        results = []
        
        for i, req_config in enumerate(requests_config):
            method = req_config.get('method', 'GET').upper()
            url = context.variable_manager.resolve_variables(req_config['url'])
            headers = req_config.get('headers', {})
            body = req_config.get('body')
            
            try:
                if method == 'GET':
                    response = requests.get(url, headers=headers)
                elif method == 'POST':
                    if body:
                        if isinstance(body, dict):
                            response = requests.post(url, json=body, headers=headers)
                        else:
                            response = requests.post(url, data=body, headers=headers)
                    else:
                        response = requests.post(url, headers=headers)
                elif method == 'PUT':
                    if body:
                        if isinstance(body, dict):
                            response = requests.put(url, json=body, headers=headers)
                        else:
                            response = requests.put(url, data=body, headers=headers)
                    else:
                        response = requests.put(url, headers=headers)
                elif method == 'DELETE':
                    response = requests.delete(url, headers=headers)
                else:
                    raise ValueError(f"Método HTTP no soportado: {method}")
                
                result = {
                    'request_index': i,
                    'method': method,
                    'url': url,
                    'status_code': response.status_code,
                    'headers': dict(response.headers),
                    'body': response.text,
                    'json': response.json() if response.headers.get('content-type', '').startswith('application/json') else None
                }
                
                results.append(result)
                print(f"  ✓ Request {i+1}: {method} {url} -> {response.status_code}")
                
            except Exception as e:
                result = {
                    'request_index': i,
                    'method': method,
                    'url': url,
                    'error': str(e)
                }
                results.append(result)
                print(f"  ✗ Request {i+1}: {method} {url} -> Error: {e}")
        
        context.variable_manager.set_variable(variable_name, json.dumps(results))
        print(f"✓ {len(requests_config)} peticiones API en lote completadas")
        
    except Exception as e:
        print(f"✗ Error en peticiones en lote: {e}")
        raise

@step('I verify API response matches expected response from file "{expected_file}"')
@step('verifico que la respuesta API coincide con la respuesta esperada del archivo "{expected_file}"')
def step_verify_api_response_matches_file(context, expected_file):
    """Verifica que la respuesta API coincide con una respuesta esperada en archivo"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    resolved_file = context.variable_manager.resolve_variables(expected_file)
    
    try:
        with open(resolved_file, 'r', encoding='utf-8') as file:
            expected_response = json.load(file)
        
        actual_response = context.last_api_response.json()
        
        if actual_response == expected_response:
            print(f"✓ Respuesta API coincide con archivo '{resolved_file}'")
        else:
            print(f"✗ Respuesta API no coincide con archivo '{resolved_file}'")
            print(f"  Esperado: {json.dumps(expected_response, indent=2)}")
            print(f"  Actual: {json.dumps(actual_response, indent=2)}")
            raise AssertionError("Respuesta API no coincide con archivo esperado")
            
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")
    except Exception as e:
        print(f"✗ Error comparando respuesta: {e}")
        raise
@step('I set API base URL to "{base_url}"')
@step('establezco la URL base de API a "{base_url}"')
def step_set_api_base_url(context, base_url):
    """Establece una URL base para las peticiones API"""
    context.api_base_url = context.variable_manager.resolve_variables(base_url)
    print(f"✓ URL base de API establecida: {context.api_base_url}")

@step('I send GET request to endpoint "{endpoint}" and store response in variable "{variable_name}"')
@step('envío petición GET al endpoint "{endpoint}" y guardo la respuesta en la variable "{variable_name}"')
def step_send_get_to_endpoint(context, endpoint, variable_name):
    """Envía GET usando URL base + endpoint"""
    base_url = getattr(context, 'api_base_url', '')
    resolved_endpoint = context.variable_manager.resolve_variables(endpoint)
    full_url = f"{base_url.rstrip('/')}/{resolved_endpoint.lstrip('/')}"
    
    # Reutilizar la función existente
    step_send_get_request(context, full_url, variable_name)

@step('I verify API response has pagination with total "{expected_total}" and page "{expected_page}"')
@step('verifico que la respuesta API tiene paginación con total "{expected_total}" y página "{expected_page}"')
def step_verify_api_pagination(context, expected_total, expected_page):
    """Verifica información de paginación en la respuesta API"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    try:
        response_json = context.last_api_response.json()
        
        # Buscar campos comunes de paginación
        pagination_fields = {
            'total': ['total', 'totalCount', 'total_count', 'count'],
            'page': ['page', 'currentPage', 'current_page', 'pageNumber']
        }
        
        total_value = None
        page_value = None
        
        for field_name in pagination_fields['total']:
            if field_name in response_json:
                total_value = response_json[field_name]
                break
        
        for field_name in pagination_fields['page']:
            if field_name in response_json:
                page_value = response_json[field_name]
                break
        
        expected_total_int = int(expected_total)
        expected_page_int = int(expected_page)
        
        errors = []
        
        if total_value is not None:
            if int(total_value) == expected_total_int:
                print(f"✓ Total correcto: {total_value}")
            else:
                errors.append(f"Total incorrecto: {total_value}, esperado: {expected_total_int}")
        else:
            errors.append("Campo 'total' no encontrado en respuesta")
        
        if page_value is not None:
            if int(page_value) == expected_page_int:
                print(f"✓ Página correcta: {page_value}")
            else:
                errors.append(f"Página incorrecta: {page_value}, esperado: {expected_page_int}")
        else:
            errors.append("Campo 'page' no encontrado en respuesta")
        
        if errors:
            raise AssertionError("; ".join(errors))
            
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")

@step('I verify API response rate limit headers are present')
@step('verifico que los headers de rate limit están presentes en la respuesta API')
def step_verify_rate_limit_headers(context):
    """Verifica que los headers de rate limiting están presentes"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    rate_limit_headers = [
        'X-RateLimit-Limit',
        'X-RateLimit-Remaining',
        'X-RateLimit-Reset',
        'RateLimit-Limit',
        'RateLimit-Remaining',
        'RateLimit-Reset'
    ]
    
    found_headers = []
    for header in rate_limit_headers:
        if header in context.last_api_response.headers:
            found_headers.append(f"{header}: {context.last_api_response.headers[header]}")
    
    if found_headers:
        print("✓ Headers de rate limit encontrados:")
        for header in found_headers:
            print(f"  {header}")
    else:
        print("⚠ No se encontraron headers de rate limit")

@step('I send concurrent API requests "{count}" times to "{url}" and verify all succeed')
@step('envío peticiones API concurrentes "{count}" veces a "{url}" y verifico que todas tengan éxito')
def step_send_concurrent_api_requests(context, count, url):
    """Envía múltiples peticiones concurrentes para testing de carga"""
    import threading
    import time
    
    resolved_url = context.variable_manager.resolve_variables(url)
    request_count = int(count)
    
    results = []
    threads = []
    
    def make_request():
        try:
            start_time = time.time()
            response = requests.get(resolved_url)
            end_time = time.time()
            
            results.append({
                'status_code': response.status_code,
                'response_time': end_time - start_time,
                'success': 200 <= response.status_code < 300
            })
        except Exception as e:
            results.append({
                'error': str(e),
                'success': False
            })
    
    # Crear y ejecutar threads
    start_time = time.time()
    for _ in range(request_count):
        thread = threading.Thread(target=make_request)
        threads.append(thread)
        thread.start()
    
    # Esperar a que terminen todos
    for thread in threads:
        thread.join()
    
    end_time = time.time()
    
    # Analizar resultados
    successful_requests = sum(1 for r in results if r.get('success', False))
    failed_requests = request_count - successful_requests
    avg_response_time = sum(r.get('response_time', 0) for r in results if 'response_time' in r) / len([r for r in results if 'response_time' in r])
    
    print(f"✓ Peticiones concurrentes completadas:")
    print(f"  Total: {request_count}")
    print(f"  Exitosas: {successful_requests}")
    print(f"  Fallidas: {failed_requests}")
    print(f"  Tiempo total: {end_time - start_time:.2f}s")
    print(f"  Tiempo promedio de respuesta: {avg_response_time:.3f}s")
    
    if failed_requests > 0:
        print(f"⚠ {failed_requests} peticiones fallaron")
    
    # Guardar resultados en contexto
    context.concurrent_test_results = results

@step('I verify API endpoint "{endpoint}" supports CORS')
@step('verifico que el endpoint API "{endpoint}" soporta CORS')
def step_verify_api_cors_support(context, endpoint):
    """Verifica que un endpoint soporta CORS"""
    resolved_endpoint = context.variable_manager.resolve_variables(endpoint)
    base_url = getattr(context, 'api_base_url', '')
    full_url = f"{base_url.rstrip('/')}/{resolved_endpoint.lstrip('/')}" if base_url else resolved_endpoint
    
    try:
        # Enviar OPTIONS request para verificar CORS
        response = requests.options(full_url)
        
        cors_headers = {
            'Access-Control-Allow-Origin': response.headers.get('Access-Control-Allow-Origin'),
            'Access-Control-Allow-Methods': response.headers.get('Access-Control-Allow-Methods'),
            'Access-Control-Allow-Headers': response.headers.get('Access-Control-Allow-Headers')
        }
        
        cors_supported = any(value for value in cors_headers.values())
        
        if cors_supported:
            print(f"✓ CORS soportado en {full_url}")
            for header, value in cors_headers.items():
                if value:
                    print(f"  {header}: {value}")
        else:
            print(f"✗ CORS no soportado en {full_url}")
            raise AssertionError(f"CORS no soportado en {full_url}")
            
    except Exception as e:
        print(f"✗ Error verificando CORS: {e}")
        raise

@step('I create API test data with template "{template}" and values "{values}" storing in variable "{variable_name}"')
@step('creo datos de prueba API con plantilla "{template}" y valores "{values}" guardando en variable "{variable_name}"')
def step_create_api_test_data(context, template, values, variable_name):
    """Crea datos de prueba usando una plantilla y valores"""
    resolved_template = context.variable_manager.resolve_variables(template)
    resolved_values = context.variable_manager.resolve_variables(values)
    
    try:
        # Parsear plantilla y valores
        template_data = json.loads(resolved_template)
        values_data = json.loads(resolved_values)
        
        # Reemplazar placeholders en la plantilla
        def replace_placeholders(obj, values):
            if isinstance(obj, dict):
                return {k: replace_placeholders(v, values) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [replace_placeholders(item, values) for item in obj]
            elif isinstance(obj, str):
                # Reemplazar placeholders como {{key}}
                import re
                def replacer(match):
                    key = match.group(1)
                    return str(values.get(key, match.group(0)))
                return re.sub(r'\{\{(\w+)\}\}', replacer, obj)
            else:
                return obj
        
        result_data = replace_placeholders(template_data, values_data)
        
        context.variable_manager.set_variable(variable_name, json.dumps(result_data))
        print(f"✓ Datos de prueba API creados y guardados en variable '{variable_name}'")
        
    except Exception as e:
        print(f"✗ Error creando datos de prueba: {e}")
        raise

@step('I verify API response follows REST conventions for "{http_method}" method')
@step('verifico que la respuesta API sigue las convenciones REST para el método "{http_method}"')
def step_verify_rest_conventions(context, http_method):
    """Verifica que la respuesta sigue las convenciones REST"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    method = http_method.upper()
    status_code = context.last_api_response.status_code
    
    # Convenciones REST por método
    rest_conventions = {
        'GET': {
            'success_codes': [200],
            'description': 'GET debe retornar 200 para éxito'
        },
        'POST': {
            'success_codes': [200, 201],
            'description': 'POST debe retornar 200 o 201 para éxito'
        },
        'PUT': {
            'success_codes': [200, 204],
            'description': 'PUT debe retornar 200 o 204 para éxito'
        },
        'PATCH': {
            'success_codes': [200, 204],
            'description': 'PATCH debe retornar 200 o 204 para éxito'
        },
        'DELETE': {
            'success_codes': [200, 204],
            'description': 'DELETE debe retornar 200 o 204 para éxito'
        }
    }
    
    if method in rest_conventions:
        expected_codes = rest_conventions[method]['success_codes']
        description = rest_conventions[method]['description']
        
        if status_code in expected_codes:
            print(f"✓ Convención REST cumplida: {description}")
        else:
            print(f"✗ Convención REST no cumplida: {description}")
            print(f"  Status actual: {status_code}, esperados: {expected_codes}")
            raise AssertionError(f"Convención REST no cumplida para método {method}")
    else:
        print(f"⚠ Método {method} no tiene convenciones REST definidas")

@step('I measure API performance for "{iterations}" requests to "{url}" and store metrics in variable "{variable_name}"')
@step('mido el rendimiento de API para "{iterations}" peticiones a "{url}" y guardo métricas en variable "{variable_name}"')
def step_measure_api_performance(context, iterations, url, variable_name):
    """Mide el rendimiento de una API con múltiples peticiones"""
    resolved_url = context.variable_manager.resolve_variables(url)
    iteration_count = int(iterations)
    
    response_times = []
    status_codes = []
    errors = []
    
    print(f"Midiendo rendimiento API con {iteration_count} peticiones...")
    
    for i in range(iteration_count):
        try:
            start_time = time.time()
            response = requests.get(resolved_url)
            end_time = time.time()
            
            response_time = end_time - start_time
            response_times.append(response_time)
            status_codes.append(response.status_code)
            
            if i % 10 == 0:  # Mostrar progreso cada 10 peticiones
                print(f"  Progreso: {i+1}/{iteration_count}")
                
        except Exception as e:
            errors.append(str(e))
    
    # Calcular métricas
    if response_times:
        metrics = {
            'total_requests': iteration_count,
            'successful_requests': len(response_times),
            'failed_requests': len(errors),
            'min_response_time': min(response_times),
            'max_response_time': max(response_times),
            'avg_response_time': sum(response_times) / len(response_times),
            'median_response_time': sorted(response_times)[len(response_times)//2],
            'status_codes': dict(zip(*zip(*[(code, status_codes.count(code)) for code in set(status_codes)]))),
            'error_rate': len(errors) / iteration_count * 100
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(metrics))
        
        print(f"✓ Métricas de rendimiento:")
        print(f"  Peticiones exitosas: {metrics['successful_requests']}/{iteration_count}")
        print(f"  Tiempo promedio: {metrics['avg_response_time']:.3f}s")
        print(f"  Tiempo mínimo: {metrics['min_response_time']:.3f}s")
        print(f"  Tiempo máximo: {metrics['max_response_time']:.3f}s")
        print(f"  Tasa de error: {metrics['error_rate']:.1f}%")
        
    else:
        raise AssertionError("No se pudieron completar peticiones para medir rendimiento")

@step('I verify API response has security headers')
@step('verifico que la respuesta API tiene headers de seguridad')
def step_verify_api_security_headers(context):
    """Verifica que la respuesta tiene headers de seguridad importantes"""
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    security_headers = {
        'X-Content-Type-Options': 'nosniff',
        'X-Frame-Options': ['DENY', 'SAMEORIGIN'],
        'X-XSS-Protection': '1; mode=block',
        'Strict-Transport-Security': None,  # Solo verificar presencia
        'Content-Security-Policy': None,
        'Referrer-Policy': None
    }
    
    found_headers = []
    missing_headers = []
    
    for header, expected_values in security_headers.items():
        actual_value = context.last_api_response.headers.get(header)
        
        if actual_value:
            if expected_values is None:
                found_headers.append(f"{header}: {actual_value}")
            elif isinstance(expected_values, list):
                if actual_value in expected_values:
                    found_headers.append(f"{header}: {actual_value}")
                else:
                    found_headers.append(f"{header}: {actual_value} (valor inesperado)")
            elif actual_value == expected_values:
                found_headers.append(f"{header}: {actual_value}")
            else:
                found_headers.append(f"{header}: {actual_value} (valor inesperado)")
        else:
            missing_headers.append(header)
    
    if found_headers:
        print("✓ Headers de seguridad encontrados:")
        for header in found_headers:
            print(f"  {header}")
    
    if missing_headers:
        print("⚠ Headers de seguridad faltantes:")
        for header in missing_headers:
            print(f"  {header}")
    
    # No fallar si faltan headers, solo informar
    print(f"✓ Verificación de headers de seguridad completada")

@step('I clear all API session data')
@step('limpio todos los datos de sesión API')
def step_clear_api_session_data(context):
    """Limpia todos los datos de sesión API"""
    # Limpiar headers personalizados
    if hasattr(context, 'api_headers'):
        delattr(context, 'api_headers')
    
    # Limpiar URL base
    if hasattr(context, 'api_base_url'):
        delattr(context, 'api_base_url')
    
    # Limpiar timeout
    if hasattr(context, 'api_timeout'):
        delattr(context, 'api_timeout')
    
    # Limpiar última respuesta
    if hasattr(context, 'last_api_response'):
        delattr(context, 'last_api_response')
    
    print("✓ Datos de sesión API limpiados")


# ============================================================================
# NUEVOS PASOS - INTERCEPTACIÓN DE LLAMADAS A APIS DESDE EL NAVEGADOR
# ============================================================================

@step('I start intercepting API calls to "{api_url}"')
@step('inicio la escucha de llamadas a API')
@step('que inicio la escucha de llamadas a API')
def step_start_listening_api_calls(context):
    """Inicia la escucha global de todas las llamadas a API (requests y responses)
    
    Esto activa listeners que guardan TODAS las llamadas en background de forma asincrónica.
    Los datos se guardan en context.api_calls para acceder después.
    
    Ejemplo:
        When inicio la escucha de llamadas a API
        And hago click en el elemento "cargar" con identificador "$.BUTTON.load"
        And espero 2 segundos
        Then extraigo el valor de la respuesta API "disponibilidad" en la ruta "data.resumen.porcentaje" y lo guardo en "porcentaje"
    """
    
    # Inicializar estructura para guardar llamadas
    if not hasattr(context, 'api_calls'):
        context.api_calls = {}  # {url: {'request': {...}, 'response': {...}}}
    
    # Marcar que la escucha está activa
    context.api_listening_active = True
    
    # Listener para responses (se ejecuta en background)
    def handle_response(response):
        """Captura responses de forma asincrónica"""
        try:
            # Solo guardar si la escucha está activa
            if not getattr(context, 'api_listening_active', False):
                return
            
            # Verificar que context.api_calls existe (puede no existir en nuevo contexto)
            if not hasattr(context, 'api_calls'):
                context.api_calls = {}
            
            url = response.url
            method = response.request.method
            
            # Obtener el body de forma segura
            try:
                body = response.text()
            except:
                body = ""
            
            # Parsear JSON si es posible
            json_data = None
            try:
                json_data = json.loads(body)
            except:
                pass
            
            # Guardar la response
            if url not in context.api_calls:
                context.api_calls[url] = {}
            
            context.api_calls[url]['response'] = {
                'status': response.status,
                'headers': dict(response.headers),
                'body': body,
                'json': json_data,
                'timestamp': time.time()
            }
            
            print(f"✓ Response guardada: {url} (Status: {response.status})")
        except Exception as e:
            print(f"⚠️ Error guardando response: {e}")
    
    # Listener para requests (se ejecuta en background)
    def handle_request(request):
        """Captura requests de forma asincrónica"""
        try:
            # Solo guardar si la escucha está activa
            if not getattr(context, 'api_listening_active', False):
                return
            
            # Verificar que context.api_calls existe (puede no existir en nuevo contexto)
            if not hasattr(context, 'api_calls'):
                context.api_calls = {}
            
            url = request.url
            
            # Guardar el request
            if url not in context.api_calls:
                context.api_calls[url] = {}
            
            context.api_calls[url]['request'] = {
                'method': request.method,
                'headers': dict(request.headers),
                'post_data': request.post_data,
                'post_data_json': request.post_data_json if request.post_data else None,
                'timestamp': time.time()
            }
            
            print(f"✓ Request guardado: {url}")
        except Exception as e:
            print(f"⚠️ Error guardando request: {e}")
    
    # Guardar referencias a los handlers para poder removerlos después
    context.api_request_handler = handle_request
    context.api_response_handler = handle_response
    
    # Registrar listeners globales (sin filtro de URL)
    context.page.on("request", handle_request)
    context.page.on("response", handle_response)
    
    print("✓ Escucha de llamadas a API iniciada (modo background)")

@step('I stop listening to API calls')
@step('detengo la escucha de llamadas a API')
def step_stop_listening_api_calls(context):
    """Detiene la escucha de llamadas a API"""
    # Marcar que la escucha ya no está activa
    context.api_listening_active = False
    
    # Intentar remover los listeners si existen las referencias
    if hasattr(context, 'page') and context.page:
        try:
            if hasattr(context, 'api_request_handler'):
                context.page.remove_listener("request", context.api_request_handler)
            if hasattr(context, 'api_response_handler'):
                context.page.remove_listener("response", context.api_response_handler)
        except Exception as e:
            # Si falla, al menos la flag api_listening_active evitará que se guarden más datos
            pass
    
    print("✓ Escucha de llamadas a API detenida")

@step('I stop intercepting API calls')
@step('detengo la interceptación de llamadas a API')
def step_stop_intercepting_api(context):
    """Detiene la interceptación de llamadas a API"""
    if hasattr(context, 'page'):
        context.page.unroute("**/*")
    print("✓ Interceptación detenida")

@step('I verify API call was made to "{api_url}"')
@step('verifico que se realizó una llamada a la API en "{api_url}"')
def step_verify_api_call_made(context, api_url):
    """Verifica que se realizó una llamada a una API específica
    
    Busca en las llamadas guardadas por el listener de background.
    
    Ejemplo:
        Then verifico que se realizó una llamada a la API en "permisos/solicitudes/equipo/pendientes"
    """
    resolved_url = context.variable_manager.resolve_variables(api_url)
    
    if not hasattr(context, 'api_calls'):
        raise AssertionError("No hay escucha de API activa. Usa 'inicio la escucha de llamadas a API' primero.")
    
    # Buscar si se realizó una llamada a esta URL
    found = False
    for url in context.api_calls.keys():
        if resolved_url in url:
            found = True
            break
    
    if found:
        print(f"✓ Se encontró llamada a API: {resolved_url}")
    else:
        available_urls = list(context.api_calls.keys())
        print(f"✗ No se encontró llamada a API: {resolved_url}")
        print(f"  Llamadas disponibles: {available_urls}")
        raise AssertionError(f"No se encontró llamada a API: {resolved_url}")

@step('I verify API call was made with method "{method}" to "{api_url}"')
@step('verifico que se realizó una llamada a la API "{api_url}" usando método "{method}"')
def step_verify_api_call_with_method(context, method, api_url):
    """Verifica que se realizó una llamada a una API con un método HTTP específico
    
    Ejemplo:
        Then verifico que se realizó una llamada a la API "https://api.ejemplo.com/usuarios" con método "POST"
    """
    resolved_url = context.variable_manager.resolve_variables(api_url)
    resolved_method = method.upper()
    
    if not hasattr(context, 'intercepted_requests'):
        raise AssertionError("No hay interceptación de API activa")
    
    # Buscar si se realizó una llamada con este método a esta URL
    found = False
    for request in context.intercepted_requests:
        if resolved_url in request['url'] and request['method'] == resolved_method:
            found = True
            context.last_intercepted_request = request
            break
    
    if found:
        print(f"✓ Se encontró llamada {resolved_method} a API: {resolved_url}")
    else:
        print(f"✗ No se encontró llamada {resolved_method} a API: {resolved_url}")
        raise AssertionError(f"No se encontró llamada {resolved_method} a API: {resolved_url}")

@step('I verify API call contains parameter "{parameter}" with value "{value}"')
@step('verifico que la llamada a API contiene el parámetro "{parameter}" con valor "{value}"')
def step_verify_api_call_parameter(context, parameter, value):
    """Verifica que la última llamada a API contiene un parámetro específico
    
    Ejemplo:
        And verifico que la llamada a API contiene el parámetro "nombre" con valor "Juan"
    """
    if not hasattr(context, 'last_intercepted_request'):
        raise AssertionError("No hay última llamada a API interceptada")
    
    request = context.last_intercepted_request
    resolved_value = context.variable_manager.resolve_variables(value)
    
    # Intentar obtener el parámetro del JSON body
    if request['post_data_json']:
        if parameter in request['post_data_json']:
            actual_value = str(request['post_data_json'][parameter])
            if actual_value == str(resolved_value):
                print(f"✓ Parámetro '{parameter}' encontrado con valor '{resolved_value}'")
            else:
                print(f"✗ Parámetro '{parameter}' tiene valor '{actual_value}', esperado '{resolved_value}'")
                raise AssertionError(f"Parámetro '{parameter}' tiene valor incorrecto")
        else:
            print(f"✗ Parámetro '{parameter}' no encontrado en request")
            raise AssertionError(f"Parámetro '{parameter}' no encontrado")
    else:
        print(f"✗ Request no tiene JSON body")
        raise AssertionError("Request no tiene JSON body")

@step('I verify API call contains header "{header_name}" with value "{header_value}"')
@step('verifico que la llamada a API contiene el header "{header_name}" con valor "{header_value}"')
def step_verify_api_call_header(context, header_name, header_value):
    """Verifica que la última llamada a API contiene un header específico
    
    Ejemplo:
        And verifico que la llamada a API contiene el header "Authorization" con valor "Bearer token123"
    """
    if not hasattr(context, 'last_intercepted_request'):
        raise AssertionError("No hay última llamada a API interceptada")
    
    request = context.last_intercepted_request
    resolved_value = context.variable_manager.resolve_variables(header_value)
    
    # Buscar el header (case-insensitive)
    found_header = None
    for header_key, header_val in request['headers'].items():
        if header_key.lower() == header_name.lower():
            found_header = header_val
            break
    
    if found_header:
        if found_header == resolved_value:
            print(f"✓ Header '{header_name}' encontrado con valor correcto")
        else:
            print(f"✗ Header '{header_name}' tiene valor '{found_header}', esperado '{resolved_value}'")
            raise AssertionError(f"Header '{header_name}' tiene valor incorrecto")
    else:
        print(f"✗ Header '{header_name}' no encontrado")
        raise AssertionError(f"Header '{header_name}' no encontrado")

@step('I verify number of API calls to "{api_url}" is "{expected_count}"')
@step('verifico que el número de llamadas a la API "{api_url}" es "{expected_count}"')
def step_verify_api_call_count(context, api_url, expected_count):
    """Verifica que se realizó un número específico de llamadas a una API
    
    Ejemplo:
        Then verifico que el número de llamadas a la API "https://api.ejemplo.com/usuarios" es "2"
    """
    resolved_url = context.variable_manager.resolve_variables(api_url)
    expected_count_int = int(expected_count)
    
    if not hasattr(context, 'intercepted_requests'):
        raise AssertionError("No hay interceptación de API activa")
    
    # Contar llamadas a esta URL
    count = 0
    for request in context.intercepted_requests:
        if resolved_url in request['url']:
            count += 1
    
    if count == expected_count_int:
        print(f"✓ Se encontraron {count} llamadas a API: {resolved_url}")
    else:
        print(f"✗ Se encontraron {count} llamadas, esperado {expected_count_int}")
        raise AssertionError(f"Número de llamadas incorrecto: {count} vs {expected_count_int}")

@step('I store API call data in variable "{variable_name}"')
@step('guardo los datos de la llamada a API en la variable "{variable_name}"')
def step_store_api_call_data(context, variable_name):
    """Guarda los datos de la última llamada a API en una variable
    
    Ejemplo:
        And guardo los datos de la llamada a API en la variable "ultima_llamada"
    """
    if not hasattr(context, 'last_intercepted_request'):
        raise AssertionError("No hay última llamada a API interceptada")
    
    request = context.last_intercepted_request
    request_data = {
        'url': request['url'],
        'method': request['method'],
        'headers': request['headers'],
        'body': request['post_data_json'] if request['post_data_json'] else request['post_data']
    }
    
    context.variable_manager.set_variable(variable_name, json.dumps(request_data))
    print(f"✓ Datos de llamada a API guardados en variable '{variable_name}'")

@step('I verify API call was NOT made to "{api_url}"')
@step('verifico que NO se realizó una llamada a la API "{api_url}"')
def step_verify_api_call_not_made(context, api_url):
    """Verifica que NO se realizó una llamada a una API específica
    
    Ejemplo:
        Then verifico que NO se realizó una llamada a la API "https://api.ejemplo.com/delete"
    """
    resolved_url = context.variable_manager.resolve_variables(api_url)
    
    if not hasattr(context, 'intercepted_requests'):
        raise AssertionError("No hay interceptación de API activa")
    
    # Buscar si se realizó una llamada a esta URL
    found = False
    for request in context.intercepted_requests:
        if resolved_url in request['url']:
            found = True
            break
    
    if not found:
        print(f"✓ No se encontró llamada a API: {resolved_url}")
    else:
        print(f"✗ Se encontró llamada a API cuando no debería: {resolved_url}")
        raise AssertionError(f"Se encontró llamada a API: {resolved_url}")

@step('I clear intercepted API calls')
@step('limpio las llamadas a API interceptadas')
def step_clear_intercepted_calls(context):
    """Limpia el registro de llamadas a API interceptadas
    
    Ejemplo:
        When limpio las llamadas a API interceptadas
    """
    if hasattr(context, 'intercepted_requests'):
        context.intercepted_requests = []
    if hasattr(context, 'intercepted_responses'):
        context.intercepted_responses = []
    print("✓ Registro de llamadas a API limpiado")

@step('I retrieve value from captured API response "{api_url}" at path "{json_path}" and store in variable "{variable_name}"')
@step('obtengo el valor de la respuesta API capturada "{api_url}" en la ruta "{json_path}" y lo guardo en la variable "{variable_name}"')
def step_retrieve_from_captured_api_response(context, api_url, json_path, variable_name):
    """Extrae un valor de una respuesta API guardada en background
    
    Busca en las llamadas guardadas por el listener y extrae un valor usando notación de punto.
    
    Ejemplos:
        extraigo el valor de la respuesta API "disponibilidad" en la ruta "data.resumen.porcentaje_disponibilidad" y lo guardo en la variable "porcentaje"
        extraigo el valor de la respuesta API "https://api.ejemplo.com/usuarios" en la ruta "data.0.nombre" y lo guardo en la variable "primer_usuario"
    
    Notas:
        - La URL puede ser parcial (ej: "disponibilidad" coincidirá con cualquier URL que contenga esa palabra)
        - La ruta usa notación de punto para navegar JSON (ej: "data.resumen.valor")
        - Para arrays usa índices numéricos (ej: "data.0.nombre")
    """
    resolved_url = context.variable_manager.resolve_variables(api_url)
    
    if not hasattr(context, 'api_calls'):
        raise AssertionError("No hay escucha de API activa. Usa 'inicio la escucha de llamadas a API' primero.")
    
    # Buscar la llamada que coincida con la URL
    matching_call = None
    for url, call_data in context.api_calls.items():
        if resolved_url in url and 'response' in call_data:
            matching_call = call_data
            break
    
    if not matching_call:
        available_urls = list(context.api_calls.keys())
        raise AssertionError(
            f"No se encontró respuesta API que contenga '{resolved_url}'. "
            f"URLs disponibles: {available_urls}"
        )
    
    # Extraer el valor usando la ruta JSON
    if not matching_call['response'].get('json'):
        raise AssertionError(f"La respuesta de '{resolved_url}' no es JSON válido")
    
    try:
        # Navegar por la ruta (soporta notación de punto e índices)
        current_value = matching_call['response']['json']
        path_parts = json_path.split('.')
        
        for part in path_parts:
            # Intentar como índice de array
            if isinstance(current_value, list):
                try:
                    index = int(part)
                    current_value = current_value[index]
                except (ValueError, IndexError):
                    raise KeyError(f"Índice '{part}' no válido para array")
            # Intentar como clave de objeto
            elif isinstance(current_value, dict):
                if part in current_value:
                    current_value = current_value[part]
                else:
                    raise KeyError(f"Clave '{part}' no encontrada")
            else:
                raise KeyError(f"No se puede navegar '{part}' en tipo {type(current_value)}")
        
        # Guardar el valor en la variable
        context.variable_manager.set_variable(variable_name, str(current_value))
        print(f"✓ Valor extraído de '{resolved_url}' en ruta '{json_path}': '{current_value}' guardado en variable '{variable_name}'")
        
    except KeyError as e:
        raise AssertionError(f"Error al navegar ruta '{json_path}': {e}")
    except Exception as e:
        raise AssertionError(f"Error extrayendo valor: {e}")
