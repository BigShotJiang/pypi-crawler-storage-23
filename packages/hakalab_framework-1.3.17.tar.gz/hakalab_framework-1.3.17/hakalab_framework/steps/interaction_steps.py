from behave import step


def _get_element(context, selector, dynamic_value=None):
    """
    Función auxiliar para obtener elementos.
    Soporta tanto selectores CSS como identificadores JSON ($.ARCHIVO.elemento)
    Soporta placeholders dinámicos: $.ARCHIVO.elemento=valor
    Soporta iframes: Si context.current_frame existe, busca dentro del iframe
    """
    # Determinar si estamos dentro de un iframe
    page_or_frame = getattr(context, 'current_frame', None) or context.page
    
    if selector.startswith('$.') and hasattr(context, 'element_locator'):
        return context.element_locator.find(page_or_frame, selector, dynamic_value)
    else:
        return page_or_frame.locator(selector)

from playwright.sync_api import TimeoutError

@step('I click on the element "{element_name}" with identifier "{identifier}"')
@step('hago click en el elemento "{element_name}" con identificador "{identifier}"')
@step('que hago click en el elemento "{element_name}" con identificador "{identifier}"')
def step_click_element(context, element_name, identifier):
    """Hace click en un elemento"""
    element = _get_element(context, identifier)
    
    # Para selects/combobox, esperar a que esté visible antes de hacer click
    try:
        element.wait_for(state='visible', timeout=5000)
    except:
        pass
    
    element.click()
    
    # Pequeña pausa para que se estabilice el elemento después del click
    import time
    time.sleep(0.3)

@step('I click on the select "{element_name}" with identifier "{identifier}"')
@step('hago click en el select "{element_name}" con identificador "{identifier}"')
@step('que hago click en el select "{element_name}" con identificador "{identifier}"')
def step_click_select(context, element_name, identifier):
    """Hace click en un select/combobox"""
    element = _get_element(context, identifier)
    element.click()

@step('I double click on the element "{element_name}" with identifier "{identifier}"')
@step('hago doble click en el elemento "{element_name}" con identificador "{identifier}"')
@step('que hago doble click en el elemento "{element_name}" con identificador "{identifier}"')
def step_double_click_element(context, element_name, identifier):
    """Hace doble click en un elemento"""
    element = _get_element(context, identifier)
    element.dblclick()

@step('I right click on the element "{element_name}" with identifier "{identifier}"')
@step('hago click derecho en el elemento "{element_name}" con identificador "{identifier}"')
@step('que hago click derecho en el elemento "{element_name}" con identificador "{identifier}"')
def step_right_click_element(context, element_name, identifier):
    """Hace click derecho en un elemento"""
    element = _get_element(context, identifier)
    element.click(button='right')

@step('I hover over the element "{element_name}" with identifier "{identifier}"')
@step('paso el mouse sobre el elemento "{element_name}" con identificador "{identifier}"')
@step('que paso el mouse sobre el elemento "{element_name}" con identificador "{identifier}"')
def step_hover_element(context, element_name, identifier):
    """Pasa el mouse sobre un elemento"""
    element = _get_element(context, identifier)
    element.hover()

@step('I fill the field "{field_name}" with "{text}" with identifier "{identifier}"')
@step('relleno el campo "{field_name}" con "{text}" con identificador "{identifier}"')
@step('que relleno el campo "{field_name}" con "{text}" con identificador "{identifier}"')
def step_fill_field(context, field_name, text, identifier):
    """Rellena un campo de texto"""
    element = _get_element(context, identifier)
    resolved_text = context.variable_manager.resolve_variables(text)
    element.fill(resolved_text)

@step('I fill the date field "{field_name}" with "{date_text}" with identifier "{identifier}"')
@step('relleno el campo de fecha "{field_name}" con "{date_text}" con identificador "{identifier}"')
@step('que relleno el campo de fecha "{field_name}" con "{date_text}" con identificador "{identifier}"')
def step_fill_date_field(context, field_name, date_text, identifier):
    """Rellena un campo de fecha (input type="date") y dispara eventos de Angular
    
    Acepta formatos:
    - DD-MM-YYYY (01-01-2027) -> convierte a YYYY-MM-DD
    - YYYY-MM-DD (2027-01-01) -> usa directamente
    
    Dispara eventos input, change y blur para que Angular detecte el cambio.
    """
    element = _get_element(context, identifier)
    resolved_date = context.variable_manager.resolve_variables(date_text)
    
    # Convertir formato DD-MM-YYYY a YYYY-MM-DD si es necesario
    if '-' in resolved_date and len(resolved_date) == 10:
        parts = resolved_date.split('-')
        if len(parts) == 3:
            # Detectar si es DD-MM-YYYY o YYYY-MM-DD
            if int(parts[0]) > 31:
                # Es YYYY-MM-DD, usar directamente
                formatted_date = resolved_date
            else:
                # Es DD-MM-YYYY, convertir a YYYY-MM-DD
                formatted_date = f"{parts[2]}-{parts[1]}-{parts[0]}"
        else:
            formatted_date = resolved_date
    else:
        formatted_date = resolved_date
    
    # Rellenar el campo
    element.fill(formatted_date)
    
    events = ['input', 'change', 'keydown', 'keyup', 'keypress']
    for event in events:
        element.dispatch_event(event)

    element.blur() 
    
    element.evaluate("(el, val) => { el.value = val; }", formatted_date)

    # 2. Disparar la secuencia que espera el DatePicker de Angular
    # 'input' para el valor, 'change' para la validación, 'blur' para el estado 'touched'
    events_to_dispatch = ['input', 'change', 'blur']

    for event_name in events_to_dispatch:
        element.dispatch_event(event_name)

    # 3. TRUCO MAESTRO: Si el campo sigue marcando "Este campo es obligatorio" (ng-invalid)
    # A veces es necesario emitir un evento 'dateChange' personalizado si es un componente de terceros
    element.evaluate("""el => {
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
    }""")  
    
    # Pequeña espera para que Angular procese los eventos
    page_or_frame = getattr(context, 'current_frame', None) or context.page
    page_or_frame.wait_for_timeout(300)

@step('I clear the field "{field_name}" with identifier "{identifier}"')
@step('limpio el campo "{field_name}" con identificador "{identifier}"')
@step('que limpio el campo "{field_name}" con identificador "{identifier}"')
def step_clear_field(context, field_name, identifier):
    """Limpia un campo de texto"""
    element = _get_element(context, identifier)
    element.fill('')

@step('I type "{text}" in the field "{field_name}" with identifier "{identifier}"')
@step('escribo "{text}" en el campo "{field_name}" con identificador "{identifier}"')
@step('que escribo "{text}" en el campo "{field_name}" con identificador "{identifier}"')
def step_type_in_field(context, text, field_name, identifier):
    """Escribe texto en un campo (sin limpiar primero)"""
    locator = context.element_locator.get_locator(identifier)
    resolved_text = context.variable_manager.resolve_variables(text)
    context.page.type(locator, resolved_text)

@step('I select the option "{option}" from dropdown "{dropdown_name}" with identifier "{identifier}"')
@step('selecciono la opción "{option}" del dropdown "{dropdown_name}" con identificador "{identifier}"')
@step('que selecciono la opción "{option}" del dropdown "{dropdown_name}" con identificador "{identifier}"')
def step_select_option(context, option, dropdown_name, identifier):
    """Selecciona una opción de un dropdown"""
    locator = context.element_locator.get_locator(identifier)
    resolved_option = context.variable_manager.resolve_variables(option)
    context.page.select_option(locator, resolved_option)

@step('I check the checkbox "{checkbox_name}" with identifier "{identifier}"')
@step('marco el checkbox "{checkbox_name}" con identificador "{identifier}"')
@step('que marco el checkbox "{checkbox_name}" con identificador "{identifier}"')
def step_check_checkbox(context, checkbox_name, identifier):
    """Marca un checkbox"""
    locator = context.element_locator.get_locator(identifier)
    context.page.check(locator)

@step('I uncheck the checkbox "{checkbox_name}" with identifier "{identifier}"')
@step('desmarco el checkbox "{checkbox_name}" con identificador "{identifier}"')
@step('que desmarco el checkbox "{checkbox_name}" con identificador "{identifier}"')
def step_uncheck_checkbox(context, checkbox_name, identifier):
    """Desmarca un checkbox"""
    locator = context.element_locator.get_locator(identifier)
    context.page.uncheck(locator)

@step('I upload the file "{file_path}" to "{field_name}" with identifier "{identifier}"')
@step('subo el archivo "{file_path}" al campo "{field_name}" con identificador "{identifier}"')
@step('que subo el archivo "{file_path}" al campo "{field_name}" con identificador "{identifier}"')
def step_upload_file(context, file_path, field_name, identifier):
    """Sube un archivo"""
    locator = context.element_locator.get_locator(identifier)
    resolved_path = context.variable_manager.resolve_variables(file_path)
    context.page.set_input_files(locator, resolved_path)


@step('I remove the attribute "{attribute_name}" from element "{element_name}" with identifier "{identifier}"')
@step('remuevo el atributo "{attribute_name}" del elemento "{element_name}" con identificador "{identifier}"')
@step('que remuevo el atributo "{attribute_name}" del elemento "{element_name}" con identificador "{identifier}"')
def step_remove_attribute(context, attribute_name, element_name, identifier):
    """Remueve un atributo HTML de un elemento
    
    Ejemplos:
    - remuevo el atributo "readonly" del elemento "input" con identificador "$.SELECTORS.input_field"
    - remuevo el atributo "disabled" del elemento "botón" con identificador "$.SELECTORS.button"
    - remuevo el atributo "required" del elemento "campo" con identificador "$.SELECTORS.required_field"
    """
    locator = context.element_locator.get_locator(identifier)
    
    # Usar Playwright locator para obtener el elemento y luego JavaScript para remover el atributo
    element = context.page.locator(locator)
    
    # Verificar que el elemento existe
    try:
        element.wait_for(state='attached', timeout=5000)
    except:
        raise AssertionError(f"❌ Elemento '{element_name}' no encontrado con identificador '{identifier}'")
    
    # Remover el atributo usando JavaScript (usando parámetros para evitar problemas de sintaxis)
    element.evaluate("el => el.removeAttribute(arguments[0])", attribute_name)
    
    print(f"✓ Atributo '{attribute_name}' removido del elemento '{element_name}'")


@step('I set the attribute "{attribute_name}" to "{attribute_value}" on element "{element_name}" with identifier "{identifier}"')
@step('establezco el atributo "{attribute_name}" a "{attribute_value}" en el elemento "{element_name}" con identificador "{identifier}"')
@step('que establezco el atributo "{attribute_name}" a "{attribute_value}" en el elemento "{element_name}" con identificador "{identifier}"')
def step_set_attribute(context, attribute_name, attribute_value, element_name, identifier):
    """Establece o modifica un atributo HTML de un elemento
    
    Ejemplos:
    - establezco el atributo "placeholder" a "Ingrese su nombre" en el elemento "input" con identificador "$.SELECTORS.input_field"
    - establezco el atributo "data-test" a "my-value" en el elemento "div" con identificador "$.SELECTORS.container"
    """
    locator = context.element_locator.get_locator(identifier)
    
    # Resolver variables en el valor del atributo
    resolved_value = context.variable_manager.resolve_variables(attribute_value) if hasattr(context, 'variable_manager') else attribute_value
    
    # Usar Playwright locator para obtener el elemento y luego JavaScript para establecer el atributo
    element = context.page.locator(locator)
    
    # Verificar que el elemento existe
    try:
        element.wait_for(state='attached', timeout=5000)
    except:
        raise AssertionError(f"❌ Elemento '{element_name}' no encontrado con identificador '{identifier}'")
    
    # Establecer el atributo usando JavaScript
    element.evaluate(f"(el, name, value) => el.setAttribute(name, value)", [attribute_name, resolved_value])
    
    print(f"✓ Atributo '{attribute_name}' establecido a '{resolved_value}' en el elemento '{element_name}'")


@step('I verify that element "{element_name}" with identifier "{identifier}" has attribute "{attribute_name}"')
@step('verifico que el elemento "{element_name}" con identificador "{identifier}" tiene el atributo "{attribute_name}"')
@step('que verifico que el elemento "{element_name}" con identificador "{identifier}" tiene el atributo "{attribute_name}"')
def step_verify_attribute_exists(context, element_name, identifier, attribute_name):
    """Verifica que un elemento tiene un atributo específico
    
    Ejemplos:
    - verifico que el elemento "input" con identificador "$.SELECTORS.input_field" tiene el atributo "readonly"
    - verifico que el elemento "botón" con identificador "$.SELECTORS.button" tiene el atributo "disabled"
    """
    locator = context.element_locator.get_locator(identifier)
    
    # Usar Playwright locator para obtener el elemento
    element = context.page.locator(locator)
    
    # Verificar que el elemento existe
    try:
        element.wait_for(state='attached', timeout=5000)
    except:
        raise AssertionError(f"❌ Elemento '{element_name}' no encontrado con identificador '{identifier}'")
    
    # Verificar el atributo usando JavaScript
    has_attribute = element.evaluate(f"el => el.hasAttribute('{attribute_name}')")
    
    assert has_attribute, f"❌ El elemento '{element_name}' no tiene el atributo '{attribute_name}'"
    print(f"✓ El elemento '{element_name}' tiene el atributo '{attribute_name}'")


@step('I verify that element "{element_name}" with identifier "{identifier}" does not have attribute "{attribute_name}"')
@step('verifico que el elemento "{element_name}" con identificador "{identifier}" no tiene el atributo "{attribute_name}"')
@step('que verifico que el elemento "{element_name}" con identificador "{identifier}" no tiene el atributo "{attribute_name}"')
def step_verify_attribute_not_exists(context, element_name, identifier, attribute_name):
    """Verifica que un elemento NO tiene un atributo específico
    
    Ejemplos:
    - verifico que el elemento "input" con identificador "$.SELECTORS.input_field" no tiene el atributo "readonly"
    - verifico que el elemento "botón" con identificador "$.SELECTORS.button" no tiene el atributo "disabled"
    """
    locator = context.element_locator.get_locator(identifier)
    
    # Usar Playwright locator para obtener el elemento
    element = context.page.locator(locator)
    
    # Verificar que el elemento existe
    try:
        element.wait_for(state='attached', timeout=5000)
    except:
        raise AssertionError(f"❌ Elemento '{element_name}' no encontrado con identificador '{identifier}'")
    
    # Verificar el atributo usando JavaScript
    has_attribute = element.evaluate(f"el => el.hasAttribute('{attribute_name}')")
    
    assert not has_attribute, f"❌ El elemento '{element_name}' tiene el atributo '{attribute_name}' (no debería tenerlo)"
    print(f"✓ El elemento '{element_name}' no tiene el atributo '{attribute_name}'")


@step('I get the attribute "{attribute_name}" from element "{element_name}" with identifier "{identifier}" and store it in variable "{variable_name}"')
@step('obtengo el atributo "{attribute_name}" del elemento "{element_name}" con identificador "{identifier}" y lo guardo en la variable "{variable_name}"')
@step('que obtengo el atributo "{attribute_name}" del elemento "{element_name}" con identificador "{identifier}" y lo guardo en la variable "{variable_name}"')
def step_get_attribute(context, attribute_name, element_name, identifier, variable_name):
    """Obtiene el valor de un atributo HTML y lo guarda en una variable
    
    Ejemplos:
    - obtengo el atributo "value" del elemento "input" con identificador "$.SELECTORS.input_field" y lo guardo en la variable "input_value"
    - obtengo el atributo "href" del elemento "link" con identificador "$.SELECTORS.link" y lo guardo en la variable "link_url"
    """
    locator = context.element_locator.get_locator(identifier)
    
    # Usar Playwright locator para obtener el elemento
    element = context.page.locator(locator)
    
    # Verificar que el elemento existe
    try:
        element.wait_for(state='attached', timeout=5000)
    except:
        raise AssertionError(f"❌ Elemento '{element_name}' no encontrado con identificador '{identifier}'")
    
    # Obtener el atributo usando JavaScript
    attribute_value = element.evaluate(f"el => el.getAttribute('{attribute_name}')")
    
    if attribute_value is None:
        print(f"⚠ El atributo '{attribute_name}' no existe en el elemento '{element_name}'")
        attribute_value = ""
    
    # Guardar en variable
    if hasattr(context, 'variable_manager'):
        context.variable_manager.set_variable(variable_name, attribute_value)
    else:
        if not hasattr(context, 'test_variables'):
            context.test_variables = {}
        context.test_variables[variable_name] = attribute_value
    
    print(f"✓ Atributo '{attribute_name}' guardado en variable '{variable_name}': '{attribute_value}'")

@step('selecciono la fecha "{date_text}" en el input de fecha "{identifier}"')
def step_fill_native_date_picker(context, date_text, identifier):
    # 1. Localizar el elemento por su ID (fecha_inicio_1) o el identificador dinámico
    locator_query = context.element_locator.get_locator(identifier)
    element = context.page.locator(locator_query)
    
    # 2. Formatear la fecha a YYYY-MM-DD (Indispensable para type="date")
    # Si recibes "05-02-2026", lo convertimos:
    resolved_date = context.variable_manager.resolve_variables(date_text)
    if '-' in resolved_date and resolved_date.index('-') <= 2:
        d, m, y = resolved_date.split('-')
        formatted_date = f"{y}-{m}-{d}"
    else:
        formatted_date = resolved_date

    # 3. Interacción de "Fuerza Bruta" para disparar el motor de Angular
    element.focus()
    
    # Rellenamos el valor (esto equivale a seleccionar la fecha en el picker)
    element.fill(formatted_date)
    
    # 4. Disparar eventos manuales
    # 'input' es lo que dispara el cambio en el FormControl de Angular
    element.dispatch_event('input')
    element.dispatch_event('change')
    
    # 5. Simular la tecla Enter (como si el usuario cerrara el picker nativo)
    context.page.keyboard.press("Enter")
    
    # 6. Quitar el foco para marcar el campo como 'touched' (adiós al error rojo)
    element.blur()
    
    # Pequeña pausa para que Angular procese
    context.page.wait_for_timeout(100)    


@step('I open calendar and fill date field "{field_name}" with "{date_text}" with identifier "{identifier}"')
@step('abro el calendario y relleno el campo de fecha "{field_name}" con "{date_text}" con identificador "{identifier}"')
def step_open_calendar_and_fill_date(context, field_name, date_text, identifier):
    """Abre el calendario nativo del navegador y rellena el campo de fecha
    
    Este paso es útil cuando el campo de fecha tiene un calendario nativo del navegador
    que necesita ser abierto visualmente antes de rellenarlo.
    
    Proceso:
    1. Hace click en el campo para dar foco
    2. Presiona Alt+ArrowDown para abrir el calendario nativo
    3. Rellena el campo con la fecha
    4. Presiona Enter para confirmar
    5. Dispara eventos de Angular
    
    Nota: No puede hacer click en días específicos del calendario nativo porque
    están en el Shadow DOM del navegador, pero puede rellenar el valor directamente.
    """
    locator = context.element_locator.get_locator(identifier)
    resolved_date = context.variable_manager.resolve_variables(date_text)
    
    # Convertir formato DD-MM-YYYY a YYYY-MM-DD si es necesario
    if '-' in resolved_date and len(resolved_date) == 10:
        parts = resolved_date.split('-')
        if len(parts) == 3:
            # Detectar si es DD-MM-YYYY o YYYY-MM-DD
            if int(parts[0]) > 31:
                # Es YYYY-MM-DD, usar directamente
                formatted_date = resolved_date
            else:
                # Es DD-MM-YYYY, convertir a YYYY-MM-DD
                formatted_date = f"{parts[2]}-{parts[1]}-{parts[0]}"
        else:
            formatted_date = resolved_date
    else:
        formatted_date = resolved_date
    
    element = context.page.locator(locator)
    
    # 1. Hacer click para dar foco
    element.click()
    context.page.wait_for_timeout(200)
    
    # 2. Intentar abrir el calendario nativo con diferentes combinaciones de teclas
    # Diferentes navegadores usan diferentes atajos
    try:
        # Chromium/Chrome: Alt+ArrowDown
        context.page.keyboard.press("Alt+ArrowDown")
        context.page.wait_for_timeout(300)
    except:
        pass
    
    # 3. Rellenar el campo mientras el calendario está abierto
    # Esto funciona porque .fill() establece el valor directamente
    element.fill(formatted_date)
    context.page.wait_for_timeout(100)
    
    # 4. Presionar Enter para confirmar (cierra el calendario si está abierto)
    element.press("Enter")
    context.page.wait_for_timeout(100)
    
    # 5. Disparar eventos de Angular para que detecte el cambio
    element.dispatch_event('input')
    element.dispatch_event('change')
    element.dispatch_event('blur')
    
    # 6. Pequeña espera para que Angular procese
    context.page.wait_for_timeout(200)
    
    print(f"✓ Campo de fecha '{field_name}' rellenado con '{formatted_date}' (calendario abierto)")


@step('abro el calendario html desde el icono derecho con localizador "{identifier}"')
def open_html_calendar(context, identifier):
    locator = context.element_locator.get_locator(identifier)
    element = context.page.locator(locator)

    box = element.bounding_box()
    if box:
        # Hacemos clic a 15 píxeles del borde derecho
        context.page.mouse.click(box['x'] + box['width'] - 15, box['y'] + box['height'] / 2)
    context.page.wait_for_timeout(5000)   

@step('presiono desde el teclado "{key}"')
def press_key(context, key):
    # Mapeo de teclas especiales
    key_map = {
        'Enter': 'Enter',
        'Space': 'Space',
        'Escape': 'Escape',
        'ArrowUp': 'ArrowUp',
        'ArrowDown': 'ArrowDown',
        'ArrowLeft': 'ArrowLeft',
        'ArrowRight': 'ArrowRight',
        'PageUp': 'PageUp',
        'PageDown': 'PageDown',
        'Alt+Down': 'Alt+ArrowDown',
        'Alt+Up': 'Alt+ArrowUp',
    }     
