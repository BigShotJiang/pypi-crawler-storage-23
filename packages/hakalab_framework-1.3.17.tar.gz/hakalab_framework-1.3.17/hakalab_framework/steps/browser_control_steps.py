"""
Steps para control avanzado del navegador
Incluye cookies, localStorage, sessionStorage, cache y configuraciones
"""

from behave import step
import json
import time

@step('I set cookie "{name}" with value "{value}"')
@step('establezco la cookie "{name}" con valor "{value}"')
def step_set_cookie(context, name, value):
    """Establece una cookie específica"""
    resolved_value = context.variable_manager.resolve_variables(value)
    
    context.page.context.add_cookies([{
        'name': name,
        'value': resolved_value,
        'url': context.page.url
    }])
    
    print(f"✓ Cookie '{name}' establecida con valor '{resolved_value}'")

@step('I get cookie "{name}" and store in variable "{variable_name}"')
@step('obtengo la cookie "{name}" y la guardo en la variable "{variable_name}"')
def step_get_cookie(context, name, variable_name):
    """Obtiene el valor de una cookie y lo guarda en una variable"""
    cookies = context.page.context.cookies()
    
    cookie_value = None
    for cookie in cookies:
        if cookie['name'] == name:
            cookie_value = cookie['value']
            break
    
    if cookie_value:
        context.variable_manager.set_variable(variable_name, cookie_value)
        print(f"✓ Cookie '{name}' obtenida: '{cookie_value}'")
    else:
        print(f"⚠ Cookie '{name}' no encontrada")
        context.variable_manager.set_variable(variable_name, "")

@step('I delete cookie "{name}"')
@step('elimino la cookie "{name}"')
def step_delete_cookie(context, name):
    """Elimina una cookie específica"""
    context.page.evaluate(f"document.cookie = '{name}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;'")
    print(f"✓ Cookie '{name}' eliminada")

@step('I clear all cookies')
@step('limpio todas las cookies')
def step_clear_all_cookies(context):
    """Elimina todas las cookies"""
    context.page.context.clear_cookies()
    print("✓ Todas las cookies eliminadas")

@step('I set localStorage item "{key}" with value "{value}"')
@step('establezco el item de localStorage "{key}" con valor "{value}"')
def step_set_localstorage(context, key, value):
    """Establece un item en localStorage"""
    resolved_value = context.variable_manager.resolve_variables(value)
    
    context.page.evaluate(f"localStorage.setItem('{key}', '{resolved_value}')")
    print(f"✓ localStorage '{key}' establecido con valor '{resolved_value}'")

@step('I get localStorage item "{key}" and store in variable "{variable_name}"')
@step('obtengo el item de localStorage "{key}" y lo guardo en la variable "{variable_name}"')
def step_get_localstorage(context, key, variable_name):
    """Obtiene un item de localStorage y lo guarda en una variable"""
    value = context.page.evaluate(f"localStorage.getItem('{key}')")
    
    if value:
        context.variable_manager.set_variable(variable_name, value)
        print(f"✓ localStorage '{key}' obtenido: '{value}'")
    else:
        print(f"⚠ localStorage '{key}' no encontrado")
        context.variable_manager.set_variable(variable_name, "")

@step('I remove localStorage item "{key}"')
@step('elimino el item de localStorage "{key}"')
def step_remove_localstorage(context, key):
    """Elimina un item específico de localStorage"""
    context.page.evaluate(f"localStorage.removeItem('{key}')")
    print(f"✓ localStorage '{key}' eliminado")

@step('I clear localStorage')
@step('limpio el localStorage')
def step_clear_localstorage(context):
    """Limpia todo el localStorage"""
    context.page.evaluate("localStorage.clear()")
    print("✓ localStorage limpiado")

@step('I set sessionStorage item "{key}" with value "{value}"')
@step('establezco el item de sessionStorage "{key}" con valor "{value}"')
def step_set_sessionstorage(context, key, value):
    """Establece un item en sessionStorage"""
    resolved_value = context.variable_manager.resolve_variables(value)
    
    context.page.evaluate(f"sessionStorage.setItem('{key}', '{resolved_value}')")
    print(f"✓ sessionStorage '{key}' establecido con valor '{resolved_value}'")

@step('I get sessionStorage item "{key}" and store in variable "{variable_name}"')
@step('obtengo el item de sessionStorage "{key}" y lo guardo en la variable "{variable_name}"')
def step_get_sessionstorage(context, key, variable_name):
    """Obtiene un item de sessionStorage y lo guarda en una variable"""
    value = context.page.evaluate(f"sessionStorage.getItem('{key}')")
    
    if value:
        context.variable_manager.set_variable(variable_name, value)
        print(f"✓ sessionStorage '{key}' obtenido: '{value}'")
    else:
        print(f"⚠ sessionStorage '{key}' no encontrado")
        context.variable_manager.set_variable(variable_name, "")

@step('I clear sessionStorage')
@step('limpio el sessionStorage')
def step_clear_sessionstorage(context):
    """Limpia todo el sessionStorage"""
    context.page.evaluate("sessionStorage.clear()")
    print("✓ sessionStorage limpiado")

@step('I execute JavaScript "{script}" and store result in variable "{variable_name}"')
@step('ejecuto JavaScript "{script}" y guardo el resultado en la variable "{variable_name}"')
def step_execute_javascript(context, script, variable_name):
    """Ejecuta JavaScript personalizado y guarda el resultado"""
    resolved_script = context.variable_manager.resolve_variables(script)
    
    result = context.page.evaluate(resolved_script)
    
    # Convertir el resultado a string si es necesario
    if result is not None:
        result_str = json.dumps(result) if isinstance(result, (dict, list)) else str(result)
        context.variable_manager.set_variable(variable_name, result_str)
        print(f"✓ JavaScript ejecutado, resultado guardado en '{variable_name}': {result_str}")
    else:
        context.variable_manager.set_variable(variable_name, "")
        print(f"✓ JavaScript ejecutado, sin resultado")

@step('I execute the following JavaScript and store result in variable "{variable_name}"')
@step('ejecuto el siguiente JavaScript y guardo el resultado en la variable "{variable_name}"')
def step_execute_multiline_javascript(context, variable_name):
    """Ejecuta JavaScript multilínea y guarda el resultado
    
    Usa context.text para JavaScript de múltiples líneas.
    El código se envuelve automáticamente en una función si es necesario.
    
    Ejemplo:
        When ejecuto el siguiente JavaScript y guardo el resultado en la variable "formato_fecha"
          \"\"\"
          const input = document.getElementById('filtroFechaFin');
          return input.getAttribute('placeholder') || 'dd-mm-aaaa';
          \"\"\"
    """
    if not context.text:
        raise AssertionError("Se requiere un bloque de texto con el código JavaScript")
    
    resolved_script = context.variable_manager.resolve_variables(context.text.strip())
    
    # Si el script contiene 'return', envolverlo en una función
    if 'return' in resolved_script:
        resolved_script = f"(() => {{ {resolved_script} }})()"
    
    try:
        result = context.page.evaluate(resolved_script)
    except Exception as e:
        print(f"⚠️ Error ejecutando JavaScript: {e}")
        print(f"Script ejecutado: {resolved_script}")
        raise
    
    # Convertir el resultado a string si es necesario
    if result is not None:
        result_str = json.dumps(result) if isinstance(result, (dict, list)) else str(result)
        context.variable_manager.set_variable(variable_name, result_str)
        print(f"✓ JavaScript multilínea ejecutado, resultado guardado en '{variable_name}': {result_str}")
    else:
        context.variable_manager.set_variable(variable_name, "")
        print(f"✓ JavaScript multilínea ejecutado, sin resultado")

@step('I set browser viewport to "{width}x{height}"')
@step('establezco el viewport del navegador a "{width}x{height}"')
def step_set_viewport(context, width, height):
    """Establece el tamaño del viewport del navegador"""
    context.page.set_viewport_size({"width": int(width), "height": int(height)})
    print(f"✓ Viewport establecido a {width}x{height}")

@step('I enable JavaScript')
@step('habilito JavaScript')
def step_enable_javascript(context):
    """Habilita JavaScript en el navegador"""
    # Nota: En Playwright, JavaScript está habilitado por defecto
    # Este step es más informativo
    print("✓ JavaScript habilitado (por defecto en Playwright)")

@step('I disable JavaScript')
@step('deshabilito JavaScript')
def step_disable_javascript(context):
    """Deshabilita JavaScript en el navegador"""
    # Para deshabilitar JS necesitaríamos crear un nuevo contexto
    print("⚠ Para deshabilitar JavaScript se requiere reiniciar el contexto del navegador")

@step('I set user agent to "{user_agent}"')
@step('establezco el user agent a "{user_agent}"')
def step_set_user_agent(context, user_agent):
    """Establece el user agent del navegador"""
    resolved_user_agent = context.variable_manager.resolve_variables(user_agent)
    context.page.set_extra_http_headers({"User-Agent": resolved_user_agent})
    print(f"✓ User agent establecido: {resolved_user_agent}")

@step('I get current user agent and store in variable "{variable_name}"')
@step('obtengo el user agent actual y lo guardo en la variable "{variable_name}"')
def step_get_user_agent(context, variable_name):
    """Obtiene el user agent actual"""
    user_agent = context.page.evaluate("navigator.userAgent")
    context.variable_manager.set_variable(variable_name, user_agent)
    print(f"✓ User agent obtenido: {user_agent}")

@step('I simulate network condition "{condition}"')
@step('simulo la condición de red "{condition}"')
def step_simulate_network_condition(context, condition):
    """Simula diferentes condiciones de red"""
    conditions = {
        'slow_3g': {'download': 500 * 1024, 'upload': 500 * 1024, 'latency': 400},
        'fast_3g': {'download': 1.6 * 1024 * 1024, 'upload': 750 * 1024, 'latency': 150},
        'offline': {'download': 0, 'upload': 0, 'latency': 0}
    }
    
    if condition.lower() in conditions:
        # Nota: Playwright no tiene throttling de red directo como Selenium
        # Esto sería más una simulación conceptual
        print(f"✓ Condición de red '{condition}' simulada")
    else:
        print(f"⚠ Condición de red '{condition}' no reconocida")

@step('I clear browser cache')
@step('limpio la caché del navegador')
def step_clear_browser_cache(context):
    """Limpia la caché del navegador"""
    # En Playwright, esto requeriría reiniciar el contexto
    # Por ahora, limpiamos storage
    context.page.evaluate("""
        if ('caches' in window) {
            caches.keys().then(names => {
                names.forEach(name => {
                    caches.delete(name);
                });
            });
        }
    """)
    print("✓ Caché del navegador limpiada")

@step('I block resource type "{resource_type}"')
@step('bloqueo el tipo de recurso "{resource_type}"')
def step_block_resource_type(context, resource_type):
    """Bloquea un tipo específico de recurso"""
    def handle_route(route):
        if route.request.resource_type == resource_type:
            route.abort()
        else:
            route.continue_()
    
    context.page.route("**/*", handle_route)
    print(f"✓ Tipo de recurso '{resource_type}' bloqueado")

@step('I unblock all resources')
@step('desbloqueo todos los recursos')
def step_unblock_resources(context):
    """Desbloquea todos los recursos"""
    context.page.unroute("**/*")
    print("✓ Todos los recursos desbloqueados")


@step('desactivo el navegador para esta prueba')
@step('no necesito navegador para esta prueba')
@step('I disable browser for this test')
@step('I do not need browser for this test')
def step_disable_browser_for_test(context):
    """
    Desactiva el navegador para pruebas que no lo necesitan (API, validación semántica, etc.)
    Evita abrir el navegador y capturar screenshots innecesarios.
    
    Uso:
        Given desactivo el navegador para esta prueba
        Given no necesito navegador para esta prueba
    
    Casos de uso:
    - Pruebas de validación semántica/NLP
    - Pruebas de API REST
    - Pruebas de base de datos
    - Pruebas de procesamiento de archivos CSV
    - Cualquier prueba que no interactúe con UI
    """
    # Marcar que no se necesita navegador
    context.browser_disabled = True
    
    # Cerrar navegador si ya está abierto
    if hasattr(context, 'page') and context.page:
        try:
            context.page.close()
            context.page = None
        except Exception:
            pass
    
    if hasattr(context, 'browser') and context.browser:
        try:
            context.browser.close()
            context.browser = None
        except Exception:
            pass
    
    print("🚫 Navegador desactivado para esta prueba")


@step('reactivo el navegador')
@step('necesito el navegador ahora')
@step('I re-enable the browser')
@step('I need the browser now')
def step_enable_browser(context):
    """
    Reactiva el navegador después de haberlo desactivado.
    
    Uso:
        Given reactivo el navegador
        Given necesito el navegador ahora
    """
    # Desmarcar la flag
    context.browser_disabled = False
    
    # Reinicializar el navegador si es necesario
    if not hasattr(context, 'browser') or not context.browser:
        context.browser = context.framework_config.setup_playwright()
        context.page = context.framework_config.create_page()
    
    print("✅ Navegador reactivado")
