"""
Steps avanzados para validación de JSON en APIs REST
Incluye validación de esquemas, comparación con archivos, y validaciones profundas
"""

from behave import step
import json
import os
from jsonschema import validate, ValidationError, Draft7Validator
from deepdiff import DeepDiff
import re

@step('I verify API response JSON matches schema file "{schema_file}"')
@step('verifico que el JSON de respuesta API coincide con el esquema del archivo "{schema_file}"')
def step_verify_json_schema_file(context, schema_file):
    """Verifica que la respuesta JSON coincide con un esquema JSON Schema (Draft 7)
    
    Ejemplo:
        Then verifico que el JSON de respuesta API coincide con el esquema del archivo "schemas/user_schema.json"
    """
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    resolved_file = context.variable_manager.resolve_variables(schema_file)
    
    try:
        # Cargar esquema
        with open(resolved_file, 'r', encoding='utf-8') as file:
            schema = json.load(file)
        
        # Obtener respuesta JSON
        response_json = context.last_api_response.json()
        
        # Validar usando jsonschema
        validate(instance=response_json, schema=schema)
        
        print(f"✓ Respuesta JSON válida según esquema '{resolved_file}'")
        
    except ValidationError as e:
        print(f"✗ Respuesta JSON no válida según esquema:")
        print(f"  Error: {e.message}")
        print(f"  Path: {' -> '.join(str(p) for p in e.path)}")
        raise AssertionError(f"Respuesta JSON no válida: {e.message}")
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")
    except FileNotFoundError:
        raise AssertionError(f"Archivo de esquema no encontrado: {resolved_file}")
    except Exception as e:
        print(f"✗ Error validando esquema: {e}")
        raise

@step('I verify API response JSON exactly matches file "{expected_file}"')
@step('verifico que el JSON de respuesta API coincide exactamente con el archivo "{expected_file}"')
def step_verify_json_exact_match(context, expected_file):
    """Verifica que la respuesta JSON es exactamente igual al contenido de un archivo
    
    Ejemplo:
        Then verifico que el JSON de respuesta API coincide exactamente con el archivo "expected/user_response.json"
    """
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    resolved_file = context.variable_manager.resolve_variables(expected_file)
    
    try:
        # Cargar archivo esperado
        with open(resolved_file, 'r', encoding='utf-8') as file:
            expected_json = json.load(file)
        
        # Obtener respuesta JSON
        actual_json = context.last_api_response.json()
        
        # Comparar
        if actual_json == expected_json:
            print(f"✓ Respuesta JSON coincide exactamente con '{resolved_file}'")
        else:
            # Mostrar diferencias
            diff = DeepDiff(expected_json, actual_json, ignore_order=False)
            print(f"✗ Respuesta JSON no coincide con '{resolved_file}'")
            print(f"  Diferencias: {diff}")
            raise AssertionError(f"Respuesta JSON no coincide exactamente")
            
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")
    except FileNotFoundError:
        raise AssertionError(f"Archivo esperado no encontrado: {resolved_file}")
    except Exception as e:
        print(f"✗ Error comparando JSON: {e}")
        raise

@step('I verify API response JSON matches file "{expected_file}" ignoring order')
@step('verifico que el JSON de respuesta API coincide con el archivo "{expected_file}" ignorando orden')
def step_verify_json_match_ignore_order(context, expected_file):
    """Verifica que la respuesta JSON coincide con un archivo ignorando el orden de arrays
    
    Ejemplo:
        Then verifico que el JSON de respuesta API coincide con el archivo "expected/users.json" ignorando orden
    """
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    resolved_file = context.variable_manager.resolve_variables(expected_file)
    
    try:
        # Cargar archivo esperado
        with open(resolved_file, 'r', encoding='utf-8') as file:
            expected_json = json.load(file)
        
        # Obtener respuesta JSON
        actual_json = context.last_api_response.json()
        
        # Comparar ignorando orden
        diff = DeepDiff(expected_json, actual_json, ignore_order=True)
        
        if not diff:
            print(f"✓ Respuesta JSON coincide con '{resolved_file}' (orden ignorado)")
        else:
            print(f"✗ Respuesta JSON no coincide con '{resolved_file}'")
            print(f"  Diferencias: {diff}")
            raise AssertionError(f"Respuesta JSON no coincide")
            
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")
    except FileNotFoundError:
        raise AssertionError(f"Archivo esperado no encontrado: {resolved_file}")
    except Exception as e:
        print(f"✗ Error comparando JSON: {e}")
        raise

@step('I verify API response JSON matches file "{expected_file}" ignoring fields "{ignored_fields}"')
@step('verifico que el JSON de respuesta API coincide con el archivo "{expected_file}" ignorando campos "{ignored_fields}"')
def step_verify_json_match_ignore_fields(context, expected_file, ignored_fields):
    """Verifica que la respuesta JSON coincide con un archivo ignorando campos específicos
    
    Ejemplo:
        Then verifico que el JSON de respuesta API coincide con el archivo "expected/user.json" ignorando campos "id,created_at,updated_at"
    """
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    resolved_file = context.variable_manager.resolve_variables(expected_file)
    fields_to_ignore = [f.strip() for f in ignored_fields.split(',')]
    
    try:
        # Cargar archivo esperado
        with open(resolved_file, 'r', encoding='utf-8') as file:
            expected_json = json.load(file)
        
        # Obtener respuesta JSON
        actual_json = context.last_api_response.json()
        
        # Comparar ignorando campos específicos
        diff = DeepDiff(expected_json, actual_json, ignore_order=True, exclude_paths=fields_to_ignore)
        
        if not diff:
            print(f"✓ Respuesta JSON coincide con '{resolved_file}' (ignorando: {', '.join(fields_to_ignore)})")
        else:
            print(f"✗ Respuesta JSON no coincide con '{resolved_file}'")
            print(f"  Diferencias: {diff}")
            raise AssertionError(f"Respuesta JSON no coincide")
            
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")
    except FileNotFoundError:
        raise AssertionError(f"Archivo esperado no encontrado: {resolved_file}")
    except Exception as e:
        print(f"✗ Error comparando JSON: {e}")
        raise

@step('I verify API response JSON has field "{field_path}" with type "{expected_type}"')
@step('verifico que el JSON de respuesta API tiene el campo "{field_path}" con tipo "{expected_type}"')
def step_verify_json_field_type(context, field_path, expected_type):
    """Verifica que un campo JSON tiene un tipo específico
    
    Tipos soportados: string, number, integer, boolean, array, object, null
    
    Ejemplo:
        Then verifico que el JSON de respuesta API tiene el campo "user.age" con tipo "integer"
    """
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    try:
        response_json = context.last_api_response.json()
        
        # Navegar por la ruta
        keys = field_path.split('.')
        current_value = response_json
        
        for key in keys:
            if isinstance(current_value, dict) and key in current_value:
                current_value = current_value[key]
            elif isinstance(current_value, list):
                try:
                    index = int(key)
                    current_value = current_value[index]
                except (ValueError, IndexError):
                    raise KeyError(f"Índice '{key}' no válido")
            else:
                raise KeyError(f"Clave '{key}' no encontrada")
        
        # Verificar tipo
        type_mapping = {
            'string': str,
            'number': (int, float),
            'integer': int,
            'boolean': bool,
            'array': list,
            'object': dict,
            'null': type(None)
        }
        
        expected_python_type = type_mapping.get(expected_type.lower())
        if not expected_python_type:
            raise ValueError(f"Tipo no soportado: {expected_type}")
        
        if isinstance(current_value, expected_python_type):
            print(f"✓ Campo '{field_path}' tiene tipo '{expected_type}'")
        else:
            actual_type = type(current_value).__name__
            print(f"✗ Campo '{field_path}' tiene tipo '{actual_type}', esperado '{expected_type}'")
            raise AssertionError(f"Tipo incorrecto para campo '{field_path}'")
            
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")
    except KeyError as e:
        raise AssertionError(f"Campo no encontrado: {e}")
    except Exception as e:
        print(f"✗ Error verificando tipo: {e}")
        raise

@step('I verify API response JSON field "{field_path}" matches regex "{pattern}"')
@step('verifico que el campo "{field_path}" del JSON de respuesta API coincide con el patrón "{pattern}"')
def step_verify_json_field_regex(context, field_path, pattern):
    """Verifica que un campo JSON coincide con una expresión regular
    
    Ejemplo:
        Then verifico que el campo "email" del JSON de respuesta API coincide con el patrón "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"
    """
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    try:
        response_json = context.last_api_response.json()
        
        # Navegar por la ruta
        keys = field_path.split('.')
        current_value = response_json
        
        for key in keys:
            if isinstance(current_value, dict) and key in current_value:
                current_value = current_value[key]
            else:
                raise KeyError(f"Clave '{key}' no encontrada")
        
        # Verificar patrón
        if re.match(pattern, str(current_value)):
            print(f"✓ Campo '{field_path}' coincide con patrón '{pattern}'")
        else:
            print(f"✗ Campo '{field_path}' = '{current_value}' no coincide con patrón '{pattern}'")
            raise AssertionError(f"Campo '{field_path}' no coincide con patrón")
            
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")
    except KeyError as e:
        raise AssertionError(f"Campo no encontrado: {e}")
    except Exception as e:
        print(f"✗ Error verificando patrón: {e}")
        raise

@step('I verify API response JSON field "{field_path}" is in range {min_value} to {max_value}')
@step('verifico que el campo "{field_path}" del JSON de respuesta API está en el rango {min_value} a {max_value}')
def step_verify_json_field_range(context, field_path, min_value, max_value):
    """Verifica que un campo numérico está dentro de un rango
    
    Ejemplo:
        Then verifico que el campo "age" del JSON de respuesta API está en el rango 18 a 65
    """
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    try:
        response_json = context.last_api_response.json()
        
        # Navegar por la ruta
        keys = field_path.split('.')
        current_value = response_json
        
        for key in keys:
            if isinstance(current_value, dict) and key in current_value:
                current_value = current_value[key]
            else:
                raise KeyError(f"Clave '{key}' no encontrada")
        
        # Verificar rango
        min_val = float(min_value)
        max_val = float(max_value)
        actual_val = float(current_value)
        
        if min_val <= actual_val <= max_val:
            print(f"✓ Campo '{field_path}' = {actual_val} está en rango [{min_val}, {max_val}]")
        else:
            print(f"✗ Campo '{field_path}' = {actual_val} fuera de rango [{min_val}, {max_val}]")
            raise AssertionError(f"Campo '{field_path}' fuera de rango")
            
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")
    except KeyError as e:
        raise AssertionError(f"Campo no encontrado: {e}")
    except ValueError:
        raise AssertionError(f"Campo '{field_path}' no es numérico")
    except Exception as e:
        print(f"✗ Error verificando rango: {e}")
        raise

@step('I verify API response JSON array "{array_path}" contains item with "{field}" equals "{value}"')
@step('verifico que el array "{array_path}" del JSON de respuesta API contiene un elemento con "{field}" igual a "{value}"')
def step_verify_json_array_contains_item(context, array_path, field, value):
    """Verifica que un array JSON contiene un elemento con un campo específico
    
    Ejemplo:
        Then verifico que el array "users" del JSON de respuesta API contiene un elemento con "name" igual a "Juan"
    """
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    resolved_value = context.variable_manager.resolve_variables(value)
    
    try:
        response_json = context.last_api_response.json()
        
        # Navegar por la ruta del array
        keys = array_path.split('.')
        current_value = response_json
        
        for key in keys:
            if isinstance(current_value, dict) and key in current_value:
                current_value = current_value[key]
            else:
                raise KeyError(f"Clave '{key}' no encontrada")
        
        # Verificar que es un array
        if not isinstance(current_value, list):
            raise AssertionError(f"'{array_path}' no es un array")
        
        # Buscar elemento
        found = False
        for item in current_value:
            if isinstance(item, dict) and field in item:
                if str(item[field]) == str(resolved_value):
                    found = True
                    break
        
        if found:
            print(f"✓ Array '{array_path}' contiene elemento con '{field}' = '{resolved_value}'")
        else:
            print(f"✗ Array '{array_path}' no contiene elemento con '{field}' = '{resolved_value}'")
            raise AssertionError(f"Elemento no encontrado en array")
            
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")
    except KeyError as e:
        raise AssertionError(f"Campo no encontrado: {e}")
    except Exception as e:
        print(f"✗ Error verificando array: {e}")
        raise

@step('I verify API response JSON array "{array_path}" all items have field "{field}"')
@step('verifico que todos los elementos del array "{array_path}" del JSON de respuesta API tienen el campo "{field}"')
def step_verify_json_array_all_have_field(context, array_path, field):
    """Verifica que todos los elementos de un array tienen un campo específico
    
    Ejemplo:
        Then verifico que todos los elementos del array "users" del JSON de respuesta API tienen el campo "id"
    """
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    try:
        response_json = context.last_api_response.json()
        
        # Navegar por la ruta del array
        keys = array_path.split('.')
        current_value = response_json
        
        for key in keys:
            if isinstance(current_value, dict) and key in current_value:
                current_value = current_value[key]
            else:
                raise KeyError(f"Clave '{key}' no encontrada")
        
        # Verificar que es un array
        if not isinstance(current_value, list):
            raise AssertionError(f"'{array_path}' no es un array")
        
        # Verificar todos los elementos
        missing_field_indices = []
        for i, item in enumerate(current_value):
            if not isinstance(item, dict) or field not in item:
                missing_field_indices.append(i)
        
        if not missing_field_indices:
            print(f"✓ Todos los elementos del array '{array_path}' tienen el campo '{field}'")
        else:
            print(f"✗ Elementos sin campo '{field}': {missing_field_indices}")
            raise AssertionError(f"Algunos elementos no tienen el campo '{field}'")
            
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")
    except KeyError as e:
        raise AssertionError(f"Campo no encontrado: {e}")
    except Exception as e:
        print(f"✗ Error verificando array: {e}")
        raise

@step('I verify API response JSON has no null values')
@step('verifico que el JSON de respuesta API no tiene valores nulos')
def step_verify_json_no_nulls(context):
    """Verifica que la respuesta JSON no contiene valores null
    
    Ejemplo:
        Then verifico que el JSON de respuesta API no tiene valores nulos
    """
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible para verificar")
    
    try:
        response_json = context.last_api_response.json()
        
        # Buscar valores null recursivamente
        null_paths = []
        
        def find_nulls(obj, path=""):
            if isinstance(obj, dict):
                for key, value in obj.items():
                    new_path = f"{path}.{key}" if path else key
                    if value is None:
                        null_paths.append(new_path)
                    else:
                        find_nulls(value, new_path)
            elif isinstance(obj, list):
                for i, item in enumerate(obj):
                    new_path = f"{path}[{i}]"
                    if item is None:
                        null_paths.append(new_path)
                    else:
                        find_nulls(item, new_path)
        
        find_nulls(response_json)
        
        if not null_paths:
            print(f"✓ JSON no contiene valores nulos")
        else:
            print(f"✗ JSON contiene valores nulos en: {', '.join(null_paths)}")
            raise AssertionError(f"JSON contiene valores nulos")
            
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")
    except Exception as e:
        print(f"✗ Error verificando nulls: {e}")
        raise

@step('I save API response JSON to file "{file_path}"')
@step('guardo el JSON de respuesta API en el archivo "{file_path}"')
def step_save_json_to_file(context, file_path):
    """Guarda la respuesta JSON en un archivo
    
    Ejemplo:
        Then guardo el JSON de respuesta API en el archivo "responses/user_response.json"
    """
    if not hasattr(context, 'last_api_response'):
        raise AssertionError("No hay respuesta API disponible")
    
    resolved_path = context.variable_manager.resolve_variables(file_path)
    
    try:
        response_json = context.last_api_response.json()
        
        # Crear directorio si no existe
        os.makedirs(os.path.dirname(resolved_path), exist_ok=True)
        
        # Guardar JSON
        with open(resolved_path, 'w', encoding='utf-8') as file:
            json.dump(response_json, file, indent=2, ensure_ascii=False)
        
        print(f"✓ JSON guardado en '{resolved_path}'")
        
    except json.JSONDecodeError:
        raise AssertionError("La respuesta API no es JSON válido")
    except Exception as e:
        print(f"✗ Error guardando JSON: {e}")
        raise

@step('I load JSON from file "{file_path}" and send POST to "{url}" storing response in variable "{variable_name}"')
@step('cargo JSON del archivo "{file_path}" y envío POST a "{url}" guardando respuesta en variable "{variable_name}"')
def step_load_json_and_post(context, file_path, url, variable_name):
    """Carga JSON desde un archivo y envía POST
    
    Ejemplo:
        When cargo JSON del archivo "payloads/create_user.json" y envío POST a "/api/users" guardando respuesta en variable "response"
    """
    resolved_path = context.variable_manager.resolve_variables(file_path)
    resolved_url = context.variable_manager.resolve_variables(url)
    
    try:
        # Cargar JSON
        with open(resolved_path, 'r', encoding='utf-8') as file:
            json_data = json.load(file)
        
        # Enviar POST
        import requests
        headers = {'Content-Type': 'application/json'}
        response = requests.post(resolved_url, json=json_data, headers=headers)
        
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': response.text,
            'json': response.json() if response.headers.get('content-type', '').startswith('application/json') else None
        }
        
        context.variable_manager.set_variable(variable_name, json.dumps(response_data))
        context.last_api_response = response
        
        print(f"✓ POST enviado con JSON desde '{resolved_path}'")
        print(f"  Status: {response.status_code}")
        
    except FileNotFoundError:
        raise AssertionError(f"Archivo no encontrado: {resolved_path}")
    except json.JSONDecodeError:
        raise AssertionError(f"Archivo no contiene JSON válido: {resolved_path}")
    except Exception as e:
        print(f"✗ Error: {e}")
        raise
