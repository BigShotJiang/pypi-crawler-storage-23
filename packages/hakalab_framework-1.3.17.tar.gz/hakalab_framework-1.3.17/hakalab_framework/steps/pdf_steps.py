#!/usr/bin/env python3
"""
Steps para validación de contenido de archivos PDF
"""
from behave import step
from pathlib import Path
import os

try:
    from pypdf import PdfReader
except ImportError:
    PdfReader = None


def _get_pdf_reader(file_path):
    """Obtiene un lector de PDF"""
    if PdfReader is None:
        raise ImportError("pypdf no está instalado. Ejecuta: pip install pypdf")
    
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Archivo PDF no encontrado: {file_path}")
    
    try:
        return PdfReader(file_path)
    except Exception as e:
        raise ValueError(f"Error al leer PDF: {e}")


@step('verifico que el archivo PDF "{filename}" contiene el texto "{text}"')
def step_verify_pdf_contains_text(context, filename, text):
    """Verifica que un PDF contiene un texto específico
    
    Busca el texto en todas las páginas del PDF.
    
    Ejemplos:
    - verifico que el archivo PDF "documento.pdf" contiene el texto "Aprobado"
    - verifico que el archivo PDF "reporte.pdf" contiene el texto "Total: $1000"
    """
    resolved_filename = context.variable_manager.resolve_variables(filename)
    resolved_text = context.variable_manager.resolve_variables(text)
    
    reader = _get_pdf_reader(resolved_filename)
    
    # Buscar texto en todas las páginas
    found = False
    for page_num, page in enumerate(reader.pages, 1):
        page_text = page.extract_text()
        if resolved_text in page_text:
            found = True
            print(f"✓ Texto '{resolved_text}' encontrado en página {page_num}")
            break
    
    assert found, f"Texto '{resolved_text}' no encontrado en el PDF"


@step('verifico que el PDF "{filename}" de la carpeta "{directory}" contiene el texto "{text}"')
def step_verify_pdf_from_directory_contains_text(context, filename, directory, text):
    """Verifica que un PDF en una carpeta específica contiene un texto
    
    Permite especificar la carpeta donde se encuentra el PDF.
    
    Ejemplos:
    - verifico que el PDF "SOLICITUDPERM_USUARIO_43.pdf" de la carpeta "downloads" contiene el texto "COMPROBANTE"
    - verifico que el PDF "reporte.pdf" de la carpeta "reports" contiene el texto "Total"
    """
    from pathlib import Path
    
    resolved_directory = context.variable_manager.resolve_variables(directory)
    resolved_filename = context.variable_manager.resolve_variables(filename)
    resolved_text = context.variable_manager.resolve_variables(text)
    
    # Construir ruta completa
    file_path = Path(resolved_directory) / resolved_filename
    
    reader = _get_pdf_reader(str(file_path))
    
    # Buscar texto en todas las páginas
    found = False
    for page_num, page in enumerate(reader.pages, 1):
        page_text = page.extract_text()
        if resolved_text in page_text:
            found = True
            print(f"✓ Texto '{resolved_text}' encontrado en página {page_num}")
            break
    
    assert found, f"Texto '{resolved_text}' no encontrado en el PDF"


@step('I verify PDF file "{filename}" does not contain text "{text}"')
@step('verifico que el archivo PDF "{filename}" no contiene el texto "{text}"')
def step_verify_pdf_not_contains_text(context, filename, text):
    """Verifica que un PDF NO contiene un texto específico
    
    Busca el texto en todas las páginas del PDF.
    
    Ejemplos:
    - verifico que el archivo PDF "documento.pdf" no contiene el texto "Rechazado"
    - verifico que el archivo PDF "reporte.pdf" no contiene el texto "Error"
    """
    resolved_filename = context.variable_manager.resolve_variables(filename)
    resolved_text = context.variable_manager.resolve_variables(text)
    
    reader = _get_pdf_reader(resolved_filename)
    
    # Buscar texto en todas las páginas
    for page_num, page in enumerate(reader.pages, 1):
        page_text = page.extract_text()
        if resolved_text in page_text:
            raise AssertionError(f"Texto '{resolved_text}' encontrado en página {page_num} (no debería estar)")
    
    print(f"✓ Texto '{resolved_text}' no encontrado en el PDF")


@step('I verify PDF file "{filename}" has "{expected_pages}" pages')
@step('verifico que el archivo PDF "{filename}" tiene "{expected_pages}" páginas')
def step_verify_pdf_page_count(context, filename, expected_pages):
    """Verifica que un PDF tiene un número específico de páginas
    
    Ejemplos:
    - verifico que el archivo PDF "documento.pdf" tiene "5" páginas
    - verifico que el archivo PDF "reporte.pdf" tiene "1" páginas
    """
    resolved_filename = context.variable_manager.resolve_variables(filename)
    expected_count = int(expected_pages)
    
    reader = _get_pdf_reader(resolved_filename)
    actual_count = len(reader.pages)
    
    assert actual_count == expected_count, f"PDF tiene {actual_count} páginas, esperado {expected_count}"
    print(f"✓ PDF tiene {actual_count} páginas")


@step('I verify PDF file "{filename}" page "{page_number}" contains text "{text}"')
@step('verifico que la página "{page_number}" del PDF "{filename}" contiene el texto "{text}"')
def step_verify_pdf_page_contains_text(context, filename, page_number, text):
    """Verifica que una página específica del PDF contiene un texto
    
    Ejemplos:
    - verifico que la página "1" del PDF "documento.pdf" contiene el texto "Título"
    - verifico que la página "3" del PDF "reporte.pdf" contiene el texto "Conclusión"
    """
    resolved_filename = context.variable_manager.resolve_variables(filename)
    resolved_text = context.variable_manager.resolve_variables(text)
    page_index = int(page_number) - 1  # Convertir a índice 0-based
    
    reader = _get_pdf_reader(resolved_filename)
    
    if page_index >= len(reader.pages):
        raise AssertionError(f"Página {page_number} no existe. PDF tiene {len(reader.pages)} páginas")
    
    page = reader.pages[page_index]
    page_text = page.extract_text()
    
    assert resolved_text in page_text, f"Texto '{resolved_text}' no encontrado en página {page_number}"
    print(f"✓ Texto '{resolved_text}' encontrado en página {page_number}")


@step('extraigo el texto del PDF "{filename}" y lo guardo en la variable "{variable_name}"')
def step_extract_pdf_text(context, filename, variable_name):
    """Extrae todo el texto de un PDF y lo guarda en una variable
    
    Ejemplos:
    - extraigo el texto del PDF "documento.pdf" y lo guardo en la variable "pdf_content"
    - extraigo el texto del PDF "reporte.pdf" y lo guardo en la variable "report_text"
    """
    resolved_filename = context.variable_manager.resolve_variables(filename)
    
    reader = _get_pdf_reader(resolved_filename)
    
    # Extraer texto de todas las páginas
    full_text = ""
    for page in reader.pages:
        full_text += page.extract_text() + "\n"
    
    # Guardar en variable
    context.variable_manager.set_variable(variable_name, full_text.strip())
    print(f"✓ Texto extraído del PDF y guardado en variable '{variable_name}'")


@step('extraigo el texto de la página "{page_number}" del PDF "{filename}" y lo guardo en la variable "{variable_name}"')
def step_extract_pdf_page_text(context, filename, page_number, variable_name):
    """Extrae el texto de una página específica del PDF y lo guarda en una variable
    
    Ejemplos:
    - extraigo el texto de la página "1" del PDF "documento.pdf" y lo guardo en la variable "first_page"
    - extraigo el texto de la página "3" del PDF "reporte.pdf" y lo guardo en la variable "conclusion"
    """
    resolved_filename = context.variable_manager.resolve_variables(filename)
    page_index = int(page_number) - 1  # Convertir a índice 0-based
    
    reader = _get_pdf_reader(resolved_filename)
    
    if page_index >= len(reader.pages):
        raise AssertionError(f"Página {page_number} no existe. PDF tiene {len(reader.pages)} páginas")
    
    page = reader.pages[page_index]
    page_text = page.extract_text()
    
    # Guardar en variable
    context.variable_manager.set_variable(variable_name, page_text.strip())
    print(f"✓ Texto de página {page_number} extraído y guardado en variable '{variable_name}'")


@step('verifico que el archivo PDF "{filename}" está encriptado')
def step_verify_pdf_encrypted(context, filename):
    """Verifica que un PDF está encriptado
    
    Ejemplos:
    - verifico que el archivo PDF "documento_seguro.pdf" está encriptado
    """
    resolved_filename = context.variable_manager.resolve_variables(filename)
    
    reader = _get_pdf_reader(resolved_filename)
    
    assert reader.is_encrypted, f"PDF no está encriptado"
    print(f"✓ PDF está encriptado")


@step('verifico que el archivo PDF "{filename}" no está encriptado')
def step_verify_pdf_not_encrypted(context, filename):
    """Verifica que un PDF NO está encriptado
    
    Ejemplos:
    - verifico que el archivo PDF "documento.pdf" no está encriptado
    """
    resolved_filename = context.variable_manager.resolve_variables(filename)
    
    reader = _get_pdf_reader(resolved_filename)
    
    assert not reader.is_encrypted, f"PDF está encriptado"
    print(f"✓ PDF no está encriptado")


@step('verifico que el PDF "{filename}" tiene metadato "{key}" con valor "{value}"')
def step_verify_pdf_metadata(context, filename, key, value):
    """Verifica que un PDF contiene metadatos específicos
    
    Ejemplos:
    - verifico que el PDF "documento.pdf" tiene metadato "Author" con valor "Juan"
    - verifico que el PDF "reporte.pdf" tiene metadato "Title" con valor "Reporte Mensual"
    """
    resolved_filename = context.variable_manager.resolve_variables(filename)
    resolved_key = context.variable_manager.resolve_variables(key)
    resolved_value = context.variable_manager.resolve_variables(value)
    
    reader = _get_pdf_reader(resolved_filename)
    
    metadata = reader.metadata
    if metadata is None:
        raise AssertionError(f"PDF no tiene metadatos")
    
    # Buscar la clave (puede estar con / al inicio)
    key_with_slash = f"/{resolved_key}"
    
    if key_with_slash in metadata:
        actual_value = str(metadata[key_with_slash])
    elif resolved_key in metadata:
        actual_value = str(metadata[resolved_key])
    else:
        raise AssertionError(f"Metadato '{resolved_key}' no encontrado en PDF")
    
    assert resolved_value in actual_value, f"Metadato '{resolved_key}' tiene valor '{actual_value}', esperado '{resolved_value}'"
    print(f"✓ Metadato '{resolved_key}' contiene '{resolved_value}'")


@step('verifico que el PDF "{filename}" contiene texto que coincide con el patrón "{pattern}"')
def step_verify_pdf_text_pattern(context, filename, pattern):
    """Verifica que un PDF contiene texto que coincide con un patrón regex
    
    Ejemplos:
    - verifico que el PDF "documento.pdf" contiene texto que coincide con el patrón "Total: \\$[0-9]+"
    - verifico que el PDF "reporte.pdf" contiene texto que coincide con el patrón "[0-9]{4}-[0-9]{2}-[0-9]{2}"
    """
    import re
    
    resolved_filename = context.variable_manager.resolve_variables(filename)
    resolved_pattern = context.variable_manager.resolve_variables(pattern)
    
    reader = _get_pdf_reader(resolved_filename)
    
    # Buscar patrón en todas las páginas
    found = False
    for page_num, page in enumerate(reader.pages, 1):
        page_text = page.extract_text()
        if re.search(resolved_pattern, page_text):
            found = True
            print(f"✓ Patrón '{resolved_pattern}' encontrado en página {page_num}")
            break
    
    assert found, f"Patrón '{resolved_pattern}' no encontrado en el PDF"
