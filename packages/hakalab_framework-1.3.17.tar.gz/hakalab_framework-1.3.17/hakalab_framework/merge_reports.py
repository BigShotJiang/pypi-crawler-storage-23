#!/usr/bin/env python3
"""
Script para fusionar reportes Cucumber JSON de múltiples jobs en un único reporte HTML
Uso: python -m hakalab_framework.merge_reports --artifacts-dir ./artifacts --output report.html
"""

import argparse
import sys
from pathlib import Path
from .core.cucumber_report_merger import CucumberReportMerger


def main():
    parser = argparse.ArgumentParser(
        description='Fusiona reportes Cucumber JSON de múltiples jobs en un único reporte HTML'
    )
    
    parser.add_argument(
        '--artifacts-dir',
        '-a',
        default='artifacts',
        help='Directorio con los artefactos descargados (default: artifacts)'
    )
    
    parser.add_argument(
        '--output-dir',
        '-o',
        default='consolidated-reports',
        help='Directorio de salida (default: consolidated-reports)'
    )
    
    parser.add_argument(
        '--output-file',
        '-f',
        default='report.html',
        help='Nombre del archivo de salida (default: report.html)'
    )
    
    args = parser.parse_args()
    
    # Validar que el directorio de artefactos existe
    artifacts_path = Path(args.artifacts_dir)
    if not artifacts_path.exists():
        print(f"Error: Directorio de artefactos no encontrado: {args.artifacts_dir}")
        return 1
    
    print(f"Directorio de artefactos: {artifacts_path.absolute()}")
    print(f"Directorio de salida: {args.output_dir}")
    
    try:
        # Crear merger y generar reporte
        merger = CucumberReportMerger(output_dir=args.output_dir)
        report_path = merger.merge_and_generate(
            artifacts_dir=args.artifacts_dir,
            output_file=args.output_file
        )
        
        print(f"\nReporte unificado generado exitosamente")
        print(f"Ubicacion: {report_path}")
        
        return 0
        
    except Exception as e:
        print(f"Error durante la fusion de reportes: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == '__main__':
    sys.exit(main())
