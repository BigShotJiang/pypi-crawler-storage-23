"""
Punto de entrada para ejecutar hakalab_framework como módulo.

Uso:
    python -m hakalab_framework.generate_unified_report [opciones]
"""

import sys

if __name__ == "__main__":
    # Por ahora solo soportamos generate_unified_report
    # En el futuro se pueden agregar más comandos
    from .generate_unified_report import main
    sys.exit(main())
