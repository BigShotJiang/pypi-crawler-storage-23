#!/usr/bin/env python
"""
CLI para generar reportes unificados desde múltiples JSONs de ejecuciones paralelas.

Uso:
    python -m hakalab_framework.cli_unified_report --json-dir ./html-reports --output-dir ./reports
"""

import argparse
import sys
from pathlib import Path
from .core.unified_report_generator import UnifiedReportGenerator


def main():
    parser = argparse.ArgumentParser(
        description="Genera un reporte HTML unificado desde múltiples JSONs de pruebas"
    )
    
    parser.add_argument(
        "--json-dir",
        type=str,
        default="html-reports",
        help="Directorio con los archivos JSON de reportes (default: html-reports)",
    )
    
    parser.add_argument(
        "--output-dir",
        type=str,
        default="html-reports",
        help="Directorio de salida para el reporte HTML (default: html-reports)",
    )
    
    parser.add_argument(
        "--output-file",
        type=str,
        default="unified_report.html",
        help="Nombre del archivo de salida (default: unified_report.html)",
    )
    
    parser.add_argument(
        "--title",
        type=str,
        default="Reporte Unificado de Pruebas",
        help="Título del reporte (default: Reporte Unificado de Pruebas)",
    )
    
    args = parser.parse_args()
    
    try:
        print(f"📊 Generando reporte unificado...")
        print(f"   Directorio de entrada: {args.json_dir}")
        print(f"   Directorio de salida: {args.output_dir}")
        
        generator = UnifiedReportGenerator(output_dir=args.output_dir)
        generator.load_json_reports(args.json_dir)
        
        print(f"   ✓ Se cargaron {len(generator.reports_data)} reportes")
        
        output_file = generator.save_report(filename=args.output_file)
        
        print(f"   ✓ Reporte generado: {output_file}")
        print(f"\n✅ Reporte unificado creado exitosamente")
        
        return 0
        
    except FileNotFoundError as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"❌ Error inesperado: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
