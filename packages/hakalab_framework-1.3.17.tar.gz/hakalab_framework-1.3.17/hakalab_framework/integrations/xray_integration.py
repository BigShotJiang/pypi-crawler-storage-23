"""
Integración con Xray (by Blend) para el Hakalab Framework - Versión Simplificada
"""
import os
import json
import requests
import time
from typing import Optional, Dict, Any, List
from datetime import datetime, timedelta
from .jira_integration import JiraIntegration


class XrayIntegration:
    """Clase para manejar la integración con Xray usando método directo"""
    
    def __init__(self, jira_integration: JiraIntegration):
        """Inicializar la integración con Xray"""
        self.jira = jira_integration
        self.xray_enabled = os.getenv('XRAY_ENABLED', 'false').lower() == 'true'
        self.xray_test_plan = os.getenv('XRAY_TEST_PLAN')
        
        # Configuración para API directa de Xray Cloud
        self.xray_authorization_token = os.getenv('XRAY_AUTHORIZATION_TOKEN')
        self.xray_base_url = os.getenv('XRAY_BASE_URL', 'https://xray.cloud.getxray.app')
        
        # Mapeo de estados de Behave a Xray
        self.status_mapping = {
            'passed': 'passed',
            'failed': 'failed', 
            'skipped': 'skipped',
            'undefined': 'skipped',
            'pending': 'skipped',
            'untested': 'skipped'
        }
        
        self.is_configured = self._validate_configuration()
    
    def _validate_configuration(self) -> bool:
        """Validar que Xray esté configurado correctamente"""
        if not self.xray_enabled:
            print("ℹ️ Xray deshabilitado")
            return False
        
        if not self.jira.is_configured:
            print("❌ Xray requiere Jira configurado")
            return False
        
        # Verificar si tenemos token de autorización
        if self.xray_authorization_token:
            print("✅ Xray configurado correctamente (autenticación: Token directo)")
        else:
            print("❌ Xray requiere XRAY_AUTHORIZATION_TOKEN configurado")
            return False
        
        if self.xray_test_plan:
            print(f"📋 Test Plan configurado: {self.xray_test_plan}")
        
        return True
    
    def get_test_issues(self, test_keys: List[str]) -> List[str]:
        """Filtrar y validar que las claves correspondan a issues de tipo Test"""
        if not self.is_configured:
            return []
        
        valid_tests = []
        
        for test_key in test_keys:
            issue = self.jira.get_issue(test_key)
            if issue:
                issue_type = issue.get('fields', {}).get('issuetype', {}).get('name', '')
                if issue_type.lower() in ['test', 'teste']:
                    valid_tests.append(test_key)
                else:
                    print(f"⚠️ {test_key} no es un issue de tipo Test (tipo actual: {issue_type})")
            else:
                print(f"⚠️ {test_key} no encontrado en Jira")
        
        return valid_tests
    
    def extract_test_key_from_tags(self, tags: List[str]) -> Optional[str]:
        """Extraer clave de test de los tags de un escenario"""
        for tag in tags:
            test_key = self.jira.extract_issue_key_from_tag(tag)
            if test_key:
                # Verificar que es un issue de tipo Test
                issue = self.jira.get_issue(test_key)
                if issue:
                    issue_type = issue.get('fields', {}).get('issuetype', {}).get('name', '')
                    if issue_type.lower() in ['test', 'teste']:
                        return test_key
        
        return None
    
    def create_execution_from_feature(self, feature_name: str, scenario_results: List[Dict[str, Any]], feature_tags: List[str] = None) -> Optional[str]:
        """Crear Test Execution con TODOS los tests usando una sola llamada (como tu curl correcto)"""
        if not self.is_configured:
            return None
        
        # Extraer test keys de los escenarios
        test_keys = []
        for result in scenario_results:
            test_key = result.get('test_key')
            if test_key:
                test_keys.append(test_key)
        
        if not test_keys:
            print("⚠️ No se encontraron test keys válidos en los escenarios")
            return None
        
        # Validar que son issues de tipo Test
        valid_test_keys = self.get_test_issues(test_keys)
        
        if not valid_test_keys:
            print("⚠️ No se encontraron issues de tipo Test válidos")
            return None
        
        # Buscar Historia de Usuario en los tags del feature
        story_key = None
        if feature_tags:
            for tag in feature_tags:
                issue_key = self.jira.extract_issue_key_from_tag(tag)
                if issue_key:
                    # Verificar si es una Historia de Usuario (no Test)
                    issue = self.jira.get_issue(issue_key)
                    if issue:
                        issue_type = issue.get('fields', {}).get('issuetype', {}).get('name', '')
                        if issue_type.lower() not in ['test', 'teste']:
                            story_key = issue_key
                            break
        
        # Agrupar resultados por test_key
        test_results = {}
        for scenario_result in scenario_results:
            test_key = scenario_result.get('test_key')
            status = scenario_result.get('status')
            scenario_name = scenario_result.get('name', 'N/A')
            error_message = scenario_result.get('error_message')
            
            if test_key and status and test_key in valid_test_keys:
                if test_key not in test_results:
                    test_results[test_key] = {
                        'status': status,
                        'scenarios': [],
                        'errors': []
                    }
                
                test_results[test_key]['scenarios'].append(scenario_name)
                if error_message:
                    test_results[test_key]['errors'].append(error_message)
                
                # Si hay un fallo, el estado general del test es failed
                if status == 'failed':
                    test_results[test_key]['status'] = 'failed'
        
        # Preparar TODOS los tests para UNA SOLA llamada (como tu curl correcto)
        print(f"🔄 Creando Test Execution con {len(test_results)} tests...")
        
        # Usar timestamps como tu curl
        now = datetime.now()
        start_time = (now - timedelta(seconds=30)).strftime("%Y-%m-%dT%H:%M:%S+01:00")
        finish_time = now.strftime("%Y-%m-%dT%H:%M:%S+01:00")
        
        # Generar nombre descriptivo del Test Execution
        execution_summary = f"Ejecución de Pruebas de {story_key if story_key else 'N/A'} - {now.strftime('%d/%m/%Y %H:%M')}"
        
        tests_array = []
        for test_key, test_data in test_results.items():
            # Mapear estado correcto para Xray
            xray_status = "passed" if test_data['status'] == 'passed' else "failed"
            
            # Comentario simple como tu curl
            comment = f"Execution from {feature_name}"
            if test_data['errors']:
                comment = f"Failed: {test_data['errors'][0][:50]}"
            
            tests_array.append({
                "testKey": test_key,
                "start": start_time,
                "finish": finish_time,
                "comment": comment,
                "status": xray_status
            })
        
        # Usar formato EXACTO de tu curl con array de tests + summary personalizado
        xray_data = {
            "tests": tests_array,
            "info": {
                "summary": execution_summary,
                "description": f"Ejecución automática del feature: {feature_name}",
                "startDate": start_time,
                "finishDate": finish_time
            }
        }
        
        headers = {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.xray_authorization_token}'
        }
        
        try:
            print(f"📤 Enviando tests a Xray...")
            
            response = requests.post(
                f"{self.xray_base_url}/api/v1/import/execution",
                json=xray_data,
                headers=headers
            )
            
            if response.status_code in [200, 201]:
                result = response.json()
                execution_key = result.get('key')
                print(f"✅ Test Execution creado: {execution_key}")
                print(f"📊 Tests incluidos y actualizados: {', '.join(test_results.keys())}")
                
                # Vincular a Historia de Usuario si existe
                if story_key and execution_key:
                    print(f"🔗 Vinculando Test Execution {execution_key} a HU {story_key}...")
                    self._link_to_story(execution_key, story_key)
                    
                    # NUEVO: Vincular cada Test individual a la Historia de Usuario
                    print(f"🔗 Vinculando Tests individuales a HU {story_key}...")
                    self._link_tests_to_story(list(test_results.keys()), story_key)
                
                return execution_key
            else:
                print(f"❌ Error al crear Test Execution: {response.status_code} - {response.text}")
                return None
                
        except Exception as e:
            print(f"❌ Error al crear Test Execution: {str(e)}")
            return None

    
    def _link_to_story(self, execution_key: str, story_key: str) -> bool:
        """Vincular Test Execution a Historia de Usuario"""
        try:
            link_data = {
                "type": {"name": "Relates"},
                "inwardIssue": {"key": execution_key},
                "outwardIssue": {"key": story_key}
            }
            
            response = self.jira.session.post(
                f"{self.jira.jira_url}/rest/api/3/issueLink",
                json=link_data
            )
            
            if response.status_code == 201:
                print(f"🔗 Test Execution {execution_key} vinculado a Historia de Usuario: {story_key}")
                return True
            else:
                print(f"⚠️ No se pudo vincular a HU {story_key}: {response.status_code}")
                return False
        except Exception as e:
            print(f"⚠️ Error al vincular a HU: {str(e)}")
            return False
    
    def _link_tests_to_story(self, test_keys: List[str], story_key: str) -> bool:
        """Vincular Tests individuales a Historia de Usuario con relación 'tests'"""
        success_count = 0
        
        # Obtener tipos de relaciones disponibles
        link_types = self.get_available_link_types()
        
        # Buscar el tipo de relación correcto para tests
        test_relation_types = []
        for link_type in link_types:
            name = link_type.get('name', '').lower()
            inward = link_type.get('inward', '').lower()
            outward = link_type.get('outward', '').lower()
            
            # Buscar relaciones relacionadas con tests
            if any(keyword in name or keyword in inward or keyword in outward 
                   for keyword in ['test', 'tested', 'cover', 'verify']):
                test_relation_types.append(link_type)
        
        if not test_relation_types:
            test_relation_types = [{"name": "Relates", "inward": "relates to", "outward": "relates to"}]
        
        for test_key in test_keys:
            linked = False
            
            # Intentar con cada tipo de relación de test
            for relation_type in test_relation_types:
                if linked:
                    break
                    
                relation_name = relation_type.get('name')
                
                # Intentar Test -> HU (outward)
                if not linked:
                    linked = self._create_link(test_key, story_key, relation_name, "outward")
                
                # Intentar HU -> Test (inward) 
                if not linked:
                    linked = self._create_link(story_key, test_key, relation_name, "inward")
            
            if linked:
                success_count += 1
                print(f"  ✅ Test {test_key} vinculado a HU {story_key}")
        
        print(f"📊 Tests vinculados a HU: {success_count}/{len(test_keys)}")
        return success_count > 0
    
    def _create_link(self, from_key: str, to_key: str, relation_name: str, direction: str) -> bool:
        """Crear un link entre dos issues"""
        try:
            link_data = {
                "type": {"name": relation_name},
                "inwardIssue": {"key": from_key},
                "outwardIssue": {"key": to_key}
            }
            
            response = self.jira.session.post(
                f"{self.jira.jira_url}/rest/api/3/issueLink",
                json=link_data
            )
            
            return response.status_code == 201
                
        except Exception as e:
            return False
    
    def get_available_link_types(self) -> List[Dict[str, Any]]:
        """Obtener tipos de relaciones disponibles en Jira"""
        if not self.jira.is_configured:
            return []
        
        try:
            response = self.jira.session.get(f"{self.jira.jira_url}/rest/api/3/issueLinkType")
            
            if response.status_code == 200:
                return response.json().get('issueLinkTypes', [])
            else:
                return []
        except Exception as e:
            return []
        """Intentar vincular con relación alternativa"""
        try:
            # Intentar con "is tested by" (relación inversa)
            link_data = {
                "type": {"name": "is tested by"},
                "inwardIssue": {"key": story_key},     # Historia de Usuario
                "outwardIssue": {"key": test_key}      # Test
            }
            
            response = self.jira.session.post(
                f"{self.jira.jira_url}/rest/api/3/issueLink",
                json=link_data
            )
            
            if response.status_code == 201:
                print(f"  ✅ Test {test_key} vinculado a HU {story_key} (relación alternativa)")
                return True
            else:
                print(f"  ⚠️ Relación alternativa también falló: {response.status_code}")
                return False
                
        except Exception as e:
            print(f"  ❌ Error en relación alternativa: {str(e)}")
            return False