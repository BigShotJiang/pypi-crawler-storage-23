"""
Hooks de Behave para integración con Jira y Xray
"""
import os
from typing import List, Dict, Any
from behave.model import Feature, Scenario
from behave.runner import Context
from .jira_integration import JiraIntegration
from .xray_integration import XrayIntegration

# Variables globales para mantener información entre hooks
_last_feature = None
_last_scenario_results = []


class JiraXrayHooks:
    """Clase para manejar los hooks de integración con Jira y Xray"""
    
    def __init__(self):
        """Inicializar las integraciones"""
        self.jira = JiraIntegration()
        self.xray = XrayIntegration(self.jira) if self.jira.is_configured else None
        self.scenario_results = []
    
    def before_all(self, context: Context):
        """Hook ejecutado antes de todas las features"""
        global _last_feature, _last_scenario_results
        _last_feature = None
        _last_scenario_results = []
        
        if not self.jira.jira_enabled:
            return  # No mostrar mensajes si está deshabilitado
        
        if self.jira.is_configured:
            print("🔗 Iniciando integración con Jira")
            if self.jira.test_connection():
                print("✅ Conexión con Jira establecida")
            else:
                print("❌ Error de conexión con Jira")
        
        if self.xray and self.xray.is_configured:
            print("🔗 Xray habilitado")
    
    def before_feature(self, context: Context, feature: Feature):
        """Hook ejecutado antes de cada feature"""
        # Limpiar resultados de escenarios anteriores
        self.scenario_results = []
        
        # Guardar información del feature en el contexto
        context.current_feature = feature
        context.jira_xray_hooks = self
    
    def after_scenario(self, context: Context, scenario: Scenario):
        """Hook ejecutado después de cada escenario"""
        # Extraer test key de los tags del escenario
        test_key = None
        if self.xray and self.xray.is_configured:
            test_key = self.xray.extract_test_key_from_tags(scenario.tags)
        
        # Recopilar información del resultado
        scenario_result = {
            'name': scenario.name,
            'status': scenario.status.name,
            'test_key': test_key,
            'tags': scenario.tags,
            'error_message': None
        }
        
        # Capturar mensaje de error si el escenario falló o tuvo error
        if scenario.status.name in ('failed', 'error') and hasattr(scenario, 'exception'):
            scenario_result['error_message'] = str(scenario.exception)
        
        self.scenario_results.append(scenario_result)
        
        # ============================================================================
        # CREACIÓN AUTOMÁTICA DE ISSUE EN JIRA SI EL ESCENARIO FALLÓ
        # ============================================================================
        
        # Verificar si el escenario falló y si está configurado para crear issue
        if scenario.status.name in ('failed', 'error'):
            if hasattr(context, 'jira_issue_on_failure') and context.jira_issue_on_failure.get('enabled'):
                self._create_issue_on_failure(context, scenario)
    
    def _create_issue_on_failure(self, context: Context, scenario: Scenario):
        """Crear una issue en Jira cuando un escenario falla"""
        if not self.jira.is_configured:
            print("⚠️ Jira no configurado, no se puede crear issue")
            return
        
        config = context.jira_issue_on_failure
        issue_type = config.get('issue_type', 'Bug')
        title = config.get('title')
        priority = config.get('priority', 'Medium')
        labels = config.get('labels', ['automated-test'])
        
        # Verificar si ya existe una issue con el mismo título y tipo
        print(f"🔍 Verificando si existe issue con título '{title}' y tipo '{issue_type}'...")
        existing_issues = self.jira.search_issues_by_summary_and_type(title, issue_type)
        
        if existing_issues:
            issue_key = existing_issues[0].get('key')
            print(f"ℹ️ Ya existe una issue con ese título y tipo: {issue_key}")
            print(f"   No se creará una duplicada")
            
            # Opcionalmente agregar un comentario a la issue existente
            error_msg = str(scenario.exception) if hasattr(scenario, 'exception') else 'Error desconocido'
            comment = f"El escenario '{scenario.name}' falló nuevamente.\n\nError: {error_msg}\n\nFecha: {self._get_current_datetime()}"
            self.jira.add_comment_to_issue(issue_key, comment)
            print(f"💬 Comentario agregado a la issue existente {issue_key}")
            return
        
        # Generar descripción automática si no se proporcionó
        description = config.get('description')
        if not description:
            error_msg = str(scenario.exception) if hasattr(scenario, 'exception') else 'Error desconocido'
            description = self._generate_issue_description(scenario, error_msg)
        
        # Crear la issue
        print(f"📝 Creando issue de tipo '{issue_type}' con título '{title}'...")
        issue_key = self.jira.create_issue(
            summary=title,
            description=description,
            issue_type=issue_type,
            priority=priority,
            labels=labels
        )
        
        if issue_key:
            print(f"✅ Issue creada exitosamente: {issue_key}")
            print(f"   🔗 {self.jira.jira_url}/browse/{issue_key}")
        else:
            print(f"❌ No se pudo crear la issue")
    
    def _generate_issue_description(self, scenario: Scenario, error_message: str) -> str:
        """Generar descripción automática para la issue"""
        description = f"""Escenario de prueba automatizada falló.

**Escenario:** {scenario.name}
**Feature:** {scenario.feature.name if hasattr(scenario, 'feature') else 'N/A'}
**Estado:** {scenario.status.name}

**Error:**
{error_message}

**Tags:** {', '.join(scenario.tags) if scenario.tags else 'Ninguno'}

**Fecha de fallo:** {self._get_current_datetime()}

---
Esta issue fue creada automáticamente por el framework de testing.
"""
        return description
    
    def _get_current_datetime(self) -> str:
        """Obtener fecha y hora actual formateada"""
        from datetime import datetime
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    def after_feature(self, context: Context, feature: Feature):
        """Hook ejecutado después de cada feature"""
        global _last_feature, _last_scenario_results
        # Guardar en variables globales para que persistan
        _last_feature = feature
        _last_scenario_results = self.scenario_results.copy()
    
    def after_all(self, context: Context):
        """Hook ejecutado después de todas las features - procesar integración aquí"""
        global _last_feature, _last_scenario_results
        
        if not _last_feature:
            return
        
        if not self.jira.jira_enabled:
            return  # No procesar si Jira está deshabilitado
            
        if not (self.jira.is_configured or (self.xray and self.xray.is_configured)):
            return
        
        feature = _last_feature
        self.scenario_results = _last_scenario_results
        
        print(f"\n🔗 Procesando integración para feature: {feature.name}")
        
        # Obtener ruta del reporte HTML
        report_path = self._get_html_report_path(context)
        
        if not report_path or not os.path.exists(report_path):
            print("⚠️ Reporte HTML no encontrado, saltando integración")
            return
        
        # Procesar integración con Jira (regla 3 y 4)
        if self.jira.is_configured:
            self._process_jira_integration(feature, report_path)
        
        # Procesar integración con Xray (regla 5)
        if self.xray and self.xray.is_configured:
            self._process_xray_integration(feature)
    
    def _get_html_report_path(self, context: Context) -> str:
        """Obtener la ruta del reporte HTML generado"""
        # Intentar obtener la ruta del contexto si está disponible
        if hasattr(context, 'html_report_path'):
            return context.html_report_path
        
        # Leer directorio de reportes HTML desde .env
        html_reports_dir = os.getenv('HTML_REPORTS_DIR', 'html-reports')
        
        # Buscar archivos HTML en el directorio configurado
        if os.path.exists(html_reports_dir):
            # Buscar el archivo HTML más reciente
            html_files = []
            for file in os.listdir(html_reports_dir):
                if file.endswith('.html'):
                    file_path = os.path.join(html_reports_dir, file)
                    html_files.append((file_path, os.path.getmtime(file_path)))
            
            if html_files:
                # Ordenar por fecha de modificación (más reciente primero)
                html_files.sort(key=lambda x: x[1], reverse=True)
                latest_report = html_files[0][0]
                print(f"📄 Reporte HTML encontrado: {latest_report}")
                return latest_report
        
        # Buscar en ubicaciones de fallback
        possible_paths = [
            f'{html_reports_dir}/report.html',
            'reports/report.html',
            'report.html',
            'reports/behave-report.html'
        ]
        
        for path in possible_paths:
            if os.path.exists(path):
                print(f"📄 Reporte HTML encontrado (fallback): {path}")
                return path
        
        print(f"⚠️ No se encontró reporte HTML en {html_reports_dir}")
        return None
    
    def _process_jira_integration(self, feature: Feature, report_path: str):
        """Procesar integración con Jira (reglas 3 y 4)"""
        # Verificar si la subida de reportes está habilitada
        upload_reports = os.getenv('JIRA_UPLOAD_REPORTS', 'true').lower() == 'true'
        
        if not upload_reports:
            print("ℹ️ Subida de reportes a Jira deshabilitada (JIRA_UPLOAD_REPORTS=false)")
            return
        
        print("📋 Procesando integración con Jira...")
        
        # Recopilar todos los tags únicos de los escenarios ejecutados
        scenario_tags = set()
        for result in self.scenario_results:
            if result.get('tags'):
                scenario_tags.update(result['tags'])
        
        # Si no hay tags en los escenarios, usar los tags del feature como fallback
        if not scenario_tags:
            print("⚠️ No hay tags en los escenarios, usando tags del feature")
            scenario_tags = set(feature.tags)
        
        if not scenario_tags:
            print("⚠️ Feature y escenarios sin tags, saltando integración con Jira")
            return
        
        # Procesar cada tag único
        results = self.jira.process_feature_tags(list(scenario_tags), report_path)
        
        if results:
            successful = sum(1 for success in results.values() if success)
            total = len(results)
            print(f"📊 Jira: {successful}/{total} reportes adjuntados exitosamente")
        else:
            print("ℹ️ Ningún tag corresponde a issues válidas de Jira")
    
    def _process_xray_integration(self, feature: Feature):
        """Procesar integración con Xray (regla 5) - Método optimizado"""
        print("🧪 Procesando integración con Xray...")
        
        # Usar el método legacy que ya funciona perfectamente
        # El método de JSON tiene problemas de compatibilidad con Xray Cloud
        self._process_xray_integration_legacy(feature)
    
    def _process_xray_integration_legacy(self, feature: Feature):
        """Método legacy de integración con Xray (para fallback)"""
        # Filtrar escenarios que tienen test keys válidos
        valid_scenarios = [
            result for result in self.scenario_results 
            if result.get('test_key')
        ]
        
        if not valid_scenarios:
            print("⚠️ No se encontraron escenarios con test keys válidos para Xray")
            return
        
        # Crear Test Execution y actualizar estados, pasando los tags del feature
        execution_key = self.xray.create_execution_from_feature(
            feature.name, 
            valid_scenarios,
            feature.tags  # Pasar los tags del feature
        )
        
        if execution_key:
            print(f"✅ Test Execution creado y actualizado (legacy): {execution_key}")
        else:
            print("❌ Error al crear Test Execution en Xray (legacy)")


# Instancia global para usar en environment.py
jira_xray_hooks = JiraXrayHooks()


def setup_jira_xray_hooks(context: Context):
    """Configurar los hooks de Jira/Xray en el contexto de Behave"""
    context.jira_xray_hooks = jira_xray_hooks
    
    # Registrar hooks
    context.add_cleanup(jira_xray_hooks.before_all, context)


# Funciones de hook para usar directamente en environment.py
def before_all_jira_xray(context: Context):
    """Hook before_all para Jira/Xray"""
    jira_xray_hooks.before_all(context)


def before_feature_jira_xray(context: Context, feature: Feature):
    """Hook before_feature para Jira/Xray"""
    jira_xray_hooks.before_feature(context, feature)


def after_scenario_jira_xray(context: Context, scenario: Scenario):
    """Hook after_scenario para Jira/Xray"""
    jira_xray_hooks.after_scenario(context, scenario)


def after_feature_jira_xray(context: Context, feature: Feature):
    """Hook after_feature para Jira/Xray"""
    jira_xray_hooks.after_feature(context, feature)