#!/usr/bin/env python
"""
Script para generar un reporte unificado desde múltiples JSONs de ejecuciones paralelas.

Uso como módulo:
    python -m hakalab_framework.generate_unified_report
    python -m hakalab_framework.generate_unified_report --json-dir ./html-reports --output-dir ./reports

Uso directo:
    python hakalab_framework/generate_unified_report.py
"""

import sys
import argparse
from pathlib import Path

from .core.unified_report_generator import UnifiedReportGenerator


def main():
    parser = argparse.ArgumentParser(
        description="Genera un reporte HTML unificado desde múltiples JSONs"
    )
    
    parser.add_argument(
        "--json-dir",
        type=str,
        default="html-reports",
        help="Directorio con los JSONs (default: html-reports)",
    )
    
    parser.add_argument(
        "--output-dir",
        type=str,
        default="html-reports",
        help="Directorio de salida (default: html-reports)",
    )
    
    parser.add_argument(
        "--output-file",
        type=str,
        default="unified_report.html",
        help="Nombre del archivo (default: unified_report.html)",
    )
    
    parser.add_argument(
        "--artifacts-dir",
        type=str,
        default=None,
        help="Alias para --json-dir (para compatibilidad con CI/CD)",
    )
    
    args = parser.parse_args()
    
    # Usar artifacts-dir si se proporciona (para compatibilidad con CI/CD)
    json_dir = args.artifacts_dir or args.json_dir
    
    try:
        print(f"📊 Generando reporte unificado...")
        print(f"   📁 Entrada: {json_dir}")
        print(f"   📁 Salida: {args.output_dir}")
        
        generator = UnifiedReportGenerator(output_dir=args.output_dir)
        generator.load_json_reports(json_dir)
        
        print(f"   ✓ {len(generator.reports_data)} reportes cargados")
        
        output_file = generator.save_report(filename=args.output_file)
        
        print(f"   ✓ Reporte guardado: {output_file}")
        print(f"\n✅ Éxito!")
        
        return 0
        
    except FileNotFoundError as e:
        print(f"❌ Error: {e}")
        return 1
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
