"""
Environment.py SIMPLE para Hakalab Framework
Configuración automática de todas las integraciones
"""
from hakalab_framework import (
    setup_framework_context,
    setup_scenario_context
)
from hakalab_framework.core.screenshot_manager import take_screenshot_on_failure, take_screenshot
from hakalab_framework.core.behave_html_integration import (
    setup_html_reporting,
    before_feature_html,
    after_feature_html,
    before_scenario_html,
    after_scenario_html,
    after_step_html,
    generate_html_report
)
from hakalab_framework.core.environment_config import (
    auto_before_feature,
    auto_after_scenario,
    auto_after_feature,
    auto_after_all
)
from hakalab_framework.steps import *


def before_all(context):
    """Configuración inicial - Framework + HTML Reporter + Auto Jira/Xray"""
    try:
        # Limpiar archivos antiguos si está habilitado
        from hakalab_framework.core.screenshot_manager import cleanup_directories
        cleanup_directories()
        
        # Configurar framework (incluye auto-detección de Jira/Xray)
        setup_framework_context(context)
        
        # Configurar HTML reporting
        setup_html_reporting(context)
        
        print("✅ Framework configurado correctamente")
    except Exception as e:
        print(f"❌ Error en before_all: {e}")
        raise


def before_feature(context, feature):
    try:
        # HTML reporting
        before_feature_html(context, feature)
        
        # Auto-hooks (incluye Jira/Xray si está habilitado)
        auto_before_feature(context, feature)
    except Exception as e:
        print(f"⚠️ Error en before_feature: {e}")


def before_scenario(context, scenario):
    try:
        setup_scenario_context(context, scenario)
        before_scenario_html(context, scenario)
        print(f"🚀 Iniciando escenario: {scenario.name}")
    except Exception as e:
        print(f"❌ Error en before_scenario: {e}")
        raise


def after_step(context, step):
    try:
        after_step_html(context, step)
        import os
        capture_framework_steps = os.getenv('CAPTURE_FRAMEWORK_STEPS', 'false').lower() == 'true'
        if capture_framework_steps and hasattr(context, 'page') and context.page:
            step_name = step.name.replace(' ', '_').replace('"', '').replace("'", '')
            screenshot_name = f"framework_step_{step.line}_{step_name[:50]}"
            take_screenshot(context, screenshot_name)
    except Exception as e:
        print(f"⚠️ Error en after_step: {e}")


def after_scenario(context, scenario):
    try:
        after_scenario_html(context, scenario)
        take_screenshot_on_failure(context, scenario)
        
        # Auto-hooks (incluye Jira/Xray si está habilitado)
        auto_after_scenario(context, scenario)
    except Exception as e:
        print(f"⚠️ Error en after_scenario: {e}")

    try:
        if hasattr(context, 'page') and context.page:
            context.page.close()
            context.page = None
    except:
        pass


def after_feature(context, feature):
    try:
        after_feature_html(context, feature)
        
        # Auto-hooks (incluye Jira/Xray si está habilitado)
        auto_after_feature(context, feature)
    except Exception as e:
        print(f"⚠️ Error en after_feature: {e}")


def after_all(context):
    try:
        if hasattr(context, 'framework_config') and context.framework_config:
            context.framework_config.cleanup()
            print("✅ Playwright cerrado correctamente")
    except Exception as e:
        print(f"⚠️ Error cerrando Playwright: {e}")

    try:
        report_path = generate_html_report(context)
        if report_path:
            print(f"🎨 Reporte HTML personalizado: {report_path}")
            print("   📊 Incluye gráficos, screenshots y navegación interactiva")
            
            # Guardar ruta del reporte para Jira/Xray
            context.html_report_path = report_path
    except Exception as e:
        print(f"⚠️ Error generando reporte HTML: {e}")

    try:
        from hakalab_framework.core.screenshot_manager import get_screenshots_summary
        summary = get_screenshots_summary()
        if summary["total"] > 0:
            print(f"📸 Screenshots generados: {summary['total']} total, {summary['failed']} fallos")
    except Exception as e:
        print(f"⚠️ Error obteniendo resumen de screenshots: {e}")

    # Auto-hooks (incluye Jira/Xray si está habilitado)
    auto_after_all(context)