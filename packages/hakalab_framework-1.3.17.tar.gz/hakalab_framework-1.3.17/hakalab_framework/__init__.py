"""
Hakalab Framework - Framework completo de pruebas funcionales
"""

__version__ = "1.2.24"
__author__ = "Felipe Farias"
__email__ = "felipe.farias@hakalab.com"
__description__ = "Framework completo de pruebas funcionales con Playwright y Behave"

from .core.element_locator import ElementLocator
from .core.variable_manager import VariableManager
from .core.report_generator import ReportGenerator
from .core.step_suggester import StepSuggester
from .core.report_merger import ReportMerger
from .core.cucumber_report_merger import CucumberReportMerger
from .core.unified_report_generator import UnifiedReportGenerator
from .core.environment_config import (
    FrameworkConfig,
    setup_framework_context,
    setup_scenario_context,
    auto_before_feature,
    auto_after_scenario,
    auto_after_feature,
    auto_after_all
)
from .core.parallelization import (
    get_feature_files,
    get_features_selection
)

# Integraciones
from .integrations.jira_integration import JiraIntegration
from .integrations.xray_integration import XrayIntegration

__all__ = [
    "ElementLocator",
    "VariableManager", 
    "ReportGenerator",
    "StepSuggester",
    "ReportMerger",
    "CucumberReportMerger",
    "UnifiedReportGenerator",
    "FrameworkConfig",
    "setup_framework_context",
    "setup_scenario_context",
    "auto_before_feature",
    "auto_after_scenario", 
    "auto_after_feature",
    "auto_after_all",
    "get_feature_files",
    "get_features_selection",
    "JiraIntegration",
    "XrayIntegration"
]