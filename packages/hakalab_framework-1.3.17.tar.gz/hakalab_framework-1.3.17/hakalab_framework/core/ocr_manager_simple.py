#!/usr/bin/env python3
"""
OCR Manager Simple - Versión básica que funciona solo con Tesseract
"""

import os
import logging
from typing import List, Dict, Optional, Tuple

try:
    import pytesseract
    from PIL import Image
    TESSERACT_AVAILABLE = True
except ImportError:
    TESSERACT_AVAILABLE = False


class OCRResult:
    """Clase para almacenar resultados de OCR"""
    def __init__(self, text: str, confidence: float, bbox: Optional[Tuple] = None):
        self.text = text.strip()
        self.confidence = confidence
        self.bbox = bbox  # (x, y, width, height)
    
    def __str__(self):
        return f"OCRResult(text='{self.text}', confidence={self.confidence:.2f})"


class OCRManagerSimple:
    """Manager simple para operaciones de OCR solo con Tesseract"""
    
    def __init__(self):
        self.logger = logging.getLogger('hakalab_framework.ocr')
        self._setup_tesseract()
        
    def _setup_tesseract(self):
        """Configura Tesseract si está disponible"""
        if TESSERACT_AVAILABLE:
            # Configurar path de Tesseract en Windows si es necesario
            tesseract_path = os.getenv('TESSERACT_PATH')
            if tesseract_path and os.path.exists(tesseract_path):
                pytesseract.pytesseract.tesseract_cmd = tesseract_path
    
    def extract_text_tesseract(self, image_path: str, language: str = 'eng+spa', 
                              config: str = '--psm 6') -> OCRResult:
        """Extrae texto usando Tesseract"""
        if not TESSERACT_AVAILABLE:
            raise ImportError("Tesseract no está disponible. Instala: pip install pytesseract Pillow")
        
        try:
            # Cargar imagen
            image = Image.open(image_path)
            
            # Extraer texto
            text = pytesseract.image_to_string(image, lang=language, config=config)
            
            # Obtener datos detallados para confidence
            try:
                data = pytesseract.image_to_data(image, lang=language, config=config, output_type=pytesseract.Output.DICT)
                confidences = [int(conf) for conf in data['conf'] if int(conf) > 0]
                avg_confidence = sum(confidences) / len(confidences) if confidences else 0
            except:
                avg_confidence = 75.0  # Valor por defecto
            
            self.logger.info(f"Tesseract OCR completado - Confidence: {avg_confidence:.2f}%")
            return OCRResult(text, avg_confidence)
            
        except Exception as e:
            self.logger.error(f"Error en Tesseract OCR: {e}")
            raise
    
    def extract_text_auto(self, image_path: str) -> List[OCRResult]:
        """Extrae texto usando Tesseract (versión simple)"""
        if TESSERACT_AVAILABLE:
            result = self.extract_text_tesseract(image_path)
            return [result]
        else:
            raise ImportError("No hay engines de OCR disponibles. Instala: pip install pytesseract Pillow")
    
    def find_text_in_image(self, image_path: str, search_text: str, 
                          case_sensitive: bool = False) -> List[OCRResult]:
        """Busca texto específico en una imagen"""
        results = self.extract_text_auto(image_path)
        
        # Buscar texto
        found_results = []
        for result in results:
            text_to_search = result.text if case_sensitive else result.text.lower()
            search_target = search_text if case_sensitive else search_text.lower()
            
            if search_target in text_to_search:
                found_results.append(result)
        
        return found_results
    
    def get_all_text(self, image_path: str, min_confidence: float = 50.0) -> str:
        """Obtiene todo el texto de una imagen como string"""
        results = self.extract_text_auto(image_path)
        
        # Filtrar por confidence y concatenar
        filtered_texts = [r.text for r in results if r.confidence >= min_confidence]
        return '\n'.join(filtered_texts)
    
    def validate_text_quality(self, image_path: str, min_confidence: float = 70.0) -> Dict:
        """Valida la calidad del texto en una imagen"""
        try:
            results = self.extract_text_auto(image_path)
            
            if not results:
                return {
                    'is_readable': False,
                    'avg_confidence': 0,
                    'text_count': 0,
                    'quality': 'No text found'
                }
            
            confidences = [r.confidence for r in results]
            avg_confidence = sum(confidences) / len(confidences)
            readable_count = sum(1 for c in confidences if c >= min_confidence)
            
            quality = 'Excellent' if avg_confidence >= 90 else \
                     'Good' if avg_confidence >= 70 else \
                     'Fair' if avg_confidence >= 50 else 'Poor'
            
            return {
                'is_readable': avg_confidence >= min_confidence,
                'avg_confidence': avg_confidence,
                'text_count': len(results),
                'readable_count': readable_count,
                'quality': quality,
                'texts': [r.text for r in results]
            }
            
        except Exception as e:
            self.logger.error(f"Error validando calidad de texto: {e}")
            return {
                'is_readable': False,
                'avg_confidence': 0,
                'text_count': 0,
                'quality': f'Error: {e}'
            }