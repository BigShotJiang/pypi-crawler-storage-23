#!/usr/bin/env python3
"""
Runner personalizado para manejar reintentos de escenarios fallidos
"""
import os
import sys
from behave.__main__ import main as behave_main
from behave.configuration import Configuration
from behave.runner import Runner
from behave.model import Scenario


class RetryRunner(Runner):
    """Runner personalizado que soporta reintentos de escenarios"""
    
    def __init__(self, config):
        super().__init__(config)
        self.retry_enabled = os.getenv('RETRY_FAILED_SCENARIOS', 'false').lower() == 'true'
        self.max_retries = int(os.getenv('MAX_SCENARIO_RETRIES', '1'))
        self.scenario_retry_count = {}
    
    def run_model(self, features=None):
        """Ejecuta el modelo con soporte para reintentos"""
        if not self.retry_enabled:
            # Si los reintentos no están habilitados, usar el comportamiento por defecto
            return super().run_model(features)
        
        # Ejecutar con reintentos
        return self._run_with_retries(features)
    
    def _run_with_retries(self, features=None):
        """Ejecuta features con reintentos de escenarios fallidos"""
        if features is None:
            features = self.features
        
        # Primera ejecución
        self.context.scenario_retry_count = {}
        failed = super().run_model(features)
        
        # Si no hay fallos o los reintentos están deshabilitados, terminar
        if not failed or not self.retry_enabled:
            return failed
        
        # Recopilar escenarios fallidos que necesitan reintento
        scenarios_to_retry = []
        
        for feature in features:
            for scenario in feature.scenarios:
                if scenario.status == 'failed':
                    scenario_id = f"{feature.name}::{scenario.name}"
                    retry_count = self.context.scenario_retry_count.get(scenario_id, 0)
                    
                    if retry_count < self.max_retries:
                        scenarios_to_retry.append((feature, scenario, retry_count))
        
        # Reintentar escenarios fallidos
        for feature, scenario, retry_count in scenarios_to_retry:
            scenario_id = f"{feature.name}::{scenario.name}"
            
            for attempt in range(retry_count + 1, self.max_retries + 1):
                print(f"\n🔄 Reintentando escenario: {scenario.name}")
                print(f"   Intento {attempt} de {self.max_retries}")
                
                # Actualizar contador
                self.context.scenario_retry_count[scenario_id] = attempt
                
                # Limpiar estado del escenario
                self._reset_scenario_state(scenario)
                
                # Re-ejecutar el escenario
                self.run_scenario(scenario)
                
                # Si pasó, salir del loop de reintentos
                if scenario.status == 'passed':
                    print(f"✅ Escenario pasó después de {attempt} reintento(s)")
                    break
                
                # Si falló y es el último intento
                if attempt >= self.max_retries:
                    print(f"❌ Escenario falló después de {self.max_retries} reintentos")
        
        # Retornar si hay fallos después de todos los reintentos
        return any(scenario.status == 'failed' for feature in features for scenario in feature.scenarios)
    
    def _reset_scenario_state(self, scenario):
        """Resetea el estado de un escenario para reintento"""
        # Resetear status
        scenario.status = 'untested'
        scenario.duration = 0
        
        # Resetear steps
        for step in scenario.steps:
            step.status = 'untested'
            step.duration = 0
            step.error_message = None
            step.exception = None
        
        # Limpiar página si existe
        try:
            if hasattr(self.context, 'page') and self.context.page:
                try:
                    self.context.page.close()
                except Exception:
                    pass
                
                # Crear nueva página
                if hasattr(self.context, 'framework_config'):
                    self.context.page = self.context.framework_config.create_page()
        except Exception as e:
            print(f"⚠️ Error reseteando página: {e}")
        
        # Limpiar variables del escenario
        try:
            if hasattr(self.context, 'variable_manager'):
                self.context.variable_manager.clear_scenario_variables()
        except Exception as e:
            print(f"⚠️ Error limpiando variables: {e}")


def run_behave_with_retries(args=None):
    """
    Ejecuta Behave con soporte para reintentos de escenarios
    
    Args:
        args: Lista de argumentos de línea de comandos (opcional)
    
    Returns:
        int: Código de salida (0 = éxito, 1 = fallos)
    """
    if args is None:
        args = sys.argv[1:]
    
    # Verificar si los reintentos están habilitados
    retry_enabled = os.getenv('RETRY_FAILED_SCENARIOS', 'false').lower() == 'true'
    
    if not retry_enabled:
        # Si no están habilitados, usar behave normal
        return behave_main(args)
    
    # Crear configuración
    config = Configuration(args)
    
    # Crear y ejecutar runner con reintentos
    runner = RetryRunner(config)
    
    # Ejecutar
    failed = runner.run()
    
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(run_behave_with_retries())
