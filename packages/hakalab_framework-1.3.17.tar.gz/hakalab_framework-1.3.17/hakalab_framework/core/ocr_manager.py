#!/usr/bin/env python3
"""
OCR Manager - Módulo para reconocimiento óptico de caracteres
Soporta múltiples engines: Tesseract, EasyOCR
"""

import os
import cv2
import numpy as np
from PIL import Image
from typing import List, Dict, Optional, Tuple
import logging

try:
    import pytesseract
    TESSERACT_AVAILABLE = True
except ImportError:
    TESSERACT_AVAILABLE = False

try:
    import easyocr
    EASYOCR_AVAILABLE = True
except ImportError:
    EASYOCR_AVAILABLE = False


class OCRResult:
    """Clase para almacenar resultados de OCR"""
    def __init__(self, text: str, confidence: float, bbox: Optional[Tuple] = None):
        self.text = text.strip()
        self.confidence = confidence
        self.bbox = bbox  # (x, y, width, height)
    
    def __str__(self):
        return f"OCRResult(text='{self.text}', confidence={self.confidence:.2f})"


class OCRManager:
    """Manager para operaciones de OCR con múltiples engines"""
    
    def __init__(self):
        self.logger = logging.getLogger('hakalab_framework.ocr')
        self.easyocr_reader = None
        self._setup_tesseract()
        
    def _setup_tesseract(self):
        """Configura Tesseract si está disponible"""
        if TESSERACT_AVAILABLE:
            # Configurar path de Tesseract en Windows si es necesario
            tesseract_path = os.getenv('TESSERACT_PATH')
            if tesseract_path and os.path.exists(tesseract_path):
                pytesseract.pytesseract.tesseract_cmd = tesseract_path
                
    def _get_easyocr_reader(self, languages=['en', 'es']):
        """Obtiene o crea el reader de EasyOCR"""
        if not EASYOCR_AVAILABLE:
            raise ImportError("EasyOCR no está instalado")
            
        if self.easyocr_reader is None:
            self.easyocr_reader = easyocr.Reader(languages, gpu=False)
        return self.easyocr_reader
    
    def preprocess_image(self, image_path: str, preprocessing: str = 'default') -> np.ndarray:
        """Preprocesa imagen para mejorar OCR"""
        # Cargar imagen
        if isinstance(image_path, str):
            image = cv2.imread(image_path)
        else:
            image = image_path
            
        if image is None:
            raise ValueError(f"No se pudo cargar la imagen: {image_path}")
        
        # Convertir a escala de grises
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        if preprocessing == 'default':
            # Preprocesamiento básico
            processed = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
        elif preprocessing == 'denoise':
            # Reducir ruido
            processed = cv2.medianBlur(gray, 3)
            processed = cv2.threshold(processed, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
        elif preprocessing == 'enhance':
            # Mejorar contraste
            processed = cv2.equalizeHist(gray)
            processed = cv2.threshold(processed, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
        elif preprocessing == 'morphology':
            # Operaciones morfológicas
            kernel = np.ones((1,1), np.uint8)
            processed = cv2.morphologyEx(gray, cv2.MORPH_CLOSE, kernel)
            processed = cv2.threshold(processed, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
        else:
            processed = gray
            
        return processed
    
    def extract_text_tesseract(self, image_path: str, language: str = 'eng+spa', 
                              config: str = '--psm 6', preprocessing: str = 'default') -> OCRResult:
        """Extrae texto usando Tesseract"""
        if not TESSERACT_AVAILABLE:
            raise ImportError("Tesseract no está disponible")
        
        try:
            # Preprocesar imagen
            processed_image = self.preprocess_image(image_path, preprocessing)
            
            # Extraer texto
            text = pytesseract.image_to_string(processed_image, lang=language, config=config)
            
            # Obtener datos detallados para confidence
            data = pytesseract.image_to_data(processed_image, lang=language, config=config, output_type=pytesseract.Output.DICT)
            
            # Calcular confidence promedio
            confidences = [int(conf) for conf in data['conf'] if int(conf) > 0]
            avg_confidence = sum(confidences) / len(confidences) if confidences else 0
            
            self.logger.info(f"Tesseract OCR completado - Confidence: {avg_confidence:.2f}%")
            return OCRResult(text, avg_confidence)
            
        except Exception as e:
            self.logger.error(f"Error en Tesseract OCR: {e}")
            raise
    
    def extract_text_easyocr(self, image_path: str, languages=['en', 'es']) -> List[OCRResult]:
        """Extrae texto usando EasyOCR"""
        if not EASYOCR_AVAILABLE:
            raise ImportError("EasyOCR no está disponible")
        
        try:
            reader = self._get_easyocr_reader(languages)
            results = reader.readtext(image_path)
            
            ocr_results = []
            for (bbox, text, confidence) in results:
                # Convertir bbox a formato (x, y, width, height)
                x_coords = [point[0] for point in bbox]
                y_coords = [point[1] for point in bbox]
                x, y = min(x_coords), min(y_coords)
                width = max(x_coords) - x
                height = max(y_coords) - y
                
                ocr_results.append(OCRResult(text, confidence * 100, (x, y, width, height)))
            
            self.logger.info(f"EasyOCR completado - {len(ocr_results)} textos encontrados")
            return ocr_results
            
        except Exception as e:
            self.logger.error(f"Error en EasyOCR: {e}")
            raise
    
    def extract_text_auto(self, image_path: str, prefer_engine: str = 'easyocr') -> List[OCRResult]:
        """Extrae texto usando el mejor engine disponible"""
        if prefer_engine == 'easyocr' and EASYOCR_AVAILABLE:
            return self.extract_text_easyocr(image_path)
        elif prefer_engine == 'tesseract' and TESSERACT_AVAILABLE:
            result = self.extract_text_tesseract(image_path)
            return [result]
        elif EASYOCR_AVAILABLE:
            return self.extract_text_easyocr(image_path)
        elif TESSERACT_AVAILABLE:
            result = self.extract_text_tesseract(image_path)
            return [result]
        else:
            raise ImportError("No hay engines de OCR disponibles")
    
    def find_text_in_image(self, image_path: str, search_text: str, 
                          case_sensitive: bool = False, engine: str = 'auto') -> List[OCRResult]:
        """Busca texto específico en una imagen"""
        if engine == 'auto':
            results = self.extract_text_auto(image_path)
        elif engine == 'easyocr':
            results = self.extract_text_easyocr(image_path)
        elif engine == 'tesseract':
            result = self.extract_text_tesseract(image_path)
            results = [result]
        else:
            raise ValueError(f"Engine no soportado: {engine}")
        
        # Buscar texto
        found_results = []
        for result in results:
            text_to_search = result.text if case_sensitive else result.text.lower()
            search_target = search_text if case_sensitive else search_text.lower()
            
            if search_target in text_to_search:
                found_results.append(result)
        
        return found_results
    
    def get_all_text(self, image_path: str, engine: str = 'auto', min_confidence: float = 50.0) -> str:
        """Obtiene todo el texto de una imagen como string"""
        if engine == 'auto':
            results = self.extract_text_auto(image_path)
        elif engine == 'easyocr':
            results = self.extract_text_easyocr(image_path)
        elif engine == 'tesseract':
            result = self.extract_text_tesseract(image_path)
            results = [result]
        else:
            raise ValueError(f"Engine no soportado: {engine}")
        
        # Filtrar por confidence y concatenar
        filtered_texts = [r.text for r in results if r.confidence >= min_confidence]
        return '\n'.join(filtered_texts)
    
    def validate_text_quality(self, image_path: str, min_confidence: float = 70.0) -> Dict:
        """Valida la calidad del texto en una imagen"""
        try:
            results = self.extract_text_auto(image_path)
            
            if not results:
                return {
                    'is_readable': False,
                    'avg_confidence': 0,
                    'text_count': 0,
                    'quality': 'No text found'
                }
            
            confidences = [r.confidence for r in results]
            avg_confidence = sum(confidences) / len(confidences)
            readable_count = sum(1 for c in confidences if c >= min_confidence)
            
            quality = 'Excellent' if avg_confidence >= 90 else \
                     'Good' if avg_confidence >= 70 else \
                     'Fair' if avg_confidence >= 50 else 'Poor'
            
            return {
                'is_readable': avg_confidence >= min_confidence,
                'avg_confidence': avg_confidence,
                'text_count': len(results),
                'readable_count': readable_count,
                'quality': quality,
                'texts': [r.text for r in results]
            }
            
        except Exception as e:
            self.logger.error(f"Error validando calidad de texto: {e}")
            return {
                'is_readable': False,
                'avg_confidence': 0,
                'text_count': 0,
                'quality': f'Error: {e}'
            }