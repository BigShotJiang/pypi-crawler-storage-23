"""
Gestor de paralelización para distribución de escenarios en CI/CD.

Este módulo proporciona funcionalidades para:
- Parsear correctamente la estructura Gherkin (Feature, Scenario, Scenario Outline, Examples)
- Contar escenarios reales considerando Scenario Outline con múltiples Examples
- Distribuir escenarios equitativamente entre shards basado en ejecuciones
- Generar filtros de tags precisos para Behave
"""

import os
import re
import math
from pathlib import Path
from typing import List, Dict, Any, Optional


class ParallelizationManager:
    """Gestor de paralelización de escenarios para CI/CD"""
    
    @staticmethod
    def get_scenario_tags() -> List[Dict[str, Any]]:
        """
        Extrae todos los escenarios y sus tags de los feature files.
        Retorna lista de diccionarios con información detallada de cada escenario.
        
        Estructura retornada:
        [
            {
                'file': 'features/demo.feature',
                'feature_tags': ['@PROD-145'],
                'scenario_name': 'Navegación básica 1',
                'scenario_tags': ['@PROD-91', '@Haka-Demo'],
                'executions': 2,  # Cantidad de ejecuciones (Examples en Scenario Outline)
                'line': 5,
                'all_tags': ['@PROD-145', '@PROD-91', '@Haka-Demo']  # Feature + Scenario
            },
            ...
        ]
        
        Returns:
            List[Dict]: Lista de escenarios con información detallada
        """
        feature_dir = Path('features')
        
        # Validar que el directorio existe
        if not feature_dir.exists():
            print(f"[WARNING] Directorio {feature_dir} no encontrado")
            return []
        
        all_features = sorted([str(f) for f in feature_dir.glob('**/*.feature')])
        
        if not all_features:
            print("[WARNING] No se encontraron archivos .feature")
            return []
        
        scenarios_data = []
        
        for feature_file in all_features:
            try:
                with open(feature_file, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                
                feature_tags = []
                current_scenario_tags = []
                current_scenario_name = None
                current_scenario_line = None
                is_scenario_outline = False
                example_count = 0
                in_examples = False
                
                for idx, line in enumerate(lines):
                    stripped = line.strip()
                    
                    # Capturar tags de Feature (antes de "Feature:")
                    if stripped.startswith('@'):
                        # Extraer todos los tags: @TAG-123, @smoke, @Haka-Demo, etc.
                        tags = re.findall(r'@[\w-]+', stripped)
                        
                        # Determinar si son tags de Feature o Scenario
                        # Buscar la siguiente línea no-tag
                        next_line_idx = idx + 1
                        while next_line_idx < len(lines) and lines[next_line_idx].strip().startswith('@'):
                            next_line_idx += 1
                        
                        next_line = lines[next_line_idx].strip() if next_line_idx < len(lines) else ''
                        
                        if next_line.startswith('Feature:'):
                            feature_tags = tags
                        elif next_line.startswith('Scenario:') or next_line.startswith('Scenario Outline:'):
                            current_scenario_tags = tags
                    
                    # Capturar Scenario
                    elif stripped.startswith('Scenario:'):
                        # Guardar escenario anterior si existe
                        if current_scenario_name:
                            executions = max(1, example_count)  # Al menos 1 ejecución
                            all_tags = list(set(feature_tags + current_scenario_tags))
                            scenarios_data.append({
                                'file': feature_file,
                                'feature_tags': feature_tags,
                                'scenario_name': current_scenario_name,
                                'scenario_tags': current_scenario_tags,
                                'executions': executions,
                                'line': current_scenario_line,
                                'all_tags': all_tags
                            })
                        
                        # Iniciar nuevo escenario
                        current_scenario_name = stripped.replace('Scenario:', '').strip()
                        current_scenario_line = idx + 1
                        current_scenario_tags = []
                        is_scenario_outline = False
                        example_count = 0
                        in_examples = False
                    
                    # Capturar Scenario Outline
                    elif stripped.startswith('Scenario Outline:'):
                        # Guardar escenario anterior si existe
                        if current_scenario_name:
                            executions = max(1, example_count)
                            all_tags = list(set(feature_tags + current_scenario_tags))
                            scenarios_data.append({
                                'file': feature_file,
                                'feature_tags': feature_tags,
                                'scenario_name': current_scenario_name,
                                'scenario_tags': current_scenario_tags,
                                'executions': executions,
                                'line': current_scenario_line,
                                'all_tags': all_tags
                            })
                        
                        # Iniciar nuevo Scenario Outline
                        current_scenario_name = stripped.replace('Scenario Outline:', '').strip()
                        current_scenario_line = idx + 1
                        current_scenario_tags = []
                        is_scenario_outline = True
                        example_count = 0
                        in_examples = False
                    
                    # Contar Examples (solo para Scenario Outline)
                    elif is_scenario_outline and stripped.startswith('Examples:'):
                        in_examples = True
                        example_count += 1
                    
                    # Detectar fin de Examples (línea vacía o nueva sección)
                    elif in_examples and (not stripped or stripped.startswith(('Scenario', '@', 'Feature'))):
                        in_examples = False
                
                # Guardar último escenario
                if current_scenario_name:
                    executions = max(1, example_count)
                    all_tags = list(set(feature_tags + current_scenario_tags))
                    scenarios_data.append({
                        'file': feature_file,
                        'feature_tags': feature_tags,
                        'scenario_name': current_scenario_name,
                        'scenario_tags': current_scenario_tags,
                        'executions': executions,
                        'line': current_scenario_line,
                        'all_tags': all_tags
                    })
            
            except Exception as e:
                print(f"[WARNING] Error procesando {feature_file}: {e}")
                continue
        
        return scenarios_data
    
    @staticmethod
    def get_features_selection() -> List[str]:
        """
        Divide escenarios entre shards para paralelización en CI.
        Si hay variables de CI, reparte escenarios. Si es local, devuelve todo.
        
        Variables de entorno esperadas:
        - SHARD_INDEX: Índice del shard actual (1-based)
        - TOTAL_SHARDS: Número total de shards
        
        Retorna:
        - Modo LOCAL: ['features']
        - Modo CI: ['features', '--tags', 'PROD-91 or PROD-92 or ...']
        
        Returns:
            List[str]: Argumentos para pasar a behave
        """
        shard_index = os.getenv('SHARD_INDEX')
        total_shards = os.getenv('TOTAL_SHARDS')

        # Modo LOCAL - ejecutar todos los features
        if not shard_index or not total_shards:
            return ['features']

        # Modo CI - dividir escenarios entre shards
        try:
            shard_index = int(shard_index)
            total_shards = int(total_shards)
        except ValueError:
            print("[ERROR] SHARD_INDEX y TOTAL_SHARDS deben ser números enteros")
            return ['features']
        
        # Validar rango
        if shard_index < 1 or shard_index > total_shards:
            print(f"[ERROR] SHARD_INDEX ({shard_index}) debe estar entre 1 y {total_shards}")
            return ['features']
        
        # Obtener información de escenarios
        scenarios_data = ParallelizationManager.get_scenario_tags()
        
        if not scenarios_data:
            print("[WARNING] No se encontraron escenarios con tags")
            return ['features']
        
        # Calcular total de ejecuciones (no solo tags)
        total_executions = sum(s['executions'] for s in scenarios_data)
        
        if total_executions == 0:
            print("[WARNING] No hay ejecuciones para distribuir")
            return ['features']
        
        # Distribuir escenarios entre shards basado en ejecuciones
        executions_per_shard = math.ceil(total_executions / total_shards)
        
        shard_scenarios = []
        current_executions = 0
        shard_start = (shard_index - 1) * executions_per_shard
        shard_end = shard_index * executions_per_shard
        
        for scenario in scenarios_data:
            # Verificar si este escenario debe incluirse en este shard
            scenario_start = current_executions
            scenario_end = current_executions + scenario['executions']
            
            # Si el escenario se superpone con el rango del shard, incluirlo
            if scenario_end > shard_start and scenario_start < shard_end:
                shard_scenarios.append(scenario)
            
            current_executions += scenario['executions']
        
        # Extraer tags únicos para este shard
        shard_tags = []
        for scenario in shard_scenarios:
            shard_tags.extend(scenario['scenario_tags'])
        shard_tags = sorted(list(set(shard_tags)))
        
        # Calcular ejecuciones en este shard
        shard_executions = sum(s['executions'] for s in shard_scenarios)
        
        # Logging detallado
        print(f"[SHARD] {shard_index}/{total_shards} | Escenarios: {len(shard_scenarios)}/{len(scenarios_data)} | Ejecuciones: {shard_executions}/{total_executions}")
        if shard_tags:
            print(f"[SHARD] Tags: {', '.join(shard_tags)}")
        
        # Retornar features con tags OR
        if shard_tags:
            tags_filter = ' or '.join(shard_tags)
            return ['features', '--tags', tags_filter]
        else:
            print(f"[WARNING] Shard {shard_index} no tiene tags asignados")
            return []
    
    @staticmethod
    def get_scenario_count() -> int:
        """
        Obtiene el número total de escenarios (considerando Examples).
        
        Returns:
            int: Número total de ejecuciones
        """
        scenarios_data = ParallelizationManager.get_scenario_tags()
        return sum(s['executions'] for s in scenarios_data)
    
    @staticmethod
    def get_scenario_info() -> Dict[str, Any]:
        """
        Obtiene información detallada sobre los escenarios.
        
        Returns:
            Dict: Información agregada de escenarios
        """
        scenarios_data = ParallelizationManager.get_scenario_tags()
        
        total_scenarios = len(scenarios_data)
        total_executions = sum(s['executions'] for s in scenarios_data)
        
        # Contar tags únicos
        all_tags = set()
        for scenario in scenarios_data:
            all_tags.update(scenario['scenario_tags'])
        
        return {
            'total_scenarios': total_scenarios,
            'total_executions': total_executions,
            'unique_tags': sorted(list(all_tags)),
            'scenarios': scenarios_data
        }
