#!/usr/bin/env python3
"""
Data Snapshot Manager
Captura información relevante de steps sin UI (API, validación semántica, etc.)
para incluir en reportes en lugar de screenshots
"""
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional


class DataSnapshotManager:
    """Gestor de snapshots de datos para pruebas sin UI"""
    
    def __init__(self, output_dir: str = "reports/data_snapshots"):
        """
        Inicializa el gestor de snapshots
        
        Args:
            output_dir: Directorio donde guardar los snapshots
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.current_scenario = None
        self.step_counter = 0
    
    def set_scenario(self, scenario_name: str):
        """Establece el escenario actual"""
        self.current_scenario = scenario_name.replace(' ', '_').replace('"', '').replace("'", '')
        self.step_counter = 0
    
    def capture_semantic_validation(
        self,
        step_name: str,
        text1: str,
        text2: str,
        similarity: float,
        threshold: float,
        model: str,
        passed: bool
    ) -> str:
        """
        Captura información de validación semántica
        
        Returns:
            Ruta del archivo JSON generado
        """
        self.step_counter += 1
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        data = {
            "type": "semantic_validation",
            "timestamp": timestamp,
            "step": step_name,
            "data": {
                "text1": text1,
                "text2": text2,
                "similarity_score": round(similarity, 4),
                "threshold": threshold,
                "model": model,
                "passed": passed,
                "difference": round(similarity - threshold, 4)
            }
        }
        
        filename = f"step_{self.step_counter:03d}_semantic_{timestamp}.json"
        filepath = self.output_dir / self.current_scenario / filename
        filepath.parent.mkdir(parents=True, exist_ok=True)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        # También crear un HTML visual
        html_path = self._create_html_snapshot(data, filepath.with_suffix('.html'))
        
        print(f"📊 Data snapshot capturado: {filepath}")
        return str(filepath)
    
    def capture_gemini_evaluation(
        self,
        step_name: str,
        sut_response: str,
        context_name: str,
        score: float,
        threshold: float,
        evaluation_details: Optional[Dict[str, Any]] = None,
        passed: bool = True
    ) -> str:
        """
        Captura información de evaluación con Gemini
        
        Returns:
            Ruta del archivo JSON generado
        """
        self.step_counter += 1
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        data = {
            "type": "gemini_evaluation",
            "timestamp": timestamp,
            "step": step_name,
            "data": {
                "sut_response": sut_response,
                "context_name": context_name,
                "evaluation_score": round(score, 4),
                "threshold": threshold,
                "passed": passed,
                "difference": round(score - threshold, 4),
                "details": evaluation_details or {}
            }
        }
        
        filename = f"step_{self.step_counter:03d}_gemini_{timestamp}.json"
        filepath = self.output_dir / self.current_scenario / filename
        filepath.parent.mkdir(parents=True, exist_ok=True)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        # También crear un HTML visual
        html_path = self._create_html_snapshot(data, filepath.with_suffix('.html'))
        
        print(f"📊 Data snapshot capturado: {filepath}")
        return str(filepath)
    
    def capture_api_request(
        self,
        step_name: str,
        method: str,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        body: Optional[Any] = None,
        response_status: Optional[int] = None,
        response_body: Optional[Any] = None,
        response_time: Optional[float] = None
    ) -> str:
        """
        Captura información de request/response de API
        
        Returns:
            Ruta del archivo JSON generado
        """
        self.step_counter += 1
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        data = {
            "type": "api_request",
            "timestamp": timestamp,
            "step": step_name,
            "data": {
                "request": {
                    "method": method,
                    "url": url,
                    "headers": headers or {},
                    "body": body
                },
                "response": {
                    "status_code": response_status,
                    "body": response_body,
                    "time_ms": round(response_time * 1000, 2) if response_time else None
                }
            }
        }
        
        filename = f"step_{self.step_counter:03d}_api_{timestamp}.json"
        filepath = self.output_dir / self.current_scenario / filename
        filepath.parent.mkdir(parents=True, exist_ok=True)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        # También crear un HTML visual
        html_path = self._create_html_snapshot(data, filepath.with_suffix('.html'))
        
        print(f"📊 Data snapshot capturado: {filepath}")
        return str(filepath)
    
    def capture_nlp_analysis(
        self,
        step_name: str,
        text: str,
        analysis_type: str,
        result: Any
    ) -> str:
        """
        Captura información de análisis NLP
        
        Returns:
            Ruta del archivo JSON generado
        """
        self.step_counter += 1
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        data = {
            "type": "nlp_analysis",
            "timestamp": timestamp,
            "step": step_name,
            "data": {
                "text": text,
                "analysis_type": analysis_type,
                "result": result
            }
        }
        
        filename = f"step_{self.step_counter:03d}_nlp_{timestamp}.json"
        filepath = self.output_dir / self.current_scenario / filename
        filepath.parent.mkdir(parents=True, exist_ok=True)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        # También crear un HTML visual
        html_path = self._create_html_snapshot(data, filepath.with_suffix('.html'))
        
        print(f"📊 Data snapshot capturado: {filepath}")
        return str(filepath)
    
    def _create_html_snapshot(self, data: Dict[str, Any], output_path: Path) -> str:
        """Crea una visualización HTML del snapshot"""
        
        html_content = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Snapshot - {data['type']}</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            overflow: hidden;
        }}
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }}
        .header h1 {{
            margin: 0;
            font-size: 28px;
            font-weight: 600;
        }}
        .header .timestamp {{
            margin-top: 10px;
            opacity: 0.9;
            font-size: 14px;
        }}
        .content {{
            padding: 30px;
        }}
        .step-name {{
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 25px;
            border-left: 4px solid #667eea;
        }}
        .step-name strong {{
            color: #667eea;
        }}
        .data-section {{
            margin-bottom: 25px;
        }}
        .data-section h3 {{
            color: #333;
            margin-bottom: 15px;
            font-size: 18px;
            border-bottom: 2px solid #667eea;
            padding-bottom: 8px;
        }}
        .data-item {{
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 10px;
        }}
        .data-item label {{
            font-weight: 600;
            color: #555;
            display: block;
            margin-bottom: 5px;
        }}
        .data-item .value {{
            color: #333;
            word-wrap: break-word;
        }}
        .score {{
            display: inline-block;
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 18px;
        }}
        .score.passed {{
            background: #d4edda;
            color: #155724;
        }}
        .score.failed {{
            background: #f8d7da;
            color: #721c24;
        }}
        .json-view {{
            background: #2d2d2d;
            color: #f8f8f2;
            padding: 20px;
            border-radius: 8px;
            overflow-x: auto;
            font-family: 'Courier New', monospace;
            font-size: 13px;
            line-height: 1.6;
        }}
        .badge {{
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
        }}
        .badge.semantic {{ background: #e3f2fd; color: #1976d2; }}
        .badge.gemini {{ background: #f3e5f5; color: #7b1fa2; }}
        .badge.api {{ background: #e8f5e9; color: #388e3c; }}
        .badge.nlp {{ background: #fff3e0; color: #f57c00; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📊 Data Snapshot</h1>
            <div class="timestamp">{data['timestamp']}</div>
        </div>
        <div class="content">
            <div class="step-name">
                <strong>Step:</strong> {data['step']}
            </div>
            
            <span class="badge {data['type'].split('_')[0]}">{data['type'].replace('_', ' ').title()}</span>
            
            {self._generate_type_specific_html(data)}
            
            <div class="data-section">
                <h3>📄 Raw Data (JSON)</h3>
                <div class="json-view">
                    <pre>{json.dumps(data, indent=2, ensure_ascii=False)}</pre>
                </div>
            </div>
        </div>
    </div>
</body>
</html>"""
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        return str(output_path)
    
    def _generate_type_specific_html(self, data: Dict[str, Any]) -> str:
        """Genera HTML específico según el tipo de snapshot"""
        
        if data['type'] == 'semantic_validation':
            d = data['data']
            passed_class = 'passed' if d['passed'] else 'failed'
            passed_text = '✅ PASSED' if d['passed'] else '❌ FAILED'
            
            return f"""
            <div class="data-section">
                <h3>🧠 Validación Semántica</h3>
                <div class="data-item">
                    <label>Texto 1:</label>
                    <div class="value">"{d['text1']}"</div>
                </div>
                <div class="data-item">
                    <label>Texto 2:</label>
                    <div class="value">"{d['text2']}"</div>
                </div>
                <div class="data-item">
                    <label>Similitud Calculada:</label>
                    <div class="value"><span class="score {passed_class}">{d['similarity_score']}</span></div>
                </div>
                <div class="data-item">
                    <label>Umbral Requerido:</label>
                    <div class="value">{d['threshold']}</div>
                </div>
                <div class="data-item">
                    <label>Modelo Usado:</label>
                    <div class="value">{d['model']}</div>
                </div>
                <div class="data-item">
                    <label>Resultado:</label>
                    <div class="value"><span class="score {passed_class}">{passed_text}</span></div>
                </div>
            </div>
            """
        
        elif data['type'] == 'gemini_evaluation':
            d = data['data']
            passed_class = 'passed' if d['passed'] else 'failed'
            passed_text = '✅ PASSED' if d['passed'] else '❌ FAILED'
            
            return f"""
            <div class="data-section">
                <h3>🤖 Evaluación con Gemini</h3>
                <div class="data-item">
                    <label>Respuesta del SUT:</label>
                    <div class="value">"{d['sut_response']}"</div>
                </div>
                <div class="data-item">
                    <label>Contexto de Negocio:</label>
                    <div class="value">{d['context_name']}</div>
                </div>
                <div class="data-item">
                    <label>Score de Evaluación:</label>
                    <div class="value"><span class="score {passed_class}">{d['evaluation_score']}</span></div>
                </div>
                <div class="data-item">
                    <label>Umbral Requerido:</label>
                    <div class="value">{d['threshold']}</div>
                </div>
                <div class="data-item">
                    <label>Resultado:</label>
                    <div class="value"><span class="score {passed_class}">{passed_text}</span></div>
                </div>
            </div>
            """
        
        elif data['type'] == 'api_request':
            d = data['data']
            status_class = 'passed' if 200 <= (d['response']['status_code'] or 0) < 300 else 'failed'
            
            return f"""
            <div class="data-section">
                <h3>🔌 API Request</h3>
                <div class="data-item">
                    <label>Method:</label>
                    <div class="value">{d['request']['method']}</div>
                </div>
                <div class="data-item">
                    <label>URL:</label>
                    <div class="value">{d['request']['url']}</div>
                </div>
                <div class="data-item">
                    <label>Status Code:</label>
                    <div class="value"><span class="score {status_class}">{d['response']['status_code']}</span></div>
                </div>
                <div class="data-item">
                    <label>Response Time:</label>
                    <div class="value">{d['response']['time_ms']} ms</div>
                </div>
            </div>
            """
        
        elif data['type'] == 'nlp_analysis':
            d = data['data']
            
            return f"""
            <div class="data-section">
                <h3>📝 Análisis NLP</h3>
                <div class="data-item">
                    <label>Texto Analizado:</label>
                    <div class="value">"{d['text']}"</div>
                </div>
                <div class="data-item">
                    <label>Tipo de Análisis:</label>
                    <div class="value">{d['analysis_type']}</div>
                </div>
                <div class="data-item">
                    <label>Resultado:</label>
                    <div class="value">{json.dumps(d['result'], indent=2, ensure_ascii=False)}</div>
                </div>
            </div>
            """
        
        return ""
