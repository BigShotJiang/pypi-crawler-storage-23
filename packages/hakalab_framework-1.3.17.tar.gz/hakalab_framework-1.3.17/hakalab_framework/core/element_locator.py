import os
import json
import re
from typing import Dict, Any, Optional
from dotenv import load_dotenv

load_dotenv()

class ElementLocator:
    """Clase para manejar la localización de elementos desde archivos JSON con soporte de placeholders dinámicos"""
    
    def __init__(self):
        self.json_poms_path = os.getenv('JSON_POMS_PATH', 'json_poms')
        self._cache = {}
        # Patrón para placeholders regulares (con comillas)
        self.placeholder_pattern = re.compile(r'<valor>|<value>|<placeholder>|\{valor\}|\{value\}|\{placeholder\}')
        # Patrón para placeholders de enteros (sin comillas)
        self.int_placeholder_pattern = re.compile(r'<valor_int>|<value_int>|<int>|\{valor_int\}|\{value_int\}|\{int\}')
    
    def get_locator(self, identifier: str, dynamic_value: Optional[str] = None) -> str:
        """
        Obtiene el localizador de un elemento desde los archivos JSON
        Soporta placeholders dinámicos que se reemplazan en tiempo de ejecución
        
        Args:
            identifier: Identificador en formato $.ARCHIVO.elemento o $.ARCHIVO.elemento=valor_dinamico
            dynamic_value: Valor dinámico para reemplazar placeholders (opcional)
            
        Returns:
            str: El localizador del elemento con placeholders reemplazados si aplica
            
        Raises:
            ValueError: Si el identificador no tiene el formato correcto
            FileNotFoundError: Si el archivo JSON no existe
            KeyError: Si el elemento no existe en el archivo
            
        Examples:
            # Uso básico
            locator = element_locator.get_locator("$.LOGIN.username_field")
            
            # Con placeholder dinámico en el identificador
            locator = element_locator.get_locator("$.SEARCH.result_by_text=Hola")
            
            # Con parámetro dinámico separado
            locator = element_locator.get_locator("$.SEARCH.result_by_text", "Hola")
        """
        # Extraer valor dinámico del identificador si está presente
        if '=' in identifier and not identifier.startswith('$.'):
            raise ValueError(f"Formato inválido. El = debe venir después de $.ARCHIVO.elemento - Recibido: {identifier}")
        
        extracted_dynamic_value = None
        if '=' in identifier:
            identifier, extracted_dynamic_value = identifier.rsplit('=', 1)
            dynamic_value = extracted_dynamic_value
        
        if not identifier.startswith('$.'):
            raise ValueError(f"El identificador debe empezar con '$.' - Recibido: {identifier}")
        
        # Parsear el identificador: $.ARCHIVO.elemento
        parts = identifier[2:].split('.', 1)
        if len(parts) != 2:
            raise ValueError(f"Formato de identificador inválido. Esperado: $.ARCHIVO.elemento - Recibido: {identifier}")
        
        file_name, element_name = parts
        
        # Cargar el archivo JSON si no está en caché
        if file_name not in self._cache:
            self._load_json_file(file_name)
        
        # Obtener el localizador
        if element_name not in self._cache[file_name]:
            raise KeyError(f"Elemento '{element_name}' no encontrado en el archivo '{file_name}.json'")
        
        locator = self._cache[file_name][element_name]
        
        # Reemplazar placeholders si hay valor dinámico
        if dynamic_value is not None:
            locator = self._replace_placeholders(locator, dynamic_value)
        
        return locator
    
    def _replace_placeholders(self, locator: str, value: str) -> str:
        """
        Reemplaza todos los placeholders en el localizador con el valor proporcionado
        
        Soporta múltiples formatos de placeholder:
        
        Placeholders con comillas (para strings):
        - <valor>
        - <value>
        - <placeholder>
        - {valor}
        - {value}
        - {placeholder}
        
        Placeholders sin comillas (para enteros/índices):
        - <valor_int>
        - <value_int>
        - <int>
        - {valor_int}
        - {value_int}
        - {int}
        
        Args:
            locator: El localizador con placeholders
            value: El valor para reemplazar los placeholders
            
        Returns:
            str: El localizador con placeholders reemplazados
            
        Examples:
            # Con <valor> (agrega comillas)
            "(//input[@type='checkbox'])[<valor>]" + "2" → "(//input[@type='checkbox'])['2']"
            
            # Con <valor_int> (sin comillas)
            "(//input[@type='checkbox'])[<valor_int>]" + "2" → "(//input[@type='checkbox'])[2]"
        """
        # Primero reemplazar placeholders de enteros (sin comillas)
        if self.int_placeholder_pattern.search(locator):
            result = self.int_placeholder_pattern.sub(value, locator)
        else:
            # Reemplazar placeholders regulares (con comillas escapadas)
            escaped_value = self._escape_xpath_value(value)
            result = self.placeholder_pattern.sub(escaped_value, locator)
        
        return result
    
    def _escape_xpath_value(self, value: str) -> str:
        """
        Escapa caracteres especiales en valores para XPath
        
        Args:
            value: El valor a escapar
            
        Returns:
            str: El valor escapado para usar en XPath
        """
        # Si el valor contiene comillas simples y dobles, usar concat()
        if "'" in value and '"' in value:
            # Dividir por comillas simples y usar concat
            parts = value.split("'")
            xpath_parts = [f"'{part}'" if part else "\"'\"" for part in parts]
            return "concat(" + ", \"'\", ".join(xpath_parts) + ")"
        
        # Si contiene comillas simples, usar comillas dobles
        if "'" in value:
            return f'"{value}"'
        
        # Si contiene comillas dobles, usar comillas simples
        if '"' in value:
            return f"'{value}'"
        
        # Si no contiene comillas, usar comillas simples por defecto
        return f"'{value}'"
    
    def _load_json_file(self, file_name: str):
        """Carga un archivo JSON en el caché"""
        file_path = os.path.join(self.json_poms_path, f"{file_name}.json")
        
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Archivo JSON no encontrado: {file_path}")
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                self._cache[file_name] = json.load(f)
        except json.JSONDecodeError as e:
            raise ValueError(f"Error al parsear el archivo JSON {file_path}: {e}")
    
    def get_element(self, page, identifier: str, dynamic_value: Optional[str] = None):
        """
        Método simplificado: Obtiene directamente el elemento de Playwright desde JSON
        Soporta placeholders dinámicos
        
        Args:
            page: Página de Playwright (context.page)
            identifier: Identificador en formato $.ARCHIVO.elemento o $.ARCHIVO.elemento=valor
            dynamic_value: Valor dinámico para reemplazar placeholders (opcional)
            
        Returns:
            Locator: Elemento de Playwright listo para usar
            
        Examples:
            # Uso básico
            element = context.element_locator.get_element(context.page, "$.LOGIN.username_field")
            element.fill("admin")
            
            # Con placeholder dinámico
            element = context.element_locator.get_element(context.page, "$.SEARCH.result_by_text=Hola")
            element.click()
            
            # Con parámetro separado
            element = context.element_locator.get_element(context.page, "$.SEARCH.result_by_text", "Hola")
            element.click()
        """
        locator = self.get_locator(identifier, dynamic_value)
        return page.locator(locator)
    
    def find(self, page, identifier: str, dynamic_value: Optional[str] = None):
        """
        Alias más corto para get_element()
        Soporta placeholders dinámicos
        
        Args:
            page: Página de Playwright (context.page)
            identifier: Identificador en formato $.ARCHIVO.elemento o $.ARCHIVO.elemento=valor
            dynamic_value: Valor dinámico para reemplazar placeholders (opcional)
            
        Returns:
            Locator: Elemento de Playwright listo para usar
            
        Examples:
            element = context.element_locator.find(context.page, "$.LOGIN.login_button")
            element.click()
            
            element = context.element_locator.find(context.page, "$.SEARCH.result_by_text=Adios")
            element.click()
        """
        return self.get_element(page, identifier, dynamic_value)
    
    def reload_cache(self):
        """Limpia y recarga el caché de archivos JSON"""
        self._cache.clear()