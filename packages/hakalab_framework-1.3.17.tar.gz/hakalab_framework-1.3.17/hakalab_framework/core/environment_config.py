#!/usr/bin/env python3
"""
Configurador de environment MINIMO para Playwright + Behave
Solo lo ultra esencial
"""
import os
import logging
import warnings
from pathlib import Path
from typing import Optional, Dict, Any
from dotenv import load_dotenv
from playwright.sync_api import sync_playwright, Browser, BrowserContext, Page

# Configurar warnings según variables de entorno
if os.getenv('HIDE_TRANSFORMERS_WARNINGS', 'false').lower() == 'true':
    # Ocultar warnings de transformers y sentence-transformers
    os.environ['TRANSFORMERS_VERBOSITY'] = 'error'
    os.environ['TOKENIZERS_PARALLELISM'] = 'false'
    warnings.filterwarnings('ignore', category=FutureWarning, module='transformers')
    warnings.filterwarnings('ignore', category=UserWarning, module='transformers')

if os.getenv('HIDE_HF_WARNINGS', 'false').lower() == 'true':
    # Ocultar warnings de Hugging Face Hub
    os.environ['HF_HUB_DISABLE_SYMLINKS_WARNING'] = '1'
    warnings.filterwarnings('ignore', message='.*HF Hub.*')

if os.getenv('HIDE_BEHAVE_WARNINGS', 'false').lower() == 'true':
    # Ocultar warnings de Behave context masking
    warnings.filterwarnings('ignore', category=UserWarning, module='behave')
    from behave.runner import Context
    if hasattr(Context, '_emit_warning'):
        Context._emit_warning = lambda *args, **kwargs: None

# Imports mínimos necesarios para que funcionen los steps
from .element_locator import ElementLocator
from .variable_manager import VariableManager
# from .allure_config import setup_allure_environment, validate_allure_setup


class FrameworkConfig:
    """Configurador MINIMO del framework"""
    
    def __init__(self, env_file: Optional[str] = None):
        """Inicializa la configuración MINIMA del framework"""
        # Cargar variables de entorno básicas
        if env_file:
            # Si se especifica un archivo, usarlo
            load_dotenv(env_file)
        else:
            # Buscar .env en la raíz del proyecto del usuario (no en el framework)
            # Empezar desde el directorio actual y subir hasta encontrar .env
            current_dir = Path.cwd()
            env_found = False
            
            # Buscar .env en el directorio actual y sus padres
            for parent in [current_dir] + list(current_dir.parents):
                env_path = parent / '.env'
                if env_path.exists():
                    load_dotenv(env_path)
                    env_found = True
                    break
            
            # Si no se encontró .env, solo cargar variables de entorno del sistema
            if not env_found:
                # No hacer nada, solo usar variables de entorno del sistema
                pass
        
        self.config = self._load_config()
        self.playwright = None
        self.browser = None
    
    def _load_config(self) -> Dict[str, Any]:
        """Carga la configuración desde variables de entorno"""
        # Debug: Mostrar valor de BROWSER antes de procesarlo
        browser_value = os.getenv('BROWSER', 'chromium')
        headless_value = os.getenv('HEADLESS', 'false')
        print(f"🔍 DEBUG: Variable BROWSER leída = '{browser_value}'")
        print(f"🔍 DEBUG: Variable HEADLESS leída = '{headless_value}'")
        
        return {
            # Configuración de navegador
            'browser': browser_value.lower(),
            'headless': headless_value.lower() == 'true',
            'timeout': int(os.getenv('TIMEOUT', '30000')),
            'viewport_width': int(os.getenv('VIEWPORT_WIDTH', '1920')),
            'viewport_height': int(os.getenv('VIEWPORT_HEIGHT', '1080')),
            'device_scale_factor': float(os.getenv('DEVICE_SCALE_FACTOR', '1')),
            'slow_mo': int(os.getenv('SLOW_MO', '0')),
            
            # Configuración avanzada del navegador
            'browser_args': os.getenv('BROWSER_ARGS', '').split(',') if os.getenv('BROWSER_ARGS') else [],
            'browser_config_preset': os.getenv('BROWSER_CONFIG_PRESET', ''),
            'browser_config_file': os.getenv('BROWSER_CONFIG_FILE', ''),
            'browser_memory_limit': int(os.getenv('BROWSER_MEMORY_LIMIT', '4096')),
            'browser_proxy': os.getenv('BROWSER_PROXY', ''),
            'browser_downloads_dir': os.getenv('BROWSER_DOWNLOADS_DIR', 'downloads'),
            'browser_download_behavior': os.getenv('BROWSER_DOWNLOAD_BEHAVIOR', 'auto'),
            
            # Configuraciones específicas de Chrome
            'chrome_disable_security': os.getenv('CHROME_DISABLE_SECURITY', 'false').lower() == 'true',
            'chrome_enable_logging': os.getenv('CHROME_ENABLE_LOGGING', 'false').lower() == 'true',
            'chrome_log_level': os.getenv('CHROME_LOG_LEVEL', 'INFO'),
            'chrome_disable_extensions': os.getenv('CHROME_DISABLE_EXTENSIONS', 'true').lower() == 'true',
            'chrome_disable_plugins': os.getenv('CHROME_DISABLE_PLUGINS', 'true').lower() == 'true',
            'chrome_disable_images': os.getenv('CHROME_DISABLE_IMAGES', 'false').lower() == 'true',
            'chrome_disable_javascript': os.getenv('CHROME_DISABLE_JAVASCRIPT', 'false').lower() == 'true',
            
            # Configuraciones específicas de Firefox
            'firefox_profile_path': os.getenv('FIREFOX_PROFILE_PATH', ''),
            'firefox_disable_addons': os.getenv('FIREFOX_DISABLE_ADDONS', 'true').lower() == 'true',
            'firefox_private_mode': os.getenv('FIREFOX_PRIVATE_MODE', 'false').lower() == 'true',
            
            # Configuraciones específicas de WebKit
            'webkit_disable_features': os.getenv('WEBKIT_DISABLE_FEATURES', '').split(',') if os.getenv('WEBKIT_DISABLE_FEATURES') else [],
            
            # Configuración de video
            'record_video': os.getenv('RECORD_VIDEO', 'false').lower() == 'true',
            'video_dir': os.getenv('VIDEO_DIR', 'videos'),
            'video_size': os.getenv('VIDEO_SIZE', '1280x720'),
            'video_mode': os.getenv('VIDEO_MODE', 'retain-on-failure'),  # on, off, retain-on-failure
            'cleanup_old_videos': os.getenv('CLEANUP_OLD_VIDEOS', 'true').lower() == 'true',
            'video_max_age_hours': int(os.getenv('VIDEO_MAX_AGE_HOURS', '168')),  # 7 días
            
            # URLs y rutas
            'base_url': os.getenv('BASE_URL', ''),  # URL por defecto (vacía si no se especifica)
            'json_poms_path': os.getenv('JSON_POMS_PATH', 'json_poms'),
            
            # Reportes y archivos
            'allure_results_dir': os.getenv('ALLURE_RESULTS_DIR', 'allure-results'),
            'html_reports_dir': os.getenv('HTML_REPORTS_DIR', 'html-reports'),
            'screenshots_dir': os.getenv('SCREENSHOTS_DIR', 'screenshots'),
            'downloads_dir': os.getenv('DOWNLOADS_DIR', 'downloads'),
            
            # Configuración de logging
            'log_level': os.getenv('LOG_LEVEL', 'INFO'),
            'log_file': os.getenv('LOG_FILE', ''),
            
            # Configuración de red
            'ignore_https_errors': os.getenv('IGNORE_HTTPS_ERRORS', 'false').lower() == 'true',
            'user_agent': os.getenv('BROWSER_USER_AGENT', '') or os.getenv('USER_AGENT', ''),
            
            # Configuración de pruebas
            'auto_screenshot_on_failure': os.getenv('AUTO_SCREENSHOT_ON_FAILURE', 'true').lower() == 'true',
            'auto_wait_for_load': os.getenv('AUTO_WAIT_FOR_LOAD', 'true').lower() == 'true',
            'retry_failed_steps': int(os.getenv('RETRY_FAILED_STEPS', '0')),
            
            # Configuración de reintentos de escenarios
            'retry_failed_scenarios': os.getenv('RETRY_FAILED_SCENARIOS', 'false').lower() == 'true',
            'max_scenario_retries': int(os.getenv('MAX_SCENARIO_RETRIES', '1')),
            
            # Configuración de modo stealth (anti-detección)
            'stealth_mode': os.getenv('STEALTH_MODE', 'false').lower() == 'true',
            
            # Configuración de paralelismo
            'parallel_workers': int(os.getenv('PARALLEL_WORKERS', '4')),
            'max_browser_instances': int(os.getenv('MAX_BROWSER_INSTANCES', '10')),
            'browser_pool_size': int(os.getenv('BROWSER_POOL_SIZE', '5')),
            'worker_timeout': int(os.getenv('WORKER_TIMEOUT', '300')),
            
            # Variables de datos de prueba (las más comunes)
            'test_email': os.getenv('TEST_EMAIL', ''),
            'test_password': os.getenv('TEST_PASSWORD', ''),
            'test_user_name': os.getenv('TEST_USER_NAME', ''),
            'api_base_url': os.getenv('API_BASE_URL', ''),
        }
    
    def setup_playwright(self) -> Browser:
        """Configura e inicializa Playwright con soporte para configuración avanzada"""
        self.playwright = sync_playwright().start()
        
        browser_options = {
            'headless': self.config['headless'],
            'slow_mo': self.config['slow_mo'],
        }
        
        if self.config['downloads_dir']:
            browser_options['downloads_path'] = self.config['downloads_dir']
        
        # Construir argumentos del navegador
        browser_args = []
        
        # Añadir argumentos desde variables de entorno
        if self.config['browser_args']:
            browser_args.extend([arg.strip() for arg in self.config['browser_args'] if arg.strip()])
        
        # Aplicar configuración predefinida si está especificada
        if self.config['browser_config_preset']:
            preset_args = self._get_preset_config(self.config['browser_config_preset'])
            browser_args.extend(preset_args)
        
        # Cargar configuración desde archivo si está especificada
        if self.config['browser_config_file']:
            file_args = self._load_config_file(self.config['browser_config_file'])
            browser_args.extend(file_args)
        
        # Aplicar configuraciones específicas del navegador
        browser_args.extend(self._get_browser_specific_args())
        
        # Configuraciones adicionales para paralelismo en modo headless
        if self.config['headless']:
            browser_args.extend([
                '--no-sandbox',
                '--disable-dev-shm-usage',
                '--disable-gpu',
                '--disable-web-security',
                '--disable-features=VizDisplayCompositor',
                f'--max_old_space_size={self.config["browser_memory_limit"]}'
            ])
        
        # Configurar proxy si está especificado
        if self.config['browser_proxy']:
            browser_args.append(f'--proxy-server={self.config["browser_proxy"]}')
        
        # Añadir argumentos al navegador
        if browser_args:
            browser_options['args'] = browser_args
        
        # Debug: Mostrar qué navegador se está configurando
        print(f"🔧 Configurando navegador: {self.config['browser']}")
        
        # Seleccionar navegador
        if self.config['browser'] == 'firefox':
            self.browser = self.playwright.firefox.launch(**browser_options)
        elif self.config['browser'] == 'webkit':
            self.browser = self.playwright.webkit.launch(**browser_options)
        elif self.config['browser'] == 'chrome':
            # Usar Chrome instalado en el sistema
            try:
                browser_options['channel'] = 'chrome'
                self.browser = self.playwright.chromium.launch(**browser_options)
                print("🌐 Usando Google Chrome instalado en el sistema")
            except Exception as e:
                print(f"⚠️ No se pudo iniciar Chrome instalado: {e}")
                print("🔄 Usando Chromium como alternativa")
                browser_options.pop('channel', None)
                self.browser = self.playwright.chromium.launch(**browser_options)
        else:  # chromium por defecto
            self.browser = self.playwright.chromium.launch(**browser_options)
            if self.config['browser'] == 'chromium':
                print("🌐 Usando Chromium")
        
        return self.browser
    
    def _get_preset_config(self, preset: str) -> list:
        """Obtiene argumentos de configuración predefinida"""
        presets = {
            'performance': [
                '--no-sandbox',
                '--disable-dev-shm-usage',
                '--disable-gpu',
                '--disable-software-rasterizer',
                '--disable-background-timer-throttling',
                '--disable-backgrounding-occluded-windows',
                '--disable-renderer-backgrounding',
                '--disable-field-trial-config',
                '--disable-back-forward-cache',
                '--disable-ipc-flooding-protection',
                '--aggressive-cache-discard',
                '--memory-pressure-off'
            ],
            'mobile': [
                '--use-mobile-user-agent',
                '--touch-events=enabled',
                '--enable-viewport-meta',
                '--disable-desktop-notifications',
                '--force-device-scale-factor=2'
            ],
            'cicd': [
                '--no-sandbox',
                '--disable-dev-shm-usage',
                '--disable-gpu',
                '--disable-software-rasterizer',
                '--disable-background-timer-throttling',
                '--disable-backgrounding-occluded-windows',
                '--disable-renderer-backgrounding',
                '--disable-extensions',
                '--disable-plugins',
                '--disable-default-apps',
                '--disable-sync',
                '--metrics-recording-only',
                '--no-first-run',
                '--safebrowsing-disable-auto-update',
                '--disable-background-networking'
            ],
            'security_disabled': [
                '--disable-web-security',
                '--disable-features=VizDisplayCompositor',
                '--disable-ipc-flooding-protection',
                '--disable-xss-auditor',
                '--ignore-certificate-errors',
                '--ignore-ssl-errors',
                '--ignore-certificate-errors-spki-list',
                '--allow-running-insecure-content'
            ]
        }
        
        return presets.get(preset, [])
    
    def _load_config_file(self, config_file: str) -> list:
        """Carga argumentos desde archivo de configuración JSON"""
        try:
            import json
            with open(config_file, 'r', encoding='utf-8') as f:
                config = json.load(f)
            return config.get('args', [])
        except Exception as e:
            print(f"⚠️ Error cargando archivo de configuración {config_file}: {e}")
            return []
    
    def _get_browser_specific_args(self) -> list:
        """Obtiene argumentos específicos según el navegador y configuración"""
        args = []
        
        if self.config['browser'] in ['chromium', 'chrome']:
            # Configuraciones específicas de Chrome
            if self.config['chrome_disable_security']:
                args.extend([
                    '--disable-web-security',
                    '--disable-features=VizDisplayCompositor',
                    '--ignore-certificate-errors',
                    '--ignore-ssl-errors'
                ])
            
            if self.config['chrome_disable_extensions']:
                args.append('--disable-extensions')
            
            if self.config['chrome_disable_plugins']:
                args.append('--disable-plugins')
            
            if self.config['chrome_disable_images']:
                args.append('--blink-settings=imagesEnabled=false')
            
            if self.config['chrome_disable_javascript']:
                args.append('--disable-javascript')
            
            if self.config['chrome_enable_logging']:
                args.extend([
                    '--enable-logging',
                    f'--log-level={self.config["chrome_log_level"].lower()}'
                ])
        
        elif self.config['browser'] == 'firefox':
            # Configuraciones específicas de Firefox
            if self.config['firefox_private_mode']:
                args.append('--private-window')
            
            if self.config['firefox_disable_addons']:
                args.append('--safe-mode')
        
        elif self.config['browser'] == 'webkit':
            # Configuraciones específicas de WebKit
            if self.config['webkit_disable_features']:
                for feature in self.config['webkit_disable_features']:
                    if feature.strip():
                        args.append(f'--disable-{feature.strip()}')
        
        return args
    
    def create_context(self) -> BrowserContext:
        """Crea un nuevo contexto de navegador con la configuración"""
        if not self.browser:
            raise RuntimeError("Browser not initialized. Call setup_playwright() first.")
        
        context_options = {
            'viewport': {
                'width': self.config['viewport_width'],
                'height': self.config['viewport_height']
            },
            'device_scale_factor': self.config['device_scale_factor'],
            'ignore_https_errors': self.config['ignore_https_errors'],
        }
        
        # Configuración de video automática
        if self.config['record_video']:
            video_dir = self.config['video_dir']
            
            # Crear directorio de videos si no existe
            os.makedirs(video_dir, exist_ok=True)
            
            # Limpiar videos antiguos si está habilitado
            if self.config['cleanup_old_videos']:
                self._cleanup_old_videos(video_dir)
            
            # Configurar grabación de video con la sintaxis correcta de Playwright
            video_size = self.config['video_size']
            width, height = map(int, video_size.split('x'))
            
            context_options['record_video_dir'] = video_dir
            context_options['record_video_size'] = {'width': width, 'height': height}
        
        # NO configurar base_url en Playwright para evitar problemas con variables de entorno
        # Si se configura base_url, Playwright trata las URLs sin protocolo como relativas
        # y las concatena con base_url, causando problemas con ${ENV.BASE_URL}
        # if self.config['base_url']:
        #     context_options['base_url'] = self.config['base_url']
        
        if self.config['user_agent']:
            context_options['user_agent'] = self.config['user_agent']
        
        return self.browser.new_context(**context_options)
    
    def create_page(self, context: Optional[BrowserContext] = None) -> Page:
        """Crea página MINIMA con soporte opcional para modo stealth"""
        if context is None:
            context = self.create_context()
        
        page = context.new_page()
        page.set_default_timeout(self.config['timeout'])
        
        # Aplicar modo stealth si está habilitado
        if self.config.get('stealth_mode', False):
            try:
                from playwright_stealth import stealth_sync
                stealth_sync(page)
                print("🥷 Modo stealth activado - Propiedades de automatización ocultas")
            except ImportError:
                print("⚠️ playwright-stealth no está instalado. Ejecuta: pip install playwright-stealth")
            except Exception as e:
                print(f"⚠️ Error activando modo stealth: {e}")
        
        return page
    
    def setup_logging(self) -> logging.Logger:
        """Configura el sistema de logging"""
        logger = logging.getLogger('hakalab_framework')
        logger.setLevel(logging.INFO)  # Hardcoded para simplicidad
        
        # Evitar duplicar handlers
        if not logger.handlers:
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            
            # Console handler
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(formatter)
            logger.addHandler(console_handler)
        
        return logger
    
    def get_test_data(self) -> Dict[str, str]:
        """Retorna los datos de prueba configurados"""
        return {
            'email': self.config.get('test_email', ''),
            'password': self.config.get('test_password', ''),
            'user_name': self.config.get('test_user_name', ''),
            'api_base_url': self.config.get('api_base_url', ''),
            'base_url': self.config.get('base_url', ''),
        }
    
    def _cleanup_old_videos(self, video_dir: str):
        """Limpia videos antiguos según la configuración"""
        try:
            import time
            from pathlib import Path
            
            max_age_hours = self.config['video_max_age_hours']
            max_age_seconds = max_age_hours * 3600
            current_time = time.time()
            
            video_path = Path(video_dir)
            if not video_path.exists():
                return
            
            deleted_count = 0
            for video_file in video_path.glob('*.webm'):
                file_age = current_time - video_file.stat().st_mtime
                if file_age > max_age_seconds:
                    try:
                        video_file.unlink()
                        deleted_count += 1
                    except Exception as e:
                        print(f"⚠️ No se pudo eliminar video antiguo {video_file}: {e}")
            
            if deleted_count > 0:
                print(f"🧹 Videos antiguos eliminados: {deleted_count} archivos")
                
        except Exception as e:
            print(f"⚠️ Error limpiando videos antiguos: {e}")
    
    def cleanup(self):
        """Cleanup ULTRA MINIMO"""
        # Cerrar browser básico
        if self.browser:
            try:
                self.browser.close()
            except:
                pass
            self.browser = None
        
        # Detener playwright básico
        if self.playwright:
            try:
                self.playwright.stop()
            except:
                pass
            self.playwright = None


def setup_framework_context(context, env_file: Optional[str] = None):
    """Setup completo del framework SIN cleanup_error"""
    
    # Inicializar configuración
    context.framework_config = FrameworkConfig(env_file)
    
    # Configurar logging
    context.logger = context.framework_config.setup_logging()
    
    # Warning si se usa BASE_URL por defecto
    base_url = context.framework_config.config.get('base_url', '')
    if base_url == 'https://example.com':
        context.logger.warning(
            "⚠️  BASE_URL no está configurada. Usando 'https://example.com' por defecto.\n"
            "   Para configurar tu URL, define BASE_URL en tu archivo .env o como variable de entorno."
        )
    
    # Configurar Playwright
    context.browser = context.framework_config.setup_playwright()
    
    # Inicializar utilidades del framework
    from .element_locator import ElementLocator
    from .variable_manager import VariableManager
    from .data_snapshot_manager import DataSnapshotManager
    
    context.element_locator = ElementLocator()
    context.variable_manager = VariableManager()
    context.data_snapshot = DataSnapshotManager()
    
    # Configurar test data (SIN context.config para evitar cleanup_error)
    try:
        context.test_data = context.framework_config.get_test_data()
        # NO asignar context.config - causa cleanup_error
    except Exception as e:
        context.logger.warning(f"Error configurando datos de prueba: {e}")
        context.test_data = {}
    
    # Auto-detectar y configurar integración Jira/Xray
    _setup_jira_xray_integration(context)
    
    context.logger.info("Framework configurado correctamente")


def _setup_jira_xray_integration(context):
    """Detecta automáticamente si Jira/Xray está habilitado y configura la integración"""
    try:
        # Verificar si Jira está habilitado
        jira_enabled = os.getenv('JIRA_ENABLED', 'false').lower() == 'true'
        
        if not jira_enabled:
            context.jira_xray_enabled = False
            return
        
        # Importar e inicializar hooks de Jira/Xray
        from ..integrations.behave_hooks import JiraXrayHooks
        context.jira_xray_hooks = JiraXrayHooks()
        context.jira_xray_enabled = True
        
        # Ejecutar configuración inicial
        context.jira_xray_hooks.before_all(context)
        
        print("🔗 Integración Jira/Xray habilitada automáticamente")
        
    except ImportError:
        # Si no están disponibles las integraciones, continuar sin ellas
        context.jira_xray_enabled = False
        print("⚠️ Módulos de integración Jira/Xray no disponibles")
    except Exception as e:
        context.jira_xray_enabled = False
        print(f"⚠️ Error configurando integración Jira/Xray: {e}")


def auto_before_feature(context, feature):
    """Hook automático before_feature que maneja todas las integraciones"""
    # Ejecutar hook de Jira/Xray si está habilitado
    if getattr(context, 'jira_xray_enabled', False) and hasattr(context, 'jira_xray_hooks'):
        try:
            context.jira_xray_hooks.before_feature(context, feature)
        except Exception as e:
            print(f"⚠️ Error en before_feature Jira/Xray: {e}")


def auto_after_scenario(context, scenario):
    """Hook automático after_scenario que maneja todas las integraciones y reintentos"""
    
    # Verificar si el escenario falló y si los reintentos están habilitados
    retry_enabled = context.framework_config.config.get('retry_failed_scenarios', False)
    max_retries = context.framework_config.config.get('max_scenario_retries', 1)
    
    # Inicializar contador de reintentos si no existe
    if not hasattr(context, 'scenario_retry_count'):
        context.scenario_retry_count = {}
    
    scenario_id = f"{scenario.feature.name}::{scenario.name}"
    
    # Obtener el contador actual de reintentos para este escenario
    current_retry = context.scenario_retry_count.get(scenario_id, 0)
    
    # Si el escenario falló y los reintentos están habilitados
    if scenario.status == 'failed' and retry_enabled and current_retry < max_retries:
        # Incrementar contador de reintentos
        context.scenario_retry_count[scenario_id] = current_retry + 1
        
        print(f"\n🔄 Reintentando escenario fallido: {scenario.name}")
        print(f"   Intento {current_retry + 1} de {max_retries}")
        
        # Limpiar el estado del escenario para el reintento
        try:
            # NO cerrar la página - solo limpiar su estado para reutilizarla
            if hasattr(context, 'page') and context.page:
                try:
                    # Navegar a about:blank para limpiar el estado
                    context.page.goto('about:blank')
                    context.logger.info("♻️ Página limpiada para reintento (navegada a about:blank)")
                except Exception as e:
                    # Si falla la limpieza, entonces sí crear una nueva página
                    context.logger.warning(f"No se pudo limpiar la página, creando una nueva: {e}")
                    try:
                        context.page.close()
                    except Exception:
                        pass
                    context.page = context.framework_config.create_page()
            else:
                # Si no hay página, crear una nueva
                context.page = context.framework_config.create_page()
            
            # Limpiar variables del escenario anterior
            if hasattr(context, 'variable_manager'):
                context.variable_manager.clear_scenario_variables()
            
            # Limpiar listeners de API
            if hasattr(context, 'api_listening_active'):
                context.api_listening_active = False
            
            # Limpiar referencia al iframe si existe
            if hasattr(context, 'current_frame'):
                context.current_frame = None
            
            # Re-ejecutar el escenario
            # Nota: Behave no soporta nativamente re-ejecutar escenarios desde hooks
            # Por lo que marcamos el escenario para reintento y lo manejamos externamente
            scenario._retry_requested = True
            scenario._retry_count = current_retry + 1
            
            print(f"✅ Escenario preparado para reintento (página reutilizada)")
            
        except Exception as e:
            print(f"⚠️ Error preparando reintento del escenario: {e}")
    
    elif scenario.status == 'failed' and retry_enabled and current_retry >= max_retries:
        print(f"\n❌ Escenario falló después de {max_retries} reintentos: {scenario.name}")
        # Limpiar el contador para este escenario
        if scenario_id in context.scenario_retry_count:
            del context.scenario_retry_count[scenario_id]
    
    elif scenario.status == 'passed' and scenario_id in context.scenario_retry_count:
        # El escenario pasó después de reintentos
        retry_count = context.scenario_retry_count[scenario_id]
        print(f"\n✅ Escenario pasó después de {retry_count} reintento(s): {scenario.name}")
        # Limpiar el contador
        del context.scenario_retry_count[scenario_id]
    
    # Ejecutar hook de Jira/Xray si está habilitado
    if getattr(context, 'jira_xray_enabled', False) and hasattr(context, 'jira_xray_hooks'):
        try:
            context.jira_xray_hooks.after_scenario(context, scenario)
        except Exception as e:
            print(f"⚠️ Error en after_scenario Jira/Xray: {e}")


def auto_after_feature(context, feature):
    """Hook automático after_feature que maneja todas las integraciones"""
    # Cerrar todas las páginas al finalizar el feature (no entre escenarios)
    try:
        if hasattr(context, 'browser') and context.browser:
            contexts = context.browser.contexts
            for browser_context in contexts:
                pages = browser_context.pages
                for page in pages:
                    try:
                        page.close()
                    except Exception:
                        pass
            # Limpiar la referencia a la página en el contexto
            if hasattr(context, 'page'):
                context.page = None
            context.logger.info("🧹 Páginas cerradas al finalizar el feature")
    except Exception as e:
        print(f"⚠️ Error cerrando páginas en after_feature: {e}")
    
    # Ejecutar hook de Jira/Xray si está habilitado
    if getattr(context, 'jira_xray_enabled', False) and hasattr(context, 'jira_xray_hooks'):
        try:
            context.jira_xray_hooks.after_feature(context, feature)
        except Exception as e:
            print(f"⚠️ Error en after_feature Jira/Xray: {e}")


def auto_after_all(context):
    """Hook automático after_all que maneja todas las integraciones"""
    # Ejecutar hook de Jira/Xray si está habilitado
    if getattr(context, 'jira_xray_enabled', False) and hasattr(context, 'jira_xray_hooks'):
        try:
            context.jira_xray_hooks.after_all(context)
        except Exception as e:
            print(f"⚠️ Error en after_all Jira/Xray: {e}")


def setup_scenario_context(context, scenario):
    """Setup completo de escenario
    
    Reutiliza la página existente si ya está creada y activa (para mantener sesión entre escenarios).
    Solo crea una nueva página si no existe o está cerrada.
    
    IMPORTANTE: La página se almacena en el browser para persistir entre escenarios del mismo feature.
    """
    
    # Inicializar data snapshot para este escenario
    if hasattr(context, 'data_snapshot'):
        context.data_snapshot.set_scenario(scenario.name)
    
    # Verificar si el navegador está desactivado para esta prueba
    if hasattr(context, 'browser_disabled') and context.browser_disabled:
        context.logger.info("🚫 Navegador desactivado - saltando inicialización")
        # Configurar funciones helper simplificadas (sin navegador)
        from .context_helpers import setup_context_helpers, add_bulk_operations, setup_advanced_helpers
        setup_context_helpers(context)
        add_bulk_operations(context)
        setup_advanced_helpers(context)
        return
    
    # Verificar si ya existe una página activa y reutilizarla
    page_is_active = False
    
    # Primero verificar si context.page ya existe y está activa
    if hasattr(context, 'page') and context.page:
        try:
            # Verificar que la página está activa intentando acceder a su URL
            _ = context.page.url
            page_is_active = True
            context.logger.info(f"♻️ Reutilizando página existente (URL: {context.page.url})")
        except Exception:
            # La página está cerrada o inválida
            page_is_active = False
            context.logger.debug("Página anterior cerrada o inválida")
    
    # Si no hay página activa en context.page, buscar en el browser
    if not page_is_active and hasattr(context, 'browser') and context.browser:
        try:
            contexts = context.browser.contexts
            if contexts and len(contexts) > 0:
                browser_context = contexts[0]
                pages = browser_context.pages
                if pages and len(pages) > 0:
                    # Intentar usar la primera página activa
                    test_page = pages[0]
                    try:
                        _ = test_page.url  # Verificar que la página está activa
                        context.page = test_page
                        page_is_active = True
                        context.logger.info(f"♻️ Reutilizando página del browser (URL: {test_page.url})")
                    except Exception:
                        page_is_active = False
        except Exception as e:
            context.logger.debug(f"No se pudo verificar páginas existentes: {e}")
            page_is_active = False
    
    # Crear nueva página SOLO si no existe o está cerrada
    if not page_is_active:
        context.page = context.framework_config.create_page()
        context.logger.info("🆕 Nueva página creada para el escenario")
    
    # IMPORTANTE: Re-aplicar el timeout configurado, incluso si reutilizamos la página
    # Esto asegura que el timeout esté siempre activo
    if hasattr(context, 'page') and context.page:
        timeout = context.framework_config.config.get('timeout', 30000)
        context.page.set_default_timeout(timeout)
        context.logger.debug(f"Timeout configurado: {timeout}ms")
    
    # Configurar funciones helper simplificadas
    from .context_helpers import setup_context_helpers, add_bulk_operations, setup_advanced_helpers
    setup_context_helpers(context)
    add_bulk_operations(context)
    setup_advanced_helpers(context)
    
    # Configurar tags si es necesario
    try:
        if hasattr(scenario, 'tags') and scenario.tags:
            if 'mobile' in [tag.lower() for tag in scenario.tags]:
                # Configurar viewport móvil
                context.page.set_viewport_size({"width": 375, "height": 667})
    except Exception as e:
        context.logger.warning(f"Error configurando tags: {e}")
    
    # Asegurar que siempre estamos en el primer tab/página si hay múltiples
    try:
        if hasattr(context, 'browser') and context.browser:
            browser_contexts = context.browser.contexts
            if browser_contexts and len(browser_contexts) > 0:
                browser_context = browser_contexts[0]
                pages = browser_context.pages
                if pages and len(pages) > 1:
                    # Hay múltiples páginas/tabs, cambiar al primero
                    first_page = pages[0]
                    first_page.bring_to_front()
                    context.page = first_page
                    context.logger.info(f"Cambiado al primer tab (total: {len(pages)} tabs abiertos)")
    except Exception as e:
        context.logger.debug(f"No se pudo cambiar al primer tab: {e}")
    
    # Limpiar listeners de API del escenario anterior si existen
    # Esto evita que se sigan guardando requests innecesariamente
    if hasattr(context, 'api_listening_active'):
        context.api_listening_active = False
    
    context.logger.info(f"Iniciando escenario: {scenario.name}")



