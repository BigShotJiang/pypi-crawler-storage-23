#!/usr/bin/env python3
"""
Auto-instalador inteligente para dependencias opcionales
Instala automáticamente las librerías cuando se necesitan
"""

import subprocess
import sys
import importlib
import logging
from typing import List, Dict, Optional
import os


class AutoInstaller:
    """Auto-instalador inteligente para dependencias opcionales"""
    
    def __init__(self):
        self.logger = logging.getLogger('hakalab_framework.auto_installer')
        self.installed_packages = set()
        
        # Mapeo de funcionalidades a dependencias
        self.dependency_groups = {
            'ocr': {
                'packages': [
                    'pytesseract>=0.3.10',
                    'easyocr>=1.7.0', 
                    'opencv-python>=4.8.0',
                    'numpy>=1.24.0'
                ],
                'test_imports': ['pytesseract', 'easyocr', 'cv2', 'numpy'],
                'description': 'OCR (Reconocimiento Óptico de Caracteres)',
                'optional': True
            },
            'advanced_data': {
                'packages': [
                    'openpyxl>=3.0.0',
                    'xlsxwriter>=3.0.0',
                    'lxml>=4.9.0'
                ],
                'test_imports': ['openpyxl', 'xlsxwriter', 'lxml'],
                'description': 'Procesamiento avanzado de datos (Excel, XML)',
                'optional': True
            },
            'performance': {
                'packages': [
                    'psutil>=5.9.0',
                    'memory-profiler>=0.60.0'
                ],
                'test_imports': ['psutil', 'memory_profiler'],
                'description': 'Monitoreo de rendimiento',
                'optional': True
            }
        }
    
    def check_dependencies(self, group: str) -> Dict[str, bool]:
        """Verifica qué dependencias están instaladas para un grupo"""
        if group not in self.dependency_groups:
            return {}
        
        results = {}
        test_imports = self.dependency_groups[group]['test_imports']
        
        for module_name in test_imports:
            try:
                importlib.import_module(module_name)
                results[module_name] = True
            except ImportError:
                results[module_name] = False
        
        return results
    
    def install_group(self, group: str, force: bool = False, quiet: bool = False) -> bool:
        """Instala un grupo de dependencias"""
        if group not in self.dependency_groups:
            self.logger.error(f"Grupo de dependencias desconocido: {group}")
            return False
        
        group_info = self.dependency_groups[group]
        
        # Verificar si ya están instaladas
        if not force:
            dependencies_status = self.check_dependencies(group)
            if all(dependencies_status.values()):
                if not quiet:
                    self.logger.info(f"✅ Dependencias de {group_info['description']} ya están instaladas")
                return True
        
        # Mostrar mensaje informativo
        if not quiet:
            print(f"\n🔧 Instalando dependencias para {group_info['description']}...")
            print(f"📦 Paquetes: {', '.join(group_info['packages'])}")
            print("⏳ Esto puede tomar unos minutos...")
        
        try:
            # Instalar paquetes
            for package in group_info['packages']:
                if not quiet:
                    print(f"  📥 Instalando {package}...")
                
                result = subprocess.run([
                    sys.executable, '-m', 'pip', 'install', package, '--user'
                ], capture_output=True, text=True, timeout=300)
                
                if result.returncode != 0:
                    self.logger.warning(f"⚠️ Error instalando {package}: {result.stderr}")
                    # Intentar sin --user
                    result = subprocess.run([
                        sys.executable, '-m', 'pip', 'install', package
                    ], capture_output=True, text=True, timeout=300)
                    
                    if result.returncode != 0:
                        self.logger.error(f"❌ No se pudo instalar {package}")
                        return False
            
            # Verificar instalación
            dependencies_status = self.check_dependencies(group)
            success = all(dependencies_status.values())
            
            if success:
                if not quiet:
                    print(f"✅ Dependencias de {group_info['description']} instaladas correctamente!")
                self.installed_packages.add(group)
                return True
            else:
                missing = [k for k, v in dependencies_status.items() if not v]
                self.logger.error(f"❌ Falló la instalación de: {missing}")
                return False
                
        except subprocess.TimeoutExpired:
            self.logger.error("❌ Timeout durante la instalación")
            return False
        except Exception as e:
            self.logger.error(f"❌ Error inesperado durante la instalación: {e}")
            return False
    
    def auto_install_for_feature(self, feature_content: str, quiet: bool = True) -> Dict[str, bool]:
        """Auto-instala dependencias basado en el contenido de un feature"""
        results = {}
        
        # Detectar si se usan steps de OCR
        ocr_keywords = [
            'extraigo texto', 'extract text', 'OCR', 'screenshot', 'imagen',
            'texto.*imagen', 'text.*image', 'reconocimiento', 'tesseract'
        ]
        
        if any(keyword.lower() in feature_content.lower() for keyword in ocr_keywords):
            if not quiet:
                print("🔍 Detectados steps de OCR, verificando dependencias...")
            results['ocr'] = self.install_group('ocr', quiet=quiet)
        
        # Detectar si se usan funcionalidades avanzadas de datos
        data_keywords = ['excel', 'xlsx', 'xml', 'openpyxl']
        if any(keyword.lower() in feature_content.lower() for keyword in data_keywords):
            if not quiet:
                print("📊 Detectado procesamiento de datos avanzado...")
            results['advanced_data'] = self.install_group('advanced_data', quiet=quiet)
        
        return results
    
    def install_on_demand(self, group: str, step_name: str = None) -> bool:
        """Instala dependencias cuando se ejecuta un step específico"""
        group_info = self.dependency_groups.get(group, {})
        
        print(f"\n🚀 El step '{step_name}' requiere {group_info.get('description', group)}")
        print("🔧 Instalando dependencias automáticamente...")
        
        return self.install_group(group, quiet=False)
    
    def get_installation_status(self) -> Dict[str, Dict]:
        """Obtiene el estado de instalación de todos los grupos"""
        status = {}
        
        for group, info in self.dependency_groups.items():
            dependencies_status = self.check_dependencies(group)
            status[group] = {
                'description': info['description'],
                'installed': all(dependencies_status.values()),
                'details': dependencies_status,
                'packages': info['packages']
            }
        
        return status
    
    def show_installation_status(self):
        """Muestra el estado de instalación de todas las dependencias"""
        print("\n📦 Estado de dependencias opcionales:")
        print("=" * 50)
        
        status = self.get_installation_status()
        
        for group, info in status.items():
            icon = "✅" if info['installed'] else "❌"
            print(f"{icon} {info['description']}")
            
            if not info['installed']:
                missing = [k for k, v in info['details'].items() if not v]
                print(f"   📥 Faltantes: {', '.join(missing)}")
                print(f"   💡 Instalar con: pip install {' '.join(info['packages'])}")
            
            print()


# Instancia global del auto-instalador
auto_installer = AutoInstaller()


def ensure_dependencies(group: str, step_name: str = None) -> bool:
    """Función helper para asegurar que las dependencias estén instaladas"""
    return auto_installer.install_on_demand(group, step_name)


def check_and_install_ocr_dependencies() -> bool:
    """Función específica para dependencias de OCR"""
    return ensure_dependencies('ocr', 'OCR')


def auto_install_from_feature_file(feature_path: str) -> Dict[str, bool]:
    """Auto-instala dependencias basado en un archivo feature"""
    try:
        with open(feature_path, 'r', encoding='utf-8') as f:
            content = f.read()
        return auto_installer.auto_install_for_feature(content, quiet=True)
    except Exception as e:
        auto_installer.logger.error(f"Error leyendo feature file {feature_path}: {e}")
        return {}