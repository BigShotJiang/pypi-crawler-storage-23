#!/usr/bin/env python3
"""
OCR Manager Demo - Versión de demostración que simula OCR para mostrar funcionalidad
"""

import os
import logging
from typing import List, Dict, Optional, Tuple
from PIL import Image


class OCRResult:
    """Clase para almacenar resultados de OCR"""
    def __init__(self, text: str, confidence: float, bbox: Optional[Tuple] = None):
        self.text = text.strip()
        self.confidence = confidence
        self.bbox = bbox  # (x, y, width, height)
    
    def __str__(self):
        return f"OCRResult(text='{self.text}', confidence={self.confidence:.2f})"


class OCRManagerDemo:
    """Manager de demostración para operaciones de OCR"""
    
    def __init__(self):
        self.logger = logging.getLogger('hakalab_framework.ocr')
        
    def extract_text_auto(self, image_path: str) -> List[OCRResult]:
        """Simula extracción de texto basada en el nombre del archivo"""
        try:
            # Verificar que la imagen existe
            if not os.path.exists(image_path):
                raise FileNotFoundError(f"Imagen no encontrada: {image_path}")
            
            # Abrir imagen para verificar que es válida
            with Image.open(image_path) as img:
                width, height = img.size
            
            # Simular resultados basados en el nombre del archivo
            filename = os.path.basename(image_path).lower()
            
            if 'example' in filename or 'ocr_test_basic' in filename:
                # Simular texto de example.com
                results = [
                    OCRResult("Example Domain", 95.2),
                    OCRResult("This domain is for use in illustrative examples in documents.", 87.5),
                    OCRResult("You may use this domain in literature without prior coordination or asking for permission.", 82.1),
                    OCRResult("More information...", 78.9)
                ]
            elif 'httpbin' in filename:
                # Simular texto de httpbin.org
                results = [
                    OCRResult("httpbin.org", 92.3),
                    OCRResult("A simple HTTP Request & Response Service.", 85.7),
                    OCRResult("Run locally: $ docker run -p 80:80 kennethreitz/httpbin", 79.4)
                ]
            else:
                # Texto genérico para otras imágenes
                results = [
                    OCRResult("Sample text detected in image", 75.0),
                    OCRResult(f"Image size: {width}x{height}", 80.0)
                ]
            
            self.logger.info(f"OCR Demo completado - {len(results)} textos simulados")
            return results
            
        except Exception as e:
            self.logger.error(f"Error en OCR Demo: {e}")
            raise
    
    def find_text_in_image(self, image_path: str, search_text: str, 
                          case_sensitive: bool = False) -> List[OCRResult]:
        """Busca texto específico en una imagen"""
        results = self.extract_text_auto(image_path)
        
        # Buscar texto
        found_results = []
        for result in results:
            text_to_search = result.text if case_sensitive else result.text.lower()
            search_target = search_text if case_sensitive else search_text.lower()
            
            if search_target in text_to_search:
                found_results.append(result)
        
        return found_results
    
    def get_all_text(self, image_path: str, min_confidence: float = 50.0) -> str:
        """Obtiene todo el texto de una imagen como string"""
        results = self.extract_text_auto(image_path)
        
        # Filtrar por confidence y concatenar
        filtered_texts = [r.text for r in results if r.confidence >= min_confidence]
        return '\n'.join(filtered_texts)
    
    def validate_text_quality(self, image_path: str, min_confidence: float = 70.0) -> Dict:
        """Valida la calidad del texto en una imagen"""
        try:
            results = self.extract_text_auto(image_path)
            
            if not results:
                return {
                    'is_readable': False,
                    'avg_confidence': 0,
                    'text_count': 0,
                    'quality': 'No text found'
                }
            
            confidences = [r.confidence for r in results]
            avg_confidence = sum(confidences) / len(confidences)
            readable_count = sum(1 for c in confidences if c >= min_confidence)
            
            quality = 'Excellent' if avg_confidence >= 90 else \
                     'Good' if avg_confidence >= 70 else \
                     'Fair' if avg_confidence >= 50 else 'Poor'
            
            return {
                'is_readable': avg_confidence >= min_confidence,
                'avg_confidence': avg_confidence,
                'text_count': len(results),
                'readable_count': readable_count,
                'quality': quality,
                'texts': [r.text for r in results]
            }
            
        except Exception as e:
            self.logger.error(f"Error validando calidad de texto: {e}")
            return {
                'is_readable': False,
                'avg_confidence': 0,
                'text_count': 0,
                'quality': f'Error: {e}'
            }