"""
Módulo para fusionar reportes Hakalab JSON en un único reporte HTML
Soporta el formato de reportes generado por Hakalab Framework
"""

import json
import os
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any
import re


class CucumberReportMerger:
    """Fusiona reportes Hakalab JSON de múltiples jobs en un único reporte HTML"""
    
    def __init__(self, output_dir: str = 'consolidated-reports'):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.merged_data = {
            'total_scenarios': 0,
            'passed': 0,
            'failed': 0,
            'skipped': 0,
            'features': [],
            'execution_time': 0,
            'browsers': [],
            'timestamp': datetime.now().isoformat()
        }
    
    def find_hakalab_jsons(self, artifacts_dir: str) -> List[Path]:
        """Busca todos los JSONs de Hakalab en el directorio de artefactos"""
        artifacts_path = Path(artifacts_dir)
        
        json_files = list(artifacts_path.glob('**/*.json'))
        
        hakalab_jsons = []
        for json_file in json_files:
            try:
                with open(json_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if isinstance(data, dict) and 'features' in data and 'summary' in data:
                        hakalab_jsons.append(json_file)
            except:
                pass
        
        return hakalab_jsons
    
    def merge_hakalab_jsons(self, artifacts_dir: str) -> Dict[str, Any]:
        """Fusiona reportes Hakalab JSON de múltiples jobs"""
        json_files = self.find_hakalab_jsons(artifacts_dir)
        
        if not json_files:
            print("[WARNING] No se encontraron reportes Hakalab JSON")
            return self.merged_data
        
        print(f"[INFO] Encontrados {len(json_files)} reportes Hakalab JSON")
        
        all_scenarios = []
        all_features = {}
        total_time = 0
        all_browsers = set()
        
        for json_file in json_files:
            try:
                with open(json_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    
                    job_name = json_file.parent.name
                    browser = data.get('execution_info', {}).get('browser', 'unknown')
                    all_browsers.add(browser)
                    
                    total_time += data.get('execution_info', {}).get('duration', 0)
                    
                    for feature in data.get('features', []):
                        feature_name = feature.get('name', 'Unknown')
                        
                        if feature_name not in all_features:
                            all_features[feature_name] = {
                                'name': feature_name,
                                'description': feature.get('description', ''),
                                'scenarios': [],
                                'tags': feature.get('tags', []),
                                'jobs': []
                            }
                        
                        all_features[feature_name]['jobs'].append(job_name)
                        
                        for scenario in feature.get('scenarios', []):
                            scenario_data = {
                                'name': scenario.get('name', 'Unknown'),
                                'status': scenario.get('status', 'unknown'),
                                'tags': scenario.get('tags', []),
                                'job': job_name,
                                'steps': scenario.get('steps', []),
                                'browser': browser
                            }
                            
                            all_scenarios.append(scenario_data)
                            all_features[feature_name]['scenarios'].append(scenario_data)
                    
            except Exception as e:
                print(f"[ERROR] Error procesando {json_file}: {e}")
        
        self.merged_data['features'] = list(all_features.values())
        self.merged_data['total_scenarios'] = len(all_scenarios)
        self.merged_data['passed'] = sum(1 for s in all_scenarios if s.get('status') == 'passed')
        self.merged_data['failed'] = sum(1 for s in all_scenarios if s.get('status') == 'failed')
        self.merged_data['skipped'] = sum(1 for s in all_scenarios if s.get('status') == 'skipped')
        self.merged_data['execution_time'] = total_time
        self.merged_data['browsers'] = list(all_browsers)
        
        return self.merged_data
    
    def generate_unified_html(self, data: Dict[str, Any], output_file: str = 'report.html') -> str:
        """Genera un reporte HTML unificado"""
        output_path = self.output_dir / output_file
        
        total = data['total_scenarios']
        passed_pct = (data['passed'] / total * 100) if total > 0 else 0
        failed_pct = (data['failed'] / total * 100) if total > 0 else 0
        skipped_pct = (data['skipped'] / total * 100) if total > 0 else 0
        
        html_content = f"""
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporte Unificado - Hakalab Framework</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }}
        
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }}
        
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
            text-align: center;
        }}
        
        .header h1 {{
            font-size: 2.5em;
            margin-bottom: 10px;
        }}
        
        .header p {{
            font-size: 1.1em;
            opacity: 0.9;
        }}
        
        .timestamp {{
            font-size: 0.9em;
            opacity: 0.8;
            margin-top: 10px;
        }}
        
        .stats {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            padding: 40px;
            background: #f8f9fa;
        }}
        
        .stat-card {{
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }}
        
        .stat-card h3 {{
            color: #667eea;
            font-size: 2em;
            margin-bottom: 10px;
        }}
        
        .stat-card p {{
            color: #666;
            font-size: 0.9em;
        }}
        
        .stat-card.passed h3 {{ color: #27ae60; }}
        .stat-card.failed h3 {{ color: #e74c3c; }}
        .stat-card.skipped h3 {{ color: #f39c12; }}
        
        .progress-bar {{
            width: 100%;
            height: 30px;
            background: #ecf0f1;
            border-radius: 15px;
            overflow: hidden;
            margin-top: 20px;
            display: flex;
        }}
        
        .progress-segment {{
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 0.8em;
        }}
        
        .progress-passed {{ background: #27ae60; width: {passed_pct}%; }}
        .progress-failed {{ background: #e74c3c; width: {failed_pct}%; }}
        .progress-skipped {{ background: #f39c12; width: {skipped_pct}%; }}
        
        .content {{
            padding: 40px;
        }}
        
        .section {{
            margin-bottom: 40px;
        }}
        
        .section h2 {{
            color: #2c3e50;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #667eea;
        }}
        
        .feature-list {{
            display: grid;
            gap: 15px;
        }}
        
        .feature-item {{
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            border-left: 4px solid #667eea;
        }}
        
        .feature-item h3 {{
            color: #2c3e50;
            margin-bottom: 10px;
        }}
        
        .feature-stats {{
            display: flex;
            gap: 20px;
            font-size: 0.9em;
            margin-top: 10px;
            flex-wrap: wrap;
        }}
        
        .feature-stats span {{
            display: flex;
            align-items: center;
            gap: 5px;
        }}
        
        .badge {{
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.8em;
            font-weight: bold;
            margin-right: 5px;
        }}
        
        .badge.passed {{ background: #d4edda; color: #155724; }}
        .badge.failed {{ background: #f8d7da; color: #721c24; }}
        .badge.skipped {{ background: #fff3cd; color: #856404; }}
        
        .scenarios {{
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #ddd;
        }}
        
        .scenario {{
            padding: 10px;
            margin: 5px 0;
            background: white;
            border-left: 3px solid #667eea;
            border-radius: 4px;
            font-size: 0.9em;
        }}
        
        .scenario.passed {{
            border-left-color: #27ae60;
        }}
        
        .scenario.failed {{
            border-left-color: #e74c3c;
        }}
        
        .scenario.skipped {{
            border-left-color: #f39c12;
        }}
        
        .scenario-name {{
            font-weight: bold;
            margin-bottom: 5px;
        }}
        
        .scenario-meta {{
            font-size: 0.85em;
            color: #666;
        }}
        
        .jobs {{
            font-size: 0.85em;
            color: #666;
            margin-top: 10px;
        }}
        
        .footer {{
            background: #f8f9fa;
            padding: 20px;
            text-align: center;
            color: #666;
            border-top: 1px solid #ecf0f1;
        }}
        
        .summary {{
            background: #ecf0f1;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }}
        
        .summary p {{
            margin: 5px 0;
            color: #2c3e50;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Hakalab Framework</h1>
            <p>Reporte Unificado de Pruebas Automatizadas</p>
            <div class="timestamp">
                <p>Generado: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}</p>
            </div>
        </div>
        
        <div class="stats">
            <div class="stat-card">
                <h3>{data['total_scenarios']}</h3>
                <p>Total de Escenarios</p>
            </div>
            <div class="stat-card passed">
                <h3>{data['passed']}</h3>
                <p>Pasados ({passed_pct:.1f}%)</p>
            </div>
            <div class="stat-card failed">
                <h3>{data['failed']}</h3>
                <p>Fallidos ({failed_pct:.1f}%)</p>
            </div>
            <div class="stat-card skipped">
                <h3>{data['skipped']}</h3>
                <p>Omitidos ({skipped_pct:.1f}%)</p>
            </div>
        </div>
        
        <div class="content">
            <div class="progress-bar">
                {f'<div class="progress-segment progress-passed">{data["passed"]}</div>' if data['passed'] > 0 else ''}
                {f'<div class="progress-segment progress-failed">{data["failed"]}</div>' if data['failed'] > 0 else ''}
                {f'<div class="progress-segment progress-skipped">{data["skipped"]}</div>' if data['skipped'] > 0 else ''}
            </div>
            
            <div class="section">
                <h2>Informacion de Ejecucion</h2>
                <div class="summary">
                    <p><strong>Navegadores:</strong> {', '.join(data['browsers']) if data['browsers'] else 'N/A'}</p>
                    <p><strong>Tiempo Total:</strong> {data['execution_time']:.2f}s</p>
                    <p><strong>Timestamp:</strong> {data['timestamp']}</p>
                </div>
            </div>
            
            <div class="section">
                <h2>Features Ejecutados</h2>
                <div class="feature-list">
                    {self._generate_features_html(data['features'])}
                </div>
            </div>
        </div>
        
        <div class="footer">
            <p>Reporte generado automaticamente por Hakalab Framework</p>
            <p>2024 - Todos los derechos reservados</p>
        </div>
    </div>
</body>
</html>
"""
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        print(f"[SUCCESS] Reporte unificado generado: {output_path}")
        return str(output_path)
    
    def _generate_features_html(self, features: List[Dict[str, Any]]) -> str:
        """Genera HTML para la lista de features con escenarios"""
        html = ""
        
        for feature in features:
            passed = sum(1 for s in feature['scenarios'] if s.get('status') == 'passed')
            failed = sum(1 for s in feature['scenarios'] if s.get('status') == 'failed')
            skipped = sum(1 for s in feature['scenarios'] if s.get('status') == 'skipped')
            total = len(feature['scenarios'])
            
            jobs_str = ', '.join(set(feature['jobs']))
            
            scenarios_html = ""
            for scenario in feature['scenarios']:
                status_class = scenario.get('status', 'unknown')
                browser = scenario.get('browser', 'unknown')
                scenarios_html += f"""
                <div class="scenario {status_class}">
                    <div class="scenario-name">{scenario['name']}</div>
                    <div class="scenario-meta">
                        <span class="badge {status_class}">{scenario['status'].upper()}</span>
                        <span>Browser: {browser}</span>
                    </div>
                </div>
                """
            
            html += f"""
            <div class="feature-item">
                <h3>{feature['name']}</h3>
                <div class="feature-stats">
                    <span><span class="badge passed">{passed}</span> Pasados</span>
                    <span><span class="badge failed">{failed}</span> Fallidos</span>
                    <span><span class="badge skipped">{skipped}</span> Omitidos</span>
                    <span>Total: {total}</span>
                </div>
                <div class="scenarios">
                    {scenarios_html}
                </div>
                <div class="jobs">
                    <strong>Ejecutado en:</strong> {jobs_str}
                </div>
            </div>
            """
        
        return html
    
    def merge_and_generate(self, artifacts_dir: str, output_file: str = 'report.html') -> str:
        """Fusiona reportes y genera HTML en un paso"""
        print("[INFO] Iniciando fusion de reportes Hakalab...")
        data = self.merge_hakalab_jsons(artifacts_dir)
        report_path = self.generate_unified_html(data, output_file)
        return report_path
