"""
Generador de reportes unificados desde múltiples JSONs de ejecuciones paralelas.
Combina reportes de diferentes workers en un único HTML portable.
"""

import json
import os
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional
import base64


class UnifiedReportGenerator:
    """Genera un reporte HTML unificado a partir de múltiples JSONs de pruebas."""

    def __init__(self, output_dir: str = "html-reports"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.reports_data: List[Dict[str, Any]] = []
        self.unified_summary = {
            "features": {"total": 0, "passed": 0, "failed": 0, "skipped": 0},
            "scenarios": {"total": 0, "passed": 0, "failed": 0, "skipped": 0},
            "steps": {"total": 0, "passed": 0, "failed": 0, "skipped": 0, "undefined": 0},
        }

    def load_json_reports(self, json_dir: str) -> None:
        """Carga todos los JSONs de reportes desde un directorio (busca recursivamente)."""
        json_path = Path(json_dir)
        if not json_path.exists():
            raise FileNotFoundError(f"Directorio {json_dir} no encontrado")

        # Buscar recursivamente en todos los subdirectorios
        json_files = sorted(json_path.rglob("test_report_*.json"))
        
        if not json_files:
            raise FileNotFoundError(f"No se encontraron archivos test_report_*.json en {json_dir} (búsqueda recursiva)")

        for json_file in json_files:
            try:
                with open(json_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    # Incluir la ruta relativa para identificar el worker
                    relative_path = json_file.relative_to(json_path)
                    data["_source_file"] = str(relative_path)
                    self.reports_data.append(data)
            except json.JSONDecodeError as e:
                print(f"Error al parsear {json_file}: {e}")

    def aggregate_summaries(self) -> None:
        """Agrega los resúmenes de todos los reportes."""
        for report in self.reports_data:
            if "summary" in report:
                summary = report["summary"]
                for key in ["features", "scenarios", "steps"]:
                    if key in summary:
                        for status in summary[key]:
                            if status in self.unified_summary[key]:
                                self.unified_summary[key][status] += summary[key][status]

    def get_execution_times(self) -> Dict[str, Any]:
        """Obtiene los tiempos de ejecución agregados."""
        if not self.reports_data:
            return {"start": "", "end": "", "duration": 0}

        start_times = []
        end_times = []
        total_duration = 0

        for report in self.reports_data:
            if "execution_info" in report:
                info = report["execution_info"]
                if "start_time" in info:
                    start_times.append(info["start_time"])
                if "end_time" in info:
                    end_times.append(info["end_time"])
                if "duration" in info:
                    total_duration += info["duration"]

        return {
            "start": min(start_times) if start_times else "",
            "end": max(end_times) if end_times else "",
            "duration": round(total_duration, 2),
        }

    def generate_html(self, title: str = "Reporte Unificado de Pruebas") -> str:
        """Genera el HTML del reporte unificado."""
        self.aggregate_summaries()
        exec_times = self.get_execution_times()

        html = self._get_html_header(title)
        html += self._get_html_body(exec_times)
        html += self._get_html_footer()

        return html

    def save_report(self, filename: str = "unified_report.html") -> Path:
        """Genera y guarda el reporte HTML."""
        html_content = self.generate_html()
        output_file = self.output_dir / filename

        with open(output_file, "w", encoding="utf-8") as f:
            f.write(html_content)

        return output_file

    def _get_html_header(self, title: str) -> str:
        """Retorna el header HTML con estilos."""
        return f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #3498db 0%, #2c3e50 100%);
            min-height: 100vh;
            padding: 20px;
        }}
        
        .container {{
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
        }}
        
        .header {{
            background: #1a1a1a;
            color: white;
            padding: 30px;
            text-align: center;
        }}
        
        .header h1 {{
            font-size: 2.5em;
            margin-bottom: 10px;
            background: linear-gradient(45deg, #00bcd4, #2196f3);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }}
        
        .header .subtitle {{
            font-size: 1.2em;
            opacity: 0.8;
        }}
        
        .info-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            background: rgba(255, 255, 255, 0.1);
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
            backdrop-filter: blur(10px);
        }}
        
        .info-item {{
            display: flex;
            flex-direction: column;
            gap: 5px;
        }}
        
        .info-label {{
            font-size: 0.9em;
            opacity: 0.8;
            font-weight: 500;
        }}
        
        .info-value {{
            font-size: 1.1em;
            font-weight: 600;
            color: #ecf0f1;
        }}
        
        .summary {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            padding: 30px;
            background: #f8f9fa;
        }}
        
        .summary-card {{
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            text-align: center;
            border-top: 4px solid #3498db;
        }}
        
        .summary-card h3 {{
            color: #2c3e50;
            margin-bottom: 20px;
            font-size: 1.3em;
        }}
        
        .chart-and-stats {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
        }}
        
        .mini-chart {{
            flex-shrink: 0;
            width: 120px;
            height: 120px;
        }}
        
        .summary-stats {{
            display: flex;
            flex-direction: column;
            gap: 10px;
            flex: 1;
        }}
        
        .stat {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 12px;
            background: #f8f9fa;
            border-radius: 6px;
        }}
        
        .stat-number {{
            font-size: 1.5em;
            font-weight: bold;
        }}
        
        .stat-label {{
            font-size: 0.9em;
            color: #666;
            text-transform: uppercase;
        }}
        
        .passed {{ color: #27ae60; }}
        .failed {{ color: #e74c3c; }}
        .skipped {{ color: #f39c12; }}
        .undefined {{ color: #9b59b6; }}
        
        .features-section {{
            padding: 30px;
            background: #f8f9fa;
        }}
        
        .features-section h2 {{
            color: #2c3e50;
            margin-bottom: 20px;
            text-align: center;
            font-size: 2em;
        }}
        
        .worker-group {{
            margin-bottom: 30px;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }}
        
        .worker-header {{
            background: #34495e;
            color: white;
            padding: 15px 20px;
            font-weight: bold;
            font-size: 1.1em;
        }}
        
        .feature {{
            background: white;
            margin: 15px;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            border-left: 5px solid #3498db;
        }}
        
        .feature-header {{
            padding: 15px;
            background: #ecf0f1;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        
        .feature-header:hover {{
            background: #d5dbdb;
        }}
        
        .feature-status {{
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9em;
            font-weight: bold;
            color: white;
        }}
        
        .feature-status.passed {{ background: #27ae60; }}
        .feature-status.failed {{ background: #e74c3c; }}
        .feature-status.skipped {{ background: #f39c12; }}
        
        .feature-content {{
            display: none;
            padding: 15px;
        }}
        
        .feature-content.active {{
            display: block;
        }}
        
        .scenario {{
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            overflow: hidden;
        }}
        
        .scenario-header {{
            padding: 12px;
            background: #f0f0f0;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        
        .scenario-header:hover {{
            background: #e8e8e8;
        }}
        
        .scenario-status {{
            padding: 4px 12px;
            border-radius: 15px;
            font-size: 0.85em;
            font-weight: bold;
            color: white;
        }}
        
        .scenario-status.passed {{ background: #27ae60; }}
        .scenario-status.failed {{ background: #e74c3c; }}
        .scenario-status.skipped {{ background: #f39c12; }}
        
        .scenario-content {{
            display: none;
            padding: 12px;
            background: #fafafa;
        }}
        
        .scenario-content.active {{
            display: block;
        }}
        
        .step {{
            margin-bottom: 8px;
            padding: 10px;
            border-radius: 6px;
            border-left: 4px solid #ccc;
        }}
        
        .step.passed {{
            background: #d5f4e6;
            border-left-color: #27ae60;
        }}
        
        .step.failed {{
            background: #fadbd8;
            border-left-color: #e74c3c;
        }}
        
        .step.skipped {{
            background: #fef9e7;
            border-left-color: #f39c12;
        }}
        
        .step-name {{
            font-weight: 500;
            margin-bottom: 5px;
        }}
        
        .step-error {{
            background: #fadbd8;
            padding: 8px;
            margin-top: 8px;
            border-radius: 4px;
            font-family: monospace;
            font-size: 0.9em;
            color: #c0392b;
        }}
        
        .step-screenshot {{
            margin-top: 8px;
            padding: 8px;
            background: rgba(255, 255, 255, 0.5);
            border-radius: 4px;
            border-left: 3px solid #3498db;
        }}
        
        .step-screenshot img {{
            max-width: 200px;
            max-height: 150px;
            border-radius: 4px;
            cursor: pointer;
            border: 1px solid #ddd;
        }}
        
        .modal {{
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.9);
            overflow: auto;
        }}
        
        .modal-content {{
            margin: auto;
            display: block;
            max-width: 90%;
            max-height: 90vh;
            margin-top: 5%;
        }}
        
        .close {{
            position: fixed;
            top: 20px;
            right: 40px;
            color: #f1f1f1;
            font-size: 40px;
            font-weight: bold;
            cursor: pointer;
            z-index: 1001;
        }}
        
        .close:hover {{
            color: #bbb;
        }}
        
        @media (max-width: 768px) {{
            .header h1 {{ font-size: 1.8em; }}
            .summary {{ grid-template-columns: 1fr; }}
            .chart-and-stats {{ flex-direction: column; }}
            .mini-chart {{ width: 100px; height: 100px; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Reporte Unificado de Pruebas</h1>
            <div class="subtitle">Consolidación de ejecuciones paralelas</div>
"""
    def _get_html_body(self, exec_times: Dict[str, Any]) -> str:
        """Retorna el body HTML con los datos agregados."""
        body = f"""
            <div class="info-grid">
                <div class="info-item">
                    <span class="info-label">🕐 Inicio</span>
                    <span class="info-value">{exec_times['start']}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">🏁 Fin</span>
                    <span class="info-value">{exec_times['end']}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">⏱️ Duración Total</span>
                    <span class="info-value">{exec_times['duration']}s</span>
                </div>
                <div class="info-item">
                    <span class="info-label">📊 Workers</span>
                    <span class="info-value">{len(self.reports_data)}</span>
                </div>
            </div>
        </div>
        
        <div class="summary">
            <div class="summary-card">
                <h3>📁 Features</h3>
                <div class="chart-and-stats">
                    <div class="mini-chart">
                        <canvas id="featuresChart" width="120" height="120"></canvas>
                    </div>
                    <div class="summary-stats">
                        <div class="stat">
                            <div class="stat-number passed">{self.unified_summary['features']['passed']}</div>
                            <div class="stat-label">Passed</div>
                        </div>
                        <div class="stat">
                            <div class="stat-number failed">{self.unified_summary['features']['failed']}</div>
                            <div class="stat-label">Failed</div>
                        </div>
                        <div class="stat">
                            <div class="stat-number skipped">{self.unified_summary['features']['skipped']}</div>
                            <div class="stat-label">Skipped</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="summary-card">
                <h3>🎬 Scenarios</h3>
                <div class="chart-and-stats">
                    <div class="mini-chart">
                        <canvas id="scenariosChart" width="120" height="120"></canvas>
                    </div>
                    <div class="summary-stats">
                        <div class="stat">
                            <div class="stat-number passed">{self.unified_summary['scenarios']['passed']}</div>
                            <div class="stat-label">Passed</div>
                        </div>
                        <div class="stat">
                            <div class="stat-number failed">{self.unified_summary['scenarios']['failed']}</div>
                            <div class="stat-label">Failed</div>
                        </div>
                        <div class="stat">
                            <div class="stat-number skipped">{self.unified_summary['scenarios']['skipped']}</div>
                            <div class="stat-label">Skipped</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="summary-card">
                <h3>👣 Steps</h3>
                <div class="chart-and-stats">
                    <div class="mini-chart">
                        <canvas id="stepsChart" width="120" height="120"></canvas>
                    </div>
                    <div class="summary-stats">
                        <div class="stat">
                            <div class="stat-number passed">{self.unified_summary['steps']['passed']}</div>
                            <div class="stat-label">Passed</div>
                        </div>
                        <div class="stat">
                            <div class="stat-number failed">{self.unified_summary['steps']['failed']}</div>
                            <div class="stat-label">Failed</div>
                        </div>
                        <div class="stat">
                            <div class="stat-number skipped">{self.unified_summary['steps']['skipped']}</div>
                            <div class="stat-label">Skipped</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="features-section">
            <h2>Resultados por Worker</h2>
            {self._get_features_html()}
        </div>
"""
        return body

    def _get_features_html(self) -> str:
        """Genera el HTML de features agrupados por worker."""
        html = ""
        for idx, report in enumerate(self.reports_data, 1):
            worker_name = report.get("_source_file", f"Worker {idx}")
            html += f'<div class="worker-group"><div class="worker-header">📦 {worker_name}</div>'
            
            if "features" in report:
                for feature in report["features"]:
                    html += self._get_feature_html(feature)
            
            html += "</div>"
        
        return html

    def _get_feature_html(self, feature: Dict[str, Any]) -> str:
        """Genera el HTML de un feature."""
        feature_name = feature.get("name", "Unknown Feature")
        feature_status = feature.get("status", "unknown")
        
        html = f"""
        <div class="feature">
            <div class="feature-header" onclick="toggleFeature(this)">
                <span>{feature_name}</span>
                <span class="feature-status {feature_status}">{feature_status.upper()}</span>
            </div>
            <div class="feature-content">
"""
        
        if "scenarios" in feature:
            for scenario in feature["scenarios"]:
                html += self._get_scenario_html(scenario)
        
        html += """
            </div>
        </div>
"""
        return html

    def _get_scenario_html(self, scenario: Dict[str, Any]) -> str:
        """Genera el HTML de un scenario."""
        scenario_name = scenario.get("name", "Unknown Scenario")
        scenario_status = scenario.get("status", "unknown")
        
        html = f"""
        <div class="scenario">
            <div class="scenario-header" onclick="toggleScenario(this)">
                <span>{scenario_name}</span>
                <span class="scenario-status {scenario_status}">{scenario_status.upper()}</span>
            </div>
            <div class="scenario-content">
"""
        
        if "steps" in scenario:
            for step in scenario["steps"]:
                html += self._get_step_html(step)
        
        html += """
            </div>
        </div>
"""
        return html

    def _get_step_html(self, step: Dict[str, Any]) -> str:
        """Genera el HTML de un step."""
        step_name = step.get("name", "Unknown Step")
        step_status = step.get("status", "unknown")
        error_msg = step.get("error_message")
        screenshot = step.get("screenshot")
        
        html = f'<div class="step {step_status}"><div class="step-name">✓ {step_name}</div>'
        
        if error_msg:
            html += f'<div class="step-error">{error_msg}</div>'
        
        if screenshot:
            try:
                img_data = screenshot if isinstance(screenshot, str) else screenshot
                html += f'<div class="step-screenshot"><img src="data:image/png;base64,{img_data}" onclick="showModal(this)"></div>'
            except Exception:
                pass
        
        html += "</div>"
        return html

    def _get_html_footer(self) -> str:
        """Retorna el footer HTML con scripts."""
        features_data = json.dumps(self._get_chart_data("features"))
        scenarios_data = json.dumps(self._get_chart_data("scenarios"))
        steps_data = json.dumps(self._get_chart_data("steps"))
        
        return f"""
    </div>
    
    <div id="imageModal" class="modal">
        <span class="close" onclick="closeModal()">&times;</span>
        <img class="modal-content" id="modalImage">
    </div>
    
    <script>
        function toggleFeature(element) {{
            const content = element.nextElementSibling;
            content.classList.toggle('active');
        }}
        
        function toggleScenario(element) {{
            const content = element.nextElementSibling;
            content.classList.toggle('active');
        }}
        
        function showModal(img) {{
            const modal = document.getElementById('imageModal');
            const modalImg = document.getElementById('modalImage');
            modal.style.display = 'block';
            modalImg.src = img.src;
        }}
        
        function closeModal() {{
            document.getElementById('imageModal').style.display = 'none';
        }}
        
        window.onclick = function(event) {{
            const modal = document.getElementById('imageModal');
            if (event.target == modal) {{
                modal.style.display = 'none';
            }}
        }}
        
        // Gráficos
        const featuresCtx = document.getElementById('featuresChart').getContext('2d');
        new Chart(featuresCtx, {{
            type: 'doughnut',
            data: {features_data},
            options: {{
                responsive: true,
                maintainAspectRatio: true,
                plugins: {{ legend: {{ display: false }} }}
            }}
        }});
        
        const scenariosCtx = document.getElementById('scenariosChart').getContext('2d');
        new Chart(scenariosCtx, {{
            type: 'doughnut',
            data: {scenarios_data},
            options: {{
                responsive: true,
                maintainAspectRatio: true,
                plugins: {{ legend: {{ display: false }} }}
            }}
        }});
        
        const stepsCtx = document.getElementById('stepsChart').getContext('2d');
        new Chart(stepsCtx, {{
            type: 'doughnut',
            data: {steps_data},
            options: {{
                responsive: true,
                maintainAspectRatio: true,
                plugins: {{ legend: {{ display: false }} }}
            }}
        }});
    </script>
</body>
</html>
"""

    def _get_chart_data(self, chart_type: str) -> Dict[str, Any]:
        """Genera los datos para los gráficos."""
        data = self.unified_summary[chart_type]
        return {
            "labels": ["Passed", "Failed", "Skipped"],
            "datasets": [
                {
                    "data": [data["passed"], data["failed"], data["skipped"]],
                    "backgroundColor": ["#27ae60", "#e74c3c", "#f39c12"],
                    "borderColor": ["#229954", "#c0392b", "#d68910"],
                    "borderWidth": 2,
                }
            ],
        }
