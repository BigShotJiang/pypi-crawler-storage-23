#!/usr/bin/env python3
"""
Integración del HTML Reporter con Behave
Captura automáticamente datos durante la ejecución de pruebas
"""
import os
import re
from pathlib import Path
from datetime import datetime
from .html_reporter import html_reporter

def clean_filename(filename: str, max_length: int = 50) -> str:
    """
    Limpia un nombre de archivo removiendo caracteres inválidos para Windows
    """
    # Caracteres inválidos en Windows: < > : " | ? * \ /
    invalid_chars = r'[<>:"|?*\\/]'
    
    # Reemplazar caracteres inválidos con guión bajo
    clean_name = re.sub(invalid_chars, '_', filename)
    
    # Reemplazar espacios con guión bajo
    clean_name = clean_name.replace(' ', '_')
    
    # Remover múltiples guiones bajos consecutivos
    clean_name = re.sub(r'_+', '_', clean_name)
    
    # Remover guiones bajos al inicio y final
    clean_name = clean_name.strip('_')
    
    # Limitar longitud
    if len(clean_name) > max_length:
        clean_name = clean_name[:max_length].rstrip('_')
    
    return clean_name

def setup_html_reporting(context):
    """Configura el reporte HTML en el contexto de Behave"""
    # Obtener configuración del navegador
    browser = 'chromium'
    if hasattr(context, 'framework_config') and context.framework_config:
        browser = context.framework_config.config.get('browser', 'chromium')
    
    # Iniciar tracking de ejecución
    html_reporter.start_execution(browser=browser, environment='test')
    
    # Guardar referencia en el contexto
    context.html_reporter = html_reporter

def before_feature_html(context, feature):
    """Hook para inicio de feature"""
    if hasattr(context, 'html_reporter'):
        tags = [tag for tag in feature.tags] if hasattr(feature, 'tags') else []
        context.html_reporter.start_feature(
            feature_name=feature.name,
            feature_description=feature.description or "",
            tags=tags
        )

def after_feature_html(context, feature):
    """Hook para fin de feature"""
    if hasattr(context, 'html_reporter'):
        context.html_reporter.end_feature()

def before_scenario_html(context, scenario):
    """Hook para inicio de scenario"""
    if hasattr(context, 'html_reporter'):
        tags = [tag for tag in scenario.tags] if hasattr(scenario, 'tags') else []
        context.html_reporter.start_scenario(
            scenario_name=scenario.name,
            tags=tags
        )

def after_scenario_html(context, scenario):
    """Hook para fin de scenario"""
    if hasattr(context, 'html_reporter'):
        status = 'passed'
        error_message = None
        
        # Verificar si el scenario falló o tuvo error
        if scenario.status.name in ('failed', 'error'):
            status = 'failed'
            if hasattr(scenario, 'exception') and scenario.exception:
                error_message = str(scenario.exception)
        elif scenario.status.name == 'skipped':
            status = 'skipped'
        
        # Capturar screenshot si el scenario falló o tuvo error
        if status == 'failed' and hasattr(context, 'page') and context.page:
            try:
                screenshot_dir = Path(os.getenv('SCREENSHOTS_DIR', 'screenshots'))
                screenshot_dir.mkdir(exist_ok=True)
                
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                scenario_name = clean_filename(scenario.name, 50)
                screenshot_name = f"FAILED_{scenario_name}_{timestamp}.png"
                screenshot_path = screenshot_dir / screenshot_name
                
                full_page = os.getenv('SCREENSHOT_FULL_PAGE', 'true').lower() == 'true'
                context.page.screenshot(
                    path=str(screenshot_path),
                    full_page=full_page,  # Configurable: página completa o viewport
                    type='png'
                )
                
                # Debug: Verificar que el archivo se creó
                if os.path.exists(str(screenshot_path)):
                    print(f"📸 Screenshot de fallo capturado: {screenshot_path}")
                    context.html_reporter.add_screenshot(
                        str(screenshot_path), 
                        f"Screenshot del fallo: {scenario.name}"
                    )
                else:
                    print(f"❌ Error: Screenshot de fallo no se creó: {screenshot_path}")
                    
            except Exception as e:
                print(f"❌ Error capturando screenshot de fallo: {e}")
                import traceback
                traceback.print_exc()
        
        context.html_reporter.end_scenario(status=status, error_message=error_message)

def after_step_html(context, step):
    """Hook para después de cada step"""
    if hasattr(context, 'html_reporter'):
        status = 'passed'
        error_message = None
        screenshot_path = None
        step_data = None
        
        # Verificar si el step falló o tuvo error
        if step.status.name in ('failed', 'error'):
            status = 'failed'
            if hasattr(step, 'exception') and step.exception:
                error_message = str(step.exception)
        elif step.status.name == 'skipped':
            status = 'skipped'
        elif step.status.name == 'undefined':
            status = 'undefined'
        
        # Capturar step_data si existe (para steps sin navegador: API, semántica, Gemini)
        if hasattr(context, 'current_step_data') and context.current_step_data:
            step_data = context.current_step_data
            # Limpiar para el siguiente step
            context.current_step_data = None
        
        # Capturar screenshot para cada step (opcional, configurable)
        if hasattr(context, 'page') and context.page:
            try:
                # Solo capturar si está habilitado en configuración
                capture_all_steps = os.getenv('HTML_REPORT_CAPTURE_ALL_STEPS', 'false').lower() == 'true'
                
                if capture_all_steps or status == 'failed':
                    screenshot_dir = Path(os.getenv('SCREENSHOTS_DIR', 'screenshots'))
                    screenshot_dir.mkdir(exist_ok=True)
                    
                    step_name = clean_filename(step.name, 50)
                    timestamp = datetime.now().strftime("%H%M%S")
                    screenshot_name = f"step_{step.line}_{step_name}_{timestamp}.png"
                    screenshot_path = screenshot_dir / screenshot_name
                    
                    full_page = os.getenv('SCREENSHOT_FULL_PAGE', 'true').lower() == 'true'
                    
                    try:
                        # Intentar tomar screenshot con timeout de 15 segundos
                        context.page.screenshot(
                            path=str(screenshot_path),
                            full_page=full_page,
                            type='png',
                            timeout=15000  # 15 segundos
                        )
                        
                        # Verificar que el archivo se creó
                        if os.path.exists(screenshot_path):
                            print(f"📸 Screenshot capturado para step: {screenshot_path}")
                            screenshot_path = str(screenshot_path)
                        else:
                            print(f"⚠️ Screenshot no se creó: {screenshot_path}")
                            screenshot_path = None
                            
                    except Exception as screenshot_error:
                        # Si el screenshot falla (timeout, error, etc.), continuar sin screenshot
                        print(f"⚠️ No se pudo capturar screenshot: {type(screenshot_error).__name__}")
                        screenshot_path = None
                        
            except Exception as e:
                print(f"⚠️ Error en captura de screenshot: {e}")
                screenshot_path = None
        
        context.html_reporter.add_step(
            step_name=step.name,
            status=status,
            error_message=error_message,
            screenshot_path=screenshot_path,
            step_data=step_data
        )

def generate_html_report(context, report_name: str = None):
    """Genera el reporte HTML final con nombre basado en el primer tag del escenario"""
    if hasattr(context, 'html_reporter'):
        if not report_name:
            from datetime import datetime
            
            # Obtener el primer tag del primer escenario ejecutado
            first_tag = None
            if hasattr(context, 'html_reporter') and hasattr(context.html_reporter, 'scenarios'):
                for scenario_data in context.html_reporter.scenarios:
                    if scenario_data.get('tags'):
                        # Buscar el primer tag que parezca un issue key (formato: XXXX-123)
                        import re
                        for tag in scenario_data['tags']:
                            if re.match(r'^[A-Z]+-\d+$', tag):
                                first_tag = tag
                                break
                        if first_tag:
                            break
            
            # Generar timestamp en formato ddmmyyyy_hhmm
            timestamp = datetime.now().strftime("%d%m%Y_%H%M")
            
            # Construir nombre del reporte
            if first_tag:
                report_name = f"Reporte_{first_tag}_{timestamp}.html"
            else:
                # Fallback al formato anterior si no hay tags
                report_name = f"test_report_{timestamp}.html"
        
        report_path = context.html_reporter.generate_report(report_name)
        print(f"📊 Reporte HTML generado: {report_path}")
        return report_path
    return None

def add_screenshot_to_report(context, screenshot_path: str, description: str = ""):
    """Agrega un screenshot manual al reporte"""
    if hasattr(context, 'html_reporter'):
        context.html_reporter.add_screenshot(screenshot_path, description)