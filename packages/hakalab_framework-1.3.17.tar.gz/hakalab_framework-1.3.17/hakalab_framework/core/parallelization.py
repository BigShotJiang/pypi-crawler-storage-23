"""
Módulo de paralelización para distribución de features en CI/CD
Proporciona funcionalidad nativa para dividir features entre shards
"""

import os
import math
import re
from pathlib import Path
from typing import List, Optional


def get_feature_files(feature_dir: str = 'features') -> List[str]:
    """
    Obtiene lista de todos los feature files ordenados.
    
    Args:
        feature_dir: Directorio donde buscar los archivos .feature
        
    Returns:
        Lista de rutas de feature files ordenadas alfabéticamente
    """
    feature_path = Path(feature_dir)
    if not feature_path.exists():
        return []
    
    features = sorted([str(f) for f in feature_path.glob('**/*.feature')])
    return features


def _filter_features_by_tag(features: List[str], tag: str) -> List[str]:
    """
    Filtra features que contienen un tag específico.
    
    Args:
        features: Lista de rutas de feature files
        tag: Tag a buscar (ej: '@PROD-145')
        
    Returns:
        Lista de features que contienen el tag
    """
    filtered = []
    tag_pattern = re.compile(r'^\s*' + re.escape(tag) + r'\b', re.MULTILINE)
    
    for feature_file in features:
        try:
            with open(feature_file, 'r', encoding='utf-8') as f:
                content = f.read()
                if tag_pattern.search(content):
                    filtered.append(feature_file)
        except Exception as e:
            print(f"[WARNING] Error leyendo {feature_file}: {e}")
    
    return filtered


def get_features_selection(feature_dir: str = 'features', tag: Optional[str] = None) -> List[str]:
    """
    Divide feature files entre shards para paralelización en CI.
    
    Si hay variables de CI (SHARD_INDEX y TOTAL_SHARDS), reparte features.
    Si es local, devuelve el directorio completo para ejecutar todos.
    
    Si se especifica un tag, solo considera features que lo contienen.
    
    Args:
        feature_dir: Directorio donde buscar los archivos .feature
        tag: Tag opcional para filtrar features (ej: '@PROD-145')
        
    Returns:
        Lista de features o directorio a ejecutar
    """
    shard_index = os.getenv('SHARD_INDEX')
    total_shards = os.getenv('TOTAL_SHARDS')
    
    # Obtener todos los features
    all_features = get_feature_files(feature_dir)
    
    # Filtrar por tag si se especifica
    if tag:
        all_features = _filter_features_by_tag(all_features, tag)
        if not all_features:
            print(f"[WARNING] No se encontraron features con el tag {tag}")
            return []
    
    # Modo LOCAL - ejecutar todos los features (o los filtrados por tag)
    if not shard_index or not total_shards:
        if tag:
            return all_features
        return [feature_dir]
    
    # Modo CI - dividir features entre shards
    shard_index = int(shard_index)
    total_shards = int(total_shards)
    
    total_features = len(all_features)
    
    if total_features == 0:
        print("[WARNING] No se encontraron feature files")
        return []
    
    # Calcular rango de features para este shard
    per_shard = math.ceil(total_features / total_shards)
    start = (shard_index - 1) * per_shard
    end = start + per_shard
    shard_features = all_features[start:end]
    
    print(f"[SHARD] {shard_index}/{total_shards} | Features: {len(shard_features)}/{total_features}")
    print(f"[SHARD] Archivos: {shard_features}")
    
    return shard_features if shard_features else []
