#!/usr/bin/env python3
"""
Database Manager - Gestor de conexiones a bases de datos
Soporta SQLite, MySQL y PostgreSQL con configuración desde variables de entorno
"""

import os
import sqlite3
import logging
from typing import Dict, Any, Optional, List
from pathlib import Path

try:
    import mysql.connector
    MYSQL_AVAILABLE = True
except ImportError:
    MYSQL_AVAILABLE = False

try:
    import psycopg2
    import psycopg2.extras
    POSTGRESQL_AVAILABLE = True
except ImportError:
    POSTGRESQL_AVAILABLE = False


class DatabaseManager:
    """Manager para conexiones a bases de datos con múltiples engines"""
    
    def __init__(self):
        self.logger = logging.getLogger('hakalab_framework.database')
        self.connection = None
        self.cursor = None
        self.db_type = None
        
    def connect_from_env(self, db_name: Optional[str] = None) -> bool:
        """Conecta a la base de datos usando configuración del .env"""
        db_type = os.getenv('DB_TYPE', 'sqlite').lower()
        
        if db_type == 'sqlite':
            return self.connect_sqlite_from_env(db_name)
        elif db_type == 'mysql':
            return self.connect_mysql_from_env()
        elif db_type == 'postgresql':
            return self.connect_postgresql_from_env()
        else:
            self.logger.error(f"Tipo de base de datos no soportado: {db_type}")
            return False
    
    def connect_sqlite_from_env(self, db_name: Optional[str] = None) -> bool:
        """Conecta a SQLite usando configuración del .env"""
        if db_name:
            db_path = db_name
        else:
            db_path = os.getenv('DB_SQLITE_PATH', 'test_data/test.db')
        
        return self.connect_sqlite(db_path)
    
    def connect_sqlite(self, db_path: str) -> bool:
        """Conecta a una base de datos SQLite"""
        try:
            # Crear directorio si no existe
            db_dir = Path(db_path).parent
            db_dir.mkdir(parents=True, exist_ok=True)
            
            timeout = float(os.getenv('DB_SQLITE_TIMEOUT', '30'))
            
            self.connection = sqlite3.connect(db_path, timeout=timeout)
            self.connection.row_factory = sqlite3.Row  # Para acceso por nombre de columna
            self.cursor = self.connection.cursor()
            self.db_type = 'sqlite'
            
            self.logger.info(f"Conectado a SQLite: {db_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error conectando a SQLite {db_path}: {e}")
            return False
    
    def connect_mysql_from_env(self) -> bool:
        """Conecta a MySQL usando configuración del .env"""
        if not MYSQL_AVAILABLE:
            self.logger.error("MySQL no está disponible. Instala: pip install mysql-connector-python")
            return False
        
        config = {
            'host': os.getenv('DB_MYSQL_HOST', 'localhost'),
            'port': int(os.getenv('DB_MYSQL_PORT', '3306')),
            'database': os.getenv('DB_MYSQL_DATABASE', 'test_db'),
            'user': os.getenv('DB_MYSQL_USERNAME', 'test_user'),
            'password': os.getenv('DB_MYSQL_PASSWORD', 'test_password'),
            'charset': os.getenv('DB_MYSQL_CHARSET', 'utf8mb4'),
            'connection_timeout': int(os.getenv('DB_CONNECTION_TIMEOUT', '30'))
        }
        
        return self.connect_mysql(config)
    
    def connect_mysql(self, config: Dict[str, Any]) -> bool:
        """Conecta a MySQL con configuración específica"""
        try:
            self.connection = mysql.connector.connect(**config)
            self.cursor = self.connection.cursor(dictionary=True)
            self.db_type = 'mysql'
            
            self.logger.info(f"Conectado a MySQL: {config['host']}:{config['port']}/{config['database']}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error conectando a MySQL: {e}")
            return False
    
    def connect_postgresql_from_env(self) -> bool:
        """Conecta a PostgreSQL usando configuración del .env"""
        if not POSTGRESQL_AVAILABLE:
            self.logger.error("PostgreSQL no está disponible. Instala: pip install psycopg2-binary")
            return False
        
        config = {
            'host': os.getenv('DB_POSTGRES_HOST', 'localhost'),
            'port': int(os.getenv('DB_POSTGRES_PORT', '5432')),
            'database': os.getenv('DB_POSTGRES_DATABASE', 'test_db'),
            'user': os.getenv('DB_POSTGRES_USERNAME', 'test_user'),
            'password': os.getenv('DB_POSTGRES_PASSWORD', 'test_password'),
            'connect_timeout': int(os.getenv('DB_CONNECTION_TIMEOUT', '30'))
        }
        
        return self.connect_postgresql(config)
    
    def connect_postgresql(self, config: Dict[str, Any]) -> bool:
        """Conecta a PostgreSQL con configuración específica"""
        try:
            self.connection = psycopg2.connect(**config)
            self.cursor = self.connection.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            self.db_type = 'postgresql'
            
            self.logger.info(f"Conectado a PostgreSQL: {config['host']}:{config['port']}/{config['database']}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error conectando a PostgreSQL: {e}")
            return False
    
    def execute_query(self, query: str, params: Optional[tuple] = None) -> List[Dict]:
        """Ejecuta una consulta SELECT y retorna los resultados"""
        if not self.cursor:
            raise Exception("No hay conexión a base de datos")
        
        debug_queries = os.getenv('DB_DEBUG_QUERIES', 'false').lower() == 'true'
        if debug_queries:
            self.logger.info(f"Ejecutando query: {query}")
            if params:
                self.logger.info(f"Parámetros: {params}")
        
        try:
            if params:
                self.cursor.execute(query, params)
            else:
                self.cursor.execute(query)
            
            results = self.cursor.fetchall()
            
            # Convertir a lista de diccionarios según el tipo de BD
            if self.db_type == 'sqlite':
                return [dict(row) for row in results]
            elif self.db_type in ['mysql', 'postgresql']:
                return list(results)
            
            return results
            
        except Exception as e:
            self.logger.error(f"Error ejecutando query: {e}")
            raise
    
    def execute_update(self, query: str, params: Optional[tuple] = None) -> int:
        """Ejecuta una consulta de actualización (INSERT, UPDATE, DELETE)"""
        if not self.cursor:
            raise Exception("No hay conexión a base de datos")
        
        debug_queries = os.getenv('DB_DEBUG_QUERIES', 'false').lower() == 'true'
        if debug_queries:
            self.logger.info(f"Ejecutando update: {query}")
            if params:
                self.logger.info(f"Parámetros: {params}")
        
        try:
            if params:
                self.cursor.execute(query, params)
            else:
                self.cursor.execute(query)
            
            # Auto-commit si está habilitado
            auto_commit = os.getenv('DB_AUTO_COMMIT', 'true').lower() == 'true'
            if auto_commit:
                self.connection.commit()
            
            return self.cursor.rowcount
            
        except Exception as e:
            self.logger.error(f"Error ejecutando update: {e}")
            raise
    
    def commit(self):
        """Confirma las transacciones pendientes"""
        if self.connection:
            self.connection.commit()
    
    def rollback(self):
        """Revierte las transacciones pendientes"""
        if self.connection:
            self.connection.rollback()
    
    def close(self):
        """Cierra la conexión a la base de datos"""
        if self.cursor:
            self.cursor.close()
            self.cursor = None
        
        if self.connection:
            self.connection.close()
            self.connection = None
        
        self.db_type = None
        self.logger.info("Conexión a base de datos cerrada")
    
    def create_test_database(self, db_name: str = None):
        """Crea una base de datos de prueba con datos de ejemplo"""
        if self.db_type == 'sqlite':
            self._create_sqlite_test_data()
        elif self.db_type == 'mysql':
            self._create_mysql_test_data()
        elif self.db_type == 'postgresql':
            self._create_postgresql_test_data()
    
    def _create_sqlite_test_data(self):
        """Crea datos de prueba para SQLite"""
        try:
            # Crear tabla de usuarios
            self.execute_update("""
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    email TEXT UNIQUE NOT NULL,
                    age INTEGER,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Crear tabla de productos
            self.execute_update("""
                CREATE TABLE IF NOT EXISTS products (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    price DECIMAL(10,2),
                    category TEXT,
                    in_stock BOOLEAN DEFAULT 1
                )
            """)
            
            # Insertar datos de prueba
            users_data = [
                ("Juan Pérez", "juan@example.com", 30),
                ("María García", "maria@example.com", 25),
                ("Carlos López", "carlos@example.com", 35)
            ]
            
            for user in users_data:
                self.execute_update(
                    "INSERT OR IGNORE INTO users (name, email, age) VALUES (?, ?, ?)",
                    user
                )
            
            products_data = [
                ("Laptop", 999.99, "Electronics", 1),
                ("Mouse", 29.99, "Electronics", 1),
                ("Desk", 199.99, "Furniture", 0)
            ]
            
            for product in products_data:
                self.execute_update(
                    "INSERT OR IGNORE INTO products (name, price, category, in_stock) VALUES (?, ?, ?, ?)",
                    product
                )
            
            self.logger.info("Datos de prueba creados para SQLite")
            
        except Exception as e:
            self.logger.error(f"Error creando datos de prueba SQLite: {e}")
            raise
    
    def backup_database(self, backup_path: str):
        """Hace backup de la base de datos"""
        backup_dir = os.getenv('DB_BACKUP_DIR', 'test_data/backups')
        os.makedirs(backup_dir, exist_ok=True)
        
        full_backup_path = os.path.join(backup_dir, backup_path)
        
        if self.db_type == 'sqlite':
            self._backup_sqlite(full_backup_path)
        else:
            self.logger.warning(f"Backup no implementado para {self.db_type}")
    
    def _backup_sqlite(self, backup_path: str):
        """Hace backup de SQLite"""
        try:
            with open(backup_path, 'w') as f:
                for line in self.connection.iterdump():
                    f.write('%s\n' % line)
            
            self.logger.info(f"Backup SQLite guardado en: {backup_path}")
            
        except Exception as e:
            self.logger.error(f"Error haciendo backup SQLite: {e}")
            raise