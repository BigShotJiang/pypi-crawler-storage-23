HAKALAB FRAMEWORK - AUTOMATIZACIÓN DE PRUEBAS AVANZADA
=====================================================

Un framework completo y profesional de pruebas funcionales que utiliza Playwright 
para automatización web moderna y Behave para BDD (Behavior Driven Development). 
Diseñado para casos de uso empresariales con capacidades avanzadas de simulación 
humana, procesamiento de datos e integración completa con Jira y Xray.

CARACTERÍSTICAS PRINCIPALES v1.2.23+
====================================

Core Features:
- Playwright: Automatización web moderna, rápida y confiable
- Behave: Framework BDD para Python con soporte completo para Gherkin
- Multiidioma: Soporte para pasos en inglés, español o mixto
- Page Object Model: Elementos organizados en archivos JSON
- Variables Dinámicas: Sistema completo de manejo y generación de variables
- Reportes HTML: Reportes HTML personalizados con screenshots integrados
- Scenario Outlines: Soporte completo para pruebas parametrizadas

Nuevas Funcionalidades v1.2.23+:
- Integración Jira/Xray: Integración completa con Jira y Xray Cloud para trazabilidad automática
- Flujo Optimizado Xray: Una sola llamada API crea Test Execution con todos los tests y actualiza estados
- Procesamiento CSV: Carga, análisis, filtrado y manipulación de archivos CSV
- Entrada Avanzada: Simulación de escritura humana con errores y velocidades variables
- Control de Tiempos: Cronómetros, esperas inteligentes y medición de rendimiento
- Variables Mejoradas: Generación automática de texto, números, fechas y timestamps
- Simulación Realista: Comportamiento humano con delays aleatorios y errores simulados
- Medición de Rendimiento: Cronometraje de operaciones críticas

Integración Jira/Xray v1.2.23+:
- Adjunto Automático: Reportes HTML se adjuntan automáticamente a issues de Jira
- Test Executions: Creación automática de Test Executions en Xray con todos los tests
- Estados Automáticos: Mapeo automático de resultados (passed/failed/skipped)
- Vinculación HU: Test Executions se vinculan automáticamente a Historias de Usuario
- Control Granular: Variables de entorno para habilitar/deshabilitar integraciones
- Validación Automática: Solo procesa issues de tipo "Test" válidas
- Flujo Optimizado: Una sola llamada API para crear, adjuntar y actualizar estados

INSTALACIÓN
===========

Instalación desde GitHub (Recomendada):
pip install git+https://github.com/hakalab/hakalab-framework.git
python -m playwright install
hakalab-init my-project
cd my-project
behave

Instalación de Versión Específica:
pip install git+https://github.com/hakalab/hakalab-framework.git@v1.2.23
python -m playwright install

Instalación en Modo Desarrollo:
git clone https://github.com/hakalab/hakalab-framework.git
cd hakalab-framework
pip install -e .
python -m playwright install

USO DEL FRAMEWORK
=================

Configuración Inicial:
cp .env.example .env

Ejecutar Pruebas:
behave
behave --tags=@smoke
behave --tags=@login,@regression
behave features/example_login.feature
behave -f html -o html-reports/report.html
behave --no-capture
BROWSER=firefox behave
HEADLESS=true behave

Generar Reportes:
Los reportes HTML se generan automáticamente en html-reports/
open html-reports/report.html  # Mac
start html-reports/report.html # Windows
xdg-open html-reports/report.html # Linux

CONFIGURACIÓN AVANZADA
======================

Variables de Entorno (.env):

# === CONFIGURACIÓN DEL NAVEGADOR ===
BROWSER=chromium              # chromium, firefox, webkit
HEADLESS=false               # true/false
TIMEOUT=30000                # Timeout en milisegundos
WINDOW_SIZE=1920,1080        # Tamaño de ventana

# === RUTAS Y DIRECTORIOS ===
JSON_POMS_PATH=json_poms     # Carpeta de Page Objects
SCREENSHOTS_DIR=screenshots   # Directorio de screenshots
HTML_REPORTS_DIR=html-reports # Directorio de reportes HTML
DOWNLOADS_DIR=downloads       # Directorio de descargas
VIDEOS_DIR=videos            # Directorio de videos

# === FUNCIONALIDADES AVANZADAS ===
HTML_REPORT_CAPTURE_ALL_STEPS=true  # Screenshots en cada step
SCREENSHOT_FULL_PAGE=true            # Screenshots de página completa
VIDEO_RECORDING=false                # Grabación de video
CLEANUP_OLD_FILES=true               # Limpieza automática
CLEANUP_MAX_AGE_HOURS=24            # Edad máxima de archivos

# === VARIABLES DE PRUEBA ===
BASE_URL=https://example.com
TEST_EMAIL=test@example.com
TEST_PASSWORD=password123
API_KEY=your-api-key-here
DATABASE_URL=postgresql://localhost/testdb

# === INTEGRACIÓN JIRA Y XRAY ===
JIRA_ENABLED=true                           # true=habilitar Jira
JIRA_URL=https://hakalab.atlassian.net
JIRA_EMAIL=felipe.farias@hakalab.com
JIRA_TOKEN=ATATT3xFfGF0DWFjw9A1O4PHPyHbOz0Ntqaj7-yWjwm0w5OernZnl0OtsXfxK1sd9foBaPKUY90WLSCseC8OS5dHmqWaV0PKTOqDKj_SIq4R_n-HHUVBzb0dRCUS2Hwv6ZjQE6LS02dc5vLNYQZuxS941J6bwRyJSgMF28ZMyrjzciCjtDSWm7k=1E898852
JIRA_PROJECT=PROD                           # Clave del proyecto
JIRA_COMMENT_MESSAGE=Reporte prueba de QA   # Mensaje para comentarios
XRAY_ENABLED=true                          # true=habilitar Xray
XRAY_TEST_PLAN=                            # Opcional: Test Plan
XRAY_AUTHORIZATION_TOKEN=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZW5hbnQiOiIyNjI1MGIzNC04YTMyLTNiZWMtOGI1MC04MjljZGJkNmMwMDciLCJhY2NvdW50SWQiOiI1ZmIyOTFiYWRkMGM1OTAwNzU5MWVhOWYiLCJpc1hlYSI6ZmFsc2UsImlhdCI6MTc2Nzk3MTg2NSwiZXhwIjoxNzY4MDU4MjY1LCJhdWQiOiIzRUJBM0IyRjA2MEI0Q0Q3QjRFQzE4NzgwQ0M1MDBFNyIsImlzcyI6ImNvbS54cGFuZGl0LnBsdWdpbnMueHJheSIsInN1YiI6IjNFQkEzQjJGMDYwQjRDRDdCNEVDMTg3ODBDQzUwMEU3In0.7HStiUpL2C7edzUDALpPHFQfJOxn8WzD6DLT3BLxva0
XRAY_BASE_URL=https://xray.cloud.getxray.app

# === DEBUG Y DESARROLLO ===
HAKALAB_SHOW_STEPS=false     # Mostrar carga de steps
DEBUG_MODE=false             # Modo debug
SLOW_MO=0                    # Delay entre acciones (ms)

Configuración de Behave (behave.ini):

[behave]
paths = features
format = html
outdir = html-reports
show_timings = true
logging_level = INFO
show_skipped = false
show_multiline = true
color = true

[behave.formatters]
html = hakalab_framework.core.behave_html_integration:HtmlFormatter

DOCUMENTACIÓN COMPLETA
======================

Guías Disponibles:
- GUIA_COMPLETA_STEPS.md - Referencia completa de todos los steps (300+)
- GUIA_INTEGRACION_JIRA_XRAY.md - Integración completa con Jira y Xray Cloud
- GUIA_INSTALACION.md - Guía detallada de instalación
- GUIA_ARQUITECTURA_FRAMEWORK.md - Arquitectura técnica del framework
- GUIA_CONFIGURACION_NAVEGADOR_AVANZADA.md - Configuración avanzada del navegador
- GUIA_API_TESTING.md - Testing de APIs REST
- GUIA_VALIDACIONES.md - Validaciones y verificaciones
- GUIA_ELEMENTOS_WEB.md - Manipulación de elementos web
- GUIA_NAVEGACION_NAVEGADOR.md - Navegación del navegador
- GUIA_OCR.md - Reconocimiento óptico de caracteres
- GUIA_ARCHIVOS_DATOS.md - Manejo de archivos y datos
- GUIA_BASE_DATOS.md - Testing de bases de datos
- INDICE_FUNCIONALIDADES.md - Índice completo de funcionalidades
- INVENTARIO_STEPS.md - Inventario de steps disponibles

Ejemplos Prácticos:
- features/advanced_features_demo.feature - Demostración de funcionalidades avanzadas
- features/csv_handling_demo.feature - Ejemplos de procesamiento CSV
- features/example_login.feature - Login básico
- features/example_forms.feature - Formularios complejos

INTEGRACIÓN JIRA/XRAY - TRAZABILIDAD AUTOMÁTICA
================================================

✅ Adjunto automático de reportes HTML a issues de Jira
✅ Creación automática de Test Executions en Xray Cloud
✅ Flujo optimizado: Una sola llamada API para crear, adjuntar y actualizar
✅ Vinculación automática a Historias de Usuario
✅ Mapeo automático de estados (passed/failed/skipped)
✅ Control granular con variables de entorno
✅ Steps específicos para gestión manual
✅ Validación automática de tipos de issues
✅ Logs detallados del proceso completo

CHANGELOG
=========

v1.2.23+ - 2026-01-09 (INTEGRACIÓN JIRA/XRAY)

Nuevas Funcionalidades Principales:
- Integración Completa con Jira: Adjunto automático de reportes HTML a issues de Jira
- Integración Optimizada con Xray Cloud: Creación automática de Test Executions
- Flujo Xray Optimizado: Una sola llamada API crea Test Execution, adjunta todos los tests y actualiza estados
- Vinculación Automática: Test Executions se vinculan automáticamente a Historias de Usuario
- Control Granular: Variables de entorno para habilitar/deshabilitar integraciones independientemente
- Steps Específicos: 12+ steps para gestión manual de Jira y Xray
- Validación Automática: Solo procesa issues de tipo "Test" válidas en Xray

Integración Jira/Xray Detallada:
- Adjunto automático de reportes HTML a issues de Jira basado en tags del feature
- Creación automática de Test Executions en Xray con todos los tests del feature
- Mapeo automático de estados: passed/failed/skipped
- Vinculación automática de Test Execution a Historia de Usuario del feature
- Flujo optimizado: Una sola llamada API para crear, adjuntar y actualizar
- Autenticación directa con token de Xray Cloud
- Logs detallados del proceso de integración
- Manejo robusto de errores y validaciones

Variables de Entorno Nuevas:
- JIRA_ENABLED: Control maestro de integración con Jira
- JIRA_URL, JIRA_EMAIL, JIRA_TOKEN, JIRA_PROJECT: Configuración de Jira
- JIRA_COMMENT_MESSAGE: Mensaje personalizable para comentarios
- XRAY_ENABLED: Control de integración con Xray
- XRAY_AUTHORIZATION_TOKEN: Token directo de Xray Cloud
- XRAY_BASE_URL: URL base de Xray Cloud API
- XRAY_TEST_PLAN: Test Plan opcional para asociar executions

Archivos Nuevos:
- hakalab_framework/integrations/jira_integration.py - Integración completa con Jira
- hakalab_framework/integrations/xray_integration.py - Integración optimizada con Xray Cloud
- hakalab_framework/integrations/behave_hooks.py - Hooks automáticos para Behave
- hakalab_framework/steps/jira_xray_steps.py - Steps específicos para Jira/Xray
- test_jira_connection.py - Script de prueba de conexión con Jira
- test_xray_connection.py - Script de prueba de conexión con Xray
- GUIA_INTEGRACION_JIRA_XRAY.md - Guía completa de integración

v1.2.12 - 2026-01-06 (VERSIÓN ANTERIOR)

Nuevas Funcionalidades:
- Manejo Avanzado de CSV: 15+ steps para procesamiento completo de archivos CSV
- Variables Dinámicas: 20+ steps para generación y manipulación automática de variables
- Control de Tiempos: 15+ steps para cronómetros, esperas inteligentes y medición de rendimiento
- Entrada Avanzada: 25+ steps para simulación de escritura humana y manipulación sofisticada de texto
- Drag & Drop Mejorado: Sistema completamente rediseñado con múltiples métodos de fallback

COMIENZA AHORA
==============

# Instalación rápida
pip install git+https://github.com/hakalab/hakalab-framework.git
python -m playwright install

# Crear proyecto
hakalab-init mi-proyecto
cd mi-proyecto

# Ejecutar primera prueba
behave

El Hakalab Framework está listo para llevar tus pruebas automatizadas al siguiente nivel!

Con 300+ steps reales, integración completa con Jira y Xray Cloud, simulación de 
comportamiento humano, procesamiento de CSV, cronómetros de rendimiento y variables 
dinámicas, tienes todo lo necesario para crear automatizaciones de nivel empresarial 
con trazabilidad completa.

================================================
Documento generado automáticamente - Hakalab Framework v1.2.23+
README Framework
Fecha: Enero 2026
================================================
