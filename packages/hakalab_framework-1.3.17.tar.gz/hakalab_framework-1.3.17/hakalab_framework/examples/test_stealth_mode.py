#!/usr/bin/env python3
"""
Script de ejemplo para probar el modo stealth
Compara la detección con y sin modo stealth
"""
import os
from playwright.sync_api import sync_playwright

def test_without_stealth():
    """Prueba sin modo stealth"""
    print("\n" + "="*60)
    print("PRUEBA SIN MODO STEALTH")
    print("="*60)
    
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        page = browser.new_page()
        
        # Navegar a sitio de detección
        page.goto("https://bot.sannysoft.com/")
        page.wait_for_timeout(3000)
        
        # Verificar navigator.webdriver
        webdriver = page.evaluate("() => navigator.webdriver")
        print(f"navigator.webdriver: {webdriver}")
        
        # Verificar plugins
        plugins_length = page.evaluate("() => navigator.plugins.length")
        print(f"navigator.plugins.length: {plugins_length}")
        
        # Verificar chrome object
        has_chrome = page.evaluate("() => typeof window.chrome !== 'undefined'")
        print(f"window.chrome exists: {has_chrome}")
        
        print("\n⚠️ Propiedades que delatan automatización detectadas")
        print("Presiona Enter para continuar...")
        input()
        
        browser.close()

def test_with_stealth():
    """Prueba con modo stealth"""
    print("\n" + "="*60)
    print("PRUEBA CON MODO STEALTH")
    print("="*60)
    
    try:
        from playwright_stealth import stealth_sync
    except ImportError:
        print("❌ playwright-stealth no está instalado")
        print("Ejecuta: pip install playwright-stealth")
        return
    
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        page = browser.new_page()
        
        # Aplicar stealth
        stealth_sync(page)
        print("🥷 Modo stealth aplicado")
        
        # Navegar a sitio de detección
        page.goto("https://bot.sannysoft.com/")
        page.wait_for_timeout(3000)
        
        # Verificar navigator.webdriver
        webdriver = page.evaluate("() => navigator.webdriver")
        print(f"navigator.webdriver: {webdriver}")
        
        # Verificar plugins
        plugins_length = page.evaluate("() => navigator.plugins.length")
        print(f"navigator.plugins.length: {plugins_length}")
        
        # Verificar chrome object
        has_chrome = page.evaluate("() => typeof window.chrome !== 'undefined'")
        print(f"window.chrome exists: {has_chrome}")
        
        print("\n✅ Propiedades de automatización ocultas")
        print("Presiona Enter para continuar...")
        input()
        
        browser.close()

def test_framework_stealth():
    """Prueba usando el framework con stealth"""
    print("\n" + "="*60)
    print("PRUEBA CON FRAMEWORK (STEALTH_MODE=true)")
    print("="*60)
    
    # Configurar variable de entorno
    os.environ['STEALTH_MODE'] = 'true'
    
    from hakalab_framework.core.environment_config import FrameworkConfig
    
    config = FrameworkConfig()
    browser = config.setup_playwright()
    page = config.create_page()
    
    # Navegar a sitio de detección
    page.goto("https://bot.sannysoft.com/")
    page.wait_for_timeout(3000)
    
    # Verificar propiedades
    webdriver = page.evaluate("() => navigator.webdriver")
    plugins_length = page.evaluate("() => navigator.plugins.length")
    has_chrome = page.evaluate("() => typeof window.chrome !== 'undefined'")
    
    print(f"navigator.webdriver: {webdriver}")
    print(f"navigator.plugins.length: {plugins_length}")
    print(f"window.chrome exists: {has_chrome}")
    
    print("\n✅ Framework con modo stealth funcionando")
    print("Presiona Enter para cerrar...")
    input()
    
    config.cleanup()

if __name__ == "__main__":
    print("""
╔══════════════════════════════════════════════════════════════╗
║         PRUEBA DE MODO STEALTH - HAKALAB FRAMEWORK          ║
╚══════════════════════════════════════════════════════════════╝

Este script compara la detección de automatización con y sin modo stealth.

Sitio de prueba: https://bot.sannysoft.com/
- Detecta propiedades que delatan automatización
- Muestra diferencias entre navegador normal y stealth

NOTA: Asegúrate de tener instalado playwright-stealth:
      pip install playwright-stealth
    """)
    
    try:
        # Prueba 1: Sin stealth
        test_without_stealth()
        
        # Prueba 2: Con stealth manual
        test_with_stealth()
        
        # Prueba 3: Con framework
        test_framework_stealth()
        
        print("\n" + "="*60)
        print("RESUMEN")
        print("="*60)
        print("✅ Todas las pruebas completadas")
        print("\nCOMPARACIÓN:")
        print("- Sin stealth: navigator.webdriver = true (detectado)")
        print("- Con stealth: navigator.webdriver = undefined (oculto)")
        print("\nPara usar en tus pruebas, configura en .env:")
        print("STEALTH_MODE=true")
        
    except KeyboardInterrupt:
        print("\n\n⚠️ Prueba interrumpida por el usuario")
    except Exception as e:
        print(f"\n❌ Error durante la prueba: {e}")
