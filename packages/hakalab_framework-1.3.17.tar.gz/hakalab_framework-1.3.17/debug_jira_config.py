#!/usr/bin/env python3
"""
Script de diagnóstico para verificar la configuración de Jira/Xray
"""
import os
from dotenv import load_dotenv

# Cargar variables de entorno
load_dotenv()

print("🔍 DIAGNÓSTICO DE CONFIGURACIÓN JIRA/XRAY")
print("=" * 50)

# Variables que busca el framework
jira_vars = {
    'JIRA_ENABLED': os.getenv('JIRA_ENABLED'),
    'JIRA_URL': os.getenv('JIRA_URL'),
    'JIRA_EMAIL': os.getenv('JIRA_EMAIL'),
    'JIRA_TOKEN': os.getenv('JIRA_TOKEN'),
    'JIRA_PROJECT': os.getenv('JIRA_PROJECT'),
    'JIRA_COMMENT_MESSAGE': os.getenv('JIRA_COMMENT_MESSAGE'),
}

xray_vars = {
    'XRAY_AUTHORIZATION_TOKEN': os.getenv('XRAY_AUTHORIZATION_TOKEN'),
    'XRAY_BASE_URL': os.getenv('XRAY_BASE_URL'),
}

print("\n📋 VARIABLES DE JIRA:")
for var, value in jira_vars.items():
    if value:
        # Mostrar solo los primeros y últimos caracteres para tokens
        if 'TOKEN' in var and len(value) > 10:
            display_value = f"{value[:10]}...{value[-10:]}"
        elif 'EMAIL' in var:
            display_value = value
        else:
            display_value = value
        print(f"  ✅ {var}: {display_value}")
    else:
        print(f"  ❌ {var}: NO CONFIGURADA")

print("\n🧪 VARIABLES DE XRAY:")
for var, value in xray_vars.items():
    if value:
        if 'TOKEN' in var and len(value) > 10:
            display_value = f"{value[:10]}...{value[-10:]}"
        else:
            display_value = value
        print(f"  ✅ {var}: {display_value}")
    else:
        print(f"  ❌ {var}: NO CONFIGURADA")

print("\n🔧 VERIFICACIÓN DE CONFIGURACIÓN:")

# Verificar si Jira está habilitado
jira_enabled = os.getenv('JIRA_ENABLED', 'false').lower() == 'true'
print(f"  JIRA_ENABLED: {jira_enabled}")

if jira_enabled:
    # Verificar variables requeridas
    required_vars = ['JIRA_URL', 'JIRA_EMAIL', 'JIRA_TOKEN', 'JIRA_PROJECT']
    missing_vars = [var for var in required_vars if not os.getenv(var)]
    
    if missing_vars:
        print(f"  ❌ Variables faltantes: {', '.join(missing_vars)}")
    else:
        print("  ✅ Todas las variables requeridas están configuradas")
        
        # Probar conexión
        print("\n🔗 PROBANDO CONEXIÓN CON JIRA...")
        try:
            from hakalab_framework.integrations.jira_integration import JiraIntegration
            jira = JiraIntegration()
            
            if jira.is_configured:
                success = jira.test_connection()
                if success:
                    print("  ✅ Conexión exitosa con Jira")
                else:
                    print("  ❌ Error de conexión con Jira")
            else:
                print("  ❌ Jira no está configurado correctamente")
                
        except Exception as e:
            print(f"  ❌ Error al probar conexión: {e}")
else:
    print("  ℹ️ Jira está deshabilitado")

print("\n" + "=" * 50)
print("🔍 DIAGNÓSTICO COMPLETADO")