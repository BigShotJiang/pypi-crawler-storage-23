#!/usr/bin/env python3
"""
Script para publicar hakalab-framework en PyPI
"""

import os
import sys
import subprocess
import shutil
from pathlib import Path

# ============================================================================
# VERSIÓN GLOBAL - CAMBIAR SOLO AQUÍ
# ============================================================================
VERSION = "1.3.17"
# ============================================================================

def run_command(command, description):
    """Ejecuta un comando y muestra el resultado"""
    print(f"\n{'='*70}")
    print(f"🔧 {description}")
    print(f"{'='*70}")
    print(f"Comando: {command}")
    
    result = subprocess.run(command, shell=True, capture_output=True, text=True)
    
    if result.stdout:
        print(result.stdout)
    
    if result.returncode != 0:
        print(f"❌ Error: {result.stderr}")
        return False
    
    print(f"✅ {description} - Completado")
    return True

def clean_build_artifacts():
    """Limpia artefactos de builds anteriores"""
    print("\n🧹 Limpiando artefactos de builds anteriores...")
    
    dirs_to_remove = ['build', 'dist', '*.egg-info', 'hakalab_framework.egg-info']
    
    for dir_pattern in dirs_to_remove:
        for path in Path('.').glob(dir_pattern):
            if path.is_dir():
                shutil.rmtree(path)
                print(f"  ✓ Eliminado: {path}")
    
    print("✅ Limpieza completada")

def verify_version():
    """Verifica que la versión sea consistente"""
    print(f"\n🔍 Verificando versión {VERSION}...")
    
    # Leer versión de setup.py
    with open('setup.py', 'r', encoding='utf-8') as f:
        setup_content = f.read()
        if f'version="{VERSION}"' not in setup_content:
            print(f"❌ Error: Versión en setup.py no es {VERSION}")
            return False
    
    # Leer versión de pyproject.toml
    with open('pyproject.toml', 'r', encoding='utf-8') as f:
        pyproject_content = f.read()
        if f'version = "{VERSION}"' not in pyproject_content:
            print(f"❌ Error: Versión en pyproject.toml no es {VERSION}")
            return False
    
    print(f"✅ Versión {VERSION} verificada en todos los archivos")
    return True

def check_dependencies():
    """Verifica que las dependencias necesarias estén instaladas"""
    print("\n📦 Verificando dependencias...")
    
    required = ['build', 'twine']
    missing = []
    
    for package in required:
        result = subprocess.run(
            f"python -m pip show {package}",
            shell=True,
            capture_output=True
        )
        if result.returncode != 0:
            missing.append(package)
    
    if missing:
        print(f"❌ Faltan dependencias: {', '.join(missing)}")
        print("\nInstala con:")
        print(f"  pip install {' '.join(missing)}")
        return False
    
    print("✅ Todas las dependencias están instaladas")
    return True

def build_package():
    """Construye el paquete"""
    return run_command(
        "python -m build",
        "Construyendo paquete"
    )

def check_package():
    """Verifica el paquete con twine"""
    return run_command(
        "python -m twine check dist/*",
        "Verificando paquete con twine"
    )

def upload_to_test_pypi():
    """Sube el paquete a TestPyPI"""
    print("\n" + "="*70)
    print("📤 Subiendo a TestPyPI (repositorio de prueba)")
    print("="*70)
    print("\nUsando configuración de: C:\\Users\\felipefarias\\.pypirc")
    print("Proyecto: hakalab-framework")
    
    response = input("\n¿Continuar con la subida a TestPyPI? (s/n): ")
    if response.lower() != 's':
        print("⏭️  Saltando TestPyPI")
        return True
    
    return run_command(
        'python -m twine upload --config-file "C:\\Users\\felipefarias\\.pypirc" --repository testpypi dist/*',
        "Subiendo a TestPyPI"
    )

def upload_to_pypi():
    """Sube el paquete a PyPI"""
    print("\n" + "="*70)
    print("📤 Subiendo a PyPI (repositorio PRODUCCIÓN)")
    print("="*70)
    print("\n⚠️  ADVERTENCIA: Esta es la subida FINAL a PyPI")
    print("Usando configuración de: C:\\Users\\felipefarias\\.pypirc")
    print("Repositorio: hakalab-framework")
    
    response = input(f"\n¿Estás SEGURO de subir hakalab-framework v{VERSION} a PyPI? (s/n): ")
    if response.lower() != 's':
        print("❌ Subida a PyPI cancelada")
        return False
    
    # Usar el repositorio hakalab-framework configurado en .pypirc
    return run_command(
        'python -m twine upload --config-file "C:\\Users\\felipefarias\\.pypirc" --repository hakalab-framework dist/*',
        "Subiendo hakalab-framework a PyPI"
    )

def main():
    """Función principal"""
    print("="*70)
    print(f"🚀 PUBLICACIÓN DE HAKALAB-FRAMEWORK v{VERSION} EN PyPI")
    print("="*70)
    
    # Verificar que estamos en el directorio correcto
    if not os.path.exists('setup.py'):
        print("❌ Error: No se encuentra setup.py")
        print("Ejecuta este script desde la raíz del proyecto")
        sys.exit(1)
    
    # Paso 1: Verificar versión
    if not verify_version():
        sys.exit(1)
    
    # Paso 2: Verificar dependencias
    if not check_dependencies():
        sys.exit(1)
    
    # Paso 3: Limpiar artefactos
    clean_build_artifacts()
    
    # Paso 4: Construir paquete
    if not build_package():
        print("\n❌ Error al construir el paquete")
        sys.exit(1)
    
    # Paso 5: Verificar paquete
    if not check_package():
        print("\n❌ Error al verificar el paquete")
        sys.exit(1)
    
    # Paso 6: Subir a TestPyPI (opcional)
    upload_to_test_pypi()
    
    # Paso 7: Subir a PyPI
    if upload_to_pypi():
        print("\n" + "="*70)
        print("🎉 ¡PUBLICACIÓN EXITOSA!")
        print("="*70)
        print(f"\n✅ hakalab-framework v{VERSION} publicado en PyPI")
        print("\nLos usuarios pueden instalarlo con:")
        print(f"  pip install hakalab-framework=={VERSION}")
        print("\nO actualizar a la última versión:")
        print("  pip install --upgrade hakalab-framework")
        print("\nVerifica en: https://pypi.org/project/hakalab-framework/")
    else:
        print("\n❌ Publicación cancelada o fallida")
        sys.exit(1)

if __name__ == "__main__":
    main()
