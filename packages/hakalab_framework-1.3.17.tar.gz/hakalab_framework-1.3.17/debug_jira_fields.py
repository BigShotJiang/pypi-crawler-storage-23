#!/usr/bin/env python
"""
Script para debuggear y listar todos los campos disponibles en Jira
Ejecuta esto para encontrar el ID correcto del campo "Estado"

Uso:
    python debug_jira_fields.py
"""

from jira_status_updater import JiraStatusUpdater

if __name__ == "__main__":
    print("🔍 Iniciando debug de campos Jira...\n")
    
    updater = JiraStatusUpdater()
    
    if not updater.is_configured:
        print("❌ Jira no está configurado. Verifica las variables de entorno:")
        print("   - JIRA_ENABLED=true")
        print("   - JIRA_URL=https://tu-jira.com")
        print("   - JIRA_EMAIL=tu-email@ejemplo.com")
        print("   - JIRA_TOKEN=tu-token-api")
        exit(1)
    
    # Probar conexión
    print("1️⃣ Probando conexión con Jira...")
    if not updater.test_connection():
        print("❌ No se pudo conectar a Jira")
        exit(1)
    
    # Listar todos los campos
    print("\n2️⃣ Listando todos los campos disponibles...")
    updater.list_all_fields()
    
    # Buscar el campo "Estado"
    print("\n3️⃣ Buscando campo 'Estado'...")
    if updater._find_custom_field():
        print(f"\n✅ Campo encontrado: {updater.custom_field_id}")
    else:
        print("\n❌ Campo 'Estado' no encontrado")
        print("\n💡 Posibles soluciones:")
        print("   1. Verifica que el campo existe en Jira")
        print("   2. Verifica que el nombre es exactamente 'Estado'")
        print("   3. Usa el ID del campo directamente (ej: customfield_10001)")
