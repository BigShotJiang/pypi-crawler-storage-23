#!/usr/bin/env python
"""Setup configuration for python-pt-br package.

Note: This file is maintained for backward compatibility.
Primary configuration is in pyproject.toml
"""

from setuptools import setup

setup()
