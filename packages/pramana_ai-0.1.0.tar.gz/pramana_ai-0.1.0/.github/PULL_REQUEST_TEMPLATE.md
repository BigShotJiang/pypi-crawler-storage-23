## Summary

<!-- 1-3 sentences: what and why -->

## Changes

-

## Checklist

- [ ] `pytest tests/` passes
- [ ] `ruff check .` passes
- [ ] Documentation updated (if applicable)
- [ ] One feature per PR
- [ ] No secrets or API keys committed
