"""Tests for Pramana."""
