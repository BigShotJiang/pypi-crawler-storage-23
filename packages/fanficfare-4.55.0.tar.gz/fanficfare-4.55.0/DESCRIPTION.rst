FanFicFare (FFF)
=======================

FanFicFare is a tool for downloading fanfiction and original stories
from various sites into ebook form.

FanFicFare(FFF) is the renamed successor to
FanFictionDownLoader(FFDL).  The project was renamed due to another,
unrelated project sharing the same name.

FanFicFare can download stories from over 100 different fanfiction and
original fiction sites.

FanFicFare can output stories into EPUB (the preferred format), HTML,
plain text and MOBI formats.
