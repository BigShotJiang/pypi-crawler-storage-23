import seismic_web3


def test_import():
    assert seismic_web3.__version__ == "0.1.0"
