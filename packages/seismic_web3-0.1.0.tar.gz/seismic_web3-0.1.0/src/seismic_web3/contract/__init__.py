"""Seismic contract interaction — ABI remapping and shielded operations."""
