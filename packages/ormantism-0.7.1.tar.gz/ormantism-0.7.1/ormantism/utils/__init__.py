"""Utility helpers for type resolution, serialization, schema, and model discovery."""
