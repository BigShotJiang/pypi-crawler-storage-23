"""AFD Examples.

This package contains example code demonstrating how to use AFD.

Examples:
    - todo_server.py: A complete MCP server for managing todos
    - test_example.py: Testing patterns with AFD assertions
    - client_usage.py: Using the transport layer programmatically
"""
