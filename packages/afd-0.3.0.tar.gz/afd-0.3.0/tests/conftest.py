"""Test configuration for AFD Python tests."""

import pytest
