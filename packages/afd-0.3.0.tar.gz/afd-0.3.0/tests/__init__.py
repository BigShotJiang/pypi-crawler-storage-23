"""AFD test suite."""
