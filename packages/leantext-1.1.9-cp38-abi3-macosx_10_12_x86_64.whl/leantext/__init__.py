from .leantext import *

__doc__ = leantext.__doc__
if hasattr(leantext, "__all__"):
    __all__ = leantext.__all__