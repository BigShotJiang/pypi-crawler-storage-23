from __future__ import annotations

from dataclasses import dataclass


@dataclass
class CliError(Exception):
    """Base CLI error carrying protocol-level codes."""

    code: str
    message: str
    details: dict | None = None

    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.message


class InvalidArgsError(CliError):
    def __init__(self, message: str, details: dict | None = None):
        super().__init__("INVALID_ARGS", message, details)


class AuthRequiredError(CliError):
    def __init__(self, message: str = "登录失效或未登录", details: dict | None = None):
        super().__init__("AUTH_REQUIRED", message, details)


class AccountUnavailableError(CliError):
    def __init__(self, message: str = "无可用账号", details: dict | None = None):
        super().__init__("ACCOUNT_UNAVAILABLE", message, details)


class RiskControlError(CliError):
    def __init__(self, message: str = "命中风控", details: dict | None = None):
        super().__init__("RISK_CONTROL_TRIGGERED", message, details)


class DependencyMissingError(CliError):
    def __init__(self, message: str = "运行依赖缺失", details: dict | None = None):
        super().__init__("DEPENDENCY_MISSING", message, details)


class CliTimeoutError(CliError):
    def __init__(self, message: str = "执行超时", details: dict | None = None):
        super().__init__("TIMEOUT", message, details)


class InternalError(CliError):
    def __init__(self, message: str = "内部异常", details: dict | None = None):
        super().__init__("INTERNAL_ERROR", message, details)
