from __future__ import annotations

from rednote_cli.adapters.platform.rednote.extractor import RednoteExtractorAdapter


async def execute_user_self(account_uid: str | None = None) -> dict:
    adapter = RednoteExtractorAdapter()
    return await adapter.get_self_info(account_uid=account_uid)
