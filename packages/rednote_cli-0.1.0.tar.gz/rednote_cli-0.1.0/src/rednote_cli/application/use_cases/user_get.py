from __future__ import annotations

from rednote_cli.adapters.platform.rednote.extractor import RednoteExtractorAdapter


async def execute_user_get(
    user_id: str,
    xsec_token: str | None = None,
    xsec_source: str | None = "pc_feed",
    account_uid: str | None = None,
) -> dict:
    adapter = RednoteExtractorAdapter()
    return await adapter.get_user_info(
        user_id=user_id,
        xsec_token=xsec_token,
        xsec_source=xsec_source,
        account_uid=account_uid,
    )
