from __future__ import annotations

import typer

from rednote_cli.application.dto.input_models import UserGetInput
from rednote_cli.application.use_cases.user_get import execute_user_get
from rednote_cli.application.use_cases.user_self import execute_user_self
from rednote_cli.cli.options import CliContext
from rednote_cli.cli.runtime import run_async_command
from rednote_cli.cli.utils import all_option_params_are_default, load_json_input, pick_cli_or_input
from rednote_cli.domain.errors import InvalidArgsError

app = typer.Typer(help="用户主页详情查询", no_args_is_help=False)


@app.callback(invoke_without_command=True)
def user_get(
    ctx: typer.Context,
    user_id: str | None = typer.Option(None, "--user-id", help="用户 ID；可由 --input 提供"),
    xsec_token: str | None = typer.Option(None, "--xsec-token", help="xsec_token，可选"),
    xsec_source: str = typer.Option("pc_feed", "--xsec-source", help="xsec 来源，默认 pc_feed"),
    account: str | None = typer.Option(None, "--account", help="账号唯一标识（user_no）"),
    input_file: str | None = typer.Option(
        None,
        "--input",
        help="JSON 输入文件路径或 '-'，字段示例：user_id,xsec_token,xsec_source,account_uid",
    ),
):
    """
    获取单个用户主页详情。

    参数优先级：显式 CLI 参数 > --input JSON > 默认值。
    """
    if ctx.invoked_subcommand:
        return
    if all_option_params_are_default(ctx=ctx):
        typer.echo(ctx.get_help())
        raise typer.Exit(code=0)

    cli_ctx: CliContext = ctx.obj
    payload = load_json_input(input_file)
    account_uid = pick_cli_or_input(
        ctx=ctx,
        param_name="account",
        cli_value=account,
        payload=payload,
        payload_key="account_uid",
    )

    async def _run():
        validated = UserGetInput(
            user_id=pick_cli_or_input(
                ctx=ctx,
                param_name="user_id",
                cli_value=user_id,
                payload=payload,
                payload_key="user_id",
            ),
            xsec_token=pick_cli_or_input(
                ctx=ctx,
                param_name="xsec_token",
                cli_value=xsec_token,
                payload=payload,
                payload_key="xsec_token",
            ),
            xsec_source=pick_cli_or_input(
                ctx=ctx,
                param_name="xsec_source",
                cli_value=xsec_source,
                payload=payload,
                payload_key="xsec_source",
            ),
            account_uid=account_uid,
        )
        return await execute_user_get(
            user_id=validated.user_id,
            xsec_token=validated.xsec_token,
            xsec_source=validated.xsec_source,
            account_uid=validated.account_uid,
        )

    run_async_command(
        ctx=cli_ctx,
        command="user.get",
        func=_run,
        account_uid=account_uid,
    )


@app.command("self")
def user_self(
    ctx: typer.Context,
    account: str | None = typer.Option(None, "--account", help="账号唯一标识（user_no）"),
):
    """查询当前登录账号自己的用户信息。"""
    if all_option_params_are_default(ctx=ctx):
        typer.echo(ctx.get_help())
        raise typer.Exit(code=0)

    cli_ctx: CliContext = ctx.obj
    account_uid = (account or "").strip()

    async def _run():
        if not account_uid:
            raise InvalidArgsError("`--account` 为必填参数")
        return await execute_user_self(account_uid=account_uid)

    run_async_command(
        ctx=cli_ctx,
        command="user.self",
        func=_run,
        account_uid=account_uid,
    )
