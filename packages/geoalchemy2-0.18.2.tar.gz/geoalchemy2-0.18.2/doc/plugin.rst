.. _plugin:

Plugin
======

.. automodule:: geoalchemy2.admin.plugin
   :members:
   :private-members:
   :show-inheritance:
