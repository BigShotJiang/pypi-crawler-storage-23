"""This module defines functions used by several dialects."""


def bind_processor_process(spatial_type, bindvalue):
    return bindvalue  # pragma: no cover
