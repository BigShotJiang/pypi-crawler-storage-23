# Changelog

All notable changes to this project will be documented in this file.

## [0.0.2-alpha0] - 2026-02-19

### Added
- Initial release of `generic-robot-env`.
- Support for `osc` and `joint` control modes.
- Automatic configuration extraction from MuJoCo XMLs.
- GitHub CI/CD workflows for testing and release.
