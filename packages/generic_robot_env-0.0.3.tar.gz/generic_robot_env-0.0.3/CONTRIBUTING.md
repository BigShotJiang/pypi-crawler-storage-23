# Contributing to generic-robot-env

Thank you for your interest in contributing to `generic-robot-env`!

## Code of Conduct

Please be respectful and professional in all interactions.

## How to Contribute

1.  **Report Bugs**: Open an issue on GitHub describing the bug and how to reproduce it.
2.  **Suggest Features**: Open an issue to discuss new features.
3.  **Pull Requests**:
    *   Fork the repository.
    *   Create a new branch for your changes.
    *   Add tests for any new functionality.
    *   Ensure all tests pass and linting is clean.
    *   Submit a PR.

## Development Setup

This project uses `uv` for dependency management.

```bash
# Install uv if you haven't
curl -LsSf https://astral.sh/uv/install.sh | sh

# Install dependencies
uv sync --all-extras
```

### Testing

Run tests with `pytest`:

```bash
uv run pytest
```

### Linting

We use `ruff` for linting and formatting.

```bash
uv run ruff check .
uv run ruff format .
```

### Git hooks

This repository uses `pre-commit` for local checks before committing or pushing changes:

- `pre-commit` hook: runs fast checks/fixes (`ruff`, formatting, and file hygiene checks)
- `pre-push` hook: runs the test suite (`pytest`)

Install hooks once after cloning:

```bash
uv run pre-commit install --hook-type pre-commit --hook-type pre-push
```

Run the same checks manually:

```bash
uv run pre-commit run --all-files
uv run pre-commit run --hook-stage pre-push
```
