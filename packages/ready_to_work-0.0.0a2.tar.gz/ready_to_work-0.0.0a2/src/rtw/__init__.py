"""ready-to-work (rtw) - Architect loop framework for AI-driven development."""

try:
    from rtw._version import __version__
except ImportError:
    __version__ = "0.0.0+dev"
