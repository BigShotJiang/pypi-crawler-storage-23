"""Card pack management utilities."""

__all__ = []
