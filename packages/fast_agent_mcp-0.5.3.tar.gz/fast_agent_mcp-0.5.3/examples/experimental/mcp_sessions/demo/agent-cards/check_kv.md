---
type: agent
model: $system.demo
skills: []
servers:
  - mcp_sessions_hashcheck
---

Per-session hash KV demo.

Try:

- "Store hash key k1 for text hello."
- "Verify hash key k1 with text hello."
- "List stored hash keys."
- "Delete hash key k1."
