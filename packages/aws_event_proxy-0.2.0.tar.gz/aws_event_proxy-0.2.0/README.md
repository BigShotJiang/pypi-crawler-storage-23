# aws-event-proxy

An AWS Lambda handler that proxies events to a configurable HTTP endpoint.

Forwards events from any AWS source (SQS, SNS, S3, DynamoDB Streams, etc.) to an external HTTP endpoint via POST, including Lambda execution context in the request headers.

## Installation

```bash
pip install aws-event-proxy
```

## Configuration

Set the `PROXY_TARGET_URL` environment variable in your Lambda function to the URL you want events forwarded to.

## Usage

Set your Lambda handler to:

```
aws_event_proxy.handler
```

### What it does

- POSTs the raw Lambda event as JSON to `PROXY_TARGET_URL`
- Attaches Lambda context metadata as the `X-Lambda-Context` request header
- Returns the parsed JSON response body from the target
- Logs proxy activity and re-raises errors to the Lambda runtime

## Packaging for Lambda deployment

```python
import aws_event_proxy

zip_bytes = aws_event_proxy.get_handler_zip()
```

`get_handler_zip()` returns the zip file as `bytes`, ready to upload to Lambda via the AWS SDK or write to disk:

```python
# Write to disk
with open("aws-event-proxy-lambda.zip", "wb") as f:
    f.write(aws_event_proxy.get_handler_zip())

# Upload directly with boto3
import boto3
boto3.client("lambda").update_function_code(
    FunctionName="my-function",
    ZipFile=aws_event_proxy.get_handler_zip(),
)
```

Set the Lambda handler to `aws_event_proxy.handler`.

## Development

```bash
make setup          # install dependencies and create .venv
poetry run pytest   # run tests
```

## Publishing

```bash
poetry publish --build
```
