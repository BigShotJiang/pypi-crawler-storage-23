import io
import zipfile
from pathlib import Path

from aws_event_proxy.handler import handler


def get_handler_zip() -> bytes:
    """Return zip file bytes containing the aws_event_proxy package, ready for Lambda deployment."""
    package_dir = Path(__file__).parent
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in sorted(package_dir.rglob("*")):
            if f.is_file() and f.suffix != ".pyc" and "__pycache__" not in f.parts:
                zf.write(f, Path("aws_event_proxy") / f.relative_to(package_dir))
    return buf.getvalue()


__all__ = ["handler", "get_handler_zip"]
