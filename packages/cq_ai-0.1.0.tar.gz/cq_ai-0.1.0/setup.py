from setuptools import setup, find_packages
from pathlib import Path

# Read the contents of your README file
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name='cq-ai',
    version='0.1.0',
    packages=find_packages(),
    include_package_data=True,
    package_data={
        'ai_coder': [
            'skills/**/SKILL.md',
            'agents/definitions/*.md',
            '**/*.yaml',
        ],
    },
    install_requires=[
        'typer[all]>=0.9.0',
        'rich>=13.0.0',
        'openai>=1.0.0',
        'anthropic>=0.18.0',
        'httpx>=0.25.0',
        'pyyaml>=6.0',
        'gitignore-parser>=0.1.0',
        'python-dotenv>=1.0.0',
        # REPL support
        'prompt_toolkit>=3.0.0',
        # Web interface
        'fastapi>=0.104.0',
        'uvicorn[standard]>=0.24.0',
        'websockets>=12.0',
        # Internet access
        'beautifulsoup4>=4.12.0',
        'lxml>=5.0.0',
        'duckduckgo-search>=4.0.0',
    ],
    extras_require={
        'dev': [
            'pytest>=7.0.0',
            'pytest-asyncio>=0.21.0',
            'black>=23.0.0',
            'ruff>=0.1.0',
        ],
    },
    entry_points={
        'console_scripts': [
            'cq=ai_coder.main:main',
            'cq-ai=ai_coder.main:main',
        ],
    },
    author='CQ Team',
    author_email='',
    description='Current Quotient AI - Terminal-native AI coding agent, developed by CQ Team',
    long_description=long_description,
    long_description_content_type='text/markdown',
    license='MIT',
    python_requires='>=3.10',
    keywords=['ai', 'coding', 'agent', 'cli', 'llm', 'cq', 'claude', 'terminal', 'developer-tools'],
    classifiers=[
        'Development Status :: 4 - Beta',
        'Environment :: Console',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Topic :: Software Development :: Code Generators',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Topic :: Utilities',
    ],
    project_urls={
        'Homepage': 'https://github.com/cq-team/cq-ai',
        'Source Repository': 'https://github.com/cq-team/cq-ai',
        'Issues': 'https://github.com/cq-team/cq-ai/issues',
    },
)
