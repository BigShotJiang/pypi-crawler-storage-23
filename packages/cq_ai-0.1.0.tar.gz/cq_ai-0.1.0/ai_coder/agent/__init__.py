"""Agent module - orchestration and planning."""
