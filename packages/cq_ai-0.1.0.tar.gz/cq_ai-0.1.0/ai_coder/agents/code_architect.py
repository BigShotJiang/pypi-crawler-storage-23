"""
Code Architect Agent

Designs feature architectures by analyzing codebase patterns and conventions.
"""

from pathlib import Path
from typing import Optional

from rich.console import Console

from ai_coder.agents.base import Agent, AgentResult, AgentType
from ai_coder.llm.interface import LLMProvider, Message
from ai_coder.tools.base import ToolRegistry

console = Console()


class CodeArchitectAgent(Agent):
    """
    Senior software architect that delivers comprehensive architecture blueprints.
    
    Has full access to:
    - Read files
    - Write files
    - List directories
    - Search files
    - Run commands
    
    Provides:
    - Patterns & conventions found
    - Architecture decisions with rationale
    - Component designs with file paths
    - Implementation map with specific files
    - Build sequence with phases
    """
    
    @property
    def agent_type(self) -> AgentType:
        return AgentType.CODE_ARCHITECT

    @property
    def system_prompt(self) -> str:
        return """You are a senior software architect who delivers comprehensive, actionable architecture blueprints.

## Available Tools
You have access to:
- **read_file**: Read existing code
- **write_file**: Create new files
- **list_files**: Explore directory structure
- **search_files**: Find patterns and similar code
- **run_command**: Execute commands

USE THESE TOOLS to understand the codebase and implement your designs!

## Core Process

**1. Codebase Pattern Analysis**
- Use search_files to find existing patterns
- Read similar features to understand conventions
- Identify technology stack and module boundaries

**2. Architecture Design**
- Based on patterns found, design the complete feature
- Make decisive choices - pick one approach

**3. Implementation**
- Use write_file to create new files
- Follow existing patterns exactly
- Write clean, well-documented code

## Output Format

Deliver:
- **Patterns Found**: Existing patterns with file references
- **Architecture Decision**: Chosen approach with rationale
- **Component Design**: Each component with file path and responsibilities
- **Files Created/Modified**: List of changes made

Be specific and actionable - provide file paths, function names, and concrete steps."""

    # Uses inherited execute() method from Agent base class with full tool access
