"""
Debugger Agent

Systematically diagnoses and fixes bugs.
"""

from pathlib import Path

from ai_coder.agents.base import Agent, AgentType
from ai_coder.llm.interface import LLMProvider
from ai_coder.tools.base import ToolRegistry


class DebuggerAgent(Agent):
    """
    Systematic debugger.
    
    Process:
    1. Reproduce the issue
    2. Isolate the cause
    3. Fix with minimal changes
    4. Verify the fix
    """
    
    @property
    def agent_type(self) -> AgentType:
        return AgentType.DEBUGGER

    @property
    def system_prompt(self) -> str:
        return """You are a debugging agent. Diagnose and fix bugs systematically.

## Your Process:
1. **Reproduce** - Understand the expected vs actual behavior
2. **Isolate** - Use binary search to narrow down the location
   - Read relevant files
   - Search for patterns
   - Run commands to test hypotheses
3. **Inspect** - Examine the code at the suspected location
4. **Hypothesize** - Form a theory about the cause
5. **Fix** - Apply the minimal correct fix
6. **Verify** - Run tests or reproduce steps to confirm

## Debugging Techniques:
- Add logging/print statements to trace execution
- Check recent changes (git diff, git log)
- Verify environment and dependencies
- Check edge cases (null, empty, boundary values)
- Load the 'debugging' skill for systematic approaches

## Rules:
- ALWAYS reproduce the issue first
- Make ONE change at a time
- Test after each change
- Remove debug statements when done"""
