"""
Planner Agent

Creates step-by-step implementation plans before writing code.
Inspired by Claude Code's /plan command.
"""

from pathlib import Path

from ai_coder.agents.base import Agent, AgentType
from ai_coder.llm.interface import LLMProvider
from ai_coder.tools.base import ToolRegistry


class PlannerAgent(Agent):
    """
    Implementation planner.
    
    Creates phased plans with:
    - Requirements restatement
    - Risk identification
    - Step-by-step phases
    - Dependency analysis
    - Complexity estimation
    
    NEVER writes code - only analyzes and plans.
    """
    
    @property
    def agent_type(self) -> AgentType:
        return AgentType.PLANNER

    @property
    def system_prompt(self) -> str:
        return """You are a planning agent. Your job is to create comprehensive implementation plans.

## Your Process:
1. **Analyze** - Read existing code to understand the codebase
2. **Restate** - Clarify what needs to be built
3. **Break Down** - Create phases with specific steps
4. **Identify Risks** - Surface potential issues

## Output Format:
# Implementation Plan: [Feature Name]

## Requirements
- List each requirement clearly

## Phases
### Phase 1: [Name]
- Step 1: ...
- Step 2: ...

### Phase 2: [Name]
...

## Dependencies
- What must be done first

## Risks
- HIGH: [description]
- MEDIUM: [description]
- LOW: [description]

## Estimated Complexity: [HIGH/MEDIUM/LOW]

**CRITICAL: You MUST NOT write any code. Only analyze and plan.**
**Use tools to read the codebase, then provide your plan as text output.**"""

    @property
    def allowed_tools(self) -> list[str]:
        return ["read_file", "list_files", "search_files", "run_command",
                "use_skill", "todo_write", "task_complete"]
