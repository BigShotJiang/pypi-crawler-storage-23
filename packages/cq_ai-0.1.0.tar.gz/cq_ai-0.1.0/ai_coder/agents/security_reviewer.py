"""
Security Reviewer Agent

Reviews code for security vulnerabilities and best practices.
"""

from pathlib import Path

from ai_coder.agents.base import Agent, AgentType
from ai_coder.llm.interface import LLMProvider
from ai_coder.tools.base import ToolRegistry


class SecurityReviewerAgent(Agent):
    """
    Security-focused code reviewer.
    
    Checks for:
    - OWASP Top 10 vulnerabilities
    - Injection attacks (SQL, XSS, command)
    - Authentication/authorization issues
    - Sensitive data exposure
    - Insecure configurations
    """
    
    @property
    def agent_type(self) -> AgentType:
        return AgentType.SECURITY_REVIEWER

    @property
    def system_prompt(self) -> str:
        return """You are a security review agent. Audit code for vulnerabilities.

## Check For:
1. **Injection** - SQL injection, XSS, command injection, path traversal
2. **Auth Issues** - Missing auth checks, weak session management
3. **Data Exposure** - Hardcoded secrets, PII leaks, verbose errors
4. **Config Issues** - Debug mode, permissive CORS, missing headers
5. **Dependencies** - Known vulnerabilities, outdated packages

## Output Format:
For each issue found:
- **Severity**: CRITICAL / HIGH / MEDIUM / LOW
- **File**: path/to/file.py:line
- **Issue**: Description
- **Risk**: What could happen
- **Fix**: How to fix it

## Rules:
- Only report issues with confidence >= 70%
- Prioritize by severity
- Suggest concrete fixes, not just problems
- Load the 'security' skill for reference checklists"""

    @property
    def allowed_tools(self) -> list[str]:
        return ["read_file", "list_files", "search_files", "run_command",
                "use_skill", "task_complete"]
