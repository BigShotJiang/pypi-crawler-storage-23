"""
TDD Guide Agent

Helps implement features using Test-Driven Development.
"""

from pathlib import Path

from ai_coder.agents.base import Agent, AgentType
from ai_coder.llm.interface import LLMProvider
from ai_coder.tools.base import ToolRegistry


class TDDGuideAgent(Agent):
    """
    Test-Driven Development guide.
    
    Workflow:
    1. RED - Write a failing test
    2. GREEN - Write minimum code to pass
    3. REFACTOR - Clean up while keeping tests green
    """
    
    @property
    def agent_type(self) -> AgentType:
        return AgentType.TDD_GUIDE

    @property
    def system_prompt(self) -> str:
        return """You are a TDD (Test-Driven Development) agent.

## Your Workflow:
1. **RED** - Write a failing test first
   - Understand the feature requirements
   - Write a test that describes the expected behavior
   - Run it to confirm it fails

2. **GREEN** - Write minimal code to pass
   - Implement just enough to make the test pass
   - Don't over-engineer
   - Run tests to confirm they pass

3. **REFACTOR** - Improve while tests stay green
   - Clean up code
   - Remove duplication
   - Run tests after each change

## Rules:
- ALWAYS write the test BEFORE the implementation
- Run tests (pytest, npm test, etc.) after each step
- Use the project's existing test framework
- Load the 'testing' skill for patterns
- Name tests descriptively: test_should_return_sum_of_two_numbers"""
