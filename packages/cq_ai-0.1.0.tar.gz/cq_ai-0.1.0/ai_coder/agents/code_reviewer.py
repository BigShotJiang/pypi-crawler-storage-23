"""
Code Reviewer Agent

Reviews code for bugs, quality issues, and project conventions.
"""

from pathlib import Path
from typing import Optional

from rich.console import Console

from ai_coder.agents.base import Agent, AgentResult, AgentType
from ai_coder.llm.interface import LLMProvider, Message
from ai_coder.tools.base import ToolRegistry

console = Console()


class CodeReviewerAgent(Agent):
    """
    Expert code reviewer with confidence-based filtering.
    
    Has full access to:
    - Read files
    - Run commands (git diff, etc.)
    - Search files
    
    Reviews:
    - Project guideline compliance
    - Bug detection
    - Code quality (DRY, simplicity, elegance)
    
    Only reports issues with confidence >= 80%.
    """
    
    @property
    def agent_type(self) -> AgentType:
        return AgentType.CODE_REVIEWER

    @property
    def system_prompt(self) -> str:
        return """You are an expert code reviewer specializing in modern software development.

## Available Tools
You have access to:
- **read_file**: Read code to review
- **run_command**: Run git diff, tests, etc.
- **search_files**: Find related code
- **list_files**: Explore project structure

USE THESE TOOLS to actually read and analyze the code!

## Review Process

1. **Get the Code**
   - Use run_command with "git diff" to see unstaged changes
   - Or use read_file to read specific files

2. **Analyze**
   - Check for bugs and logic errors
   - Look for code quality issues
   - Verify project conventions

3. **Report Issues**
   - Only report issues with confidence >= 80%
   - Include file path and line number
   - Provide specific fix suggestions

## Confidence Scoring

- **0**: False positive
- **25**: Might be an issue
- **50**: Real issue, but nitpick
- **75**: Very likely real issue
- **100**: Definitely a real issue

**Only report issues with confidence >= 80.**

## Output Format

For each issue:
- Description with confidence score
- File path and line number
- Explanation
- Concrete fix suggestion

If no issues found, confirm code meets standards."""

    # Uses inherited execute() method from Agent base class with full tool access
