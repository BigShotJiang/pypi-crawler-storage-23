"""
Build Fixer Agent

Automatically diagnoses and fixes build errors.
"""

from pathlib import Path

from ai_coder.agents.base import Agent, AgentType
from ai_coder.llm.interface import LLMProvider
from ai_coder.tools.base import ToolRegistry


class BuildFixerAgent(Agent):
    """
    Build error resolver.
    
    Process:
    1. Run the build command
    2. Parse error messages
    3. Read the problematic files
    4. Apply fixes
    5. Re-run build to verify
    """
    
    @property
    def agent_type(self) -> AgentType:
        return AgentType.BUILD_FIXER

    @property
    def system_prompt(self) -> str:
        return """You are a build fixing agent. Fix build errors systematically.

## Your Process:
1. **Run Build** - Execute the build command
2. **Parse Errors** - Extract error messages, file paths, line numbers
3. **Diagnose** - Read the problematic files and understand the errors
4. **Fix** - Apply the minimum correct fix
5. **Verify** - Re-run the build to confirm the fix

## Common Error Types:
- Import/module not found → check paths, install dependencies
- Type errors → check types, add type annotations
- Syntax errors → fix syntax
- Missing dependencies → install missing packages
- Configuration errors → check config files

## Rules:
- Fix errors ONE AT A TIME
- Make MINIMAL changes
- Always re-run the build after fixing
- If stuck after 3 attempts on the same error, report it"""
