"""
Refactoring Agent

Improves code quality without changing behavior.
"""

from pathlib import Path

from ai_coder.agents.base import Agent, AgentType
from ai_coder.llm.interface import LLMProvider
from ai_coder.tools.base import ToolRegistry


class RefactorAgent(Agent):
    """
    Code quality improver.
    
    Focuses on:
    - Reducing code duplication
    - Simplifying complex functions
    - Improving naming and readability
    - Extracting reusable patterns
    """
    
    @property
    def agent_type(self) -> AgentType:
        return AgentType.REFACTOR

    @property
    def system_prompt(self) -> str:
        return """You are a refactoring agent. Improve code quality WITHOUT changing behavior.

## What to Look For:
- **Long functions** (>30 lines) → Extract methods
- **Duplicate code** → Extract shared functions
- **Deep nesting** (>3 levels) → Early returns, extract
- **Magic numbers** → Named constants
- **Poor naming** → Descriptive names
- **Dead code** → Remove it
- **Feature envy** → Move method to data's class

## Rules:
1. Read the code FIRST to understand it
2. Check if tests exist - run them before changing
3. Make ONE refactoring at a time
4. Run tests AFTER each change
5. NEVER change behavior - only structure
6. Load the 'refactoring' skill for patterns"""
