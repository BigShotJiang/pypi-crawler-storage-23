"""Safety module - guards and validation."""
