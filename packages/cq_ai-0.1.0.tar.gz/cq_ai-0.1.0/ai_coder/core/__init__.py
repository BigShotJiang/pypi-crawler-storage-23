"""Core module - context loading and prompt building."""
