"""LLM module - language model interfaces."""

# Import interface components
from ai_coder.llm.interface import (
    Message,
    ToolCall,
    CompletionResponse,
    LLMConfig,
    LLMProvider,
    LLMError,
    RateLimitError,
    AuthenticationError,
    ModelNotFoundError,
    register_provider,
    get_provider,
    list_providers,
)

# Import all providers to register them
from ai_coder.llm import openai_provider
from ai_coder.llm import anthropic_provider
from ai_coder.llm import gemini_provider
from ai_coder.llm import huggingface_provider
from ai_coder.llm import openrouter_provider
from ai_coder.llm import custom_provider  # This registers ollama, lmstudio, together, groq, fireworks, azure

__all__ = [
    "Message",
    "ToolCall",
    "CompletionResponse",
    "LLMConfig",
    "LLMProvider",
    "LLMError",
    "RateLimitError",
    "AuthenticationError",
    "ModelNotFoundError",
    "register_provider",
    "get_provider",
    "list_providers",
]
