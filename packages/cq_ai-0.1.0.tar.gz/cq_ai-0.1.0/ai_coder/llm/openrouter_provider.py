"""
OpenRouter Provider Module

OpenRouter API - Access 100+ AI models with one API key:
- OpenAI models (GPT-4, GPT-4o)
- Anthropic models (Claude 3.5, Claude 3)
- Google models (Gemini)
- Meta models (Llama 3)
- Mistral, Cohere, and many more
"""

import json
import time
from typing import Optional

import httpx

from ai_coder.llm.interface import (
    LLMProvider,
    LLMConfig,
    Message,
    ToolCall,
    CompletionResponse,
    LLMError,
    RateLimitError,
    AuthenticationError,
    register_provider,
)


@register_provider("openrouter")
class OpenRouterProvider(LLMProvider):
    """
    OpenRouter API provider - one API for 100+ models.
    
    Get your API key at: https://openrouter.ai/keys
    
    Popular models:
    - openai/gpt-4o
    - anthropic/claude-3.5-sonnet
    - google/gemini-pro-1.5
    - meta-llama/llama-3.1-70b-instruct
    - mistralai/mistral-large
    """

    def __init__(self, config: LLMConfig):
        super().__init__(config)
        
        self.api_key = config.api_key
        if not self.api_key:
            raise AuthenticationError("OPENROUTER_API_KEY is required. Get one at https://openrouter.ai/keys")
        
        self.base_url = config.api_base or "https://openrouter.ai/api/v1"
        self.base_url = self.base_url.rstrip("/")
        
        self.headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
            "HTTP-Referer": "https://github.com/ai-coder",  # Optional but recommended
            "X-Title": "AI Coder",  # Optional
        }
        
        self.client = httpx.Client(timeout=config.timeout)

    def complete(
        self,
        messages: list[Message],
        tools: Optional[list[dict]] = None,
    ) -> CompletionResponse:
        """Generate completion using OpenRouter API."""
        formatted_messages = self._format_messages(messages)

        payload = {
            "model": self.config.model,
            "messages": formatted_messages,
            "max_tokens": self.config.max_tokens,
            "temperature": self.config.temperature,
        }

        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"

        url = f"{self.base_url}/chat/completions"

        for attempt in range(self.config.max_retries):
            try:
                response = self.client.post(url, headers=self.headers, json=payload)
                
                if response.status_code == 401:
                    raise AuthenticationError("OpenRouter API key is invalid")
                
                if response.status_code == 429:
                    if attempt < self.config.max_retries - 1:
                        wait_time = 2 ** attempt
                        time.sleep(wait_time)
                        continue
                    raise RateLimitError("Rate limit exceeded")
                
                if response.status_code >= 400:
                    error_text = response.text[:500]
                    raise LLMError(f"OpenRouter API error ({response.status_code}): {error_text}")
                
                return self._parse_response(response.json())

            except httpx.TimeoutException:
                if attempt < self.config.max_retries - 1:
                    time.sleep(1)
                    continue
                raise LLMError("Request timed out")
            
            except httpx.RequestError as e:
                if attempt < self.config.max_retries - 1:
                    time.sleep(1)
                    continue
                raise LLMError(f"Connection error: {e}")

        raise LLMError("Max retries exceeded")

    def _format_messages(self, messages: list[Message]) -> list[dict]:
        """Format messages for OpenRouter API (OpenAI-compatible)."""
        formatted = []

        for msg in messages:
            if msg.role == "tool":
                formatted.append({
                    "role": "tool",
                    "content": msg.content,
                    "tool_call_id": msg.tool_call_id or "",
                })
            elif msg.tool_calls:
                formatted.append({
                    "role": "assistant",
                    "content": msg.content or "",
                    "tool_calls": msg.tool_calls,
                })
            else:
                formatted.append({
                    "role": msg.role,
                    "content": msg.content,
                })

        return formatted

    def _parse_response(self, data: dict) -> CompletionResponse:
        """Parse OpenRouter API response."""
        choices = data.get("choices", [])
        if not choices:
            return CompletionResponse(content="No response generated")

        choice = choices[0]
        message = choice.get("message", {})

        tool_calls = []
        raw_tool_calls = message.get("tool_calls", [])
        for tc in raw_tool_calls:
            try:
                func = tc.get("function", {})
                args = func.get("arguments", "{}")
                if isinstance(args, str):
                    args = json.loads(args)
                
                tool_calls.append(ToolCall(
                    id=tc.get("id", ""),
                    name=func.get("name", ""),
                    arguments=args,
                ))
            except json.JSONDecodeError:
                pass

        usage = None
        if "usage" in data:
            usage = {
                "prompt_tokens": data["usage"].get("prompt_tokens", 0),
                "completion_tokens": data["usage"].get("completion_tokens", 0),
                "total_tokens": data["usage"].get("total_tokens", 0),
            }

        return CompletionResponse(
            content=message.get("content"),
            tool_calls=tool_calls,
            finish_reason=choice.get("finish_reason", "stop"),
            usage=usage,
            raw_response=data,
        )

    def count_tokens(self, text: str) -> int:
        """Estimate token count."""
        return len(text) // 4
