"""AI Coder - Terminal-native AI coding agent."""

import sys as _sys
import os as _os

# Fix Windows console encoding - must run before ANY Rich/print output
# This allows emoji and Unicode characters to display correctly on Windows
if _sys.platform == "win32":
    # Enable UTF-8 mode for the entire process
    _os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    try:
        _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        _sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, OSError):
        pass  # Already redirected or not a real terminal

__version__ = "0.1.0"
