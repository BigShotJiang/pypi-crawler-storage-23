---
name: security
description: Security best practices for code review, input validation, authentication, and common vulnerabilities. Use for security-related tasks.
---

# Security Skill

## OWASP Top 10 Checklist
1. **Injection**: Parameterize all queries, never concatenate user input
2. **Broken Auth**: Use established frameworks, MFA, secure session management  
3. **Sensitive Data**: Encrypt at rest and in transit, minimal data exposure
4. **XXE**: Disable external entities in XML parsers
5. **Broken Access Control**: Deny by default, validate on server side
6. **Misconfig**: Harden defaults, remove debug/test code
7. **XSS**: Encode output, use CSP headers
8. **Insecure Deserialization**: Validate input, use safe serializers
9. **Known Vulnerabilities**: Keep dependencies updated
10. **Insufficient Logging**: Log security events, monitor anomalies

## Input Validation
```python
# Always validate and sanitize
import re
from pathlib import Path

def validate_email(email: str) -> bool:
    return bool(re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email))

def safe_path(user_input: str, base_dir: Path) -> Path:
    """Prevent path traversal."""
    resolved = (base_dir / user_input).resolve()
    if not resolved.is_relative_to(base_dir):
        raise ValueError("Path traversal detected")
    return resolved
```

## Password Handling
```python
import bcrypt

hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
is_valid = bcrypt.checkpw(password.encode(), hashed)
# NEVER store plaintext passwords
```

## Common Dangerous Patterns
- `eval()`, `exec()` with user input
- `subprocess.run(shell=True)` with user input
- SQL string concatenation
- Hardcoded secrets in code
- Debug mode in production
- Permissive CORS settings
