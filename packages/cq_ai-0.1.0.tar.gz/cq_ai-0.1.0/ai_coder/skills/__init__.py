"""Skills module - on-demand knowledge injection system."""

from ai_coder.skills.loader import SkillLoader

__all__ = ["SkillLoader"]
