---
name: testing
description: Testing strategies, TDD workflow, unit/integration/e2e testing patterns. Use when writing or improving tests.
---

# Testing Skill

## TDD Workflow
1. **Red**: Write a failing test
2. **Green**: Write minimal code to pass
3. **Refactor**: Clean up while keeping tests green

## Test Structure (AAA Pattern)
```python
def test_user_creation():
    # Arrange
    name = "Alice"
    email = "alice@example.com"
    
    # Act
    user = create_user(name, email)
    
    # Assert
    assert user.name == name
    assert user.email == email
    assert user.id is not None
```

## Testing Pyramid
```
     /  E2E  \        Few, slow, expensive
    /Integration\      Some, moderate
   /   Unit Tests  \   Many, fast, cheap
```

## What to Test
- **Always**: Business logic, data transformations, edge cases
- **Usually**: API endpoints, database queries, error handling  
- **Sometimes**: UI rendering, third-party integrations
- **Rarely**: Getters/setters, framework code, constants

## Mocking
```python
from unittest.mock import Mock, patch

@patch('module.external_api')
def test_with_mock(mock_api):
    mock_api.return_value = {"status": "ok"}
    result = my_function()
    assert result == "ok"
    mock_api.assert_called_once()
```

## Coverage
```bash
pytest --cov=src --cov-report=term-missing
# Aim for 80%+ coverage on business logic
```
