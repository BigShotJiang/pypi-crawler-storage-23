---
name: git
description: Git workflow best practices, branching strategies, commit conventions, and common operations. Use for version control tasks.
---

# Git Workflow Skill

## Commit Conventions
Use conventional commits:
```
feat: add user authentication
fix: resolve login redirect bug  
docs: update API documentation
refactor: extract validation logic
test: add unit tests for auth module
chore: update dependencies
```

## Branching Strategy
```
main ← production-ready code
├── develop ← integration branch
│   ├── feature/auth-login
│   ├── feature/user-profile
│   └── fix/password-reset
└── release/v1.2.0
```

## Common Operations
```bash
# Stage and commit
git add -p                    # Interactive staging
git commit -m "feat: description"

# Branch management
git checkout -b feature/name  # Create branch
git merge --no-ff feature/name # Merge with commit

# View changes
git diff --staged             # Staged changes
git log --oneline -20         # Recent history
git log --graph --all         # Visual branch graph

# Undo operations
git stash                     # Save work temporarily
git stash pop                 # Restore stashed work
git reset --soft HEAD~1       # Undo last commit (keep changes)
git checkout -- file.py       # Discard file changes

# Rebase
git rebase -i HEAD~3          # Interactive rebase last 3
git rebase main               # Rebase onto main
```

## Pre-commit Checks
Always run before committing:
1. `git diff --staged` - Review changes
2. Run tests - Ensure nothing breaks
3. Run linter - Check code quality
4. Check for debug code - Remove console.log/print statements
