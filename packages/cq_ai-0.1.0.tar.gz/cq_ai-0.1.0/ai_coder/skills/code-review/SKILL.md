---
name: code-review
description: Systematic code review checklist covering correctness, security, performance, and maintainability. Use when reviewing code changes.
---

# Code Review Skill

## Review Checklist

### 1. Correctness (Most Important)
- [ ] Does the code do what it's supposed to?
- [ ] Are edge cases handled?
- [ ] Are error conditions handled gracefully?
- [ ] Are there any off-by-one errors?
- [ ] Is the logic correct for all input types?

### 2. Security
- [ ] No SQL injection (parameterized queries)
- [ ] No XSS (output encoding)
- [ ] Input validation on all boundaries
- [ ] No hardcoded secrets
- [ ] Authentication/authorization checks present
- [ ] File paths validated (no traversal)

### 3. Performance
- [ ] No N+1 query problems
- [ ] Appropriate indexing for queries
- [ ] No unnecessary loops or computations
- [ ] Pagination for large datasets
- [ ] Caching where appropriate

### 4. Maintainability
- [ ] Clear naming (functions, variables, classes)
- [ ] Functions are focused (single responsibility)
- [ ] No code duplication
- [ ] Comments explain WHY, not WHAT
- [ ] Consistent with project conventions

### 5. Testing
- [ ] Tests cover happy path
- [ ] Tests cover error cases
- [ ] Tests cover edge cases
- [ ] Tests are readable and maintainable

## Confidence Scoring
- **90-100%**: Definite bug or security issue
- **70-89%**: Very likely a real issue
- **50-69%**: Probable issue, worth discussing
- **Below 50%**: Don't report (too uncertain)

**Only report issues with confidence >= 70%**
