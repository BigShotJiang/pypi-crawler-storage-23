---
name: docker
description: Docker and containerization best practices, Dockerfile patterns, docker-compose. Use for containerization tasks.
---

# Docker Skill

## Dockerfile Best Practices
```dockerfile
# Use specific base image version
FROM python:3.12-slim

# Set working directory
WORKDIR /app

# Install dependencies first (cache layer)
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy source code
COPY . .

# Non-root user
RUN useradd -m appuser
USER appuser

# Expose port
EXPOSE 8000

# Health check
HEALTHCHECK CMD curl -f http://localhost:8000/health || exit 1

# Run application
CMD ["python", "-m", "uvicorn", "main:app", "--host", "0.0.0.0"]
```

## Docker Compose
```yaml
services:
  app:
    build: .
    ports: ["8000:8000"]
    environment:
      DATABASE_URL: postgresql://user:pass@db:5432/app
    depends_on:
      db: { condition: service_healthy }
  db:
    image: postgres:16-alpine
    volumes: [db_data:/var/lib/postgresql/data]
    healthcheck:
      test: pg_isready -U user
      interval: 5s
volumes:
  db_data:
```

## Key Commands
```bash
docker build -t myapp .
docker run -p 8000:8000 myapp
docker compose up -d
docker compose logs -f app
docker system prune -a       # Clean up
```
