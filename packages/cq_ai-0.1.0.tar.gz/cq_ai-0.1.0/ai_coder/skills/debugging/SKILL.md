---
name: debugging
description: Systematic debugging techniques, logging strategies, profiling tools. Use when diagnosing or fixing bugs.
---

# Debugging Skill

## Systematic Debugging Process
1. **Reproduce**: Create reliable reproduction steps
2. **Isolate**: Narrow down the location (binary search)
3. **Inspect**: Read the code, check state, add logging
4. **Hypothesize**: Form a theory about the cause
5. **Test**: Verify the hypothesis
6. **Fix**: Apply the minimal correct fix
7. **Verify**: Run tests, check edge cases

## Logging Strategy
```python
import logging

logger = logging.getLogger(__name__)

# Use appropriate levels
logger.debug("Variable state: %s", var)    # Development only
logger.info("User %s logged in", user_id)  # Normal operations
logger.warning("Disk usage at 85%%")        # Attention needed
logger.error("Failed to process: %s", e)    # Errors
logger.critical("Database connection lost")  # System failure
```

## Python Debugging Tools
```python
# Quick debug
import pdb; pdb.set_trace()     # Interactive debugger
breakpoint()                      # Python 3.7+

# Profiling
python -m cProfile script.py     # CPU profiling
python -m memory_profiler script.py  # Memory profiling

# Stack trace
import traceback
traceback.print_exc()
```

## Common Bug Patterns
- **Off-by-one**: Check loop bounds and array indexes
- **Race condition**: Check shared state and timing
- **Null reference**: Check for None/null before access
- **State mutation**: Check if objects are modified unexpectedly
- **Import order**: Check circular imports
- **Encoding**: Check UTF-8 vs ASCII, line endings
