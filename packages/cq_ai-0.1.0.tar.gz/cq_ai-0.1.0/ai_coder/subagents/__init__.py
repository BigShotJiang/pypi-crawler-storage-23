"""Subagents module - spawn focused subagents for decomposed tasks."""

from ai_coder.subagents.spawner import run_subagent, AGENT_TYPES, get_agent_descriptions

__all__ = ["run_subagent", "AGENT_TYPES", "get_agent_descriptions"]
