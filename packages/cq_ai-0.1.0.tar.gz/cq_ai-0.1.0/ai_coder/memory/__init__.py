"""Memory module - session state and history."""
