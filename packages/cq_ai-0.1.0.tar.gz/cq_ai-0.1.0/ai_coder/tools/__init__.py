"""Tools module - file editing, terminal execution."""
