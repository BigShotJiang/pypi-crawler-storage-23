# CQ-AI

**Terminal-native AI coding agent, developed by the CQ Team.**

CQ-AI (formerly ai-coder) is a powerful command-line tool that acts as your intelligent software engineering assistant. It integrates directly into your terminal, understands your codebase, and can plan, build, debug, and refactor code autonomously.

## Features

- 🖥️ **Interactive REPL** - Persistent `cq>` shell with slash commands
- 🤖 **Agentic Workflow** - Plan → Confirm → Execute → Verify
- 📁 **Repository Awareness** - Understands project structure and context
- ✏️ **Multi-File Editing** - Creates and modifies files with diff previews
- 🔧 **Tool Execution** - Runs builds, tests, and linters automatically
- 🛡️ **Safety Guards** - Prevents destructive actions without approval

## Installation

### Prerequisites
- Python 3.10+
- `pip` or `pipx`

### Install from source
```bash
git clone https://github.com/yourusername/cq-ai.git
cd cq-ai
pip install -e .
```

### Set up API key
Create a `.env` file in your project or set environment variables:
```bash
# For OpenAI (default)
export OPENAI_API_KEY=sk-your-key-here

# For Anthropic
export ANTHROPIC_API_KEY=sk-ant-your-key-here
```

## Usage

### Interactive Mode (Recommended)
Just type `cq` to enter the interactive REPL:

```bash
cq
```

You'll see the `cq-ai>` prompt. You can type natural language requests or use slash commands.

```text
cq-ai (my-project)> build a React login form
[Agent plans, creates files, and asks for confirmation]

cq-ai (my-project)> /debug the auth middleware
[Debugger agent analyzes and fixes issues]

cq-ai (my-project)> /help
```

### Slash Commands

| Command | Description |
|---------|-------------|
| `/build` | Interactive project builder |
| `/debug` | Find and fix bugs |
| `/review` | Code review and quality check |
| `/refactor`| Refactor code without changing behavior |
| `/plan` | Create implementation plan only |
| `/security`| Run security audit |
| `/test` | Test-driven development guide |
| `/fix` | Fix build/compile errors |
| `/config` | Run setup wizard |
| `/exit` | Exit the REPL |

### Single Command Mode
You can also run tasks directly from the shell without entering the REPL:

```bash
# Quick task
cq run "Add a dark mode toggle"

# Fix build errors
cq build-fix "npm run build"

# Security audit
cq security src/api/
```

## Configuration

Initialize configuration in your project:
```bash
cq init
```

Edit `.ai-coder/config.yaml`:
```yaml
llm:
  provider: "openai"  # openai, anthropic, huggingface, ollama, etc.
  model: "gpt-4o"
  temperature: 0.0

agent:
  max_iterations: 30
  auto_confirm: false
```

## License

MIT License
