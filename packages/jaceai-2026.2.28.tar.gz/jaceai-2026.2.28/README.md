# JaceAI — AI Web Browsing & Task Automation Agent for Python

[![PyPI](https://img.shields.io/pypi/v/jaceai.svg)](https://pypi.org/project/jaceai/) [![Python](https://img.shields.io/pypi/pyversions/jaceai.svg)](https://pypi.org/project/jaceai/) [![license](https://img.shields.io/pypi/l/jaceai.svg)](https://github.com/commandoperator/cmdop-sdk-python/blob/main/LICENSE)

![CMDOP Architecture](https://cmdop.com/images/architecture/vs-personal-agent.png)

JaceAI is your go-to Python library for AI web scraping and browser automation. As a headless browser AI agent, it excels at web task automation. Alternatives include Puppeteer, Playwright, Browserbase, and Stagehand, but JaceAI provides a simpler, more Pythonic API for complex web interactions.

## Features

- Automate complex web interactions with an AI-powered browser automation agent.
- Perform AI web scraping Python tasks to extract structured data from dynamic sites.
- Orchestrate web task automation using a headless browser AI.
- Manage headless browser instances for efficient web scraping in Python.

## Use Cases

- Scrape and extract structured data from any URL
- Automate web forms and interactions with AI
- Take screenshots and monitor websites remotely

## Installation

```bash
pip install jaceai
```

## Quick Start

```python
from jaceai import JaceAI

client = JaceAI.remote(api_key="cmdop_live_xxx")

data = client.extract("https://news.ycombinator.com", "top 5 story titles")
print(data)

client.fill_form("https://example.com/contact", "Fill name with 'Alice', email with 'alice@example.com' and submit")
```

## Links

- [CMDOP Homepage](https://cmdop.com)
- [Documentation](https://cmdop.com/docs/sdk/python/)
- [jaceai on PyPI](https://pypi.org/project/jaceai/)
- [GitHub](https://github.com/commandoperator/cmdop-sdk-python)
