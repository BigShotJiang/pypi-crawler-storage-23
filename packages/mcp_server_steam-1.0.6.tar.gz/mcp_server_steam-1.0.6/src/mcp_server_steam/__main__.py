"""Entry point for python -m mcp_server_steam."""

from mcp_server_steam import main

if __name__ == "__main__":
    main()
