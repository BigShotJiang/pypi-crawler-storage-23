"""High-level Pmini client that exposes convenient drone control helpers."""

from __future__ import annotations

import logging
import time
from typing import Callable, Optional, Sequence

from .common import Attitude, BatteryStatus, CommandResult, FlightMode, LidarFrame, Position
from .config import DEFAULT_PMINI_CONFIG, PminiConfig
from .zenoh_client import ZenohClient

logger = logging.getLogger(__name__)

# MAV_FRAME constants
MAV_FRAME_LOCAL_NED = 1
MAV_FRAME_LOCAL_OFFSET_NED = 7
MAV_FRAME_BODY_NED = 8
MAV_FRAME_BODY_OFFSET_NED = 9  # Default


def _parse_frame(frame: str | int | None) -> int:
    """
    Convert frame string or number to MAV_FRAME numeric value.

    Args:
        frame: Frame as string ("local", "body", "local_offset", "body_offset")
               or integer (1, 7, 8, 9), or None for default.

    Returns:
        MAV_FRAME numeric value (defaults to 9 = BODY_OFFSET_NED).
    """
    if frame is None:
        return MAV_FRAME_BODY_OFFSET_NED

    if isinstance(frame, int):
        # Validate numeric frame values
        if frame in (1, 7, 8, 9):
            return frame
        raise ValueError(f"Invalid frame value: {frame}. Must be 1, 7, 8, or 9.")

    if isinstance(frame, str):
        frame_lower = frame.lower()
        frame_map = {
            "local": MAV_FRAME_LOCAL_NED,
            "local_offset": MAV_FRAME_LOCAL_OFFSET_NED,
            "body": MAV_FRAME_BODY_NED,
            "body_offset": MAV_FRAME_BODY_OFFSET_NED,
        }
        if frame_lower in frame_map:
            return frame_map[frame_lower]
        # Try to parse as integer string
        try:
            frame_int = int(frame_lower)
            if frame_int in (1, 7, 8, 9):
                return frame_int
        except ValueError:
            pass
        raise ValueError(
            f"Invalid frame name: {frame}. Must be one of: local, body, local_offset, body_offset, or 1, 7, 8, 9."
        )

    raise TypeError(f"Frame must be str, int, or None, got {type(frame).__name__}")


class Pmini:
    """High-level synchronous client built on top of :class:`ZenohClient`."""

    def __init__(self, config: Optional[PminiConfig] = None):
        self._config = config or DEFAULT_PMINI_CONFIG
        self._zenoh = ZenohClient(self._config)

    # ------------------------------------------------------------------
    # Connection management
    # ------------------------------------------------------------------
    def connect(self) -> None:
        """Open the underlying Zenoh session and start telemetry subscriptions."""
        logger.info("Connecting to PMini via Zenoh...")
        self._zenoh.connect()

    def disconnect(self) -> None:
        """Disconnect from the drone."""
        logger.info("Disconnecting from PMini...")
        self._zenoh.disconnect()

    # ------------------------------------------------------------------
    # Telemetry accessors
    # ------------------------------------------------------------------
    def get_position(self) -> Optional[Position]:
        """Return the latest position sample (if available)."""
        return self._zenoh.get_position()

    def add_position_callback(self, callback: Callable[[Position], None]) -> None:
        self._zenoh.add_position_callback(callback)

    def remove_position_callback(self, callback: Callable[[Position], None]) -> None:
        self._zenoh.remove_position_callback(callback)

    def get_attitude(self) -> Optional[Attitude]:
        """Return the latest attitude sample (if available)."""
        return self._zenoh.get_attitude()

    def add_attitude_callback(self, callback: Callable[[Attitude], None]) -> None:
        self._zenoh.add_attitude_callback(callback)

    def remove_attitude_callback(self, callback: Callable[[Attitude], None]) -> None:
        self._zenoh.remove_attitude_callback(callback)

    def get_battery(self) -> Optional[BatteryStatus]:
        """Return the latest battery sample (if available)."""
        return self._zenoh.get_battery()

    def add_battery_callback(self, callback: Callable[[BatteryStatus], None]) -> None:
        self._zenoh.add_battery_callback(callback)

    def remove_battery_callback(self, callback: Callable[[BatteryStatus], None]) -> None:
        self._zenoh.remove_battery_callback(callback)

    def get_status(self) -> Optional[dict]:
        return self._zenoh.get_status()

    def get_status_text(self) -> Optional[dict]:
        return self._zenoh.get_status_text()

    def add_status_text_callback(self, callback: Callable[[dict], None]) -> None:
        self._zenoh.add_status_text_callback(callback)

    def remove_status_text_callback(self, callback: Callable[[dict], None]) -> None:
        self._zenoh.remove_status_text_callback(callback)

    # ------------------------------------------------------------------
    # Telemetry convenience methods (used by Blockly-generated code)
    # ------------------------------------------------------------------
    def get_position_value(self, component: Optional[str] = None):
        """Get position value. component: 'x', 'y', 'z', or None for dict."""
        pos = self.get_position()
        if pos is None:
            return 0.0 if component else {"x": 0.0, "y": 0.0, "z": 0.0}
        if component is None:
            return {"x": pos.x, "y": pos.y, "z": pos.z}
        return getattr(pos, component, 0.0)

    def get_velocity_value(self, component: Optional[str] = None):
        """Get velocity value from sensors. component: 'x', 'y', 'z', or None for dict."""
        sensors = self._zenoh.get_sensors()
        if sensors and "imu" in sensors:
            # IMU sensor values: [ax, ay, az, gx, gy, gz, mx, my, mz, vx, vy, vz]
            # Velocity may not be in IMU; fall back to status
            pass
        # Velocity not directly published as separate topic; return from sensors or 0
        return 0.0 if component else {"x": 0.0, "y": 0.0, "z": 0.0}

    def get_attitude_value(self, component: Optional[str] = None):
        """Get attitude value. component: 'roll', 'pitch', 'yaw', or None for dict."""
        att = self.get_attitude()
        if att is None:
            return 0.0 if component else {"roll": 0.0, "pitch": 0.0, "yaw": 0.0}
        if component is None:
            return {"roll": att.roll, "pitch": att.pitch, "yaw": att.yaw}
        return getattr(att, component, 0.0)

    def get_angular_velocity_value(self, component: Optional[str] = None):
        """Get angular velocity. component: 'roll', 'pitch', 'yaw', or None for dict."""
        sensors = self._zenoh.get_sensors()
        if sensors and "imu" in sensors:
            vals = sensors["imu"]
            if len(vals) >= 6:
                mapping = {"roll": vals[3], "pitch": vals[4], "yaw": vals[5]}
                if component is None:
                    return mapping
                return mapping.get(component, 0.0)
        return 0.0 if component else {"roll": 0.0, "pitch": 0.0, "yaw": 0.0}

    def get_acceleration_value(self, component: Optional[str] = None):
        """Get acceleration value. component: 'x', 'y', 'z', or None for dict."""
        sensors = self._zenoh.get_sensors()
        if sensors and "imu" in sensors:
            vals = sensors["imu"]
            if len(vals) >= 3:
                mapping = {"x": vals[0], "y": vals[1], "z": vals[2]}
                if component is None:
                    return mapping
                return mapping.get(component, 0.0)
        return 0.0 if component else {"x": 0.0, "y": 0.0, "z": 0.0}

    def get_lidar_distance(self) -> float:
        """Get downward lidar distance in meters."""
        frame: Optional[LidarFrame] = self._zenoh.get_lidar_frame()
        if frame is not None and frame.ranges_mm:
            # Center 4 pixels of 8x8 grid: indices 27, 28, 35, 36
            center_indices = [27, 28, 35, 36]
            valid_ranges = []
            for i in center_indices:
                if i < len(frame.ranges_mm) and i < len(frame.status):
                    if frame.status[i] in (5, 9) and frame.ranges_mm[i] > 0:
                        valid_ranges.append(frame.ranges_mm[i])
            if valid_ranges:
                return sum(valid_ranges) / len(valid_ranges) / 1000.0
        # Fallback: try rangefinder sensor
        sensors = self._zenoh.get_sensors()
        if sensors and "rangefinder" in sensors:
            vals = sensors["rangefinder"]
            if vals:
                return vals[0]
        return 0.0

    def get_altitude(self) -> float:
        """Get current altitude in meters (positive = above ground)."""
        pos = self.get_position()
        if pos is not None:
            return -pos.z  # NED: z is down, altitude is up
        return 0.0

    def get_battery_voltage(self) -> float:
        """Get battery voltage in volts."""
        bat = self.get_battery()
        return bat.voltage if bat else 0.0

    def get_battery_current(self) -> float:
        """Get battery current draw in amps."""
        bat = self.get_battery()
        return bat.current if bat else 0.0

    def get_battery_remaining(self) -> float:
        """Get battery remaining percentage (0-100)."""
        bat = self.get_battery()
        return bat.remaining_percent if bat else 0.0

    # ------------------------------------------------------------------
    # Environment sensor convenience methods
    # ------------------------------------------------------------------
    def _get_sensor_value(self, sensor_type: str, index: int = 0) -> float:
        """Get a single value from the sensor telemetry by type and index."""
        sensors = self._zenoh.get_sensors()
        if sensors and sensor_type in sensors:
            vals = sensors[sensor_type]
            if len(vals) > index:
                return vals[index]
        return 0.0

    def get_sensor_values(self, sensor_type: str):
        """Get all values for a sensor type as a list."""
        sensors = self._zenoh.get_sensors()
        if sensors and sensor_type in sensors:
            return sensors[sensor_type]
        return []

    def get_temperature(self) -> float:
        """Get ambient temperature in degrees Celsius."""
        return self._get_sensor_value("temperature", 0)

    def get_humidity(self) -> float:
        """Get relative humidity percentage."""
        return self._get_sensor_value("temperature", 1)

    def get_pressure(self) -> float:
        """Get barometric pressure in hectopascals."""
        return self._get_sensor_value("barometer", 0)

    def get_barometric_altitude(self) -> float:
        """Get altitude from barometric pressure in meters."""
        return self._get_sensor_value("barometer", 1)

    def get_gas_concentration(self) -> float:
        """Get gas concentration in ppm."""
        return self._get_sensor_value("gas", 0)

    def get_light_level(self) -> float:
        """Get ambient light level in lux."""
        return self._get_sensor_value("light", 0)

    def get_sound_level(self) -> float:
        """Get ambient sound level in dB."""
        return self._get_sensor_value("sound", 0)

    def get_co2_level(self) -> float:
        """Get CO2 concentration in ppm."""
        return self._get_sensor_value("co2", 0)

    def get_magnetic_field_value(self, component: Optional[str] = None):
        """Get magnetic field value. component: 'x', 'y', 'z', or None for dict."""
        sensors = self._zenoh.get_sensors()
        if sensors and "imu" in sensors:
            vals = sensors["imu"]
            if len(vals) >= 9:
                mapping = {"x": vals[6], "y": vals[7], "z": vals[8]}
                if component is None:
                    return mapping
                return mapping.get(component, 0.0)
        return 0.0 if component else {"x": 0.0, "y": 0.0, "z": 0.0}

    # ------------------------------------------------------------------
    # Boolean detector methods
    # ------------------------------------------------------------------
    def is_flame_detected(self) -> bool:
        """Returns True if flame is detected."""
        return self._get_sensor_value("flame", 0) > 0.5

    def is_sound_detected(self) -> bool:
        """Returns True if loud sound is detected."""
        return self._get_sensor_value("sound", 1) > 0.5 if len(self.get_sensor_values("sound")) > 1 else False

    def is_knocked(self) -> bool:
        """Returns True if a knock/collision is detected."""
        return self._get_sensor_value("knock", 0) > 0.5

    def is_touching_ground(self) -> bool:
        """Returns True if the drone is on the ground."""
        return self._get_sensor_value("touch", 0) > 0.5

    # ------------------------------------------------------------------
    # Command helpers
    # ------------------------------------------------------------------
    def takeoff(self, altitude_m: float = 1.0) -> CommandResult:
        return self._zenoh.send_command("takeoff", args=[altitude_m])

    def land(self) -> CommandResult:
        return self._zenoh.send_command("land")

    def arm(self) -> CommandResult:
        return self._zenoh.send_command("arm")

    def disarm(self) -> CommandResult:
        return self._zenoh.send_command("disarm")

    def set_mode(self, mode: FlightMode | str) -> CommandResult:
        mode_name = mode.value if isinstance(mode, FlightMode) else str(mode)
        return self._zenoh.send_command("mode", extra_payload={"args": [mode_name]})

    def emergency_stop(self) -> CommandResult:
        return self._zenoh.send_command("emergency_stop")

    def reboot(self) -> CommandResult:
        return self._zenoh.send_command("reboot")

    def goto_local_ned(self, x: float, y: float, z: float, yaw: float | None = 0.0) -> CommandResult:
        """Legacy method: goto with BODY_OFFSET_NED frame (default)."""
        return self.goto(x, y, z, yaw, frame=MAV_FRAME_BODY_OFFSET_NED)

    def goto(
        self,
        x: float,
        y: float,
        z: float,
        yaw: float | None = 0.0,
        frame: str | int = MAV_FRAME_BODY_OFFSET_NED,
    ) -> CommandResult:
        """
        Send a goto command to move to a position.

        Args:
            x: X coordinate (meters)
            y: Y coordinate (meters)
            z: Z coordinate (meters, up is positive)
            yaw: Optional yaw angle (radians). Defaults to 0.0.
            frame: Frame type as string ("local", "body", "local_offset", "body_offset")
                   or integer (1, 7, 8, 9). Defaults to 9 (BODY_OFFSET_NED).

        Returns:
            CommandResult with status and message.
        """
        frame_value = _parse_frame(frame)
        args = [x, y, z]
        if yaw is not None:
            args.append(yaw)
        args.append(frame_value)
        return self._zenoh.send_command("goto", args=args)

    def move_velocity(self, v_x: float, v_y: float, v_z: float, yaw_rate: float = 0.0, duration: float = 1.0) -> CommandResult:
        """Set velocity in body frame. vx=forward, vy=right, vz=down (m/s)."""
        args = [v_x, v_y, v_z, duration, yaw_rate]
        return self._zenoh.send_command("velocity", args=args)

    def set_velocity_local_ned(self, v_x: float, v_y: float, v_z: float, yaw: float | None = 0.0) -> CommandResult:
        args = [v_x, v_y, v_z]
        if yaw is not None:
            args.append(yaw)
        return self._zenoh.send_command("velocity", args=args)

    def set_speed(self, speed_percent: float) -> CommandResult:
        """Set global flight speed (1-100%)."""
        return self._zenoh.send_command("set_speed", args=[speed_percent])

    def yaw_to(self, heading_rad: float) -> CommandResult:
        """Turn to a specific heading in radians."""
        return self._zenoh.send_command("yaw_to", args=[heading_rad])

    def flip(self, direction: str) -> CommandResult:
        """Perform an aerial flip. direction: 'forward', 'backward', 'left', 'right'."""
        return self._zenoh.send_command("flip", args=[], extra_payload={"direction": direction})

    def set_led(self, r: int, g: int, b: int) -> CommandResult:
        """Set LED color (RGB 0-255)."""
        return self._zenoh.send_command("set_led", args=[r, g, b])

    def play_buzzer(self, frequency: float, duration: float) -> CommandResult:
        """Play a buzzer tone. frequency in Hz, duration in seconds."""
        return self._zenoh.send_command("play_buzzer", args=[frequency, duration])

    def log_list(self) -> CommandResult:
        return self._zenoh.send_command("log_list")

    def log_download(self, log_id: int, max_bytes: int | None = None) -> CommandResult:
        args = [int(log_id)]
        if max_bytes is not None:
            limit = int(max_bytes)
            if limit > 0:
                args.append(limit)
        return self._zenoh.send_command("log_download", args=args)

    def log_download_to_file(
        self,
        log_id: int,
        path: str,
        *,
        max_bytes: int | None = None,
        timeout: float = 120.0,
        progress_callback: Optional[Callable[[dict], None]] = None,
    ) -> CommandResult:
        return self._zenoh.download_log_to_file(
            log_id,
            path,
            max_bytes=max_bytes,
            timeout=timeout,
            progress_callback=progress_callback,
        )

    def log_clear(self) -> CommandResult:
        """Erase all logs stored on the vehicle."""
        return self._zenoh.clear_logs()

    def custom_command(
        self, command: str, args: Optional[Sequence[float]] = None, extra_payload: Optional[dict] = None
    ) -> CommandResult:
        """Send a custom command not covered by helpers."""
        return self._zenoh.send_command(command, args=args, extra_payload=extra_payload)

    # ------------------------------------------------------------------
    # APEX GD-149 high-level commands
    # ------------------------------------------------------------------
    _THROTTLE_VZ_MAP = {0: -0.5, 1: -0.33, 2: -0.17, 3: 0.0, 4: 0.17, 5: 0.33, 6: 0.5}
    _SPEED_MAP = {1: 0.3, 2: 0.6, 3: 1.0}

    def active_fly(self) -> CommandResult:
        """APEX GD-149: Arm the drone motors for flight."""
        return self.arm()

    def take_off(self) -> CommandResult:
        """APEX GD-149: Take off to default height (1m)."""
        return self.takeoff(1.0)

    def apex_land(self) -> CommandResult:
        """APEX GD-149: Land the drone."""
        return self.land()

    def throttle(self, value: int) -> CommandResult:
        """APEX GD-149: Set throttle level (0-6). Maps to vertical velocity."""
        vz = self._THROTTLE_VZ_MAP.get(value, 0.0)
        return self.move_velocity(0, 0, vz)

    def rotate(self, direction: str, speed: int) -> None:
        """APEX GD-149: Rotate left/right at given speed (1-3) for 1 second."""
        yaw_rate = self._SPEED_MAP.get(speed, 0.3)
        if direction.upper() == "LEFT":
            yaw_rate = -yaw_rate
        self.move_velocity(0, 0, 0, yaw_rate=yaw_rate)
        time.sleep(1)
        self.move_velocity(0, 0, 0, yaw_rate=0.0)

    def fly(self, direction: str, speed: int) -> None:
        """APEX GD-149: Fly in a direction at given speed (1-3) for 1 second."""
        v = self._SPEED_MAP.get(speed, 0.3)
        vx, vy = 0.0, 0.0
        d = direction.upper()
        if d == "FRONT":
            vx = v
        elif d == "BACK":
            vx = -v
        elif d == "LEFT":
            vy = -v
        elif d == "RIGHT":
            vy = v
        self.move_velocity(vx, vy, 0)
        time.sleep(1)
        self.move_velocity(0, 0, 0)
