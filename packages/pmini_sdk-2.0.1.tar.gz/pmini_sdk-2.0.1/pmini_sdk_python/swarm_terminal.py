"""Interactive terminal for broadcasting Zenoh commands to multiple PMini drones."""

from __future__ import annotations

import cmd
import json
import logging
import shlex
import threading
import time
from dataclasses import dataclass, field
from typing import Any, List, Optional, Sequence, Tuple

from .config import DEFAULT_PMINI_CONFIG, PminiConfig

logger = logging.getLogger(__name__)

try:
    import zenoh  # type: ignore
except ImportError as exc:  # pragma: no cover - dependency missing
    zenoh = None  # type: ignore
    _ZENOH_IMPORT_ERROR: Optional[ImportError] = exc
else:  # pragma: no cover - exercised in integration
    _ZENOH_IMPORT_ERROR = None


DEFAULT_DRONE_IDS = ["pmini01"]


class SwarmCommandClient:
    """Minimal Zenoh publisher used to push commands onto pmini/<id>/command/<name> topics."""

    def __init__(self, config: Optional[PminiConfig] = None):
        if zenoh is None:
            raise RuntimeError(
                "zenoh package is not available. Install with `pip install eclipse-zenoh`"
            ) from _ZENOH_IMPORT_ERROR

        self._config = config or DEFAULT_PMINI_CONFIG
        self._session: Optional[Any] = None
        self._lock = threading.Lock()

    def connect(self) -> None:
        with self._lock:
            if self._session is not None:
                logger.debug("Zenoh session already active")
                return

            conf = zenoh.Config()
            conf.insert_json5("mode", json.dumps(self._config.mode))

            listen_endpoints = self._decorate_endpoints(self._config.listen_endpoints)
            connect_endpoints = self._decorate_endpoints(self._config.connect_endpoints)
            if listen_endpoints:
                conf.insert_json5("listen/endpoints", json.dumps(listen_endpoints))
            if connect_endpoints:
                conf.insert_json5("connect/endpoints", json.dumps(connect_endpoints))

            logger.info(
                "Opening Zenoh session (mode=%s, listen=%s, connect=%s)",
                self._config.mode,
                listen_endpoints or None,
                connect_endpoints or None,
            )
            self._session = zenoh.open(conf)
            if self._config.wait_seconds > 0:
                time.sleep(self._config.wait_seconds)

    def disconnect(self) -> None:
        with self._lock:
            if self._session:
                try:
                    self._session.close()
                finally:
                    self._session = None

    def publish_command(
        self,
        drone_ids: Sequence[str],
        command: str,
        payload: Optional[dict],
        *,
        broadcast: bool = False,
    ) -> None:
        session = self._require_session()

        topics = self._resolve_topics(drone_ids, command, broadcast)
        body = json.dumps(payload or {}, separators=(",", ":")).encode("utf-8") if payload else b""

        for topic in topics:
            logger.debug("Publishing %s to %s", command, topic)
            session.put(topic, body)

    def _require_session(self):
        if self._session is None:
            raise RuntimeError("Zenoh session not connected. Run 'connect' first.")
        return self._session

    def _decorate_endpoints(self, endpoints: Sequence[str]) -> List[str]:
        result: List[str] = []
        for endpoint in endpoints:
            if not endpoint:
                continue
            value = endpoint.strip()
            if self._config.iface and "#iface=" not in value:
                value = f"{value}#iface={self._config.iface}"
            result.append(value)
        return result

    @staticmethod
    def _resolve_topics(drone_ids: Sequence[str], command: str, broadcast: bool) -> List[str]:
        suffix = command.strip().lower()
        if not suffix:
            raise ValueError("Command name is required")
        if broadcast or not drone_ids:
            return [f"pmini/all/command/{suffix}"]
        topics = [f"pmini/{drone_id.strip()}/command/{suffix}" for drone_id in drone_ids if drone_id.strip()]
        if not topics:
            raise ValueError("No valid drone ids provided")
        return topics


@dataclass
class TargetSelection:
    use_all: bool = False
    ids: List[str] = field(default_factory=list)


class PminiSwarmTerminal(cmd.Cmd):
    intro = (
        "PMini Swarm Terminal\n"
        "====================\n"
        "Type 'help' for commands. Use 'targets' to set default drone IDs.\n"
        "Connect to router: 'connect router=udp/192.168.1.129:7447'\n"
        "Use '--all' or 'all_*' helpers to broadcast to every drone.\n"
    )
    prompt = "pmini-swarm> "

    def __init__(self):
        super().__init__()
        self._client: Optional[SwarmCommandClient] = None
        self._default_ids: List[str] = DEFAULT_DRONE_IDS.copy()

    # ------------------------------------------------------------------
    # Connection
    # ------------------------------------------------------------------
    def do_connect(self, arg: str) -> None:
        """connect [router=udp/IP:PORT] [mode=client] [iface=wlan0]

        Connect to Zenoh router via UDP. Examples:
          connect router=udp/192.168.1.129:7447
          connect router=192.168.1.129:7447  (UDP assumed)
          connect 192.168.1.129:7447  (shorthand)"""
        if self._client:
            print("Already connected.")
            return

        config = PminiConfig()
        config.mode = "client"  # Default to client mode for router connection

        tokens = self._split(arg)
        router_endpoint = None

        for token in tokens:
            key, _, value = token.partition("=")
            if key == "router" and value:
                router_endpoint = value
            elif key == "mode" and value:
                config.mode = value
            elif key == "listen" and value:
                config.listen_endpoints = [value]
            elif key == "connect" and value:
                router_endpoint = value
            elif key == "iface" and value:
                config.iface = value
            elif ":" in token and not key:  # Shorthand: just IP:PORT
                router_endpoint = token

        # Normalize router endpoint to UDP format
        if router_endpoint:
            if not router_endpoint.startswith(("udp/", "tcp/")):
                router_endpoint = f"udp/{router_endpoint}"
            config.connect_endpoints = [router_endpoint]
        # If no router specified, use default from config (which may need updating)

        try:
            client = SwarmCommandClient(config=config)
            client.connect()
        except Exception as exc:  # noqa: BLE001
            print(f"Failed to connect: {exc}")
            return

        self._client = client
        endpoints = config.connect_endpoints or ["<default>"]
        print(f"Connected successfully to router: {', '.join(endpoints)}")

    def do_disconnect(self, _: str) -> None:
        """Disconnect from Zenoh."""
        if not self._client:
            print("Not connected.")
            return
        self._client.disconnect()
        self._client = None
        print("Disconnected.")

    # ------------------------------------------------------------------
    # Command helpers
    # ------------------------------------------------------------------
    def do_takeoff(self, arg: str) -> None:
        """takeoff [altitude_m] [--all] [--ids id1,id2]"""
        tokens, selection = self._extract_targets(arg)
        altitude = self._parse_optional_float(tokens[0]) if tokens else None
        payload = {"altitude": altitude} if altitude is not None else None
        self._send_command("takeoff", selection, payload)

    def do_land(self, arg: str) -> None:
        """land [--all] [--ids id1,id2]"""
        _, selection = self._extract_targets(arg)
        self._send_command("land", selection, None)

    def do_arm(self, arg: str) -> None:
        """arm [--all] [--ids id1,id2]"""
        _, selection = self._extract_targets(arg)
        self._send_command("arm", selection, None)

    def do_disarm(self, arg: str) -> None:
        """disarm [--all] [--ids id1,id2]"""
        _, selection = self._extract_targets(arg)
        self._send_command("disarm", selection, None)

    def do_goto(self, arg: str) -> None:
        """goto x y z [yaw] [--all] [--ids id1,id2]"""
        tokens, selection = self._extract_targets(arg)
        if len(tokens) < 3:
            print("Usage: goto x y z [yaw] [--all|--ids]")
            return
        try:
            x, y, z = (float(tokens[i]) for i in range(3))
            yaw = float(tokens[3]) if len(tokens) >= 4 else 0.0
        except ValueError:
            print("All parameters must be numeric.")
            return
        payload = {"x": x, "y": y, "z": z, "yaw": yaw}
        self._send_command("goto", selection, payload)

    def do_emergency_stop(self, arg: str) -> None:
        """emergency_stop [--all] [--ids id1,id2]"""
        _, selection = self._extract_targets(arg)
        self._send_command("emergency_stop", selection, None)

    def do_mode(self, arg: str) -> None:
        """mode <name|custom_mode> [--all] [--ids id1,id2]"""
        tokens, selection = self._extract_targets(arg)
        if not tokens:
            print("Usage: mode <name|custom_mode> [--all|--ids]")
            return
        payload = self._build_mode_payload(tokens[0])
        self._send_command("mode", selection, payload)

    def do_log_clear(self, arg: str) -> None:
        """log_clear [--all] [--ids id1,id2]"""
        _, selection = self._extract_targets(arg)
        self._send_command("log_clear", selection, None)

    # ------------------------------------------------------------------
    # Broadcast helpers
    # ------------------------------------------------------------------
    def do_all_takeoff(self, arg: str) -> None:
        """all_takeoff [altitude_m] — broadcast takeoff to all drones."""
        tokens = self._split(arg)
        altitude = self._parse_optional_float(tokens[0]) if tokens else None
        payload = {"altitude": altitude} if altitude is not None else None
        self._send_command("takeoff", self._broadcast_selection(), payload)

    def do_all_land(self, arg: str) -> None:
        """all_land — broadcast landing to all drones."""
        self._send_command("land", self._broadcast_selection(), None)

    def do_all_arm(self, arg: str) -> None:
        """all_arm — broadcast arm to all drones."""
        self._send_command("arm", self._broadcast_selection(), None)

    def do_all_disarm(self, arg: str) -> None:
        """all_disarm — broadcast disarm to all drones."""
        self._send_command("disarm", self._broadcast_selection(), None)

    def do_all_mode(self, arg: str) -> None:
        """all_mode <name|custom_mode> — broadcast mode change."""
        tokens = self._split(arg)
        if not tokens:
            print("Usage: all_mode <name|custom_mode>")
            return
        payload = self._build_mode_payload(tokens[0])
        self._send_command("mode", self._broadcast_selection(), payload)

    def do_all_goto(self, arg: str) -> None:
        """all_goto x y z [yaw] — broadcast goto to all drones."""
        tokens = self._split(arg)
        if len(tokens) < 3:
            print("Usage: all_goto x y z [yaw]")
            return
        try:
            x, y, z = (float(tokens[i]) for i in range(3))
            yaw = float(tokens[3]) if len(tokens) >= 4 else 0.0
        except ValueError:
            print("All parameters must be numeric.")
            return
        payload = {"x": x, "y": y, "z": z, "yaw": yaw}
        self._send_command("goto", self._broadcast_selection(), payload)

    def do_all_emergency_stop(self, arg: str) -> None:
        """all_emergency_stop — broadcast emergency stop."""
        self._send_command("emergency_stop", self._broadcast_selection(), None)

    def do_all_log_clear(self, arg: str) -> None:
        """all_log_clear — broadcast log clearing."""
        self._send_command("log_clear", self._broadcast_selection(), None)

    def do_targets(self, arg: str) -> None:
        """targets [id1 id2 ...]  (show or set default drone ids)"""
        tokens = self._split(arg)
        if not tokens:
            if self._default_ids:
                print("Current targets:", ", ".join(self._default_ids))
            else:
                print("No default targets set.")
            return
        self._default_ids = tokens
        print("Default targets set to:", ", ".join(self._default_ids))

    # ------------------------------------------------------------------
    # Session management
    # ------------------------------------------------------------------
    def do_status(self, _: str) -> None:
        """Show connection status."""
        if self._client:
            endpoints = self._client._config.connect_endpoints or []
            if endpoints:
                print(f"Connected to router: {', '.join(endpoints)}")
            else:
                print("Connected (using default endpoints).")
        else:
            print("Not connected.")
        if self._default_ids:
            print("Default targets:", ", ".join(self._default_ids))
        else:
            print("Default targets: <broadcast only>")

    def do_quit(self, _: str) -> bool:
        """Exit the terminal."""
        self._cleanup()
        print("Goodbye!")
        return True

    def do_exit(self, arg: str) -> bool:  # pragma: no cover - alias
        return self.do_quit(arg)

    def do_EOF(self, arg: str) -> bool:  # pragma: no cover - alias
        print()
        return self.do_quit(arg)

    def default(self, line: str) -> None:
        print(f"Unknown command: {line}")

    def help_general(self) -> None:
        """Explain how to broadcast commands to every drone."""
        print("Broadcast commands send to 'pmini/all/command/<name>'.")
        print("Use '--all' with any command or the dedicated 'all_*' helpers, e.g.:")
        print("  takeoff 1.2 --all")
        print("  all_mode GUIDED")
        print("  all_emergency_stop")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _cleanup(self) -> None:
        if self._client:
            self._client.disconnect()
            self._client = None

    def _ensure_client(self) -> SwarmCommandClient:
        if not self._client:
            raise RuntimeError("Not connected. Use 'connect' first.")
        return self._client

    def _split(self, arg: str) -> List[str]:
        if not arg:
            return []
        try:
            return shlex.split(arg)
        except ValueError as exc:
            print(f"Failed to parse arguments: {exc}")
            return []

    def _extract_targets(self, arg: str) -> Tuple[List[str], TargetSelection]:
        tokens = self._split(arg)
        selection = TargetSelection()
        remaining: List[str] = []
        i = 0
        while i < len(tokens):
            token = tokens[i]
            if token in ("--all", "-a"):
                selection.use_all = True
                i += 1
            elif token in ("--id", "--ids", "-i"):
                if i + 1 >= len(tokens):
                    print("Option --ids requires a comma-separated list.")
                    return [], selection
                selection.ids.extend([item for item in tokens[i + 1].split(",") if item])
                i += 2
            else:
                remaining.append(token)
                i += 1
        return remaining, selection

    def _resolve_target_list(self, selection: TargetSelection) -> Tuple[bool, List[str]]:
        if selection.use_all:
            return True, []
        ids = selection.ids or self._default_ids
        if not ids:
            raise RuntimeError("No target IDs specified. Use '--ids' or set defaults with 'targets'.")
        return False, ids

    def _send_command(self, command: str, selection: TargetSelection, payload: Optional[dict]) -> None:
        try:
            client = self._ensure_client()
            broadcast, ids = self._resolve_target_list(selection)
            client.publish_command(ids, command, payload, broadcast=broadcast)
            target_label = "pmini/all" if broadcast else ", ".join(ids)
            print(f"Sent '{command}' to {target_label}.")
        except Exception as exc:  # noqa: BLE001
            print(f"Failed to send '{command}': {exc}")

    @staticmethod
    def _parse_optional_float(value: str) -> Optional[float]:
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _is_number(value: str) -> bool:
        if value is None:
            return False
        try:
            float(value)
            return True
        except ValueError:
            return False

    @staticmethod
    def _broadcast_selection() -> TargetSelection:
        return TargetSelection(use_all=True)

    def _build_mode_payload(self, value: str) -> dict:
        if self._is_number(value):
            return {"custom_mode": int(float(value))}
        return {"mode": value}


def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")
    terminal = PminiSwarmTerminal()
    try:
        terminal.cmdloop()
    except KeyboardInterrupt:  # pragma: no cover - CLI convenience
        terminal._cleanup()
        print("\nInterrupted.")
    return 0


if __name__ == "__main__":  # pragma: no cover - CLI entrypoint
    raise SystemExit(main())
