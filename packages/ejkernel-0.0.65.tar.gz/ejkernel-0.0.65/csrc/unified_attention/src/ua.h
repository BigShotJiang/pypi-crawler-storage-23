// Copyright 2025 The EasyDeL/ejKernel Author @erfanzar (Erfan Zare Chavoshi).
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <cuda_runtime.h>

#include <cstdint>

namespace ua {

struct UaParams {
  const void *queries;
  const void *key_cache;
  const void *value_cache;
  const int32_t *kv_lens;
  const int32_t *block_tables;
  const int32_t *query_start_loc;
  const float *softmax_aux;
  void *out;
  int32_t total_tokens;
  int32_t num_q_heads;
  int32_t num_kv_heads;
  int32_t head_dim;
  int32_t block_size;
  int32_t max_blocks_per_seq;
  int32_t num_seqs;
  float softmax_scale;
  float softcap;
  int32_t use_sinks;
  int32_t sliding_window;
  int32_t block_dim;
};

template <typename T, int HEAD_DIM>
void run_unified_attention_(UaParams &params, cudaStream_t stream);

} // namespace ua
