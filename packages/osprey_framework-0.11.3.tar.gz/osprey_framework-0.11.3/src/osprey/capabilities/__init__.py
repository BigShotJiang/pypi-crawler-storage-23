"""Native control system capabilities for the Osprey framework."""
