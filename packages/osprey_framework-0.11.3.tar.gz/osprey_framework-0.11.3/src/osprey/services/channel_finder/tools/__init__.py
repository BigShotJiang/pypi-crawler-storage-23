"""
Channel Finder Database Tools

Native tools for building, validating, and previewing channel databases.
Previously generated as Jinja2 templates; now first-class framework modules.
"""
