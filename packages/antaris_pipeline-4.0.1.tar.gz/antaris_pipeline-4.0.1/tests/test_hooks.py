"""
Tests for the antaris-pipeline hook system.

Covers registration, execution order, abort mechanism, unregister, multiple hooks per phase,
context.results accumulation, clear functionality, and PipelineHooks convenience methods.
"""

import pytest
from unittest.mock import Mock, call

from antaris_pipeline.hooks import (
    HookPhase,
    HookContext,
    HookResult,
    HookRegistry,
    PipelineHooks,
    HookCallback
)


class TestHookContext:
    """Test the HookContext dataclass."""
    
    def test_default_values(self):
        """Test default values are set correctly."""
        ctx = HookContext(session_id="test-session")
        
        assert ctx.session_id == "test-session"
        assert ctx.agent_id == ""
        assert ctx.phase == HookPhase.SESSION_START
        assert ctx.data == {}
        assert ctx.metadata == {}
        assert ctx.results == {}
    
    def test_custom_values(self):
        """Test custom values are preserved."""
        data = {"key": "value"}
        metadata = {"source": "test"}
        results = {"hook1": "result"}
        
        ctx = HookContext(
            session_id="test-session",
            agent_id="test-agent",
            phase=HookPhase.BEFORE_LLM,
            data=data,
            metadata=metadata,
            results=results
        )
        
        assert ctx.session_id == "test-session"
        assert ctx.agent_id == "test-agent"
        assert ctx.phase == HookPhase.BEFORE_LLM
        assert ctx.data == data
        assert ctx.metadata == metadata
        assert ctx.results == results


class TestHookResult:
    """Test the HookResult dataclass."""
    
    def test_default_values(self):
        """Test default values are set correctly."""
        result = HookResult()
        
        assert result.success is True
        assert result.data == {}
        assert result.error is None
        assert result.abort is False
    
    def test_custom_values(self):
        """Test custom values are preserved."""
        data = {"output": "test"}
        
        result = HookResult(
            success=False,
            data=data,
            error="Test error",
            abort=True
        )
        
        assert result.success is False
        assert result.data == data
        assert result.error == "Test error"
        assert result.abort is True


class TestHookRegistry:
    """Test the HookRegistry class."""
    
    def setup_method(self):
        """Set up fresh registry for each test."""
        self.registry = HookRegistry()
    
    def test_register_basic(self):
        """Test basic hook registration."""
        callback = Mock(return_value=HookResult())
        
        self.registry.register(HookPhase.SESSION_START, callback)
        
        hooks = self.registry.list_hooks(HookPhase.SESSION_START)
        assert len(hooks[HookPhase.SESSION_START.value]) == 1
    
    def test_register_with_name(self):
        """Test registration with custom name."""
        callback = Mock(return_value=HookResult())
        
        self.registry.register(HookPhase.SESSION_START, callback, name="test-hook")
        
        hooks = self.registry.list_hooks(HookPhase.SESSION_START)
        assert "test-hook" in hooks[HookPhase.SESSION_START.value]
    
    def test_register_invalid_callback(self):
        """Test registration with invalid callback raises ValueError."""
        with pytest.raises(ValueError, match="Callback must be callable"):
            self.registry.register(HookPhase.SESSION_START, "not-a-function")
    
    def test_execution_order_priority(self):
        """Test hooks execute in priority order (lower = earlier)."""
        results = []
        
        def make_hook(name: str):
            def hook(ctx: HookContext) -> HookResult:
                results.append(name)
                return HookResult()
            return hook
        
        # Register with different priorities
        self.registry.register(HookPhase.SESSION_START, make_hook("third"), priority=30)
        self.registry.register(HookPhase.SESSION_START, make_hook("first"), priority=10)
        self.registry.register(HookPhase.SESSION_START, make_hook("second"), priority=20)
        
        ctx = HookContext(session_id="test")
        self.registry.execute(HookPhase.SESSION_START, ctx)
        
        assert results == ["first", "second", "third"]
    
    def test_abort_stops_chain(self):
        """Test that abort=True stops executing remaining hooks."""
        results = []
        
        def hook1(ctx: HookContext) -> HookResult:
            results.append("hook1")
            return HookResult()
        
        def hook2_abort(ctx: HookContext) -> HookResult:
            results.append("hook2_abort")
            return HookResult(abort=True)
        
        def hook3_skipped(ctx: HookContext) -> HookResult:
            results.append("hook3_skipped")
            return HookResult()
        
        self.registry.register(HookPhase.SESSION_START, hook1, priority=10)
        self.registry.register(HookPhase.SESSION_START, hook2_abort, priority=20)
        self.registry.register(HookPhase.SESSION_START, hook3_skipped, priority=30)
        
        ctx = HookContext(session_id="test")
        hook_results = self.registry.execute(HookPhase.SESSION_START, ctx)
        
        assert results == ["hook1", "hook2_abort"]
        assert len(hook_results) == 2
        assert hook_results[1].abort is True
    
    def test_unregister_by_name(self):
        """Test unregistering hooks by name."""
        callback = Mock(return_value=HookResult())
        
        self.registry.register(HookPhase.SESSION_START, callback, name="test-hook")
        
        # Verify it's registered
        hooks = self.registry.list_hooks(HookPhase.SESSION_START)
        assert "test-hook" in hooks[HookPhase.SESSION_START.value]
        
        # Unregister it
        removed = self.registry.unregister(HookPhase.SESSION_START, "test-hook")
        assert removed is True
        
        # Verify it's gone
        hooks = self.registry.list_hooks(HookPhase.SESSION_START)
        assert "test-hook" not in hooks[HookPhase.SESSION_START.value]
        
        # Try to unregister again
        removed = self.registry.unregister(HookPhase.SESSION_START, "test-hook")
        assert removed is False
    
    def test_multiple_hooks_per_phase(self):
        """Test multiple hooks can be registered for the same phase."""
        callback1 = Mock(return_value=HookResult())
        callback2 = Mock(return_value=HookResult())
        callback3 = Mock(return_value=HookResult())
        
        self.registry.register(HookPhase.SESSION_START, callback1, name="hook1")
        self.registry.register(HookPhase.SESSION_START, callback2, name="hook2")
        self.registry.register(HookPhase.SESSION_START, callback3, name="hook3")
        
        hooks = self.registry.list_hooks(HookPhase.SESSION_START)
        assert len(hooks[HookPhase.SESSION_START.value]) == 3
        assert "hook1" in hooks[HookPhase.SESSION_START.value]
        assert "hook2" in hooks[HookPhase.SESSION_START.value]
        assert "hook3" in hooks[HookPhase.SESSION_START.value]
    
    def test_context_results_accumulation(self):
        """Test that hook results accumulate in context.results."""
        def hook1(ctx: HookContext) -> HookResult:
            return HookResult(data={"hook1": "result1"})
        
        def hook2(ctx: HookContext) -> HookResult:
            # Should be able to access previous results
            assert "hook1" in ctx.results
            return HookResult(data={"hook2": "result2"})
        
        self.registry.register(HookPhase.SESSION_START, hook1, name="hook1", priority=10)
        self.registry.register(HookPhase.SESSION_START, hook2, name="hook2", priority=20)
        
        ctx = HookContext(session_id="test")
        results = self.registry.execute(HookPhase.SESSION_START, ctx)
        
        assert len(results) == 2
        assert "hook1" in ctx.results
        assert "hook2" in ctx.results
        assert ctx.results["hook1"].data == {"hook1": "result1"}
        assert ctx.results["hook2"].data == {"hook2": "result2"}
    
    def test_hook_exception_handling(self):
        """Test that hook exceptions are handled gracefully."""
        def good_hook(ctx: HookContext) -> HookResult:
            return HookResult(data={"good": "result"})
        
        def bad_hook(ctx: HookContext) -> HookResult:
            raise ValueError("Hook failed")
        
        def final_hook(ctx: HookContext) -> HookResult:
            return HookResult(data={"final": "result"})
        
        self.registry.register(HookPhase.SESSION_START, good_hook, name="good", priority=10)
        self.registry.register(HookPhase.SESSION_START, bad_hook, name="bad", priority=20)
        self.registry.register(HookPhase.SESSION_START, final_hook, name="final", priority=30)
        
        ctx = HookContext(session_id="test")
        results = self.registry.execute(HookPhase.SESSION_START, ctx)
        
        assert len(results) == 3
        assert results[0].success is True
        assert results[1].success is False
        assert "Hook failed" in results[1].error
        assert results[2].success is True
    
    def test_clear_specific_phase(self):
        """Test clearing hooks for a specific phase."""
        callback1 = Mock(return_value=HookResult())
        callback2 = Mock(return_value=HookResult())
        
        self.registry.register(HookPhase.SESSION_START, callback1)
        self.registry.register(HookPhase.SESSION_END, callback2)
        
        # Clear only SESSION_START
        self.registry.clear(HookPhase.SESSION_START)
        
        hooks = self.registry.list_hooks()
        assert len(hooks[HookPhase.SESSION_START.value]) == 0
        assert len(hooks[HookPhase.SESSION_END.value]) == 1
    
    def test_clear_all_phases(self):
        """Test clearing all hooks."""
        callback1 = Mock(return_value=HookResult())
        callback2 = Mock(return_value=HookResult())
        
        self.registry.register(HookPhase.SESSION_START, callback1)
        self.registry.register(HookPhase.SESSION_END, callback2)
        
        # Clear all
        self.registry.clear()
        
        hooks = self.registry.list_hooks()
        for phase_hooks in hooks.values():
            assert len(phase_hooks) == 0
    
    def test_list_hooks_all_phases(self):
        """Test listing hooks for all phases."""
        callback1 = Mock(return_value=HookResult())
        callback2 = Mock(return_value=HookResult())
        
        self.registry.register(HookPhase.SESSION_START, callback1, name="start-hook")
        self.registry.register(HookPhase.SESSION_END, callback2, name="end-hook")
        
        hooks = self.registry.list_hooks()
        
        assert len(hooks) == 5  # All 5 hook phases
        assert "start-hook" in hooks[HookPhase.SESSION_START.value]
        assert "end-hook" in hooks[HookPhase.SESSION_END.value]


class TestPipelineHooks:
    """Test the PipelineHooks convenience class."""
    
    def setup_method(self):
        """Set up fresh PipelineHooks for each test."""
        self.hooks = PipelineHooks()
    
    def test_convenience_registration_methods(self):
        """Test that convenience methods register hooks correctly."""
        callback = Mock(return_value=HookResult())
        
        self.hooks.on_session_start(callback, name="test-start")
        self.hooks.on_session_end(callback, name="test-end")
        self.hooks.on_before_llm(callback, name="test-before")
        self.hooks.on_after_llm(callback, name="test-after")
        self.hooks.on_context_budget(callback, name="test-budget")
        
        hooks = self.hooks.list_hooks()
        
        assert "test-start" in hooks[HookPhase.SESSION_START.value]
        assert "test-end" in hooks[HookPhase.SESSION_END.value]
        assert "test-before" in hooks[HookPhase.BEFORE_LLM.value]
        assert "test-after" in hooks[HookPhase.AFTER_LLM.value]
        assert "test-budget" in hooks[HookPhase.CONTEXT_BUDGET.value]
    
    def test_trigger_session_start(self):
        """Test trigger_session_start creates correct HookContext."""
        callback = Mock(return_value=HookResult())
        self.hooks.on_session_start(callback)
        
        results = self.hooks.trigger_session_start(
            session_id="test-session",
            agent_id="test-agent",
            custom_data="test-value"
        )
        
        assert len(results) == 1
        callback.assert_called_once()
        
        ctx = callback.call_args[0][0]  # First argument
        assert ctx.session_id == "test-session"
        assert ctx.agent_id == "test-agent"
        assert ctx.phase == HookPhase.SESSION_START
        assert ctx.data["custom_data"] == "test-value"
    
    def test_trigger_session_end(self):
        """Test trigger_session_end creates correct HookContext."""
        callback = Mock(return_value=HookResult())
        self.hooks.on_session_end(callback)
        
        results = self.hooks.trigger_session_end(
            session_id="test-session",
            agent_id="test-agent",
            duration=120
        )
        
        assert len(results) == 1
        callback.assert_called_once()
        
        ctx = callback.call_args[0][0]
        assert ctx.session_id == "test-session"
        assert ctx.agent_id == "test-agent" 
        assert ctx.phase == HookPhase.SESSION_END
        assert ctx.data["duration"] == 120
    
    def test_trigger_before_llm(self):
        """Test trigger_before_llm creates correct HookContext."""
        callback = Mock(return_value=HookResult())
        self.hooks.on_before_llm(callback)
        
        results = self.hooks.trigger_before_llm(
            session_id="test-session",
            query="test query",
            agent_id="test-agent",
            model="gpt-4"
        )
        
        assert len(results) == 1
        callback.assert_called_once()
        
        ctx = callback.call_args[0][0]
        assert ctx.session_id == "test-session"
        assert ctx.agent_id == "test-agent"
        assert ctx.phase == HookPhase.BEFORE_LLM
        assert ctx.data["query"] == "test query"
        assert ctx.data["model"] == "gpt-4"
    
    def test_trigger_after_llm(self):
        """Test trigger_after_llm creates correct HookContext."""
        callback = Mock(return_value=HookResult())
        self.hooks.on_after_llm(callback)
        
        results = self.hooks.trigger_after_llm(
            session_id="test-session",
            response="test response", 
            agent_id="test-agent",
            tokens_used=150
        )
        
        assert len(results) == 1
        callback.assert_called_once()
        
        ctx = callback.call_args[0][0]
        assert ctx.session_id == "test-session"
        assert ctx.agent_id == "test-agent"
        assert ctx.phase == HookPhase.AFTER_LLM
        assert ctx.data["response"] == "test response"
        assert ctx.data["tokens_used"] == 150
    
    def test_trigger_context_budget(self):
        """Test trigger_context_budget creates correct HookContext."""
        callback = Mock(return_value=HookResult())
        self.hooks.on_context_budget(callback)
        
        results = self.hooks.trigger_context_budget(
            session_id="test-session",
            budget_tokens=8000,
            agent_id="test-agent",
            current_tokens=7500
        )
        
        assert len(results) == 1
        callback.assert_called_once()
        
        ctx = callback.call_args[0][0]
        assert ctx.session_id == "test-session"
        assert ctx.agent_id == "test-agent"
        assert ctx.phase == HookPhase.CONTEXT_BUDGET
        assert ctx.data["budget_tokens"] == 8000
        assert ctx.data["current_tokens"] == 7500
    
    def test_delegated_methods(self):
        """Test that delegated registry methods work."""
        callback = Mock(return_value=HookResult())
        
        # Register and verify
        self.hooks.on_session_start(callback, name="test-hook")
        hooks = self.hooks.list_hooks(HookPhase.SESSION_START)
        assert "test-hook" in hooks[HookPhase.SESSION_START.value]
        
        # Unregister and verify
        removed = self.hooks.unregister(HookPhase.SESSION_START, "test-hook")
        assert removed is True
        hooks = self.hooks.list_hooks(HookPhase.SESSION_START)
        assert "test-hook" not in hooks[HookPhase.SESSION_START.value]
        
        # Register again and clear
        self.hooks.on_session_start(callback, name="test-hook")
        self.hooks.clear(HookPhase.SESSION_START)
        hooks = self.hooks.list_hooks(HookPhase.SESSION_START)
        assert len(hooks[HookPhase.SESSION_START.value]) == 0


class TestIntegrationScenarios:
    """Test realistic integration scenarios."""
    
    def test_memory_recall_scenario(self):
        """Test a realistic memory recall scenario."""
        hooks = PipelineHooks()
        
        # Mock memory system
        mock_memories = ["memory1", "memory2"]
        
        def memory_recall_hook(ctx: HookContext) -> HookResult:
            query = ctx.data.get("query", "")
            if query:
                # Simulate memory search
                memories = mock_memories
                return HookResult(data={"memories": memories})
            return HookResult()
        
        hooks.on_session_start(memory_recall_hook, name="memory-recall", priority=10)
        
        results = hooks.trigger_session_start(
            session_id="user-123",
            agent_id="forge-agent",
            query="Tell me about machine learning"
        )
        
        assert len(results) == 1
        assert results[0].success is True
        assert results[0].data["memories"] == mock_memories
    
    def test_guard_screening_scenario(self):
        """Test a realistic guard screening scenario."""
        hooks = PipelineHooks()
        
        def guard_screening_hook(ctx: HookContext) -> HookResult:
            query = ctx.data.get("query", "")
            if "dangerous" in query.lower():
                return HookResult(
                    success=False,
                    error="Content blocked by safety guard",
                    abort=True
                )
            return HookResult(data={"safety_check": "passed"})
        
        hooks.on_before_llm(guard_screening_hook, name="safety-guard", priority=5)
        
        # Test safe query
        results = hooks.trigger_before_llm(
            session_id="user-123",
            query="What is the weather like?",
            agent_id="forge-agent"
        )
        assert len(results) == 1
        assert results[0].success is True
        
        # Test dangerous query
        results = hooks.trigger_before_llm(
            session_id="user-123", 
            query="How to make dangerous chemicals?",
            agent_id="forge-agent"
        )
        assert len(results) == 1
        assert results[0].success is False
        assert results[0].abort is True
    
    def test_instrumentation_chaining_scenario(self):
        """Test chaining hooks for instrumentation."""
        hooks = PipelineHooks()
        
        def metrics_hook(ctx: HookContext) -> HookResult:
            return HookResult(data={"metrics": {"response_time": 0.5}})
        
        def logging_hook(ctx: HookContext) -> HookResult:
            # Access previous hook results
            metrics = ctx.results.get("metrics", {}).data.get("metrics", {})
            return HookResult(data={"logged": True, "metrics": metrics})
        
        def cooccurrence_hook(ctx: HookContext) -> HookResult:
            response = ctx.data.get("response", "")
            return HookResult(data={"cooccurrence": f"processed: {response[:10]}..."})
        
        hooks.on_after_llm(metrics_hook, name="metrics", priority=10)
        hooks.on_after_llm(logging_hook, name="logging", priority=20)
        hooks.on_after_llm(cooccurrence_hook, name="cooccurrence", priority=30)
        
        results = hooks.trigger_after_llm(
            session_id="user-123",
            response="This is a test response from the LLM",
            agent_id="forge-agent"
        )
        
        assert len(results) == 3
        assert all(r.success for r in results)
        assert results[1].data["metrics"] == {"response_time": 0.5}
        assert results[2].data["cooccurrence"] == "processed: This is a ..."