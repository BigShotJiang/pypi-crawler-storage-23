"""
Antaris Pipeline Hook Contract

Lightweight hook registration system for host applications to tap into pipeline lifecycle.
Zero dependencies, standard library only.
"""

from abc import ABC, abstractmethod
from typing import Any, Callable, Dict, List, Optional, NamedTuple
from dataclasses import dataclass, field
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class HookPhase(Enum):
    """Lifecycle phases where hooks can be registered."""
    SESSION_START = "on_session_start"
    SESSION_END = "on_session_end"
    BEFORE_LLM = "on_before_llm"
    AFTER_LLM = "on_after_llm"
    CONTEXT_BUDGET = "on_context_budget"


@dataclass
class HookContext:
    """Context passed to every hook callback.
    
    Attributes:
        session_id: Current session identifier
        agent_id: Agent that owns this session
        phase: Which lifecycle phase triggered this hook
        data: Phase-specific data (query text, response, budget info, etc.)
        metadata: Arbitrary metadata from the host application
        results: Results from previous hooks in the chain (for chaining)
    """
    session_id: str
    agent_id: str = ""
    phase: HookPhase = HookPhase.SESSION_START
    data: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    results: Dict[str, Any] = field(default_factory=dict)


@dataclass 
class HookResult:
    """Result returned by a hook callback.
    
    Attributes:
        success: Whether the hook executed successfully
        data: Any data to pass to subsequent hooks or back to the host
        error: Error message if success=False
        abort: If True, stop processing further hooks in this phase
    """
    success: bool = True
    data: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    abort: bool = False


# Type alias for hook callbacks
HookCallback = Callable[[HookContext], HookResult]


class _RegisteredHook(NamedTuple):
    """Internal structure for registered hooks."""
    name: str
    callback: HookCallback
    priority: int


class HookRegistry:
    """Central registry for lifecycle hooks.
    
    Hosts register callbacks; the pipeline calls them at the right time.
    Multiple callbacks per phase are supported (executed in registration order).
    
    Usage:
        registry = HookRegistry()
        
        # Register a memory recall hook
        def recall_hook(ctx: HookContext) -> HookResult:
            memories = memory_system.search(ctx.data.get("query", ""))
            return HookResult(data={"memories": memories})
        
        registry.register(HookPhase.SESSION_START, recall_hook, priority=10)
        
        # Execute all hooks for a phase
        results = registry.execute(HookPhase.SESSION_START, context)
    """
    
    def __init__(self):
        self._hooks: Dict[HookPhase, List[_RegisteredHook]] = {
            phase: [] for phase in HookPhase
        }
        self._hook_counter = 0
    
    def register(self, phase: HookPhase, callback: HookCallback, 
                 name: str = "", priority: int = 50) -> None:
        """Register a callback for a lifecycle phase.
        
        Args:
            phase: Which phase to hook into
            callback: Function to call
            name: Optional name for debugging/logging
            priority: Execution order (lower = earlier, default 50)
        """
        if not callable(callback):
            raise ValueError("Callback must be callable")
        
        if not name:
            self._hook_counter += 1
            name = f"hook_{self._hook_counter}"
        
        hook = _RegisteredHook(name=name, callback=callback, priority=priority)
        self._hooks[phase].append(hook)
        
        # Sort by priority (lower = earlier)
        self._hooks[phase].sort(key=lambda h: h.priority)
        
        logger.debug(f"Registered hook '{name}' for {phase.value} with priority {priority}")
    
    def unregister(self, phase: HookPhase, name: str) -> bool:
        """Remove a named hook. Returns True if found and removed."""
        hooks = self._hooks[phase]
        initial_length = len(hooks)
        
        self._hooks[phase] = [h for h in hooks if h.name != name]
        
        removed = len(self._hooks[phase]) < initial_length
        if removed:
            logger.debug(f"Unregistered hook '{name}' from {phase.value}")
        return removed
    
    def execute(self, phase: HookPhase, context: HookContext) -> List[HookResult]:
        """Execute all hooks for a phase in priority order.
        
        If any hook returns abort=True, stop executing remaining hooks.
        Each hook's result is added to context.results[hook_name].
        """
        results = []
        hooks = self._hooks[phase]
        
        logger.debug(f"Executing {len(hooks)} hooks for {phase.value}")
        
        for hook in hooks:
            try:
                result = hook.callback(context)
                
                # Store result in context for chaining
                context.results[hook.name] = result
                results.append(result)
                
                logger.debug(f"Hook '{hook.name}' executed: success={result.success}")
                
                if result.abort:
                    logger.info(f"Hook '{hook.name}' requested abort, stopping chain")
                    break
                    
            except Exception as e:
                error_msg = f"Hook '{hook.name}' failed: {str(e)}"
                logger.error(error_msg, exc_info=True)
                
                error_result = HookResult(
                    success=False,
                    error=error_msg
                )
                context.results[hook.name] = error_result
                results.append(error_result)
        
        return results
    
    def list_hooks(self, phase: Optional[HookPhase] = None) -> Dict[str, List[str]]:
        """List registered hooks, optionally filtered by phase."""
        if phase is not None:
            return {phase.value: [h.name for h in self._hooks[phase]]}
        
        return {
            phase.value: [h.name for h in self._hooks[phase]]
            for phase in HookPhase
        }
    
    def clear(self, phase: Optional[HookPhase] = None) -> None:
        """Clear hooks for a phase, or all hooks if phase is None."""
        if phase is not None:
            count = len(self._hooks[phase])
            self._hooks[phase].clear()
            logger.debug(f"Cleared {count} hooks from {phase.value}")
        else:
            total_count = sum(len(hooks) for hooks in self._hooks.values())
            for phase in HookPhase:
                self._hooks[phase].clear()
            logger.debug(f"Cleared all {total_count} hooks")


class PipelineHooks:
    """Convenience class that wraps HookRegistry with typed helper methods.
    
    This is the primary interface hosts use. One method per hook phase.
    
    Usage:
        hooks = PipelineHooks()
        
        # Forge registers its hooks at startup
        hooks.on_session_start(memory_recall_fn, name="memory-recall")
        hooks.on_before_llm(guard_screen_fn, name="guard-screen")
        hooks.on_after_llm(instrumentation_fn, name="instrumentation")
        
        # Pipeline calls hooks at the right time
        hooks.trigger_session_start(session_id="abc", agent_id="forge-user-1")
    """
    
    def __init__(self):
        self.registry = HookRegistry()
    
    # Registration helpers
    def on_session_start(self, callback: HookCallback, name: str = "", priority: int = 50) -> None:
        """Register a callback for session start."""
        self.registry.register(HookPhase.SESSION_START, callback, name, priority)
    
    def on_session_end(self, callback: HookCallback, name: str = "", priority: int = 50) -> None:
        """Register a callback for session end."""
        self.registry.register(HookPhase.SESSION_END, callback, name, priority)
    
    def on_before_llm(self, callback: HookCallback, name: str = "", priority: int = 50) -> None:
        """Register a callback for before LLM call."""
        self.registry.register(HookPhase.BEFORE_LLM, callback, name, priority)
    
    def on_after_llm(self, callback: HookCallback, name: str = "", priority: int = 50) -> None:
        """Register a callback for after LLM response."""
        self.registry.register(HookPhase.AFTER_LLM, callback, name, priority)
    
    def on_context_budget(self, callback: HookCallback, name: str = "", priority: int = 50) -> None:
        """Register a callback for context budget management."""
        self.registry.register(HookPhase.CONTEXT_BUDGET, callback, name, priority)
    
    # Trigger helpers (called by the pipeline)
    def trigger_session_start(self, session_id: str, agent_id: str = "", **data) -> List[HookResult]:
        """Trigger session start hooks."""
        context = HookContext(
            session_id=session_id,
            agent_id=agent_id,
            phase=HookPhase.SESSION_START,
            data=data
        )
        return self.registry.execute(HookPhase.SESSION_START, context)
    
    def trigger_session_end(self, session_id: str, agent_id: str = "", **data) -> List[HookResult]:
        """Trigger session end hooks."""
        context = HookContext(
            session_id=session_id,
            agent_id=agent_id,
            phase=HookPhase.SESSION_END,
            data=data
        )
        return self.registry.execute(HookPhase.SESSION_END, context)
    
    def trigger_before_llm(self, session_id: str, query: str = "", agent_id: str = "", **data) -> List[HookResult]:
        """Trigger before LLM hooks."""
        context = HookContext(
            session_id=session_id,
            agent_id=agent_id,
            phase=HookPhase.BEFORE_LLM,
            data={"query": query, **data}
        )
        return self.registry.execute(HookPhase.BEFORE_LLM, context)
    
    def trigger_after_llm(self, session_id: str, response: str = "", agent_id: str = "", **data) -> List[HookResult]:
        """Trigger after LLM hooks."""
        context = HookContext(
            session_id=session_id,
            agent_id=agent_id,
            phase=HookPhase.AFTER_LLM,
            data={"response": response, **data}
        )
        return self.registry.execute(HookPhase.AFTER_LLM, context)
    
    def trigger_context_budget(self, session_id: str, budget_tokens: int = 0, agent_id: str = "", **data) -> List[HookResult]:
        """Trigger context budget hooks."""
        context = HookContext(
            session_id=session_id,
            agent_id=agent_id,
            phase=HookPhase.CONTEXT_BUDGET,
            data={"budget_tokens": budget_tokens, **data}
        )
        return self.registry.execute(HookPhase.CONTEXT_BUDGET, context)
    
    # Delegate registry methods
    def unregister(self, phase: HookPhase, name: str) -> bool:
        """Remove a named hook."""
        return self.registry.unregister(phase, name)
    
    def list_hooks(self, phase: Optional[HookPhase] = None) -> Dict[str, List[str]]:
        """List registered hooks."""
        return self.registry.list_hooks(phase)
    
    def clear(self, phase: Optional[HookPhase] = None) -> None:
        """Clear hooks."""
        self.registry.clear(phase)

    def register(self, phase: HookPhase, callback: "HookCallback", name: str = "", priority: int = 0) -> None:
        """Register a hook callback. Convenience wrapper for plugins."""
        self.registry.register(phase, callback, name=name, priority=priority)

    def register_plugin(self, plugin: "HookPlugin") -> None:
        """Install a HookPlugin — calls plugin.install() once."""
        plugin.install(self)

    def unregister_plugin(self, plugin: "HookPlugin") -> None:
        """Uninstall a HookPlugin — calls plugin.uninstall() for cleanup."""
        plugin.uninstall(self)


class HookPlugin(ABC):
    """Base class for plugins that register hooks across multiple phases as a unit.

    Subclass and implement install(). The host calls register_plugin(plugin),
    which calls install() once. Call unregister_plugin(plugin) to clean up.

    Example::

        class MemoryPlugin(HookPlugin):
            def install(self, hooks: PipelineHooks) -> None:
                hooks.register(HookPhase.SESSION_START, self.on_start, name="mem.start")
                hooks.register(HookPhase.BEFORE_LLM, self.on_before_llm, name="mem.screen")
                hooks.register(HookPhase.SESSION_END, self.on_end, name="mem.end")
    """

    @abstractmethod
    def install(self, hooks: PipelineHooks) -> None:
        """Register all hooks for this plugin. Called once on registration."""
        ...

    def uninstall(self, hooks: PipelineHooks) -> None:
        """Unregister all hooks. Override to clean up registered callbacks.

        Default is a no-op. Plugins that need cleanup should call
        hooks.unregister(phase, name) for each registered callback.
        """
        pass

    @property
    def name(self) -> str:
        """Plugin name for logging/debugging. Defaults to class name."""
        return self.__class__.__name__