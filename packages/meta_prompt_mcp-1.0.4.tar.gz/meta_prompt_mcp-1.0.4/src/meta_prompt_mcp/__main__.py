"""Allow running as `python -m meta_prompt_mcp`."""
from meta_prompt_mcp.server import main

main()
