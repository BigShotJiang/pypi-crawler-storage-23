"""Meta-Prompt MCP — A Prompting Oracle powered by Google's Prompting Guide 101."""

__version__ = "0.1.0"
