# API Reference

## Client

::: cbspy.client.Client
    options:
      show_root_heading: true
      show_source: false
      members_order: source

## Data Models

### Column

::: cbspy.models.Column
    options:
      show_root_heading: true
      show_source: false

### TableMetadata

::: cbspy.models.TableMetadata
    options:
      show_root_heading: true
      show_source: false

## Exceptions

::: cbspy.exceptions.CBSError
    options:
      show_root_heading: true
      show_source: false

::: cbspy.exceptions.TableNotFoundError
    options:
      show_root_heading: true
      show_source: false

::: cbspy.exceptions.APIError
    options:
      show_root_heading: true
      show_source: false
