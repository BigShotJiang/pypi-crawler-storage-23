# Changelog

## 0.0.4 (2026-03-01)

Full Changelog: [v0.0.3...v0.0.4](https://github.com/Ahmadjamil888/Pipeline_SDK/compare/v0.0.3...v0.0.4)

### Chores

* update SDK settings ([e57b2ff](https://github.com/Ahmadjamil888/Pipeline_SDK/commit/e57b2ff96cdaccf222f644f37084ff0917d3e31b))
* update SDK settings ([f2869a7](https://github.com/Ahmadjamil888/Pipeline_SDK/commit/f2869a734b32761963f003390886c3d167835f2f))

## 0.0.3 (2026-03-01)

Full Changelog: [v0.0.2...v0.0.3](https://github.com/Ahmadjamil888/Pipeline_SDK/compare/v0.0.2...v0.0.3)

### Chores

* update SDK settings ([da651de](https://github.com/Ahmadjamil888/Pipeline_SDK/commit/da651de5c11e62312a8e02767dc2e692226503e3))
* update SDK settings ([aa0281a](https://github.com/Ahmadjamil888/Pipeline_SDK/commit/aa0281a49219e5dca8662788b2717d86b7795ba5))

## 0.0.2 (2026-02-28)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/Ahmadjamil888/Pipeline_SDK/compare/v0.0.1...v0.0.2)

### Chores

* update SDK settings ([95537b2](https://github.com/Ahmadjamil888/Pipeline_SDK/commit/95537b280779211f9468be7f8b1d2b11da9e3a6c))
* update SDK settings ([50439ed](https://github.com/Ahmadjamil888/Pipeline_SDK/commit/50439ed2a66726930607e6b8288144d44ed963eb))
* update SDK settings ([6afd1b9](https://github.com/Ahmadjamil888/Pipeline_SDK/commit/6afd1b91d1113741e47113121e95724adbb4f274))
* update SDK settings ([5f6c7a7](https://github.com/Ahmadjamil888/Pipeline_SDK/commit/5f6c7a784531c4212ee904af375932e9a30cbd91))
