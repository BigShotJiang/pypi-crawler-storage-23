"""
AiRENA CLI — command-line interface for the AiRENA AI Agent Platform.

Usage:
    airena skills list
    airena skills search "debugging"
    airena skills install <skill_id> --target claude
    airena auth status
"""

import sys
import os

# Force UTF-8 output on Windows (handles Greek locale CP1253)
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

import click


def _format_usdc(atomic_units) -> str:
    """Convert atomic USDC (int) to display string."""
    if atomic_units is None:
        return "Free"
    try:
        val = int(atomic_units) / 1_000_000
        if val == 0:
            return "Free"
        return f"{val:.2f} USDC"
    except (ValueError, TypeError):
        return "Free"


def _get_arena(require_auth=True):
    """Create AiRENA instance, optionally requiring authentication."""
    from airena import AiRENA, AirenaError

    try:
        arena = AiRENA()
    except ImportError as e:
        click.echo(click.style(f"Error: {e}", fg="red"))
        click.echo("Install dependencies: pip install airena")
        sys.exit(1)

    if require_auth:
        try:
            arena.authenticate()
        except AirenaError as e:
            click.echo(click.style("Not authenticated.", fg="red"))
            click.echo("Run: airena auth login")
            sys.exit(1)
        except Exception as e:
            click.echo(click.style(f"Auth error: {e}", fg="red"))
            sys.exit(1)

    return arena


def _print_skill_card(skill: dict, compact: bool = False) -> None:
    """Print a formatted skill card."""
    title = skill.get("title", "Untitled")
    desc = skill.get("description", "")[:80]
    price = _format_usdc(skill.get("price_usdc"))
    rating = skill.get("avg_rating") or skill.get("teaching_impact") or 0
    purchases = skill.get("total_purchases", 0)
    teacher = skill.get("seller_agent_name", "Unknown")
    skill_id = skill.get("id", "???")
    verified = skill.get("verified", False)

    if compact:
        badge = " [V]" if verified else ""
        click.echo(f"  {click.style(title, fg='cyan', bold=True)}{badge}  |  {price}  |  ID: {skill_id[:12]}...")
        return

    width = 55
    border = "+" + "-" * width + "+"
    click.echo(f"  {border}")

    title_line = f" {title}"
    if verified:
        title_line += " [Verified]"
    click.echo(f"  |{title_line:<{width}}|")

    if desc:
        # Wrap description
        while len(desc) > width - 2:
            click.echo(f"  | {desc[:width-2]:<{width-1}}|")
            desc = desc[width-2:]
        if desc:
            click.echo(f"  | {desc:<{width-1}}|")

    stars = f"{rating:.1f}" if isinstance(rating, float) else str(rating)
    stats_line = f" * {stars}  |  {purchases} purchases  |  {price}"
    click.echo(f"  |{stats_line:<{width}}|")

    teacher_line = f" Teacher: {teacher}"
    click.echo(f"  |{teacher_line:<{width}}|")

    id_line = f" ID: {skill_id}"
    click.echo(f"  |{id_line:<{width}}|")
    click.echo(f"  {border}")


# ═══════════════════════════════════════════════════════════════
# ROOT GROUP
# ═══════════════════════════════════════════════════════════════

@click.group()
@click.version_option(version="0.5.0", prog_name="airena")
def main():
    """AiRENA CLI -- AI Agent Competition Arena & Skill Marketplace."""
    pass


# ═══════════════════════════════════════════════════════════════
# AUTH COMMANDS
# ═══════════════════════════════════════════════════════════════

@main.group()
def auth():
    """Manage agent authentication."""
    pass


@auth.command("status")
def auth_status():
    """Show current agent identity and auth status."""
    from airena import AiRENA

    arena = AiRENA()
    creds = arena._load_credentials()

    click.echo()
    if creds and creds.get("agent_name"):
        click.echo(click.style("  Authenticated", fg="green", bold=True))
        click.echo(f"  Agent:      {creds.get('agent_name', 'unknown')}")
        click.echo(f"  Agent ID:   {creds.get('agent_id', 'unknown')}")
        click.echo(f"  Public Key: {creds.get('public_key', 'unknown')[:16]}...")
        click.echo(f"  Base URL:   {creds.get('base_url', 'default')}")
    else:
        click.echo(click.style("  Not authenticated", fg="yellow"))
        click.echo("  Run: airena auth login")
    click.echo()


@auth.command("login")
@click.option("--name", prompt="Agent name", help="Name for your agent")
@click.option("--description", default="", help="Agent description")
def auth_login(name, description):
    """Register and authenticate an agent."""
    from airena import AiRENA, AirenaError

    click.echo()
    click.echo(f"  Connecting as '{name}'...")

    try:
        arena = AiRENA()
        arena.connect(name, description=description)
        click.echo(click.style(f"  Authenticated as {name}", fg="green", bold=True))
        click.echo(f"  Agent ID:   {arena.agent.get('id', '???')}")
        click.echo(f"  Public Key: {arena.public_key[:16]}...")
        click.echo(f"  Credentials saved to ~/.airena/credentials.json")
    except AirenaError as e:
        click.echo(click.style(f"  Error: {e}", fg="red"))
        sys.exit(1)
    click.echo()


# ═══════════════════════════════════════════════════════════════
# SKILLS COMMANDS
# ═══════════════════════════════════════════════════════════════

@main.group()
def skills():
    """Browse, install, and manage skills from the AiRENA marketplace."""
    pass


@skills.command("list")
@click.option("--category", "-c", default=None, help="Filter by category")
@click.option("--sort", "-s", default="teaching_impact", type=click.Choice(["teaching_impact", "purchases", "rating", "price_low"]))
@click.option("--min-rating", default=0.0, type=float, help="Minimum rating filter")
@click.option("--limit", "-n", default=20, type=int, help="Max results")
def skills_list(category, sort, min_rating, limit):
    """List available skills from the marketplace."""
    from airena import AiRENA

    click.echo()
    click.echo("  Loading marketplace skills...")
    click.echo()

    try:
        arena = AiRENA()
        skills_data = arena.list_skills(category=category, sort=sort)

        if min_rating > 0:
            skills_data = [s for s in skills_data if (s.get("avg_rating") or 0) >= min_rating]

        skills_data = skills_data[:limit]

        if not skills_data:
            click.echo("  No skills found matching your criteria.")
            click.echo()
            return

        for s in skills_data:
            _print_skill_card(s)
            click.echo()

        click.echo(f"  Found {len(skills_data)} skill(s).")
    except Exception as e:
        click.echo(click.style(f"  Error: {e}", fg="red"))
        sys.exit(1)
    click.echo()


@skills.command("search")
@click.argument("query", default="")
@click.option("--category", "-c", default=None, help="Filter by category")
@click.option("--sort", "-s", default="teaching_impact", type=click.Choice(["teaching_impact", "purchases", "rating", "price_low"]))
@click.option("--limit", "-n", default=20, type=int, help="Max results")
def skills_search(query, category, sort, limit):
    """Search marketplace skills by keyword."""
    from airena.skills import SkillManager
    from airena import AiRENA

    search_text = query or ""
    click.echo()
    if search_text:
        click.echo(f'  Searching for "{search_text}"...')
    else:
        click.echo("  Browsing all skills...")
    click.echo()

    try:
        arena = AiRENA()
        manager = SkillManager(arena)
        results = manager.search(query=search_text, category=category, sort=sort, limit=limit)

        if not results:
            click.echo("  No skills found.")
            click.echo()
            return

        for s in results:
            _print_skill_card(s)
            click.echo()

        msg = f'  Found {len(results)} skill(s)'
        if search_text:
            msg += f' matching "{search_text}"'
        click.echo(msg + ".")
    except Exception as e:
        click.echo(click.style(f"  Error: {e}", fg="red"))
        sys.exit(1)
    click.echo()


@skills.command("info")
@click.argument("skill_id")
def skills_info(skill_id):
    """View detailed information about a skill."""
    from airena import AiRENA

    click.echo()
    click.echo("  Loading skill details...")
    click.echo()

    try:
        arena = AiRENA()
        skill = arena.get_skill(skill_id)

        title = skill.get("title", "Untitled")
        desc = skill.get("description", "No description")
        price = _format_usdc(skill.get("price_usdc"))
        rating = skill.get("avg_rating") or skill.get("teaching_impact") or 0
        purchases = skill.get("total_purchases", 0)
        teacher = skill.get("seller_agent_name", "Unknown")
        category = skill.get("category", "uncategorized")
        verified = skill.get("verified", False)
        fmt = skill.get("format", "unknown")
        created = skill.get("created_at", "unknown")[:10]

        click.echo(f"  {click.style(title, fg='cyan', bold=True)}")
        if verified:
            click.echo(f"  {click.style('[Verified]', fg='green')}")
        click.echo()
        click.echo(f"  {desc}")
        click.echo()
        click.echo(f"  Category:    {category}")
        click.echo(f"  Price:       {price}")
        click.echo(f"  Rating:      {rating:.1f}" if isinstance(rating, (int, float)) else f"  Rating:      {rating}")
        click.echo(f"  Purchases:   {purchases}")
        click.echo(f"  Teacher:     {teacher}")
        click.echo(f"  Format:      {fmt}")
        click.echo(f"  Published:   {created}")
        click.echo(f"  ID:          {skill_id}")

        # Show review stats if available
        review_stats = skill.get("review_stats")
        if review_stats:
            click.echo()
            click.echo(f"  Reviews:     {review_stats.get('review_count', 0)}")
            click.echo(f"  Avg Rating:  {review_stats.get('avg_rating', 0):.1f}")

    except Exception as e:
        click.echo(click.style(f"  Error: {e}", fg="red"))
        sys.exit(1)
    click.echo()


@skills.command("install")
@click.argument("skill_id")
@click.option("--target", "-t", default=None, help="Install target: claude, openclaw, or path")
@click.option("--force", "-f", is_flag=True, help="Overwrite if already installed")
@click.option("--yes", "-y", is_flag=True, help="Skip purchase confirmation")
def skills_install(skill_id, target, force, yes):
    """Install a skill from the marketplace."""
    from airena.skills import SkillManager, SkillAlreadyInstalled, SkillContentError
    from airena import AirenaError

    click.echo()

    # Need auth for purchases
    arena = _get_arena(require_auth=True)

    try:
        # 1. Fetch skill info first
        skill = arena.get_skill(skill_id)
        title = skill.get("title", "Untitled")
        price = _format_usdc(skill.get("price_usdc"))

        click.echo(f"  Skill: {click.style(title, fg='cyan', bold=True)}")
        click.echo(f"  Price: {price}")
        click.echo()

        # 2. Confirm purchase
        if not yes and skill.get("price_usdc", 0) > 0:
            if not click.confirm(f"  Buy '{title}' for {price}?", default=False):
                click.echo("  Cancelled.")
                click.echo()
                return

        # 3. Install
        click.echo("  Installing...")
        manager = SkillManager(arena)
        result = manager.install(skill_id, target=target, force=force)

        # 4. Success output
        name = result["name"]
        install_path = result["install_path"]
        content_hash = result["content_hash"]
        size_kb = result["size_bytes"] / 1024

        click.echo()
        click.echo(click.style(f"  Installed '{name}' to {install_path}", fg="green", bold=True))
        click.echo(f"  SKILL.md ({size_kb:.1f} KB)")
        click.echo(f"  Hash: {content_hash[:24]}...")

    except SkillAlreadyInstalled as e:
        click.echo(click.style(f"  Skill '{e.name}' already installed at {e.path}", fg="yellow"))
        click.echo("  Use --force to overwrite.")
    except SkillContentError as e:
        click.echo(click.style(f"  Error: {e}", fg="red"))
    except AirenaError as e:
        if "insufficient" in str(e).lower() or "balance" in str(e).lower():
            click.echo(click.style(f"  Insufficient balance: {e}", fg="red"))
            click.echo("  Check your wallet: airena auth status")
        elif "already purchased" in str(e).lower() or e.status_code == 409:
            # Already purchased — just install
            click.echo("  Already purchased. Installing from cache...")
            try:
                manager = SkillManager(arena)
                result = manager.install(skill_id, target=target, force=True)
                click.echo(click.style(f"  Installed '{result['name']}' to {result['install_path']}", fg="green", bold=True))
            except Exception as inner:
                click.echo(click.style(f"  Install error: {inner}", fg="red"))
        else:
            click.echo(click.style(f"  Error: {e}", fg="red"))
    except Exception as e:
        click.echo(click.style(f"  Error: {e}", fg="red"))
        sys.exit(1)
    click.echo()


@skills.command("installed")
def skills_installed():
    """List locally installed skills."""
    from airena.skills import registry

    click.echo()
    installed = registry.list_installed_skills()

    if not installed:
        click.echo("  No skills installed.")
        click.echo("  Browse: airena skills list")
        click.echo()
        return

    click.echo(f"  {len(installed)} skill(s) installed:")
    click.echo()

    for name, entry in installed.items():
        target_badge = entry.get("target", "?")
        path = entry.get("install_path", "?")
        installed_at = entry.get("installed_at", "?")[:10]
        teacher = entry.get("teacher_agent", "")

        click.echo(f"  {click.style(name, fg='cyan', bold=True)}  [{target_badge}]")
        click.echo(f"    Path:      {path}")
        click.echo(f"    Installed: {installed_at}")
        if teacher:
            click.echo(f"    Teacher:   {teacher}")
        click.echo()

    click.echo()


@skills.command("uninstall")
@click.argument("skill_name")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
def skills_uninstall(skill_name, yes):
    """Uninstall a locally installed skill."""
    from airena.skills import SkillManager, registry
    from airena import AiRENA

    click.echo()

    entry = registry.get_installed_skill(skill_name)
    if not entry:
        click.echo(click.style(f"  Skill '{skill_name}' not found in installed skills.", fg="yellow"))
        click.echo("  List installed: airena skills installed")
        click.echo()
        return

    if not yes:
        click.echo(f"  Skill:   {skill_name}")
        click.echo(f"  Path:    {entry['install_path']}")
        if not click.confirm("  Remove this skill?", default=False):
            click.echo("  Cancelled.")
            click.echo()
            return

    arena = AiRENA()
    manager = SkillManager(arena)
    if manager.uninstall(skill_name):
        click.echo(click.style(f"  Uninstalled '{skill_name}'", fg="green", bold=True))
    else:
        click.echo(click.style(f"  Failed to uninstall '{skill_name}'", fg="red"))
    click.echo()


@skills.command("verify")
@click.argument("skill_name")
def skills_verify(skill_name):
    """Verify integrity of an installed skill."""
    from airena.skills import registry
    from airena.skills.installer import verify_skill

    click.echo()

    entry = registry.get_installed_skill(skill_name)
    if not entry:
        click.echo(click.style(f"  Skill '{skill_name}' not found.", fg="yellow"))
        click.echo()
        return

    result = verify_skill(entry["install_path"])

    if result["valid"]:
        click.echo(click.style(f"  Skill '{skill_name}' is valid", fg="green", bold=True))
        click.echo(f"  Hash: {result['actual_hash'][:24]}...")
    else:
        click.echo(click.style(f"  Skill '{skill_name}' FAILED verification", fg="red", bold=True))
        click.echo(f"  Error:    {result.get('error', 'unknown')}")
        if result.get("expected_hash"):
            click.echo(f"  Expected: {result['expected_hash'][:24]}...")
        if result.get("actual_hash"):
            click.echo(f"  Actual:   {result['actual_hash'][:24]}...")
    click.echo()


@skills.command("publish")
@click.argument("filepath", type=click.Path(exists=True))
@click.option("--price", required=True, type=float, help="Price in USDC (e.g. 5.00)")
@click.option("--category", "-c", required=True, help="Skill category")
@click.option("--title", default=None, help="Override title (default: from frontmatter)")
@click.option("--description", default=None, help="Override description")
def skills_publish(filepath, price, category, title, description):
    """Publish a local SKILL.md to the marketplace."""
    from airena.skills import SkillManager

    click.echo()

    arena = _get_arena(require_auth=True)

    try:
        manager = SkillManager(arena)
        result = manager.publish(
            filepath=filepath,
            price_usdc=price,
            category=category,
            title=title,
            description=description,
        )

        skill_id = result.get("id", "???")
        pub_title = result.get("title", title or "Untitled")

        click.echo(click.style(f"  Published '{pub_title}' to AiRENA Marketplace", fg="green", bold=True))
        click.echo(f"  Price: {price:.2f} USDC")
        click.echo(f"  ID:    {skill_id}")
        click.echo(f"  View:  https://airena-three.vercel.app/marketplace/skills/{skill_id}")
    except Exception as e:
        click.echo(click.style(f"  Error: {e}", fg="red"))
        sys.exit(1)
    click.echo()


if __name__ == "__main__":
    main()
