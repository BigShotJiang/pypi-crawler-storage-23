"""
Local registry of installed AiRENA skills.

Tracks what's installed, where, and content hashes for integrity verification.
Registry file: ~/.airena/installed-skills.json
"""

import json
import pathlib
from datetime import datetime, timezone
from typing import Optional


REGISTRY_VERSION = 1


def _registry_path() -> pathlib.Path:
    return pathlib.Path.home() / ".airena" / "installed-skills.json"


def load_registry() -> dict:
    """Load the local skill registry. Returns empty registry if not found."""
    path = _registry_path()
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and data.get("version") == REGISTRY_VERSION:
                return data
        except (json.JSONDecodeError, IOError):
            pass
    return {"version": REGISTRY_VERSION, "skills": {}}


def save_registry(registry: dict) -> None:
    """Save the local skill registry."""
    path = _registry_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(registry, indent=2, ensure_ascii=False), encoding="utf-8")


def register_skill(
    name: str,
    skill_id: str,
    install_path: str,
    target: str,
    content_hash: str,
    version: str = "1.0",
    teacher_agent: Optional[str] = None,
    price_usdc: int = 0,
) -> dict:
    """Register an installed skill in the local registry."""
    registry = load_registry()
    entry = {
        "skill_id": skill_id,
        "name": name,
        "install_path": install_path,
        "target": target,
        "content_hash": content_hash,
        "installed_at": datetime.now(timezone.utc).isoformat(),
        "version": version,
        "teacher_agent": teacher_agent,
        "price_usdc": price_usdc,
    }
    registry["skills"][name] = entry
    save_registry(registry)
    return entry


def unregister_skill(name: str) -> bool:
    """Remove a skill from the local registry. Returns True if found."""
    registry = load_registry()
    if name in registry["skills"]:
        del registry["skills"][name]
        save_registry(registry)
        return True
    return False


def get_installed_skill(name: str) -> Optional[dict]:
    """Get registry entry for an installed skill."""
    registry = load_registry()
    return registry["skills"].get(name)


def list_installed_skills() -> dict:
    """Return all installed skills as {name: entry} dict."""
    registry = load_registry()
    return registry.get("skills", {})
