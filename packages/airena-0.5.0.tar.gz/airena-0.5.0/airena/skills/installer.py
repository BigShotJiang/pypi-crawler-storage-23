"""
Skill installer — handles writing/removing skill files on disk.

Supports targets:
  - claude:   .claude/skills/<name>/SKILL.md (project-level)
  - openclaw: ~/.openclaw/skills/<name>/SKILL.md
  - custom:   <path>/skills/<name>/SKILL.md
"""

import hashlib
import json
import os
import pathlib
import shutil
from datetime import datetime, timezone
from typing import Optional


def compute_hash(content: str) -> str:
    """Compute SHA-256 hash of skill content."""
    return "sha256:" + hashlib.sha256(content.encode("utf-8")).hexdigest()


def detect_target() -> tuple:
    """Auto-detect install target based on environment.

    Returns:
        (target_name, base_path) tuple
    """
    # Check if .claude/ exists in current directory
    cwd_claude = pathlib.Path.cwd() / ".claude"
    if cwd_claude.exists() and cwd_claude.is_dir():
        return "claude", cwd_claude

    # Check if ~/.openclaw/ exists
    home_openclaw = pathlib.Path.home() / ".openclaw"
    if home_openclaw.exists() and home_openclaw.is_dir():
        return "openclaw", home_openclaw

    # Default to .claude/skills/ in current directory
    return "claude", cwd_claude


def resolve_target(target: Optional[str]) -> tuple:
    """Resolve target string to (target_name, base_path).

    Args:
        target: 'claude', 'openclaw', or a filesystem path. None for auto-detect.

    Returns:
        (target_name, base_path) tuple
    """
    if target is None:
        return detect_target()

    if target == "claude":
        return "claude", pathlib.Path.cwd() / ".claude"
    elif target == "openclaw":
        return "openclaw", pathlib.Path.home() / ".openclaw"
    else:
        # Custom path
        return "custom", pathlib.Path(target)


def install_skill(
    name: str,
    content: str,
    skill_id: str,
    target: Optional[str] = None,
    version: str = "1.0",
    teacher_agent: Optional[str] = None,
    price_usdc: int = 0,
) -> dict:
    """Install a skill to the filesystem.

    Args:
        name: Skill name (slug-form, e.g. 'advanced-debugging')
        content: Formatted SKILL.md content
        skill_id: Marketplace skill UUID
        target: Install target ('claude', 'openclaw', path, or None for auto)
        version: Skill version
        teacher_agent: Name of the teaching agent
        price_usdc: Price paid in atomic USDC

    Returns:
        dict with install_path, content_hash, target, size_bytes
    """
    target_name, base_path = resolve_target(target)

    # Build skill directory
    skill_dir = base_path / "skills" / name
    skill_dir.mkdir(parents=True, exist_ok=True)

    # Write SKILL.md
    skill_file = skill_dir / "SKILL.md"
    skill_file.write_text(content, encoding="utf-8")

    # Compute hash
    content_hash = compute_hash(content)

    # Write .airena-meta.json
    meta = {
        "skill_id": skill_id,
        "name": name,
        "installed_at": datetime.now(timezone.utc).isoformat(),
        "version": version,
        "content_hash": content_hash,
        "source": "airena-marketplace",
        "teacher_agent": teacher_agent,
        "price_usdc": price_usdc,
    }
    meta_file = skill_dir / ".airena-meta.json"
    meta_file.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")

    size_bytes = len(content.encode("utf-8"))

    return {
        "install_path": str(skill_dir),
        "content_hash": content_hash,
        "target": target_name,
        "size_bytes": size_bytes,
    }


def uninstall_skill(install_path: str) -> bool:
    """Remove a skill directory from disk.

    Args:
        install_path: Path to the skill directory

    Returns:
        True if removed, False if not found
    """
    path = pathlib.Path(install_path)
    if path.exists() and path.is_dir():
        shutil.rmtree(path)
        return True
    return False


def verify_skill(install_path: str) -> dict:
    """Verify an installed skill's integrity.

    Returns:
        dict with 'valid', 'expected_hash', 'actual_hash', 'error'
    """
    path = pathlib.Path(install_path)
    skill_file = path / "SKILL.md"
    meta_file = path / ".airena-meta.json"

    if not skill_file.exists():
        return {"valid": False, "error": "SKILL.md not found"}

    if not meta_file.exists():
        return {"valid": False, "error": ".airena-meta.json not found"}

    try:
        meta = json.loads(meta_file.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, IOError) as e:
        return {"valid": False, "error": f"Cannot read meta: {e}"}

    content = skill_file.read_text(encoding="utf-8")
    actual_hash = compute_hash(content)
    expected_hash = meta.get("content_hash", "")

    return {
        "valid": actual_hash == expected_hash,
        "expected_hash": expected_hash,
        "actual_hash": actual_hash,
        "error": None if actual_hash == expected_hash else "Hash mismatch — content modified",
    }
