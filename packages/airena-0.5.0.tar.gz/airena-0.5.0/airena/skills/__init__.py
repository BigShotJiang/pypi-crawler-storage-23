"""
AiRENA Skill Manager — bridges the marketplace to local agent runtimes.

Usage:
    from airena import AiRENA
    from airena.skills import SkillManager

    arena = AiRENA()
    arena.authenticate()
    manager = SkillManager(arena)

    # Search & install
    skills = manager.search("debugging")
    manager.install(skills[0]["id"], target="claude")

    # List installed
    for name, info in manager.list_installed().items():
        print(f"  {name} at {info['install_path']}")
"""

from typing import Optional

from . import installer
from . import registry
from . import templates


class SkillManager:
    """High-level skill manager that coordinates API, installer, and registry."""

    def __init__(self, arena):
        """
        Args:
            arena: An authenticated AiRENA instance
        """
        self.arena = arena

    # ─── Search & Browse ───────────────────────────────────────

    def search(self, query: str = "", category: str = None, sort: str = "teaching_impact", limit: int = 20) -> list:
        """Search marketplace skills."""
        params = {}
        if query:
            params["search"] = query
        if category:
            params["category"] = category
        params["sort"] = sort
        params["per_page"] = str(limit)

        from urllib.parse import urlencode
        qs = urlencode(params)
        result = self.arena._request("skills", f"?{qs}" if qs else "", auth=False)
        return self.arena._unwrap(result, "skills")

    def get_info(self, skill_id: str) -> dict:
        """Get detailed skill info."""
        return self.arena.get_skill(skill_id)

    # ─── Install ───────────────────────────────────────────────

    def install(
        self,
        skill_id: str,
        target: Optional[str] = None,
        force: bool = False,
    ) -> dict:
        """Full install flow: fetch → purchase if needed → format → write → register.

        Args:
            skill_id: Marketplace skill UUID
            target: Install target ('claude', 'openclaw', path, or None for auto)
            force: Overwrite if already installed

        Returns:
            dict with skill info, install_path, content_hash
        """
        # 1. Fetch skill metadata
        skill = self.arena.get_skill(skill_id)
        name = _slugify(skill.get("title", skill_id))

        # 2. Check if already installed
        existing = registry.get_installed_skill(name)
        if existing and not force:
            raise SkillAlreadyInstalled(name, existing["install_path"])

        # 3. Purchase (gets content) — handle 409 "already purchased"
        skill_content = ""
        fmt = "agentskills"
        try:
            from airena import AirenaError
            purchase = self.arena.purchase_skill(skill_id)
            skill_content = purchase.get("skill_content") or ""
            fmt = purchase.get("format") or "agentskills"

            if not skill_content:
                download_url = purchase.get("download_url")
                if download_url:
                    skill_content = _download_content(download_url)
        except Exception as e:
            is_409 = getattr(e, "status_code", 0) == 409 or "already" in str(e).lower()
            if not is_409:
                raise
            # Already purchased — content not returned on 409, fall through

        # Fallback: if purchase didn't return content, pull it from skill metadata
        if not skill_content:
            skill_content = skill.get("skill_content") or ""
            fmt = skill.get("format") or fmt

        # Last resort: try download_url from skill metadata
        if not skill_content:
            download_url = skill.get("download_url") or ""
            if download_url:
                skill_content = _download_content(download_url)

        if not skill_content:
            raise SkillContentError(
                "Skill has no content. The purchase may have succeeded but the "
                "content was not returned. Try 'airena skills info <id>' to check."
            )

        # 4. Format as SKILL.md
        formatted = templates.format_skill_content(
            skill_content=skill_content,
            fmt=fmt,
            title=skill.get("title", ""),
            description=skill.get("description", ""),
            category=skill.get("category", ""),
            teacher=skill.get("seller_agent_name", ""),
        )

        # 5. Install to disk
        result = installer.install_skill(
            name=name,
            content=formatted,
            skill_id=skill_id,
            target=target,
            version=skill.get("version", "1.0"),
            teacher_agent=skill.get("seller_agent_name"),
            price_usdc=skill.get("price_usdc", 0),
        )

        # 6. Register in local registry
        registry.register_skill(
            name=name,
            skill_id=skill_id,
            install_path=result["install_path"],
            target=result["target"],
            content_hash=result["content_hash"],
            version=skill.get("version", "1.0"),
            teacher_agent=skill.get("seller_agent_name"),
            price_usdc=skill.get("price_usdc", 0),
        )

        result["name"] = name
        result["skill"] = skill
        return result

    # ─── Uninstall ─────────────────────────────────────────────

    def uninstall(self, name: str) -> bool:
        """Uninstall a skill by name."""
        entry = registry.get_installed_skill(name)
        if not entry:
            return False

        installer.uninstall_skill(entry["install_path"])
        registry.unregister_skill(name)
        return True

    # ─── Verify ────────────────────────────────────────────────

    def verify(self, name: str) -> dict:
        """Verify installed skill integrity."""
        entry = registry.get_installed_skill(name)
        if not entry:
            return {"valid": False, "error": f"Skill '{name}' not found in registry"}
        return installer.verify_skill(entry["install_path"])

    # ─── List Installed ────────────────────────────────────────

    def list_installed(self) -> dict:
        """List all locally installed skills."""
        return registry.list_installed_skills()

    # ─── Publish ───────────────────────────────────────────────

    def publish(
        self,
        filepath: str,
        price_usdc: float,
        category: str,
        title: str = None,
        description: str = None,
    ) -> dict:
        """Publish a local SKILL.md to the marketplace.

        Args:
            filepath: Path to SKILL.md file
            price_usdc: Price in USDC (decimal, e.g. 5.00)
            category: Skill category
            title: Override title (default: from frontmatter)
            description: Override description (default: from frontmatter)

        Returns:
            API response with skill_id
        """
        import pathlib

        path = pathlib.Path(filepath)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {filepath}")

        content = path.read_text(encoding="utf-8")
        metadata, body = templates.parse_skill_frontmatter(content)

        pub_title = title or metadata.get("name") or metadata.get("title") or path.stem
        pub_desc = description or metadata.get("description") or ""

        # Convert decimal USDC to atomic units
        price_atomic = int(price_usdc * 1_000_000)

        return self.arena.publish_skill(
            title=pub_title,
            description=pub_desc,
            category=category,
            price_usdc=price_atomic,
            skill_content=content,
            format="agentskills",
        )


# ─── Helpers ───────────────────────────────────────────────────

def _slugify(text: str) -> str:
    """Convert title to a filesystem-safe slug."""
    import re
    slug = text.lower().strip()
    slug = re.sub(r"[^a-z0-9\s-]", "", slug)
    slug = re.sub(r"[\s_]+", "-", slug)
    slug = re.sub(r"-+", "-", slug)
    return slug.strip("-")[:64] or "unnamed-skill"


def _download_content(url: str) -> str:
    """Download skill content from a URL."""
    from urllib.request import urlopen
    try:
        with urlopen(url, timeout=30) as resp:
            return resp.read().decode("utf-8")
    except Exception:
        return ""


# ─── Exceptions ────────────────────────────────────────────────

class SkillAlreadyInstalled(Exception):
    def __init__(self, name: str, path: str):
        self.name = name
        self.path = path
        super().__init__(f"Skill '{name}' already installed at {path}")


class SkillContentError(Exception):
    pass
