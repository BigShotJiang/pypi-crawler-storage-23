"""
SKILL.md template formatting for AiRENA skill packages.

Handles conversion from various skill formats to proper SKILL.md files
compatible with Claude (.claude/skills/) and OpenClaw (~/.openclaw/skills/).
"""


def format_agentskills(content: str) -> str:
    """Content is already in Agent Skills markdown format. Return as-is."""
    return content


def wrap_code_as_skill(
    title: str,
    description: str,
    code: str,
    language: str = "python",
    category: str = "",
    teacher: str = "",
) -> str:
    """Wrap raw code in a simple SKILL.md template (no frontmatter)."""
    header = f"# {title}\n\n"
    if description:
        header += f"{description}\n\n"
    if teacher:
        header += f"*Learned from {teacher} on AiRENA marketplace*\n\n"
    if category:
        header += f"**Category:** {category}\n\n"

    header += "## Implementation\n\n"
    header += f"```{language}\n{code}\n```\n"

    return header


def wrap_code_as_skillmd(
    title: str,
    description: str,
    code: str,
    language: str = "python",
    category: str = "",
    teacher: str = "",
) -> str:
    """Wrap raw source code in a SKILL.md with YAML frontmatter.

    Used for format='source_code' skills from the marketplace.
    Produces a proper Agent Skills format file with frontmatter metadata
    and a fenced code block.
    """
    lines = ["---"]
    lines.append(f"name: {title}")
    if description:
        # Keep frontmatter description on one line, truncated
        short_desc = description.replace("\n", " ").strip()
        if len(short_desc) > 120:
            short_desc = short_desc[:117] + "..."
        lines.append(f"description: \"{short_desc}\"")
    if category:
        lines.append(f"category: {category}")
    if teacher:
        lines.append(f"teacher: {teacher}")
    lines.append(f"source: airena-marketplace")
    lines.append("---")
    lines.append("")

    lines.append(f"# {title}")
    lines.append("")
    if description:
        lines.append(description)
        lines.append("")
    if teacher:
        lines.append(f"*Learned from {teacher} on AiRENA marketplace*")
        lines.append("")

    lines.append("## Implementation")
    lines.append("")
    lines.append(f"```{language}")
    lines.append(code)
    lines.append("```")
    lines.append("")

    return "\n".join(lines)


def format_skill_content(
    skill_content: str,
    fmt: str,
    title: str = "",
    description: str = "",
    category: str = "",
    teacher: str = "",
    language: str = "python",
) -> str:
    """Format skill content based on its format type.

    Args:
        skill_content: The raw skill content
        fmt: Format type - 'agentskills', 'code', 'markdown', etc.
        title: Skill title (used for code wrapping)
        description: Skill description
        category: Skill category
        teacher: Teacher agent name
        language: Code language (for code format)

    Returns:
        Formatted SKILL.md content
    """
    if fmt == "agentskills" or fmt == "markdown":
        return format_agentskills(skill_content)
    elif fmt in ("code", "source_code"):
        return wrap_code_as_skillmd(
            title=title,
            description=description,
            code=skill_content,
            language=language,
            category=category,
            teacher=teacher,
        )
    else:
        # Unknown format — wrap as-is with a header
        result = f"# {title}\n\n" if title else ""
        result += f"{description}\n\n" if description else ""
        result += skill_content
        return result


def parse_skill_frontmatter(content: str) -> tuple:
    """Parse YAML frontmatter from a SKILL.md file.

    Returns:
        (metadata_dict, body_str)
    """
    try:
        import yaml
    except ImportError:
        # Fallback: simple parsing without yaml
        return _parse_frontmatter_simple(content)

    if not content.startswith("---"):
        return {}, content

    parts = content.split("---", 2)
    if len(parts) < 3:
        return {}, content

    try:
        metadata = yaml.safe_load(parts[1]) or {}
    except yaml.YAMLError:
        metadata = {}

    body = parts[2].strip()
    return metadata, body


def _parse_frontmatter_simple(content: str) -> tuple:
    """Simple frontmatter parser without yaml dependency."""
    if not content.startswith("---"):
        return {}, content

    lines = content.split("\n")
    metadata = {}
    end_idx = 0

    for i, line in enumerate(lines[1:], 1):
        if line.strip() == "---":
            end_idx = i
            break
        if ":" in line:
            key, _, val = line.partition(":")
            metadata[key.strip()] = val.strip().strip('"').strip("'")

    body = "\n".join(lines[end_idx + 1:]).strip() if end_idx > 0 else content
    return metadata, body
