# Posture Agent - CLAUDE.md

Developer endpoint agent distributed via PyPI as `intercept-agent`. Runs on developer machines to collect environment metadata (installed tools, security posture, IDE configuration) and reports it to the Intercept API for supply chain security assessment.

**Current version**: Check `VERSION` file (bump before every commit).

## Critical Rules

1. **macOS-only today.** All collectors use macOS-specific commands (`ioreg`, `sysctl`, `fdesetup`, `spctl`, `launchctl`). When adding Linux/Windows support, every collector must be guarded with `platform.system()` checks -- never assume macOS.

2. **Minimal dependencies.** This package installs on user machines. Only four runtime deps: `click`, `pydantic`, `pyyaml`, `httpx`. Do NOT add dependencies without strong justification. Use stdlib whenever possible (e.g., `logging` instead of `loguru`).

3. **Metadata only, never secrets.** Collectors report names, versions, boolean statuses, and file names. NEVER read file contents of SSH private keys, credentials, tokens, or config values. The `security.py` collector reads only the first 64 bytes of SSH key files to detect the key type header.

4. **All collectors must be fault-tolerant.** Every detection call can fail (tool not installed, permission denied, timeout). Always wrap in try/except, append to `errors` list, and continue. A single collector failure must never crash the agent.

5. **Async throughout.** All collectors and shell commands are async. Use `asyncio.gather` for parallel execution. Shell commands go through `utils/shell.py`, never `subprocess` directly.

6. **Version bump required.** CI/CD publishes to PyPI on version change. Bump `VERSION` before committing.

## Project Structure

```
services/posture-agent/
  VERSION                          # Semver, read by hatchling for PyPI version
  pyproject.toml                   # Build config (hatchling), deps, entry point
  resources/
    com.hijacksecurity.intercept-agent.plist   # Template for launchd
  config/
    dev-local.yaml                 # debug: true, localhost API
    dev-docker.yaml                # docker network API URL
    test.yaml                      # test cluster API URL
    prod.yaml                      # production API URL
  posture_agent/
    __init__.py
    main.py                        # Click CLI: collect, install, uninstall, status
    core/
      config.py                    # Settings class, YAML + env var loading
      logging.py                   # stdlib logging setup (text or JSON format)
    collectors/
      base.py                      # BaseCollector ABC + CollectorResult model
      machine.py                   # Hostname, OS, CPU, memory, username
      ides.py                      # VS Code, Cursor, JetBrains, Xcode, vim, etc.
      extensions.py                # IDE extensions (VS Code CLI or filesystem fallback)
      ai_tools.py                  # AI coding tools (CLI + IDE extensions)
      dev_tools.py                 # Languages, build tools, cloud CLIs, containers
      security.py                  # Git signing, SSH keys, FileVault, firewall, Gatekeeper
      package_managers.py          # Homebrew, npm, pip, cargo, etc.
      mcp_servers.py               # MCP server configs with risk indicators
    models/
      report.py                    # PostureReportPayload Pydantic model
    services/
      fingerprint.py               # Machine UUID via ioreg (SHA256-hashed)
      reporter.py                  # HTTP POST to API with retry/backoff
    utils/
      shell.py                     # run_command(), check_version(), PATH expansion
  tests/
    test_cli.py                    # Click CLI smoke tests
    test_collectors.py             # Per-collector integration tests
    test_fingerprint.py            # Fingerprint stability tests
```

## Patterns and Conventions

### Adding a New Collector

1. Create `posture_agent/collectors/my_collector.py`:

```python
"""My new collector."""

from posture_agent.collectors.base import BaseCollector, CollectorResult
from posture_agent.utils.shell import check_version, run_command


class MyCollector(BaseCollector):
    name = "my_collector"  # This becomes the key in the report payload

    async def collect(self) -> CollectorResult:
        errors: list[str] = []
        data: list[dict[str, str]] = []

        try:
            which_result = await run_command("which", "mytool")
            if which_result and which_result.strip():
                version = await check_version("mytool", "--version") or ""
                data.append({"name": "MyTool", "version": version})
        except Exception as e:
            errors.append(f"MyTool: {e}")

        return CollectorResult(collector=self.name, data=data, errors=errors)
```

2. Register in `main.py` -- add to imports and to `run_collection()`:

```python
from posture_agent.collectors.my_collector import MyCollector

# Inside run_collection(), after other collector checks:
if settings.collectors.my_collector:
    collectors.append(MyCollector())
```

3. Add toggle to `CollectorsConfig` in `core/config.py`:

```python
class CollectorsConfig(BaseModel):
    # ... existing fields ...
    my_collector: bool = True
```

4. Add field to `PostureReportPayload` in `models/report.py`:

```python
class PostureReportPayload(BaseModel):
    # ... existing fields ...
    my_collector: list[Any] | dict[str, Any] = []
```

5. Add tests in `tests/test_collectors.py`.

### Adding a New Tool Detection

For tools detected by binary name and version flag, add to the appropriate definitions list:

```python
# In dev_tools.py (DEV_TOOL_DEFINITIONS), ai_tools.py (AI_CLI_TOOLS),
# or package_managers.py (PACKAGE_MANAGERS):
("Display Name", "binary_name", "--version"),
```

The `check_version()` helper extracts the first semver-like pattern from the first line of output. Multi-word flags like `"version --client"` are split automatically.

### Adding an IDE

Add a tuple to `IDE_DEFINITIONS` in `ides.py`:

```python
# (display_name, binary_or_None, app_bundle_path_or_None, version_flag_or_None)
("My IDE", "myide", "/Applications/MyIDE.app", "--version"),
```

Detection checks the app bundle first (macOS `/Applications/`), then falls back to `which <binary>`. Version is read from `Info.plist` if the app bundle exists, otherwise from the CLI flag.

### Shell Command Execution

Always use the helpers in `utils/shell.py`:

```python
from posture_agent.utils.shell import run_command, check_version

# run_command: returns stdout as str or None on any failure
result = await run_command("git", "config", "--global", "user.name")
if result:  # Always check for None
    value = result.strip()

# check_version: extracts version pattern from command output
version = await check_version("node", "--version")  # Returns "20.11.0" or None
```

- `run_command` has a 10-second default timeout.
- `_get_expanded_path()` adds common tool locations (`/opt/homebrew/bin`, `~/.cargo/bin`, nvm dirs, etc.) so tools are found even under launchd's minimal PATH.
- Never call `subprocess` directly; always go through these helpers.

## Data Flow

```
1. CLI invoked:     intercept-agent collect [--report]
2. Fingerprint:     ioreg -> IOPlatformUUID -> SHA256[:32]
3. Collectors:      asyncio.gather(machine, ides, extensions, ai_tools,
                                   dev_tools, security, package_managers, mcp_servers)
4. Payload:         PostureReportPayload(fingerprint, agent_version, collected_at, ...)
5. Dry run:         JSON to stdout
6. Report mode:     POST {API_URL}/api/v1/core/posture/reports
                    Headers: X-API-Key (if hsk_ api_key configured)
                    tenant_id resolved server-side from API key
                    Retry: 3 attempts, exponential backoff (2^attempt seconds)
```

### Machine Fingerprint

Stable unique ID per machine, generated in `services/fingerprint.py`:
1. Primary: `ioreg` IOPlatformUUID (macOS hardware UUID)
2. Fallback: IOPlatformSerialNumber
3. Last resort: `hostname-architecture`

Result is always a 32-character hex string (SHA256 truncated).

### Report Payload Schema

```json
{
  "fingerprint": "a1b2c3d4e5f6...",
  "agent_version": "0.3.4",
  "collected_at": "2025-01-24T12:00:00Z",
  "machine": {
    "hostname": "dev-laptop",
    "username": "developer",
    "os_name": "macOS",
    "os_version": "15.2",
    "architecture": "arm64",
    "cpu_brand": "Apple M3 Pro",
    "cpu_cores": 12,
    "memory_gb": 36.0
  },
  "ides": [{"name": "VS Code", "version": "1.96.0", "binary": "code"}],
  "extensions": {
    "vscode": [{"id": "ms-python.python", "version": "2024.0.1"}],
    "jetbrains": [{"id": "plugin-name", "ide": "IntelliJIdea2024.3", "version": "1.0"}]
  },
  "ai_tools": [
    {"name": "Claude Code", "type": "cli", "binary": "claude", "version": "1.0.0"},
    {"name": "github.copilot", "type": "extension", "editor": "VS Code", "version": ""}
  ],
  "dev_tools": [{"name": "Git", "binary": "git", "version": "2.43.0", "path": "/usr/bin/git"}],
  "security": {
    "git_signing_enabled": true,
    "git_signing_format": "ssh",
    "git_name": "Dev User",
    "git_email": "dev@example.com",
    "ssh_key_count": 2,
    "ssh_keys": [{"name": "id_ed25519", "algorithm": "ed25519"}],
    "ssh_agent_keys": 1,
    "ssh_agent_type": "1Password",
    "filevault_enabled": true,
    "firewall_enabled": true,
    "gatekeeper_enabled": true,
    "global_hooks_path": "",
    "credential_helper": "osxkeychain",
    "allowed_signers_configured": true,
    "allowed_signers_exists": true
  },
  "package_managers": [{"name": "Homebrew", "binary": "brew", "version": "4.2.0"}],
  "mcp_servers": [
    {
      "name": "github",
      "tool": "claude",
      "config_path": "/Users/dev/.claude/mcp.json",
      "transport": "stdio",
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "url": null,
      "env_keys": ["GITHUB_TOKEN"],
      "risk_indicators": ["credentials"]
    }
  ]
}
```

## Configuration

### Load Priority (first found wins)

1. `~/.config/intercept/agent.yaml` (user config, created by `install` command)
2. `config/{ENVIRONMENT}.yaml` (from package directory)

### Environment Variable Overrides

| Variable | Effect |
|---|---|
| `ENVIRONMENT` | Selects config file: `dev-local`, `dev-docker`, `test`, `prod` (default: `dev-local`) |
| `INTERCEPT_API_URL` | Overrides `api.url` |
| `INTERCEPT_API_KEY` | Sets `api.api_key`. Must be `hsk_` prefixed. Sent as `X-API-Key` header. |
| `INTERCEPT_TENANT_ID` | Sets `api.tenant_id` (included in report body) |

### Disabling Collectors

In `agent.yaml` or environment config:

```yaml
collectors:
  mcp_servers: false    # Skip MCP server discovery
  security: false       # Skip security posture checks
```

## Testing

```bash
# Run all tests
cd services/posture-agent && PYTHONPATH=. ../../.venv/bin/pytest tests/ -v

# Run a specific test class
PYTHONPATH=. ../../.venv/bin/pytest tests/test_collectors.py::TestMCPServersCollector -v

# Dry-run collection (no API call)
PYTHONPATH=. ../../.venv/bin/python -m posture_agent.main collect

# Test with debug logging
PYTHONPATH=. ../../.venv/bin/python -m posture_agent.main --debug collect
```

Tests run the actual collectors against the local machine (integration-style). They verify:
- Each collector returns a `CollectorResult` with the correct `collector` name
- Data types match expectations (list, dict)
- Ubiquitous tools like Git are detected
- Fingerprint is stable across calls (32 hex chars)
- CLI commands exit cleanly and produce expected output

When mocking is needed (e.g., testing error paths), patch `posture_agent.utils.shell.run_command`.

## Common Mistakes

**1. Forgetting None checks on `run_command` return values.**
`run_command` returns `None` on any failure (timeout, command not found, non-zero exit). Always check before calling `.strip()`.
```python
# WRONG:
result = await run_command("which", "node")
path = result.strip()  # AttributeError if tool not installed

# RIGHT:
result = await run_command("which", "node")
if result and result.strip():
    path = result.strip()
```

**2. Hardcoding macOS paths without platform guards.**
When extending for Linux/Windows, never assume `/Applications/`, `~/Library/`, or macOS commands exist.
```python
# WRONG (breaks on Linux):
plist_path = Path.home() / "Library" / "Application Support" / "JetBrains"

# RIGHT:
import platform
if platform.system() == "Darwin":
    config_dir = Path.home() / "Library" / "Application Support" / "JetBrains"
elif platform.system() == "Linux":
    config_dir = Path.home() / ".local" / "share" / "JetBrains"
```

**3. Not adding the new collector to all four locations.**
A new collector requires changes in: (1) the collector module, (2) `CollectorsConfig` in `config.py`, (3) `run_collection()` in `main.py`, (4) `PostureReportPayload` in `report.py`. Missing any of these causes silent data loss or startup errors.

**4. Reading sensitive file contents.**
The agent collects metadata about files (names, types, existence), never their contents. The SSH key detection reads only a 64-byte header to identify the key format. Do not expand this pattern.

**5. Blocking the event loop.**
All I/O must be async. Use `run_command()` (which uses `asyncio.create_subprocess_exec`) instead of `subprocess.run()` in collectors. The only exceptions are the CLI commands (`install`, `uninstall`, `status`) which use `subprocess.run` directly since they are not performance-sensitive.

**6. Adding heavyweight dependencies.**
This runs on user machines installed via `pip`/`pipx`. Every dependency increases install size, potential conflicts, and attack surface. Prefer stdlib solutions.

## Scheduling (macOS launchd)

The `install` command creates a launchd plist at `~/Library/LaunchAgents/com.hijacksecurity.intercept-agent.plist` that:
- Runs `intercept-agent collect --report` on the configured interval (default: 3600s)
- Captures the user's expanded PATH so tools are discoverable
- Logs to `~/.config/intercept/logs/agent.{stdout,stderr}.log`
- Runs at load (`RunAtLoad: true`) and does not stay alive (`KeepAlive: false`)

## Building and Publishing

```bash
# Build wheel and sdist
cd services/posture-agent && python -m build

# Publishing is handled by CI (ci-posture-agent.yml) on VERSION bump
```

Build system: `hatchling`. Version is read dynamically from the `VERSION` file. Entry point: `intercept-agent = posture_agent.main:cli`.
