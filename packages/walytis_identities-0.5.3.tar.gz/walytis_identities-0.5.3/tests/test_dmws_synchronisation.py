import _auto_run_with_pytest  # noqa
from testing_utils import collect_all_test_logs
from datetime import datetime
from time import sleep
from testing_utils import get_logs_and_delete_dockers, DOCKER_LOG_FILES
from emtest import get_pytest_report_dirs
import json
import os
import shutil
from threading import Thread

from conftest import cleanup_walytis_ipfs, logger_tests
import pytest
from brenthy_docker import DockerShellError, DockerShellTimeoutError
from brenthy_tools_beta.utils import function_name
from emtest import are_we_in_docker, await_thread_cleanup, env_vars
from termcolor import colored as coloured
from testing_utils import (
    CORRESP_JOIN_TIMEOUT_S,
    CRYPTO_FAMILY,
    KEY,
    PROFILE_CREATE_TIMEOUT_S,
    PROFILE_JOIN_TIMEOUT_S,
    dm_config_dir,
)
from walid_docker.build_docker import build_docker_image
from walid_docker.walid_docker import (
    WalytisIdentitiesDocker,
    delete_containers,
)

from walytis_identities.log import (
    logger_dmws,
    logger_gdm_join,
)
import logging

logger_gdm_join.setLevel(logging.DEBUG)
logger_tests.setLevel(logging.DEBUG)

REBUILD_DOCKER = True
REBUILD_DOCKER = env_vars.bool("TESTS_REBUILD_DOCKER", default=REBUILD_DOCKER)

CONTAINER_NAME_PREFIX = "walytis_identities_tests_dmws_"


# Boilerplate python code when for running python tests in a docker container
DOCKER_PYTHON_LOAD_TESTING_CODE = """
import sys
import threading
import json
from time import sleep
sys.path.append('/opt/walytis_identities/tests')
import conftest # configure Walytis API & logging
import docker_dmws_sync
from docker_dmws_sync import shared_data
import pytest
from docker_dmws_sync import logger_tests
logger_tests.info('DOCKER: Preparing tests...')
docker_dmws_sync.REBUILD_DOCKER=False
docker_dmws_sync.DELETE_ALL_BRENTHY_DOCKERS=False
logger_tests.info('DOCKER: Ready to test!')
"""
DOCKER_PYTHON_FINISH_TESTING_CODE = """
"""

N_DOCKER_CONTAINERS = 4


class SharedData:
    def __init__(self):
        self.abort = False
        self.super = None
        self.dm = None
        self.key_store_path = os.path.join(dm_config_dir, "keystore.json")

        # the cryptographic family to use for the tests
        self.CRYPTO_FAMILY = CRYPTO_FAMILY
        self.KEY = KEY
        print("Setting up docker containers...")

        self.containers: list[WalytisIdentitiesDocker] = [
            None
        ] * N_DOCKER_CONTAINERS

    def init_dockers(self):
        threads = []
        delete_containers(container_name_substr=CONTAINER_NAME_PREFIX)
        for i in range(N_DOCKER_CONTAINERS):

            def task(number):
                self.containers[number] = WalytisIdentitiesDocker(
                    container_name=f"{CONTAINER_NAME_PREFIX}{number}"
                )

            thread = Thread(target=task, args=(i,))
            thread.start()
            threads.append(thread)
        for thread in threads:
            thread.join()

        # ensure IPFS nodes in all containers connect to each other
        for i in range(N_DOCKER_CONTAINERS):
            peer_conn_info = []
            for j in range(N_DOCKER_CONTAINERS):
                if j == i:
                    continue

                # wait for IPFS nodes to initialise
                self.containers[i].await_ipfs()
                self.containers[j].await_ipfs()

                peer_id = self.containers[j].ipfs_id
                multiaddrs = self.containers[j].get_multi_addrs()
                for multiaddr in multiaddrs:
                    result = self.containers[i].run_bash_code(
                        f"ipfs swarm connect {multiaddr}/p2p/{peer_id}"
                    )
                    if f"connect {peer_id} success" in result:
                        break
                    print(result)

                multiaddr_info = ", ".join(
                    [f'"{multiaddr}"' for multiaddr in multiaddrs]
                )
                peer_conn_info.append(
                    f'{{"ID": "{peer_id}", "Addrs": [{multiaddr_info}]}}'
                )
            _peer_conn_info = ",".join(peer_conn_info)
            self.containers[i].run_bash_code(
                f"ipfs config --json Peering.Peers '[{_peer_conn_info}]'"
            )
        print("Set up docker containers.")


shared_data = SharedData()


@pytest.fixture(scope="module", autouse=True)
def setup_and_teardown(request: pytest.FixtureRequest) -> None:
    """Wrap around tests, running preparations and cleaning up afterwards.

    A module-level fixture that runs once for all tests in this file.
    """
    # Setup: code here runs before tests that uses this fixture
    print(f"\nRunning tests for {__name__}\n")
    prepare()

    yield  # This separates setup from teardown

    # Teardown: code here runs after the tests
    print(f"\nFinished tests for {__name__}\n")
    # cleanup(request)


def prepare():
    if not os.path.exists(dm_config_dir):
        os.makedirs(dm_config_dir)
    if are_we_in_docker():
        return
    if REBUILD_DOCKER:
        build_docker_image(verbose=False)

    shared_data.init_dockers()


def setup_dm(docker_container: WalytisIdentitiesDocker):
    """In a docker container, create an Endra dm."""
    print(coloured(f"\n\nRunning {function_name()}", "blue"))

    python_code = "\n".join(
        [
            DOCKER_PYTHON_LOAD_TESTING_CODE,
            "docker_dmws_sync.docker_create_dm()",
            "print(f'DOCKER: Created DidManagerWithSupers: {type(shared_data.dm)}')",
            "shared_data.dm.terminate()",
            "print('Terminated!')",
        ]
    )
    try:
        output_lines = docker_container.run_python_code(
            python_code,
            print_output=True,
            timeout=PROFILE_CREATE_TIMEOUT_S,
            background=False,
        ).split("\n")

    except DockerShellError as e:
        print(e)
        output_lines = []
        # breakpoint()
    except DockerShellTimeoutError as e:
        print(f"Docker shell timeout reached after {e.timeout}s")
        output_lines = e.output.split("\n")
    docker_lines = [
        line.replace("DOCKER: ", "").strip()
        for line in output_lines
        if line.startswith("DOCKER: ")
    ]
    last_line = docker_lines[-1] if len(docker_lines) > 0 else None
    assert (
        last_line
        == "Created DidManagerWithSupers: <class 'walytis_identities.did_manager_with_supers.DidManagerWithSupers'>"
    ), function_name()


def load_dm(docker_container: WalytisIdentitiesDocker) -> dict | None:
    """In a docker container, load an Endra dm & create an invitation.

    The docker container must already have had the Endra dm set up.

    Args:
        docker_container: the docker container in which to load the dm
    Returns:
        dict: an invitation to allow another device to join the dm
    """
    print(coloured(f"\n\nRunning {function_name()}", "blue"))
    python_code = "\n".join(
        [
            DOCKER_PYTHON_LOAD_TESTING_CODE,
            "docker_dmws_sync.docker_load_dm()",
            "invitation=shared_data.dm.did_manager.invite_member()",
            "print('DOCKER: ', json.dumps(invitation))",
            "print(f'DOCKER: Loaded DidManagerWithSupers: {type(shared_data.dm)}')",
            "shared_data.dm.terminate()",
        ]
    )
    # breakpoint()
    try:
        output_lines = docker_container.run_python_code(
            python_code,
            print_output=True,
            timeout=PROFILE_CREATE_TIMEOUT_S,
            background=False,
        ).split("\n")
    except DockerShellError as e:
        print(e)
        output_lines = []
        # breakpoint()
    except DockerShellTimeoutError as e:
        print(f"Docker shell timeout reached after {e.timeout}s")
        output_lines = e.output.split("\n")

    docker_lines = [
        line.replace("DOCKER: ", "").strip()
        for line in output_lines
        if line.startswith("DOCKER: ")
    ]

    if len(docker_lines) < 2:
        assert False, function_name()

    last_line = docker_lines[-1] if len(docker_lines) > 0 else None

    try:
        invitation = json.loads(docker_lines[-2].strip().replace("'", '"'))
    except json.decoder.JSONDecodeError:
        logger_tests.warning(f"Error getting invitation: {docker_lines[-2]}")
        invitation = None
    assert (
        last_line
        == "Loaded DidManagerWithSupers: <class 'walytis_identities.did_manager_with_supers.DidManagerWithSupers'>"
    ), function_name()

    return invitation


def add_sub(
    docker_container_new: WalytisIdentitiesDocker,
    docker_container_old: WalytisIdentitiesDocker,
    invitation: dict,
    task_name: str,
) -> None:
    """Join an existing Endra dm on a new docker container.

    Args:
        docker_container_new: the container on which to set up Endra, joining
            the existing Endra dm
        docker_container_old; the container on which the Endra dm is
            already set up
        invitation: the invitation that allows the new docker container to join
            the Endra dm
    """
    print(coloured(f"\n\nRunning {function_name()}", "blue"))

    python_code = "\n".join(
        [
            DOCKER_PYTHON_LOAD_TESTING_CODE,
            f"logger_tests.info('Running {task_name} - OLD')",
            "docker_dmws_sync.docker_load_dm()",
            "logger_tests.info('Waiting to allow new device to join...')",
            f"sleep({PROFILE_JOIN_TIMEOUT_S})",
            "logger_tests.info('Finished waiting, terminating...')",
            "shared_data.dm.terminate()",
            "logger_tests.info('Exiting after waiting.')",
        ]
    )
    docker_container_old.run_python_code(
        python_code,
        background=True,
        print_output=True,
    )
    invit_json = json.dumps(invitation)

    python_code = "\n".join(
        [
            DOCKER_PYTHON_LOAD_TESTING_CODE,
            f"logger_tests.info('Running {task_name} - NEW')",
            f"docker_dmws_sync.docker_join_dm('{invit_json}')",
            "shared_data.dm.terminate()",
        ]
    )
    try:
        sleep(2)  # give docker_container_old a chance to load longer
        output_lines = docker_container_new.run_python_code(
            python_code,
            timeout=PROFILE_JOIN_TIMEOUT_S + 5,
            print_output=True,
            background=False,
        ).split("\n")
    except DockerShellError as e:
        print(e)
        output_lines = []
        # breakpoint()
    except DockerShellTimeoutError as e:
        print(f"Docker shell timeout reached after {e.timeout}s")
        output_lines = e.output.split("\n")

    docker_lines = [
        line.replace("DOCKER: ", "").strip()
        for line in output_lines
        if line.startswith("DOCKER: ")
    ]
    last_line = docker_lines[-1] if len(docker_lines) > 0 else None

    assert last_line == "Got control key!", function_name()


def create_super(docker_container: WalytisIdentitiesDocker) -> dict | None:
    print(coloured(f"\n\nRunning {function_name()}", "blue"))
    python_code = "\n".join(
        [
            DOCKER_PYTHON_LOAD_TESTING_CODE,
            "docker_dmws_sync.docker_load_dm()",
            "super=docker_dmws_sync.docker_create_super()",
            "invitation = super.invite_member()",
            "invitation.update({'did':super.did})",
            "print('DOCKER: ',json.dumps(invitation))",
            "print(f'DOCKER: Created super: {type(super)}')",
            "shared_data.dm.terminate()",
        ]
    )
    try:
        output_lines = docker_container.run_python_code(
            python_code,
            print_output=True,
            timeout=PROFILE_CREATE_TIMEOUT_S,
            background=False,
        ).split("\n")
    except DockerShellError as e:
        print(e)
        output_lines = []
        # breakpoint()
    except DockerShellTimeoutError as e:
        print(f"Docker shell timeout reached after {e.timeout}s")
        output_lines = e.output.split("\n")

    docker_lines = [
        line.replace("DOCKER: ", "").strip()
        for line in output_lines
        if line.startswith("DOCKER: ")
    ]

    if len(docker_lines) < 2:
        assert False, function_name()
        return None

    last_line = docker_lines[-1] if len(docker_lines) > 0 else None

    invitation = json.loads(docker_lines[-2].strip().replace("'", '"'))

    assert (
        last_line
        == "Created super: <class 'walytis_identities.group_did_manager.GroupDidManager'>"
    ), function_name()

    return invitation


def join_super(
    docker_container_old: WalytisIdentitiesDocker,
    docker_container_new: WalytisIdentitiesDocker,
    invitation: dict,
    task_name: str,
) -> None:
    print(coloured(f"\n\nRunning {function_name()}", "blue"))
    python_code_1 = "\n".join(
        [
            DOCKER_PYTHON_LOAD_TESTING_CODE,
            f"logger_tests.info('Running {task_name} - OLD')",
            "docker_dmws_sync.docker_load_dm()",
            "logger_tests.info('join_super: Waiting to allow conversation join...')",
            f"sleep({CORRESP_JOIN_TIMEOUT_S})",
            "logger_tests.info('Finished waiting, terminating...')",
            "shared_data.dm.terminate()",
            "logger_tests.info('Exiting after waiting.')",
        ]
    )
    docker_container_old.run_python_code(python_code_1, background=True)
    invit_json = json.dumps(invitation)

    python_code_2 = "\n".join(
        [
            DOCKER_PYTHON_LOAD_TESTING_CODE,
            f"logger_tests.info('Running {task_name} - NEW')",
            "docker_dmws_sync.docker_load_dm()",
            f"super = docker_dmws_sync.docker_join_super('{invit_json}')",
            "print('DOCKER: ', super.did)",
            "shared_data.dm.terminate()",
            "super.terminate()",
        ]
    )

    try:
        output_lines = docker_container_new.run_python_code(
            python_code_2,
            timeout=CORRESP_JOIN_TIMEOUT_S + 5,
            print_output=True,
            background=False,
        ).split("\n")
    except DockerShellError as e:
        print(e)
        output_lines = []
        # breakpoint()
    except DockerShellTimeoutError as e:
        print(f"Docker shell timeout reached after {e.timeout}s")
        output_lines = e.output.split("\n")

    docker_lines = [
        line.replace("DOCKER: ", "").strip()
        for line in output_lines
        if line.startswith("DOCKER: ")
    ]

    second_last_line = docker_lines[-2] if len(docker_lines) > 1 else None
    super_id = docker_lines[-1].strip() if len(docker_lines) > 0 else None
    expected_super_id = invitation["did"]

    assert (
        second_last_line == "Got control key!"
        and super_id == expected_super_id
    ), function_name()


def auto_join_super(
    docker_container_old: WalytisIdentitiesDocker,
    docker_container_new: WalytisIdentitiesDocker,
    superondence_id: str,
    task_name: str,
) -> None:
    print(coloured(f"\n\nRunning {function_name()}", "blue"))
    python_code = "\n".join(
        [
            DOCKER_PYTHON_LOAD_TESTING_CODE,
            f"logger_tests.info('Running {task_name} - OLD')",
            "docker_dmws_sync.docker_load_dm()",
            "logger_tests.info('Waiting to allow auto conversation join...')",
            f"sleep({CORRESP_JOIN_TIMEOUT_S})",
            "logger_tests.info('Finished waiting, terminating...')",
            "shared_data.dm.terminate()",
            "logger_tests.info('Exiting after waiting.')",
        ]
    )

    docker_container_old.run_python_code(
        python_code, print_output=True, background=True
    )
    python_code = "\n".join(
        [
            DOCKER_PYTHON_LOAD_TESTING_CODE,
            f"logger_tests.info('Running {task_name} - NEW')",
            "docker_dmws_sync.docker_load_dm()",
            "logger_tests.info('Waiting to allow auto conversation join...')",
            f"sleep({CORRESP_JOIN_TIMEOUT_S})",
            "print('GroupDidManager DIDs:')",
            "logger_tests.info('Finished waiting, terminating...')",
            "for c in shared_data.dm.get_active_supers():",
            "    print(c)",
            "shared_data.dm.terminate()",
        ]
    )
    try:
        sleep(2)  # give docker_container_old a chance to load longer
        output = docker_container_new.run_python_code(
            python_code,
            timeout=CORRESP_JOIN_TIMEOUT_S + 15,
            print_output=True,
            background=False,
        )
    except DockerShellError as e:
        print(e)
        output = ""
        # breakpoint()
    except DockerShellTimeoutError as e:
        print(f"Docker shell timeout reached after {e.timeout}s")
        output = e.output
    output_lines = output.split("GroupDidManager DIDs:")
    c_ids: list[str] = []
    if len(output_lines) == 2:
        none, c_id_text = output_lines  # noqa
        c_ids = [line.strip() for line in c_id_text.split("\n")]
        c_ids = [c_id for c_id in c_ids if c_id != ""]

    assert superondence_id in c_ids, function_name()


def test_setup_dm_1():
    # create first dm with multiple devices
    setup_dm(shared_data.containers[0])


def test_load_dm_0():
    shared_data.invitation = load_dm(shared_data.containers[0])


def test_add_sub_1():
    if not shared_data.invitation:
        shared_data.abort = True
    if shared_data.abort:
        pytest.skip("Test aborted due to failures.")
    add_sub(
        shared_data.containers[1],
        shared_data.containers[0],
        shared_data.invitation,
        task_name="AddSub-1",
    )


def test_load_dm_1():
    if shared_data.abort:
        pytest.skip("Test aborted due to failures.")
    load_dm(shared_data.containers[1])


def test_setup_dm_2():
    if shared_data.abort:
        pytest.skip("Test aborted due to failures.")
    # create second dm with multiple devices
    setup_dm(shared_data.containers[2])


def test_load_dm2():
    shared_data.invitation2 = load_dm(shared_data.containers[2])


def test_add_sub2():
    if not shared_data.invitation2:
        shared_data.abort = True
    if shared_data.abort:
        pytest.skip("Test aborted due to failures.")
    add_sub(
        shared_data.containers[3],
        shared_data.containers[2],
        shared_data.invitation2,
        task_name="AddSub-2",
    )


def test_load_dm3():
    if shared_data.abort:
        pytest.skip("Test aborted due to failures.")
    load_dm(shared_data.containers[3])


def test_super_3():
    # create superondence & share accross dms
    shared_data.invitation3 = create_super(shared_data.containers[0])


def test_auto_join_super_1():
    if not shared_data.invitation3:
        shared_data.abort = True
    if shared_data.abort:
        pytest.skip("Test aborted due to failures.")
    shared_data.super_id = shared_data.invitation3["did"]

    # test that dm1's second device automatically joins the correspondence
    # after dm1's first device creates it
    auto_join_super(
        shared_data.containers[0],
        shared_data.containers[1],
        shared_data.super_id,
        task_name="AutoJoinSuper-1",
    )


def test_join_super_1():
    if shared_data.abort:
        pytest.skip("Test aborted due to failures.")
    # test that dm2 can join the superondence given an invitation
    join_super(
        shared_data.containers[0],
        shared_data.containers[2],
        shared_data.invitation3,
        task_name="JoinSuper-1",
    )


def test_auto_join_super_2():
    if shared_data.abort:
        pytest.skip("Test aborted due to failures.")
    # test that dm2's second device automatically joins the correspondence
    # after dm2's first device joins it
    auto_join_super(
        shared_data.containers[2],
        shared_data.containers[3],
        shared_data.super_id,
        task_name="AutoJoinSuper-2",
    )
    # create second dm with multiple devices


def test_cleanup(
    test_module_name, test_module_start_time, test_report_dirs
) -> None:
    """Ensure all resources used by tests are cleaned up."""
    # get logs from, then delete containers

    if os.path.exists(dm_config_dir):
        shutil.rmtree(dm_config_dir)
    if shared_data.super:
        shared_data.super.delete()
    if shared_data.dm:
        shared_data.dm.delete()
    collect_all_test_logs(
        test_module_name,
        shared_data.containers,
        test_report_dirs,
        test_module_start_time,
    )
    cleanup_walytis_ipfs()


def test_threads_cleanup() -> None:
    """Test that no threads are left running."""
    assert await_thread_cleanup(timeout=10)
