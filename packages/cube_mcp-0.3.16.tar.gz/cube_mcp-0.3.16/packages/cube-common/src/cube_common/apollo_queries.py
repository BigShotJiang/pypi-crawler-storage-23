"""All Apollo GraphQL query and mutation strings."""

# ---------------------------------------------------------------------------
# Environment queries
# ---------------------------------------------------------------------------

GET_ENVIRONMENT_BY_RID = """
query GetEnv($rid: RID!) {
    apollo {
        environment(rid: $rid) {
            id
            rid
            name
        }
    }
}
"""

LIST_ENVIRONMENTS = """
query ListEnvs {
    apollo {
        environments(pageSize: 200) {
            environments {
                id
                rid
                name
                namespaceId
            }
            nextPageToken
        }
    }
}
"""

CREATE_ENVIRONMENT = """
mutation CreateEnv($request: CreateApolloEnvironmentRequest!) {
    apollo {
        createEnvironment(request: $request) {
            id
            rid
            name
            spaceId
            namespaceId
            accreditation
        }
    }
}
"""

# ---------------------------------------------------------------------------
# Module queries
# ---------------------------------------------------------------------------

INSTALL_MODULE = """
mutation InstallModule($request: InstallApolloProductModuleInputV2!) {
    apollo {
        installModuleV2(request: $request) {
            rid
            displayName
            moduleMavenCoordinate
            state {
                __typename
            }
        }
    }
}
"""

# ---------------------------------------------------------------------------
# Entity queries
# ---------------------------------------------------------------------------

ENTITY_HEALTH_FIELDS = """
    id
    rid
    displayName
    lifecycleStatus
    product { productId }
    entityLocator {
        ... on ApolloEntityLocator_ApolloEntity { entityName }
    }
    reportedStatus {
        version
        rolloutStatus
        configStatus
        healthStatus
        upgradeBlockerTypes
    }
    planStatus {
        __typename
    }
    nonGenericPlans(pageSize: 5) {
        plans {
            rid
            agentId
            status {
                type
                result { summary }
                reason { summary }
            }
            startTime
            endTime
            tasks {
                description { type summary }
                status {
                    type
                    updatedAt
                }
            }
        }
    }
"""

ENVIRONMENT_ENTITIES = f"""
query EnvironmentEntities($id: String!) {{
    apollo {{
        environmentById(id: $id) {{
            name
            entities(pageSize: 100) {{
                entities {{
                    {ENTITY_HEALTH_FIELDS}
                }}
            }}
        }}
    }}
}}
"""

INSTALL_ENTITIES = """
mutation InstallEntities($envId: String!, $entities: InstallApolloEntitiesOnEnvironmentRequest!) {
    apollo {
        installEntitiesOnEnvironment(apolloEnvironmentId: $envId, entities: $entities) {
            rid
            title
            requestStatus
        }
    }
}
"""

UNINSTALL_ENTITY = """
mutation UninstallEntity($rid: RID!) {
    apollo {
        uninstallEntity(rid: $rid) {
            rid
            requestStatus
        }
    }
}
"""

# ---------------------------------------------------------------------------
# Replication queries
# ---------------------------------------------------------------------------

SOURCE_ENVIRONMENT = """
query SourceEnv($id: String!) {
    apollo {
        environmentById(id: $id) {
            name
            accreditation
            moduleInstallationsV2 {
                moduleInstallations {
                    displayName
                    moduleMavenCoordinate
                    variables {
                        variableName
                        variableValue {
                            __typename
                            ... on ApolloProductModuleVariableValue_StringValue { value }
                            ... on ApolloProductModuleVariableValue_OptionValue { value }
                        }
                    }
                }
            }
            entities(pageSize: 200) {
                entities {
                    id
                    entityLocator {
                        ... on ApolloEntityLocator_ApolloEntity { entityName type }
                    }
                    product { productId }
                    declaredState { releaseChannel }
                    installedByModuleV2 { rid }
                    reportedConfigOverrides {
                        ... on ApolloEntityReportedConfigOverrides_Default {
                            overrides
                        }
                    }
                    secrets {
                        name
                        specification {
                            ... on ApolloSecretSpecification_MultiKey {
                                keys { key }
                            }
                        }
                    }
                }
            }
        }
    }
}
"""

TARGET_ENVIRONMENT = """
query TargetEnv($id: String!) {
    apollo {
        environmentById(id: $id) {
            moduleInstallationsV2 {
                moduleInstallations {
                    moduleMavenCoordinate
                }
            }
            entities(pageSize: 200) {
                entities {
                    entityLocator {
                        ... on ApolloEntityLocator_ApolloEntity { entityName }
                    }
                }
            }
        }
    }
}
"""

CLEANUP_CHECK = """
query CleanupCheck($id: String!) {
    apollo {
        environmentById(id: $id) {
            entities(pageSize: 200) {
                entities {
                    rid
                    entityLocator {
                        ... on ApolloEntityLocator_ApolloEntity { entityName }
                    }
                }
            }
        }
    }
}
"""

# ---------------------------------------------------------------------------
# Plan details query
# ---------------------------------------------------------------------------

PLAN_DETAILS = """
query PlanDetails($id: String!) {
    apollo {
        environmentById(id: $id) {
            name
            entities(pageSize: 200) {
                entities {
                    id
                    displayName
                    lifecycleStatus
                    product { productId }
                    entityLocator {
                        ... on ApolloEntityLocator_ApolloEntity { entityName }
                    }
                    reportedStatus { version }
                    nonGenericPlans(pageSize: 10) {
                        plans {
                            rid
                            agentId
                            proposedTime
                            startTime
                            endTime
                            status {
                                type
                                result { type summary metadataMap }
                                reason { type summary metadataMap }
                            }
                            stateChanges {
                                entityType
                                changeType
                            }
                            tasks {
                                rid
                                origin
                                description { type summary }
                                createdAt
                                status {
                                    type
                                    updatedAt
                                    description { type summary metadataMap }
                                }
                                latestEvent {
                                    timestamp
                                    description { summary }
                                }
                                events {
                                    timestamp
                                    description { summary }
                                }
                                subtasks {
                                    origin
                                    description { type summary }
                                    createdAt
                                    status {
                                        type
                                        updatedAt
                                        description { type summary metadataMap }
                                    }
                                    latestEvent {
                                        timestamp
                                        description { summary }
                                    }
                                    events {
                                        timestamp
                                        description { summary }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
"""

# ---------------------------------------------------------------------------
# Environment management mutations
# ---------------------------------------------------------------------------

DELETE_ENVIRONMENT = """
mutation DeleteEnv($rid: RID!) {
    apollo {
        deleteEnvironment(rid: $rid) {
            rid
            requestStatus
        }
    }
}
"""

RESET_ENVIRONMENT_AGENTS = """
mutation ResetAgents($envId: String!) {
    apollo {
        resetEnvironmentAgents(apolloEnvironmentId: $envId) {
            rid
            requestStatus
        }
    }
}
"""

# ---------------------------------------------------------------------------
# Entity management mutations
# ---------------------------------------------------------------------------

UPDATE_ENTITY_CONFIG = """
mutation UpdateEntityConfig($rid: RID!, $config: String!) {
    apollo {
        setEntityConfigOverrides(rid: $rid, configOverrides: $config) {
            rid
            requestStatus
        }
    }
}
"""

ENFORCE_ENTITY_CONFIG = """
mutation EnforceEntityConfig($rid: RID!) {
    apollo {
        enforceEntityConfig(rid: $rid) {
            rid
            requestStatus
        }
    }
}
"""

ENTITY_BY_NAME = """
query EntityByName($id: String!) {
    apollo {
        environmentById(id: $id) {
            entities(pageSize: 200) {
                entities {
                    rid
                    displayName
                    entityLocator {
                        ... on ApolloEntityLocator_ApolloEntity { entityName }
                    }
                    product { productId }
                    reportedConfigOverrides {
                        ... on ApolloEntityReportedConfigOverrides_Default {
                            overrides
                        }
                    }
                }
            }
        }
    }
}
"""

# ---------------------------------------------------------------------------
# Module management queries
# ---------------------------------------------------------------------------

LIST_MODULES = """
query ListModules($id: String!) {
    apollo {
        environmentById(id: $id) {
            name
            moduleInstallationsV2 {
                moduleInstallations {
                    rid
                    displayName
                    moduleMavenCoordinate
                    state {
                        __typename
                    }
                    variables {
                        variableName
                        variableValue {
                            __typename
                            ... on ApolloProductModuleVariableValue_StringValue { value }
                            ... on ApolloProductModuleVariableValue_OptionValue { value }
                        }
                    }
                }
            }
        }
    }
}
"""

UNINSTALL_MODULE = """
mutation UninstallModule($rid: RID!) {
    apollo {
        unlinkModuleV2(rid: $rid) {
            rid
        }
    }
}
"""

UPDATE_MODULE_VARIABLES = """
mutation UpdateModuleVars($rid: RID!, $variables: [ApolloProductModuleVariableInput!]!) {
    apollo {
        updateModuleVariablesV2(rid: $rid, variables: $variables) {
            rid
            displayName
            state {
                __typename
            }
        }
    }
}
"""

# ---------------------------------------------------------------------------
# Secret management mutations
# ---------------------------------------------------------------------------

CREATE_SECRET = """
mutation CreateSecret($request: CreateApolloSecretRequest!) {
    apollo {
        createSecret(request: $request) {
            rid
            name
        }
    }
}
"""

UPDATE_SECRET = """
mutation UpdateSecret($rid: RID!, $request: UpdateApolloSecretRequest!) {
    apollo {
        updateSecret(rid: $rid, request: $request) {
            rid
            name
        }
    }
}
"""

ENTITY_SECRETS = """
query EntitySecrets($id: String!) {
    apollo {
        environmentById(id: $id) {
            entities(pageSize: 200) {
                entities {
                    rid
                    displayName
                    entityLocator {
                        ... on ApolloEntityLocator_ApolloEntity { entityName }
                    }
                    secrets {
                        rid
                        name
                        specification {
                            ... on ApolloSecretSpecification_MultiKey {
                                keys { key }
                            }
                        }
                    }
                }
            }
        }
    }
}
"""

# ---------------------------------------------------------------------------
# Product creation
# ---------------------------------------------------------------------------

CREATE_PRODUCT = """
mutation CreateProduct($productId: String!) {
    apollo {
        createProduct(productId: $productId) {
            productId
        }
    }
}
"""

CREATE_PRODUCT_RELEASE_FROM_MANIFEST = """
mutation CreateProductRelease($productReleaseManifest: String!) {
    apollo {
        createProductReleaseFromManifestV2(productReleaseManifest: $productReleaseManifest) {
            rid
            version
        }
    }
}
"""

# ---------------------------------------------------------------------------
# Product queries
# ---------------------------------------------------------------------------

LIST_PRODUCTS = """
query ListProducts($pageSize: Int!) {
    apollo {
        products(pageSize: $pageSize) {
            products {
                productId
                labels {
                    labelId
                    labelValue
                }
            }
            nextPageToken
        }
    }
}
"""

GET_PRODUCT_RELEASES = """
query ProductReleases($productId: String!, $pageSize: Int!) {
    apollo {
        productReleases(productId: $productId, pageSize: $pageSize) {
            releases {
                rid
                version
                releaseChannels {
                    releaseChannelName
                }
            }
            nextPageToken
        }
    }
}
"""

# ---------------------------------------------------------------------------
# Release channel queries
# ---------------------------------------------------------------------------

LIST_RELEASE_CHANNELS = """
query ListReleaseChannels {
    apollo {
        releaseChannels(pageSize: 200) {
            releaseChannels {
                rid
                name
                description
                type
            }
            nextPageToken
        }
    }
}
"""

ADD_TO_RELEASE_CHANNEL = """
mutation AddToChannel($releaseRid: RID!, $channelName: String!, $rationale: String) {
    apollo {
        addProductReleaseToReleaseChannel(
            productReleaseRid: $releaseRid,
            releaseChannelName: $channelName,
            rationale: $rationale
        ) {
            rid
            version
            releaseChannels {
                releaseChannelName
            }
        }
    }
}
"""

REMOVE_FROM_RELEASE_CHANNEL = """
mutation RemoveFromChannel($releaseRid: RID!, $channelName: String!, $rationale: String) {
    apollo {
        removeProductReleaseFromReleaseChannel(
            productReleaseRid: $releaseRid,
            releaseChannelName: $channelName,
            rationale: $rationale
        ) {
            rid
            version
            releaseChannels {
                releaseChannelName
            }
        }
    }
}
"""

# ---------------------------------------------------------------------------
# Product label mutations
# ---------------------------------------------------------------------------

SET_LABEL = """
mutation SetLabel($productId: String!, $labelId: String!, $labelValue: String!) {
    apollo {
        setLabelOnProduct(productId: $productId, labelId: $labelId, labelValue: $labelValue) {
            productId
            labels {
                labelId
                labelValue
            }
        }
    }
}
"""

REMOVE_LABEL = """
mutation RemoveLabel($productId: String!, $labelId: String!) {
    apollo {
        removeLabelFromProduct(productId: $productId, labelId: $labelId) {
            productId
            labels {
                labelId
                labelValue
            }
        }
    }
}
"""

# ---------------------------------------------------------------------------
# Change request queries
# ---------------------------------------------------------------------------

LIST_CHANGE_REQUESTS = """
query ListCRs($pageSize: Int!) {
    apollo {
        changeRequests(pageSize: $pageSize) {
            changeRequests {
                rid
                title
                requestStatus
                createdAt
                environment {
                    name
                }
            }
            nextPageToken
        }
    }
}
"""

LIST_CHANGE_REQUESTS_BY_ENV = """
query ListCRsByEnv($envId: String!, $pageSize: Int!) {
    apollo {
        environmentById(id: $envId) {
            changeRequests(pageSize: $pageSize) {
                changeRequests {
                    rid
                    title
                    requestStatus
                    createdAt
                }
                nextPageToken
            }
        }
    }
}
"""

APPROVE_CHANGE_REQUEST = """
mutation ApproveCR($rid: RID!, $comment: String) {
    apollo {
        approveChangeRequest(rid: $rid, comment: $comment) {
            rid
            requestStatus
        }
    }
}
"""

REJECT_CHANGE_REQUEST = """
mutation RejectCR($rid: RID!, $comment: String!) {
    apollo {
        rejectChangeRequest(rid: $rid, comment: $comment) {
            rid
            requestStatus
        }
    }
}
"""

CANCEL_CHANGE_REQUEST = """
mutation CancelCR($rid: RID!) {
    apollo {
        cancelChangeRequest(rid: $rid) {
            rid
            requestStatus
        }
    }
}
"""
