"""ACR token and Apollo publish tools."""

from __future__ import annotations

import logging

import yaml

from cube_common.apollo_client import ApolloClient
from cube_common.apollo_queries import (
    CREATE_PRODUCT,
    CREATE_PRODUCT_RELEASE_FROM_MANIFEST,
    LIST_PRODUCTS,
)

logger = logging.getLogger(__name__)


async def acr_get_token(client: ApolloClient) -> str:
    """Get a raw ACR OAuth2 token. Returns the full token for agent use."""
    token = await client.get_token()
    return token


async def apollo_publish_manifest(client: ApolloClient, manifest_yaml: str) -> str:
    """Publish a manifest to Apollo via GraphQL.

    1. Parse the product_id (group:name) from the manifest's maven-coordinate.
    2. If the product doesn't exist yet, create it.
    3. Publish the release using the manifest YAML.
    """
    # --- extract product_id from manifest ---
    manifest = yaml.safe_load(manifest_yaml)
    maven_coordinate: str = manifest["product-id"]["maven-coordinate"]
    # maven-coordinate is "group:name:version" — product_id is "group:name"
    parts = maven_coordinate.split(":")
    product_id = f"{parts[0]}:{parts[1]}"

    # --- ensure product exists ---
    data = await client.graphql(LIST_PRODUCTS, {"pageSize": 500})
    products = data["apollo"]["products"]["products"]
    exists = any(p["productId"] == product_id for p in products)

    created = False
    if not exists:
        await client.graphql(CREATE_PRODUCT, {"productId": product_id})
        created = True
        logger.info("Created new Apollo product: %s", product_id)

    # --- publish release ---
    data = await client.graphql(
        CREATE_PRODUCT_RELEASE_FROM_MANIFEST,
        {"productReleaseManifest": manifest_yaml},
    )
    release = data["apollo"]["createProductReleaseFromManifestV2"]
    version = release["version"]

    if created:
        return f"Created product '{product_id}' and published release {version}."
    return f"Published release {version} for product '{product_id}'."
