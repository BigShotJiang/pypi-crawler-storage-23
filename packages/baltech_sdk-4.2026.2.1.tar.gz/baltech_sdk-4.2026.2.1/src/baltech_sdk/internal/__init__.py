"""Internal interfaces - includes all public + internal APIs."""
from brp_lib import BrpStack, UsbHid, SecureChannel, RS232, set_brp_lib_path, get_brp_lib_path

from .. import _internal
from .._internal import *
from .._internal import InternalCommands as Commands, InternalConfigAccessor as ConfigAccessor
from .._config import BaseConfig, ConfDict

__all__ = [
    "Brp",
    "Config",
    "ConfDict",
    # brp_lib
    "UsbHid",
    "RS232",
    "SecureChannel",
    "get_brp_lib_path",
    "set_brp_lib_path",
    # re-exports
    "Commands",
    "ConfigAccessor",
    *_internal.__all__,

]


class Brp(BrpStack, Commands):
    """Brp with ALL commands (public + internal)."""
    pass


class Config(BaseConfig, ConfigAccessor):
    """Config with ALL config values (public + internal)."""
    pass
