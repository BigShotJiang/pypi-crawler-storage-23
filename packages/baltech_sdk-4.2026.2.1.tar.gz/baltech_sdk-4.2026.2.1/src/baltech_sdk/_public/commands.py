
from io import BytesIO
from typing import Optional, Union, List, Dict, NamedTuple, Tuple, Any, Literal

from typing_extensions import Self

from ..generator_interface import safe_read_int_from_buffer, Command, FrameProcessor, PayloadTooLongError, PayloadTooShortError, PayloadFormatError
from .typedefs import *
from .protocols import BaltechScript
from .protocols import BRP
from .protocols import Template
class AR_SetMode(Command):
    CommandGroupId = 0x05
    CommandId = 0x00
    def build_frame(self, Mode: AutoReadMode, BrpTimeout: int = 1000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x05\x00")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(AutoReadMode_Parser.as_value(Mode).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Mode: AutoReadMode, BrpTimeout: int = 1000) -> None:
        request_frame = self.build_frame(Mode=Mode, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class AR_GetMessage(Command):
    CommandGroupId = 0x05
    CommandId = 0x01
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x05\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> AR_GetMessage_Result:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _MsgType = MessageType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _MsgData_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _MsgData = _recv_buffer.read(_MsgData_len)
        if len(_MsgData) != _MsgData_len:
            raise PayloadTooShortError(_MsgData_len - len(_MsgData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return AR_GetMessage_Result(_MsgType, _MsgData)
class AR_RunScript(Command):
    CommandGroupId = 0x05
    CommandId = 0x03
    def build_frame(self, Script: Union[BaltechScript, bytes], BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x05\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(int(len(bytes(Script))).to_bytes(1, byteorder='big'))
        _send_buffer.write(bytes(Script))
        return _send_buffer.getvalue()
    def __call__(self, Script: Union[BaltechScript, bytes], BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Script=Script, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class AR_RestrictScanCardFamilies(Command):
    CommandGroupId = 0x05
    CommandId = 0x04
    def build_frame(self, CardFamiliesFilter: Union[CardFamilies, CardFamilies_Dict], BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x05\x04")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if isinstance(CardFamiliesFilter, dict):
            CardFamiliesFilter = CardFamilies(**CardFamiliesFilter)
        CardFamiliesFilter_int = 0
        CardFamiliesFilter_int |= (int(CardFamiliesFilter.LEGICPrime) & 0b1) << 11
        CardFamiliesFilter_int |= (int(CardFamiliesFilter.BluetoothMce) & 0b1) << 10
        CardFamiliesFilter_int |= (int(CardFamiliesFilter.Khz125Part2) & 0b1) << 9
        CardFamiliesFilter_int |= (int(CardFamiliesFilter.Srix) & 0b1) << 8
        CardFamiliesFilter_int |= (int(CardFamiliesFilter.Khz125Part1) & 0b1) << 7
        CardFamiliesFilter_int |= (int(CardFamiliesFilter.Felica) & 0b1) << 6
        CardFamiliesFilter_int |= (int(CardFamiliesFilter.IClass) & 0b1) << 5
        CardFamiliesFilter_int |= (int(CardFamiliesFilter.IClassIso14B) & 0b1) << 4
        CardFamiliesFilter_int |= (int(CardFamiliesFilter.Iso14443B) & 0b1) << 3
        CardFamiliesFilter_int |= (int(CardFamiliesFilter.Iso15693) & 0b1) << 2
        CardFamiliesFilter_int |= (int(CardFamiliesFilter.Iso14443A) & 0b1) << 0
        _send_buffer.write(CardFamiliesFilter_int.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, CardFamiliesFilter: Union[CardFamilies, CardFamilies_Dict], BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(CardFamiliesFilter=CardFamiliesFilter, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class BlePeriph_DefineService(Command):
    CommandGroupId = 0x4B
    CommandId = 0x01
    def build_frame(self, ServiceUUID: bytes, Characteristics: List[BlePeriph_DefineService_Characteristics_Entry], BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x4B\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(b'\x00')
        _send_buffer.write(int(len(ServiceUUID)).to_bytes(1, byteorder='big'))
        _send_buffer.write(ServiceUUID)
        _send_buffer.write(int(len(Characteristics)).to_bytes(1, byteorder='big'))
        for _Characteristics_Entry in Characteristics:
            _CharacteristicUUID, _SupportsIndicate, _SupportsNotify, _SupportsWrite, _SupportsWriteNoResponse, _SupportsRead, _VariableSize, _Size = _Characteristics_Entry
            _send_buffer.write(int(len(_CharacteristicUUID)).to_bytes(1, byteorder='big'))
            _send_buffer.write(_CharacteristicUUID)
            _var_0000_int = 0
            _var_0000_int |= (int(_SupportsIndicate) & 0b1) << 5
            _var_0000_int |= (int(_SupportsNotify) & 0b1) << 4
            _var_0000_int |= (int(_SupportsWrite) & 0b1) << 3
            _var_0000_int |= (int(_SupportsWriteNoResponse) & 0b1) << 2
            _var_0000_int |= (int(_SupportsRead) & 0b1) << 1
            _send_buffer.write(_var_0000_int.to_bytes(length=2, byteorder='big'))
            _var_0001_int = 0
            _var_0001_int |= (int(_VariableSize) & 0b1) << 0
            _send_buffer.write(_var_0001_int.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_Size.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, ServiceUUID: bytes, Characteristics: List[BlePeriph_DefineService_Characteristics_Entry], BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(ServiceUUID=ServiceUUID, Characteristics=Characteristics, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class BlePeriph_Enable(Command):
    CommandGroupId = 0x4B
    CommandId = 0x02
    def build_frame(self, Activate: bool, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x4B\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Activate.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Activate: bool, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Activate=Activate, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class BlePeriph_SetAdvertisingData(Command):
    CommandGroupId = 0x4B
    CommandId = 0x03
    def build_frame(self, AdvertisingData: bytes, ScanResponseData: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x4B\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(int(len(AdvertisingData)).to_bytes(1, byteorder='big'))
        _send_buffer.write(AdvertisingData)
        _send_buffer.write(int(len(ScanResponseData)).to_bytes(1, byteorder='big'))
        _send_buffer.write(ScanResponseData)
        return _send_buffer.getvalue()
    def __call__(self, AdvertisingData: bytes, ScanResponseData: bytes, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(AdvertisingData=AdvertisingData, ScanResponseData=ScanResponseData, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class BlePeriph_WriteCharacteristic(Command):
    CommandGroupId = 0x4B
    CommandId = 0x04
    def build_frame(self, CharacteristicNdx: int, WriteValue: bytes, BrpTimeout: int = 1000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x4B\x04")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(CharacteristicNdx.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(WriteValue)).to_bytes(2, byteorder='big'))
        _send_buffer.write(WriteValue)
        return _send_buffer.getvalue()
    def __call__(self, CharacteristicNdx: int, WriteValue: bytes, BrpTimeout: int = 1000) -> None:
        request_frame = self.build_frame(CharacteristicNdx=CharacteristicNdx, WriteValue=WriteValue, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class BlePeriph_ReadCharacteristic(Command):
    CommandGroupId = 0x4B
    CommandId = 0x05
    def build_frame(self, CharacteristicNdx: int, ReadLength: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x4B\x05")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(CharacteristicNdx.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(ReadLength.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, CharacteristicNdx: int, ReadLength: int, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(CharacteristicNdx=CharacteristicNdx, ReadLength=ReadLength, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ReadValue_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _ReadValue = _recv_buffer.read(_ReadValue_len)
        if len(_ReadValue) != _ReadValue_len:
            raise PayloadTooShortError(_ReadValue_len - len(_ReadValue))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ReadValue
class BlePeriph_GetEvents(Command):
    CommandGroupId = 0x4B
    CommandId = 0x06
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x4B\x06")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> BlePeriph_GetEvents_Result:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _EventMask_int = safe_read_int_from_buffer(_recv_buffer, 4)
        _ConnectionStatusChanged = bool((_EventMask_int >> 31) & 0b1)
        _ValueChangedCharacteristicNdx4 = bool((_EventMask_int >> 4) & 0b1)
        _ValueChangedCharacteristicNdx3 = bool((_EventMask_int >> 3) & 0b1)
        _ValueChangedCharacteristicNdx2 = bool((_EventMask_int >> 2) & 0b1)
        _ValueChangedCharacteristicNdx1 = bool((_EventMask_int >> 1) & 0b1)
        _ValueChangedCharacteristicNdx0 = bool((_EventMask_int >> 0) & 0b1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return BlePeriph_GetEvents_Result(_ConnectionStatusChanged, _ValueChangedCharacteristicNdx4, _ValueChangedCharacteristicNdx3, _ValueChangedCharacteristicNdx2, _ValueChangedCharacteristicNdx1, _ValueChangedCharacteristicNdx0)
class BlePeriph_IsConnected(Command):
    CommandGroupId = 0x4B
    CommandId = 0x07
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x4B\x07")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> BlePeriph_IsConnected_Result:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Address = _recv_buffer.read(6)
        if len(_Address) != 6:
            raise PayloadTooShortError(6 - len(_Address))
        _AddressType = BlePeriph_IsConnected_AddressType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return BlePeriph_IsConnected_Result(_Address, _AddressType)
class BlePeriph_GetRSSI(Command):
    CommandGroupId = 0x4B
    CommandId = 0x08
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x4B\x08")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _AbsRSSI = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _AbsRSSI
class BlePeriph_CloseConnection(Command):
    CommandGroupId = 0x4B
    CommandId = 0x09
    def build_frame(self, BrpTimeout: int = 1000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x4B\x09")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 1000) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Crypto_EncryptBlock(Command):
    CommandGroupId = 0x02
    CommandId = 0x00
    def build_frame(self, KeyIndex: Optional[int] = None, KeyValue: Optional[bytes] = None, *, Block: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x02\x00")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if KeyIndex is None and (KeyValue is not None):
            KeyIndex = 0
        if KeyIndex is None:
            KeyIndex = 0
        _send_buffer.write(KeyIndex.to_bytes(length=1, byteorder='big'))
        if KeyIndex == 0:
            if KeyValue is None:
                raise TypeError("missing a required argument: 'KeyValue'")
            if len(KeyValue) != 10:
                raise ValueError(KeyValue)
            _send_buffer.write(KeyValue)
        if len(Block) != 8:
            raise ValueError(Block)
        _send_buffer.write(Block)
        return _send_buffer.getvalue()
    def __call__(self, KeyIndex: Optional[int] = None, KeyValue: Optional[bytes] = None, *, Block: bytes, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(KeyIndex=KeyIndex, KeyValue=KeyValue, Block=Block, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _EncryptedBlock = _recv_buffer.read(8)
        if len(_EncryptedBlock) != 8:
            raise PayloadTooShortError(8 - len(_EncryptedBlock))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _EncryptedBlock
class Crypto_DecryptBlock(Command):
    CommandGroupId = 0x02
    CommandId = 0x01
    def build_frame(self, KeyIndex: Optional[int] = None, KeyValue: Optional[bytes] = None, *, Block: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x02\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if KeyIndex is None and (KeyValue is not None):
            KeyIndex = 0
        if KeyIndex is None:
            KeyIndex = 0
        _send_buffer.write(KeyIndex.to_bytes(length=1, byteorder='big'))
        if KeyIndex == 0:
            if KeyValue is None:
                raise TypeError("missing a required argument: 'KeyValue'")
            if len(KeyValue) != 10:
                raise ValueError(KeyValue)
            _send_buffer.write(KeyValue)
        if len(Block) != 8:
            raise ValueError(Block)
        _send_buffer.write(Block)
        return _send_buffer.getvalue()
    def __call__(self, KeyIndex: Optional[int] = None, KeyValue: Optional[bytes] = None, *, Block: bytes, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(KeyIndex=KeyIndex, KeyValue=KeyValue, Block=Block, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _UnencryptedBlock = _recv_buffer.read(8)
        if len(_UnencryptedBlock) != 8:
            raise PayloadTooShortError(8 - len(_UnencryptedBlock))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _UnencryptedBlock
class Crypto_EncryptBuffer(Command):
    CommandGroupId = 0x02
    CommandId = 0x02
    def build_frame(self, KeyIndex: Optional[int] = None, KeyValue: Optional[bytes] = None, *, InitialVector: bytes, Buffer: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x02\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if KeyIndex is None and (KeyValue is not None):
            KeyIndex = 0
        if KeyIndex is None:
            KeyIndex = 0
        _send_buffer.write(KeyIndex.to_bytes(length=1, byteorder='big'))
        if KeyIndex == 0:
            if KeyValue is None:
                raise TypeError("missing a required argument: 'KeyValue'")
            if len(KeyValue) != 10:
                raise ValueError(KeyValue)
            _send_buffer.write(KeyValue)
        if len(InitialVector) != 8:
            raise ValueError(InitialVector)
        _send_buffer.write(InitialVector)
        _send_buffer.write(int(len(Buffer)).to_bytes(1, byteorder='big'))
        _send_buffer.write(Buffer)
        return _send_buffer.getvalue()
    def __call__(self, KeyIndex: Optional[int] = None, KeyValue: Optional[bytes] = None, *, InitialVector: bytes, Buffer: bytes, BrpTimeout: int = 100) -> Crypto_EncryptBuffer_Result:
        request_frame = self.build_frame(KeyIndex=KeyIndex, KeyValue=KeyValue, InitialVector=InitialVector, Buffer=Buffer, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _NextInitialVector = _recv_buffer.read(8)
        if len(_NextInitialVector) != 8:
            raise PayloadTooShortError(8 - len(_NextInitialVector))
        _EncryptedBuffer_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _EncryptedBuffer = _recv_buffer.read(_EncryptedBuffer_len)
        if len(_EncryptedBuffer) != _EncryptedBuffer_len:
            raise PayloadTooShortError(_EncryptedBuffer_len - len(_EncryptedBuffer))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Crypto_EncryptBuffer_Result(_NextInitialVector, _EncryptedBuffer)
class Crypto_DecryptBuffer(Command):
    CommandGroupId = 0x02
    CommandId = 0x03
    def build_frame(self, KeyIndex: Optional[int] = None, KeyValue: Optional[bytes] = None, *, InitialVector: bytes, Buffer: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x02\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if KeyIndex is None and (KeyValue is not None):
            KeyIndex = 0
        if KeyIndex is None:
            KeyIndex = 0
        _send_buffer.write(KeyIndex.to_bytes(length=1, byteorder='big'))
        if KeyIndex == 0:
            if KeyValue is None:
                raise TypeError("missing a required argument: 'KeyValue'")
            if len(KeyValue) != 10:
                raise ValueError(KeyValue)
            _send_buffer.write(KeyValue)
        if len(InitialVector) != 8:
            raise ValueError(InitialVector)
        _send_buffer.write(InitialVector)
        _send_buffer.write(int(len(Buffer)).to_bytes(1, byteorder='big'))
        _send_buffer.write(Buffer)
        return _send_buffer.getvalue()
    def __call__(self, KeyIndex: Optional[int] = None, KeyValue: Optional[bytes] = None, *, InitialVector: bytes, Buffer: bytes, BrpTimeout: int = 100) -> Crypto_DecryptBuffer_Result:
        request_frame = self.build_frame(KeyIndex=KeyIndex, KeyValue=KeyValue, InitialVector=InitialVector, Buffer=Buffer, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _NextInitialVector = _recv_buffer.read(8)
        if len(_NextInitialVector) != 8:
            raise PayloadTooShortError(8 - len(_NextInitialVector))
        _UnencryptedBuffer_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _UnencryptedBuffer = _recv_buffer.read(_UnencryptedBuffer_len)
        if len(_UnencryptedBuffer) != _UnencryptedBuffer_len:
            raise PayloadTooShortError(_UnencryptedBuffer_len - len(_UnencryptedBuffer))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Crypto_DecryptBuffer_Result(_NextInitialVector, _UnencryptedBuffer)
class Crypto_BalKeyEncryptBuffer(Command):
    CommandGroupId = 0x02
    CommandId = 0x04
    def build_frame(self, KeyVersion: int = 2, EmbeddedKeyIndex: int = 0, EmbeddedKeyPos: int = 255, *, Buffer: bytes, InitialVector: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x02\x04")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(KeyVersion.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(EmbeddedKeyIndex.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(EmbeddedKeyPos.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(Buffer)).to_bytes(1, byteorder='big'))
        _send_buffer.write(Buffer)
        _send_buffer.write(int(len(InitialVector)).to_bytes(1, byteorder='big'))
        _send_buffer.write(InitialVector)
        return _send_buffer.getvalue()
    def __call__(self, KeyVersion: int = 2, EmbeddedKeyIndex: int = 0, EmbeddedKeyPos: int = 255, *, Buffer: bytes, InitialVector: bytes, BrpTimeout: int = 100) -> Crypto_BalKeyEncryptBuffer_Result:
        request_frame = self.build_frame(KeyVersion=KeyVersion, EmbeddedKeyIndex=EmbeddedKeyIndex, EmbeddedKeyPos=EmbeddedKeyPos, Buffer=Buffer, InitialVector=InitialVector, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _EncryptedBuffer_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _EncryptedBuffer = _recv_buffer.read(_EncryptedBuffer_len)
        if len(_EncryptedBuffer) != _EncryptedBuffer_len:
            raise PayloadTooShortError(_EncryptedBuffer_len - len(_EncryptedBuffer))
        _NextInitialVector_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _NextInitialVector = _recv_buffer.read(_NextInitialVector_len)
        if len(_NextInitialVector) != _NextInitialVector_len:
            raise PayloadTooShortError(_NextInitialVector_len - len(_NextInitialVector))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Crypto_BalKeyEncryptBuffer_Result(_EncryptedBuffer, _NextInitialVector)
class Crypto_GetKeySig(Command):
    CommandGroupId = 0x02
    CommandId = 0x10
    def build_frame(self, KeyIndex: Optional[int] = None, KeyValue: Optional[bytes] = None, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x02\x10")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if KeyIndex is None and (KeyValue is not None):
            KeyIndex = 0
        if KeyIndex is None:
            KeyIndex = 0
        _send_buffer.write(KeyIndex.to_bytes(length=1, byteorder='big'))
        if KeyIndex == 0:
            if KeyValue is None:
                raise TypeError("missing a required argument: 'KeyValue'")
            if len(KeyValue) != 10:
                raise ValueError(KeyValue)
            _send_buffer.write(KeyValue)
        return _send_buffer.getvalue()
    def __call__(self, KeyIndex: Optional[int] = None, KeyValue: Optional[bytes] = None, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(KeyIndex=KeyIndex, KeyValue=KeyValue, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _KeySignature = safe_read_int_from_buffer(_recv_buffer, 4)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _KeySignature
class Crypto_CopyConfigKey(Command):
    CommandGroupId = 0x02
    CommandId = 0x11
    def build_frame(self, KeyIndex: int, ForceDefaultKey: bool = False, BrpTimeout: int = 2000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x02\x11")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(KeyIndex.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(ForceDefaultKey.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, KeyIndex: int, ForceDefaultKey: bool = False, BrpTimeout: int = 2000) -> None:
        request_frame = self.build_frame(KeyIndex=KeyIndex, ForceDefaultKey=ForceDefaultKey, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Desfire_ExecCommand(Command):
    CommandGroupId = 0x1B
    CommandId = 0x00
    def build_frame(self, Cmd: int, Header: bytes, Param: bytes, CryptoMode: Desfire_ExecCommand_CryptoMode = "Plain", ResponseLen: int = 65535, BrpTimeout: int = 2000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1B\x00")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Cmd.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(Header)).to_bytes(1, byteorder='big'))
        _send_buffer.write(Header)
        _send_buffer.write(int(len(Param)).to_bytes(2, byteorder='big'))
        _send_buffer.write(Param)
        _send_buffer.write(Desfire_ExecCommand_CryptoMode_Parser.as_value(CryptoMode).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(ResponseLen.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Cmd: int, Header: bytes, Param: bytes, CryptoMode: Desfire_ExecCommand_CryptoMode = "Plain", ResponseLen: int = 65535, BrpTimeout: int = 2000) -> bytes:
        request_frame = self.build_frame(Cmd=Cmd, Header=Header, Param=Param, CryptoMode=CryptoMode, ResponseLen=ResponseLen, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Resp_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _Resp = _recv_buffer.read(_Resp_len)
        if len(_Resp) != _Resp_len:
            raise PayloadTooShortError(_Resp_len - len(_Resp))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Resp
class Desfire_Authenticate(Command):
    CommandGroupId = 0x1B
    CommandId = 0x01
    def build_frame(self, SecureMessaging: Desfire_Authenticate_SecureMessaging = "EV1", DesKeynr: int = 0, KeyId: int = 128, KeyHasDivData: Optional[bool] = None, KeyDivMode: Desfire_Authenticate_KeyDivMode = "NoDiv", KeyHasExtIdx: Optional[bool] = None, KeyDivData: Optional[bytes] = None, KeyExtIdx: Optional[int] = None, BrpTimeout: int = 2000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1B\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if KeyHasExtIdx is None and (KeyExtIdx is not None):
            KeyHasExtIdx = True
        if KeyHasDivData is None and (KeyDivData is not None):
            KeyHasDivData = True
        if KeyHasDivData is None:
            KeyHasDivData = False
        if KeyHasExtIdx is None:
            KeyHasExtIdx = False
        _send_buffer.write(Desfire_Authenticate_SecureMessaging_Parser.as_value(SecureMessaging).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(DesKeynr.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(KeyId.to_bytes(length=1, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (int(KeyHasDivData) & 0b1) << 4
        _var_0000_int |= (Desfire_Authenticate_KeyDivMode_Parser.as_value(KeyDivMode) & 0b111) << 1
        _var_0000_int |= (int(KeyHasExtIdx) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        if KeyHasDivData:
            if KeyDivData is None:
                raise TypeError("missing a required argument: 'KeyDivData'")
            _send_buffer.write(int(len(KeyDivData)).to_bytes(1, byteorder='big'))
            _send_buffer.write(KeyDivData)
        if KeyHasExtIdx:
            if KeyExtIdx is None:
                raise TypeError("missing a required argument: 'KeyExtIdx'")
            _send_buffer.write(KeyExtIdx.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, SecureMessaging: Desfire_Authenticate_SecureMessaging = "EV1", DesKeynr: int = 0, KeyId: int = 128, KeyHasDivData: Optional[bool] = None, KeyDivMode: Desfire_Authenticate_KeyDivMode = "NoDiv", KeyHasExtIdx: Optional[bool] = None, KeyDivData: Optional[bytes] = None, KeyExtIdx: Optional[int] = None, BrpTimeout: int = 2000) -> None:
        request_frame = self.build_frame(SecureMessaging=SecureMessaging, DesKeynr=DesKeynr, KeyId=KeyId, KeyHasDivData=KeyHasDivData, KeyDivMode=KeyDivMode, KeyHasExtIdx=KeyHasExtIdx, KeyDivData=KeyDivData, KeyExtIdx=KeyExtIdx, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Desfire_AuthExtKey(Command):
    CommandGroupId = 0x1B
    CommandId = 0x02
    def build_frame(self, SecureMessaging: Desfire_AuthExtKey_SecureMessaging = "EV1", DesKeyNr: int = 0, CryptoMode: Desfire_AuthExtKey_CryptoMode = "AES", *, Key: bytes, BrpTimeout: int = 2000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1B\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Desfire_AuthExtKey_SecureMessaging_Parser.as_value(SecureMessaging).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(DesKeyNr.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Desfire_AuthExtKey_CryptoMode_Parser.as_value(CryptoMode).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(Key)).to_bytes(1, byteorder='big'))
        _send_buffer.write(Key)
        return _send_buffer.getvalue()
    def __call__(self, SecureMessaging: Desfire_AuthExtKey_SecureMessaging = "EV1", DesKeyNr: int = 0, CryptoMode: Desfire_AuthExtKey_CryptoMode = "AES", *, Key: bytes, BrpTimeout: int = 2000) -> None:
        request_frame = self.build_frame(SecureMessaging=SecureMessaging, DesKeyNr=DesKeyNr, CryptoMode=CryptoMode, Key=Key, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Desfire_SelectApplication(Command):
    CommandGroupId = 0x1B
    CommandId = 0x03
    def build_frame(self, AppId: int = 0, BrpTimeout: int = 2000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1B\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(AppId.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, AppId: int = 0, BrpTimeout: int = 2000) -> None:
        request_frame = self.build_frame(AppId=AppId, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Desfire_ReadData(Command):
    CommandGroupId = 0x1B
    CommandId = 0x04
    def build_frame(self, FileId: int, Adr: int = 0, Len: int = 0, Mode: Desfire_ReadData_Mode = "Plain", BrpTimeout: int = 3000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1B\x04")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(FileId.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Adr.to_bytes(length=4, byteorder='big'))
        _send_buffer.write(Len.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(Desfire_ReadData_Mode_Parser.as_value(Mode).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, FileId: int, Adr: int = 0, Len: int = 0, Mode: Desfire_ReadData_Mode = "Plain", BrpTimeout: int = 3000) -> bytes:
        request_frame = self.build_frame(FileId=FileId, Adr=Adr, Len=Len, Mode=Mode, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Data_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _Data = _recv_buffer.read(_Data_len)
        if len(_Data) != _Data_len:
            raise PayloadTooShortError(_Data_len - len(_Data))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Data
class Desfire_WriteData(Command):
    CommandGroupId = 0x1B
    CommandId = 0x05
    def build_frame(self, FileId: int, Adr: int = 0, *, Data: bytes, Mode: Desfire_WriteData_Mode = "Plain", BrpTimeout: int = 3000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1B\x05")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(FileId.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Adr.to_bytes(length=4, byteorder='big'))
        _send_buffer.write(int(len(Data)).to_bytes(2, byteorder='big'))
        _send_buffer.write(Data)
        _send_buffer.write(Desfire_WriteData_Mode_Parser.as_value(Mode).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, FileId: int, Adr: int = 0, *, Data: bytes, Mode: Desfire_WriteData_Mode = "Plain", BrpTimeout: int = 3000) -> None:
        request_frame = self.build_frame(FileId=FileId, Adr=Adr, Data=Data, Mode=Mode, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Desfire_ChangeExtKey(Command):
    CommandGroupId = 0x1B
    CommandId = 0x06
    def build_frame(self, MasterKeyType: Desfire_ChangeExtKey_MasterKeyType = "DESorTripleDES", IsKeySet: Optional[bool] = None, IsAesKey: bool = False, IsVersion: Optional[bool] = None, IsChangeKey: bool = True, *, KeyNo: int, KeyVersion: Optional[int] = None, NewKey: bytes, OldKey: bytes, KeySet: Optional[int] = None, BrpTimeout: int = 2000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1B\x06")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if IsVersion is None and (KeyVersion is not None):
            IsVersion = True
        if IsKeySet is None and (KeySet is not None):
            IsKeySet = True
        if IsKeySet is None:
            IsKeySet = False
        if IsVersion is None:
            IsVersion = False
        if KeyVersion is None:
            KeyVersion = 0
        _var_0000_int = 0
        _var_0000_int |= (Desfire_ChangeExtKey_MasterKeyType_Parser.as_value(MasterKeyType) & 0b11) << 6
        _var_0000_int |= (int(IsKeySet) & 0b1) << 3
        _var_0000_int |= (int(IsAesKey) & 0b1) << 2
        _var_0000_int |= (int(IsVersion) & 0b1) << 1
        _var_0000_int |= (int(IsChangeKey) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(KeyNo.to_bytes(length=1, byteorder='big'))
        if IsVersion:
            if KeyVersion is None:
                raise TypeError("missing a required argument: 'KeyVersion'")
            _send_buffer.write(KeyVersion.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(NewKey)).to_bytes(1, byteorder='big'))
        _send_buffer.write(NewKey)
        _send_buffer.write(int(len(OldKey)).to_bytes(1, byteorder='big'))
        _send_buffer.write(OldKey)
        if IsKeySet:
            if KeySet is None:
                raise TypeError("missing a required argument: 'KeySet'")
            _send_buffer.write(KeySet.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, MasterKeyType: Desfire_ChangeExtKey_MasterKeyType = "DESorTripleDES", IsKeySet: Optional[bool] = None, IsAesKey: bool = False, IsVersion: Optional[bool] = None, IsChangeKey: bool = True, *, KeyNo: int, KeyVersion: Optional[int] = None, NewKey: bytes, OldKey: bytes, KeySet: Optional[int] = None, BrpTimeout: int = 2000) -> None:
        request_frame = self.build_frame(MasterKeyType=MasterKeyType, IsKeySet=IsKeySet, IsAesKey=IsAesKey, IsVersion=IsVersion, IsChangeKey=IsChangeKey, KeyNo=KeyNo, KeyVersion=KeyVersion, NewKey=NewKey, OldKey=OldKey, KeySet=KeySet, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Desfire_ChangeKey(Command):
    CommandGroupId = 0x1B
    CommandId = 0x07
    def build_frame(self, IsKeySet: Optional[bool] = None, IsMasterKey: bool = False, IsChangeKey: bool = False, *, KeyNr: int, NewKeyDivMode: Desfire_ChangeKey_NewKeyDivMode = "SamAv1OneRound", NewKeyHasDivData: Optional[bool] = None, NewKeyHasExtIdx: Optional[bool] = None, NewKeyIdx: int, CurKeyDivMode: Desfire_ChangeKey_CurKeyDivMode = "SamAv1OneRound", CurKeyHasDivData: Optional[bool] = None, CurKeyHasExtIdx: Optional[bool] = None, CurKeyIdx: int, NewKeyDivData: Optional[bytes] = None, CurKeyDivData: Optional[bytes] = None, NewKeyExtIdx: Optional[int] = None, CurKeyExtIdx: Optional[int] = None, KeySet: Optional[int] = None, BrpTimeout: int = 2000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1B\x07")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if CurKeyHasExtIdx is None and (CurKeyExtIdx is not None):
            CurKeyHasExtIdx = True
        if CurKeyHasDivData is None and (CurKeyDivData is not None):
            CurKeyHasDivData = True
        if NewKeyHasExtIdx is None and (NewKeyExtIdx is not None):
            NewKeyHasExtIdx = True
        if NewKeyHasDivData is None and (NewKeyDivData is not None):
            NewKeyHasDivData = True
        if IsKeySet is None and (KeySet is not None):
            IsKeySet = True
        if IsKeySet is None:
            IsKeySet = False
        if NewKeyHasDivData is None:
            NewKeyHasDivData = False
        if NewKeyHasExtIdx is None:
            NewKeyHasExtIdx = False
        if CurKeyHasDivData is None:
            CurKeyHasDivData = False
        if CurKeyHasExtIdx is None:
            CurKeyHasExtIdx = False
        _var_0000_int = 0
        _var_0000_int |= (int(IsKeySet) & 0b1) << 2
        _var_0000_int |= (int(IsMasterKey) & 0b1) << 1
        _var_0000_int |= (int(IsChangeKey) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(KeyNr.to_bytes(length=1, byteorder='big'))
        _var_0001_int = 0
        _var_0001_int |= (Desfire_ChangeKey_NewKeyDivMode_Parser.as_value(NewKeyDivMode) & 0b11) << 3
        _var_0001_int |= (int(NewKeyHasDivData) & 0b1) << 1
        _var_0001_int |= (int(NewKeyHasExtIdx) & 0b1) << 0
        _send_buffer.write(_var_0001_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(NewKeyIdx.to_bytes(length=1, byteorder='big'))
        _var_0002_int = 0
        _var_0002_int |= (Desfire_ChangeKey_CurKeyDivMode_Parser.as_value(CurKeyDivMode) & 0b11) << 3
        _var_0002_int |= (int(CurKeyHasDivData) & 0b1) << 1
        _var_0002_int |= (int(CurKeyHasExtIdx) & 0b1) << 0
        _send_buffer.write(_var_0002_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(CurKeyIdx.to_bytes(length=1, byteorder='big'))
        if NewKeyHasDivData:
            if NewKeyDivData is None:
                raise TypeError("missing a required argument: 'NewKeyDivData'")
            _send_buffer.write(int(len(NewKeyDivData)).to_bytes(1, byteorder='big'))
            _send_buffer.write(NewKeyDivData)
        if CurKeyHasDivData:
            if CurKeyDivData is None:
                raise TypeError("missing a required argument: 'CurKeyDivData'")
            _send_buffer.write(int(len(CurKeyDivData)).to_bytes(1, byteorder='big'))
            _send_buffer.write(CurKeyDivData)
        if NewKeyHasExtIdx:
            if NewKeyExtIdx is None:
                raise TypeError("missing a required argument: 'NewKeyExtIdx'")
            _send_buffer.write(NewKeyExtIdx.to_bytes(length=1, byteorder='big'))
        if CurKeyHasExtIdx:
            if CurKeyExtIdx is None:
                raise TypeError("missing a required argument: 'CurKeyExtIdx'")
            _send_buffer.write(CurKeyExtIdx.to_bytes(length=1, byteorder='big'))
        if IsKeySet:
            if KeySet is None:
                raise TypeError("missing a required argument: 'KeySet'")
            _send_buffer.write(KeySet.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, IsKeySet: Optional[bool] = None, IsMasterKey: bool = False, IsChangeKey: bool = False, *, KeyNr: int, NewKeyDivMode: Desfire_ChangeKey_NewKeyDivMode = "SamAv1OneRound", NewKeyHasDivData: Optional[bool] = None, NewKeyHasExtIdx: Optional[bool] = None, NewKeyIdx: int, CurKeyDivMode: Desfire_ChangeKey_CurKeyDivMode = "SamAv1OneRound", CurKeyHasDivData: Optional[bool] = None, CurKeyHasExtIdx: Optional[bool] = None, CurKeyIdx: int, NewKeyDivData: Optional[bytes] = None, CurKeyDivData: Optional[bytes] = None, NewKeyExtIdx: Optional[int] = None, CurKeyExtIdx: Optional[int] = None, KeySet: Optional[int] = None, BrpTimeout: int = 2000) -> None:
        request_frame = self.build_frame(IsKeySet=IsKeySet, IsMasterKey=IsMasterKey, IsChangeKey=IsChangeKey, KeyNr=KeyNr, NewKeyDivMode=NewKeyDivMode, NewKeyHasDivData=NewKeyHasDivData, NewKeyHasExtIdx=NewKeyHasExtIdx, NewKeyIdx=NewKeyIdx, CurKeyDivMode=CurKeyDivMode, CurKeyHasDivData=CurKeyHasDivData, CurKeyHasExtIdx=CurKeyHasExtIdx, CurKeyIdx=CurKeyIdx, NewKeyDivData=NewKeyDivData, CurKeyDivData=CurKeyDivData, NewKeyExtIdx=NewKeyExtIdx, CurKeyExtIdx=CurKeyExtIdx, KeySet=KeySet, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Desfire_SetFraming(Command):
    CommandGroupId = 0x1B
    CommandId = 0x10
    def build_frame(self, CommMode: Desfire_SetFraming_CommMode = "DESFireNative", BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1B\x10")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Desfire_SetFraming_CommMode_Parser.as_value(CommMode).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, CommMode: Desfire_SetFraming_CommMode = "DESFireNative", BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(CommMode=CommMode, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Desfire_ResetAuthentication(Command):
    CommandGroupId = 0x1B
    CommandId = 0x11
    def build_frame(self, BrpTimeout: int = 2000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1B\x11")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 2000) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Desfire_CreateDam(Command):
    CommandGroupId = 0x1B
    CommandId = 0x08
    def build_frame(self, AppId: int = 0, *, AppParams: bytes, EncryptedDefaultDamKey: bytes, DamMacKey: bytes, BrpTimeout: int = 2000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1B\x08")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(AppId.to_bytes(length=4, byteorder='big'))
        _send_buffer.write(int(len(AppParams)).to_bytes(1, byteorder='big'))
        _send_buffer.write(AppParams)
        _send_buffer.write(int(len(EncryptedDefaultDamKey)).to_bytes(1, byteorder='big'))
        _send_buffer.write(EncryptedDefaultDamKey)
        _send_buffer.write(int(len(DamMacKey)).to_bytes(1, byteorder='big'))
        _send_buffer.write(DamMacKey)
        return _send_buffer.getvalue()
    def __call__(self, AppId: int = 0, *, AppParams: bytes, EncryptedDefaultDamKey: bytes, DamMacKey: bytes, BrpTimeout: int = 2000) -> None:
        request_frame = self.build_frame(AppId=AppId, AppParams=AppParams, EncryptedDefaultDamKey=EncryptedDefaultDamKey, DamMacKey=DamMacKey, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Desfire_GetOriginalitySignature(Command):
    CommandGroupId = 0x1B
    CommandId = 0x0A
    def build_frame(self, BrpTimeout: int = 2000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1B\x0A")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 2000) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Signature_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Signature = _recv_buffer.read(_Signature_len)
        if len(_Signature) != _Signature_len:
            raise PayloadTooShortError(_Signature_len - len(_Signature))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Signature
class Desfire_VirtualCardSelect(Command):
    CommandGroupId = 0x1B
    CommandId = 0x0B
    def build_frame(self, ForceVcsAuthentication: bool = False, UseExtVcSelectKeys: Optional[bool] = None, DiversifyMacKey: int = 0, DiversifyEncKey: bool = False, UseVcSelectKeys: Optional[bool] = None, *, IID: bytes, EncKeyIdx: Optional[int] = None, MacKeyIdx: Optional[int] = None, DivData: Optional[bytes] = None, EncKey: Optional[bytes] = None, MacKey: Optional[bytes] = None, BrpTimeout: int = 2000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1B\x0B")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if UseVcSelectKeys is None and (EncKeyIdx is not None or MacKeyIdx is not None):
            UseVcSelectKeys = True
        if UseExtVcSelectKeys is None and (EncKey is not None or MacKey is not None):
            UseExtVcSelectKeys = True
        if UseExtVcSelectKeys is None:
            UseExtVcSelectKeys = False
        if UseVcSelectKeys is None:
            UseVcSelectKeys = False
        _var_0000_int = 0
        _var_0000_int |= (int(ForceVcsAuthentication) & 0b1) << 5
        _var_0000_int |= (int(UseExtVcSelectKeys) & 0b1) << 4
        _var_0000_int |= (DiversifyMacKey & 0b11) << 2
        _var_0000_int |= (int(DiversifyEncKey) & 0b1) << 1
        _var_0000_int |= (int(UseVcSelectKeys) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(IID)).to_bytes(1, byteorder='big'))
        _send_buffer.write(IID)
        if UseVcSelectKeys:
            if EncKeyIdx is None:
                raise TypeError("missing a required argument: 'EncKeyIdx'")
            if MacKeyIdx is None:
                raise TypeError("missing a required argument: 'MacKeyIdx'")
            _send_buffer.write(EncKeyIdx.to_bytes(length=2, byteorder='big'))
            _send_buffer.write(MacKeyIdx.to_bytes(length=2, byteorder='big'))
        if DiversifyMacKey == 1 or DiversifyMacKey == 2 or DiversifyMacKey == 3 or DiversifyEncKey:
            if DivData is None:
                raise TypeError("missing a required argument: 'DivData'")
            _send_buffer.write(int(len(DivData)).to_bytes(1, byteorder='big'))
            _send_buffer.write(DivData)
        if UseExtVcSelectKeys:
            if EncKey is None:
                raise TypeError("missing a required argument: 'EncKey'")
            if MacKey is None:
                raise TypeError("missing a required argument: 'MacKey'")
            _send_buffer.write(int(len(EncKey)).to_bytes(1, byteorder='big'))
            _send_buffer.write(EncKey)
            _send_buffer.write(int(len(MacKey)).to_bytes(1, byteorder='big'))
            _send_buffer.write(MacKey)
        return _send_buffer.getvalue()
    def __call__(self, ForceVcsAuthentication: bool = False, UseExtVcSelectKeys: Optional[bool] = None, DiversifyMacKey: int = 0, DiversifyEncKey: bool = False, UseVcSelectKeys: Optional[bool] = None, *, IID: bytes, EncKeyIdx: Optional[int] = None, MacKeyIdx: Optional[int] = None, DivData: Optional[bytes] = None, EncKey: Optional[bytes] = None, MacKey: Optional[bytes] = None, BrpTimeout: int = 2000) -> Desfire_VirtualCardSelect_Result:
        request_frame = self.build_frame(ForceVcsAuthentication=ForceVcsAuthentication, UseExtVcSelectKeys=UseExtVcSelectKeys, DiversifyMacKey=DiversifyMacKey, DiversifyEncKey=DiversifyEncKey, UseVcSelectKeys=UseVcSelectKeys, IID=IID, EncKeyIdx=EncKeyIdx, MacKeyIdx=MacKeyIdx, DivData=DivData, EncKey=EncKey, MacKey=MacKey, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _FciType = safe_read_int_from_buffer(_recv_buffer, 1)
        _Fci_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Fci = _recv_buffer.read(_Fci_len)
        if len(_Fci) != _Fci_len:
            raise PayloadTooShortError(_Fci_len - len(_Fci))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Desfire_VirtualCardSelect_Result(_FciType, _Fci)
class Desfire_ProxCheck(Command):
    CommandGroupId = 0x1B
    CommandId = 0x0C
    def build_frame(self, M: int = 4, UseExtProxKey: Optional[bool] = None, DiversifyProxKey: bool = False, UseProxKey: Optional[bool] = None, ProxKeyIdx: Optional[int] = None, DivData: Optional[bytes] = None, ProxKey: Optional[bytes] = None, BrpTimeout: int = 2000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1B\x0C")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if UseProxKey is None and (ProxKeyIdx is not None):
            UseProxKey = True
        if UseExtProxKey is None and (ProxKey is not None):
            UseExtProxKey = True
        if UseExtProxKey is None:
            UseExtProxKey = False
        if UseProxKey is None:
            UseProxKey = False
        _var_0000_int = 0
        _var_0000_int |= (M & 0b111) << 4
        _var_0000_int |= (int(UseExtProxKey) & 0b1) << 2
        _var_0000_int |= (int(DiversifyProxKey) & 0b1) << 1
        _var_0000_int |= (int(UseProxKey) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        if UseProxKey:
            if ProxKeyIdx is None:
                raise TypeError("missing a required argument: 'ProxKeyIdx'")
            _send_buffer.write(ProxKeyIdx.to_bytes(length=2, byteorder='big'))
        if DiversifyProxKey and UseProxKey:
            if DivData is None:
                raise TypeError("missing a required argument: 'DivData'")
            _send_buffer.write(int(len(DivData)).to_bytes(1, byteorder='big'))
            _send_buffer.write(DivData)
        if UseExtProxKey:
            if ProxKey is None:
                raise TypeError("missing a required argument: 'ProxKey'")
            _send_buffer.write(int(len(ProxKey)).to_bytes(1, byteorder='big'))
            _send_buffer.write(ProxKey)
        return _send_buffer.getvalue()
    def __call__(self, M: int = 4, UseExtProxKey: Optional[bool] = None, DiversifyProxKey: bool = False, UseProxKey: Optional[bool] = None, ProxKeyIdx: Optional[int] = None, DivData: Optional[bytes] = None, ProxKey: Optional[bytes] = None, BrpTimeout: int = 2000) -> None:
        request_frame = self.build_frame(M=M, UseExtProxKey=UseExtProxKey, DiversifyProxKey=DiversifyProxKey, UseProxKey=UseProxKey, ProxKeyIdx=ProxKeyIdx, DivData=DivData, ProxKey=ProxKey, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Desfire_GetDfNames(Command):
    CommandGroupId = 0x1B
    CommandId = 0x0D
    def build_frame(self, BrpTimeout: int = 3000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1B\x0D")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 3000) -> List[Desfire_GetDfNames_AppNr_Entry]:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _AppNr_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _AppNr = []  # type: ignore[var-annotated,unused-ignore]
        while not len(_AppNr) >= _AppNr_len:
            _AppId = safe_read_int_from_buffer(_recv_buffer, 4)
            _IsoFileId = safe_read_int_from_buffer(_recv_buffer, 2)
            _IsoDfName_len = safe_read_int_from_buffer(_recv_buffer, 1)
            _IsoDfName = _recv_buffer.read(_IsoDfName_len)
            if len(_IsoDfName) != _IsoDfName_len:
                raise PayloadTooShortError(_IsoDfName_len - len(_IsoDfName))
            _AppNr_Entry = Desfire_GetDfNames_AppNr_Entry(_AppId, _IsoFileId, _IsoDfName)
            _AppNr.append(_AppNr_Entry)
        if len(_AppNr) != _AppNr_len:
            raise PayloadTooShortError(_AppNr_len - len(_AppNr))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _AppNr
class Felica_GenericCmd(Command):
    CommandGroupId = 0x1C
    CommandId = 0x02
    def build_frame(self, FastBaud: Felica_GenericCmd_FastBaud = "Kbps424", *, Cmd: int, Param: bytes, Timeout: int = 20, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1C\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Felica_GenericCmd_FastBaud_Parser.as_value(FastBaud).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Cmd.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(Param)).to_bytes(1, byteorder='big'))
        _send_buffer.write(Param)
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, FastBaud: Felica_GenericCmd_FastBaud = "Kbps424", *, Cmd: int, Param: bytes, Timeout: int = 20, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(FastBaud=FastBaud, Cmd=Cmd, Param=Param, Timeout=Timeout, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Resp_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Resp = _recv_buffer.read(_Resp_len)
        if len(_Resp) != _Resp_len:
            raise PayloadTooShortError(_Resp_len - len(_Resp))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Resp
class Felica_SetUID2(Command):
    CommandGroupId = 0x1C
    CommandId = 0x01
    def build_frame(self, UID2: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1C\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if len(UID2) != 8:
            raise ValueError(UID2)
        _send_buffer.write(UID2)
        return _send_buffer.getvalue()
    def __call__(self, UID2: bytes, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(UID2=UID2, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Felica_Request(Command):
    CommandGroupId = 0x1C
    CommandId = 0x00
    def build_frame(self, FastBaud: Felica_Request_FastBaud = "Kbps212", SystemCode: int = 65535, RequestCode: int = 0, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1C\x00")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Felica_Request_FastBaud_Parser.as_value(FastBaud).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(SystemCode.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(RequestCode.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, FastBaud: Felica_Request_FastBaud = "Kbps212", SystemCode: int = 65535, RequestCode: int = 0, BrpTimeout: int = 100) -> Felica_Request_Result:
        request_frame = self.build_frame(FastBaud=FastBaud, SystemCode=SystemCode, RequestCode=RequestCode, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ColFlag = safe_read_int_from_buffer(_recv_buffer, 1)
        _Labels_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Labels = []  # type: ignore[var-annotated,unused-ignore]
        while not len(_Labels) >= _Labels_len:
            _NFCID_len = safe_read_int_from_buffer(_recv_buffer, 1)
            _NFCID = _recv_buffer.read(_NFCID_len)
            if len(_NFCID) != _NFCID_len:
                raise PayloadTooShortError(_NFCID_len - len(_NFCID))
            _Labels.append(_NFCID)
        if len(_Labels) != _Labels_len:
            raise PayloadTooShortError(_Labels_len - len(_Labels))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Felica_Request_Result(_ColFlag, _Labels)
class Iso14a_Select(Command):
    CommandGroupId = 0x13
    CommandId = 0x03
    def build_frame(self, CascLev: int = 0, BitCount: int = 0, *, PreSelSer: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x13\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(CascLev.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(BitCount.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(PreSelSer)
        return _send_buffer.getvalue()
    def __call__(self, CascLev: int = 0, BitCount: int = 0, *, PreSelSer: bytes, BrpTimeout: int = 100) -> Iso14a_Select_Result:
        request_frame = self.build_frame(CascLev=CascLev, BitCount=BitCount, PreSelSer=PreSelSer, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _SAK = safe_read_int_from_buffer(_recv_buffer, 1)
        _Serial_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Serial = _recv_buffer.read(_Serial_len)
        if len(_Serial) != _Serial_len:
            raise PayloadTooShortError(_Serial_len - len(_Serial))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Iso14a_Select_Result(_SAK, _Serial)
class Iso14a_Halt(Command):
    CommandGroupId = 0x13
    CommandId = 0x04
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x13\x04")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Iso14a_RequestATS(Command):
    CommandGroupId = 0x13
    CommandId = 0x05
    def build_frame(self, FSDI: Iso14a_RequestATS_FSDI = "Bytes64", CID: int = 0, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x13\x05")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (Iso14a_RequestATS_FSDI_Parser.as_value(FSDI) & 0b1111) << 4
        _var_0000_int |= (CID & 0b1111) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, FSDI: Iso14a_RequestATS_FSDI = "Bytes64", CID: int = 0, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(FSDI=FSDI, CID=CID, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ATS = _recv_buffer.read(-1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ATS
class Iso14a_PerformPPS(Command):
    CommandGroupId = 0x13
    CommandId = 0x06
    def build_frame(self, CID: int = 0, DSI: DivisorInteger = "Kbps106", DRI: DivisorInteger = "Kbps106", BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x13\x06")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(CID.to_bytes(length=1, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (DivisorInteger_Parser.as_value(DSI) & 0b11) << 2
        _var_0000_int |= (DivisorInteger_Parser.as_value(DRI) & 0b11) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, CID: int = 0, DSI: DivisorInteger = "Kbps106", DRI: DivisorInteger = "Kbps106", BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(CID=CID, DSI=DSI, DRI=DRI, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Iso14a_Request(Command):
    CommandGroupId = 0x13
    CommandId = 0x07
    def build_frame(self, ReqAll: bool = False, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x13\x07")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (int(ReqAll) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, ReqAll: bool = False, BrpTimeout: int = 100) -> Iso14a_Request_Result:
        request_frame = self.build_frame(ReqAll=ReqAll, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ATQA = _recv_buffer.read(2)
        if len(_ATQA) != 2:
            raise PayloadTooShortError(2 - len(_ATQA))
        _Collision = bool(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Iso14a_Request_Result(_ATQA, _Collision)
class Iso14a_RequestVasup(Command):
    CommandGroupId = 0x13
    CommandId = 0x0A
    def build_frame(self, ReqAll: bool = False, FormatVersion: int = 2, VasSupported: bool = True, AuthUserRequested: bool = True, TerminalTypeDataLength: int = 3, *, TerminalType: int, TCI: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x13\x0A")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (int(ReqAll) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(FormatVersion.to_bytes(length=1, byteorder='big'))
        _var_0001_int = 0
        _var_0001_int |= (int(VasSupported) & 0b1) << 7
        _var_0001_int |= (int(AuthUserRequested) & 0b1) << 6
        _var_0001_int |= (TerminalTypeDataLength & 0b1111) << 0
        _send_buffer.write(_var_0001_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(TerminalType.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(TCI)
        return _send_buffer.getvalue()
    def __call__(self, ReqAll: bool = False, FormatVersion: int = 2, VasSupported: bool = True, AuthUserRequested: bool = True, TerminalTypeDataLength: int = 3, *, TerminalType: int, TCI: bytes, BrpTimeout: int = 100) -> Iso14a_RequestVasup_Result:
        request_frame = self.build_frame(ReqAll=ReqAll, FormatVersion=FormatVersion, VasSupported=VasSupported, AuthUserRequested=AuthUserRequested, TerminalTypeDataLength=TerminalTypeDataLength, TerminalType=TerminalType, TCI=TCI, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ATQA = _recv_buffer.read(2)
        if len(_ATQA) != 2:
            raise PayloadTooShortError(2 - len(_ATQA))
        _Collision = bool(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Iso14a_RequestVasup_Result(_ATQA, _Collision)
class Iso14a_TransparentCmd(Command):
    CommandGroupId = 0x13
    CommandId = 0x20
    def build_frame(self, EnMifBwProt: bool = False, EnBitmode: bool = False, EnCRCRX: bool = True, EnCRCTX: bool = True, ParityMode: bool = True, EnParity: bool = True, *, SendDataLen: int, Timeout: int = 26, DSI: DivisorInteger = "Kbps106", DRI: DivisorInteger = "Kbps106", SendData: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x13\x20")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (int(EnMifBwProt) & 0b1) << 7
        _var_0000_int |= (int(EnBitmode) & 0b1) << 4
        _var_0000_int |= (int(EnCRCRX) & 0b1) << 3
        _var_0000_int |= (int(EnCRCTX) & 0b1) << 2
        _var_0000_int |= (int(ParityMode) & 0b1) << 1
        _var_0000_int |= (int(EnParity) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(SendDataLen.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        _var_0001_int = 0
        _var_0001_int |= (DivisorInteger_Parser.as_value(DSI) & 0b11) << 2
        _var_0001_int |= (DivisorInteger_Parser.as_value(DRI) & 0b11) << 0
        _send_buffer.write(_var_0001_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(SendData)
        return _send_buffer.getvalue()
    def __call__(self, EnMifBwProt: bool = False, EnBitmode: bool = False, EnCRCRX: bool = True, EnCRCTX: bool = True, ParityMode: bool = True, EnParity: bool = True, *, SendDataLen: int, Timeout: int = 26, DSI: DivisorInteger = "Kbps106", DRI: DivisorInteger = "Kbps106", SendData: bytes, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(EnMifBwProt=EnMifBwProt, EnBitmode=EnBitmode, EnCRCRX=EnCRCRX, EnCRCTX=EnCRCTX, ParityMode=ParityMode, EnParity=EnParity, SendDataLen=SendDataLen, Timeout=Timeout, DSI=DSI, DRI=DRI, SendData=SendData, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _RcvData_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _RcvData = _recv_buffer.read(_RcvData_len)
        if len(_RcvData) != _RcvData_len:
            raise PayloadTooShortError(_RcvData_len - len(_RcvData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _RcvData
class Iso14b_Request(Command):
    CommandGroupId = 0x14
    CommandId = 0x02
    def build_frame(self, ExtendedATQB: bool = False, ReqAll: bool = False, TimeSlots: Iso14b_Request_TimeSlots = "TimeSlots1", AFI: int = 0, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x14\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (int(ExtendedATQB) & 0b1) << 4
        _var_0000_int |= (int(ReqAll) & 0b1) << 3
        _var_0000_int |= (Iso14b_Request_TimeSlots_Parser.as_value(TimeSlots) & 0b111) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(AFI.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, ExtendedATQB: bool = False, ReqAll: bool = False, TimeSlots: Iso14b_Request_TimeSlots = "TimeSlots1", AFI: int = 0, BrpTimeout: int = 100) -> List[Iso14b_Request_ValueList_Entry]:
        request_frame = self.build_frame(ExtendedATQB=ExtendedATQB, ReqAll=ReqAll, TimeSlots=TimeSlots, AFI=AFI, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ValueList_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _ValueList = []  # type: ignore[var-annotated,unused-ignore]
        while not len(_ValueList) >= _ValueList_len:
            _PUPI = _recv_buffer.read(4)
            if len(_PUPI) != 4:
                raise PayloadTooShortError(4 - len(_PUPI))
            _AppData = _recv_buffer.read(4)
            if len(_AppData) != 4:
                raise PayloadTooShortError(4 - len(_AppData))
            _var_0001_int = safe_read_int_from_buffer(_recv_buffer, 1)
            _Synced = bool((_var_0001_int >> 7) & 0b1)
            _Send848 = bool((_var_0001_int >> 6) & 0b1)
            _Send424 = bool((_var_0001_int >> 5) & 0b1)
            _Send212 = bool((_var_0001_int >> 4) & 0b1)
            _Recv848 = bool((_var_0001_int >> 2) & 0b1)
            _Recv424 = bool((_var_0001_int >> 1) & 0b1)
            _Recv212 = bool((_var_0001_int >> 0) & 0b1)
            _var_0002_int = safe_read_int_from_buffer(_recv_buffer, 2)
            _FSCI = Iso14b_Request_FSCI_Parser.as_literal((_var_0002_int >> 12) & 0b1111)
            _ProtType = Iso14b_Request_ProtType_Parser.as_literal((_var_0002_int >> 8) & 0b1)
            _FWI = Iso14b_Request_FWI_Parser.as_literal((_var_0002_int >> 4) & 0b1111)
            _ADC = (_var_0002_int >> 2) & 0b11
            _NAD = bool((_var_0002_int >> 1) & 0b1)
            _CID = bool((_var_0002_int >> 0) & 0b1)
            if ExtendedATQB:
                _var_0004_int = safe_read_int_from_buffer(_recv_buffer, 1)
                _SFGI = Iso14b_Request_SFGI_Parser.as_literal((_var_0004_int >> 4) & 0b1111)
            else:
                _SFGI = None
            _ValueList_Entry = Iso14b_Request_ValueList_Entry(_PUPI, _AppData, _Synced, _Send848, _Send424, _Send212, _Recv848, _Recv424, _Recv212, _FSCI, _ProtType, _FWI, _ADC, _NAD, _CID, _SFGI)
            _ValueList.append(_ValueList_Entry)
        if len(_ValueList) != _ValueList_len:
            raise PayloadTooShortError(_ValueList_len - len(_ValueList))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ValueList
class Iso14b_Attrib(Command):
    CommandGroupId = 0x14
    CommandId = 0x03
    def build_frame(self, PUPI: bytes, TR0: Iso14b_Attrib_TR0 = "Numerator64", TR1: Iso14b_Attrib_TR1 = "Numerator80", EOF: Iso14b_Attrib_EOF = "EOFrequired", SOF: Iso14b_Attrib_SOF = "SOFrequired", DSI: DivisorInteger = "Kbps106", DRI: DivisorInteger = "Kbps106", FSDI: Iso14b_Attrib_FSDI = "Bytes64", *, ProtocolType: int, CID: int = 0, EnHLR: bool = False, EnMBLI: bool = False, EnCID: bool = False, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x14\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if len(PUPI) != 4:
            raise ValueError(PUPI)
        _send_buffer.write(PUPI)
        _var_0000_int = 0
        _var_0000_int |= (Iso14b_Attrib_TR0_Parser.as_value(TR0) & 0b11) << 22
        _var_0000_int |= (Iso14b_Attrib_TR1_Parser.as_value(TR1) & 0b11) << 20
        _var_0000_int |= (Iso14b_Attrib_EOF_Parser.as_value(EOF) & 0b1) << 19
        _var_0000_int |= (Iso14b_Attrib_SOF_Parser.as_value(SOF) & 0b1) << 18
        _var_0000_int |= (DivisorInteger_Parser.as_value(DSI) & 0b11) << 14
        _var_0000_int |= (DivisorInteger_Parser.as_value(DRI) & 0b11) << 12
        _var_0000_int |= (Iso14b_Attrib_FSDI_Parser.as_value(FSDI) & 0b1111) << 8
        _var_0000_int |= (ProtocolType & 0b1111) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=3, byteorder='big'))
        _send_buffer.write(CID.to_bytes(length=1, byteorder='big'))
        _var_0001_int = 0
        _var_0001_int |= (int(EnHLR) & 0b1) << 2
        _var_0001_int |= (int(EnMBLI) & 0b1) << 1
        _var_0001_int |= (int(EnCID) & 0b1) << 0
        _send_buffer.write(_var_0001_int.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, PUPI: bytes, TR0: Iso14b_Attrib_TR0 = "Numerator64", TR1: Iso14b_Attrib_TR1 = "Numerator80", EOF: Iso14b_Attrib_EOF = "EOFrequired", SOF: Iso14b_Attrib_SOF = "SOFrequired", DSI: DivisorInteger = "Kbps106", DRI: DivisorInteger = "Kbps106", FSDI: Iso14b_Attrib_FSDI = "Bytes64", *, ProtocolType: int, CID: int = 0, EnHLR: bool = False, EnMBLI: bool = False, EnCID: bool = False, BrpTimeout: int = 100) -> Iso14b_Attrib_Result:
        request_frame = self.build_frame(PUPI=PUPI, TR0=TR0, TR1=TR1, EOF=EOF, SOF=SOF, DSI=DSI, DRI=DRI, FSDI=FSDI, ProtocolType=ProtocolType, CID=CID, EnHLR=EnHLR, EnMBLI=EnMBLI, EnCID=EnCID, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        if EnCID:
            _AssignedCID = safe_read_int_from_buffer(_recv_buffer, 1)
        else:
            _AssignedCID = None
        if EnMBLI:
            _MBLI = safe_read_int_from_buffer(_recv_buffer, 1)
        else:
            _MBLI = None
        if EnHLR:
            _HLR_len = safe_read_int_from_buffer(_recv_buffer, 1)
            _HLR = _recv_buffer.read(_HLR_len)
            if len(_HLR) != _HLR_len:
                raise PayloadTooShortError(_HLR_len - len(_HLR))
        else:
            _HLR = None
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Iso14b_Attrib_Result(_AssignedCID, _MBLI, _HLR)
class Iso14b_Halt(Command):
    CommandGroupId = 0x14
    CommandId = 0x04
    def build_frame(self, PUPI: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x14\x04")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if len(PUPI) != 4:
            raise ValueError(PUPI)
        _send_buffer.write(PUPI)
        return _send_buffer.getvalue()
    def __call__(self, PUPI: bytes, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(PUPI=PUPI, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Iso14b_TransparentCmd(Command):
    CommandGroupId = 0x14
    CommandId = 0x20
    def build_frame(self, EnCRCRX: bool = True, EnCRCTX: bool = True, *, SendDataLen: int, Timeout: int = 10, DSI: DivisorInteger = "Kbps106", DRI: DivisorInteger = "Kbps106", SendData: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x14\x20")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (int(EnCRCRX) & 0b1) << 1
        _var_0000_int |= (int(EnCRCTX) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(SendDataLen.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        _var_0001_int = 0
        _var_0001_int |= (DivisorInteger_Parser.as_value(DSI) & 0b11) << 2
        _var_0001_int |= (DivisorInteger_Parser.as_value(DRI) & 0b11) << 0
        _send_buffer.write(_var_0001_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(SendData)
        return _send_buffer.getvalue()
    def __call__(self, EnCRCRX: bool = True, EnCRCTX: bool = True, *, SendDataLen: int, Timeout: int = 10, DSI: DivisorInteger = "Kbps106", DRI: DivisorInteger = "Kbps106", SendData: bytes, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(EnCRCRX=EnCRCRX, EnCRCTX=EnCRCTX, SendDataLen=SendDataLen, Timeout=Timeout, DSI=DSI, DRI=DRI, SendData=SendData, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _RecvData_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _RecvData = _recv_buffer.read(_RecvData_len)
        if len(_RecvData) != _RecvData_len:
            raise PayloadTooShortError(_RecvData_len - len(_RecvData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _RecvData
class Iso14L4_SetupAPDU(Command):
    CommandGroupId = 0x16
    CommandId = 0x00
    def build_frame(self, EnDefault: bool = True, ToggleAB: bool = False, EnNAD: bool = False, EnCID: bool = False, CID: int = 0, NAD: int = 0, FSCI: Iso14L4_SetupAPDU_FSCI = "Bytes64", FWI: Iso14L4_SetupAPDU_FWI = "Us4832", DSI: DivisorInteger = "Kbps106", DRI: DivisorInteger = "Kbps106", BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x16\x00")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (int(EnDefault) & 0b1) << 3
        _var_0000_int |= (int(ToggleAB) & 0b1) << 2
        _var_0000_int |= (int(EnNAD) & 0b1) << 1
        _var_0000_int |= (int(EnCID) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(CID.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(NAD.to_bytes(length=1, byteorder='big'))
        _var_0001_int = 0
        _var_0001_int |= (Iso14L4_SetupAPDU_FSCI_Parser.as_value(FSCI) & 0b1111) << 12
        _var_0001_int |= (Iso14L4_SetupAPDU_FWI_Parser.as_value(FWI) & 0b1111) << 8
        _var_0001_int |= (DivisorInteger_Parser.as_value(DSI) & 0b11) << 2
        _var_0001_int |= (DivisorInteger_Parser.as_value(DRI) & 0b11) << 0
        _send_buffer.write(_var_0001_int.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, EnDefault: bool = True, ToggleAB: bool = False, EnNAD: bool = False, EnCID: bool = False, CID: int = 0, NAD: int = 0, FSCI: Iso14L4_SetupAPDU_FSCI = "Bytes64", FWI: Iso14L4_SetupAPDU_FWI = "Us4832", DSI: DivisorInteger = "Kbps106", DRI: DivisorInteger = "Kbps106", BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(EnDefault=EnDefault, ToggleAB=ToggleAB, EnNAD=EnNAD, EnCID=EnCID, CID=CID, NAD=NAD, FSCI=FSCI, FWI=FWI, DSI=DSI, DRI=DRI, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Iso14L4_ExchangeAPDU(Command):
    CommandGroupId = 0x16
    CommandId = 0x01
    def build_frame(self, SendData: bytes, BrpTimeout: int = 60000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x16\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(int(len(SendData)).to_bytes(2, byteorder='big'))
        _send_buffer.write(SendData)
        return _send_buffer.getvalue()
    def __call__(self, SendData: bytes, BrpTimeout: int = 60000) -> bytes:
        request_frame = self.build_frame(SendData=SendData, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _RecvData_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _RecvData = _recv_buffer.read(_RecvData_len)
        if len(_RecvData) != _RecvData_len:
            raise PayloadTooShortError(_RecvData_len - len(_RecvData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _RecvData
class Iso14L4_Deselect(Command):
    CommandGroupId = 0x16
    CommandId = 0x02
    def build_frame(self, BrpTimeout: int = 2000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x16\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 2000) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Iso15_SetParam(Command):
    CommandGroupId = 0x21
    CommandId = 0x00
    def build_frame(self, ModulationIndex: bool = False, TXMode: bool = True, HighDataRate: bool = True, DualSubcarrier: bool = False, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x21\x00")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (int(ModulationIndex) & 0b1) << 3
        _var_0000_int |= (int(TXMode) & 0b1) << 2
        _var_0000_int |= (int(HighDataRate) & 0b1) << 1
        _var_0000_int |= (int(DualSubcarrier) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, ModulationIndex: bool = False, TXMode: bool = True, HighDataRate: bool = True, DualSubcarrier: bool = False, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(ModulationIndex=ModulationIndex, TXMode=TXMode, HighDataRate=HighDataRate, DualSubcarrier=DualSubcarrier, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Iso15_GetParam(Command):
    CommandGroupId = 0x21
    CommandId = 0x01
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x21\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> Iso15_GetParam_Result:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Mode_int = safe_read_int_from_buffer(_recv_buffer, 1)
        _ModulationIndex = bool((_Mode_int >> 3) & 0b1)
        _TXMode = bool((_Mode_int >> 2) & 0b1)
        _HighDataRate = bool((_Mode_int >> 1) & 0b1)
        _DualSubcarrier = bool((_Mode_int >> 0) & 0b1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Iso15_GetParam_Result(_ModulationIndex, _TXMode, _HighDataRate, _DualSubcarrier)
class Iso15_GetUIDList(Command):
    CommandGroupId = 0x21
    CommandId = 0x02
    def build_frame(self, EnAFI: Optional[bool] = None, NextBlock: bool = False, AutoQuiet: bool = False, EnDSFID: bool = False, En16Slots: bool = False, AFI: Optional[int] = None, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x21\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if EnAFI is None and (AFI is not None):
            EnAFI = True
        if EnAFI is None:
            EnAFI = False
        if AFI is None:
            AFI = 0
        _var_0000_int = 0
        _var_0000_int |= (int(EnAFI) & 0b1) << 4
        _var_0000_int |= (int(NextBlock) & 0b1) << 3
        _var_0000_int |= (int(AutoQuiet) & 0b1) << 2
        _var_0000_int |= (int(EnDSFID) & 0b1) << 1
        _var_0000_int |= (int(En16Slots) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        if EnAFI:
            if AFI is None:
                raise TypeError("missing a required argument: 'AFI'")
            _send_buffer.write(AFI.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, EnAFI: Optional[bool] = None, NextBlock: bool = False, AutoQuiet: bool = False, EnDSFID: bool = False, En16Slots: bool = False, AFI: Optional[int] = None, BrpTimeout: int = 100) -> Iso15_GetUIDList_Result:
        request_frame = self.build_frame(EnAFI=EnAFI, NextBlock=NextBlock, AutoQuiet=AutoQuiet, EnDSFID=EnDSFID, En16Slots=En16Slots, AFI=AFI, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _More = safe_read_int_from_buffer(_recv_buffer, 1)
        _Labels_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Labels = []  # type: ignore[var-annotated,unused-ignore]
        while not len(_Labels) >= _Labels_len:
            _UID = _recv_buffer.read(8)
            if len(_UID) != 8:
                raise PayloadTooShortError(8 - len(_UID))
            if EnDSFID:
                _DSFID = safe_read_int_from_buffer(_recv_buffer, 1)
            else:
                _DSFID = None
            _Labels_Entry = Iso15_GetUIDList_Labels_Entry(_UID, _DSFID)
            _Labels.append(_Labels_Entry)
        if len(_Labels) != _Labels_len:
            raise PayloadTooShortError(_Labels_len - len(_Labels))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Iso15_GetUIDList_Result(_More, _Labels)
class Iso15_SetMode(Command):
    CommandGroupId = 0x21
    CommandId = 0x03
    def build_frame(self, Mode: Iso15_SetMode_Mode = "Addressed", UID: Optional[bytes] = None, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x21\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Iso15_SetMode_Mode_Parser.as_value(Mode).to_bytes(length=1, byteorder='big'))
        if Mode != "Unaddressed":
            if UID is None:
                raise TypeError("missing a required argument: 'UID'")
            if len(UID) != 8:
                raise ValueError(UID)
            _send_buffer.write(UID)
        return _send_buffer.getvalue()
    def __call__(self, Mode: Iso15_SetMode_Mode = "Addressed", UID: Optional[bytes] = None, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Mode=Mode, UID=UID, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Iso15_StayQuiet(Command):
    CommandGroupId = 0x21
    CommandId = 0x04
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x21\x04")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Iso15_LockBlock(Command):
    CommandGroupId = 0x21
    CommandId = 0x07
    def build_frame(self, BlockID: int = 0, OptionFlag: bool = False, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x21\x07")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(BlockID.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(OptionFlag.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BlockID: int = 0, OptionFlag: bool = False, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(BlockID=BlockID, OptionFlag=OptionFlag, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _LabelStat = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _LabelStat
class Iso15_ResetToReady(Command):
    CommandGroupId = 0x21
    CommandId = 0x08
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x21\x08")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _LabelStat = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _LabelStat
class Iso15_WriteAFI(Command):
    CommandGroupId = 0x21
    CommandId = 0x09
    def build_frame(self, AFI: int, OptionFlag: bool = False, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x21\x09")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(AFI.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(OptionFlag.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, AFI: int, OptionFlag: bool = False, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(AFI=AFI, OptionFlag=OptionFlag, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _LabelStat = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _LabelStat
class Iso15_LockAFI(Command):
    CommandGroupId = 0x21
    CommandId = 0x0A
    def build_frame(self, OptionFlag: bool = False, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x21\x0A")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(OptionFlag.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, OptionFlag: bool = False, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(OptionFlag=OptionFlag, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _LabelStat = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _LabelStat
class Iso15_WriteDSFID(Command):
    CommandGroupId = 0x21
    CommandId = 0x0B
    def build_frame(self, DSFID: int, OptionFlag: bool = False, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x21\x0B")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(DSFID.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(OptionFlag.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, DSFID: int, OptionFlag: bool = False, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(DSFID=DSFID, OptionFlag=OptionFlag, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _LabelStat = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _LabelStat
class Iso15_LockDSFID(Command):
    CommandGroupId = 0x21
    CommandId = 0x0C
    def build_frame(self, OptionFlag: bool = False, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x21\x0C")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(OptionFlag.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, OptionFlag: bool = False, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(OptionFlag=OptionFlag, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _LabelStat = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _LabelStat
class Iso15_GetSystemInformation(Command):
    CommandGroupId = 0x21
    CommandId = 0x0D
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x21\x0D")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> Iso15_GetSystemInformation_Result:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _LabelStat = safe_read_int_from_buffer(_recv_buffer, 1)
        if _LabelStat == 0:
            _Info_int = safe_read_int_from_buffer(_recv_buffer, 1)
            _EnICRef = bool((_Info_int >> 3) & 0b1)
            _EnMemSize = bool((_Info_int >> 2) & 0b1)
            _EnAFI = bool((_Info_int >> 1) & 0b1)
            _EnDSFID = bool((_Info_int >> 0) & 0b1)
            _SNR = _recv_buffer.read(8)
            if len(_SNR) != 8:
                raise PayloadTooShortError(8 - len(_SNR))
        else:
            _EnICRef = None
            _EnMemSize = None
            _EnAFI = None
            _EnDSFID = None
            _SNR = None
        if _LabelStat == 0 and _EnDSFID:
            _DSFID = safe_read_int_from_buffer(_recv_buffer, 1)
        else:
            _DSFID = None
        if _LabelStat == 0 and _EnAFI:
            _AFI = safe_read_int_from_buffer(_recv_buffer, 1)
        else:
            _AFI = None
        if _LabelStat == 0 and _EnMemSize:
            _BlockNum = safe_read_int_from_buffer(_recv_buffer, 1)
            _BlockSize = safe_read_int_from_buffer(_recv_buffer, 1)
        else:
            _BlockNum = None
            _BlockSize = None
        if _LabelStat == 0 and _EnICRef:
            _ICRef = safe_read_int_from_buffer(_recv_buffer, 1)
        else:
            _ICRef = None
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Iso15_GetSystemInformation_Result(_LabelStat, _EnICRef, _EnMemSize, _EnAFI, _EnDSFID, _SNR, _DSFID, _AFI, _BlockNum, _BlockSize, _ICRef)
class Iso15_GetSecurityStatus(Command):
    CommandGroupId = 0x21
    CommandId = 0x0E
    def build_frame(self, BlockID: int = 0, BlockNum: int = 0, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x21\x0E")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(BlockID.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(BlockNum.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BlockID: int = 0, BlockNum: int = 0, BrpTimeout: int = 100) -> Iso15_GetSecurityStatus_Result:
        request_frame = self.build_frame(BlockID=BlockID, BlockNum=BlockNum, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _LabelStat = safe_read_int_from_buffer(_recv_buffer, 1)
        _BlockStat = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _Status = safe_read_int_from_buffer(_recv_buffer, 1)
            _BlockStat.append(_Status)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Iso15_GetSecurityStatus_Result(_LabelStat, _BlockStat)
class Iso15_CustomCommand(Command):
    CommandGroupId = 0x21
    CommandId = 0x0F
    def build_frame(self, Cmd: int, Opt: int, MFC: int, TO: int, RequestData: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x21\x0F")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Cmd.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Opt.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(MFC.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(TO.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(RequestData)).to_bytes(2, byteorder='big'))
        _send_buffer.write(RequestData)
        return _send_buffer.getvalue()
    def __call__(self, Cmd: int, Opt: int, MFC: int, TO: int, RequestData: bytes, BrpTimeout: int = 100) -> Iso15_CustomCommand_Result:
        request_frame = self.build_frame(Cmd=Cmd, Opt=Opt, MFC=MFC, TO=TO, RequestData=RequestData, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _LabelStat = safe_read_int_from_buffer(_recv_buffer, 1)
        if _LabelStat == 0:
            _ResponseData_len = safe_read_int_from_buffer(_recv_buffer, 2)
            _ResponseData = _recv_buffer.read(_ResponseData_len)
            if len(_ResponseData) != _ResponseData_len:
                raise PayloadTooShortError(_ResponseData_len - len(_ResponseData))
        else:
            _ResponseData = None
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Iso15_CustomCommand_Result(_LabelStat, _ResponseData)
class Iso15_ReadSingleBlock(Command):
    CommandGroupId = 0x21
    CommandId = 0x11
    def build_frame(self, BlockID: int = 0, EnBlockSec: bool = False, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x21\x11")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(BlockID.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(EnBlockSec.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BlockID: int = 0, EnBlockSec: bool = False, BrpTimeout: int = 100) -> Iso15_ReadSingleBlock_Result:
        request_frame = self.build_frame(BlockID=BlockID, EnBlockSec=EnBlockSec, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _LabelStat = safe_read_int_from_buffer(_recv_buffer, 1)
        if _LabelStat == 0:
            _Payload_len = safe_read_int_from_buffer(_recv_buffer, 1)
            _Payload = _recv_buffer.read(_Payload_len)
            if len(_Payload) != _Payload_len:
                raise PayloadTooShortError(_Payload_len - len(_Payload))
        else:
            _Payload = None
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Iso15_ReadSingleBlock_Result(_LabelStat, _Payload)
class Iso15_WriteSingleBlock(Command):
    CommandGroupId = 0x21
    CommandId = 0x12
    def build_frame(self, BlockID: int = 0, *, BlockLen: int, OptionFlag: bool = False, SingleBlockData: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x21\x12")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(BlockID.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(BlockLen.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(OptionFlag.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(SingleBlockData)
        return _send_buffer.getvalue()
    def __call__(self, BlockID: int = 0, *, BlockLen: int, OptionFlag: bool = False, SingleBlockData: bytes, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(BlockID=BlockID, BlockLen=BlockLen, OptionFlag=OptionFlag, SingleBlockData=SingleBlockData, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _LabelStat = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _LabelStat
class Iso15_WriteMultipleBlocks(Command):
    CommandGroupId = 0x21
    CommandId = 0x21
    def build_frame(self, FirstBlockId: int = 0, *, WriteBlocks: List[bytes], OptionFlag: bool = False, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x21\x21")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(FirstBlockId.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(WriteBlocks)).to_bytes(2, byteorder='big'))
        for _WriteBlocks_Entry in WriteBlocks:
            _WriteBlock = _WriteBlocks_Entry
            _send_buffer.write(int(len(_WriteBlock)).to_bytes(1, byteorder='big'))
            _send_buffer.write(_WriteBlock)
        _send_buffer.write(OptionFlag.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, FirstBlockId: int = 0, *, WriteBlocks: List[bytes], OptionFlag: bool = False, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(FirstBlockId=FirstBlockId, WriteBlocks=WriteBlocks, OptionFlag=OptionFlag, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _LabelStat = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _LabelStat
class Iso15_ReadMultipleBlocks(Command):
    CommandGroupId = 0x21
    CommandId = 0x22
    def build_frame(self, FirstBlockId: int, BlockCount: int = 1, EnBlockSec: bool = False, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x21\x22")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(FirstBlockId.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(BlockCount.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(EnBlockSec.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, FirstBlockId: int, BlockCount: int = 1, EnBlockSec: bool = False, BrpTimeout: int = 100) -> Iso15_ReadMultipleBlocks_Result:
        request_frame = self.build_frame(FirstBlockId=FirstBlockId, BlockCount=BlockCount, EnBlockSec=EnBlockSec, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _LabelStat = safe_read_int_from_buffer(_recv_buffer, 1)
        _RecvBlocks_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _RecvBlocks = []  # type: ignore[var-annotated,unused-ignore]
        while not len(_RecvBlocks) >= _RecvBlocks_len:
            _RecvBlock_len = safe_read_int_from_buffer(_recv_buffer, 1)
            _RecvBlock = _recv_buffer.read(_RecvBlock_len)
            if len(_RecvBlock) != _RecvBlock_len:
                raise PayloadTooShortError(_RecvBlock_len - len(_RecvBlock))
            _RecvBlocks.append(_RecvBlock)
        if len(_RecvBlocks) != _RecvBlocks_len:
            raise PayloadTooShortError(_RecvBlocks_len - len(_RecvBlocks))
        _BlocksSecData_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _BlocksSecData = []  # type: ignore[var-annotated,unused-ignore]
        while not len(_BlocksSecData) >= _BlocksSecData_len:
            _BlockSecData = safe_read_int_from_buffer(_recv_buffer, 1)
            _BlocksSecData.append(_BlockSecData)
        if len(_BlocksSecData) != _BlocksSecData_len:
            raise PayloadTooShortError(_BlocksSecData_len - len(_BlocksSecData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Iso15_ReadMultipleBlocks_Result(_LabelStat, _RecvBlocks, _BlocksSecData)
class Iso15_TransparentCmd(Command):
    CommandGroupId = 0x21
    CommandId = 0x23
    def build_frame(self, SendData: bytes, Timeout: int = 26, EnCrcRx: bool = True, EnCrcTx: bool = True, RxWait: int = 0, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x21\x23")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(int(len(SendData)).to_bytes(2, byteorder='big'))
        _send_buffer.write(SendData)
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(EnCrcRx.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(EnCrcTx.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(RxWait.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, SendData: bytes, Timeout: int = 26, EnCrcRx: bool = True, EnCrcTx: bool = True, RxWait: int = 0, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(SendData=SendData, Timeout=Timeout, EnCrcRx=EnCrcRx, EnCrcTx=EnCrcTx, RxWait=RxWait, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _RecvData_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _RecvData = _recv_buffer.read(_RecvData_len)
        if len(_RecvData) != _RecvData_len:
            raise PayloadTooShortError(_RecvData_len - len(_RecvData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _RecvData
class Iso78_OpenSam(Command):
    CommandGroupId = 0x40
    CommandId = 0x04
    def build_frame(self, LID: Iso78_OpenSam_LID, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x40\x04")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Iso78_OpenSam_LID_Parser.as_value(LID).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, LID: Iso78_OpenSam_LID, BrpTimeout: int = 100) -> Iso78_OpenSam_Result:
        request_frame = self.build_frame(LID=LID, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _SamHandle = safe_read_int_from_buffer(_recv_buffer, 1)
        _ATR_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _ATR = _recv_buffer.read(_ATR_len)
        if len(_ATR) != _ATR_len:
            raise PayloadTooShortError(_ATR_len - len(_ATR))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Iso78_OpenSam_Result(_SamHandle, _ATR)
class Iso78_CloseSam(Command):
    CommandGroupId = 0x40
    CommandId = 0x05
    def build_frame(self, SamHandle: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x40\x05")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(SamHandle.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, SamHandle: int, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(SamHandle=SamHandle, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Iso78_ExchangeApdu(Command):
    CommandGroupId = 0x40
    CommandId = 0x06
    def build_frame(self, SamHandle: int, SendData: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x40\x06")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(SamHandle.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(SendData)).to_bytes(2, byteorder='big'))
        _send_buffer.write(SendData)
        return _send_buffer.getvalue()
    def __call__(self, SamHandle: int, SendData: bytes, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(SamHandle=SamHandle, SendData=SendData, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _RecvData_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _RecvData = _recv_buffer.read(_RecvData_len)
        if len(_RecvData) != _RecvData_len:
            raise PayloadTooShortError(_RecvData_len - len(_RecvData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _RecvData
class Lic_GetLicenses(Command):
    CommandGroupId = 0x0B
    CommandId = 0x01
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x0B\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> LicenseBitMask:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _LicenseBitMask_int = safe_read_int_from_buffer(_recv_buffer, 4)
        _Ble = bool((_LicenseBitMask_int >> 3) & 0b1)
        _BleLicRequired = bool((_LicenseBitMask_int >> 2) & 0b1)
        _HidOnlyForSE = bool((_LicenseBitMask_int >> 1) & 0b1)
        _Hid = bool((_LicenseBitMask_int >> 0) & 0b1)
        _LicenseBitMask = LicenseBitMask(_Ble, _BleLicRequired, _HidOnlyForSE, _Hid)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _LicenseBitMask
class Lic_ReadLicCard(Command):
    CommandGroupId = 0x0B
    CommandId = 0x02
    def build_frame(self, BrpTimeout: int = 2000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x0B\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 2000) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Main_Bf3UploadStart(Command):
    CommandGroupId = 0xF0
    CommandId = 0x10
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xF0\x10")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> Main_Bf3UploadStart_Result:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ReqDataAdr = safe_read_int_from_buffer(_recv_buffer, 4)
        _ReqDataLen = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Main_Bf3UploadStart_Result(_ReqDataAdr, _ReqDataLen)
class Main_Bf3UploadContinue(Command):
    CommandGroupId = 0xF0
    CommandId = 0x11
    def build_frame(self, DataAdr: int, Data: bytes, BrpTimeout: int = 1000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xF0\x11")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(DataAdr.to_bytes(length=4, byteorder='big'))
        _send_buffer.write(int(len(Data)).to_bytes(2, byteorder='big'))
        _send_buffer.write(Data)
        return _send_buffer.getvalue()
    def __call__(self, DataAdr: int, Data: bytes, BrpTimeout: int = 1000) -> Main_Bf3UploadContinue_Result:
        request_frame = self.build_frame(DataAdr=DataAdr, Data=Data, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _RequiredAction_int = safe_read_int_from_buffer(_recv_buffer, 1)
        _Reconnect = bool((_RequiredAction_int >> 1) & 0b1)
        _Continue = bool((_RequiredAction_int >> 0) & 0b1)
        _ReqDataAdr = safe_read_int_from_buffer(_recv_buffer, 4)
        _ReqDataLen = safe_read_int_from_buffer(_recv_buffer, 2)
        _AdditionalFields_int = safe_read_int_from_buffer(_recv_buffer, 1)
        _ContainsEstimation = bool((_AdditionalFields_int >> 1) & 0b1)
        _ContainsReconnectRetryTimeout = bool((_AdditionalFields_int >> 0) & 0b1)
        if _ContainsReconnectRetryTimeout:
            _ReconnectRetryTimeout = safe_read_int_from_buffer(_recv_buffer, 4)
        else:
            _ReconnectRetryTimeout = None
        if _ContainsEstimation:
            _EstimatedNumberOfBytes = safe_read_int_from_buffer(_recv_buffer, 4)
            _EstimatedTimeOverhead = safe_read_int_from_buffer(_recv_buffer, 4)
        else:
            _EstimatedNumberOfBytes = None
            _EstimatedTimeOverhead = None
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Main_Bf3UploadContinue_Result(_Reconnect, _Continue, _ReqDataAdr, _ReqDataLen, _ContainsEstimation, _ContainsReconnectRetryTimeout, _ReconnectRetryTimeout, _EstimatedNumberOfBytes, _EstimatedTimeOverhead)
class Mif_LoadKey(Command):
    CommandGroupId = 0x10
    CommandId = 0x00
    def build_frame(self, KeyIdx: int, Key: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x00")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(KeyIdx.to_bytes(length=1, byteorder='big'))
        if len(Key) != 6:
            raise ValueError(Key)
        _send_buffer.write(Key)
        return _send_buffer.getvalue()
    def __call__(self, KeyIdx: int, Key: bytes, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(KeyIdx=KeyIdx, Key=Key, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Mif_AuthE2(Command):
    CommandGroupId = 0x10
    CommandId = 0x04
    def build_frame(self, AuthMode: Mif_AuthE2_AuthMode = "KeyA", *, Block: int, KeyIdx: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x04")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Mif_AuthE2_AuthMode_Parser.as_value(AuthMode).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Block.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(KeyIdx.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, AuthMode: Mif_AuthE2_AuthMode = "KeyA", *, Block: int, KeyIdx: int, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(AuthMode=AuthMode, Block=Block, KeyIdx=KeyIdx, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Mif_AuthUser(Command):
    CommandGroupId = 0x10
    CommandId = 0x05
    def build_frame(self, AuthMode: Mif_AuthUser_AuthMode = "KeyA", *, Block: int, Key: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x05")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Mif_AuthUser_AuthMode_Parser.as_value(AuthMode).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Block.to_bytes(length=1, byteorder='big'))
        if len(Key) != 6:
            raise ValueError(Key)
        _send_buffer.write(Key)
        return _send_buffer.getvalue()
    def __call__(self, AuthMode: Mif_AuthUser_AuthMode = "KeyA", *, Block: int, Key: bytes, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(AuthMode=AuthMode, Block=Block, Key=Key, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Mif_Read(Command):
    CommandGroupId = 0x10
    CommandId = 0x06
    def build_frame(self, Block: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x06")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Block.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Block: int, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(Block=Block, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _BlockData = _recv_buffer.read(16)
        if len(_BlockData) != 16:
            raise PayloadTooShortError(16 - len(_BlockData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _BlockData
class Mif_Write(Command):
    CommandGroupId = 0x10
    CommandId = 0x07
    def build_frame(self, Block: int, BlockData: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x07")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Block.to_bytes(length=1, byteorder='big'))
        if len(BlockData) != 16:
            raise ValueError(BlockData)
        _send_buffer.write(BlockData)
        return _send_buffer.getvalue()
    def __call__(self, Block: int, BlockData: bytes, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Block=Block, BlockData=BlockData, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Mif_ChangeValue(Command):
    CommandGroupId = 0x10
    CommandId = 0x08
    def build_frame(self, Mode: Mif_ChangeValue_Mode, Block: int, Value: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x08")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Mif_ChangeValue_Mode_Parser.as_value(Mode).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Block.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Value.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Mode: Mif_ChangeValue_Mode, Block: int, Value: int, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Mode=Mode, Block=Block, Value=Value, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Mif_ChangeValueBackup(Command):
    CommandGroupId = 0x10
    CommandId = 0x09
    def build_frame(self, Mode: Mif_ChangeValueBackup_Mode, Block: int, Value: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x09")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Mif_ChangeValueBackup_Mode_Parser.as_value(Mode).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Block.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Value.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Mode: Mif_ChangeValueBackup_Mode, Block: int, Value: int, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Mode=Mode, Block=Block, Value=Value, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Mif_TransferBlock(Command):
    CommandGroupId = 0x10
    CommandId = 0x0A
    def build_frame(self, Block: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x0A")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Block.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Block: int, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Block=Block, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Mif_AuthE2Extended(Command):
    CommandGroupId = 0x10
    CommandId = 0x10
    def build_frame(self, AuthLevel: Mif_AuthE2Extended_AuthLevel = "AesSl3", KeyHasExtIdx: Optional[bool] = None, EV1Mode: bool = False, IsKeyB: bool = False, Block: int = 16384, *, KeyIdx: int, KeyExtIdx: Optional[int] = None, DivData: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x10")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if KeyHasExtIdx is None and (KeyExtIdx is not None):
            KeyHasExtIdx = True
        if KeyHasExtIdx is None:
            KeyHasExtIdx = False
        if KeyExtIdx is None:
            KeyExtIdx = 0
        _var_0000_int = 0
        _var_0000_int |= (Mif_AuthE2Extended_AuthLevel_Parser.as_value(AuthLevel) & 0b11) << 6
        _var_0000_int |= (int(KeyHasExtIdx) & 0b1) << 2
        _var_0000_int |= (int(EV1Mode) & 0b1) << 1
        _var_0000_int |= (int(IsKeyB) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Block.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(KeyIdx.to_bytes(length=1, byteorder='big'))
        if KeyHasExtIdx:
            if KeyExtIdx is None:
                raise TypeError("missing a required argument: 'KeyExtIdx'")
            _send_buffer.write(KeyExtIdx.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(DivData)).to_bytes(1, byteorder='big'))
        _send_buffer.write(DivData)
        return _send_buffer.getvalue()
    def __call__(self, AuthLevel: Mif_AuthE2Extended_AuthLevel = "AesSl3", KeyHasExtIdx: Optional[bool] = None, EV1Mode: bool = False, IsKeyB: bool = False, Block: int = 16384, *, KeyIdx: int, KeyExtIdx: Optional[int] = None, DivData: bytes, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(AuthLevel=AuthLevel, KeyHasExtIdx=KeyHasExtIdx, EV1Mode=EV1Mode, IsKeyB=IsKeyB, Block=Block, KeyIdx=KeyIdx, KeyExtIdx=KeyExtIdx, DivData=DivData, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Mif_AuthUserExtended(Command):
    CommandGroupId = 0x10
    CommandId = 0x11
    def build_frame(self, AuthLevel: Mif_AuthUserExtended_AuthLevel = "AesSl3", EV1Mode: bool = False, KeyB: bool = False, Block: int = 16384, *, Key: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x11")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (Mif_AuthUserExtended_AuthLevel_Parser.as_value(AuthLevel) & 0b11) << 6
        _var_0000_int |= (int(EV1Mode) & 0b1) << 1
        _var_0000_int |= (int(KeyB) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Block.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(Key)
        return _send_buffer.getvalue()
    def __call__(self, AuthLevel: Mif_AuthUserExtended_AuthLevel = "AesSl3", EV1Mode: bool = False, KeyB: bool = False, Block: int = 16384, *, Key: bytes, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(AuthLevel=AuthLevel, EV1Mode=EV1Mode, KeyB=KeyB, Block=Block, Key=Key, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Mif_ResetAuth(Command):
    CommandGroupId = 0x10
    CommandId = 0x12
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x12")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Mif_ReadSL3(Command):
    CommandGroupId = 0x10
    CommandId = 0x13
    def build_frame(self, NoMacOnCmd: bool = False, PlainData: bool = False, NoMacOnResp: bool = False, *, Block: int, BlockNr: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x13")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (int(NoMacOnCmd) & 0b1) << 2
        _var_0000_int |= (int(PlainData) & 0b1) << 1
        _var_0000_int |= (int(NoMacOnResp) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Block.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(BlockNr.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, NoMacOnCmd: bool = False, PlainData: bool = False, NoMacOnResp: bool = False, *, Block: int, BlockNr: int, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(NoMacOnCmd=NoMacOnCmd, PlainData=PlainData, NoMacOnResp=NoMacOnResp, Block=Block, BlockNr=BlockNr, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _BlockData_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _BlockData = _recv_buffer.read(_BlockData_len)
        if len(_BlockData) != _BlockData_len:
            raise PayloadTooShortError(_BlockData_len - len(_BlockData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _BlockData
class Mif_WriteSL3(Command):
    CommandGroupId = 0x10
    CommandId = 0x14
    def build_frame(self, PlainData: bool = False, NoMacOnResp: bool = False, *, Block: int, BlockData: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x14")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (int(PlainData) & 0b1) << 1
        _var_0000_int |= (int(NoMacOnResp) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Block.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(int(len(BlockData)).to_bytes(2, byteorder='big'))
        _send_buffer.write(BlockData)
        return _send_buffer.getvalue()
    def __call__(self, PlainData: bool = False, NoMacOnResp: bool = False, *, Block: int, BlockData: bytes, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(PlainData=PlainData, NoMacOnResp=NoMacOnResp, Block=Block, BlockData=BlockData, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Mif_ChangeAESKey(Command):
    CommandGroupId = 0x10
    CommandId = 0x15
    def build_frame(self, KeyHasExtIdx: Optional[bool] = None, NoMacOnResp: bool = False, *, Block: int, KeyIdx: int, KeyExtIdx: Optional[int] = None, DivData: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x15")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if KeyHasExtIdx is None and (KeyExtIdx is not None):
            KeyHasExtIdx = True
        if KeyHasExtIdx is None:
            KeyHasExtIdx = False
        if KeyExtIdx is None:
            KeyExtIdx = 0
        _var_0000_int = 0
        _var_0000_int |= (int(KeyHasExtIdx) & 0b1) << 3
        _var_0000_int |= (int(NoMacOnResp) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Block.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(KeyIdx.to_bytes(length=1, byteorder='big'))
        if KeyHasExtIdx:
            if KeyExtIdx is None:
                raise TypeError("missing a required argument: 'KeyExtIdx'")
            _send_buffer.write(KeyExtIdx.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(DivData)).to_bytes(1, byteorder='big'))
        _send_buffer.write(DivData)
        return _send_buffer.getvalue()
    def __call__(self, KeyHasExtIdx: Optional[bool] = None, NoMacOnResp: bool = False, *, Block: int, KeyIdx: int, KeyExtIdx: Optional[int] = None, DivData: bytes, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(KeyHasExtIdx=KeyHasExtIdx, NoMacOnResp=NoMacOnResp, Block=Block, KeyIdx=KeyIdx, KeyExtIdx=KeyExtIdx, DivData=DivData, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Mif_ValueSL3(Command):
    CommandGroupId = 0x10
    CommandId = 0x16
    def build_frame(self, NoMacOnResp: bool = False, *, Cmd: Mif_ValueSL3_Cmd, Block: int, DestBlock: Optional[int] = None, Value: Optional[int] = None, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x16")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (int(NoMacOnResp) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Mif_ValueSL3_Cmd_Parser.as_value(Cmd).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Block.to_bytes(length=2, byteorder='big'))
        if Cmd == "IncrementTransfer" or Cmd == "DecrementTransfer":
            if DestBlock is None:
                raise TypeError("missing a required argument: 'DestBlock'")
            _send_buffer.write(DestBlock.to_bytes(length=2, byteorder='big'))
        if Cmd == "Increment" or Cmd == "Decrement" or Cmd == "IncrementTransfer" or Cmd == "DecrementTransfer":
            if Value is None:
                raise TypeError("missing a required argument: 'Value'")
            _send_buffer.write(Value.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, NoMacOnResp: bool = False, *, Cmd: Mif_ValueSL3_Cmd, Block: int, DestBlock: Optional[int] = None, Value: Optional[int] = None, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(NoMacOnResp=NoMacOnResp, Cmd=Cmd, Block=Block, DestBlock=DestBlock, Value=Value, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _TMCounterTMValue_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _TMCounterTMValue = _recv_buffer.read(_TMCounterTMValue_len)
        if len(_TMCounterTMValue) != _TMCounterTMValue_len:
            raise PayloadTooShortError(_TMCounterTMValue_len - len(_TMCounterTMValue))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _TMCounterTMValue
class Mif_ProxCheck(Command):
    CommandGroupId = 0x10
    CommandId = 0x17
    def build_frame(self, M: int = 4, DisableIsoWrapping: bool = False, UseExtProxKey: Optional[bool] = None, DiversifyProxKey: bool = False, UseProxKey: Optional[bool] = None, ProxKeyIdx: Optional[int] = None, DivData: Optional[bytes] = None, ProxKey: Optional[bytes] = None, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x17")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if UseProxKey is None and (ProxKeyIdx is not None):
            UseProxKey = True
        if UseExtProxKey is None and (ProxKey is not None):
            UseExtProxKey = True
        if UseExtProxKey is None:
            UseExtProxKey = False
        if UseProxKey is None:
            UseProxKey = False
        _var_0000_int = 0
        _var_0000_int |= (M & 0b111) << 4
        _var_0000_int |= (int(DisableIsoWrapping) & 0b1) << 3
        _var_0000_int |= (int(UseExtProxKey) & 0b1) << 2
        _var_0000_int |= (int(DiversifyProxKey) & 0b1) << 1
        _var_0000_int |= (int(UseProxKey) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        if UseProxKey:
            if ProxKeyIdx is None:
                raise TypeError("missing a required argument: 'ProxKeyIdx'")
            _send_buffer.write(ProxKeyIdx.to_bytes(length=2, byteorder='big'))
        if DiversifyProxKey and UseProxKey:
            if DivData is None:
                raise TypeError("missing a required argument: 'DivData'")
            _send_buffer.write(int(len(DivData)).to_bytes(1, byteorder='big'))
            _send_buffer.write(DivData)
        if UseExtProxKey:
            if ProxKey is None:
                raise TypeError("missing a required argument: 'ProxKey'")
            _send_buffer.write(int(len(ProxKey)).to_bytes(1, byteorder='big'))
            _send_buffer.write(ProxKey)
        return _send_buffer.getvalue()
    def __call__(self, M: int = 4, DisableIsoWrapping: bool = False, UseExtProxKey: Optional[bool] = None, DiversifyProxKey: bool = False, UseProxKey: Optional[bool] = None, ProxKeyIdx: Optional[int] = None, DivData: Optional[bytes] = None, ProxKey: Optional[bytes] = None, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(M=M, DisableIsoWrapping=DisableIsoWrapping, UseExtProxKey=UseExtProxKey, DiversifyProxKey=DiversifyProxKey, UseProxKey=UseProxKey, ProxKeyIdx=ProxKeyIdx, DivData=DivData, ProxKey=ProxKey, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Mif_GetCardVersion(Command):
    CommandGroupId = 0x10
    CommandId = 0x18
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x18")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _CardVersion_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _CardVersion = _recv_buffer.read(_CardVersion_len)
        if len(_CardVersion) != _CardVersion_len:
            raise PayloadTooShortError(_CardVersion_len - len(_CardVersion))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _CardVersion
class Mif_ReadSig(Command):
    CommandGroupId = 0x10
    CommandId = 0x19
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x19")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _NxpSignature_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _NxpSignature = _recv_buffer.read(_NxpSignature_len)
        if len(_NxpSignature) != _NxpSignature_len:
            raise PayloadTooShortError(_NxpSignature_len - len(_NxpSignature))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _NxpSignature
class Mif_VirtualCardSelect(Command):
    CommandGroupId = 0x10
    CommandId = 0x1A
    def build_frame(self, ForceVcsAuthentication: bool = False, UseExtVcSelectKeys: Optional[bool] = None, DiversifyMacKey: int = 0, DiversifyEncKey: bool = False, UseVcSelectKeys: Optional[bool] = None, *, IID: bytes, EncKeyIdx: Optional[int] = None, MacKeyIdx: Optional[int] = None, DivData: Optional[bytes] = None, EncKey: Optional[bytes] = None, MacKey: Optional[bytes] = None, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x1A")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if UseVcSelectKeys is None and (EncKeyIdx is not None or MacKeyIdx is not None):
            UseVcSelectKeys = True
        if UseExtVcSelectKeys is None and (EncKey is not None or MacKey is not None):
            UseExtVcSelectKeys = True
        if UseExtVcSelectKeys is None:
            UseExtVcSelectKeys = False
        if UseVcSelectKeys is None:
            UseVcSelectKeys = False
        _var_0000_int = 0
        _var_0000_int |= (int(ForceVcsAuthentication) & 0b1) << 5
        _var_0000_int |= (int(UseExtVcSelectKeys) & 0b1) << 4
        _var_0000_int |= (DiversifyMacKey & 0b11) << 2
        _var_0000_int |= (int(DiversifyEncKey) & 0b1) << 1
        _var_0000_int |= (int(UseVcSelectKeys) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(IID)).to_bytes(1, byteorder='big'))
        _send_buffer.write(IID)
        if UseVcSelectKeys:
            if EncKeyIdx is None:
                raise TypeError("missing a required argument: 'EncKeyIdx'")
            if MacKeyIdx is None:
                raise TypeError("missing a required argument: 'MacKeyIdx'")
            _send_buffer.write(EncKeyIdx.to_bytes(length=2, byteorder='big'))
            _send_buffer.write(MacKeyIdx.to_bytes(length=2, byteorder='big'))
        if DiversifyMacKey == 1 or DiversifyMacKey == 2 or DiversifyMacKey == 3 or DiversifyEncKey:
            if DivData is None:
                raise TypeError("missing a required argument: 'DivData'")
            _send_buffer.write(int(len(DivData)).to_bytes(1, byteorder='big'))
            _send_buffer.write(DivData)
        if UseExtVcSelectKeys:
            if EncKey is None:
                raise TypeError("missing a required argument: 'EncKey'")
            if MacKey is None:
                raise TypeError("missing a required argument: 'MacKey'")
            _send_buffer.write(int(len(EncKey)).to_bytes(1, byteorder='big'))
            _send_buffer.write(EncKey)
            _send_buffer.write(int(len(MacKey)).to_bytes(1, byteorder='big'))
            _send_buffer.write(MacKey)
        return _send_buffer.getvalue()
    def __call__(self, ForceVcsAuthentication: bool = False, UseExtVcSelectKeys: Optional[bool] = None, DiversifyMacKey: int = 0, DiversifyEncKey: bool = False, UseVcSelectKeys: Optional[bool] = None, *, IID: bytes, EncKeyIdx: Optional[int] = None, MacKeyIdx: Optional[int] = None, DivData: Optional[bytes] = None, EncKey: Optional[bytes] = None, MacKey: Optional[bytes] = None, BrpTimeout: int = 100) -> Mif_VirtualCardSelect_Result:
        request_frame = self.build_frame(ForceVcsAuthentication=ForceVcsAuthentication, UseExtVcSelectKeys=UseExtVcSelectKeys, DiversifyMacKey=DiversifyMacKey, DiversifyEncKey=DiversifyEncKey, UseVcSelectKeys=UseVcSelectKeys, IID=IID, EncKeyIdx=EncKeyIdx, MacKeyIdx=MacKeyIdx, DivData=DivData, EncKey=EncKey, MacKey=MacKey, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _FciType = Mif_VirtualCardSelect_FciType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _Fci_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Fci = _recv_buffer.read(_Fci_len)
        if len(_Fci) != _Fci_len:
            raise PayloadTooShortError(_Fci_len - len(_Fci))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Mif_VirtualCardSelect_Result(_FciType, _Fci)
class Mif_SectorSwitch(Command):
    CommandGroupId = 0x10
    CommandId = 0x1B
    def build_frame(self, L3SectorSwitch: bool = True, *, SectorSwitchKeyIdx: int, SectorSwitchKeyDivData: bytes, SectorSpec: List[Mif_SectorSwitch_SectorSpec_Entry], SectorKeysDivData: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x1B")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (int(L3SectorSwitch) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(SectorSwitchKeyIdx.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(int(len(SectorSwitchKeyDivData)).to_bytes(1, byteorder='big'))
        _send_buffer.write(SectorSwitchKeyDivData)
        _send_buffer.write(int(len(SectorSpec)).to_bytes(1, byteorder='big'))
        for _SectorSpec_Entry in SectorSpec:
            _BlockAddress, _SectorKeyIdx = _SectorSpec_Entry
            _send_buffer.write(_BlockAddress.to_bytes(length=2, byteorder='big'))
            _send_buffer.write(_SectorKeyIdx.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(int(len(SectorKeysDivData)).to_bytes(1, byteorder='big'))
        _send_buffer.write(SectorKeysDivData)
        return _send_buffer.getvalue()
    def __call__(self, L3SectorSwitch: bool = True, *, SectorSwitchKeyIdx: int, SectorSwitchKeyDivData: bytes, SectorSpec: List[Mif_SectorSwitch_SectorSpec_Entry], SectorKeysDivData: bytes, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(L3SectorSwitch=L3SectorSwitch, SectorSwitchKeyIdx=SectorSwitchKeyIdx, SectorSwitchKeyDivData=SectorSwitchKeyDivData, SectorSpec=SectorSpec, SectorKeysDivData=SectorKeysDivData, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Mif_CommitReaderID(Command):
    CommandGroupId = 0x10
    CommandId = 0x1D
    def build_frame(self, Block: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x1D")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Block.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Block: int, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(Block=Block, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _EncTRI_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _EncTRI = _recv_buffer.read(_EncTRI_len)
        if len(_EncTRI) != _EncTRI_len:
            raise PayloadTooShortError(_EncTRI_len - len(_EncTRI))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _EncTRI
class Mif_SetFraming(Command):
    CommandGroupId = 0x10
    CommandId = 0x1C
    def build_frame(self, CommMode: Mif_SetFraming_CommMode = "MifareNative", BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x1C")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Mif_SetFraming_CommMode_Parser.as_value(CommMode).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, CommMode: Mif_SetFraming_CommMode = "MifareNative", BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(CommMode=CommMode, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class MobileId_Enable(Command):
    CommandGroupId = 0x4C
    CommandId = 0x01
    def build_frame(self, Mode: MobileId_Enable_Mode, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x4C\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(MobileId_Enable_Mode_Parser.as_value(Mode).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Mode: MobileId_Enable_Mode, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Mode=Mode, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class MobileId_GetVirtualCredentialId(Command):
    CommandGroupId = 0x4C
    CommandId = 0x03
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x4C\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _CredentialId_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _CredentialId = _recv_buffer.read(_CredentialId_len)
        if len(_CredentialId) != _CredentialId_len:
            raise PayloadTooShortError(_CredentialId_len - len(_CredentialId))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _CredentialId
class Sec_GetAcMask(Command):
    CommandGroupId = 0x07
    CommandId = 0x01
    def build_frame(self, SecLevel: int = 255, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x07\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(SecLevel.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, SecLevel: int = 255, BrpTimeout: int = 100) -> HostSecurityAccessConditionBits:
        request_frame = self.build_frame(SecLevel=SecLevel, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _AcMask_int = safe_read_int_from_buffer(_recv_buffer, 4)
        _HostToHostAccess = bool((_AcMask_int >> 28) & 0b1)
        _AutoreadAccess = bool((_AcMask_int >> 27) & 0b1)
        _CryptoAccess = bool((_AcMask_int >> 26) & 0b1)
        _Bf2Upload = bool((_AcMask_int >> 25) & 0b1)
        _ExtendedAccess = bool((_AcMask_int >> 24) & 0b1)
        _FlashFileSystemWrite = bool((_AcMask_int >> 23) & 0b1)
        _FlashFileSystemRead = bool((_AcMask_int >> 22) & 0b1)
        _RtcWrite = bool((_AcMask_int >> 21) & 0b1)
        _VhlExchangeapdu = bool((_AcMask_int >> 20) & 0b1)
        _VhlFormat = bool((_AcMask_int >> 19) & 0b1)
        _VhlWrite = bool((_AcMask_int >> 18) & 0b1)
        _VhlRead = bool((_AcMask_int >> 17) & 0b1)
        _VhlSelect = bool((_AcMask_int >> 16) & 0b1)
        _ExtSamAccess = bool((_AcMask_int >> 15) & 0b1)
        _HfLowlevelAccess = bool((_AcMask_int >> 14) & 0b1)
        _GuiAccess = bool((_AcMask_int >> 13) & 0b1)
        _IoPortWrite = bool((_AcMask_int >> 12) & 0b1)
        _IoPortRead = bool((_AcMask_int >> 11) & 0b1)
        _ConfigReset = bool((_AcMask_int >> 10) & 0b1)
        _ConfigWrite = bool((_AcMask_int >> 9) & 0b1)
        _ConfigRead = bool((_AcMask_int >> 8) & 0b1)
        _SysReset = bool((_AcMask_int >> 7) & 0b1)
        _SetAccessConditionMask2 = bool((_AcMask_int >> 6) & 0b1)
        _SetAccessConditionMask1 = bool((_AcMask_int >> 5) & 0b1)
        _SetAccessConditionMask0 = bool((_AcMask_int >> 4) & 0b1)
        _SetKey3 = bool((_AcMask_int >> 3) & 0b1)
        _SetKey2 = bool((_AcMask_int >> 2) & 0b1)
        _SetKey1 = bool((_AcMask_int >> 1) & 0b1)
        _FactoryReset = bool((_AcMask_int >> 0) & 0b1)
        _AcMask = HostSecurityAccessConditionBits(_HostToHostAccess, _AutoreadAccess, _CryptoAccess, _Bf2Upload, _ExtendedAccess, _FlashFileSystemWrite, _FlashFileSystemRead, _RtcWrite, _VhlExchangeapdu, _VhlFormat, _VhlWrite, _VhlRead, _VhlSelect, _ExtSamAccess, _HfLowlevelAccess, _GuiAccess, _IoPortWrite, _IoPortRead, _ConfigReset, _ConfigWrite, _ConfigRead, _SysReset, _SetAccessConditionMask2, _SetAccessConditionMask1, _SetAccessConditionMask0, _SetKey3, _SetKey2, _SetKey1, _FactoryReset)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _AcMask
class Sec_SetAcMask(Command):
    CommandGroupId = 0x07
    CommandId = 0x02
    def build_frame(self, SecLevel: int = 255, *, AcMask: Union[HostSecurityAccessConditionBits, HostSecurityAccessConditionBits_Dict], BrpTimeout: int = 1000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x07\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(SecLevel.to_bytes(length=1, byteorder='big'))
        if isinstance(AcMask, dict):
            AcMask = HostSecurityAccessConditionBits(**AcMask)
        AcMask_int = 0
        AcMask_int |= (int(AcMask.HostToHostAccess) & 0b1) << 28
        AcMask_int |= (int(AcMask.AutoreadAccess) & 0b1) << 27
        AcMask_int |= (int(AcMask.CryptoAccess) & 0b1) << 26
        AcMask_int |= (int(AcMask.Bf2Upload) & 0b1) << 25
        AcMask_int |= (int(AcMask.ExtendedAccess) & 0b1) << 24
        AcMask_int |= (int(AcMask.FlashFileSystemWrite) & 0b1) << 23
        AcMask_int |= (int(AcMask.FlashFileSystemRead) & 0b1) << 22
        AcMask_int |= (int(AcMask.RtcWrite) & 0b1) << 21
        AcMask_int |= (int(AcMask.VhlExchangeapdu) & 0b1) << 20
        AcMask_int |= (int(AcMask.VhlFormat) & 0b1) << 19
        AcMask_int |= (int(AcMask.VhlWrite) & 0b1) << 18
        AcMask_int |= (int(AcMask.VhlRead) & 0b1) << 17
        AcMask_int |= (int(AcMask.VhlSelect) & 0b1) << 16
        AcMask_int |= (int(AcMask.ExtSamAccess) & 0b1) << 15
        AcMask_int |= (int(AcMask.HfLowlevelAccess) & 0b1) << 14
        AcMask_int |= (int(AcMask.GuiAccess) & 0b1) << 13
        AcMask_int |= (int(AcMask.IoPortWrite) & 0b1) << 12
        AcMask_int |= (int(AcMask.IoPortRead) & 0b1) << 11
        AcMask_int |= (int(AcMask.ConfigReset) & 0b1) << 10
        AcMask_int |= (int(AcMask.ConfigWrite) & 0b1) << 9
        AcMask_int |= (int(AcMask.ConfigRead) & 0b1) << 8
        AcMask_int |= (int(AcMask.SysReset) & 0b1) << 7
        AcMask_int |= (int(AcMask.SetAccessConditionMask2) & 0b1) << 6
        AcMask_int |= (int(AcMask.SetAccessConditionMask1) & 0b1) << 5
        AcMask_int |= (int(AcMask.SetAccessConditionMask0) & 0b1) << 4
        AcMask_int |= (int(AcMask.SetKey3) & 0b1) << 3
        AcMask_int |= (int(AcMask.SetKey2) & 0b1) << 2
        AcMask_int |= (int(AcMask.SetKey1) & 0b1) << 1
        AcMask_int |= (int(AcMask.FactoryReset) & 0b1) << 0
        _send_buffer.write(AcMask_int.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, SecLevel: int = 255, *, AcMask: Union[HostSecurityAccessConditionBits, HostSecurityAccessConditionBits_Dict], BrpTimeout: int = 1000) -> None:
        request_frame = self.build_frame(SecLevel=SecLevel, AcMask=AcMask, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sec_SetKey(Command):
    CommandGroupId = 0x07
    CommandId = 0x03
    def build_frame(self, ContinuousIV: bool = False, Encrypted: bool = False, MACed: bool = False, SessionKey: bool = False, DeriveKey: int = 0, *, SecLevel: int, Key: bytes, BrpTimeout: int = 1000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x07\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (int(ContinuousIV) & 0b1) << 7
        _var_0000_int |= (int(Encrypted) & 0b1) << 6
        _var_0000_int |= (int(MACed) & 0b1) << 5
        _var_0000_int |= (int(SessionKey) & 0b1) << 4
        _var_0000_int |= (DeriveKey & 0b11) << 2
        _var_0000_int |= (SecLevel & 0b11) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        if len(Key) != 16:
            raise ValueError(Key)
        _send_buffer.write(Key)
        return _send_buffer.getvalue()
    def __call__(self, ContinuousIV: bool = False, Encrypted: bool = False, MACed: bool = False, SessionKey: bool = False, DeriveKey: int = 0, *, SecLevel: int, Key: bytes, BrpTimeout: int = 1000) -> None:
        request_frame = self.build_frame(ContinuousIV=ContinuousIV, Encrypted=Encrypted, MACed=MACed, SessionKey=SessionKey, DeriveKey=DeriveKey, SecLevel=SecLevel, Key=Key, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sec_AuthPhase1(Command):
    CommandGroupId = 0x07
    CommandId = 0x04
    def build_frame(self, SecLevel: int, RndA: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x07\x04")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(SecLevel.to_bytes(length=1, byteorder='big'))
        if len(RndA) != 16:
            raise ValueError(RndA)
        _send_buffer.write(RndA)
        return _send_buffer.getvalue()
    def __call__(self, SecLevel: int, RndA: bytes, BrpTimeout: int = 100) -> Sec_AuthPhase1_Result:
        request_frame = self.build_frame(SecLevel=SecLevel, RndA=RndA, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _EncRndA = _recv_buffer.read(16)
        if len(_EncRndA) != 16:
            raise PayloadTooShortError(16 - len(_EncRndA))
        _RndB = _recv_buffer.read(16)
        if len(_RndB) != 16:
            raise PayloadTooShortError(16 - len(_RndB))
        _ReqAuthModes_int = safe_read_int_from_buffer(_recv_buffer, 1)
        _ContinuousIV = bool((_ReqAuthModes_int >> 7) & 0b1)
        _Encrypted = bool((_ReqAuthModes_int >> 6) & 0b1)
        _MACed = bool((_ReqAuthModes_int >> 5) & 0b1)
        _SessionKey = bool((_ReqAuthModes_int >> 4) & 0b1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Sec_AuthPhase1_Result(_EncRndA, _RndB, _ContinuousIV, _Encrypted, _MACed, _SessionKey)
class Sec_AuthPhase2(Command):
    CommandGroupId = 0x07
    CommandId = 0x05
    def build_frame(self, EncRndB: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x07\x05")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if len(EncRndB) != 16:
            raise ValueError(EncRndB)
        _send_buffer.write(EncRndB)
        return _send_buffer.getvalue()
    def __call__(self, EncRndB: bytes, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(EncRndB=EncRndB, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sec_Tunnel(Command):
    CommandGroupId = 0x07
    CommandId = 0x06
    def build_frame(self, ContinuousIV: bool = True, Encrypted: bool = True, MACed: bool = False, SessionKey: bool = True, *, SecLevel: int, TunnelledCmd: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x07\x06")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (int(ContinuousIV) & 0b1) << 7
        _var_0000_int |= (int(Encrypted) & 0b1) << 6
        _var_0000_int |= (int(MACed) & 0b1) << 5
        _var_0000_int |= (int(SessionKey) & 0b1) << 4
        _var_0000_int |= (SecLevel & 0b11) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(TunnelledCmd)
        return _send_buffer.getvalue()
    def __call__(self, ContinuousIV: bool = True, Encrypted: bool = True, MACed: bool = False, SessionKey: bool = True, *, SecLevel: int, TunnelledCmd: bytes, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(ContinuousIV=ContinuousIV, Encrypted=Encrypted, MACed=MACed, SessionKey=SessionKey, SecLevel=SecLevel, TunnelledCmd=TunnelledCmd, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _TunnelledResp = _recv_buffer.read(-1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _TunnelledResp
class Sec_Reset(Command):
    CommandGroupId = 0x07
    CommandId = 0x08
    def build_frame(self, BrpTimeout: int = 10000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x07\x08")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 10000) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sec_LockReset(Command):
    CommandGroupId = 0x07
    CommandId = 0x09
    def build_frame(self, SecLevel: int = 255, BrpTimeout: int = 1000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x07\x09")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(SecLevel.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, SecLevel: int = 255, BrpTimeout: int = 1000) -> None:
        request_frame = self.build_frame(SecLevel=SecLevel, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sec_GetCurAcMask(Command):
    CommandGroupId = 0x07
    CommandId = 0x0A
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x07\x0A")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> HostSecurityAccessConditionBits:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _AcMask_int = safe_read_int_from_buffer(_recv_buffer, 4)
        _HostToHostAccess = bool((_AcMask_int >> 28) & 0b1)
        _AutoreadAccess = bool((_AcMask_int >> 27) & 0b1)
        _CryptoAccess = bool((_AcMask_int >> 26) & 0b1)
        _Bf2Upload = bool((_AcMask_int >> 25) & 0b1)
        _ExtendedAccess = bool((_AcMask_int >> 24) & 0b1)
        _FlashFileSystemWrite = bool((_AcMask_int >> 23) & 0b1)
        _FlashFileSystemRead = bool((_AcMask_int >> 22) & 0b1)
        _RtcWrite = bool((_AcMask_int >> 21) & 0b1)
        _VhlExchangeapdu = bool((_AcMask_int >> 20) & 0b1)
        _VhlFormat = bool((_AcMask_int >> 19) & 0b1)
        _VhlWrite = bool((_AcMask_int >> 18) & 0b1)
        _VhlRead = bool((_AcMask_int >> 17) & 0b1)
        _VhlSelect = bool((_AcMask_int >> 16) & 0b1)
        _ExtSamAccess = bool((_AcMask_int >> 15) & 0b1)
        _HfLowlevelAccess = bool((_AcMask_int >> 14) & 0b1)
        _GuiAccess = bool((_AcMask_int >> 13) & 0b1)
        _IoPortWrite = bool((_AcMask_int >> 12) & 0b1)
        _IoPortRead = bool((_AcMask_int >> 11) & 0b1)
        _ConfigReset = bool((_AcMask_int >> 10) & 0b1)
        _ConfigWrite = bool((_AcMask_int >> 9) & 0b1)
        _ConfigRead = bool((_AcMask_int >> 8) & 0b1)
        _SysReset = bool((_AcMask_int >> 7) & 0b1)
        _SetAccessConditionMask2 = bool((_AcMask_int >> 6) & 0b1)
        _SetAccessConditionMask1 = bool((_AcMask_int >> 5) & 0b1)
        _SetAccessConditionMask0 = bool((_AcMask_int >> 4) & 0b1)
        _SetKey3 = bool((_AcMask_int >> 3) & 0b1)
        _SetKey2 = bool((_AcMask_int >> 2) & 0b1)
        _SetKey1 = bool((_AcMask_int >> 1) & 0b1)
        _FactoryReset = bool((_AcMask_int >> 0) & 0b1)
        _AcMask = HostSecurityAccessConditionBits(_HostToHostAccess, _AutoreadAccess, _CryptoAccess, _Bf2Upload, _ExtendedAccess, _FlashFileSystemWrite, _FlashFileSystemRead, _RtcWrite, _VhlExchangeapdu, _VhlFormat, _VhlWrite, _VhlRead, _VhlSelect, _ExtSamAccess, _HfLowlevelAccess, _GuiAccess, _IoPortWrite, _IoPortRead, _ConfigReset, _ConfigWrite, _ConfigRead, _SysReset, _SetAccessConditionMask2, _SetAccessConditionMask1, _SetAccessConditionMask0, _SetKey3, _SetKey2, _SetKey1, _FactoryReset)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _AcMask
class Sys_GetBufferSize(Command):
    CommandGroupId = 0x00
    CommandId = 0x00
    def build_frame(self, BrpTimeout: int = 50) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x00")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 50) -> Sys_GetBufferSize_Result:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _MaxSendSize = safe_read_int_from_buffer(_recv_buffer, 2)
        _MaxRecvSize = safe_read_int_from_buffer(_recv_buffer, 2)
        _TotalSize = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Sys_GetBufferSize_Result(_MaxSendSize, _MaxRecvSize, _TotalSize)
class Sys_HFReset(Command):
    CommandGroupId = 0x00
    CommandId = 0x01
    def build_frame(self, OffDuration: int = 1, BrpTimeout: int = 2000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(OffDuration.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, OffDuration: int = 1, BrpTimeout: int = 2000) -> None:
        request_frame = self.build_frame(OffDuration=OffDuration, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sys_Reset(Command):
    CommandGroupId = 0x00
    CommandId = 0x03
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sys_GetInfo(Command):
    CommandGroupId = 0x00
    CommandId = 0x04
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x04")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> str:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Info_bytes = b''
        _Info_next_byte = _recv_buffer.read(1)
        while _Info_next_byte and _Info_next_byte != b'\x00':
            _Info_bytes += _Info_next_byte
            _Info_next_byte = _recv_buffer.read(1)
        if not _Info_next_byte:
            raise PayloadFormatError('missing zero-terminator in field Info')
        _Info = _Info_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Info
class Sys_GetBootStatus(Command):
    CommandGroupId = 0x00
    CommandId = 0x05
    def build_frame(self, BrpTimeout: int = 50) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x05")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 50) -> Sys_GetBootStatus_BootStatus:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _BootStatus_int = safe_read_int_from_buffer(_recv_buffer, 4)
        _NewerReaderChipFirmware = bool((_BootStatus_int >> 31) & 0b1)
        _UnexpectedRebootsLegacy = bool((_BootStatus_int >> 30) & 0b1)
        _FactorySettings = bool((_BootStatus_int >> 29) & 0b1)
        _ConfigurationInconsistent = bool((_BootStatus_int >> 28) & 0b1)
        _FirmwareVersionBlocked = bool((_BootStatus_int >> 27) & 0b1)
        _Bluetooth = bool((_BootStatus_int >> 23) & 0b1)
        _WiFi = bool((_BootStatus_int >> 22) & 0b1)
        _Tamper = bool((_BootStatus_int >> 21) & 0b1)
        _BatteryManagement = bool((_BootStatus_int >> 20) & 0b1)
        _Keyboard = bool((_BootStatus_int >> 19) & 0b1)
        _FirmwareVersionBlockedLegacy = bool((_BootStatus_int >> 18) & 0b1)
        _Display = bool((_BootStatus_int >> 17) & 0b1)
        _ConfCardPresented = bool((_BootStatus_int >> 16) & 0b1)
        _Ethernet = bool((_BootStatus_int >> 15) & 0b1)
        _ExtendedLED = bool((_BootStatus_int >> 14) & 0b1)
        _Rf125kHz = bool((_BootStatus_int >> 12) & 0b1)
        _Rf13MHz = bool((_BootStatus_int >> 10) & 0b1)
        _Rf13MHzLegic = bool((_BootStatus_int >> 9) & 0b1)
        _Rf13MHzLegacy = bool((_BootStatus_int >> 8) & 0b1)
        _HWoptions = bool((_BootStatus_int >> 7) & 0b1)
        _RTC = bool((_BootStatus_int >> 5) & 0b1)
        _Dataflash = bool((_BootStatus_int >> 4) & 0b1)
        _Configuration = bool((_BootStatus_int >> 2) & 0b1)
        _CorruptFirmware = bool((_BootStatus_int >> 1) & 0b1)
        _IncompleteFirmware = bool((_BootStatus_int >> 0) & 0b1)
        _BootStatus = Sys_GetBootStatus_BootStatus(_NewerReaderChipFirmware, _UnexpectedRebootsLegacy, _FactorySettings, _ConfigurationInconsistent, _FirmwareVersionBlocked, _Bluetooth, _WiFi, _Tamper, _BatteryManagement, _Keyboard, _FirmwareVersionBlockedLegacy, _Display, _ConfCardPresented, _Ethernet, _ExtendedLED, _Rf125kHz, _Rf13MHz, _Rf13MHzLegic, _Rf13MHzLegacy, _HWoptions, _RTC, _Dataflash, _Configuration, _CorruptFirmware, _IncompleteFirmware)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _BootStatus
class Sys_CfgGetValue(Command):
    CommandGroupId = 0x00
    CommandId = 0x08
    def build_frame(self, Key: int, Value: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x08")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Key.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Key: int, Value: int, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(Key=Key, Value=Value, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Content_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Content = _recv_buffer.read(_Content_len)
        if len(_Content) != _Content_len:
            raise PayloadTooShortError(_Content_len - len(_Content))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Content
class Sys_CfgSetValue(Command):
    CommandGroupId = 0x00
    CommandId = 0x09
    def build_frame(self, Key: int, Value: int, Content: bytes, BrpTimeout: int = 10000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x09")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Key.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(Content)).to_bytes(1, byteorder='big'))
        _send_buffer.write(Content)
        return _send_buffer.getvalue()
    def __call__(self, Key: int, Value: int, Content: bytes, BrpTimeout: int = 10000) -> None:
        request_frame = self.build_frame(Key=Key, Value=Value, Content=Content, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sys_CfgDelValues(Command):
    CommandGroupId = 0x00
    CommandId = 0x0A
    def build_frame(self, Key: int = 65535, Value: int = 255, BrpTimeout: int = 10000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x0A")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Key.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Key: int = 65535, Value: int = 255, BrpTimeout: int = 10000) -> None:
        request_frame = self.build_frame(Key=Key, Value=Value, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sys_CfgGetKeyList(Command):
    CommandGroupId = 0x00
    CommandId = 0x0B
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x0B")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> List[int]:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _KeyList_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _KeyList = []  # type: ignore[var-annotated,unused-ignore]
        while not len(_KeyList) >= _KeyList_len:
            _Key = safe_read_int_from_buffer(_recv_buffer, 2)
            _KeyList.append(_Key)
        if len(_KeyList) != _KeyList_len:
            raise PayloadTooShortError(_KeyList_len - len(_KeyList))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _KeyList
class Sys_CfgGetValueList(Command):
    CommandGroupId = 0x00
    CommandId = 0x0C
    def build_frame(self, Key: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x0C")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Key.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Key: int, BrpTimeout: int = 100) -> List[int]:
        request_frame = self.build_frame(Key=Key, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ValueList_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _ValueList = []  # type: ignore[var-annotated,unused-ignore]
        while not len(_ValueList) >= _ValueList_len:
            _Value = safe_read_int_from_buffer(_recv_buffer, 1)
            _ValueList.append(_Value)
        if len(_ValueList) != _ValueList_len:
            raise PayloadTooShortError(_ValueList_len - len(_ValueList))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ValueList
class Sys_CfgCheck(Command):
    CommandGroupId = 0x00
    CommandId = 0x13
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x13")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> Sys_CfgCheck_Result:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _TotalSize = safe_read_int_from_buffer(_recv_buffer, 2)
        _FreeSize = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Sys_CfgCheck_Result(_TotalSize, _FreeSize)
class Sys_SelectProtocol(Command):
    CommandGroupId = 0x00
    CommandId = 0x12
    def build_frame(self, Protocol: ProtocolID, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x12")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(ProtocolID_Parser.as_value(Protocol).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Protocol: ProtocolID, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Protocol=Protocol, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sys_CfgLoadBlock(Command):
    CommandGroupId = 0x00
    CommandId = 0x16
    def build_frame(self, Version: int = 0, *, Data: bytes, BrpTimeout: int = 10000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x16")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Version.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(Data)).to_bytes(1, byteorder='big'))
        _send_buffer.write(Data)
        return _send_buffer.getvalue()
    def __call__(self, Version: int = 0, *, Data: bytes, BrpTimeout: int = 10000) -> None:
        request_frame = self.build_frame(Version=Version, Data=Data, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sys_CfgReset(Command):
    CommandGroupId = 0x00
    CommandId = 0x18
    def build_frame(self, BrpTimeout: int = 10000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x18")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 10000) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sys_StopProtocol(Command):
    CommandGroupId = 0x00
    CommandId = 0x19
    def build_frame(self, Protocol: ProtocolID, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x19")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(ProtocolID_Parser.as_value(Protocol).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Protocol: ProtocolID, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Protocol=Protocol, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sys_SendMessage(Command):
    CommandGroupId = 0x00
    CommandId = 0x1A
    def build_frame(self, Protocol: ProtocolID, MsgType: MessageType, Message: bytes, BrpTimeout: int = 1000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x1A")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(ProtocolID_Parser.as_value(Protocol).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(MessageType_Parser.as_value(MsgType).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(Message)).to_bytes(1, byteorder='big'))
        _send_buffer.write(Message)
        return _send_buffer.getvalue()
    def __call__(self, Protocol: ProtocolID, MsgType: MessageType, Message: bytes, BrpTimeout: int = 1000) -> None:
        request_frame = self.build_frame(Protocol=Protocol, MsgType=MsgType, Message=Message, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sys_CfgGetId(Command):
    CommandGroupId = 0x00
    CommandId = 0x20
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x20")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> Sys_CfgGetId_Result:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ConfigId_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _ConfigId_bytes = _recv_buffer.read(_ConfigId_len)
        _ConfigId = _ConfigId_bytes.decode('ascii')
        if len(_ConfigId) != _ConfigId_len:
            raise PayloadTooShortError(_ConfigId_len - len(_ConfigId))
        _ConfigName_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _ConfigName_bytes = _recv_buffer.read(_ConfigName_len)
        _ConfigName = _ConfigName_bytes.decode('ascii')
        if len(_ConfigName) != _ConfigName_len:
            raise PayloadTooShortError(_ConfigName_len - len(_ConfigName))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Sys_CfgGetId_Result(_ConfigId, _ConfigName)
class Sys_CfgGetDeviceSettingsId(Command):
    CommandGroupId = 0x00
    CommandId = 0x21
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x21")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> Sys_CfgGetDeviceSettingsId_Result:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ConfigId_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _ConfigId_bytes = _recv_buffer.read(_ConfigId_len)
        _ConfigId = _ConfigId_bytes.decode('ascii')
        if len(_ConfigId) != _ConfigId_len:
            raise PayloadTooShortError(_ConfigId_len - len(_ConfigId))
        _ConfigName_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _ConfigName_bytes = _recv_buffer.read(_ConfigName_len)
        _ConfigName = _ConfigName_bytes.decode('ascii')
        if len(_ConfigName) != _ConfigName_len:
            raise PayloadTooShortError(_ConfigName_len - len(_ConfigName))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Sys_CfgGetDeviceSettingsId_Result(_ConfigId, _ConfigName)
class Sys_GetStatistics(Command):
    CommandGroupId = 0x00
    CommandId = 0x23
    def build_frame(self, DeleteCounters: bool = False, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x23")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(DeleteCounters.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, DeleteCounters: bool = False, BrpTimeout: int = 100) -> List[Sys_GetStatistics_CounterTuple_Entry]:
        request_frame = self.build_frame(DeleteCounters=DeleteCounters, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _CounterTuple_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _CounterTuple = []  # type: ignore[var-annotated,unused-ignore]
        while not len(_CounterTuple) >= _CounterTuple_len:
            _ID = safe_read_int_from_buffer(_recv_buffer, 1)
            _Value = safe_read_int_from_buffer(_recv_buffer, 1)
            _CounterTuple_Entry = Sys_GetStatistics_CounterTuple_Entry(_ID, _Value)
            _CounterTuple.append(_CounterTuple_Entry)
        if len(_CounterTuple) != _CounterTuple_len:
            raise PayloadTooShortError(_CounterTuple_len - len(_CounterTuple))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _CounterTuple
class Sys_GetFeatures(Command):
    CommandGroupId = 0x00
    CommandId = 0x24
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x24")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> Sys_GetFeatures_Result:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _FeatureList_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _FeatureList = []  # type: ignore[var-annotated,unused-ignore]
        while not len(_FeatureList) >= _FeatureList_len:
            _SupportedFeatureID = FeatureID_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 2))
            _FeatureList.append(_SupportedFeatureID)
        if len(_FeatureList) != _FeatureList_len:
            raise PayloadTooShortError(_FeatureList_len - len(_FeatureList))
        _MaxFeatureID = FeatureID_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 2))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Sys_GetFeatures_Result(_FeatureList, _MaxFeatureID)
class Sys_GetPartNumber(Command):
    CommandGroupId = 0x00
    CommandId = 0x25
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x25")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> Sys_GetPartNumber_Result:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _PartNo_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _PartNo_bytes = _recv_buffer.read(_PartNo_len)
        _PartNo = _PartNo_bytes.decode('ascii')
        if len(_PartNo) != _PartNo_len:
            raise PayloadTooShortError(_PartNo_len - len(_PartNo))
        _HwRevNo_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _HwRevNo_bytes = _recv_buffer.read(_HwRevNo_len)
        _HwRevNo = _HwRevNo_bytes.decode('ascii')
        if len(_HwRevNo) != _HwRevNo_len:
            raise PayloadTooShortError(_HwRevNo_len - len(_HwRevNo))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Sys_GetPartNumber_Result(_PartNo, _HwRevNo)
class Sys_CfgLoadPrepare(Command):
    CommandGroupId = 0x00
    CommandId = 0x26
    def build_frame(self, AuthReq: AuthReqUpload = "Default", BrpTimeout: int = 10000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x26")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(AuthReqUpload_Parser.as_value(AuthReq).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, AuthReq: AuthReqUpload = "Default", BrpTimeout: int = 10000) -> None:
        request_frame = self.build_frame(AuthReq=AuthReq, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sys_CfgLoadFinish(Command):
    CommandGroupId = 0x00
    CommandId = 0x27
    def build_frame(self, FinalizeAction: Sys_CfgLoadFinish_FinalizeAction, BrpTimeout: int = 10000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x27")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Sys_CfgLoadFinish_FinalizeAction_Parser.as_value(FinalizeAction).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, FinalizeAction: Sys_CfgLoadFinish_FinalizeAction, BrpTimeout: int = 10000) -> None:
        request_frame = self.build_frame(FinalizeAction=FinalizeAction, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sys_FactoryReset(Command):
    CommandGroupId = 0x00
    CommandId = 0x28
    def build_frame(self, PerformReboot: bool = True, BrpTimeout: int = 30000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x28")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(PerformReboot.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, PerformReboot: bool = True, BrpTimeout: int = 30000) -> None:
        request_frame = self.build_frame(PerformReboot=PerformReboot, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sys_GetLicenses(Command):
    CommandGroupId = 0x00
    CommandId = 0x29
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x29")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> LicenseBitMask:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _LicenseBitMask_int = safe_read_int_from_buffer(_recv_buffer, 4)
        _Ble = bool((_LicenseBitMask_int >> 3) & 0b1)
        _BleLicRequired = bool((_LicenseBitMask_int >> 2) & 0b1)
        _HidOnlyForSE = bool((_LicenseBitMask_int >> 1) & 0b1)
        _Hid = bool((_LicenseBitMask_int >> 0) & 0b1)
        _LicenseBitMask = LicenseBitMask(_Ble, _BleLicRequired, _HidOnlyForSE, _Hid)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _LicenseBitMask
class Ultralight_ExecCmd(Command):
    CommandGroupId = 0x25
    CommandId = 0x00
    def build_frame(self, Cmd: int, Param: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x25\x00")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Cmd.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(Param)).to_bytes(1, byteorder='big'))
        _send_buffer.write(Param)
        return _send_buffer.getvalue()
    def __call__(self, Cmd: int, Param: bytes, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(Cmd=Cmd, Param=Param, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Response_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Response = _recv_buffer.read(_Response_len)
        if len(_Response) != _Response_len:
            raise PayloadTooShortError(_Response_len - len(_Response))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Response
class Ultralight_Read(Command):
    CommandGroupId = 0x25
    CommandId = 0x01
    def build_frame(self, PageAdr: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x25\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(PageAdr.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, PageAdr: int, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(PageAdr=PageAdr, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _PageData = _recv_buffer.read(16)
        if len(_PageData) != 16:
            raise PayloadTooShortError(16 - len(_PageData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _PageData
class Ultralight_Write(Command):
    CommandGroupId = 0x25
    CommandId = 0x02
    def build_frame(self, PageAdr: int, PageData: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x25\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(PageAdr.to_bytes(length=1, byteorder='big'))
        if len(PageData) != 4:
            raise ValueError(PageData)
        _send_buffer.write(PageData)
        return _send_buffer.getvalue()
    def __call__(self, PageAdr: int, PageData: bytes, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(PageAdr=PageAdr, PageData=PageData, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Ultralight_AuthE2(Command):
    CommandGroupId = 0x25
    CommandId = 0x03
    def build_frame(self, DivMode: Ultralight_AuthE2_DivMode = "NoDiv", HasExtIdx: Optional[bool] = None, *, KeyIdx: int, DivData: bytes, KeyExtIdx: Optional[int] = None, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x25\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if HasExtIdx is None and (KeyExtIdx is not None):
            HasExtIdx = True
        if HasExtIdx is None:
            HasExtIdx = False
        _var_0000_int = 0
        _var_0000_int |= (Ultralight_AuthE2_DivMode_Parser.as_value(DivMode) & 0b11) << 1
        _var_0000_int |= (int(HasExtIdx) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(KeyIdx.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(DivData)).to_bytes(1, byteorder='big'))
        _send_buffer.write(DivData)
        if HasExtIdx:
            if KeyExtIdx is None:
                raise TypeError("missing a required argument: 'KeyExtIdx'")
            _send_buffer.write(KeyExtIdx.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, DivMode: Ultralight_AuthE2_DivMode = "NoDiv", HasExtIdx: Optional[bool] = None, *, KeyIdx: int, DivData: bytes, KeyExtIdx: Optional[int] = None, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(DivMode=DivMode, HasExtIdx=HasExtIdx, KeyIdx=KeyIdx, DivData=DivData, KeyExtIdx=KeyExtIdx, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Ultralight_AuthUser(Command):
    CommandGroupId = 0x25
    CommandId = 0x04
    def build_frame(self, CryptoMode: Ultralight_AuthUser_CryptoMode = "TripleDES", *, Key: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x25\x04")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (Ultralight_AuthUser_CryptoMode_Parser.as_value(CryptoMode) & 0b11) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(Key)).to_bytes(1, byteorder='big'))
        _send_buffer.write(Key)
        return _send_buffer.getvalue()
    def __call__(self, CryptoMode: Ultralight_AuthUser_CryptoMode = "TripleDES", *, Key: bytes, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(CryptoMode=CryptoMode, Key=Key, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Ultralight_SectorSwitch(Command):
    CommandGroupId = 0x25
    CommandId = 0x05
    def build_frame(self, SectorNumber: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x25\x05")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(SectorNumber.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, SectorNumber: int, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(SectorNumber=SectorNumber, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class UI_Enable(Command):
    CommandGroupId = 0x0A
    CommandId = 0x01
    def build_frame(self, Port: IoPort, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x0A\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(IoPort_Parser.as_value(Port).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Port: IoPort, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Port=Port, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class UI_Disable(Command):
    CommandGroupId = 0x0A
    CommandId = 0x02
    def build_frame(self, Port: IoPort, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x0A\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(IoPort_Parser.as_value(Port).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Port: IoPort, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Port=Port, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class UI_Toggle(Command):
    CommandGroupId = 0x0A
    CommandId = 0x03
    def build_frame(self, Port: IoPort, ToggleCount: int, Timespan1: int, Timespan2: int, Polarity: UI_Toggle_Polarity, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x0A\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(IoPort_Parser.as_value(Port).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(ToggleCount.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Timespan1.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(Timespan2.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(UI_Toggle_Polarity_Parser.as_value(Polarity).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Port: IoPort, ToggleCount: int, Timespan1: int, Timespan2: int, Polarity: UI_Toggle_Polarity, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Port=Port, ToggleCount=ToggleCount, Timespan1=Timespan1, Timespan2=Timespan2, Polarity=Polarity, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class UI_SetRgbLed(Command):
    CommandGroupId = 0x0A
    CommandId = 0x20
    def build_frame(self, LedState: Union[LedBitMask, LedBitMask_Dict], RgbColor: int, TransitionTime: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x0A\x20")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if isinstance(LedState, dict):
            LedState = LedBitMask(**LedState)
        LedState_int = 0
        LedState_int |= (int(LedState.LeftLed) & 0b1) << 2
        LedState_int |= (int(LedState.RightLed) & 0b1) << 1
        LedState_int |= (int(LedState.SingleLed) & 0b1) << 0
        _send_buffer.write(LedState_int.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(RgbColor.to_bytes(length=4, byteorder='big'))
        _send_buffer.write(TransitionTime.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, LedState: Union[LedBitMask, LedBitMask_Dict], RgbColor: int, TransitionTime: int, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(LedState=LedState, RgbColor=RgbColor, TransitionTime=TransitionTime, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class UI_PulseRgbLed(Command):
    CommandGroupId = 0x0A
    CommandId = 0x21
    def build_frame(self, LedState: Union[LedBitMask, LedBitMask_Dict], RgbColor1: int, RgbColor2: int, TransitionTime: int, Period: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x0A\x21")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if isinstance(LedState, dict):
            LedState = LedBitMask(**LedState)
        LedState_int = 0
        LedState_int |= (int(LedState.LeftLed) & 0b1) << 2
        LedState_int |= (int(LedState.RightLed) & 0b1) << 1
        LedState_int |= (int(LedState.SingleLed) & 0b1) << 0
        _send_buffer.write(LedState_int.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(RgbColor1.to_bytes(length=4, byteorder='big'))
        _send_buffer.write(RgbColor2.to_bytes(length=4, byteorder='big'))
        _send_buffer.write(TransitionTime.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(Period.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, LedState: Union[LedBitMask, LedBitMask_Dict], RgbColor1: int, RgbColor2: int, TransitionTime: int, Period: int, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(LedState=LedState, RgbColor1=RgbColor1, RgbColor2=RgbColor2, TransitionTime=TransitionTime, Period=Period, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class VHL_Select(Command):
    CommandGroupId = 0x01
    CommandId = 0x00
    def build_frame(self, CardFamiliesFilter: Union[CardFamilies, CardFamilies_Dict], Reselect: bool = False, AcceptConfCard: bool = False, BrpTimeout: int = 3000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x01\x00")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if isinstance(CardFamiliesFilter, dict):
            CardFamiliesFilter = CardFamilies(**CardFamiliesFilter)
        CardFamiliesFilter_int = 0
        CardFamiliesFilter_int |= (int(CardFamiliesFilter.LEGICPrime) & 0b1) << 11
        CardFamiliesFilter_int |= (int(CardFamiliesFilter.BluetoothMce) & 0b1) << 10
        CardFamiliesFilter_int |= (int(CardFamiliesFilter.Khz125Part2) & 0b1) << 9
        CardFamiliesFilter_int |= (int(CardFamiliesFilter.Srix) & 0b1) << 8
        CardFamiliesFilter_int |= (int(CardFamiliesFilter.Khz125Part1) & 0b1) << 7
        CardFamiliesFilter_int |= (int(CardFamiliesFilter.Felica) & 0b1) << 6
        CardFamiliesFilter_int |= (int(CardFamiliesFilter.IClass) & 0b1) << 5
        CardFamiliesFilter_int |= (int(CardFamiliesFilter.IClassIso14B) & 0b1) << 4
        CardFamiliesFilter_int |= (int(CardFamiliesFilter.Iso14443B) & 0b1) << 3
        CardFamiliesFilter_int |= (int(CardFamiliesFilter.Iso15693) & 0b1) << 2
        CardFamiliesFilter_int |= (int(CardFamiliesFilter.Iso14443A) & 0b1) << 0
        _send_buffer.write(CardFamiliesFilter_int.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(Reselect.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(AcceptConfCard.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, CardFamiliesFilter: Union[CardFamilies, CardFamilies_Dict], Reselect: bool = False, AcceptConfCard: bool = False, BrpTimeout: int = 3000) -> CardType:
        request_frame = self.build_frame(CardFamiliesFilter=CardFamiliesFilter, Reselect=Reselect, AcceptConfCard=AcceptConfCard, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _SelectedCardType = CardType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _SelectedCardType
class VHL_GetSnr(Command):
    CommandGroupId = 0x01
    CommandId = 0x01
    def build_frame(self, BrpTimeout: int = 1000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x01\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 1000) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Snr = _recv_buffer.read(-1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Snr
class VHL_Read(Command):
    CommandGroupId = 0x01
    CommandId = 0x02
    def build_frame(self, Id: int = 255, Adr: int = 0, *, Len: int, BrpTimeout: int = 3000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x01\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Id.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Adr.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(Len.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Id: int = 255, Adr: int = 0, *, Len: int, BrpTimeout: int = 3000) -> bytes:
        request_frame = self.build_frame(Id=Id, Adr=Adr, Len=Len, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Data = _recv_buffer.read(-1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Data
class VHL_Write(Command):
    CommandGroupId = 0x01
    CommandId = 0x03
    def build_frame(self, Id: int = 255, Adr: int = 0, *, Data: bytes, BrpTimeout: int = 3000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x01\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Id.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Adr.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(int(len(Data)).to_bytes(2, byteorder='big'))
        _send_buffer.write(Data)
        return _send_buffer.getvalue()
    def __call__(self, Id: int = 255, Adr: int = 0, *, Data: bytes, BrpTimeout: int = 3000) -> None:
        request_frame = self.build_frame(Id=Id, Adr=Adr, Data=Data, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class VHL_IsSelected(Command):
    CommandGroupId = 0x01
    CommandId = 0x04
    def build_frame(self, BrpTimeout: int = 3000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x01\x04")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 3000) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class VHL_ExchangeAPDU(Command):
    CommandGroupId = 0x01
    CommandId = 0x06
    def build_frame(self, AssumedCardType: CardType = "Default", *, Cmd: bytes, BrpTimeout: int = 60000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x01\x06")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(CardType_Parser.as_value(AssumedCardType).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(Cmd)).to_bytes(2, byteorder='big'))
        _send_buffer.write(Cmd)
        return _send_buffer.getvalue()
    def __call__(self, AssumedCardType: CardType = "Default", *, Cmd: bytes, BrpTimeout: int = 60000) -> bytes:
        request_frame = self.build_frame(AssumedCardType=AssumedCardType, Cmd=Cmd, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Resp_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _Resp = _recv_buffer.read(_Resp_len)
        if len(_Resp) != _Resp_len:
            raise PayloadTooShortError(_Resp_len - len(_Resp))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Resp
class VHL_Setup(Command):
    CommandGroupId = 0x01
    CommandId = 0x07
    def build_frame(self, ConsideredCardType: Optional[CardType] = None, HasMifareKey: Optional[VHL_Setup_HasMifareKey] = None, MifareKey: Optional[bytes] = None, MifareHasAsKeyA: Optional[VHL_Setup_MifareHasAsKeyA] = None, MifareAsKeyA: Optional[bool] = None, MifareHasMadId: Optional[VHL_Setup_MifareHasMadId] = None, MifareMadId: Optional[int] = None, DesfireHasAppId: Optional[VHL_Setup_DesfireHasAppId] = None, DesfireAppId: Optional[int] = None, HasDesfireFileDesc: Optional[VHL_Setup_HasDesfireFileDesc] = None, DesfireFileDesc: Optional[Union[DesfireFileDescription, DesfireFileDescription_Dict]] = None, DesfireKey: Optional[bytes] = None, LegicSegmentInfo: Optional[bytes] = None, LegicHasEnStamp: Optional[VHL_Setup_LegicHasEnStamp] = None, LegicEnStamp: Optional[bool] = None, LegicHasAdrMode: Optional[VHL_Setup_LegicHasAdrMode] = None, LegicAdrMode: Optional[VHL_Setup_LegicAdrMode] = None, Iso15HasFirstBlock: Optional[VHL_Setup_Iso15HasFirstBlock] = None, Iso15FirstBlock: Optional[int] = None, Iso15HasBlockCount: Optional[VHL_Setup_Iso15HasBlockCount] = None, Iso15BlockCount: Optional[int] = None, Iso15HasOptionFlag: Optional[VHL_Setup_Iso15HasOptionFlag] = None, Iso15OptionFlag: Optional[VHL_Setup_Iso15OptionFlag] = None, Iso15HasBlockSize: Optional[VHL_Setup_Iso15HasBlockSize] = None, Iso15BlockSize: Optional[int] = None, Iso14SelectFileCmdListLen: Optional[int] = None, Iso14SelectFileCmdList: Optional[List[VHL_Setup_Iso14SelectFileCmdList_Entry]] = None, Iso14HasFileLen: Optional[VHL_Setup_Iso14HasFileLen] = None, Iso14FileLen: Optional[int] = None, Iso14HasApduTimeout: Optional[VHL_Setup_Iso14HasApduTimeout] = None, Iso14ApduTimeout: Optional[int] = None, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x01\x07")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if Iso14HasApduTimeout is None and (Iso14ApduTimeout is not None):
            Iso14HasApduTimeout = "Enabled"
        if Iso14HasFileLen is None and (Iso14FileLen is not None):
            Iso14HasFileLen = "Enabled"
        if Iso15HasBlockSize is None and (Iso15BlockSize is not None):
            Iso15HasBlockSize = "Enabled"
        if Iso15HasOptionFlag is None and (Iso15OptionFlag is not None):
            Iso15HasOptionFlag = "Enabled"
        if Iso15HasBlockCount is None and (Iso15BlockCount is not None):
            Iso15HasBlockCount = "Enabled"
        if Iso15HasFirstBlock is None and (Iso15FirstBlock is not None):
            Iso15HasFirstBlock = "Enabled"
        if LegicHasAdrMode is None and (LegicAdrMode is not None):
            LegicHasAdrMode = "Enabled"
        if LegicHasEnStamp is None and (LegicEnStamp is not None):
            LegicHasEnStamp = "Enabled"
        if HasDesfireFileDesc is None and (DesfireFileDesc is not None):
            HasDesfireFileDesc = "Enabled"
        if DesfireHasAppId is None and (DesfireAppId is not None):
            DesfireHasAppId = "Enabled"
        if MifareHasMadId is None and (MifareMadId is not None):
            MifareHasMadId = "Enabled"
        if MifareHasAsKeyA is None and (MifareAsKeyA is not None):
            MifareHasAsKeyA = "Enabled"
        if HasMifareKey is None and (MifareKey is not None):
            HasMifareKey = "Enabled"
        _autoset_ConsideredCardType: set[CardType] = set()
        if HasMifareKey is not None or MifareHasAsKeyA is not None or MifareHasMadId is not None:
            _autoset_ConsideredCardType.add("MifareClassic")
        if DesfireHasAppId is not None or HasDesfireFileDesc is not None or DesfireKey is not None:
            _autoset_ConsideredCardType.add("MifareDesfire")
        if Iso15HasFirstBlock is not None or Iso15HasBlockCount is not None or Iso15HasOptionFlag is not None or Iso15HasBlockSize is not None:
            _autoset_ConsideredCardType.add("Iso15693")
        if Iso14SelectFileCmdListLen is not None or Iso14SelectFileCmdList is not None or Iso14HasFileLen is not None or Iso14HasApduTimeout is not None:
            _autoset_ConsideredCardType.add("Iso14443aIntIndustry")
        if ConsideredCardType is None and len(_autoset_ConsideredCardType) > 1:
            raise TypeError("missing a required argument: 'ConsideredCardType'")
        if ConsideredCardType is None and _autoset_ConsideredCardType:
            ConsideredCardType = next(iter(_autoset_ConsideredCardType))
        if ConsideredCardType is None:
            ConsideredCardType = "Default"
        if HasMifareKey is None:
            HasMifareKey = "Enabled"
        if MifareKey is None:
            MifareKey = b'\xff\xff\xff\xff\xff\xff'
        if MifareHasAsKeyA is None:
            MifareHasAsKeyA = "Enabled"
        if MifareAsKeyA is None:
            MifareAsKeyA = True
        if MifareHasMadId is None:
            MifareHasMadId = "Disabled"
        if DesfireHasAppId is None:
            DesfireHasAppId = "Enabled"
        if DesfireAppId is None:
            DesfireAppId = 0
        if HasDesfireFileDesc is None:
            HasDesfireFileDesc = "Enabled"
        if DesfireKey is None:
            DesfireKey = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        if LegicSegmentInfo is None:
            LegicSegmentInfo = b'\x01'
        if LegicHasEnStamp is None:
            LegicHasEnStamp = "Enabled"
        if LegicEnStamp is None:
            LegicEnStamp = False
        if LegicHasAdrMode is None:
            LegicHasAdrMode = "Enabled"
        if LegicAdrMode is None:
            LegicAdrMode = "ProtocolHeader"
        if Iso15HasFirstBlock is None:
            Iso15HasFirstBlock = "Disabled"
        if Iso15HasBlockCount is None:
            Iso15HasBlockCount = "Disabled"
        if Iso15HasOptionFlag is None:
            Iso15HasOptionFlag = "Disabled"
        if Iso15HasBlockSize is None:
            Iso15HasBlockSize = "Disabled"
        if Iso14HasFileLen is None:
            Iso14HasFileLen = "Enabled"
        if Iso14FileLen is None:
            Iso14FileLen = 4294967295
        if Iso14HasApduTimeout is None:
            Iso14HasApduTimeout = "Enabled"
        if Iso14ApduTimeout is None:
            Iso14ApduTimeout = 2500
        _send_buffer.write(CardType_Parser.as_value(ConsideredCardType).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(b'\x00')
        if ConsideredCardType == "MifareClassic":
            if HasMifareKey is None:
                raise TypeError("missing a required argument: 'HasMifareKey'")
            if MifareHasAsKeyA is None:
                raise TypeError("missing a required argument: 'MifareHasAsKeyA'")
            if MifareHasMadId is None:
                raise TypeError("missing a required argument: 'MifareHasMadId'")
            _send_buffer.write(VHL_Setup_HasMifareKey_Parser.as_value(HasMifareKey).to_bytes(length=1, byteorder='big'))
            if HasMifareKey == "Enabled":
                if MifareKey is None:
                    raise TypeError("missing a required argument: 'MifareKey'")
                if len(MifareKey) != 6:
                    raise ValueError(MifareKey)
                _send_buffer.write(MifareKey)
            _send_buffer.write(VHL_Setup_MifareHasAsKeyA_Parser.as_value(MifareHasAsKeyA).to_bytes(length=1, byteorder='big'))
            if MifareHasAsKeyA == "Enabled":
                if MifareAsKeyA is None:
                    raise TypeError("missing a required argument: 'MifareAsKeyA'")
                _send_buffer.write(MifareAsKeyA.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(VHL_Setup_MifareHasMadId_Parser.as_value(MifareHasMadId).to_bytes(length=1, byteorder='big'))
            if MifareHasMadId == "Enabled":
                if MifareMadId is None:
                    raise TypeError("missing a required argument: 'MifareMadId'")
                _send_buffer.write(MifareMadId.to_bytes(length=2, byteorder='big'))
        if ConsideredCardType == "MifareDesfire":
            if DesfireHasAppId is None:
                raise TypeError("missing a required argument: 'DesfireHasAppId'")
            if HasDesfireFileDesc is None:
                raise TypeError("missing a required argument: 'HasDesfireFileDesc'")
            if DesfireKey is None:
                raise TypeError("missing a required argument: 'DesfireKey'")
            _send_buffer.write(VHL_Setup_DesfireHasAppId_Parser.as_value(DesfireHasAppId).to_bytes(length=1, byteorder='big'))
            if DesfireHasAppId == "Enabled":
                if DesfireAppId is None:
                    raise TypeError("missing a required argument: 'DesfireAppId'")
                _send_buffer.write(DesfireAppId.to_bytes(length=4, byteorder='big'))
            _send_buffer.write(VHL_Setup_HasDesfireFileDesc_Parser.as_value(HasDesfireFileDesc).to_bytes(length=1, byteorder='big'))
            if HasDesfireFileDesc == "Enabled":
                if DesfireFileDesc is None:
                    raise TypeError("missing a required argument: 'DesfireFileDesc'")
                if isinstance(DesfireFileDesc, dict):
                    DesfireFileDesc = DesfireFileDescription(**DesfireFileDesc)
                _FileNo, _FileCommunicationSecurity, _FileType, _ReadKeyNo, _WriteKeyNo, _Offset, _Length, _ReadKeyIdx, _WriteKeyIdx, _AccessRightsLowByte, _ChangeKeyIdx, _FileSize, _IsoFid = DesfireFileDesc
                _send_buffer.write(_FileNo.to_bytes(length=1, byteorder='big'))
                _send_buffer.write(DesfireFileDescription_FileCommunicationSecurity_Parser.as_value(_FileCommunicationSecurity).to_bytes(length=1, byteorder='big'))
                _send_buffer.write(DesfireFileDescription_FileType_Parser.as_value(_FileType).to_bytes(length=1, byteorder='big'))
                _send_buffer.write(_ReadKeyNo.to_bytes(length=1, byteorder='big'))
                _send_buffer.write(_WriteKeyNo.to_bytes(length=1, byteorder='big'))
                _send_buffer.write(_Offset.to_bytes(length=2, byteorder='big'))
                _send_buffer.write(_Length.to_bytes(length=2, byteorder='big'))
                _send_buffer.write(_ReadKeyIdx.to_bytes(length=1, byteorder='big'))
                _send_buffer.write(_WriteKeyIdx.to_bytes(length=1, byteorder='big'))
                _send_buffer.write(_AccessRightsLowByte.to_bytes(length=1, byteorder='big'))
                _send_buffer.write(_ChangeKeyIdx.to_bytes(length=1, byteorder='big'))
                _send_buffer.write(_FileSize.to_bytes(length=2, byteorder='big'))
                _send_buffer.write(_IsoFid.to_bytes(length=2, byteorder='big'))
            _send_buffer.write(int(len(DesfireKey)).to_bytes(1, byteorder='big'))
            _send_buffer.write(DesfireKey)
        if ConsideredCardType == "LEGICPrimeLegacy" or ConsideredCardType == "LEGICAdvantLegacy" or ConsideredCardType == "LEGICPrime" or ConsideredCardType == "LEGICAdvantIso14443a" or ConsideredCardType == "LEGICAdvantIso15693":
            if LegicSegmentInfo is None:
                raise TypeError("missing a required argument: 'LegicSegmentInfo'")
            if LegicHasEnStamp is None:
                raise TypeError("missing a required argument: 'LegicHasEnStamp'")
            if LegicHasAdrMode is None:
                raise TypeError("missing a required argument: 'LegicHasAdrMode'")
            _send_buffer.write(int(len(LegicSegmentInfo)).to_bytes(1, byteorder='big'))
            _send_buffer.write(LegicSegmentInfo)
            _send_buffer.write(VHL_Setup_LegicHasEnStamp_Parser.as_value(LegicHasEnStamp).to_bytes(length=1, byteorder='big'))
            if LegicHasEnStamp == "Enabled":
                if LegicEnStamp is None:
                    raise TypeError("missing a required argument: 'LegicEnStamp'")
                _send_buffer.write(LegicEnStamp.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(VHL_Setup_LegicHasAdrMode_Parser.as_value(LegicHasAdrMode).to_bytes(length=1, byteorder='big'))
            if LegicHasAdrMode == "Enabled":
                if LegicAdrMode is None:
                    raise TypeError("missing a required argument: 'LegicAdrMode'")
                _send_buffer.write(VHL_Setup_LegicAdrMode_Parser.as_value(LegicAdrMode).to_bytes(length=1, byteorder='big'))
        if ConsideredCardType == "Iso15693":
            if Iso15HasFirstBlock is None:
                raise TypeError("missing a required argument: 'Iso15HasFirstBlock'")
            if Iso15HasBlockCount is None:
                raise TypeError("missing a required argument: 'Iso15HasBlockCount'")
            if Iso15HasOptionFlag is None:
                raise TypeError("missing a required argument: 'Iso15HasOptionFlag'")
            if Iso15HasBlockSize is None:
                raise TypeError("missing a required argument: 'Iso15HasBlockSize'")
            _send_buffer.write(VHL_Setup_Iso15HasFirstBlock_Parser.as_value(Iso15HasFirstBlock).to_bytes(length=1, byteorder='big'))
            if Iso15HasFirstBlock == "Enabled":
                if Iso15FirstBlock is None:
                    raise TypeError("missing a required argument: 'Iso15FirstBlock'")
                _send_buffer.write(Iso15FirstBlock.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(VHL_Setup_Iso15HasBlockCount_Parser.as_value(Iso15HasBlockCount).to_bytes(length=1, byteorder='big'))
            if Iso15HasBlockCount == "Enabled":
                if Iso15BlockCount is None:
                    raise TypeError("missing a required argument: 'Iso15BlockCount'")
                _send_buffer.write(Iso15BlockCount.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(VHL_Setup_Iso15HasOptionFlag_Parser.as_value(Iso15HasOptionFlag).to_bytes(length=1, byteorder='big'))
            if Iso15HasOptionFlag == "Enabled":
                if Iso15OptionFlag is None:
                    raise TypeError("missing a required argument: 'Iso15OptionFlag'")
                _send_buffer.write(VHL_Setup_Iso15OptionFlag_Parser.as_value(Iso15OptionFlag).to_bytes(length=1, byteorder='big'))
            _send_buffer.write(VHL_Setup_Iso15HasBlockSize_Parser.as_value(Iso15HasBlockSize).to_bytes(length=1, byteorder='big'))
            if Iso15HasBlockSize == "Enabled":
                if Iso15BlockSize is None:
                    raise TypeError("missing a required argument: 'Iso15BlockSize'")
                _send_buffer.write(Iso15BlockSize.to_bytes(length=1, byteorder='big'))
        if ConsideredCardType == "Iso14443aIntIndustry":
            if Iso14SelectFileCmdListLen is None:
                raise TypeError("missing a required argument: 'Iso14SelectFileCmdListLen'")
            if Iso14SelectFileCmdList is None:
                raise TypeError("missing a required argument: 'Iso14SelectFileCmdList'")
            if Iso14HasFileLen is None:
                raise TypeError("missing a required argument: 'Iso14HasFileLen'")
            if Iso14HasApduTimeout is None:
                raise TypeError("missing a required argument: 'Iso14HasApduTimeout'")
            _send_buffer.write(Iso14SelectFileCmdListLen.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(int(len(Iso14SelectFileCmdList)).to_bytes(1, byteorder='big'))
            for _Iso14SelectFileCmdList_Entry in Iso14SelectFileCmdList:
                _FileSpecifier, _Name, _Path, _ApduCommand = _Iso14SelectFileCmdList_Entry
                _send_buffer.write(VHL_Setup_FileSpecifier_Parser.as_value(_FileSpecifier).to_bytes(length=1, byteorder='big'))
                if _FileSpecifier == "SelectByName":
                    if _Name is None:
                        raise TypeError("missing a required argument: '_Name'")
                    _send_buffer.write(int(len(_Name)).to_bytes(1, byteorder='big'))
                    _send_buffer.write(_Name)
                if _FileSpecifier == "SelectByPath":
                    if _Path is None:
                        raise TypeError("missing a required argument: '_Path'")
                    _send_buffer.write(int(len(_Path)).to_bytes(1, byteorder='big'))
                    _send_buffer.write(_Path)
                if _FileSpecifier == "SelectByAPDU":
                    if _ApduCommand is None:
                        raise TypeError("missing a required argument: '_ApduCommand'")
                    _send_buffer.write(int(len(_ApduCommand)).to_bytes(1, byteorder='big'))
                    _send_buffer.write(_ApduCommand)
            _send_buffer.write(VHL_Setup_Iso14HasFileLen_Parser.as_value(Iso14HasFileLen).to_bytes(length=1, byteorder='big'))
            if Iso14HasFileLen == "Enabled":
                if Iso14FileLen is None:
                    raise TypeError("missing a required argument: 'Iso14FileLen'")
                _send_buffer.write(Iso14FileLen.to_bytes(length=4, byteorder='big'))
            _send_buffer.write(VHL_Setup_Iso14HasApduTimeout_Parser.as_value(Iso14HasApduTimeout).to_bytes(length=1, byteorder='big'))
            if Iso14HasApduTimeout == "Enabled":
                if Iso14ApduTimeout is None:
                    raise TypeError("missing a required argument: 'Iso14ApduTimeout'")
                _send_buffer.write(Iso14ApduTimeout.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, ConsideredCardType: Optional[CardType] = None, HasMifareKey: Optional[VHL_Setup_HasMifareKey] = None, MifareKey: Optional[bytes] = None, MifareHasAsKeyA: Optional[VHL_Setup_MifareHasAsKeyA] = None, MifareAsKeyA: Optional[bool] = None, MifareHasMadId: Optional[VHL_Setup_MifareHasMadId] = None, MifareMadId: Optional[int] = None, DesfireHasAppId: Optional[VHL_Setup_DesfireHasAppId] = None, DesfireAppId: Optional[int] = None, HasDesfireFileDesc: Optional[VHL_Setup_HasDesfireFileDesc] = None, DesfireFileDesc: Optional[Union[DesfireFileDescription, DesfireFileDescription_Dict]] = None, DesfireKey: Optional[bytes] = None, LegicSegmentInfo: Optional[bytes] = None, LegicHasEnStamp: Optional[VHL_Setup_LegicHasEnStamp] = None, LegicEnStamp: Optional[bool] = None, LegicHasAdrMode: Optional[VHL_Setup_LegicHasAdrMode] = None, LegicAdrMode: Optional[VHL_Setup_LegicAdrMode] = None, Iso15HasFirstBlock: Optional[VHL_Setup_Iso15HasFirstBlock] = None, Iso15FirstBlock: Optional[int] = None, Iso15HasBlockCount: Optional[VHL_Setup_Iso15HasBlockCount] = None, Iso15BlockCount: Optional[int] = None, Iso15HasOptionFlag: Optional[VHL_Setup_Iso15HasOptionFlag] = None, Iso15OptionFlag: Optional[VHL_Setup_Iso15OptionFlag] = None, Iso15HasBlockSize: Optional[VHL_Setup_Iso15HasBlockSize] = None, Iso15BlockSize: Optional[int] = None, Iso14SelectFileCmdListLen: Optional[int] = None, Iso14SelectFileCmdList: Optional[List[VHL_Setup_Iso14SelectFileCmdList_Entry]] = None, Iso14HasFileLen: Optional[VHL_Setup_Iso14HasFileLen] = None, Iso14FileLen: Optional[int] = None, Iso14HasApduTimeout: Optional[VHL_Setup_Iso14HasApduTimeout] = None, Iso14ApduTimeout: Optional[int] = None, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(ConsideredCardType=ConsideredCardType, HasMifareKey=HasMifareKey, MifareKey=MifareKey, MifareHasAsKeyA=MifareHasAsKeyA, MifareAsKeyA=MifareAsKeyA, MifareHasMadId=MifareHasMadId, MifareMadId=MifareMadId, DesfireHasAppId=DesfireHasAppId, DesfireAppId=DesfireAppId, HasDesfireFileDesc=HasDesfireFileDesc, DesfireFileDesc=DesfireFileDesc, DesfireKey=DesfireKey, LegicSegmentInfo=LegicSegmentInfo, LegicHasEnStamp=LegicHasEnStamp, LegicEnStamp=LegicEnStamp, LegicHasAdrMode=LegicHasAdrMode, LegicAdrMode=LegicAdrMode, Iso15HasFirstBlock=Iso15HasFirstBlock, Iso15FirstBlock=Iso15FirstBlock, Iso15HasBlockCount=Iso15HasBlockCount, Iso15BlockCount=Iso15BlockCount, Iso15HasOptionFlag=Iso15HasOptionFlag, Iso15OptionFlag=Iso15OptionFlag, Iso15HasBlockSize=Iso15HasBlockSize, Iso15BlockSize=Iso15BlockSize, Iso14SelectFileCmdListLen=Iso14SelectFileCmdListLen, Iso14SelectFileCmdList=Iso14SelectFileCmdList, Iso14HasFileLen=Iso14HasFileLen, Iso14FileLen=Iso14FileLen, Iso14HasApduTimeout=Iso14HasApduTimeout, Iso14ApduTimeout=Iso14ApduTimeout, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class VHL_CheckReconfigErr(Command):
    CommandGroupId = 0x01
    CommandId = 0x0B
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x01\x0B")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> bool:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Failed = bool(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Failed
class VHL_ExchangeLongAPDU(Command):
    CommandGroupId = 0x01
    CommandId = 0x0C
    def build_frame(self, AssumedCardType: CardType = "Default", Reset: bool = False, ContinueCmd: bool = False, *, Cmd: bytes, BrpTimeout: int = 60000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x01\x0C")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(CardType_Parser.as_value(AssumedCardType).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Reset.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(ContinueCmd.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(Cmd)).to_bytes(2, byteorder='big'))
        _send_buffer.write(Cmd)
        return _send_buffer.getvalue()
    def __call__(self, AssumedCardType: CardType = "Default", Reset: bool = False, ContinueCmd: bool = False, *, Cmd: bytes, BrpTimeout: int = 60000) -> VHL_ExchangeLongAPDU_Result:
        request_frame = self.build_frame(AssumedCardType=AssumedCardType, Reset=Reset, ContinueCmd=ContinueCmd, Cmd=Cmd, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ContinueResp = bool(safe_read_int_from_buffer(_recv_buffer, 1))
        _Resp_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _Resp = _recv_buffer.read(_Resp_len)
        if len(_Resp) != _Resp_len:
            raise PayloadTooShortError(_Resp_len - len(_Resp))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return VHL_ExchangeLongAPDU_Result(_ContinueResp, _Resp)
class VHL_GetFileInfo(Command):
    CommandGroupId = 0x01
    CommandId = 0x0D
    def build_frame(self, Id: int = 255, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x01\x0D")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Id.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Id: int = 255, BrpTimeout: int = 100) -> VHL_GetFileInfo_Result:
        request_frame = self.build_frame(Id=Id, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Len = safe_read_int_from_buffer(_recv_buffer, 2)
        _BlockSize = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return VHL_GetFileInfo_Result(_Len, _BlockSize)
class VHL_GetATR(Command):
    CommandGroupId = 0x01
    CommandId = 0x0E
    def build_frame(self, BrpTimeout: int = 1000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x01\x0E")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 1000) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ATR_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _ATR = _recv_buffer.read(_ATR_len)
        if len(_ATR) != _ATR_len:
            raise PayloadTooShortError(_ATR_len - len(_ATR))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ATR
class VHL_ResolveFilename(Command):
    CommandGroupId = 0x01
    CommandId = 0x10
    def build_frame(self, FileName: str, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x01\x10")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(int(len(FileName)).to_bytes(1, byteorder='big'))
        _send_buffer.write(FileName.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, FileName: str, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(FileName=FileName, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Id = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Id
class VHL_GetCardType(Command):
    CommandGroupId = 0x01
    CommandId = 0x11
    def build_frame(self, BrpTimeout: int = 3000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x01\x11")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 3000) -> CardType:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _SelectedCardType = CardType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _SelectedCardType
class PublicCommands(FrameProcessor):
    @property
    def AR_SetMode(self) -> AR_SetMode:
        """
        This command controls Autoread mode at runtime. Usually, the Autoread subsystem will be stared at boot time if the reader is  configured to work autonomously. However, you can still enable and disable Autoread at runtime. This is e.g. needed if you use [ VHL & Autoread](https://docs.baltech.de/developers/map-vhl-autoread.html) in combination, so you can interrupt Autoread to run VHL commands.
        
        **_AR.SetMode_ automatically empties the reader's message buffer. This ensures that the next AR.GetMessage you run doesn't return "old" data from a card detected before running _AR.SetMode_ .**
        """
        return AR_SetMode(self)
    @property
    def AR_GetMessage(self) -> AR_GetMessage:
        """
        This command checks if a card has been presented to the reader since the last _AR.GetMessage_ execution. If yes, the card identification will be returned in _MsgData_. If no, the AR.ErrNoMessage status code will be returned. 
        
        Apart from card identifications, some readers support additional types of messages, e.g. PINs entered via the keyboard. This information is returned in _MsgType_. 
        
        **Read results are buffered in the reader's memory for 5 seconds, i.e. that's the time frame you have to execute this command.**
        """
        return AR_GetMessage(self)
    @property
    def AR_RunScript(self) -> AR_RunScript:
        """
        This command runs a BaltechScript. This is a small sequence of instructions for the reader to execute. Typically, it's used to control reader feedback, i.e. LEDs, beeper, relay, and other I/O ports when you have highly specific requirements and/or want to store the script on the reader. 
        
        **Instead of _AR.RunScript_ , we recommend the UI command set as it's easier to implement and sufficient for the majority of use cases.**
        
        ## Script structure
        
        A script consists of the following parts:
        
          * _Frame value_ (e.g. 0x01 for Enable)
          * _Port_ (e.g. 0x00 for the green LED)
          * _Parameters_ if applicable (e.g. number of repetitions and delay after each change of state)
        
        
        
        ## Examples
        
        Here are a few examples of how to create a script. We'll use the following script commands as they're the most important ones: 
        
          * Enable
          * Disable
          * Toggle
          * ToggleInverted
        
        
        
        ### Single script to control 1 port
        
        In this example, we'll switch on the green LED permanently. To do so, we need to run the Enable script as follows:
        
        `01 00`
        
          * _01_ is the frame value for _Enable_.
          * _00_ is the parameter value for the _green LED_.
        
        
        
        ### Sequence of scripts
        
        You can run a sequence of scripts in parallel by concatenating them.
        
        #### Simultaneous feedback sequence
        
        In this example, we'll switch on the green LED permanently. At the same time, we have the beeper beep 3 times for 200 ms. To do so, we extend the _Enable_ script from the above example with a Toggle script:
        
        `01 00 03 02 03 02`
        
        The _Toggle_ script in this sequence is composed as follows:
        
          * _03_ is the frame value for _Toggle_.
          * _02_ is the parameter for the _beeper_.
          * _03_ is the _repeat count_.
          * _02_ is the _delay_ : 
        
        The unit of this value is 1/10 sec, i.e. it's 200 ms in this example. This time period applies to the length of the beep and the delay afterwards, i.e. you have a duration of 2x200 ms per beep and a duration of 1200 ms for the entire sequence.
        
        
        
        
        #### Consecutive feedback sequence
        
        Concatenated scripts are always executed in parallel. However, you can still produce a consecutive feedback sequence using ToggleInverted and an appropriate delay. In this example, we'll use the toggle script from the above example to have the beeper beep 3 times for 200 ms. After the third beep, the red LED is enabled:
        
        `03 02 03 02 06 01 01 0C`
        
        The _ToggleInverted_ script in this sequence is composed as follows:
        
          * _06_ is the frame value for _ToggleInverted_.
          * _01_ is the parameter for the _red LED_.
          * _01_ is the _repeat count_.
          * _0C_ is the _delay_ : 
        
        The unit of this value is 1/10 sec, i.e. it's 1200 ms in this example. This corresponds to the duration of the _Toggle_ script that runs in parallel (see also previous example). Thus the LED (controlled by the _ToggleInverted_ script) turns on after the beeper sequence (controlled by the _Toggle_ script) is completed.
        """
        return AR_RunScript(self)
    @property
    def AR_RestrictScanCardFamilies(self) -> AR_RestrictScanCardFamilies:
        """
        This command restricts the card families that Autoread will scan for. By selecting only the required card families, the detection time on card presentation will be minimized.
        """
        return AR_RestrictScanCardFamilies(self)
    @property
    def BlePeriph_DefineService(self) -> BlePeriph_DefineService:
        """
        This command registers a new BLE service. When a BLE Central tries to discover services, this service will be amongst the available ones. 
        
        If currently enabled, this method disables BLE implicitly. To start the service, call BlePeriph.Enable(true) afterwards. 
        
        **A maximum of 5 characteristics may be defined for the BLE service. The total size of all characteristics may not exceed 1536 bytes.**
        """
        return BlePeriph_DefineService(self)
    @property
    def BlePeriph_Enable(self) -> BlePeriph_Enable:
        """
        This command starts/stops the advertisement of the reader as a BLE Peripheral, so you can respond to connection and other requests.
        """
        return BlePeriph_Enable(self)
    @property
    def BlePeriph_SetAdvertisingData(self) -> BlePeriph_SetAdvertisingData:
        """
        This command defines the data to be advertised by the reader. If advertisement is currently enabled, the new data will be used immediately.
        """
        return BlePeriph_SetAdvertisingData(self)
    @property
    def BlePeriph_WriteCharacteristic(self) -> BlePeriph_WriteCharacteristic:
        """
        This command changes the value of a characteristic. All future reads from the Central or BlePeriph.ReadCharacteristic from the BRP host will return the new value. 
        
        If the Central has registered a notification/indication for this characteristic, the reader will automatically send a corresponding message to the Central. 
        
        **A characteristic can only be written when BLE is enabled .**
        """
        return BlePeriph_WriteCharacteristic(self)
    @property
    def BlePeriph_ReadCharacteristic(self) -> BlePeriph_ReadCharacteristic:
        """
        This command retrieves the current value of a characteristic. A characteristic will be initialized to _00 00 ... 00_ when calling BlePeriph.Enable and will be modified by either the BRP host (BlePeriph.WriteCharacteristic) or the BLE Central (via a write to the characteristic). 
        
        **A characteristic can only be read when BLE is enabled .**
        """
        return BlePeriph_ReadCharacteristic(self)
    @property
    def BlePeriph_GetEvents(self) -> BlePeriph_GetEvents:
        """
        This command returns a bitmask of all events that have occurred since the last call of _BlePeriph.GetEvents_.
        """
        return BlePeriph_GetEvents(self)
    @property
    def BlePeriph_IsConnected(self) -> BlePeriph_IsConnected:
        """
        This command is used to check the current connection status. If connected, it returns the device address of the connected BLE central.
        """
        return BlePeriph_IsConnected(self)
    @property
    def BlePeriph_GetRSSI(self) -> BlePeriph_GetRSSI:
        """
        This command returns the RSSI value of the connected BLE Central.
        """
        return BlePeriph_GetRSSI(self)
    @property
    def BlePeriph_CloseConnection(self) -> BlePeriph_CloseConnection:
        """
        This command closes the active connection with a BLE Central.
        """
        return BlePeriph_CloseConnection(self)
    @property
    def Crypto_EncryptBlock(self) -> Crypto_EncryptBlock:
        """
        This command encrypts an 8-Byte data block given in the _Block_ parameter using the SkipJack algorithm. If _KeyIndex_ is set to 0x00, _KeyValue_ will be used as encryption key. Otherwise, _KeyIndex_ is interpreted as the index of the corresponding entry in the internal key list. _KeyIndex_ = 0x01 denotes configuration value 0x81, _KeyIndex_ = 0x02 denotes configuration value 0x82, etc.
        """
        return Crypto_EncryptBlock(self)
    @property
    def Crypto_DecryptBlock(self) -> Crypto_DecryptBlock:
        """
        This command decrypts an 8-Byte data block given in the _Block_ parameter using the SkipJack algorithm. If _KeyIndex_ is set to 0x00, _KeyValue_ will be used as encryption key. Otherwise, _KeyIndex_ is interpreted as the index of the corresponding entry in the internal key list. _KeyIndex_ = 0x01 denotes configuration value 0x81, _KeyIndex_ = 0x02 denotes configuration value 0x82, etc.
        """
        return Crypto_DecryptBlock(self)
    @property
    def Crypto_EncryptBuffer(self) -> Crypto_EncryptBuffer:
        """
        This command encrypts a variable length buffer given in the _Buffer_ parameter using the SkipJack algorithm. If _KeyIndex_ is set to 0x00, _KeyValue_ will be used as encryption key. Otherwise, _KeyIndex_ is interpreted as the index of the corresponding entry in the internal key list. _KeyIndex_ = 0x01 denotes configuration value 0x81, _KeyIndex_ = 0x02 denotes configuration value 0x82, etc. 
        
        The value returned in the _InitialVector_ variable is necessary for CBC encryption. If large amounts of data must be encrypted, this command has to be called more than once. In this case, the returned _InitialVector_ variable of call _i_ of the command has to be specified as the _InitialVector_ parameter of call _i+1_.
        """
        return Crypto_EncryptBuffer(self)
    @property
    def Crypto_DecryptBuffer(self) -> Crypto_DecryptBuffer:
        """
        This command decrypts a variable length buffer given in the _Buffer_ parameter using the SkipJack algorithm. If _KeyIndex_ is set to 0x00, _KeyValue_ will be used as encryption key. Otherwise, _KeyIndex_ is interpreted as the index of the corresponding entry in the internal key list. _KeyIndex_ = 0x01 denotes configuration value 0x81, _KeyIndex_ = 0x02 denotes configuration value 0x82, etc. 
        
        The value returned in the _InitialVector_ variable is necessary for CBC encryption. If large amounts of data must be encrypted, this command has to be called more than once. In this case, the returned _InitialVector_ variable of call _i_ of the command has to be specified as the _InitialVector_ parameter of call _i+1_.
        """
        return Crypto_DecryptBuffer(self)
    @property
    def Crypto_BalKeyEncryptBuffer(self) -> Crypto_BalKeyEncryptBuffer:
        """
        This command is a special version of the Crypto.EncryptBuffer command which always uses a customer key to encrypt a buffer of data and inserts a Crypto-Key at a desired position before encryption. 
        
        The key to insert has to be specified in the _EmbeddedKeyIndex_ parameter. In this case, the 10 Byte Key will, on the one hand, replace the data at the _EmbeddedKeyPos_ position, and on the other hand, replace the last two Bytes by a CRC (16-bit, 8404B, MSB encoded) that is generated on the data contained in _Buffer_.
        """
        return Crypto_BalKeyEncryptBuffer(self)
    @property
    def Crypto_GetKeySig(self) -> Crypto_GetKeySig:
        """
        Returns a signature of the ConfigurationKey to identify the MasterCard needed for this reader.
        """
        return Crypto_GetKeySig(self)
    @property
    def Crypto_CopyConfigKey(self) -> Crypto_CopyConfigKey:
        """
        Copies the configuration card key 0x0202/0x85 (_Device/Run/ConfigCardEncryptKey_) to the _Custom/Crypto/Key[x]_ area of the Baltech reader's configuration, where _x_ is the index of the target key, specified in the _KeyIndex_ parameter. 
        
        When a key does not exist, a Baltech standard key is used instead.
        """
        return Crypto_CopyConfigKey(self)
    @property
    def Desfire_ExecCommand(self) -> Desfire_ExecCommand:
        """
        Generic command to communicate to a DESFire card. Depending on the value of the _CryptoMode_ parameter, data will be transmitted plain, MACed or encrypted. 
        
        The DESFire command frame has to be split into two parts, header and data. The data block will be encrypted whereas the header block is left unencrypted. 
        
        Example: in the Desfire _ChangeKeySettings_ command, the header is empty. The encrypted key settings will be transferred in the data block.
        """
        return Desfire_ExecCommand(self)
    @property
    def Desfire_Authenticate(self) -> Desfire_Authenticate:
        """
        This command authenticates a card with the reader. All authentication modes of DESFire cards are supported. Subsequent commands, such as Desfire.ExecCommand, take the authentication mode into account when communicating with a card. 
        
        The key used for authentication is specified in the Device / CryptoKey key of the reader's configuration.
        """
        return Desfire_Authenticate(self)
    @property
    def Desfire_AuthExtKey(self) -> Desfire_AuthExtKey:
        """
        This command authenticates a card with the reader, similarly to the Desfire.Authenticate command, but uses an external authentication key provided as a parameter. Allowed are keys with a length of 8, 16 and 24 Byte. 
        
          * 8 Byte keys are always DES keys. 
          * 16 Byte keys can be DES and AES keys. 
          * 24 Byte keys are only used for 3K3DES encryption.
        """
        return Desfire_AuthExtKey(self)
    @property
    def Desfire_SelectApplication(self) -> Desfire_SelectApplication:
        """
        Selects an application of the DESFire card. Has to be called before any file specific command.
        """
        return Desfire_SelectApplication(self)
    @property
    def Desfire_ReadData(self) -> Desfire_ReadData:
        """
        Reads data from a Standard or Backup data file.
        """
        return Desfire_ReadData(self)
    @property
    def Desfire_WriteData(self) -> Desfire_WriteData:
        """
        Writes data to a Standard or a Backup data file.
        """
        return Desfire_WriteData(self)
    @property
    def Desfire_ChangeExtKey(self) -> Desfire_ChangeExtKey:
        """
        This command allows to change any key stored on the card. 
        
        The key length has to be set according to the desired encryption algorithm: 
        
          * DES encryption uses keys of 8 Byte. 
          * 3DES and AES encryption uses keys of 16 Byte. 
          * 3K3DES encryption uses keys of 24 Byte.
        """
        return Desfire_ChangeExtKey(self)
    @property
    def Desfire_ChangeKey(self) -> Desfire_ChangeKey:
        """
        Modifies a DESFire card key defined in the SAM or crypto memory.
        """
        return Desfire_ChangeKey(self)
    @property
    def Desfire_SetFraming(self) -> Desfire_SetFraming:
        """
        This command switches the DESFire communication protocol mode to use (std, iso_wrapping). Please refer to the [DESFire specification](http://www.nxp.com/products/identification-and-security/smart-card-ics/mifare-ics/mifare-desfire:MC_53450) for more information.
        """
        return Desfire_SetFraming(self)
    @property
    def Desfire_ResetAuthentication(self) -> Desfire_ResetAuthentication:
        """
        This command resets the reader's authentication state until the next call of the Desfire.Authenticate or Desfire.AuthExtKey commands. All following DESFire commands will be sent and received in plain text without MAC. 
        
        It is not possible to run the Desfire.ExecCommand with _CryptoMode_ set to any other value than PLAIN after the execution of this command, until the card is reauthenticated.
        """
        return Desfire_ResetAuthentication(self)
    @property
    def Desfire_CreateDam(self) -> Desfire_CreateDam:
        """
        This command creates a delegated application
        """
        return Desfire_CreateDam(self)
    @property
    def Desfire_GetOriginalitySignature(self) -> Desfire_GetOriginalitySignature:
        """
        This command returns the NXP originality signature of a desfire card.
        """
        return Desfire_GetOriginalitySignature(self)
    @property
    def Desfire_VirtualCardSelect(self) -> Desfire_VirtualCardSelect:
        """
        This command selects a virtual card
        """
        return Desfire_VirtualCardSelect(self)
    @property
    def Desfire_ProxCheck(self) -> Desfire_ProxCheck:
        """
        This command executes a proximity check of the card
        """
        return Desfire_ProxCheck(self)
    @property
    def Desfire_GetDfNames(self) -> Desfire_GetDfNames:
        """
        This command returns the application identifiers together with file IDs and (optionally) DF names of all applications with ISO7816-4 support.
        """
        return Desfire_GetDfNames(self)
    @property
    def Felica_GenericCmd(self) -> Felica_GenericCmd:
        """
        Generic command for FeliCa.
        """
        return Felica_GenericCmd(self)
    @property
    def Felica_SetUID2(self) -> Felica_SetUID2:
        """
        Sets UID2 used by generic command.
        """
        return Felica_SetUID2(self)
    @property
    def Felica_Request(self) -> Felica_Request:
        """
        Polls for tags with number of time slots, returns NFCID2 list of detected tags (maximum 16 / length 8).
        """
        return Felica_Request(self)
    @property
    def Iso14a_Select(self) -> Iso14a_Select:
        """
        This command Performs the anti-collision and selection sequence of a PICC in the field of the antenna. The PICC has to be in ready state (see Iso14a.Request command) for this command to succeed. 
        
        PICCs exist with three different lengths of serial numbers: 
        
          * Four bytes (single size) 
          * Seven bytes (double size) 
          * Ten bytes (triple size) 
        
        
        
        In manual anti-collision mode, the Iso14a.Select command can only return 4 Bytes of the serial number at a time, in the _Serial_ returned variable. Iso14a.Select therefore needs to be called one, two or three times to read serial numbers of single, double or triple size, respectively. Each call of the Iso14a.Select command is associated to a specific _cascade level_ , specified by the _CascLev_ parameter. The first call of Iso14a.Select is associated to cascade level 1, the second call to cascade level 2, and the third call to cascade level 3. 
        
        The fact that a serial number has not been completely returned by the Iso14a.Select command is indicated by a _cascade tag_ (CT, 0x88), in the first byte of the returned _Serial_ variable. In this case, the Iso14a.Select command needs to be called with the next higher cascade level (for instance _CascLev_ = 2 if Iso14a.Select was called with _CascLev_ = 1). The complete serial number of a PICC consists then of the concatenation of the (up to 3) returned values of _Serial_ , after removing the cascade tags(s) from these values. A completed selection flow is signaled by the _Casc_ flag in the _SAK_ byte and by the missing cascade tag in the returned serial number. 
        
        Using the _PreSelSer_ parameter, the serial number (or an initial part of it) of a given PICC can be specified to be selected within a specific cascade level (up to four bytes) in order to speed up the anti-collision sequence. The CT must be included in _PreSelSer_ if it belongs to non-final parts of the serial number. 
        
        For convenience reasons, an automatic anti-collision mode has been implemented. This mode can be activated by setting the _CascLev_ parameter to 0. In this case, the PICC can be selected with a single call of Iso14a.Select and the returned _Serial_ variable contains the complete serial number, without cascade tag(s). 
        
        **In this case, cascade tags must be manually added to the _PreSelSer_ parameter to be able to use the preselection feature.**
        
        This command combines the commands ANTICOLL and SELECT as specified in the ISO 14443-3 (Type A) standard.
        """
        return Iso14a_Select(self)
    @property
    def Iso14a_Halt(self) -> Iso14a_Halt:
        """
        Switch PICC to halt state. 
        
        The PICC has to be selected before it may be switched to halt state. 
        
        **This command only works for PICCs that are, though in active state, not in ISO 14443-4 mode. For such PICCs, the Iso14L4.Deselect command should be used instead.**
        """
        return Iso14a_Halt(self)
    @property
    def Iso14a_RequestATS(self) -> Iso14a_RequestATS:
        """
        This command requests the Answer to Select (ATS) of the PICC according to the ISO 14443-3 (Type A) standard. 
        
        RequestATS has to be called by the PCD (reader) directly after a successful call of the Iso14a.Select command if 
        
          1. The selected PICC is ISO 14443-4 compliant (according to _SAK_ byte) and 
          2. communication as specified by ISO 14443-4 shall be performed via the Iso14L4.ExchangeAPDU command. 
        
        
        
        Since it is possible to keep several PICCs in active state at the same time according to ISO 14443-4, a unique CID has to be assigned to each of them. However, if you only want to communicate with a single label at a given time, the value 0 should be assigned to the _CID_ variable. In this case, it is possible to call the Iso14L4.ExchangeAPDU command without bothering about CIDs. 
        
        Please refer to the Iso14a.PerformPPS and Iso14L4.ExchangeAPDU command descriptions for more information about frame sizes and timing issues. 
        
        After successful execution of this command, the communication parameters can be tuned with the Iso14a.PerformPPS command.
        """
        return Iso14a_RequestATS(self)
    @property
    def Iso14a_PerformPPS(self) -> Iso14a_PerformPPS:
        """
        This command sets up the communication parameters for ISO 14443-4 commands. 
        
        Iso14a.PerformPPS may be used to change the default communication parameters in order to achieve faster HF communication. This command has to be executed directly after the Iso14a.RequestATS command but it is not necessary to execute it at all. 
        
        This command covers the PPS command as specified by ISO 14443-3 (type A). 
        
        The _PPS1_ bit mask is only sent to the PICC if DSI or DRI differ from the current settings.
        """
        return Iso14a_PerformPPS(self)
    @property
    def Iso14a_Request(self) -> Iso14a_Request:
        """
        This commands scans for ISO 14443-3 (Type A) compliant PICCs in the field of the antenna. 
        
        If the _ReqAll_ parameter flag is set, both PICCs in idle state and PICCs in halt state will be switched to ready state. If this flag is not set, only PICCs in idle state will be switched to ready state. 
        
        **Only PICCs in ready state may be selected via the Iso14a.Select command.**
        
        This command covers the commands REQA and WAKE-UP as specified by the ISO 14443-3 standard.
        """
        return Iso14a_Request(self)
    @property
    def Iso14a_RequestVasup(self) -> Iso14a_RequestVasup:
        """
        This commands scans for ISO 14443-3 (Type A) compliant PICCs in the field of the antenna and enhances polling with the VASUP-A command (required for ECP support). 
        
        If the _ReqAll_ parameter flag is set, both PICCs in idle state and PICCs in halt state will be switched to ready state. If this flag is not set, only PICCs in idle state will be switched to ready state. 
        
        **Only PICCs in ready state may be selected via the Iso14a.Select command.**
        
        This command covers the commands REQA and WAKE-UP as specified by the ISO 14443-3 standard.
        """
        return Iso14a_RequestVasup(self)
    @property
    def Iso14a_TransparentCmd(self) -> Iso14a_TransparentCmd:
        """
        This command sends a data stream to a card and returns the communication status and the received card data stream to the host.
        """
        return Iso14a_TransparentCmd(self)
    @property
    def Iso14b_Request(self) -> Iso14b_Request:
        """
        Scan for ISO 14443 (Type B) compliant PICCs in the field of the antenna. 
        
        If a collision occurred in at least one time slot (signaled by status code ISO14B_COLLISION_ERR), this command needs to be called again with an increased number of time slots so that more PICCs can be detected. 
        
        The ISO14B_MEM_ERR status code signals that more PICCs are available than can be handled with the buffer provided by the reader for BRP communication. The Iso14b.Halt command can be used to disable undesired PICCs before calling the Iso14b.Request command again. 
        
        PICCs that have been returned by this command may subsequently be switched to the active state via the Iso14b.Attrib command.
        """
        return Iso14b_Request(self)
    @property
    def Iso14b_Attrib(self) -> Iso14b_Attrib:
        """
        Select the PICC with given _PUPI_ serial number for further communication. The desired PICC must have been reported by the Iso14b.Request command before. 
        
        The parameters given in the _Param_ bit mask have to match both the supported communication parameters of the reader and of the current PICC, according to the _ProtInfo_ bit mask returned by the Iso14b.Request command. These parameters will be applied for all ISO 14443-4 APDUs that will be exchanged via the Iso14L4.ExchangeAPDU command. 
        
        Furthermore, a unique communication channel ID (CID) has to be assigned, which identifies the PICC and which will also be needed by the ISO 14443-4 commands. 
        
        Normally, there may be up to 14 PICCs in active state at the same time and each PICC will be uniquely identified by its CID. However, there are exist PICCs which do no support being assigned a CID. Only one of these PICCs may be in active state at the same time (along with other PICCs supporting the CID feature). The same restriction also holds for PICCs which are assigned a CID of 0x00 with this command.
        """
        return Iso14b_Attrib(self)
    @property
    def Iso14b_Halt(self) -> Iso14b_Halt:
        """
        Switch the PICC with the given _PUPI_ serial number into halt state, so that it will not answer to further Iso14b.Request commands, except when the _ReqAll_ flag parameter of the Iso14b.Request command is set. The memory occupied by this PICC's information will also be freed, which makes it is available for future calls of the Iso14b.Request command. Use this command in order to deactivate some of the PICCs in case the Iso14b.ErrMem status code has been returned by the last call of Iso14b.Request. 
        
        **This command only works for PICCs in ready state. For PICCs in active state, the Iso14L4.Deselect command should be used instead.**
        """
        return Iso14b_Halt(self)
    @property
    def Iso14b_TransparentCmd(self) -> Iso14b_TransparentCmd:
        """
        This command sends a data stream to a card and returns the communication status and the received card data stream to the host.
        """
        return Iso14b_TransparentCmd(self)
    @property
    def Iso14L4_SetupAPDU(self) -> Iso14L4_SetupAPDU:
        """
        Setup communication parameters and select a certain PICC for APDU exchange. The chosen settings will be applied to all subsequent calls of the Iso14L4.ExchangeAPDU and Iso14L4.Deselect commands. 
        
        The _FrameParam_ and _Bitrate_ parameters have to be chosen according to the PICC's capabilities. 
        
        In some cases, the _CID_ of the label to select has to be passed as a parameter. This is the case if the label supports the feature of being assigned a CID, and if a CID value has been previously assigned to the PICC using the Iso14a.RequestATS command (for ISO 14443 Type A labels) or by the or the Iso14b.Attrib command (for ISO 14443 Type B labels). Otherwise, the CID functionality should be disabled, by clearing the _EnCID_ flag. 
        
        PICCs which do not support a CID (for which the returned _CID_ value from the Iso14a.RequestATS command, or from the Iso14b.Request command, is 0x00) will only respond to the Iso14L4.ExchangeAPDU and Iso14L4.Deselect commands if the CID functionality is disabled. 
        
        A PICC, which supports a CID, will 
        
          1. respond to the Iso14L4.ExchangeAPDU and Iso14L4.Deselect commands only if the CID functionality is enabled and if the specified CID value matches the PICC's own CID value. 
          2. ignore the Iso14L4.ExchangeAPDU and Iso14L4.Deselect commands if a different CID value is specified. 
          3. also respond to Iso14L4.ExchangeAPDU and Iso14L4.Deselect commands with a disabled CID functionality, if its own CID value is 0. 
        
        
        
        The _NAD_ parameter may be used to select a certain logical application (node) on the target PICC, if these are supported by this PICC.
        """
        return Iso14L4_SetupAPDU(self)
    @property
    def Iso14L4_ExchangeAPDU(self) -> Iso14L4_ExchangeAPDU:
        """
        This command allows to transmit/receive _Application Protocol Data Units_ (APDUs) according to the ISO 14443-4 standard. 
        
        The Iso14L4.SetupAPDU command must be run before Iso14L4.ExchangeAPDU in order to select the required PICC and set the appropriate communication parameters. If an error occurs during the execution of Iso14L4.ExchangeAPDU, it is mandatory to reselect the PICC. The Iso14L4.SetupAPDU command can be called anew if communication parameters with the PICC should be changed.
        """
        return Iso14L4_ExchangeAPDU(self)
    @property
    def Iso14L4_Deselect(self) -> Iso14L4_Deselect:
        """
        This command switches one or multiple PICC(s) to halt state. 
        
        **This command only works for certain types of PICCs (see command group description above). For other types of PICCs, the Iso14a.Halt command or the Iso14b.Halt command should be used instead.**
        """
        return Iso14L4_Deselect(self)
    @property
    def Iso15_SetParam(self) -> Iso15_SetParam:
        """
        This command configures the reader chip. If a parameter is not supported, a status message is returned.
        """
        return Iso15_SetParam(self)
    @property
    def Iso15_GetParam(self) -> Iso15_GetParam:
        """
        This command reads the configuration of the reader chip.
        """
        return Iso15_GetParam(self)
    @property
    def Iso15_GetUIDList(self) -> Iso15_GetUIDList:
        """
        This command scans for ISO 15693 labels which are in the field of the readers antenna and which are not in _quiet-state_. The list of UIDs is returned in the response frame. Furthermore, the DSFID is send back if the _DSFID_ flag in _Mode_ is set. 
        
        If the _More_ response value is different from zero, there are more tags to scan, and Iso15.GetUIDList has to be called again with the _NextBlock_ flag set to get the rest of the labels which have not been transferred within this frame. 
        
        To optimize the label scanning time, the reader should be told if there are many labels (more than 2 or 3) in the antenna's field. In this case, the _En16Slots_ flag should be set. This bit will tell Iso15.GetUIDList to send the inventory with 16 time slots instead of one. 
        
        Furthermore the _Autoquiet_ flag can be set to put every label into _quiet-state_ after a successful scan. This will result in a kind of incremental behaviour from Iso15.GetUIDList since after the first successful Iso15.GetUIDList call, all following Iso15.GetUIDList calls will only return labels which came into the field of the antenna after the last call.
        """
        return Iso15_GetUIDList(self)
    @property
    def Iso15_SetMode(self) -> Iso15_SetMode:
        """
        This command configures the mode to address a label. 
        
          * _Unaddressed mode_ : The following label commands are sent to the label without an UID (broadcast). This implies that not more than one label should be in the antenna's field because every label is responding in this mode which would result in a collision. 
          * _Addressed mode_ : The following label commands are sent to the label including the UID given in _UID_. To talk to one distinct label among others, the Iso15.SetMode command has to be called with a value of 0x01 in the _Mode_ byte before execution of other label commands. 
          * _Selected mode_ : Useful if a lot of operations need to be performed with the same label since the UID is not transferred to the label over and over again. A Iso15.SetMode command with _Mode_ 0x02 implicitly executes a _Select_ command with the corresponding UID as parameter (see the [ISO 1593-3 standard](http://www.iso.org/iso/catalogue_detail.htm?csnumber=43467) for details). A previously selected label will be deselected automatically if a Iso15.SetMode command with Mode 0x02 and a different UID or a Iso15.SetMode command with Mode unequal 0x02 is executed. If a Iso15.SetMode command with Mode 0x02 fails, the reader remains in the unaddressed mode. 
        
        
        
        **Please be aware that not all label types support all modes.**
        """
        return Iso15_SetMode(self)
    @property
    def Iso15_StayQuiet(self) -> Iso15_StayQuiet:
        """
        This command puts a label into the _quiet-state_. This command shall always be executed in addressed mode (see the Iso15.SetMode command). After executing this command, the label will not response to any Iso15.GetUIDList command until its state machine is reset (either by a physical HF-reset (i.e. switching off the field of the antenna or taking the label out of the field) or by executing the commands Iso15.ResetToReady or Iso15.SetMode (using selected mode).
        """
        return Iso15_StayQuiet(self)
    @property
    def Iso15_LockBlock(self) -> Iso15_LockBlock:
        """
        This command permanently locks the block with ID _BlockID_. 
        
        **This command is an _optional command_ .**
        """
        return Iso15_LockBlock(self)
    @property
    def Iso15_ResetToReady(self) -> Iso15_ResetToReady:
        """
        This command puts a label into _ready-state_ , according to the VICC state transition diagram from the [ISO 15693-3 specification](http://www.iso.org/iso/catalogue_detail.htm?csnumber=43467). 
        
        **This command is an _optional command_ .**
        """
        return Iso15_ResetToReady(self)
    @property
    def Iso15_WriteAFI(self) -> Iso15_WriteAFI:
        """
        This commands writes the _AFI_ value into the label's memory. 
        
        **This commands is an _optional command_ .**
        """
        return Iso15_WriteAFI(self)
    @property
    def Iso15_LockAFI(self) -> Iso15_LockAFI:
        """
        This command locks the _AFI_ value permanently into the reader's memory. 
        
        **This commands is an _optional command_ .**
        """
        return Iso15_LockAFI(self)
    @property
    def Iso15_WriteDSFID(self) -> Iso15_WriteDSFID:
        """
        This commands writes the _DSFID_ value into the label's memory. 
        
        **This commands is an _optional command_ .**
        """
        return Iso15_WriteDSFID(self)
    @property
    def Iso15_LockDSFID(self) -> Iso15_LockDSFID:
        """
        This command locks the _DSFID_ value permanently into the reader's memory. 
        
        **This commands is an _optional command_ .**
        """
        return Iso15_LockDSFID(self)
    @property
    def Iso15_GetSystemInformation(self) -> Iso15_GetSystemInformation:
        """
        This command gets the system information of a VICC. 
        
        **This commands is an _optional command_ .**
        """
        return Iso15_GetSystemInformation(self)
    @property
    def Iso15_GetSecurityStatus(self) -> Iso15_GetSecurityStatus:
        """
        This command retrieves the block security status of a label. 
        
        **This command is an _optional command_ .**
        """
        return Iso15_GetSecurityStatus(self)
    @property
    def Iso15_CustomCommand(self) -> Iso15_CustomCommand:
        """
        This command executes any ISO 15693 manufacturer proprietary commands, so-called _custom-commands_. 
        
        By default, the same label is addressed as in the last regular ISO 15693 command.
        """
        return Iso15_CustomCommand(self)
    @property
    def Iso15_ReadSingleBlock(self) -> Iso15_ReadSingleBlock:
        """
        This command reads a single block from a label. 
        
        This command implements the "read single block" optional command from the [ISO 15693-3 specification](http://www.iso.org/iso/catalogue_detail.htm?csnumber=43467).
        """
        return Iso15_ReadSingleBlock(self)
    @property
    def Iso15_WriteSingleBlock(self) -> Iso15_WriteSingleBlock:
        """
        This command writes a single block to a label. 
        
        This command implements the "write single block" optional command from the [ISO 15693-3 specification](http://www.iso.org/iso/catalogue_detail.htm?csnumber=43467).
        """
        return Iso15_WriteSingleBlock(self)
    @property
    def Iso15_WriteMultipleBlocks(self) -> Iso15_WriteMultipleBlocks:
        """
        Sends the "WriteMultipleBlocks" to the card to store the data passed in _WriteBlocks_ to the data blocks of the presented card starting at block with id _Blockid_. For more information about this command please refer to the [ISO 15693-3 specification](http://www.iso.org/iso/catalogue_detail.htm?csnumber=43467).
        """
        return Iso15_WriteMultipleBlocks(self)
    @property
    def Iso15_ReadMultipleBlocks(self) -> Iso15_ReadMultipleBlocks:
        """
        This command reads one or multiple blocks from a label. 
        
        This command implements the (optional) "ReadMultipleBlocks" command from the [ISO 15693-3 specification](http://www.iso.org/iso/catalogue_detail.htm?csnumber=43467).
        """
        return Iso15_ReadMultipleBlocks(self)
    @property
    def Iso15_TransparentCmd(self) -> Iso15_TransparentCmd:
        """
        This command sends a data stream to a label and returns the communication status and the received label data stream to the host. If no bytes are sent and the CRC check is disabled, only an EOF is sent to the label. After execution of this command, the _Mode_ parameter is reset to default. 
        
        **Please be aware that the _flag_ Byte (see the[ ISO 15693-3 specification](http://www.iso.org/iso/catalogue_detail.htm?csnumber=43467) , 2001 p.9) is not generated by the reader. This flag has to be transmitted as part of the _data_ string.**
        """
        return Iso15_TransparentCmd(self)
    @property
    def Iso78_OpenSam(self) -> Iso78_OpenSam:
        """
        This command sets up a communication channel to a Secure Access Module (SAM) inserted into the reader. To select the SAM, you specify it using the _LID_ parameter as described below. Once you've run this command successfully, you can run Iso78.ExchangeApdu to communicate with the SAM. 
        
        To close the communication channel after data exchange, run Iso78.CloseSam.
        """
        return Iso78_OpenSam(self)
    @property
    def Iso78_CloseSam(self) -> Iso78_CloseSam:
        """
        This command closes a communication channel previously opened via the Iso78.OpenSam command. It is recommended to call this command before physically removing the SAM from its slot since it also powers down the SAM module.
        """
        return Iso78_CloseSam(self)
    @property
    def Iso78_ExchangeApdu(self) -> Iso78_ExchangeApdu:
        """
        This command sends an APDU command on the currently selected and opened SAM module using a logical ID. Please note that the complete APDU command including the CLA, INS, P1, P2, Lc and Le values need part of the _SendData_ parameter.
        """
        return Iso78_ExchangeApdu(self)
    @property
    def Lic_GetLicenses(self) -> Lic_GetLicenses:
        """
        This command retrieves a bit mask of the licenses that are activated on the reader.
        """
        return Lic_GetLicenses(self)
    @property
    def Lic_ReadLicCard(self) -> Lic_ReadLicCard:
        """
        This command reads and evaluates a LicenseCard. 
        
        A license is debited from the card and activated on the reader if the following applies: 
        
          * The presented card is a valid LicenseCard.
          * This license type is supported by the reader.
          * A license of this type is not yet activated on the reader.
        """
        return Lic_ReadLicCard(self)
    @property
    def Main_Bf3UploadStart(self) -> Main_Bf3UploadStart:
        """
        This command starts the upload of a BEC2/BF3 file to update the reader's configuration and/or firmware.  
        The reader responds by requesting the first data block within the BEC2/BF3 file. To transfer this data block, run the Main.Bf3UploadContinue command afterwards. 
        
        **For more details about implementation, please refer to the help topic[ Implement wired upload via the host](https://docs.baltech.de/developers/implement-wired-upload.html) .**
        """
        return Main_Bf3UploadStart(self)
    @property
    def Main_Bf3UploadContinue(self) -> Main_Bf3UploadContinue:
        """
        This command is used to transfer the data of a BEC2/BF3 file block by block to the reader.  
        The host transfers the data block of the BEC2/BF3 file which has been requested by the reader previously. The response parameter _RequiredAction_ indicates how the host has to proceed afterwards: 
        
          * Transfer the next data block. 
          * Disconnect and reconnect to the reader. 
          * Upload completed - no more data to transfer. 
        
        
        
        **For more details about implementation, please refer to the help topic[ Implement wired upload via the host](https://docs.baltech.de/developers/implement-wired-upload.html) .**
        """
        return Main_Bf3UploadContinue(self)
    @property
    def Mif_LoadKey(self) -> Mif_LoadKey:
        """
        This command writes a MIFARE Classic key to the reader's secure key memory. The reader can store 32 different keys so the key index must not exceed 31. These keys will be used for the authentication of certain sectors.
        """
        return Mif_LoadKey(self)
    @property
    def Mif_AuthE2(self) -> Mif_AuthE2:
        """
        This command authenticates a certain sector of a card using a key from the secure EEPROM of the Baltech reader chip. 
        
        Depending on the value of the _AuthMode_ variable, either key A or key B of the sector specified by the _Block_ variable will be compared to the key specified in _KeyIdx_. 
        
        It is only possible to authenticate one sector at a time.
        """
        return Mif_AuthE2(self)
    @property
    def Mif_AuthUser(self) -> Mif_AuthUser:
        """
        This command authenticates a certain sector of a card using the key specified in the _Key_ variable. 
        
        Depending on the value of the _AuthMode_ variable, either key A or key B of the sector specified by the _Block_ variable will be compared to the key specified in _KeyIdx_. 
        
        It is only possible to authenticate one sector at a time.
        """
        return Mif_AuthUser(self)
    @property
    def Mif_Read(self) -> Mif_Read:
        """
        This command reads data from a specified block of the currently selected card, providing authentication has been performed beforehand.
        """
        return Mif_Read(self)
    @property
    def Mif_Write(self) -> Mif_Write:
        """
        This command write data to a specified block of the currently selected card, providing authentication has been performed beforehand.
        """
        return Mif_Write(self)
    @property
    def Mif_ChangeValue(self) -> Mif_ChangeValue:
        """
        This command uses the value block specified by the _Block_ parameter and performs an operation given by the _Mode_ parameter. The result is stored in the card's Transfer Buffer. 
        
        _Mode_ = 1 increments the _value_ , _Mode_ = 0 decrements the value, _Mode_ = 0x02 simply transfers the value to the Transfer Buffer - the _Value_ parameter is ignored. 
        
        In order to persistently store the calculated value on the card, a _transfer_ operation, using the Mif.TransferBlock command, has to be performed directly after the completion of this command. 
        
        This command can be used for MIFARE Classic cards and only works on value sectors. 
        
        **This command is not supported by LEGIC readers.**
        """
        return Mif_ChangeValue(self)
    @property
    def Mif_ChangeValueBackup(self) -> Mif_ChangeValueBackup:
        """
        This command is identical to Mif.ChangeValue, but can only be used for MIFARE cards which support automatic transfer, such as _Pro_ or _Light_ MIFARE variants. 
        
        **This command is not supported by LEGIC readers.**
        """
        return Mif_ChangeValueBackup(self)
    @property
    def Mif_TransferBlock(self) -> Mif_TransferBlock:
        """
        This command transfers data from the card's internal Transfer Buffer to a specified block. 
        
        This command needs to be called directly after any operation on the internal data register performed by Mif.ChangeValue or Mif.ChangeValueBackup in order to make the results of these commands persistent. 
        
        **This command is not supported by LEGIC readers.**
        """
        return Mif_TransferBlock(self)
    @property
    def Mif_AuthE2Extended(self) -> Mif_AuthE2Extended:
        """
        This command is identical to the Mif.AuthE2 command with the exception that it supports stronger authentication methods (MIFARE and AES), supported by MIFARE Pro cards. 
        
        **MIFARE Plus SL2 support was deprecated and removed in firmware 2.12.00. It is unsupported in this and all later versions.**
        """
        return Mif_AuthE2Extended(self)
    @property
    def Mif_AuthUserExtended(self) -> Mif_AuthUserExtended:
        """
        This command is identical to the Mif.AuthUser command with the exception that it supports stronger authentication methods (MIFARE and AES), supported by MIFARE Pro cards. 
        
        **MIFARE Plus SL2 support was deprecated and removed in firmware 2.12.00. It is unsupported in this and all later versions.**
        """
        return Mif_AuthUserExtended(self)
    @property
    def Mif_ResetAuth(self) -> Mif_ResetAuth:
        """
        This command resets the reader's authentication state (used for MIFARE Pro specific Read/Write counters.
        """
        return Mif_ResetAuth(self)
    @property
    def Mif_ReadSL3(self) -> Mif_ReadSL3:
        """
        This command reads blocks from an SL3-authenticated MIFARE Pro card.
        """
        return Mif_ReadSL3(self)
    @property
    def Mif_WriteSL3(self) -> Mif_WriteSL3:
        """
        This command writes blocks to an SL3-authenticated MIFARE Pro card.
        """
        return Mif_WriteSL3(self)
    @property
    def Mif_ChangeAESKey(self) -> Mif_ChangeAESKey:
        """
        This command changes an AES key on a MIFARE Plus card.
        """
        return Mif_ChangeAESKey(self)
    @property
    def Mif_ValueSL3(self) -> Mif_ValueSL3:
        """
        This command performs an operation on a value block. 
        
        It can be used for MIFARE Plus cards in security level 3.
        """
        return Mif_ValueSL3(self)
    @property
    def Mif_ProxCheck(self) -> Mif_ProxCheck:
        """
        This command performs a proximity check. The key-related parameters are only used if no authentication has been performed before this command is called.
        """
        return Mif_ProxCheck(self)
    @property
    def Mif_GetCardVersion(self) -> Mif_GetCardVersion:
        """
        This command returns HW- / SW- / Production-Information. (only MIFARE+ EV1 and newer)
        """
        return Mif_GetCardVersion(self)
    @property
    def Mif_ReadSig(self) -> Mif_ReadSig:
        return Mif_ReadSig(self)
    @property
    def Mif_VirtualCardSelect(self) -> Mif_VirtualCardSelect:
        """
        Command is only supported by MIFARE Plus EV1 cards. Selected in ISO14443-3 mode the VCSupportLastISOL3 command is executed. Selected in ISO14443-4 mode the IsoSelect command is executed If the card answers in the latter case with a Payload (UID does not match or authentication with VCSelection is mandatory) the reader executes an additional ISOExternalAuthentication command
        """
        return Mif_VirtualCardSelect(self)
    @property
    def Mif_SectorSwitch(self) -> Mif_SectorSwitch:
        """
        This command performs a sector switch command (only for EV1 cards). Prior the card has to be set in 14443-4 mode, all sectors are addressed with sector Key B.
        """
        return Mif_SectorSwitch(self)
    @property
    def Mif_CommitReaderID(self) -> Mif_CommitReaderID:
        """
        This commands commits a reader ID from a card and returns the encrypted TMRI to the host. Authentication must take place before using this command.
        """
        return Mif_CommitReaderID(self)
    @property
    def Mif_SetFraming(self) -> Mif_SetFraming:
        """
        This command switches the communication protocol mode for MIFARE Plus EV1 cards.
        """
        return Mif_SetFraming(self)
    @property
    def MobileId_Enable(self) -> MobileId_Enable:
        """
        This command enables/disables Mobile ID.
        """
        return MobileId_Enable(self)
    @property
    def MobileId_GetVirtualCredentialId(self) -> MobileId_GetVirtualCredentialId:
        """
        This command checks if a Mobile ID credential has been presented to the reader since the last _MobileId.GetVirtualCredentialId_ execution. 
        
          * If a valid credential is detected, the credential identification will be returned in _CredentialId_. 
          * If no credential is detected, the MobileId.ErrNoCredential status code will be returned. 
          * If an invalid credential is detected, one of the other status codes will be returned. 
        
        
        
        **If you use Autoread, run AR.GetMessage instead of this command to retrieve the ID of a presented credential.**
        """
        return MobileId_GetVirtualCredentialId(self)
    @property
    def Sec_GetAcMask(self) -> Sec_GetAcMask:
        """
        This command retrieves the Access Condition Mask of a specified security level. 
        
        The Access Condition Mask can be set using the command Sec.SetAcMask or by loading a reader configuration file which defines the respective configuration values Device/HostSecurity/AccessConditionMask. 
        
        **In case of security level 0 (plain access) the actual Access Condition Mask that is applied by the reader may deviate from the value which is returned by this command. Refer to Sec.GetCurAcMask .**
        
        **It is _not_ possible to deny the retrieval of the Access Condition Mask via the "Encryption and Authorization" settings in the configuration. This means that this command will never return the ERR_ACCESS_DENIED status code.**
        """
        return Sec_GetAcMask(self)
    @property
    def Sec_SetAcMask(self) -> Sec_SetAcMask:
        """
        This command sets the Access Condition Mask of the security level specified in the _SecurityLevel_ parameter to the _AcMask_ value. 
        
        Alternatively Access Condition Masks may also be set via reader configuration, refer to Device/HostSecurity/AccessConditionMask. 
        
        **The Access Condition Mask of security level 3 is by definition 0xFFFFFFFF. It can not be restricted.**
        """
        return Sec_SetAcMask(self)
    @property
    def Sec_SetKey(self) -> Sec_SetKey:
        """
        Sets a key and the appropriate Authorization Mode bits for a specified Security Level. 
        
        Please note that if _DeriveKey_ is not 0, Sec.SetKey will not use the _Key_ parameter as a new key value for the authentication of security level _SecLevel_ directly. Instead, it encrypts the key specified in _DeriveKey_ with the key specified in _Key_ (via AES), and uses this encrypted key as a new key value for the authentication of security level _SecLevel_. 
        
        If one or more of the _SessionKey_ , _MACed_ , _Encrypted_ or _ContinuousIV_ bits are set, it is not possible to authenticate without the corresponding authentication mode setting.
        """
        return Sec_SetKey(self)
    @property
    def Sec_AuthPhase1(self) -> Sec_AuthPhase1:
        """
        This command initiates a 2-phase authentication. The 2-phase authentication is required for entering a security level, if its Authorization Mode enforces a session key. 
        
        In the first phase of the 2-phase authentication, the host sends a random number (_RndA_) to the reader. The reader encrypts this number two times, using AES128 encryption, with the key of the Security Level specified in _SecLevel_ , and sends the result back to the host as _EncRndA_. The host then has to check if the reader encrypted the number correctly. If this is the case, the reader returns the OK status code and the Sec.AuthPhase2 command can be called to initiate the second phase of the 2-phase authentication procedure. 
        
        If _EncRndA_ is invalid, the reader is configured with an invalid key, different from the one expected by the host. In this case, an error status code is returned.
        """
        return Sec_AuthPhase1(self)
    @property
    def Sec_AuthPhase2(self) -> Sec_AuthPhase2:
        """
        This command finishes the 2-phase authentication procedure started by the Sec.AuthPhase1 command. The host has to encrypt the parameter _RndB_ returned by Sec.AuthPhase1 two times, using AES128 encryption, with the key of the Security Level specified by the _SecLevel_ parameter of Sec.AuthPhase1. The host then sends the result back to the reader as _EncRndB_. 
        
        If _RndB_ was encrypted correctly, the reader returns the OK status code and enters the security level specified in Sec.AuthPhase1 as parameter _SecLevel_. Depending on the Authentication Mode, the reader enters this Security Level permanently (all subsequent commands are executed in this Security Level) or temporarily (only encrypted/MACed commands are executed in this Security Level). To ensure that the reader enters the Security Level temporarily, one of the _Encrypted_ /_MACed_ flags of the Authentication Mode has to be set. Please refer to the Sec.SetKey command for details. 
        
        Additionally, the Sec.AuthPhase2 command generates a session key by encrypting the _RndA_ parameter of Sec.AuthPhase1 and the _RndB_ value returned by Sec.AuthPhase1, _each only once_. The resulting 16 Byte session key is the result of the encryption of the concatenated _RndA_ (first 8 Bytes) and _RndB_ (last 8 Bytes).
        """
        return Sec_AuthPhase2(self)
    @property
    def Sec_Tunnel(self) -> Sec_Tunnel:
        """
        This command enables to send a specific command, called the _tunnelled_ command, to the reader (and to receive its response) in an encrypted and/or MACed fashion. 
        
        Depending on the values of the _AuthModeAndSecLevel_ bit mask, the tunnelled command will either be encrypted, MACed or both. The structure of the _TunnelledCmd_ parameter and of the _TunnelledResp_ response vary depending on the encryption/MACing behaviour: 
        
          * _Encrypted only_ : 
            * The data has to be padded to the next 16 Byte boundary by appending "00"-Bytes. 
            * The initial vector (IV) has to be reset to all zeros (00 00 ... 00) if if the _ContinuousIV_ flag is not set. If _ContinuousIV_ is set, Cipher Block Chaining (CBC) will be used in the encryption process. In this case, the result from the last block encryption will be used as IV. 
        
            * The padded data is encrypted using AES128 in CBC mode. The key for encryption is either the key assigned to the currently selected Security Level or, if the _SessionKey_ flag is set, the session key derived from the values _RndA_ and _RndB_ of the Sec.AuthPhase1 command: 
        
        _SessionKey = encrypt(RndA[0..7] + RndB[8..15])_
        
          * _Encrypted and MACed_ : Same as the _encrypted only_ variant, but a number of padding Bytes (at least 8) are appended to the encrypted data before transmission. The receiver always has to check whether the padding Bytes have the 0x00 value. If not, the frame is considered invalid. 
          * _MACed only_ : The encryption process is applied to the data which has to be MACed, but unlike in the _encryption only_ mode, the data is not modified. The first 8 Bytes of the hash value resulting from the encryption process (normally used as an IV for the next data block) are simply appended to the original data block to get the MACed data block. 
        
        
        
        **This command must not be used in BRP _Repeat Mode_ .**
        """
        return Sec_Tunnel(self)
    @property
    def Sec_Reset(self) -> Sec_Reset:
        """
        This command resets the Baltech ID engine's security system. After its execution, all security features will be disabled and the whole memory (i.e. the whole configuration) will be deleted. 
        
        Unless a Sec.LockReset was executed beforehand, this command runs in every security level. If available, factory settings as well as "Encryption and Authorization" settings are restored.
        """
        return Sec_Reset(self)
    @property
    def Sec_LockReset(self) -> Sec_LockReset:
        """
        This command prevents, that a Sys.FactoryReset is run for the Security Level specified in the _SecLevel_ command. See also Sec.SetAcMask.
        """
        return Sec_LockReset(self)
    @property
    def Sec_GetCurAcMask(self) -> Sec_GetCurAcMask:
        """
        This command retrieves the Access Condition Mask, which is applied by the reader in the current context (i.e. security level, protocol). 
        
        If this command is executed in security level 1-3 the actual Access Condition Mask is defined by the value which has been set for the particular security level before via Sec.SetAcMask command respectively the configuration value Device/HostSecurity/AccessConditionMask. In this case this command is identical to Sec.GetAcMask for the respective security level. 
        
        In case of security level 0 (plain access) the applied Access Condition Mask is determined by the protocol-specific Access Condition Mask ( Protocols/AccessConditionsBitsStd, Protocols/AccessConditionsBitsAlt). If this value is not available for the particular protocol the reader uses the value that has been set with Sec.SetAcMask respectively Device/HostSecurity/AccessConditionMask[0] before in combination (bitwise AND) with a hard-coded default value as fallback; in most cases this default value corresponds to all access rights - for BRP over TCP it is zero. 
        
        **It is _not_ possible to deny the retrieval of the Access Condition Mask via the "Encryption and Authorization" settings in the configuration. This means that this command will never return the ERR_ACCESS_DENIED status code.**
        """
        return Sec_GetCurAcMask(self)
    @property
    def Sys_GetBufferSize(self) -> Sys_GetBufferSize:
        """
        This command returns the maximum sizes of [command](https://docs.baltech.de/developers/brp-command-frame.html) and [response](https://docs.baltech.de/developers/brp-response-frame.html) frames that the reader can send and receive. This information is indicated by 3 return values: _MaxSendSize_ , _MaxRecvSize_ , and _TotalSize_. They're determined by the firmware. 
        
        **You need to comply with _all_ 3 values in your application: It's not enough if the command frame size and the expected response frame size are each smaller than or equal to _MaxSendSize_ and _MaxRecvSize_ , respectively. Their combined frame size must not exceed _TotalSize_ either. If _all_ 3 values are < 128 bytes, you don't need to use _Sys_GetBufferSize_ because this is the minimum size that all BALTECH readers support.**
        """
        return Sys_GetBufferSize(self)
    @property
    def Sys_HFReset(self) -> Sys_HFReset:
        """
        This command turns the HF antenna off or on. 
        
        **You cannot use it in combination with VHL commands .**
        
        The behavior is as follows: 
        
          * When the antenna is _on_ , the command turns it off for the time defined in _OffDuration_. To turn it off permanently, set the value to 0. 
          * When the antenna is _off_ , the command turns it on. To do so, set _OffDuration_ > 0\\. 
        
        
        
        **The HF antenna is turned _off_ after booting. If, however, the reader is configured for[ Autoread](https://docs.baltech.de/developers/map-autoread.html) , the HF antenna is turned on automatically during initialization, so you don't need to actively turn it on. This is the default behavior as of ID-engine Z.**
        """
        return Sys_HFReset(self)
    @property
    def Sys_Reset(self) -> Sys_Reset:
        """
        This command reboots the reader. Its main purpose is to apply configuration changes made e.g. with Sys.CfgSetValue. 
        
        ## Close and reopen the connection after running Sys.Reset
        
        Close the connection to the reader immediately after running _Sys.Reset_. Depending on the protocol, the connection may be lost. In this case, you need to reconnect.
        
        ### When to reconnect?
        
        The reset takes about 500 to 1000 ms to complete. Thus, we recommend you wait about 100 ms after closing the connection. Then try to reconnect every 100 ms.
        
        ### When is a reconnect successful?
        
        Consider a reconnect successful as soon as the reader executes a command. Opening a port is not a guarantee that you've reconnected.
        """
        return Sys_Reset(self)
    @property
    def Sys_GetInfo(self) -> Sys_GetInfo:
        """
        This command retrieves the firmware string of the reader, which holds information about the reader firmware and serial number. It has the following format: 
        
        _1xxx nnnnnnnnn r.rr.rr dd/dd/dd ssssssss_
        
        _1xxx_ |  ID of firmware (4 digits)   
        ---|---  
        _nnnnnnnnn_ |  Name of firmware (9 alphanumeric characters/spaces)   
        _r.rr.rr_ |  Release of firmware (major release, minor release, build ID)   
        _dd/dd/dd_ |  Date of release   
        _ssssssss_ |  Serial number of reader (8 digits)   
          
        **The combination of ID and release uniquely identifies any firmware version. You can use this information e.g. to retrieve the firmware in our download area.**
        """
        return Sys_GetInfo(self)
    @property
    def Sys_GetBootStatus(self) -> Sys_GetBootStatus:
        """
        This command retrieves the boot status of the reader, i.e. it describes the state of each component of the reader's hardware. Every bit in the returned value corresponds to a reader-internal component or a system error. If the component couldn't be initialized or the system error is triggered, the related bit is set. 
        
          * _Error bits (0-23):_ You have to solve these issues before you can use the reader. 
          * _Warning bits (24-31):_ The reader may still work properly. However, we highly recommend you solve these issues as well.
        """
        return Sys_GetBootStatus(self)
    @property
    def Sys_CfgGetValue(self) -> Sys_CfgGetValue:
        """
        This command retrieves a desired value of the reader's configuration, specified by the _Key_ and _Value_ parameters.
        """
        return Sys_CfgGetValue(self)
    @property
    def Sys_CfgSetValue(self) -> Sys_CfgSetValue:
        """
        This command stores a value in the reader's configuration. The _Content_ parameter will be stored to the desired configuration value specified by the _Key_ and _Value_ parameters. If the value is already stored in the configuration, it will be replaced.
        """
        return Sys_CfgSetValue(self)
    @property
    def Sys_CfgDelValues(self) -> Sys_CfgDelValues:
        """
        This command deletes a key or a value from the reader's configuration. 
        
          * It is possible to use the wildcard character (0xFF). 
          * If 0xFF is used as _Value_ , all values of the given _Key_ will be deleted. For instance, setting 0x0101 as _Key_ and 0xFF as _Value_ will delete all configuration values within the key 0x0101. 
          * If 0xFF is used as SubKey (low order byte of the _Key_ variable), all SubKeys from a specified MasterKey will be deleted. For instance, setting 0x01FF as _Key_ delete all SubKeys and thus also all values contained in MasterKey 0x01. The content of the _Value_ variable is irrelevant in this case. 
          * If 0xFF is used as MasterKey (high order byte of the _Key_ variable), the complete configuration will be deleted. The contents of the low order byte of the _Key_ variable and of the _Value_ variable are irrelevant in this case. 
          * This command is subject to potential restrictions . Specifically, SubKeys >= 0x80 are not deleted when the 0xFF wildcard is used. Deletion of these SubKeys must be performed explicitly.
        """
        return Sys_CfgDelValues(self)
    @property
    def Sys_CfgGetKeyList(self) -> Sys_CfgGetKeyList:
        """
        Retrieves a list of all keys stored in the reader's configuration.
        """
        return Sys_CfgGetKeyList(self)
    @property
    def Sys_CfgGetValueList(self) -> Sys_CfgGetValueList:
        """
        Returns a list of all configuration values within a specified _Key_.
        """
        return Sys_CfgGetValueList(self)
    @property
    def Sys_CfgCheck(self) -> Sys_CfgCheck:
        """
        This command checks the consistency of the reader's internal configuration. Additionally, it returns the overall configuration data size as well as the amount of free space for further configuration data. Please keep in mind that each value (including empty values) requires a few extra bytes of overhead for data management purposes. 
        
        **Starting with reader generation ID-engine Z, configuration consistency is always checked during powerup. That's why this command is no longer needed and always returns 0 (for _TotalSize_ and _FreeSize_ ) without any further checks.**
        """
        return Sys_CfgCheck(self)
    @property
    def Sys_SelectProtocol(self) -> Sys_SelectProtocol:
        """
        This command starts a host protocol. 
        
        Depending on the reader's hardware and firmware, multiple protocols may be supported. For most reader-to-host interfaces (e.g. USB, Ethernet), an unlimited number of protocols can be used on the physical channel, but in some cases only a single protocol per physical channel can be used at a time. This is for example the case when using a serial (RS-232/UART) interface, offering two physical channels, in which case each physical channel must be shared by several protocols. 
        
        **After power-up, the reader activates all protocols specified in the Device / Run / EnabledProtocols configuration value. To change the activated protocols at runtime, this command has to be used.**
        
        In case only a single protocol is allowed to run per physical channel, calling this command when a channel is already in use by another protocol will stop the currently running protocol. 
        
        _Example:_ the protocol is currently running on a serial interface (physical channel CH0) when Sys.SelectProtocol is called with _ProtocolID_ = 0x09 (Debug Interface). Since the Debug Interface protocol uses the same physical channel (CH0), it will be disabled.
        """
        return Sys_SelectProtocol(self)
    @property
    def Sys_CfgLoadBlock(self) -> Sys_CfgLoadBlock:
        """
        This command transfers the configuration from a BEC file into the reader. You have to call it for every _block_ tag in the BEC file. 
        
        **All _Sys.CfgLoad_ commands only work with the legacy file format BEC. For the current[ default format BEC2](https://docs.baltech.de/deployable-file-formats) , please use Main.Bf3UploadStart and Main.Bf3UploadContinue as explained in this[ overview](https://docs.baltech.de/developers/implement-wired-upload.html) .**
        
        ## Commands to run before and after
        
        To initiate the transfer, run Sys.CfgLoadPrepare before the first _Sys.CfgLoadBlock_.  
        For legacy reasons, you can ommit _Sys.CfgLoadPrepare_ because it's not supported by readers older than our current product lines based on ID-engine Z. In this case, ensure that the _Sys.CfgLoadBlock_ transferring the first block of the BEC file is the first _Sys.CfgLoadBlock_ after powerup. 
        
        To complete the operation once all _block_ tags are transferred, run Sys.CfgLoadFinish.  
        If you omit _Sys.CfgLoadPrepare_ for legacy reasons, omit _Sys.CfgLoadFinish_ as well. In this case, do a a manual reset to activate the configuration changes.
        """
        return Sys_CfgLoadBlock(self)
    @property
    def Sys_CfgReset(self) -> Sys_CfgReset:
        """
        Deletes the complete configuration. This command has the same effect as the Sys.CfgDelValues command using 0xFF as MasterKey. 
        
        **Like Sys.CfgDelValues , this command is subject to potential restrictions . Specifically, SubKeys > = 0x80 are not deleted by this command. Deletion of these SubKeys must be performed explicitly using Sys.CfgDelValues .**
        """
        return Sys_CfgReset(self)
    @property
    def Sys_StopProtocol(self) -> Sys_StopProtocol:
        """
        This command stops a host protocol. No reaction is expected after the protocol has been stopped. More details on protocols can be found in the Sys.SelectProtocol command reference.
        """
        return Sys_StopProtocol(self)
    @property
    def Sys_SendMessage(self) -> Sys_SendMessage:
        """
        This command sends a message to the host via a certain protocol. 
        
        If _Protocol_ is 0, the message is sent to _all_ active protocols. Furthermore, it is transformed by the corresponding HostMsgFormatTemplates, e.g. Protocols/KeyboardEmulation/HostMsgFormatTemplate in case of keyboard emulation. 
        
        If _Protocol_ is a protocol ID, the message is sent to this protocol only and _no_ HostMsgFormatTemplate conversion is initiated. The desired protocol must be active, e.g. by calling Sys.SelectProtocol.
        """
        return Sys_SendMessage(self)
    @property
    def Sys_CfgGetId(self) -> Sys_CfgGetId:
        """
        This command returns the identifier of the reader configuration. The prerequisite is that the configuration contains a valid host interface component and/or RFID interface component. 
        
        **If the RFID interface component(s) are stored in one configuration and other components (typically the host interface component) in another configuration, this command will only return the ID for the configuration with the RFID interface component(s). To get the ID for the configuration with the host interface component, run Sys.CfgGetDeviceSettingsId .**
        """
        return Sys_CfgGetId(self)
    @property
    def Sys_CfgGetDeviceSettingsId(self) -> Sys_CfgGetDeviceSettingsId:
        """
        This command retrieves the ID of the reader configuration containing the device settings. 
        
        **Use this command if the RFID interface component(s) are stored in one configuration and other components (typically the host interface component) in another configuration. If you have no RFID interface component or a configuration containing all components, run Sys.CfgGetId to get the configuration ID.**
        """
        return Sys_CfgGetDeviceSettingsId(self)
    @property
    def Sys_GetStatistics(self) -> Sys_GetStatistics:
        """
        This command retrieves all available statistics counters from the reader's configuration. The statistics counters are stored in the Device / Statistics configuration key. 
        
        **This command is designed for Baltech internal use only.**
        """
        return Sys_GetStatistics(self)
    @property
    def Sys_GetFeatures(self) -> Sys_GetFeatures:
        """
        This command retrieves the list of features supported by the reader, so you can find out if the reader meets your requirements. The list of features includes e.g. supported card types, LEDs, encryption methods, and maintenance options. It depends both on the reader hardware and firmware.
        """
        return Sys_GetFeatures(self)
    @property
    def Sys_GetPartNumber(self) -> Sys_GetPartNumber:
        """
        This command returns the part number and the hardware revision number of the device. This information, which is usually also printed on the label, allows you to identify the reader model type for e.g. reorder purposes. 
        
        **Don't use this command to distinguish the device features in your application! Use Sys.GetFeatures instead. The reason is: Baltech may offer (replacement) products with the same or a similar feature set, which have different part numbers. If the application would stick to a certain part number these devices would not be deployable.**
        """
        return Sys_GetPartNumber(self)
    @property
    def Sys_CfgLoadPrepare(self) -> Sys_CfgLoadPrepare:
        """
        This command initiates the transfer of a BEC file via Sys.CfgLoadBlock. It will cancel any running BEC transfer and start loading a new one. 
        
        **All _Sys.CfgLoad_ commands only work with the legacy file format BEC. For the current[ default format BEC2](https://docs.baltech.de/deployable-file-formats) , please use Main.Bf3UploadStart and Main.Bf3UploadContinue as explained in this[ overview](https://docs.baltech.de/developers/implement-wired-upload.html) .**
        """
        return Sys_CfgLoadPrepare(self)
    @property
    def Sys_CfgLoadFinish(self) -> Sys_CfgLoadFinish:
        """
        This command has to be called after transferring a BEC file with Sys.CfgLoadBlock. Depending on how you set the parameter _FinalizeAction_ , this command will do one of the following: 
        
          * Complete the transfer; this requires all _Sys.CfgLoadBlock_ calls to have succeeded. 
          * Cancel the transfer and undo all configuration changes since Sys.CfgLoadPrepare. 
        
        
        
        **All _Sys.CfgLoad_ commands only work with the legacy file format BEC. For the current[ default format BEC2](https://docs.baltech.de/deployable-file-formats) , please use Main.Bf3UploadStart and Main.Bf3UploadContinue as explained in this[ overview](https://docs.baltech.de/developers/implement-wired-upload.html) .**
        """
        return Sys_CfgLoadFinish(self)
    @property
    def Sys_FactoryReset(self) -> Sys_FactoryReset:
        """
        This command restores the reader's [ factory settings](https://docs.baltech.de/project-setup/factory-settings.html).
        """
        return Sys_FactoryReset(self)
    @property
    def Sys_GetLicenses(self) -> Sys_GetLicenses:
        """
        This command retrieves a bit mask of the licenses that are activated in the reader.
        """
        return Sys_GetLicenses(self)
    @property
    def Ultralight_ExecCmd(self) -> Ultralight_ExecCmd:
        """
        Generic command to communicate to a Mifare Ultralight card.
        """
        return Ultralight_ExecCmd(self)
    @property
    def Ultralight_Read(self) -> Ultralight_Read:
        """
        Standard read command for Ultralight cards. Command returns 4 pages of a card (16 byte).
        """
        return Ultralight_Read(self)
    @property
    def Ultralight_Write(self) -> Ultralight_Write:
        """
        Standard write command for Ultralight cards. 1 page (4 bytes) is writen to a card.
        """
        return Ultralight_Write(self)
    @property
    def Ultralight_AuthE2(self) -> Ultralight_AuthE2:
        """
        Authenticates to a Ultralight-c card. 
        
        The key used for authentication is specified in the Device / CryptoKey key of the reader's configuration. Key has to be of type 3DES (16 bytes).
        """
        return Ultralight_AuthE2(self)
    @property
    def Ultralight_AuthUser(self) -> Ultralight_AuthUser:
        """
        Authenticates to an Ultralight-C/EV1 card.
        """
        return Ultralight_AuthUser(self)
    @property
    def Ultralight_SectorSwitch(self) -> Ultralight_SectorSwitch:
        """
        Selects a sector of an Ultralight-C/EV1 card.
        """
        return Ultralight_SectorSwitch(self)
    @property
    def UI_Enable(self) -> UI_Enable:
        """
        This command enables a specific port of the reader. 
        
        Depending on the type of the selected port, it does one of the following:
        
          * Drive an output pin high (GPIO)
          * Activate a peripheral component (beeper, relay)
          * Switch an LED to a certain color
        """
        return UI_Enable(self)
    @property
    def UI_Disable(self) -> UI_Disable:
        """
        This command disables a specific port of the reader. 
        
        Depending on the type of the selected port, it does one the following:
        
          * Drive an output pin low (GPIO)
          * Deactivate a peripheral component (beeper, relay)
          * Switch an LED off
        """
        return UI_Disable(self)
    @property
    def UI_Toggle(self) -> UI_Toggle:
        """
        This command toggles the output state of a specific port. 
        
        A single toggle consists of 2 state changes: From the initial state to the inverse state and back. The initial state is defined by the _Polarity_ parameter. This is also the state of the port at the end of the toggling operation. 
        
        To stop the toggling, call UI.Enable or UI.Disable for this port.
        """
        return UI_Toggle(self)
    @property
    def UI_SetRgbLed(self) -> UI_SetRgbLed:
        """
        This command changes the RGB color of a single LED or a group of LEDs. The color may be activated instantly or smoothly by a sine-wave approximated fading transition. 
        
        If the addressed LEDs are already active when this command is called, the color first fades to black (off), before the transition to the new color starts. 
        
        **This command gives you direct control of the reader's LEDs. It competes with the command UI.Enable , which can be used to switch LEDs via Virtual LED port definitions (VLEDs)._UI.Enable_ operates on a higher abstraction level. Don't mix the 2 commands as this may result in inconsistent behavior.**
        """
        return UI_SetRgbLed(self)
    @property
    def UI_PulseRgbLed(self) -> UI_PulseRgbLed:
        """
        This command starts to pulse a single LED or a group of multiple LEDs continuously by performing smooth sine-wave approximated transitions between 2 RGB colors. 
        
        To stop the pulsing, call the command UI.SetRgbLed. 
        
        **This command gives you direct control of the reader's LEDs. It competes with the command UI.Enable , which can be used to switch LEDs via Virtual LED port definitions (VLEDs)._UI.Enable_ operates on a higher abstraction level. Don't mix the 2 commands as this may result in inconsistent behavior.**
        """
        return UI_PulseRgbLed(self)
    @property
    def VHL_Select(self) -> VHL_Select:
        """
        This command selects a card or tag in the antenna field for further operations. You need to run it successfully before you can use the following VHL commands: 
        
          * VHL.GetSnr
          * VHL.GetATR
          * VHL.Read
          * VHL.Write
          * VHL.ExchangeAPDU
          * VHL.GetCardType
        
        
        
        ## Handling multiple cards in the antenna field
        
        Using the _Reselect_ parameter, you can interact with a card that you've already processed before (learn more in the _Parameters_ section below). 
        
        **Certain cards return[ random IDs](https://docs.baltech.de/glossary.html#random-id) . If 2 or more cards with random IDs _AND_ the same card family are present in the antenna field at the same time,_VHL.Select_ detects these cards more than once.**
        
        ## Potential error cases after selection
        
        After running _VHL.Select_ successfully, the above commands will usually be executed successfully, even if the card temporarily leaves the antenna field. Communication parameters such as _bit rate_ and _frame size_ are automatically chosen to optimize performance. 
        
        However, problems with certain cards (e.g. MIFARE proX/DESFire) may occur when they're in the border area of the antenna field and brought in very slowly. In these cases, _VHL.Select_ may be executed successful, but the subsequent command may fail. 
        
        **In this case, make sure your application guarantees a suitable card distance, either by user guidance or by repetition of the VHL.IsSelected command until its success. This is especially important in conjunction with the VHL.ExchangeAPDU command since it doesn't perform retries internally.**
        """
        return VHL_Select(self)
    @property
    def VHL_GetSnr(self) -> VHL_GetSnr:
        """
        This command returns the serial number (UID) of the currently selected card. The UID is the number sent when the card is selected; this may also be a random ID. 
        
        If VHL.Select hasn't been executed successfully before, the reader will return VHL.ErrCardNotSelected. If the last selected card is no longer available in the antenna field, or a read/write operation failed previous to this command, the returned serial number is undefined. 
        
        **Don't make security-critical decisions by only examining the card's serial number.**
        """
        return VHL_GetSnr(self)
    @property
    def VHL_Read(self) -> VHL_Read:
        """
        This command reads data from a card based on a VHL file. In this file, you specify the card-specific memory structure. You can either [add the VHL file to your reader configuration](https://docs.baltech.de/developers/configure-rfid-interface.html#add-a-vhl-file) or create it dynamically using VHL.Setup.
        """
        return VHL_Read(self)
    @property
    def VHL_Write(self) -> VHL_Write:
        """
        This command writes data to a card based on a VHL file. In this file, you specify the card-specific memory structure. You can either [add the VHL file to your reader configuration](https://docs.baltech.de/developers/configure-rfid-interface.html#add-a-vhl-file) or create it dynamically using VHL.Setup.
        """
        return VHL_Write(self)
    @property
    def VHL_IsSelected(self) -> VHL_IsSelected:
        """
        This command checks if the card/label selected by the last execution of the VHL.Select command is still in the HF field of the antenna. If the card/label has been taken away from the reader and put back on it _after_ the last execution of VHL.Select, or if VHL.Select has not been called after a card has been put on the reader, this command will return the VHL.ErrCardNotSelected status code. 
        
        **For 125 kHz cards, a retry is automatically performed in case of a misread to improve reliability. Please note that this may increase reaction time for 125 kHz cards to a maximum of 100 ms.**
        """
        return VHL_IsSelected(self)
    @property
    def VHL_ExchangeAPDU(self) -> VHL_ExchangeAPDU:
        """
        This command sends APDUs to the currently selected card. APDUs are the communication units between a reader and an ISO 14443-4 card. They're defined in the [ISO/IEC 7816-4 standard](https://www.iso.org/standard/77180.html). _VHL.ExchangeAPDU_ transmits the actual APDU command via the _Cmd_ parameter and returns the APDU response as _Resp_. 
        
        ## Keep an eye on the frame size
        
        The combined size of transmitted and received APDU data (i.e. the combined size of _Cmd_ and _Resp_) must not exceed the maximum frame size supported by your reader's firmware version. To check the maximum frame size, run Sys.GetBufferSize and refer to the _TotalSize_ response value. 
        
        **For larger amount of data, please use VHL.ExchangeLongAPDU instead.**
        
        ## No error correction or retry mechanisms
        
        The reader firmware does _not_ perform any error handling operations with ISO/IEC 7816-4 inter-industry commands. Errors will be directly reported as part of the _Resp_ value without further action, so you have to take care of error handling in your application.
        """
        return VHL_ExchangeAPDU(self)
    @property
    def VHL_Setup(self) -> VHL_Setup:
        """
        This command creates a VHL file dynamically and transfers it to the reader's RAM. The VHL file specifies the card-specific memory structure required to call VHL.Read or VHL.Write. You need to run _VHL.Setup_ if you don't want to configure the readers with a static VHL file ( [ learn more](https://docs.baltech.de/developers/map-vhl-without-config.html)). 
        
        **To run VHL.Format , you cannot use a dynamic VHL file. In this case, you have to follow the[ standard VHL implementation](https://docs.baltech.de/developers/map-vhl.html) with a static VHL file.**
        
        ## What to specify
        
        To describe the memory structure, provide a list of parameters depending on the card type (see optional fields in the _Parameters_ table below). If you omit a parameter, the reader will use the default value. To fill in the parameter values, please refer to the card specification. For LEGIC or MIFARE cards, you can also [analyze the card structure](https://docs.baltech.de/project-setup/analyze-card-structure.html) using BALTECH ID-engine Explorer. 
        
        ## Mixing dynamic and static VHL files
        
        In principle, it is possible to mix dynamic VHL files and static VHL files (as part of the reader configuration for the [ VHL & Autoread](https://docs.baltech.de/developers/map-vhl-autoread.html)). However, please note that the dynamic VHL file is lost as soon as you run VHL.Read or VHL.Write with a static VHL file. Thus, if you later want to run _VHL.Read_ or _VHL.Write_ with the dynamic VHL file again, you first need to rerun _VHL.Setup_ to recreate the dynamic VHL file.
        """
        return VHL_Setup(self)
    @property
    def VHL_CheckReconfigErr(self) -> VHL_CheckReconfigErr:
        """
        This command returns the status of the last reconfiguration with a ConfigCard using the VHL.Select command. 
        
        **The _Failed_ status flag is cleared with the next reader reboot.**
        """
        return VHL_CheckReconfigErr(self)
    @property
    def VHL_ExchangeLongAPDU(self) -> VHL_ExchangeLongAPDU:
        """
        This command sends basic Inter-Industry commands to the currently selected card in accordance with the [ISO/IEC 7816-4 standard](http://www.iso.org/iso/catalogue_detail.htm?csnumber=54550). This command has the same functionality as VHL.ExchangeAPDU, but it allows the application to send commands and receive responses larger than the reader's internal protocol buffers by splitting the command. See the Sys.GetBufferSize command documentation for more details about the reader's internal buffers. 
        
        When splitting a command into multiple blocks, this command has to be repeated to transfer the APDU as _Cmd_ parameter block by block. As long as the _ContinueCmd_ parameter is set to _true_ , the reader will wait for further output before transmitting the APDU. The last block of the APDU can be sent by setting _ContinueCmd_ to _false_. The reader will only start transferring the response once the last block of the APDU command has been sent. If the response is bigger than one communication frame, it is split in the same manner as the command with the _ContinueResp_ flag set to _true_ as long as the response has not been completely received. The command is completely exchanged when the _ContinueResp_ flag is set to _false_. 
        
        A command transfer can be broken if the reader returns an error status code or by starting a new VHL.ExchangeLongAPDU sequence. When starting a new APDU the _Reset_ parameter of the first VHL.ExchangeLongAPDU call always has to be set to _true_ (it does not matter if the command breaks a preceding VHL.ExchangeLongAPDU or not). 
        
        The splitting of a command into blocks is determined by the size of the reader's sending and receiving buffers. The size of these buffers can be obtained by the Sys.GetBufferSize command. A frame must not exceed _MaxSendSize_ \\- 4 or _TotalSize_ \\- 8. 
        
        **The sum of the amount of data transmitted and received through _Cmd_ and _Resp_ has to be smaller than or equal to _TotalSize_ .**
        
        The following example shows how a 1000 Byte APDU Command which returns a 500 Byte response is transferred to a reader having a buffer of 400 Bytes (i.e. for which Sys.GetBufferSize returns a 400 Byte _MaxSendSize_ and a 400 Byte _TotalSize_ ): 
        
          1. ExchangeLongAPDU(Reset=True, ContinueCmd=True, Cmd=bytes 0..391) >= ContinueResp=True, Resp=empty 
          2. ExchangeLongAPDU(Reset=False, ContinueCmd=True, Cmd=bytes 392..783) >= ContinueResp=True, Resp=empty 
          3. ExchangeLongAPDU(Reset=False, ContinueCmd=False, Cmd=bytes 784..999) >= ContinueResp=True, Resp=0..175 
          4. ExchangeLongAPDU(Reset=False, ContinueCmd=False, Cmd=empty) >= ContinueResp=False, Resp=176..499
        """
        return VHL_ExchangeLongAPDU(self)
    @property
    def VHL_GetFileInfo(self) -> VHL_GetFileInfo:
        """
        This command returns the available size of the VHL-file whose ID is specified by the _ID_ parameter. Two values are returned: the length of the VHL-file (_Len_) and the size of a single block (_BlockSize_). 
        
        **The size of the returned value _Len_ indicates the maximum number of bytes which can be read/written with the VHL.Read or VHL.Write commands. Attempting to read or write a larger amount of Bytes with VHL.Read or VHL.Write will generate an error status code ( VHL.ErrRead or VHL.ErrWrite ).**
        
        If the card system organizes its memory in blocks, _BlockSize_ returns the size of a single block. If the memory is not organized in blocks, 1 will be returned. 0 will be returned if the block sizes are not unique (currently, there is no such card system in existence). 
        
        **This command can only be executed if a card is selected, e.g. with a previous call of VHL.Select .**
        
        **The returned VHL-file size corresponds to the reader's configuration values. It does not necessarily guarantee that a file of the returned sized can be read on the card. In some cases, the actual size of the card may be smaller than the returned VHL-file size.**
        """
        return VHL_GetFileInfo(self)
    @property
    def VHL_GetATR(self) -> VHL_GetATR:
        """
        This command returns the Answer to Reset (ATR) of the currently selected card as defined in the [PC/SC specification, version 2](http://pcscworkgroup.com/Download/Specifications/pcsc3_v2.01.09.pdf). If VHL.Select hasn't been executed successfully before, the VHL.ErrCardNotSelected status code will be returned. If the last selected card is no longer available in the antenna field, or a read/write operation failed previous to this command, the returned ATR is undefined.
        """
        return VHL_GetATR(self)
    @property
    def VHL_ResolveFilename(self) -> VHL_ResolveFilename:
        """
        This command returns the ID of a VHL file based on its filename. To to do, the command searches for a file whose configuration value VhlCfg.File.Filename matches the passed _Filename_ exactly. 
        
        Use this ID to reference the VHL file in the following commands:
        
          * VHL.Read
          * VHL.Write
          * VHL.Format
          * VHL.GetFileInfo
        
        
        
        **We strongly recommend you don't hardcode file IDs, but always resolve them via this command. Otherwise, your application won't work anymore if e.g. a project manager later merges VHL files into a different configuration using BALTECH ConfigEditor. This process may result in a new ID, but not in a new name.**
        """
        return VHL_ResolveFilename(self)
    @property
    def VHL_GetCardType(self) -> VHL_GetCardType:
        """
        This command returns the card type of the currently selected card. 
        
        If no card is selected or the last selected card is no longer available in the antenna field, the reader will return VHL.ErrCardNotSelected.
        """
        return VHL_GetCardType(self)
__all__: list[str] = [
    "PublicCommands",
    "AR_SetMode",
    "AR_GetMessage",
    "AR_RunScript",
    "AR_RestrictScanCardFamilies",
    "BlePeriph_DefineService",
    "BlePeriph_Enable",
    "BlePeriph_SetAdvertisingData",
    "BlePeriph_WriteCharacteristic",
    "BlePeriph_ReadCharacteristic",
    "BlePeriph_GetEvents",
    "BlePeriph_IsConnected",
    "BlePeriph_GetRSSI",
    "BlePeriph_CloseConnection",
    "Crypto_EncryptBlock",
    "Crypto_DecryptBlock",
    "Crypto_EncryptBuffer",
    "Crypto_DecryptBuffer",
    "Crypto_BalKeyEncryptBuffer",
    "Crypto_GetKeySig",
    "Crypto_CopyConfigKey",
    "Desfire_ExecCommand",
    "Desfire_Authenticate",
    "Desfire_AuthExtKey",
    "Desfire_SelectApplication",
    "Desfire_ReadData",
    "Desfire_WriteData",
    "Desfire_ChangeExtKey",
    "Desfire_ChangeKey",
    "Desfire_SetFraming",
    "Desfire_ResetAuthentication",
    "Desfire_CreateDam",
    "Desfire_GetOriginalitySignature",
    "Desfire_VirtualCardSelect",
    "Desfire_ProxCheck",
    "Desfire_GetDfNames",
    "Felica_GenericCmd",
    "Felica_SetUID2",
    "Felica_Request",
    "Iso14a_Select",
    "Iso14a_Halt",
    "Iso14a_RequestATS",
    "Iso14a_PerformPPS",
    "Iso14a_Request",
    "Iso14a_RequestVasup",
    "Iso14a_TransparentCmd",
    "Iso14b_Request",
    "Iso14b_Attrib",
    "Iso14b_Halt",
    "Iso14b_TransparentCmd",
    "Iso14L4_SetupAPDU",
    "Iso14L4_ExchangeAPDU",
    "Iso14L4_Deselect",
    "Iso15_SetParam",
    "Iso15_GetParam",
    "Iso15_GetUIDList",
    "Iso15_SetMode",
    "Iso15_StayQuiet",
    "Iso15_LockBlock",
    "Iso15_ResetToReady",
    "Iso15_WriteAFI",
    "Iso15_LockAFI",
    "Iso15_WriteDSFID",
    "Iso15_LockDSFID",
    "Iso15_GetSystemInformation",
    "Iso15_GetSecurityStatus",
    "Iso15_CustomCommand",
    "Iso15_ReadSingleBlock",
    "Iso15_WriteSingleBlock",
    "Iso15_WriteMultipleBlocks",
    "Iso15_ReadMultipleBlocks",
    "Iso15_TransparentCmd",
    "Iso78_OpenSam",
    "Iso78_CloseSam",
    "Iso78_ExchangeApdu",
    "Lic_GetLicenses",
    "Lic_ReadLicCard",
    "Main_Bf3UploadStart",
    "Main_Bf3UploadContinue",
    "Mif_LoadKey",
    "Mif_AuthE2",
    "Mif_AuthUser",
    "Mif_Read",
    "Mif_Write",
    "Mif_ChangeValue",
    "Mif_ChangeValueBackup",
    "Mif_TransferBlock",
    "Mif_AuthE2Extended",
    "Mif_AuthUserExtended",
    "Mif_ResetAuth",
    "Mif_ReadSL3",
    "Mif_WriteSL3",
    "Mif_ChangeAESKey",
    "Mif_ValueSL3",
    "Mif_ProxCheck",
    "Mif_GetCardVersion",
    "Mif_ReadSig",
    "Mif_VirtualCardSelect",
    "Mif_SectorSwitch",
    "Mif_CommitReaderID",
    "Mif_SetFraming",
    "MobileId_Enable",
    "MobileId_GetVirtualCredentialId",
    "Sec_GetAcMask",
    "Sec_SetAcMask",
    "Sec_SetKey",
    "Sec_AuthPhase1",
    "Sec_AuthPhase2",
    "Sec_Tunnel",
    "Sec_Reset",
    "Sec_LockReset",
    "Sec_GetCurAcMask",
    "Sys_GetBufferSize",
    "Sys_HFReset",
    "Sys_Reset",
    "Sys_GetInfo",
    "Sys_GetBootStatus",
    "Sys_CfgGetValue",
    "Sys_CfgSetValue",
    "Sys_CfgDelValues",
    "Sys_CfgGetKeyList",
    "Sys_CfgGetValueList",
    "Sys_CfgCheck",
    "Sys_SelectProtocol",
    "Sys_CfgLoadBlock",
    "Sys_CfgReset",
    "Sys_StopProtocol",
    "Sys_SendMessage",
    "Sys_CfgGetId",
    "Sys_CfgGetDeviceSettingsId",
    "Sys_GetStatistics",
    "Sys_GetFeatures",
    "Sys_GetPartNumber",
    "Sys_CfgLoadPrepare",
    "Sys_CfgLoadFinish",
    "Sys_FactoryReset",
    "Sys_GetLicenses",
    "Ultralight_ExecCmd",
    "Ultralight_Read",
    "Ultralight_Write",
    "Ultralight_AuthE2",
    "Ultralight_AuthUser",
    "Ultralight_SectorSwitch",
    "UI_Enable",
    "UI_Disable",
    "UI_Toggle",
    "UI_SetRgbLed",
    "UI_PulseRgbLed",
    "VHL_Select",
    "VHL_GetSnr",
    "VHL_Read",
    "VHL_Write",
    "VHL_IsSelected",
    "VHL_ExchangeAPDU",
    "VHL_Setup",
    "VHL_CheckReconfigErr",
    "VHL_ExchangeLongAPDU",
    "VHL_GetFileInfo",
    "VHL_GetATR",
    "VHL_ResolveFilename",
    "VHL_GetCardType",
]