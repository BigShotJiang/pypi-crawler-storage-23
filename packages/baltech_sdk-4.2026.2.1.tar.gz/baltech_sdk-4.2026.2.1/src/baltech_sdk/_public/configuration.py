
from io import BytesIO
from typing import Any, Optional, NamedTuple, Union, List, ClassVar, Tuple, Literal

from typing_extensions import Self

from ..generator_interface import safe_read_int_from_buffer, FrameProcessor, ConfigBase, ConfigValue, PayloadTooLongError, PayloadTooShortError, PayloadFormatError
from .typedefs import *
from .protocols import BaltechScript
from .protocols import BRP
from .protocols import Template
class Autoread(ConfigBase):
    MasterKey: ClassVar[int] = 0x04
    MasterKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        self.process_frame(_send_buffer.getvalue())
class Autoread_Rule(ConfigBase):
    MasterKey: ClassVar[int] = 0x04
    SubKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 63
    def reset(self, Rule_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
class Autoread_Rule_Template(ConfigValue):
    MasterKey: ClassVar[int] = 0x04
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x00
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 63
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, Rule_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x00')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Template:
        _recv_buffer = BytesIO(frame)
        _Value = Template(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, Rule_ndx: int, default: Optional[Template] = None) -> Optional[Template]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x00')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Rule_ndx: int, Value: Union[Template, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x00')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Rule_ndx: int, Value: Union[Template, bytes]) -> None:
        frame = self.build_frame(Rule_ndx=Rule_ndx, Value=Value)
        self.process_frame(frame)
class Autoread_Rule_VhlFileIndex(ConfigValue):
    MasterKey: ClassVar[int] = 0x04
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 63
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, Rule_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, Rule_ndx: int, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x01')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Rule_ndx: int, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x01')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Rule_ndx: int, Value: int) -> None:
        frame = self.build_frame(Rule_ndx=Rule_ndx, Value=Value)
        self.process_frame(frame)
class Autoread_Rule_ConstArea(ConfigValue):
    MasterKey: ClassVar[int] = 0x04
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 63
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, Rule_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Autoread_Rule_ConstArea_Result:
        _recv_buffer = BytesIO(frame)
        _Position = safe_read_int_from_buffer(_recv_buffer, 2)
        _CompareData_bytes = _recv_buffer.read(-1)
        _CompareData = _CompareData_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Autoread_Rule_ConstArea_Result(_Position, _CompareData)
    def get(self, Rule_ndx: int, default: Optional[Autoread_Rule_ConstArea_Result] = None) -> Optional[Autoread_Rule_ConstArea_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x02')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Rule_ndx: int, Position: int, CompareData: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x02')
        _send_buffer.write(Position.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(CompareData.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Rule_ndx: int, Position: int, CompareData: str) -> None:
        frame = self.build_frame(Rule_ndx=Rule_ndx, Position=Position, CompareData=CompareData)
        self.process_frame(frame)
class Autoread_Rule_CardTypes(ConfigValue):
    MasterKey: ClassVar[int] = 0x04
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x03
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 63
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, Rule_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x03')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[CardType]:
        _recv_buffer = BytesIO(frame)
        _AcceptedCardTypes = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _AcceptedCardType = CardType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
            _AcceptedCardTypes.append(_AcceptedCardType)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _AcceptedCardTypes
    def get(self, Rule_ndx: int, default: Optional[List[CardType]] = None) -> Optional[List[CardType]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x03')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Rule_ndx: int, AcceptedCardTypes: List[CardType]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x03')
        for _AcceptedCardTypes_Entry in AcceptedCardTypes:
            _AcceptedCardType = _AcceptedCardTypes_Entry
            _send_buffer.write(CardType_Parser.as_value(_AcceptedCardType).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Rule_ndx: int, AcceptedCardTypes: List[CardType]) -> None:
        frame = self.build_frame(Rule_ndx=Rule_ndx, AcceptedCardTypes=AcceptedCardTypes)
        self.process_frame(frame)
class Autoread_Rule_CheckScriptId(ConfigValue):
    MasterKey: ClassVar[int] = 0x04
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x04
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 63
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, Rule_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x04')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _ScriptId = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ScriptId
    def get(self, Rule_ndx: int, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x04')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Rule_ndx: int, ScriptId: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x04')
        _send_buffer.write(ScriptId.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Rule_ndx: int, ScriptId: int) -> None:
        frame = self.build_frame(Rule_ndx=Rule_ndx, ScriptId=ScriptId)
        self.process_frame(frame)
class Autoread_Rule_MsgType(ConfigValue):
    MasterKey: ClassVar[int] = 0x04
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x05
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 63
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, Rule_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x05')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> MessageType:
        _recv_buffer = BytesIO(frame)
        _Value = MessageType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, Rule_ndx: int, default: Optional[MessageType] = None) -> Optional[MessageType]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x05')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Rule_ndx: int, Value: MessageType) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x05')
        _send_buffer.write(MessageType_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Rule_ndx: int, Value: MessageType) -> None:
        frame = self.build_frame(Rule_ndx=Rule_ndx, Value=Value)
        self.process_frame(frame)
class Autoread_Rule_WiegandInputBitLen(ConfigValue):
    MasterKey: ClassVar[int] = 0x04
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x06
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 63
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, Rule_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x06')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, Rule_ndx: int, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x06')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Rule_ndx: int, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x06')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Rule_ndx: int, Value: int) -> None:
        frame = self.build_frame(Rule_ndx=Rule_ndx, Value=Value)
        self.process_frame(frame)
class Autoread_Rule_CardFamilies(ConfigValue):
    MasterKey: ClassVar[int] = 0x04
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x07
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 63
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, Rule_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x07')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> CardFamilies:
        _recv_buffer = BytesIO(frame)
        _Value_int = safe_read_int_from_buffer(_recv_buffer, 2)
        _LEGICPrime = bool((_Value_int >> 11) & 0b1)
        _BluetoothMce = bool((_Value_int >> 10) & 0b1)
        _Khz125Part2 = bool((_Value_int >> 9) & 0b1)
        _Srix = bool((_Value_int >> 8) & 0b1)
        _Khz125Part1 = bool((_Value_int >> 7) & 0b1)
        _Felica = bool((_Value_int >> 6) & 0b1)
        _IClass = bool((_Value_int >> 5) & 0b1)
        _IClassIso14B = bool((_Value_int >> 4) & 0b1)
        _Iso14443B = bool((_Value_int >> 3) & 0b1)
        _Iso15693 = bool((_Value_int >> 2) & 0b1)
        _Iso14443A = bool((_Value_int >> 0) & 0b1)
        _Value = CardFamilies(_LEGICPrime, _BluetoothMce, _Khz125Part2, _Srix, _Khz125Part1, _Felica, _IClass, _IClassIso14B, _Iso14443B, _Iso15693, _Iso14443A)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, Rule_ndx: int, default: Optional[CardFamilies] = None) -> Optional[CardFamilies]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x07')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Rule_ndx: int, Value: Union[CardFamilies, CardFamilies_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x07')
        if isinstance(Value, dict):
            Value = CardFamilies(**Value)
        Value_int = 0
        Value_int |= (int(Value.LEGICPrime) & 0b1) << 11
        Value_int |= (int(Value.BluetoothMce) & 0b1) << 10
        Value_int |= (int(Value.Khz125Part2) & 0b1) << 9
        Value_int |= (int(Value.Srix) & 0b1) << 8
        Value_int |= (int(Value.Khz125Part1) & 0b1) << 7
        Value_int |= (int(Value.Felica) & 0b1) << 6
        Value_int |= (int(Value.IClass) & 0b1) << 5
        Value_int |= (int(Value.IClassIso14B) & 0b1) << 4
        Value_int |= (int(Value.Iso14443B) & 0b1) << 3
        Value_int |= (int(Value.Iso15693) & 0b1) << 2
        Value_int |= (int(Value.Iso14443A) & 0b1) << 0
        _send_buffer.write(Value_int.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Rule_ndx: int, Value: Union[CardFamilies, CardFamilies_Dict]) -> None:
        frame = self.build_frame(Rule_ndx=Rule_ndx, Value=Value)
        self.process_frame(frame)
class Autoread_Rule_PrioritizationMode(ConfigValue):
    MasterKey: ClassVar[int] = 0x04
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x08
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 63
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, Rule_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x08')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Autoread_Rule_PrioritizationMode_PrioMode:
        _recv_buffer = BytesIO(frame)
        _PrioMode = Autoread_Rule_PrioritizationMode_PrioMode_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _PrioMode
    def get(self, Rule_ndx: int, default: Optional[Autoread_Rule_PrioritizationMode_PrioMode] = None) -> Optional[Autoread_Rule_PrioritizationMode_PrioMode]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x08')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Rule_ndx: int, PrioMode: Autoread_Rule_PrioritizationMode_PrioMode) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x08')
        _send_buffer.write(Autoread_Rule_PrioritizationMode_PrioMode_Parser.as_value(PrioMode).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Rule_ndx: int, PrioMode: Autoread_Rule_PrioritizationMode_PrioMode) -> None:
        frame = self.build_frame(Rule_ndx=Rule_ndx, PrioMode=PrioMode)
        self.process_frame(frame)
class Autoread_Rule_PrioritizationTriggeringCardFamilies(ConfigValue):
    MasterKey: ClassVar[int] = 0x04
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x09
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 63
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, Rule_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\t')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> CardFamilies:
        _recv_buffer = BytesIO(frame)
        _Value_int = safe_read_int_from_buffer(_recv_buffer, 2)
        _LEGICPrime = bool((_Value_int >> 11) & 0b1)
        _BluetoothMce = bool((_Value_int >> 10) & 0b1)
        _Khz125Part2 = bool((_Value_int >> 9) & 0b1)
        _Srix = bool((_Value_int >> 8) & 0b1)
        _Khz125Part1 = bool((_Value_int >> 7) & 0b1)
        _Felica = bool((_Value_int >> 6) & 0b1)
        _IClass = bool((_Value_int >> 5) & 0b1)
        _IClassIso14B = bool((_Value_int >> 4) & 0b1)
        _Iso14443B = bool((_Value_int >> 3) & 0b1)
        _Iso15693 = bool((_Value_int >> 2) & 0b1)
        _Iso14443A = bool((_Value_int >> 0) & 0b1)
        _Value = CardFamilies(_LEGICPrime, _BluetoothMce, _Khz125Part2, _Srix, _Khz125Part1, _Felica, _IClass, _IClassIso14B, _Iso14443B, _Iso15693, _Iso14443A)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, Rule_ndx: int, default: Optional[CardFamilies] = None) -> Optional[CardFamilies]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\t')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Rule_ndx: int, Value: Union[CardFamilies, CardFamilies_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\t')
        if isinstance(Value, dict):
            Value = CardFamilies(**Value)
        Value_int = 0
        Value_int |= (int(Value.LEGICPrime) & 0b1) << 11
        Value_int |= (int(Value.BluetoothMce) & 0b1) << 10
        Value_int |= (int(Value.Khz125Part2) & 0b1) << 9
        Value_int |= (int(Value.Srix) & 0b1) << 8
        Value_int |= (int(Value.Khz125Part1) & 0b1) << 7
        Value_int |= (int(Value.Felica) & 0b1) << 6
        Value_int |= (int(Value.IClass) & 0b1) << 5
        Value_int |= (int(Value.IClassIso14B) & 0b1) << 4
        Value_int |= (int(Value.Iso14443B) & 0b1) << 3
        Value_int |= (int(Value.Iso15693) & 0b1) << 2
        Value_int |= (int(Value.Iso14443A) & 0b1) << 0
        _send_buffer.write(Value_int.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Rule_ndx: int, Value: Union[CardFamilies, CardFamilies_Dict]) -> None:
        frame = self.build_frame(Rule_ndx=Rule_ndx, Value=Value)
        self.process_frame(frame)
class Autoread_Rule_OnMatchAction(ConfigValue):
    MasterKey: ClassVar[int] = 0x04
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x0A
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 63
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, Rule_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\n')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Autoread_Rule_OnMatchAction_Action:
        _recv_buffer = BytesIO(frame)
        _Action = Autoread_Rule_OnMatchAction_Action_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Action
    def get(self, Rule_ndx: int, default: Optional[Autoread_Rule_OnMatchAction_Action] = None) -> Optional[Autoread_Rule_OnMatchAction_Action]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\n')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Rule_ndx: int, Action: Autoread_Rule_OnMatchAction_Action) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\n')
        _send_buffer.write(Autoread_Rule_OnMatchAction_Action_Parser.as_value(Action).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Rule_ndx: int, Action: Autoread_Rule_OnMatchAction_Action) -> None:
        frame = self.build_frame(Rule_ndx=Rule_ndx, Action=Action)
        self.process_frame(frame)
class Autoread_Rule_AllowRandomSerialNumbers(ConfigValue):
    MasterKey: ClassVar[int] = 0x04
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x0B
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 63
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, Rule_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x0b')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> bool:
        _recv_buffer = BytesIO(frame)
        _Value = bool(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, Rule_ndx: int, default: Optional[bool] = None) -> Optional[bool]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x0b')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Rule_ndx: int, Value: bool) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x0b')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Rule_ndx: int, Value: bool) -> None:
        frame = self.build_frame(Rule_ndx=Rule_ndx, Value=Value)
        self.process_frame(frame)
class Autoread_Rule_OnMatchEvent(ConfigValue):
    MasterKey: ClassVar[int] = 0x04
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x0C
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 63
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, Rule_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x0c')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, Rule_ndx: int, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x0c')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Rule_ndx: int, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x0c')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Rule_ndx: int, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Rule_ndx=Rule_ndx, Value=Value)
        self.process_frame(frame)
class Autoread_Rule_VhlFileName(ConfigValue):
    MasterKey: ClassVar[int] = 0x04
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x0D
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 63
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, Rule_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\r')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, Rule_ndx: int, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\r')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Rule_ndx: int, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\r')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Rule_ndx: int, Value: str) -> None:
        frame = self.build_frame(Rule_ndx=Rule_ndx, Value=Value)
        self.process_frame(frame)
class Autoread_Rule_CheckScript(ConfigValue):
    MasterKey: ClassVar[int] = 0x04
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x10
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 63
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, Rule_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x10')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, Rule_ndx: int, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x10')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Rule_ndx: int, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x10')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Rule_ndx: int, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Rule_ndx=Rule_ndx, Value=Value)
        self.process_frame(frame)
class Autoread_Rule_BlackWhiteListTemplate(ConfigValue):
    MasterKey: ClassVar[int] = 0x04
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x11
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 63
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, Rule_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x11')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Template:
        _recv_buffer = BytesIO(frame)
        _Value = Template(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, Rule_ndx: int, default: Optional[Template] = None) -> Optional[Template]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x11')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Rule_ndx: int, Value: Union[Template, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x11')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Rule_ndx: int, Value: Union[Template, bytes]) -> None:
        frame = self.build_frame(Rule_ndx=Rule_ndx, Value=Value)
        self.process_frame(frame)
class Autoread_Rule_SendProtocol(ConfigValue):
    MasterKey: ClassVar[int] = 0x04
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x12
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 63
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, Rule_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x12')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> ProtocolID:
        _recv_buffer = BytesIO(frame)
        _ProtocolId = ProtocolID_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ProtocolId
    def get(self, Rule_ndx: int, default: Optional[ProtocolID] = None) -> Optional[ProtocolID]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x12')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Rule_ndx: int, ProtocolId: ProtocolID) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x12')
        _send_buffer.write(ProtocolID_Parser.as_value(ProtocolId).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Rule_ndx: int, ProtocolId: ProtocolID) -> None:
        frame = self.build_frame(Rule_ndx=Rule_ndx, ProtocolId=ProtocolId)
        self.process_frame(frame)
class Autoread_Rule_TemplateExt1(ConfigValue):
    MasterKey: ClassVar[int] = 0x04
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x31
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 63
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, Rule_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'1')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Template:
        _recv_buffer = BytesIO(frame)
        _Value = Template(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, Rule_ndx: int, default: Optional[Template] = None) -> Optional[Template]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'1')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Rule_ndx: int, Value: Union[Template, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'1')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Rule_ndx: int, Value: Union[Template, bytes]) -> None:
        frame = self.build_frame(Rule_ndx=Rule_ndx, Value=Value)
        self.process_frame(frame)
class Autoread_Rule_TemplateExt2(ConfigValue):
    MasterKey: ClassVar[int] = 0x04
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x32
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 63
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, Rule_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'2')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Template:
        _recv_buffer = BytesIO(frame)
        _Value = Template(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, Rule_ndx: int, default: Optional[Template] = None) -> Optional[Template]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'2')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Rule_ndx: int, Value: Union[Template, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'2')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Rule_ndx: int, Value: Union[Template, bytes]) -> None:
        frame = self.build_frame(Rule_ndx=Rule_ndx, Value=Value)
        self.process_frame(frame)
class Autoread_Rule_Counter(ConfigValue):
    MasterKey: ClassVar[int] = 0x04
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x44
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 63
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, Rule_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'D')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 4)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, Rule_ndx: int, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'D')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Rule_ndx: int, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'D')
        _send_buffer.write(Value.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Rule_ndx: int, Value: int) -> None:
        frame = self.build_frame(Rule_ndx=Rule_ndx, Value=Value)
        self.process_frame(frame)
class Autoread_Rule_OnMatchSendApdu(ConfigValue):
    MasterKey: ClassVar[int] = 0x04
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x13
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 63
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, Rule_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x13')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, Rule_ndx: int, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x13')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Rule_ndx: int, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x04')
        if Rule_ndx < 0 or Rule_ndx >= 63:
            raise IndexError(Rule_ndx)
        _send_buffer.write((1 + Rule_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x13')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Rule_ndx: int, Value: str) -> None:
        frame = self.build_frame(Rule_ndx=Rule_ndx, Value=Value)
        self.process_frame(frame)
class Scripts(ConfigBase):
    MasterKey: ClassVar[int] = 0x05
    MasterKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        self.process_frame(_send_buffer.getvalue())
class Scripts_StaticMessages(ConfigBase):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
class Scripts_StaticMessages_SendMessage(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x00
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 3
    def reset(self, SendMessage_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x02')
        if SendMessage_ndx < 0 or SendMessage_ndx >= 3:
            raise IndexError(SendMessage_ndx)
        _send_buffer.write((0 + SendMessage_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, SendMessage_ndx: int, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x02')
        if SendMessage_ndx < 0 or SendMessage_ndx >= 3:
            raise IndexError(SendMessage_ndx)
        _send_buffer.write((0 + SendMessage_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, SendMessage_ndx: int, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x02')
        if SendMessage_ndx < 0 or SendMessage_ndx >= 3:
            raise IndexError(SendMessage_ndx)
        _send_buffer.write((0 + SendMessage_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, SendMessage_ndx: int, Value: str) -> None:
        frame = self.build_frame(SendMessage_ndx=SendMessage_ndx, Value=Value)
        self.process_frame(frame)
class Scripts_StaticMessages_SendMsgLegacy(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x03
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 125
    def reset(self, SendMsgLegacy_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x02')
        if SendMsgLegacy_ndx < 0 or SendMsgLegacy_ndx >= 125:
            raise IndexError(SendMsgLegacy_ndx)
        _send_buffer.write((3 + SendMsgLegacy_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, SendMsgLegacy_ndx: int, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x02')
        if SendMsgLegacy_ndx < 0 or SendMsgLegacy_ndx >= 125:
            raise IndexError(SendMsgLegacy_ndx)
        _send_buffer.write((3 + SendMsgLegacy_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, SendMsgLegacy_ndx: int, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x02')
        if SendMsgLegacy_ndx < 0 or SendMsgLegacy_ndx >= 125:
            raise IndexError(SendMsgLegacy_ndx)
        _send_buffer.write((3 + SendMsgLegacy_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, SendMsgLegacy_ndx: int, Value: str) -> None:
        frame = self.build_frame(SendMsgLegacy_ndx=SendMsgLegacy_ndx, Value=Value)
        self.process_frame(frame)
class Scripts_StaticMessages_MatchMessage(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x80
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 3
    def reset(self, MatchMessage_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x02')
        if MatchMessage_ndx < 0 or MatchMessage_ndx >= 3:
            raise IndexError(MatchMessage_ndx)
        _send_buffer.write((128 + MatchMessage_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, MatchMessage_ndx: int, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x02')
        if MatchMessage_ndx < 0 or MatchMessage_ndx >= 3:
            raise IndexError(MatchMessage_ndx)
        _send_buffer.write((128 + MatchMessage_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, MatchMessage_ndx: int, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x02')
        if MatchMessage_ndx < 0 or MatchMessage_ndx >= 3:
            raise IndexError(MatchMessage_ndx)
        _send_buffer.write((128 + MatchMessage_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, MatchMessage_ndx: int, Value: str) -> None:
        frame = self.build_frame(MatchMessage_ndx=MatchMessage_ndx, Value=Value)
        self.process_frame(frame)
class Scripts_Events(ConfigBase):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
class Scripts_Events_OnSetState(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x00
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 4
    def reset(self, OnSetState_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnSetState_ndx < 0 or OnSetState_ndx >= 4:
            raise IndexError(OnSetState_ndx)
        _send_buffer.write((0 + OnSetState_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, OnSetState_ndx: int, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnSetState_ndx < 0 or OnSetState_ndx >= 4:
            raise IndexError(OnSetState_ndx)
        _send_buffer.write((0 + OnSetState_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, OnSetState_ndx: int, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnSetState_ndx < 0 or OnSetState_ndx >= 4:
            raise IndexError(OnSetState_ndx)
        _send_buffer.write((0 + OnSetState_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, OnSetState_ndx: int, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(OnSetState_ndx=OnSetState_ndx, Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnSetInput(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x04
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 2
    def reset(self, OnSetInput_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnSetInput_ndx < 0 or OnSetInput_ndx >= 2:
            raise IndexError(OnSetInput_ndx)
        _send_buffer.write((4 + OnSetInput_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, OnSetInput_ndx: int, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnSetInput_ndx < 0 or OnSetInput_ndx >= 2:
            raise IndexError(OnSetInput_ndx)
        _send_buffer.write((4 + OnSetInput_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, OnSetInput_ndx: int, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnSetInput_ndx < 0 or OnSetInput_ndx >= 2:
            raise IndexError(OnSetInput_ndx)
        _send_buffer.write((4 + OnSetInput_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, OnSetInput_ndx: int, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(OnSetInput_ndx=OnSetInput_ndx, Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnSetTamperAlarm(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x07
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x07')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x07')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x07')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnSetGpio(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x08
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 6
    def reset(self, OnSetGpio_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnSetGpio_ndx < 0 or OnSetGpio_ndx >= 6:
            raise IndexError(OnSetGpio_ndx)
        _send_buffer.write((8 + OnSetGpio_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, OnSetGpio_ndx: int, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnSetGpio_ndx < 0 or OnSetGpio_ndx >= 6:
            raise IndexError(OnSetGpio_ndx)
        _send_buffer.write((8 + OnSetGpio_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, OnSetGpio_ndx: int, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnSetGpio_ndx < 0 or OnSetGpio_ndx >= 6:
            raise IndexError(OnSetGpio_ndx)
        _send_buffer.write((8 + OnSetGpio_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, OnSetGpio_ndx: int, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(OnSetGpio_ndx=OnSetGpio_ndx, Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnClearState(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x20
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 4
    def reset(self, OnClearState_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnClearState_ndx < 0 or OnClearState_ndx >= 4:
            raise IndexError(OnClearState_ndx)
        _send_buffer.write((32 + OnClearState_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, OnClearState_ndx: int, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnClearState_ndx < 0 or OnClearState_ndx >= 4:
            raise IndexError(OnClearState_ndx)
        _send_buffer.write((32 + OnClearState_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, OnClearState_ndx: int, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnClearState_ndx < 0 or OnClearState_ndx >= 4:
            raise IndexError(OnClearState_ndx)
        _send_buffer.write((32 + OnClearState_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, OnClearState_ndx: int, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(OnClearState_ndx=OnClearState_ndx, Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnClearInput(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x24
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 2
    def reset(self, OnClearInput_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnClearInput_ndx < 0 or OnClearInput_ndx >= 2:
            raise IndexError(OnClearInput_ndx)
        _send_buffer.write((36 + OnClearInput_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, OnClearInput_ndx: int, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnClearInput_ndx < 0 or OnClearInput_ndx >= 2:
            raise IndexError(OnClearInput_ndx)
        _send_buffer.write((36 + OnClearInput_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, OnClearInput_ndx: int, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnClearInput_ndx < 0 or OnClearInput_ndx >= 2:
            raise IndexError(OnClearInput_ndx)
        _send_buffer.write((36 + OnClearInput_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, OnClearInput_ndx: int, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(OnClearInput_ndx=OnClearInput_ndx, Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnClearTamperAlarm(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x27
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b"'")
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b"'")
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b"'")
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnClearGpio(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x28
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 6
    def reset(self, OnClearGpio_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnClearGpio_ndx < 0 or OnClearGpio_ndx >= 6:
            raise IndexError(OnClearGpio_ndx)
        _send_buffer.write((40 + OnClearGpio_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, OnClearGpio_ndx: int, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnClearGpio_ndx < 0 or OnClearGpio_ndx >= 6:
            raise IndexError(OnClearGpio_ndx)
        _send_buffer.write((40 + OnClearGpio_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, OnClearGpio_ndx: int, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnClearGpio_ndx < 0 or OnClearGpio_ndx >= 6:
            raise IndexError(OnClearGpio_ndx)
        _send_buffer.write((40 + OnClearGpio_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, OnClearGpio_ndx: int, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(OnClearGpio_ndx=OnClearGpio_ndx, Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnPinEntry(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x3C
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'<')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'<')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'<')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnDetectedCard(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x40
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'@')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'@')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'@')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnMatchMsg(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x41
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 3
    def reset(self, OnMatchMsg_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnMatchMsg_ndx < 0 or OnMatchMsg_ndx >= 3:
            raise IndexError(OnMatchMsg_ndx)
        _send_buffer.write((65 + OnMatchMsg_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, OnMatchMsg_ndx: int, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnMatchMsg_ndx < 0 or OnMatchMsg_ndx >= 3:
            raise IndexError(OnMatchMsg_ndx)
        _send_buffer.write((65 + OnMatchMsg_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, OnMatchMsg_ndx: int, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnMatchMsg_ndx < 0 or OnMatchMsg_ndx >= 3:
            raise IndexError(OnMatchMsg_ndx)
        _send_buffer.write((65 + OnMatchMsg_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, OnMatchMsg_ndx: int, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(OnMatchMsg_ndx=OnMatchMsg_ndx, Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnAccepted(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x44
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'D')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'D')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'D')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnInvalidCard(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x45
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'E')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'E')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'E')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnEnabledProtocol(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x46
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'F')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'F')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'F')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnBlackWhiteListDenied(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x47
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'G')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'G')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'G')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnSetGreenLed(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x48
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'H')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'H')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'H')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnSetRedLed(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x49
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'I')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'I')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'I')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnSetBeeper(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x4A
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'J')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'J')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'J')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnSetRelay(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x4B
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'K')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'K')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'K')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnSetBlueLed(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x4E
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'N')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'N')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'N')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnClearGreenLed(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x50
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'P')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'P')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'P')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnClearRedLed(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x51
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'Q')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'Q')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'Q')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnClearBeeper(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x52
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'R')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'R')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'R')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnClearRelay(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x53
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'S')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'S')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'S')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnClearBlueLed(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x56
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'V')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'V')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'V')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnTimer(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x68
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 3
    def reset(self, OnTimer_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnTimer_ndx < 0 or OnTimer_ndx >= 3:
            raise IndexError(OnTimer_ndx)
        _send_buffer.write((104 + OnTimer_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, OnTimer_ndx: int, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnTimer_ndx < 0 or OnTimer_ndx >= 3:
            raise IndexError(OnTimer_ndx)
        _send_buffer.write((104 + OnTimer_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, OnTimer_ndx: int, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnTimer_ndx < 0 or OnTimer_ndx >= 3:
            raise IndexError(OnTimer_ndx)
        _send_buffer.write((104 + OnTimer_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, OnTimer_ndx: int, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(OnTimer_ndx=OnTimer_ndx, Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnConfigCardSucceeded(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x70
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'p')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'p')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'p')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnConfigCardFailed(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x71
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'q')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'q')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'q')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnPowerup(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x72
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'r')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'r')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'r')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnAutoreadEnabled(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x73
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b's')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b's')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b's')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnAutoreadDisabled(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x74
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b't')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b't')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b't')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnScan(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x75
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'u')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'u')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'u')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnDetectedNoCard(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x76
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'v')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'v')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'v')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnCheckSuppressRepeat(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x77
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'w')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'w')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'w')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnBrpCommand(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x78
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'x')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'x')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'x')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnCardRemoved(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x79
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'y')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'y')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'y')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnCardProcessed(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x7A
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'z')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'z')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'z')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnCardAcceptedByHost(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x7B
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'{')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'{')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'{')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnCardDeniedByHost(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x7C
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'|')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'|')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'|')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device(ConfigBase):
    MasterKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
class Device_Keypad(ConfigBase):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x03
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        self.process_frame(_send_buffer.getvalue())
class Device_Keypad_SpecialKeySettings(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x03
    ValueKey: ClassVar[int] = 0x00
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x00')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Device_Keypad_SpecialKeySettings_Settings:
        _recv_buffer = BytesIO(frame)
        _Settings = Device_Keypad_SpecialKeySettings_Settings_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Settings
    def get(self, default: Optional[Device_Keypad_SpecialKeySettings_Settings] = None) -> Optional[Device_Keypad_SpecialKeySettings_Settings]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x00')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Settings: Device_Keypad_SpecialKeySettings_Settings) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x00')
        _send_buffer.write(Device_Keypad_SpecialKeySettings_Settings_Parser.as_value(Settings).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Settings: Device_Keypad_SpecialKeySettings_Settings) -> None:
        frame = self.build_frame(Settings=Settings)
        self.process_frame(frame)
class Device_Keypad_Timeout(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x03
    ValueKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x01')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x01')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Keypad_PinLength(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x03
    ValueKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x02')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x02')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Keypad_KeyPressSignal(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x03
    ValueKey: ClassVar[int] = 0x03
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x03')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Device_Keypad_KeyPressSignal_SignalType:
        _recv_buffer = BytesIO(frame)
        _SignalType = Device_Keypad_KeyPressSignal_SignalType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _SignalType
    def get(self, default: Optional[Device_Keypad_KeyPressSignal_SignalType] = None) -> Optional[Device_Keypad_KeyPressSignal_SignalType]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x03')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, SignalType: Device_Keypad_KeyPressSignal_SignalType) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x03')
        _send_buffer.write(Device_Keypad_KeyPressSignal_SignalType_Parser.as_value(SignalType).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, SignalType: Device_Keypad_KeyPressSignal_SignalType) -> None:
        frame = self.build_frame(SignalType=SignalType)
        self.process_frame(frame)
class Device_Boot(ConfigBase):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
class Device_Boot_FireInputEventAtPowerup(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x14
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 2
    def reset(self, FireInputEventAtPowerup_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        if FireInputEventAtPowerup_ndx < 0 or FireInputEventAtPowerup_ndx >= 2:
            raise IndexError(FireInputEventAtPowerup_ndx)
        _send_buffer.write((20 + FireInputEventAtPowerup_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> FireEventAtPowerup:
        _recv_buffer = BytesIO(frame)
        _Value = FireEventAtPowerup_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, FireInputEventAtPowerup_ndx: int, default: Optional[FireEventAtPowerup] = None) -> Optional[FireEventAtPowerup]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        if FireInputEventAtPowerup_ndx < 0 or FireInputEventAtPowerup_ndx >= 2:
            raise IndexError(FireInputEventAtPowerup_ndx)
        _send_buffer.write((20 + FireInputEventAtPowerup_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, FireInputEventAtPowerup_ndx: int, Value: FireEventAtPowerup) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        if FireInputEventAtPowerup_ndx < 0 or FireInputEventAtPowerup_ndx >= 2:
            raise IndexError(FireInputEventAtPowerup_ndx)
        _send_buffer.write((20 + FireInputEventAtPowerup_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(FireEventAtPowerup_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, FireInputEventAtPowerup_ndx: int, Value: FireEventAtPowerup) -> None:
        frame = self.build_frame(FireInputEventAtPowerup_ndx=FireInputEventAtPowerup_ndx, Value=Value)
        self.process_frame(frame)
class Device_Boot_FireTamperEventAtPowerup(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x17
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x17')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> FireEventAtPowerup:
        _recv_buffer = BytesIO(frame)
        _Value = FireEventAtPowerup_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[FireEventAtPowerup] = None) -> Optional[FireEventAtPowerup]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x17')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: FireEventAtPowerup) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x17')
        _send_buffer.write(FireEventAtPowerup_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: FireEventAtPowerup) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Boot_FireGpioEventAtPowerup(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x18
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 8
    def reset(self, FireGpioEventAtPowerup_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        if FireGpioEventAtPowerup_ndx < 0 or FireGpioEventAtPowerup_ndx >= 8:
            raise IndexError(FireGpioEventAtPowerup_ndx)
        _send_buffer.write((24 + FireGpioEventAtPowerup_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> FireEventAtPowerup:
        _recv_buffer = BytesIO(frame)
        _Value = FireEventAtPowerup_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, FireGpioEventAtPowerup_ndx: int, default: Optional[FireEventAtPowerup] = None) -> Optional[FireEventAtPowerup]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        if FireGpioEventAtPowerup_ndx < 0 or FireGpioEventAtPowerup_ndx >= 8:
            raise IndexError(FireGpioEventAtPowerup_ndx)
        _send_buffer.write((24 + FireGpioEventAtPowerup_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, FireGpioEventAtPowerup_ndx: int, Value: FireEventAtPowerup) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        if FireGpioEventAtPowerup_ndx < 0 or FireGpioEventAtPowerup_ndx >= 8:
            raise IndexError(FireGpioEventAtPowerup_ndx)
        _send_buffer.write((24 + FireGpioEventAtPowerup_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(FireEventAtPowerup_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, FireGpioEventAtPowerup_ndx: int, Value: FireEventAtPowerup) -> None:
        frame = self.build_frame(FireGpioEventAtPowerup_ndx=FireGpioEventAtPowerup_ndx, Value=Value)
        self.process_frame(frame)
class Device_Boot_StartAutoreadAtPowerup(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> AutoReadMode:
        _recv_buffer = BytesIO(frame)
        _Mode = AutoReadMode_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Mode
    def get(self, default: Optional[AutoReadMode] = None) -> Optional[AutoReadMode]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Mode: AutoReadMode) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(AutoReadMode_Parser.as_value(Mode).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Mode: AutoReadMode) -> None:
        frame = self.build_frame(Mode=Mode)
        self.process_frame(frame)
class Device_Boot_FirmwareCrcCheck(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Device_Boot_FirmwareCrcCheck_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Device_Boot_FirmwareCrcCheck_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Device_Boot_FirmwareCrcCheck_Value] = None) -> Optional[Device_Boot_FirmwareCrcCheck_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Device_Boot_FirmwareCrcCheck_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(Device_Boot_FirmwareCrcCheck_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Device_Boot_FirmwareCrcCheck_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run(ConfigBase):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
class Device_Run_ConfigCardAcceptTime(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x00
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x00')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x00')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x00')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_EnabledProtocols(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x03
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[ProtocolID]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _ProtocolId = ProtocolID_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
            _Value.append(_ProtocolId)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[List[ProtocolID]] = None) -> Optional[List[ProtocolID]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: List[ProtocolID]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        for _Value_Entry in Value:
            _ProtocolId = _Value_Entry
            _send_buffer.write(ProtocolID_Parser.as_value(_ProtocolId).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: List[ProtocolID]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_AutoreadPulseHf(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x04
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Device_Run_AutoreadPulseHf_PulseHf:
        _recv_buffer = BytesIO(frame)
        _PulseHf = Device_Run_AutoreadPulseHf_PulseHf_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _PulseHf
    def get(self, default: Optional[Device_Run_AutoreadPulseHf_PulseHf] = None) -> Optional[Device_Run_AutoreadPulseHf_PulseHf]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, PulseHf: Device_Run_AutoreadPulseHf_PulseHf) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        _send_buffer.write(Device_Run_AutoreadPulseHf_PulseHf_Parser.as_value(PulseHf).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, PulseHf: Device_Run_AutoreadPulseHf_PulseHf) -> None:
        frame = self.build_frame(PulseHf=PulseHf)
        self.process_frame(frame)
class Device_Run_RepeatMessageDelay(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x07
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x07')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x07')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x07')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_RepeatMessageMode(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x0C
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x0c')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Device_Run_RepeatMessageMode_Result:
        _recv_buffer = BytesIO(frame)
        _Mode_int = safe_read_int_from_buffer(_recv_buffer, 1)
        _Suppress = bool((_Mode_int >> 1) & 0b1)
        _Force = bool((_Mode_int >> 0) & 0b1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Device_Run_RepeatMessageMode_Result(_Suppress, _Force)
    def get(self, default: Optional[Device_Run_RepeatMessageMode_Result] = None) -> Optional[Device_Run_RepeatMessageMode_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x0c')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Suppress: bool, Force: bool) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x0c')
        _var_0000_int = 0
        _var_0000_int |= (int(Suppress) & 0b1) << 1
        _var_0000_int |= (int(Force) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Suppress: bool, Force: bool) -> None:
        frame = self.build_frame(Suppress=Suppress, Force=Force)
        self.process_frame(frame)
class Device_Run_RestrictFirmwareRelease(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x0E
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x0e')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x0e')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x0e')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_EnableProtocolOnBAC(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x11
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x11')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> ProtocolID:
        _recv_buffer = BytesIO(frame)
        _Value = ProtocolID_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[ProtocolID] = None) -> Optional[ProtocolID]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x11')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: ProtocolID) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x11')
        _send_buffer.write(ProtocolID_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: ProtocolID) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_AccessRightsOfBAC(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x12
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x12')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Device_Run_AccessRightsOfBAC_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Device_Run_AccessRightsOfBAC_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Device_Run_AccessRightsOfBAC_Value] = None) -> Optional[Device_Run_AccessRightsOfBAC_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x12')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Device_Run_AccessRightsOfBAC_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x12')
        _send_buffer.write(Device_Run_AccessRightsOfBAC_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Device_Run_AccessRightsOfBAC_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_FirmwareVersionBlacklist(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x14
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x14')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[FirmwareVersion]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _FirmwareID = safe_read_int_from_buffer(_recv_buffer, 2)
            _SmallestBlockedFwVersionMajor = safe_read_int_from_buffer(_recv_buffer, 1)
            _SmallestBlockedFwVersionMinor = safe_read_int_from_buffer(_recv_buffer, 1)
            _SmallestBlockedFwVersionBuild = safe_read_int_from_buffer(_recv_buffer, 1)
            _GreatestBlockedFwVersionMajor = safe_read_int_from_buffer(_recv_buffer, 1)
            _GreatestBlockedFwVersionMinor = safe_read_int_from_buffer(_recv_buffer, 1)
            _GreatestBlockedFwVersionBuild = safe_read_int_from_buffer(_recv_buffer, 1)
            _BlacklistedFirmware = FirmwareVersion(_FirmwareID, _SmallestBlockedFwVersionMajor, _SmallestBlockedFwVersionMinor, _SmallestBlockedFwVersionBuild, _GreatestBlockedFwVersionMajor, _GreatestBlockedFwVersionMinor, _GreatestBlockedFwVersionBuild)
            _Value.append(_BlacklistedFirmware)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[List[FirmwareVersion]] = None) -> Optional[List[FirmwareVersion]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x14')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: List[FirmwareVersion]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x14')
        for _Value_Entry in Value:
            _BlacklistedFirmware = _Value_Entry
            if isinstance(_BlacklistedFirmware, dict):
                _BlacklistedFirmware = FirmwareVersion(**_BlacklistedFirmware)
            _FirmwareID, _SmallestBlockedFwVersionMajor, _SmallestBlockedFwVersionMinor, _SmallestBlockedFwVersionBuild, _GreatestBlockedFwVersionMajor, _GreatestBlockedFwVersionMinor, _GreatestBlockedFwVersionBuild = _BlacklistedFirmware
            _send_buffer.write(_FirmwareID.to_bytes(length=2, byteorder='big'))
            _send_buffer.write(_SmallestBlockedFwVersionMajor.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_SmallestBlockedFwVersionMinor.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_SmallestBlockedFwVersionBuild.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_GreatestBlockedFwVersionMajor.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_GreatestBlockedFwVersionMinor.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_GreatestBlockedFwVersionBuild.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: List[FirmwareVersion]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_DefaultBusAdrForBAC(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x15
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x15')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x15')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x15')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_MessageExpireTimeout(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x17
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x17')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x17')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x17')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_AutoreadPollTime(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x18
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x18')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x18')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x18')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_AuthReqUploadViaBrp(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x19
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x19')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> AuthReqUpload:
        _recv_buffer = BytesIO(frame)
        _AuthReq = AuthReqUpload_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _AuthReq
    def get(self, default: Optional[AuthReqUpload] = None) -> Optional[AuthReqUpload]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x19')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, AuthReq: AuthReqUpload = "Default") -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x19')
        _send_buffer.write(AuthReqUpload_Parser.as_value(AuthReq).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, AuthReq: AuthReqUpload = "Default") -> None:
        frame = self.build_frame(AuthReq=AuthReq)
        self.process_frame(frame)
class Device_Run_AuthReqUploadViaIso14443(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x1A
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x1a')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> AuthReqUpload:
        _recv_buffer = BytesIO(frame)
        _AuthReq = AuthReqUpload_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _AuthReq
    def get(self, default: Optional[AuthReqUpload] = None) -> Optional[AuthReqUpload]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x1a')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, AuthReq: AuthReqUpload = "Default") -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x1a')
        _send_buffer.write(AuthReqUpload_Parser.as_value(AuthReq).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, AuthReq: AuthReqUpload = "Default") -> None:
        frame = self.build_frame(AuthReq=AuthReq)
        self.process_frame(frame)
class Device_Run_AutoreadWaitForCardRemoval(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x1B
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x1b')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Device_Run_AutoreadWaitForCardRemoval_WaitForCardRemoval:
        _recv_buffer = BytesIO(frame)
        _WaitForCardRemoval = Device_Run_AutoreadWaitForCardRemoval_WaitForCardRemoval_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _WaitForCardRemoval
    def get(self, default: Optional[Device_Run_AutoreadWaitForCardRemoval_WaitForCardRemoval] = None) -> Optional[Device_Run_AutoreadWaitForCardRemoval_WaitForCardRemoval]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x1b')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, WaitForCardRemoval: Device_Run_AutoreadWaitForCardRemoval_WaitForCardRemoval) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x1b')
        _send_buffer.write(Device_Run_AutoreadWaitForCardRemoval_WaitForCardRemoval_Parser.as_value(WaitForCardRemoval).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, WaitForCardRemoval: Device_Run_AutoreadWaitForCardRemoval_WaitForCardRemoval) -> None:
        frame = self.build_frame(WaitForCardRemoval=WaitForCardRemoval)
        self.process_frame(frame)
class Device_Run_UsbVendorId(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x1C
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x1c')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x1c')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x1c')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_UsbProductId(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x1D
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x1d')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x1d')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x1d')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_DenyUploadViaIso14443(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x1E
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x1e')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Device_Run_DenyUploadViaIso14443_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Device_Run_DenyUploadViaIso14443_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Device_Run_DenyUploadViaIso14443_Value] = None) -> Optional[Device_Run_DenyUploadViaIso14443_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x1e')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Device_Run_DenyUploadViaIso14443_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x1e')
        _send_buffer.write(Device_Run_DenyUploadViaIso14443_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Device_Run_DenyUploadViaIso14443_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_DenyReaderInfoViaIso14443(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x1F
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x1f')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Device_Run_DenyReaderInfoViaIso14443_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Device_Run_DenyReaderInfoViaIso14443_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Device_Run_DenyReaderInfoViaIso14443_Value] = None) -> Optional[Device_Run_DenyReaderInfoViaIso14443_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x1f')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Device_Run_DenyReaderInfoViaIso14443_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x1f')
        _send_buffer.write(Device_Run_DenyReaderInfoViaIso14443_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Device_Run_DenyReaderInfoViaIso14443_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_DenyUnauthFwUploadViaBrp(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x20
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b' ')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Device_Run_DenyUnauthFwUploadViaBrp_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Device_Run_DenyUnauthFwUploadViaBrp_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Device_Run_DenyUnauthFwUploadViaBrp_Value] = None) -> Optional[Device_Run_DenyUnauthFwUploadViaBrp_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b' ')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Device_Run_DenyUnauthFwUploadViaBrp_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b' ')
        _send_buffer.write(Device_Run_DenyUnauthFwUploadViaBrp_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Device_Run_DenyUnauthFwUploadViaBrp_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_SetBusAdrOnUploadViaIso14443(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x21
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'!')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Device_Run_SetBusAdrOnUploadViaIso14443_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Device_Run_SetBusAdrOnUploadViaIso14443_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Device_Run_SetBusAdrOnUploadViaIso14443_Value] = None) -> Optional[Device_Run_SetBusAdrOnUploadViaIso14443_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'!')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Device_Run_SetBusAdrOnUploadViaIso14443_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'!')
        _send_buffer.write(Device_Run_SetBusAdrOnUploadViaIso14443_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Device_Run_SetBusAdrOnUploadViaIso14443_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_MaintenanceFunctionFilter(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x22
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'"')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Device_Run_MaintenanceFunctionFilter_Result:
        _recv_buffer = BytesIO(frame)
        _Value_int = safe_read_int_from_buffer(_recv_buffer, 2)
        _DisableReaderInfo = bool((_Value_int >> 4) & 0b1)
        _DisableBec2Upload = bool((_Value_int >> 3) & 0b1)
        _DisableLicenseCards = bool((_Value_int >> 2) & 0b1)
        _DisableAdrCards = bool((_Value_int >> 1) & 0b1)
        _DisableConfigCards = bool((_Value_int >> 0) & 0b1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Device_Run_MaintenanceFunctionFilter_Result(_DisableReaderInfo, _DisableBec2Upload, _DisableLicenseCards, _DisableAdrCards, _DisableConfigCards)
    def get(self, default: Optional[Device_Run_MaintenanceFunctionFilter_Result] = None) -> Optional[Device_Run_MaintenanceFunctionFilter_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'"')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, DisableReaderInfo: bool, DisableBec2Upload: bool, DisableLicenseCards: bool, DisableAdrCards: bool, DisableConfigCards: bool) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'"')
        _var_0000_int = 0
        _var_0000_int |= (int(DisableReaderInfo) & 0b1) << 4
        _var_0000_int |= (int(DisableBec2Upload) & 0b1) << 3
        _var_0000_int |= (int(DisableLicenseCards) & 0b1) << 2
        _var_0000_int |= (int(DisableAdrCards) & 0b1) << 1
        _var_0000_int |= (int(DisableConfigCards) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, DisableReaderInfo: bool, DisableBec2Upload: bool, DisableLicenseCards: bool, DisableAdrCards: bool, DisableConfigCards: bool) -> None:
        frame = self.build_frame(DisableReaderInfo=DisableReaderInfo, DisableBec2Upload=DisableBec2Upload, DisableLicenseCards=DisableLicenseCards, DisableAdrCards=DisableAdrCards, DisableConfigCards=DisableConfigCards)
        self.process_frame(frame)
class Device_Run_BusAdressByBAC32Bit(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x23
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'#')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 4)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'#')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'#')
        _send_buffer.write(Value.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_ConfigCardMifareKey(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x81
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x81')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x81')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x81')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_ConfigSecurityCode(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x82
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x82')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x82')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x82')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_CustomerKey(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x85
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x85')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x85')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x85')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_AltConfigSecurityCode(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x8A
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x8a')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x8a')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x8a')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_ConfigCardDesfireKey(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x8F
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x8f')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x8f')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x8f')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_HostSecurity(ConfigBase):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x08
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        self.process_frame(_send_buffer.getvalue())
class Device_HostSecurity_AccessConditionMask(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x08
    ValueKey: ClassVar[int] = 0x00
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 4
    def reset(self, AccessConditionMask_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if AccessConditionMask_ndx < 0 or AccessConditionMask_ndx >= 4:
            raise IndexError(AccessConditionMask_ndx)
        _send_buffer.write((0 + AccessConditionMask_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> HostSecurityAccessConditionBits:
        _recv_buffer = BytesIO(frame)
        _Value_int = safe_read_int_from_buffer(_recv_buffer, 4)
        _HostToHostAccess = bool((_Value_int >> 28) & 0b1)
        _AutoreadAccess = bool((_Value_int >> 27) & 0b1)
        _CryptoAccess = bool((_Value_int >> 26) & 0b1)
        _Bf2Upload = bool((_Value_int >> 25) & 0b1)
        _ExtendedAccess = bool((_Value_int >> 24) & 0b1)
        _FlashFileSystemWrite = bool((_Value_int >> 23) & 0b1)
        _FlashFileSystemRead = bool((_Value_int >> 22) & 0b1)
        _RtcWrite = bool((_Value_int >> 21) & 0b1)
        _VhlExchangeapdu = bool((_Value_int >> 20) & 0b1)
        _VhlFormat = bool((_Value_int >> 19) & 0b1)
        _VhlWrite = bool((_Value_int >> 18) & 0b1)
        _VhlRead = bool((_Value_int >> 17) & 0b1)
        _VhlSelect = bool((_Value_int >> 16) & 0b1)
        _ExtSamAccess = bool((_Value_int >> 15) & 0b1)
        _HfLowlevelAccess = bool((_Value_int >> 14) & 0b1)
        _GuiAccess = bool((_Value_int >> 13) & 0b1)
        _IoPortWrite = bool((_Value_int >> 12) & 0b1)
        _IoPortRead = bool((_Value_int >> 11) & 0b1)
        _ConfigReset = bool((_Value_int >> 10) & 0b1)
        _ConfigWrite = bool((_Value_int >> 9) & 0b1)
        _ConfigRead = bool((_Value_int >> 8) & 0b1)
        _SysReset = bool((_Value_int >> 7) & 0b1)
        _SetAccessConditionMask2 = bool((_Value_int >> 6) & 0b1)
        _SetAccessConditionMask1 = bool((_Value_int >> 5) & 0b1)
        _SetAccessConditionMask0 = bool((_Value_int >> 4) & 0b1)
        _SetKey3 = bool((_Value_int >> 3) & 0b1)
        _SetKey2 = bool((_Value_int >> 2) & 0b1)
        _SetKey1 = bool((_Value_int >> 1) & 0b1)
        _FactoryReset = bool((_Value_int >> 0) & 0b1)
        _Value = HostSecurityAccessConditionBits(_HostToHostAccess, _AutoreadAccess, _CryptoAccess, _Bf2Upload, _ExtendedAccess, _FlashFileSystemWrite, _FlashFileSystemRead, _RtcWrite, _VhlExchangeapdu, _VhlFormat, _VhlWrite, _VhlRead, _VhlSelect, _ExtSamAccess, _HfLowlevelAccess, _GuiAccess, _IoPortWrite, _IoPortRead, _ConfigReset, _ConfigWrite, _ConfigRead, _SysReset, _SetAccessConditionMask2, _SetAccessConditionMask1, _SetAccessConditionMask0, _SetKey3, _SetKey2, _SetKey1, _FactoryReset)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, AccessConditionMask_ndx: int, default: Optional[HostSecurityAccessConditionBits] = None) -> Optional[HostSecurityAccessConditionBits]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if AccessConditionMask_ndx < 0 or AccessConditionMask_ndx >= 4:
            raise IndexError(AccessConditionMask_ndx)
        _send_buffer.write((0 + AccessConditionMask_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, AccessConditionMask_ndx: int, Value: Union[HostSecurityAccessConditionBits, HostSecurityAccessConditionBits_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if AccessConditionMask_ndx < 0 or AccessConditionMask_ndx >= 4:
            raise IndexError(AccessConditionMask_ndx)
        _send_buffer.write((0 + AccessConditionMask_ndx).to_bytes(1, byteorder='big'))
        if isinstance(Value, dict):
            Value = HostSecurityAccessConditionBits(**Value)
        Value_int = 0
        Value_int |= (int(Value.HostToHostAccess) & 0b1) << 28
        Value_int |= (int(Value.AutoreadAccess) & 0b1) << 27
        Value_int |= (int(Value.CryptoAccess) & 0b1) << 26
        Value_int |= (int(Value.Bf2Upload) & 0b1) << 25
        Value_int |= (int(Value.ExtendedAccess) & 0b1) << 24
        Value_int |= (int(Value.FlashFileSystemWrite) & 0b1) << 23
        Value_int |= (int(Value.FlashFileSystemRead) & 0b1) << 22
        Value_int |= (int(Value.RtcWrite) & 0b1) << 21
        Value_int |= (int(Value.VhlExchangeapdu) & 0b1) << 20
        Value_int |= (int(Value.VhlFormat) & 0b1) << 19
        Value_int |= (int(Value.VhlWrite) & 0b1) << 18
        Value_int |= (int(Value.VhlRead) & 0b1) << 17
        Value_int |= (int(Value.VhlSelect) & 0b1) << 16
        Value_int |= (int(Value.ExtSamAccess) & 0b1) << 15
        Value_int |= (int(Value.HfLowlevelAccess) & 0b1) << 14
        Value_int |= (int(Value.GuiAccess) & 0b1) << 13
        Value_int |= (int(Value.IoPortWrite) & 0b1) << 12
        Value_int |= (int(Value.IoPortRead) & 0b1) << 11
        Value_int |= (int(Value.ConfigReset) & 0b1) << 10
        Value_int |= (int(Value.ConfigWrite) & 0b1) << 9
        Value_int |= (int(Value.ConfigRead) & 0b1) << 8
        Value_int |= (int(Value.SysReset) & 0b1) << 7
        Value_int |= (int(Value.SetAccessConditionMask2) & 0b1) << 6
        Value_int |= (int(Value.SetAccessConditionMask1) & 0b1) << 5
        Value_int |= (int(Value.SetAccessConditionMask0) & 0b1) << 4
        Value_int |= (int(Value.SetKey3) & 0b1) << 3
        Value_int |= (int(Value.SetKey2) & 0b1) << 2
        Value_int |= (int(Value.SetKey1) & 0b1) << 1
        Value_int |= (int(Value.FactoryReset) & 0b1) << 0
        _send_buffer.write(Value_int.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, AccessConditionMask_ndx: int, Value: Union[HostSecurityAccessConditionBits, HostSecurityAccessConditionBits_Dict]) -> None:
        frame = self.build_frame(AccessConditionMask_ndx=AccessConditionMask_ndx, Value=Value)
        self.process_frame(frame)
class Device_HostSecurity_Key(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x08
    ValueKey: ClassVar[int] = 0x81
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 4
    def reset(self, Key_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if Key_ndx < 0 or Key_ndx >= 4:
            raise IndexError(Key_ndx)
        _send_buffer.write((129 + Key_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Device_HostSecurity_Key_Result:
        _recv_buffer = BytesIO(frame)
        _AuthenticationMode_int = safe_read_int_from_buffer(_recv_buffer, 1)
        _RequireContinuousIv = bool((_AuthenticationMode_int >> 7) & 0b1)
        _RequireEncrypted = bool((_AuthenticationMode_int >> 6) & 0b1)
        _RequireMac = bool((_AuthenticationMode_int >> 5) & 0b1)
        _RequireSessionKey = bool((_AuthenticationMode_int >> 4) & 0b1)
        _AuthenticationMode = HostSecurityAuthenticationMode(_RequireContinuousIv, _RequireEncrypted, _RequireMac, _RequireSessionKey)
        _DeriveKeyId = safe_read_int_from_buffer(_recv_buffer, 1)
        _AesKey_bytes = _recv_buffer.read(-1)
        _AesKey = _AesKey_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Device_HostSecurity_Key_Result(_AuthenticationMode, _DeriveKeyId, _AesKey)
    def get(self, Key_ndx: int, default: Optional[Device_HostSecurity_Key_Result] = None) -> Optional[Device_HostSecurity_Key_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if Key_ndx < 0 or Key_ndx >= 4:
            raise IndexError(Key_ndx)
        _send_buffer.write((129 + Key_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Key_ndx: int, AuthenticationMode: Union[HostSecurityAuthenticationMode, HostSecurityAuthenticationMode_Dict], DeriveKeyId: int, AesKey: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if Key_ndx < 0 or Key_ndx >= 4:
            raise IndexError(Key_ndx)
        _send_buffer.write((129 + Key_ndx).to_bytes(1, byteorder='big'))
        if isinstance(AuthenticationMode, dict):
            AuthenticationMode = HostSecurityAuthenticationMode(**AuthenticationMode)
        AuthenticationMode_int = 0
        AuthenticationMode_int |= (int(AuthenticationMode.RequireContinuousIv) & 0b1) << 7
        AuthenticationMode_int |= (int(AuthenticationMode.RequireEncrypted) & 0b1) << 6
        AuthenticationMode_int |= (int(AuthenticationMode.RequireMac) & 0b1) << 5
        AuthenticationMode_int |= (int(AuthenticationMode.RequireSessionKey) & 0b1) << 4
        _send_buffer.write(AuthenticationMode_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(DeriveKeyId.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(AesKey.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Key_ndx: int, AuthenticationMode: Union[HostSecurityAuthenticationMode, HostSecurityAuthenticationMode_Dict], DeriveKeyId: int, AesKey: str) -> None:
        frame = self.build_frame(Key_ndx=Key_ndx, AuthenticationMode=AuthenticationMode, DeriveKeyId=DeriveKeyId, AesKey=AesKey)
        self.process_frame(frame)
class Device_VirtualLeds(ConfigBase):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x09
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\t')
        self.process_frame(_send_buffer.getvalue())
class Device_VirtualLeds_TransitionTime(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x09
    ValueKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\t')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\t')
        _send_buffer.write(b'\x01')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\t')
        _send_buffer.write(b'\x01')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_VirtualLeds_PulsePeriod(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x09
    ValueKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\t')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\t')
        _send_buffer.write(b'\x02')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\t')
        _send_buffer.write(b'\x02')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_VirtualLeds_CustomVledDefinition(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x09
    ValueKey: ClassVar[int] = 0x40
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 16
    def reset(self, CustomVledDefinition_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\t')
        if CustomVledDefinition_ndx < 0 or CustomVledDefinition_ndx >= 16:
            raise IndexError(CustomVledDefinition_ndx)
        _send_buffer.write((64 + CustomVledDefinition_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> VirtualLedDefinition:
        _recv_buffer = BytesIO(frame)
        _Mode_int = safe_read_int_from_buffer(_recv_buffer, 1)
        _ContainsTransitionTime = bool((_Mode_int >> 2) & 0b1)
        _IsPulse = bool((_Mode_int >> 1) & 0b1)
        _ContainsPhysicalLedSelection = bool((_Mode_int >> 0) & 0b1)
        _Mode = VirtualLedDefinition_Mode(_ContainsTransitionTime, _IsPulse, _ContainsPhysicalLedSelection)
        _RgbColor = safe_read_int_from_buffer(_recv_buffer, 4)
        if _ContainsPhysicalLedSelection:
            _PhysicalLedSelection = VirtualLedDefinition_PhysicalLedSelection_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        else:
            _PhysicalLedSelection = None
        if _IsPulse:
            _RgbColor2 = safe_read_int_from_buffer(_recv_buffer, 4)
        else:
            _RgbColor2 = None
        if _ContainsTransitionTime:
            _TransitionTime = safe_read_int_from_buffer(_recv_buffer, 2)
        else:
            _TransitionTime = None
        _VledDefinition = VirtualLedDefinition(_Mode, _RgbColor, _PhysicalLedSelection, _RgbColor2, _TransitionTime)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _VledDefinition
    def get(self, CustomVledDefinition_ndx: int, default: Optional[VirtualLedDefinition] = None) -> Optional[VirtualLedDefinition]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\t')
        if CustomVledDefinition_ndx < 0 or CustomVledDefinition_ndx >= 16:
            raise IndexError(CustomVledDefinition_ndx)
        _send_buffer.write((64 + CustomVledDefinition_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, CustomVledDefinition_ndx: int, VledDefinition: Union[VirtualLedDefinition, VirtualLedDefinition_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\t')
        if CustomVledDefinition_ndx < 0 or CustomVledDefinition_ndx >= 16:
            raise IndexError(CustomVledDefinition_ndx)
        _send_buffer.write((64 + CustomVledDefinition_ndx).to_bytes(1, byteorder='big'))
        if isinstance(VledDefinition, dict):
            VledDefinition = VirtualLedDefinition(**VledDefinition)
        _Mode, _RgbColor, _PhysicalLedSelection, _RgbColor2, _TransitionTime = VledDefinition
        if isinstance(_Mode, dict):
            _Mode = VirtualLedDefinition_Mode(**_Mode)
        _Mode_int = 0
        _Mode_int |= (int(_Mode.ContainsTransitionTime) & 0b1) << 2
        _Mode_int |= (int(_Mode.IsPulse) & 0b1) << 1
        _Mode_int |= (int(_Mode.ContainsPhysicalLedSelection) & 0b1) << 0
        _send_buffer.write(_Mode_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(_RgbColor.to_bytes(length=4, byteorder='big'))
        if _Mode.ContainsPhysicalLedSelection:
            if _PhysicalLedSelection is None:
                raise TypeError("missing a required argument: '_PhysicalLedSelection'")
            _send_buffer.write(VirtualLedDefinition_PhysicalLedSelection_Parser.as_value(_PhysicalLedSelection).to_bytes(length=1, byteorder='big'))
        if _Mode.IsPulse:
            if _RgbColor2 is None:
                raise TypeError("missing a required argument: '_RgbColor2'")
            _send_buffer.write(_RgbColor2.to_bytes(length=4, byteorder='big'))
        if _Mode.ContainsTransitionTime:
            if _TransitionTime is None:
                raise TypeError("missing a required argument: '_TransitionTime'")
            _send_buffer.write(_TransitionTime.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, CustomVledDefinition_ndx: int, VledDefinition: Union[VirtualLedDefinition, VirtualLedDefinition_Dict]) -> None:
        frame = self.build_frame(CustomVledDefinition_ndx=CustomVledDefinition_ndx, VledDefinition=VledDefinition)
        self.process_frame(frame)
class Custom(ConfigBase):
    MasterKey: ClassVar[int] = 0x06
    MasterKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        self.process_frame(_send_buffer.getvalue())
class Custom_BlackWhiteList(ConfigBase):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
class Custom_BlackWhiteList_ListMode(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Custom_BlackWhiteList_ListMode_BlackWhiteListMode:
        _recv_buffer = BytesIO(frame)
        _BlackWhiteListMode = Custom_BlackWhiteList_ListMode_BlackWhiteListMode_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _BlackWhiteListMode
    def get(self, default: Optional[Custom_BlackWhiteList_ListMode_BlackWhiteListMode] = None) -> Optional[Custom_BlackWhiteList_ListMode_BlackWhiteListMode]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, BlackWhiteListMode: Custom_BlackWhiteList_ListMode_BlackWhiteListMode) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(Custom_BlackWhiteList_ListMode_BlackWhiteListMode_Parser.as_value(BlackWhiteListMode).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BlackWhiteListMode: Custom_BlackWhiteList_ListMode_BlackWhiteListMode) -> None:
        frame = self.build_frame(BlackWhiteListMode=BlackWhiteListMode)
        self.process_frame(frame)
class Custom_BlackWhiteList_RangeStart(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Custom_BlackWhiteList_RangeEnd(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x03
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Custom_BlackWhiteList_EntrySize(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x04
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Custom_BlackWhiteList_List(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x10
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 112
    def reset(self, List_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x02')
        if List_ndx < 0 or List_ndx >= 112:
            raise IndexError(List_ndx)
        _send_buffer.write((16 + List_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, List_ndx: int, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x02')
        if List_ndx < 0 or List_ndx >= 112:
            raise IndexError(List_ndx)
        _send_buffer.write((16 + List_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, List_ndx: int, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x02')
        if List_ndx < 0 or List_ndx >= 112:
            raise IndexError(List_ndx)
        _send_buffer.write((16 + List_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, List_ndx: int, Value: str) -> None:
        frame = self.build_frame(List_ndx=List_ndx, Value=Value)
        self.process_frame(frame)
class Custom_AdminData(ConfigBase):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x20
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        self.process_frame(_send_buffer.getvalue())
class Custom_AdminData_CustomerNo(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 4)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x01')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x01')
        _send_buffer.write(Value.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Custom_AdminData_DeviceSettingsNo(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x02')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x02')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Custom_AdminData_DeviceSettingsName(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x03
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x03')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x03')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x03')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Custom_AdminData_DeviceSettingsVersion(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x04
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x04')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x04')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x04')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Custom_AdminData_ProjectSettingsNo(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x05
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x05')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x05')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x05')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Custom_AdminData_ProjectName(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x06
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x06')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x06')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x06')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Custom_AdminData_ProjectSettingsVersion(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x07
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x07')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x07')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x07')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project(ConfigBase):
    MasterKey: ClassVar[int] = 0x08
    MasterKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        self.process_frame(_send_buffer.getvalue())
class Project_VhlSettings(ConfigBase):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
class Project_VhlSettings_ScanCardFamilies(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> CardFamilies:
        _recv_buffer = BytesIO(frame)
        _Value_int = safe_read_int_from_buffer(_recv_buffer, 2)
        _LEGICPrime = bool((_Value_int >> 11) & 0b1)
        _BluetoothMce = bool((_Value_int >> 10) & 0b1)
        _Khz125Part2 = bool((_Value_int >> 9) & 0b1)
        _Srix = bool((_Value_int >> 8) & 0b1)
        _Khz125Part1 = bool((_Value_int >> 7) & 0b1)
        _Felica = bool((_Value_int >> 6) & 0b1)
        _IClass = bool((_Value_int >> 5) & 0b1)
        _IClassIso14B = bool((_Value_int >> 4) & 0b1)
        _Iso14443B = bool((_Value_int >> 3) & 0b1)
        _Iso15693 = bool((_Value_int >> 2) & 0b1)
        _Iso14443A = bool((_Value_int >> 0) & 0b1)
        _Value = CardFamilies(_LEGICPrime, _BluetoothMce, _Khz125Part2, _Srix, _Khz125Part1, _Felica, _IClass, _IClassIso14B, _Iso14443B, _Iso15693, _Iso14443A)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[CardFamilies] = None) -> Optional[CardFamilies]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[CardFamilies, CardFamilies_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        if isinstance(Value, dict):
            Value = CardFamilies(**Value)
        Value_int = 0
        Value_int |= (int(Value.LEGICPrime) & 0b1) << 11
        Value_int |= (int(Value.BluetoothMce) & 0b1) << 10
        Value_int |= (int(Value.Khz125Part2) & 0b1) << 9
        Value_int |= (int(Value.Srix) & 0b1) << 8
        Value_int |= (int(Value.Khz125Part1) & 0b1) << 7
        Value_int |= (int(Value.Felica) & 0b1) << 6
        Value_int |= (int(Value.IClass) & 0b1) << 5
        Value_int |= (int(Value.IClassIso14B) & 0b1) << 4
        Value_int |= (int(Value.Iso14443B) & 0b1) << 3
        Value_int |= (int(Value.Iso15693) & 0b1) << 2
        Value_int |= (int(Value.Iso14443A) & 0b1) << 0
        _send_buffer.write(Value_int.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[CardFamilies, CardFamilies_Dict]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings_ForceReselect(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_VhlSettings_ForceReselect_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Project_VhlSettings_ForceReselect_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Project_VhlSettings_ForceReselect_Value] = None) -> Optional[Project_VhlSettings_ForceReselect_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Project_VhlSettings_ForceReselect_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(Project_VhlSettings_ForceReselect_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Project_VhlSettings_ForceReselect_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings_DelayRequestATS(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x03
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings_DelayPerformPPS(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x04
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x04')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings_MaxBaudrateIso14443A(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x10
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x10')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> MaxBaudrateIso14443:
        _recv_buffer = BytesIO(frame)
        _Value = MaxBaudrateIso14443_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[MaxBaudrateIso14443] = None) -> Optional[MaxBaudrateIso14443]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x10')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: MaxBaudrateIso14443) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x10')
        _send_buffer.write(MaxBaudrateIso14443_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: MaxBaudrateIso14443) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings_MaxBaudrateIso14443B(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x20
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b' ')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> MaxBaudrateIso14443:
        _recv_buffer = BytesIO(frame)
        _Value = MaxBaudrateIso14443_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[MaxBaudrateIso14443] = None) -> Optional[MaxBaudrateIso14443]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b' ')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: MaxBaudrateIso14443) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b' ')
        _send_buffer.write(MaxBaudrateIso14443_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: MaxBaudrateIso14443) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings_PrioritizeCardFamilies(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x06
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> CardFamilies:
        _recv_buffer = BytesIO(frame)
        _Value_int = safe_read_int_from_buffer(_recv_buffer, 2)
        _LEGICPrime = bool((_Value_int >> 11) & 0b1)
        _BluetoothMce = bool((_Value_int >> 10) & 0b1)
        _Khz125Part2 = bool((_Value_int >> 9) & 0b1)
        _Srix = bool((_Value_int >> 8) & 0b1)
        _Khz125Part1 = bool((_Value_int >> 7) & 0b1)
        _Felica = bool((_Value_int >> 6) & 0b1)
        _IClass = bool((_Value_int >> 5) & 0b1)
        _IClassIso14B = bool((_Value_int >> 4) & 0b1)
        _Iso14443B = bool((_Value_int >> 3) & 0b1)
        _Iso15693 = bool((_Value_int >> 2) & 0b1)
        _Iso14443A = bool((_Value_int >> 0) & 0b1)
        _Value = CardFamilies(_LEGICPrime, _BluetoothMce, _Khz125Part2, _Srix, _Khz125Part1, _Felica, _IClass, _IClassIso14B, _Iso14443B, _Iso15693, _Iso14443A)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[CardFamilies] = None) -> Optional[CardFamilies]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[CardFamilies, CardFamilies_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        if isinstance(Value, dict):
            Value = CardFamilies(**Value)
        Value_int = 0
        Value_int |= (int(Value.LEGICPrime) & 0b1) << 11
        Value_int |= (int(Value.BluetoothMce) & 0b1) << 10
        Value_int |= (int(Value.Khz125Part2) & 0b1) << 9
        Value_int |= (int(Value.Srix) & 0b1) << 8
        Value_int |= (int(Value.Khz125Part1) & 0b1) << 7
        Value_int |= (int(Value.Felica) & 0b1) << 6
        Value_int |= (int(Value.IClass) & 0b1) << 5
        Value_int |= (int(Value.IClassIso14B) & 0b1) << 4
        Value_int |= (int(Value.Iso14443B) & 0b1) << 3
        Value_int |= (int(Value.Iso15693) & 0b1) << 2
        Value_int |= (int(Value.Iso14443A) & 0b1) << 0
        _send_buffer.write(Value_int.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[CardFamilies, CardFamilies_Dict]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings_PrioritizationTriggeringCardFamilies(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x07
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x07')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> CardFamilies:
        _recv_buffer = BytesIO(frame)
        _Value_int = safe_read_int_from_buffer(_recv_buffer, 2)
        _LEGICPrime = bool((_Value_int >> 11) & 0b1)
        _BluetoothMce = bool((_Value_int >> 10) & 0b1)
        _Khz125Part2 = bool((_Value_int >> 9) & 0b1)
        _Srix = bool((_Value_int >> 8) & 0b1)
        _Khz125Part1 = bool((_Value_int >> 7) & 0b1)
        _Felica = bool((_Value_int >> 6) & 0b1)
        _IClass = bool((_Value_int >> 5) & 0b1)
        _IClassIso14B = bool((_Value_int >> 4) & 0b1)
        _Iso14443B = bool((_Value_int >> 3) & 0b1)
        _Iso15693 = bool((_Value_int >> 2) & 0b1)
        _Iso14443A = bool((_Value_int >> 0) & 0b1)
        _Value = CardFamilies(_LEGICPrime, _BluetoothMce, _Khz125Part2, _Srix, _Khz125Part1, _Felica, _IClass, _IClassIso14B, _Iso14443B, _Iso15693, _Iso14443A)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[CardFamilies] = None) -> Optional[CardFamilies]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x07')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[CardFamilies, CardFamilies_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x07')
        if isinstance(Value, dict):
            Value = CardFamilies(**Value)
        Value_int = 0
        Value_int |= (int(Value.LEGICPrime) & 0b1) << 11
        Value_int |= (int(Value.BluetoothMce) & 0b1) << 10
        Value_int |= (int(Value.Khz125Part2) & 0b1) << 9
        Value_int |= (int(Value.Srix) & 0b1) << 8
        Value_int |= (int(Value.Khz125Part1) & 0b1) << 7
        Value_int |= (int(Value.Felica) & 0b1) << 6
        Value_int |= (int(Value.IClass) & 0b1) << 5
        Value_int |= (int(Value.IClassIso14B) & 0b1) << 4
        Value_int |= (int(Value.Iso14443B) & 0b1) << 3
        Value_int |= (int(Value.Iso15693) & 0b1) << 2
        Value_int |= (int(Value.Iso14443A) & 0b1) << 0
        _send_buffer.write(Value_int.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[CardFamilies, CardFamilies_Dict]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings_PrioritizeDelay(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x08
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings_ConfCardCardFamilies(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x09
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\t')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> CardFamilies:
        _recv_buffer = BytesIO(frame)
        _Value_int = safe_read_int_from_buffer(_recv_buffer, 2)
        _LEGICPrime = bool((_Value_int >> 11) & 0b1)
        _BluetoothMce = bool((_Value_int >> 10) & 0b1)
        _Khz125Part2 = bool((_Value_int >> 9) & 0b1)
        _Srix = bool((_Value_int >> 8) & 0b1)
        _Khz125Part1 = bool((_Value_int >> 7) & 0b1)
        _Felica = bool((_Value_int >> 6) & 0b1)
        _IClass = bool((_Value_int >> 5) & 0b1)
        _IClassIso14B = bool((_Value_int >> 4) & 0b1)
        _Iso14443B = bool((_Value_int >> 3) & 0b1)
        _Iso15693 = bool((_Value_int >> 2) & 0b1)
        _Iso14443A = bool((_Value_int >> 0) & 0b1)
        _Value = CardFamilies(_LEGICPrime, _BluetoothMce, _Khz125Part2, _Srix, _Khz125Part1, _Felica, _IClass, _IClassIso14B, _Iso14443B, _Iso15693, _Iso14443A)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[CardFamilies] = None) -> Optional[CardFamilies]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\t')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[CardFamilies, CardFamilies_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\t')
        if isinstance(Value, dict):
            Value = CardFamilies(**Value)
        Value_int = 0
        Value_int |= (int(Value.LEGICPrime) & 0b1) << 11
        Value_int |= (int(Value.BluetoothMce) & 0b1) << 10
        Value_int |= (int(Value.Khz125Part2) & 0b1) << 9
        Value_int |= (int(Value.Srix) & 0b1) << 8
        Value_int |= (int(Value.Khz125Part1) & 0b1) << 7
        Value_int |= (int(Value.Felica) & 0b1) << 6
        Value_int |= (int(Value.IClass) & 0b1) << 5
        Value_int |= (int(Value.IClassIso14B) & 0b1) << 4
        Value_int |= (int(Value.Iso14443B) & 0b1) << 3
        Value_int |= (int(Value.Iso15693) & 0b1) << 2
        Value_int |= (int(Value.Iso14443A) & 0b1) << 0
        _send_buffer.write(Value_int.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[CardFamilies, CardFamilies_Dict]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings_Iso14aVasup(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x25
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'%')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_VhlSettings_Iso14aVasup_Result:
        _recv_buffer = BytesIO(frame)
        _FormatVersion = safe_read_int_from_buffer(_recv_buffer, 1)
        _TerminalInfo_int = safe_read_int_from_buffer(_recv_buffer, 1)
        _VasSupported = bool((_TerminalInfo_int >> 7) & 0b1)
        _AuthUserRequested = bool((_TerminalInfo_int >> 6) & 0b1)
        _TerminalTypeDataLength = (_TerminalInfo_int >> 0) & 0b1111
        _TerminalType = safe_read_int_from_buffer(_recv_buffer, 2)
        _TCI = _recv_buffer.read(-1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Project_VhlSettings_Iso14aVasup_Result(_FormatVersion, _VasSupported, _AuthUserRequested, _TerminalTypeDataLength, _TerminalType, _TCI)
    def get(self, default: Optional[Project_VhlSettings_Iso14aVasup_Result] = None) -> Optional[Project_VhlSettings_Iso14aVasup_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'%')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, FormatVersion: int, VasSupported: bool, AuthUserRequested: bool, TerminalTypeDataLength: int, TerminalType: int, TCI: bytes) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'%')
        _send_buffer.write(FormatVersion.to_bytes(length=1, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (int(VasSupported) & 0b1) << 7
        _var_0000_int |= (int(AuthUserRequested) & 0b1) << 6
        _var_0000_int |= (TerminalTypeDataLength & 0b1111) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(TerminalType.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(TCI)
        return _send_buffer.getvalue()
    def __call__(self, FormatVersion: int, VasSupported: bool, AuthUserRequested: bool, TerminalTypeDataLength: int, TerminalType: int, TCI: bytes) -> None:
        frame = self.build_frame(FormatVersion=FormatVersion, VasSupported=VasSupported, AuthUserRequested=AuthUserRequested, TerminalTypeDataLength=TerminalTypeDataLength, TerminalType=TerminalType, TCI=TCI)
        self.process_frame(frame)
class Project_HidSam(ConfigBase):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x51
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'Q')
        self.process_frame(_send_buffer.getvalue())
class Project_HidSam_Confcard(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x51
    ValueKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'Q')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_HidSam_Confcard_Result:
        _recv_buffer = BytesIO(frame)
        _Value_int = safe_read_int_from_buffer(_recv_buffer, 1)
        _HidConfigurationCard = bool((_Value_int >> 1) & 0b1)
        _HidPreparationCard = bool((_Value_int >> 0) & 0b1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Project_HidSam_Confcard_Result(_HidConfigurationCard, _HidPreparationCard)
    def get(self, default: Optional[Project_HidSam_Confcard_Result] = None) -> Optional[Project_HidSam_Confcard_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'Q')
        _send_buffer.write(b'\x01')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, HidConfigurationCard: bool, HidPreparationCard: bool) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'Q')
        _send_buffer.write(b'\x01')
        _var_0000_int = 0
        _var_0000_int |= (int(HidConfigurationCard) & 0b1) << 1
        _var_0000_int |= (int(HidPreparationCard) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, HidConfigurationCard: bool, HidPreparationCard: bool) -> None:
        frame = self.build_frame(HidConfigurationCard=HidConfigurationCard, HidPreparationCard=HidPreparationCard)
        self.process_frame(frame)
class Project_HidSam_ScanTime(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x51
    ValueKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'Q')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'Q')
        _send_buffer.write(b'\x02')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'Q')
        _send_buffer.write(b'\x02')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_HidSam_Retries(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x51
    ValueKey: ClassVar[int] = 0x03
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'Q')
        _send_buffer.write(b'\x03')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'Q')
        _send_buffer.write(b'\x03')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'Q')
        _send_buffer.write(b'\x03')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings125Khz(ConfigBase):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        self.process_frame(_send_buffer.getvalue())
class Project_VhlSettings125Khz_ScanCardTypesPart1(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x00
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x00')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> CardTypes125KhzPart1:
        _recv_buffer = BytesIO(frame)
        _Value_int = safe_read_int_from_buffer(_recv_buffer, 2)
        _TTF = bool((_Value_int >> 15) & 0b1)
        _Hitag2B = bool((_Value_int >> 14) & 0b1)
        _Hitag2M = bool((_Value_int >> 13) & 0b1)
        _Hitag1S = bool((_Value_int >> 12) & 0b1)
        _HidIoprox = bool((_Value_int >> 11) & 0b1)
        _HidProx = bool((_Value_int >> 10) & 0b1)
        _HidAwid = bool((_Value_int >> 9) & 0b1)
        _HidIndala = bool((_Value_int >> 8) & 0b1)
        _Quadrakey = bool((_Value_int >> 7) & 0b1)
        _Keri = bool((_Value_int >> 6) & 0b1)
        _HidProx32 = bool((_Value_int >> 5) & 0b1)
        _Pyramid = bool((_Value_int >> 4) & 0b1)
        _EM4450 = bool((_Value_int >> 3) & 0b1)
        _EM4100 = bool((_Value_int >> 1) & 0b1)
        _EM4205 = bool((_Value_int >> 0) & 0b1)
        _Value = CardTypes125KhzPart1(_TTF, _Hitag2B, _Hitag2M, _Hitag1S, _HidIoprox, _HidProx, _HidAwid, _HidIndala, _Quadrakey, _Keri, _HidProx32, _Pyramid, _EM4450, _EM4100, _EM4205)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[CardTypes125KhzPart1] = None) -> Optional[CardTypes125KhzPart1]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x00')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[CardTypes125KhzPart1, CardTypes125KhzPart1_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x00')
        if isinstance(Value, dict):
            Value = CardTypes125KhzPart1(**Value)
        Value_int = 0
        Value_int |= (int(Value.TTF) & 0b1) << 15
        Value_int |= (int(Value.Hitag2B) & 0b1) << 14
        Value_int |= (int(Value.Hitag2M) & 0b1) << 13
        Value_int |= (int(Value.Hitag1S) & 0b1) << 12
        Value_int |= (int(Value.HidIoprox) & 0b1) << 11
        Value_int |= (int(Value.HidProx) & 0b1) << 10
        Value_int |= (int(Value.HidAwid) & 0b1) << 9
        Value_int |= (int(Value.HidIndala) & 0b1) << 8
        Value_int |= (int(Value.Quadrakey) & 0b1) << 7
        Value_int |= (int(Value.Keri) & 0b1) << 6
        Value_int |= (int(Value.HidProx32) & 0b1) << 5
        Value_int |= (int(Value.Pyramid) & 0b1) << 4
        Value_int |= (int(Value.EM4450) & 0b1) << 3
        Value_int |= (int(Value.EM4100) & 0b1) << 1
        Value_int |= (int(Value.EM4205) & 0b1) << 0
        _send_buffer.write(Value_int.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[CardTypes125KhzPart1, CardTypes125KhzPart1_Dict]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings125Khz_ScanCardTypesPart2(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x16
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x16')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> CardTypes125KhzPart2:
        _recv_buffer = BytesIO(frame)
        _Value_int = safe_read_int_from_buffer(_recv_buffer, 2)
        _Idteck = bool((_Value_int >> 4) & 0b1)
        _Cotag = bool((_Value_int >> 3) & 0b1)
        _HidIndalaSecure = bool((_Value_int >> 2) & 0b1)
        _GProx = bool((_Value_int >> 1) & 0b1)
        _SecuraKey = bool((_Value_int >> 0) & 0b1)
        _Value = CardTypes125KhzPart2(_Idteck, _Cotag, _HidIndalaSecure, _GProx, _SecuraKey)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[CardTypes125KhzPart2] = None) -> Optional[CardTypes125KhzPart2]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x16')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[CardTypes125KhzPart2, CardTypes125KhzPart2_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x16')
        if isinstance(Value, dict):
            Value = CardTypes125KhzPart2(**Value)
        Value_int = 0
        Value_int |= (int(Value.Idteck) & 0b1) << 4
        Value_int |= (int(Value.Cotag) & 0b1) << 3
        Value_int |= (int(Value.HidIndalaSecure) & 0b1) << 2
        Value_int |= (int(Value.GProx) & 0b1) << 1
        Value_int |= (int(Value.SecuraKey) & 0b1) << 0
        _send_buffer.write(Value_int.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[CardTypes125KhzPart2, CardTypes125KhzPart2_Dict]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings125Khz_TTFModType(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_VhlSettings125Khz_TTFModType_TTFMod:
        _recv_buffer = BytesIO(frame)
        _TTFMod = Project_VhlSettings125Khz_TTFModType_TTFMod_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _TTFMod
    def get(self, default: Optional[Project_VhlSettings125Khz_TTFModType_TTFMod] = None) -> Optional[Project_VhlSettings125Khz_TTFModType_TTFMod]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x01')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, TTFMod: Project_VhlSettings125Khz_TTFModType_TTFMod) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x01')
        _send_buffer.write(Project_VhlSettings125Khz_TTFModType_TTFMod_Parser.as_value(TTFMod).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, TTFMod: Project_VhlSettings125Khz_TTFModType_TTFMod) -> None:
        frame = self.build_frame(TTFMod=TTFMod)
        self.process_frame(frame)
class Project_VhlSettings125Khz_TTFBaudrate(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_VhlSettings125Khz_TTFBaudrate_TTFBaud:
        _recv_buffer = BytesIO(frame)
        _TTFBaud = Project_VhlSettings125Khz_TTFBaudrate_TTFBaud_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _TTFBaud
    def get(self, default: Optional[Project_VhlSettings125Khz_TTFBaudrate_TTFBaud] = None) -> Optional[Project_VhlSettings125Khz_TTFBaudrate_TTFBaud]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x02')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, TTFBaud: Project_VhlSettings125Khz_TTFBaudrate_TTFBaud) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x02')
        _send_buffer.write(Project_VhlSettings125Khz_TTFBaudrate_TTFBaud_Parser.as_value(TTFBaud).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, TTFBaud: Project_VhlSettings125Khz_TTFBaudrate_TTFBaud) -> None:
        frame = self.build_frame(TTFBaud=TTFBaud)
        self.process_frame(frame)
class Project_VhlSettings125Khz_TTFHeaderLength(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x03
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x03')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x03')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x03')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings125Khz_TTFHeader(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x04
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x04')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x04')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x04')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings125Khz_TTFDataLength(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x05
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x05')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x05')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x05')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings125Khz_TTFOkCounter(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x06
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x06')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x06')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x06')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings125Khz_IndaspDecode(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x07
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x07')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Template:
        _recv_buffer = BytesIO(frame)
        _Value = Template(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Template] = None) -> Optional[Template]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x07')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[Template, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x07')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[Template, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings125Khz_IndaspParityCheck(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x08
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x08')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_VhlSettings125Khz_IndaspParityCheck_ParityDisable:
        _recv_buffer = BytesIO(frame)
        _ParityDisable = Project_VhlSettings125Khz_IndaspParityCheck_ParityDisable_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ParityDisable
    def get(self, default: Optional[Project_VhlSettings125Khz_IndaspParityCheck_ParityDisable] = None) -> Optional[Project_VhlSettings125Khz_IndaspParityCheck_ParityDisable]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x08')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, ParityDisable: Project_VhlSettings125Khz_IndaspParityCheck_ParityDisable) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x08')
        _send_buffer.write(Project_VhlSettings125Khz_IndaspParityCheck_ParityDisable_Parser.as_value(ParityDisable).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, ParityDisable: Project_VhlSettings125Khz_IndaspParityCheck_ParityDisable) -> None:
        frame = self.build_frame(ParityDisable=ParityDisable)
        self.process_frame(frame)
class Project_VhlSettings125Khz_TTFReadStartpos(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x0E
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x0e')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x0e')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x0e')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings125Khz_HidProxSerialNrFormat(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x0F
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x0f')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_VhlSettings125Khz_HidProxSerialNrFormat_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Project_VhlSettings125Khz_HidProxSerialNrFormat_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Project_VhlSettings125Khz_HidProxSerialNrFormat_Value] = None) -> Optional[Project_VhlSettings125Khz_HidProxSerialNrFormat_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x0f')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Project_VhlSettings125Khz_HidProxSerialNrFormat_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x0f')
        _send_buffer.write(Project_VhlSettings125Khz_HidProxSerialNrFormat_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Project_VhlSettings125Khz_HidProxSerialNrFormat_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings125Khz_ModType(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x10
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x10')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_VhlSettings125Khz_ModType_Mod:
        _recv_buffer = BytesIO(frame)
        _Mod = Project_VhlSettings125Khz_ModType_Mod_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Mod
    def get(self, default: Optional[Project_VhlSettings125Khz_ModType_Mod] = None) -> Optional[Project_VhlSettings125Khz_ModType_Mod]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x10')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Mod: Project_VhlSettings125Khz_ModType_Mod) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x10')
        _send_buffer.write(Project_VhlSettings125Khz_ModType_Mod_Parser.as_value(Mod).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Mod: Project_VhlSettings125Khz_ModType_Mod) -> None:
        frame = self.build_frame(Mod=Mod)
        self.process_frame(frame)
class Project_VhlSettings125Khz_BaudRate(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x11
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x11')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_VhlSettings125Khz_BaudRate_Baud:
        _recv_buffer = BytesIO(frame)
        _Baud = Project_VhlSettings125Khz_BaudRate_Baud_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Baud
    def get(self, default: Optional[Project_VhlSettings125Khz_BaudRate_Baud] = None) -> Optional[Project_VhlSettings125Khz_BaudRate_Baud]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x11')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Baud: Project_VhlSettings125Khz_BaudRate_Baud) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x11')
        _send_buffer.write(Project_VhlSettings125Khz_BaudRate_Baud_Parser.as_value(Baud).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Baud: Project_VhlSettings125Khz_BaudRate_Baud) -> None:
        frame = self.build_frame(Baud=Baud)
        self.process_frame(frame)
class Project_VhlSettings125Khz_SnrVersionCotag(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x20
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b' ')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _SnrVersion = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _SnrVersion
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b' ')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, SnrVersion: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b' ')
        _send_buffer.write(SnrVersion.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, SnrVersion: int) -> None:
        frame = self.build_frame(SnrVersion=SnrVersion)
        self.process_frame(frame)
class Project_VhlSettings125Khz_SnrVersionIdteck(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x21
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'!')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _SnrVersion = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _SnrVersion
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'!')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, SnrVersion: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'!')
        _send_buffer.write(SnrVersion.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, SnrVersion: int) -> None:
        frame = self.build_frame(SnrVersion=SnrVersion)
        self.process_frame(frame)
class Project_VhlSettings125Khz_EM4100SerialNrFormat(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x22
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'"')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_VhlSettings125Khz_EM4100SerialNrFormat_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Project_VhlSettings125Khz_EM4100SerialNrFormat_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Project_VhlSettings125Khz_EM4100SerialNrFormat_Value] = None) -> Optional[Project_VhlSettings125Khz_EM4100SerialNrFormat_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'"')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Project_VhlSettings125Khz_EM4100SerialNrFormat_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'"')
        _send_buffer.write(Project_VhlSettings125Khz_EM4100SerialNrFormat_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Project_VhlSettings125Khz_EM4100SerialNrFormat_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings125Khz_AwidSerialNrFormat(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x23
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'#')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_VhlSettings125Khz_AwidSerialNrFormat_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Project_VhlSettings125Khz_AwidSerialNrFormat_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Project_VhlSettings125Khz_AwidSerialNrFormat_Value] = None) -> Optional[Project_VhlSettings125Khz_AwidSerialNrFormat_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'#')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Project_VhlSettings125Khz_AwidSerialNrFormat_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'#')
        _send_buffer.write(Project_VhlSettings125Khz_AwidSerialNrFormat_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Project_VhlSettings125Khz_AwidSerialNrFormat_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings125Khz_IoProxSerialNrFormat(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x24
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'$')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_VhlSettings125Khz_IoProxSerialNrFormat_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Project_VhlSettings125Khz_IoProxSerialNrFormat_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Project_VhlSettings125Khz_IoProxSerialNrFormat_Value] = None) -> Optional[Project_VhlSettings125Khz_IoProxSerialNrFormat_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'$')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Project_VhlSettings125Khz_IoProxSerialNrFormat_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'$')
        _send_buffer.write(Project_VhlSettings125Khz_IoProxSerialNrFormat_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Project_VhlSettings125Khz_IoProxSerialNrFormat_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings125Khz_PyramidSerialNrFormat(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x25
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'%')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_VhlSettings125Khz_PyramidSerialNrFormat_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Project_VhlSettings125Khz_PyramidSerialNrFormat_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Project_VhlSettings125Khz_PyramidSerialNrFormat_Value] = None) -> Optional[Project_VhlSettings125Khz_PyramidSerialNrFormat_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'%')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Project_VhlSettings125Khz_PyramidSerialNrFormat_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'%')
        _send_buffer.write(Project_VhlSettings125Khz_PyramidSerialNrFormat_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Project_VhlSettings125Khz_PyramidSerialNrFormat_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings125Khz_ObidCardIdFormat(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x26
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'&')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_VhlSettings125Khz_ObidCardIdFormat_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Project_VhlSettings125Khz_ObidCardIdFormat_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Project_VhlSettings125Khz_ObidCardIdFormat_Value] = None) -> Optional[Project_VhlSettings125Khz_ObidCardIdFormat_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'&')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Project_VhlSettings125Khz_ObidCardIdFormat_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'&')
        _send_buffer.write(Project_VhlSettings125Khz_ObidCardIdFormat_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Project_VhlSettings125Khz_ObidCardIdFormat_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_SamAVx(ConfigBase):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
class Project_SamAVx_PowerUpState(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_SamAVx_PowerUpState_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Project_SamAVx_PowerUpState_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Project_SamAVx_PowerUpState_Value] = None) -> Optional[Project_SamAVx_PowerUpState_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Project_SamAVx_PowerUpState_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(Project_SamAVx_PowerUpState_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Project_SamAVx_PowerUpState_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_SamAVx_UnlockKeyNr(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_SamAVx_UnlockKeyVersion(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x03
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_SamAVx_UnlockKeyCryptoMemoryIdx(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x84
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x84')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> CryptoMemoryIndex:
        _recv_buffer = BytesIO(frame)
        _Page = safe_read_int_from_buffer(_recv_buffer, 1)
        _Idx = safe_read_int_from_buffer(_recv_buffer, 1)
        _CryptoMemoryIdx = CryptoMemoryIndex(_Page, _Idx)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _CryptoMemoryIdx
    def get(self, default: Optional[CryptoMemoryIndex] = None) -> Optional[CryptoMemoryIndex]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x84')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, CryptoMemoryIdx: Union[CryptoMemoryIndex, CryptoMemoryIndex_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x84')
        if isinstance(CryptoMemoryIdx, dict):
            CryptoMemoryIdx = CryptoMemoryIndex(**CryptoMemoryIdx)
        _Page, _Idx = CryptoMemoryIdx
        _send_buffer.write(_Page.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(_Idx.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, CryptoMemoryIdx: Union[CryptoMemoryIndex, CryptoMemoryIndex_Dict]) -> None:
        frame = self.build_frame(CryptoMemoryIdx=CryptoMemoryIdx)
        self.process_frame(frame)
class Project_SamAVx_AuthKeyNr(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x05
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_SamAVx_AuthKeyVersion(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x06
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_SamAVx_AuthKeyCryptoMemoryIdx(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x87
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x87')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> CryptoMemoryIndex:
        _recv_buffer = BytesIO(frame)
        _Page = safe_read_int_from_buffer(_recv_buffer, 1)
        _Idx = safe_read_int_from_buffer(_recv_buffer, 1)
        _CryptoMemoryIdx = CryptoMemoryIndex(_Page, _Idx)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _CryptoMemoryIdx
    def get(self, default: Optional[CryptoMemoryIndex] = None) -> Optional[CryptoMemoryIndex]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x87')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, CryptoMemoryIdx: Union[CryptoMemoryIndex, CryptoMemoryIndex_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x87')
        if isinstance(CryptoMemoryIdx, dict):
            CryptoMemoryIdx = CryptoMemoryIndex(**CryptoMemoryIdx)
        _Page, _Idx = CryptoMemoryIdx
        _send_buffer.write(_Page.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(_Idx.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, CryptoMemoryIdx: Union[CryptoMemoryIndex, CryptoMemoryIndex_Dict]) -> None:
        frame = self.build_frame(CryptoMemoryIdx=CryptoMemoryIdx)
        self.process_frame(frame)
class Project_SamAVx_SecureMessaging(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x08
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_SamAVx_SecureMessaging_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Project_SamAVx_SecureMessaging_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Project_SamAVx_SecureMessaging_Value] = None) -> Optional[Project_SamAVx_SecureMessaging_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Project_SamAVx_SecureMessaging_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(Project_SamAVx_SecureMessaging_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Project_SamAVx_SecureMessaging_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_SamAVx_LogicalChannel(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x09
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\t')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\t')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\t')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_SamAVx_AnswerToReset(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x20
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 2
    def reset(self, AnswerToReset_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        if AnswerToReset_ndx < 0 or AnswerToReset_ndx >= 2:
            raise IndexError(AnswerToReset_ndx)
        _send_buffer.write((32 + AnswerToReset_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_SamAVx_AnswerToReset_Result:
        _recv_buffer = BytesIO(frame)
        _LID = Project_SamAVx_AnswerToReset_LID_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _ATR = _recv_buffer.read(-1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Project_SamAVx_AnswerToReset_Result(_LID, _ATR)
    def get(self, AnswerToReset_ndx: int, default: Optional[Project_SamAVx_AnswerToReset_Result] = None) -> Optional[Project_SamAVx_AnswerToReset_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        if AnswerToReset_ndx < 0 or AnswerToReset_ndx >= 2:
            raise IndexError(AnswerToReset_ndx)
        _send_buffer.write((32 + AnswerToReset_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, AnswerToReset_ndx: int, LID: Project_SamAVx_AnswerToReset_LID, ATR: bytes) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x01')
        if AnswerToReset_ndx < 0 or AnswerToReset_ndx >= 2:
            raise IndexError(AnswerToReset_ndx)
        _send_buffer.write((32 + AnswerToReset_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(Project_SamAVx_AnswerToReset_LID_Parser.as_value(LID).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(ATR)
        return _send_buffer.getvalue()
    def __call__(self, AnswerToReset_ndx: int, LID: Project_SamAVx_AnswerToReset_LID, ATR: bytes) -> None:
        frame = self.build_frame(AnswerToReset_ndx=AnswerToReset_ndx, LID=LID, ATR=ATR)
        self.process_frame(frame)
class Project_CryptoKey(ConfigBase):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x30
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 16
    def reset(self, CryptoKey_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if CryptoKey_ndx < 0 or CryptoKey_ndx >= 16:
            raise IndexError(CryptoKey_ndx)
        _send_buffer.write((48 + CryptoKey_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
class Project_CryptoKey_Entry(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x30
    ValueKey: ClassVar[int] = 0x80
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 16
    ValueKeyCount: ClassVar[int] = 64
    def reset(self, CryptoKey_ndx: int, Entry_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if CryptoKey_ndx < 0 or CryptoKey_ndx >= 16:
            raise IndexError(CryptoKey_ndx)
        _send_buffer.write((48 + CryptoKey_ndx).to_bytes(1, byteorder='big'))
        if Entry_ndx < 0 or Entry_ndx >= 64:
            raise IndexError(Entry_ndx)
        _send_buffer.write((128 + Entry_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_CryptoKey_Entry_Result:
        _recv_buffer = BytesIO(frame)
        _KeySettings_int = safe_read_int_from_buffer(_recv_buffer, 1)
        _IsVersion = bool((_KeySettings_int >> 7) & 0b1)
        _IsDivInfo = bool((_KeySettings_int >> 6) & 0b1)
        _IsDivInfoVhl = bool((_KeySettings_int >> 5) & 0b1)
        _DenyFormat = bool((_KeySettings_int >> 2) & 0b1)
        _DenyWrite = bool((_KeySettings_int >> 1) & 0b1)
        _DenyRead = bool((_KeySettings_int >> 0) & 0b1)
        _KeySettings = KeyAccessRights_KeySettings(_IsVersion, _IsDivInfo, _IsDivInfoVhl, _DenyFormat, _DenyWrite, _DenyRead)
        if _IsVersion:
            _Version = safe_read_int_from_buffer(_recv_buffer, 1)
        else:
            _Version = None
        if _IsDivInfo:
            _DiversificationMode = KeyAccessRights_DiversificationMode_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
            _DivIdx = safe_read_int_from_buffer(_recv_buffer, 1)
        else:
            _DiversificationMode = None
            _DivIdx = None
        _AccessRights = KeyAccessRights(_KeySettings, _Version, _DiversificationMode, _DivIdx)
        _Algorithm = CryptoAlgorithm_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _Key_bytes = _recv_buffer.read(-1)
        _Key = _Key_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Project_CryptoKey_Entry_Result(_AccessRights, _Algorithm, _Key)
    def get(self, CryptoKey_ndx: int, Entry_ndx: int, default: Optional[Project_CryptoKey_Entry_Result] = None) -> Optional[Project_CryptoKey_Entry_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        if CryptoKey_ndx < 0 or CryptoKey_ndx >= 16:
            raise IndexError(CryptoKey_ndx)
        _send_buffer.write((48 + CryptoKey_ndx).to_bytes(1, byteorder='big'))
        if Entry_ndx < 0 or Entry_ndx >= 64:
            raise IndexError(Entry_ndx)
        _send_buffer.write((128 + Entry_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, CryptoKey_ndx: int, Entry_ndx: int, AccessRights: Union[KeyAccessRights, KeyAccessRights_Dict], Algorithm: CryptoAlgorithm, Key: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        if CryptoKey_ndx < 0 or CryptoKey_ndx >= 16:
            raise IndexError(CryptoKey_ndx)
        _send_buffer.write((48 + CryptoKey_ndx).to_bytes(1, byteorder='big'))
        if Entry_ndx < 0 or Entry_ndx >= 64:
            raise IndexError(Entry_ndx)
        _send_buffer.write((128 + Entry_ndx).to_bytes(1, byteorder='big'))
        if isinstance(AccessRights, dict):
            AccessRights = KeyAccessRights(**AccessRights)
        _KeySettings, _Version, _DiversificationMode, _DivIdx = AccessRights
        if isinstance(_KeySettings, dict):
            _KeySettings = KeyAccessRights_KeySettings(**_KeySettings)
        _KeySettings_int = 0
        _KeySettings_int |= (int(_KeySettings.IsVersion) & 0b1) << 7
        _KeySettings_int |= (int(_KeySettings.IsDivInfo) & 0b1) << 6
        _KeySettings_int |= (int(_KeySettings.IsDivInfoVhl) & 0b1) << 5
        _KeySettings_int |= (int(_KeySettings.DenyFormat) & 0b1) << 2
        _KeySettings_int |= (int(_KeySettings.DenyWrite) & 0b1) << 1
        _KeySettings_int |= (int(_KeySettings.DenyRead) & 0b1) << 0
        _send_buffer.write(_KeySettings_int.to_bytes(length=1, byteorder='big'))
        if _KeySettings.IsVersion:
            if _Version is None:
                raise TypeError("missing a required argument: '_Version'")
            _send_buffer.write(_Version.to_bytes(length=1, byteorder='big'))
        if _KeySettings.IsDivInfo:
            if _DiversificationMode is None:
                raise TypeError("missing a required argument: '_DiversificationMode'")
            if _DivIdx is None:
                raise TypeError("missing a required argument: '_DivIdx'")
            _send_buffer.write(KeyAccessRights_DiversificationMode_Parser.as_value(_DiversificationMode).to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_DivIdx.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(CryptoAlgorithm_Parser.as_value(Algorithm).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Key.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, CryptoKey_ndx: int, Entry_ndx: int, AccessRights: Union[KeyAccessRights, KeyAccessRights_Dict], Algorithm: CryptoAlgorithm, Key: str) -> None:
        frame = self.build_frame(CryptoKey_ndx=CryptoKey_ndx, Entry_ndx=Entry_ndx, AccessRights=AccessRights, Algorithm=Algorithm, Key=Key)
        self.process_frame(frame)
class Project_DiversificationData(ConfigBase):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x40
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'@')
        self.process_frame(_send_buffer.getvalue())
class Project_DiversificationData_Entry(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x40
    ValueKey: ClassVar[int] = 0x00
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 32
    def reset(self, Entry_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'@')
        if Entry_ndx < 0 or Entry_ndx >= 32:
            raise IndexError(Entry_ndx)
        _send_buffer.write((0 + Entry_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Template:
        _recv_buffer = BytesIO(frame)
        _Value = Template(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, Entry_ndx: int, default: Optional[Template] = None) -> Optional[Template]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'@')
        if Entry_ndx < 0 or Entry_ndx >= 32:
            raise IndexError(Entry_ndx)
        _send_buffer.write((0 + Entry_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Entry_ndx: int, Value: Union[Template, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'@')
        if Entry_ndx < 0 or Entry_ndx >= 32:
            raise IndexError(Entry_ndx)
        _send_buffer.write((0 + Entry_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Entry_ndx: int, Value: Union[Template, bytes]) -> None:
        frame = self.build_frame(Entry_ndx=Entry_ndx, Value=Value)
        self.process_frame(frame)
class Project_SamAVxKeySettings(ConfigBase):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x41
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'A')
        self.process_frame(_send_buffer.getvalue())
class Project_SamAVxKeySettings_Index(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x41
    ValueKey: ClassVar[int] = 0x00
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 128
    def reset(self, Index_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'A')
        if Index_ndx < 0 or Index_ndx >= 128:
            raise IndexError(Index_ndx)
        _send_buffer.write((0 + Index_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[Project_SamAVxKeySettings_Index_KeySettingsList_Entry]:
        _recv_buffer = BytesIO(frame)
        _KeySettingsList = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _KeyVersion = safe_read_int_from_buffer(_recv_buffer, 1)
            _DiversificationMode = Project_SamAVxKeySettings_Index_DiversificationMode_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
            _DivIdx = safe_read_int_from_buffer(_recv_buffer, 1)
            _KeySettingsList_Entry = Project_SamAVxKeySettings_Index_KeySettingsList_Entry(_KeyVersion, _DiversificationMode, _DivIdx)
            _KeySettingsList.append(_KeySettingsList_Entry)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _KeySettingsList
    def get(self, Index_ndx: int, default: Optional[List[Project_SamAVxKeySettings_Index_KeySettingsList_Entry]] = None) -> Optional[List[Project_SamAVxKeySettings_Index_KeySettingsList_Entry]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'A')
        if Index_ndx < 0 or Index_ndx >= 128:
            raise IndexError(Index_ndx)
        _send_buffer.write((0 + Index_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Index_ndx: int, KeySettingsList: List[Project_SamAVxKeySettings_Index_KeySettingsList_Entry]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'A')
        if Index_ndx < 0 or Index_ndx >= 128:
            raise IndexError(Index_ndx)
        _send_buffer.write((0 + Index_ndx).to_bytes(1, byteorder='big'))
        for _KeySettingsList_Entry in KeySettingsList:
            _KeyVersion, _DiversificationMode, _DivIdx = _KeySettingsList_Entry
            _send_buffer.write(_KeyVersion.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(Project_SamAVxKeySettings_Index_DiversificationMode_Parser.as_value(_DiversificationMode).to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_DivIdx.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Index_ndx: int, KeySettingsList: List[Project_SamAVxKeySettings_Index_KeySettingsList_Entry]) -> None:
        frame = self.build_frame(Index_ndx=Index_ndx, KeySettingsList=KeySettingsList)
        self.process_frame(frame)
class Project_LegicKeySettings(ConfigBase):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x44
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'D')
        self.process_frame(_send_buffer.getvalue())
class Project_LegicKeySettings_Index(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x44
    ValueKey: ClassVar[int] = 0x00
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 128
    def reset(self, Index_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'D')
        if Index_ndx < 0 or Index_ndx >= 128:
            raise IndexError(Index_ndx)
        _send_buffer.write((0 + Index_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_LegicKeySettings_Index_Result:
        _recv_buffer = BytesIO(frame)
        _VcpLabel = safe_read_int_from_buffer(_recv_buffer, 2)
        _KeyType = Project_LegicKeySettings_Index_KeyType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _DiversificationMode = Project_LegicKeySettings_Index_DiversificationMode_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _DivIdx = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Project_LegicKeySettings_Index_Result(_VcpLabel, _KeyType, _DiversificationMode, _DivIdx)
    def get(self, Index_ndx: int, default: Optional[Project_LegicKeySettings_Index_Result] = None) -> Optional[Project_LegicKeySettings_Index_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'D')
        if Index_ndx < 0 or Index_ndx >= 128:
            raise IndexError(Index_ndx)
        _send_buffer.write((0 + Index_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Index_ndx: int, VcpLabel: int, KeyType: Project_LegicKeySettings_Index_KeyType, DiversificationMode: Project_LegicKeySettings_Index_DiversificationMode, DivIdx: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'D')
        if Index_ndx < 0 or Index_ndx >= 128:
            raise IndexError(Index_ndx)
        _send_buffer.write((0 + Index_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(VcpLabel.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(Project_LegicKeySettings_Index_KeyType_Parser.as_value(KeyType).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Project_LegicKeySettings_Index_DiversificationMode_Parser.as_value(DiversificationMode).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(DivIdx.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Index_ndx: int, VcpLabel: int, KeyType: Project_LegicKeySettings_Index_KeyType, DiversificationMode: Project_LegicKeySettings_Index_DiversificationMode, DivIdx: int) -> None:
        frame = self.build_frame(Index_ndx=Index_ndx, VcpLabel=VcpLabel, KeyType=KeyType, DiversificationMode=DiversificationMode, DivIdx=DivIdx)
        self.process_frame(frame)
class Project_LegicVcp(ConfigBase):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x45
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'E')
        self.process_frame(_send_buffer.getvalue())
class Project_LegicVcp_Status(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x45
    ValueKey: ClassVar[int] = 0x00
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'E')
        _send_buffer.write(b'\x00')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_LegicVcp_Status_Result:
        _recv_buffer = BytesIO(frame)
        _Context = Project_LegicVcp_Status_Context_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _StatusCode = Project_LegicVcp_Status_StatusCode_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Project_LegicVcp_Status_Result(_Context, _StatusCode)
    def get(self, default: Optional[Project_LegicVcp_Status_Result] = None) -> Optional[Project_LegicVcp_Status_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'E')
        _send_buffer.write(b'\x00')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Context: Project_LegicVcp_Status_Context, StatusCode: Project_LegicVcp_Status_StatusCode) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'E')
        _send_buffer.write(b'\x00')
        _send_buffer.write(Project_LegicVcp_Status_Context_Parser.as_value(Context).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Project_LegicVcp_Status_StatusCode_Parser.as_value(StatusCode).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Context: Project_LegicVcp_Status_Context, StatusCode: Project_LegicVcp_Status_StatusCode) -> None:
        frame = self.build_frame(Context=Context, StatusCode=StatusCode)
        self.process_frame(frame)
class Project_LegicVcp_VcpKeyIndex(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x45
    ValueKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'E')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'E')
        _send_buffer.write(b'\x01')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'E')
        _send_buffer.write(b'\x01')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_LegicVcp_VcpFile4000Hash(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x45
    ValueKey: ClassVar[int] = 0x10
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'E')
        _send_buffer.write(b'\x10')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'E')
        _send_buffer.write(b'\x10')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'E')
        _send_buffer.write(b'\x10')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_LegicVcp_VcpFile4000Data(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x45
    ValueKey: ClassVar[int] = 0x11
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 15
    def reset(self, VcpFile4000Data_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'E')
        if VcpFile4000Data_ndx < 0 or VcpFile4000Data_ndx >= 15:
            raise IndexError(VcpFile4000Data_ndx)
        _send_buffer.write((17 + VcpFile4000Data_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, VcpFile4000Data_ndx: int, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'E')
        if VcpFile4000Data_ndx < 0 or VcpFile4000Data_ndx >= 15:
            raise IndexError(VcpFile4000Data_ndx)
        _send_buffer.write((17 + VcpFile4000Data_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, VcpFile4000Data_ndx: int, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'E')
        if VcpFile4000Data_ndx < 0 or VcpFile4000Data_ndx >= 15:
            raise IndexError(VcpFile4000Data_ndx)
        _send_buffer.write((17 + VcpFile4000Data_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, VcpFile4000Data_ndx: int, Value: str) -> None:
        frame = self.build_frame(VcpFile4000Data_ndx=VcpFile4000Data_ndx, Value=Value)
        self.process_frame(frame)
class Project_LegicVcp_VcpFile6000Hash(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x45
    ValueKey: ClassVar[int] = 0x20
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'E')
        _send_buffer.write(b' ')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'E')
        _send_buffer.write(b' ')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'E')
        _send_buffer.write(b' ')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_LegicVcp_VcpFile6000Data(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x45
    ValueKey: ClassVar[int] = 0x21
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 15
    def reset(self, VcpFile6000Data_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'E')
        if VcpFile6000Data_ndx < 0 or VcpFile6000Data_ndx >= 15:
            raise IndexError(VcpFile6000Data_ndx)
        _send_buffer.write((33 + VcpFile6000Data_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, VcpFile6000Data_ndx: int, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'E')
        if VcpFile6000Data_ndx < 0 or VcpFile6000Data_ndx >= 15:
            raise IndexError(VcpFile6000Data_ndx)
        _send_buffer.write((33 + VcpFile6000Data_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, VcpFile6000Data_ndx: int, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'E')
        if VcpFile6000Data_ndx < 0 or VcpFile6000Data_ndx >= 15:
            raise IndexError(VcpFile6000Data_ndx)
        _send_buffer.write((33 + VcpFile6000Data_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, VcpFile6000Data_ndx: int, Value: str) -> None:
        frame = self.build_frame(VcpFile6000Data_ndx=VcpFile6000Data_ndx, Value=Value)
        self.process_frame(frame)
class Project_LegicVcp_Password(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x45
    ValueKey: ClassVar[int] = 0x80
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'E')
        _send_buffer.write(b'\x80')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'E')
        _send_buffer.write(b'\x80')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'E')
        _send_buffer.write(b'\x80')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_MobileId(ConfigBase):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x53
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        self.process_frame(_send_buffer.getvalue())
class Project_MobileId_Mode(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x53
    ValueKey: ClassVar[int] = 0x00
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x00')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_MobileId_Mode_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Project_MobileId_Mode_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Project_MobileId_Mode_Value] = None) -> Optional[Project_MobileId_Mode_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x00')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Project_MobileId_Mode_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x00')
        _send_buffer.write(Project_MobileId_Mode_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Project_MobileId_Mode_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_MobileId_DisplayName(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x53
    ValueKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x01')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x01')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_MobileId_TriggerFromDistance(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x53
    ValueKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_MobileId_TriggerFromDistance_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Project_MobileId_TriggerFromDistance_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Project_MobileId_TriggerFromDistance_Value] = None) -> Optional[Project_MobileId_TriggerFromDistance_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x02')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Project_MobileId_TriggerFromDistance_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x02')
        _send_buffer.write(Project_MobileId_TriggerFromDistance_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Project_MobileId_TriggerFromDistance_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_MobileId_ConvenientAccess(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x53
    ValueKey: ClassVar[int] = 0x03
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x03')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_MobileId_ConvenientAccess_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Project_MobileId_ConvenientAccess_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Project_MobileId_ConvenientAccess_Value] = None) -> Optional[Project_MobileId_ConvenientAccess_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x03')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Project_MobileId_ConvenientAccess_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x03')
        _send_buffer.write(Project_MobileId_ConvenientAccess_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Project_MobileId_ConvenientAccess_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_MobileId_AdvertisementFilter(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x53
    ValueKey: ClassVar[int] = 0x04
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x04')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_MobileId_AdvertisementFilter_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Project_MobileId_AdvertisementFilter_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Project_MobileId_AdvertisementFilter_Value] = None) -> Optional[Project_MobileId_AdvertisementFilter_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x04')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Project_MobileId_AdvertisementFilter_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x04')
        _send_buffer.write(Project_MobileId_AdvertisementFilter_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Project_MobileId_AdvertisementFilter_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_MobileId_RssiCorrectionConvenientAccess(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x53
    ValueKey: ClassVar[int] = 0x05
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x05')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x05')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x05')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_MobileId_DetectionRssiFilter(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x53
    ValueKey: ClassVar[int] = 0x06
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x06')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_MobileId_DetectionRssiFilter_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Project_MobileId_DetectionRssiFilter_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Project_MobileId_DetectionRssiFilter_Value] = None) -> Optional[Project_MobileId_DetectionRssiFilter_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x06')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Project_MobileId_DetectionRssiFilter_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x06')
        _send_buffer.write(Project_MobileId_DetectionRssiFilter_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Project_MobileId_DetectionRssiFilter_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_MobileId_RssiOffset(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x53
    ValueKey: ClassVar[int] = 0x07
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x07')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x07')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x07')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_MobileId_MsgType(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x53
    ValueKey: ClassVar[int] = 0x11
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x11')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> MessageType:
        _recv_buffer = BytesIO(frame)
        _Value = MessageType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[MessageType] = None) -> Optional[MessageType]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x11')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: MessageType) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x11')
        _send_buffer.write(MessageType_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: MessageType) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_MobileId_OnMatchEvent(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x53
    ValueKey: ClassVar[int] = 0x12
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x12')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x12')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        _send_buffer.write(b'\x12')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_MobileId_Template(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x53
    ValueKey: ClassVar[int] = 0x20
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 32
    def reset(self, Template_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        if Template_ndx < 0 or Template_ndx >= 32:
            raise IndexError(Template_ndx)
        _send_buffer.write((32 + Template_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Template:
        _recv_buffer = BytesIO(frame)
        _Value = Template(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, Template_ndx: int, default: Optional[Template] = None) -> Optional[Template]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        if Template_ndx < 0 or Template_ndx >= 32:
            raise IndexError(Template_ndx)
        _send_buffer.write((32 + Template_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Template_ndx: int, Value: Union[Template, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        if Template_ndx < 0 or Template_ndx >= 32:
            raise IndexError(Template_ndx)
        _send_buffer.write((32 + Template_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Template_ndx: int, Value: Union[Template, bytes]) -> None:
        frame = self.build_frame(Template_ndx=Template_ndx, Value=Value)
        self.process_frame(frame)
class Project_MobileId_Key(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x53
    ValueKey: ClassVar[int] = 0x80
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 32
    def reset(self, Key_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        if Key_ndx < 0 or Key_ndx >= 32:
            raise IndexError(Key_ndx)
        _send_buffer.write((128 + Key_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Key_bytes = _recv_buffer.read(16)
        _Key = _Key_bytes.decode('ascii')
        if len(_Key) != 16:
            raise PayloadTooShortError(16 - len(_Key))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Key
    def get(self, Key_ndx: int, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        if Key_ndx < 0 or Key_ndx >= 32:
            raise IndexError(Key_ndx)
        _send_buffer.write((128 + Key_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Key_ndx: int, Key: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'S')
        if Key_ndx < 0 or Key_ndx >= 32:
            raise IndexError(Key_ndx)
        _send_buffer.write((128 + Key_ndx).to_bytes(1, byteorder='big'))
        if len(Key) != 16:
            raise ValueError(Key)
        _send_buffer.write(Key.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Key_ndx: int, Key: str) -> None:
        frame = self.build_frame(Key_ndx=Key_ndx, Key=Key)
        self.process_frame(frame)
class Protocols(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
class Protocols_BrpSerial(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x03
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        self.process_frame(_send_buffer.getvalue())
class Protocols_BrpSerial_Baudrate(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x03
    ValueKey: ClassVar[int] = 0x00
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x00')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Baudrate:
        _recv_buffer = BytesIO(frame)
        _Value = Baudrate_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 2))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Baudrate] = None) -> Optional[Baudrate]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x00')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Baudrate = "Baud115200") -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x00')
        _send_buffer.write(Baudrate_Parser.as_value(Value).to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Baudrate = "Baud115200") -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BrpSerial_Parity(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x03
    ValueKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Parity:
        _recv_buffer = BytesIO(frame)
        _Value = Parity_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Parity] = None) -> Optional[Parity]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x01')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Parity) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x01')
        _send_buffer.write(Parity_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Parity) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BrpSerial_InterbyteTimeout(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x03
    ValueKey: ClassVar[int] = 0x03
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x03')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_BrpSerial_InterbyteTimeout_Result:
        _recv_buffer = BytesIO(frame)
        _Timeout = safe_read_int_from_buffer(_recv_buffer, 2)
        _LegacyFormat = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Protocols_BrpSerial_InterbyteTimeout_Result(_Timeout, _LegacyFormat)
    def get(self, default: Optional[Protocols_BrpSerial_InterbyteTimeout_Result] = None) -> Optional[Protocols_BrpSerial_InterbyteTimeout_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x03')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Timeout: int, LegacyFormat: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x03')
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(LegacyFormat.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Timeout: int, LegacyFormat: int) -> None:
        frame = self.build_frame(Timeout=Timeout, LegacyFormat=LegacyFormat)
        self.process_frame(frame)
class Protocols_BrpSerial_CmdWorkInterval(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x03
    ValueKey: ClassVar[int] = 0x15
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x15')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x15')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x15')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BrpSerial_RepeatModeMinDelay(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x03
    ValueKey: ClassVar[int] = 0x14
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x14')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x14')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        _send_buffer.write(b'\x14')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BrpSerial_HostMsgFormatTemplate(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x03
    ValueKey: ClassVar[int] = 0x40
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 4
    def reset(self, HostMsgFormatTemplate_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Template:
        _recv_buffer = BytesIO(frame)
        _Value = Template(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, HostMsgFormatTemplate_ndx: int, default: Optional[Template] = None) -> Optional[Template]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, HostMsgFormatTemplate_ndx: int, Value: Union[Template, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, HostMsgFormatTemplate_ndx: int, Value: Union[Template, bytes]) -> None:
        frame = self.build_frame(HostMsgFormatTemplate_ndx=HostMsgFormatTemplate_ndx, Value=Value)
        self.process_frame(frame)
class Protocols_BrpSerial_AutoRunCommand(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x03
    ValueKey: ClassVar[int] = 0x50
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 16
    def reset(self, AutoRunCommand_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if AutoRunCommand_ndx < 0 or AutoRunCommand_ndx >= 16:
            raise IndexError(AutoRunCommand_ndx)
        _send_buffer.write((80 + AutoRunCommand_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> AutoRunCommand:
        _recv_buffer = BytesIO(frame)
        _RunMode = AutoRunCommand_RunMode_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _DeviceCode = safe_read_int_from_buffer(_recv_buffer, 1)
        _CommandCode = safe_read_int_from_buffer(_recv_buffer, 1)
        _Parameter_bytes = _recv_buffer.read(-1)
        _Parameter = _Parameter_bytes.decode('ascii')
        _Value = AutoRunCommand(_RunMode, _DeviceCode, _CommandCode, _Parameter)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, AutoRunCommand_ndx: int, default: Optional[AutoRunCommand] = None) -> Optional[AutoRunCommand]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if AutoRunCommand_ndx < 0 or AutoRunCommand_ndx >= 16:
            raise IndexError(AutoRunCommand_ndx)
        _send_buffer.write((80 + AutoRunCommand_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, AutoRunCommand_ndx: int, Value: Union[AutoRunCommand, AutoRunCommand_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if AutoRunCommand_ndx < 0 or AutoRunCommand_ndx >= 16:
            raise IndexError(AutoRunCommand_ndx)
        _send_buffer.write((80 + AutoRunCommand_ndx).to_bytes(1, byteorder='big'))
        if isinstance(Value, dict):
            Value = AutoRunCommand(**Value)
        _RunMode, _DeviceCode, _CommandCode, _Parameter = Value
        _send_buffer.write(AutoRunCommand_RunMode_Parser.as_value(_RunMode).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(_DeviceCode.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(_CommandCode.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(_Parameter.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, AutoRunCommand_ndx: int, Value: Union[AutoRunCommand, AutoRunCommand_Dict]) -> None:
        frame = self.build_frame(AutoRunCommand_ndx=AutoRunCommand_ndx, Value=Value)
        self.process_frame(frame)
class Protocols_BrpHid(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x05
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        self.process_frame(_send_buffer.getvalue())
class Protocols_BrpHid_CmdWorkInterval(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x05
    ValueKey: ClassVar[int] = 0x15
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x15')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x15')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x15')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BrpHid_RepeatModeMinDelay(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x05
    ValueKey: ClassVar[int] = 0x14
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x14')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x14')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x14')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BrpHid_UsbVendorName(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x05
    ValueKey: ClassVar[int] = 0x21
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'!')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'!')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'!')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BrpHid_UsbProductName(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x05
    ValueKey: ClassVar[int] = 0x22
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'"')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'"')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'"')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BrpHid_UsbSerialNumber(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x05
    ValueKey: ClassVar[int] = 0x23
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'#')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'#')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'#')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BrpHid_HostMsgFormatTemplate(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x05
    ValueKey: ClassVar[int] = 0x40
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 4
    def reset(self, HostMsgFormatTemplate_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Template:
        _recv_buffer = BytesIO(frame)
        _Value = Template(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, HostMsgFormatTemplate_ndx: int, default: Optional[Template] = None) -> Optional[Template]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, HostMsgFormatTemplate_ndx: int, Value: Union[Template, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, HostMsgFormatTemplate_ndx: int, Value: Union[Template, bytes]) -> None:
        frame = self.build_frame(HostMsgFormatTemplate_ndx=HostMsgFormatTemplate_ndx, Value=Value)
        self.process_frame(frame)
class Protocols_BrpHid_AutoRunCommand(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x05
    ValueKey: ClassVar[int] = 0x50
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 16
    def reset(self, AutoRunCommand_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        if AutoRunCommand_ndx < 0 or AutoRunCommand_ndx >= 16:
            raise IndexError(AutoRunCommand_ndx)
        _send_buffer.write((80 + AutoRunCommand_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> AutoRunCommand:
        _recv_buffer = BytesIO(frame)
        _RunMode = AutoRunCommand_RunMode_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _DeviceCode = safe_read_int_from_buffer(_recv_buffer, 1)
        _CommandCode = safe_read_int_from_buffer(_recv_buffer, 1)
        _Parameter_bytes = _recv_buffer.read(-1)
        _Parameter = _Parameter_bytes.decode('ascii')
        _Value = AutoRunCommand(_RunMode, _DeviceCode, _CommandCode, _Parameter)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, AutoRunCommand_ndx: int, default: Optional[AutoRunCommand] = None) -> Optional[AutoRunCommand]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        if AutoRunCommand_ndx < 0 or AutoRunCommand_ndx >= 16:
            raise IndexError(AutoRunCommand_ndx)
        _send_buffer.write((80 + AutoRunCommand_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, AutoRunCommand_ndx: int, Value: Union[AutoRunCommand, AutoRunCommand_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        if AutoRunCommand_ndx < 0 or AutoRunCommand_ndx >= 16:
            raise IndexError(AutoRunCommand_ndx)
        _send_buffer.write((80 + AutoRunCommand_ndx).to_bytes(1, byteorder='big'))
        if isinstance(Value, dict):
            Value = AutoRunCommand(**Value)
        _RunMode, _DeviceCode, _CommandCode, _Parameter = Value
        _send_buffer.write(AutoRunCommand_RunMode_Parser.as_value(_RunMode).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(_DeviceCode.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(_CommandCode.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(_Parameter.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, AutoRunCommand_ndx: int, Value: Union[AutoRunCommand, AutoRunCommand_Dict]) -> None:
        frame = self.build_frame(AutoRunCommand_ndx=AutoRunCommand_ndx, Value=Value)
        self.process_frame(frame)
class Protocols_SNet(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x10
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x10')
        self.process_frame(_send_buffer.getvalue())
class Protocols_SNet_BusAddress(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x10
    ValueKey: ClassVar[int] = 0x20
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x10')
        _send_buffer.write(b' ')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x10')
        _send_buffer.write(b' ')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x10')
        _send_buffer.write(b' ')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_SNet_DeviceType(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x10
    ValueKey: ClassVar[int] = 0x21
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x10')
        _send_buffer.write(b'!')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_SNet_DeviceType_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_SNet_DeviceType_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_SNet_DeviceType_Value] = None) -> Optional[Protocols_SNet_DeviceType_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x10')
        _send_buffer.write(b'!')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_SNet_DeviceType_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x10')
        _send_buffer.write(b'!')
        _send_buffer.write(Protocols_SNet_DeviceType_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_SNet_DeviceType_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_SNet_HostMsgFormatTemplate(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x10
    ValueKey: ClassVar[int] = 0x40
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 4
    def reset(self, HostMsgFormatTemplate_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x10')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Template:
        _recv_buffer = BytesIO(frame)
        _Value = Template(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, HostMsgFormatTemplate_ndx: int, default: Optional[Template] = None) -> Optional[Template]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x10')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, HostMsgFormatTemplate_ndx: int, Value: Union[Template, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x10')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, HostMsgFormatTemplate_ndx: int, Value: Union[Template, bytes]) -> None:
        frame = self.build_frame(HostMsgFormatTemplate_ndx=HostMsgFormatTemplate_ndx, Value=Value)
        self.process_frame(frame)
class Protocols_Bpa9(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x11
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x11')
        self.process_frame(_send_buffer.getvalue())
class Protocols_Bpa9_HostMsgFormatTemplate(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x11
    ValueKey: ClassVar[int] = 0x40
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 4
    def reset(self, HostMsgFormatTemplate_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x11')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Template:
        _recv_buffer = BytesIO(frame)
        _Value = Template(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, HostMsgFormatTemplate_ndx: int, default: Optional[Template] = None) -> Optional[Template]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x11')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, HostMsgFormatTemplate_ndx: int, Value: Union[Template, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x11')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, HostMsgFormatTemplate_ndx: int, Value: Union[Template, bytes]) -> None:
        frame = self.build_frame(HostMsgFormatTemplate_ndx=HostMsgFormatTemplate_ndx, Value=Value)
        self.process_frame(frame)
class Protocols_Wiegand(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x20
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b' ')
        self.process_frame(_send_buffer.getvalue())
class Protocols_Wiegand_HostMsgFormatTemplate(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x40
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 4
    def reset(self, HostMsgFormatTemplate_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b' ')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Template:
        _recv_buffer = BytesIO(frame)
        _Value = Template(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, HostMsgFormatTemplate_ndx: int, default: Optional[Template] = None) -> Optional[Template]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b' ')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, HostMsgFormatTemplate_ndx: int, Value: Union[Template, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b' ')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, HostMsgFormatTemplate_ndx: int, Value: Union[Template, bytes]) -> None:
        frame = self.build_frame(HostMsgFormatTemplate_ndx=HostMsgFormatTemplate_ndx, Value=Value)
        self.process_frame(frame)
class Protocols_Wiegand_MessageLength(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x02')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x02')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Wiegand_BitOrder(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x03
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x03')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_Wiegand_BitOrder_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_Wiegand_BitOrder_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_Wiegand_BitOrder_Value] = None) -> Optional[Protocols_Wiegand_BitOrder_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x03')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_Wiegand_BitOrder_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x03')
        _send_buffer.write(Protocols_Wiegand_BitOrder_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_Wiegand_BitOrder_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Wiegand_PinMessageFormat(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x33
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b' ')
        _send_buffer.write(b'3')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_Wiegand_PinMessageFormat_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_Wiegand_PinMessageFormat_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_Wiegand_PinMessageFormat_Value] = None) -> Optional[Protocols_Wiegand_PinMessageFormat_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b' ')
        _send_buffer.write(b'3')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_Wiegand_PinMessageFormat_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b' ')
        _send_buffer.write(b'3')
        _send_buffer.write(Protocols_Wiegand_PinMessageFormat_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_Wiegand_PinMessageFormat_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Wiegand_PulseWidth(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x04
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x04')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x04')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x04')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Wiegand_PulseInterval(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x05
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x05')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x05')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x05')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Wiegand_Mode(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x06
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x06')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_Wiegand_Mode_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_Wiegand_Mode_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_Wiegand_Mode_Value] = None) -> Optional[Protocols_Wiegand_Mode_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x06')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_Wiegand_Mode_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x06')
        _send_buffer.write(Protocols_Wiegand_Mode_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_Wiegand_Mode_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_RawSerial(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x23
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'#')
        self.process_frame(_send_buffer.getvalue())
class Protocols_RawSerial_Baudrate(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x23
    ValueKey: ClassVar[int] = 0x00
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'#')
        _send_buffer.write(b'\x00')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Baudrate:
        _recv_buffer = BytesIO(frame)
        _Value = Baudrate_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 2))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Baudrate] = None) -> Optional[Baudrate]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'#')
        _send_buffer.write(b'\x00')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Baudrate = "Baud115200") -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'#')
        _send_buffer.write(b'\x00')
        _send_buffer.write(Baudrate_Parser.as_value(Value).to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Baudrate = "Baud115200") -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_RawSerial_Parity(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x23
    ValueKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'#')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Parity:
        _recv_buffer = BytesIO(frame)
        _Value = Parity_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Parity] = None) -> Optional[Parity]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'#')
        _send_buffer.write(b'\x01')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Parity) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'#')
        _send_buffer.write(b'\x01')
        _send_buffer.write(Parity_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Parity) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_RawSerial_BitsPerByte(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x23
    ValueKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'#')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'#')
        _send_buffer.write(b'\x02')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'#')
        _send_buffer.write(b'\x02')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_RawSerial_Channel(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x23
    ValueKey: ClassVar[int] = 0x21
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'#')
        _send_buffer.write(b'!')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_RawSerial_Channel_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_RawSerial_Channel_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_RawSerial_Channel_Value] = None) -> Optional[Protocols_RawSerial_Channel_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'#')
        _send_buffer.write(b'!')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_RawSerial_Channel_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'#')
        _send_buffer.write(b'!')
        _send_buffer.write(Protocols_RawSerial_Channel_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_RawSerial_Channel_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_RawSerial_HostMsgFormatTemplate(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x23
    ValueKey: ClassVar[int] = 0x40
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 4
    def reset(self, HostMsgFormatTemplate_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'#')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Template:
        _recv_buffer = BytesIO(frame)
        _Value = Template(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, HostMsgFormatTemplate_ndx: int, default: Optional[Template] = None) -> Optional[Template]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'#')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, HostMsgFormatTemplate_ndx: int, Value: Union[Template, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'#')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, HostMsgFormatTemplate_ndx: int, Value: Union[Template, bytes]) -> None:
        frame = self.build_frame(HostMsgFormatTemplate_ndx=HostMsgFormatTemplate_ndx, Value=Value)
        self.process_frame(frame)
class Protocols_LowLevelIoPorts(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x24
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'$')
        self.process_frame(_send_buffer.getvalue())
class Protocols_LowLevelIoPorts_PhysicalPinMap(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x24
    ValueKey: ClassVar[int] = 0x04
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'$')
        _send_buffer.write(b'\x04')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[IoPort]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _PhysicalPin = IoPort_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
            _Value.append(_PhysicalPin)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[List[IoPort]] = None) -> Optional[List[IoPort]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'$')
        _send_buffer.write(b'\x04')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: List[IoPort]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'$')
        _send_buffer.write(b'\x04')
        for _Value_Entry in Value:
            _PhysicalPin = _Value_Entry
            _send_buffer.write(IoPort_Parser.as_value(_PhysicalPin).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: List[IoPort]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_MagstripeEmulation(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x21
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'!')
        self.process_frame(_send_buffer.getvalue())
class Protocols_MagstripeEmulation_Encoding(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x21
    ValueKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'!')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_MagstripeEmulation_Encoding_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_MagstripeEmulation_Encoding_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_MagstripeEmulation_Encoding_Value] = None) -> Optional[Protocols_MagstripeEmulation_Encoding_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'!')
        _send_buffer.write(b'\x02')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_MagstripeEmulation_Encoding_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'!')
        _send_buffer.write(b'\x02')
        _send_buffer.write(Protocols_MagstripeEmulation_Encoding_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_MagstripeEmulation_Encoding_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        self.process_frame(_send_buffer.getvalue())
class Protocols_Network_IpAddress(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x20
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b' ')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b' ')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b' ')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network_IpSubnetMask(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x21
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'!')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'!')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'!')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network_IpGateway(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x22
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'"')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'"')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'"')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network_IpDnsServer(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x23
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'#')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'#')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'#')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network_DhcpMode(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x24
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'$')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_Network_DhcpMode_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_Network_DhcpMode_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_Network_DhcpMode_Value] = None) -> Optional[Protocols_Network_DhcpMode_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'$')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_Network_DhcpMode_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'$')
        _send_buffer.write(Protocols_Network_DhcpMode_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_Network_DhcpMode_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_KeyboardEmulation(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x2B
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'+')
        self.process_frame(_send_buffer.getvalue())
class Protocols_KeyboardEmulation_RegisterInterface(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x2B
    ValueKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'+')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_KeyboardEmulation_RegisterInterface_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_KeyboardEmulation_RegisterInterface_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_KeyboardEmulation_RegisterInterface_Value] = None) -> Optional[Protocols_KeyboardEmulation_RegisterInterface_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'+')
        _send_buffer.write(b'\x01')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_KeyboardEmulation_RegisterInterface_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'+')
        _send_buffer.write(b'\x01')
        _send_buffer.write(Protocols_KeyboardEmulation_RegisterInterface_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_KeyboardEmulation_RegisterInterface_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_KeyboardEmulation_ScancodesMap(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x2B
    ValueKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'+')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[Protocols_KeyboardEmulation_ScancodesMap_Value_Entry]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _AsciiCode = safe_read_int_from_buffer(_recv_buffer, 1)
            _ScanCode = safe_read_int_from_buffer(_recv_buffer, 1)
            _ModifierKeys_int = safe_read_int_from_buffer(_recv_buffer, 1)
            _Shift = bool((_ModifierKeys_int >> 7) & 0b1)
            _Ctrl = bool((_ModifierKeys_int >> 6) & 0b1)
            _AltGr = bool((_ModifierKeys_int >> 5) & 0b1)
            _Value_Entry = Protocols_KeyboardEmulation_ScancodesMap_Value_Entry(_AsciiCode, _ScanCode, _Shift, _Ctrl, _AltGr)
            _Value.append(_Value_Entry)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[List[Protocols_KeyboardEmulation_ScancodesMap_Value_Entry]] = None) -> Optional[List[Protocols_KeyboardEmulation_ScancodesMap_Value_Entry]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'+')
        _send_buffer.write(b'\x02')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: List[Protocols_KeyboardEmulation_ScancodesMap_Value_Entry]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'+')
        _send_buffer.write(b'\x02')
        for _Value_Entry in Value:
            _AsciiCode, _ScanCode, _Shift, _Ctrl, _AltGr = _Value_Entry
            _send_buffer.write(_AsciiCode.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_ScanCode.to_bytes(length=1, byteorder='big'))
            _var_0000_int = 0
            _var_0000_int |= (int(_Shift) & 0b1) << 7
            _var_0000_int |= (int(_Ctrl) & 0b1) << 6
            _var_0000_int |= (int(_AltGr) & 0b1) << 5
            _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: List[Protocols_KeyboardEmulation_ScancodesMap_Value_Entry]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_KeyboardEmulation_KeypressDelay(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x2B
    ValueKey: ClassVar[int] = 0x03
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'+')
        _send_buffer.write(b'\x03')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'+')
        _send_buffer.write(b'\x03')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'+')
        _send_buffer.write(b'\x03')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_KeyboardEmulation_UsbInterfaceSubClass(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x2B
    ValueKey: ClassVar[int] = 0x04
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'+')
        _send_buffer.write(b'\x04')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_KeyboardEmulation_UsbInterfaceSubClass_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_KeyboardEmulation_UsbInterfaceSubClass_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_KeyboardEmulation_UsbInterfaceSubClass_Value] = None) -> Optional[Protocols_KeyboardEmulation_UsbInterfaceSubClass_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'+')
        _send_buffer.write(b'\x04')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_KeyboardEmulation_UsbInterfaceSubClass_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'+')
        _send_buffer.write(b'\x04')
        _send_buffer.write(Protocols_KeyboardEmulation_UsbInterfaceSubClass_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_KeyboardEmulation_UsbInterfaceSubClass_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_KeyboardEmulation_UsbInterfaceOrder(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x2B
    ValueKey: ClassVar[int] = 0x05
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'+')
        _send_buffer.write(b'\x05')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_KeyboardEmulation_UsbInterfaceOrder_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_KeyboardEmulation_UsbInterfaceOrder_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_KeyboardEmulation_UsbInterfaceOrder_Value] = None) -> Optional[Protocols_KeyboardEmulation_UsbInterfaceOrder_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'+')
        _send_buffer.write(b'\x05')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_KeyboardEmulation_UsbInterfaceOrder_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'+')
        _send_buffer.write(b'\x05')
        _send_buffer.write(Protocols_KeyboardEmulation_UsbInterfaceOrder_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_KeyboardEmulation_UsbInterfaceOrder_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_KeyboardEmulation_HostMsgFormatTemplate(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x2B
    ValueKey: ClassVar[int] = 0x40
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 4
    def reset(self, HostMsgFormatTemplate_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'+')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Template:
        _recv_buffer = BytesIO(frame)
        _Value = Template(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, HostMsgFormatTemplate_ndx: int, default: Optional[Template] = None) -> Optional[Template]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'+')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, HostMsgFormatTemplate_ndx: int, Value: Union[Template, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'+')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, HostMsgFormatTemplate_ndx: int, Value: Union[Template, bytes]) -> None:
        frame = self.build_frame(HostMsgFormatTemplate_ndx=HostMsgFormatTemplate_ndx, Value=Value)
        self.process_frame(frame)
class Protocols_Ccid(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x36
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'6')
        self.process_frame(_send_buffer.getvalue())
class Protocols_Ccid_CardTypeMask(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x36
    ValueKey: ClassVar[int] = 0x20
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'6')
        _send_buffer.write(b' ')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> CardFamilies:
        _recv_buffer = BytesIO(frame)
        _Value_int = safe_read_int_from_buffer(_recv_buffer, 2)
        _LEGICPrime = bool((_Value_int >> 11) & 0b1)
        _BluetoothMce = bool((_Value_int >> 10) & 0b1)
        _Khz125Part2 = bool((_Value_int >> 9) & 0b1)
        _Srix = bool((_Value_int >> 8) & 0b1)
        _Khz125Part1 = bool((_Value_int >> 7) & 0b1)
        _Felica = bool((_Value_int >> 6) & 0b1)
        _IClass = bool((_Value_int >> 5) & 0b1)
        _IClassIso14B = bool((_Value_int >> 4) & 0b1)
        _Iso14443B = bool((_Value_int >> 3) & 0b1)
        _Iso15693 = bool((_Value_int >> 2) & 0b1)
        _Iso14443A = bool((_Value_int >> 0) & 0b1)
        _Value = CardFamilies(_LEGICPrime, _BluetoothMce, _Khz125Part2, _Srix, _Khz125Part1, _Felica, _IClass, _IClassIso14B, _Iso14443B, _Iso15693, _Iso14443A)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[CardFamilies] = None) -> Optional[CardFamilies]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'6')
        _send_buffer.write(b' ')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[CardFamilies, CardFamilies_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'6')
        _send_buffer.write(b' ')
        if isinstance(Value, dict):
            Value = CardFamilies(**Value)
        Value_int = 0
        Value_int |= (int(Value.LEGICPrime) & 0b1) << 11
        Value_int |= (int(Value.BluetoothMce) & 0b1) << 10
        Value_int |= (int(Value.Khz125Part2) & 0b1) << 9
        Value_int |= (int(Value.Srix) & 0b1) << 8
        Value_int |= (int(Value.Khz125Part1) & 0b1) << 7
        Value_int |= (int(Value.Felica) & 0b1) << 6
        Value_int |= (int(Value.IClass) & 0b1) << 5
        Value_int |= (int(Value.IClassIso14B) & 0b1) << 4
        Value_int |= (int(Value.Iso14443B) & 0b1) << 3
        Value_int |= (int(Value.Iso15693) & 0b1) << 2
        Value_int |= (int(Value.Iso14443A) & 0b1) << 0
        _send_buffer.write(Value_int.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[CardFamilies, CardFamilies_Dict]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Ccid_ForceApduCardType(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x36
    ValueKey: ClassVar[int] = 0x21
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'6')
        _send_buffer.write(b'!')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> CardType:
        _recv_buffer = BytesIO(frame)
        _Value = CardType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[CardType] = None) -> Optional[CardType]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'6')
        _send_buffer.write(b'!')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: CardType = "Default") -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'6')
        _send_buffer.write(b'!')
        _send_buffer.write(CardType_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: CardType = "Default") -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Ccid_LedControl(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x36
    ValueKey: ClassVar[int] = 0x22
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'6')
        _send_buffer.write(b'"')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_Ccid_LedControl_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_Ccid_LedControl_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_Ccid_LedControl_Value] = None) -> Optional[Protocols_Ccid_LedControl_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'6')
        _send_buffer.write(b'"')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_Ccid_LedControl_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'6')
        _send_buffer.write(b'"')
        _send_buffer.write(Protocols_Ccid_LedControl_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_Ccid_LedControl_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Osdp(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x38
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        self.process_frame(_send_buffer.getvalue())
class Protocols_Osdp_BaudRate(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x38
    ValueKey: ClassVar[int] = 0x00
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        _send_buffer.write(b'\x00')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Baudrate:
        _recv_buffer = BytesIO(frame)
        _Value = Baudrate_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 2))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Baudrate] = None) -> Optional[Baudrate]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        _send_buffer.write(b'\x00')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Baudrate = "Baud115200") -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        _send_buffer.write(b'\x00')
        _send_buffer.write(Baudrate_Parser.as_value(Value).to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Baudrate = "Baud115200") -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Osdp_Address(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x38
    ValueKey: ClassVar[int] = 0x21
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        _send_buffer.write(b'!')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        _send_buffer.write(b'!')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        _send_buffer.write(b'!')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Osdp_CharTimeout(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x38
    ValueKey: ClassVar[int] = 0x22
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        _send_buffer.write(b'"')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        _send_buffer.write(b'"')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        _send_buffer.write(b'"')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Osdp_SCBKeyDefault(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x38
    ValueKey: ClassVar[int] = 0xA4
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        _send_buffer.write(b'\xa4')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_Osdp_SCBKeyDefault_Result:
        _recv_buffer = BytesIO(frame)
        _DiversifyFlag = Protocols_Osdp_SCBKeyDefault_DiversifyFlag_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _SCBKD_bytes = _recv_buffer.read(-1)
        _SCBKD = _SCBKD_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Protocols_Osdp_SCBKeyDefault_Result(_DiversifyFlag, _SCBKD)
    def get(self, default: Optional[Protocols_Osdp_SCBKeyDefault_Result] = None) -> Optional[Protocols_Osdp_SCBKeyDefault_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        _send_buffer.write(b'\xa4')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, DiversifyFlag: Protocols_Osdp_SCBKeyDefault_DiversifyFlag, SCBKD: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        _send_buffer.write(b'\xa4')
        _send_buffer.write(Protocols_Osdp_SCBKeyDefault_DiversifyFlag_Parser.as_value(DiversifyFlag).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(SCBKD.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, DiversifyFlag: Protocols_Osdp_SCBKeyDefault_DiversifyFlag, SCBKD: str) -> None:
        frame = self.build_frame(DiversifyFlag=DiversifyFlag, SCBKD=SCBKD)
        self.process_frame(frame)
class Protocols_Osdp_SCBKey(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x38
    ValueKey: ClassVar[int] = 0xA5
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        _send_buffer.write(b'\xa5')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_Osdp_SCBKey_Result:
        _recv_buffer = BytesIO(frame)
        _DiversifyFlag = Protocols_Osdp_SCBKey_DiversifyFlag_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _SCBK_bytes = _recv_buffer.read(-1)
        _SCBK = _SCBK_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Protocols_Osdp_SCBKey_Result(_DiversifyFlag, _SCBK)
    def get(self, default: Optional[Protocols_Osdp_SCBKey_Result] = None) -> Optional[Protocols_Osdp_SCBKey_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        _send_buffer.write(b'\xa5')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, DiversifyFlag: Protocols_Osdp_SCBKey_DiversifyFlag, SCBK: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        _send_buffer.write(b'\xa5')
        _send_buffer.write(Protocols_Osdp_SCBKey_DiversifyFlag_Parser.as_value(DiversifyFlag).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(SCBK.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, DiversifyFlag: Protocols_Osdp_SCBKey_DiversifyFlag, SCBK: str) -> None:
        frame = self.build_frame(DiversifyFlag=DiversifyFlag, SCBK=SCBK)
        self.process_frame(frame)
class Protocols_Osdp_SecureInstallMode(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x38
    ValueKey: ClassVar[int] = 0x26
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        _send_buffer.write(b'&')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_Osdp_SecureInstallMode_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_Osdp_SecureInstallMode_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_Osdp_SecureInstallMode_Value] = None) -> Optional[Protocols_Osdp_SecureInstallMode_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        _send_buffer.write(b'&')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_Osdp_SecureInstallMode_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        _send_buffer.write(b'&')
        _send_buffer.write(Protocols_Osdp_SecureInstallMode_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_Osdp_SecureInstallMode_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Osdp_DataMode(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x38
    ValueKey: ClassVar[int] = 0x27
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        _send_buffer.write(b"'")
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_Osdp_DataMode_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_Osdp_DataMode_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 2))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_Osdp_DataMode_Value] = None) -> Optional[Protocols_Osdp_DataMode_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        _send_buffer.write(b"'")
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_Osdp_DataMode_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        _send_buffer.write(b"'")
        _send_buffer.write(Protocols_Osdp_DataMode_Value_Parser.as_value(Value).to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_Osdp_DataMode_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Osdp_HostMsgFormatTemplate(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x38
    ValueKey: ClassVar[int] = 0x40
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 4
    def reset(self, HostMsgFormatTemplate_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Template:
        _recv_buffer = BytesIO(frame)
        _Value = Template(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, HostMsgFormatTemplate_ndx: int, default: Optional[Template] = None) -> Optional[Template]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, HostMsgFormatTemplate_ndx: int, Value: Union[Template, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'8')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, HostMsgFormatTemplate_ndx: int, Value: Union[Template, bytes]) -> None:
        frame = self.build_frame(HostMsgFormatTemplate_ndx=HostMsgFormatTemplate_ndx, Value=Value)
        self.process_frame(frame)
class Protocols_HttpsClient(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x28
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'(')
        self.process_frame(_send_buffer.getvalue())
class Protocols_HttpsClient_AuthUrl(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x28
    ValueKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 2
    def reset(self, AuthUrl_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'(')
        if AuthUrl_ndx < 0 or AuthUrl_ndx >= 2:
            raise IndexError(AuthUrl_ndx)
        _send_buffer.write((1 + AuthUrl_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Url_bytes = _recv_buffer.read(-1)
        _Url = _Url_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Url
    def get(self, AuthUrl_ndx: int, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'(')
        if AuthUrl_ndx < 0 or AuthUrl_ndx >= 2:
            raise IndexError(AuthUrl_ndx)
        _send_buffer.write((1 + AuthUrl_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, AuthUrl_ndx: int, Url: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'(')
        if AuthUrl_ndx < 0 or AuthUrl_ndx >= 2:
            raise IndexError(AuthUrl_ndx)
        _send_buffer.write((1 + AuthUrl_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(Url.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, AuthUrl_ndx: int, Url: str) -> None:
        frame = self.build_frame(AuthUrl_ndx=AuthUrl_ndx, Url=Url)
        self.process_frame(frame)
class Protocols_HttpsClient_ReaderUpdateUrl(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x28
    ValueKey: ClassVar[int] = 0x03
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'(')
        _send_buffer.write(b'\x03')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Url_bytes = _recv_buffer.read(-1)
        _Url = _Url_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Url
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'(')
        _send_buffer.write(b'\x03')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Url: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'(')
        _send_buffer.write(b'\x03')
        _send_buffer.write(Url.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Url: str) -> None:
        frame = self.build_frame(Url=Url)
        self.process_frame(frame)
class Protocols_HttpsClient_IfconverterUpdateUrl(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x28
    ValueKey: ClassVar[int] = 0x04
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'(')
        _send_buffer.write(b'\x04')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Url_bytes = _recv_buffer.read(-1)
        _Url = _Url_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Url
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'(')
        _send_buffer.write(b'\x04')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Url: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'(')
        _send_buffer.write(b'\x04')
        _send_buffer.write(Url.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Url: str) -> None:
        frame = self.build_frame(Url=Url)
        self.process_frame(frame)
class Protocols_HttpsClient_UpdateTime(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x28
    ValueKey: ClassVar[int] = 0x06
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'(')
        _send_buffer.write(b'\x06')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _SecondsSinceMidnight = safe_read_int_from_buffer(_recv_buffer, 4)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _SecondsSinceMidnight
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'(')
        _send_buffer.write(b'\x06')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, SecondsSinceMidnight: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'(')
        _send_buffer.write(b'\x06')
        _send_buffer.write(SecondsSinceMidnight.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, SecondsSinceMidnight: int) -> None:
        frame = self.build_frame(SecondsSinceMidnight=SecondsSinceMidnight)
        self.process_frame(frame)
class Protocols_HttpsClient_UpdateTimeSpread(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x28
    ValueKey: ClassVar[int] = 0x07
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'(')
        _send_buffer.write(b'\x07')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _MaxSeconds = safe_read_int_from_buffer(_recv_buffer, 4)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _MaxSeconds
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'(')
        _send_buffer.write(b'\x07')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, MaxSeconds: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'(')
        _send_buffer.write(b'\x07')
        _send_buffer.write(MaxSeconds.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, MaxSeconds: int) -> None:
        frame = self.build_frame(MaxSeconds=MaxSeconds)
        self.process_frame(frame)
class Protocols_HttpsClient_InitialEncryptedAuthToken(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x28
    ValueKey: ClassVar[int] = 0x08
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'(')
        _send_buffer.write(b'\x08')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> bytes:
        _recv_buffer = BytesIO(frame)
        _Token = _recv_buffer.read(-1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Token
    def get(self, default: Optional[bytes] = None) -> Optional[bytes]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'(')
        _send_buffer.write(b'\x08')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Token: bytes) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'(')
        _send_buffer.write(b'\x08')
        _send_buffer.write(Token)
        return _send_buffer.getvalue()
    def __call__(self, Token: bytes) -> None:
        frame = self.build_frame(Token=Token)
        self.process_frame(frame)
class Protocols_HttpsClient_RootCertServer(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x28
    ValueKey: ClassVar[int] = 0x20
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 50
    def reset(self, RootCertServer_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'(')
        if RootCertServer_ndx < 0 or RootCertServer_ndx >= 50:
            raise IndexError(RootCertServer_ndx)
        _send_buffer.write((32 + RootCertServer_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> bytes:
        _recv_buffer = BytesIO(frame)
        _CertPart = _recv_buffer.read(-1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _CertPart
    def get(self, RootCertServer_ndx: int, default: Optional[bytes] = None) -> Optional[bytes]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'(')
        if RootCertServer_ndx < 0 or RootCertServer_ndx >= 50:
            raise IndexError(RootCertServer_ndx)
        _send_buffer.write((32 + RootCertServer_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, RootCertServer_ndx: int, CertPart: bytes) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'(')
        if RootCertServer_ndx < 0 or RootCertServer_ndx >= 50:
            raise IndexError(RootCertServer_ndx)
        _send_buffer.write((32 + RootCertServer_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(CertPart)
        return _send_buffer.getvalue()
    def __call__(self, RootCertServer_ndx: int, CertPart: bytes) -> None:
        frame = self.build_frame(RootCertServer_ndx=RootCertServer_ndx, CertPart=CertPart)
        self.process_frame(frame)
class Protocols_AccessConditionBitsStd(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x60
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'`')
        self.process_frame(_send_buffer.getvalue())
class Protocols_AccessConditionBitsStd_BrpOverSerial(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x60
    ValueKey: ClassVar[int] = 0x03
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'`')
        _send_buffer.write(b'\x03')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> HostSecurityAccessConditionBits:
        _recv_buffer = BytesIO(frame)
        _Value_int = safe_read_int_from_buffer(_recv_buffer, 4)
        _HostToHostAccess = bool((_Value_int >> 28) & 0b1)
        _AutoreadAccess = bool((_Value_int >> 27) & 0b1)
        _CryptoAccess = bool((_Value_int >> 26) & 0b1)
        _Bf2Upload = bool((_Value_int >> 25) & 0b1)
        _ExtendedAccess = bool((_Value_int >> 24) & 0b1)
        _FlashFileSystemWrite = bool((_Value_int >> 23) & 0b1)
        _FlashFileSystemRead = bool((_Value_int >> 22) & 0b1)
        _RtcWrite = bool((_Value_int >> 21) & 0b1)
        _VhlExchangeapdu = bool((_Value_int >> 20) & 0b1)
        _VhlFormat = bool((_Value_int >> 19) & 0b1)
        _VhlWrite = bool((_Value_int >> 18) & 0b1)
        _VhlRead = bool((_Value_int >> 17) & 0b1)
        _VhlSelect = bool((_Value_int >> 16) & 0b1)
        _ExtSamAccess = bool((_Value_int >> 15) & 0b1)
        _HfLowlevelAccess = bool((_Value_int >> 14) & 0b1)
        _GuiAccess = bool((_Value_int >> 13) & 0b1)
        _IoPortWrite = bool((_Value_int >> 12) & 0b1)
        _IoPortRead = bool((_Value_int >> 11) & 0b1)
        _ConfigReset = bool((_Value_int >> 10) & 0b1)
        _ConfigWrite = bool((_Value_int >> 9) & 0b1)
        _ConfigRead = bool((_Value_int >> 8) & 0b1)
        _SysReset = bool((_Value_int >> 7) & 0b1)
        _SetAccessConditionMask2 = bool((_Value_int >> 6) & 0b1)
        _SetAccessConditionMask1 = bool((_Value_int >> 5) & 0b1)
        _SetAccessConditionMask0 = bool((_Value_int >> 4) & 0b1)
        _SetKey3 = bool((_Value_int >> 3) & 0b1)
        _SetKey2 = bool((_Value_int >> 2) & 0b1)
        _SetKey1 = bool((_Value_int >> 1) & 0b1)
        _FactoryReset = bool((_Value_int >> 0) & 0b1)
        _Value = HostSecurityAccessConditionBits(_HostToHostAccess, _AutoreadAccess, _CryptoAccess, _Bf2Upload, _ExtendedAccess, _FlashFileSystemWrite, _FlashFileSystemRead, _RtcWrite, _VhlExchangeapdu, _VhlFormat, _VhlWrite, _VhlRead, _VhlSelect, _ExtSamAccess, _HfLowlevelAccess, _GuiAccess, _IoPortWrite, _IoPortRead, _ConfigReset, _ConfigWrite, _ConfigRead, _SysReset, _SetAccessConditionMask2, _SetAccessConditionMask1, _SetAccessConditionMask0, _SetKey3, _SetKey2, _SetKey1, _FactoryReset)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[HostSecurityAccessConditionBits] = None) -> Optional[HostSecurityAccessConditionBits]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'`')
        _send_buffer.write(b'\x03')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[HostSecurityAccessConditionBits, HostSecurityAccessConditionBits_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'`')
        _send_buffer.write(b'\x03')
        if isinstance(Value, dict):
            Value = HostSecurityAccessConditionBits(**Value)
        Value_int = 0
        Value_int |= (int(Value.HostToHostAccess) & 0b1) << 28
        Value_int |= (int(Value.AutoreadAccess) & 0b1) << 27
        Value_int |= (int(Value.CryptoAccess) & 0b1) << 26
        Value_int |= (int(Value.Bf2Upload) & 0b1) << 25
        Value_int |= (int(Value.ExtendedAccess) & 0b1) << 24
        Value_int |= (int(Value.FlashFileSystemWrite) & 0b1) << 23
        Value_int |= (int(Value.FlashFileSystemRead) & 0b1) << 22
        Value_int |= (int(Value.RtcWrite) & 0b1) << 21
        Value_int |= (int(Value.VhlExchangeapdu) & 0b1) << 20
        Value_int |= (int(Value.VhlFormat) & 0b1) << 19
        Value_int |= (int(Value.VhlWrite) & 0b1) << 18
        Value_int |= (int(Value.VhlRead) & 0b1) << 17
        Value_int |= (int(Value.VhlSelect) & 0b1) << 16
        Value_int |= (int(Value.ExtSamAccess) & 0b1) << 15
        Value_int |= (int(Value.HfLowlevelAccess) & 0b1) << 14
        Value_int |= (int(Value.GuiAccess) & 0b1) << 13
        Value_int |= (int(Value.IoPortWrite) & 0b1) << 12
        Value_int |= (int(Value.IoPortRead) & 0b1) << 11
        Value_int |= (int(Value.ConfigReset) & 0b1) << 10
        Value_int |= (int(Value.ConfigWrite) & 0b1) << 9
        Value_int |= (int(Value.ConfigRead) & 0b1) << 8
        Value_int |= (int(Value.SysReset) & 0b1) << 7
        Value_int |= (int(Value.SetAccessConditionMask2) & 0b1) << 6
        Value_int |= (int(Value.SetAccessConditionMask1) & 0b1) << 5
        Value_int |= (int(Value.SetAccessConditionMask0) & 0b1) << 4
        Value_int |= (int(Value.SetKey3) & 0b1) << 3
        Value_int |= (int(Value.SetKey2) & 0b1) << 2
        Value_int |= (int(Value.SetKey1) & 0b1) << 1
        Value_int |= (int(Value.FactoryReset) & 0b1) << 0
        _send_buffer.write(Value_int.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[HostSecurityAccessConditionBits, HostSecurityAccessConditionBits_Dict]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_AccessConditionBitsStd_BrpOverHid(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x60
    ValueKey: ClassVar[int] = 0x05
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'`')
        _send_buffer.write(b'\x05')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> HostSecurityAccessConditionBits:
        _recv_buffer = BytesIO(frame)
        _Value_int = safe_read_int_from_buffer(_recv_buffer, 4)
        _HostToHostAccess = bool((_Value_int >> 28) & 0b1)
        _AutoreadAccess = bool((_Value_int >> 27) & 0b1)
        _CryptoAccess = bool((_Value_int >> 26) & 0b1)
        _Bf2Upload = bool((_Value_int >> 25) & 0b1)
        _ExtendedAccess = bool((_Value_int >> 24) & 0b1)
        _FlashFileSystemWrite = bool((_Value_int >> 23) & 0b1)
        _FlashFileSystemRead = bool((_Value_int >> 22) & 0b1)
        _RtcWrite = bool((_Value_int >> 21) & 0b1)
        _VhlExchangeapdu = bool((_Value_int >> 20) & 0b1)
        _VhlFormat = bool((_Value_int >> 19) & 0b1)
        _VhlWrite = bool((_Value_int >> 18) & 0b1)
        _VhlRead = bool((_Value_int >> 17) & 0b1)
        _VhlSelect = bool((_Value_int >> 16) & 0b1)
        _ExtSamAccess = bool((_Value_int >> 15) & 0b1)
        _HfLowlevelAccess = bool((_Value_int >> 14) & 0b1)
        _GuiAccess = bool((_Value_int >> 13) & 0b1)
        _IoPortWrite = bool((_Value_int >> 12) & 0b1)
        _IoPortRead = bool((_Value_int >> 11) & 0b1)
        _ConfigReset = bool((_Value_int >> 10) & 0b1)
        _ConfigWrite = bool((_Value_int >> 9) & 0b1)
        _ConfigRead = bool((_Value_int >> 8) & 0b1)
        _SysReset = bool((_Value_int >> 7) & 0b1)
        _SetAccessConditionMask2 = bool((_Value_int >> 6) & 0b1)
        _SetAccessConditionMask1 = bool((_Value_int >> 5) & 0b1)
        _SetAccessConditionMask0 = bool((_Value_int >> 4) & 0b1)
        _SetKey3 = bool((_Value_int >> 3) & 0b1)
        _SetKey2 = bool((_Value_int >> 2) & 0b1)
        _SetKey1 = bool((_Value_int >> 1) & 0b1)
        _FactoryReset = bool((_Value_int >> 0) & 0b1)
        _Value = HostSecurityAccessConditionBits(_HostToHostAccess, _AutoreadAccess, _CryptoAccess, _Bf2Upload, _ExtendedAccess, _FlashFileSystemWrite, _FlashFileSystemRead, _RtcWrite, _VhlExchangeapdu, _VhlFormat, _VhlWrite, _VhlRead, _VhlSelect, _ExtSamAccess, _HfLowlevelAccess, _GuiAccess, _IoPortWrite, _IoPortRead, _ConfigReset, _ConfigWrite, _ConfigRead, _SysReset, _SetAccessConditionMask2, _SetAccessConditionMask1, _SetAccessConditionMask0, _SetKey3, _SetKey2, _SetKey1, _FactoryReset)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[HostSecurityAccessConditionBits] = None) -> Optional[HostSecurityAccessConditionBits]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'`')
        _send_buffer.write(b'\x05')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[HostSecurityAccessConditionBits, HostSecurityAccessConditionBits_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'`')
        _send_buffer.write(b'\x05')
        if isinstance(Value, dict):
            Value = HostSecurityAccessConditionBits(**Value)
        Value_int = 0
        Value_int |= (int(Value.HostToHostAccess) & 0b1) << 28
        Value_int |= (int(Value.AutoreadAccess) & 0b1) << 27
        Value_int |= (int(Value.CryptoAccess) & 0b1) << 26
        Value_int |= (int(Value.Bf2Upload) & 0b1) << 25
        Value_int |= (int(Value.ExtendedAccess) & 0b1) << 24
        Value_int |= (int(Value.FlashFileSystemWrite) & 0b1) << 23
        Value_int |= (int(Value.FlashFileSystemRead) & 0b1) << 22
        Value_int |= (int(Value.RtcWrite) & 0b1) << 21
        Value_int |= (int(Value.VhlExchangeapdu) & 0b1) << 20
        Value_int |= (int(Value.VhlFormat) & 0b1) << 19
        Value_int |= (int(Value.VhlWrite) & 0b1) << 18
        Value_int |= (int(Value.VhlRead) & 0b1) << 17
        Value_int |= (int(Value.VhlSelect) & 0b1) << 16
        Value_int |= (int(Value.ExtSamAccess) & 0b1) << 15
        Value_int |= (int(Value.HfLowlevelAccess) & 0b1) << 14
        Value_int |= (int(Value.GuiAccess) & 0b1) << 13
        Value_int |= (int(Value.IoPortWrite) & 0b1) << 12
        Value_int |= (int(Value.IoPortRead) & 0b1) << 11
        Value_int |= (int(Value.ConfigReset) & 0b1) << 10
        Value_int |= (int(Value.ConfigWrite) & 0b1) << 9
        Value_int |= (int(Value.ConfigRead) & 0b1) << 8
        Value_int |= (int(Value.SysReset) & 0b1) << 7
        Value_int |= (int(Value.SetAccessConditionMask2) & 0b1) << 6
        Value_int |= (int(Value.SetAccessConditionMask1) & 0b1) << 5
        Value_int |= (int(Value.SetAccessConditionMask0) & 0b1) << 4
        Value_int |= (int(Value.SetKey3) & 0b1) << 3
        Value_int |= (int(Value.SetKey2) & 0b1) << 2
        Value_int |= (int(Value.SetKey1) & 0b1) << 1
        Value_int |= (int(Value.FactoryReset) & 0b1) << 0
        _send_buffer.write(Value_int.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[HostSecurityAccessConditionBits, HostSecurityAccessConditionBits_Dict]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_AccessConditionBitsStd_BrpOverOsdp(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x60
    ValueKey: ClassVar[int] = 0x38
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'`')
        _send_buffer.write(b'8')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> HostSecurityAccessConditionBits:
        _recv_buffer = BytesIO(frame)
        _Value_int = safe_read_int_from_buffer(_recv_buffer, 4)
        _HostToHostAccess = bool((_Value_int >> 28) & 0b1)
        _AutoreadAccess = bool((_Value_int >> 27) & 0b1)
        _CryptoAccess = bool((_Value_int >> 26) & 0b1)
        _Bf2Upload = bool((_Value_int >> 25) & 0b1)
        _ExtendedAccess = bool((_Value_int >> 24) & 0b1)
        _FlashFileSystemWrite = bool((_Value_int >> 23) & 0b1)
        _FlashFileSystemRead = bool((_Value_int >> 22) & 0b1)
        _RtcWrite = bool((_Value_int >> 21) & 0b1)
        _VhlExchangeapdu = bool((_Value_int >> 20) & 0b1)
        _VhlFormat = bool((_Value_int >> 19) & 0b1)
        _VhlWrite = bool((_Value_int >> 18) & 0b1)
        _VhlRead = bool((_Value_int >> 17) & 0b1)
        _VhlSelect = bool((_Value_int >> 16) & 0b1)
        _ExtSamAccess = bool((_Value_int >> 15) & 0b1)
        _HfLowlevelAccess = bool((_Value_int >> 14) & 0b1)
        _GuiAccess = bool((_Value_int >> 13) & 0b1)
        _IoPortWrite = bool((_Value_int >> 12) & 0b1)
        _IoPortRead = bool((_Value_int >> 11) & 0b1)
        _ConfigReset = bool((_Value_int >> 10) & 0b1)
        _ConfigWrite = bool((_Value_int >> 9) & 0b1)
        _ConfigRead = bool((_Value_int >> 8) & 0b1)
        _SysReset = bool((_Value_int >> 7) & 0b1)
        _SetAccessConditionMask2 = bool((_Value_int >> 6) & 0b1)
        _SetAccessConditionMask1 = bool((_Value_int >> 5) & 0b1)
        _SetAccessConditionMask0 = bool((_Value_int >> 4) & 0b1)
        _SetKey3 = bool((_Value_int >> 3) & 0b1)
        _SetKey2 = bool((_Value_int >> 2) & 0b1)
        _SetKey1 = bool((_Value_int >> 1) & 0b1)
        _FactoryReset = bool((_Value_int >> 0) & 0b1)
        _Value = HostSecurityAccessConditionBits(_HostToHostAccess, _AutoreadAccess, _CryptoAccess, _Bf2Upload, _ExtendedAccess, _FlashFileSystemWrite, _FlashFileSystemRead, _RtcWrite, _VhlExchangeapdu, _VhlFormat, _VhlWrite, _VhlRead, _VhlSelect, _ExtSamAccess, _HfLowlevelAccess, _GuiAccess, _IoPortWrite, _IoPortRead, _ConfigReset, _ConfigWrite, _ConfigRead, _SysReset, _SetAccessConditionMask2, _SetAccessConditionMask1, _SetAccessConditionMask0, _SetKey3, _SetKey2, _SetKey1, _FactoryReset)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[HostSecurityAccessConditionBits] = None) -> Optional[HostSecurityAccessConditionBits]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'`')
        _send_buffer.write(b'8')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[HostSecurityAccessConditionBits, HostSecurityAccessConditionBits_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'`')
        _send_buffer.write(b'8')
        if isinstance(Value, dict):
            Value = HostSecurityAccessConditionBits(**Value)
        Value_int = 0
        Value_int |= (int(Value.HostToHostAccess) & 0b1) << 28
        Value_int |= (int(Value.AutoreadAccess) & 0b1) << 27
        Value_int |= (int(Value.CryptoAccess) & 0b1) << 26
        Value_int |= (int(Value.Bf2Upload) & 0b1) << 25
        Value_int |= (int(Value.ExtendedAccess) & 0b1) << 24
        Value_int |= (int(Value.FlashFileSystemWrite) & 0b1) << 23
        Value_int |= (int(Value.FlashFileSystemRead) & 0b1) << 22
        Value_int |= (int(Value.RtcWrite) & 0b1) << 21
        Value_int |= (int(Value.VhlExchangeapdu) & 0b1) << 20
        Value_int |= (int(Value.VhlFormat) & 0b1) << 19
        Value_int |= (int(Value.VhlWrite) & 0b1) << 18
        Value_int |= (int(Value.VhlRead) & 0b1) << 17
        Value_int |= (int(Value.VhlSelect) & 0b1) << 16
        Value_int |= (int(Value.ExtSamAccess) & 0b1) << 15
        Value_int |= (int(Value.HfLowlevelAccess) & 0b1) << 14
        Value_int |= (int(Value.GuiAccess) & 0b1) << 13
        Value_int |= (int(Value.IoPortWrite) & 0b1) << 12
        Value_int |= (int(Value.IoPortRead) & 0b1) << 11
        Value_int |= (int(Value.ConfigReset) & 0b1) << 10
        Value_int |= (int(Value.ConfigWrite) & 0b1) << 9
        Value_int |= (int(Value.ConfigRead) & 0b1) << 8
        Value_int |= (int(Value.SysReset) & 0b1) << 7
        Value_int |= (int(Value.SetAccessConditionMask2) & 0b1) << 6
        Value_int |= (int(Value.SetAccessConditionMask1) & 0b1) << 5
        Value_int |= (int(Value.SetAccessConditionMask0) & 0b1) << 4
        Value_int |= (int(Value.SetKey3) & 0b1) << 3
        Value_int |= (int(Value.SetKey2) & 0b1) << 2
        Value_int |= (int(Value.SetKey1) & 0b1) << 1
        Value_int |= (int(Value.FactoryReset) & 0b1) << 0
        _send_buffer.write(Value_int.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[HostSecurityAccessConditionBits, HostSecurityAccessConditionBits_Dict]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_AccessConditionBitsStd_Ccid(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x60
    ValueKey: ClassVar[int] = 0x36
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'`')
        _send_buffer.write(b'6')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> HostSecurityAccessConditionBits:
        _recv_buffer = BytesIO(frame)
        _Value_int = safe_read_int_from_buffer(_recv_buffer, 4)
        _HostToHostAccess = bool((_Value_int >> 28) & 0b1)
        _AutoreadAccess = bool((_Value_int >> 27) & 0b1)
        _CryptoAccess = bool((_Value_int >> 26) & 0b1)
        _Bf2Upload = bool((_Value_int >> 25) & 0b1)
        _ExtendedAccess = bool((_Value_int >> 24) & 0b1)
        _FlashFileSystemWrite = bool((_Value_int >> 23) & 0b1)
        _FlashFileSystemRead = bool((_Value_int >> 22) & 0b1)
        _RtcWrite = bool((_Value_int >> 21) & 0b1)
        _VhlExchangeapdu = bool((_Value_int >> 20) & 0b1)
        _VhlFormat = bool((_Value_int >> 19) & 0b1)
        _VhlWrite = bool((_Value_int >> 18) & 0b1)
        _VhlRead = bool((_Value_int >> 17) & 0b1)
        _VhlSelect = bool((_Value_int >> 16) & 0b1)
        _ExtSamAccess = bool((_Value_int >> 15) & 0b1)
        _HfLowlevelAccess = bool((_Value_int >> 14) & 0b1)
        _GuiAccess = bool((_Value_int >> 13) & 0b1)
        _IoPortWrite = bool((_Value_int >> 12) & 0b1)
        _IoPortRead = bool((_Value_int >> 11) & 0b1)
        _ConfigReset = bool((_Value_int >> 10) & 0b1)
        _ConfigWrite = bool((_Value_int >> 9) & 0b1)
        _ConfigRead = bool((_Value_int >> 8) & 0b1)
        _SysReset = bool((_Value_int >> 7) & 0b1)
        _SetAccessConditionMask2 = bool((_Value_int >> 6) & 0b1)
        _SetAccessConditionMask1 = bool((_Value_int >> 5) & 0b1)
        _SetAccessConditionMask0 = bool((_Value_int >> 4) & 0b1)
        _SetKey3 = bool((_Value_int >> 3) & 0b1)
        _SetKey2 = bool((_Value_int >> 2) & 0b1)
        _SetKey1 = bool((_Value_int >> 1) & 0b1)
        _FactoryReset = bool((_Value_int >> 0) & 0b1)
        _Value = HostSecurityAccessConditionBits(_HostToHostAccess, _AutoreadAccess, _CryptoAccess, _Bf2Upload, _ExtendedAccess, _FlashFileSystemWrite, _FlashFileSystemRead, _RtcWrite, _VhlExchangeapdu, _VhlFormat, _VhlWrite, _VhlRead, _VhlSelect, _ExtSamAccess, _HfLowlevelAccess, _GuiAccess, _IoPortWrite, _IoPortRead, _ConfigReset, _ConfigWrite, _ConfigRead, _SysReset, _SetAccessConditionMask2, _SetAccessConditionMask1, _SetAccessConditionMask0, _SetKey3, _SetKey2, _SetKey1, _FactoryReset)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[HostSecurityAccessConditionBits] = None) -> Optional[HostSecurityAccessConditionBits]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'`')
        _send_buffer.write(b'6')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[HostSecurityAccessConditionBits, HostSecurityAccessConditionBits_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'`')
        _send_buffer.write(b'6')
        if isinstance(Value, dict):
            Value = HostSecurityAccessConditionBits(**Value)
        Value_int = 0
        Value_int |= (int(Value.HostToHostAccess) & 0b1) << 28
        Value_int |= (int(Value.AutoreadAccess) & 0b1) << 27
        Value_int |= (int(Value.CryptoAccess) & 0b1) << 26
        Value_int |= (int(Value.Bf2Upload) & 0b1) << 25
        Value_int |= (int(Value.ExtendedAccess) & 0b1) << 24
        Value_int |= (int(Value.FlashFileSystemWrite) & 0b1) << 23
        Value_int |= (int(Value.FlashFileSystemRead) & 0b1) << 22
        Value_int |= (int(Value.RtcWrite) & 0b1) << 21
        Value_int |= (int(Value.VhlExchangeapdu) & 0b1) << 20
        Value_int |= (int(Value.VhlFormat) & 0b1) << 19
        Value_int |= (int(Value.VhlWrite) & 0b1) << 18
        Value_int |= (int(Value.VhlRead) & 0b1) << 17
        Value_int |= (int(Value.VhlSelect) & 0b1) << 16
        Value_int |= (int(Value.ExtSamAccess) & 0b1) << 15
        Value_int |= (int(Value.HfLowlevelAccess) & 0b1) << 14
        Value_int |= (int(Value.GuiAccess) & 0b1) << 13
        Value_int |= (int(Value.IoPortWrite) & 0b1) << 12
        Value_int |= (int(Value.IoPortRead) & 0b1) << 11
        Value_int |= (int(Value.ConfigReset) & 0b1) << 10
        Value_int |= (int(Value.ConfigWrite) & 0b1) << 9
        Value_int |= (int(Value.ConfigRead) & 0b1) << 8
        Value_int |= (int(Value.SysReset) & 0b1) << 7
        Value_int |= (int(Value.SetAccessConditionMask2) & 0b1) << 6
        Value_int |= (int(Value.SetAccessConditionMask1) & 0b1) << 5
        Value_int |= (int(Value.SetAccessConditionMask0) & 0b1) << 4
        Value_int |= (int(Value.SetKey3) & 0b1) << 3
        Value_int |= (int(Value.SetKey2) & 0b1) << 2
        Value_int |= (int(Value.SetKey1) & 0b1) << 1
        Value_int |= (int(Value.FactoryReset) & 0b1) << 0
        _send_buffer.write(Value_int.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[HostSecurityAccessConditionBits, HostSecurityAccessConditionBits_Dict]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_AccessConditionBitsAlt(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x61
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'a')
        self.process_frame(_send_buffer.getvalue())
class Protocols_AccessConditionBitsAlt_BrpOverOsdpLimited(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x61
    ValueKey: ClassVar[int] = 0x38
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'a')
        _send_buffer.write(b'8')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> HostSecurityAccessConditionBits:
        _recv_buffer = BytesIO(frame)
        _Value_int = safe_read_int_from_buffer(_recv_buffer, 4)
        _HostToHostAccess = bool((_Value_int >> 28) & 0b1)
        _AutoreadAccess = bool((_Value_int >> 27) & 0b1)
        _CryptoAccess = bool((_Value_int >> 26) & 0b1)
        _Bf2Upload = bool((_Value_int >> 25) & 0b1)
        _ExtendedAccess = bool((_Value_int >> 24) & 0b1)
        _FlashFileSystemWrite = bool((_Value_int >> 23) & 0b1)
        _FlashFileSystemRead = bool((_Value_int >> 22) & 0b1)
        _RtcWrite = bool((_Value_int >> 21) & 0b1)
        _VhlExchangeapdu = bool((_Value_int >> 20) & 0b1)
        _VhlFormat = bool((_Value_int >> 19) & 0b1)
        _VhlWrite = bool((_Value_int >> 18) & 0b1)
        _VhlRead = bool((_Value_int >> 17) & 0b1)
        _VhlSelect = bool((_Value_int >> 16) & 0b1)
        _ExtSamAccess = bool((_Value_int >> 15) & 0b1)
        _HfLowlevelAccess = bool((_Value_int >> 14) & 0b1)
        _GuiAccess = bool((_Value_int >> 13) & 0b1)
        _IoPortWrite = bool((_Value_int >> 12) & 0b1)
        _IoPortRead = bool((_Value_int >> 11) & 0b1)
        _ConfigReset = bool((_Value_int >> 10) & 0b1)
        _ConfigWrite = bool((_Value_int >> 9) & 0b1)
        _ConfigRead = bool((_Value_int >> 8) & 0b1)
        _SysReset = bool((_Value_int >> 7) & 0b1)
        _SetAccessConditionMask2 = bool((_Value_int >> 6) & 0b1)
        _SetAccessConditionMask1 = bool((_Value_int >> 5) & 0b1)
        _SetAccessConditionMask0 = bool((_Value_int >> 4) & 0b1)
        _SetKey3 = bool((_Value_int >> 3) & 0b1)
        _SetKey2 = bool((_Value_int >> 2) & 0b1)
        _SetKey1 = bool((_Value_int >> 1) & 0b1)
        _FactoryReset = bool((_Value_int >> 0) & 0b1)
        _Value = HostSecurityAccessConditionBits(_HostToHostAccess, _AutoreadAccess, _CryptoAccess, _Bf2Upload, _ExtendedAccess, _FlashFileSystemWrite, _FlashFileSystemRead, _RtcWrite, _VhlExchangeapdu, _VhlFormat, _VhlWrite, _VhlRead, _VhlSelect, _ExtSamAccess, _HfLowlevelAccess, _GuiAccess, _IoPortWrite, _IoPortRead, _ConfigReset, _ConfigWrite, _ConfigRead, _SysReset, _SetAccessConditionMask2, _SetAccessConditionMask1, _SetAccessConditionMask0, _SetKey3, _SetKey2, _SetKey1, _FactoryReset)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[HostSecurityAccessConditionBits] = None) -> Optional[HostSecurityAccessConditionBits]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'a')
        _send_buffer.write(b'8')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[HostSecurityAccessConditionBits, HostSecurityAccessConditionBits_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'a')
        _send_buffer.write(b'8')
        if isinstance(Value, dict):
            Value = HostSecurityAccessConditionBits(**Value)
        Value_int = 0
        Value_int |= (int(Value.HostToHostAccess) & 0b1) << 28
        Value_int |= (int(Value.AutoreadAccess) & 0b1) << 27
        Value_int |= (int(Value.CryptoAccess) & 0b1) << 26
        Value_int |= (int(Value.Bf2Upload) & 0b1) << 25
        Value_int |= (int(Value.ExtendedAccess) & 0b1) << 24
        Value_int |= (int(Value.FlashFileSystemWrite) & 0b1) << 23
        Value_int |= (int(Value.FlashFileSystemRead) & 0b1) << 22
        Value_int |= (int(Value.RtcWrite) & 0b1) << 21
        Value_int |= (int(Value.VhlExchangeapdu) & 0b1) << 20
        Value_int |= (int(Value.VhlFormat) & 0b1) << 19
        Value_int |= (int(Value.VhlWrite) & 0b1) << 18
        Value_int |= (int(Value.VhlRead) & 0b1) << 17
        Value_int |= (int(Value.VhlSelect) & 0b1) << 16
        Value_int |= (int(Value.ExtSamAccess) & 0b1) << 15
        Value_int |= (int(Value.HfLowlevelAccess) & 0b1) << 14
        Value_int |= (int(Value.GuiAccess) & 0b1) << 13
        Value_int |= (int(Value.IoPortWrite) & 0b1) << 12
        Value_int |= (int(Value.IoPortRead) & 0b1) << 11
        Value_int |= (int(Value.ConfigReset) & 0b1) << 10
        Value_int |= (int(Value.ConfigWrite) & 0b1) << 9
        Value_int |= (int(Value.ConfigRead) & 0b1) << 8
        Value_int |= (int(Value.SysReset) & 0b1) << 7
        Value_int |= (int(Value.SetAccessConditionMask2) & 0b1) << 6
        Value_int |= (int(Value.SetAccessConditionMask1) & 0b1) << 5
        Value_int |= (int(Value.SetAccessConditionMask0) & 0b1) << 4
        Value_int |= (int(Value.SetKey3) & 0b1) << 3
        Value_int |= (int(Value.SetKey2) & 0b1) << 2
        Value_int |= (int(Value.SetKey1) & 0b1) << 1
        Value_int |= (int(Value.FactoryReset) & 0b1) << 0
        _send_buffer.write(Value_int.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[HostSecurityAccessConditionBits, HostSecurityAccessConditionBits_Dict]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class VhlCfg(ConfigBase):
    MasterKey: ClassVar[int] = 0x03
    MasterKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        self.process_frame(_send_buffer.getvalue())
class VhlCfg_File(ConfigBase):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
class VhlCfg_File_AreaList125(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x52
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'R')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[VhlCfg_File_AreaList125_Value_Entry]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _PageAddress = safe_read_int_from_buffer(_recv_buffer, 1)
            _PageNr = safe_read_int_from_buffer(_recv_buffer, 1)
            _Value_Entry = VhlCfg_File_AreaList125_Value_Entry(_PageAddress, _PageNr)
            _Value.append(_Value_Entry)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[VhlCfg_File_AreaList125_Value_Entry]] = None) -> Optional[List[VhlCfg_File_AreaList125_Value_Entry]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'R')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[VhlCfg_File_AreaList125_Value_Entry]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'R')
        for _Value_Entry in Value:
            _PageAddress, _PageNr = _Value_Entry
            _send_buffer.write(_PageAddress.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_PageNr.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[VhlCfg_File_AreaList125_Value_Entry]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_Secret125(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0xBA
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\xba')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Secret_bytes = _recv_buffer.read(-1)
        _Secret = _Secret_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Secret
    def get(self, File_ndx: int, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\xba')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Secret: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\xba')
        _send_buffer.write(Secret.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Secret: str) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Secret=Secret)
        self.process_frame(frame)
class VhlCfg_File_DesfireAid(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x38
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'8')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 4)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'8')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'8')
        _send_buffer.write(Value.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: int) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_DesfireKeyList(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0xB9
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\xb9')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[VhlCfg_File_DesfireKeyList_Value_Entry]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _KeySettings_int = safe_read_int_from_buffer(_recv_buffer, 1)
            _IsVersion = bool((_KeySettings_int >> 7) & 0b1)
            _IsDivInfo = bool((_KeySettings_int >> 6) & 0b1)
            _IsDivInfoVhl = bool((_KeySettings_int >> 5) & 0b1)
            _DenyFormat = bool((_KeySettings_int >> 2) & 0b1)
            _DenyWrite = bool((_KeySettings_int >> 1) & 0b1)
            _DenyRead = bool((_KeySettings_int >> 0) & 0b1)
            _KeySettings = KeyAccessRights_KeySettings(_IsVersion, _IsDivInfo, _IsDivInfoVhl, _DenyFormat, _DenyWrite, _DenyRead)
            if _IsVersion:
                _Version = safe_read_int_from_buffer(_recv_buffer, 1)
            else:
                _Version = None
            if _IsDivInfo:
                _DiversificationMode = KeyAccessRights_DiversificationMode_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
                _DivIdx = safe_read_int_from_buffer(_recv_buffer, 1)
            else:
                _DiversificationMode = None
                _DivIdx = None
            _AccessRights = KeyAccessRights(_KeySettings, _Version, _DiversificationMode, _DivIdx)
            _Algorithm = CryptoAlgorithm_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
            if _Algorithm == "DES":
                _DesKey = _recv_buffer.read(8)
                if len(_DesKey) != 8:
                    raise PayloadTooShortError(8 - len(_DesKey))
            else:
                _DesKey = None
            if _Algorithm == "ThreeKeyTripleDES":
                _ThreeKeyTripleDESKey = _recv_buffer.read(24)
                if len(_ThreeKeyTripleDESKey) != 24:
                    raise PayloadTooShortError(24 - len(_ThreeKeyTripleDESKey))
            else:
                _ThreeKeyTripleDESKey = None
            if _Algorithm == "TripleDES" or _Algorithm == "AES":
                _TripleDesAesKey = _recv_buffer.read(16)
                if len(_TripleDesAesKey) != 16:
                    raise PayloadTooShortError(16 - len(_TripleDesAesKey))
            else:
                _TripleDesAesKey = None
            if _Algorithm == "MifareClassic":
                _MifareClassicKey = _recv_buffer.read(6)
                if len(_MifareClassicKey) != 6:
                    raise PayloadTooShortError(6 - len(_MifareClassicKey))
            else:
                _MifareClassicKey = None
            _Value_Entry = VhlCfg_File_DesfireKeyList_Value_Entry(_AccessRights, _Algorithm, _DesKey, _ThreeKeyTripleDESKey, _TripleDesAesKey, _MifareClassicKey)
            _Value.append(_Value_Entry)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[VhlCfg_File_DesfireKeyList_Value_Entry]] = None) -> Optional[List[VhlCfg_File_DesfireKeyList_Value_Entry]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\xb9')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[VhlCfg_File_DesfireKeyList_Value_Entry]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\xb9')
        for _Value_Entry in Value:
            _AccessRights, _Algorithm, _DesKey, _ThreeKeyTripleDESKey, _TripleDesAesKey, _MifareClassicKey = _Value_Entry
            if isinstance(_AccessRights, dict):
                _AccessRights = KeyAccessRights(**_AccessRights)
            _KeySettings, _Version, _DiversificationMode, _DivIdx = _AccessRights
            if isinstance(_KeySettings, dict):
                _KeySettings = KeyAccessRights_KeySettings(**_KeySettings)
            _KeySettings_int = 0
            _KeySettings_int |= (int(_KeySettings.IsVersion) & 0b1) << 7
            _KeySettings_int |= (int(_KeySettings.IsDivInfo) & 0b1) << 6
            _KeySettings_int |= (int(_KeySettings.IsDivInfoVhl) & 0b1) << 5
            _KeySettings_int |= (int(_KeySettings.DenyFormat) & 0b1) << 2
            _KeySettings_int |= (int(_KeySettings.DenyWrite) & 0b1) << 1
            _KeySettings_int |= (int(_KeySettings.DenyRead) & 0b1) << 0
            _send_buffer.write(_KeySettings_int.to_bytes(length=1, byteorder='big'))
            if _KeySettings.IsVersion:
                if _Version is None:
                    raise TypeError("missing a required argument: '_Version'")
                _send_buffer.write(_Version.to_bytes(length=1, byteorder='big'))
            if _KeySettings.IsDivInfo:
                if _DiversificationMode is None:
                    raise TypeError("missing a required argument: '_DiversificationMode'")
                if _DivIdx is None:
                    raise TypeError("missing a required argument: '_DivIdx'")
                _send_buffer.write(KeyAccessRights_DiversificationMode_Parser.as_value(_DiversificationMode).to_bytes(length=1, byteorder='big'))
                _send_buffer.write(_DivIdx.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(CryptoAlgorithm_Parser.as_value(_Algorithm).to_bytes(length=1, byteorder='big'))
            if _Algorithm == "DES":
                if _DesKey is None:
                    raise TypeError("missing a required argument: '_DesKey'")
                if len(_DesKey) != 8:
                    raise ValueError(_DesKey)
                _send_buffer.write(_DesKey)
            if _Algorithm == "ThreeKeyTripleDES":
                if _ThreeKeyTripleDESKey is None:
                    raise TypeError("missing a required argument: '_ThreeKeyTripleDESKey'")
                if len(_ThreeKeyTripleDESKey) != 24:
                    raise ValueError(_ThreeKeyTripleDESKey)
                _send_buffer.write(_ThreeKeyTripleDESKey)
            if _Algorithm == "TripleDES" or _Algorithm == "AES":
                if _TripleDesAesKey is None:
                    raise TypeError("missing a required argument: '_TripleDesAesKey'")
                if len(_TripleDesAesKey) != 16:
                    raise ValueError(_TripleDesAesKey)
                _send_buffer.write(_TripleDesAesKey)
            if _Algorithm == "MifareClassic":
                if _MifareClassicKey is None:
                    raise TypeError("missing a required argument: '_MifareClassicKey'")
                if len(_MifareClassicKey) != 6:
                    raise ValueError(_MifareClassicKey)
                _send_buffer.write(_MifareClassicKey)
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[VhlCfg_File_DesfireKeyList_Value_Entry]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_DesfireFileDesc(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x3A
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b':')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[DesfireFileDescription]:
        _recv_buffer = BytesIO(frame)
        _DesfireFileDescList = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _FileNo = safe_read_int_from_buffer(_recv_buffer, 1)
            _FileCommunicationSecurity = DesfireFileDescription_FileCommunicationSecurity_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
            _FileType = DesfireFileDescription_FileType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
            _ReadKeyNo = safe_read_int_from_buffer(_recv_buffer, 1)
            _WriteKeyNo = safe_read_int_from_buffer(_recv_buffer, 1)
            _Offset = safe_read_int_from_buffer(_recv_buffer, 2)
            _Length = safe_read_int_from_buffer(_recv_buffer, 2)
            _ReadKeyIdx = safe_read_int_from_buffer(_recv_buffer, 1)
            _WriteKeyIdx = safe_read_int_from_buffer(_recv_buffer, 1)
            _AccessRightsLowByte = safe_read_int_from_buffer(_recv_buffer, 1)
            _ChangeKeyIdx = safe_read_int_from_buffer(_recv_buffer, 1)
            _FileSize = safe_read_int_from_buffer(_recv_buffer, 2)
            _IsoFid = safe_read_int_from_buffer(_recv_buffer, 2)
            _DesfireFileDesc = DesfireFileDescription(_FileNo, _FileCommunicationSecurity, _FileType, _ReadKeyNo, _WriteKeyNo, _Offset, _Length, _ReadKeyIdx, _WriteKeyIdx, _AccessRightsLowByte, _ChangeKeyIdx, _FileSize, _IsoFid)
            _DesfireFileDescList.append(_DesfireFileDesc)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _DesfireFileDescList
    def get(self, File_ndx: int, default: Optional[List[DesfireFileDescription]] = None) -> Optional[List[DesfireFileDescription]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b':')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, DesfireFileDescList: List[DesfireFileDescription]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b':')
        for _DesfireFileDescList_Entry in DesfireFileDescList:
            _DesfireFileDesc = _DesfireFileDescList_Entry
            if isinstance(_DesfireFileDesc, dict):
                _DesfireFileDesc = DesfireFileDescription(**_DesfireFileDesc)
            _FileNo, _FileCommunicationSecurity, _FileType, _ReadKeyNo, _WriteKeyNo, _Offset, _Length, _ReadKeyIdx, _WriteKeyIdx, _AccessRightsLowByte, _ChangeKeyIdx, _FileSize, _IsoFid = _DesfireFileDesc
            _send_buffer.write(_FileNo.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(DesfireFileDescription_FileCommunicationSecurity_Parser.as_value(_FileCommunicationSecurity).to_bytes(length=1, byteorder='big'))
            _send_buffer.write(DesfireFileDescription_FileType_Parser.as_value(_FileType).to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_ReadKeyNo.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_WriteKeyNo.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_Offset.to_bytes(length=2, byteorder='big'))
            _send_buffer.write(_Length.to_bytes(length=2, byteorder='big'))
            _send_buffer.write(_ReadKeyIdx.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_WriteKeyIdx.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_AccessRightsLowByte.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_ChangeKeyIdx.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_FileSize.to_bytes(length=2, byteorder='big'))
            _send_buffer.write(_IsoFid.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, DesfireFileDescList: List[DesfireFileDescription]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, DesfireFileDescList=DesfireFileDescList)
        self.process_frame(frame)
class VhlCfg_File_DesfirePiccMasterKeys(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x3B
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b';')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[DesfireKeyIdx]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _PiccMasterkeyIdx = safe_read_int_from_buffer(_recv_buffer, 1)
            _Value.append(_PiccMasterkeyIdx)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[DesfireKeyIdx]] = None) -> Optional[List[DesfireKeyIdx]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b';')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[DesfireKeyIdx]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b';')
        for _Value_Entry in Value:
            _PiccMasterkeyIdx = _Value_Entry
            _send_buffer.write(_PiccMasterkeyIdx.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[DesfireKeyIdx]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_DesfireProtocol(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x3C
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'<')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> VhlCfg_File_DesfireProtocol_ProtocolMode:
        _recv_buffer = BytesIO(frame)
        _ProtocolMode = VhlCfg_File_DesfireProtocol_ProtocolMode_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ProtocolMode
    def get(self, File_ndx: int, default: Optional[VhlCfg_File_DesfireProtocol_ProtocolMode] = None) -> Optional[VhlCfg_File_DesfireProtocol_ProtocolMode]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'<')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, ProtocolMode: VhlCfg_File_DesfireProtocol_ProtocolMode) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'<')
        _send_buffer.write(VhlCfg_File_DesfireProtocol_ProtocolMode_Parser.as_value(ProtocolMode).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, ProtocolMode: VhlCfg_File_DesfireProtocol_ProtocolMode) -> None:
        frame = self.build_frame(File_ndx=File_ndx, ProtocolMode=ProtocolMode)
        self.process_frame(frame)
class VhlCfg_File_DesfireMapKeyidx(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x42
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'B')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[VhlCfg_File_DesfireMapKeyidx_KeyidxMapList_Entry]:
        _recv_buffer = BytesIO(frame)
        _KeyidxMapList = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _Keyidx = safe_read_int_from_buffer(_recv_buffer, 1)
            _KeyidxMsb = safe_read_int_from_buffer(_recv_buffer, 2)
            _KeyidxLsb = safe_read_int_from_buffer(_recv_buffer, 1)
            _KeyidxMapList_Entry = VhlCfg_File_DesfireMapKeyidx_KeyidxMapList_Entry(_Keyidx, _KeyidxMsb, _KeyidxLsb)
            _KeyidxMapList.append(_KeyidxMapList_Entry)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _KeyidxMapList
    def get(self, File_ndx: int, default: Optional[List[VhlCfg_File_DesfireMapKeyidx_KeyidxMapList_Entry]] = None) -> Optional[List[VhlCfg_File_DesfireMapKeyidx_KeyidxMapList_Entry]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'B')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, KeyidxMapList: List[VhlCfg_File_DesfireMapKeyidx_KeyidxMapList_Entry]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'B')
        for _KeyidxMapList_Entry in KeyidxMapList:
            _Keyidx, _KeyidxMsb, _KeyidxLsb = _KeyidxMapList_Entry
            _send_buffer.write(_Keyidx.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_KeyidxMsb.to_bytes(length=2, byteorder='big'))
            _send_buffer.write(_KeyidxLsb.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, KeyidxMapList: List[VhlCfg_File_DesfireMapKeyidx_KeyidxMapList_Entry]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, KeyidxMapList=KeyidxMapList)
        self.process_frame(frame)
class VhlCfg_File_DesfireRandomIdKey(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x49
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'I')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> VhlCfg_File_DesfireRandomIdKey_Result:
        _recv_buffer = BytesIO(frame)
        _ReadIdKeyNo = safe_read_int_from_buffer(_recv_buffer, 1)
        _ReadIdKeyIdx = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return VhlCfg_File_DesfireRandomIdKey_Result(_ReadIdKeyNo, _ReadIdKeyIdx)
    def get(self, File_ndx: int, default: Optional[VhlCfg_File_DesfireRandomIdKey_Result] = None) -> Optional[VhlCfg_File_DesfireRandomIdKey_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'I')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, ReadIdKeyNo: int = 0, ReadIdKeyIdx: int = 192) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'I')
        _send_buffer.write(ReadIdKeyNo.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(ReadIdKeyIdx.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, ReadIdKeyNo: int = 0, ReadIdKeyIdx: int = 192) -> None:
        frame = self.build_frame(File_ndx=File_ndx, ReadIdKeyNo=ReadIdKeyNo, ReadIdKeyIdx=ReadIdKeyIdx)
        self.process_frame(frame)
class VhlCfg_File_DesfireProxcheck(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x4F
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'O')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> DesfireKeyIdx:
        _recv_buffer = BytesIO(frame)
        _ProxcheckKeyidx = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ProxcheckKeyidx
    def get(self, File_ndx: int, default: Optional[DesfireKeyIdx] = None) -> Optional[DesfireKeyIdx]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'O')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, ProxcheckKeyidx: DesfireKeyIdx) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'O')
        _send_buffer.write(ProxcheckKeyidx.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, ProxcheckKeyidx: DesfireKeyIdx) -> None:
        frame = self.build_frame(File_ndx=File_ndx, ProxcheckKeyidx=ProxcheckKeyidx)
        self.process_frame(frame)
class VhlCfg_File_DesfireVcsParams(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x50
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'P')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> VhlCfg_File_DesfireVcsParams_Result:
        _recv_buffer = BytesIO(frame)
        _VcsOptions_int = safe_read_int_from_buffer(_recv_buffer, 1)
        _PrependUidBeforeMacDivData = bool((_VcsOptions_int >> 2) & 0b1)
        _RejectCardsWithoutValidIid = bool((_VcsOptions_int >> 1) & 0b1)
        _ForceAuthToCard = bool((_VcsOptions_int >> 0) & 0b1)
        _DfName_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _DfName = _recv_buffer.read(_DfName_len)
        if len(_DfName) != _DfName_len:
            raise PayloadTooShortError(_DfName_len - len(_DfName))
        _VcsEncKeyidx = safe_read_int_from_buffer(_recv_buffer, 1)
        _VcsMacKeyidx = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return VhlCfg_File_DesfireVcsParams_Result(_PrependUidBeforeMacDivData, _RejectCardsWithoutValidIid, _ForceAuthToCard, _DfName, _VcsEncKeyidx, _VcsMacKeyidx)
    def get(self, File_ndx: int, default: Optional[VhlCfg_File_DesfireVcsParams_Result] = None) -> Optional[VhlCfg_File_DesfireVcsParams_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'P')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, PrependUidBeforeMacDivData: bool, RejectCardsWithoutValidIid: bool, ForceAuthToCard: bool, DfName: bytes, VcsEncKeyidx: DesfireKeyIdx, VcsMacKeyidx: DesfireKeyIdx) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'P')
        _var_0000_int = 0
        _var_0000_int |= (int(PrependUidBeforeMacDivData) & 0b1) << 2
        _var_0000_int |= (int(RejectCardsWithoutValidIid) & 0b1) << 1
        _var_0000_int |= (int(ForceAuthToCard) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(DfName)).to_bytes(1, byteorder='big'))
        _send_buffer.write(DfName)
        _send_buffer.write(VcsEncKeyidx.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(VcsMacKeyidx.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, PrependUidBeforeMacDivData: bool, RejectCardsWithoutValidIid: bool, ForceAuthToCard: bool, DfName: bytes, VcsEncKeyidx: DesfireKeyIdx, VcsMacKeyidx: DesfireKeyIdx) -> None:
        frame = self.build_frame(File_ndx=File_ndx, PrependUidBeforeMacDivData=PrependUidBeforeMacDivData, RejectCardsWithoutValidIid=RejectCardsWithoutValidIid, ForceAuthToCard=ForceAuthToCard, DfName=DfName, VcsEncKeyidx=VcsEncKeyidx, VcsMacKeyidx=VcsMacKeyidx)
        self.process_frame(frame)
class VhlCfg_File_DesfireEV2FormatFileMultAccessCond(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x51
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'Q')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[VhlCfg_File_DesfireEV2FormatFileMultAccessCond_FileList_Entry]:
        _recv_buffer = BytesIO(frame)
        _FileList = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _FileNr = safe_read_int_from_buffer(_recv_buffer, 1)
            _AccessCondList_len = safe_read_int_from_buffer(_recv_buffer, 1)
            _AccessCondList = []  # type: ignore[var-annotated,unused-ignore]
            while not len(_AccessCondList) >= _AccessCondList_len:
                _AccessCond = safe_read_int_from_buffer(_recv_buffer, 2)
                _AccessCondList.append(_AccessCond)
            if len(_AccessCondList) != _AccessCondList_len:
                raise PayloadTooShortError(_AccessCondList_len - len(_AccessCondList))
            _FileList_Entry = VhlCfg_File_DesfireEV2FormatFileMultAccessCond_FileList_Entry(_FileNr, _AccessCondList)
            _FileList.append(_FileList_Entry)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _FileList
    def get(self, File_ndx: int, default: Optional[List[VhlCfg_File_DesfireEV2FormatFileMultAccessCond_FileList_Entry]] = None) -> Optional[List[VhlCfg_File_DesfireEV2FormatFileMultAccessCond_FileList_Entry]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'Q')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, FileList: List[VhlCfg_File_DesfireEV2FormatFileMultAccessCond_FileList_Entry]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'Q')
        for _FileList_Entry in FileList:
            _FileNr, _AccessCondList = _FileList_Entry
            _send_buffer.write(_FileNr.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(int(len(_AccessCondList)).to_bytes(1, byteorder='big'))
            for _AccessCondList_Entry in _AccessCondList:
                _AccessCond = _AccessCondList_Entry
                _send_buffer.write(_AccessCond.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, FileList: List[VhlCfg_File_DesfireEV2FormatFileMultAccessCond_FileList_Entry]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, FileList=FileList)
        self.process_frame(frame)
class VhlCfg_File_ForceCardSM(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x53
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'S')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> VhlCfg_File_ForceCardSM_MinimumSM:
        _recv_buffer = BytesIO(frame)
        _MinimumSM = VhlCfg_File_ForceCardSM_MinimumSM_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _MinimumSM
    def get(self, File_ndx: int, default: Optional[VhlCfg_File_ForceCardSM_MinimumSM] = None) -> Optional[VhlCfg_File_ForceCardSM_MinimumSM]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'S')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, MinimumSM: VhlCfg_File_ForceCardSM_MinimumSM) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'S')
        _send_buffer.write(VhlCfg_File_ForceCardSM_MinimumSM_Parser.as_value(MinimumSM).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, MinimumSM: VhlCfg_File_ForceCardSM_MinimumSM) -> None:
        frame = self.build_frame(File_ndx=File_ndx, MinimumSM=MinimumSM)
        self.process_frame(frame)
class VhlCfg_File_DesfireDiversificationData(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x5B
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'[')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Template:
        _recv_buffer = BytesIO(frame)
        _Value = Template(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[Template] = None) -> Optional[Template]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'[')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: Union[Template, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'[')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: Union[Template, bytes]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_DesfireSoftUid(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x5C
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\\')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> VhlCfg_File_DesfireSoftUid_Result:
        _recv_buffer = BytesIO(frame)
        _AID = safe_read_int_from_buffer(_recv_buffer, 4)
        _FileNr = safe_read_int_from_buffer(_recv_buffer, 1)
        _ReadKeyNo = safe_read_int_from_buffer(_recv_buffer, 1)
        _ReadKeyIdx = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return VhlCfg_File_DesfireSoftUid_Result(_AID, _FileNr, _ReadKeyNo, _ReadKeyIdx)
    def get(self, File_ndx: int, default: Optional[VhlCfg_File_DesfireSoftUid_Result] = None) -> Optional[VhlCfg_File_DesfireSoftUid_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\\')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, AID: int, FileNr: int, ReadKeyNo: int = 0, ReadKeyIdx: int = 192) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\\')
        _send_buffer.write(AID.to_bytes(length=4, byteorder='big'))
        _send_buffer.write(FileNr.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(ReadKeyNo.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(ReadKeyIdx.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, AID: int, FileNr: int, ReadKeyNo: int = 0, ReadKeyIdx: int = 192) -> None:
        frame = self.build_frame(File_ndx=File_ndx, AID=AID, FileNr=FileNr, ReadKeyNo=ReadKeyNo, ReadKeyIdx=ReadKeyIdx)
        self.process_frame(frame)
class VhlCfg_File_FelicaSystemCode(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x70
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'p')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _SystemCode = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _SystemCode
    def get(self, File_ndx: int, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'p')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, SystemCode: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'p')
        _send_buffer.write(SystemCode.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, SystemCode: int) -> None:
        frame = self.build_frame(File_ndx=File_ndx, SystemCode=SystemCode)
        self.process_frame(frame)
class VhlCfg_File_FelicaServiceCodeList(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x71
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'q')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[int]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _ServiceCode = safe_read_int_from_buffer(_recv_buffer, 2)
            _Value.append(_ServiceCode)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[int]] = None) -> Optional[List[int]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'q')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[int]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'q')
        for _Value_Entry in Value:
            _ServiceCode = _Value_Entry
            _send_buffer.write(_ServiceCode.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[int]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_FelicaAreaList(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x72
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'r')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[VhlCfg_File_FelicaAreaList_Value_Entry]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _BlockAddress = safe_read_int_from_buffer(_recv_buffer, 1)
            _BlockNr = safe_read_int_from_buffer(_recv_buffer, 1)
            _Value_Entry = VhlCfg_File_FelicaAreaList_Value_Entry(_BlockAddress, _BlockNr)
            _Value.append(_Value_Entry)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[VhlCfg_File_FelicaAreaList_Value_Entry]] = None) -> Optional[List[VhlCfg_File_FelicaAreaList_Value_Entry]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'r')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[VhlCfg_File_FelicaAreaList_Value_Entry]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'r')
        for _Value_Entry in Value:
            _BlockAddress, _BlockNr = _Value_Entry
            _send_buffer.write(_BlockAddress.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_BlockNr.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[VhlCfg_File_FelicaAreaList_Value_Entry]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_FidoRpid(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x73
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b's')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> bytes:
        _recv_buffer = BytesIO(frame)
        _Rpid = _recv_buffer.read(-1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Rpid
    def get(self, File_ndx: int, default: Optional[bytes] = None) -> Optional[bytes]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b's')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Rpid: bytes) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b's')
        _send_buffer.write(Rpid)
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Rpid: bytes) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Rpid=Rpid)
        self.process_frame(frame)
class VhlCfg_File_FidoPublicKey(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x74
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b't')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> bytes:
        _recv_buffer = BytesIO(frame)
        _PublicKey = _recv_buffer.read(65)
        if len(_PublicKey) != 65:
            raise PayloadTooShortError(65 - len(_PublicKey))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _PublicKey
    def get(self, File_ndx: int, default: Optional[bytes] = None) -> Optional[bytes]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b't')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, PublicKey: bytes) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b't')
        if len(PublicKey) != 65:
            raise ValueError(PublicKey)
        _send_buffer.write(PublicKey)
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, PublicKey: bytes) -> None:
        frame = self.build_frame(File_ndx=File_ndx, PublicKey=PublicKey)
        self.process_frame(frame)
class VhlCfg_File_IntIndFileDescList(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x54
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'T')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[VhlCfg_File_IntIndFileDescList_Value_Entry]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _FileSpecifier = FileType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
            _FileId_len = safe_read_int_from_buffer(_recv_buffer, 1)
            _FileId_bytes = _recv_buffer.read(_FileId_len)
            _FileId = _FileId_bytes.decode('ascii')
            if len(_FileId) != _FileId_len:
                raise PayloadTooShortError(_FileId_len - len(_FileId))
            _Value_Entry = VhlCfg_File_IntIndFileDescList_Value_Entry(_FileSpecifier, _FileId)
            _Value.append(_Value_Entry)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[VhlCfg_File_IntIndFileDescList_Value_Entry]] = None) -> Optional[List[VhlCfg_File_IntIndFileDescList_Value_Entry]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'T')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[VhlCfg_File_IntIndFileDescList_Value_Entry]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'T')
        for _Value_Entry in Value:
            _FileSpecifier, _FileId = _Value_Entry
            _send_buffer.write(FileType_Parser.as_value(_FileSpecifier).to_bytes(length=1, byteorder='big'))
            _send_buffer.write(int(len(_FileId)).to_bytes(1, byteorder='big'))
            _send_buffer.write(_FileId.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[VhlCfg_File_IntIndFileDescList_Value_Entry]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_IntIndSegment(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x55
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'U')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> VhlCfg_File_IntIndSegment_Result:
        _recv_buffer = BytesIO(frame)
        _FileOffset = safe_read_int_from_buffer(_recv_buffer, 2)
        _FileLength = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return VhlCfg_File_IntIndSegment_Result(_FileOffset, _FileLength)
    def get(self, File_ndx: int, default: Optional[VhlCfg_File_IntIndSegment_Result] = None) -> Optional[VhlCfg_File_IntIndSegment_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'U')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, FileOffset: int, FileLength: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'U')
        _send_buffer.write(FileOffset.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(FileLength.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, FileOffset: int, FileLength: int) -> None:
        frame = self.build_frame(File_ndx=File_ndx, FileOffset=FileOffset, FileLength=FileLength)
        self.process_frame(frame)
class VhlCfg_File_IntIndKeyIdx(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x56
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'V')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> VhlCfg_File_IntIndKeyIdx_Result:
        _recv_buffer = BytesIO(frame)
        _MemoryType = safe_read_int_from_buffer(_recv_buffer, 1)
        _KeyIndex = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return VhlCfg_File_IntIndKeyIdx_Result(_MemoryType, _KeyIndex)
    def get(self, File_ndx: int, default: Optional[VhlCfg_File_IntIndKeyIdx_Result] = None) -> Optional[VhlCfg_File_IntIndKeyIdx_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'V')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, MemoryType: int, KeyIndex: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'V')
        _send_buffer.write(MemoryType.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(KeyIndex.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, MemoryType: int, KeyIndex: int) -> None:
        frame = self.build_frame(File_ndx=File_ndx, MemoryType=MemoryType, KeyIndex=KeyIndex)
        self.process_frame(frame)
class VhlCfg_File_IntIndRecordNumber(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x57
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'W')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _RecordNumber = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _RecordNumber
    def get(self, File_ndx: int, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'W')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, RecordNumber: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'W')
        _send_buffer.write(RecordNumber.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, RecordNumber: int) -> None:
        frame = self.build_frame(File_ndx=File_ndx, RecordNumber=RecordNumber)
        self.process_frame(frame)
class VhlCfg_File_IntIndOnReadSelectOnly(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x58
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'X')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> VhlCfg_File_IntIndOnReadSelectOnly_Value:
        _recv_buffer = BytesIO(frame)
        _Value = VhlCfg_File_IntIndOnReadSelectOnly_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[VhlCfg_File_IntIndOnReadSelectOnly_Value] = None) -> Optional[VhlCfg_File_IntIndOnReadSelectOnly_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'X')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: VhlCfg_File_IntIndOnReadSelectOnly_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'X')
        _send_buffer.write(VhlCfg_File_IntIndOnReadSelectOnly_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: VhlCfg_File_IntIndOnReadSelectOnly_Value) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_IntIndTimeout(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x59
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'Y')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Timeout = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Timeout
    def get(self, File_ndx: int, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'Y')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Timeout: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'Y')
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Timeout: int) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Timeout=Timeout)
        self.process_frame(frame)
class VhlCfg_File_Iso15Afi(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x30
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'0')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _AFI = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _AFI
    def get(self, File_ndx: int, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'0')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, AFI: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'0')
        _send_buffer.write(AFI.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, AFI: int) -> None:
        frame = self.build_frame(File_ndx=File_ndx, AFI=AFI)
        self.process_frame(frame)
class VhlCfg_File_Iso15DsfId(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x31
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'1')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _DSFID = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _DSFID
    def get(self, File_ndx: int, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'1')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, DSFID: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'1')
        _send_buffer.write(DSFID.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, DSFID: int) -> None:
        frame = self.build_frame(File_ndx=File_ndx, DSFID=DSFID)
        self.process_frame(frame)
class VhlCfg_File_Iso15BlockList(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x33
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'3')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[VhlCfg_File_Iso15BlockList_Value_Entry]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _StartBlock = safe_read_int_from_buffer(_recv_buffer, 1)
            _NumberOfBlocks = safe_read_int_from_buffer(_recv_buffer, 1)
            _Value_Entry = VhlCfg_File_Iso15BlockList_Value_Entry(_StartBlock, _NumberOfBlocks)
            _Value.append(_Value_Entry)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[VhlCfg_File_Iso15BlockList_Value_Entry]] = None) -> Optional[List[VhlCfg_File_Iso15BlockList_Value_Entry]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'3')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[VhlCfg_File_Iso15BlockList_Value_Entry]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'3')
        for _Value_Entry in Value:
            _StartBlock, _NumberOfBlocks = _Value_Entry
            _send_buffer.write(_StartBlock.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_NumberOfBlocks.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[VhlCfg_File_Iso15BlockList_Value_Entry]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_Iso15BlockSize(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x34
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'4')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _BlockSize = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _BlockSize
    def get(self, File_ndx: int, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'4')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, BlockSize: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'4')
        _send_buffer.write(BlockSize.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, BlockSize: int) -> None:
        frame = self.build_frame(File_ndx=File_ndx, BlockSize=BlockSize)
        self.process_frame(frame)
class VhlCfg_File_Iso15WriteOptFlag(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x35
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'5')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> VhlCfg_File_Iso15WriteOptFlag_Value:
        _recv_buffer = BytesIO(frame)
        _Value = VhlCfg_File_Iso15WriteOptFlag_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[VhlCfg_File_Iso15WriteOptFlag_Value] = None) -> Optional[VhlCfg_File_Iso15WriteOptFlag_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'5')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: VhlCfg_File_Iso15WriteOptFlag_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'5')
        _send_buffer.write(VhlCfg_File_Iso15WriteOptFlag_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: VhlCfg_File_Iso15WriteOptFlag_Value) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_Iso15ReadCmd(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x36
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'6')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> VhlCfg_File_Iso15ReadCmd_Value:
        _recv_buffer = BytesIO(frame)
        _Value = VhlCfg_File_Iso15ReadCmd_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[VhlCfg_File_Iso15ReadCmd_Value] = None) -> Optional[VhlCfg_File_Iso15ReadCmd_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'6')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: VhlCfg_File_Iso15ReadCmd_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'6')
        _send_buffer.write(VhlCfg_File_Iso15ReadCmd_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: VhlCfg_File_Iso15ReadCmd_Value) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_Iso15WriteCmd(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x37
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'7')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> VhlCfg_File_Iso15WriteCmd_Value:
        _recv_buffer = BytesIO(frame)
        _Value = VhlCfg_File_Iso15WriteCmd_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[VhlCfg_File_Iso15WriteCmd_Value] = None) -> Optional[VhlCfg_File_Iso15WriteCmd_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'7')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: VhlCfg_File_Iso15WriteCmd_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'7')
        _send_buffer.write(VhlCfg_File_Iso15WriteCmd_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: VhlCfg_File_Iso15WriteCmd_Value) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_Iso15ExtendedBlockList(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x32
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'2')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[VhlCfg_File_Iso15ExtendedBlockList_Value_Entry]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _StartBlock = safe_read_int_from_buffer(_recv_buffer, 2)
            _NumberOfBlocks = safe_read_int_from_buffer(_recv_buffer, 2)
            _Value_Entry = VhlCfg_File_Iso15ExtendedBlockList_Value_Entry(_StartBlock, _NumberOfBlocks)
            _Value.append(_Value_Entry)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[VhlCfg_File_Iso15ExtendedBlockList_Value_Entry]] = None) -> Optional[List[VhlCfg_File_Iso15ExtendedBlockList_Value_Entry]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'2')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[VhlCfg_File_Iso15ExtendedBlockList_Value_Entry]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'2')
        for _Value_Entry in Value:
            _StartBlock, _NumberOfBlocks = _Value_Entry
            _send_buffer.write(_StartBlock.to_bytes(length=2, byteorder='big'))
            _send_buffer.write(_NumberOfBlocks.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[VhlCfg_File_Iso15ExtendedBlockList_Value_Entry]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_LegicSegmentListLegacy(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x20
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b' ')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[VhlCfg_File_LegicSegmentListLegacy_Value_Entry]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _SegmentIdAndAdr_int = safe_read_int_from_buffer(_recv_buffer, 1)
            _AdvantAddressMode = bool((_SegmentIdAndAdr_int >> 7) & 0b1)
            _SegmentIdentification = (_SegmentIdAndAdr_int >> 0) & 0b1111111
            _SegmentInformation_bytes = _recv_buffer.read(1)
            _SegmentInformation = _SegmentInformation_bytes.decode('ascii')
            if len(_SegmentInformation) != 1:
                raise PayloadTooShortError(1 - len(_SegmentInformation))
            _Value_Entry = VhlCfg_File_LegicSegmentListLegacy_Value_Entry(_AdvantAddressMode, _SegmentIdentification, _SegmentInformation)
            _Value.append(_Value_Entry)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[VhlCfg_File_LegicSegmentListLegacy_Value_Entry]] = None) -> Optional[List[VhlCfg_File_LegicSegmentListLegacy_Value_Entry]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b' ')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[VhlCfg_File_LegicSegmentListLegacy_Value_Entry]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b' ')
        for _Value_Entry in Value:
            _AdvantAddressMode, _SegmentIdentification, _SegmentInformation = _Value_Entry
            _var_0000_int = 0
            _var_0000_int |= (int(_AdvantAddressMode) & 0b1) << 7
            _var_0000_int |= (_SegmentIdentification & 0b1111111) << 0
            _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
            if len(_SegmentInformation) != 1:
                raise ValueError(_SegmentInformation)
            _send_buffer.write(_SegmentInformation.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[VhlCfg_File_LegicSegmentListLegacy_Value_Entry]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_LegicLengthList(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x21
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'!')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[int]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _Length = safe_read_int_from_buffer(_recv_buffer, 2)
            _Value.append(_Length)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[int]] = None) -> Optional[List[int]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'!')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[int]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'!')
        for _Value_Entry in Value:
            _Length = _Value_Entry
            _send_buffer.write(_Length.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[int]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_LegicAddressList(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x22
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'"')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[AddressAndEnableCRC]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _Address_int = safe_read_int_from_buffer(_recv_buffer, 2)
            _EnableCRC = bool((_Address_int >> 15) & 0b1)
            _Address = AddressAndEnableCRC(_EnableCRC)
            _Value.append(_Address)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[AddressAndEnableCRC]] = None) -> Optional[List[AddressAndEnableCRC]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'"')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[AddressAndEnableCRC]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'"')
        for _Value_Entry in Value:
            _Address = _Value_Entry
            if isinstance(_Address, dict):
                _Address = AddressAndEnableCRC(**_Address)
            _Address_int = 0
            _Address_int |= (int(_Address.EnableCRC) & 0b1) << 15
            _send_buffer.write(_Address_int.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[AddressAndEnableCRC]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_LegicCRCAddressList(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x23
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'#')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[CRCAddressAndCRCType]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _Address_int = safe_read_int_from_buffer(_recv_buffer, 2)
            _CRC16bit = bool((_Address_int >> 15) & 0b1)
            _Address = CRCAddressAndCRCType(_CRC16bit)
            _Value.append(_Address)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[CRCAddressAndCRCType]] = None) -> Optional[List[CRCAddressAndCRCType]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'#')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[CRCAddressAndCRCType]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'#')
        for _Value_Entry in Value:
            _Address = _Value_Entry
            if isinstance(_Address, dict):
                _Address = CRCAddressAndCRCType(**_Address)
            _Address_int = 0
            _Address_int |= (int(_Address.CRC16bit) & 0b1) << 15
            _send_buffer.write(_Address_int.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[CRCAddressAndCRCType]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_LegicSegmentTypeList(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x24
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'$')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[VhlCfg_File_LegicSegmentTypeList_SegType]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _SegType = VhlCfg_File_LegicSegmentTypeList_SegType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
            _Value.append(_SegType)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[VhlCfg_File_LegicSegmentTypeList_SegType]] = None) -> Optional[List[VhlCfg_File_LegicSegmentTypeList_SegType]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'$')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[VhlCfg_File_LegicSegmentTypeList_SegType]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'$')
        for _Value_Entry in Value:
            _SegType = _Value_Entry
            _send_buffer.write(VhlCfg_File_LegicSegmentTypeList_SegType_Parser.as_value(_SegType).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[VhlCfg_File_LegicSegmentTypeList_SegType]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_LegicUserKeyIndexList(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x25
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'%')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[int]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _KeyIdx = safe_read_int_from_buffer(_recv_buffer, 1)
            _Value.append(_KeyIdx)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[int]] = None) -> Optional[List[int]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'%')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[int]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'%')
        for _Value_Entry in Value:
            _KeyIdx = _Value_Entry
            _send_buffer.write(_KeyIdx.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[int]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_LegicMasterTokenZoneList(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x26
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'&')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[VhlCfg_File_LegicMasterTokenZoneList_MtZone]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _MtZone = VhlCfg_File_LegicMasterTokenZoneList_MtZone_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 2))
            _Value.append(_MtZone)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[VhlCfg_File_LegicMasterTokenZoneList_MtZone]] = None) -> Optional[List[VhlCfg_File_LegicMasterTokenZoneList_MtZone]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'&')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[VhlCfg_File_LegicMasterTokenZoneList_MtZone]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'&')
        for _Value_Entry in Value:
            _MtZone = _Value_Entry
            _send_buffer.write(VhlCfg_File_LegicMasterTokenZoneList_MtZone_Parser.as_value(_MtZone).to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[VhlCfg_File_LegicMasterTokenZoneList_MtZone]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_LegicCtcFileSystemList(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x27
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b"'")
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[VhlCfg_File_LegicCtcFileSystemList_FileSystem]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _FileSystem = VhlCfg_File_LegicCtcFileSystemList_FileSystem_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
            _Value.append(_FileSystem)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[VhlCfg_File_LegicCtcFileSystemList_FileSystem]] = None) -> Optional[List[VhlCfg_File_LegicCtcFileSystemList_FileSystem]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b"'")
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[VhlCfg_File_LegicCtcFileSystemList_FileSystem]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b"'")
        for _Value_Entry in Value:
            _FileSystem = _Value_Entry
            _send_buffer.write(VhlCfg_File_LegicCtcFileSystemList_FileSystem_Parser.as_value(_FileSystem).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[VhlCfg_File_LegicCtcFileSystemList_FileSystem]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_LegicApplicationSegmentList(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x28
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'(')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[VhlCfg_File_LegicApplicationSegmentList_Value_Entry]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _SegmentIdAndAdr_int = safe_read_int_from_buffer(_recv_buffer, 1)
            _AdvantAddressMode = bool((_SegmentIdAndAdr_int >> 7) & 0b1)
            _StampSearch = bool((_SegmentIdAndAdr_int >> 0) & 0b1)
            _SegmentIdAndAdr = SegmentIdentificationAndAddressing(_AdvantAddressMode, _StampSearch)
            _SegmentInformation_len = safe_read_int_from_buffer(_recv_buffer, 1)
            _SegmentInformation_bytes = _recv_buffer.read(_SegmentInformation_len)
            _SegmentInformation = _SegmentInformation_bytes.decode('ascii')
            if len(_SegmentInformation) != _SegmentInformation_len:
                raise PayloadTooShortError(_SegmentInformation_len - len(_SegmentInformation))
            _Value_Entry = VhlCfg_File_LegicApplicationSegmentList_Value_Entry(_SegmentIdAndAdr, _SegmentInformation)
            _Value.append(_Value_Entry)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[VhlCfg_File_LegicApplicationSegmentList_Value_Entry]] = None) -> Optional[List[VhlCfg_File_LegicApplicationSegmentList_Value_Entry]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'(')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[VhlCfg_File_LegicApplicationSegmentList_Value_Entry]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'(')
        for _Value_Entry in Value:
            _SegmentIdAndAdr, _SegmentInformation = _Value_Entry
            if isinstance(_SegmentIdAndAdr, dict):
                _SegmentIdAndAdr = SegmentIdentificationAndAddressing(**_SegmentIdAndAdr)
            _SegmentIdAndAdr_int = 0
            _SegmentIdAndAdr_int |= (int(_SegmentIdAndAdr.AdvantAddressMode) & 0b1) << 7
            _SegmentIdAndAdr_int |= (int(_SegmentIdAndAdr.StampSearch) & 0b1) << 0
            _send_buffer.write(_SegmentIdAndAdr_int.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(int(len(_SegmentInformation)).to_bytes(1, byteorder='big'))
            _send_buffer.write(_SegmentInformation.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[VhlCfg_File_LegicApplicationSegmentList_Value_Entry]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_LegicKeyList(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0xB0
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\xb0')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[VhlCfg_File_LegicKeyList_Value_Entry]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _KeyIndex = safe_read_int_from_buffer(_recv_buffer, 1)
            _KeyType = VhlCfg_File_LegicKeyList_KeyType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
            _RFU = _recv_buffer.read(1)
            if _RFU != b'\x00':
                raise PayloadFormatError(f'_RFU does not contain expected value')
            if _KeyType == "DES":
                _DesKey = _recv_buffer.read(8)
                if len(_DesKey) != 8:
                    raise PayloadTooShortError(8 - len(_DesKey))
            else:
                _DesKey = None
            if _KeyType == "TripleDES":
                _TripleDesKey = _recv_buffer.read(16)
                if len(_TripleDesKey) != 16:
                    raise PayloadTooShortError(16 - len(_TripleDesKey))
            else:
                _TripleDesKey = None
            if _KeyType == "ThreeKeyTripleDES":
                _ThreeKeyTripleDESKey = _recv_buffer.read(24)
                if len(_ThreeKeyTripleDESKey) != 24:
                    raise PayloadTooShortError(24 - len(_ThreeKeyTripleDESKey))
            else:
                _ThreeKeyTripleDESKey = None
            if _KeyType == "AES128":
                _Aes128Key = _recv_buffer.read(16)
                if len(_Aes128Key) != 16:
                    raise PayloadTooShortError(16 - len(_Aes128Key))
            else:
                _Aes128Key = None
            if _KeyType == "AES256":
                _AES256Key = _recv_buffer.read(32)
                if len(_AES256Key) != 32:
                    raise PayloadTooShortError(32 - len(_AES256Key))
            else:
                _AES256Key = None
            _Value_Entry = VhlCfg_File_LegicKeyList_Value_Entry(_KeyIndex, _KeyType, _DesKey, _TripleDesKey, _ThreeKeyTripleDESKey, _Aes128Key, _AES256Key)
            _Value.append(_Value_Entry)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[VhlCfg_File_LegicKeyList_Value_Entry]] = None) -> Optional[List[VhlCfg_File_LegicKeyList_Value_Entry]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\xb0')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[VhlCfg_File_LegicKeyList_Value_Entry]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\xb0')
        for _Value_Entry in Value:
            _KeyIndex, _KeyType, _DesKey, _TripleDesKey, _ThreeKeyTripleDESKey, _Aes128Key, _AES256Key = _Value_Entry
            _send_buffer.write(_KeyIndex.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(VhlCfg_File_LegicKeyList_KeyType_Parser.as_value(_KeyType).to_bytes(length=1, byteorder='big'))
            _send_buffer.write(b'\x00')
            if _KeyType == "DES":
                if _DesKey is None:
                    raise TypeError("missing a required argument: '_DesKey'")
                if len(_DesKey) != 8:
                    raise ValueError(_DesKey)
                _send_buffer.write(_DesKey)
            if _KeyType == "TripleDES":
                if _TripleDesKey is None:
                    raise TypeError("missing a required argument: '_TripleDesKey'")
                if len(_TripleDesKey) != 16:
                    raise ValueError(_TripleDesKey)
                _send_buffer.write(_TripleDesKey)
            if _KeyType == "ThreeKeyTripleDES":
                if _ThreeKeyTripleDESKey is None:
                    raise TypeError("missing a required argument: '_ThreeKeyTripleDESKey'")
                if len(_ThreeKeyTripleDESKey) != 24:
                    raise ValueError(_ThreeKeyTripleDESKey)
                _send_buffer.write(_ThreeKeyTripleDESKey)
            if _KeyType == "AES128":
                if _Aes128Key is None:
                    raise TypeError("missing a required argument: '_Aes128Key'")
                if len(_Aes128Key) != 16:
                    raise ValueError(_Aes128Key)
                _send_buffer.write(_Aes128Key)
            if _KeyType == "AES256":
                if _AES256Key is None:
                    raise TypeError("missing a required argument: '_AES256Key'")
                if len(_AES256Key) != 32:
                    raise ValueError(_AES256Key)
                _send_buffer.write(_AES256Key)
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[VhlCfg_File_LegicKeyList_Value_Entry]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_MifareMode(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x10
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x10')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> VhlCfg_File_MifareMode_AccessMode:
        _recv_buffer = BytesIO(frame)
        _AccessMode = VhlCfg_File_MifareMode_AccessMode_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _AccessMode
    def get(self, File_ndx: int, default: Optional[VhlCfg_File_MifareMode_AccessMode] = None) -> Optional[VhlCfg_File_MifareMode_AccessMode]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x10')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, AccessMode: VhlCfg_File_MifareMode_AccessMode) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x10')
        _send_buffer.write(VhlCfg_File_MifareMode_AccessMode_Parser.as_value(AccessMode).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, AccessMode: VhlCfg_File_MifareMode_AccessMode) -> None:
        frame = self.build_frame(File_ndx=File_ndx, AccessMode=AccessMode)
        self.process_frame(frame)
class VhlCfg_File_MifarePlusMadKeyBIndex(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x91
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x91')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> VhlCfg_File_MifarePlusMadKeyBIndex_Result:
        _recv_buffer = BytesIO(frame)
        _MadKeyBMemoryType = MifarePlusKeyMemoryType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _MadKeyBIdx = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return VhlCfg_File_MifarePlusMadKeyBIndex_Result(_MadKeyBMemoryType, _MadKeyBIdx)
    def get(self, File_ndx: int, default: Optional[VhlCfg_File_MifarePlusMadKeyBIndex_Result] = None) -> Optional[VhlCfg_File_MifarePlusMadKeyBIndex_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x91')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, MadKeyBMemoryType: MifarePlusKeyMemoryType, MadKeyBIdx: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x91')
        _send_buffer.write(MifarePlusKeyMemoryType_Parser.as_value(MadKeyBMemoryType).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(MadKeyBIdx.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, MadKeyBMemoryType: MifarePlusKeyMemoryType, MadKeyBIdx: int) -> None:
        frame = self.build_frame(File_ndx=File_ndx, MadKeyBMemoryType=MadKeyBMemoryType, MadKeyBIdx=MadKeyBIdx)
        self.process_frame(frame)
class VhlCfg_File_MifareKeyList(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x95
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x95')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[VhlCfg_File_MifareKeyList_Value_Entry]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _AccessLimitations_int = safe_read_int_from_buffer(_recv_buffer, 1)
            _DenyTransferToSecureMemory = bool((_AccessLimitations_int >> 4) & 0b1)
            _DenyChangeKey = bool((_AccessLimitations_int >> 2) & 0b1)
            _DenyWrite = bool((_AccessLimitations_int >> 1) & 0b1)
            _DenyRead = bool((_AccessLimitations_int >> 0) & 0b1)
            _Key = _recv_buffer.read(6)
            if len(_Key) != 6:
                raise PayloadTooShortError(6 - len(_Key))
            _Value_Entry = VhlCfg_File_MifareKeyList_Value_Entry(_DenyTransferToSecureMemory, _DenyChangeKey, _DenyWrite, _DenyRead, _Key)
            _Value.append(_Value_Entry)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[VhlCfg_File_MifareKeyList_Value_Entry]] = None) -> Optional[List[VhlCfg_File_MifareKeyList_Value_Entry]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x95')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[VhlCfg_File_MifareKeyList_Value_Entry]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x95')
        for _Value_Entry in Value:
            _DenyTransferToSecureMemory, _DenyChangeKey, _DenyWrite, _DenyRead, _Key = _Value_Entry
            _var_0000_int = 0
            _var_0000_int |= (int(_DenyTransferToSecureMemory) & 0b1) << 4
            _var_0000_int |= (int(_DenyChangeKey) & 0b1) << 2
            _var_0000_int |= (int(_DenyWrite) & 0b1) << 1
            _var_0000_int |= (int(_DenyRead) & 0b1) << 0
            _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
            if len(_Key) != 6:
                raise ValueError(_Key)
            _send_buffer.write(_Key)
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[VhlCfg_File_MifareKeyList_Value_Entry]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_MifareTransferToSecureMemory(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x96
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x96')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> VhlCfg_File_MifareTransferToSecureMemory_TransferKeys:
        _recv_buffer = BytesIO(frame)
        _TransferKeys = VhlCfg_File_MifareTransferToSecureMemory_TransferKeys_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _TransferKeys
    def get(self, File_ndx: int, default: Optional[VhlCfg_File_MifareTransferToSecureMemory_TransferKeys] = None) -> Optional[VhlCfg_File_MifareTransferToSecureMemory_TransferKeys]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x96')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, TransferKeys: VhlCfg_File_MifareTransferToSecureMemory_TransferKeys) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x96')
        _send_buffer.write(VhlCfg_File_MifareTransferToSecureMemory_TransferKeys_Parser.as_value(TransferKeys).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, TransferKeys: VhlCfg_File_MifareTransferToSecureMemory_TransferKeys) -> None:
        frame = self.build_frame(File_ndx=File_ndx, TransferKeys=TransferKeys)
        self.process_frame(frame)
class VhlCfg_File_MifareMadAid(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x18
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x18')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _AID = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _AID
    def get(self, File_ndx: int, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x18')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, AID: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x18')
        _send_buffer.write(AID.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, AID: int) -> None:
        frame = self.build_frame(File_ndx=File_ndx, AID=AID)
        self.process_frame(frame)
class VhlCfg_File_MifarePlusAesKeyList(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x99
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x99')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[VhlCfg_File_MifarePlusAesKeyList_Value_Entry]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _AccessLimitations_int = safe_read_int_from_buffer(_recv_buffer, 1)
            _DenyChangeKey = bool((_AccessLimitations_int >> 2) & 0b1)
            _DenyWrite = bool((_AccessLimitations_int >> 1) & 0b1)
            _DenyRead = bool((_AccessLimitations_int >> 0) & 0b1)
            _Key = _recv_buffer.read(6)
            if len(_Key) != 6:
                raise PayloadTooShortError(6 - len(_Key))
            _Value_Entry = VhlCfg_File_MifarePlusAesKeyList_Value_Entry(_DenyChangeKey, _DenyWrite, _DenyRead, _Key)
            _Value.append(_Value_Entry)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[VhlCfg_File_MifarePlusAesKeyList_Value_Entry]] = None) -> Optional[List[VhlCfg_File_MifarePlusAesKeyList_Value_Entry]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x99')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[VhlCfg_File_MifarePlusAesKeyList_Value_Entry]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x99')
        for _Value_Entry in Value:
            _DenyChangeKey, _DenyWrite, _DenyRead, _Key = _Value_Entry
            _var_0000_int = 0
            _var_0000_int |= (int(_DenyChangeKey) & 0b1) << 2
            _var_0000_int |= (int(_DenyWrite) & 0b1) << 1
            _var_0000_int |= (int(_DenyRead) & 0b1) << 0
            _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
            if len(_Key) != 6:
                raise ValueError(_Key)
            _send_buffer.write(_Key)
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[VhlCfg_File_MifarePlusAesKeyList_Value_Entry]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_MifareSectorList(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x17
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x17')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[int]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _Sector = safe_read_int_from_buffer(_recv_buffer, 1)
            _Value.append(_Sector)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[int]] = None) -> Optional[List[int]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x17')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[int]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x17')
        for _Value_Entry in Value:
            _Sector = _Value_Entry
            _send_buffer.write(_Sector.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[int]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_MifarePlusKeyAssignment(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x90
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x90')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[VhlCfg_File_MifarePlusKeyAssignment_Value_Entry]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _FlagByte_int = safe_read_int_from_buffer(_recv_buffer, 1)
            _WriteWithKeyB = bool((_FlagByte_int >> 1) & 0b1)
            _ReadWithKeyB = bool((_FlagByte_int >> 0) & 0b1)
            _KeyAMemoryType = MifarePlusKeyMemoryType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
            _KeyAIdx = safe_read_int_from_buffer(_recv_buffer, 1)
            _KeyBMemoryType = MifarePlusKeyMemoryType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
            _KeyBIdx = safe_read_int_from_buffer(_recv_buffer, 1)
            _ACBytes = _recv_buffer.read(5)
            if len(_ACBytes) != 5:
                raise PayloadTooShortError(5 - len(_ACBytes))
            _Value_Entry = VhlCfg_File_MifarePlusKeyAssignment_Value_Entry(_WriteWithKeyB, _ReadWithKeyB, _KeyAMemoryType, _KeyAIdx, _KeyBMemoryType, _KeyBIdx, _ACBytes)
            _Value.append(_Value_Entry)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[VhlCfg_File_MifarePlusKeyAssignment_Value_Entry]] = None) -> Optional[List[VhlCfg_File_MifarePlusKeyAssignment_Value_Entry]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x90')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[VhlCfg_File_MifarePlusKeyAssignment_Value_Entry]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x90')
        for _Value_Entry in Value:
            _WriteWithKeyB, _ReadWithKeyB, _KeyAMemoryType, _KeyAIdx, _KeyBMemoryType, _KeyBIdx, _ACBytes = _Value_Entry
            _var_0000_int = 0
            _var_0000_int |= (int(_WriteWithKeyB) & 0b1) << 1
            _var_0000_int |= (int(_ReadWithKeyB) & 0b1) << 0
            _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(MifarePlusKeyMemoryType_Parser.as_value(_KeyAMemoryType).to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_KeyAIdx.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(MifarePlusKeyMemoryType_Parser.as_value(_KeyBMemoryType).to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_KeyBIdx.to_bytes(length=1, byteorder='big'))
            if len(_ACBytes) != 5:
                raise ValueError(_ACBytes)
            _send_buffer.write(_ACBytes)
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[VhlCfg_File_MifarePlusKeyAssignment_Value_Entry]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_MifarePlusCommunicationMode(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x1B
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x1b')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> VhlCfg_File_MifarePlusCommunicationMode_Result:
        _recv_buffer = BytesIO(frame)
        _SL3CommunicationMode_int = safe_read_int_from_buffer(_recv_buffer, 1)
        _ReadNoMacOnCommand = bool((_SL3CommunicationMode_int >> 2) & 0b1)
        _ReadPlain = bool((_SL3CommunicationMode_int >> 1) & 0b1)
        _ReadNoMacOnResponse = bool((_SL3CommunicationMode_int >> 0) & 0b1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return VhlCfg_File_MifarePlusCommunicationMode_Result(_ReadNoMacOnCommand, _ReadPlain, _ReadNoMacOnResponse)
    def get(self, File_ndx: int, default: Optional[VhlCfg_File_MifarePlusCommunicationMode_Result] = None) -> Optional[VhlCfg_File_MifarePlusCommunicationMode_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x1b')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, ReadNoMacOnCommand: bool, ReadPlain: bool, ReadNoMacOnResponse: bool) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x1b')
        _var_0000_int = 0
        _var_0000_int |= (int(ReadNoMacOnCommand) & 0b1) << 2
        _var_0000_int |= (int(ReadPlain) & 0b1) << 1
        _var_0000_int |= (int(ReadNoMacOnResponse) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, ReadNoMacOnCommand: bool, ReadPlain: bool, ReadNoMacOnResponse: bool) -> None:
        frame = self.build_frame(File_ndx=File_ndx, ReadNoMacOnCommand=ReadNoMacOnCommand, ReadPlain=ReadPlain, ReadNoMacOnResponse=ReadNoMacOnResponse)
        self.process_frame(frame)
class VhlCfg_File_MifarePlusProxyimityCheck(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x93
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x93')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> VhlCfg_File_MifarePlusProxyimityCheck_Result:
        _recv_buffer = BytesIO(frame)
        _ProxCheckKeyMemoryType = MifarePlusKeyMemoryType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _ProxCheckKeyIdx = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return VhlCfg_File_MifarePlusProxyimityCheck_Result(_ProxCheckKeyMemoryType, _ProxCheckKeyIdx)
    def get(self, File_ndx: int, default: Optional[VhlCfg_File_MifarePlusProxyimityCheck_Result] = None) -> Optional[VhlCfg_File_MifarePlusProxyimityCheck_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x93')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, ProxCheckKeyMemoryType: MifarePlusKeyMemoryType, ProxCheckKeyIdx: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x93')
        _send_buffer.write(MifarePlusKeyMemoryType_Parser.as_value(ProxCheckKeyMemoryType).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(ProxCheckKeyIdx.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, ProxCheckKeyMemoryType: MifarePlusKeyMemoryType, ProxCheckKeyIdx: int) -> None:
        frame = self.build_frame(File_ndx=File_ndx, ProxCheckKeyMemoryType=ProxCheckKeyMemoryType, ProxCheckKeyIdx=ProxCheckKeyIdx)
        self.process_frame(frame)
class VhlCfg_File_MifareVcsParams(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x16
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x16')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> VhlCfg_File_MifareVcsParams_Result:
        _recv_buffer = BytesIO(frame)
        _VcsOptions_int = safe_read_int_from_buffer(_recv_buffer, 1)
        _PrependUidBeforeMacDivData = bool((_VcsOptions_int >> 2) & 0b1)
        _RejectCardsWithoutValidIid = bool((_VcsOptions_int >> 1) & 0b1)
        _ForceAuthToCard = bool((_VcsOptions_int >> 0) & 0b1)
        _DfName_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _DfName = _recv_buffer.read(_DfName_len)
        if len(_DfName) != _DfName_len:
            raise PayloadTooShortError(_DfName_len - len(_DfName))
        _MifareVcsEncKeyMemoryType = MifarePlusKeyMemoryType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _MifareVcsEncKeyIdx = safe_read_int_from_buffer(_recv_buffer, 1)
        _MifareVcsMacKeyMemoryType = MifarePlusKeyMemoryType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _MifareVcsMacKeyIdx = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return VhlCfg_File_MifareVcsParams_Result(_PrependUidBeforeMacDivData, _RejectCardsWithoutValidIid, _ForceAuthToCard, _DfName, _MifareVcsEncKeyMemoryType, _MifareVcsEncKeyIdx, _MifareVcsMacKeyMemoryType, _MifareVcsMacKeyIdx)
    def get(self, File_ndx: int, default: Optional[VhlCfg_File_MifareVcsParams_Result] = None) -> Optional[VhlCfg_File_MifareVcsParams_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x16')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, PrependUidBeforeMacDivData: bool, RejectCardsWithoutValidIid: bool, ForceAuthToCard: bool, DfName: bytes, MifareVcsEncKeyMemoryType: MifarePlusKeyMemoryType, MifareVcsEncKeyIdx: int, MifareVcsMacKeyMemoryType: MifarePlusKeyMemoryType, MifareVcsMacKeyIdx: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x16')
        _var_0000_int = 0
        _var_0000_int |= (int(PrependUidBeforeMacDivData) & 0b1) << 2
        _var_0000_int |= (int(RejectCardsWithoutValidIid) & 0b1) << 1
        _var_0000_int |= (int(ForceAuthToCard) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(DfName)).to_bytes(1, byteorder='big'))
        _send_buffer.write(DfName)
        _send_buffer.write(MifarePlusKeyMemoryType_Parser.as_value(MifareVcsEncKeyMemoryType).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(MifareVcsEncKeyIdx.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(MifarePlusKeyMemoryType_Parser.as_value(MifareVcsMacKeyMemoryType).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(MifareVcsMacKeyIdx.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, PrependUidBeforeMacDivData: bool, RejectCardsWithoutValidIid: bool, ForceAuthToCard: bool, DfName: bytes, MifareVcsEncKeyMemoryType: MifarePlusKeyMemoryType, MifareVcsEncKeyIdx: int, MifareVcsMacKeyMemoryType: MifarePlusKeyMemoryType, MifareVcsMacKeyIdx: int) -> None:
        frame = self.build_frame(File_ndx=File_ndx, PrependUidBeforeMacDivData=PrependUidBeforeMacDivData, RejectCardsWithoutValidIid=RejectCardsWithoutValidIid, ForceAuthToCard=ForceAuthToCard, DfName=DfName, MifareVcsEncKeyMemoryType=MifareVcsEncKeyMemoryType, MifareVcsEncKeyIdx=MifareVcsEncKeyIdx, MifareVcsMacKeyMemoryType=MifareVcsMacKeyMemoryType, MifareVcsMacKeyIdx=MifareVcsMacKeyIdx)
        self.process_frame(frame)
class VhlCfg_File_MifarePlusKeyIdxOffset(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x1C
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x1c')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _KeyIdxOffset = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _KeyIdxOffset
    def get(self, File_ndx: int, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x1c')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, KeyIdxOffset: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x1c')
        _send_buffer.write(KeyIdxOffset.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, KeyIdxOffset: int) -> None:
        frame = self.build_frame(File_ndx=File_ndx, KeyIdxOffset=KeyIdxOffset)
        self.process_frame(frame)
class VhlCfg_File_MifareClassicFormatSectorTrailer(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x9E
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x9e')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _SectorTrailer_bytes = _recv_buffer.read(-1)
        _SectorTrailer = _SectorTrailer_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _SectorTrailer
    def get(self, File_ndx: int, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x9e')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, SectorTrailer: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x9e')
        _send_buffer.write(SectorTrailer.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, SectorTrailer: str) -> None:
        frame = self.build_frame(File_ndx=File_ndx, SectorTrailer=SectorTrailer)
        self.process_frame(frame)
class VhlCfg_File_MifareClassicKeyList(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x94
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x94')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[str]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _Key_bytes = _recv_buffer.read(6)
            _Key = _Key_bytes.decode('ascii')
            if len(_Key) != 6:
                raise PayloadTooShortError(6 - len(_Key))
            _Value.append(_Key)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[str]] = None) -> Optional[List[str]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x94')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[str]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x94')
        for _Value_Entry in Value:
            _Key = _Value_Entry
            if len(_Key) != 6:
                raise ValueError(_Key)
            _send_buffer.write(_Key.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[str]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_MifareClassicBlockList(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x11
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x11')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[int]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _BlockNumber = safe_read_int_from_buffer(_recv_buffer, 1)
            _Value.append(_BlockNumber)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[int]] = None) -> Optional[List[int]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x11')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[int]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x11')
        for _Value_Entry in Value:
            _BlockNumber = _Value_Entry
            _send_buffer.write(_BlockNumber.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[int]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_MifareClassicReadKeyAssignment(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x12
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x12')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[MifareClassicVhlKeyAssignment]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _Key_int = safe_read_int_from_buffer(_recv_buffer, 1)
            _Secure = bool((_Key_int >> 7) & 0b1)
            _KeyB = bool((_Key_int >> 6) & 0b1)
            _Key = MifareClassicVhlKeyAssignment(_Secure, _KeyB)
            _Value.append(_Key)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[MifareClassicVhlKeyAssignment]] = None) -> Optional[List[MifareClassicVhlKeyAssignment]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x12')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[MifareClassicVhlKeyAssignment]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x12')
        for _Value_Entry in Value:
            _Key = _Value_Entry
            if isinstance(_Key, dict):
                _Key = MifareClassicVhlKeyAssignment(**_Key)
            _Key_int = 0
            _Key_int |= (int(_Key.Secure) & 0b1) << 7
            _Key_int |= (int(_Key.KeyB) & 0b1) << 6
            _send_buffer.write(_Key_int.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[MifareClassicVhlKeyAssignment]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_MifareClassicWriteKeyAssignment(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x13
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x13')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[MifareClassicVhlKeyAssignment]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _Key_int = safe_read_int_from_buffer(_recv_buffer, 1)
            _Secure = bool((_Key_int >> 7) & 0b1)
            _KeyB = bool((_Key_int >> 6) & 0b1)
            _Key = MifareClassicVhlKeyAssignment(_Secure, _KeyB)
            _Value.append(_Key)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[MifareClassicVhlKeyAssignment]] = None) -> Optional[List[MifareClassicVhlKeyAssignment]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x13')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[MifareClassicVhlKeyAssignment]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x13')
        for _Value_Entry in Value:
            _Key = _Value_Entry
            if isinstance(_Key, dict):
                _Key = MifareClassicVhlKeyAssignment(**_Key)
            _Key_int = 0
            _Key_int |= (int(_Key.Secure) & 0b1) << 7
            _Key_int |= (int(_Key.KeyB) & 0b1) << 6
            _send_buffer.write(_Key_int.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[MifareClassicVhlKeyAssignment]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_MifareClassicFormatOriginalKeyList(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x9D
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x9d')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[VhlCfg_File_MifareClassicFormatOriginalKeyList_Value_Entry]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _AuthenticationKeyAssignment = VhlCfg_File_MifareClassicFormatOriginalKeyList_AuthenticationKeyAssignment_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
            _Key = _recv_buffer.read(6)
            if len(_Key) != 6:
                raise PayloadTooShortError(6 - len(_Key))
            _Value_Entry = VhlCfg_File_MifareClassicFormatOriginalKeyList_Value_Entry(_AuthenticationKeyAssignment, _Key)
            _Value.append(_Value_Entry)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[VhlCfg_File_MifareClassicFormatOriginalKeyList_Value_Entry]] = None) -> Optional[List[VhlCfg_File_MifareClassicFormatOriginalKeyList_Value_Entry]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x9d')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[VhlCfg_File_MifareClassicFormatOriginalKeyList_Value_Entry]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x9d')
        for _Value_Entry in Value:
            _AuthenticationKeyAssignment, _Key = _Value_Entry
            _send_buffer.write(VhlCfg_File_MifareClassicFormatOriginalKeyList_AuthenticationKeyAssignment_Parser.as_value(_AuthenticationKeyAssignment).to_bytes(length=1, byteorder='big'))
            if len(_Key) != 6:
                raise ValueError(_Key)
            _send_buffer.write(_Key)
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[VhlCfg_File_MifareClassicFormatOriginalKeyList_Value_Entry]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_MifareClassicMadKeyB(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x9A
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x9a')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _MadKeyB_bytes = _recv_buffer.read(-1)
        _MadKeyB = _MadKeyB_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _MadKeyB
    def get(self, File_ndx: int, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x9a')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, MadKeyB: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x9a')
        _send_buffer.write(MadKeyB.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, MadKeyB: str) -> None:
        frame = self.build_frame(File_ndx=File_ndx, MadKeyB=MadKeyB)
        self.process_frame(frame)
class VhlCfg_File_PivPublicKey(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x75
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'u')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> bytes:
        _recv_buffer = BytesIO(frame)
        _PublicKey = _recv_buffer.read(65)
        if len(_PublicKey) != 65:
            raise PayloadTooShortError(65 - len(_PublicKey))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _PublicKey
    def get(self, File_ndx: int, default: Optional[bytes] = None) -> Optional[bytes]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'u')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, PublicKey: bytes) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'u')
        if len(PublicKey) != 65:
            raise ValueError(PublicKey)
        _send_buffer.write(PublicKey)
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, PublicKey: bytes) -> None:
        frame = self.build_frame(File_ndx=File_ndx, PublicKey=PublicKey)
        self.process_frame(frame)
class VhlCfg_File_UltralightBlockList(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x60
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'`')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[int]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _BlockDescription = safe_read_int_from_buffer(_recv_buffer, 2)
            _Value.append(_BlockDescription)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[int]] = None) -> Optional[List[int]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'`')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[int]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'`')
        for _Value_Entry in Value:
            _BlockDescription = _Value_Entry
            _send_buffer.write(_BlockDescription.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[int]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_UltralightKeyIdx(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x61
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'a')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'a')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'a')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: int) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_UltralightExtendedBlockList(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x62
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'b')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[VhlCfg_File_UltralightExtendedBlockList_Value_Entry]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _StartBlock = safe_read_int_from_buffer(_recv_buffer, 2)
            _NumberOfBlocks = safe_read_int_from_buffer(_recv_buffer, 2)
            _Value_Entry = VhlCfg_File_UltralightExtendedBlockList_Value_Entry(_StartBlock, _NumberOfBlocks)
            _Value.append(_Value_Entry)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[VhlCfg_File_UltralightExtendedBlockList_Value_Entry]] = None) -> Optional[List[VhlCfg_File_UltralightExtendedBlockList_Value_Entry]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'b')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[VhlCfg_File_UltralightExtendedBlockList_Value_Entry]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'b')
        for _Value_Entry in Value:
            _StartBlock, _NumberOfBlocks = _Value_Entry
            _send_buffer.write(_StartBlock.to_bytes(length=2, byteorder='big'))
            _send_buffer.write(_NumberOfBlocks.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[VhlCfg_File_UltralightExtendedBlockList_Value_Entry]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_UltralightKeyList(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0xA8
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\xa8')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[VhlCfg_File_UltralightKeyList_Value_Entry]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _KeySettings_int = safe_read_int_from_buffer(_recv_buffer, 1)
            _IsVersion = bool((_KeySettings_int >> 7) & 0b1)
            _IsDivInfo = bool((_KeySettings_int >> 6) & 0b1)
            _IsDivInfoVhl = bool((_KeySettings_int >> 5) & 0b1)
            _DenyFormat = bool((_KeySettings_int >> 2) & 0b1)
            _DenyWrite = bool((_KeySettings_int >> 1) & 0b1)
            _DenyRead = bool((_KeySettings_int >> 0) & 0b1)
            _KeySettings = KeyAccessRights_KeySettings(_IsVersion, _IsDivInfo, _IsDivInfoVhl, _DenyFormat, _DenyWrite, _DenyRead)
            if _IsVersion:
                _Version = safe_read_int_from_buffer(_recv_buffer, 1)
            else:
                _Version = None
            if _IsDivInfo:
                _DiversificationMode = KeyAccessRights_DiversificationMode_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
                _DivIdx = safe_read_int_from_buffer(_recv_buffer, 1)
            else:
                _DiversificationMode = None
                _DivIdx = None
            _AccessRights = KeyAccessRights(_KeySettings, _Version, _DiversificationMode, _DivIdx)
            _Algorithm = CryptoAlgorithm_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
            if _Algorithm == "TripleDES" or _Algorithm == "AES":
                _TripleDesAesKey = _recv_buffer.read(16)
                if len(_TripleDesAesKey) != 16:
                    raise PayloadTooShortError(16 - len(_TripleDesAesKey))
            else:
                _TripleDesAesKey = None
            _Value_Entry = VhlCfg_File_UltralightKeyList_Value_Entry(_AccessRights, _Algorithm, _TripleDesAesKey)
            _Value.append(_Value_Entry)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[List[VhlCfg_File_UltralightKeyList_Value_Entry]] = None) -> Optional[List[VhlCfg_File_UltralightKeyList_Value_Entry]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\xa8')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: List[VhlCfg_File_UltralightKeyList_Value_Entry]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\xa8')
        for _Value_Entry in Value:
            _AccessRights, _Algorithm, _TripleDesAesKey = _Value_Entry
            if isinstance(_AccessRights, dict):
                _AccessRights = KeyAccessRights(**_AccessRights)
            _KeySettings, _Version, _DiversificationMode, _DivIdx = _AccessRights
            if isinstance(_KeySettings, dict):
                _KeySettings = KeyAccessRights_KeySettings(**_KeySettings)
            _KeySettings_int = 0
            _KeySettings_int |= (int(_KeySettings.IsVersion) & 0b1) << 7
            _KeySettings_int |= (int(_KeySettings.IsDivInfo) & 0b1) << 6
            _KeySettings_int |= (int(_KeySettings.IsDivInfoVhl) & 0b1) << 5
            _KeySettings_int |= (int(_KeySettings.DenyFormat) & 0b1) << 2
            _KeySettings_int |= (int(_KeySettings.DenyWrite) & 0b1) << 1
            _KeySettings_int |= (int(_KeySettings.DenyRead) & 0b1) << 0
            _send_buffer.write(_KeySettings_int.to_bytes(length=1, byteorder='big'))
            if _KeySettings.IsVersion:
                if _Version is None:
                    raise TypeError("missing a required argument: '_Version'")
                _send_buffer.write(_Version.to_bytes(length=1, byteorder='big'))
            if _KeySettings.IsDivInfo:
                if _DiversificationMode is None:
                    raise TypeError("missing a required argument: '_DiversificationMode'")
                if _DivIdx is None:
                    raise TypeError("missing a required argument: '_DivIdx'")
                _send_buffer.write(KeyAccessRights_DiversificationMode_Parser.as_value(_DiversificationMode).to_bytes(length=1, byteorder='big'))
                _send_buffer.write(_DivIdx.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(CryptoAlgorithm_Parser.as_value(_Algorithm).to_bytes(length=1, byteorder='big'))
            if _Algorithm == "TripleDES" or _Algorithm == "AES":
                if _TripleDesAesKey is None:
                    raise TypeError("missing a required argument: '_TripleDesAesKey'")
                if len(_TripleDesAesKey) != 16:
                    raise ValueError(_TripleDesAesKey)
                _send_buffer.write(_TripleDesAesKey)
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: List[VhlCfg_File_UltralightKeyList_Value_Entry]) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_UltralightPassword(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0xA9
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\xa9')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> bytes:
        _recv_buffer = BytesIO(frame)
        _Password_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Password = _recv_buffer.read(_Password_len)
        if len(_Password) != _Password_len:
            raise PayloadTooShortError(_Password_len - len(_Password))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Password
    def get(self, File_ndx: int, default: Optional[bytes] = None) -> Optional[bytes]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\xa9')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Password: bytes) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\xa9')
        _send_buffer.write(int(len(Password)).to_bytes(1, byteorder='big'))
        _send_buffer.write(Password)
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Password: bytes) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Password=Password)
        self.process_frame(frame)
class VhlCfg_File_Filename(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x00
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x00')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x00')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x00')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: str) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_CardType(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> CardType:
        _recv_buffer = BytesIO(frame)
        _Value = CardType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[CardType] = None) -> Optional[CardType]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x01')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: CardType = "Default") -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x01')
        _send_buffer.write(CardType_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: CardType = "Default") -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class VhlCfg_File_RetryCnt(ConfigValue):
    MasterKey: ClassVar[int] = 0x03
    SubKey: ClassVar[int] = 0x00
    ValueKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 252
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, File_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, File_ndx: int, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x02')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, File_ndx: int, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x03')
        if File_ndx < 0 or File_ndx >= 252:
            raise IndexError(File_ndx)
        _send_buffer.write((0 + File_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(b'\x02')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, File_ndx: int, Value: int) -> None:
        frame = self.build_frame(File_ndx=File_ndx, Value=Value)
        self.process_frame(frame)
class PublicConfigAccessor(FrameProcessor):
    @property
    def Autoread(self) -> Autoread:
        """
        The Autoread masterkey contains a set of rules that describes how cards have to be read. When a card is presented it starts processing Rule0. On failure it will go on with the next rule until a rule succeeds reading the card or no more rules are available. 
        
        To activate the autoread mode at least the Template of Rule0 has to be defined or the autoread mode has to be forced to autorun by the AutoreadMode value. 
        
        The resulting data is send to the host depending on the active host protocols. Each protocol driver may convert the data to a protocol specific format before sending it.
        """
        return Autoread(self)
    @property
    def Autoread_Rule(self) -> Autoread_Rule:
        """
        When processing a rule the following steps are checked within this order: 
        
          1. the cardtype of the detected card is within CardTypes
          2. the constant area required by ConstArea is found on the card 
          3. the Template can be processed successfully 
          4. the BaltechScript in CheckScript is runs successfully (returns with _DefaultAction_ or is not defined 
          5. the data return by the template is in the whitelist / not in the blacklist (see Custom/BlackWhiteList).
        """
        return Autoread_Rule(self)
    @property
    def Autoread_Rule_Template(self) -> Autoread_Rule_Template:
        """
        This template describes which parts of the VHL file (see VarData) or the card's serial number (see Serialnr) to read and how to convert them to ASCII format. 
        
        **A default value reading the card's serial number was introduced with firmware 2.11.00. For all previous versions, this value has to be defined explicitly; otherwise no data will be processed by Autoread.**
        """
        return Autoread_Rule_Template(self)
    @property
    def Autoread_Rule_VhlFileIndex(self) -> Autoread_Rule_VhlFileIndex:
        """
        Specifies the index of the VHL file (0-0x3F), that shall be used as source data for the Template. Commands like VarData are reading this vhlfile. 
        
        If this value is omitted implicitly 1 is assumed as default.
        """
        return Autoread_Rule_VhlFileIndex(self)
    @property
    def Autoread_Rule_ConstArea(self) -> Autoread_Rule_ConstArea:
        """
        With this value, an Autoread rule requires fix data at a specific position within the VHL file. _Position_ define the position from where the fix data area is starting. The rest of this field constant data VHL file has to match.
        """
        return Autoread_Rule_ConstArea(self)
    @property
    def Autoread_Rule_CardTypes(self) -> Autoread_Rule_CardTypes:
        """
        With this value the autoread rule can be enforced to accept only one of the cardtypes specified in this list.
        """
        return Autoread_Rule_CardTypes(self)
    @property
    def Autoread_Rule_CheckScriptId(self) -> Autoread_Rule_CheckScriptId:
        """
        **This value is obsolete. It is only supported for legacy configurations. Please use Autoread.Rule.CheckScript instead.**
        
        When a card matches an autoread rule, this value allows to do additional script based checks that can deny the card. If this value is not set, the card will always be accepted.
        """
        return Autoread_Rule_CheckScriptId(self)
    @property
    def Autoread_Rule_MsgType(self) -> Autoread_Rule_MsgType:
        """
        This value defines the message type that the command AR.GetMessage returns. For each message type, you can define how to format the message and how to transmit it to the host system. To do so, use the _HostMsgFormatTemplate_ value of your protocol. You can find in the Protocols MasterKey, under the Subkey for your protocol.
        """
        return Autoread_Rule_MsgType(self)
    @property
    def Autoread_Rule_WiegandInputBitLen(self) -> Autoread_Rule_WiegandInputBitLen:
        """
        Only needed for readers, that provides a Wiegand Input port and which process this wiegand input like a card presentation (i.e. with the Autoread functionality). If defined, reader accepts only wiegand frames with this bitlen. If 0xFF any bitlen is accepted.
        """
        return Autoread_Rule_WiegandInputBitLen(self)
    @property
    def Autoread_Rule_CardFamilies(self) -> Autoread_Rule_CardFamilies:
        """
        If the prioritization feature is enabled this value defines the card families to be handled prioritized. In this respect this value corresponds to VhlSettings.PrioritizeCardFamilies. Be aware that if the VhlSettings value is set the Autoread rule value is ignored!
        """
        return Autoread_Rule_CardFamilies(self)
    @property
    def Autoread_Rule_PrioritizationMode(self) -> Autoread_Rule_PrioritizationMode:
        """
        This value allows enabling a prioritization scheme which is applied when multiple cards are presented to the reader simultaneously. The prioritization guarantees that the reader always returns the prioritized card families first/only. 
        
        If prioritization is enabled the card families which shall pe prioritized are defined in Card Families. By default the prioritization is applied to any detected card. The configuration value PrioritizationTriggeringCardFamilies allows restricting the prioritization to certain card families in order to optimize the processing speed.
        """
        return Autoread_Rule_PrioritizationMode(self)
    @property
    def Autoread_Rule_PrioritizationTriggeringCardFamilies(self) -> Autoread_Rule_PrioritizationTriggeringCardFamilies:
        """
        This value defines the card families which trigger the prioritization mechanism. Only if the reader detects a card which belongs to one of the specified card families, it checks for a prioritized card which it would return instead of the originally detected card. 
        
        If this value is not set, the reader applies the prioritization mechanism to every detected card. Because the prioritization consumes additional time the processing speed can be optimized by defining this value and restricting the prioritization to the relevant cards only. 
        
        **This value corresponds to VhlSettings.PrioritizeCardFamilies . If the VhlSettings value is set it overwrites the Autoread rule value!**
        """
        return Autoread_Rule_PrioritizationTriggeringCardFamilies(self)
    @property
    def Autoread_Rule_OnMatchAction(self) -> Autoread_Rule_OnMatchAction:
        """
        This value allows defining an inverse rule which suppresses the output if the rule can be applied successfully (see _DenyCard_). This feature can be used to filter out cards with certain properties.
        """
        return Autoread_Rule_OnMatchAction(self)
    @property
    def Autoread_Rule_AllowRandomSerialNumbers(self) -> Autoread_Rule_AllowRandomSerialNumbers:
        """
        This value allows Autoread to be forced to return random card serial numbers. 
        
        Random card serial numbers, changing with every card presentation, are useless for identification purposes. This is why random serial numbers are ignored by rules which process the card serial number by default. This value allows changing this behaviour.
        """
        return Autoread_Rule_AllowRandomSerialNumbers(self)
    @property
    def Autoread_Rule_OnMatchEvent(self) -> Autoread_Rule_OnMatchEvent:
        """
        This event is fired when the surrounding rule is matching. If the script that is executed on this event contains a _DefaultAction_ , one of the following events will be fired subsequently: 
        
          * OnAccepted
          * OnMatchMsg[X]
          * OnInvalidCard
        
        
        
        **If the script contains no _DefaultAction_ , the events listed above will be omitted.**
        """
        return Autoread_Rule_OnMatchEvent(self)
    @property
    def Autoread_Rule_VhlFileName(self) -> Autoread_Rule_VhlFileName:
        """
        Specifies the name of the VHL file to be used as source data for the template. This VHL file is read by commands such as VarData. 
        
        If this value is omitted, VhlFileIdx is used as default.
        """
        return Autoread_Rule_VhlFileName(self)
    @property
    def Autoread_Rule_CheckScript(self) -> Autoread_Rule_CheckScript:
        """
        When a card matches an autoread rule, this value allows to do additional script based checks that can deny the card. 
        
        The card will always be accepted if this configuration value is not set or if the script within this value contains a DefaultAction command. Otherwise, Autoread will assume that this rule has failed and will progress with the remaining rules.
        """
        return Autoread_Rule_CheckScript(self)
    @property
    def Autoread_Rule_BlackWhiteListTemplate(self) -> Autoread_Rule_BlackWhiteListTemplate:
        """
        If this template is set, it is used to generate a number that is compared against a black-/whitelist instead of the number that is returned by Autoread (see Template).
        """
        return Autoread_Rule_BlackWhiteListTemplate(self)
    @property
    def Autoread_Rule_SendProtocol(self) -> Autoread_Rule_SendProtocol:
        """
        If this value is set, the number returned by Autoread will not be sent to all activated protocols, but only to the specified protocol.
        """
        return Autoread_Rule_SendProtocol(self)
    @property
    def Autoread_Rule_TemplateExt1(self) -> Autoread_Rule_TemplateExt1:
        """
        This value can be used as an extension for the Template value, in case the Autoread template to use is longer than 128 Bytes. In this case, the previous part of the template must end with the TemplateCommand command.
        """
        return Autoread_Rule_TemplateExt1(self)
    @property
    def Autoread_Rule_TemplateExt2(self) -> Autoread_Rule_TemplateExt2:
        """
        This value can be used as an extension for the Template and TemplateExt1 values, in case the Autoread template to use is longer than 256 Bytes. In this case, the previous part of the template must end with the TemplateCommand command.
        """
        return Autoread_Rule_TemplateExt2(self)
    @property
    def Autoread_Rule_Counter(self) -> Autoread_Rule_Counter:
        """
        This is an internal storage for saving the current counter state that is needed when a CardCounter command is processed and need to retrieve/increment the current value.
        """
        return Autoread_Rule_Counter(self)
    @property
    def Autoread_Rule_OnMatchSendApdu(self) -> Autoread_Rule_OnMatchSendApdu:
        """
        _OnMatchSendApdu_ consists of an APDU. The APDU is sent to the card when the rule has been successfully applied and the VHL commands have been executed in EnableOnce mode if necessary.
        """
        return Autoread_Rule_OnMatchSendApdu(self)
    @property
    def Scripts(self) -> Scripts:
        """
        The autoread functionality of the reader is highly customizable with the help of BaltechScripts. These scripts and their helper values are stored in this masterkey.
        """
        return Scripts(self)
    @property
    def Scripts_StaticMessages(self) -> Scripts_StaticMessages:
        """
        Contains constant messages that are needed by scripts
        """
        return Scripts_StaticMessages(self)
    @property
    def Scripts_StaticMessages_SendMessage(self) -> Scripts_StaticMessages_SendMessage:
        """
        These values contain constant messages to be used by _SendMsg_ (see BaltechScripts Commands ). 
        
        **The maximum allowed size of a message is 30 bytes!**
        """
        return Scripts_StaticMessages_SendMessage(self)
    @property
    def Scripts_StaticMessages_SendMsgLegacy(self) -> Scripts_StaticMessages_SendMsgLegacy:
        """
        These values contain constant messages to be used by _SendMsg_ (see BaltechScripts Commands ). 
        
        **The maximum allowed size of a message is 30 bytes!**
        """
        return Scripts_StaticMessages_SendMsgLegacy(self)
    @property
    def Scripts_StaticMessages_MatchMessage(self) -> Scripts_StaticMessages_MatchMessage:
        """
        Autoread compares every returned message to one of these constant messages. On match the corresponding OnMatchMsg Event will be fired.
        """
        return Scripts_StaticMessages_MatchMessage(self)
    @property
    def Scripts_Events(self) -> Scripts_Events:
        """
        The Autoread functionality defines a number of events, each of which corresponds to a configuration value within this subkey. At each event, you can perform a custom action. To do so, you need to load the code for the action onto the reader as the respective configuration value. 
        
        **Most events have a _default action_ , i.e. the action that the firmware performs by default. If you configure a custom action, it will replace the default action. To perform the default action _in addition_ to your custom action, you need to run the DefaultAction command.**
        
        For more details about the events and their default actions, please refer to the configuration value descriptions.
        """
        return Scripts_Events(self)
    @property
    def Scripts_Events_OnSetState(self) -> Scripts_Events_OnSetState:
        """
        A state switched from cleared to set. This event can define a custom action. The meaning of the state depends on the firmware. 
        
        **The initial state is defined in Device/Boot/FireInputEventAtPowerup**
        """
        return Scripts_Events_OnSetState(self)
    @property
    def Scripts_Events_OnSetInput(self) -> Scripts_Events_OnSetInput:
        """
        The _InputX_ I/O-port changed its state from low to high. This event can define a custom action. 
        
        **The initial state is defined in Device/Boot/FireInputEventAtPowerup**
        """
        return Scripts_Events_OnSetInput(self)
    @property
    def Scripts_Events_OnSetTamperAlarm(self) -> Scripts_Events_OnSetTamperAlarm:
        """
        The _TamperAlarm_ I/O-port changed its state from off to on. This event can define a custom action. 
        
        **The initial state is defined in Device/Boot/FireInputEventAtPowerup**
        """
        return Scripts_Events_OnSetTamperAlarm(self)
    @property
    def Scripts_Events_OnSetGpio(self) -> Scripts_Events_OnSetGpio:
        """
        The _GpioX_ I/O-port changed its state from low to high. This event can define a custom action. 
        
        **The initial state is defined in Device/Boot/FireInputEventAtPowerup**
        """
        return Scripts_Events_OnSetGpio(self)
    @property
    def Scripts_Events_OnClearState(self) -> Scripts_Events_OnClearState:
        """
        A state switched from set to cleared. This event can define a custom action. The meaning of the state depends on the firmware. 
        
        **The initial state is defined in Device/Boot/FireInputEventAtPowerup**
        """
        return Scripts_Events_OnClearState(self)
    @property
    def Scripts_Events_OnClearInput(self) -> Scripts_Events_OnClearInput:
        """
        The _InputX_ I/O-port changed its state from high to low. This event can define a custom action. 
        
        **The initial state is defined in Device/Boot/FireInputEventAtPowerup**
        """
        return Scripts_Events_OnClearInput(self)
    @property
    def Scripts_Events_OnClearTamperAlarm(self) -> Scripts_Events_OnClearTamperAlarm:
        """
        The _TamperAlarm_ I/O port has changed its state from on to off.  
        The initial state is defined in Device/Boot/FireInputEventAtPowerup. 
        
        The _default action_ for this event is to send an AlarmOff message to the host. 
        
        **If you configure a custom action, it will replace the default action. To perform _both actions_ , you need to run the DefaultAction command.**
        """
        return Scripts_Events_OnClearTamperAlarm(self)
    @property
    def Scripts_Events_OnClearGpio(self) -> Scripts_Events_OnClearGpio:
        """
        The _GpioX_ I/O-port changed its state from high to low. This event can define a custom action. 
        
        **The initial state is defined in Device/Boot/FireInputEventAtPowerup**
        """
        return Scripts_Events_OnClearGpio(self)
    @property
    def Scripts_Events_OnPinEntry(self) -> Scripts_Events_OnPinEntry:
        """
        A PIN code has been entered via the keypad. 
        
        The _default action_ for this event is to send a message with the PIN code to the host. 
        
        **If you configure a custom action, it will replace the default action. To perform _both actions_ , you need to run the DefaultAction command.**
        """
        return Scripts_Events_OnPinEntry(self)
    @property
    def Scripts_Events_OnDetectedCard(self) -> Scripts_Events_OnDetectedCard:
        """
        The Autoread scan (see Scripts/Events/OnScan) has detected a card that is not a ConfigCard. 
        
        The _default action_ for this event is to continue Autoread, i.e. to read the card based on the Autoread rules. Depending on the data stored on the card and the Autoread rules/blacklist/whitelist/match messages, one of the following scripts will be fired: 
        
          * Scripts/Events/OnAccepted
          * Scripts/Events/OnInvalidCard
          * Scripts/Events/OnBlackWhiteListDenied
          * Scripts/Events/OnMatchMsg
        
        
        
        **If you configure a custom action, it will replace the default action. To perform _both actions_ , you need to run the DefaultAction command.**
        """
        return Scripts_Events_OnDetectedCard(self)
    @property
    def Scripts_Events_OnMatchMsg(self) -> Scripts_Events_OnMatchMsg:
        """
        A card has been read by the Autoread functionality and the returned message matches one of the values stored in Scripts/StaticMessages/MatchMessage. 
        
        The _default action_ for this event is to send the message to the host. 
        
        **If you configure a custom action, it will replace the default action. To perform _both actions_ , you need to run the DefaultAction command.**
        """
        return Scripts_Events_OnMatchMsg(self)
    @property
    def Scripts_Events_OnAccepted(self) -> Scripts_Events_OnAccepted:
        """
        A card has been read by the Autoread functionality and the returned message matches none of the values stored in Scripts/StaticMessages/MatchMessage. 
        
        The _default action_ for this event is to send the message to the host. 
        
        **If you configure a custom action, it will replace the default action. To perform _both actions_ , you need to run the DefaultAction command.**
        """
        return Scripts_Events_OnAccepted(self)
    @property
    def Scripts_Events_OnInvalidCard(self) -> Scripts_Events_OnInvalidCard:
        """
        The detected card cannot be read by any of the Autoread rules.
        """
        return Scripts_Events_OnInvalidCard(self)
    @property
    def Scripts_Events_OnEnabledProtocol(self) -> Scripts_Events_OnEnabledProtocol:
        """
        If a host protocol is enabled (see Device/Run/EnabldeProtocols) this event is fired.
        """
        return Scripts_Events_OnEnabledProtocol(self)
    @property
    def Scripts_Events_OnBlackWhiteListDenied(self) -> Scripts_Events_OnBlackWhiteListDenied:
        """
        A card is denied by the blacklist or whitelist stored in the reader configuration (see Custom/BlackWhiteList subkey). 
        
        The _default action_ for this event is to deny the card. 
        
        **If you configure a custom action, it will replace the default action, i.e. the card will be accepted and sent to the host ( Scripts/Events/OnAccepted will be called). To perform the custom action _and_ deny the card, you need to run the DefaultAction command.**
        """
        return Scripts_Events_OnBlackWhiteListDenied(self)
    @property
    def Scripts_Events_OnSetGreenLed(self) -> Scripts_Events_OnSetGreenLed:
        """
        The green LED has been enabled by a custom protocol command. 
        
        The _default action_ for this event is to physically enable the green LED. 
        
        **If you configure a custom action, it will replace the default action. To perform _both actions_ , you need to run the DefaultAction command.**
        """
        return Scripts_Events_OnSetGreenLed(self)
    @property
    def Scripts_Events_OnSetRedLed(self) -> Scripts_Events_OnSetRedLed:
        """
        The red LED has been enabled by a custom protocol command. 
        
        The _default action_ for this event is to physically enable the red LED. 
        
        **If you configure a custom action, it will replace the default action. To perform _both actions_ , you need to run the DefaultAction command.**
        """
        return Scripts_Events_OnSetRedLed(self)
    @property
    def Scripts_Events_OnSetBeeper(self) -> Scripts_Events_OnSetBeeper:
        """
        The beeper has been enabled by a custom protocol command. 
        
        The _default action_ for this event is to physically enable the beeper. 
        
        **If you configure a custom action, it will replace the default action. To perform _both actions_ , you need to run the DefaultAction command.**
        """
        return Scripts_Events_OnSetBeeper(self)
    @property
    def Scripts_Events_OnSetRelay(self) -> Scripts_Events_OnSetRelay:
        """
        The relay has been enabled by a custom protocol command. 
        
        The _default action_ for this event is to physically enable the relay. 
        
        **If you configure a custom action, it will replace the default action. To perform _both actions_ , you need to run the DefaultAction command.**
        """
        return Scripts_Events_OnSetRelay(self)
    @property
    def Scripts_Events_OnSetBlueLed(self) -> Scripts_Events_OnSetBlueLed:
        """
        The blue LED has been enabled by a custom protocol command. 
        
        The _default action_ for this event is to physically enable the blue LED. 
        
        **If you configure a custom action, it will replace the default action. To perform _both actions_ , you need to run the DefaultAction command.**
        """
        return Scripts_Events_OnSetBlueLed(self)
    @property
    def Scripts_Events_OnClearGreenLed(self) -> Scripts_Events_OnClearGreenLed:
        """
        The green LED has been disabled by a custom protocol command. 
        
        The _default action_ for this event is to physically disable the green LED. 
        
        **If you configure a custom action, it will replace the default action. To perform _both actions_ , you need to run the DefaultAction command.**
        """
        return Scripts_Events_OnClearGreenLed(self)
    @property
    def Scripts_Events_OnClearRedLed(self) -> Scripts_Events_OnClearRedLed:
        """
        The red LED has been disabled by a custom protocol command. 
        
        The _default action_ for this event is to physically disable the red LED. 
        
        **If you configure a custom action, it will replace the default action. To perform _both actions_ , you need to run the DefaultAction command.**
        """
        return Scripts_Events_OnClearRedLed(self)
    @property
    def Scripts_Events_OnClearBeeper(self) -> Scripts_Events_OnClearBeeper:
        """
        The beeper has been disabled by a custom protocol command. 
        
        The _default action_ for this event is to physically disable the beeper. 
        
        **If you configure a custom action, it will replace the default action. To perform _both actions_ , you need to run the DefaultAction command.**
        """
        return Scripts_Events_OnClearBeeper(self)
    @property
    def Scripts_Events_OnClearRelay(self) -> Scripts_Events_OnClearRelay:
        """
        The relay has been disabled by a custom protocol command. 
        
        The _default action_ for this event is to physically disable the relay. 
        
        **If you configure a custom action, it will replace the default action. To perform _both actions_ , you need to run the DefaultAction command.**
        """
        return Scripts_Events_OnClearRelay(self)
    @property
    def Scripts_Events_OnClearBlueLed(self) -> Scripts_Events_OnClearBlueLed:
        """
        The blue LED has been disabled by a custom protocol command. 
        
        The _default action_ for this event is to physically disable the blue LED. 
        
        **If you configure a custom action, it will replace the default action. To perform _both actions_ , you need to run the DefaultAction command.**
        """
        return Scripts_Events_OnClearBlueLed(self)
    @property
    def Scripts_Events_OnTimer(self) -> Scripts_Events_OnTimer:
        """
        Is fired when a timer that was setup by _SetTimer_ (see BaltechScripts Commands) expired. Before firing the timer it will be deleted. To run a timer continuously it has to be setup again within this event.
        """
        return Scripts_Events_OnTimer(self)
    @property
    def Scripts_Events_OnConfigCardSucceeded(self) -> Scripts_Events_OnConfigCardSucceeded:
        """
        The reader has been reconfigured with a ConfigCard and reset. 
        
        The _default action_ for this event is to emit the following feedback to the card holder: 
        
          * Beeper beeps for 0.7 seconds.
          * Green LED is on for 6 seconds.
        
        
        
        **If you configure a custom action, it will replace the default action. To perform _both actions_ , you need to run the DefaultAction command.**
        """
        return Scripts_Events_OnConfigCardSucceeded(self)
    @property
    def Scripts_Events_OnConfigCardFailed(self) -> Scripts_Events_OnConfigCardFailed:
        """
        Reconfiguring the reader with a ConfigCard has failed. 
        
        The _default action_ for this event is to emit the following feedback to the card holder: 
        
          * Beeper beeps 7-9 times depending on error type, 0.1 seconds each. 
          * Red LED is on for 6 seconds.
        
        
        
        **If you configure a custom action, it will replace the default action. To perform _both actions_ , you need to run the DefaultAction command.**
        """
        return Scripts_Events_OnConfigCardFailed(self)
    @property
    def Scripts_Events_OnPowerup(self) -> Scripts_Events_OnPowerup:
        """
        If the reader was powered or got any kind of reset it will emit this event after everything is initialized.
        """
        return Scripts_Events_OnPowerup(self)
    @property
    def Scripts_Events_OnAutoreadEnabled(self) -> Scripts_Events_OnAutoreadEnabled:
        """
        When the autoread is enabled (either on powerup via configuration or during runtime via host command AR.SetMode() ) this event is triggered.
        """
        return Scripts_Events_OnAutoreadEnabled(self)
    @property
    def Scripts_Events_OnAutoreadDisabled(self) -> Scripts_Events_OnAutoreadDisabled:
        """
        When the autoread is disabled via host command AR.SetMode() this event is triggered.
        """
        return Scripts_Events_OnAutoreadDisabled(self)
    @property
    def Scripts_Events_OnScan(self) -> Scripts_Events_OnScan:
        """
        This event is fired _before_ every card scan. Autoread waits at least 50 ms between 2 card scans; however, depending on the card system, this delay may increase up to a multiple of 100 ms. 
        
        The _default action_ for this event is to scan the card. Depending on the scan result, one of the following events will be fired afterwards: 
        
          * Scripts/Events/OnDetectedNoCard
          * Scripts/Events/OnConfigCardSucceeded
          * Scripts/Events/OnConfigCardFailed
          * Scripts/Events/OnDetectedCard
        
        
        
        **If you configure a custom action, it will replace the default action. To perform _both actions_ , you need to run the DefaultAction command.**
        """
        return Scripts_Events_OnScan(self)
    @property
    def Scripts_Events_OnDetectedNoCard(self) -> Scripts_Events_OnDetectedNoCard:
        """
        Once all cards detected by the reader have been processed, this event is fired to indicate that there are no more cards. 
        
        **This event does not indicate that there are no cards _in front of the reader_ . It only means that there are no more _unprocessed cards_ .**
        """
        return Scripts_Events_OnDetectedNoCard(self)
    @property
    def Scripts_Events_OnCheckSuppressRepeat(self) -> Scripts_Events_OnCheckSuppressRepeat:
        """
        The reader has detected the same card again during the RepeatMessageDelay interval, while RepeatMessageMode is set to _Suppress_. 
        
        The _default action_ for this event is to suppress a message from being sent to the host. As a result, the host will only be notified about the first detection of the card. 
        
        **If you configure a custom action, it will replace the default action: You'll override _Suppress_ mode for this card presentation, i.e. the reader will send a message each time it detects the card. To perform the custom action _and_ keep _Suppress_ mode enabled, you need to run the DefaultAction command.**
        """
        return Scripts_Events_OnCheckSuppressRepeat(self)
    @property
    def Scripts_Events_OnBrpCommand(self) -> Scripts_Events_OnBrpCommand:
        """
        This event will be fired when the host sends any BRP command to the reader. It is usually used to ensure that the user is informed if the host communication gets lost.
        """
        return Scripts_Events_OnBrpCommand(self)
    @property
    def Scripts_Events_OnCardRemoved(self) -> Scripts_Events_OnCardRemoved:
        """
        This event will be fired when Autoread detects that a presented card has been removed. 
        
        **This event is only triggered if Device/Run/AutoreadWaitForCardRemoval is activated.**
        """
        return Scripts_Events_OnCardRemoved(self)
    @property
    def Scripts_Events_OnCardProcessed(self) -> Scripts_Events_OnCardProcessed:
        """
        This event will be fired by Autoread when a post-processing firmware module has processed the card successfully.
        """
        return Scripts_Events_OnCardProcessed(self)
    @property
    def Scripts_Events_OnCardAcceptedByHost(self) -> Scripts_Events_OnCardAcceptedByHost:
        """
        If the host has accepted the card number read in the last Autoread loop, the host may trigger this event via AR.RunScript. This indicates that the card number is included in the host's whitelist. The reader firmware, however, never directly executes this script. 
        
        In contrary to directly switching LEDs/beeper, using this event allows you to keep the UI definition in the reader configuration. See also Scripts.Events.OnCardDeniedByHost.
        """
        return Scripts_Events_OnCardAcceptedByHost(self)
    @property
    def Scripts_Events_OnCardDeniedByHost(self) -> Scripts_Events_OnCardDeniedByHost:
        """
        If the host has denied the card number read in the last Autoread loop, the host may trigger this event via AR.RunScript. This indicates that the card is not included in the host's whitelist. The reader firmware, however, never directly executes this script. 
        
        In contrary to directly switching LEDs/beeper, using this event allows you to keep the UI definition in the reader configuration. See also Scripts.Events.OnCardAcceptedByHost.
        """
        return Scripts_Events_OnCardDeniedByHost(self)
    @property
    def Device(self) -> Device:
        """
        This masterkey contains settings that influence the behaviour of the device.
        """
        return Device(self)
    @property
    def Device_Keypad(self) -> Device_Keypad:
        """
        When autoread functionality is activated the keyboard is used to enter PINs. Therefore an internal character buffer is available which collects all entered pins. This internal buffer will be send to the host as message of Messagetype "Keyboard" as soon as one of the following events occurs: 
        
          * A predefined number of digits was entered 
          * A special key that terminate keyboard entry was pressed 
          * A Timeout was exceeded during pin entry
        """
        return Device_Keypad(self)
    @property
    def Device_Keypad_SpecialKeySettings(self) -> Device_Keypad_SpecialKeySettings:
        """
        This value describes the behaviour of special keys like the star ('*') and the sharp ('#') keys.
        """
        return Device_Keypad_SpecialKeySettings(self)
    @property
    def Device_Keypad_Timeout(self) -> Device_Keypad_Timeout:
        """
        When pressing the first key of a PIN a timer is started. After "Timeout" seconds the internal character buffer will be transmitted to host and reset. If Timeout is 0xFF (which is not recommended) there is not timeout for pin entry. If this value is not defined 2 seconds will be used as default.
        """
        return Device_Keypad_Timeout(self)
    @property
    def Device_Keypad_PinLength(self) -> Device_Keypad_PinLength:
        """
        When more digits than specified in this value are entered within Device/Keypad/Timeout seconds the internal character buffer is send to the host and reset. If this value is not defined a 6 digits are used as default.
        """
        return Device_Keypad_PinLength(self)
    @property
    def Device_Keypad_KeyPressSignal(self) -> Device_Keypad_KeyPressSignal:
        """
        Specify the user feedback when a key is pressed.
        """
        return Device_Keypad_KeyPressSignal(self)
    @property
    def Device_Boot(self) -> Device_Boot:
        """
        This subkey configures how the devices shall behave during powerup.
        """
        return Device_Boot(self)
    @property
    def Device_Boot_FireInputEventAtPowerup(self) -> Device_Boot_FireInputEventAtPowerup:
        """
        Specifies under which condition the InputX line shall be fired at powerup.
        """
        return Device_Boot_FireInputEventAtPowerup(self)
    @property
    def Device_Boot_FireTamperEventAtPowerup(self) -> Device_Boot_FireTamperEventAtPowerup:
        """
        Specifies under which condition the Tamperalarm shall be fired at powerup.
        """
        return Device_Boot_FireTamperEventAtPowerup(self)
    @property
    def Device_Boot_FireGpioEventAtPowerup(self) -> Device_Boot_FireGpioEventAtPowerup:
        """
        Specifies under which condition the GpioX line shall be fired at powerup.
        """
        return Device_Boot_FireGpioEventAtPowerup(self)
    @property
    def Device_Boot_StartAutoreadAtPowerup(self) -> Device_Boot_StartAutoreadAtPowerup:
        """
        This value defines if Autoread functionality shall be started automatically at powerup of reader.
        """
        return Device_Boot_StartAutoreadAtPowerup(self)
    @property
    def Device_Boot_FirmwareCrcCheck(self) -> Device_Boot_FirmwareCrcCheck:
        """
        Every firmware is protected by a CRC. By default the firmware does a self test by calculating the CRC and verifying that it is correct. If the readers program memory is defect or the firwmare was not loaded completely/correctly this test will fail and the BootStatus bit 1 (=0x00000002) will be set.
        """
        return Device_Boot_FirmwareCrcCheck(self)
    @property
    def Device_Run(self) -> Device_Run:
        """
        Contains basic settings for operation of the device
        """
        return Device_Run(self)
    @property
    def Device_Run_ConfigCardAcceptTime(self) -> Device_Run_ConfigCardAcceptTime:
        """
        It is possible to restrict the acceptance of Configuration Cards in autoread mode to a defined time window after powerup. This value specifies the length of this time window in seconds. If it is set to 0, reconfiguration via Configuration Cards is disabled. If it is set to 255 (=the default value) reconfiguration via Configuraton Cards is not limited at all.
        """
        return Device_Run_ConfigCardAcceptTime(self)
    @property
    def Device_Run_EnabledProtocols(self) -> Device_Run_EnabledProtocols:
        """
        This is a list of all protocols that shall be active on powerup. Depending on the firmware variant there may be more activated protocols than listed here. If 2 protocols use the same physical interface, the latter one is the actual activated one. 
        
        **The protocols that are actually activated on powerup are not only determined by this configuration value, but also by Device/Run/EnableProtocolOnBAC , which defines the protocol that is enabled when a bus address has been set up via BALTECH AdrCard ( Device.Run.BusAdressByBAC32Bit ). This protocol overrides all competing protocols in the EnabledProtocols list which are running on the same physical interface.**
        """
        return Device_Run_EnabledProtocols(self)
    @property
    def Device_Run_AutoreadPulseHf(self) -> Device_Run_AutoreadPulseHf:
        """
        Specifies if HF shall be disabled between two scan cycles of the autoread functionality.
        """
        return Device_Run_AutoreadPulseHf(self)
    @property
    def Device_Run_RepeatMessageDelay(self) -> Device_Run_RepeatMessageDelay:
        """
        If RepeatMessageMode is set to another value than default, this time specifies the (minimum/maximum) delay between repeating a message in ms. 
        
        **Internally this value is handled as a multiple of AutoreadPollTime respectively the time one single poll cycle requires. As this value depends on the activated card types, the observed delay may deviate from the selected time value.**
        """
        return Device_Run_RepeatMessageDelay(self)
    @property
    def Device_Run_RepeatMessageMode(self) -> Device_Run_RepeatMessageMode:
        """
        In Autoread mode, the reader usually sends _one_ message per detected card to the host. However, you can change that behavior using this configuration value. You may want to do so in the following cases: 
        
          * In difficult environments, the reader may erroneously detect the same card several times during one presentation. In this case, you can _suppress_ additional messages from being sent to the host. 
          * If a card is presented longer, you may want more than one message to be sent to the host. In this case, you can _enforce_ a minimum amount of messages. 
        
        \\-
        """
        return Device_Run_RepeatMessageMode(self)
    @property
    def Device_Run_RestrictFirmwareRelease(self) -> Device_Run_RestrictFirmwareRelease:
        """
        In earlier firmware builds this value was used to restrict the firmware version that works with this configuration. Is replaced by Device/Run/FirmwareVersionBlacklist.
        """
        return Device_Run_RestrictFirmwareRelease(self)
    @property
    def Device_Run_EnableProtocolOnBAC(self) -> Device_Run_EnableProtocolOnBAC:
        """
        Specifies a (Bus-)protocol, that will be started as soon as a Baltech Address Card (BAC) is used to setup a bus address (see Device/Run/BusAdressByBAC32Bit)
        """
        return Device_Run_EnableProtocolOnBAC(self)
    @property
    def Device_Run_AccessRightsOfBAC(self) -> Device_Run_AccessRightsOfBAC:
        """
        Specifies the behavior of the reader if a BALTECH AdrCard (BAC) or an NFC device enabled for bus address setup is presented. 
        
        **When setting a bus address via NFC, also set the configuration value RequiresBusAddress to ensure a correct workflow of the upload software tool.**
        """
        return Device_Run_AccessRightsOfBAC(self)
    @property
    def Device_Run_FirmwareVersionBlacklist(self) -> Device_Run_FirmwareVersionBlacklist:
        """
        This value contains a list of blocked firmware versions. Every entry consists of the entries specified below and corresponds to a range of versions of a specific a firmware id.
        """
        return Device_Run_FirmwareVersionBlacklist(self)
    @property
    def Device_Run_DefaultBusAdrForBAC(self) -> Device_Run_DefaultBusAdrForBAC:
        """
        If a bus protocol is active and no bus address was set up via BALTECH AdrCard, this value indicates the address which is currently used by the protocol due to a protocol-specific address or a firmware default value. 
        
        **This value doesn't allow to configure a bus address. It is used internally by the firmware to report the bus address correctly when a BALTECH AdrCard is presented and should not be changed! Use Device/Run/BusAdressByBAC32Bit or the protocol-specific address configuration value to set up a bus address.**
        """
        return Device_Run_DefaultBusAdrForBAC(self)
    @property
    def Device_Run_MessageExpireTimeout(self) -> Device_Run_MessageExpireTimeout:
        """
        Specifies the time messages (i.e. card read) are retained for retrieval by host before they are thrown away (in 1/10 Seconds). 
        
        This timeout prevents ghost reads if the host fails to poll the reader for some time. 
        
        Setting this value to 0 will disable the timeout (message will not be thrown away automatically then)
        """
        return Device_Run_MessageExpireTimeout(self)
    @property
    def Device_Run_AutoreadPollTime(self) -> Device_Run_AutoreadPollTime:
        """
        This value specifies the minimum polling cycle time of the autoread functionality in ms. It defaults to 100 ms. 
        
        Along with Pulse Mode this value can be used to save energy by reducing the average power consumption of the reader. 
        
        **This value only guarantees a lower limit of the polling cycle time! The actual cycle time depends on number and type of the activated card systems and may be larger if no restrictions are configured. In case of a multi-frequency reader scanning for all supported card systems a single poll cycle may take around 500 ms.**
        """
        return Device_Run_AutoreadPollTime(self)
    @property
    def Device_Run_AuthReqUploadViaBrp(self) -> Device_Run_AuthReqUploadViaBrp:
        """
        Specifies the authentication level a BEC, BEC2, or BF3 file has to fulfill if the file is uploaded via BRP commands. 
        
        When uploading a BEC file, this value is a fallback if the parameter of Sys.CfgLoadPrepare is "Default".
        """
        return Device_Run_AuthReqUploadViaBrp(self)
    @property
    def Device_Run_AuthReqUploadViaIso14443(self) -> Device_Run_AuthReqUploadViaIso14443:
        """
        Specifies the authentication level a configuration, BEC2 or BF3 file has to fulfill if the file is uploaded via the reader's contactless radio interface using a ConfigCard or an NFC device.
        """
        return Device_Run_AuthReqUploadViaIso14443(self)
    @property
    def Device_Run_AutoreadWaitForCardRemoval(self) -> Device_Run_AutoreadWaitForCardRemoval:
        """
        Specifies if Autoread waits until a presented card has been removed before it continues scanning for further cards. 
        
        If this mode is enabled, the reader triggers the event Scripts/Events/OnCardRemoved whenever Autoread detects that a card has been removed. You can use this mode in combination with RepeatMessageMode Suppress to avoid that this event is triggered in case of short-term card removals of less than RepeatMessageDelay ms. 
        
        **You can't use this mode in combination with RepeatMessageMode Force .**
        """
        return Device_Run_AutoreadWaitForCardRemoval(self)
    @property
    def Device_Run_UsbVendorId(self) -> Device_Run_UsbVendorId:
        """
        Set this value to modify the VendorID of USB devices. 
        
        **Setting this value is very dangerous: Neither BALTECH ToolSuite nor the SDK can connect to a device via USB once its VendorID has been modified.**
        
        If you use firmware 1100, you need version 1.25.00 or above.
        """
        return Device_Run_UsbVendorId(self)
    @property
    def Device_Run_UsbProductId(self) -> Device_Run_UsbProductId:
        """
        Set this value to modify the ProductID of USB devices. 
        
        If you use firmware 1100, you need version 1.25.00 or above.
        """
        return Device_Run_UsbProductId(self)
    @property
    def Device_Run_DenyUploadViaIso14443(self) -> Device_Run_DenyUploadViaIso14443:
        """
        Deny/allow upload of BEC2 files via the reader's wireless RFID interface (ISO 14443-4) using a ConfigCard or an NFC device.
        """
        return Device_Run_DenyUploadViaIso14443(self)
    @property
    def Device_Run_DenyReaderInfoViaIso14443(self) -> Device_Run_DenyReaderInfoViaIso14443:
        """
        Deny/allow retrieval of general reader information via the reader's wireless RFID interface using an NFC device. 
        
        The reader information contains the reader's serial number, firmware version, boot status, and identifier as well as the name of the loaded project/device settings.
        """
        return Device_Run_DenyReaderInfoViaIso14443(self)
    @property
    def Device_Run_DenyUnauthFwUploadViaBrp(self) -> Device_Run_DenyUnauthFwUploadViaBrp:
        """
        Deny/allow firmware upload of BF2 and BF3 files via BRP. 
        
        If this value is set to "True", the upload of BF2 or BF3 files is denied as soon as the reader is secured by a Config Security Code. In this case, a firmware update can only be deployed when packaged with a configuration in a BEC2 file. Alternatively, a factory reset can be performed to reset the Config Security Code.
        """
        return Device_Run_DenyUnauthFwUploadViaBrp(self)
    @property
    def Device_Run_SetBusAdrOnUploadViaIso14443(self) -> Device_Run_SetBusAdrOnUploadViaIso14443:
        """
        Enable/disable the setup of a bus address along with a BEC2 file upload via the reader's wireless RFID interface. 
        
        If this feature is enabled, the reader requests the bus address from the host via APDU after a successful BEC2 file upload. The BEC2 file serves as an authorization for address setup. 
        
        **If you enable this feature, also set the configuration value RequiresBusAddress to ensure a correct workflow of the upload software tool.**
        """
        return Device_Run_SetBusAdrOnUploadViaIso14443(self)
    @property
    def Device_Run_MaintenanceFunctionFilter(self) -> Device_Run_MaintenanceFunctionFilter:
        """
        Disable individual maintenance functions that are triggered when the reader operates in Autoread mode and a maintenance function card (e.g. ConfigCard or LicenseCard) or an NFC device is presented.
        """
        return Device_Run_MaintenanceFunctionFilter(self)
    @property
    def Device_Run_BusAdressByBAC32Bit(self) -> Device_Run_BusAdressByBAC32Bit:
        """
        If the bus address of the reader is set via a BALTECH AdrCard (BAC) or via NFC, the address is stored within this configuration value. This address value works across all bus protocols - no DIP switch required. 
        
        This value is only for internal use. It is supported since firmware 1100 v2.20.00 and replaces BusAdressByBACLegacy.
        """
        return Device_Run_BusAdressByBAC32Bit(self)
    @property
    def Device_Run_ConfigCardMifareKey(self) -> Device_Run_ConfigCardMifareKey:
        """
        This value has to be set only if: 
        
          * The reader shall _not_ be configurable via Mifare Classic Configuration Cards (has to be set to empty value then) 
          * The reader shall be reconfigurable with Mifare Configuration Cards that is non-standard, but with a custom configuration card. 
        
        
        
        **This is a factory loaded key that will be restored automatically on reader reboot if deleted accidentally (see Device/Run/ConfigCardMifareKeyBackup ).**
        """
        return Device_Run_ConfigCardMifareKey(self)
    @property
    def Device_Run_ConfigSecurityCode(self) -> Device_Run_ConfigSecurityCode:
        """
        This value specifies the security code that is needed to reconfigure the reader via BALTECH ConfigCard or via an encrypted configuration file (BEC, BEC2). 
        
        **If this value is not set, the reader can be reconfigured by every configuration card.**
        """
        return Device_Run_ConfigSecurityCode(self)
    @property
    def Device_Run_CustomerKey(self) -> Device_Run_CustomerKey:
        """
        This value has to be set only if: 
        
          * The reader shall _not_ encrypt the content of the Configuration Card additionally to the cards crypto system (has to be set to empty value then) 
          * The reader shall be reconfigurable with Mifare Configuration Cards that are not created with configurator pack 001 (=Baltech Standard), but with a custom configurator pack. 
        
        
        
        **This is a factory loaded key that will be restored automatically on reader reboot if deleted accidentally (see Device/Run/CustomerKeyBackup ).**
        """
        return Device_Run_CustomerKey(self)
    @property
    def Device_Run_AltConfigSecurityCode(self) -> Device_Run_AltConfigSecurityCode:
        """
        This is an alternative ConfigSecurityCode. The reader will accept Configuration Cards with either of both values.
        """
        return Device_Run_AltConfigSecurityCode(self)
    @property
    def Device_Run_ConfigCardDesfireKey(self) -> Device_Run_ConfigCardDesfireKey:
        """
        This value has to be set only if: 
        
          * The reader shall _not_ be configurable via Mifare Desfire Configuration Cards (has to be set to empty value then) 
          * The reader shall be reconfigurable with Mifare Desfire Configuration Cards that are non-standard, but with a custom configuration card. 
        
        
        
        **This is a factory loaded key that will be retored automatically on reader reboot if deleted accidentally (see Device/Run/ConfigCardDesfireKeyBackup**
        """
        return Device_Run_ConfigCardDesfireKey(self)
    @property
    def Device_HostSecurity(self) -> Device_HostSecurity:
        """
        These values can be used to change the reader's security settings. They address both AES and PKI authentication and encryption. When the reader is rebooted the next time, the settings will be applied. 
        
        **These values are not only written to configuration memory but also extracted from ConfigEditor to be loaded via TLV block directly into security memory.**
        """
        return Device_HostSecurity(self)
    @property
    def Device_HostSecurity_AccessConditionMask(self) -> Device_HostSecurity_AccessConditionMask:
        """
        Defines an Access Condition Mask for every security Level. If the config value of a security Level is not set, it is not restricted at all. 
        
        **Level 3 has _always_ all access rights. No matter if there is a limitation via AcMask[3] or not.**
        """
        return Device_HostSecurity_AccessConditionMask(self)
    @property
    def Device_HostSecurity_Key(self) -> Device_HostSecurity_Key:
        """
        Defines a Key for every security Level. This key has to be used when working encrypted. 
        
        **Level 0 will never use keys, since it always works unencrypted.**
        """
        return Device_HostSecurity_Key(self)
    @property
    def Device_VirtualLeds(self) -> Device_VirtualLeds:
        """
        This key contains all settings related to Virtual LEDs (VLEDs). 
        
        A Virtual LED is a description for the behavior of one or more reader LEDs when being enabled via UI.Enable or BaltechScript. 
        
        You can enable VLEDs instantly without any delay. Alternatively, you can activate them gradually: In this case, the RGB color is increased in several steps until the desired color is obtained. When you deactivate a VLED, the inverse fading behavior is applied. You can configure this transition time globally for all VLEDs or define a certain value for each VLED individually. 
        
        There are static and dynamic VLEDs. A static VLED preserves a certain color until it is deactivated or a different VLED is activated. A dynamic or pulsing VLED continuously fades the RGB color between 2 values.
        """
        return Device_VirtualLeds(self)
    @property
    def Device_VirtualLeds_TransitionTime(self) -> Device_VirtualLeds_TransitionTime:
        """
        This value defines the default transition time in ms from off to the target RGB color or vice versa, when a VLED port is enabled or disabled. The value 0 enables/disables LEDs instantly. 
        
        This value is applied to every VLED if no individual transition time is specified in the corresponding VLED definition. 
        
        **This value is not applied to legacy LED ports (GreenLed/RedLed/BlueLed). To maintain backwards compatibility, these ports use transition time 0 as default. To override this value, define an individual transition time within the VLED definition .**
        """
        return Device_VirtualLeds_TransitionTime(self)
    @property
    def Device_VirtualLeds_PulsePeriod(self) -> Device_VirtualLeds_PulsePeriod:
        """
        This value defines the period in ms for pulsing VLEDs. This is the time to transition from the first to the second RGB color and back. 
        
        This value applies to any dynamic VLED definition.
        """
        return Device_VirtualLeds_PulsePeriod(self)
    @property
    def Device_VirtualLeds_CustomVledDefinition(self) -> Device_VirtualLeds_CustomVledDefinition:
        """
        Virtual LED (VLED) definitions describe how one or more LEDs are to be activated when the corresponding VLED port is enabled via UI.Enable or BaltechScript. 
        
        **The first 8 VLED definitions (0x40 - 0x47) are also used to maintain legacy compatibility. They're evaluated by the firmware in case a legacy LED port (GreenLed/RedLed/BlueLed) is switched. To avoid an undesired behavior, use either legacy _or_ VLED ports, but not both.**
        """
        return Device_VirtualLeds_CustomVledDefinition(self)
    @property
    def Custom(self) -> Custom:
        """
        This value contains configuration values for customer specific applications. Due to historical reasons some non-customer specific subkeys are nonetheless part of this masterkey.
        """
        return Custom(self)
    @property
    def Custom_BlackWhiteList(self) -> Custom_BlackWhiteList:
        """
        This subkey defines either whitelist or a blacklist for the autoread functionality. Every value read by autoread functionality will be checked against this list. It will be denied if it part of the list (blacklist) or not part of the list (whitelist). In the case of denial the Scripts/Events/OnBlackWhiteListDenied Event will be emitted.
        """
        return Custom_BlackWhiteList(self)
    @property
    def Custom_BlackWhiteList_ListMode(self) -> Custom_BlackWhiteList_ListMode:
        """
        Specifies if the list within this subkey shall be used as Black- or as Whitelist.
        """
        return Custom_BlackWhiteList_ListMode(self)
    @property
    def Custom_BlackWhiteList_RangeStart(self) -> Custom_BlackWhiteList_RangeStart:
        """
        If this value is specified, it defines a lower limit of accepted/denied values read by autoread functionality. It is intended mainly for Blacklistmode, where all values below this value are denied (In Whitelistmode all values below this value are accepted).
        """
        return Custom_BlackWhiteList_RangeStart(self)
    @property
    def Custom_BlackWhiteList_RangeEnd(self) -> Custom_BlackWhiteList_RangeEnd:
        """
        If this value is specified, it defines an upper limit of accepted/denied values read by autoread functionality. It is intended mainly for Blacklistmode, where all values higher than this value are denied (In Whitelistmode all values higher than this value are accepted).
        """
        return Custom_BlackWhiteList_RangeEnd(self)
    @property
    def Custom_BlackWhiteList_EntrySize(self) -> Custom_BlackWhiteList_EntrySize:
        """
        This value specifies the length of a entry in the Black-/Whitelist. All entries in this list have to be of the length specified here. Although this value can be omitted (in which case the length of the message returned by Autoread is assumed as entrysize), we strongly recommend you specify the size explicitly. 
        
        If the length of the value returned by Autoread does not match this value the smaller one is used as "comparison length". Only "comparson length" bytes (starting from the right) from the autoread number and the black-/whitelist entry are compared then.
        """
        return Custom_BlackWhiteList_EntrySize(self)
    @property
    def Custom_BlackWhiteList_List(self) -> Custom_BlackWhiteList_List:
        """
        This is a list of all values returned by autoread functionality that shall be denied (in Blacklistmode) or accepted (in Whitelistmode). 
        
        Every configuration value may contain multiple, concatenated autoread values. All autoread values stored in this list must be sorted ascending (the values within a configuration value as the values between configuration values). 
        
        ` If the autoread functionality returns a value of 4 byte length this would be a valid list: List[0] = "1111" "2222" "3333" List[1] = "4444" List[2] = "5555" "6666" `
        """
        return Custom_BlackWhiteList_List(self)
    @property
    def Custom_AdminData(self) -> Custom_AdminData:
        """
        Contains only values that are identifying and describing the rest of the configuration. These values do not have direct impact on the reader firmware behaviour. They are only used as storage for allowing configuration management software to set/get administrative information about the project/reader. 
        
        The configuration is split into two logical parts which are identifies by different fields: 
        
          * DeviceSettings: includes all configuration settings needed for host/user interaction 
          * ProjectSettings: includes all configuration settings describing the project card(s) like crypto-key, format of data, ... 
          * MasterCard: Mastercards are identified by these values. _Attention:_ non-mastercards will refer to a mastercard, too. The corresponding Values are called _MasterCardRef_ / _MasterCardNameRef_.
        """
        return Custom_AdminData(self)
    @property
    def Custom_AdminData_CustomerNo(self) -> Custom_AdminData_CustomerNo:
        """
        A unique Customer's ID. This are the first 5 digits of the ConfigID (12345-xxxx-xxxx-xx). The following ID ranges may be used  Range  |  Meaning   
        ---|---  
        00000  |  Only for standard configurations created by Baltech   
        0xxxx  |  Only for custom configurations created by Baltech   
        5xxxx  |  configurations created by Baltech's customers. The customers may use _xxxx_ to store their customers' id.   
        99999  |  ???
        """
        return Custom_AdminData_CustomerNo(self)
    @property
    def Custom_AdminData_DeviceSettingsNo(self) -> Custom_AdminData_DeviceSettingsNo:
        """
        Contains an ID that identifies the device settings in an unique manner. This are the 4 digits in the third block of the ConfigID (xxxxx-xxxx-1234-xx). The following ranges may be used  Range  |  Meaning   
        ---|---  
        00000  |  This value means, that _no_ device settings are stored in this configuration at all.   
        1000 - 4999  |  The device settings were created by Baltech   
        5xxx  |  The device settings were created by the customer. This implies that Baltech does not guarantee uniqueness of this value.   
        91xx  |  Dummybaseconfigurations (only for legacyprojects). They are not needed when working with ConfigEditor.   
        9999  |  ???
        """
        return Custom_AdminData_DeviceSettingsNo(self)
    @property
    def Custom_AdminData_DeviceSettingsName(self) -> Custom_AdminData_DeviceSettingsName:
        """
        A human readable description of the DeviceSettings
        """
        return Custom_AdminData_DeviceSettingsName(self)
    @property
    def Custom_AdminData_DeviceSettingsVersion(self) -> Custom_AdminData_DeviceSettingsVersion:
        """
        The version of the Devicesettings. Has to be incremented on every change on device specific settings by one.
        """
        return Custom_AdminData_DeviceSettingsVersion(self)
    @property
    def Custom_AdminData_ProjectSettingsNo(self) -> Custom_AdminData_ProjectSettingsNo:
        """
        Contains an ID that identifies the device settings in an unique manner. This are the 4 digits in the second block of the ConfigID (xxxxx-1234-xxxx-xx). This ID has to be unique within the same CustomerNo. By convention Value < 0500 are used by Baltech and Values > 0500 are used by Baltech's Customers.
        """
        return Custom_AdminData_ProjectSettingsNo(self)
    @property
    def Custom_AdminData_ProjectName(self) -> Custom_AdminData_ProjectName:
        """
        A human readable description of the ProjectSettings
        """
        return Custom_AdminData_ProjectName(self)
    @property
    def Custom_AdminData_ProjectSettingsVersion(self) -> Custom_AdminData_ProjectSettingsVersion:
        """
        The version of the Projectsettings. Has to be incremented on every change on project specific settings by one.
        """
        return Custom_AdminData_ProjectSettingsVersion(self)
    @property
    def Project(self) -> Project:
        """
        This masterkey contains all values specific to the RFID interface component apart from Autoread, VHL and ProjectRegisters.
        """
        return Project(self)
    @property
    def Project_VhlSettings(self) -> Project_VhlSettings:
        """
        Contains all non-File specific VHL settings
        """
        return Project_VhlSettings(self)
    @property
    def Project_VhlSettings_ScanCardFamilies(self) -> Project_VhlSettings_ScanCardFamilies:
        """
        Defines a bitsmask that is used by VHLSelect() to restrict the frequencies and HF-protocols that are polled. This can speed up the scanning. 
        
        **If not set this value defaults to 0xFFFF (=accept all card types) if neither Device/VhlSettings125Khz/ScanCardTypes , Project/VhlSettings125Khz/ScanCardTypesPart1 nor Project/VhlSettings125Khz/ScanCardTypesPart2 are set. In the latter case it defaults to _125Khz_ .**
        """
        return Project_VhlSettings_ScanCardFamilies(self)
    @property
    def Project_VhlSettings_ForceReselect(self) -> Project_VhlSettings_ForceReselect:
        """
        Setting this value to True enforces a Reselect on every VHLSelect.
        """
        return Project_VhlSettings_ForceReselect(self)
    @property
    def Project_VhlSettings_DelayRequestATS(self) -> Project_VhlSettings_DelayRequestATS:
        """
        Specifies the delay in ms that shall be waited after detecting an ISO14443 card and before requesting its ATS (Answer To Select).
        """
        return Project_VhlSettings_DelayRequestATS(self)
    @property
    def Project_VhlSettings_DelayPerformPPS(self) -> Project_VhlSettings_DelayPerformPPS:
        """
        Specifies the delay in ms that shall be waited after receiving the ATS of an ISO14443 card and before performing its PPS.
        """
        return Project_VhlSettings_DelayPerformPPS(self)
    @property
    def Project_VhlSettings_MaxBaudrateIso14443A(self) -> Project_VhlSettings_MaxBaudrateIso14443A:
        """
        When VHLSelect / autoread detects a Iso14443/A card it negotiates the send and the receive baudrate automatically. Usually it tries to communicate as fast as possible (that means as fast as the card is supporting). If the performance shall be limited (i.e. due to HF instabilities) this value can be used to set a Maximum value for DSI (=reader to card baudrate) and DRI (=card to reader baudrate).
        """
        return Project_VhlSettings_MaxBaudrateIso14443A(self)
    @property
    def Project_VhlSettings_MaxBaudrateIso14443B(self) -> Project_VhlSettings_MaxBaudrateIso14443B:
        """
        When VHLSelect / autoread detects a Iso14443/B card it negotiates the send and the receive baudrate automatically. Usually it tries to communicate as fast as possible (that means as fast as the card is supporting). If the performance shall be limited (i.e. due to HF instabilities) this value can be used to set a Maximum value for DSI (=reader to card baudrate) and DRI (=card to reader baudrate).
        """
        return Project_VhlSettings_MaxBaudrateIso14443B(self)
    @property
    def Project_VhlSettings_PrioritizeCardFamilies(self) -> Project_VhlSettings_PrioritizeCardFamilies:
        """
        This value provides a bitmask of card families that shall be prioritized by VHL.Select when more than one card is detected at same time. 
        
        The reader guarantees that in case of presenting multiple cards at once always the prioritized card families are returned first. 
        
        **If Autoread is used, CardFamilies in combination with PrioritizationMode should be used instead.**
        """
        return Project_VhlSettings_PrioritizeCardFamilies(self)
    @property
    def Project_VhlSettings_PrioritizationTriggeringCardFamilies(self) -> Project_VhlSettings_PrioritizationTriggeringCardFamilies:
        """
        This value defines the card families which trigger the prioritization mechanism. Only if the reader detects a card which belongs to one of the specified card families, it checks for a prioritized card which it would return instead of the originally detected card. 
        
        If this value is not set, the reader applies the prioritization mechanism to every detected card. Because the prioritization consumes additional time the processing speed can be optimized by defining this value and restricting the prioritization to the relevant cards only. 
        
        **If Autoread is used, this configuration value should be used instead.**
        """
        return Project_VhlSettings_PrioritizationTriggeringCardFamilies(self)
    @property
    def Project_VhlSettings_PrioritizeDelay(self) -> Project_VhlSettings_PrioritizeDelay:
        """
        Specifies the Time that shall be waited _after_ resetting the HF and _before_ scannning for prioritized card systems
        """
        return Project_VhlSettings_PrioritizeDelay(self)
    @property
    def Project_VhlSettings_ConfCardCardFamilies(self) -> Project_VhlSettings_ConfCardCardFamilies:
        """
        Specifies the card families that are scanned when searching for configuration cards. These card families will be scanned even if the corresponding card family is not included in Project.VhlSettings.ScanCardFamilies. In the latter case detected cards that are non-configuration cards are ignored.
        """
        return Project_VhlSettings_ConfCardCardFamilies(self)
    @property
    def Project_VhlSettings_Iso14aVasup(self) -> Project_VhlSettings_Iso14aVasup:
        """
        Specifies parameters for VASUP-A.
        """
        return Project_VhlSettings_Iso14aVasup(self)
    @property
    def Project_HidSam(self) -> Project_HidSam:
        """
        This subkey contains Hid SAM specific settings.
        """
        return Project_HidSam(self)
    @property
    def Project_HidSam_Confcard(self) -> Project_HidSam_Confcard:
        """
        Enables the reader to scan for HID configuration cards.
        """
        return Project_HidSam_Confcard(self)
    @property
    def Project_HidSam_ScanTime(self) -> Project_HidSam_ScanTime:
        """
        configures scan time for HID cards in ms after power up of the reader.
        """
        return Project_HidSam_ScanTime(self)
    @property
    def Project_HidSam_Retries(self) -> Project_HidSam_Retries:
        """
        retry counter for HID config cards
        """
        return Project_HidSam_Retries(self)
    @property
    def Project_VhlSettings125Khz(self) -> Project_VhlSettings125Khz:
        """
        Contains generic settings for 125kHz Reader that are working with VHL/Autoread.
        """
        return Project_VhlSettings125Khz(self)
    @property
    def Project_VhlSettings125Khz_ScanCardTypesPart1(self) -> Project_VhlSettings125Khz_ScanCardTypesPart1:
        """
        Defines a bitsmask that is used by VHLSelect() to restrict the HF-protocols that are polled. This can speed up the scanning. This is an extension to Project/VhlSettings/ScanCardFamilies.
        """
        return Project_VhlSettings125Khz_ScanCardTypesPart1(self)
    @property
    def Project_VhlSettings125Khz_ScanCardTypesPart2(self) -> Project_VhlSettings125Khz_ScanCardTypesPart2:
        """
        Defines a bitsmask that is used by VHLSelect() to restrict the HF-protocols that are polled. This can speed up the scanning. This is an extension to Project/VhlSettings/ScanCardFamilies.
        """
        return Project_VhlSettings125Khz_ScanCardTypesPart2(self)
    @property
    def Project_VhlSettings125Khz_TTFModType(self) -> Project_VhlSettings125Khz_TTFModType:
        """
        This value specifies the modulation type for the TTF card type.
        """
        return Project_VhlSettings125Khz_TTFModType(self)
    @property
    def Project_VhlSettings125Khz_TTFBaudrate(self) -> Project_VhlSettings125Khz_TTFBaudrate:
        """
        This value specifies the baud rate for the TTF card type. Currently, this value is only used for EM4100 cards.
        """
        return Project_VhlSettings125Khz_TTFBaudrate(self)
    @property
    def Project_VhlSettings125Khz_TTFHeaderLength(self) -> Project_VhlSettings125Khz_TTFHeaderLength:
        """
        Specifies the pattern length in bit, the reader searches for.
        """
        return Project_VhlSettings125Khz_TTFHeaderLength(self)
    @property
    def Project_VhlSettings125Khz_TTFHeader(self) -> Project_VhlSettings125Khz_TTFHeader:
        """
        Pattern which has to match to read a card successfully. The pattern length is specified by Project/VhlSettings125Khz/TTFHeaderLength.
        """
        return Project_VhlSettings125Khz_TTFHeader(self)
    @property
    def Project_VhlSettings125Khz_TTFDataLength(self) -> Project_VhlSettings125Khz_TTFDataLength:
        """
        Card data length (includes also Pattern Length) to read.
        """
        return Project_VhlSettings125Khz_TTFDataLength(self)
    @property
    def Project_VhlSettings125Khz_TTFOkCounter(self) -> Project_VhlSettings125Khz_TTFOkCounter:
        """
        Number of consecutive successfully reads until a card searched by a pattern is reported as detected by VHL.
        """
        return Project_VhlSettings125Khz_TTFOkCounter(self)
    @property
    def Project_VhlSettings125Khz_IndaspDecode(self) -> Project_VhlSettings125Khz_IndaspDecode:
        """
        This value refers to a template for the data converter. It converts the raw data stream of Indala asp cards to a 26 bit wiegand format. Always 5 bytes are expected: Byte 0 and byte 4 contain the Wiegand parity bit, byte 1 the site code and byte 2/3 the serial number (MSByte first). (Baltech internal documentation: jira:EQT-229)
        """
        return Project_VhlSettings125Khz_IndaspDecode(self)
    @property
    def Project_VhlSettings125Khz_IndaspParityCheck(self) -> Project_VhlSettings125Khz_IndaspParityCheck:
        """
        This value disables parity checking of the 26 bit indala wiegand format. Parity checking is done after processing the template defined by Project/VhlSettings125Khz/IndaspDecode.
        """
        return Project_VhlSettings125Khz_IndaspParityCheck(self)
    @property
    def Project_VhlSettings125Khz_TTFReadStartpos(self) -> Project_VhlSettings125Khz_TTFReadStartpos:
        """
        Specifies Startbitposition of TTF bitstream.
        """
        return Project_VhlSettings125Khz_TTFReadStartpos(self)
    @property
    def Project_VhlSettings125Khz_HidProxSerialNrFormat(self) -> Project_VhlSettings125Khz_HidProxSerialNrFormat:
        """
        This value specifies the format that shall be used when the SerialNumber of a HID Prox card is returned via VhlGetSnr(). 
        
        **The default value for this settings has changed. In Firmware released until 02/2014 the defaultvalue when _not_ specifying this value was _McmCompatible_ .**
        """
        return Project_VhlSettings125Khz_HidProxSerialNrFormat(self)
    @property
    def Project_VhlSettings125Khz_ModType(self) -> Project_VhlSettings125Khz_ModType:
        """
        This value specifies the modulation type for some cards. Currently, this value is only used for EM4205 cards.
        """
        return Project_VhlSettings125Khz_ModType(self)
    @property
    def Project_VhlSettings125Khz_BaudRate(self) -> Project_VhlSettings125Khz_BaudRate:
        """
        This value specifies the baud rate for some cards. Currently, this value is only used for EM4100 / 4205 cards.
        """
        return Project_VhlSettings125Khz_BaudRate(self)
    @property
    def Project_VhlSettings125Khz_SnrVersionCotag(self) -> Project_VhlSettings125Khz_SnrVersionCotag:
        """
        Value allows several serial number versions.
        """
        return Project_VhlSettings125Khz_SnrVersionCotag(self)
    @property
    def Project_VhlSettings125Khz_SnrVersionIdteck(self) -> Project_VhlSettings125Khz_SnrVersionIdteck:
        """
        Value allows several serial number versions
        """
        return Project_VhlSettings125Khz_SnrVersionIdteck(self)
    @property
    def Project_VhlSettings125Khz_EM4100SerialNrFormat(self) -> Project_VhlSettings125Khz_EM4100SerialNrFormat:
        """
        This value specifies the format that shall be used when the SerialNumber of a EM 4100 card is returned via VhlGetSnr().
        """
        return Project_VhlSettings125Khz_EM4100SerialNrFormat(self)
    @property
    def Project_VhlSettings125Khz_AwidSerialNrFormat(self) -> Project_VhlSettings125Khz_AwidSerialNrFormat:
        """
        This value specifies the format that shall be used when the SerialNumber of a Awid card is returned via VhlGetSnr().
        """
        return Project_VhlSettings125Khz_AwidSerialNrFormat(self)
    @property
    def Project_VhlSettings125Khz_IoProxSerialNrFormat(self) -> Project_VhlSettings125Khz_IoProxSerialNrFormat:
        """
        This value specifies the format that shall be used when the SerialNumber of a IoProx card is returned via VHL.GetSnr.
        """
        return Project_VhlSettings125Khz_IoProxSerialNrFormat(self)
    @property
    def Project_VhlSettings125Khz_PyramidSerialNrFormat(self) -> Project_VhlSettings125Khz_PyramidSerialNrFormat:
        """
        This value specifies the format that shall be used when the serial number of a Farpointe Pyramid card is returned via VHL.GetSnr.
        """
        return Project_VhlSettings125Khz_PyramidSerialNrFormat(self)
    @property
    def Project_VhlSettings125Khz_ObidCardIdFormat(self) -> Project_VhlSettings125Khz_ObidCardIdFormat:
        """
        This value specifies the format to use when the programmed card number (PCN) of Hitag 1 cards with OBID encoding is retrieved via VHL.Read.
        """
        return Project_VhlSettings125Khz_ObidCardIdFormat(self)
    @property
    def Project_SamAVx(self) -> Project_SamAVx:
        """
        Desfire AVx SAM specific configuration values
        """
        return Project_SamAVx(self)
    @property
    def Project_SamAVx_PowerUpState(self) -> Project_SamAVx_PowerUpState:
        """
        SAM Keyidx to unlock SAM.
        """
        return Project_SamAVx_PowerUpState(self)
    @property
    def Project_SamAVx_UnlockKeyNr(self) -> Project_SamAVx_UnlockKeyNr:
        """
        SAM Key number of the unlock key.
        """
        return Project_SamAVx_UnlockKeyNr(self)
    @property
    def Project_SamAVx_UnlockKeyVersion(self) -> Project_SamAVx_UnlockKeyVersion:
        """
        SAM key version of the unlock key.
        """
        return Project_SamAVx_UnlockKeyVersion(self)
    @property
    def Project_SamAVx_UnlockKeyCryptoMemoryIdx(self) -> Project_SamAVx_UnlockKeyCryptoMemoryIdx:
        """
        Keyindex to the project crypto memory to unlock the SAM
        """
        return Project_SamAVx_UnlockKeyCryptoMemoryIdx(self)
    @property
    def Project_SamAVx_AuthKeyNr(self) -> Project_SamAVx_AuthKeyNr:
        """
        SAM Key number to authenticate SAM.
        """
        return Project_SamAVx_AuthKeyNr(self)
    @property
    def Project_SamAVx_AuthKeyVersion(self) -> Project_SamAVx_AuthKeyVersion:
        """
        SAM key version of the authentication key.
        """
        return Project_SamAVx_AuthKeyVersion(self)
    @property
    def Project_SamAVx_AuthKeyCryptoMemoryIdx(self) -> Project_SamAVx_AuthKeyCryptoMemoryIdx:
        """
        Keyindex to the project crypto memory to authenticate the SAM
        """
        return Project_SamAVx_AuthKeyCryptoMemoryIdx(self)
    @property
    def Project_SamAVx_SecureMessaging(self) -> Project_SamAVx_SecureMessaging:
        """
        SAM secure messaging mode
        """
        return Project_SamAVx_SecureMessaging(self)
    @property
    def Project_SamAVx_LogicalChannel(self) -> Project_SamAVx_LogicalChannel:
        """
        This value defines the logical channel used for card communication.
        """
        return Project_SamAVx_LogicalChannel(self)
    @property
    def Project_SamAVx_AnswerToReset(self) -> Project_SamAVx_AnswerToReset:
        """
        This value defines the SAM's Answer to Reset (ATR) for a certain slot.
        """
        return Project_SamAVx_AnswerToReset(self)
    @property
    def Project_CryptoKey(self) -> Project_CryptoKey:
        """
        Key container used by the crypto manager for crypto operations.
        """
        return Project_CryptoKey(self)
    @property
    def Project_CryptoKey_Entry(self) -> Project_CryptoKey_Entry:
        """
        Key entry which contains a key and its according CryptoOptions with KeyAccessRights used by the crypto manager.
        """
        return Project_CryptoKey_Entry(self)
    @property
    def Project_DiversificationData(self) -> Project_DiversificationData:
        """
        Data converter rules for diversification data generation
        """
        return Project_DiversificationData(self)
    @property
    def Project_DiversificationData_Entry(self) -> Project_DiversificationData_Entry:
        """
        Entry contains a rule processed by the data converter. For card number generation only SerialNumber is supported.
        """
        return Project_DiversificationData_Entry(self)
    @property
    def Project_SamAVxKeySettings(self) -> Project_SamAVxKeySettings:
        """
        Extensions for AV2/3 SAM key entries
        """
        return Project_SamAVxKeySettings(self)
    @property
    def Project_SamAVxKeySettings_Index(self) -> Project_SamAVxKeySettings_Index:
        """
        This entry expands a sam key index about additional diversification settings.
        """
        return Project_SamAVxKeySettings_Index(self)
    @property
    def Project_LegicKeySettings(self) -> Project_LegicKeySettings:
        """
        Settings for keys stored in LEGIC reader chip
        """
        return Project_LegicKeySettings(self)
    @property
    def Project_LegicKeySettings_Index(self) -> Project_LegicKeySettings_Index:
        """
        Each entry corresponds to a slot in the key storage of the LEGIC reader chip (SM4x00/SM6300).
        """
        return Project_LegicKeySettings_Index(self)
    @property
    def Project_LegicVcp(self) -> Project_LegicVcp:
        """
        Values required for LEGIC VCP file handling 
        
        VCP (Versatile Configuration Package) files are used to transfer card keys securely into the key storage of the LEGIC reader chip. There are different VCP files for LEGIC 4000 series (SM-4x00) and for LEGIC 6000 series (SM-6300), which are stored in separate configuration values. The reader firmware transfers the appropriate VCP file into the LEGIC reader chip at the next startup and deletes all files from configuration memory afterward. 
        
        **This feature is supported starting with firmware 1100 v2.20.00.**
        """
        return Project_LegicVcp(self)
    @property
    def Project_LegicVcp_Status(self) -> Project_LegicVcp_Status:
        """
        This value indicates the status of the VCP file transfer.
        """
        return Project_LegicVcp_Status(self)
    @property
    def Project_LegicVcp_VcpKeyIndex(self) -> Project_LegicVcp_VcpKeyIndex:
        """
        This value defines the key storage index for the user VCP key.
        """
        return Project_LegicVcp_VcpKeyIndex(self)
    @property
    def Project_LegicVcp_VcpFile4000Hash(self) -> Project_LegicVcp_VcpFile4000Hash:
        """
        Hash value of the VCP file for LEGIC 4000 series (SM-4x00). Allows for identifying the file content after the file is deleted from the configuration.
        """
        return Project_LegicVcp_VcpFile4000Hash(self)
    @property
    def Project_LegicVcp_VcpFile4000Data(self) -> Project_LegicVcp_VcpFile4000Data:
        """
        These values define the VCP file for LEGIC 4000 series (SM-4x00).
        """
        return Project_LegicVcp_VcpFile4000Data(self)
    @property
    def Project_LegicVcp_VcpFile6000Hash(self) -> Project_LegicVcp_VcpFile6000Hash:
        """
        Hash value of the VCP file for LEGIC 6000 series (SM-6300). Allows for identifying the file content after the file is deleted from the configuration.
        """
        return Project_LegicVcp_VcpFile6000Hash(self)
    @property
    def Project_LegicVcp_VcpFile6000Data(self) -> Project_LegicVcp_VcpFile6000Data:
        """
        These values define the VCP file for LEGIC 6000 series (SM-6300).
        """
        return Project_LegicVcp_VcpFile6000Data(self)
    @property
    def Project_LegicVcp_Password(self) -> Project_LegicVcp_Password:
        """
        This value defines the password required to load a password-protected VCP file.
        """
        return Project_LegicVcp_Password(self)
    @property
    def Project_MobileId(self) -> Project_MobileId:
        """
        This key contains values that allow you to set up the Mobile ID functionality to read Mobile ID credentials using Autoread.
        """
        return Project_MobileId(self)
    @property
    def Project_MobileId_Mode(self) -> Project_MobileId_Mode:
        """
        This value enables/disables Mobile ID within Autoread.
        """
        return Project_MobileId_Mode(self)
    @property
    def Project_MobileId_DisplayName(self) -> Project_MobileId_DisplayName:
        """
        This value defines a human-readable name of the reader (ASCII string), which is reported to the Mobile ID app directly after the connection is established. 
        
        The value may be used in combination with the Trigger from Distance capability. Displayed on the mobile device, the name allows the user to identify the reader to be triggered at the touch af a button. 
        
        **The name can be a maximum of 48 characters long.**
        """
        return Project_MobileId_DisplayName(self)
    @property
    def Project_MobileId_TriggerFromDistance(self) -> Project_MobileId_TriggerFromDistance:
        """
        This value indicates if the reader can be triggered from a distance, i.e. by a trigger moment other than sufficient proximity to the reader (RSSI). It corresponds to the _Remote_ option in the _User Interaction_ dropdown in the Mobile ID configuration component in BALTECH ConfigEditor. 
        
        The Trigger from Distance capability is reported to the Mobile ID app after the connection is established. If set, the app may use this information to define its own trigger moment, e.g. a button press by the user.
        """
        return Project_MobileId_TriggerFromDistance(self)
    @property
    def Project_MobileId_ConvenientAccess(self) -> Project_MobileId_ConvenientAccess:
        """
        This value indicates if the reader supports the Convenient Access capability of Mobile ID. If enabled, the reader can be triggered with the phone left in the pocket. This value corresponds to the _Convenient_ option in the _User Interaction_ dropdown in the Mobile ID configuration component in BALTECH ConfigEditor.
        """
        return Project_MobileId_ConvenientAccess(self)
    @property
    def Project_MobileId_AdvertisementFilter(self) -> Project_MobileId_AdvertisementFilter:
        """
        This value enables/disables the advertisement filter of the Mobile ID protocol. The filter ensures that only devices are processed that send advertisement data containing the Mobile ID service UUID or manufacturer-specific data with the Apple company ID (0x004C). 
        
        **The advertisement filter is only applied to devices with an RSSI below the activation threshold. The filter is overridden if the RSSI exceeds this threshold.**
        """
        return Project_MobileId_AdvertisementFilter(self)
    @property
    def Project_MobileId_RssiCorrectionConvenientAccess(self) -> Project_MobileId_RssiCorrectionConvenientAccess:
        """
        This is an RSSI offset that will be taken into account to compensate reader model/environment-specific variations in Convenient Access mode.
        """
        return Project_MobileId_RssiCorrectionConvenientAccess(self)
    @property
    def Project_MobileId_DetectionRssiFilter(self) -> Project_MobileId_DetectionRssiFilter:
        """
        This value enables/disables the detection RSSI filter of the Mobile ID protocol. The filter ensures that only devices are processed that exceed a minimum RSSI dependent on the reader model.
        """
        return Project_MobileId_DetectionRssiFilter(self)
    @property
    def Project_MobileId_RssiOffset(self) -> Project_MobileId_RssiOffset:
        """
        This offset is added to the RSSI measurement results produced by the Mobile ID firmware implementation. It can be used to adjust the trigger distance.
        """
        return Project_MobileId_RssiOffset(self)
    @property
    def Project_MobileId_MsgType(self) -> Project_MobileId_MsgType:
        """
        This value defines the message type that the command AR.GetMessage returns when a Mobile ID credential is detected.
        """
        return Project_MobileId_MsgType(self)
    @property
    def Project_MobileId_OnMatchEvent(self) -> Project_MobileId_OnMatchEvent:
        """
        This event is fired when a Mobile ID credential is presented. If the script that is executed on this event contains a _DefaultAction_ , one of the following events will be fired subsequently: 
        
          * OnAccepted
          * OnMatchMsg[X]
          * OnInvalidCard
        
        
        
        **If the script contains no _DefaultAction_ , the events listed above will be omitted.**
        """
        return Project_MobileId_OnMatchEvent(self)
    @property
    def Project_MobileId_Template(self) -> Project_MobileId_Template:
        """
        These templates can be used to convert a credential ID received from a Mobile ID device to the desired format. Each template corresponds to a Mobile ID project defined by its encryption key.
        """
        return Project_MobileId_Template(self)
    @property
    def Project_MobileId_Key(self) -> Project_MobileId_Key:
        """
        These values define a list of one or more project-specific Mobile ID encryption keys.
        """
        return Project_MobileId_Key(self)
    @property
    def Protocols(self) -> Protocols:
        """
        This key contains all host protocol specific settings. Every subkey is for a specific protocol.
        """
        return Protocols(self)
    @property
    def Protocols_BrpSerial(self) -> Protocols_BrpSerial:
        """
        Specifies all Values than can be used to parametrize the BRP over Serial protocol. BRP over Serial includes data transfer via RS-232/UART and via USB using a Virtual-COM-Port driver at the host PC.
        """
        return Protocols_BrpSerial(self)
    @property
    def Protocols_BrpSerial_Baudrate(self) -> Protocols_BrpSerial_Baudrate:
        """
        Define the Data transfer speed in 100 bits per second
        """
        return Protocols_BrpSerial_Baudrate(self)
    @property
    def Protocols_BrpSerial_Parity(self) -> Protocols_BrpSerial_Parity:
        """
        Define if a parity bit shall be used to ensure correctness of transfer data and if so, what type of parity bits shall be used.
        """
        return Protocols_BrpSerial_Parity(self)
    @property
    def Protocols_BrpSerial_InterbyteTimeout(self) -> Protocols_BrpSerial_InterbyteTimeout:
        """
        Specifies the maximum time in ms which may elapse between two bytes within the same frame. 
        
        Two value formats are supported: 8-bit is the legacy format. For new projects 16-bit values should be used.
        """
        return Protocols_BrpSerial_InterbyteTimeout(self)
    @property
    def Protocols_BrpSerial_CmdWorkInterval(self) -> Protocols_BrpSerial_CmdWorkInterval:
        """
        Time in ms between 2 CMD_WORK messages if a BRP command is executed in continuous or repeat mode. 
        
        When this value is set to 0xFFFF (default), no CMD_WORK message is sent until the command is finished.
        """
        return Protocols_BrpSerial_CmdWorkInterval(self)
    @property
    def Protocols_BrpSerial_RepeatModeMinDelay(self) -> Protocols_BrpSerial_RepeatModeMinDelay:
        """
        This value specifies the minimum time in ms between two responses sent in repeat mode. If not set, a default of 100ms is assumed.
        """
        return Protocols_BrpSerial_RepeatModeMinDelay(self)
    @property
    def Protocols_BrpSerial_HostMsgFormatTemplate(self) -> Protocols_BrpSerial_HostMsgFormatTemplate:
        """
        Specifies the way the ascii decimal number read from the card by autoread shall be converted to the lowlevel format needed by this protocol.
        """
        return Protocols_BrpSerial_HostMsgFormatTemplate(self)
    @property
    def Protocols_BrpSerial_AutoRunCommand(self) -> Protocols_BrpSerial_AutoRunCommand:
        """
        A list of BRP command frames that shall be executed automatically at powerup (including sending their responses to the host) before starting with normal operation. 
        
        **These commands are executed in order (_first_ StartupRunCmd[0],_then_ StartupRunCmd[1], ...) until the first index without corresponding StartupRunCmd value.**
        """
        return Protocols_BrpSerial_AutoRunCommand(self)
    @property
    def Protocols_BrpHid(self) -> Protocols_BrpHid:
        """
        USB Protocol that tunnels BRP over the Human Interface Protocol specified at usb.org (see http://en.wikipedia.org/wiki/Human_interface_device). For a detailed spec how BRP frames are packed into HID frames see BRP.pdf
        """
        return Protocols_BrpHid(self)
    @property
    def Protocols_BrpHid_CmdWorkInterval(self) -> Protocols_BrpHid_CmdWorkInterval:
        """
        Time in ms between 2 CMD_WORK messages if a BRP command is executed in continuous or repeat mode. 
        
        When this value is set to 0xFFFF (default), no CMD_WORK message is sent until the command is finished.
        """
        return Protocols_BrpHid_CmdWorkInterval(self)
    @property
    def Protocols_BrpHid_RepeatModeMinDelay(self) -> Protocols_BrpHid_RepeatModeMinDelay:
        """
        This value specifies the minimum time in ms between two responses sent in repeat mode. If not set, a default of 100ms is assumed.
        """
        return Protocols_BrpHid_RepeatModeMinDelay(self)
    @property
    def Protocols_BrpHid_UsbVendorName(self) -> Protocols_BrpHid_UsbVendorName:
        """
        This is the USB Vendor Name that the device reports to the USB host.
        """
        return Protocols_BrpHid_UsbVendorName(self)
    @property
    def Protocols_BrpHid_UsbProductName(self) -> Protocols_BrpHid_UsbProductName:
        """
        This is the USB Product Name that the device reports to the USB host.
        """
        return Protocols_BrpHid_UsbProductName(self)
    @property
    def Protocols_BrpHid_UsbSerialNumber(self) -> Protocols_BrpHid_UsbSerialNumber:
        """
        This is the USB Serial number the device reports to the USB host. If this value is not defined the reader uses the factory programmed device serial number.
        """
        return Protocols_BrpHid_UsbSerialNumber(self)
    @property
    def Protocols_BrpHid_HostMsgFormatTemplate(self) -> Protocols_BrpHid_HostMsgFormatTemplate:
        """
        Specifies the way the ascii decimal number read from the card by autoread shall be converted to the lowlevel format needed by this protocol.
        """
        return Protocols_BrpHid_HostMsgFormatTemplate(self)
    @property
    def Protocols_BrpHid_AutoRunCommand(self) -> Protocols_BrpHid_AutoRunCommand:
        """
        A list of BRP command frames that shall be executed automatically at powerup (including sending their responses to the host) before starting with normal operation. 
        
        **These commands are executed in order (_first_ StartupRunCmd[0],_then_ StartupRunCmd[1], ...) until the first index without corresponding StartupRunCmd value.**
        """
        return Protocols_BrpHid_AutoRunCommand(self)
    @property
    def Protocols_SNet(self) -> Protocols_SNet:
        """
        Configuration values for S-Net protocol used in ACCESS200
        """
        return Protocols_SNet(self)
    @property
    def Protocols_SNet_BusAddress(self) -> Protocols_SNet_BusAddress:
        """
        S-Net bus address values: 0x00-0x7F. If you don't want to use BALTECH AdrCard, you can set a fixed bus address with this value.
        """
        return Protocols_SNet_BusAddress(self)
    @property
    def Protocols_SNet_DeviceType(self) -> Protocols_SNet_DeviceType:
        return Protocols_SNet_DeviceType(self)
    @property
    def Protocols_SNet_HostMsgFormatTemplate(self) -> Protocols_SNet_HostMsgFormatTemplate:
        """
        Specifies the way the ASCII decimal number read from the card by Autoread is to be converted to the low-level format needed by this protocol.
        """
        return Protocols_SNet_HostMsgFormatTemplate(self)
    @property
    def Protocols_Bpa9(self) -> Protocols_Bpa9:
        """
        Configuration values for BPA/9 protocol (RS-485)
        """
        return Protocols_Bpa9(self)
    @property
    def Protocols_Bpa9_HostMsgFormatTemplate(self) -> Protocols_Bpa9_HostMsgFormatTemplate:
        """
        Specifies the way the ASCII decimal number read from the card by Autoread is to be converted to the low-level format needed by this protocol.
        """
        return Protocols_Bpa9_HostMsgFormatTemplate(self)
    @property
    def Protocols_Wiegand(self) -> Protocols_Wiegand:
        """
        Specify settings for Wiegand interface (output). To use this interface autoread functionality has to be activated.
        """
        return Protocols_Wiegand(self)
    @property
    def Protocols_Wiegand_HostMsgFormatTemplate(self) -> Protocols_Wiegand_HostMsgFormatTemplate:
        """
        Specifies the way the ascii decimal number read from the card by autoread shall be converted to the lowlevel format needed by this protocol.
        """
        return Protocols_Wiegand_HostMsgFormatTemplate(self)
    @property
    def Protocols_Wiegand_MessageLength(self) -> Protocols_Wiegand_MessageLength:
        """
        The size of a single Wiegand message in bits. 
        
        With Wiegand/Mode = Standard only values that are a multiple of 8 plus 2 are allowed (e.g. 34). If Wiegand/Mode = Raw any bit length may be selected. 
        
        **The value 0xFF means, that the length of the message depends on the length of the data returned by the autoread functionality.**
        """
        return Protocols_Wiegand_MessageLength(self)
    @property
    def Protocols_Wiegand_BitOrder(self) -> Protocols_Wiegand_BitOrder:
        """
        Specifies the order of the bits within a Wiegand message.
        """
        return Protocols_Wiegand_BitOrder(self)
    @property
    def Protocols_Wiegand_PinMessageFormat(self) -> Protocols_Wiegand_PinMessageFormat:
        """
        Specifies the format of PINs entered by user via keyboard (see MessageType = Keyboard) that shall be send via Wiegand.
        """
        return Protocols_Wiegand_PinMessageFormat(self)
    @property
    def Protocols_Wiegand_PulseWidth(self) -> Protocols_Wiegand_PulseWidth:
        """
        Specifies the time of a Wiegand pulse in 1/100 ms.
        """
        return Protocols_Wiegand_PulseWidth(self)
    @property
    def Protocols_Wiegand_PulseInterval(self) -> Protocols_Wiegand_PulseInterval:
        """
        Specifies the time between two Wiegand pulses in ms.
        """
        return Protocols_Wiegand_PulseInterval(self)
    @property
    def Protocols_Wiegand_Mode(self) -> Protocols_Wiegand_Mode:
        """
        Specifies the mode how Wiegand data are sent to the host. Currently two modes are supported: Standard and raw mode.
        """
        return Protocols_Wiegand_Mode(self)
    @property
    def Protocols_RawSerial(self) -> Protocols_RawSerial:
        """
        This subkey specifies all protocol parameters needed for the RawSerial protocol, which transfers messages via RS-232/UART to the host without any extra protocol overhead.
        """
        return Protocols_RawSerial(self)
    @property
    def Protocols_RawSerial_Baudrate(self) -> Protocols_RawSerial_Baudrate:
        """
        Specifies the Baudrate.
        """
        return Protocols_RawSerial_Baudrate(self)
    @property
    def Protocols_RawSerial_Parity(self) -> Protocols_RawSerial_Parity:
        """
        Parity-mode that shall be used for transfer of data. If not specified "None" is assumed.
        """
        return Protocols_RawSerial_Parity(self)
    @property
    def Protocols_RawSerial_BitsPerByte(self) -> Protocols_RawSerial_BitsPerByte:
        """
        Specifies the number of payload bits per byte (without start/stop/parity bits). If this value is not specified 8 is assumed.
        """
        return Protocols_RawSerial_BitsPerByte(self)
    @property
    def Protocols_RawSerial_Channel(self) -> Protocols_RawSerial_Channel:
        """
        Specifies the Pins that shall be used to transfer the data to the host. 
        
        **This value is only relevant for ID-engine SD readers, which provide two RS-232/UART interfaces. ID-engine X and ID-engine Z readers, which feature only one RS-232/UART, ignore this value.**
        """
        return Protocols_RawSerial_Channel(self)
    @property
    def Protocols_RawSerial_HostMsgFormatTemplate(self) -> Protocols_RawSerial_HostMsgFormatTemplate:
        """
        Specifies the way the ascii decimal number read from the card by autoread shall be converted to the lowlevel format needed by this protocol.
        """
        return Protocols_RawSerial_HostMsgFormatTemplate(self)
    @property
    def Protocols_LowLevelIoPorts(self) -> Protocols_LowLevelIoPorts:
        """
        When this protocol is activated, the physical pins of the second protocol channel (used also for Wiegand and RawSerial are use for I/O and thus can be set via commands for setting/getting IO-Ports.
        """
        return Protocols_LowLevelIoPorts(self)
    @property
    def Protocols_LowLevelIoPorts_PhysicalPinMap(self) -> Protocols_LowLevelIoPorts_PhysicalPinMap:
        """
        If this protocol is activated every physical pin of the 3 pins of the second channel is assigned to a virtual Port. This assignment can be changed by setting an entry of this list to a specific virtual Port. The list entries are assigned to this physical pins (in order): 
        
          1. TX os RS-232/UART when configured for RawSerial 
          2. Direction pin when configuration for a RS485 based protocol like OSDP 
          3. RX os RS-232/UART when configured for RawSerial
        """
        return Protocols_LowLevelIoPorts_PhysicalPinMap(self)
    @property
    def Protocols_MagstripeEmulation(self) -> Protocols_MagstripeEmulation:
        """
        This subkey specifies the parameters for the magstripe emulation interface, which makes a SmartCard reader emulate a magstripe card reader.
        """
        return Protocols_MagstripeEmulation(self)
    @property
    def Protocols_MagstripeEmulation_Encoding(self) -> Protocols_MagstripeEmulation_Encoding:
        """
        Specifies the character encoding for magstripe emulation.
        """
        return Protocols_MagstripeEmulation_Encoding(self)
    @property
    def Protocols_Network(self) -> Protocols_Network:
        """
        This subkey specifies all protocol parameters needed for the network communication (Ethernet).
        """
        return Protocols_Network(self)
    @property
    def Protocols_Network_IpAddress(self) -> Protocols_Network_IpAddress:
        """
        This is the IP-Address the reader device should apply for network communication. 
        
        This value is a part of the static IP configuration of a reader device. A complete static IP configuration consists of IpAddress IpSubnetMask, IpGateway and IpDnsServer. 
        
        These values should be set by the network administrator if the dynamic IP configuration is disabled (refer to DhcpMode).
        """
        return Protocols_Network_IpAddress(self)
    @property
    def Protocols_Network_IpSubnetMask(self) -> Protocols_Network_IpSubnetMask:
        """
        This is the subnet mask. 
        
        The subnet mask specifies which IP addresses belong to the readers subnet. The reader uses this value to decide if a host is located in the same subnet (these packets are sent directly) or not (these packets are sent to IpGateway). 
        
        This value is part of the static IP configuration. Refer to IpAddress.
        """
        return Protocols_Network_IpSubnetMask(self)
    @property
    def Protocols_Network_IpGateway(self) -> Protocols_Network_IpGateway:
        """
        This is the IP address of the gateway. 
        
        The reader will always try to send IP packets directly to the receiver if it is located in the same subnet. All other packets will be sent to the standard gateway, which takes care of routing this packets correctly. 
        
        This value is part of the static IP configuration. Refer to IpAddress.
        """
        return Protocols_Network_IpGateway(self)
    @property
    def Protocols_Network_IpDnsServer(self) -> Protocols_Network_IpDnsServer:
        """
        This is the IP address of the DNS server. 
        
        The reader tries to contact the DNS server in case there are host names to be resolved. 
        
        This value is part of the static IP configuration. Refer to IpAddress.
        """
        return Protocols_Network_IpDnsServer(self)
    @property
    def Protocols_Network_DhcpMode(self) -> Protocols_Network_DhcpMode:
        """
        Activates/deactivates the DHCP client of the reader. 
        
        If DHCP is enabled the reader tries to get a dynamic IP configuration from a DHCP server at startup. 
        
        If the DHCP client is disabled a static IP configuration should be available (refer to IpAddress). Otherwise the device may only be accessed via a link-local address. 
        
        If mode is set to "Auto" then the DHCP client is only enabled if a static IP configuration is not available.
        """
        return Protocols_Network_DhcpMode(self)
    @property
    def Protocols_KeyboardEmulation(self) -> Protocols_KeyboardEmulation:
        """
        If the USB keyboard emulation protocol is enabled (see Device/Run/EnabledProtocols), you can fine-tune it with these values.
        """
        return Protocols_KeyboardEmulation(self)
    @property
    def Protocols_KeyboardEmulation_RegisterInterface(self) -> Protocols_KeyboardEmulation_RegisterInterface:
        """
        **This is a legacy value.**
        
        Specifies if the USB HID interface shall be registered during connecting the USB device even if the KeyboardEmulation protocol is not enabled.
        """
        return Protocols_KeyboardEmulation_RegisterInterface(self)
    @property
    def Protocols_KeyboardEmulation_ScancodesMap(self) -> Protocols_KeyboardEmulation_ScancodesMap:
        """
        Defines a map that describe how to map various ASCII characters to Scancodes (=codes that are transferred via USB). Since scancodes are keyboard layout specific (=country specific) they have to be adapted for different countries.
        """
        return Protocols_KeyboardEmulation_ScancodesMap(self)
    @property
    def Protocols_KeyboardEmulation_KeypressDelay(self) -> Protocols_KeyboardEmulation_KeypressDelay:
        """
        Specifies the minimum delay in ms between two emulated keypresses. For most (!) firmware variants this defaults to 4. But with this configuration value you can increase the value if the host is not fast enough.
        """
        return Protocols_KeyboardEmulation_KeypressDelay(self)
    @property
    def Protocols_KeyboardEmulation_UsbInterfaceSubClass(self) -> Protocols_KeyboardEmulation_UsbInterfaceSubClass:
        """
        Specifies the subclass of the USB interface for keyboard emulation.
        """
        return Protocols_KeyboardEmulation_UsbInterfaceSubClass(self)
    @property
    def Protocols_KeyboardEmulation_UsbInterfaceOrder(self) -> Protocols_KeyboardEmulation_UsbInterfaceOrder:
        """
        Specifies if the keyboard emulation USB interface is returned before or after the BRP/HID interface (see USB command GetConfiguration).
        """
        return Protocols_KeyboardEmulation_UsbInterfaceOrder(self)
    @property
    def Protocols_KeyboardEmulation_HostMsgFormatTemplate(self) -> Protocols_KeyboardEmulation_HostMsgFormatTemplate:
        """
        Specifies the way the ascii decimal number read from the card by autoread shall be converted to the lowlevel format needed by this protocol.
        """
        return Protocols_KeyboardEmulation_HostMsgFormatTemplate(self)
    @property
    def Protocols_Ccid(self) -> Protocols_Ccid:
        """
        If the CCID protocol is enabled (see Device/Run/EnabledProtocols), you can fine-tune it with these values. 
        
        **As CCID starts Autoread autonomously, Device/Boot/StartAutoreadAtPowerup should always be set to _Disabled_ to avoid undesired behavior at power-up.**
        """
        return Protocols_Ccid(self)
    @property
    def Protocols_Ccid_CardTypeMask(self) -> Protocols_Ccid_CardTypeMask:
        """
        Restrict card type mask for CCID card selection. See also Project/VhlSettings/ScanCardFamilies.
        """
        return Protocols_Ccid_CardTypeMask(self)
    @property
    def Protocols_Ccid_ForceApduCardType(self) -> Protocols_Ccid_ForceApduCardType:
        """
        Forces the card type used for APDU exchange with the card to a certain value. If not specified the card type which has been determined by VHL select is used.
        """
        return Protocols_Ccid_ForceApduCardType(self)
    @property
    def Protocols_Ccid_LedControl(self) -> Protocols_Ccid_LedControl:
        """
        This value can be used to disable the legacy LED control via the CCID protocol. This allows LEDs to be controlled using Autoread Events.
        """
        return Protocols_Ccid_LedControl(self)
    @property
    def Protocols_Osdp(self) -> Protocols_Osdp:
        """
        If the OSDP protocol is enabled (see Device/Run/EnabledProtocols), you can fine-tune it with these values.
        """
        return Protocols_Osdp(self)
    @property
    def Protocols_Osdp_BaudRate(self) -> Protocols_Osdp_BaudRate:
        """
        Baudrate used by Osdp Protocol. (unit: value in 100 bits per second)
        """
        return Protocols_Osdp_BaudRate(self)
    @property
    def Protocols_Osdp_Address(self) -> Protocols_Osdp_Address:
        """
        Device id of this osdp device. Values: 0x00-0x7F
        """
        return Protocols_Osdp_Address(self)
    @property
    def Protocols_Osdp_CharTimeout(self) -> Protocols_Osdp_CharTimeout:
        """
        Character timeout in ms for the osdp device. Specifies the maximum time in ms which may elapse between two bytes within the same frame.
        """
        return Protocols_Osdp_CharTimeout(self)
    @property
    def Protocols_Osdp_SCBKeyDefault(self) -> Protocols_Osdp_SCBKeyDefault:
        """
        This is the default key for OSDP protocol encryption. (SCBK-D). Will be used in install mode.
        """
        return Protocols_Osdp_SCBKeyDefault(self)
    @property
    def Protocols_Osdp_SCBKey(self) -> Protocols_Osdp_SCBKey:
        """
        This is the secure key for OSDP protocol encryption. In the standard OSDP specification this key is diversified and installed over the OSDP protocol. If this key exists OSDP works in secure mode.
        """
        return Protocols_Osdp_SCBKey(self)
    @property
    def Protocols_Osdp_SecureInstallMode(self) -> Protocols_Osdp_SecureInstallMode:
        """
        Flag for special install mode.
        """
        return Protocols_Osdp_SecureInstallMode(self)
    @property
    def Protocols_Osdp_DataMode(self) -> Protocols_Osdp_DataMode:
        """
        Adjustes OSDP message type for card data replies: ASCII data, Bitstream raw data or Bitstream wiegand data
        """
        return Protocols_Osdp_DataMode(self)
    @property
    def Protocols_Osdp_HostMsgFormatTemplate(self) -> Protocols_Osdp_HostMsgFormatTemplate:
        """
        Specifies the way the ascii decimal number read from the card by autoread shall be converted to the lowlevel format needed by this protocol.
        """
        return Protocols_Osdp_HostMsgFormatTemplate(self)
    @property
    def Protocols_HttpsClient(self) -> Protocols_HttpsClient:
        """
        This protocol requires a BALTECH IF Converter that connects to a server via Ethernet as HTTPS client.
        """
        return Protocols_HttpsClient(self)
    @property
    def Protocols_HttpsClient_AuthUrl(self) -> Protocols_HttpsClient_AuthUrl:
        """
        Specifies the root path of the HTTP(S) service to contact for reader operations (e.g. transmission of Autoread messages). 
        
        As an option, you can specify 2 servers. If the first server is unreachable, IF Converter will fail over to the second. Once the first server is available again, IF Converter will switch back automatically.
        """
        return Protocols_HttpsClient_AuthUrl(self)
    @property
    def Protocols_HttpsClient_ReaderUpdateUrl(self) -> Protocols_HttpsClient_ReaderUpdateUrl:
        """
        Specifies the HTTPS server to poll for updates of the BEC2 file that contains the reader configuration (and optionally firmware). If not specified, <AuthUrl>/config.update.bec2 will be used instead.
        """
        return Protocols_HttpsClient_ReaderUpdateUrl(self)
    @property
    def Protocols_HttpsClient_IfconverterUpdateUrl(self) -> Protocols_HttpsClient_IfconverterUpdateUrl:
        """
        Specifies the HTTPS server to poll for updates of the IF Converter firmware.
        """
        return Protocols_HttpsClient_IfconverterUpdateUrl(self)
    @property
    def Protocols_HttpsClient_UpdateTime(self) -> Protocols_HttpsClient_UpdateTime:
        """
        Specifies the time of day to check for IF Converter and reader updates.
        """
        return Protocols_HttpsClient_UpdateTime(self)
    @property
    def Protocols_HttpsClient_UpdateTimeSpread(self) -> Protocols_HttpsClient_UpdateTimeSpread:
        """
        Specifies the maximum delay added to UpdateTime before checking if an update is available. The actual delay is determined individually for each IF Converter-reader pair, using a random value between 0 and _UpdateSpreadTime_. This ensures that not all devices connect to the server at the same time. This value should depend on the expected number of readers in your project and on the speed of your network connection.
        """
        return Protocols_HttpsClient_UpdateTimeSpread(self)
    @property
    def Protocols_HttpsClient_InitialEncryptedAuthToken(self) -> Protocols_HttpsClient_InitialEncryptedAuthToken:
        """
        Project-specific, encrypted authentication token for the server specified in AuthUrl. 
        
        The token is used on the first successful connection. Then, it will be replaced by a server-generated authentication token individual to the reader. 
        
        The key for encrypting the initial token is: 
        
        ` -----BEGIN PUBLIC KEY----- MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE3mEEb/cQw5uyR3o9sv2LfXAbNs2a lyzKx30YeXSzqpcKv6P9Zjst1HleRn4YKTMVdNpqBms+EvG7ckeEHQ128Q== -----END PUBLIC KEY----- `
        
        When using an IF Converter development image, the key is: 
        
        ` -----BEGIN PUBLIC KEY----- MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEeV6InxoTLA1uWvoikxksU/XkfDeh xztawfX/tBEdOaVNx5i8QVhDxqfQUMns1VCIeIb5DFkRWGG+E7xKjUOFIw== -----END PUBLIC KEY----- `
        """
        return Protocols_HttpsClient_InitialEncryptedAuthToken(self)
    @property
    def Protocols_HttpsClient_RootCertServer(self) -> Protocols_HttpsClient_RootCertServer:
        """
        If one of the servers referred by the URL Configvalues (i.e. Protocols.HttpsClient.AuthUrl(0)) uses HTTPS/TLS with a custom root certificate, provide the root certificates here. 
        
        You need to split the DER-encoded root certificate into chunks of not more than 120 bytes in size. Then assign every _RootCertServer(x)_ array entry one of these chunks. At last ensure that the array entry following the last certificate chunk is unused to indicate the end of the certificate. 
        
        You may concatenate multiple root certificates in the method as described above (ensuring that there is always exactly one unused array entry). The IF Converter will automaticially select the right root certificate when connecting to a HTTPS URL.
        """
        return Protocols_HttpsClient_RootCertServer(self)
    @property
    def Protocols_AccessConditionBitsStd(self) -> Protocols_AccessConditionBitsStd:
        """
        Under this subkey all protocol specific access condition bits are specified.
        """
        return Protocols_AccessConditionBitsStd(self)
    @property
    def Protocols_AccessConditionBitsStd_BrpOverSerial(self) -> Protocols_AccessConditionBitsStd_BrpOverSerial:
        """
        Specifies the access rights when running a BRP (over serial) command.
        """
        return Protocols_AccessConditionBitsStd_BrpOverSerial(self)
    @property
    def Protocols_AccessConditionBitsStd_BrpOverHid(self) -> Protocols_AccessConditionBitsStd_BrpOverHid:
        """
        Specifies the access rights when running a BRP over HID command.
        """
        return Protocols_AccessConditionBitsStd_BrpOverHid(self)
    @property
    def Protocols_AccessConditionBitsStd_BrpOverOsdp(self) -> Protocols_AccessConditionBitsStd_BrpOverOsdp:
        """
        Specifies the access rights when running BRP commands over OSDP. Configuration value is used, if: - OSDP is configured to run in secure mode and the secure connection has already been established. - OSDP is configured to run in unsecure mode.
        """
        return Protocols_AccessConditionBitsStd_BrpOverOsdp(self)
    @property
    def Protocols_AccessConditionBitsStd_Ccid(self) -> Protocols_AccessConditionBitsStd_Ccid:
        """
        Specifies the access rights when running CCID protocol.
        """
        return Protocols_AccessConditionBitsStd_Ccid(self)
    @property
    def Protocols_AccessConditionBitsAlt(self) -> Protocols_AccessConditionBitsAlt:
        """
        Under this subkey special protocol specific access condition bits are specified.
        """
        return Protocols_AccessConditionBitsAlt(self)
    @property
    def Protocols_AccessConditionBitsAlt_BrpOverOsdpLimited(self) -> Protocols_AccessConditionBitsAlt_BrpOverOsdpLimited:
        """
        Specifies the access rights when running BRP commands over OSDP, at which OSDP is configured to run in secure mode and the secure connection has not yet been established.
        """
        return Protocols_AccessConditionBitsAlt_BrpOverOsdpLimited(self)
    @property
    def VhlCfg(self) -> VhlCfg:
        """
        Contains a list of VHL (very high level) descriptions how to read/write/format a card (=files). Every subkey corresponds to a specific VHL file id.
        """
        return VhlCfg(self)
    @property
    def VhlCfg_File(self) -> VhlCfg_File:
        """
        This key contains a description how to access a card of a specific type with VHLRead / VHLWrite / VHLFormat.
        """
        return VhlCfg_File(self)
    @property
    def VhlCfg_File_AreaList125(self) -> VhlCfg_File_AreaList125:
        """
        List of 2 byte tuples. First byte specifies the page address, the second byte the number of pages that shall be accessed via this VHL file.
        """
        return VhlCfg_File_AreaList125(self)
    @property
    def VhlCfg_File_Secret125(self) -> VhlCfg_File_Secret125:
        """
        * \\- 4-byte password for EM4205 cards 
          * \\- 4-byte password (RWD) for Hitag2 cards 
          * \\- 4-byte password (RWD) and 3-byte password (TAG) for Hitag2 cards
        """
        return VhlCfg_File_Secret125(self)
    @property
    def VhlCfg_File_DesfireAid(self) -> VhlCfg_File_DesfireAid:
        """
        Desfire Application Identifier: only one Desfire Application can be processed per VHL file.   
        
        
        **VHLReadWrite():** this is the AID of the Desfire Application that shall be processed.   
        
        
        **VHLFormat():** Desfire application will be created if not existent. Depending on the master key settings, key authentication may be required - therefore the value VhlCfg/File/DesfirePiccMasterKeys may be defined. 
        
        **This value has to be specified in MSB first order (as all Baltech configuration values). Care has to be taken if the AID is retrieved directly from a Desfire internal representation, which uses LSB first order (In this case the AID has to be rotated).**
        
        ` ConfigValue: 0x00 0x12 0x34 0x56 AID: 0x123456 Desfire internal representation: 0x56 0x34 0x12 `
        """
        return VhlCfg_File_DesfireAid(self)
    @property
    def VhlCfg_File_DesfireKeyList(self) -> VhlCfg_File_DesfireKeyList:
        """
        Contains the list of keys needed to access a Desfire card with this VHL file. These keys are referenced by VhlCfg/File/DesfireFileDesc
        """
        return VhlCfg_File_DesfireKeyList(self)
    @property
    def VhlCfg_File_DesfireFileDesc(self) -> VhlCfg_File_DesfireFileDesc:
        """
        A VHL file can be composed of multiple files of a single desfire application. One list entry specifies the file settings of exactly one desfire file and contains one (or more) entries that describes how to access the desfire file and what part of the desfire file shall be accessed. 
        
        **VHLReadWrite():** a Desfire application with two Desfire files of 50 bytes each could be mapped into single VHL file by specifing a DesfireFileDesc with two entries. The first entry maps desfire file 0 into the VHL file bytes 0-49 and the desfire file 1 is mapped by the second entry into the VHL file bytes 50-99. When reading VHL file bytes 48-52 the reader will implicitly read the last 2 bytes of desfire file 0 and the first two bytes of the desfire file 1 and return the concatenated result. 
        
        **VHLFormat():** after executing VHLFormat() command all files should have the same settings as specified in the list entries. I.e. if a file already exists on card and the file settings of the card differ from the settings in the list entry, the existing file settings will be changed (success depends on access rights of the file). If file size is different the file will be deleted and created again. If a file exists on card but not in the file descriptor list it will be preserved. (e.g. on card exists file 1,2,5 - file descriptor contains file 1,2,6 - after execution of VHLFormat() the card contains file 1,2,5,6, files 1,2 have been adapted to new configuration values. 
        
        The last list entry may be specified incompletely. All missing data at the end of the entry will be assumed to have default values (This is only a convenience feature). 
        
        **Special DESFire VHL implementation for LEGIC**
        
        In addition to the standard DESFire VHL implementation, a special version is available exclusively for LEGIC readers starting with firmware 1100 v2.20.00. This implementation is required when DESFire keys are not available in plaintext, but are instead embedded in an encrypted VCP (Versatile Configuration Package) file. To enable this implementation, set VhlCfg/File/CardType to _DesfireForLegic_ (0xE6). 
        
        The special implementation has the following restrictions: 
        
          * Only VHL.Read is supported (VHL.Write and VHL.Format are not available). 
          * Dynamic VHL files are not supported. 
          * Concatenation of multiple file descriptors as described above is not supported (only one file descriptor is evaluated). 
          * Only AES-128 keys are supported. 
        
        
        
        The parameter _ReadKeyIdx_ specified in the file descriptor may have the following values: 
        
          * 0x00-0x7F: Refers to an index in Project/LegicKeySettings/Index (keys are transferred into LEGIC reader chip using a VCP file). 
          * 0xC0-0xCB: Refers to an index in VhlCfg/File/DesfireKeyList (keys are available in plaintext).
        """
        return VhlCfg_File_DesfireFileDesc(self)
    @property
    def VhlCfg_File_DesfirePiccMasterKeys(self) -> VhlCfg_File_DesfirePiccMasterKeys:
        """
        This entry is only needed for running VHLFormat() and specifies the key index for the PICC master key.
        """
        return VhlCfg_File_DesfirePiccMasterKeys(self)
    @property
    def VhlCfg_File_DesfireProtocol(self) -> VhlCfg_File_DesfireProtocol:
        """
        This value allows to select the communication protocol to a Desfire card.
        """
        return VhlCfg_File_DesfireProtocol(self)
    @property
    def VhlCfg_File_DesfireMapKeyidx(self) -> VhlCfg_File_DesfireMapKeyidx:
        """
        If this entry exists all desfire key indexes within the configuration are mapped to 16 bit values. 
        
          * If the key index refers to a crypto memory key (0x80..0xBF) the MSB of the 16 bit value refers to a page of the project crypto memory (0x00..0x0F), the LSB corresponds to the 8 bit value. 
          * If the key index refers to a SAM key (0x00..0x7F) the MSB of the 16 bit value denotes an index to the SamAVxKeySettings list, the LSB corresponds to the 8 bit value. 
          * For all other types of key references the MSB should be set to 0x00, all other values are rfu.
        """
        return VhlCfg_File_DesfireMapKeyidx(self)
    @property
    def VhlCfg_File_DesfireRandomIdKey(self) -> VhlCfg_File_DesfireRandomIdKey:
        """
        The value is required to authenticate with MIFARE DESFire cards with random UID to be able to read the real UID. It is currently only used for diversification.
        """
        return VhlCfg_File_DesfireRandomIdKey(self)
    @property
    def VhlCfg_File_DesfireProxcheck(self) -> VhlCfg_File_DesfireProxcheck:
        """
        If this key entry exists the reader performs a Proximity Check.
        """
        return VhlCfg_File_DesfireProxcheck(self)
    @property
    def VhlCfg_File_DesfireVcsParams(self) -> VhlCfg_File_DesfireVcsParams:
        """
        If this key entry exists the reader performs a virtual card selection.
        """
        return VhlCfg_File_DesfireVcsParams(self)
    @property
    def VhlCfg_File_DesfireEV2FormatFileMultAccessCond(self) -> VhlCfg_File_DesfireEV2FormatFileMultAccessCond:
        """
        This entry specifies multiple access conditions for files within an application. (only for EV2 cards)
        """
        return VhlCfg_File_DesfireEV2FormatFileMultAccessCond(self)
    @property
    def VhlCfg_File_ForceCardSM(self) -> VhlCfg_File_ForceCardSM:
        """
        Forces a minimum secure messaging (SM) level for the communication between a Secure Access Module (SAM) and the card, typically in high-security environments. 
        
          * If this value is not set, the hightest SM level supported by both the SAM and the card is used.
          * If this value is set, the minimum SM level specified must always be maintained. If either the SAM or the card does not support this level, communication between them is not possible.
        """
        return VhlCfg_File_ForceCardSM(self)
    @property
    def VhlCfg_File_DesfireDiversificationData(self) -> VhlCfg_File_DesfireDiversificationData:
        """
        Entry contains a rule processed by the data converter. For card number generation, only SerialNumber is supported.
        """
        return VhlCfg_File_DesfireDiversificationData(self)
    @property
    def VhlCfg_File_DesfireSoftUid(self) -> VhlCfg_File_DesfireSoftUid:
        """
        The value is required to read a "soft-UID", i.e. a PCN stored in a file that is used for key diversification instead of the card's UID.
        """
        return VhlCfg_File_DesfireSoftUid(self)
    @property
    def VhlCfg_File_FelicaSystemCode(self) -> VhlCfg_File_FelicaSystemCode:
        """
        This value specifies the system code (logical card)
        """
        return VhlCfg_File_FelicaSystemCode(self)
    @property
    def VhlCfg_File_FelicaServiceCodeList(self) -> VhlCfg_File_FelicaServiceCodeList:
        """
        List of service codes This value is a list of service codes to access. (integer 16bit values). For every entry also an entry in FelicaAreaList has to be defined.
        """
        return VhlCfg_File_FelicaServiceCodeList(self)
    @property
    def VhlCfg_File_FelicaAreaList(self) -> VhlCfg_File_FelicaAreaList:
        """
        List of 2 byte tuples. First byte specifies the block address, (0-255) the second byte the number of blocks (1..) that shall be accessed via this VHL file. For every tuple also an entry in FelicaServiceCodeList has to be defined.
        """
        return VhlCfg_File_FelicaAreaList(self)
    @property
    def VhlCfg_File_FidoRpid(self) -> VhlCfg_File_FidoRpid:
        """
        This value specifies the relying party identifier (RPID). It's required for referencing a FIDO2 credential that is stored on the authenticator (here: Yubikey). It's used to read the certificate contained in the large blop of the tox credential.
        """
        return VhlCfg_File_FidoRpid(self)
    @property
    def VhlCfg_File_FidoPublicKey(self) -> VhlCfg_File_FidoPublicKey:
        """
        This value specifies the public CA key (ECC P-256) of the certificate authority (CA) that issued the certificate stored in the authenticator's large blob.
        """
        return VhlCfg_File_FidoPublicKey(self)
    @property
    def VhlCfg_File_IntIndFileDescList(self) -> VhlCfg_File_IntIndFileDescList:
        """
        This value specifies a list of file ID's of n interindustry card. File ID's can be a Name or a 2 byte file identifier (FID)
        """
        return VhlCfg_File_IntIndFileDescList(self)
    @property
    def VhlCfg_File_IntIndSegment(self) -> VhlCfg_File_IntIndSegment:
        """
        Offset and Value to read/write from. Both values are Integer
        """
        return VhlCfg_File_IntIndSegment(self)
    @property
    def VhlCfg_File_IntIndKeyIdx(self) -> VhlCfg_File_IntIndKeyIdx:
        return VhlCfg_File_IntIndKeyIdx(self)
    @property
    def VhlCfg_File_IntIndRecordNumber(self) -> VhlCfg_File_IntIndRecordNumber:
        return VhlCfg_File_IntIndRecordNumber(self)
    @property
    def VhlCfg_File_IntIndOnReadSelectOnly(self) -> VhlCfg_File_IntIndOnReadSelectOnly:
        """
        With this value the Interindustry VHL can be enforced to execute a SELECT application only.
        """
        return VhlCfg_File_IntIndOnReadSelectOnly(self)
    @property
    def VhlCfg_File_IntIndTimeout(self) -> VhlCfg_File_IntIndTimeout:
        """
        This value specifies the maximum time the reader should wait for an APDU command response from the card in the context of an Interindustry VHL read or write access.
        """
        return VhlCfg_File_IntIndTimeout(self)
    @property
    def VhlCfg_File_Iso15Afi(self) -> VhlCfg_File_Iso15Afi:
        """
        This optional value may be set to address only transponders with a certain application family identifier (AFI).
        """
        return VhlCfg_File_Iso15Afi(self)
    @property
    def VhlCfg_File_Iso15DsfId(self) -> VhlCfg_File_Iso15DsfId:
        """
        This optional value may be set to address only transponders with a certain data storage format identifier (DSFID).
        """
        return VhlCfg_File_Iso15DsfId(self)
    @property
    def VhlCfg_File_Iso15BlockList(self) -> VhlCfg_File_Iso15BlockList:
        """
        The configuration value is a list of 1 or more block descriptions that specify which ISO 15693 memory blocks have to be accessed by VHL. Every entry consists of 2 bytes: The first byte addresses the start block number (first block = 0), the second byte defines the number of blocks. 
        
        Either this value or the value Iso15ExtendedBlockList is mandatory for an ISO 15693 VHL definition.
        """
        return VhlCfg_File_Iso15BlockList(self)
    @property
    def VhlCfg_File_Iso15BlockSize(self) -> VhlCfg_File_Iso15BlockSize:
        """
        Forces block size to a certain value.
        """
        return VhlCfg_File_Iso15BlockSize(self)
    @property
    def VhlCfg_File_Iso15WriteOptFlag(self) -> VhlCfg_File_Iso15WriteOptFlag:
        """
        Selects option flag value for write operations.
        """
        return VhlCfg_File_Iso15WriteOptFlag(self)
    @property
    def VhlCfg_File_Iso15ReadCmd(self) -> VhlCfg_File_Iso15ReadCmd:
        """
        Selects the ISO 15693 command that is used for a VHL read operation. With the default settings _ReadAuto_ , the reader will do the following: 
        
          * If there are more than 4 blocks to read, the reader will first try the _ReadMultipleBlocks_ command. If this command isn't supported, _ReadSingleBlock_ will be used as a fallback. 
          * If there are fewer than 4 blocks to read, the reader will first try the _ReadSingleBlock_ command. If this command isn't supported, _ReadMultipleBlocks_ will be used as a fallback.
        """
        return VhlCfg_File_Iso15ReadCmd(self)
    @property
    def VhlCfg_File_Iso15WriteCmd(self) -> VhlCfg_File_Iso15WriteCmd:
        """
        Selects the ISO 15693 command that is used for a VHL write operation. With the default setting _WriteAuto_ , the reader will do the following: 
        
          * If there are more than 4 blocks to write, the reader will first try the _WriteMultipleBlocks_ command. If this command isn't supported, _WriteSingleBlock_ will be used as a fallback. 
          * If there are fewer than 4 blocks to write, the reader will first try the _WriteSingleBlock_ command. If this command isn't supported, _WriteMultipleBlocks_ will be used as a fallback.
        """
        return VhlCfg_File_Iso15WriteCmd(self)
    @property
    def VhlCfg_File_Iso15ExtendedBlockList(self) -> VhlCfg_File_Iso15ExtendedBlockList:
        """
        The configuration value is a list of 1 or more block descriptions that specify which ISO 15693 memory blocks have to be accessed by VHL. Each entry consists of 2 16-bit parameters: The first parameter addresses the start block number (first block = 0), the second parameter defines the number of blocks. 
        
        The configuration value is supported by firmware version 1100 v2.07 or above. 
        
        Either this value or the value Iso15BlockList is mandatory for an ISO 15693 VHL definition.
        """
        return VhlCfg_File_Iso15ExtendedBlockList(self)
    @property
    def VhlCfg_File_LegicSegmentListLegacy(self) -> VhlCfg_File_LegicSegmentListLegacy:
        """
        **Please use LegicApplicationSegmentList instead of this value for new applications.**
        
        _General information about Legic VHL definition:_   
        A Legic VHL description consists of one or more so-called fragments. Each fragment represents a certain data area on a Legic card. It can be a whole segment or only a part of it.   
        A fragment is described by a segment information (this value), by its length LegicLengthList and by the starting address within the desired segment LegicAddressList. Optionally a CRC checksum may be verified for every fragment (LegicCRCAddressList) and a certain segment type may be specified (LegicSegmentType). 
        
        The configuration value LegicSegmentListLegacy is a list of one or more segment descriptions. Every entry corresponds to a certain fragment and specifies which Legic segment has to be accessed by VHL. 
        
        This value is mandatory for a Legic VHL fragment definition. 
        
        Every entry in the list consists of at least two bytes: The first byte specifies the method the segment is identified and the Address mode (SegmentIdAndAdr). Depending on this value one or more bytes follow with required identification attributes.  
          
        Basically there are two ways to identify a segment: 
        
          * ID: SegmentIdentification has to be set to 0. SegmentInformation is the segment ID and has to be a value between 1 and 127 (0x01...0x7F) 
          * Stamp: SegmentIdentification has to be set to the Stamp length. The maximum allowed value is 12 (0x0C). SegmentInformation is the desired Stamp. 
        
        
        
        ` "ProtocolHeaderAddressMode 1": address segment 1 in Protocol Header mode "AdvantAddressMode 3": address segment 3 in Advant Address Mode "ProtocolHeaderAddressMode|3 0x12 0x23 0x45": address segment with stamp "12 34 56" in Protocol Header mode "AdvantAddressMode|3 0x12 0x23 0x45": address segment with stamp "12 34 56" in Advant Address mode `
        """
        return VhlCfg_File_LegicSegmentListLegacy(self)
    @property
    def VhlCfg_File_LegicLengthList(self) -> VhlCfg_File_LegicLengthList:
        """
        This is a list of 16-bit length values. Every entry specifies the length (MSB) of the corresponding fragment. 
        
        This value is mandatory for a Legic VHL fragment definition. 
        
        Refer to LegicApplicationSegmentList for an overview about the Legic fragment definition.
        """
        return VhlCfg_File_LegicLengthList(self)
    @property
    def VhlCfg_File_LegicAddressList(self) -> VhlCfg_File_LegicAddressList:
        """
        This is a list of 16-bit address values. Every entry specifies the starting address (MSB) of the corresponding fragment within the specified segment. 
        
        This value is mandatory for a Legic VHL fragment definition. 
        
        Refer to LegicApplicationSegmentList for an overview about the Legic fragment definition.
        """
        return VhlCfg_File_LegicAddressList(self)
    @property
    def VhlCfg_File_LegicCRCAddressList(self) -> VhlCfg_File_LegicCRCAddressList:
        """
        This is a list of 16-bit CRC address values. Every entry specifies the address (MSB) the CRC is stored within the specified segment. 
        
        This value is optional. Because there must only be an entry for a fragment that has enabled the CRC check (refer to LegicAddressList), this list may be shorter than the other lists. 
        
        Refer to LegicApplicationSegmentList for an overview about the Legic fragment definition.
        """
        return VhlCfg_File_LegicCRCAddressList(self)
    @property
    def VhlCfg_File_LegicSegmentTypeList(self) -> VhlCfg_File_LegicSegmentTypeList:
        """
        This is a list of 8-bit segment types. Every entry specifies the segment type according to the Legic definition that is used to access the corresponding fragment. 
        
        This value is optional. If no list is given VHL will assume a Data segment for every fragment. Usually a segment type must only be specified in case of Access or Biometric segments. 
        
        Refer to LegicApplicationSegmentList for an overview about the Legic fragment definition.
        """
        return VhlCfg_File_LegicSegmentTypeList(self)
    @property
    def VhlCfg_File_LegicUserKeyIndexList(self) -> VhlCfg_File_LegicUserKeyIndexList:
        """
        This is a list of indexes referencing keys in the storage of the LEGIC SM. Each entry corresponds to a fragment defined by LegicApplicationSegmentList and specifies the index of the key required to access the encrypted segment data. 
        
        Keys are stored in the LEGIC SM using LegicKeyList. 
        
        This value is optional. You only need it if you want to access segments with user-defined encryption. 
        
        Refer to LegicApplicationSegmentList for an overview of the LEGIC fragment definition.
        """
        return VhlCfg_File_LegicUserKeyIndexList(self)
    @property
    def VhlCfg_File_LegicMasterTokenZoneList(self) -> VhlCfg_File_LegicMasterTokenZoneList:
        """
        This is a list of Master Token Zones. Each entry corresponds to a fragment defined by LegicApplicationSegmentList and limits the segment access to the specified Master Token Zone. If the selected segment has been created by a Master Token from a different Zone, data access is denied. 
        
        This value is optional. If no list is provided, VHL will process segments of any Master Token Zone. 
        
        Refer to LegicApplicationSegmentList for an overview of the LEGIC fragment definition.
        """
        return VhlCfg_File_LegicMasterTokenZoneList(self)
    @property
    def VhlCfg_File_LegicCtcFileSystemList(self) -> VhlCfg_File_LegicCtcFileSystemList:
        """
        This value is a list of file systems. Each entry corresponds to 1 fragment defined by LegicApplicationSegmentList and determines which of the 2 available file systems to select in order to access LEGIC Cross Standard Transponders CTC4096. 
        
        This value is optional. It's only relevant for accessing LEGIC CTC4096 transponders. If no list is provided, VHL will choose the file system according to the selected RF standard. 
        
        **It's not possible to access the LEGIC advant file system if the transponder is selected as LEGIC prime.**
        
        Refer to LegicApplicationSegmentList for an overview of the LEGIC fragment definition.
        """
        return VhlCfg_File_LegicCtcFileSystemList(self)
    @property
    def VhlCfg_File_LegicApplicationSegmentList(self) -> VhlCfg_File_LegicApplicationSegmentList:
        """
        _General information about Legic VHL definition:_   
        A Legic VHL description consists of one or more so-called fragments. Each fragment represents a certain data area on a Legic card. It can be a whole segment or only a part of it.   
        A fragment is described by a segment information (this value), by its length LegicLengthList and by the starting address within the desired segment LegicAddressList. Optionally a CRC checksum may be verified for every fragment (LegicCRCAddressList) and a certain segment type may be specified (LegicSegmentTypeList). 
        
        The configuration value LegicApplicationSegmentList is a list of one or more segment descriptions. Every entry corresponds to a certain fragment and specifies which Legic segment has to be accessed by VHL. 
        
        This value is mandatory for a Legic VHL fragment definition. 
        
        Every entry in the list consists of two components: The first byte specifies how the segment shall be accessed by the reader (SegmentIdentification). The following bytes specify the required segment identification attributes. Depending on the selected value of SegmentIdentification they will be interpreted as segment ID or stamp respectively. 
        
        ` "ProtocolHeaderAddressMode 1 1": address segment 1 in Protocol Header mode "AdvantAddressMode 1 3": address segment 3 in Advant Address Mode "StampSearch 3 0x12 0x23 0x45": address segment with stamp "12 34 56" in Protocol Header mode "AdvantAddressMode|StampSearch 3 0x12 0x23 0x45": address segment with stamp "12 34 56" in Advant Address mode `
        """
        return VhlCfg_File_LegicApplicationSegmentList(self)
    @property
    def VhlCfg_File_LegicKeyList(self) -> VhlCfg_File_LegicKeyList:
        """
        This is a list of keys required for accessing LEGIC data segments that are encrypted with a user-defined key. 
        
        The keys are transferred into the persistent key storage of the LEGIC SM on the first reboot after configuration has been loaded. The configuration value is deleted afterward. 
        
        The encryption keys are used by LegicUserKeyIndexList.
        """
        return VhlCfg_File_LegicKeyList(self)
    @property
    def VhlCfg_File_MifareMode(self) -> VhlCfg_File_MifareMode:
        """
        Specifies if addressing of a Mifare Classic/Plus card shall be done via absolute addresses or relative to MAD (Mifare Application Directory) sectors.
        """
        return VhlCfg_File_MifareMode(self)
    @property
    def VhlCfg_File_MifarePlusMadKeyBIndex(self) -> VhlCfg_File_MifarePlusMadKeyBIndex:
        """
        This entry is only needed for running VHL-Format(). If MAD encoding is enabled (MAD_AID does exist), this value contains a 2 byte index to the write key (Key B) of the MAD. This key is needed by VHL-Format() to create the MAD or to adapt the MAD when adding a new application. If MAD encoding is not enabled, this value may be omitted. This value is used by Mifare plus firmware only. For Mifare classic firmware use MifareClassicMadKeyB instead.
        """
        return VhlCfg_File_MifarePlusMadKeyBIndex(self)
    @property
    def VhlCfg_File_MifareKeyList(self) -> VhlCfg_File_MifareKeyList:
        """
        Contains a list of 7 bytes: one byte access limitations and 6 bytes Mifare key.
        """
        return VhlCfg_File_MifareKeyList(self)
    @property
    def VhlCfg_File_MifareTransferToSecureMemory(self) -> VhlCfg_File_MifareTransferToSecureMemory:
        """
        This command transfers all Mifare classic keys from MifareKeyList (or MifareClassicKeyList) to secure memory, which is better protected against attacks. 
        
        Key transfer is done at power up of the reader and after key transfer is finished all keys are deleted from the configuration. This value is replaced by the firmware of the reader and designates the VHL key offset of this file within the secure memory.   
        Usually, the first key is transferred to the reader chip's memory address 0, the second one to the reader chip's memory address 1 and so on. A different address range can be specified, however, by definition of the START_RC500_EEP Value, please refer to Device/Run/FirstVhlRc500Key. 
        
        **If TRANSFER is set and according rights definition in MifareKeyList is restricted, the corresponding key will not be transferred.**
        """
        return VhlCfg_File_MifareTransferToSecureMemory(self)
    @property
    def VhlCfg_File_MifareMadAid(self) -> VhlCfg_File_MifareMadAid:
        """
        This value is only needed if the card has a Mifare Application Directory (MAD) and MifareMode is set to "MAD". It specifies the Application-ID within a MAD sector.
        """
        return VhlCfg_File_MifareMadAid(self)
    @property
    def VhlCfg_File_MifarePlusAesKeyList(self) -> VhlCfg_File_MifarePlusAesKeyList:
        """
        Contains a list of 7 bytes: one byte access limitations and 16 bytes AES key. This value is used by Mifare plus firmware only.
        """
        return VhlCfg_File_MifarePlusAesKeyList(self)
    @property
    def VhlCfg_File_MifareSectorList(self) -> VhlCfg_File_MifareSectorList:
        """
        This value contains a list of sectors which shall be accessed. It replaces the MifareClassicBlockList value, which specifies sectors instead of blocks. This value can also be used for VHL-Format(): it contains a list of sectors numbers which shall be formatted - if an AID is specified this list contains sectors which belongs to the AID: then the sectors are addressed relatively to the MAD. Refer also to MifareMode.
        """
        return VhlCfg_File_MifareSectorList(self)
    @property
    def VhlCfg_File_MifarePlusKeyAssignment(self) -> VhlCfg_File_MifarePlusKeyAssignment:
        """
        This value primary used for VHL format consists of a 10 byte list which contains the information for the complete sector trailer and according keys A and B (AES and/or Mifare, dependant of the card security level). For each sector in MifareSectorList this information is programmed. 
        
          * Security level 3: for each sector 2 AES keys (A and B) and a sector trailer containing 5 bytes access conditions (AC bytes / all other bytes are set to 0) are programmed. 
          * Security level 0 and 2: for each sector 2 AES keys (A and B) and the complete sector trailer with Mifare keys (A and B) and 4 byte access condition are programmed. 
          * Security level 1: the complete sector trailer with Mifare keys (A and B) and 4 byte access condition is programmed. 
        
        
        
        **Currently for key A/B only VHL keys can be used.**
        
        For VHL-read/write() this value specifies the key to authenticate with - for this purpose ACS bytes will be discarded. 
        
        This value is used by Mifare plus firmware only. For Mifare classic firmware use MifareClassicFormatSectorTrailer.
        """
        return VhlCfg_File_MifarePlusKeyAssignment(self)
    @property
    def VhlCfg_File_MifarePlusCommunicationMode(self) -> VhlCfg_File_MifarePlusCommunicationMode:
        """
        This value is used by Mifare plus firmware only. It specifies the communication mode in security level 3 of a Mifare plus card.
        """
        return VhlCfg_File_MifarePlusCommunicationMode(self)
    @property
    def VhlCfg_File_MifarePlusProxyimityCheck(self) -> VhlCfg_File_MifarePlusProxyimityCheck:
        """
        This value is used by Mifare plus firmware only and specifies an index to the proximity check key. If configuration value is missing no proximity check by the reader will be done. Cards with proximity check enabled do not work without this check.
        """
        return VhlCfg_File_MifarePlusProxyimityCheck(self)
    @property
    def VhlCfg_File_MifareVcsParams(self) -> VhlCfg_File_MifareVcsParams:
        """
        This value enables Virtual Card Selection. An ISO Select command is performed to select a particular MIFARE (Plus) installation. If valid keys are specified, an additional ISO External Authenticate will be executed.
        """
        return VhlCfg_File_MifareVcsParams(self)
    @property
    def VhlCfg_File_MifarePlusKeyIdxOffset(self) -> VhlCfg_File_MifarePlusKeyIdxOffset:
        """
        This value is used by Mifare plus firmware only. It describes for SAM and crypto memory keys an offset for Mifare keys to AES keys (!-signed value). This value is only useful at security level 0 and 2 - in this cases for access / authentication both keys are needed. Default value is 1.
        """
        return VhlCfg_File_MifarePlusKeyIdxOffset(self)
    @property
    def VhlCfg_File_MifareClassicFormatSectorTrailer(self) -> VhlCfg_File_MifareClassicFormatSectorTrailer:
        """
        **This value is is used by Mifare classic firmware only. For Mifare plus firmware use MifareClassicKeyAssignment instead. It is only needed by VHL-Format(). Every sector trailer will be overwritten with this array.**
        """
        return VhlCfg_File_MifareClassicFormatSectorTrailer(self)
    @property
    def VhlCfg_File_MifareClassicKeyList(self) -> VhlCfg_File_MifareClassicKeyList:
        """
        Contains a list of 6 byte keys. These keys are referenced by MifareClassicWriteKeyAssignment and MifareClassicReadKeyAssignment
        
        **This value is used by Mifare classic firmware only. For Mifare plus firmware use MifareKeyList instead.**
        """
        return VhlCfg_File_MifareClassicKeyList(self)
    @property
    def VhlCfg_File_MifareClassicBlockList(self) -> VhlCfg_File_MifareClassicBlockList:
        """
        This value cannot be used with VHL-Format(). It contains a list of blocks that shall be accessible via this VHL file. Every entry is a zero-based 8bit address. This means: if MifareMode is set to Absolute 
        
          * Block 0 is the information block 
          * Block 3 is the sector trailer of block 0 
          * Block 4 is block 0 of sector 1 
          * ... 
        
        
        
        **This value is used by Mifare classic firmware only. For Mifare plus firmware use MifareSectorList instead.**
        
        **If Mad is enabled (see MifareMode ) the blocks are relative to the first sector of the application.**
        """
        return VhlCfg_File_MifareClassicBlockList(self)
    @property
    def VhlCfg_File_MifareClassicReadKeyAssignment(self) -> VhlCfg_File_MifareClassicReadKeyAssignment:
        """
        For every entry in MifareSectorList (or MifareClassicBlockList for legacy configurations) an entry in this list has to be specified, that refers to a key in MifareKeyList (or MifareClassicKeyList). Furthermore every entry has to be bitmask-combined with either KeyA or KeyB to inform the reader if the key at the corresponding key index shall be applied as key A/B. 
        
        If this value contains less entries than MifareSectorList the missing entries will be filled up by duplicating the last entry in this list. If this value is not defined all sectors will be read by using key 0 as KeyA. 
        
        **This value is used by Mifare classic firmware only. For Mifare plus firmware MifarePlusKeyAssignment instead.**
        """
        return VhlCfg_File_MifareClassicReadKeyAssignment(self)
    @property
    def VhlCfg_File_MifareClassicWriteKeyAssignment(self) -> VhlCfg_File_MifareClassicWriteKeyAssignment:
        """
        For every entry in MifareSectorList (or MifareClassicBlockList for legacy configurations) an entry in this list has to be specified, that refers to a key in MifareKeyList (or MifareClassicKeyList). Furthermore every entry has to be bitmask-combined with either KeyA or KeyB to inform the reader if the key at the corresponding key index shall be applied as key A or key B. 
        
        If this value contains less entries than MifareSectorList the missing entries will be filled up by duplicating the last entry in this list. If this value is not defined all sectors will be written by using key 1 as KeyB. 
        
        **This value is used by Mifare classic firmware only. For Mifare plus firmware use MifarePlusKeyAssignment instead.**
        """
        return VhlCfg_File_MifareClassicWriteKeyAssignment(self)
    @property
    def VhlCfg_File_MifareClassicFormatOriginalKeyList(self) -> VhlCfg_File_MifareClassicFormatOriginalKeyList:
        """
        This list is only needed for VHL-Format() support. To encode the new sector trailer, the card is authenticated with one of these keys. The VHL Format command tries to authenticate with all keys if the list contains more than one key. 
        
        If this value is not set, the card will by authenticated with factory keys (0xFF, 0xFF, ... 0xFF; KeyA). 
        
        **This value is used by Mifare classic firmware only. For Mifare plus firmware use MifarePlusKeyAssignment instead.**
        """
        return VhlCfg_File_MifareClassicFormatOriginalKeyList(self)
    @property
    def VhlCfg_File_MifareClassicMadKeyB(self) -> VhlCfg_File_MifareClassicMadKeyB:
        """
        This list is only needed by VHL-Format(). If MAD encoding is enabled (refer to MifareMadAid), this value contains the write key (Key B) of the MAD. This key is needed by VHL Format to create the MAD / adapt the MAD when adding a new application. If MAD encoding is not enabled, this value may be omitted. 
        
        **This value is used by Mifare classic firmware only. For Mifare plus firmware use MifarePlusKeyAssignment instead.**
        """
        return VhlCfg_File_MifareClassicMadKeyB(self)
    @property
    def VhlCfg_File_PivPublicKey(self) -> VhlCfg_File_PivPublicKey:
        """
        This value specifies the public key (ECC P-256) required to perform PIV cardholder authentication via PKI-CAK (NIST SP 800-73). It must represent the public key of the certificate authority (CA) that issued the Card Authentication certificates stored on the cards to be authenticated and read. 
        
        **If this value isn't available, the firmware assumes self-signed certificates, and the public key is retrieved from the Card Authentication certificate.**
        """
        return VhlCfg_File_PivPublicKey(self)
    @property
    def VhlCfg_File_UltralightBlockList(self) -> VhlCfg_File_UltralightBlockList:
        """
        This configuration value is a list of 1 or more block descriptions that specify which Ultralight memory blocks have to be accessed by VHL. Each entry consists of 2 bytes: The first byte addresses the start block number (first block = 0), the second byte defines the number of blocks. 
        
        **This value is mandatory for an Ultralight VHL definition.**
        """
        return VhlCfg_File_UltralightBlockList(self)
    @property
    def VhlCfg_File_UltralightKeyIdx(self) -> VhlCfg_File_UltralightKeyIdx:
        """
        This entry is only needed for Ultralight-C. If defined, an authentication is performed to allow access to memory areas that are only readable and/or writeable after authentication.
        """
        return VhlCfg_File_UltralightKeyIdx(self)
    @property
    def VhlCfg_File_UltralightExtendedBlockList(self) -> VhlCfg_File_UltralightExtendedBlockList:
        """
        This configuration value is a list of 1 or more block descriptions that specify which Ultralight memory blocks have to be accessed by VHL. Each entry consists of 2 16 bit values: The first addresses the start block number (first block = 0), the second value defines the number of blocks.
        """
        return VhlCfg_File_UltralightExtendedBlockList(self)
    @property
    def VhlCfg_File_UltralightKeyList(self) -> VhlCfg_File_UltralightKeyList:
        """
        Contains the list of keys needed to access a MIFARE Ultralight C/EV1 card with this VHL file. These keys are referenced by VhlCfg/File/UltralightKeyIdx
        """
        return VhlCfg_File_UltralightKeyList(self)
    @property
    def VhlCfg_File_UltralightPassword(self) -> VhlCfg_File_UltralightPassword:
        """
        This entry is only needed for Ultralight-EV1 cards to allow access to password-protected memory areas. If defined, a password verification is performed.
        """
        return VhlCfg_File_UltralightPassword(self)
    @property
    def VhlCfg_File_Filename(self) -> VhlCfg_File_Filename:
        """
        This is mainly for use by host applications using VHL-Kommands. They can search for the corresponding VHL file ID via the VHL.ResolveFilename command if this name is known.
        """
        return VhlCfg_File_Filename(self)
    @property
    def VhlCfg_File_CardType(self) -> VhlCfg_File_CardType:
        """
        Usually the VHL system guesses the card type automatically and uses the corresponding configuration values for accessing the card. But for cases where the cardtype is guessed wrong or a card contains more than one cardtype this value can be used to force the VHL system to work as if a card of this type would have been detected.
        """
        return VhlCfg_File_CardType(self)
    @property
    def VhlCfg_File_RetryCnt(self) -> VhlCfg_File_RetryCnt:
        """
        This value specifies how often the firmware shall do retries when card access failed. 
        
        **This value is not supported in current firmware versions any more. The number of retries is determined automatically now (usually 1).**
        """
        return VhlCfg_File_RetryCnt(self)
__all__: list[str] = [
    "PublicConfigAccessor",
    "Autoread",
    "Autoread_Rule",
    "Autoread_Rule_Template",
    "Autoread_Rule_VhlFileIndex",
    "Autoread_Rule_ConstArea",
    "Autoread_Rule_CardTypes",
    "Autoread_Rule_CheckScriptId",
    "Autoread_Rule_MsgType",
    "Autoread_Rule_WiegandInputBitLen",
    "Autoread_Rule_CardFamilies",
    "Autoread_Rule_PrioritizationMode",
    "Autoread_Rule_PrioritizationTriggeringCardFamilies",
    "Autoread_Rule_OnMatchAction",
    "Autoread_Rule_AllowRandomSerialNumbers",
    "Autoread_Rule_OnMatchEvent",
    "Autoread_Rule_VhlFileName",
    "Autoread_Rule_CheckScript",
    "Autoread_Rule_BlackWhiteListTemplate",
    "Autoread_Rule_SendProtocol",
    "Autoread_Rule_TemplateExt1",
    "Autoread_Rule_TemplateExt2",
    "Autoread_Rule_Counter",
    "Autoread_Rule_OnMatchSendApdu",
    "Scripts",
    "Scripts_StaticMessages",
    "Scripts_StaticMessages_SendMessage",
    "Scripts_StaticMessages_SendMsgLegacy",
    "Scripts_StaticMessages_MatchMessage",
    "Scripts_Events",
    "Scripts_Events_OnSetState",
    "Scripts_Events_OnSetInput",
    "Scripts_Events_OnSetTamperAlarm",
    "Scripts_Events_OnSetGpio",
    "Scripts_Events_OnClearState",
    "Scripts_Events_OnClearInput",
    "Scripts_Events_OnClearTamperAlarm",
    "Scripts_Events_OnClearGpio",
    "Scripts_Events_OnPinEntry",
    "Scripts_Events_OnDetectedCard",
    "Scripts_Events_OnMatchMsg",
    "Scripts_Events_OnAccepted",
    "Scripts_Events_OnInvalidCard",
    "Scripts_Events_OnEnabledProtocol",
    "Scripts_Events_OnBlackWhiteListDenied",
    "Scripts_Events_OnSetGreenLed",
    "Scripts_Events_OnSetRedLed",
    "Scripts_Events_OnSetBeeper",
    "Scripts_Events_OnSetRelay",
    "Scripts_Events_OnSetBlueLed",
    "Scripts_Events_OnClearGreenLed",
    "Scripts_Events_OnClearRedLed",
    "Scripts_Events_OnClearBeeper",
    "Scripts_Events_OnClearRelay",
    "Scripts_Events_OnClearBlueLed",
    "Scripts_Events_OnTimer",
    "Scripts_Events_OnConfigCardSucceeded",
    "Scripts_Events_OnConfigCardFailed",
    "Scripts_Events_OnPowerup",
    "Scripts_Events_OnAutoreadEnabled",
    "Scripts_Events_OnAutoreadDisabled",
    "Scripts_Events_OnScan",
    "Scripts_Events_OnDetectedNoCard",
    "Scripts_Events_OnCheckSuppressRepeat",
    "Scripts_Events_OnBrpCommand",
    "Scripts_Events_OnCardRemoved",
    "Scripts_Events_OnCardProcessed",
    "Scripts_Events_OnCardAcceptedByHost",
    "Scripts_Events_OnCardDeniedByHost",
    "Device",
    "Device_Keypad",
    "Device_Keypad_SpecialKeySettings",
    "Device_Keypad_Timeout",
    "Device_Keypad_PinLength",
    "Device_Keypad_KeyPressSignal",
    "Device_Boot",
    "Device_Boot_FireInputEventAtPowerup",
    "Device_Boot_FireTamperEventAtPowerup",
    "Device_Boot_FireGpioEventAtPowerup",
    "Device_Boot_StartAutoreadAtPowerup",
    "Device_Boot_FirmwareCrcCheck",
    "Device_Run",
    "Device_Run_ConfigCardAcceptTime",
    "Device_Run_EnabledProtocols",
    "Device_Run_AutoreadPulseHf",
    "Device_Run_RepeatMessageDelay",
    "Device_Run_RepeatMessageMode",
    "Device_Run_RestrictFirmwareRelease",
    "Device_Run_EnableProtocolOnBAC",
    "Device_Run_AccessRightsOfBAC",
    "Device_Run_FirmwareVersionBlacklist",
    "Device_Run_DefaultBusAdrForBAC",
    "Device_Run_MessageExpireTimeout",
    "Device_Run_AutoreadPollTime",
    "Device_Run_AuthReqUploadViaBrp",
    "Device_Run_AuthReqUploadViaIso14443",
    "Device_Run_AutoreadWaitForCardRemoval",
    "Device_Run_UsbVendorId",
    "Device_Run_UsbProductId",
    "Device_Run_DenyUploadViaIso14443",
    "Device_Run_DenyReaderInfoViaIso14443",
    "Device_Run_DenyUnauthFwUploadViaBrp",
    "Device_Run_SetBusAdrOnUploadViaIso14443",
    "Device_Run_MaintenanceFunctionFilter",
    "Device_Run_BusAdressByBAC32Bit",
    "Device_Run_ConfigCardMifareKey",
    "Device_Run_ConfigSecurityCode",
    "Device_Run_CustomerKey",
    "Device_Run_AltConfigSecurityCode",
    "Device_Run_ConfigCardDesfireKey",
    "Device_HostSecurity",
    "Device_HostSecurity_AccessConditionMask",
    "Device_HostSecurity_Key",
    "Device_VirtualLeds",
    "Device_VirtualLeds_TransitionTime",
    "Device_VirtualLeds_PulsePeriod",
    "Device_VirtualLeds_CustomVledDefinition",
    "Custom",
    "Custom_BlackWhiteList",
    "Custom_BlackWhiteList_ListMode",
    "Custom_BlackWhiteList_RangeStart",
    "Custom_BlackWhiteList_RangeEnd",
    "Custom_BlackWhiteList_EntrySize",
    "Custom_BlackWhiteList_List",
    "Custom_AdminData",
    "Custom_AdminData_CustomerNo",
    "Custom_AdminData_DeviceSettingsNo",
    "Custom_AdminData_DeviceSettingsName",
    "Custom_AdminData_DeviceSettingsVersion",
    "Custom_AdminData_ProjectSettingsNo",
    "Custom_AdminData_ProjectName",
    "Custom_AdminData_ProjectSettingsVersion",
    "Project",
    "Project_VhlSettings",
    "Project_VhlSettings_ScanCardFamilies",
    "Project_VhlSettings_ForceReselect",
    "Project_VhlSettings_DelayRequestATS",
    "Project_VhlSettings_DelayPerformPPS",
    "Project_VhlSettings_MaxBaudrateIso14443A",
    "Project_VhlSettings_MaxBaudrateIso14443B",
    "Project_VhlSettings_PrioritizeCardFamilies",
    "Project_VhlSettings_PrioritizationTriggeringCardFamilies",
    "Project_VhlSettings_PrioritizeDelay",
    "Project_VhlSettings_ConfCardCardFamilies",
    "Project_VhlSettings_Iso14aVasup",
    "Project_HidSam",
    "Project_HidSam_Confcard",
    "Project_HidSam_ScanTime",
    "Project_HidSam_Retries",
    "Project_VhlSettings125Khz",
    "Project_VhlSettings125Khz_ScanCardTypesPart1",
    "Project_VhlSettings125Khz_ScanCardTypesPart2",
    "Project_VhlSettings125Khz_TTFModType",
    "Project_VhlSettings125Khz_TTFBaudrate",
    "Project_VhlSettings125Khz_TTFHeaderLength",
    "Project_VhlSettings125Khz_TTFHeader",
    "Project_VhlSettings125Khz_TTFDataLength",
    "Project_VhlSettings125Khz_TTFOkCounter",
    "Project_VhlSettings125Khz_IndaspDecode",
    "Project_VhlSettings125Khz_IndaspParityCheck",
    "Project_VhlSettings125Khz_TTFReadStartpos",
    "Project_VhlSettings125Khz_HidProxSerialNrFormat",
    "Project_VhlSettings125Khz_ModType",
    "Project_VhlSettings125Khz_BaudRate",
    "Project_VhlSettings125Khz_SnrVersionCotag",
    "Project_VhlSettings125Khz_SnrVersionIdteck",
    "Project_VhlSettings125Khz_EM4100SerialNrFormat",
    "Project_VhlSettings125Khz_AwidSerialNrFormat",
    "Project_VhlSettings125Khz_IoProxSerialNrFormat",
    "Project_VhlSettings125Khz_PyramidSerialNrFormat",
    "Project_VhlSettings125Khz_ObidCardIdFormat",
    "Project_SamAVx",
    "Project_SamAVx_PowerUpState",
    "Project_SamAVx_UnlockKeyNr",
    "Project_SamAVx_UnlockKeyVersion",
    "Project_SamAVx_UnlockKeyCryptoMemoryIdx",
    "Project_SamAVx_AuthKeyNr",
    "Project_SamAVx_AuthKeyVersion",
    "Project_SamAVx_AuthKeyCryptoMemoryIdx",
    "Project_SamAVx_SecureMessaging",
    "Project_SamAVx_LogicalChannel",
    "Project_SamAVx_AnswerToReset",
    "Project_CryptoKey",
    "Project_CryptoKey_Entry",
    "Project_DiversificationData",
    "Project_DiversificationData_Entry",
    "Project_SamAVxKeySettings",
    "Project_SamAVxKeySettings_Index",
    "Project_LegicKeySettings",
    "Project_LegicKeySettings_Index",
    "Project_LegicVcp",
    "Project_LegicVcp_Status",
    "Project_LegicVcp_VcpKeyIndex",
    "Project_LegicVcp_VcpFile4000Hash",
    "Project_LegicVcp_VcpFile4000Data",
    "Project_LegicVcp_VcpFile6000Hash",
    "Project_LegicVcp_VcpFile6000Data",
    "Project_LegicVcp_Password",
    "Project_MobileId",
    "Project_MobileId_Mode",
    "Project_MobileId_DisplayName",
    "Project_MobileId_TriggerFromDistance",
    "Project_MobileId_ConvenientAccess",
    "Project_MobileId_AdvertisementFilter",
    "Project_MobileId_RssiCorrectionConvenientAccess",
    "Project_MobileId_DetectionRssiFilter",
    "Project_MobileId_RssiOffset",
    "Project_MobileId_MsgType",
    "Project_MobileId_OnMatchEvent",
    "Project_MobileId_Template",
    "Project_MobileId_Key",
    "Protocols",
    "Protocols_BrpSerial",
    "Protocols_BrpSerial_Baudrate",
    "Protocols_BrpSerial_Parity",
    "Protocols_BrpSerial_InterbyteTimeout",
    "Protocols_BrpSerial_CmdWorkInterval",
    "Protocols_BrpSerial_RepeatModeMinDelay",
    "Protocols_BrpSerial_HostMsgFormatTemplate",
    "Protocols_BrpSerial_AutoRunCommand",
    "Protocols_BrpHid",
    "Protocols_BrpHid_CmdWorkInterval",
    "Protocols_BrpHid_RepeatModeMinDelay",
    "Protocols_BrpHid_UsbVendorName",
    "Protocols_BrpHid_UsbProductName",
    "Protocols_BrpHid_UsbSerialNumber",
    "Protocols_BrpHid_HostMsgFormatTemplate",
    "Protocols_BrpHid_AutoRunCommand",
    "Protocols_SNet",
    "Protocols_SNet_BusAddress",
    "Protocols_SNet_DeviceType",
    "Protocols_SNet_HostMsgFormatTemplate",
    "Protocols_Bpa9",
    "Protocols_Bpa9_HostMsgFormatTemplate",
    "Protocols_Wiegand",
    "Protocols_Wiegand_HostMsgFormatTemplate",
    "Protocols_Wiegand_MessageLength",
    "Protocols_Wiegand_BitOrder",
    "Protocols_Wiegand_PinMessageFormat",
    "Protocols_Wiegand_PulseWidth",
    "Protocols_Wiegand_PulseInterval",
    "Protocols_Wiegand_Mode",
    "Protocols_RawSerial",
    "Protocols_RawSerial_Baudrate",
    "Protocols_RawSerial_Parity",
    "Protocols_RawSerial_BitsPerByte",
    "Protocols_RawSerial_Channel",
    "Protocols_RawSerial_HostMsgFormatTemplate",
    "Protocols_LowLevelIoPorts",
    "Protocols_LowLevelIoPorts_PhysicalPinMap",
    "Protocols_MagstripeEmulation",
    "Protocols_MagstripeEmulation_Encoding",
    "Protocols_Network",
    "Protocols_Network_IpAddress",
    "Protocols_Network_IpSubnetMask",
    "Protocols_Network_IpGateway",
    "Protocols_Network_IpDnsServer",
    "Protocols_Network_DhcpMode",
    "Protocols_KeyboardEmulation",
    "Protocols_KeyboardEmulation_RegisterInterface",
    "Protocols_KeyboardEmulation_ScancodesMap",
    "Protocols_KeyboardEmulation_KeypressDelay",
    "Protocols_KeyboardEmulation_UsbInterfaceSubClass",
    "Protocols_KeyboardEmulation_UsbInterfaceOrder",
    "Protocols_KeyboardEmulation_HostMsgFormatTemplate",
    "Protocols_Ccid",
    "Protocols_Ccid_CardTypeMask",
    "Protocols_Ccid_ForceApduCardType",
    "Protocols_Ccid_LedControl",
    "Protocols_Osdp",
    "Protocols_Osdp_BaudRate",
    "Protocols_Osdp_Address",
    "Protocols_Osdp_CharTimeout",
    "Protocols_Osdp_SCBKeyDefault",
    "Protocols_Osdp_SCBKey",
    "Protocols_Osdp_SecureInstallMode",
    "Protocols_Osdp_DataMode",
    "Protocols_Osdp_HostMsgFormatTemplate",
    "Protocols_HttpsClient",
    "Protocols_HttpsClient_AuthUrl",
    "Protocols_HttpsClient_ReaderUpdateUrl",
    "Protocols_HttpsClient_IfconverterUpdateUrl",
    "Protocols_HttpsClient_UpdateTime",
    "Protocols_HttpsClient_UpdateTimeSpread",
    "Protocols_HttpsClient_InitialEncryptedAuthToken",
    "Protocols_HttpsClient_RootCertServer",
    "Protocols_AccessConditionBitsStd",
    "Protocols_AccessConditionBitsStd_BrpOverSerial",
    "Protocols_AccessConditionBitsStd_BrpOverHid",
    "Protocols_AccessConditionBitsStd_BrpOverOsdp",
    "Protocols_AccessConditionBitsStd_Ccid",
    "Protocols_AccessConditionBitsAlt",
    "Protocols_AccessConditionBitsAlt_BrpOverOsdpLimited",
    "VhlCfg",
    "VhlCfg_File",
    "VhlCfg_File_AreaList125",
    "VhlCfg_File_Secret125",
    "VhlCfg_File_DesfireAid",
    "VhlCfg_File_DesfireKeyList",
    "VhlCfg_File_DesfireFileDesc",
    "VhlCfg_File_DesfirePiccMasterKeys",
    "VhlCfg_File_DesfireProtocol",
    "VhlCfg_File_DesfireMapKeyidx",
    "VhlCfg_File_DesfireRandomIdKey",
    "VhlCfg_File_DesfireProxcheck",
    "VhlCfg_File_DesfireVcsParams",
    "VhlCfg_File_DesfireEV2FormatFileMultAccessCond",
    "VhlCfg_File_ForceCardSM",
    "VhlCfg_File_DesfireDiversificationData",
    "VhlCfg_File_DesfireSoftUid",
    "VhlCfg_File_FelicaSystemCode",
    "VhlCfg_File_FelicaServiceCodeList",
    "VhlCfg_File_FelicaAreaList",
    "VhlCfg_File_FidoRpid",
    "VhlCfg_File_FidoPublicKey",
    "VhlCfg_File_IntIndFileDescList",
    "VhlCfg_File_IntIndSegment",
    "VhlCfg_File_IntIndKeyIdx",
    "VhlCfg_File_IntIndRecordNumber",
    "VhlCfg_File_IntIndOnReadSelectOnly",
    "VhlCfg_File_IntIndTimeout",
    "VhlCfg_File_Iso15Afi",
    "VhlCfg_File_Iso15DsfId",
    "VhlCfg_File_Iso15BlockList",
    "VhlCfg_File_Iso15BlockSize",
    "VhlCfg_File_Iso15WriteOptFlag",
    "VhlCfg_File_Iso15ReadCmd",
    "VhlCfg_File_Iso15WriteCmd",
    "VhlCfg_File_Iso15ExtendedBlockList",
    "VhlCfg_File_LegicSegmentListLegacy",
    "VhlCfg_File_LegicLengthList",
    "VhlCfg_File_LegicAddressList",
    "VhlCfg_File_LegicCRCAddressList",
    "VhlCfg_File_LegicSegmentTypeList",
    "VhlCfg_File_LegicUserKeyIndexList",
    "VhlCfg_File_LegicMasterTokenZoneList",
    "VhlCfg_File_LegicCtcFileSystemList",
    "VhlCfg_File_LegicApplicationSegmentList",
    "VhlCfg_File_LegicKeyList",
    "VhlCfg_File_MifareMode",
    "VhlCfg_File_MifarePlusMadKeyBIndex",
    "VhlCfg_File_MifareKeyList",
    "VhlCfg_File_MifareTransferToSecureMemory",
    "VhlCfg_File_MifareMadAid",
    "VhlCfg_File_MifarePlusAesKeyList",
    "VhlCfg_File_MifareSectorList",
    "VhlCfg_File_MifarePlusKeyAssignment",
    "VhlCfg_File_MifarePlusCommunicationMode",
    "VhlCfg_File_MifarePlusProxyimityCheck",
    "VhlCfg_File_MifareVcsParams",
    "VhlCfg_File_MifarePlusKeyIdxOffset",
    "VhlCfg_File_MifareClassicFormatSectorTrailer",
    "VhlCfg_File_MifareClassicKeyList",
    "VhlCfg_File_MifareClassicBlockList",
    "VhlCfg_File_MifareClassicReadKeyAssignment",
    "VhlCfg_File_MifareClassicWriteKeyAssignment",
    "VhlCfg_File_MifareClassicFormatOriginalKeyList",
    "VhlCfg_File_MifareClassicMadKeyB",
    "VhlCfg_File_PivPublicKey",
    "VhlCfg_File_UltralightBlockList",
    "VhlCfg_File_UltralightKeyIdx",
    "VhlCfg_File_UltralightExtendedBlockList",
    "VhlCfg_File_UltralightKeyList",
    "VhlCfg_File_UltralightPassword",
    "VhlCfg_File_Filename",
    "VhlCfg_File_CardType",
    "VhlCfg_File_RetryCnt",
]