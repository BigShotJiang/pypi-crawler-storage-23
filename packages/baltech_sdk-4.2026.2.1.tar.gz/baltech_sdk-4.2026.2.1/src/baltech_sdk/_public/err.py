
from ..generator_interface import DeviceError
class ARCommandGroupError(DeviceError):
    ErrorCode = 0x00010500
    URL = "https://docs.baltech.de/refman/cmds/ar/index.html"
class AR_ErrNoMessage(ARCommandGroupError):
    """
    No valid card has been presented to the reader so far.
    """
    ErrorCode = 0x00010501
    URL = "https://docs.baltech.de/refman/cmds/ar/index.html#AR.ErrNoMessage"
class AR_ErrScriptRuntime(ARCommandGroupError):
    """
    A runtime error occurred when executing the script.
    """
    ErrorCode = 0x00010502
    URL = "https://docs.baltech.de/refman/cmds/ar/index.html#AR.ErrScriptRuntime"
class AR_ErrScriptSyntax(ARCommandGroupError):
    """
    There's a syntax error in the script code.
    """
    ErrorCode = 0x00010503
    URL = "https://docs.baltech.de/refman/cmds/ar/index.html#AR.ErrScriptSyntax"
class AR_ErrScriptNotImplemented(ARCommandGroupError):
    """
    The script ran the command DefaultAction.
    """
    ErrorCode = 0x00010504
    URL = "https://docs.baltech.de/refman/cmds/ar/index.html#AR.ErrScriptNotImplemented"
class AR_ErrArDisabled(ARCommandGroupError):
    """
    Autoread is disabled.
    """
    ErrorCode = 0x00010510
    URL = "https://docs.baltech.de/refman/cmds/ar/index.html#AR.ErrArDisabled"
class BlePeriphCommandGroupError(DeviceError):
    ErrorCode = 0x00014B00
    URL = "https://docs.baltech.de/refman/cmds/bleperiph/index.html"
class BlePeriph_ErrNotEnabled(BlePeriphCommandGroupError):
    """
    The command could not be executed because BLE is currently not enabled.
    """
    ErrorCode = 0x00014B01
    URL = "https://docs.baltech.de/refman/cmds/bleperiph/index.html#BlePeriph.ErrNotEnabled"
class BlePeriph_ErrNotConnected(BlePeriphCommandGroupError):
    """
    The reader is currently not connected with a BLE central.
    """
    ErrorCode = 0x00014B02
    URL = "https://docs.baltech.de/refman/cmds/bleperiph/index.html#BlePeriph.ErrNotConnected"
class BlePeriph_ErrInvalidCharacteristicNdx(BlePeriphCommandGroupError):
    """
    The given characteristic index is invalid.
    """
    ErrorCode = 0x00014B03
    URL = "https://docs.baltech.de/refman/cmds/bleperiph/index.html#BlePeriph.ErrInvalidCharacteristicNdx"
class BlePeriph_ErrWriteCharacteristic(BlePeriphCommandGroupError):
    """
    The characteristic value could not be written because the given offset or length exceeds the characteristic size.
    """
    ErrorCode = 0x00014B04
    URL = "https://docs.baltech.de/refman/cmds/bleperiph/index.html#BlePeriph.ErrWriteCharacteristic"
class CryptoCommandGroupError(DeviceError):
    ErrorCode = 0x00010200
    URL = "https://docs.baltech.de/refman/cmds/crypto/index.html"
class Crypto_CrptErrInvalidBlock(CryptoCommandGroupError):
    """
    Encrypted block format is invalid.
    """
    ErrorCode = 0x00010201
    URL = "https://docs.baltech.de/refman/cmds/crypto/index.html#Crypto.CrptErrInvalidBlock"
class Crypto_CrptErrAuth(CryptoCommandGroupError):
    """
    Internal key cannot be accessed for the specified action due to the access condition flags settings.
    """
    ErrorCode = 0x00010202
    URL = "https://docs.baltech.de/refman/cmds/crypto/index.html#Crypto.CrptErrAuth"
class Crypto_CrptErrKeyNotFound(CryptoCommandGroupError):
    """
    Specified key not available in the internal key list.
    """
    ErrorCode = 0x00010203
    URL = "https://docs.baltech.de/refman/cmds/crypto/index.html#Crypto.CrptErrKeyNotFound"
class Crypto_CrptErrWriteConfigkey(CryptoCommandGroupError):
    """
    Configuration key cannot be stored in the reader's configuration.
    """
    ErrorCode = 0x00010204
    URL = "https://docs.baltech.de/refman/cmds/crypto/index.html#Crypto.CrptErrWriteConfigkey"
class Crypto_CrptErrInvalidKey(CryptoCommandGroupError):
    """
    No valid configuration card key. Since no key is present, the reader is forced to work unencrypted. 
    
    **This status code is not supported by Crypto.Encrypt/Crypto.Decrypt commands due to legacy reasons.**
    """
    ErrorCode = 0x00010205
    URL = "https://docs.baltech.de/refman/cmds/crypto/index.html#Crypto.CrptErrInvalidKey"
class DesfireCommandGroupError(DeviceError):
    ErrorCode = 0x00011B00
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html"
class Desfire_ErrIso14NoTag(DesfireCommandGroupError):
    """
    There's no card in the HF field, or the card doesn't respond.
    """
    ErrorCode = 0x00011B01
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrIso14NoTag"
class Desfire_ErrBreak(DesfireCommandGroupError):
    """
    The command has been aborted because the HF interface has been requested by another task or command. Please reselect the card. 
    
    **This error only occurs when you combine VHL and low-level commands. We highly recommend you avoid that combination as these 2 command sets will interfere with each other's card states.**
    """
    ErrorCode = 0x00011B03
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrBreak"
class Desfire_ErrIso14Hf(DesfireCommandGroupError):
    """
    The response frame received from the PICC is invalid, e.g. it may contain an invalid number of bits. Please rerun the command.
    """
    ErrorCode = 0x00011B04
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrIso14Hf"
class Desfire_ErrIso14CardInvalid(DesfireCommandGroupError):
    """
    The card behaves in an unspecified way or is corrupted. Please rerun the command or reselect the card.
    """
    ErrorCode = 0x00011B05
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrIso14CardInvalid"
class Desfire_ErrReaderChipCommunication(DesfireCommandGroupError):
    """
    Communication with the reader's HF interface has failed. Please reset the HF interface with Sys.HFReset and check the reader status with Sys.GetBootStatus.
    """
    ErrorCode = 0x00011B06
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrReaderChipCommunication"
class Desfire_ErrIso14ApduCmd(DesfireCommandGroupError):
    """
    ISO 14443-4 error: The command or parameters are invalid.
    """
    ErrorCode = 0x00011B07
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrIso14ApduCmd"
class Desfire_ErrIso14InvalidResponse(DesfireCommandGroupError):
    """
    ISO 14443-4 error: The card returned an invalid response, e.g. data with an invalid length. This may have several reasons, e.g. a wrong card type.
    """
    ErrorCode = 0x00011B08
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrIso14InvalidResponse"
class Desfire_ErrPcdAuthentication(DesfireCommandGroupError):
    """
    Authentication with the PICC has failed, e.g. because the encryption algorithm or key is wrong.
    """
    ErrorCode = 0x00011B09
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrPcdAuthentication"
class Desfire_ErrIntegrity(DesfireCommandGroupError):
    """
    Secure messaging error: The CRC or MAC checksum doesn't match the transmitted data. Authentication has been lost. Please reauthenticate and rerun the commands.
    """
    ErrorCode = 0x00011B0A
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrIntegrity"
class Desfire_ErrPcdKey(DesfireCommandGroupError):
    """
    The key in the SAM/crypto memory is invalid or missing.
    """
    ErrorCode = 0x00011B0B
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrPcdKey"
class Desfire_ErrNoChanges(DesfireCommandGroupError):
    """
    Card error as per DESFire specification: No changes done to backup files, CommitTransaction / AbortTransaction not necessary.
    """
    ErrorCode = 0x00011B0C
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrNoChanges"
class Desfire_ErrPcdParam(DesfireCommandGroupError):
    """
    The BRP command contains an invalid parameter.
    """
    ErrorCode = 0x00011B0D
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrPcdParam"
class Desfire_VcsAndProxCheckError(DesfireCommandGroupError):
    """
    The proximity check has timed out. Please reselect the card.
    """
    ErrorCode = 0x00011B0F
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.VcsAndProxCheckError"
class Desfire_ErrFirmwareNotSupported(DesfireCommandGroupError):
    """
    This command or parameter isn't supported by the reader firmware.
    """
    ErrorCode = 0x00011B10
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrFirmwareNotSupported"
class Desfire_ErrSamCommunication(DesfireCommandGroupError):
    """
    Communication with the SAM has failed. This may have several reasons, e.g. the wrong SAM type or a failure to activate the SAM. Please check the SAM status and reset the reader with Sys.Reset.
    """
    ErrorCode = 0x00011B11
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrSamCommunication"
class Desfire_ErrSamUnlock(DesfireCommandGroupError):
    """
    Unlocking/authenticating with the SAM has failed. Please check the SamAVx configuration values.
    """
    ErrorCode = 0x00011B12
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrSamUnlock"
class Desfire_ErrHardwareNotSupported(DesfireCommandGroupError):
    """
    This command isn't supported by the reader hardware. 
    
    **This error may refer to any hardware component.**
    """
    ErrorCode = 0x00011B13
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrHardwareNotSupported"
class Desfire_ErrIllegalCmdLegacy(DesfireCommandGroupError):
    """
    Card error as per DESFire specification: Command code not supported by card. This status code is identical to ErrIllegalCmd (0x33) und returned be older firmware versions.
    """
    ErrorCode = 0x00011B1C
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrIllegalCmdLegacy"
class Desfire_ErrLength(DesfireCommandGroupError):
    """
    Card error as per DESFire specification: Length of command string invalid.
    """
    ErrorCode = 0x00011B20
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrLength"
class Desfire_ErrPermissionDenied(DesfireCommandGroupError):
    """
    Card error as per DESFire specification: Current configuration/state does not allow the requested command.
    """
    ErrorCode = 0x00011B21
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrPermissionDenied"
class Desfire_ErrParameter(DesfireCommandGroupError):
    """
    Card error as per DESFire specification: Value of the parameter invalid.
    """
    ErrorCode = 0x00011B22
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrParameter"
class Desfire_ErrAppNotFound(DesfireCommandGroupError):
    """
    Card error as per DESFire specification: Requested AID not present on PICC.
    """
    ErrorCode = 0x00011B23
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrAppNotFound"
class Desfire_ErrAppIntegrity(DesfireCommandGroupError):
    """
    Card error as per DESFire specification: Unrecoverable error in application. Application will be disabled.
    """
    ErrorCode = 0x00011B24
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrAppIntegrity"
class Desfire_ErrAuthentication(DesfireCommandGroupError):
    """
    Card error as per DESFire specification: Current authentication status does not allow execution of requested command.
    """
    ErrorCode = 0x00011B25
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrAuthentication"
class Desfire_ErrBoundary(DesfireCommandGroupError):
    """
    Card error as per DESFire specification: Attempted to read/write beyond the limits of the file.
    """
    ErrorCode = 0x00011B27
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrBoundary"
class Desfire_ErrPiccIntegrity(DesfireCommandGroupError):
    """
    Card error as per DESFire specification: Unrecoverable error within PICC, PICC will be disabled.
    """
    ErrorCode = 0x00011B28
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrPiccIntegrity"
class Desfire_ErrCommandAborted(DesfireCommandGroupError):
    """
    Card error as per DESFire specification: Previous command was not fully completed. Not all frames were requested or provided by the reader.
    """
    ErrorCode = 0x00011B29
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrCommandAborted"
class Desfire_ErrPiccDisabled(DesfireCommandGroupError):
    """
    Card error as per DESFire specification: PICC was disabled by an unrecoverable error.
    """
    ErrorCode = 0x00011B2A
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrPiccDisabled"
class Desfire_ErrCount(DesfireCommandGroupError):
    """
    Card error as per DESFire specification: Number of applications limited to 28, no additional CreateApplication possible.
    """
    ErrorCode = 0x00011B2B
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrCount"
class Desfire_ErrDuplicate(DesfireCommandGroupError):
    """
    Card error as per DESFire specification: Creation of file/application failed because file/application with same number already exists.
    """
    ErrorCode = 0x00011B2C
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrDuplicate"
class Desfire_ErrEeprom(DesfireCommandGroupError):
    """
    Card error as per DESFire specification: Could not complete NV-write operation due to loss of power, internal backup/rollback mechanism activated.
    """
    ErrorCode = 0x00011B2D
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrEeprom"
class Desfire_ErrFileNotFound(DesfireCommandGroupError):
    """
    Card error as per DESFire specification: Specified file number does not exist.
    """
    ErrorCode = 0x00011B2E
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrFileNotFound"
class Desfire_ErrFileIntegrity(DesfireCommandGroupError):
    """
    Card error as per DESFire specification: Unrecoverable error within file, file will be disabled.
    """
    ErrorCode = 0x00011B2F
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrFileIntegrity"
class Desfire_ErrNoSuchKey(DesfireCommandGroupError):
    """
    Card error as per DESFire specification: Invalid key number specified.
    """
    ErrorCode = 0x00011B30
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrNoSuchKey"
class Desfire_ErrOutOfMemory(DesfireCommandGroupError):
    """
    Card error as per DESFire specification: Insufficient NV-Memory to complete command .
    """
    ErrorCode = 0x00011B32
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrOutOfMemory"
class Desfire_ErrIllegalCmd(DesfireCommandGroupError):
    """
    Card error as per DESFire specification: Command code not supported by card.
    """
    ErrorCode = 0x00011B33
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrIllegalCmd"
class Desfire_ErrCmdOverflow(DesfireCommandGroupError):
    """
    Card error as per DESFire specification: Too many commands in the session or transaction.
    """
    ErrorCode = 0x00011B34
    URL = "https://docs.baltech.de/refman/cmds/desfire/index.html#Desfire.ErrCmdOverflow"
class FelicaCommandGroupError(DeviceError):
    ErrorCode = 0x00011C00
    URL = "https://docs.baltech.de/refman/cmds/felica/index.html"
class Felica_ErrFelicaNoTag(FelicaCommandGroupError):
    """
    No PICC in HF field.
    """
    ErrorCode = 0x00011C01
    URL = "https://docs.baltech.de/refman/cmds/felica/index.html#Felica.ErrFelicaNoTag"
class Felica_ErrFelicaHf(FelicaCommandGroupError):
    """
    PICC-reader communication error.
    """
    ErrorCode = 0x00011C04
    URL = "https://docs.baltech.de/refman/cmds/felica/index.html#Felica.ErrFelicaHf"
class Felica_ErrFelicaFrame(FelicaCommandGroupError):
    """
    Bit error, parity error or frame error.
    """
    ErrorCode = 0x00011C07
    URL = "https://docs.baltech.de/refman/cmds/felica/index.html#Felica.ErrFelicaFrame"
class Felica_ErrFelicaCom(FelicaCommandGroupError):
    """
    Communication error uC - reader chip.
    """
    ErrorCode = 0x00011C10
    URL = "https://docs.baltech.de/refman/cmds/felica/index.html#Felica.ErrFelicaCom"
class Felica_ErrFelicaCardNotSupported(FelicaCommandGroupError):
    """
    Reader chip does not support cardtype-selected baud rate.
    """
    ErrorCode = 0x00011C22
    URL = "https://docs.baltech.de/refman/cmds/felica/index.html#Felica.ErrFelicaCardNotSupported"
class Iso14aCommandGroupError(DeviceError):
    ErrorCode = 0x00011300
    URL = "https://docs.baltech.de/refman/cmds/iso14a/index.html"
class Iso14a_ErrNoTag(Iso14aCommandGroupError):
    """
    No card in field of antenna or card in field of antenna does not match the given VHL-file.
    """
    ErrorCode = 0x00011301
    URL = "https://docs.baltech.de/refman/cmds/iso14a/index.html#Iso14a.ErrNoTag"
class Iso14a_ErrCollision(Iso14aCommandGroupError):
    """
    More than one PICC answered in the same time slot and none of them could therefore be requested correctly. 
    
    **In case this status code is returned by the Iso14a.Request command, when two or more ISO 14443 Type A PICCs of different types (e.g. one Mifare Classic card and one Mifare DESFire card) are present in the HF field of the reader, the AQTA response will still be returned and the card selection procedure can be continued normally with the Iso14a.Select command.**
    """
    ErrorCode = 0x00011302
    URL = "https://docs.baltech.de/refman/cmds/iso14a/index.html#Iso14a.ErrCollision"
class Iso14a_ErrHf(Iso14aCommandGroupError):
    """
    General HF error.
    """
    ErrorCode = 0x00011304
    URL = "https://docs.baltech.de/refman/cmds/iso14a/index.html#Iso14a.ErrHf"
class Iso14a_ErrFrame(Iso14aCommandGroupError):
    """
    Bit error, Parity error or Frame error (start/stop bit).
    """
    ErrorCode = 0x00011307
    URL = "https://docs.baltech.de/refman/cmds/iso14a/index.html#Iso14a.ErrFrame"
class Iso14a_ErrCrc(Iso14aCommandGroupError):
    """
    CRC checksum error.
    """
    ErrorCode = 0x00011308
    URL = "https://docs.baltech.de/refman/cmds/iso14a/index.html#Iso14a.ErrCrc"
class Iso14a_ErrCom(Iso14aCommandGroupError):
    """
    Error in communication with reader chip.
    """
    ErrorCode = 0x00011310
    URL = "https://docs.baltech.de/refman/cmds/iso14a/index.html#Iso14a.ErrCom"
class Iso14bCommandGroupError(DeviceError):
    ErrorCode = 0x00011400
    URL = "https://docs.baltech.de/refman/cmds/iso14b/index.html"
class Iso14b_ErrNoTag(Iso14bCommandGroupError):
    """
    No card in field of antenna or card in field of antenna does not match given VHL-file.
    """
    ErrorCode = 0x00011401
    URL = "https://docs.baltech.de/refman/cmds/iso14b/index.html#Iso14b.ErrNoTag"
class Iso14b_ErrCollision(Iso14bCommandGroupError):
    """
    More than one PICC answered in the same time slot and none of them could therefore be requested correctly. The Iso14b.Request command needs to be called again, maybe with more time slots.
    """
    ErrorCode = 0x00011402
    URL = "https://docs.baltech.de/refman/cmds/iso14b/index.html#Iso14b.ErrCollision"
class Iso14b_ErrHf(Iso14bCommandGroupError):
    """
    General HF error.
    """
    ErrorCode = 0x00011404
    URL = "https://docs.baltech.de/refman/cmds/iso14b/index.html#Iso14b.ErrHf"
class Iso14b_ErrFrame(Iso14bCommandGroupError):
    """
    Bit error, parity error or frame error (start/stop bit).
    """
    ErrorCode = 0x00011407
    URL = "https://docs.baltech.de/refman/cmds/iso14b/index.html#Iso14b.ErrFrame"
class Iso14b_ErrCom(Iso14bCommandGroupError):
    """
    Error in communication with reader chip.
    """
    ErrorCode = 0x00011410
    URL = "https://docs.baltech.de/refman/cmds/iso14b/index.html#Iso14b.ErrCom"
class Iso14b_ErrMem(Iso14bCommandGroupError):
    """
    Either internal list of labels or response buffer full.
    """
    ErrorCode = 0x00011423
    URL = "https://docs.baltech.de/refman/cmds/iso14b/index.html#Iso14b.ErrMem"
class Iso14L4CommandGroupError(DeviceError):
    ErrorCode = 0x00011600
    URL = "https://docs.baltech.de/refman/cmds/iso14l4/index.html"
class Iso14L4_ErrNoTag(Iso14L4CommandGroupError):
    """
    No card in field of antenna or card in field of antenna does not match given VHL-file.
    """
    ErrorCode = 0x00011601
    URL = "https://docs.baltech.de/refman/cmds/iso14l4/index.html#Iso14L4.ErrNoTag"
class Iso14L4_ErrHf(Iso14L4CommandGroupError):
    """
    General HF error.
    """
    ErrorCode = 0x00011604
    URL = "https://docs.baltech.de/refman/cmds/iso14l4/index.html#Iso14L4.ErrHf"
class Iso14L4_ErrCard(Iso14L4CommandGroupError):
    """
    PICC corrupt or behaves unspecified.
    """
    ErrorCode = 0x00011605
    URL = "https://docs.baltech.de/refman/cmds/iso14l4/index.html#Iso14L4.ErrCard"
class Iso14L4_ErrCom(Iso14L4CommandGroupError):
    """
    Error in communication to reader chip.
    """
    ErrorCode = 0x00011610
    URL = "https://docs.baltech.de/refman/cmds/iso14l4/index.html#Iso14L4.ErrCom"
class Iso14L4_ErrCmd(Iso14L4CommandGroupError):
    """
    Command and/or parameters invalid.
    """
    ErrorCode = 0x00011623
    URL = "https://docs.baltech.de/refman/cmds/iso14l4/index.html#Iso14L4.ErrCmd"
class Iso15CommandGroupError(DeviceError):
    ErrorCode = 0x00012100
    URL = "https://docs.baltech.de/refman/cmds/iso15/index.html"
class Iso15_ErrNoTag(Iso15CommandGroupError):
    """
    No label in field of antenna.
    """
    ErrorCode = 0x00012101
    URL = "https://docs.baltech.de/refman/cmds/iso15/index.html#Iso15.ErrNoTag"
class Iso15_ErrCollision(Iso15CommandGroupError):
    """
    This status code is triggered by two events: 
    
      * A collision between two or more labels occurred. 
      * DSFID different - cannot resolve collision.
    """
    ErrorCode = 0x00012102
    URL = "https://docs.baltech.de/refman/cmds/iso15/index.html#Iso15.ErrCollision"
class Iso15_ErrHf(Iso15CommandGroupError):
    """
    General HF Error.
    """
    ErrorCode = 0x00012104
    URL = "https://docs.baltech.de/refman/cmds/iso15/index.html#Iso15.ErrHf"
class Iso15_ErrLabel(Iso15CommandGroupError):
    """
    Label status error.
    """
    ErrorCode = 0x00012105
    URL = "https://docs.baltech.de/refman/cmds/iso15/index.html#Iso15.ErrLabel"
class Iso15_ErrCom(Iso15CommandGroupError):
    """
    Error in communication to reader chip.
    """
    ErrorCode = 0x00012110
    URL = "https://docs.baltech.de/refman/cmds/iso15/index.html#Iso15.ErrCom"
class Iso15_ErrParamNotSupported(Iso15CommandGroupError):
    """
    Reader chip does not support label type parameters.
    """
    ErrorCode = 0x00012123
    URL = "https://docs.baltech.de/refman/cmds/iso15/index.html#Iso15.ErrParamNotSupported"
class Iso15_ErrMem(Iso15CommandGroupError):
    """
    Either internal list of labels or response buffer full.
    """
    ErrorCode = 0x00012124
    URL = "https://docs.baltech.de/refman/cmds/iso15/index.html#Iso15.ErrMem"
class Iso15_ErrLabelBlocksize(Iso15CommandGroupError):
    """
    The blocks requested are not equal in size (Read multiple blocks).
    """
    ErrorCode = 0x00012125
    URL = "https://docs.baltech.de/refman/cmds/iso15/index.html#Iso15.ErrLabelBlocksize"
class Iso78CommandGroupError(DeviceError):
    ErrorCode = 0x00014000
    URL = "https://docs.baltech.de/refman/cmds/iso78/index.html"
class Iso78_ErrInvalidSlot(Iso78CommandGroupError):
    """
    The specified slot index is not supported.
    """
    ErrorCode = 0x00014002
    URL = "https://docs.baltech.de/refman/cmds/iso78/index.html#Iso78.ErrInvalidSlot"
class Iso78_ErrAbort(Iso78CommandGroupError):
    """
    SAM aborted command execution by sending an abort command.
    """
    ErrorCode = 0x00014010
    URL = "https://docs.baltech.de/refman/cmds/iso78/index.html#Iso78.ErrAbort"
class Iso78_ErrProtNotSupported(Iso78CommandGroupError):
    """
    The specified protocol is not supported.
    """
    ErrorCode = 0x00014020
    URL = "https://docs.baltech.de/refman/cmds/iso78/index.html#Iso78.ErrProtNotSupported"
class Iso78_ErrCom(Iso78CommandGroupError):
    """
    Communication error.
    """
    ErrorCode = 0x00014021
    URL = "https://docs.baltech.de/refman/cmds/iso78/index.html#Iso78.ErrCom"
class Iso78_ErrHw(Iso78CommandGroupError):
    """
    Hardware error.
    """
    ErrorCode = 0x00014022
    URL = "https://docs.baltech.de/refman/cmds/iso78/index.html#Iso78.ErrHw"
class Iso78_ErrInvalid7816Cmd(Iso78CommandGroupError):
    """
    The command/parameter(s) is/are not supported by the SAM.
    """
    ErrorCode = 0x00014031
    URL = "https://docs.baltech.de/refman/cmds/iso78/index.html#Iso78.ErrInvalid7816Cmd"
class LicCommandGroupError(DeviceError):
    ErrorCode = 0x00010B00
    URL = "https://docs.baltech.de/refman/cmds/lic/index.html"
class Lic_ErrNoLicCard(LicCommandGroupError):
    """
    No valid LicenseCard detected.
    """
    ErrorCode = 0x00010B01
    URL = "https://docs.baltech.de/refman/cmds/lic/index.html#Lic.ErrNoLicCard"
class Lic_ErrAccess(LicCommandGroupError):
    """
    Card cannot be accessed (e.g. card was removed too early).
    """
    ErrorCode = 0x00010B02
    URL = "https://docs.baltech.de/refman/cmds/lic/index.html#Lic.ErrAccess"
class Lic_ErrNotSupported(LicCommandGroupError):
    """
    The license type of the presented LicenseCard isn't supported by the reader hardware or firmware.  
    _Example:_ Readers without 125 kHz interface don't support LicenseCards containing [Prox licenses](https://docs.baltech.de/installation/deploy-license.html).
    """
    ErrorCode = 0x00010B03
    URL = "https://docs.baltech.de/refman/cmds/lic/index.html#Lic.ErrNotSupported"
class Lic_ErrAlreadyActive(LicCommandGroupError):
    """
    A license of this type is already activated on the reader.
    """
    ErrorCode = 0x00010B04
    URL = "https://docs.baltech.de/refman/cmds/lic/index.html#Lic.ErrAlreadyActive"
class Lic_ErrNoFreeLicense(LicCommandGroupError):
    """
    The LicenseCard contains no free license.
    """
    ErrorCode = 0x00010B05
    URL = "https://docs.baltech.de/refman/cmds/lic/index.html#Lic.ErrNoFreeLicense"
class Lic_ErrActivation(LicCommandGroupError):
    """
    The license couldn't be activated on the reader.  
    
    
    **Please[ get in touch](https://docs.baltech.de/support/contact-support.html) with us.**
    """
    ErrorCode = 0x00010B06
    URL = "https://docs.baltech.de/refman/cmds/lic/index.html#Lic.ErrActivation"
class MainCommandGroupError(DeviceError):
    ErrorCode = 0x0001F000
    URL = "https://docs.baltech.de/refman/cmds/main/index.html"
class Main_ErrInvalidState(MainCommandGroupError):
    """
    Is returned by Bf3UploadStart if an upload process is already running or by Bf3UploadContinue if an upload process is currently not active.
    """
    ErrorCode = 0x0001F010
    URL = "https://docs.baltech.de/refman/cmds/main/index.html#Main.ErrInvalidState"
class Main_ErrReadFile(MainCommandGroupError):
    """
    Is returned by Bf3UploadContinue if BF3/BEC2 file data couldn't be retrieved from the host.
    """
    ErrorCode = 0x0001F011
    URL = "https://docs.baltech.de/refman/cmds/main/index.html#Main.ErrReadFile"
class Main_ErrInvalidFormat(MainCommandGroupError):
    """
    Is returned by Bf3UploadContinue if the BF3/BEC2 file has an invalid format.
    """
    ErrorCode = 0x0001F012
    URL = "https://docs.baltech.de/refman/cmds/main/index.html#Main.ErrInvalidFormat"
class Main_ErrInvalidCustomerKey(MainCommandGroupError):
    """
    Is returned by Bf3UploadContinue if the customer key of the BEC2 file doesn't match the customer key stored in the reader.
    """
    ErrorCode = 0x0001F013
    URL = "https://docs.baltech.de/refman/cmds/main/index.html#Main.ErrInvalidCustomerKey"
class Main_ErrInvalidConfigSecurityCode(MainCommandGroupError):
    """
    Is returned by Bf3UploadContinue if the Config Security Code of the BEC2 file doesn't match the Config Security Code stored in the reader ([ learn more](https://docs.baltech.de/project-setup/security.html#config-security-code)).
    """
    ErrorCode = 0x0001F014
    URL = "https://docs.baltech.de/refman/cmds/main/index.html#Main.ErrInvalidConfigSecurityCode"
class Main_ErrInvalidConfigVersion(MainCommandGroupError):
    """
    Is returned by Bf3UploadContinue if the configuration version of the BEC2 file is older than the configuration version stored in the reader.
    """
    ErrorCode = 0x0001F015
    URL = "https://docs.baltech.de/refman/cmds/main/index.html#Main.ErrInvalidConfigVersion"
class Main_ErrInvalidCmac(MainCommandGroupError):
    """
    Is returned by Bf3UploadContinue if the Message Authentication Code (CMAC) of the BF3/BEC2 file is incorrect.
    """
    ErrorCode = 0x0001F016
    URL = "https://docs.baltech.de/refman/cmds/main/index.html#Main.ErrInvalidCmac"
class Main_ErrUpload(MainCommandGroupError):
    """
    Is returned by Bf3UploadContinue if a component of the current BF3/BEC2 file couldn't be written to the reader memory.
    """
    ErrorCode = 0x0001F017
    URL = "https://docs.baltech.de/refman/cmds/main/index.html#Main.ErrUpload"
class Main_ErrUnsupportedFirmware(MainCommandGroupError):
    """
    Is returned by Bf3UploadContinue if the BF3/BEC2 file contains a firmware which is not supported by the reader hardware.
    """
    ErrorCode = 0x0001F018
    URL = "https://docs.baltech.de/refman/cmds/main/index.html#Main.ErrUnsupportedFirmware"
class Main_ErrAlreadyUpToDate(MainCommandGroupError):
    """
    Is returned by Bf3UploadContinue if all relevant components of the current BF3/BEC2 file are already up to date.
    """
    ErrorCode = 0x0001F019
    URL = "https://docs.baltech.de/refman/cmds/main/index.html#Main.ErrAlreadyUpToDate"
class Main_ErrMissingConfigSecurityCode(MainCommandGroupError):
    """
    Is returned by Bf3UploadContinue if the reader was not able to decode the current BEC2 file, because there is no Config Security Code stored in the reader yet.
    """
    ErrorCode = 0x0001F01A
    URL = "https://docs.baltech.de/refman/cmds/main/index.html#Main.ErrMissingConfigSecurityCode"
class Main_ErrInvalidEccKey(MainCommandGroupError):
    """
    The elliptic curve key that is used to encrypt the configuration is wrong.
    """
    ErrorCode = 0x0001F01B
    URL = "https://docs.baltech.de/refman/cmds/main/index.html#Main.ErrInvalidEccKey"
class Main_ErrVerify(MainCommandGroupError):
    """
    Is returned by SwitchFW and Bf3UploadContinue if the cryptographic signature of the firmware cannot be verified successfully.
    """
    ErrorCode = 0x0001F01C
    URL = "https://docs.baltech.de/refman/cmds/main/index.html#Main.ErrVerify"
class MifCommandGroupError(DeviceError):
    ErrorCode = 0x00011000
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html"
class Mif_ErrNoTag(MifCommandGroupError):
    """
    There's no card in the HF field, or the card doesn't respond.
    """
    ErrorCode = 0x00011001
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrNoTag"
class Mif_ErrAuth(MifCommandGroupError):
    """
    Card authentication has failed.
    """
    ErrorCode = 0x00011004
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrAuth"
class Mif_ErrParity(MifCommandGroupError):
    """
    Legacy error code: The parity bits don't match the transmitted data. Authentication has been lost. Please reauthenticate and rerun the commands.
    """
    ErrorCode = 0x00011005
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrParity"
class Mif_ErrCode(MifCommandGroupError):
    """
    The card behaves in an unspecified way. Please rerun the command or reselect the card.
    """
    ErrorCode = 0x00011006
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrCode"
class Mif_ErrKey(MifCommandGroupError):
    """
    The key in the SAM/crypto memory is invalid or missing.
    """
    ErrorCode = 0x00011009
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrKey"
class Mif_ErrNotauth(MifCommandGroupError):
    """
    Card authentication has failed. The current configuration/state doesn't allow the requested command.
    """
    ErrorCode = 0x0001100A
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrNotauth"
class Mif_ErrBitcount(MifCommandGroupError):
    """
    Legacy error code: HF data transition error. The number of received bits is invalid.
    """
    ErrorCode = 0x0001100B
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrBitcount"
class Mif_ErrBytecount(MifCommandGroupError):
    """
    Legacy error code: HF data transition error. The number of received bytes is invalid.
    """
    ErrorCode = 0x0001100C
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrBytecount"
class Mif_VcsAndProxCheckError(MifCommandGroupError):
    """
    The proximity check has timed out. Please reselect the card.
    """
    ErrorCode = 0x0001100E
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.VcsAndProxCheckError"
class Mif_ErrFraming(MifCommandGroupError):
    """
    The response frame is invalid, e.g. it may contain an invalid number of bits. Please rerun the command.
    """
    ErrorCode = 0x00011015
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrFraming"
class Mif_ErrCmd(MifCommandGroupError):
    """
    The specified command or parameters are unknown.
    """
    ErrorCode = 0x00011017
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrCmd"
class Mif_ErrColl(MifCommandGroupError):
    """
    An error occurred in the anti-collision sequence. Please reselect the card.
    """
    ErrorCode = 0x00011018
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrColl"
class Mif_CondNotvalid(MifCommandGroupError):
    """
    Card error as per MIFARE specification: Condition of use not satisfied.
    """
    ErrorCode = 0x00011020
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.CondNotvalid"
class MobileIdCommandGroupError(DeviceError):
    ErrorCode = 0x00014C00
    URL = "https://docs.baltech.de/refman/cmds/mobileid/index.html"
class MobileId_ErrNoCredential(MobileIdCommandGroupError):
    """
    No valid credential has been presented to the reader so far.
    """
    ErrorCode = 0x00014C01
    URL = "https://docs.baltech.de/refman/cmds/mobileid/index.html#MobileId.ErrNoCredential"
class MobileId_ErrProtocol(MobileIdCommandGroupError):
    """
    The credential is trying to perform an action that doesn't comply with the BALTECH Mobile ID protocol. (For details, please refer to the protocol specification, available on request.)
    """
    ErrorCode = 0x00014C02
    URL = "https://docs.baltech.de/refman/cmds/mobileid/index.html#MobileId.ErrProtocol"
class MobileId_ErrAuthentication(MobileIdCommandGroupError):
    """
    An authentication error occured, e.g. invalid encryption key or authentication tag.
    """
    ErrorCode = 0x00014C03
    URL = "https://docs.baltech.de/refman/cmds/mobileid/index.html#MobileId.ErrAuthentication"
class MobileId_ErrCredentialVersion(MobileIdCommandGroupError):
    """
    The version of the presented credential is not compatible with the current reader firmware.
    """
    ErrorCode = 0x00014C04
    URL = "https://docs.baltech.de/refman/cmds/mobileid/index.html#MobileId.ErrCredentialVersion"
class MobileId_ErrCredentialCmac(MobileIdCommandGroupError):
    """
    The presented credential is rejected due to an invalid CMAC.
    """
    ErrorCode = 0x00014C05
    URL = "https://docs.baltech.de/refman/cmds/mobileid/index.html#MobileId.ErrCredentialCmac"
class MobileId_ErrDisabled(MobileIdCommandGroupError):
    """
    Mobile ID functionality is currently disabled.
    """
    ErrorCode = 0x00014C10
    URL = "https://docs.baltech.de/refman/cmds/mobileid/index.html#MobileId.ErrDisabled"
class SecCommandGroupError(DeviceError):
    ErrorCode = 0x00010700
    URL = "https://docs.baltech.de/refman/cmds/sec/index.html"
class Sec_ErrCrypto(SecCommandGroupError):
    """
    Invalid key used for encryption/MACing, MAC address invalid, or decrypted data invalid.
    """
    ErrorCode = 0x00010701
    URL = "https://docs.baltech.de/refman/cmds/sec/index.html#Sec.ErrCrypto"
class Sec_ErrTunnel(SecCommandGroupError):
    """
    It is not possible to tunnel this command.
    """
    ErrorCode = 0x00010702
    URL = "https://docs.baltech.de/refman/cmds/sec/index.html#Sec.ErrTunnel"
class SysCommandGroupError(DeviceError):
    ErrorCode = 0x00010000
    URL = "https://docs.baltech.de/refman/cmds/sys/index.html"
class Sys_ErrCfgFull(SysCommandGroupError):
    """
    There's not enough space to store the reader's configuration values.
    """
    ErrorCode = 0x00010001
    URL = "https://docs.baltech.de/refman/cmds/sys/index.html#Sys.ErrCfgFull"
class Sys_ErrCfgAccess(SysCommandGroupError):
    """
    Reading/writing to the internal memory failed.  
    
    
    **Please[ get in touch](https://docs.baltech.de/support/contact-support.html) with us.**
    """
    ErrorCode = 0x00010002
    URL = "https://docs.baltech.de/refman/cmds/sys/index.html#Sys.ErrCfgAccess"
class Sys_ErrCfgNotFound(SysCommandGroupError):
    """
    The meaning of this status code varies depending on the access mode: 
    
      * _Read access:_ The desired key/value couldn't be found in the configuration. 
      * _Write access:_ The key/value ID is invalid. The value couldn't be set.
    """
    ErrorCode = 0x00010003
    URL = "https://docs.baltech.de/refman/cmds/sys/index.html#Sys.ErrCfgNotFound"
class Sys_ErrInvalidCfgBlock(SysCommandGroupError):
    """
    The format of the configuration file (BEC file) is invalid.
    """
    ErrorCode = 0x00010004
    URL = "https://docs.baltech.de/refman/cmds/sys/index.html#Sys.ErrInvalidCfgBlock"
class Sys_ErrCfgAccessDenied(SysCommandGroupError):
    """
    Memory access denied. The configuration value ID is too high (> 0x80).
    """
    ErrorCode = 0x00010005
    URL = "https://docs.baltech.de/refman/cmds/sys/index.html#Sys.ErrCfgAccessDenied"
class Sys_ErrInvalidProtocol(SysCommandGroupError):
    """
    The selected protocol isn't supported by the current firmware.
    """
    ErrorCode = 0x00010007
    URL = "https://docs.baltech.de/refman/cmds/sys/index.html#Sys.ErrInvalidProtocol"
class Sys_ErrNotSupportedByHardware(SysCommandGroupError):
    """
    This feature isn't supported by the reader hardware.
    """
    ErrorCode = 0x00010008
    URL = "https://docs.baltech.de/refman/cmds/sys/index.html#Sys.ErrNotSupportedByHardware"
class Sys_ErrFactsetRestore(SysCommandGroupError):
    """
    Restoring the reader's factory settings failed.
    """
    ErrorCode = 0x00010009
    URL = "https://docs.baltech.de/refman/cmds/sys/index.html#Sys.ErrFactsetRestore"
class UltralightCommandGroupError(DeviceError):
    ErrorCode = 0x00012500
    URL = "https://docs.baltech.de/refman/cmds/ultralight/index.html"
class Ultralight_ErrNoTag(UltralightCommandGroupError):
    """
    There's no card in the HF field, or the card doesn't respond.
    """
    ErrorCode = 0x00012501
    URL = "https://docs.baltech.de/refman/cmds/ultralight/index.html#Ultralight.ErrNoTag"
class Ultralight_ErrAuth(UltralightCommandGroupError):
    """
    Authentication with the card has failed.
    """
    ErrorCode = 0x00012502
    URL = "https://docs.baltech.de/refman/cmds/ultralight/index.html#Ultralight.ErrAuth"
class Ultralight_ErrHf(UltralightCommandGroupError):
    """
    The response frame is invalid, e.g. it may contain an invalid number of bits or an invalid CRC checksum. Please rerun the command.
    """
    ErrorCode = 0x00012503
    URL = "https://docs.baltech.de/refman/cmds/ultralight/index.html#Ultralight.ErrHf"
class Ultralight_ErrKey(UltralightCommandGroupError):
    """
    The encryption key is undefined or inaccessible.
    """
    ErrorCode = 0x00012504
    URL = "https://docs.baltech.de/refman/cmds/ultralight/index.html#Ultralight.ErrKey"
class Ultralight_ErrNack(UltralightCommandGroupError):
    """
    The card didn't accept the command. Please check the conditions and rerun the command.
    """
    ErrorCode = 0x00012505
    URL = "https://docs.baltech.de/refman/cmds/ultralight/index.html#Ultralight.ErrNack"
class Ultralight_ErrInterface(UltralightCommandGroupError):
    """
    Communication with the reader chip has failed. Please reset the reader with Sys.Reset and check the reader chip status with Sys.GetBootStatus.
    """
    ErrorCode = 0x00012518
    URL = "https://docs.baltech.de/refman/cmds/ultralight/index.html#Ultralight.ErrInterface"
class Ultralight_ErrCmd(UltralightCommandGroupError):
    """
    The specified command or parameters are unknown.
    """
    ErrorCode = 0x00012519
    URL = "https://docs.baltech.de/refman/cmds/ultralight/index.html#Ultralight.ErrCmd"
class Ultralight_ErrHwNotSupported(UltralightCommandGroupError):
    """
    This command isn't supported by the reader hardware.
    """
    ErrorCode = 0x00012520
    URL = "https://docs.baltech.de/refman/cmds/ultralight/index.html#Ultralight.ErrHwNotSupported"
class Ultralight_BreakErr(UltralightCommandGroupError):
    """
    The command has been aborted because the HF interface has been requested by another task or command. Please reselect the card. 
    
    **This error only occurs when you combine VHL and low-level commands. We highly recommend you avoid that combination as these 2 command sets will interfere with each other's card states.**
    """
    ErrorCode = 0x00012528
    URL = "https://docs.baltech.de/refman/cmds/ultralight/index.html#Ultralight.BreakErr"
class UICommandGroupError(DeviceError):
    ErrorCode = 0x00010A00
    URL = "https://docs.baltech.de/refman/cmds/ui/index.html"
class UI_ErrInvalidPort(UICommandGroupError):
    """
    The specified port isn't available or it doesn't support the desired operation.
    """
    ErrorCode = 0x00010A01
    URL = "https://docs.baltech.de/refman/cmds/ui/index.html#UI.ErrInvalidPort"
class VHLCommandGroupError(DeviceError):
    ErrorCode = 0x00010100
    URL = "https://docs.baltech.de/refman/cmds/vhl/index.html"
class VHL_ErrNoTag(VHLCommandGroupError):
    """
    This status code occurs in the following cases: 
    
      * There's no card in the antenna field.
      * The card doesn't respond, i.e. it doesn't match the given VHL file.
      * You use an HID Prox/Indala/Keri card, but the reader doesn't have the [required Prox license](https://docs.baltech.de/project-setup/get-prox-license-for-hid-prox-indala-keri.html). 
    
    
    
    This status code is the only one that requires a reselection of the card with VHL.Select.
    """
    ErrorCode = 0x00010101
    URL = "https://docs.baltech.de/refman/cmds/vhl/index.html#VHL.ErrNoTag"
class VHL_ErrCardNotSelected(VHLCommandGroupError):
    """
    The command can't be run because no card is selected.
    """
    ErrorCode = 0x00010102
    URL = "https://docs.baltech.de/refman/cmds/vhl/index.html#VHL.ErrCardNotSelected"
class VHL_ErrHf(VHLCommandGroupError):
    """
    Communication problems with the card occurred. Data may have been corrupted.
    """
    ErrorCode = 0x00010103
    URL = "https://docs.baltech.de/refman/cmds/vhl/index.html#VHL.ErrHf"
class VHL_ErrConfig(VHLCommandGroupError):
    """
    The VHL file structure in the reader configuration is invalid or the specified VHL file isn't available.
    """
    ErrorCode = 0x00010104
    URL = "https://docs.baltech.de/refman/cmds/vhl/index.html#VHL.ErrConfig"
class VHL_ErrAuth(VHLCommandGroupError):
    """
    An authentication error occurred. Data may have been written partially. This may occur if the specified VHL file uses invalid keys (MIFARE) or the specified stamp is not in the reader's EEPROM (LEGIC).
    """
    ErrorCode = 0x00010105
    URL = "https://docs.baltech.de/refman/cmds/vhl/index.html#VHL.ErrAuth"
class VHL_ErrRead(VHLCommandGroupError):
    """
    The communication sequence was OK, but reading failed. The card remains selected. This may occur if the specified VHL file is too long for the physical card storage.
    """
    ErrorCode = 0x00010106
    URL = "https://docs.baltech.de/refman/cmds/vhl/index.html#VHL.ErrRead"
class VHL_ErrWrite(VHLCommandGroupError):
    """
    The communication sequence was OK, but writing failed. Data may have been written partially. The card remains selected. This may occur if the specified VHL file is too long for the physical card storage.
    """
    ErrorCode = 0x00010107
    URL = "https://docs.baltech.de/refman/cmds/vhl/index.html#VHL.ErrWrite"
class VHL_ConfcardRead(VHLCommandGroupError):
    """
    A BALTECH ConfigCard has been detected successfully and will be read after this command.
    """
    ErrorCode = 0x00010108
    URL = "https://docs.baltech.de/refman/cmds/vhl/index.html#VHL.ConfcardRead"
class VHL_ErrHw(VHLCommandGroupError):
    """
    An error occurred while communicating with the reader chip/SAM.
    """
    ErrorCode = 0x0001010C
    URL = "https://docs.baltech.de/refman/cmds/vhl/index.html#VHL.ErrHw"
class VHL_ErrApdu(VHLCommandGroupError):
    """
    Card communication error: The command has been aborted, or the response hasn't been read completely.
    """
    ErrorCode = 0x0001010D
    URL = "https://docs.baltech.de/refman/cmds/vhl/index.html#VHL.ErrApdu"
__all__: list[str] = [
    "ARCommandGroupError",
    "AR_ErrNoMessage",
    "AR_ErrScriptRuntime",
    "AR_ErrScriptSyntax",
    "AR_ErrScriptNotImplemented",
    "AR_ErrArDisabled",
    "BlePeriphCommandGroupError",
    "BlePeriph_ErrNotEnabled",
    "BlePeriph_ErrNotConnected",
    "BlePeriph_ErrInvalidCharacteristicNdx",
    "BlePeriph_ErrWriteCharacteristic",
    "CryptoCommandGroupError",
    "Crypto_CrptErrInvalidBlock",
    "Crypto_CrptErrAuth",
    "Crypto_CrptErrKeyNotFound",
    "Crypto_CrptErrWriteConfigkey",
    "Crypto_CrptErrInvalidKey",
    "DesfireCommandGroupError",
    "Desfire_ErrIso14NoTag",
    "Desfire_ErrBreak",
    "Desfire_ErrIso14Hf",
    "Desfire_ErrIso14CardInvalid",
    "Desfire_ErrReaderChipCommunication",
    "Desfire_ErrIso14ApduCmd",
    "Desfire_ErrIso14InvalidResponse",
    "Desfire_ErrPcdAuthentication",
    "Desfire_ErrIntegrity",
    "Desfire_ErrPcdKey",
    "Desfire_ErrNoChanges",
    "Desfire_ErrPcdParam",
    "Desfire_VcsAndProxCheckError",
    "Desfire_ErrFirmwareNotSupported",
    "Desfire_ErrSamCommunication",
    "Desfire_ErrSamUnlock",
    "Desfire_ErrHardwareNotSupported",
    "Desfire_ErrIllegalCmdLegacy",
    "Desfire_ErrLength",
    "Desfire_ErrPermissionDenied",
    "Desfire_ErrParameter",
    "Desfire_ErrAppNotFound",
    "Desfire_ErrAppIntegrity",
    "Desfire_ErrAuthentication",
    "Desfire_ErrBoundary",
    "Desfire_ErrPiccIntegrity",
    "Desfire_ErrCommandAborted",
    "Desfire_ErrPiccDisabled",
    "Desfire_ErrCount",
    "Desfire_ErrDuplicate",
    "Desfire_ErrEeprom",
    "Desfire_ErrFileNotFound",
    "Desfire_ErrFileIntegrity",
    "Desfire_ErrNoSuchKey",
    "Desfire_ErrOutOfMemory",
    "Desfire_ErrIllegalCmd",
    "Desfire_ErrCmdOverflow",
    "FelicaCommandGroupError",
    "Felica_ErrFelicaNoTag",
    "Felica_ErrFelicaHf",
    "Felica_ErrFelicaFrame",
    "Felica_ErrFelicaCom",
    "Felica_ErrFelicaCardNotSupported",
    "Iso14aCommandGroupError",
    "Iso14a_ErrNoTag",
    "Iso14a_ErrCollision",
    "Iso14a_ErrHf",
    "Iso14a_ErrFrame",
    "Iso14a_ErrCrc",
    "Iso14a_ErrCom",
    "Iso14bCommandGroupError",
    "Iso14b_ErrNoTag",
    "Iso14b_ErrCollision",
    "Iso14b_ErrHf",
    "Iso14b_ErrFrame",
    "Iso14b_ErrCom",
    "Iso14b_ErrMem",
    "Iso14L4CommandGroupError",
    "Iso14L4_ErrNoTag",
    "Iso14L4_ErrHf",
    "Iso14L4_ErrCard",
    "Iso14L4_ErrCom",
    "Iso14L4_ErrCmd",
    "Iso15CommandGroupError",
    "Iso15_ErrNoTag",
    "Iso15_ErrCollision",
    "Iso15_ErrHf",
    "Iso15_ErrLabel",
    "Iso15_ErrCom",
    "Iso15_ErrParamNotSupported",
    "Iso15_ErrMem",
    "Iso15_ErrLabelBlocksize",
    "Iso78CommandGroupError",
    "Iso78_ErrInvalidSlot",
    "Iso78_ErrAbort",
    "Iso78_ErrProtNotSupported",
    "Iso78_ErrCom",
    "Iso78_ErrHw",
    "Iso78_ErrInvalid7816Cmd",
    "LicCommandGroupError",
    "Lic_ErrNoLicCard",
    "Lic_ErrAccess",
    "Lic_ErrNotSupported",
    "Lic_ErrAlreadyActive",
    "Lic_ErrNoFreeLicense",
    "Lic_ErrActivation",
    "MainCommandGroupError",
    "Main_ErrInvalidState",
    "Main_ErrReadFile",
    "Main_ErrInvalidFormat",
    "Main_ErrInvalidCustomerKey",
    "Main_ErrInvalidConfigSecurityCode",
    "Main_ErrInvalidConfigVersion",
    "Main_ErrInvalidCmac",
    "Main_ErrUpload",
    "Main_ErrUnsupportedFirmware",
    "Main_ErrAlreadyUpToDate",
    "Main_ErrMissingConfigSecurityCode",
    "Main_ErrInvalidEccKey",
    "Main_ErrVerify",
    "MifCommandGroupError",
    "Mif_ErrNoTag",
    "Mif_ErrAuth",
    "Mif_ErrParity",
    "Mif_ErrCode",
    "Mif_ErrKey",
    "Mif_ErrNotauth",
    "Mif_ErrBitcount",
    "Mif_ErrBytecount",
    "Mif_VcsAndProxCheckError",
    "Mif_ErrFraming",
    "Mif_ErrCmd",
    "Mif_ErrColl",
    "Mif_CondNotvalid",
    "MobileIdCommandGroupError",
    "MobileId_ErrNoCredential",
    "MobileId_ErrProtocol",
    "MobileId_ErrAuthentication",
    "MobileId_ErrCredentialVersion",
    "MobileId_ErrCredentialCmac",
    "MobileId_ErrDisabled",
    "SecCommandGroupError",
    "Sec_ErrCrypto",
    "Sec_ErrTunnel",
    "SysCommandGroupError",
    "Sys_ErrCfgFull",
    "Sys_ErrCfgAccess",
    "Sys_ErrCfgNotFound",
    "Sys_ErrInvalidCfgBlock",
    "Sys_ErrCfgAccessDenied",
    "Sys_ErrInvalidProtocol",
    "Sys_ErrNotSupportedByHardware",
    "Sys_ErrFactsetRestore",
    "UltralightCommandGroupError",
    "Ultralight_ErrNoTag",
    "Ultralight_ErrAuth",
    "Ultralight_ErrHf",
    "Ultralight_ErrKey",
    "Ultralight_ErrNack",
    "Ultralight_ErrInterface",
    "Ultralight_ErrCmd",
    "Ultralight_ErrHwNotSupported",
    "Ultralight_BreakErr",
    "UICommandGroupError",
    "UI_ErrInvalidPort",
    "VHLCommandGroupError",
    "VHL_ErrNoTag",
    "VHL_ErrCardNotSelected",
    "VHL_ErrHf",
    "VHL_ErrConfig",
    "VHL_ErrAuth",
    "VHL_ErrRead",
    "VHL_ErrWrite",
    "VHL_ConfcardRead",
    "VHL_ErrHw",
    "VHL_ErrApdu",
]