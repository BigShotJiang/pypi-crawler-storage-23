
from typing import Optional, NamedTuple, Literal, TypedDict, List, Tuple, Any

from typing_extensions import Self, NotRequired

from ..generator_interface import LiteralParser
class AR_GetMessage_Result(NamedTuple):
    MsgType: 'MessageType'
    MsgData: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('MsgType', self.MsgType))
        args.append(('MsgData', self.MsgData))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class BlePeriph_GetEvents_Result(NamedTuple):
    ConnectionStatusChanged: 'bool'
    ValueChangedCharacteristicNdx4: 'bool'
    ValueChangedCharacteristicNdx3: 'bool'
    ValueChangedCharacteristicNdx2: 'bool'
    ValueChangedCharacteristicNdx1: 'bool'
    ValueChangedCharacteristicNdx0: 'bool'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('ConnectionStatusChanged', self.ConnectionStatusChanged))
        args.append(('ValueChangedCharacteristicNdx4', self.ValueChangedCharacteristicNdx4))
        args.append(('ValueChangedCharacteristicNdx3', self.ValueChangedCharacteristicNdx3))
        args.append(('ValueChangedCharacteristicNdx2', self.ValueChangedCharacteristicNdx2))
        args.append(('ValueChangedCharacteristicNdx1', self.ValueChangedCharacteristicNdx1))
        args.append(('ValueChangedCharacteristicNdx0', self.ValueChangedCharacteristicNdx0))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
    
    @classmethod
    def all(cls) -> Self:
        return cls(ConnectionStatusChanged=True, ValueChangedCharacteristicNdx4=True, ValueChangedCharacteristicNdx3=True, ValueChangedCharacteristicNdx2=True, ValueChangedCharacteristicNdx1=True, ValueChangedCharacteristicNdx0=True)
    
    @classmethod
    def all_except(cls, *, ConnectionStatusChanged: Optional[Literal[False]] = None, ValueChangedCharacteristicNdx4: Optional[Literal[False]] = None, ValueChangedCharacteristicNdx3: Optional[Literal[False]] = None, ValueChangedCharacteristicNdx2: Optional[Literal[False]] = None, ValueChangedCharacteristicNdx1: Optional[Literal[False]] = None, ValueChangedCharacteristicNdx0: Optional[Literal[False]] = None) -> Self:
        true_fields = [name for name, value in [('ConnectionStatusChanged', ConnectionStatusChanged), ('ValueChangedCharacteristicNdx4', ValueChangedCharacteristicNdx4), ('ValueChangedCharacteristicNdx3', ValueChangedCharacteristicNdx3), ('ValueChangedCharacteristicNdx2', ValueChangedCharacteristicNdx2), ('ValueChangedCharacteristicNdx1', ValueChangedCharacteristicNdx1), ('ValueChangedCharacteristicNdx0', ValueChangedCharacteristicNdx0)] if value is True]  # type: ignore[comparison-overlap]
        if true_fields:
            raise TypeError(f"all_except() only accepts False values, got {', '.join(f'{name}=True' for name in true_fields)}")
        kwargs = {name: False if value is False else True for name, value in [('ConnectionStatusChanged', ConnectionStatusChanged), ('ValueChangedCharacteristicNdx4', ValueChangedCharacteristicNdx4), ('ValueChangedCharacteristicNdx3', ValueChangedCharacteristicNdx3), ('ValueChangedCharacteristicNdx2', ValueChangedCharacteristicNdx2), ('ValueChangedCharacteristicNdx1', ValueChangedCharacteristicNdx1), ('ValueChangedCharacteristicNdx0', ValueChangedCharacteristicNdx0)]}
        return cls(**kwargs)
class BlePeriph_IsConnected_Result(NamedTuple):
    Address: 'bytes'
    AddressType: 'BlePeriph_IsConnected_AddressType'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('Address', self.Address))
        args.append(('AddressType', self.AddressType))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Crypto_EncryptBuffer_Result(NamedTuple):
    NextInitialVector: 'bytes'
    EncryptedBuffer: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('NextInitialVector', self.NextInitialVector))
        args.append(('EncryptedBuffer', self.EncryptedBuffer))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Crypto_DecryptBuffer_Result(NamedTuple):
    NextInitialVector: 'bytes'
    UnencryptedBuffer: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('NextInitialVector', self.NextInitialVector))
        args.append(('UnencryptedBuffer', self.UnencryptedBuffer))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Crypto_BalKeyEncryptBuffer_Result(NamedTuple):
    EncryptedBuffer: 'bytes'
    NextInitialVector: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('EncryptedBuffer', self.EncryptedBuffer))
        args.append(('NextInitialVector', self.NextInitialVector))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Desfire_VirtualCardSelect_Result(NamedTuple):
    FciType: 'int'
    Fci: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('FciType', self.FciType))
        args.append(('Fci', self.Fci))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Felica_Request_Result(NamedTuple):
    ColFlag: 'int'
    Labels: 'List[bytes]'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('ColFlag', self.ColFlag))
        args.append(('Labels', self.Labels))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Iso14a_Select_Result(NamedTuple):
    SAK: 'int'
    Serial: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('SAK', self.SAK))
        args.append(('Serial', self.Serial))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Iso14a_Request_Result(NamedTuple):
    ATQA: 'bytes'
    Collision: 'bool'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('ATQA', self.ATQA))
        args.append(('Collision', self.Collision))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Iso14a_RequestVasup_Result(NamedTuple):
    ATQA: 'bytes'
    Collision: 'bool'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('ATQA', self.ATQA))
        args.append(('Collision', self.Collision))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Iso14b_Attrib_Result(NamedTuple):
    AssignedCID: 'Optional[int]' = None
    MBLI: 'Optional[int]' = None
    HLR: 'Optional[bytes]' = None
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        if self.AssignedCID != None:
            args.append(('AssignedCID', self.AssignedCID))
        if self.MBLI != None:
            args.append(('MBLI', self.MBLI))
        if self.HLR != None:
            args.append(('HLR', self.HLR))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Iso15_GetParam_Result(NamedTuple):
    ModulationIndex: 'bool'
    TXMode: 'bool'
    HighDataRate: 'bool'
    DualSubcarrier: 'bool'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('ModulationIndex', self.ModulationIndex))
        args.append(('TXMode', self.TXMode))
        args.append(('HighDataRate', self.HighDataRate))
        args.append(('DualSubcarrier', self.DualSubcarrier))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
    
    @classmethod
    def all(cls) -> Self:
        return cls(ModulationIndex=True, TXMode=True, HighDataRate=True, DualSubcarrier=True)
    
    @classmethod
    def all_except(cls, *, ModulationIndex: Optional[Literal[False]] = None, TXMode: Optional[Literal[False]] = None, HighDataRate: Optional[Literal[False]] = None, DualSubcarrier: Optional[Literal[False]] = None) -> Self:
        true_fields = [name for name, value in [('ModulationIndex', ModulationIndex), ('TXMode', TXMode), ('HighDataRate', HighDataRate), ('DualSubcarrier', DualSubcarrier)] if value is True]  # type: ignore[comparison-overlap]
        if true_fields:
            raise TypeError(f"all_except() only accepts False values, got {', '.join(f'{name}=True' for name in true_fields)}")
        kwargs = {name: False if value is False else True for name, value in [('ModulationIndex', ModulationIndex), ('TXMode', TXMode), ('HighDataRate', HighDataRate), ('DualSubcarrier', DualSubcarrier)]}
        return cls(**kwargs)
class Iso15_GetUIDList_Result(NamedTuple):
    More: 'int'
    Labels: 'List[Iso15_GetUIDList_Labels_Entry]'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('More', self.More))
        args.append(('Labels', self.Labels))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Iso15_GetSystemInformation_Result(NamedTuple):
    LabelStat: 'int'
    EnICRef: 'Optional[bool]' = None
    EnMemSize: 'Optional[bool]' = None
    EnAFI: 'Optional[bool]' = None
    EnDSFID: 'Optional[bool]' = None
    SNR: 'Optional[bytes]' = None
    DSFID: 'Optional[int]' = None
    AFI: 'Optional[int]' = None
    BlockNum: 'Optional[int]' = None
    BlockSize: 'Optional[int]' = None
    ICRef: 'Optional[int]' = None
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('LabelStat', self.LabelStat))
        if self.EnICRef != None:
            args.append(('EnICRef', self.EnICRef))
        if self.EnMemSize != None:
            args.append(('EnMemSize', self.EnMemSize))
        if self.EnAFI != None:
            args.append(('EnAFI', self.EnAFI))
        if self.EnDSFID != None:
            args.append(('EnDSFID', self.EnDSFID))
        if self.SNR != None:
            args.append(('SNR', self.SNR))
        if self.DSFID != None:
            args.append(('DSFID', self.DSFID))
        if self.AFI != None:
            args.append(('AFI', self.AFI))
        if self.BlockNum != None:
            args.append(('BlockNum', self.BlockNum))
        if self.BlockSize != None:
            args.append(('BlockSize', self.BlockSize))
        if self.ICRef != None:
            args.append(('ICRef', self.ICRef))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Iso15_GetSecurityStatus_Result(NamedTuple):
    LabelStat: 'int'
    BlockStat: 'List[int]'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('LabelStat', self.LabelStat))
        args.append(('BlockStat', self.BlockStat))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Iso15_CustomCommand_Result(NamedTuple):
    LabelStat: 'int'
    ResponseData: 'Optional[bytes]' = None
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('LabelStat', self.LabelStat))
        if self.ResponseData != None:
            args.append(('ResponseData', self.ResponseData))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Iso15_ReadSingleBlock_Result(NamedTuple):
    LabelStat: 'int'
    Payload: 'Optional[bytes]' = None
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('LabelStat', self.LabelStat))
        if self.Payload != None:
            args.append(('Payload', self.Payload))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Iso15_ReadMultipleBlocks_Result(NamedTuple):
    LabelStat: 'int'
    RecvBlocks: 'List[bytes]'
    BlocksSecData: 'List[int]'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('LabelStat', self.LabelStat))
        args.append(('RecvBlocks', self.RecvBlocks))
        args.append(('BlocksSecData', self.BlocksSecData))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Iso78_OpenSam_Result(NamedTuple):
    SamHandle: 'int'
    ATR: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('SamHandle', self.SamHandle))
        args.append(('ATR', self.ATR))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Main_Bf3UploadStart_Result(NamedTuple):
    ReqDataAdr: 'int'
    ReqDataLen: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('ReqDataAdr', self.ReqDataAdr))
        args.append(('ReqDataLen', self.ReqDataLen))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Main_Bf3UploadContinue_Result(NamedTuple):
    Reconnect: 'bool'
    Continue: 'bool'
    ReqDataAdr: 'int'
    ReqDataLen: 'int'
    ContainsEstimation: 'bool'
    ContainsReconnectRetryTimeout: 'bool'
    ReconnectRetryTimeout: 'Optional[int]' = None
    EstimatedNumberOfBytes: 'Optional[int]' = None
    EstimatedTimeOverhead: 'Optional[int]' = None
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('Reconnect', self.Reconnect))
        args.append(('Continue', self.Continue))
        args.append(('ReqDataAdr', self.ReqDataAdr))
        args.append(('ReqDataLen', self.ReqDataLen))
        args.append(('ContainsEstimation', self.ContainsEstimation))
        args.append(('ContainsReconnectRetryTimeout', self.ContainsReconnectRetryTimeout))
        if self.ReconnectRetryTimeout != None:
            args.append(('ReconnectRetryTimeout', self.ReconnectRetryTimeout))
        if self.EstimatedNumberOfBytes != None:
            args.append(('EstimatedNumberOfBytes', self.EstimatedNumberOfBytes))
        if self.EstimatedTimeOverhead != None:
            args.append(('EstimatedTimeOverhead', self.EstimatedTimeOverhead))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Mif_VirtualCardSelect_Result(NamedTuple):
    FciType: 'Mif_VirtualCardSelect_FciType'
    Fci: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('FciType', self.FciType))
        args.append(('Fci', self.Fci))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Sec_AuthPhase1_Result(NamedTuple):
    EncRndA: 'bytes'
    RndB: 'bytes'
    ContinuousIV: 'bool'
    Encrypted: 'bool'
    MACed: 'bool'
    SessionKey: 'bool'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('EncRndA', self.EncRndA))
        args.append(('RndB', self.RndB))
        args.append(('ContinuousIV', self.ContinuousIV))
        args.append(('Encrypted', self.Encrypted))
        args.append(('MACed', self.MACed))
        args.append(('SessionKey', self.SessionKey))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Sys_GetBufferSize_Result(NamedTuple):
    MaxSendSize: 'int'
    MaxRecvSize: 'int'
    TotalSize: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('MaxSendSize', self.MaxSendSize))
        args.append(('MaxRecvSize', self.MaxRecvSize))
        args.append(('TotalSize', self.TotalSize))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Sys_CfgCheck_Result(NamedTuple):
    TotalSize: 'int'
    FreeSize: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('TotalSize', self.TotalSize))
        args.append(('FreeSize', self.FreeSize))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Sys_CfgGetId_Result(NamedTuple):
    ConfigId: 'str'
    ConfigName: 'str'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('ConfigId', self.ConfigId))
        args.append(('ConfigName', self.ConfigName))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Sys_CfgGetDeviceSettingsId_Result(NamedTuple):
    ConfigId: 'str'
    ConfigName: 'str'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('ConfigId', self.ConfigId))
        args.append(('ConfigName', self.ConfigName))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Sys_GetFeatures_Result(NamedTuple):
    FeatureList: 'List[FeatureID]'
    MaxFeatureID: 'FeatureID'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('FeatureList', self.FeatureList))
        args.append(('MaxFeatureID', self.MaxFeatureID))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Sys_GetPartNumber_Result(NamedTuple):
    PartNo: 'str'
    HwRevNo: 'str'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('PartNo', self.PartNo))
        args.append(('HwRevNo', self.HwRevNo))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class VHL_ExchangeLongAPDU_Result(NamedTuple):
    ContinueResp: 'bool'
    Resp: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('ContinueResp', self.ContinueResp))
        args.append(('Resp', self.Resp))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class VHL_GetFileInfo_Result(NamedTuple):
    Len: 'int'
    BlockSize: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('Len', self.Len))
        args.append(('BlockSize', self.BlockSize))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Autoread_Rule_ConstArea_Result(NamedTuple):
    Position: 'int'
    CompareData: 'str'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('Position', self.Position))
        args.append(('CompareData', self.CompareData))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Device_Run_RepeatMessageMode_Result(NamedTuple):
    Suppress: 'bool'
    Force: 'bool'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('Suppress', self.Suppress))
        args.append(('Force', self.Force))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
    
    @classmethod
    def all(cls) -> Self:
        return cls(Suppress=True, Force=True)
    
    @classmethod
    def all_except(cls, *, Suppress: Optional[Literal[False]] = None, Force: Optional[Literal[False]] = None) -> Self:
        true_fields = [name for name, value in [('Suppress', Suppress), ('Force', Force)] if value is True]  # type: ignore[comparison-overlap]
        if true_fields:
            raise TypeError(f"all_except() only accepts False values, got {', '.join(f'{name}=True' for name in true_fields)}")
        kwargs = {name: False if value is False else True for name, value in [('Suppress', Suppress), ('Force', Force)]}
        return cls(**kwargs)
class Device_Run_MaintenanceFunctionFilter_Result(NamedTuple):
    DisableReaderInfo: 'bool'
    DisableBec2Upload: 'bool'
    DisableLicenseCards: 'bool'
    DisableAdrCards: 'bool'
    DisableConfigCards: 'bool'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('DisableReaderInfo', self.DisableReaderInfo))
        args.append(('DisableBec2Upload', self.DisableBec2Upload))
        args.append(('DisableLicenseCards', self.DisableLicenseCards))
        args.append(('DisableAdrCards', self.DisableAdrCards))
        args.append(('DisableConfigCards', self.DisableConfigCards))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
    
    @classmethod
    def all(cls) -> Self:
        return cls(DisableReaderInfo=True, DisableBec2Upload=True, DisableLicenseCards=True, DisableAdrCards=True, DisableConfigCards=True)
    
    @classmethod
    def all_except(cls, *, DisableReaderInfo: Optional[Literal[False]] = None, DisableBec2Upload: Optional[Literal[False]] = None, DisableLicenseCards: Optional[Literal[False]] = None, DisableAdrCards: Optional[Literal[False]] = None, DisableConfigCards: Optional[Literal[False]] = None) -> Self:
        true_fields = [name for name, value in [('DisableReaderInfo', DisableReaderInfo), ('DisableBec2Upload', DisableBec2Upload), ('DisableLicenseCards', DisableLicenseCards), ('DisableAdrCards', DisableAdrCards), ('DisableConfigCards', DisableConfigCards)] if value is True]  # type: ignore[comparison-overlap]
        if true_fields:
            raise TypeError(f"all_except() only accepts False values, got {', '.join(f'{name}=True' for name in true_fields)}")
        kwargs = {name: False if value is False else True for name, value in [('DisableReaderInfo', DisableReaderInfo), ('DisableBec2Upload', DisableBec2Upload), ('DisableLicenseCards', DisableLicenseCards), ('DisableAdrCards', DisableAdrCards), ('DisableConfigCards', DisableConfigCards)]}
        return cls(**kwargs)
class Device_HostSecurity_Key_Result(NamedTuple):
    AuthenticationMode: 'HostSecurityAuthenticationMode'
    DeriveKeyId: 'int'
    AesKey: 'str'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('AuthenticationMode', self.AuthenticationMode))
        args.append(('DeriveKeyId', self.DeriveKeyId))
        args.append(('AesKey', self.AesKey))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Project_VhlSettings_Iso14aVasup_Result(NamedTuple):
    FormatVersion: 'int'
    VasSupported: 'bool'
    AuthUserRequested: 'bool'
    TerminalTypeDataLength: 'int'
    TerminalType: 'int'
    TCI: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('FormatVersion', self.FormatVersion))
        args.append(('VasSupported', self.VasSupported))
        args.append(('AuthUserRequested', self.AuthUserRequested))
        args.append(('TerminalTypeDataLength', self.TerminalTypeDataLength))
        args.append(('TerminalType', self.TerminalType))
        args.append(('TCI', self.TCI))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Project_HidSam_Confcard_Result(NamedTuple):
    HidConfigurationCard: 'bool'
    HidPreparationCard: 'bool'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('HidConfigurationCard', self.HidConfigurationCard))
        args.append(('HidPreparationCard', self.HidPreparationCard))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
    
    @classmethod
    def all(cls) -> Self:
        return cls(HidConfigurationCard=True, HidPreparationCard=True)
    
    @classmethod
    def all_except(cls, *, HidConfigurationCard: Optional[Literal[False]] = None, HidPreparationCard: Optional[Literal[False]] = None) -> Self:
        true_fields = [name for name, value in [('HidConfigurationCard', HidConfigurationCard), ('HidPreparationCard', HidPreparationCard)] if value is True]  # type: ignore[comparison-overlap]
        if true_fields:
            raise TypeError(f"all_except() only accepts False values, got {', '.join(f'{name}=True' for name in true_fields)}")
        kwargs = {name: False if value is False else True for name, value in [('HidConfigurationCard', HidConfigurationCard), ('HidPreparationCard', HidPreparationCard)]}
        return cls(**kwargs)
class Project_SamAVx_AnswerToReset_Result(NamedTuple):
    LID: 'Project_SamAVx_AnswerToReset_LID'
    ATR: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('LID', self.LID))
        args.append(('ATR', self.ATR))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Project_CryptoKey_Entry_Result(NamedTuple):
    AccessRights: 'KeyAccessRights'
    Algorithm: 'CryptoAlgorithm'
    Key: 'str'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('AccessRights', self.AccessRights))
        args.append(('Algorithm', self.Algorithm))
        args.append(('Key', self.Key))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Project_LegicKeySettings_Index_Result(NamedTuple):
    VcpLabel: 'int'
    KeyType: 'Project_LegicKeySettings_Index_KeyType'
    DiversificationMode: 'Project_LegicKeySettings_Index_DiversificationMode'
    DivIdx: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('VcpLabel', self.VcpLabel))
        args.append(('KeyType', self.KeyType))
        args.append(('DiversificationMode', self.DiversificationMode))
        args.append(('DivIdx', self.DivIdx))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Project_LegicVcp_Status_Result(NamedTuple):
    Context: 'Project_LegicVcp_Status_Context'
    StatusCode: 'Project_LegicVcp_Status_StatusCode'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('Context', self.Context))
        args.append(('StatusCode', self.StatusCode))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Protocols_BrpSerial_InterbyteTimeout_Result(NamedTuple):
    Timeout: 'int'
    LegacyFormat: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('Timeout', self.Timeout))
        args.append(('LegacyFormat', self.LegacyFormat))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Protocols_Osdp_SCBKeyDefault_Result(NamedTuple):
    DiversifyFlag: 'Protocols_Osdp_SCBKeyDefault_DiversifyFlag'
    SCBKD: 'str'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('DiversifyFlag', self.DiversifyFlag))
        args.append(('SCBKD', self.SCBKD))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Protocols_Osdp_SCBKey_Result(NamedTuple):
    DiversifyFlag: 'Protocols_Osdp_SCBKey_DiversifyFlag'
    SCBK: 'str'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('DiversifyFlag', self.DiversifyFlag))
        args.append(('SCBK', self.SCBK))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class VhlCfg_File_DesfireRandomIdKey_Result(NamedTuple):
    ReadIdKeyNo: 'int' = 0
    ReadIdKeyIdx: 'int' = 192
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        if self.ReadIdKeyNo != 0:
            args.append(('ReadIdKeyNo', self.ReadIdKeyNo))
        if self.ReadIdKeyIdx != 192:
            args.append(('ReadIdKeyIdx', self.ReadIdKeyIdx))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class VhlCfg_File_DesfireVcsParams_Result(NamedTuple):
    PrependUidBeforeMacDivData: 'bool'
    RejectCardsWithoutValidIid: 'bool'
    ForceAuthToCard: 'bool'
    DfName: 'bytes'
    VcsEncKeyidx: 'DesfireKeyIdx'
    VcsMacKeyidx: 'DesfireKeyIdx'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('PrependUidBeforeMacDivData', self.PrependUidBeforeMacDivData))
        args.append(('RejectCardsWithoutValidIid', self.RejectCardsWithoutValidIid))
        args.append(('ForceAuthToCard', self.ForceAuthToCard))
        args.append(('DfName', self.DfName))
        args.append(('VcsEncKeyidx', self.VcsEncKeyidx))
        args.append(('VcsMacKeyidx', self.VcsMacKeyidx))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class VhlCfg_File_DesfireSoftUid_Result(NamedTuple):
    AID: 'int'
    FileNr: 'int'
    ReadKeyNo: 'int' = 0
    ReadKeyIdx: 'int' = 192
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('AID', self.AID))
        args.append(('FileNr', self.FileNr))
        if self.ReadKeyNo != 0:
            args.append(('ReadKeyNo', self.ReadKeyNo))
        if self.ReadKeyIdx != 192:
            args.append(('ReadKeyIdx', self.ReadKeyIdx))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class VhlCfg_File_IntIndSegment_Result(NamedTuple):
    FileOffset: 'int'
    FileLength: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('FileOffset', self.FileOffset))
        args.append(('FileLength', self.FileLength))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class VhlCfg_File_IntIndKeyIdx_Result(NamedTuple):
    MemoryType: 'int'
    KeyIndex: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('MemoryType', self.MemoryType))
        args.append(('KeyIndex', self.KeyIndex))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class VhlCfg_File_MifarePlusMadKeyBIndex_Result(NamedTuple):
    MadKeyBMemoryType: 'MifarePlusKeyMemoryType'
    MadKeyBIdx: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('MadKeyBMemoryType', self.MadKeyBMemoryType))
        args.append(('MadKeyBIdx', self.MadKeyBIdx))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class VhlCfg_File_MifarePlusCommunicationMode_Result(NamedTuple):
    ReadNoMacOnCommand: 'bool'
    ReadPlain: 'bool'
    ReadNoMacOnResponse: 'bool'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('ReadNoMacOnCommand', self.ReadNoMacOnCommand))
        args.append(('ReadPlain', self.ReadPlain))
        args.append(('ReadNoMacOnResponse', self.ReadNoMacOnResponse))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
    
    @classmethod
    def all(cls) -> Self:
        return cls(ReadNoMacOnCommand=True, ReadPlain=True, ReadNoMacOnResponse=True)
    
    @classmethod
    def all_except(cls, *, ReadNoMacOnCommand: Optional[Literal[False]] = None, ReadPlain: Optional[Literal[False]] = None, ReadNoMacOnResponse: Optional[Literal[False]] = None) -> Self:
        true_fields = [name for name, value in [('ReadNoMacOnCommand', ReadNoMacOnCommand), ('ReadPlain', ReadPlain), ('ReadNoMacOnResponse', ReadNoMacOnResponse)] if value is True]  # type: ignore[comparison-overlap]
        if true_fields:
            raise TypeError(f"all_except() only accepts False values, got {', '.join(f'{name}=True' for name in true_fields)}")
        kwargs = {name: False if value is False else True for name, value in [('ReadNoMacOnCommand', ReadNoMacOnCommand), ('ReadPlain', ReadPlain), ('ReadNoMacOnResponse', ReadNoMacOnResponse)]}
        return cls(**kwargs)
class VhlCfg_File_MifarePlusProxyimityCheck_Result(NamedTuple):
    ProxCheckKeyMemoryType: 'MifarePlusKeyMemoryType'
    ProxCheckKeyIdx: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('ProxCheckKeyMemoryType', self.ProxCheckKeyMemoryType))
        args.append(('ProxCheckKeyIdx', self.ProxCheckKeyIdx))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class VhlCfg_File_MifareVcsParams_Result(NamedTuple):
    PrependUidBeforeMacDivData: 'bool'
    RejectCardsWithoutValidIid: 'bool'
    ForceAuthToCard: 'bool'
    DfName: 'bytes'
    MifareVcsEncKeyMemoryType: 'MifarePlusKeyMemoryType'
    MifareVcsEncKeyIdx: 'int'
    MifareVcsMacKeyMemoryType: 'MifarePlusKeyMemoryType'
    MifareVcsMacKeyIdx: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('PrependUidBeforeMacDivData', self.PrependUidBeforeMacDivData))
        args.append(('RejectCardsWithoutValidIid', self.RejectCardsWithoutValidIid))
        args.append(('ForceAuthToCard', self.ForceAuthToCard))
        args.append(('DfName', self.DfName))
        args.append(('MifareVcsEncKeyMemoryType', self.MifareVcsEncKeyMemoryType))
        args.append(('MifareVcsEncKeyIdx', self.MifareVcsEncKeyIdx))
        args.append(('MifareVcsMacKeyMemoryType', self.MifareVcsMacKeyMemoryType))
        args.append(('MifareVcsMacKeyIdx', self.MifareVcsMacKeyIdx))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class AddressAndEnableCRC(NamedTuple):
    """
    This word defines the start address according to the addressing mode selected in SegmentIdentificationAndAddressing for every fragment. 
    
    The MSB determines if a CRC check shall be applied for accessing this segment.
    """
    EnableCRC: 'bool' = False
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        if self.EnableCRC != False:
            args.append(('EnableCRC', self.EnableCRC))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
    
    @classmethod
    def all(cls) -> Self:
        return cls(EnableCRC=True)
    
    @classmethod
    def all_except(cls, *, EnableCRC: Optional[Literal[False]] = None) -> Self:
        true_fields = [name for name, value in [('EnableCRC', EnableCRC)] if value is True]  # type: ignore[comparison-overlap]
        if true_fields:
            raise TypeError(f"all_except() only accepts False values, got {', '.join(f'{name}=True' for name in true_fields)}")
        kwargs = {name: False if value is False else True for name, value in [('EnableCRC', EnableCRC)]}
        return cls(**kwargs)
class AddressAndEnableCRC_Dict(TypedDict):
    """
    This word defines the start address according to the addressing mode selected in SegmentIdentificationAndAddressing for every fragment. 
    
    The MSB determines if a CRC check shall be applied for accessing this segment.
    """
    EnableCRC: 'NotRequired[bool]'
Alignment = Literal["Right", "Left"]
Alignment_Parser = LiteralParser[Alignment, int](
    name='Alignment',
    literal_map={
        'Right': 1,
        'Left': 0,
    },
)
AuthReqUpload = Literal["Default", "None", "CustomerKey", "ConfigSecurityCode", "Version", "GreaterVersion"]
AuthReqUpload_Parser = LiteralParser[AuthReqUpload, int](
    name='AuthReqUpload',
    literal_map={
        'Default': 0,
        'None': 1,
        'CustomerKey': 2,
        'ConfigSecurityCode': 3,
        'Version': 4,
        'GreaterVersion': 5,
    },
)
AutoReadMode = Literal["Disabled", "Enabled", "EnableOnce", "EnableIfDefinedRules"]
AutoReadMode_Parser = LiteralParser[AutoReadMode, int](
    name='AutoReadMode',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
        'EnableOnce': 2,
        'EnableIfDefinedRules': 255,
    },
)
class AutoRunCommand(NamedTuple):
    RunMode: 'AutoRunCommand_RunMode'
    DeviceCode: 'int'
    CommandCode: 'int'
    Parameter: 'str'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('RunMode', self.RunMode))
        args.append(('DeviceCode', self.DeviceCode))
        args.append(('CommandCode', self.CommandCode))
        args.append(('Parameter', self.Parameter))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class AutoRunCommand_Dict(TypedDict):
    RunMode: 'AutoRunCommand_RunMode'
    DeviceCode: 'int'
    CommandCode: 'int'
    Parameter: 'str'
AutoRunCommand_RunMode = Literal["Standard", "Continuous", "Repeat"]
AutoRunCommand_RunMode_Parser = LiteralParser[AutoRunCommand_RunMode, int](
    name='AutoRunCommand_RunMode',
    literal_map={
        'Standard': 0,
        'Continuous': 1,
        'Repeat': 2,
    },
)
Autoread_Rule_OnMatchAction_Action = Literal["AcceptCard", "DenyCard"]
Autoread_Rule_OnMatchAction_Action_Parser = LiteralParser[Autoread_Rule_OnMatchAction_Action, int](
    name='Autoread_Rule_OnMatchAction_Action',
    literal_map={
        'AcceptCard': 0,
        'DenyCard': 1,
    },
)
Autoread_Rule_PrioritizationMode_PrioMode = Literal["NoPrio", "PrioReturnInOrder", "PrioSuppressOthers"]
Autoread_Rule_PrioritizationMode_PrioMode_Parser = LiteralParser[Autoread_Rule_PrioritizationMode_PrioMode, int](
    name='Autoread_Rule_PrioritizationMode_PrioMode',
    literal_map={
        'NoPrio': 0,
        'PrioReturnInOrder': 1,
        'PrioSuppressOthers': 2,
    },
)
BRP_CommandFrame_CheckSumAlgo = Literal["None", "BCC8", "CRC16", "BCC16"]
BRP_CommandFrame_CheckSumAlgo_Parser = LiteralParser[BRP_CommandFrame_CheckSumAlgo, int](
    name='BRP_CommandFrame_CheckSumAlgo',
    literal_map={
        'None': 0,
        'BCC8': 1,
        'CRC16': 2,
        'BCC16': 3,
    },
)
BRP_CommandFrame_ExecutionMode = Literal["Standard", "Repeat", "Continuous"]
BRP_CommandFrame_ExecutionMode_Parser = LiteralParser[BRP_CommandFrame_ExecutionMode, int](
    name='BRP_CommandFrame_ExecutionMode',
    literal_map={
        'Standard': 0,
        'Repeat': 1,
        'Continuous': 2,
    },
)
BRP_ResponseFrame_CheckSumAlgo = Literal["None", "BCC8", "CRC16", "BCC16"]
BRP_ResponseFrame_CheckSumAlgo_Parser = LiteralParser[BRP_ResponseFrame_CheckSumAlgo, int](
    name='BRP_ResponseFrame_CheckSumAlgo',
    literal_map={
        'None': 0,
        'BCC8': 1,
        'CRC16': 2,
        'BCC16': 3,
    },
)
BRP_ResponseFrame_Phase = Literal["None", "RepeatEnd", "ContinuousEnd"]
BRP_ResponseFrame_Phase_Parser = LiteralParser[BRP_ResponseFrame_Phase, int](
    name='BRP_ResponseFrame_Phase',
    literal_map={
        'None': 0,
        'RepeatEnd': 1,
        'ContinuousEnd': 2,
    },
)
Baudrate = Literal["Baud300", "Baud600", "Baud1200", "Baud2400", "Baud4800", "Baud9600", "Baud14400", "Baud19200", "Baud28800", "Baud38400", "Baud57600", "Baud115200", "Baud500000", "Baud576000", "Baud921600"]
Baudrate_Parser = LiteralParser[Baudrate, int](
    name='Baudrate',
    literal_map={
        'Baud300': 3,
        'Baud600': 6,
        'Baud1200': 12,
        'Baud2400': 24,
        'Baud4800': 48,
        'Baud9600': 96,
        'Baud14400': 144,
        'Baud19200': 192,
        'Baud28800': 288,
        'Baud38400': 384,
        'Baud57600': 576,
        'Baud115200': 1152,
        'Baud500000': 5000,
        'Baud576000': 5760,
        'Baud921600': 9216,
    },
)
class BlePeriph_DefineService_Characteristics_Entry(NamedTuple):
    """
    List of characteristics (max. 5)
    """
    CharacteristicUUID: 'bytes'
    SupportsIndicate: 'bool'
    SupportsNotify: 'bool'
    SupportsWrite: 'bool'
    SupportsWriteNoResponse: 'bool'
    SupportsRead: 'bool'
    VariableSize: 'bool'
    Size: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('CharacteristicUUID', self.CharacteristicUUID))
        args.append(('SupportsIndicate', self.SupportsIndicate))
        args.append(('SupportsNotify', self.SupportsNotify))
        args.append(('SupportsWrite', self.SupportsWrite))
        args.append(('SupportsWriteNoResponse', self.SupportsWriteNoResponse))
        args.append(('SupportsRead', self.SupportsRead))
        args.append(('VariableSize', self.VariableSize))
        args.append(('Size', self.Size))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
BlePeriph_IsConnected_AddressType = Literal["Public", "RandomStatic", "RandomResolvable", "RandomNonResolvable"]
BlePeriph_IsConnected_AddressType_Parser = LiteralParser[BlePeriph_IsConnected_AddressType, int](
    name='BlePeriph_IsConnected_AddressType',
    literal_map={
        'Public': 0,
        'RandomStatic': 1,
        'RandomResolvable': 2,
        'RandomNonResolvable': 3,
    },
)
class CRCAddressAndCRCType(NamedTuple):
    """
    This word defines the CRC address according to the addressing mode selected in SegmentIdentificationAndAddressing. There must be an entry for every fragment that has enabled the CRC check in AddressAndEnableCRC. 
    
    The MSB determines the CRC type.
    """
    CRC16bit: 'bool' = False
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        if self.CRC16bit != False:
            args.append(('CRC16bit', self.CRC16bit))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
    
    @classmethod
    def all(cls) -> Self:
        return cls(CRC16bit=True)
    
    @classmethod
    def all_except(cls, *, CRC16bit: Optional[Literal[False]] = None) -> Self:
        true_fields = [name for name, value in [('CRC16bit', CRC16bit)] if value is True]  # type: ignore[comparison-overlap]
        if true_fields:
            raise TypeError(f"all_except() only accepts False values, got {', '.join(f'{name}=True' for name in true_fields)}")
        kwargs = {name: False if value is False else True for name, value in [('CRC16bit', CRC16bit)]}
        return cls(**kwargs)
class CRCAddressAndCRCType_Dict(TypedDict):
    """
    This word defines the CRC address according to the addressing mode selected in SegmentIdentificationAndAddressing. There must be an entry for every fragment that has enabled the CRC check in AddressAndEnableCRC. 
    
    The MSB determines the CRC type.
    """
    CRC16bit: 'NotRequired[bool]'
class CardFamilies(NamedTuple):
    LEGICPrime: 'bool' = False
    BluetoothMce: 'bool' = False
    Khz125Part2: 'bool' = False
    Srix: 'bool' = False
    Khz125Part1: 'bool' = False
    Felica: 'bool' = False
    IClass: 'bool' = False
    IClassIso14B: 'bool' = False
    Iso14443B: 'bool' = False
    Iso15693: 'bool' = False
    Iso14443A: 'bool' = False
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        if self.LEGICPrime != False:
            args.append(('LEGICPrime', self.LEGICPrime))
        if self.BluetoothMce != False:
            args.append(('BluetoothMce', self.BluetoothMce))
        if self.Khz125Part2 != False:
            args.append(('Khz125Part2', self.Khz125Part2))
        if self.Srix != False:
            args.append(('Srix', self.Srix))
        if self.Khz125Part1 != False:
            args.append(('Khz125Part1', self.Khz125Part1))
        if self.Felica != False:
            args.append(('Felica', self.Felica))
        if self.IClass != False:
            args.append(('IClass', self.IClass))
        if self.IClassIso14B != False:
            args.append(('IClassIso14B', self.IClassIso14B))
        if self.Iso14443B != False:
            args.append(('Iso14443B', self.Iso14443B))
        if self.Iso15693 != False:
            args.append(('Iso15693', self.Iso15693))
        if self.Iso14443A != False:
            args.append(('Iso14443A', self.Iso14443A))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
    
    @classmethod
    def all(cls) -> Self:
        return cls(LEGICPrime=True, BluetoothMce=True, Khz125Part2=True, Srix=True, Khz125Part1=True, Felica=True, IClass=True, IClassIso14B=True, Iso14443B=True, Iso15693=True, Iso14443A=True)
    
    @classmethod
    def all_except(cls, *, LEGICPrime: Optional[Literal[False]] = None, BluetoothMce: Optional[Literal[False]] = None, Khz125Part2: Optional[Literal[False]] = None, Srix: Optional[Literal[False]] = None, Khz125Part1: Optional[Literal[False]] = None, Felica: Optional[Literal[False]] = None, IClass: Optional[Literal[False]] = None, IClassIso14B: Optional[Literal[False]] = None, Iso14443B: Optional[Literal[False]] = None, Iso15693: Optional[Literal[False]] = None, Iso14443A: Optional[Literal[False]] = None) -> Self:
        true_fields = [name for name, value in [('LEGICPrime', LEGICPrime), ('BluetoothMce', BluetoothMce), ('Khz125Part2', Khz125Part2), ('Srix', Srix), ('Khz125Part1', Khz125Part1), ('Felica', Felica), ('IClass', IClass), ('IClassIso14B', IClassIso14B), ('Iso14443B', Iso14443B), ('Iso15693', Iso15693), ('Iso14443A', Iso14443A)] if value is True]  # type: ignore[comparison-overlap]
        if true_fields:
            raise TypeError(f"all_except() only accepts False values, got {', '.join(f'{name}=True' for name in true_fields)}")
        kwargs = {name: False if value is False else True for name, value in [('LEGICPrime', LEGICPrime), ('BluetoothMce', BluetoothMce), ('Khz125Part2', Khz125Part2), ('Srix', Srix), ('Khz125Part1', Khz125Part1), ('Felica', Felica), ('IClass', IClass), ('IClassIso14B', IClassIso14B), ('Iso14443B', Iso14443B), ('Iso15693', Iso15693), ('Iso14443A', Iso14443A)]}
        return cls(**kwargs)
class CardFamilies_Dict(TypedDict):
    LEGICPrime: 'NotRequired[bool]'
    BluetoothMce: 'NotRequired[bool]'
    Khz125Part2: 'NotRequired[bool]'
    Srix: 'NotRequired[bool]'
    Khz125Part1: 'NotRequired[bool]'
    Felica: 'NotRequired[bool]'
    IClass: 'NotRequired[bool]'
    IClassIso14B: 'NotRequired[bool]'
    Iso14443B: 'NotRequired[bool]'
    Iso15693: 'NotRequired[bool]'
    Iso14443A: 'NotRequired[bool]'
CardType = Literal["Default", "MifareClassic", "Iso14443aGeneric", "Iso14443aInterIndustryLegacy", "MifareUltraLight", "MifareDesfire", "InfineonSle55", "Iso14443aIntIndustry", "MifarePlusL2", "LEGICAdvantIso14443a", "MifarePlusL3", "LEGICPrimeLegacy", "LEGICAdvantLegacy", "Iso15693", "LEGICAdvantIso15693", "Iso14443bUnknown", "Iso14443bIntIndustry", "IClassIso14B", "IClassIso14B2", "IClass", "Felica", "EM4205", "EM4100", "EM4450", "Pyramid", "HidProx32", "Keri", "Quadrakey", "HidIndala", "HidAwid", "HidProx", "HidIoprox", "Hitag1S", "Hitag2M", "Hitag2B", "TTF", "STSRIX", "SecuraKey", "GProx", "HidIndalaSecure", "Cotag", "Idteck", "BluetoothMce", "LEGICPrime", "HidSio", "Fido", "Piv", "DesfireForLegic", "undefined"]
CardType_Parser = LiteralParser[CardType, int](
    name='CardType',
    literal_map={
        'Default': 0,
        'MifareClassic': 16,
        'Iso14443aGeneric': 17,
        'Iso14443aInterIndustryLegacy': 18,
        'MifareUltraLight': 19,
        'MifareDesfire': 20,
        'InfineonSle55': 21,
        'Iso14443aIntIndustry': 22,
        'MifarePlusL2': 23,
        'LEGICAdvantIso14443a': 24,
        'MifarePlusL3': 25,
        'LEGICPrimeLegacy': 32,
        'LEGICAdvantLegacy': 33,
        'Iso15693': 48,
        'LEGICAdvantIso15693': 50,
        'Iso14443bUnknown': 64,
        'Iso14443bIntIndustry': 65,
        'IClassIso14B': 66,
        'IClassIso14B2': 80,
        'IClass': 96,
        'Felica': 112,
        'EM4205': 128,
        'EM4100': 129,
        'EM4450': 131,
        'Pyramid': 132,
        'HidProx32': 133,
        'Keri': 134,
        'Quadrakey': 135,
        'HidIndala': 136,
        'HidAwid': 137,
        'HidProx': 138,
        'HidIoprox': 139,
        'Hitag1S': 140,
        'Hitag2M': 141,
        'Hitag2B': 142,
        'TTF': 143,
        'STSRIX': 144,
        'SecuraKey': 160,
        'GProx': 161,
        'HidIndalaSecure': 162,
        'Cotag': 163,
        'Idteck': 164,
        'BluetoothMce': 176,
        'LEGICPrime': 192,
        'HidSio': 224,
        'Fido': 228,
        'Piv': 229,
        'DesfireForLegic': 230,
        'undefined': -1,
    },
    undefined_literal='undefined',
)
class CardTypes125KhzPart1(NamedTuple):
    TTF: 'bool' = False
    Hitag2B: 'bool' = False
    Hitag2M: 'bool' = False
    Hitag1S: 'bool' = False
    HidIoprox: 'bool' = False
    HidProx: 'bool' = False
    HidAwid: 'bool' = False
    HidIndala: 'bool' = False
    Quadrakey: 'bool' = False
    Keri: 'bool' = False
    HidProx32: 'bool' = False
    Pyramid: 'bool' = False
    EM4450: 'bool' = False
    EM4100: 'bool' = False
    EM4205: 'bool' = False
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        if self.TTF != False:
            args.append(('TTF', self.TTF))
        if self.Hitag2B != False:
            args.append(('Hitag2B', self.Hitag2B))
        if self.Hitag2M != False:
            args.append(('Hitag2M', self.Hitag2M))
        if self.Hitag1S != False:
            args.append(('Hitag1S', self.Hitag1S))
        if self.HidIoprox != False:
            args.append(('HidIoprox', self.HidIoprox))
        if self.HidProx != False:
            args.append(('HidProx', self.HidProx))
        if self.HidAwid != False:
            args.append(('HidAwid', self.HidAwid))
        if self.HidIndala != False:
            args.append(('HidIndala', self.HidIndala))
        if self.Quadrakey != False:
            args.append(('Quadrakey', self.Quadrakey))
        if self.Keri != False:
            args.append(('Keri', self.Keri))
        if self.HidProx32 != False:
            args.append(('HidProx32', self.HidProx32))
        if self.Pyramid != False:
            args.append(('Pyramid', self.Pyramid))
        if self.EM4450 != False:
            args.append(('EM4450', self.EM4450))
        if self.EM4100 != False:
            args.append(('EM4100', self.EM4100))
        if self.EM4205 != False:
            args.append(('EM4205', self.EM4205))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
    
    @classmethod
    def all(cls) -> Self:
        return cls(TTF=True, Hitag2B=True, Hitag2M=True, Hitag1S=True, HidIoprox=True, HidProx=True, HidAwid=True, HidIndala=True, Quadrakey=True, Keri=True, HidProx32=True, Pyramid=True, EM4450=True, EM4100=True, EM4205=True)
    
    @classmethod
    def all_except(cls, *, TTF: Optional[Literal[False]] = None, Hitag2B: Optional[Literal[False]] = None, Hitag2M: Optional[Literal[False]] = None, Hitag1S: Optional[Literal[False]] = None, HidIoprox: Optional[Literal[False]] = None, HidProx: Optional[Literal[False]] = None, HidAwid: Optional[Literal[False]] = None, HidIndala: Optional[Literal[False]] = None, Quadrakey: Optional[Literal[False]] = None, Keri: Optional[Literal[False]] = None, HidProx32: Optional[Literal[False]] = None, Pyramid: Optional[Literal[False]] = None, EM4450: Optional[Literal[False]] = None, EM4100: Optional[Literal[False]] = None, EM4205: Optional[Literal[False]] = None) -> Self:
        true_fields = [name for name, value in [('TTF', TTF), ('Hitag2B', Hitag2B), ('Hitag2M', Hitag2M), ('Hitag1S', Hitag1S), ('HidIoprox', HidIoprox), ('HidProx', HidProx), ('HidAwid', HidAwid), ('HidIndala', HidIndala), ('Quadrakey', Quadrakey), ('Keri', Keri), ('HidProx32', HidProx32), ('Pyramid', Pyramid), ('EM4450', EM4450), ('EM4100', EM4100), ('EM4205', EM4205)] if value is True]  # type: ignore[comparison-overlap]
        if true_fields:
            raise TypeError(f"all_except() only accepts False values, got {', '.join(f'{name}=True' for name in true_fields)}")
        kwargs = {name: False if value is False else True for name, value in [('TTF', TTF), ('Hitag2B', Hitag2B), ('Hitag2M', Hitag2M), ('Hitag1S', Hitag1S), ('HidIoprox', HidIoprox), ('HidProx', HidProx), ('HidAwid', HidAwid), ('HidIndala', HidIndala), ('Quadrakey', Quadrakey), ('Keri', Keri), ('HidProx32', HidProx32), ('Pyramid', Pyramid), ('EM4450', EM4450), ('EM4100', EM4100), ('EM4205', EM4205)]}
        return cls(**kwargs)
class CardTypes125KhzPart1_Dict(TypedDict):
    TTF: 'NotRequired[bool]'
    Hitag2B: 'NotRequired[bool]'
    Hitag2M: 'NotRequired[bool]'
    Hitag1S: 'NotRequired[bool]'
    HidIoprox: 'NotRequired[bool]'
    HidProx: 'NotRequired[bool]'
    HidAwid: 'NotRequired[bool]'
    HidIndala: 'NotRequired[bool]'
    Quadrakey: 'NotRequired[bool]'
    Keri: 'NotRequired[bool]'
    HidProx32: 'NotRequired[bool]'
    Pyramid: 'NotRequired[bool]'
    EM4450: 'NotRequired[bool]'
    EM4100: 'NotRequired[bool]'
    EM4205: 'NotRequired[bool]'
class CardTypes125KhzPart2(NamedTuple):
    Idteck: 'bool' = False
    Cotag: 'bool' = False
    HidIndalaSecure: 'bool' = False
    GProx: 'bool' = False
    SecuraKey: 'bool' = False
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        if self.Idteck != False:
            args.append(('Idteck', self.Idteck))
        if self.Cotag != False:
            args.append(('Cotag', self.Cotag))
        if self.HidIndalaSecure != False:
            args.append(('HidIndalaSecure', self.HidIndalaSecure))
        if self.GProx != False:
            args.append(('GProx', self.GProx))
        if self.SecuraKey != False:
            args.append(('SecuraKey', self.SecuraKey))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
    
    @classmethod
    def all(cls) -> Self:
        return cls(Idteck=True, Cotag=True, HidIndalaSecure=True, GProx=True, SecuraKey=True)
    
    @classmethod
    def all_except(cls, *, Idteck: Optional[Literal[False]] = None, Cotag: Optional[Literal[False]] = None, HidIndalaSecure: Optional[Literal[False]] = None, GProx: Optional[Literal[False]] = None, SecuraKey: Optional[Literal[False]] = None) -> Self:
        true_fields = [name for name, value in [('Idteck', Idteck), ('Cotag', Cotag), ('HidIndalaSecure', HidIndalaSecure), ('GProx', GProx), ('SecuraKey', SecuraKey)] if value is True]  # type: ignore[comparison-overlap]
        if true_fields:
            raise TypeError(f"all_except() only accepts False values, got {', '.join(f'{name}=True' for name in true_fields)}")
        kwargs = {name: False if value is False else True for name, value in [('Idteck', Idteck), ('Cotag', Cotag), ('HidIndalaSecure', HidIndalaSecure), ('GProx', GProx), ('SecuraKey', SecuraKey)]}
        return cls(**kwargs)
class CardTypes125KhzPart2_Dict(TypedDict):
    Idteck: 'NotRequired[bool]'
    Cotag: 'NotRequired[bool]'
    HidIndalaSecure: 'NotRequired[bool]'
    GProx: 'NotRequired[bool]'
    SecuraKey: 'NotRequired[bool]'
CryptoAlgorithm = Literal["DES", "TripleDES", "ThreeKeyTripleDES", "AES", "MifareClassic"]
CryptoAlgorithm_Parser = LiteralParser[CryptoAlgorithm, int](
    name='CryptoAlgorithm',
    literal_map={
        'DES': 1,
        'TripleDES': 2,
        'ThreeKeyTripleDES': 3,
        'AES': 4,
        'MifareClassic': 5,
    },
)
class CryptoMemoryIndex(NamedTuple):
    Page: 'int'
    Idx: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('Page', self.Page))
        args.append(('Idx', self.Idx))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class CryptoMemoryIndex_Dict(TypedDict):
    Page: 'int'
    Idx: 'int'
Custom_BlackWhiteList_ListMode_BlackWhiteListMode = Literal["Blacklist", "Whitelist"]
Custom_BlackWhiteList_ListMode_BlackWhiteListMode_Parser = LiteralParser[Custom_BlackWhiteList_ListMode_BlackWhiteListMode, int](
    name='Custom_BlackWhiteList_ListMode_BlackWhiteListMode',
    literal_map={
        'Blacklist': 1,
        'Whitelist': 0,
    },
)
class DesfireFileDescription(NamedTuple):
    FileNo: 'int' = 0
    FileCommunicationSecurity: 'DesfireFileDescription_FileCommunicationSecurity' = "Plain"
    FileType: 'DesfireFileDescription_FileType' = "Standard"
    ReadKeyNo: 'int' = 0
    WriteKeyNo: 'int' = 0
    Offset: 'int' = 0
    Length: 'int' = 32767
    ReadKeyIdx: 'int' = 192
    WriteKeyIdx: 'int' = 192
    AccessRightsLowByte: 'int' = 0
    ChangeKeyIdx: 'int' = 0
    FileSize: 'int' = 256
    IsoFid: 'int' = 16128
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        if self.FileNo != 0:
            args.append(('FileNo', self.FileNo))
        if self.FileCommunicationSecurity != "Plain":
            args.append(('FileCommunicationSecurity', self.FileCommunicationSecurity))
        if self.FileType != "Standard":
            args.append(('FileType', self.FileType))
        if self.ReadKeyNo != 0:
            args.append(('ReadKeyNo', self.ReadKeyNo))
        if self.WriteKeyNo != 0:
            args.append(('WriteKeyNo', self.WriteKeyNo))
        if self.Offset != 0:
            args.append(('Offset', self.Offset))
        if self.Length != 32767:
            args.append(('Length', self.Length))
        if self.ReadKeyIdx != 192:
            args.append(('ReadKeyIdx', self.ReadKeyIdx))
        if self.WriteKeyIdx != 192:
            args.append(('WriteKeyIdx', self.WriteKeyIdx))
        if self.AccessRightsLowByte != 0:
            args.append(('AccessRightsLowByte', self.AccessRightsLowByte))
        if self.ChangeKeyIdx != 0:
            args.append(('ChangeKeyIdx', self.ChangeKeyIdx))
        if self.FileSize != 256:
            args.append(('FileSize', self.FileSize))
        if self.IsoFid != 16128:
            args.append(('IsoFid', self.IsoFid))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class DesfireFileDescription_Dict(TypedDict):
    FileNo: 'NotRequired[int]'
    FileCommunicationSecurity: 'NotRequired[DesfireFileDescription_FileCommunicationSecurity]'
    FileType: 'NotRequired[DesfireFileDescription_FileType]'
    ReadKeyNo: 'NotRequired[int]'
    WriteKeyNo: 'NotRequired[int]'
    Offset: 'NotRequired[int]'
    Length: 'NotRequired[int]'
    ReadKeyIdx: 'NotRequired[int]'
    WriteKeyIdx: 'NotRequired[int]'
    AccessRightsLowByte: 'NotRequired[int]'
    ChangeKeyIdx: 'NotRequired[int]'
    FileSize: 'NotRequired[int]'
    IsoFid: 'NotRequired[int]'
DesfireFileDescription_FileCommunicationSecurity = Literal["Plain", "Mac", "Encrypted"]
DesfireFileDescription_FileCommunicationSecurity_Parser = LiteralParser[DesfireFileDescription_FileCommunicationSecurity, int](
    name='DesfireFileDescription_FileCommunicationSecurity',
    literal_map={
        'Plain': 0,
        'Mac': 1,
        'Encrypted': 3,
    },
)
DesfireFileDescription_FileType = Literal["Standard", "Backup", "BackupManualCommit"]
DesfireFileDescription_FileType_Parser = LiteralParser[DesfireFileDescription_FileType, int](
    name='DesfireFileDescription_FileType',
    literal_map={
        'Standard': 0,
        'Backup': 1,
        'BackupManualCommit': 2,
    },
)
DesfireKeyIdx = int
Desfire_AuthExtKey_CryptoMode = Literal["DES", "TripleDES", "ThreeKeyTripleDES", "AES"]
Desfire_AuthExtKey_CryptoMode_Parser = LiteralParser[Desfire_AuthExtKey_CryptoMode, int](
    name='Desfire_AuthExtKey_CryptoMode',
    literal_map={
        'DES': 1,
        'TripleDES': 2,
        'ThreeKeyTripleDES': 3,
        'AES': 4,
    },
)
Desfire_AuthExtKey_SecureMessaging = Literal["Native", "EV1", "EV2"]
Desfire_AuthExtKey_SecureMessaging_Parser = LiteralParser[Desfire_AuthExtKey_SecureMessaging, int](
    name='Desfire_AuthExtKey_SecureMessaging',
    literal_map={
        'Native': 1,
        'EV1': 0,
        'EV2': 2,
    },
)
Desfire_Authenticate_KeyDivMode = Literal["NoDiv", "SamAV1OneRound", "SamAV1TwoRounds", "SamAV2"]
Desfire_Authenticate_KeyDivMode_Parser = LiteralParser[Desfire_Authenticate_KeyDivMode, int](
    name='Desfire_Authenticate_KeyDivMode',
    literal_map={
        'NoDiv': 0,
        'SamAV1OneRound': 1,
        'SamAV1TwoRounds': 2,
        'SamAV2': 3,
    },
)
Desfire_Authenticate_SecureMessaging = Literal["Native", "EV1", "EV2"]
Desfire_Authenticate_SecureMessaging_Parser = LiteralParser[Desfire_Authenticate_SecureMessaging, int](
    name='Desfire_Authenticate_SecureMessaging',
    literal_map={
        'Native': 1,
        'EV1': 0,
        'EV2': 2,
    },
)
Desfire_ChangeExtKey_MasterKeyType = Literal["DESorTripleDES", "ThreeKeyTripleDES", "AES"]
Desfire_ChangeExtKey_MasterKeyType_Parser = LiteralParser[Desfire_ChangeExtKey_MasterKeyType, int](
    name='Desfire_ChangeExtKey_MasterKeyType',
    literal_map={
        'DESorTripleDES': 0,
        'ThreeKeyTripleDES': 1,
        'AES': 2,
    },
)
Desfire_ChangeKey_CurKeyDivMode = Literal["SamAv1OneRound", "SamAv1TwoRounds", "SamAv2"]
Desfire_ChangeKey_CurKeyDivMode_Parser = LiteralParser[Desfire_ChangeKey_CurKeyDivMode, int](
    name='Desfire_ChangeKey_CurKeyDivMode',
    literal_map={
        'SamAv1OneRound': 0,
        'SamAv1TwoRounds': 1,
        'SamAv2': 2,
    },
)
Desfire_ChangeKey_NewKeyDivMode = Literal["SamAv1OneRound", "SamAv1TwoRounds", "SamAv2"]
Desfire_ChangeKey_NewKeyDivMode_Parser = LiteralParser[Desfire_ChangeKey_NewKeyDivMode, int](
    name='Desfire_ChangeKey_NewKeyDivMode',
    literal_map={
        'SamAv1OneRound': 0,
        'SamAv1TwoRounds': 1,
        'SamAv2': 2,
    },
)
Desfire_ExecCommand_CryptoMode = Literal["Plain", "MAC", "Encrypted"]
Desfire_ExecCommand_CryptoMode_Parser = LiteralParser[Desfire_ExecCommand_CryptoMode, int](
    name='Desfire_ExecCommand_CryptoMode',
    literal_map={
        'Plain': 0,
        'MAC': 1,
        'Encrypted': 3,
    },
)
class Desfire_GetDfNames_AppNr_Entry(NamedTuple):
    AppId: 'int'
    IsoFileId: 'int'
    IsoDfName: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('AppId', self.AppId))
        args.append(('IsoFileId', self.IsoFileId))
        args.append(('IsoDfName', self.IsoDfName))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
Desfire_ReadData_Mode = Literal["Plain", "MAC", "Encrypted"]
Desfire_ReadData_Mode_Parser = LiteralParser[Desfire_ReadData_Mode, int](
    name='Desfire_ReadData_Mode',
    literal_map={
        'Plain': 0,
        'MAC': 1,
        'Encrypted': 3,
    },
)
Desfire_SetFraming_CommMode = Literal["DESFireNative", "ISO7816Compatible"]
Desfire_SetFraming_CommMode_Parser = LiteralParser[Desfire_SetFraming_CommMode, int](
    name='Desfire_SetFraming_CommMode',
    literal_map={
        'DESFireNative': 1,
        'ISO7816Compatible': 2,
    },
)
Desfire_WriteData_Mode = Literal["Plain", "MAC", "Encrypted"]
Desfire_WriteData_Mode_Parser = LiteralParser[Desfire_WriteData_Mode, int](
    name='Desfire_WriteData_Mode',
    literal_map={
        'Plain': 0,
        'MAC': 1,
        'Encrypted': 3,
    },
)
Device_Boot_FirmwareCrcCheck_Value = Literal["Enabled", "Disabled"]
Device_Boot_FirmwareCrcCheck_Value_Parser = LiteralParser[Device_Boot_FirmwareCrcCheck_Value, int](
    name='Device_Boot_FirmwareCrcCheck_Value',
    literal_map={
        'Enabled': 255,
        'Disabled': 0,
    },
)
Device_Keypad_KeyPressSignal_SignalType = Literal["ShortBeep", "LongBeep"]
Device_Keypad_KeyPressSignal_SignalType_Parser = LiteralParser[Device_Keypad_KeyPressSignal_SignalType, int](
    name='Device_Keypad_KeyPressSignal_SignalType',
    literal_map={
        'ShortBeep': 0,
        'LongBeep': 1,
    },
)
Device_Keypad_SpecialKeySettings_Settings = Literal["StarSharpCorrect", "StarSharpTerminate", "Raw", "StarClearSharpTerminate", "DipSwitch"]
Device_Keypad_SpecialKeySettings_Settings_Parser = LiteralParser[Device_Keypad_SpecialKeySettings_Settings, int](
    name='Device_Keypad_SpecialKeySettings_Settings',
    literal_map={
        'StarSharpCorrect': 0,
        'StarSharpTerminate': 1,
        'Raw': 2,
        'StarClearSharpTerminate': 3,
        'DipSwitch': 255,
    },
)
Device_Run_AccessRightsOfBAC_Value = Literal["Disabled", "ReadOnly", "EnabledOnTamper", "Enabled"]
Device_Run_AccessRightsOfBAC_Value_Parser = LiteralParser[Device_Run_AccessRightsOfBAC_Value, int](
    name='Device_Run_AccessRightsOfBAC_Value',
    literal_map={
        'Disabled': 0,
        'ReadOnly': 1,
        'EnabledOnTamper': 2,
        'Enabled': 3,
    },
)
Device_Run_AutoreadPulseHf_PulseHf = Literal["Disabled", "Enabled"]
Device_Run_AutoreadPulseHf_PulseHf_Parser = LiteralParser[Device_Run_AutoreadPulseHf_PulseHf, int](
    name='Device_Run_AutoreadPulseHf_PulseHf',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
    },
)
Device_Run_AutoreadWaitForCardRemoval_WaitForCardRemoval = Literal["Disabled", "Enabled"]
Device_Run_AutoreadWaitForCardRemoval_WaitForCardRemoval_Parser = LiteralParser[Device_Run_AutoreadWaitForCardRemoval_WaitForCardRemoval, int](
    name='Device_Run_AutoreadWaitForCardRemoval_WaitForCardRemoval',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
    },
)
Device_Run_DenyReaderInfoViaIso14443_Value = Literal["False", "True"]
Device_Run_DenyReaderInfoViaIso14443_Value_Parser = LiteralParser[Device_Run_DenyReaderInfoViaIso14443_Value, int](
    name='Device_Run_DenyReaderInfoViaIso14443_Value',
    literal_map={
        'False': 0,
        'True': 1,
    },
)
Device_Run_DenyUnauthFwUploadViaBrp_Value = Literal["False", "True"]
Device_Run_DenyUnauthFwUploadViaBrp_Value_Parser = LiteralParser[Device_Run_DenyUnauthFwUploadViaBrp_Value, int](
    name='Device_Run_DenyUnauthFwUploadViaBrp_Value',
    literal_map={
        'False': 0,
        'True': 1,
    },
)
Device_Run_DenyUploadViaIso14443_Value = Literal["False", "True"]
Device_Run_DenyUploadViaIso14443_Value_Parser = LiteralParser[Device_Run_DenyUploadViaIso14443_Value, int](
    name='Device_Run_DenyUploadViaIso14443_Value',
    literal_map={
        'False': 0,
        'True': 1,
    },
)
Device_Run_SetBusAdrOnUploadViaIso14443_Value = Literal["Disabled", "Enabled", "Auto"]
Device_Run_SetBusAdrOnUploadViaIso14443_Value_Parser = LiteralParser[Device_Run_SetBusAdrOnUploadViaIso14443_Value, int](
    name='Device_Run_SetBusAdrOnUploadViaIso14443_Value',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
        'Auto': 2,
    },
)
DivisorInteger = Literal["Kbps106", "Kbps212", "Kbps424", "Kbps848"]
DivisorInteger_Parser = LiteralParser[DivisorInteger, int](
    name='DivisorInteger',
    literal_map={
        'Kbps106': 0,
        'Kbps212': 1,
        'Kbps424': 2,
        'Kbps848': 3,
    },
)
FeatureID = Literal["GreenLed", "RedLed", "Beeper", "Relay", "MHz13", "Khz125", "Iso14443A", "Iso14443AUidOnly", "Iso14443B", "Iso14443BUidOnly", "Iso15693", "Iso15693UidOnly", "Felica", "FelicaUidOnly", "Legic", "Sam", "SamAv2", "SamHid", "Picopass", "MifareClassic", "MifarePlusEv0", "MifareDESFireEv1", "Srix", "Jewel", "ISO14443L4", "InterIndustry", "EM4205", "EM4100", "EM4450", "FarpointePyramid", "HidProx32", "HidAwid", "HidProx", "HidIoProx", "Indala", "Keri", "IndalaSecure", "Quadrakey", "SecuraKey", "GProx", "Hitag1S", "Hitag2M", "Hitag2B", "BlueLed", "Cotag", "PicopassUidOnly", "IdTeck", "Tamper", "MaxHfBaudrate106kbps", "MaxHfBaudrate212kbps", "MaxHfBaudrate424kbps", "FirmwareLoader", "FwUploadViaBrpOverSer", "AesHostProtocolEncryption", "PkiHostProtocolEncryption", "HidIClass", "HidIClassSr", "HidIClassSeAndSeos", "MifareUltralight", "CardEmulationISO14443L4", "MifareDESFireEv2", "MifarePlusEv1", "SamAv3", "OsdpV217", "Bluetooth", "RgbLed", "RgbLedLimited", "Bec2Upload", "MifareDESFireEv3", "MobileId", "MobileCardEmulation", "BleHci", "BlePeripheral", "undefined"]
FeatureID_Parser = LiteralParser[FeatureID, int](
    name='FeatureID',
    literal_map={
        'GreenLed': 1,
        'RedLed': 2,
        'Beeper': 3,
        'Relay': 4,
        'MHz13': 5,
        'Khz125': 6,
        'Iso14443A': 7,
        'Iso14443AUidOnly': 8,
        'Iso14443B': 9,
        'Iso14443BUidOnly': 10,
        'Iso15693': 11,
        'Iso15693UidOnly': 12,
        'Felica': 13,
        'FelicaUidOnly': 14,
        'Legic': 15,
        'Sam': 16,
        'SamAv2': 17,
        'SamHid': 18,
        'Picopass': 19,
        'MifareClassic': 35,
        'MifarePlusEv0': 36,
        'MifareDESFireEv1': 37,
        'Srix': 38,
        'Jewel': 39,
        'ISO14443L4': 40,
        'InterIndustry': 41,
        'EM4205': 42,
        'EM4100': 43,
        'EM4450': 44,
        'FarpointePyramid': 45,
        'HidProx32': 46,
        'HidAwid': 47,
        'HidProx': 48,
        'HidIoProx': 49,
        'Indala': 50,
        'Keri': 51,
        'IndalaSecure': 52,
        'Quadrakey': 53,
        'SecuraKey': 54,
        'GProx': 55,
        'Hitag1S': 56,
        'Hitag2M': 57,
        'Hitag2B': 58,
        'BlueLed': 59,
        'Cotag': 60,
        'PicopassUidOnly': 61,
        'IdTeck': 62,
        'Tamper': 63,
        'MaxHfBaudrate106kbps': 64,
        'MaxHfBaudrate212kbps': 65,
        'MaxHfBaudrate424kbps': 66,
        'FirmwareLoader': 67,
        'FwUploadViaBrpOverSer': 68,
        'AesHostProtocolEncryption': 69,
        'PkiHostProtocolEncryption': 70,
        'HidIClass': 71,
        'HidIClassSr': 72,
        'HidIClassSeAndSeos': 73,
        'MifareUltralight': 74,
        'CardEmulationISO14443L4': 75,
        'MifareDESFireEv2': 76,
        'MifarePlusEv1': 77,
        'SamAv3': 78,
        'OsdpV217': 79,
        'Bluetooth': 80,
        'RgbLed': 81,
        'RgbLedLimited': 82,
        'Bec2Upload': 83,
        'MifareDESFireEv3': 84,
        'MobileId': 85,
        'MobileCardEmulation': 86,
        'BleHci': 87,
        'BlePeripheral': 88,
        'undefined': -1,
    },
    undefined_literal='undefined',
)
Felica_GenericCmd_FastBaud = Literal["Kbps212", "Kbps424"]
Felica_GenericCmd_FastBaud_Parser = LiteralParser[Felica_GenericCmd_FastBaud, int](
    name='Felica_GenericCmd_FastBaud',
    literal_map={
        'Kbps212': 0,
        'Kbps424': 1,
    },
)
Felica_Request_FastBaud = Literal["Kbps212", "Kbps424"]
Felica_Request_FastBaud_Parser = LiteralParser[Felica_Request_FastBaud, int](
    name='Felica_Request_FastBaud',
    literal_map={
        'Kbps212': 0,
        'Kbps424': 1,
    },
)
FileType = Literal["FileByDfName", "FileByFileId", "FileByApduCmd"]
FileType_Parser = LiteralParser[FileType, int](
    name='FileType',
    literal_map={
        'FileByDfName': 0,
        'FileByFileId': 1,
        'FileByApduCmd': 2,
    },
)
FireEventAtPowerup = Literal["Never", "IfClear", "IfSet", "Always"]
FireEventAtPowerup_Parser = LiteralParser[FireEventAtPowerup, int](
    name='FireEventAtPowerup',
    literal_map={
        'Never': 0,
        'IfClear': 1,
        'IfSet': 2,
        'Always': 3,
    },
)
class FirmwareVersion(NamedTuple):
    FirmwareID: 'int'
    SmallestBlockedFwVersionMajor: 'int'
    SmallestBlockedFwVersionMinor: 'int'
    SmallestBlockedFwVersionBuild: 'int'
    GreatestBlockedFwVersionMajor: 'int'
    GreatestBlockedFwVersionMinor: 'int'
    GreatestBlockedFwVersionBuild: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('FirmwareID', self.FirmwareID))
        args.append(('SmallestBlockedFwVersionMajor', self.SmallestBlockedFwVersionMajor))
        args.append(('SmallestBlockedFwVersionMinor', self.SmallestBlockedFwVersionMinor))
        args.append(('SmallestBlockedFwVersionBuild', self.SmallestBlockedFwVersionBuild))
        args.append(('GreatestBlockedFwVersionMajor', self.GreatestBlockedFwVersionMajor))
        args.append(('GreatestBlockedFwVersionMinor', self.GreatestBlockedFwVersionMinor))
        args.append(('GreatestBlockedFwVersionBuild', self.GreatestBlockedFwVersionBuild))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class FirmwareVersion_Dict(TypedDict):
    FirmwareID: 'int'
    SmallestBlockedFwVersionMajor: 'int'
    SmallestBlockedFwVersionMinor: 'int'
    SmallestBlockedFwVersionBuild: 'int'
    GreatestBlockedFwVersionMajor: 'int'
    GreatestBlockedFwVersionMinor: 'int'
    GreatestBlockedFwVersionBuild: 'int'
class HostSecurityAccessConditionBits(NamedTuple):
    """
    Every Feature in this list can be disabled by not setting the corresponding bit.
    """
    HostToHostAccess: 'bool' = False
    AutoreadAccess: 'bool' = False
    CryptoAccess: 'bool' = False
    Bf2Upload: 'bool' = False
    ExtendedAccess: 'bool' = False
    FlashFileSystemWrite: 'bool' = False
    FlashFileSystemRead: 'bool' = False
    RtcWrite: 'bool' = False
    VhlExchangeapdu: 'bool' = False
    VhlFormat: 'bool' = False
    VhlWrite: 'bool' = False
    VhlRead: 'bool' = False
    VhlSelect: 'bool' = False
    ExtSamAccess: 'bool' = False
    HfLowlevelAccess: 'bool' = False
    GuiAccess: 'bool' = False
    IoPortWrite: 'bool' = False
    IoPortRead: 'bool' = False
    ConfigReset: 'bool' = False
    ConfigWrite: 'bool' = False
    ConfigRead: 'bool' = False
    SysReset: 'bool' = False
    SetAccessConditionMask2: 'bool' = False
    SetAccessConditionMask1: 'bool' = False
    SetAccessConditionMask0: 'bool' = False
    SetKey3: 'bool' = False
    SetKey2: 'bool' = False
    SetKey1: 'bool' = False
    FactoryReset: 'bool' = False
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        if self.HostToHostAccess != False:
            args.append(('HostToHostAccess', self.HostToHostAccess))
        if self.AutoreadAccess != False:
            args.append(('AutoreadAccess', self.AutoreadAccess))
        if self.CryptoAccess != False:
            args.append(('CryptoAccess', self.CryptoAccess))
        if self.Bf2Upload != False:
            args.append(('Bf2Upload', self.Bf2Upload))
        if self.ExtendedAccess != False:
            args.append(('ExtendedAccess', self.ExtendedAccess))
        if self.FlashFileSystemWrite != False:
            args.append(('FlashFileSystemWrite', self.FlashFileSystemWrite))
        if self.FlashFileSystemRead != False:
            args.append(('FlashFileSystemRead', self.FlashFileSystemRead))
        if self.RtcWrite != False:
            args.append(('RtcWrite', self.RtcWrite))
        if self.VhlExchangeapdu != False:
            args.append(('VhlExchangeapdu', self.VhlExchangeapdu))
        if self.VhlFormat != False:
            args.append(('VhlFormat', self.VhlFormat))
        if self.VhlWrite != False:
            args.append(('VhlWrite', self.VhlWrite))
        if self.VhlRead != False:
            args.append(('VhlRead', self.VhlRead))
        if self.VhlSelect != False:
            args.append(('VhlSelect', self.VhlSelect))
        if self.ExtSamAccess != False:
            args.append(('ExtSamAccess', self.ExtSamAccess))
        if self.HfLowlevelAccess != False:
            args.append(('HfLowlevelAccess', self.HfLowlevelAccess))
        if self.GuiAccess != False:
            args.append(('GuiAccess', self.GuiAccess))
        if self.IoPortWrite != False:
            args.append(('IoPortWrite', self.IoPortWrite))
        if self.IoPortRead != False:
            args.append(('IoPortRead', self.IoPortRead))
        if self.ConfigReset != False:
            args.append(('ConfigReset', self.ConfigReset))
        if self.ConfigWrite != False:
            args.append(('ConfigWrite', self.ConfigWrite))
        if self.ConfigRead != False:
            args.append(('ConfigRead', self.ConfigRead))
        if self.SysReset != False:
            args.append(('SysReset', self.SysReset))
        if self.SetAccessConditionMask2 != False:
            args.append(('SetAccessConditionMask2', self.SetAccessConditionMask2))
        if self.SetAccessConditionMask1 != False:
            args.append(('SetAccessConditionMask1', self.SetAccessConditionMask1))
        if self.SetAccessConditionMask0 != False:
            args.append(('SetAccessConditionMask0', self.SetAccessConditionMask0))
        if self.SetKey3 != False:
            args.append(('SetKey3', self.SetKey3))
        if self.SetKey2 != False:
            args.append(('SetKey2', self.SetKey2))
        if self.SetKey1 != False:
            args.append(('SetKey1', self.SetKey1))
        if self.FactoryReset != False:
            args.append(('FactoryReset', self.FactoryReset))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
    
    @classmethod
    def all(cls) -> Self:
        return cls(HostToHostAccess=True, AutoreadAccess=True, CryptoAccess=True, Bf2Upload=True, ExtendedAccess=True, FlashFileSystemWrite=True, FlashFileSystemRead=True, RtcWrite=True, VhlExchangeapdu=True, VhlFormat=True, VhlWrite=True, VhlRead=True, VhlSelect=True, ExtSamAccess=True, HfLowlevelAccess=True, GuiAccess=True, IoPortWrite=True, IoPortRead=True, ConfigReset=True, ConfigWrite=True, ConfigRead=True, SysReset=True, SetAccessConditionMask2=True, SetAccessConditionMask1=True, SetAccessConditionMask0=True, SetKey3=True, SetKey2=True, SetKey1=True, FactoryReset=True)
    
    @classmethod
    def all_except(cls, *, HostToHostAccess: Optional[Literal[False]] = None, AutoreadAccess: Optional[Literal[False]] = None, CryptoAccess: Optional[Literal[False]] = None, Bf2Upload: Optional[Literal[False]] = None, ExtendedAccess: Optional[Literal[False]] = None, FlashFileSystemWrite: Optional[Literal[False]] = None, FlashFileSystemRead: Optional[Literal[False]] = None, RtcWrite: Optional[Literal[False]] = None, VhlExchangeapdu: Optional[Literal[False]] = None, VhlFormat: Optional[Literal[False]] = None, VhlWrite: Optional[Literal[False]] = None, VhlRead: Optional[Literal[False]] = None, VhlSelect: Optional[Literal[False]] = None, ExtSamAccess: Optional[Literal[False]] = None, HfLowlevelAccess: Optional[Literal[False]] = None, GuiAccess: Optional[Literal[False]] = None, IoPortWrite: Optional[Literal[False]] = None, IoPortRead: Optional[Literal[False]] = None, ConfigReset: Optional[Literal[False]] = None, ConfigWrite: Optional[Literal[False]] = None, ConfigRead: Optional[Literal[False]] = None, SysReset: Optional[Literal[False]] = None, SetAccessConditionMask2: Optional[Literal[False]] = None, SetAccessConditionMask1: Optional[Literal[False]] = None, SetAccessConditionMask0: Optional[Literal[False]] = None, SetKey3: Optional[Literal[False]] = None, SetKey2: Optional[Literal[False]] = None, SetKey1: Optional[Literal[False]] = None, FactoryReset: Optional[Literal[False]] = None) -> Self:
        true_fields = [name for name, value in [('HostToHostAccess', HostToHostAccess), ('AutoreadAccess', AutoreadAccess), ('CryptoAccess', CryptoAccess), ('Bf2Upload', Bf2Upload), ('ExtendedAccess', ExtendedAccess), ('FlashFileSystemWrite', FlashFileSystemWrite), ('FlashFileSystemRead', FlashFileSystemRead), ('RtcWrite', RtcWrite), ('VhlExchangeapdu', VhlExchangeapdu), ('VhlFormat', VhlFormat), ('VhlWrite', VhlWrite), ('VhlRead', VhlRead), ('VhlSelect', VhlSelect), ('ExtSamAccess', ExtSamAccess), ('HfLowlevelAccess', HfLowlevelAccess), ('GuiAccess', GuiAccess), ('IoPortWrite', IoPortWrite), ('IoPortRead', IoPortRead), ('ConfigReset', ConfigReset), ('ConfigWrite', ConfigWrite), ('ConfigRead', ConfigRead), ('SysReset', SysReset), ('SetAccessConditionMask2', SetAccessConditionMask2), ('SetAccessConditionMask1', SetAccessConditionMask1), ('SetAccessConditionMask0', SetAccessConditionMask0), ('SetKey3', SetKey3), ('SetKey2', SetKey2), ('SetKey1', SetKey1), ('FactoryReset', FactoryReset)] if value is True]  # type: ignore[comparison-overlap]
        if true_fields:
            raise TypeError(f"all_except() only accepts False values, got {', '.join(f'{name}=True' for name in true_fields)}")
        kwargs = {name: False if value is False else True for name, value in [('HostToHostAccess', HostToHostAccess), ('AutoreadAccess', AutoreadAccess), ('CryptoAccess', CryptoAccess), ('Bf2Upload', Bf2Upload), ('ExtendedAccess', ExtendedAccess), ('FlashFileSystemWrite', FlashFileSystemWrite), ('FlashFileSystemRead', FlashFileSystemRead), ('RtcWrite', RtcWrite), ('VhlExchangeapdu', VhlExchangeapdu), ('VhlFormat', VhlFormat), ('VhlWrite', VhlWrite), ('VhlRead', VhlRead), ('VhlSelect', VhlSelect), ('ExtSamAccess', ExtSamAccess), ('HfLowlevelAccess', HfLowlevelAccess), ('GuiAccess', GuiAccess), ('IoPortWrite', IoPortWrite), ('IoPortRead', IoPortRead), ('ConfigReset', ConfigReset), ('ConfigWrite', ConfigWrite), ('ConfigRead', ConfigRead), ('SysReset', SysReset), ('SetAccessConditionMask2', SetAccessConditionMask2), ('SetAccessConditionMask1', SetAccessConditionMask1), ('SetAccessConditionMask0', SetAccessConditionMask0), ('SetKey3', SetKey3), ('SetKey2', SetKey2), ('SetKey1', SetKey1), ('FactoryReset', FactoryReset)]}
        return cls(**kwargs)
class HostSecurityAccessConditionBits_Dict(TypedDict):
    """
    Every Feature in this list can be disabled by not setting the corresponding bit.
    """
    HostToHostAccess: 'NotRequired[bool]'
    AutoreadAccess: 'NotRequired[bool]'
    CryptoAccess: 'NotRequired[bool]'
    Bf2Upload: 'NotRequired[bool]'
    ExtendedAccess: 'NotRequired[bool]'
    FlashFileSystemWrite: 'NotRequired[bool]'
    FlashFileSystemRead: 'NotRequired[bool]'
    RtcWrite: 'NotRequired[bool]'
    VhlExchangeapdu: 'NotRequired[bool]'
    VhlFormat: 'NotRequired[bool]'
    VhlWrite: 'NotRequired[bool]'
    VhlRead: 'NotRequired[bool]'
    VhlSelect: 'NotRequired[bool]'
    ExtSamAccess: 'NotRequired[bool]'
    HfLowlevelAccess: 'NotRequired[bool]'
    GuiAccess: 'NotRequired[bool]'
    IoPortWrite: 'NotRequired[bool]'
    IoPortRead: 'NotRequired[bool]'
    ConfigReset: 'NotRequired[bool]'
    ConfigWrite: 'NotRequired[bool]'
    ConfigRead: 'NotRequired[bool]'
    SysReset: 'NotRequired[bool]'
    SetAccessConditionMask2: 'NotRequired[bool]'
    SetAccessConditionMask1: 'NotRequired[bool]'
    SetAccessConditionMask0: 'NotRequired[bool]'
    SetKey3: 'NotRequired[bool]'
    SetKey2: 'NotRequired[bool]'
    SetKey1: 'NotRequired[bool]'
    FactoryReset: 'NotRequired[bool]'
class HostSecurityAuthenticationMode(NamedTuple):
    """
    Specifies a minimum of security requirements, when working in this security level
    """
    RequireContinuousIv: 'bool' = False
    RequireEncrypted: 'bool' = False
    RequireMac: 'bool' = False
    RequireSessionKey: 'bool' = False
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        if self.RequireContinuousIv != False:
            args.append(('RequireContinuousIv', self.RequireContinuousIv))
        if self.RequireEncrypted != False:
            args.append(('RequireEncrypted', self.RequireEncrypted))
        if self.RequireMac != False:
            args.append(('RequireMac', self.RequireMac))
        if self.RequireSessionKey != False:
            args.append(('RequireSessionKey', self.RequireSessionKey))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
    
    @classmethod
    def all(cls) -> Self:
        return cls(RequireContinuousIv=True, RequireEncrypted=True, RequireMac=True, RequireSessionKey=True)
    
    @classmethod
    def all_except(cls, *, RequireContinuousIv: Optional[Literal[False]] = None, RequireEncrypted: Optional[Literal[False]] = None, RequireMac: Optional[Literal[False]] = None, RequireSessionKey: Optional[Literal[False]] = None) -> Self:
        true_fields = [name for name, value in [('RequireContinuousIv', RequireContinuousIv), ('RequireEncrypted', RequireEncrypted), ('RequireMac', RequireMac), ('RequireSessionKey', RequireSessionKey)] if value is True]  # type: ignore[comparison-overlap]
        if true_fields:
            raise TypeError(f"all_except() only accepts False values, got {', '.join(f'{name}=True' for name in true_fields)}")
        kwargs = {name: False if value is False else True for name, value in [('RequireContinuousIv', RequireContinuousIv), ('RequireEncrypted', RequireEncrypted), ('RequireMac', RequireMac), ('RequireSessionKey', RequireSessionKey)]}
        return cls(**kwargs)
class HostSecurityAuthenticationMode_Dict(TypedDict):
    """
    Specifies a minimum of security requirements, when working in this security level
    """
    RequireContinuousIv: 'NotRequired[bool]'
    RequireEncrypted: 'NotRequired[bool]'
    RequireMac: 'NotRequired[bool]'
    RequireSessionKey: 'NotRequired[bool]'
IoPort = Literal["GreenLed", "RedLed", "Beeper", "Relay", "Input0", "Input1", "BlueLed", "TamperAlarm", "Gpio0", "Gpio1", "Gpio2", "Gpio3", "Gpio4", "Gpio5", "Gpio6", "Gpio7", "CustomVled0", "CustomVled1", "CustomVled2", "CustomVled3", "CustomVled4", "CustomVled5", "CustomVled6", "CustomVled7", "CustomVled8", "CustomVled9", "CustomVled10", "CustomVled11", "CustomVled12", "CustomVled13", "CustomVled14", "CustomVled15"]
IoPort_Parser = LiteralParser[IoPort, int](
    name='IoPort',
    literal_map={
        'GreenLed': 0,
        'RedLed': 1,
        'Beeper': 2,
        'Relay': 3,
        'Input0': 4,
        'Input1': 5,
        'BlueLed': 6,
        'TamperAlarm': 7,
        'Gpio0': 8,
        'Gpio1': 9,
        'Gpio2': 10,
        'Gpio3': 11,
        'Gpio4': 12,
        'Gpio5': 13,
        'Gpio6': 14,
        'Gpio7': 15,
        'CustomVled0': 64,
        'CustomVled1': 65,
        'CustomVled2': 66,
        'CustomVled3': 67,
        'CustomVled4': 68,
        'CustomVled5': 69,
        'CustomVled6': 70,
        'CustomVled7': 71,
        'CustomVled8': 72,
        'CustomVled9': 73,
        'CustomVled10': 74,
        'CustomVled11': 75,
        'CustomVled12': 76,
        'CustomVled13': 77,
        'CustomVled14': 78,
        'CustomVled15': 79,
    },
)
Iso14L4_SetupAPDU_FSCI = Literal["Bytes16", "Bytes24", "Bytes32", "Bytes40", "Bytes48", "Bytes64", "Bytes96", "Bytes128", "Bytes256"]
Iso14L4_SetupAPDU_FSCI_Parser = LiteralParser[Iso14L4_SetupAPDU_FSCI, int](
    name='Iso14L4_SetupAPDU_FSCI',
    literal_map={
        'Bytes16': 0,
        'Bytes24': 1,
        'Bytes32': 2,
        'Bytes40': 3,
        'Bytes48': 4,
        'Bytes64': 5,
        'Bytes96': 6,
        'Bytes128': 7,
        'Bytes256': 8,
    },
)
Iso14L4_SetupAPDU_FWI = Literal["Us302", "Us604", "Us1208", "Us2416", "Us4832", "Us9664", "Ms19", "Ms39", "Ms77", "Ms155", "Ms309", "Ms618", "Ms1237", "Ms2474", "Ms4948"]
Iso14L4_SetupAPDU_FWI_Parser = LiteralParser[Iso14L4_SetupAPDU_FWI, int](
    name='Iso14L4_SetupAPDU_FWI',
    literal_map={
        'Us302': 0,
        'Us604': 1,
        'Us1208': 2,
        'Us2416': 3,
        'Us4832': 4,
        'Us9664': 5,
        'Ms19': 6,
        'Ms39': 7,
        'Ms77': 8,
        'Ms155': 9,
        'Ms309': 10,
        'Ms618': 11,
        'Ms1237': 12,
        'Ms2474': 13,
        'Ms4948': 14,
    },
)
Iso14a_RequestATS_FSDI = Literal["Bytes16", "Bytes24", "Bytes32", "Bytes40", "Bytes48", "Bytes64", "Bytes96", "Bytes128", "Bytes256"]
Iso14a_RequestATS_FSDI_Parser = LiteralParser[Iso14a_RequestATS_FSDI, int](
    name='Iso14a_RequestATS_FSDI',
    literal_map={
        'Bytes16': 0,
        'Bytes24': 1,
        'Bytes32': 2,
        'Bytes40': 3,
        'Bytes48': 4,
        'Bytes64': 5,
        'Bytes96': 6,
        'Bytes128': 7,
        'Bytes256': 8,
    },
)
Iso14b_Attrib_EOF = Literal["EOFrequired", "EOFoptional"]
Iso14b_Attrib_EOF_Parser = LiteralParser[Iso14b_Attrib_EOF, int](
    name='Iso14b_Attrib_EOF',
    literal_map={
        'EOFrequired': 0,
        'EOFoptional': 1,
    },
)
Iso14b_Attrib_FSDI = Literal["Bytes16", "Bytes24", "Bytes32", "Bytes40", "Bytes48", "Bytes64", "Bytes96", "Bytes128", "Bytes256"]
Iso14b_Attrib_FSDI_Parser = LiteralParser[Iso14b_Attrib_FSDI, int](
    name='Iso14b_Attrib_FSDI',
    literal_map={
        'Bytes16': 0,
        'Bytes24': 1,
        'Bytes32': 2,
        'Bytes40': 3,
        'Bytes48': 4,
        'Bytes64': 5,
        'Bytes96': 6,
        'Bytes128': 7,
        'Bytes256': 8,
    },
)
Iso14b_Attrib_SOF = Literal["SOFrequired", "SOFoptional"]
Iso14b_Attrib_SOF_Parser = LiteralParser[Iso14b_Attrib_SOF, int](
    name='Iso14b_Attrib_SOF',
    literal_map={
        'SOFrequired': 0,
        'SOFoptional': 1,
    },
)
Iso14b_Attrib_TR0 = Literal["Numerator64", "Numerator48", "Numerator16"]
Iso14b_Attrib_TR0_Parser = LiteralParser[Iso14b_Attrib_TR0, int](
    name='Iso14b_Attrib_TR0',
    literal_map={
        'Numerator64': 0,
        'Numerator48': 1,
        'Numerator16': 2,
    },
)
Iso14b_Attrib_TR1 = Literal["Numerator80", "Numerator64", "Numerator16"]
Iso14b_Attrib_TR1_Parser = LiteralParser[Iso14b_Attrib_TR1, int](
    name='Iso14b_Attrib_TR1',
    literal_map={
        'Numerator80': 0,
        'Numerator64': 1,
        'Numerator16': 2,
    },
)
Iso14b_Request_FSCI = Literal["Bytes16", "Bytes24", "Bytes32", "Bytes40", "Bytes48", "Bytes64", "Bytes96", "Bytes128", "Bytes256"]
Iso14b_Request_FSCI_Parser = LiteralParser[Iso14b_Request_FSCI, int](
    name='Iso14b_Request_FSCI',
    literal_map={
        'Bytes16': 0,
        'Bytes24': 1,
        'Bytes32': 2,
        'Bytes40': 3,
        'Bytes48': 4,
        'Bytes64': 5,
        'Bytes96': 6,
        'Bytes128': 7,
        'Bytes256': 8,
    },
)
Iso14b_Request_FWI = Literal["Us302", "Us604", "Us1208", "Us2416", "Us4832", "Us9664", "Ms19", "Ms39", "Ms77", "Ms155", "Ms309", "Ms618", "Ms1237", "Ms2474", "Ms4948"]
Iso14b_Request_FWI_Parser = LiteralParser[Iso14b_Request_FWI, int](
    name='Iso14b_Request_FWI',
    literal_map={
        'Us302': 0,
        'Us604': 1,
        'Us1208': 2,
        'Us2416': 3,
        'Us4832': 4,
        'Us9664': 5,
        'Ms19': 6,
        'Ms39': 7,
        'Ms77': 8,
        'Ms155': 9,
        'Ms309': 10,
        'Ms618': 11,
        'Ms1237': 12,
        'Ms2474': 13,
        'Ms4948': 14,
    },
)
Iso14b_Request_ProtType = Literal["NoISO14443L4Support", "ISO14443L4Support", "undefined"]
Iso14b_Request_ProtType_Parser = LiteralParser[Iso14b_Request_ProtType, int](
    name='Iso14b_Request_ProtType',
    literal_map={
        'NoISO14443L4Support': 0,
        'ISO14443L4Support': 1,
        'undefined': -1,
    },
    undefined_literal='undefined',
)
Iso14b_Request_SFGI = Literal["Us302", "Us604", "Us1208", "Us2416", "Us4832", "Us9664", "Ms19", "Ms39", "Ms77", "Ms155", "Ms309", "Ms618", "Ms1237", "Ms2474", "Ms4948"]
Iso14b_Request_SFGI_Parser = LiteralParser[Iso14b_Request_SFGI, int](
    name='Iso14b_Request_SFGI',
    literal_map={
        'Us302': 0,
        'Us604': 1,
        'Us1208': 2,
        'Us2416': 3,
        'Us4832': 4,
        'Us9664': 5,
        'Ms19': 6,
        'Ms39': 7,
        'Ms77': 8,
        'Ms155': 9,
        'Ms309': 10,
        'Ms618': 11,
        'Ms1237': 12,
        'Ms2474': 13,
        'Ms4948': 14,
    },
)
Iso14b_Request_TimeSlots = Literal["TimeSlots1", "TimeSlots2", "TimeSlots4", "TimeSlots8", "TimeSlots16"]
Iso14b_Request_TimeSlots_Parser = LiteralParser[Iso14b_Request_TimeSlots, int](
    name='Iso14b_Request_TimeSlots',
    literal_map={
        'TimeSlots1': 0,
        'TimeSlots2': 1,
        'TimeSlots4': 2,
        'TimeSlots8': 3,
        'TimeSlots16': 4,
    },
)
class Iso14b_Request_ValueList_Entry(NamedTuple):
    PUPI: 'bytes'
    AppData: 'bytes'
    Synced: 'bool'
    Send848: 'bool'
    Send424: 'bool'
    Send212: 'bool'
    Recv848: 'bool'
    Recv424: 'bool'
    Recv212: 'bool'
    FSCI: 'FSCI'
    ProtType: 'ProtType'
    FWI: 'FWI'
    ADC: 'int'
    NAD: 'bool'
    CID: 'bool'
    SFGI: 'Optional[SFGI]' = None
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('PUPI', self.PUPI))
        args.append(('AppData', self.AppData))
        args.append(('Synced', self.Synced))
        args.append(('Send848', self.Send848))
        args.append(('Send424', self.Send424))
        args.append(('Send212', self.Send212))
        args.append(('Recv848', self.Recv848))
        args.append(('Recv424', self.Recv424))
        args.append(('Recv212', self.Recv212))
        args.append(('FSCI', self.FSCI))
        args.append(('ProtType', self.ProtType))
        args.append(('FWI', self.FWI))
        args.append(('ADC', self.ADC))
        args.append(('NAD', self.NAD))
        args.append(('CID', self.CID))
        if self.SFGI != None:
            args.append(('SFGI', self.SFGI))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
FSCI = Literal["Bytes16", "Bytes24", "Bytes32", "Bytes40", "Bytes48", "Bytes64", "Bytes96", "Bytes128", "Bytes256"]
FSCI_Parser = LiteralParser[FSCI, int](
    name='FSCI',
    literal_map={
        'Bytes16': 0,
        'Bytes24': 1,
        'Bytes32': 2,
        'Bytes40': 3,
        'Bytes48': 4,
        'Bytes64': 5,
        'Bytes96': 6,
        'Bytes128': 7,
        'Bytes256': 8,
    },
)
FWI = Literal["Us302", "Us604", "Us1208", "Us2416", "Us4832", "Us9664", "Ms19", "Ms39", "Ms77", "Ms155", "Ms309", "Ms618", "Ms1237", "Ms2474", "Ms4948"]
FWI_Parser = LiteralParser[FWI, int](
    name='FWI',
    literal_map={
        'Us302': 0,
        'Us604': 1,
        'Us1208': 2,
        'Us2416': 3,
        'Us4832': 4,
        'Us9664': 5,
        'Ms19': 6,
        'Ms39': 7,
        'Ms77': 8,
        'Ms155': 9,
        'Ms309': 10,
        'Ms618': 11,
        'Ms1237': 12,
        'Ms2474': 13,
        'Ms4948': 14,
    },
)
class Iso15_GetUIDList_Labels_Entry(NamedTuple):
    UID: 'bytes'
    DSFID: 'Optional[int]' = None
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('UID', self.UID))
        if self.DSFID != None:
            args.append(('DSFID', self.DSFID))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
Iso15_SetMode_Mode = Literal["Unaddressed", "Addressed", "Selected"]
Iso15_SetMode_Mode_Parser = LiteralParser[Iso15_SetMode_Mode, int](
    name='Iso15_SetMode_Mode',
    literal_map={
        'Unaddressed': 0,
        'Addressed': 1,
        'Selected': 2,
    },
)
Iso78_OpenSam_LID = Literal["AV2", "HID", "Gen1", "Gen2"]
Iso78_OpenSam_LID_Parser = LiteralParser[Iso78_OpenSam_LID, int](
    name='Iso78_OpenSam_LID',
    literal_map={
        'AV2': 0,
        'HID': 1,
        'Gen1': 16,
        'Gen2': 17,
    },
)
class KeyAccessRights(NamedTuple):
    KeySettings: 'KeyAccessRights_KeySettings'
    Version: 'Optional[int]' = None
    DiversificationMode: 'Optional[KeyAccessRights_DiversificationMode]' = None
    DivIdx: 'Optional[int]' = None
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('KeySettings', self.KeySettings))
        if self.Version != None:
            args.append(('Version', self.Version))
        if self.DiversificationMode != None:
            args.append(('DiversificationMode', self.DiversificationMode))
        if self.DivIdx != None:
            args.append(('DivIdx', self.DivIdx))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class KeyAccessRights_Dict(TypedDict):
    KeySettings: 'KeyAccessRights_KeySettings'
    Version: 'NotRequired[int]'
    DiversificationMode: 'NotRequired[KeyAccessRights_DiversificationMode]'
    DivIdx: 'NotRequired[int]'
KeyAccessRights_DiversificationMode = Literal["NoDiversification", "ModeAv2"]
KeyAccessRights_DiversificationMode_Parser = LiteralParser[KeyAccessRights_DiversificationMode, int](
    name='KeyAccessRights_DiversificationMode',
    literal_map={
        'NoDiversification': 0,
        'ModeAv2': 2,
    },
)
class KeyAccessRights_KeySettings(NamedTuple):
    """
    Access rights and key info 
    
    Access rights: By default, all operations are allowed. With this bitmask, however, this key can be locked for certain operations.
    """
    IsVersion: 'bool' = False
    IsDivInfo: 'bool' = False
    IsDivInfoVhl: 'bool' = False
    DenyFormat: 'bool' = False
    DenyWrite: 'bool' = False
    DenyRead: 'bool' = False
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        if self.IsVersion != False:
            args.append(('IsVersion', self.IsVersion))
        if self.IsDivInfo != False:
            args.append(('IsDivInfo', self.IsDivInfo))
        if self.IsDivInfoVhl != False:
            args.append(('IsDivInfoVhl', self.IsDivInfoVhl))
        if self.DenyFormat != False:
            args.append(('DenyFormat', self.DenyFormat))
        if self.DenyWrite != False:
            args.append(('DenyWrite', self.DenyWrite))
        if self.DenyRead != False:
            args.append(('DenyRead', self.DenyRead))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
    
    @classmethod
    def all(cls) -> Self:
        return cls(IsVersion=True, IsDivInfo=True, IsDivInfoVhl=True, DenyFormat=True, DenyWrite=True, DenyRead=True)
    
    @classmethod
    def all_except(cls, *, IsVersion: Optional[Literal[False]] = None, IsDivInfo: Optional[Literal[False]] = None, IsDivInfoVhl: Optional[Literal[False]] = None, DenyFormat: Optional[Literal[False]] = None, DenyWrite: Optional[Literal[False]] = None, DenyRead: Optional[Literal[False]] = None) -> Self:
        true_fields = [name for name, value in [('IsVersion', IsVersion), ('IsDivInfo', IsDivInfo), ('IsDivInfoVhl', IsDivInfoVhl), ('DenyFormat', DenyFormat), ('DenyWrite', DenyWrite), ('DenyRead', DenyRead)] if value is True]  # type: ignore[comparison-overlap]
        if true_fields:
            raise TypeError(f"all_except() only accepts False values, got {', '.join(f'{name}=True' for name in true_fields)}")
        kwargs = {name: False if value is False else True for name, value in [('IsVersion', IsVersion), ('IsDivInfo', IsDivInfo), ('IsDivInfoVhl', IsDivInfoVhl), ('DenyFormat', DenyFormat), ('DenyWrite', DenyWrite), ('DenyRead', DenyRead)]}
        return cls(**kwargs)
class KeyAccessRights_KeySettings_Dict(TypedDict):
    """
    Access rights and key info 
    
    Access rights: By default, all operations are allowed. With this bitmask, however, this key can be locked for certain operations.
    """
    IsVersion: 'NotRequired[bool]'
    IsDivInfo: 'NotRequired[bool]'
    IsDivInfoVhl: 'NotRequired[bool]'
    DenyFormat: 'NotRequired[bool]'
    DenyWrite: 'NotRequired[bool]'
    DenyRead: 'NotRequired[bool]'
class LedBitMask(NamedTuple):
    """
    A bitmask containing the physical LEDs you want to switch.
    """
    LeftLed: 'bool' = False
    RightLed: 'bool' = False
    SingleLed: 'bool' = False
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        if self.LeftLed != False:
            args.append(('LeftLed', self.LeftLed))
        if self.RightLed != False:
            args.append(('RightLed', self.RightLed))
        if self.SingleLed != False:
            args.append(('SingleLed', self.SingleLed))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
    
    @classmethod
    def all(cls) -> Self:
        return cls(LeftLed=True, RightLed=True, SingleLed=True)
    
    @classmethod
    def all_except(cls, *, LeftLed: Optional[Literal[False]] = None, RightLed: Optional[Literal[False]] = None, SingleLed: Optional[Literal[False]] = None) -> Self:
        true_fields = [name for name, value in [('LeftLed', LeftLed), ('RightLed', RightLed), ('SingleLed', SingleLed)] if value is True]  # type: ignore[comparison-overlap]
        if true_fields:
            raise TypeError(f"all_except() only accepts False values, got {', '.join(f'{name}=True' for name in true_fields)}")
        kwargs = {name: False if value is False else True for name, value in [('LeftLed', LeftLed), ('RightLed', RightLed), ('SingleLed', SingleLed)]}
        return cls(**kwargs)
class LedBitMask_Dict(TypedDict):
    """
    A bitmask containing the physical LEDs you want to switch.
    """
    LeftLed: 'NotRequired[bool]'
    RightLed: 'NotRequired[bool]'
    SingleLed: 'NotRequired[bool]'
class LicenseBitMask(NamedTuple):
    """
    License bit mask
    """
    Ble: 'bool' = False
    BleLicRequired: 'bool' = False
    HidOnlyForSE: 'bool' = False
    Hid: 'bool' = False
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        if self.Ble != False:
            args.append(('Ble', self.Ble))
        if self.BleLicRequired != False:
            args.append(('BleLicRequired', self.BleLicRequired))
        if self.HidOnlyForSE != False:
            args.append(('HidOnlyForSE', self.HidOnlyForSE))
        if self.Hid != False:
            args.append(('Hid', self.Hid))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
    
    @classmethod
    def all(cls) -> Self:
        return cls(Ble=True, BleLicRequired=True, HidOnlyForSE=True, Hid=True)
    
    @classmethod
    def all_except(cls, *, Ble: Optional[Literal[False]] = None, BleLicRequired: Optional[Literal[False]] = None, HidOnlyForSE: Optional[Literal[False]] = None, Hid: Optional[Literal[False]] = None) -> Self:
        true_fields = [name for name, value in [('Ble', Ble), ('BleLicRequired', BleLicRequired), ('HidOnlyForSE', HidOnlyForSE), ('Hid', Hid)] if value is True]  # type: ignore[comparison-overlap]
        if true_fields:
            raise TypeError(f"all_except() only accepts False values, got {', '.join(f'{name}=True' for name in true_fields)}")
        kwargs = {name: False if value is False else True for name, value in [('Ble', Ble), ('BleLicRequired', BleLicRequired), ('HidOnlyForSE', HidOnlyForSE), ('Hid', Hid)]}
        return cls(**kwargs)
class LicenseBitMask_Dict(TypedDict):
    """
    License bit mask
    """
    Ble: 'NotRequired[bool]'
    BleLicRequired: 'NotRequired[bool]'
    HidOnlyForSE: 'NotRequired[bool]'
    Hid: 'NotRequired[bool]'
MaxBaudrateIso14443 = Literal["Dri106Dsi106", "Dri212Dsi106", "Dri424Dsi106", "Dri848Dsi106", "Dri106Dsi212", "Dri212Dsi212", "Dri424Dsi212", "Dri848Dsi212", "Dri106Dsi424", "Dri212Dsi424", "Dri424Dsi424", "Dri848Dsi424", "Dri106Dsi848", "Dri212Dsi848", "Dri424Dsi848", "Dri848Dsi848"]
MaxBaudrateIso14443_Parser = LiteralParser[MaxBaudrateIso14443, int](
    name='MaxBaudrateIso14443',
    literal_map={
        'Dri106Dsi106': 0,
        'Dri212Dsi106': 1,
        'Dri424Dsi106': 2,
        'Dri848Dsi106': 3,
        'Dri106Dsi212': 4,
        'Dri212Dsi212': 5,
        'Dri424Dsi212': 6,
        'Dri848Dsi212': 7,
        'Dri106Dsi424': 8,
        'Dri212Dsi424': 9,
        'Dri424Dsi424': 10,
        'Dri848Dsi424': 11,
        'Dri106Dsi848': 12,
        'Dri212Dsi848': 13,
        'Dri424Dsi848': 14,
        'Dri848Dsi848': 15,
    },
)
MessageType = Literal["Card", "AlarmOn", "AlarmOff", "Keyboard", "CardRemoval", "FunctionKey", "Logs"]
MessageType_Parser = LiteralParser[MessageType, int](
    name='MessageType',
    literal_map={
        'Card': 0,
        'AlarmOn': 1,
        'AlarmOff': 2,
        'Keyboard': 3,
        'CardRemoval': 4,
        'FunctionKey': 5,
        'Logs': 6,
    },
)
Mif_AuthE2Extended_AuthLevel = Literal["AesSl1", "AesSl3", "Mifare"]
Mif_AuthE2Extended_AuthLevel_Parser = LiteralParser[Mif_AuthE2Extended_AuthLevel, int](
    name='Mif_AuthE2Extended_AuthLevel',
    literal_map={
        'AesSl1': 0,
        'AesSl3': 2,
        'Mifare': 3,
    },
)
Mif_AuthE2_AuthMode = Literal["KeyA", "KeyB"]
Mif_AuthE2_AuthMode_Parser = LiteralParser[Mif_AuthE2_AuthMode, int](
    name='Mif_AuthE2_AuthMode',
    literal_map={
        'KeyA': 96,
        'KeyB': 97,
    },
)
Mif_AuthUserExtended_AuthLevel = Literal["AesSl1", "AesSl3", "Mifare"]
Mif_AuthUserExtended_AuthLevel_Parser = LiteralParser[Mif_AuthUserExtended_AuthLevel, int](
    name='Mif_AuthUserExtended_AuthLevel',
    literal_map={
        'AesSl1': 0,
        'AesSl3': 2,
        'Mifare': 3,
    },
)
Mif_AuthUser_AuthMode = Literal["KeyA", "KeyB"]
Mif_AuthUser_AuthMode_Parser = LiteralParser[Mif_AuthUser_AuthMode, int](
    name='Mif_AuthUser_AuthMode',
    literal_map={
        'KeyA': 96,
        'KeyB': 97,
    },
)
Mif_ChangeValueBackup_Mode = Literal["Decrement", "Increment", "Restore"]
Mif_ChangeValueBackup_Mode_Parser = LiteralParser[Mif_ChangeValueBackup_Mode, int](
    name='Mif_ChangeValueBackup_Mode',
    literal_map={
        'Decrement': 0,
        'Increment': 1,
        'Restore': 2,
    },
)
Mif_ChangeValue_Mode = Literal["Decrement", "Increment", "Restore"]
Mif_ChangeValue_Mode_Parser = LiteralParser[Mif_ChangeValue_Mode, int](
    name='Mif_ChangeValue_Mode',
    literal_map={
        'Decrement': 0,
        'Increment': 1,
        'Restore': 2,
    },
)
class Mif_SectorSwitch_SectorSpec_Entry(NamedTuple):
    BlockAddress: 'int'
    SectorKeyIdx: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('BlockAddress', self.BlockAddress))
        args.append(('SectorKeyIdx', self.SectorKeyIdx))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
Mif_SetFraming_CommMode = Literal["MifareNative", "MifareISO"]
Mif_SetFraming_CommMode_Parser = LiteralParser[Mif_SetFraming_CommMode, int](
    name='Mif_SetFraming_CommMode',
    literal_map={
        'MifareNative': 1,
        'MifareISO': 2,
    },
)
Mif_ValueSL3_Cmd = Literal["Increment", "Decrement", "Transfer", "IncrementTransfer", "DecrementTransfer", "Restore"]
Mif_ValueSL3_Cmd_Parser = LiteralParser[Mif_ValueSL3_Cmd, int](
    name='Mif_ValueSL3_Cmd',
    literal_map={
        'Increment': 0,
        'Decrement': 1,
        'Transfer': 2,
        'IncrementTransfer': 3,
        'DecrementTransfer': 4,
        'Restore': 5,
    },
)
Mif_VirtualCardSelect_FciType = Literal["RawData", "UidAndCardType", "UidCardTypeAndMemSize"]
Mif_VirtualCardSelect_FciType_Parser = LiteralParser[Mif_VirtualCardSelect_FciType, int](
    name='Mif_VirtualCardSelect_FciType',
    literal_map={
        'RawData': 0,
        'UidAndCardType': 1,
        'UidCardTypeAndMemSize': 2,
    },
)
class MifareClassicVhlKeyAssignment(NamedTuple):
    """
    This bitmask can be combined with a reference to a key index in the readers keylist and specifies more details.
    """
    Secure: 'bool' = False
    KeyB: 'bool' = False
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        if self.Secure != False:
            args.append(('Secure', self.Secure))
        if self.KeyB != False:
            args.append(('KeyB', self.KeyB))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
    
    @classmethod
    def all(cls) -> Self:
        return cls(Secure=True, KeyB=True)
    
    @classmethod
    def all_except(cls, *, Secure: Optional[Literal[False]] = None, KeyB: Optional[Literal[False]] = None) -> Self:
        true_fields = [name for name, value in [('Secure', Secure), ('KeyB', KeyB)] if value is True]  # type: ignore[comparison-overlap]
        if true_fields:
            raise TypeError(f"all_except() only accepts False values, got {', '.join(f'{name}=True' for name in true_fields)}")
        kwargs = {name: False if value is False else True for name, value in [('Secure', Secure), ('KeyB', KeyB)]}
        return cls(**kwargs)
class MifareClassicVhlKeyAssignment_Dict(TypedDict):
    """
    This bitmask can be combined with a reference to a key index in the readers keylist and specifies more details.
    """
    Secure: 'NotRequired[bool]'
    KeyB: 'NotRequired[bool]'
MifarePlusKeyMemoryType = Literal["CryptoKey", "SamKey", "ReaderChipKey", "VhlKey"]
MifarePlusKeyMemoryType_Parser = LiteralParser[MifarePlusKeyMemoryType, int](
    name='MifarePlusKeyMemoryType',
    literal_map={
        'CryptoKey': 0,
        'SamKey': 1,
        'ReaderChipKey': 2,
        'VhlKey': 3,
    },
)
MobileId_Enable_Mode = Literal["Disable", "Enable"]
MobileId_Enable_Mode_Parser = LiteralParser[MobileId_Enable_Mode, int](
    name='MobileId_Enable_Mode',
    literal_map={
        'Disable': 0,
        'Enable': 1,
    },
)
Parity = Literal["None", "Even", "Odd"]
Parity_Parser = LiteralParser[Parity, int](
    name='Parity',
    literal_map={
        'None': 78,
        'Even': 69,
        'Odd': 79,
    },
)
Project_LegicKeySettings_Index_DiversificationMode = Literal["NoDiversification", "ModeAv2"]
Project_LegicKeySettings_Index_DiversificationMode_Parser = LiteralParser[Project_LegicKeySettings_Index_DiversificationMode, int](
    name='Project_LegicKeySettings_Index_DiversificationMode',
    literal_map={
        'NoDiversification': 0,
        'ModeAv2': 2,
    },
)
Project_LegicKeySettings_Index_KeyType = Literal["DES", "TripleDES", "ThreeKeyTripleDES", "AES"]
Project_LegicKeySettings_Index_KeyType_Parser = LiteralParser[Project_LegicKeySettings_Index_KeyType, int](
    name='Project_LegicKeySettings_Index_KeyType',
    literal_map={
        'DES': 1,
        'TripleDES': 2,
        'ThreeKeyTripleDES': 3,
        'AES': 4,
    },
)
Project_LegicVcp_Status_Context = Literal["General", "LoadParse", "GetTag", "AcceptTag"]
Project_LegicVcp_Status_Context_Parser = LiteralParser[Project_LegicVcp_Status_Context, int](
    name='Project_LegicVcp_Status_Context',
    literal_map={
        'General': 0,
        'LoadParse': 1,
        'GetTag': 2,
        'AcceptTag': 3,
    },
)
Project_LegicVcp_Status_StatusCode = Literal["Ok", "GeneralError", "WrongParameter", "InvalidMac", "WrongTag"]
Project_LegicVcp_Status_StatusCode_Parser = LiteralParser[Project_LegicVcp_Status_StatusCode, int](
    name='Project_LegicVcp_Status_StatusCode',
    literal_map={
        'Ok': 0,
        'GeneralError': 1,
        'WrongParameter': 3,
        'InvalidMac': 19,
        'WrongTag': 20,
    },
)
Project_MobileId_AdvertisementFilter_Value = Literal["Disabled", "Enabled"]
Project_MobileId_AdvertisementFilter_Value_Parser = LiteralParser[Project_MobileId_AdvertisementFilter_Value, int](
    name='Project_MobileId_AdvertisementFilter_Value',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
    },
)
Project_MobileId_ConvenientAccess_Value = Literal["Disabled", "Enabled"]
Project_MobileId_ConvenientAccess_Value_Parser = LiteralParser[Project_MobileId_ConvenientAccess_Value, int](
    name='Project_MobileId_ConvenientAccess_Value',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
    },
)
Project_MobileId_DetectionRssiFilter_Value = Literal["Disabled", "Enabled"]
Project_MobileId_DetectionRssiFilter_Value_Parser = LiteralParser[Project_MobileId_DetectionRssiFilter_Value, int](
    name='Project_MobileId_DetectionRssiFilter_Value',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
    },
)
Project_MobileId_Mode_Value = Literal["Disabled", "Enabled"]
Project_MobileId_Mode_Value_Parser = LiteralParser[Project_MobileId_Mode_Value, int](
    name='Project_MobileId_Mode_Value',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
    },
)
Project_MobileId_TriggerFromDistance_Value = Literal["Disabled", "Enabled"]
Project_MobileId_TriggerFromDistance_Value_Parser = LiteralParser[Project_MobileId_TriggerFromDistance_Value, int](
    name='Project_MobileId_TriggerFromDistance_Value',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
    },
)
Project_SamAVxKeySettings_Index_DiversificationMode = Literal["NoDiversification", "ModeAv1", "ModeAv2", "ModeAv1Des1Round"]
Project_SamAVxKeySettings_Index_DiversificationMode_Parser = LiteralParser[Project_SamAVxKeySettings_Index_DiversificationMode, int](
    name='Project_SamAVxKeySettings_Index_DiversificationMode',
    literal_map={
        'NoDiversification': 0,
        'ModeAv1': 1,
        'ModeAv2': 2,
        'ModeAv1Des1Round': 17,
    },
)
class Project_SamAVxKeySettings_Index_KeySettingsList_Entry(NamedTuple):
    """
    This value consists of a list (array) with a maximum of 3 entries (for SamKey A / B / C). 8-bit key indexes refer automatically to entry 0, the MSB of a 16-bit key index refers to entry 0..2.
    """
    KeyVersion: 'int'
    DiversificationMode: 'DiversificationMode'
    DivIdx: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('KeyVersion', self.KeyVersion))
        args.append(('DiversificationMode', self.DiversificationMode))
        args.append(('DivIdx', self.DivIdx))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
DiversificationMode = Literal["NoDiversification", "ModeAv1", "ModeAv2", "ModeAv1Des1Round"]
DiversificationMode_Parser = LiteralParser[DiversificationMode, int](
    name='DiversificationMode',
    literal_map={
        'NoDiversification': 0,
        'ModeAv1': 1,
        'ModeAv2': 2,
        'ModeAv1Des1Round': 17,
    },
)
Project_SamAVx_AnswerToReset_LID = Literal["AV2", "HID", "Gen1", "Gen2"]
Project_SamAVx_AnswerToReset_LID_Parser = LiteralParser[Project_SamAVx_AnswerToReset_LID, int](
    name='Project_SamAVx_AnswerToReset_LID',
    literal_map={
        'AV2': 0,
        'HID': 1,
        'Gen1': 16,
        'Gen2': 17,
    },
)
Project_SamAVx_PowerUpState_Value = Literal["Idle", "Powered", "Force"]
Project_SamAVx_PowerUpState_Value_Parser = LiteralParser[Project_SamAVx_PowerUpState_Value, int](
    name='Project_SamAVx_PowerUpState_Value',
    literal_map={
        'Idle': 0,
        'Powered': 1,
        'Force': 2,
    },
)
Project_SamAVx_SecureMessaging_Value = Literal["Plain", "Mac", "Encrypted"]
Project_SamAVx_SecureMessaging_Value_Parser = LiteralParser[Project_SamAVx_SecureMessaging_Value, int](
    name='Project_SamAVx_SecureMessaging_Value',
    literal_map={
        'Plain': 0,
        'Mac': 1,
        'Encrypted': 2,
    },
)
Project_VhlSettings125Khz_AwidSerialNrFormat_Value = Literal["BaltechStandard", "MXCompatible"]
Project_VhlSettings125Khz_AwidSerialNrFormat_Value_Parser = LiteralParser[Project_VhlSettings125Khz_AwidSerialNrFormat_Value, int](
    name='Project_VhlSettings125Khz_AwidSerialNrFormat_Value',
    literal_map={
        'BaltechStandard': 0,
        'MXCompatible': 1,
    },
)
Project_VhlSettings125Khz_BaudRate_Baud = Literal["Baud32", "Baud64"]
Project_VhlSettings125Khz_BaudRate_Baud_Parser = LiteralParser[Project_VhlSettings125Khz_BaudRate_Baud, int](
    name='Project_VhlSettings125Khz_BaudRate_Baud',
    literal_map={
        'Baud32': 32,
        'Baud64': 64,
    },
)
Project_VhlSettings125Khz_EM4100SerialNrFormat_Value = Literal["BaltechStandard", "MXCompatible"]
Project_VhlSettings125Khz_EM4100SerialNrFormat_Value_Parser = LiteralParser[Project_VhlSettings125Khz_EM4100SerialNrFormat_Value, int](
    name='Project_VhlSettings125Khz_EM4100SerialNrFormat_Value',
    literal_map={
        'BaltechStandard': 0,
        'MXCompatible': 1,
    },
)
Project_VhlSettings125Khz_HidProxSerialNrFormat_Value = Literal["NoConversion", "WithParityBits", "McmCompatible", "CardNumberRightAdjusted", "CardNumberLeftAdjusted"]
Project_VhlSettings125Khz_HidProxSerialNrFormat_Value_Parser = LiteralParser[Project_VhlSettings125Khz_HidProxSerialNrFormat_Value, int](
    name='Project_VhlSettings125Khz_HidProxSerialNrFormat_Value',
    literal_map={
        'NoConversion': 0,
        'WithParityBits': 1,
        'McmCompatible': 2,
        'CardNumberRightAdjusted': 3,
        'CardNumberLeftAdjusted': 4,
    },
)
Project_VhlSettings125Khz_IndaspParityCheck_ParityDisable = Literal["Enable", "Disable"]
Project_VhlSettings125Khz_IndaspParityCheck_ParityDisable_Parser = LiteralParser[Project_VhlSettings125Khz_IndaspParityCheck_ParityDisable, int](
    name='Project_VhlSettings125Khz_IndaspParityCheck_ParityDisable',
    literal_map={
        'Enable': 0,
        'Disable': 1,
    },
)
Project_VhlSettings125Khz_IoProxSerialNrFormat_Value = Literal["BaltechStandard", "MXCompatible"]
Project_VhlSettings125Khz_IoProxSerialNrFormat_Value_Parser = LiteralParser[Project_VhlSettings125Khz_IoProxSerialNrFormat_Value, int](
    name='Project_VhlSettings125Khz_IoProxSerialNrFormat_Value',
    literal_map={
        'BaltechStandard': 0,
        'MXCompatible': 1,
    },
)
Project_VhlSettings125Khz_ModType_Mod = Literal["ModManchester", "ModBiphase", "ModNRZ", "ModHID"]
Project_VhlSettings125Khz_ModType_Mod_Parser = LiteralParser[Project_VhlSettings125Khz_ModType_Mod, int](
    name='Project_VhlSettings125Khz_ModType_Mod',
    literal_map={
        'ModManchester': 16,
        'ModBiphase': 32,
        'ModNRZ': 48,
        'ModHID': 80,
    },
)
Project_VhlSettings125Khz_ObidCardIdFormat_Value = Literal["Legacy", "Raw", "UnpackedVarLen"]
Project_VhlSettings125Khz_ObidCardIdFormat_Value_Parser = LiteralParser[Project_VhlSettings125Khz_ObidCardIdFormat_Value, int](
    name='Project_VhlSettings125Khz_ObidCardIdFormat_Value',
    literal_map={
        'Legacy': 0,
        'Raw': 1,
        'UnpackedVarLen': 2,
    },
)
Project_VhlSettings125Khz_PyramidSerialNrFormat_Value = Literal["BaltechStandard", "MXCompatible"]
Project_VhlSettings125Khz_PyramidSerialNrFormat_Value_Parser = LiteralParser[Project_VhlSettings125Khz_PyramidSerialNrFormat_Value, int](
    name='Project_VhlSettings125Khz_PyramidSerialNrFormat_Value',
    literal_map={
        'BaltechStandard': 0,
        'MXCompatible': 1,
    },
)
Project_VhlSettings125Khz_TTFBaudrate_TTFBaud = Literal["Baud32", "Baud64"]
Project_VhlSettings125Khz_TTFBaudrate_TTFBaud_Parser = LiteralParser[Project_VhlSettings125Khz_TTFBaudrate_TTFBaud, int](
    name='Project_VhlSettings125Khz_TTFBaudrate_TTFBaud',
    literal_map={
        'Baud32': 32,
        'Baud64': 64,
    },
)
Project_VhlSettings125Khz_TTFModType_TTFMod = Literal["ModManchester", "ModBiphase", "ModNRZ", "ModHID"]
Project_VhlSettings125Khz_TTFModType_TTFMod_Parser = LiteralParser[Project_VhlSettings125Khz_TTFModType_TTFMod, int](
    name='Project_VhlSettings125Khz_TTFModType_TTFMod',
    literal_map={
        'ModManchester': 16,
        'ModBiphase': 32,
        'ModNRZ': 48,
        'ModHID': 80,
    },
)
Project_VhlSettings_ForceReselect_Value = Literal["False", "True"]
Project_VhlSettings_ForceReselect_Value_Parser = LiteralParser[Project_VhlSettings_ForceReselect_Value, int](
    name='Project_VhlSettings_ForceReselect_Value',
    literal_map={
        'False': 0,
        'True': 1,
    },
)
ProtType = Literal["NoISO14443L4Support", "ISO14443L4Support", "undefined"]
ProtType_Parser = LiteralParser[ProtType, int](
    name='ProtType',
    literal_map={
        'NoISO14443L4Support': 0,
        'ISO14443L4Support': 1,
        'undefined': -1,
    },
    undefined_literal='undefined',
)
ProtocolID = Literal["All", "BrpSerial", "BrpRs485", "BrpHid", "BrpTcp", "DebugInterface", "RawSerial", "Wiegand", "KeyboardEmulation", "LowLevelIoPorts", "ClkData", "Omron", "Snet", "Bpa9", "LBus", "Ccid", "RawSerial2", "Osdp", "BleHci", "HttpsClient"]
ProtocolID_Parser = LiteralParser[ProtocolID, int](
    name='ProtocolID',
    literal_map={
        'All': 0,
        'BrpSerial': 3,
        'BrpRs485': 4,
        'BrpHid': 5,
        'BrpTcp': 134,
        'DebugInterface': 9,
        'RawSerial': 35,
        'Wiegand': 32,
        'KeyboardEmulation': 43,
        'LowLevelIoPorts': 36,
        'ClkData': 34,
        'Omron': 33,
        'Snet': 16,
        'Bpa9': 17,
        'LBus': 50,
        'Ccid': 54,
        'RawSerial2': 55,
        'Osdp': 56,
        'BleHci': 59,
        'HttpsClient': 40,
    },
)
Protocols_Ccid_LedControl_Value = Literal["Disabled", "Enabled"]
Protocols_Ccid_LedControl_Value_Parser = LiteralParser[Protocols_Ccid_LedControl_Value, int](
    name='Protocols_Ccid_LedControl_Value',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
    },
)
Protocols_KeyboardEmulation_RegisterInterface_Value = Literal["AutoDetect", "Disabled", "Enabled"]
Protocols_KeyboardEmulation_RegisterInterface_Value_Parser = LiteralParser[Protocols_KeyboardEmulation_RegisterInterface_Value, int](
    name='Protocols_KeyboardEmulation_RegisterInterface_Value',
    literal_map={
        'AutoDetect': 0,
        'Disabled': 1,
        'Enabled': 2,
    },
)
class Protocols_KeyboardEmulation_ScancodesMap_Value_Entry(NamedTuple):
    AsciiCode: 'int'
    ScanCode: 'int'
    Shift: 'bool'
    Ctrl: 'bool'
    AltGr: 'bool'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('AsciiCode', self.AsciiCode))
        args.append(('ScanCode', self.ScanCode))
        args.append(('Shift', self.Shift))
        args.append(('Ctrl', self.Ctrl))
        args.append(('AltGr', self.AltGr))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
Protocols_KeyboardEmulation_UsbInterfaceOrder_Value = Literal["First", "Second"]
Protocols_KeyboardEmulation_UsbInterfaceOrder_Value_Parser = LiteralParser[Protocols_KeyboardEmulation_UsbInterfaceOrder_Value, int](
    name='Protocols_KeyboardEmulation_UsbInterfaceOrder_Value',
    literal_map={
        'First': 0,
        'Second': 1,
    },
)
Protocols_KeyboardEmulation_UsbInterfaceSubClass_Value = Literal["NoBoot", "Boot"]
Protocols_KeyboardEmulation_UsbInterfaceSubClass_Value_Parser = LiteralParser[Protocols_KeyboardEmulation_UsbInterfaceSubClass_Value, int](
    name='Protocols_KeyboardEmulation_UsbInterfaceSubClass_Value',
    literal_map={
        'NoBoot': 0,
        'Boot': 1,
    },
)
Protocols_MagstripeEmulation_Encoding_Value = Literal["Numeric", "Alphanumeric"]
Protocols_MagstripeEmulation_Encoding_Value_Parser = LiteralParser[Protocols_MagstripeEmulation_Encoding_Value, int](
    name='Protocols_MagstripeEmulation_Encoding_Value',
    literal_map={
        'Numeric': 4,
        'Alphanumeric': 6,
    },
)
Protocols_Network_DhcpMode_Value = Literal["Disabled", "Enabled", "Auto"]
Protocols_Network_DhcpMode_Value_Parser = LiteralParser[Protocols_Network_DhcpMode_Value, int](
    name='Protocols_Network_DhcpMode_Value',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
        'Auto': 2,
    },
)
Protocols_Osdp_DataMode_Value = Literal["Ascii", "BitstreamRaw", "BitstreamWiegand"]
Protocols_Osdp_DataMode_Value_Parser = LiteralParser[Protocols_Osdp_DataMode_Value, int](
    name='Protocols_Osdp_DataMode_Value',
    literal_map={
        'Ascii': 0,
        'BitstreamRaw': 1,
        'BitstreamWiegand': 2,
    },
)
Protocols_Osdp_SCBKeyDefault_DiversifyFlag = Literal["IsAlreadyDiversified", "WillBeDiversified"]
Protocols_Osdp_SCBKeyDefault_DiversifyFlag_Parser = LiteralParser[Protocols_Osdp_SCBKeyDefault_DiversifyFlag, int](
    name='Protocols_Osdp_SCBKeyDefault_DiversifyFlag',
    literal_map={
        'IsAlreadyDiversified': 0,
        'WillBeDiversified': 1,
    },
)
Protocols_Osdp_SCBKey_DiversifyFlag = Literal["IsAlreadyDiversified", "WillBeDiversified"]
Protocols_Osdp_SCBKey_DiversifyFlag_Parser = LiteralParser[Protocols_Osdp_SCBKey_DiversifyFlag, int](
    name='Protocols_Osdp_SCBKey_DiversifyFlag',
    literal_map={
        'IsAlreadyDiversified': 0,
        'WillBeDiversified': 1,
    },
)
Protocols_Osdp_SecureInstallMode_Value = Literal["Insecure", "Install", "Secure", "SecureInstall", "V1"]
Protocols_Osdp_SecureInstallMode_Value_Parser = LiteralParser[Protocols_Osdp_SecureInstallMode_Value, int](
    name='Protocols_Osdp_SecureInstallMode_Value',
    literal_map={
        'Insecure': 0,
        'Install': 1,
        'Secure': 2,
        'SecureInstall': 3,
        'V1': 4,
    },
)
Protocols_RawSerial_Channel_Value = Literal["Channel0", "Channel1"]
Protocols_RawSerial_Channel_Value_Parser = LiteralParser[Protocols_RawSerial_Channel_Value, int](
    name='Protocols_RawSerial_Channel_Value',
    literal_map={
        'Channel0': 0,
        'Channel1': 1,
    },
)
Protocols_SNet_DeviceType_Value = Literal["Mkr", "DkrKeyPinMode", "DkrStandardMode"]
Protocols_SNet_DeviceType_Value_Parser = LiteralParser[Protocols_SNet_DeviceType_Value, int](
    name='Protocols_SNet_DeviceType_Value',
    literal_map={
        'Mkr': 0,
        'DkrKeyPinMode': 1,
        'DkrStandardMode': 2,
    },
)
Protocols_Wiegand_BitOrder_Value = Literal["LsbFirst", "MsbFirst"]
Protocols_Wiegand_BitOrder_Value_Parser = LiteralParser[Protocols_Wiegand_BitOrder_Value, int](
    name='Protocols_Wiegand_BitOrder_Value',
    literal_map={
        'LsbFirst': 255,
        'MsbFirst': 0,
    },
)
Protocols_Wiegand_Mode_Value = Literal["Standard", "Raw"]
Protocols_Wiegand_Mode_Value_Parser = LiteralParser[Protocols_Wiegand_Mode_Value, int](
    name='Protocols_Wiegand_Mode_Value',
    literal_map={
        'Standard': 0,
        'Raw': 1,
    },
)
Protocols_Wiegand_PinMessageFormat_Value = Literal["MultiDigit", "SingleDigit", "SingleDigitWithBcc", "SingleDigitWithSwappedBcc", "SingleDigit4Bit"]
Protocols_Wiegand_PinMessageFormat_Value_Parser = LiteralParser[Protocols_Wiegand_PinMessageFormat_Value, int](
    name='Protocols_Wiegand_PinMessageFormat_Value',
    literal_map={
        'MultiDigit': 0,
        'SingleDigit': 1,
        'SingleDigitWithBcc': 2,
        'SingleDigitWithSwappedBcc': 3,
        'SingleDigit4Bit': 4,
    },
)
class RunSequenceCmd(NamedTuple):
    CmdCode: 'RunSequenceCmd_CmdCode'
    RepeatCnt: 'Optional[int]' = None
    Param: 'Optional[int]' = None
    SwitchIoPort: 'Optional[IoPort]' = None
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('CmdCode', self.CmdCode))
        if self.RepeatCnt != None:
            args.append(('RepeatCnt', self.RepeatCnt))
        if self.Param != None:
            args.append(('Param', self.Param))
        if self.SwitchIoPort != None:
            args.append(('SwitchIoPort', self.SwitchIoPort))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class RunSequenceCmd_Dict(TypedDict):
    CmdCode: 'RunSequenceCmd_CmdCode'
    RepeatCnt: 'NotRequired[int]'
    Param: 'NotRequired[int]'
    SwitchIoPort: 'NotRequired[IoPort]'
RunSequenceCmd_CmdCode = Literal["EnablePort", "DisablePort", "RepeatLoop", "WaitMs", "WaitSec", "EndOfSequence", "StartLoop", "OnStop", "EnablePortGreenLed", "EnablePortRedLed", "EnablePortBeeper", "EnablePortRelay", "EnablePortBlue", "DisablePortGreenLed", "DisablePortRedLed", "DisablePortBeeper", "DisablePortRelay", "DisablePortBlue", "InvertPortGreenLed", "InvertPortRedLed", "InvertPortBeeper", "InvertPortRelay", "InvertPortBlue", "Repeat1Times", "RepeatLoop2Times", "RepeatLoop3Times", "RepeatLoop4Times", "RepeatLoop5Times", "RepeatLoop6Times", "RepeatLoop7Times", "RepeatLoop8Times", "RepeatLoop9Times", "RepeatLoop10Times", "RepeatLoop11Times", "RepeatLoop12Times", "RepeatLoop13Times", "RepeatLoop14Times", "RepeatLoop15Times", "Wait100Ms", "Wait200Ms", "Wait300Ms", "Wait400Ms", "Wait500Ms", "Wait600Ms", "Wait700Ms", "Wait800Ms", "Wait900Ms", "Wait1000Ms", "Wait1100Ms", "Wait1200Ms", "Wait1300Ms", "Wait1400Ms", "Wait1500Ms", "Wait1600Ms", "Wait1700Ms", "Wait1800Ms", "Wait1900Ms", "Wait2000Ms", "Wait2100Ms", "Wait2200Ms", "Wait2300Ms", "Wait2400Ms", "Wait2500Ms", "Wait2600Ms", "Wait2700Ms", "Wait2800Ms", "Wait2900Ms", "Wait3000Ms", "Wait3100Ms", "Wait3200Ms", "Wait3300Ms", "Wait3400Ms", "Wait3500Ms", "Wait3600Ms", "Wait3700Ms", "Wait3800Ms", "Wait3900Ms", "Wait4000Ms", "Wait4100Ms", "Wait4200Ms", "Wait4300Ms", "Wait4400Ms", "Wait4500Ms", "Wait4600Ms", "Wait4700Ms", "Wait4800Ms", "Wait4900Ms", "Wait5000Ms", "Wait5100Ms", "Wait5200Ms", "Wait5300Ms", "Wait5400Ms", "Wait5500Ms", "Wait5600Ms", "Wait5700Ms", "Wait5800Ms", "Wait5900Ms", "Wait6000Ms", "Wait6100Ms", "Wait6200Ms", "Wait6300Ms"]
RunSequenceCmd_CmdCode_Parser = LiteralParser[RunSequenceCmd_CmdCode, int](
    name='RunSequenceCmd_CmdCode',
    literal_map={
        'EnablePort': 1,
        'DisablePort': 2,
        'RepeatLoop': 5,
        'WaitMs': 8,
        'WaitSec': 9,
        'EndOfSequence': 241,
        'StartLoop': 242,
        'OnStop': 243,
        'EnablePortGreenLed': 16,
        'EnablePortRedLed': 17,
        'EnablePortBeeper': 18,
        'EnablePortRelay': 19,
        'EnablePortBlue': 22,
        'DisablePortGreenLed': 32,
        'DisablePortRedLed': 33,
        'DisablePortBeeper': 34,
        'DisablePortRelay': 35,
        'DisablePortBlue': 38,
        'InvertPortGreenLed': 48,
        'InvertPortRedLed': 49,
        'InvertPortBeeper': 50,
        'InvertPortRelay': 51,
        'InvertPortBlue': 54,
        'Repeat1Times': 81,
        'RepeatLoop2Times': 82,
        'RepeatLoop3Times': 83,
        'RepeatLoop4Times': 84,
        'RepeatLoop5Times': 85,
        'RepeatLoop6Times': 86,
        'RepeatLoop7Times': 87,
        'RepeatLoop8Times': 88,
        'RepeatLoop9Times': 89,
        'RepeatLoop10Times': 90,
        'RepeatLoop11Times': 91,
        'RepeatLoop12Times': 92,
        'RepeatLoop13Times': 93,
        'RepeatLoop14Times': 94,
        'RepeatLoop15Times': 95,
        'Wait100Ms': 129,
        'Wait200Ms': 130,
        'Wait300Ms': 131,
        'Wait400Ms': 132,
        'Wait500Ms': 133,
        'Wait600Ms': 134,
        'Wait700Ms': 135,
        'Wait800Ms': 136,
        'Wait900Ms': 137,
        'Wait1000Ms': 138,
        'Wait1100Ms': 139,
        'Wait1200Ms': 140,
        'Wait1300Ms': 141,
        'Wait1400Ms': 142,
        'Wait1500Ms': 143,
        'Wait1600Ms': 144,
        'Wait1700Ms': 145,
        'Wait1800Ms': 146,
        'Wait1900Ms': 147,
        'Wait2000Ms': 148,
        'Wait2100Ms': 149,
        'Wait2200Ms': 150,
        'Wait2300Ms': 151,
        'Wait2400Ms': 152,
        'Wait2500Ms': 153,
        'Wait2600Ms': 154,
        'Wait2700Ms': 155,
        'Wait2800Ms': 156,
        'Wait2900Ms': 157,
        'Wait3000Ms': 158,
        'Wait3100Ms': 159,
        'Wait3200Ms': 160,
        'Wait3300Ms': 161,
        'Wait3400Ms': 162,
        'Wait3500Ms': 163,
        'Wait3600Ms': 164,
        'Wait3700Ms': 165,
        'Wait3800Ms': 166,
        'Wait3900Ms': 167,
        'Wait4000Ms': 168,
        'Wait4100Ms': 169,
        'Wait4200Ms': 170,
        'Wait4300Ms': 171,
        'Wait4400Ms': 172,
        'Wait4500Ms': 173,
        'Wait4600Ms': 174,
        'Wait4700Ms': 175,
        'Wait4800Ms': 176,
        'Wait4900Ms': 177,
        'Wait5000Ms': 178,
        'Wait5100Ms': 179,
        'Wait5200Ms': 180,
        'Wait5300Ms': 181,
        'Wait5400Ms': 182,
        'Wait5500Ms': 183,
        'Wait5600Ms': 184,
        'Wait5700Ms': 185,
        'Wait5800Ms': 186,
        'Wait5900Ms': 187,
        'Wait6000Ms': 188,
        'Wait6100Ms': 189,
        'Wait6200Ms': 190,
        'Wait6300Ms': 191,
    },
)
SFGI = Literal["Us302", "Us604", "Us1208", "Us2416", "Us4832", "Us9664", "Ms19", "Ms39", "Ms77", "Ms155", "Ms309", "Ms618", "Ms1237", "Ms2474", "Ms4948"]
SFGI_Parser = LiteralParser[SFGI, int](
    name='SFGI',
    literal_map={
        'Us302': 0,
        'Us604': 1,
        'Us1208': 2,
        'Us2416': 3,
        'Us4832': 4,
        'Us9664': 5,
        'Ms19': 6,
        'Ms39': 7,
        'Ms77': 8,
        'Ms155': 9,
        'Ms309': 10,
        'Ms618': 11,
        'Ms1237': 12,
        'Ms2474': 13,
        'Ms4948': 14,
    },
)
class SegmentIdentificationAndAddressing(NamedTuple):
    """
    This byte defines how a Legic segment shall be accessed. 
    
    There are two possibilities to select a certain segment on a Legic card: 
    
      * ID: The reader selects the segment with the desired number. 
      * Stamp: The reader selects the first segment that matches the desired stamp. 
    
    
    
    **If possible always stamp search should be used for segment identification to guarantee that only genuine cards are processed!**
    
    Legic advant compatible readers support two addressing modes: 
    
      * Protocol Header: Stamp data (read-only) can be accessed starting with address 18 (data below address 18 is undefined). Application data follows directly after the stamp. 
      * Advant: Application data stored in S_DATA can be accessed starting with address 0. Stamp data is not accessible in this case.
    """
    AdvantAddressMode: 'bool' = False
    StampSearch: 'bool' = False
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        if self.AdvantAddressMode != False:
            args.append(('AdvantAddressMode', self.AdvantAddressMode))
        if self.StampSearch != False:
            args.append(('StampSearch', self.StampSearch))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
    
    @classmethod
    def all(cls) -> Self:
        return cls(AdvantAddressMode=True, StampSearch=True)
    
    @classmethod
    def all_except(cls, *, AdvantAddressMode: Optional[Literal[False]] = None, StampSearch: Optional[Literal[False]] = None) -> Self:
        true_fields = [name for name, value in [('AdvantAddressMode', AdvantAddressMode), ('StampSearch', StampSearch)] if value is True]  # type: ignore[comparison-overlap]
        if true_fields:
            raise TypeError(f"all_except() only accepts False values, got {', '.join(f'{name}=True' for name in true_fields)}")
        kwargs = {name: False if value is False else True for name, value in [('AdvantAddressMode', AdvantAddressMode), ('StampSearch', StampSearch)]}
        return cls(**kwargs)
class SegmentIdentificationAndAddressing_Dict(TypedDict):
    """
    This byte defines how a Legic segment shall be accessed. 
    
    There are two possibilities to select a certain segment on a Legic card: 
    
      * ID: The reader selects the segment with the desired number. 
      * Stamp: The reader selects the first segment that matches the desired stamp. 
    
    
    
    **If possible always stamp search should be used for segment identification to guarantee that only genuine cards are processed!**
    
    Legic advant compatible readers support two addressing modes: 
    
      * Protocol Header: Stamp data (read-only) can be accessed starting with address 18 (data below address 18 is undefined). Application data follows directly after the stamp. 
      * Advant: Application data stored in S_DATA can be accessed starting with address 0. Stamp data is not accessible in this case.
    """
    AdvantAddressMode: 'NotRequired[bool]'
    StampSearch: 'NotRequired[bool]'
Sys_CfgLoadFinish_FinalizeAction = Literal["CancelCfgLoad", "FinalizeCfgLoadWithoutReboot", "FinalizeCfgLoadWithReboot"]
Sys_CfgLoadFinish_FinalizeAction_Parser = LiteralParser[Sys_CfgLoadFinish_FinalizeAction, int](
    name='Sys_CfgLoadFinish_FinalizeAction',
    literal_map={
        'CancelCfgLoad': 0,
        'FinalizeCfgLoadWithoutReboot': 1,
        'FinalizeCfgLoadWithReboot': 2,
    },
)
class Sys_GetBootStatus_BootStatus(NamedTuple):
    NewerReaderChipFirmware: 'bool' = False
    UnexpectedRebootsLegacy: 'bool' = False
    FactorySettings: 'bool' = False
    ConfigurationInconsistent: 'bool' = False
    FirmwareVersionBlocked: 'bool' = False
    Bluetooth: 'bool' = False
    WiFi: 'bool' = False
    Tamper: 'bool' = False
    BatteryManagement: 'bool' = False
    Keyboard: 'bool' = False
    FirmwareVersionBlockedLegacy: 'bool' = False
    Display: 'bool' = False
    ConfCardPresented: 'bool' = False
    Ethernet: 'bool' = False
    ExtendedLED: 'bool' = False
    Rf125kHz: 'bool' = False
    Rf13MHz: 'bool' = False
    Rf13MHzLegic: 'bool' = False
    Rf13MHzLegacy: 'bool' = False
    HWoptions: 'bool' = False
    RTC: 'bool' = False
    Dataflash: 'bool' = False
    Configuration: 'bool' = False
    CorruptFirmware: 'bool' = False
    IncompleteFirmware: 'bool' = False
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        if self.NewerReaderChipFirmware != False:
            args.append(('NewerReaderChipFirmware', self.NewerReaderChipFirmware))
        if self.UnexpectedRebootsLegacy != False:
            args.append(('UnexpectedRebootsLegacy', self.UnexpectedRebootsLegacy))
        if self.FactorySettings != False:
            args.append(('FactorySettings', self.FactorySettings))
        if self.ConfigurationInconsistent != False:
            args.append(('ConfigurationInconsistent', self.ConfigurationInconsistent))
        if self.FirmwareVersionBlocked != False:
            args.append(('FirmwareVersionBlocked', self.FirmwareVersionBlocked))
        if self.Bluetooth != False:
            args.append(('Bluetooth', self.Bluetooth))
        if self.WiFi != False:
            args.append(('WiFi', self.WiFi))
        if self.Tamper != False:
            args.append(('Tamper', self.Tamper))
        if self.BatteryManagement != False:
            args.append(('BatteryManagement', self.BatteryManagement))
        if self.Keyboard != False:
            args.append(('Keyboard', self.Keyboard))
        if self.FirmwareVersionBlockedLegacy != False:
            args.append(('FirmwareVersionBlockedLegacy', self.FirmwareVersionBlockedLegacy))
        if self.Display != False:
            args.append(('Display', self.Display))
        if self.ConfCardPresented != False:
            args.append(('ConfCardPresented', self.ConfCardPresented))
        if self.Ethernet != False:
            args.append(('Ethernet', self.Ethernet))
        if self.ExtendedLED != False:
            args.append(('ExtendedLED', self.ExtendedLED))
        if self.Rf125kHz != False:
            args.append(('Rf125kHz', self.Rf125kHz))
        if self.Rf13MHz != False:
            args.append(('Rf13MHz', self.Rf13MHz))
        if self.Rf13MHzLegic != False:
            args.append(('Rf13MHzLegic', self.Rf13MHzLegic))
        if self.Rf13MHzLegacy != False:
            args.append(('Rf13MHzLegacy', self.Rf13MHzLegacy))
        if self.HWoptions != False:
            args.append(('HWoptions', self.HWoptions))
        if self.RTC != False:
            args.append(('RTC', self.RTC))
        if self.Dataflash != False:
            args.append(('Dataflash', self.Dataflash))
        if self.Configuration != False:
            args.append(('Configuration', self.Configuration))
        if self.CorruptFirmware != False:
            args.append(('CorruptFirmware', self.CorruptFirmware))
        if self.IncompleteFirmware != False:
            args.append(('IncompleteFirmware', self.IncompleteFirmware))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
    
    @classmethod
    def all(cls) -> Self:
        return cls(NewerReaderChipFirmware=True, UnexpectedRebootsLegacy=True, FactorySettings=True, ConfigurationInconsistent=True, FirmwareVersionBlocked=True, Bluetooth=True, WiFi=True, Tamper=True, BatteryManagement=True, Keyboard=True, FirmwareVersionBlockedLegacy=True, Display=True, ConfCardPresented=True, Ethernet=True, ExtendedLED=True, Rf125kHz=True, Rf13MHz=True, Rf13MHzLegic=True, Rf13MHzLegacy=True, HWoptions=True, RTC=True, Dataflash=True, Configuration=True, CorruptFirmware=True, IncompleteFirmware=True)
    
    @classmethod
    def all_except(cls, *, NewerReaderChipFirmware: Optional[Literal[False]] = None, UnexpectedRebootsLegacy: Optional[Literal[False]] = None, FactorySettings: Optional[Literal[False]] = None, ConfigurationInconsistent: Optional[Literal[False]] = None, FirmwareVersionBlocked: Optional[Literal[False]] = None, Bluetooth: Optional[Literal[False]] = None, WiFi: Optional[Literal[False]] = None, Tamper: Optional[Literal[False]] = None, BatteryManagement: Optional[Literal[False]] = None, Keyboard: Optional[Literal[False]] = None, FirmwareVersionBlockedLegacy: Optional[Literal[False]] = None, Display: Optional[Literal[False]] = None, ConfCardPresented: Optional[Literal[False]] = None, Ethernet: Optional[Literal[False]] = None, ExtendedLED: Optional[Literal[False]] = None, Rf125kHz: Optional[Literal[False]] = None, Rf13MHz: Optional[Literal[False]] = None, Rf13MHzLegic: Optional[Literal[False]] = None, Rf13MHzLegacy: Optional[Literal[False]] = None, HWoptions: Optional[Literal[False]] = None, RTC: Optional[Literal[False]] = None, Dataflash: Optional[Literal[False]] = None, Configuration: Optional[Literal[False]] = None, CorruptFirmware: Optional[Literal[False]] = None, IncompleteFirmware: Optional[Literal[False]] = None) -> Self:
        true_fields = [name for name, value in [('NewerReaderChipFirmware', NewerReaderChipFirmware), ('UnexpectedRebootsLegacy', UnexpectedRebootsLegacy), ('FactorySettings', FactorySettings), ('ConfigurationInconsistent', ConfigurationInconsistent), ('FirmwareVersionBlocked', FirmwareVersionBlocked), ('Bluetooth', Bluetooth), ('WiFi', WiFi), ('Tamper', Tamper), ('BatteryManagement', BatteryManagement), ('Keyboard', Keyboard), ('FirmwareVersionBlockedLegacy', FirmwareVersionBlockedLegacy), ('Display', Display), ('ConfCardPresented', ConfCardPresented), ('Ethernet', Ethernet), ('ExtendedLED', ExtendedLED), ('Rf125kHz', Rf125kHz), ('Rf13MHz', Rf13MHz), ('Rf13MHzLegic', Rf13MHzLegic), ('Rf13MHzLegacy', Rf13MHzLegacy), ('HWoptions', HWoptions), ('RTC', RTC), ('Dataflash', Dataflash), ('Configuration', Configuration), ('CorruptFirmware', CorruptFirmware), ('IncompleteFirmware', IncompleteFirmware)] if value is True]  # type: ignore[comparison-overlap]
        if true_fields:
            raise TypeError(f"all_except() only accepts False values, got {', '.join(f'{name}=True' for name in true_fields)}")
        kwargs = {name: False if value is False else True for name, value in [('NewerReaderChipFirmware', NewerReaderChipFirmware), ('UnexpectedRebootsLegacy', UnexpectedRebootsLegacy), ('FactorySettings', FactorySettings), ('ConfigurationInconsistent', ConfigurationInconsistent), ('FirmwareVersionBlocked', FirmwareVersionBlocked), ('Bluetooth', Bluetooth), ('WiFi', WiFi), ('Tamper', Tamper), ('BatteryManagement', BatteryManagement), ('Keyboard', Keyboard), ('FirmwareVersionBlockedLegacy', FirmwareVersionBlockedLegacy), ('Display', Display), ('ConfCardPresented', ConfCardPresented), ('Ethernet', Ethernet), ('ExtendedLED', ExtendedLED), ('Rf125kHz', Rf125kHz), ('Rf13MHz', Rf13MHz), ('Rf13MHzLegic', Rf13MHzLegic), ('Rf13MHzLegacy', Rf13MHzLegacy), ('HWoptions', HWoptions), ('RTC', RTC), ('Dataflash', Dataflash), ('Configuration', Configuration), ('CorruptFirmware', CorruptFirmware), ('IncompleteFirmware', IncompleteFirmware)]}
        return cls(**kwargs)
class Sys_GetBootStatus_BootStatus_Dict(TypedDict):
    NewerReaderChipFirmware: 'NotRequired[bool]'
    UnexpectedRebootsLegacy: 'NotRequired[bool]'
    FactorySettings: 'NotRequired[bool]'
    ConfigurationInconsistent: 'NotRequired[bool]'
    FirmwareVersionBlocked: 'NotRequired[bool]'
    Bluetooth: 'NotRequired[bool]'
    WiFi: 'NotRequired[bool]'
    Tamper: 'NotRequired[bool]'
    BatteryManagement: 'NotRequired[bool]'
    Keyboard: 'NotRequired[bool]'
    FirmwareVersionBlockedLegacy: 'NotRequired[bool]'
    Display: 'NotRequired[bool]'
    ConfCardPresented: 'NotRequired[bool]'
    Ethernet: 'NotRequired[bool]'
    ExtendedLED: 'NotRequired[bool]'
    Rf125kHz: 'NotRequired[bool]'
    Rf13MHz: 'NotRequired[bool]'
    Rf13MHzLegic: 'NotRequired[bool]'
    Rf13MHzLegacy: 'NotRequired[bool]'
    HWoptions: 'NotRequired[bool]'
    RTC: 'NotRequired[bool]'
    Dataflash: 'NotRequired[bool]'
    Configuration: 'NotRequired[bool]'
    CorruptFirmware: 'NotRequired[bool]'
    IncompleteFirmware: 'NotRequired[bool]'
class Sys_GetStatistics_CounterTuple_Entry(NamedTuple):
    ID: 'int'
    Value: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('ID', self.ID))
        args.append(('Value', self.Value))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
TemplateBitorder = Literal["Lsb", "Msb"]
TemplateBitorder_Parser = LiteralParser[TemplateBitorder, int](
    name='TemplateBitorder',
    literal_map={
        'Lsb': 0,
        'Msb': 1,
    },
)
class TemplateFilter(NamedTuple):
    """
    For every of these filter bits, a specific data conversion mechanism is specified. This mechanism is applied to a TemplateCommand if the filterbit is set. 
    
    The activated filters are applied ordered by there value. Starting with the smallest value.
    """
    BcdToBin: 'bool' = False
    BinToAscii: 'bool' = False
    Unpack: 'bool' = False
    BinToBcd: 'bool' = False
    SwapNibbles: 'bool' = False
    Pack: 'bool' = False
    AsciiToBin: 'bool' = False
    Reverse: 'bool' = False
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        if self.BcdToBin != False:
            args.append(('BcdToBin', self.BcdToBin))
        if self.BinToAscii != False:
            args.append(('BinToAscii', self.BinToAscii))
        if self.Unpack != False:
            args.append(('Unpack', self.Unpack))
        if self.BinToBcd != False:
            args.append(('BinToBcd', self.BinToBcd))
        if self.SwapNibbles != False:
            args.append(('SwapNibbles', self.SwapNibbles))
        if self.Pack != False:
            args.append(('Pack', self.Pack))
        if self.AsciiToBin != False:
            args.append(('AsciiToBin', self.AsciiToBin))
        if self.Reverse != False:
            args.append(('Reverse', self.Reverse))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
    
    @classmethod
    def all(cls) -> Self:
        return cls(BcdToBin=True, BinToAscii=True, Unpack=True, BinToBcd=True, SwapNibbles=True, Pack=True, AsciiToBin=True, Reverse=True)
    
    @classmethod
    def all_except(cls, *, BcdToBin: Optional[Literal[False]] = None, BinToAscii: Optional[Literal[False]] = None, Unpack: Optional[Literal[False]] = None, BinToBcd: Optional[Literal[False]] = None, SwapNibbles: Optional[Literal[False]] = None, Pack: Optional[Literal[False]] = None, AsciiToBin: Optional[Literal[False]] = None, Reverse: Optional[Literal[False]] = None) -> Self:
        true_fields = [name for name, value in [('BcdToBin', BcdToBin), ('BinToAscii', BinToAscii), ('Unpack', Unpack), ('BinToBcd', BinToBcd), ('SwapNibbles', SwapNibbles), ('Pack', Pack), ('AsciiToBin', AsciiToBin), ('Reverse', Reverse)] if value is True]  # type: ignore[comparison-overlap]
        if true_fields:
            raise TypeError(f"all_except() only accepts False values, got {', '.join(f'{name}=True' for name in true_fields)}")
        kwargs = {name: False if value is False else True for name, value in [('BcdToBin', BcdToBin), ('BinToAscii', BinToAscii), ('Unpack', Unpack), ('BinToBcd', BinToBcd), ('SwapNibbles', SwapNibbles), ('Pack', Pack), ('AsciiToBin', AsciiToBin), ('Reverse', Reverse)]}
        return cls(**kwargs)
class TemplateFilter_Dict(TypedDict):
    """
    For every of these filter bits, a specific data conversion mechanism is specified. This mechanism is applied to a TemplateCommand if the filterbit is set. 
    
    The activated filters are applied ordered by there value. Starting with the smallest value.
    """
    BcdToBin: 'NotRequired[bool]'
    BinToAscii: 'NotRequired[bool]'
    Unpack: 'NotRequired[bool]'
    BinToBcd: 'NotRequired[bool]'
    SwapNibbles: 'NotRequired[bool]'
    Pack: 'NotRequired[bool]'
    AsciiToBin: 'NotRequired[bool]'
    Reverse: 'NotRequired[bool]'
Template_Encrypt_CryptoMode = Literal["Ecb", "Cbc"]
Template_Encrypt_CryptoMode_Parser = LiteralParser[Template_Encrypt_CryptoMode, int](
    name='Template_Encrypt_CryptoMode',
    literal_map={
        'Ecb': 0,
        'Cbc': 1,
    },
)
Template_IsEqual_ActionOnSuccess = Literal["Cut", "Keep"]
Template_IsEqual_ActionOnSuccess_Parser = LiteralParser[Template_IsEqual_ActionOnSuccess, int](
    name='Template_IsEqual_ActionOnSuccess',
    literal_map={
        'Cut': 1,
        'Keep': 2,
    },
)
class Template_Scramble_BitMap_Entry(NamedTuple):
    """
    This array contains mapping, that maps every bits in the destination block to a bit in the source block or a constant value.
    """
    Invert: 'bool'
    SrcBitPos: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('Invert', self.Invert))
        args.append(('SrcBitPos', self.SrcBitPos))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
UI_Toggle_Polarity = Literal["Normal", "Inverted"]
UI_Toggle_Polarity_Parser = LiteralParser[UI_Toggle_Polarity, int](
    name='UI_Toggle_Polarity',
    literal_map={
        'Normal': 0,
        'Inverted': 1,
    },
)
Ultralight_AuthE2_DivMode = Literal["NoDiv", "SamAv1OneRound", "SamAv1TwoRounds", "SamAv2"]
Ultralight_AuthE2_DivMode_Parser = LiteralParser[Ultralight_AuthE2_DivMode, int](
    name='Ultralight_AuthE2_DivMode',
    literal_map={
        'NoDiv': 0,
        'SamAv1OneRound': 1,
        'SamAv1TwoRounds': 2,
        'SamAv2': 3,
    },
)
Ultralight_AuthUser_CryptoMode = Literal["TripleDES", "AES"]
Ultralight_AuthUser_CryptoMode_Parser = LiteralParser[Ultralight_AuthUser_CryptoMode, int](
    name='Ultralight_AuthUser_CryptoMode',
    literal_map={
        'TripleDES': 0,
        'AES': 1,
    },
)
VHL_Setup_DesfireHasAppId = Literal["Disabled", "Enabled"]
VHL_Setup_DesfireHasAppId_Parser = LiteralParser[VHL_Setup_DesfireHasAppId, int](
    name='VHL_Setup_DesfireHasAppId',
    literal_map={
        'Disabled': 0,
        'Enabled': 4,
    },
)
VHL_Setup_FileSpecifier = Literal["SelectByName", "SelectByPath", "SelectByAPDU"]
VHL_Setup_FileSpecifier_Parser = LiteralParser[VHL_Setup_FileSpecifier, int](
    name='VHL_Setup_FileSpecifier',
    literal_map={
        'SelectByName': 0,
        'SelectByPath': 1,
        'SelectByAPDU': 2,
    },
)
VHL_Setup_HasDesfireFileDesc = Literal["Disabled", "Enabled"]
VHL_Setup_HasDesfireFileDesc_Parser = LiteralParser[VHL_Setup_HasDesfireFileDesc, int](
    name='VHL_Setup_HasDesfireFileDesc',
    literal_map={
        'Disabled': 0,
        'Enabled': 16,
    },
)
VHL_Setup_HasMifareKey = Literal["Disabled", "Enabled"]
VHL_Setup_HasMifareKey_Parser = LiteralParser[VHL_Setup_HasMifareKey, int](
    name='VHL_Setup_HasMifareKey',
    literal_map={
        'Disabled': 0,
        'Enabled': 6,
    },
)
VHL_Setup_Iso14HasApduTimeout = Literal["Disabled", "Enabled"]
VHL_Setup_Iso14HasApduTimeout_Parser = LiteralParser[VHL_Setup_Iso14HasApduTimeout, int](
    name='VHL_Setup_Iso14HasApduTimeout',
    literal_map={
        'Disabled': 0,
        'Enabled': 2,
    },
)
VHL_Setup_Iso14HasFileLen = Literal["Disabled", "Enabled"]
VHL_Setup_Iso14HasFileLen_Parser = LiteralParser[VHL_Setup_Iso14HasFileLen, int](
    name='VHL_Setup_Iso14HasFileLen',
    literal_map={
        'Disabled': 0,
        'Enabled': 4,
    },
)
class VHL_Setup_Iso14SelectFileCmdList_Entry(NamedTuple):
    FileSpecifier: 'FileSpecifier'
    Name: 'Optional[bytes]' = None
    Path: 'Optional[bytes]' = None
    ApduCommand: 'Optional[bytes]' = None
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('FileSpecifier', self.FileSpecifier))
        if self.Name != None:
            args.append(('Name', self.Name))
        if self.Path != None:
            args.append(('Path', self.Path))
        if self.ApduCommand != None:
            args.append(('ApduCommand', self.ApduCommand))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
FileSpecifier = Literal["SelectByName", "SelectByPath", "SelectByAPDU"]
FileSpecifier_Parser = LiteralParser[FileSpecifier, int](
    name='FileSpecifier',
    literal_map={
        'SelectByName': 0,
        'SelectByPath': 1,
        'SelectByAPDU': 2,
    },
)
VHL_Setup_Iso15HasBlockCount = Literal["Disabled", "Enabled"]
VHL_Setup_Iso15HasBlockCount_Parser = LiteralParser[VHL_Setup_Iso15HasBlockCount, int](
    name='VHL_Setup_Iso15HasBlockCount',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
    },
)
VHL_Setup_Iso15HasBlockSize = Literal["Disabled", "Enabled"]
VHL_Setup_Iso15HasBlockSize_Parser = LiteralParser[VHL_Setup_Iso15HasBlockSize, int](
    name='VHL_Setup_Iso15HasBlockSize',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
    },
)
VHL_Setup_Iso15HasFirstBlock = Literal["Disabled", "Enabled"]
VHL_Setup_Iso15HasFirstBlock_Parser = LiteralParser[VHL_Setup_Iso15HasFirstBlock, int](
    name='VHL_Setup_Iso15HasFirstBlock',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
    },
)
VHL_Setup_Iso15HasOptionFlag = Literal["Disabled", "Enabled"]
VHL_Setup_Iso15HasOptionFlag_Parser = LiteralParser[VHL_Setup_Iso15HasOptionFlag, int](
    name='VHL_Setup_Iso15HasOptionFlag',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
    },
)
VHL_Setup_Iso15OptionFlag = Literal["OptFlagZero", "OptFlagOne", "OptFlagAuto"]
VHL_Setup_Iso15OptionFlag_Parser = LiteralParser[VHL_Setup_Iso15OptionFlag, int](
    name='VHL_Setup_Iso15OptionFlag',
    literal_map={
        'OptFlagZero': 0,
        'OptFlagOne': 1,
        'OptFlagAuto': 2,
    },
)
VHL_Setup_LegicAdrMode = Literal["ProtocolHeader", "Advant"]
VHL_Setup_LegicAdrMode_Parser = LiteralParser[VHL_Setup_LegicAdrMode, int](
    name='VHL_Setup_LegicAdrMode',
    literal_map={
        'ProtocolHeader': 0,
        'Advant': 1,
    },
)
VHL_Setup_LegicHasAdrMode = Literal["Disabled", "Enabled"]
VHL_Setup_LegicHasAdrMode_Parser = LiteralParser[VHL_Setup_LegicHasAdrMode, int](
    name='VHL_Setup_LegicHasAdrMode',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
    },
)
VHL_Setup_LegicHasEnStamp = Literal["Disabled", "Enabled"]
VHL_Setup_LegicHasEnStamp_Parser = LiteralParser[VHL_Setup_LegicHasEnStamp, int](
    name='VHL_Setup_LegicHasEnStamp',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
    },
)
VHL_Setup_MifareHasAsKeyA = Literal["Disabled", "Enabled"]
VHL_Setup_MifareHasAsKeyA_Parser = LiteralParser[VHL_Setup_MifareHasAsKeyA, int](
    name='VHL_Setup_MifareHasAsKeyA',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
    },
)
VHL_Setup_MifareHasMadId = Literal["Disabled", "Enabled"]
VHL_Setup_MifareHasMadId_Parser = LiteralParser[VHL_Setup_MifareHasMadId, int](
    name='VHL_Setup_MifareHasMadId',
    literal_map={
        'Disabled': 0,
        'Enabled': 2,
    },
)
class VhlCfg_File_AreaList125_Value_Entry(NamedTuple):
    PageAddress: 'int'
    PageNr: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('PageAddress', self.PageAddress))
        args.append(('PageNr', self.PageNr))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class VhlCfg_File_DesfireEV2FormatFileMultAccessCond_FileList_Entry(NamedTuple):
    FileNr: 'int'
    AccessCondList: 'List[int]'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('FileNr', self.FileNr))
        args.append(('AccessCondList', self.AccessCondList))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class VhlCfg_File_DesfireKeyList_Value_Entry(NamedTuple):
    AccessRights: 'KeyAccessRights'
    Algorithm: 'CryptoAlgorithm'
    DesKey: 'Optional[bytes]' = None
    ThreeKeyTripleDESKey: 'Optional[bytes]' = None
    TripleDesAesKey: 'Optional[bytes]' = None
    MifareClassicKey: 'Optional[bytes]' = None
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('AccessRights', self.AccessRights))
        args.append(('Algorithm', self.Algorithm))
        if self.DesKey != None:
            args.append(('DesKey', self.DesKey))
        if self.ThreeKeyTripleDESKey != None:
            args.append(('ThreeKeyTripleDESKey', self.ThreeKeyTripleDESKey))
        if self.TripleDesAesKey != None:
            args.append(('TripleDesAesKey', self.TripleDesAesKey))
        if self.MifareClassicKey != None:
            args.append(('MifareClassicKey', self.MifareClassicKey))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class VhlCfg_File_DesfireMapKeyidx_KeyidxMapList_Entry(NamedTuple):
    """
    Entry has to be a sorted list, sorted by keyidx in ascending order.
    """
    Keyidx: 'int'
    KeyidxMsb: 'int'
    KeyidxLsb: 'DesfireKeyIdx'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('Keyidx', self.Keyidx))
        args.append(('KeyidxMsb', self.KeyidxMsb))
        args.append(('KeyidxLsb', self.KeyidxLsb))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
VhlCfg_File_DesfireProtocol_ProtocolMode = Literal["Auto", "Native", "IsoCompatible"]
VhlCfg_File_DesfireProtocol_ProtocolMode_Parser = LiteralParser[VhlCfg_File_DesfireProtocol_ProtocolMode, int](
    name='VhlCfg_File_DesfireProtocol_ProtocolMode',
    literal_map={
        'Auto': 0,
        'Native': 1,
        'IsoCompatible': 2,
    },
)
class VhlCfg_File_FelicaAreaList_Value_Entry(NamedTuple):
    BlockAddress: 'int'
    BlockNr: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('BlockAddress', self.BlockAddress))
        args.append(('BlockNr', self.BlockNr))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
VhlCfg_File_ForceCardSM_MinimumSM = Literal["Native", "EV1", "EV2AES128"]
VhlCfg_File_ForceCardSM_MinimumSM_Parser = LiteralParser[VhlCfg_File_ForceCardSM_MinimumSM, int](
    name='VhlCfg_File_ForceCardSM_MinimumSM',
    literal_map={
        'Native': 0,
        'EV1': 1,
        'EV2AES128': 2,
    },
)
class VhlCfg_File_IntIndFileDescList_Value_Entry(NamedTuple):
    FileSpecifier: 'FileType'
    FileId: 'str'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('FileSpecifier', self.FileSpecifier))
        args.append(('FileId', self.FileId))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
VhlCfg_File_IntIndOnReadSelectOnly_Value = Literal["False", "True"]
VhlCfg_File_IntIndOnReadSelectOnly_Value_Parser = LiteralParser[VhlCfg_File_IntIndOnReadSelectOnly_Value, int](
    name='VhlCfg_File_IntIndOnReadSelectOnly_Value',
    literal_map={
        'False': 0,
        'True': 1,
    },
)
class VhlCfg_File_Iso15BlockList_Value_Entry(NamedTuple):
    StartBlock: 'int'
    NumberOfBlocks: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('StartBlock', self.StartBlock))
        args.append(('NumberOfBlocks', self.NumberOfBlocks))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class VhlCfg_File_Iso15ExtendedBlockList_Value_Entry(NamedTuple):
    StartBlock: 'int'
    NumberOfBlocks: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('StartBlock', self.StartBlock))
        args.append(('NumberOfBlocks', self.NumberOfBlocks))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
VhlCfg_File_Iso15ReadCmd_Value = Literal["ReadAuto", "ReadMultipleBlocks", "ReadSingleBlock", "FastMultipleBlock26kbit", "FastMultipleBlock52kbit", "FastMultipleBlock105kbit", "FastMultipleBlock211kbit"]
VhlCfg_File_Iso15ReadCmd_Value_Parser = LiteralParser[VhlCfg_File_Iso15ReadCmd_Value, int](
    name='VhlCfg_File_Iso15ReadCmd_Value',
    literal_map={
        'ReadAuto': 0,
        'ReadMultipleBlocks': 1,
        'ReadSingleBlock': 2,
        'FastMultipleBlock26kbit': 4,
        'FastMultipleBlock52kbit': 5,
        'FastMultipleBlock105kbit': 6,
        'FastMultipleBlock211kbit': 7,
    },
)
VhlCfg_File_Iso15WriteCmd_Value = Literal["WriteAuto", "WriteMultipleBlocks", "WriteSingleBlock"]
VhlCfg_File_Iso15WriteCmd_Value_Parser = LiteralParser[VhlCfg_File_Iso15WriteCmd_Value, int](
    name='VhlCfg_File_Iso15WriteCmd_Value',
    literal_map={
        'WriteAuto': 0,
        'WriteMultipleBlocks': 1,
        'WriteSingleBlock': 2,
    },
)
VhlCfg_File_Iso15WriteOptFlag_Value = Literal["WriteOptFlagZero", "WriteOptFlagOne", "WriteOptFlagAuto"]
VhlCfg_File_Iso15WriteOptFlag_Value_Parser = LiteralParser[VhlCfg_File_Iso15WriteOptFlag_Value, int](
    name='VhlCfg_File_Iso15WriteOptFlag_Value',
    literal_map={
        'WriteOptFlagZero': 0,
        'WriteOptFlagOne': 1,
        'WriteOptFlagAuto': 2,
    },
)
class VhlCfg_File_LegicApplicationSegmentList_Value_Entry(NamedTuple):
    SegmentIdAndAdr: 'SegmentIdentificationAndAddressing'
    SegmentInformation: 'str'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('SegmentIdAndAdr', self.SegmentIdAndAdr))
        args.append(('SegmentInformation', self.SegmentInformation))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
VhlCfg_File_LegicCtcFileSystemList_FileSystem = Literal["FsLegicAdvant", "FsLegicPrime"]
VhlCfg_File_LegicCtcFileSystemList_FileSystem_Parser = LiteralParser[VhlCfg_File_LegicCtcFileSystemList_FileSystem, int](
    name='VhlCfg_File_LegicCtcFileSystemList_FileSystem',
    literal_map={
        'FsLegicAdvant': 0,
        'FsLegicPrime': 1,
    },
)
VhlCfg_File_LegicKeyList_KeyType = Literal["DES", "TripleDES", "ThreeKeyTripleDES", "AES128", "AES256"]
VhlCfg_File_LegicKeyList_KeyType_Parser = LiteralParser[VhlCfg_File_LegicKeyList_KeyType, int](
    name='VhlCfg_File_LegicKeyList_KeyType',
    literal_map={
        'DES': 1,
        'TripleDES': 2,
        'ThreeKeyTripleDES': 3,
        'AES128': 4,
        'AES256': 5,
    },
)
class VhlCfg_File_LegicKeyList_Value_Entry(NamedTuple):
    KeyIndex: 'int'
    KeyType: 'KeyType'
    DesKey: 'Optional[bytes]' = None
    TripleDesKey: 'Optional[bytes]' = None
    ThreeKeyTripleDESKey: 'Optional[bytes]' = None
    Aes128Key: 'Optional[bytes]' = None
    AES256Key: 'Optional[bytes]' = None
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('KeyIndex', self.KeyIndex))
        args.append(('KeyType', self.KeyType))
        if self.DesKey != None:
            args.append(('DesKey', self.DesKey))
        if self.TripleDesKey != None:
            args.append(('TripleDesKey', self.TripleDesKey))
        if self.ThreeKeyTripleDESKey != None:
            args.append(('ThreeKeyTripleDESKey', self.ThreeKeyTripleDESKey))
        if self.Aes128Key != None:
            args.append(('Aes128Key', self.Aes128Key))
        if self.AES256Key != None:
            args.append(('AES256Key', self.AES256Key))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
KeyType = Literal["DES", "TripleDES", "ThreeKeyTripleDES", "AES128", "AES256"]
KeyType_Parser = LiteralParser[KeyType, int](
    name='KeyType',
    literal_map={
        'DES': 1,
        'TripleDES': 2,
        'ThreeKeyTripleDES': 3,
        'AES128': 4,
        'AES256': 5,
    },
)
VhlCfg_File_LegicMasterTokenZoneList_MtZone = Literal["MtZoneA", "MtZoneB", "MtZoneC", "MtZoneAny"]
VhlCfg_File_LegicMasterTokenZoneList_MtZone_Parser = LiteralParser[VhlCfg_File_LegicMasterTokenZoneList_MtZone, int](
    name='VhlCfg_File_LegicMasterTokenZoneList_MtZone',
    literal_map={
        'MtZoneA': 0,
        'MtZoneB': 574,
        'MtZoneC': 830,
        'MtZoneAny': 65535,
    },
)
class VhlCfg_File_LegicSegmentListLegacy_Value_Entry(NamedTuple):
    AdvantAddressMode: 'bool'
    SegmentIdentification: 'int'
    SegmentInformation: 'str'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('AdvantAddressMode', self.AdvantAddressMode))
        args.append(('SegmentIdentification', self.SegmentIdentification))
        args.append(('SegmentInformation', self.SegmentInformation))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
VhlCfg_File_LegicSegmentTypeList_SegType = Literal["Any", "GAM", "SAM", "IAM", "XAM1", "Data", "Access", "Biometric", "AMPlus"]
VhlCfg_File_LegicSegmentTypeList_SegType_Parser = LiteralParser[VhlCfg_File_LegicSegmentTypeList_SegType, int](
    name='VhlCfg_File_LegicSegmentTypeList_SegType',
    literal_map={
        'Any': 0,
        'GAM': 1,
        'SAM': 2,
        'IAM': 3,
        'XAM1': 4,
        'Data': 64,
        'Access': 80,
        'Biometric': 112,
        'AMPlus': 192,
    },
)
VhlCfg_File_MifareClassicFormatOriginalKeyList_AuthenticationKeyAssignment = Literal["UseKeyA", "UseKeyB"]
VhlCfg_File_MifareClassicFormatOriginalKeyList_AuthenticationKeyAssignment_Parser = LiteralParser[VhlCfg_File_MifareClassicFormatOriginalKeyList_AuthenticationKeyAssignment, int](
    name='VhlCfg_File_MifareClassicFormatOriginalKeyList_AuthenticationKeyAssignment',
    literal_map={
        'UseKeyA': 0,
        'UseKeyB': 1,
    },
)
class VhlCfg_File_MifareClassicFormatOriginalKeyList_Value_Entry(NamedTuple):
    """
    List of key entries
    """
    AuthenticationKeyAssignment: 'AuthenticationKeyAssignment'
    Key: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('AuthenticationKeyAssignment', self.AuthenticationKeyAssignment))
        args.append(('Key', self.Key))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
AuthenticationKeyAssignment = Literal["UseKeyA", "UseKeyB"]
AuthenticationKeyAssignment_Parser = LiteralParser[AuthenticationKeyAssignment, int](
    name='AuthenticationKeyAssignment',
    literal_map={
        'UseKeyA': 0,
        'UseKeyB': 1,
    },
)
class VhlCfg_File_MifareKeyList_Value_Entry(NamedTuple):
    DenyTransferToSecureMemory: 'bool'
    DenyChangeKey: 'bool'
    DenyWrite: 'bool'
    DenyRead: 'bool'
    Key: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('DenyTransferToSecureMemory', self.DenyTransferToSecureMemory))
        args.append(('DenyChangeKey', self.DenyChangeKey))
        args.append(('DenyWrite', self.DenyWrite))
        args.append(('DenyRead', self.DenyRead))
        args.append(('Key', self.Key))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
VhlCfg_File_MifareMode_AccessMode = Literal["Absolute", "Mad", "AbsoluteFullS0"]
VhlCfg_File_MifareMode_AccessMode_Parser = LiteralParser[VhlCfg_File_MifareMode_AccessMode, int](
    name='VhlCfg_File_MifareMode_AccessMode',
    literal_map={
        'Absolute': 0,
        'Mad': 1,
        'AbsoluteFullS0': 2,
    },
)
class VhlCfg_File_MifarePlusAesKeyList_Value_Entry(NamedTuple):
    DenyChangeKey: 'bool'
    DenyWrite: 'bool'
    DenyRead: 'bool'
    Key: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('DenyChangeKey', self.DenyChangeKey))
        args.append(('DenyWrite', self.DenyWrite))
        args.append(('DenyRead', self.DenyRead))
        args.append(('Key', self.Key))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class VhlCfg_File_MifarePlusKeyAssignment_Value_Entry(NamedTuple):
    WriteWithKeyB: 'bool'
    ReadWithKeyB: 'bool'
    KeyAMemoryType: 'MifarePlusKeyMemoryType'
    KeyAIdx: 'int'
    KeyBMemoryType: 'MifarePlusKeyMemoryType'
    KeyBIdx: 'int'
    ACBytes: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('WriteWithKeyB', self.WriteWithKeyB))
        args.append(('ReadWithKeyB', self.ReadWithKeyB))
        args.append(('KeyAMemoryType', self.KeyAMemoryType))
        args.append(('KeyAIdx', self.KeyAIdx))
        args.append(('KeyBMemoryType', self.KeyBMemoryType))
        args.append(('KeyBIdx', self.KeyBIdx))
        args.append(('ACBytes', self.ACBytes))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
VhlCfg_File_MifareTransferToSecureMemory_TransferKeys = Literal["Yes", "No"]
VhlCfg_File_MifareTransferToSecureMemory_TransferKeys_Parser = LiteralParser[VhlCfg_File_MifareTransferToSecureMemory_TransferKeys, int](
    name='VhlCfg_File_MifareTransferToSecureMemory_TransferKeys',
    literal_map={
        'Yes': 255,
        'No': 254,
    },
)
class VhlCfg_File_UltralightExtendedBlockList_Value_Entry(NamedTuple):
    StartBlock: 'int'
    NumberOfBlocks: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('StartBlock', self.StartBlock))
        args.append(('NumberOfBlocks', self.NumberOfBlocks))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class VhlCfg_File_UltralightKeyList_Value_Entry(NamedTuple):
    AccessRights: 'KeyAccessRights'
    Algorithm: 'CryptoAlgorithm'
    TripleDesAesKey: 'Optional[bytes]' = None
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('AccessRights', self.AccessRights))
        args.append(('Algorithm', self.Algorithm))
        if self.TripleDesAesKey != None:
            args.append(('TripleDesAesKey', self.TripleDesAesKey))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class VirtualLedDefinition(NamedTuple):
    Mode: 'VirtualLedDefinition_Mode'
    RgbColor: 'int'
    PhysicalLedSelection: 'Optional[VirtualLedDefinition_PhysicalLedSelection]' = None
    RgbColor2: 'Optional[int]' = None
    TransitionTime: 'Optional[int]' = None
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('Mode', self.Mode))
        args.append(('RgbColor', self.RgbColor))
        if self.PhysicalLedSelection != None:
            args.append(('PhysicalLedSelection', self.PhysicalLedSelection))
        if self.RgbColor2 != None:
            args.append(('RgbColor2', self.RgbColor2))
        if self.TransitionTime != None:
            args.append(('TransitionTime', self.TransitionTime))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class VirtualLedDefinition_Dict(TypedDict):
    Mode: 'VirtualLedDefinition_Mode'
    RgbColor: 'int'
    PhysicalLedSelection: 'NotRequired[VirtualLedDefinition_PhysicalLedSelection]'
    RgbColor2: 'NotRequired[int]'
    TransitionTime: 'NotRequired[int]'
class VirtualLedDefinition_Mode(NamedTuple):
    """
    This byte is required to enable additional fields for the characterization of the desired LED behavior.
    """
    ContainsTransitionTime: 'bool' = False
    IsPulse: 'bool' = False
    ContainsPhysicalLedSelection: 'bool' = False
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        if self.ContainsTransitionTime != False:
            args.append(('ContainsTransitionTime', self.ContainsTransitionTime))
        if self.IsPulse != False:
            args.append(('IsPulse', self.IsPulse))
        if self.ContainsPhysicalLedSelection != False:
            args.append(('ContainsPhysicalLedSelection', self.ContainsPhysicalLedSelection))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
    
    @classmethod
    def all(cls) -> Self:
        return cls(ContainsTransitionTime=True, IsPulse=True, ContainsPhysicalLedSelection=True)
    
    @classmethod
    def all_except(cls, *, ContainsTransitionTime: Optional[Literal[False]] = None, IsPulse: Optional[Literal[False]] = None, ContainsPhysicalLedSelection: Optional[Literal[False]] = None) -> Self:
        true_fields = [name for name, value in [('ContainsTransitionTime', ContainsTransitionTime), ('IsPulse', IsPulse), ('ContainsPhysicalLedSelection', ContainsPhysicalLedSelection)] if value is True]  # type: ignore[comparison-overlap]
        if true_fields:
            raise TypeError(f"all_except() only accepts False values, got {', '.join(f'{name}=True' for name in true_fields)}")
        kwargs = {name: False if value is False else True for name, value in [('ContainsTransitionTime', ContainsTransitionTime), ('IsPulse', IsPulse), ('ContainsPhysicalLedSelection', ContainsPhysicalLedSelection)]}
        return cls(**kwargs)
class VirtualLedDefinition_Mode_Dict(TypedDict):
    """
    This byte is required to enable additional fields for the characterization of the desired LED behavior.
    """
    ContainsTransitionTime: 'NotRequired[bool]'
    IsPulse: 'NotRequired[bool]'
    ContainsPhysicalLedSelection: 'NotRequired[bool]'
VirtualLedDefinition_PhysicalLedSelection = Literal["Right", "Left", "All"]
VirtualLedDefinition_PhysicalLedSelection_Parser = LiteralParser[VirtualLedDefinition_PhysicalLedSelection, int](
    name='VirtualLedDefinition_PhysicalLedSelection',
    literal_map={
        'Right': 1,
        'Left': 2,
        'All': 3,
    },
)
__all__: list[str] = [
    "AR_GetMessage_Result",
    "AddressAndEnableCRC",
    "AddressAndEnableCRC_Dict",
    "Alignment",
    "Alignment_Parser",
    "AuthReqUpload",
    "AuthReqUpload_Parser",
    "AuthenticationKeyAssignment",
    "AuthenticationKeyAssignment_Parser",
    "AutoReadMode",
    "AutoReadMode_Parser",
    "AutoRunCommand",
    "AutoRunCommand_Dict",
    "AutoRunCommand_RunMode",
    "AutoRunCommand_RunMode_Parser",
    "Autoread_Rule_ConstArea_Result",
    "Autoread_Rule_OnMatchAction_Action",
    "Autoread_Rule_OnMatchAction_Action_Parser",
    "Autoread_Rule_PrioritizationMode_PrioMode",
    "Autoread_Rule_PrioritizationMode_PrioMode_Parser",
    "BRP_CommandFrame_CheckSumAlgo",
    "BRP_CommandFrame_CheckSumAlgo_Parser",
    "BRP_CommandFrame_ExecutionMode",
    "BRP_CommandFrame_ExecutionMode_Parser",
    "BRP_ResponseFrame_CheckSumAlgo",
    "BRP_ResponseFrame_CheckSumAlgo_Parser",
    "BRP_ResponseFrame_Phase",
    "BRP_ResponseFrame_Phase_Parser",
    "Baudrate",
    "Baudrate_Parser",
    "BlePeriph_DefineService_Characteristics_Entry",
    "BlePeriph_GetEvents_Result",
    "BlePeriph_IsConnected_AddressType",
    "BlePeriph_IsConnected_AddressType_Parser",
    "BlePeriph_IsConnected_Result",
    "CRCAddressAndCRCType",
    "CRCAddressAndCRCType_Dict",
    "CardFamilies",
    "CardFamilies_Dict",
    "CardType",
    "CardType_Parser",
    "CardTypes125KhzPart1",
    "CardTypes125KhzPart1_Dict",
    "CardTypes125KhzPart2",
    "CardTypes125KhzPart2_Dict",
    "CryptoAlgorithm",
    "CryptoAlgorithm_Parser",
    "CryptoMemoryIndex",
    "CryptoMemoryIndex_Dict",
    "Crypto_BalKeyEncryptBuffer_Result",
    "Crypto_DecryptBuffer_Result",
    "Crypto_EncryptBuffer_Result",
    "Custom_BlackWhiteList_ListMode_BlackWhiteListMode",
    "Custom_BlackWhiteList_ListMode_BlackWhiteListMode_Parser",
    "DesfireFileDescription",
    "DesfireFileDescription_Dict",
    "DesfireFileDescription_FileCommunicationSecurity",
    "DesfireFileDescription_FileCommunicationSecurity_Parser",
    "DesfireFileDescription_FileType",
    "DesfireFileDescription_FileType_Parser",
    "DesfireKeyIdx",
    "Desfire_AuthExtKey_CryptoMode",
    "Desfire_AuthExtKey_CryptoMode_Parser",
    "Desfire_AuthExtKey_SecureMessaging",
    "Desfire_AuthExtKey_SecureMessaging_Parser",
    "Desfire_Authenticate_KeyDivMode",
    "Desfire_Authenticate_KeyDivMode_Parser",
    "Desfire_Authenticate_SecureMessaging",
    "Desfire_Authenticate_SecureMessaging_Parser",
    "Desfire_ChangeExtKey_MasterKeyType",
    "Desfire_ChangeExtKey_MasterKeyType_Parser",
    "Desfire_ChangeKey_CurKeyDivMode",
    "Desfire_ChangeKey_CurKeyDivMode_Parser",
    "Desfire_ChangeKey_NewKeyDivMode",
    "Desfire_ChangeKey_NewKeyDivMode_Parser",
    "Desfire_ExecCommand_CryptoMode",
    "Desfire_ExecCommand_CryptoMode_Parser",
    "Desfire_GetDfNames_AppNr_Entry",
    "Desfire_ReadData_Mode",
    "Desfire_ReadData_Mode_Parser",
    "Desfire_SetFraming_CommMode",
    "Desfire_SetFraming_CommMode_Parser",
    "Desfire_VirtualCardSelect_Result",
    "Desfire_WriteData_Mode",
    "Desfire_WriteData_Mode_Parser",
    "Device_Boot_FirmwareCrcCheck_Value",
    "Device_Boot_FirmwareCrcCheck_Value_Parser",
    "Device_HostSecurity_Key_Result",
    "Device_Keypad_KeyPressSignal_SignalType",
    "Device_Keypad_KeyPressSignal_SignalType_Parser",
    "Device_Keypad_SpecialKeySettings_Settings",
    "Device_Keypad_SpecialKeySettings_Settings_Parser",
    "Device_Run_AccessRightsOfBAC_Value",
    "Device_Run_AccessRightsOfBAC_Value_Parser",
    "Device_Run_AutoreadPulseHf_PulseHf",
    "Device_Run_AutoreadPulseHf_PulseHf_Parser",
    "Device_Run_AutoreadWaitForCardRemoval_WaitForCardRemoval",
    "Device_Run_AutoreadWaitForCardRemoval_WaitForCardRemoval_Parser",
    "Device_Run_DenyReaderInfoViaIso14443_Value",
    "Device_Run_DenyReaderInfoViaIso14443_Value_Parser",
    "Device_Run_DenyUnauthFwUploadViaBrp_Value",
    "Device_Run_DenyUnauthFwUploadViaBrp_Value_Parser",
    "Device_Run_DenyUploadViaIso14443_Value",
    "Device_Run_DenyUploadViaIso14443_Value_Parser",
    "Device_Run_MaintenanceFunctionFilter_Result",
    "Device_Run_RepeatMessageMode_Result",
    "Device_Run_SetBusAdrOnUploadViaIso14443_Value",
    "Device_Run_SetBusAdrOnUploadViaIso14443_Value_Parser",
    "DiversificationMode",
    "DiversificationMode_Parser",
    "DivisorInteger",
    "DivisorInteger_Parser",
    "FSCI",
    "FSCI_Parser",
    "FWI",
    "FWI_Parser",
    "FeatureID",
    "FeatureID_Parser",
    "Felica_GenericCmd_FastBaud",
    "Felica_GenericCmd_FastBaud_Parser",
    "Felica_Request_FastBaud",
    "Felica_Request_FastBaud_Parser",
    "Felica_Request_Result",
    "FileSpecifier",
    "FileSpecifier_Parser",
    "FileType",
    "FileType_Parser",
    "FireEventAtPowerup",
    "FireEventAtPowerup_Parser",
    "FirmwareVersion",
    "FirmwareVersion_Dict",
    "HostSecurityAccessConditionBits",
    "HostSecurityAccessConditionBits_Dict",
    "HostSecurityAuthenticationMode",
    "HostSecurityAuthenticationMode_Dict",
    "IoPort",
    "IoPort_Parser",
    "Iso14L4_SetupAPDU_FSCI",
    "Iso14L4_SetupAPDU_FSCI_Parser",
    "Iso14L4_SetupAPDU_FWI",
    "Iso14L4_SetupAPDU_FWI_Parser",
    "Iso14a_RequestATS_FSDI",
    "Iso14a_RequestATS_FSDI_Parser",
    "Iso14a_RequestVasup_Result",
    "Iso14a_Request_Result",
    "Iso14a_Select_Result",
    "Iso14b_Attrib_EOF",
    "Iso14b_Attrib_EOF_Parser",
    "Iso14b_Attrib_FSDI",
    "Iso14b_Attrib_FSDI_Parser",
    "Iso14b_Attrib_Result",
    "Iso14b_Attrib_SOF",
    "Iso14b_Attrib_SOF_Parser",
    "Iso14b_Attrib_TR0",
    "Iso14b_Attrib_TR0_Parser",
    "Iso14b_Attrib_TR1",
    "Iso14b_Attrib_TR1_Parser",
    "Iso14b_Request_FSCI",
    "Iso14b_Request_FSCI_Parser",
    "Iso14b_Request_FWI",
    "Iso14b_Request_FWI_Parser",
    "Iso14b_Request_ProtType",
    "Iso14b_Request_ProtType_Parser",
    "Iso14b_Request_SFGI",
    "Iso14b_Request_SFGI_Parser",
    "Iso14b_Request_TimeSlots",
    "Iso14b_Request_TimeSlots_Parser",
    "Iso14b_Request_ValueList_Entry",
    "Iso15_CustomCommand_Result",
    "Iso15_GetParam_Result",
    "Iso15_GetSecurityStatus_Result",
    "Iso15_GetSystemInformation_Result",
    "Iso15_GetUIDList_Labels_Entry",
    "Iso15_GetUIDList_Result",
    "Iso15_ReadMultipleBlocks_Result",
    "Iso15_ReadSingleBlock_Result",
    "Iso15_SetMode_Mode",
    "Iso15_SetMode_Mode_Parser",
    "Iso78_OpenSam_LID",
    "Iso78_OpenSam_LID_Parser",
    "Iso78_OpenSam_Result",
    "KeyAccessRights",
    "KeyAccessRights_Dict",
    "KeyAccessRights_DiversificationMode",
    "KeyAccessRights_DiversificationMode_Parser",
    "KeyAccessRights_KeySettings",
    "KeyAccessRights_KeySettings_Dict",
    "KeyType",
    "KeyType_Parser",
    "LedBitMask",
    "LedBitMask_Dict",
    "LicenseBitMask",
    "LicenseBitMask_Dict",
    "Main_Bf3UploadContinue_Result",
    "Main_Bf3UploadStart_Result",
    "MaxBaudrateIso14443",
    "MaxBaudrateIso14443_Parser",
    "MessageType",
    "MessageType_Parser",
    "Mif_AuthE2Extended_AuthLevel",
    "Mif_AuthE2Extended_AuthLevel_Parser",
    "Mif_AuthE2_AuthMode",
    "Mif_AuthE2_AuthMode_Parser",
    "Mif_AuthUserExtended_AuthLevel",
    "Mif_AuthUserExtended_AuthLevel_Parser",
    "Mif_AuthUser_AuthMode",
    "Mif_AuthUser_AuthMode_Parser",
    "Mif_ChangeValueBackup_Mode",
    "Mif_ChangeValueBackup_Mode_Parser",
    "Mif_ChangeValue_Mode",
    "Mif_ChangeValue_Mode_Parser",
    "Mif_SectorSwitch_SectorSpec_Entry",
    "Mif_SetFraming_CommMode",
    "Mif_SetFraming_CommMode_Parser",
    "Mif_ValueSL3_Cmd",
    "Mif_ValueSL3_Cmd_Parser",
    "Mif_VirtualCardSelect_FciType",
    "Mif_VirtualCardSelect_FciType_Parser",
    "Mif_VirtualCardSelect_Result",
    "MifareClassicVhlKeyAssignment",
    "MifareClassicVhlKeyAssignment_Dict",
    "MifarePlusKeyMemoryType",
    "MifarePlusKeyMemoryType_Parser",
    "MobileId_Enable_Mode",
    "MobileId_Enable_Mode_Parser",
    "Parity",
    "Parity_Parser",
    "Project_CryptoKey_Entry_Result",
    "Project_HidSam_Confcard_Result",
    "Project_LegicKeySettings_Index_DiversificationMode",
    "Project_LegicKeySettings_Index_DiversificationMode_Parser",
    "Project_LegicKeySettings_Index_KeyType",
    "Project_LegicKeySettings_Index_KeyType_Parser",
    "Project_LegicKeySettings_Index_Result",
    "Project_LegicVcp_Status_Context",
    "Project_LegicVcp_Status_Context_Parser",
    "Project_LegicVcp_Status_Result",
    "Project_LegicVcp_Status_StatusCode",
    "Project_LegicVcp_Status_StatusCode_Parser",
    "Project_MobileId_AdvertisementFilter_Value",
    "Project_MobileId_AdvertisementFilter_Value_Parser",
    "Project_MobileId_ConvenientAccess_Value",
    "Project_MobileId_ConvenientAccess_Value_Parser",
    "Project_MobileId_DetectionRssiFilter_Value",
    "Project_MobileId_DetectionRssiFilter_Value_Parser",
    "Project_MobileId_Mode_Value",
    "Project_MobileId_Mode_Value_Parser",
    "Project_MobileId_TriggerFromDistance_Value",
    "Project_MobileId_TriggerFromDistance_Value_Parser",
    "Project_SamAVxKeySettings_Index_DiversificationMode",
    "Project_SamAVxKeySettings_Index_DiversificationMode_Parser",
    "Project_SamAVxKeySettings_Index_KeySettingsList_Entry",
    "Project_SamAVx_AnswerToReset_LID",
    "Project_SamAVx_AnswerToReset_LID_Parser",
    "Project_SamAVx_AnswerToReset_Result",
    "Project_SamAVx_PowerUpState_Value",
    "Project_SamAVx_PowerUpState_Value_Parser",
    "Project_SamAVx_SecureMessaging_Value",
    "Project_SamAVx_SecureMessaging_Value_Parser",
    "Project_VhlSettings125Khz_AwidSerialNrFormat_Value",
    "Project_VhlSettings125Khz_AwidSerialNrFormat_Value_Parser",
    "Project_VhlSettings125Khz_BaudRate_Baud",
    "Project_VhlSettings125Khz_BaudRate_Baud_Parser",
    "Project_VhlSettings125Khz_EM4100SerialNrFormat_Value",
    "Project_VhlSettings125Khz_EM4100SerialNrFormat_Value_Parser",
    "Project_VhlSettings125Khz_HidProxSerialNrFormat_Value",
    "Project_VhlSettings125Khz_HidProxSerialNrFormat_Value_Parser",
    "Project_VhlSettings125Khz_IndaspParityCheck_ParityDisable",
    "Project_VhlSettings125Khz_IndaspParityCheck_ParityDisable_Parser",
    "Project_VhlSettings125Khz_IoProxSerialNrFormat_Value",
    "Project_VhlSettings125Khz_IoProxSerialNrFormat_Value_Parser",
    "Project_VhlSettings125Khz_ModType_Mod",
    "Project_VhlSettings125Khz_ModType_Mod_Parser",
    "Project_VhlSettings125Khz_ObidCardIdFormat_Value",
    "Project_VhlSettings125Khz_ObidCardIdFormat_Value_Parser",
    "Project_VhlSettings125Khz_PyramidSerialNrFormat_Value",
    "Project_VhlSettings125Khz_PyramidSerialNrFormat_Value_Parser",
    "Project_VhlSettings125Khz_TTFBaudrate_TTFBaud",
    "Project_VhlSettings125Khz_TTFBaudrate_TTFBaud_Parser",
    "Project_VhlSettings125Khz_TTFModType_TTFMod",
    "Project_VhlSettings125Khz_TTFModType_TTFMod_Parser",
    "Project_VhlSettings_ForceReselect_Value",
    "Project_VhlSettings_ForceReselect_Value_Parser",
    "Project_VhlSettings_Iso14aVasup_Result",
    "ProtType",
    "ProtType_Parser",
    "ProtocolID",
    "ProtocolID_Parser",
    "Protocols_BrpSerial_InterbyteTimeout_Result",
    "Protocols_Ccid_LedControl_Value",
    "Protocols_Ccid_LedControl_Value_Parser",
    "Protocols_KeyboardEmulation_RegisterInterface_Value",
    "Protocols_KeyboardEmulation_RegisterInterface_Value_Parser",
    "Protocols_KeyboardEmulation_ScancodesMap_Value_Entry",
    "Protocols_KeyboardEmulation_UsbInterfaceOrder_Value",
    "Protocols_KeyboardEmulation_UsbInterfaceOrder_Value_Parser",
    "Protocols_KeyboardEmulation_UsbInterfaceSubClass_Value",
    "Protocols_KeyboardEmulation_UsbInterfaceSubClass_Value_Parser",
    "Protocols_MagstripeEmulation_Encoding_Value",
    "Protocols_MagstripeEmulation_Encoding_Value_Parser",
    "Protocols_Network_DhcpMode_Value",
    "Protocols_Network_DhcpMode_Value_Parser",
    "Protocols_Osdp_DataMode_Value",
    "Protocols_Osdp_DataMode_Value_Parser",
    "Protocols_Osdp_SCBKeyDefault_DiversifyFlag",
    "Protocols_Osdp_SCBKeyDefault_DiversifyFlag_Parser",
    "Protocols_Osdp_SCBKeyDefault_Result",
    "Protocols_Osdp_SCBKey_DiversifyFlag",
    "Protocols_Osdp_SCBKey_DiversifyFlag_Parser",
    "Protocols_Osdp_SCBKey_Result",
    "Protocols_Osdp_SecureInstallMode_Value",
    "Protocols_Osdp_SecureInstallMode_Value_Parser",
    "Protocols_RawSerial_Channel_Value",
    "Protocols_RawSerial_Channel_Value_Parser",
    "Protocols_SNet_DeviceType_Value",
    "Protocols_SNet_DeviceType_Value_Parser",
    "Protocols_Wiegand_BitOrder_Value",
    "Protocols_Wiegand_BitOrder_Value_Parser",
    "Protocols_Wiegand_Mode_Value",
    "Protocols_Wiegand_Mode_Value_Parser",
    "Protocols_Wiegand_PinMessageFormat_Value",
    "Protocols_Wiegand_PinMessageFormat_Value_Parser",
    "RunSequenceCmd",
    "RunSequenceCmd_Dict",
    "RunSequenceCmd_CmdCode",
    "RunSequenceCmd_CmdCode_Parser",
    "SFGI",
    "SFGI_Parser",
    "Sec_AuthPhase1_Result",
    "SegmentIdentificationAndAddressing",
    "SegmentIdentificationAndAddressing_Dict",
    "Sys_CfgCheck_Result",
    "Sys_CfgGetDeviceSettingsId_Result",
    "Sys_CfgGetId_Result",
    "Sys_CfgLoadFinish_FinalizeAction",
    "Sys_CfgLoadFinish_FinalizeAction_Parser",
    "Sys_GetBootStatus_BootStatus",
    "Sys_GetBootStatus_BootStatus_Dict",
    "Sys_GetBufferSize_Result",
    "Sys_GetFeatures_Result",
    "Sys_GetPartNumber_Result",
    "Sys_GetStatistics_CounterTuple_Entry",
    "TemplateBitorder",
    "TemplateBitorder_Parser",
    "TemplateFilter",
    "TemplateFilter_Dict",
    "Template_Encrypt_CryptoMode",
    "Template_Encrypt_CryptoMode_Parser",
    "Template_IsEqual_ActionOnSuccess",
    "Template_IsEqual_ActionOnSuccess_Parser",
    "Template_Scramble_BitMap_Entry",
    "UI_Toggle_Polarity",
    "UI_Toggle_Polarity_Parser",
    "Ultralight_AuthE2_DivMode",
    "Ultralight_AuthE2_DivMode_Parser",
    "Ultralight_AuthUser_CryptoMode",
    "Ultralight_AuthUser_CryptoMode_Parser",
    "VHL_ExchangeLongAPDU_Result",
    "VHL_GetFileInfo_Result",
    "VHL_Setup_DesfireHasAppId",
    "VHL_Setup_DesfireHasAppId_Parser",
    "VHL_Setup_FileSpecifier",
    "VHL_Setup_FileSpecifier_Parser",
    "VHL_Setup_HasDesfireFileDesc",
    "VHL_Setup_HasDesfireFileDesc_Parser",
    "VHL_Setup_HasMifareKey",
    "VHL_Setup_HasMifareKey_Parser",
    "VHL_Setup_Iso14HasApduTimeout",
    "VHL_Setup_Iso14HasApduTimeout_Parser",
    "VHL_Setup_Iso14HasFileLen",
    "VHL_Setup_Iso14HasFileLen_Parser",
    "VHL_Setup_Iso14SelectFileCmdList_Entry",
    "VHL_Setup_Iso15HasBlockCount",
    "VHL_Setup_Iso15HasBlockCount_Parser",
    "VHL_Setup_Iso15HasBlockSize",
    "VHL_Setup_Iso15HasBlockSize_Parser",
    "VHL_Setup_Iso15HasFirstBlock",
    "VHL_Setup_Iso15HasFirstBlock_Parser",
    "VHL_Setup_Iso15HasOptionFlag",
    "VHL_Setup_Iso15HasOptionFlag_Parser",
    "VHL_Setup_Iso15OptionFlag",
    "VHL_Setup_Iso15OptionFlag_Parser",
    "VHL_Setup_LegicAdrMode",
    "VHL_Setup_LegicAdrMode_Parser",
    "VHL_Setup_LegicHasAdrMode",
    "VHL_Setup_LegicHasAdrMode_Parser",
    "VHL_Setup_LegicHasEnStamp",
    "VHL_Setup_LegicHasEnStamp_Parser",
    "VHL_Setup_MifareHasAsKeyA",
    "VHL_Setup_MifareHasAsKeyA_Parser",
    "VHL_Setup_MifareHasMadId",
    "VHL_Setup_MifareHasMadId_Parser",
    "VhlCfg_File_AreaList125_Value_Entry",
    "VhlCfg_File_DesfireEV2FormatFileMultAccessCond_FileList_Entry",
    "VhlCfg_File_DesfireKeyList_Value_Entry",
    "VhlCfg_File_DesfireMapKeyidx_KeyidxMapList_Entry",
    "VhlCfg_File_DesfireProtocol_ProtocolMode",
    "VhlCfg_File_DesfireProtocol_ProtocolMode_Parser",
    "VhlCfg_File_DesfireRandomIdKey_Result",
    "VhlCfg_File_DesfireSoftUid_Result",
    "VhlCfg_File_DesfireVcsParams_Result",
    "VhlCfg_File_FelicaAreaList_Value_Entry",
    "VhlCfg_File_ForceCardSM_MinimumSM",
    "VhlCfg_File_ForceCardSM_MinimumSM_Parser",
    "VhlCfg_File_IntIndFileDescList_Value_Entry",
    "VhlCfg_File_IntIndKeyIdx_Result",
    "VhlCfg_File_IntIndOnReadSelectOnly_Value",
    "VhlCfg_File_IntIndOnReadSelectOnly_Value_Parser",
    "VhlCfg_File_IntIndSegment_Result",
    "VhlCfg_File_Iso15BlockList_Value_Entry",
    "VhlCfg_File_Iso15ExtendedBlockList_Value_Entry",
    "VhlCfg_File_Iso15ReadCmd_Value",
    "VhlCfg_File_Iso15ReadCmd_Value_Parser",
    "VhlCfg_File_Iso15WriteCmd_Value",
    "VhlCfg_File_Iso15WriteCmd_Value_Parser",
    "VhlCfg_File_Iso15WriteOptFlag_Value",
    "VhlCfg_File_Iso15WriteOptFlag_Value_Parser",
    "VhlCfg_File_LegicApplicationSegmentList_Value_Entry",
    "VhlCfg_File_LegicCtcFileSystemList_FileSystem",
    "VhlCfg_File_LegicCtcFileSystemList_FileSystem_Parser",
    "VhlCfg_File_LegicKeyList_KeyType",
    "VhlCfg_File_LegicKeyList_KeyType_Parser",
    "VhlCfg_File_LegicKeyList_Value_Entry",
    "VhlCfg_File_LegicMasterTokenZoneList_MtZone",
    "VhlCfg_File_LegicMasterTokenZoneList_MtZone_Parser",
    "VhlCfg_File_LegicSegmentListLegacy_Value_Entry",
    "VhlCfg_File_LegicSegmentTypeList_SegType",
    "VhlCfg_File_LegicSegmentTypeList_SegType_Parser",
    "VhlCfg_File_MifareClassicFormatOriginalKeyList_AuthenticationKeyAssignment",
    "VhlCfg_File_MifareClassicFormatOriginalKeyList_AuthenticationKeyAssignment_Parser",
    "VhlCfg_File_MifareClassicFormatOriginalKeyList_Value_Entry",
    "VhlCfg_File_MifareKeyList_Value_Entry",
    "VhlCfg_File_MifareMode_AccessMode",
    "VhlCfg_File_MifareMode_AccessMode_Parser",
    "VhlCfg_File_MifarePlusAesKeyList_Value_Entry",
    "VhlCfg_File_MifarePlusCommunicationMode_Result",
    "VhlCfg_File_MifarePlusKeyAssignment_Value_Entry",
    "VhlCfg_File_MifarePlusMadKeyBIndex_Result",
    "VhlCfg_File_MifarePlusProxyimityCheck_Result",
    "VhlCfg_File_MifareTransferToSecureMemory_TransferKeys",
    "VhlCfg_File_MifareTransferToSecureMemory_TransferKeys_Parser",
    "VhlCfg_File_MifareVcsParams_Result",
    "VhlCfg_File_UltralightExtendedBlockList_Value_Entry",
    "VhlCfg_File_UltralightKeyList_Value_Entry",
    "VirtualLedDefinition",
    "VirtualLedDefinition_Dict",
    "VirtualLedDefinition_Mode",
    "VirtualLedDefinition_Mode_Dict",
    "VirtualLedDefinition_PhysicalLedSelection",
    "VirtualLedDefinition_PhysicalLedSelection_Parser",
]