from brp_lib import UsbHid, RS232, SecureChannel, get_brp_lib_path, set_brp_lib_path, BrpStack

from . import _public
from ._public import *
from ._public import PublicCommands as Commands, PublicConfigAccessor as ConfigAccessor
from ._config import BaseConfig, ConfDict

__all__ = [
    "Brp",
    "Config",
    "ConfDict",
    # brp_lib
    "UsbHid",
    "RS232",
    "SecureChannel",
    "get_brp_lib_path",
    "set_brp_lib_path",
    # re-exports
    "Commands",
    "ConfigAccessor",
    *_public.__all__,

]


class Brp(BrpStack, Commands):
    """Brp with public commands only."""
    pass


class Config(BaseConfig, ConfigAccessor):
    """Config with public configuration values."""
    pass
