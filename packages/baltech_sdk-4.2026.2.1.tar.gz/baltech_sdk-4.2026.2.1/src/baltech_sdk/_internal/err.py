
from ..generator_interface import DeviceError
from .._public.err import *
class ASKCommandGroupError(DeviceError):
    ErrorCode = 0x00013600
    URL = "https://docs.baltech.de/refman/cmds/ask/index.html"
class ASK_ErrAskNoTag(ASKCommandGroupError):
    """
    No Tag.
    """
    ErrorCode = 0x00013601
    URL = "https://docs.baltech.de/refman/cmds/ask/index.html#ASK.ErrAskNoTag"
class ASK_ErrAskRxdata(ASKCommandGroupError):
    """
    Wrong length or wrong data.
    """
    ErrorCode = 0x00013603
    URL = "https://docs.baltech.de/refman/cmds/ask/index.html#ASK.ErrAskRxdata"
class ASK_ErrAskParity(ASKCommandGroupError):
    """
    Parity error.
    """
    ErrorCode = 0x00013605
    URL = "https://docs.baltech.de/refman/cmds/ask/index.html#ASK.ErrAskParity"
class ASK_ErrAskParam(ASKCommandGroupError):
    """
    Wrong command param (on HF).
    """
    ErrorCode = 0x00013607
    URL = "https://docs.baltech.de/refman/cmds/ask/index.html#ASK.ErrAskParam"
class ASK_ErrAskHfreqctrl(ASKCommandGroupError):
    """
    Another task requested control over HF via hf_request_control.
    """
    ErrorCode = 0x00013608
    URL = "https://docs.baltech.de/refman/cmds/ask/index.html#ASK.ErrAskHfreqctrl"
class ASK_ErrAskHw(ASKCommandGroupError):
    """
    Missing Platform ID or Readerchip error.
    """
    ErrorCode = 0x00013609
    URL = "https://docs.baltech.de/refman/cmds/ask/index.html#ASK.ErrAskHw"
class ASK_ErrAskHwNotSupported(ASKCommandGroupError):
    """
    Hardware not supported.
    """
    ErrorCode = 0x0001360B
    URL = "https://docs.baltech.de/refman/cmds/ask/index.html#ASK.ErrAskHwNotSupported"
class CardEmuCommandGroupError(DeviceError):
    ErrorCode = 0x00014700
    URL = "https://docs.baltech.de/refman/cmds/cardemu/index.html"
class CardEmu_CardemuErrNoTag(CardEmuCommandGroupError):
    """
    No tag error.
    """
    ErrorCode = 0x00014701
    URL = "https://docs.baltech.de/refman/cmds/cardemu/index.html#CardEmu.CardemuErrNoTag"
class CardEmu_CardemuErrCollision(CardEmuCommandGroupError):
    """
    Collision occurred (status value will be stored with bit position of collision in high nibble).
    """
    ErrorCode = 0x00014702
    URL = "https://docs.baltech.de/refman/cmds/cardemu/index.html#CardEmu.CardemuErrCollision"
class CardEmu_CardemuErrHf(CardEmuCommandGroupError):
    """
    General HF error.
    """
    ErrorCode = 0x00014704
    URL = "https://docs.baltech.de/refman/cmds/cardemu/index.html#CardEmu.CardemuErrHf"
class CardEmu_CardemuErrFrame(CardEmuCommandGroupError):
    """
    Bit error, parity error or frame error (start /stop bit).
    """
    ErrorCode = 0x00014707
    URL = "https://docs.baltech.de/refman/cmds/cardemu/index.html#CardEmu.CardemuErrFrame"
class CardEmu_CardemuErrCrc(CardEmuCommandGroupError):
    """
    CRC checksum error.
    """
    ErrorCode = 0x00014708
    URL = "https://docs.baltech.de/refman/cmds/cardemu/index.html#CardEmu.CardemuErrCrc"
class CardEmu_CardemuErrCom(CardEmuCommandGroupError):
    """
    Communication error uC - reader chip.
    """
    ErrorCode = 0x00014710
    URL = "https://docs.baltech.de/refman/cmds/cardemu/index.html#CardEmu.CardemuErrCom"
class CardEmu_CardemuErrBuflen(CardEmuCommandGroupError):
    """
    Remaining data in FIFO / FIFO overflow.
    """
    ErrorCode = 0x00014711
    URL = "https://docs.baltech.de/refman/cmds/cardemu/index.html#CardEmu.CardemuErrBuflen"
class CardEmu_CardemuErrTimeout(CardEmuCommandGroupError):
    """
    Timeout occurred while waiting for card / APDU command.
    """
    ErrorCode = 0x0001473F
    URL = "https://docs.baltech.de/refman/cmds/cardemu/index.html#CardEmu.CardemuErrTimeout"
class DbgCommandGroupError(DeviceError):
    ErrorCode = 0x0001F300
    URL = "https://docs.baltech.de/refman/cmds/dbg/index.html"
class Dbg_DbgErrBusy(DbgCommandGroupError):
    """
    Still processing last command.
    """
    ErrorCode = 0x0001F301
    URL = "https://docs.baltech.de/refman/cmds/dbg/index.html#Dbg.DbgErrBusy"
class EMCommandGroupError(DeviceError):
    ErrorCode = 0x00013100
    URL = "https://docs.baltech.de/refman/cmds/em/index.html"
class EM_ErrEmNoTag(EMCommandGroupError):
    """
    No tag error.
    """
    ErrorCode = 0x00013101
    URL = "https://docs.baltech.de/refman/cmds/em/index.html#EM.ErrEmNoTag"
class EM_ErrEmRxdata(EMCommandGroupError):
    """
    Wrong length or wrong data.
    """
    ErrorCode = 0x00013103
    URL = "https://docs.baltech.de/refman/cmds/em/index.html#EM.ErrEmRxdata"
class EM_ErrEmChecksum(EMCommandGroupError):
    """
    Receive checksum error.
    """
    ErrorCode = 0x00013104
    URL = "https://docs.baltech.de/refman/cmds/em/index.html#EM.ErrEmChecksum"
class EM_ErrEmParity(EMCommandGroupError):
    """
    Receive parity error.
    """
    ErrorCode = 0x00013105
    URL = "https://docs.baltech.de/refman/cmds/em/index.html#EM.ErrEmParity"
class EM_EmCmdError(EMCommandGroupError):
    """
    Error detected during command execution.
    """
    ErrorCode = 0x00013106
    URL = "https://docs.baltech.de/refman/cmds/em/index.html#EM.EmCmdError"
class EM_EmTagtypeNotDetected(EMCommandGroupError):
    """
    Unknown tag type or modulation not detected.
    """
    ErrorCode = 0x00013107
    URL = "https://docs.baltech.de/refman/cmds/em/index.html#EM.EmTagtypeNotDetected"
class EM_ErrEmOvTo(EMCommandGroupError):
    """
    ISR buffer overflow during send/receive, TO during send.
    """
    ErrorCode = 0x00013108
    URL = "https://docs.baltech.de/refman/cmds/em/index.html#EM.ErrEmOvTo"
class EM_EmParamError(EMCommandGroupError):
    """
    Host command parameter error.
    """
    ErrorCode = 0x00013109
    URL = "https://docs.baltech.de/refman/cmds/em/index.html#EM.EmParamError"
class EM_ErrEmHfreqctrl(EMCommandGroupError):
    """
    Another task requested control over HF via hf_request_control.
    """
    ErrorCode = 0x0001310A
    URL = "https://docs.baltech.de/refman/cmds/em/index.html#EM.ErrEmHfreqctrl"
class EM_ErrEmHw(EMCommandGroupError):
    """
    Missing Platform ID or Readerchip error.
    """
    ErrorCode = 0x0001310B
    URL = "https://docs.baltech.de/refman/cmds/em/index.html#EM.ErrEmHw"
class EM_ErrEmHwNotSupported(EMCommandGroupError):
    """
    Hardware not supported.
    """
    ErrorCode = 0x0001310D
    URL = "https://docs.baltech.de/refman/cmds/em/index.html#EM.ErrEmHwNotSupported"
class EthCommandGroupError(DeviceError):
    ErrorCode = 0x00014500
    URL = "https://docs.baltech.de/refman/cmds/eth/index.html"
class Eth_ErrNoResultYet(EthCommandGroupError):
    """
    No result yet.
    """
    ErrorCode = 0x00014501
    URL = "https://docs.baltech.de/refman/cmds/eth/index.html#Eth.ErrNoResultYet"
class Eth_ErrNotConnected(EthCommandGroupError):
    """
    Port is not connected.
    """
    ErrorCode = 0x00014502
    URL = "https://docs.baltech.de/refman/cmds/eth/index.html#Eth.ErrNotConnected"
class Eth_ErrDisabled(EthCommandGroupError):
    """
    Detection is disabled.
    """
    ErrorCode = 0x00014503
    URL = "https://docs.baltech.de/refman/cmds/eth/index.html#Eth.ErrDisabled"
class Felica_ErrFelicaHwNotSupported(FelicaCommandGroupError):
    """
    Command not supported by hardware.
    """
    ErrorCode = 0x00011C23
    URL = "https://docs.baltech.de/refman/cmds/felica/index.html#Felica.ErrFelicaHwNotSupported"
class HIDCommandGroupError(DeviceError):
    ErrorCode = 0x00013300
    URL = "https://docs.baltech.de/refman/cmds/hid/index.html"
class HID_ErrHidNoTag(HIDCommandGroupError):
    """
    No tag error.
    """
    ErrorCode = 0x00013301
    URL = "https://docs.baltech.de/refman/cmds/hid/index.html#HID.ErrHidNoTag"
class HID_ErrHidRxdata(HIDCommandGroupError):
    """
    Wrong length or wrong data.
    """
    ErrorCode = 0x00013303
    URL = "https://docs.baltech.de/refman/cmds/hid/index.html#HID.ErrHidRxdata"
class HID_ErrHidParity(HIDCommandGroupError):
    """
    Parity error.
    """
    ErrorCode = 0x00013305
    URL = "https://docs.baltech.de/refman/cmds/hid/index.html#HID.ErrHidParity"
class HID_ErrHidParam(HIDCommandGroupError):
    """
    Wrong command param (on HF).
    """
    ErrorCode = 0x00013307
    URL = "https://docs.baltech.de/refman/cmds/hid/index.html#HID.ErrHidParam"
class HID_ErrHidHfreqctrl(HIDCommandGroupError):
    """
    Another task requested control over HF via hf_request_control.
    """
    ErrorCode = 0x00013308
    URL = "https://docs.baltech.de/refman/cmds/hid/index.html#HID.ErrHidHfreqctrl"
class HID_ErrHidHw(HIDCommandGroupError):
    """
    Reader chip hardware error.
    """
    ErrorCode = 0x00013309
    URL = "https://docs.baltech.de/refman/cmds/hid/index.html#HID.ErrHidHw"
class HID_ErrHidHwNotSupported(HIDCommandGroupError):
    """
    Hardware not supported.
    """
    ErrorCode = 0x0001330B
    URL = "https://docs.baltech.de/refman/cmds/hid/index.html#HID.ErrHidHwNotSupported"
class HID_ErrLicense(HIDCommandGroupError):
    """
    You use an HID Prox/Indala/Keri card, but the reader doesn't have the [required Prox license](https://docs.baltech.de/project-setup/get-prox-license-for-hid-prox-indala-keri.html).
    """
    ErrorCode = 0x0001330C
    URL = "https://docs.baltech.de/refman/cmds/hid/index.html#HID.ErrLicense"
class HitagCommandGroupError(DeviceError):
    ErrorCode = 0x00013000
    URL = "https://docs.baltech.de/refman/cmds/hitag/index.html"
class Hitag_ErrHtgNoTag(HitagCommandGroupError):
    """
    No tag error.
    """
    ErrorCode = 0x00013001
    URL = "https://docs.baltech.de/refman/cmds/hitag/index.html#Hitag.ErrHtgNoTag"
class Hitag_ErrHtgCollision(HitagCommandGroupError):
    """
    Collision occurred.
    """
    ErrorCode = 0x00013002
    URL = "https://docs.baltech.de/refman/cmds/hitag/index.html#Hitag.ErrHtgCollision"
class Hitag_ErrHtgRxdata(HitagCommandGroupError):
    """
    Wrong length or wrong data.
    """
    ErrorCode = 0x00013003
    URL = "https://docs.baltech.de/refman/cmds/hitag/index.html#Hitag.ErrHtgRxdata"
class Hitag_HtgChecksum(HitagCommandGroupError):
    """
    Receive checksum error.
    """
    ErrorCode = 0x00013004
    URL = "https://docs.baltech.de/refman/cmds/hitag/index.html#Hitag.HtgChecksum"
class Hitag_HtgWrongParam(HitagCommandGroupError):
    """
    Wrong command parameter.
    """
    ErrorCode = 0x00013007
    URL = "https://docs.baltech.de/refman/cmds/hitag/index.html#Hitag.HtgWrongParam"
class Hitag_ErrHtgAuth(HitagCommandGroupError):
    """
    Authentication error.
    """
    ErrorCode = 0x00013009
    URL = "https://docs.baltech.de/refman/cmds/hitag/index.html#Hitag.ErrHtgAuth"
class Hitag_ErrHtgOvTo(HitagCommandGroupError):
    """
    ISR buffer overflow during send/receive, TO during send.
    """
    ErrorCode = 0x00013008
    URL = "https://docs.baltech.de/refman/cmds/hitag/index.html#Hitag.ErrHtgOvTo"
class Hitag_ErrHtgHw(HitagCommandGroupError):
    """
    Reader chip HW error.
    """
    ErrorCode = 0x0001300A
    URL = "https://docs.baltech.de/refman/cmds/hitag/index.html#Hitag.ErrHtgHw"
class Hitag_ErrHtgCr(HitagCommandGroupError):
    """
    Crypt processor HW error.
    """
    ErrorCode = 0x0001300B
    URL = "https://docs.baltech.de/refman/cmds/hitag/index.html#Hitag.ErrHtgCr"
class Hitag_ErrHtgCfg(HitagCommandGroupError):
    """
    Update of configuration not successful.
    """
    ErrorCode = 0x0001300C
    URL = "https://docs.baltech.de/refman/cmds/hitag/index.html#Hitag.ErrHtgCfg"
class Hitag_ErrHtgHfreqctrl(HitagCommandGroupError):
    """
    Another task requested control over HF via hf_request_control.
    """
    ErrorCode = 0x0001300D
    URL = "https://docs.baltech.de/refman/cmds/hitag/index.html#Hitag.ErrHtgHfreqctrl"
class Hitag_ErrHtgHwNotSupported(HitagCommandGroupError):
    """
    Hardware not supported.
    """
    ErrorCode = 0x0001300F
    URL = "https://docs.baltech.de/refman/cmds/hitag/index.html#Hitag.ErrHtgHwNotSupported"
class I2cCommandGroupError(DeviceError):
    ErrorCode = 0x00010800
    URL = "https://docs.baltech.de/refman/cmds/i2c/index.html"
class I2c_ErrI2CRead(I2cCommandGroupError):
    """
    Error reading from I2C interface.
    """
    ErrorCode = 0x00010801
    URL = "https://docs.baltech.de/refman/cmds/i2c/index.html#I2c.ErrI2CRead"
class I2c_ErrI2CWrite(I2cCommandGroupError):
    """
    Error writing to I2C interface.
    """
    ErrorCode = 0x00010802
    URL = "https://docs.baltech.de/refman/cmds/i2c/index.html#I2c.ErrI2CWrite"
class Iso14a_ErrKey(Iso14aCommandGroupError):
    """
    Key error (Only triggered by Mifare authentication).
    """
    ErrorCode = 0x00011306
    URL = "https://docs.baltech.de/refman/cmds/iso14a/index.html#Iso14a.ErrKey"
class Iso14a_ErrEeprom(Iso14aCommandGroupError):
    """
    Error accessing EEPROM of the reader chip.
    """
    ErrorCode = 0x00011321
    URL = "https://docs.baltech.de/refman/cmds/iso14a/index.html#Iso14a.ErrEeprom"
class Iso14a_ErrCardNotSupported(Iso14aCommandGroupError):
    """
    Reader chip does not support card type.
    """
    ErrorCode = 0x00011322
    URL = "https://docs.baltech.de/refman/cmds/iso14a/index.html#Iso14a.ErrCardNotSupported"
class Iso14a_ErrHwNotSupported(Iso14aCommandGroupError):
    """
    Command not supported by hardware.
    """
    ErrorCode = 0x00011323
    URL = "https://docs.baltech.de/refman/cmds/iso14a/index.html#Iso14a.ErrHwNotSupported"
class Iso14a_BreakErr(Iso14aCommandGroupError):
    """
    Command has been interrupted.
    """
    ErrorCode = 0x00011330
    URL = "https://docs.baltech.de/refman/cmds/iso14a/index.html#Iso14a.BreakErr"
class Iso14b_ErrAuth(Iso14bCommandGroupError):
    """
    Authentication error.
    """
    ErrorCode = 0x00011403
    URL = "https://docs.baltech.de/refman/cmds/iso14b/index.html#Iso14b.ErrAuth"
class Iso14b_ErrCrc(Iso14bCommandGroupError):
    """
    CRC checksum error.
    """
    ErrorCode = 0x00011408
    URL = "https://docs.baltech.de/refman/cmds/iso14b/index.html#Iso14b.ErrCrc"
class Iso14b_ErrEeprom(Iso14bCommandGroupError):
    """
    Error accessing EEPROM of the reader chip.
    """
    ErrorCode = 0x00011421
    URL = "https://docs.baltech.de/refman/cmds/iso14b/index.html#Iso14b.ErrEeprom"
class Iso14b_ErrCardNotSupported(Iso14bCommandGroupError):
    """
    Reader chip does not support card type.
    """
    ErrorCode = 0x00011422
    URL = "https://docs.baltech.de/refman/cmds/iso14b/index.html#Iso14b.ErrCardNotSupported"
class Iso14b_ErrHwNotSupported(Iso14bCommandGroupError):
    """
    Command not supported by hardware.
    """
    ErrorCode = 0x00011424
    URL = "https://docs.baltech.de/refman/cmds/iso14b/index.html#Iso14b.ErrHwNotSupported"
class Iso14CECommandGroupError(DeviceError):
    ErrorCode = 0x00014A00
    URL = "https://docs.baltech.de/refman/cmds/iso14ce/index.html"
class Iso14CE_ErrIso144State(Iso14CECommandGroupError):
    """
    Emulated PICC currently not in the proper state to exchange ISO14443-4 APDUs (PCD didn't activate the protocol) 
    
    Card emulation has to be restarted.
    """
    ErrorCode = 0x00014A01
    URL = "https://docs.baltech.de/refman/cmds/iso14ce/index.html#Iso14CE.ErrIso144State"
class Iso14CE_ErrCom(Iso14CECommandGroupError):
    """
    Communication problem between microcontroller and reader chip.
    """
    ErrorCode = 0x00014A02
    URL = "https://docs.baltech.de/refman/cmds/iso14ce/index.html#Iso14CE.ErrCom"
class Iso14CE_ErrTransmission(Iso14CECommandGroupError):
    """
    HF transmission error (e.g. CRC, framing,...).
    """
    ErrorCode = 0x00014A03
    URL = "https://docs.baltech.de/refman/cmds/iso14ce/index.html#Iso14CE.ErrTransmission"
class Iso14CE_ErrTimeout(Iso14CECommandGroupError):
    """
    Timeout: no APDU was received from the PCD within the specified time.
    """
    ErrorCode = 0x00014A04
    URL = "https://docs.baltech.de/refman/cmds/iso14ce/index.html#Iso14CE.ErrTimeout"
class Iso14CE_ErrOverflow(Iso14CECommandGroupError):
    """
    Buffer overflow: the PCD sent more data than the receive buffer of the emulated PICC can handle.
    """
    ErrorCode = 0x00014A05
    URL = "https://docs.baltech.de/refman/cmds/iso14ce/index.html#Iso14CE.ErrOverflow"
class Iso14CE_ErrInternal(Iso14CECommandGroupError):
    """
    Internal error - should never occur.
    """
    ErrorCode = 0x00014A06
    URL = "https://docs.baltech.de/refman/cmds/iso14ce/index.html#Iso14CE.ErrInternal"
class Iso14CE_ErrDeselect(Iso14CECommandGroupError):
    """
    PICC has been deselected.
    """
    ErrorCode = 0x00014A07
    URL = "https://docs.baltech.de/refman/cmds/iso14ce/index.html#Iso14CE.ErrDeselect"
class Iso15_ErrCmd(Iso15CommandGroupError):
    """
    Command and/or parameters invalid.
    """
    ErrorCode = 0x00012120
    URL = "https://docs.baltech.de/refman/cmds/iso15/index.html#Iso15.ErrCmd"
class Iso15_ErrHwNotSupported(Iso15CommandGroupError):
    """
    Command not supported by hardware.
    """
    ErrorCode = 0x00012126
    URL = "https://docs.baltech.de/refman/cmds/iso15/index.html#Iso15.ErrHwNotSupported"
class LegicCommandGroupError(DeviceError):
    ErrorCode = 0x00011E00
    URL = "https://docs.baltech.de/refman/cmds/legic/index.html"
class Legic_ErrCommunication(LegicCommandGroupError):
    """
    Communication error. 
    
    Command could not be executed successfully due to a error in the communication of the reader controller with the LEGIC chip (e.g. checksum error, internal timeout error). It is recommended to repeat the command.
    """
    ErrorCode = 0x00011E01
    URL = "https://docs.baltech.de/refman/cmds/legic/index.html#Legic.ErrCommunication"
class Legic_ErrNotInitialized(LegicCommandGroupError):
    """
    LEGIC support is not initialized yet. 
    
    After powering up, the LEGIC chip normally needs several 100 milliseconds until it is ready to execute commands. As long as the reader returns this status code the command needs to be repeated. 
    
    If the LEGIC chip is still not available 3.5 seconds after the reader has powered up, usually due to a hardware defect, the _Rf13MHzLegic_ boot status of the Baltech reader will be set (The Baltech reader boot status can be read using the Sys.GetBootStatus command).
    """
    ErrorCode = 0x00011E02
    URL = "https://docs.baltech.de/refman/cmds/legic/index.html#Legic.ErrNotInitialized"
class Legic_ErrNotAssembled(LegicCommandGroupError):
    """
    No appropriate LEGIC reader chip is assembled on this hardware. 
    
    This reader device doesn't support LEGIC or doesn't contain the required LEGIC reader chip to execute the called command. Please check the model number.
    """
    ErrorCode = 0x00011E03
    URL = "https://docs.baltech.de/refman/cmds/legic/index.html#Legic.ErrNotAssembled"
class LgaCommandGroupError(DeviceError):
    ErrorCode = 0x00011200
    URL = "https://docs.baltech.de/refman/cmds/lga/index.html"
class Lga_ErrNotag(LgaCommandGroupError):
    """
    No LEGIC Advant/Prime card found in the reader's HF field or communication with card lost.
    """
    ErrorCode = 0x00011201
    URL = "https://docs.baltech.de/refman/cmds/lga/index.html#Lga.ErrNotag"
class Lga_ErrLegic(LgaCommandGroupError):
    """
    The LEGIC reader chip returned an error code. 
    
    The LEGIC reader reported an error that occurred during command execution. The actual LEGIC status code appears in the response parameter.
    """
    ErrorCode = 0x00011202
    URL = "https://docs.baltech.de/refman/cmds/lga/index.html#Lga.ErrLegic"
class Lga_ErrCommunication(LgaCommandGroupError):
    """
    Communication error. 
    
    Command could not be executed successfully due to a error in the communication of the reader controller with the LEGIC chip (e.g. checksum error, internal timeout error). It is recommended to repeat the command.
    """
    ErrorCode = 0x00011203
    URL = "https://docs.baltech.de/refman/cmds/lga/index.html#Lga.ErrCommunication"
class Lga_ErrNotInitialized(LgaCommandGroupError):
    """
    LEGIC support is not initialized yet. 
    
    After powering up, the LEGIC chip normally needs several 100 milliseconds until it is ready to execute commands. As long as the reader returns this status code the command needs to be repeated. 
    
    If the LEGIC chip is still not available 3.5 seconds after the reader has powered up, usually due to a hardware defect, the _Rf13MHzLegic_ boot status of the Baltech reader will be set (The Baltech reader boot status can be read using the Sys.GetBootStatus command).
    """
    ErrorCode = 0x00011204
    URL = "https://docs.baltech.de/refman/cmds/lga/index.html#Lga.ErrNotInitialized"
class Lga_ErrNotAssembled(LgaCommandGroupError):
    """
    No LEGIC reader chip is assembled on this hardware. 
    
    This reader device doesn't support LEGIC. Please check the model number.
    """
    ErrorCode = 0x00011205
    URL = "https://docs.baltech.de/refman/cmds/lga/index.html#Lga.ErrNotAssembled"
class Main_ErrOutdatedFirmware(MainCommandGroupError):
    """
    Is returned by isFirmwareUpToDate() if the following piece of firmware is not up to date.
    """
    ErrorCode = 0x0001F001
    URL = "https://docs.baltech.de/refman/cmds/main/index.html#Main.ErrOutdatedFirmware"
class Main_ErrUnknownVersion(MainCommandGroupError):
    """
    Is returned by isFirmwareUpToDate() if it's unknown whether the following piece of firmware is outdated or not.
    """
    ErrorCode = 0x0001F002
    URL = "https://docs.baltech.de/refman/cmds/main/index.html#Main.ErrUnknownVersion"
class MceCommandGroupError(DeviceError):
    ErrorCode = 0x00014D00
    URL = "https://docs.baltech.de/refman/cmds/mce/index.html"
class Mce_ErrNoTag(MceCommandGroupError):
    """
    No valid MCE device is currently presented to the reader.
    """
    ErrorCode = 0x00014D01
    URL = "https://docs.baltech.de/refman/cmds/mce/index.html#Mce.ErrNoTag"
class Mce_ErrDisabled(MceCommandGroupError):
    """
    MCE functionality is currently disabled.
    """
    ErrorCode = 0x00014D03
    URL = "https://docs.baltech.de/refman/cmds/mce/index.html#Mce.ErrDisabled"
class Mce_ErrLicense(MceCommandGroupError):
    """
    A valid BLE license is required, but not available.
    """
    ErrorCode = 0x00014D04
    URL = "https://docs.baltech.de/refman/cmds/mce/index.html#Mce.ErrLicense"
class Mif_ErrCrc(MifCommandGroupError):
    """
    The response frame is invalid, e.g. it may contain an invalid CRC checksum. Please rerun the command.
    """
    ErrorCode = 0x00011002
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrCrc"
class Mif_ErrSnr(MifCommandGroupError):
    """
    Legacy error code: The serial number is wrong.
    """
    ErrorCode = 0x00011008
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrSnr"
class Mif_ErrWrite(MifCommandGroupError):
    """
    Writing to the card has failed. Please rerun the command or check the access conditions.
    """
    ErrorCode = 0x0001100F
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrWrite"
class Mif_ErrInc(MifCommandGroupError):
    """
    Legacy error code: Increment couldn't be performed.
    """
    ErrorCode = 0x00011010
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrInc"
class Mif_ErrDecr(MifCommandGroupError):
    """
    Legacy error code: Decrement couldn't be performed.
    """
    ErrorCode = 0x00011011
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrDecr"
class Mif_ErrRead(MifCommandGroupError):
    """
    Reading data from the card has failed. Please rerun the command or check the access conditions.
    """
    ErrorCode = 0x00011012
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrRead"
class Mif_ErrOvfl(MifCommandGroupError):
    """
    Legacy error code: An overflow occurred during decrement or increment.
    """
    ErrorCode = 0x00011013
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrOvfl"
class Mif_ErrBreak(MifCommandGroupError):
    """
    The command has been aborted because the HF interface has been requested by another task or command. Please reselect the card. 
    
    **This error only occurs when you combine VHL and low-level commands. We highly recommend you avoid that combination as these 2 command sets will interfere with each other's card states.**
    """
    ErrorCode = 0x00011016
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrBreak"
class Mif_ErrReaderChipCommunication(MifCommandGroupError):
    """
    Communication with the reader's HF interface has failed. Please reset the HF interface with Sys.HFReset and check the reader status with Sys.GetBootStatus.
    """
    ErrorCode = 0x0001101A
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrReaderChipCommunication"
class Mif_ErrFirmwareNotSupported(MifCommandGroupError):
    """
    This command isn't supported by the reader firmware.
    """
    ErrorCode = 0x0001101D
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrFirmwareNotSupported"
class Mif_ErrVal(MifCommandGroupError):
    """
    A value operation, e.g. increment or decrement, has failed. This may have several reasons, e.g. an invalid value format, or the value to manipulate doesn't exist on the card.
    """
    ErrorCode = 0x0001101E
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrVal"
class Mif_ErrIntegrity(MifCommandGroupError):
    """
    Secure messaging error: The CRC or MAC checksum doesn't match the transmitted data. Authentication has been lost. Please reauthenticate and rerun the commands, or check the security conditions.
    """
    ErrorCode = 0x0001101F
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrIntegrity"
class Mif_ErrHwNotSupported(MifCommandGroupError):
    """
    This command isn't supported by the reader hardware, i.e. by the SAM or reader chip.
    """
    ErrorCode = 0x00011021
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrHwNotSupported"
class Mif_ErrSamUnlock(MifCommandGroupError):
    """
    Unlocking/authenticating with the SAM has failed. Please check the SamAVx configuration values.
    """
    ErrorCode = 0x00011022
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrSamUnlock"
class Mif_ErrSamCommunication(MifCommandGroupError):
    """
    Communication with the SAM has failed. This may have several reasons, e.g. the wrong SAM type or a failure to activate the SAM. Please check the SAM status and reset the reader with Sys.Reset.
    """
    ErrorCode = 0x00011023
    URL = "https://docs.baltech.de/refman/cmds/mif/index.html#Mif.ErrSamCommunication"
class PicoCommandGroupError(DeviceError):
    ErrorCode = 0x00011A00
    URL = "https://docs.baltech.de/refman/cmds/pico/index.html"
class Pico_ErrNoTag(PicoCommandGroupError):
    """
    No PICC
    """
    ErrorCode = 0x00011A01
    URL = "https://docs.baltech.de/refman/cmds/pico/index.html#Pico.ErrNoTag"
class Pico_ErrCollision(PicoCommandGroupError):
    """
    Collision occurred (value will be ordered with bit position of collision in high nibble!)
    """
    ErrorCode = 0x00011A02
    URL = "https://docs.baltech.de/refman/cmds/pico/index.html#Pico.ErrCollision"
class Pico_ErrHf(PicoCommandGroupError):
    """
    General HF error
    """
    ErrorCode = 0x00011A04
    URL = "https://docs.baltech.de/refman/cmds/pico/index.html#Pico.ErrHf"
class Pico_ErrFrame(PicoCommandGroupError):
    """
    Bit error, parity error or frame error (start/stop-bit)
    """
    ErrorCode = 0x00011A07
    URL = "https://docs.baltech.de/refman/cmds/pico/index.html#Pico.ErrFrame"
class Pico_ErrCrc(PicoCommandGroupError):
    """
    CRC checksum error
    """
    ErrorCode = 0x00011A08
    URL = "https://docs.baltech.de/refman/cmds/pico/index.html#Pico.ErrCrc"
class Pico_ErrCom(PicoCommandGroupError):
    """
    Communication error UC - reader chip
    """
    ErrorCode = 0x00011A10
    URL = "https://docs.baltech.de/refman/cmds/pico/index.html#Pico.ErrCom"
class Pico_ErrCardNotSupported(PicoCommandGroupError):
    """
    Reader chip does not support card type
    """
    ErrorCode = 0x00011A22
    URL = "https://docs.baltech.de/refman/cmds/pico/index.html#Pico.ErrCardNotSupported"
class Pico_ErrHwNotSupported(PicoCommandGroupError):
    """
    Command not supported by hardware
    """
    ErrorCode = 0x00011A23
    URL = "https://docs.baltech.de/refman/cmds/pico/index.html#Pico.ErrHwNotSupported"
class PkiCommandGroupError(DeviceError):
    ErrorCode = 0x00010900
    URL = "https://docs.baltech.de/refman/cmds/pki/index.html"
class Pki_ErrCrypto(PkiCommandGroupError):
    """
    Invalid Key used for encryption/MACing or MAC is invalid.
    """
    ErrorCode = 0x00010901
    URL = "https://docs.baltech.de/refman/cmds/pki/index.html#Pki.ErrCrypto"
class Pki_ErrTunnel(PkiCommandGroupError):
    """
    It is not possible to tunnel this command.
    """
    ErrorCode = 0x00010902
    URL = "https://docs.baltech.de/refman/cmds/pki/index.html#Pki.ErrTunnel"
class Pki_ErrCert(PkiCommandGroupError):
    """
    The certificate (or key) has invalid format or signature.
    """
    ErrorCode = 0x00010903
    URL = "https://docs.baltech.de/refman/cmds/pki/index.html#Pki.ErrCert"
class Pki_ErrSeqctr(PkiCommandGroupError):
    """
    The sequence counter was too low.
    """
    ErrorCode = 0x00010904
    URL = "https://docs.baltech.de/refman/cmds/pki/index.html#Pki.ErrSeqctr"
class Pki_ErrSeclevelUnsupported(PkiCommandGroupError):
    """
    This security level has no key for authentication.
    """
    ErrorCode = 0x00010905
    URL = "https://docs.baltech.de/refman/cmds/pki/index.html#Pki.ErrSeclevelUnsupported"
class Pki_ErrSessionTimeout(PkiCommandGroupError):
    """
    The security session timed out.
    """
    ErrorCode = 0x00010906
    URL = "https://docs.baltech.de/refman/cmds/pki/index.html#Pki.ErrSessionTimeout"
class QKeyCommandGroupError(DeviceError):
    ErrorCode = 0x00013500
    URL = "https://docs.baltech.de/refman/cmds/qkey/index.html"
class QKey_ErrQkeyNoTag(QKeyCommandGroupError):
    """
    No tag error.
    """
    ErrorCode = 0x00013501
    URL = "https://docs.baltech.de/refman/cmds/qkey/index.html#QKey.ErrQkeyNoTag"
class QKey_ErrQkeyRxdata(QKeyCommandGroupError):
    """
    Wrong length or wrong data.
    """
    ErrorCode = 0x00013503
    URL = "https://docs.baltech.de/refman/cmds/qkey/index.html#QKey.ErrQkeyRxdata"
class QKey_ErrQkeyParity(QKeyCommandGroupError):
    """
    Parity error.
    """
    ErrorCode = 0x00013505
    URL = "https://docs.baltech.de/refman/cmds/qkey/index.html#QKey.ErrQkeyParity"
class QKey_ErrQkeyParam(QKeyCommandGroupError):
    """
    Wrong command param (on HF).
    """
    ErrorCode = 0x00013507
    URL = "https://docs.baltech.de/refman/cmds/qkey/index.html#QKey.ErrQkeyParam"
class QKey_ErrQkeyHfreqctrl(QKeyCommandGroupError):
    """
    Another task requested control over HF via hf_request_control.
    """
    ErrorCode = 0x00013508
    URL = "https://docs.baltech.de/refman/cmds/qkey/index.html#QKey.ErrQkeyHfreqctrl"
class QKey_ErrQkeyHw(QKeyCommandGroupError):
    """
    Missing Platform ID or Readerchip error.
    """
    ErrorCode = 0x00013509
    URL = "https://docs.baltech.de/refman/cmds/qkey/index.html#QKey.ErrQkeyHw"
class QKey_ErrQkeyHwNotSupported(QKeyCommandGroupError):
    """
    Hardware not supported.
    """
    ErrorCode = 0x0001350B
    URL = "https://docs.baltech.de/refman/cmds/qkey/index.html#QKey.ErrQkeyHwNotSupported"
class RtcCommandGroupError(DeviceError):
    ErrorCode = 0x00010400
    URL = "https://docs.baltech.de/refman/cmds/rtc/index.html"
class Rtc_ErrHardware(RtcCommandGroupError):
    """
    The RTC hardware is defect.
    """
    ErrorCode = 0x00010401
    URL = "https://docs.baltech.de/refman/cmds/rtc/index.html#Rtc.ErrHardware"
class Rtc_ErrVoltageLow(RtcCommandGroupError):
    """
    The battery of the RTC is low. The time may be invalid.
    """
    ErrorCode = 0x00010402
    URL = "https://docs.baltech.de/refman/cmds/rtc/index.html#Rtc.ErrVoltageLow"
class SrixCommandGroupError(DeviceError):
    ErrorCode = 0x00012400
    URL = "https://docs.baltech.de/refman/cmds/srix/index.html"
class Srix_ErrNoTag(SrixCommandGroupError):
    """
    No Tag
    """
    ErrorCode = 0x00012401
    URL = "https://docs.baltech.de/refman/cmds/srix/index.html#Srix.ErrNoTag"
class Srix_ErrFrame(SrixCommandGroupError):
    """
    Frame Error (CRC, parity...)
    """
    ErrorCode = 0x00012403
    URL = "https://docs.baltech.de/refman/cmds/srix/index.html#Srix.ErrFrame"
class Srix_ErrHf(SrixCommandGroupError):
    """
    General hf error
    """
    ErrorCode = 0x00012404
    URL = "https://docs.baltech.de/refman/cmds/srix/index.html#Srix.ErrHf"
class Srix_ErrCom(SrixCommandGroupError):
    """
    Hardware error
    """
    ErrorCode = 0x00012405
    URL = "https://docs.baltech.de/refman/cmds/srix/index.html#Srix.ErrCom"
class Srix_ErrSrixCardtypeNotSupported(SrixCommandGroupError):
    """
    Chip type not supported by reader chip
    """
    ErrorCode = 0x00012406
    URL = "https://docs.baltech.de/refman/cmds/srix/index.html#Srix.ErrSrixCardtypeNotSupported"
class Srix_ErrHwNotSupported(SrixCommandGroupError):
    """
    Hardware does not support reader chip
    """
    ErrorCode = 0x00012407
    URL = "https://docs.baltech.de/refman/cmds/srix/index.html#Srix.ErrHwNotSupported"
class Srix_ErrCmdBreak(SrixCommandGroupError):
    """
    Command has been interrupted
    """
    ErrorCode = 0x00012408
    URL = "https://docs.baltech.de/refman/cmds/srix/index.html#Srix.ErrCmdBreak"
class Sys_ErrRegAccess(SysCommandGroupError):
    """
    Register cannot be modified or doesn't exist.
    """
    ErrorCode = 0x00010006
    URL = "https://docs.baltech.de/refman/cmds/sys/index.html#Sys.ErrRegAccess"
class Sys_ErrCfgConfigSecurityCode(SysCommandGroupError):
    """
    Sys.CfgLoadBlock was run with an invalid Config Security Code, i.e. the configuration you're trying to deploy is not a new version of the existing configuration, but a completely different configuration ([ learn more](https://docs.baltech.de/project-setup/security.html#config-security-code)).
    """
    ErrorCode = 0x0001000A
    URL = "https://docs.baltech.de/refman/cmds/sys/index.html#Sys.ErrCfgConfigSecurityCode"
class Sys_ErrCfgVersion(SysCommandGroupError):
    """
    Sys.CfgLoadBlock was run with a configuration version that is older than the one currently deployed ([ learn more](https://docs.baltech.de/project-setup/security.html#configuration-updates-with-rollback-prevention)).
    """
    ErrorCode = 0x0001000B
    URL = "https://docs.baltech.de/refman/cmds/sys/index.html#Sys.ErrCfgVersion"
class Sys_ErrCfgLoadWrongState(SysCommandGroupError):
    """
    The command can't be run in the current (CfgLoadBlock) state, i.e.  Sys.CfgLoadFinish must be run after  Sys.CfgLoadPrepare.
    """
    ErrorCode = 0x0001000C
    URL = "https://docs.baltech.de/refman/cmds/sys/index.html#Sys.ErrCfgLoadWrongState"
class Sys_ErrInvalidFwCrc(SysCommandGroupError):
    """
    The CRC of the firmware is invalid. This error can only be returned by the Sys.GetFwCrc command.
    """
    ErrorCode = 0x0001007F
    URL = "https://docs.baltech.de/refman/cmds/sys/index.html#Sys.ErrInvalidFwCrc"
class TTFCommandGroupError(DeviceError):
    ErrorCode = 0x00013400
    URL = "https://docs.baltech.de/refman/cmds/ttf/index.html"
class TTF_ErrTtfNoTag(TTFCommandGroupError):
    """
    No tag error.
    """
    ErrorCode = 0x00013401
    URL = "https://docs.baltech.de/refman/cmds/ttf/index.html#TTF.ErrTtfNoTag"
class TTF_ErrTtfRxdata(TTFCommandGroupError):
    """
    Wrong length or wrong data.
    """
    ErrorCode = 0x00013403
    URL = "https://docs.baltech.de/refman/cmds/ttf/index.html#TTF.ErrTtfRxdata"
class TTF_ErrTtfParam(TTFCommandGroupError):
    """
    Wrong cmd param.
    """
    ErrorCode = 0x00013407
    URL = "https://docs.baltech.de/refman/cmds/ttf/index.html#TTF.ErrTtfParam"
class TTF_ErrTtfOvTo(TTFCommandGroupError):
    """
    ISR buffer overflow during receive.
    """
    ErrorCode = 0x00013408
    URL = "https://docs.baltech.de/refman/cmds/ttf/index.html#TTF.ErrTtfOvTo"
class TTF_ErrTtfHfreqctrl(TTFCommandGroupError):
    """
    Another task requested control over HF via hf_request_control.
    """
    ErrorCode = 0x00013409
    URL = "https://docs.baltech.de/refman/cmds/ttf/index.html#TTF.ErrTtfHfreqctrl"
class TTF_ErrTtfHw(TTFCommandGroupError):
    """
    Platform ID missing or hardware error.
    """
    ErrorCode = 0x0001340A
    URL = "https://docs.baltech.de/refman/cmds/ttf/index.html#TTF.ErrTtfHw"
class TTF_ErrTtfHwNotSupported(TTFCommandGroupError):
    """
    Hardware not supported.
    """
    ErrorCode = 0x0001340C
    URL = "https://docs.baltech.de/refman/cmds/ttf/index.html#TTF.ErrTtfHwNotSupported"
class Ultralight_ErrFirmwareNotSupported(UltralightCommandGroupError):
    """
    This command isn't supported by the reader firmware.
    """
    ErrorCode = 0x00012521
    URL = "https://docs.baltech.de/refman/cmds/ultralight/index.html#Ultralight.ErrFirmwareNotSupported"
class UsbHostCommandGroupError(DeviceError):
    ErrorCode = 0x00014400
    URL = "https://docs.baltech.de/refman/cmds/usbhost/index.html"
class UsbHost_UsbhstErrNotconnected(UsbHostCommandGroupError):
    """
    No device connected.
    """
    ErrorCode = 0x00014401
    URL = "https://docs.baltech.de/refman/cmds/usbhost/index.html#UsbHost.UsbhstErrNotconnected"
class UsbHost_UsbhstErrTimeout(UsbHostCommandGroupError):
    """
    Device did not respond within Timeout.
    """
    ErrorCode = 0x00014402
    URL = "https://docs.baltech.de/refman/cmds/usbhost/index.html#UsbHost.UsbhstErrTimeout"
class UsbHost_UsbhstErrNack(UsbHostCommandGroupError):
    """
    Device responded only with NACK within Timeout.
    """
    ErrorCode = 0x00014403
    URL = "https://docs.baltech.de/refman/cmds/usbhost/index.html#UsbHost.UsbhstErrNack"
class UsbHost_UsbhstErrStall(UsbHostCommandGroupError):
    """
    Device responded with STALL.
    """
    ErrorCode = 0x00014404
    URL = "https://docs.baltech.de/refman/cmds/usbhost/index.html#UsbHost.UsbhstErrStall"
class UsbHost_UsbhstErrTransfer(UsbHostCommandGroupError):
    """
    Error on transferring data (CRC, Invalid PID, ...).
    """
    ErrorCode = 0x00014405
    URL = "https://docs.baltech.de/refman/cmds/usbhost/index.html#UsbHost.UsbhstErrTransfer"
class UsbHost_UsbhstErrUnexpectedPkt(UsbHostCommandGroupError):
    """
    Device sent unexpected data.
    """
    ErrorCode = 0x00014406
    URL = "https://docs.baltech.de/refman/cmds/usbhost/index.html#UsbHost.UsbhstErrUnexpectedPkt"
class UsbHost_UsbhstErrBufferoverflow(UsbHostCommandGroupError):
    """
    Received too much data.
    """
    ErrorCode = 0x00014407
    URL = "https://docs.baltech.de/refman/cmds/usbhost/index.html#UsbHost.UsbhstErrBufferoverflow"
class UsbHost_UsbhstErrSetupPipes(UsbHostCommandGroupError):
    """
    Failure on setting up pipes.
    """
    ErrorCode = 0x00014420
    URL = "https://docs.baltech.de/refman/cmds/usbhost/index.html#UsbHost.UsbhstErrSetupPipes"
class VHL_ErrInvalidCardType(VHLCommandGroupError):
    """
    The desired card type doesn't match the card family of the currently selected card.
    """
    ErrorCode = 0x00010109
    URL = "https://docs.baltech.de/refman/cmds/vhl/index.html#VHL.ErrInvalidCardType"
class VHL_ErrNotSupported(VHLCommandGroupError):
    """
    The command is currently not supported. Future releases may support the command.
    """
    ErrorCode = 0x0001010A
    URL = "https://docs.baltech.de/refman/cmds/vhl/index.html#VHL.ErrNotSupported"
class VHL_ErrFormat(VHLCommandGroupError):
    """
    The communication sequence was OK, but formatting failed. Data may have been written partially. The card remains selected.
    """
    ErrorCode = 0x0001010B
    URL = "https://docs.baltech.de/refman/cmds/vhl/index.html#VHL.ErrFormat"
class DHWCtrlCommandGroupError(DeviceError):
    ErrorCode = 0x0001E000
    URL = "https://docs.baltech.de/refman/cmds/dhwctrl/index.html"
class DHWCtrl_ErrUnknownPort(DHWCtrlCommandGroupError):
    """
    This port is not available on this hardware platform.
    """
    ErrorCode = 0x0001E001
    URL = "https://docs.baltech.de/refman/cmds/dhwctrl/index.html#DHWCtrl.ErrUnknownPort"
class DHWCtrl_ErrMarshall(DHWCtrlCommandGroupError):
    """
    The structure of a StartupRun-block is wrong or the command DHWCtrl.GetStartupRun has not properly been called.
    """
    ErrorCode = 0x0001E002
    URL = "https://docs.baltech.de/refman/cmds/dhwctrl/index.html#DHWCtrl.ErrMarshall"
class DHWCtrl_ErrNoStartupRun(DHWCtrlCommandGroupError):
    """
    There was no StartupRun-block, or the DHWCtrl.GetStartupRun command was not executed.
    """
    ErrorCode = 0x0001E003
    URL = "https://docs.baltech.de/refman/cmds/dhwctrl/index.html#DHWCtrl.ErrNoStartupRun"
class DHWCtrl_ErrNoPowermgr(DHWCtrlCommandGroupError):
    """
    The Power Manager was unable to take the module into suspend mode.
    """
    ErrorCode = 0x0001E004
    URL = "https://docs.baltech.de/refman/cmds/dhwctrl/index.html#DHWCtrl.ErrNoPowermgr"
class DHWCtrl_ErrNoProdloader(DHWCtrlCommandGroupError):
    """
    No production loader is present in the reader's flash memory.
    """
    ErrorCode = 0x0001E005
    URL = "https://docs.baltech.de/refman/cmds/dhwctrl/index.html#DHWCtrl.ErrNoProdloader"
class DHWCtrl_ErrPfid2NotAvailable(DHWCtrlCommandGroupError):
    """
    No PlatformID2 available.
    """
    ErrorCode = 0x0001E006
    URL = "https://docs.baltech.de/refman/cmds/dhwctrl/index.html#DHWCtrl.ErrPfid2NotAvailable"
class DHWCtrl_ErrEepIndex(DHWCtrlCommandGroupError):
    """
    Specified EEPROM address and amount of Bytes to write are not compatible.
    """
    ErrorCode = 0x0001E011
    URL = "https://docs.baltech.de/refman/cmds/dhwctrl/index.html#DHWCtrl.ErrEepIndex"
class DHWCtrl_ErrEepVerify(DHWCtrlCommandGroupError):
    """
    Data written to EEPROM could not be verified.
    """
    ErrorCode = 0x0001E012
    URL = "https://docs.baltech.de/refman/cmds/dhwctrl/index.html#DHWCtrl.ErrEepVerify"
class DHWCtrl_ErrEepTimeout(DHWCtrlCommandGroupError):
    """
    Data could not be written within timeout.
    """
    ErrorCode = 0x0001E013
    URL = "https://docs.baltech.de/refman/cmds/dhwctrl/index.html#DHWCtrl.ErrEepTimeout"
class DHWCtrl_ErrDataflash(DHWCtrlCommandGroupError):
    """
    Dataflash could not be found.
    """
    ErrorCode = 0x0001E020
    URL = "https://docs.baltech.de/refman/cmds/dhwctrl/index.html#DHWCtrl.ErrDataflash"
class DHWCtrl_ErrDataflashTimeout(DHWCtrlCommandGroupError):
    """
    Timeout occurred.
    """
    ErrorCode = 0x0001E021
    URL = "https://docs.baltech.de/refman/cmds/dhwctrl/index.html#DHWCtrl.ErrDataflashTimeout"
class DHWCtrl_ErrDataflashVerify(DHWCtrlCommandGroupError):
    """
    Verification failed after writing data.
    """
    ErrorCode = 0x0001E022
    URL = "https://docs.baltech.de/refman/cmds/dhwctrl/index.html#DHWCtrl.ErrDataflashVerify"
class DHWCtrl_ErrDataflashParam(DHWCtrlCommandGroupError):
    """
    Parameter(s)/address(es) are not valid.
    """
    ErrorCode = 0x0001E023
    URL = "https://docs.baltech.de/refman/cmds/dhwctrl/index.html#DHWCtrl.ErrDataflashParam"
class DHWCtrl_ErrDataflashSpi(DHWCtrlCommandGroupError):
    """
    Communication via SPI interface failed.
    """
    ErrorCode = 0x0001E024
    URL = "https://docs.baltech.de/refman/cmds/dhwctrl/index.html#DHWCtrl.ErrDataflashSpi"
class DHWCtrl_ErrDataflashFlash(DHWCtrlCommandGroupError):
    """
    Flash device behaves in an unspecified manner.
    """
    ErrorCode = 0x0001E025
    URL = "https://docs.baltech.de/refman/cmds/dhwctrl/index.html#DHWCtrl.ErrDataflashFlash"
class DHWCtrl_ErrAvrProgSpi(DHWCtrlCommandGroupError):
    """
    SPI programming instruction couldn't be executed successfully.
    """
    ErrorCode = 0x0001E030
    URL = "https://docs.baltech.de/refman/cmds/dhwctrl/index.html#DHWCtrl.ErrAvrProgSpi"
class DHWCtrl_ErrAvrProgPdi(DHWCtrlCommandGroupError):
    """
    PDI operation couldn't be executed successfully.
    """
    ErrorCode = 0x0001E031
    URL = "https://docs.baltech.de/refman/cmds/dhwctrl/index.html#DHWCtrl.ErrAvrProgPdi"
class DHWCtrl_ErrNicNoData(DHWCtrlCommandGroupError):
    """
    No data was received by NIC.
    """
    ErrorCode = 0x0001E050
    URL = "https://docs.baltech.de/refman/cmds/dhwctrl/index.html#DHWCtrl.ErrNicNoData"
class DHWCtrl_ErrNicBufferFlow(DHWCtrlCommandGroupError):
    """
    Received data was to big for buffer.
    """
    ErrorCode = 0x0001E051
    URL = "https://docs.baltech.de/refman/cmds/dhwctrl/index.html#DHWCtrl.ErrNicBufferFlow"
__all__: list[str] = [
    "ASKCommandGroupError",
    "ASK_ErrAskNoTag",
    "ASK_ErrAskRxdata",
    "ASK_ErrAskParity",
    "ASK_ErrAskParam",
    "ASK_ErrAskHfreqctrl",
    "ASK_ErrAskHw",
    "ASK_ErrAskHwNotSupported",
    "CardEmuCommandGroupError",
    "CardEmu_CardemuErrNoTag",
    "CardEmu_CardemuErrCollision",
    "CardEmu_CardemuErrHf",
    "CardEmu_CardemuErrFrame",
    "CardEmu_CardemuErrCrc",
    "CardEmu_CardemuErrCom",
    "CardEmu_CardemuErrBuflen",
    "CardEmu_CardemuErrTimeout",
    "DbgCommandGroupError",
    "Dbg_DbgErrBusy",
    "EMCommandGroupError",
    "EM_ErrEmNoTag",
    "EM_ErrEmRxdata",
    "EM_ErrEmChecksum",
    "EM_ErrEmParity",
    "EM_EmCmdError",
    "EM_EmTagtypeNotDetected",
    "EM_ErrEmOvTo",
    "EM_EmParamError",
    "EM_ErrEmHfreqctrl",
    "EM_ErrEmHw",
    "EM_ErrEmHwNotSupported",
    "EthCommandGroupError",
    "Eth_ErrNoResultYet",
    "Eth_ErrNotConnected",
    "Eth_ErrDisabled",
    "Felica_ErrFelicaHwNotSupported",
    "HIDCommandGroupError",
    "HID_ErrHidNoTag",
    "HID_ErrHidRxdata",
    "HID_ErrHidParity",
    "HID_ErrHidParam",
    "HID_ErrHidHfreqctrl",
    "HID_ErrHidHw",
    "HID_ErrHidHwNotSupported",
    "HID_ErrLicense",
    "HitagCommandGroupError",
    "Hitag_ErrHtgNoTag",
    "Hitag_ErrHtgCollision",
    "Hitag_ErrHtgRxdata",
    "Hitag_HtgChecksum",
    "Hitag_HtgWrongParam",
    "Hitag_ErrHtgAuth",
    "Hitag_ErrHtgOvTo",
    "Hitag_ErrHtgHw",
    "Hitag_ErrHtgCr",
    "Hitag_ErrHtgCfg",
    "Hitag_ErrHtgHfreqctrl",
    "Hitag_ErrHtgHwNotSupported",
    "I2cCommandGroupError",
    "I2c_ErrI2CRead",
    "I2c_ErrI2CWrite",
    "Iso14a_ErrKey",
    "Iso14a_ErrEeprom",
    "Iso14a_ErrCardNotSupported",
    "Iso14a_ErrHwNotSupported",
    "Iso14a_BreakErr",
    "Iso14b_ErrAuth",
    "Iso14b_ErrCrc",
    "Iso14b_ErrEeprom",
    "Iso14b_ErrCardNotSupported",
    "Iso14b_ErrHwNotSupported",
    "Iso14CECommandGroupError",
    "Iso14CE_ErrIso144State",
    "Iso14CE_ErrCom",
    "Iso14CE_ErrTransmission",
    "Iso14CE_ErrTimeout",
    "Iso14CE_ErrOverflow",
    "Iso14CE_ErrInternal",
    "Iso14CE_ErrDeselect",
    "Iso15_ErrCmd",
    "Iso15_ErrHwNotSupported",
    "LegicCommandGroupError",
    "Legic_ErrCommunication",
    "Legic_ErrNotInitialized",
    "Legic_ErrNotAssembled",
    "LgaCommandGroupError",
    "Lga_ErrNotag",
    "Lga_ErrLegic",
    "Lga_ErrCommunication",
    "Lga_ErrNotInitialized",
    "Lga_ErrNotAssembled",
    "Main_ErrOutdatedFirmware",
    "Main_ErrUnknownVersion",
    "MceCommandGroupError",
    "Mce_ErrNoTag",
    "Mce_ErrDisabled",
    "Mce_ErrLicense",
    "Mif_ErrCrc",
    "Mif_ErrSnr",
    "Mif_ErrWrite",
    "Mif_ErrInc",
    "Mif_ErrDecr",
    "Mif_ErrRead",
    "Mif_ErrOvfl",
    "Mif_ErrBreak",
    "Mif_ErrReaderChipCommunication",
    "Mif_ErrFirmwareNotSupported",
    "Mif_ErrVal",
    "Mif_ErrIntegrity",
    "Mif_ErrHwNotSupported",
    "Mif_ErrSamUnlock",
    "Mif_ErrSamCommunication",
    "PicoCommandGroupError",
    "Pico_ErrNoTag",
    "Pico_ErrCollision",
    "Pico_ErrHf",
    "Pico_ErrFrame",
    "Pico_ErrCrc",
    "Pico_ErrCom",
    "Pico_ErrCardNotSupported",
    "Pico_ErrHwNotSupported",
    "PkiCommandGroupError",
    "Pki_ErrCrypto",
    "Pki_ErrTunnel",
    "Pki_ErrCert",
    "Pki_ErrSeqctr",
    "Pki_ErrSeclevelUnsupported",
    "Pki_ErrSessionTimeout",
    "QKeyCommandGroupError",
    "QKey_ErrQkeyNoTag",
    "QKey_ErrQkeyRxdata",
    "QKey_ErrQkeyParity",
    "QKey_ErrQkeyParam",
    "QKey_ErrQkeyHfreqctrl",
    "QKey_ErrQkeyHw",
    "QKey_ErrQkeyHwNotSupported",
    "RtcCommandGroupError",
    "Rtc_ErrHardware",
    "Rtc_ErrVoltageLow",
    "SrixCommandGroupError",
    "Srix_ErrNoTag",
    "Srix_ErrFrame",
    "Srix_ErrHf",
    "Srix_ErrCom",
    "Srix_ErrSrixCardtypeNotSupported",
    "Srix_ErrHwNotSupported",
    "Srix_ErrCmdBreak",
    "Sys_ErrRegAccess",
    "Sys_ErrCfgConfigSecurityCode",
    "Sys_ErrCfgVersion",
    "Sys_ErrCfgLoadWrongState",
    "Sys_ErrInvalidFwCrc",
    "TTFCommandGroupError",
    "TTF_ErrTtfNoTag",
    "TTF_ErrTtfRxdata",
    "TTF_ErrTtfParam",
    "TTF_ErrTtfOvTo",
    "TTF_ErrTtfHfreqctrl",
    "TTF_ErrTtfHw",
    "TTF_ErrTtfHwNotSupported",
    "Ultralight_ErrFirmwareNotSupported",
    "UsbHostCommandGroupError",
    "UsbHost_UsbhstErrNotconnected",
    "UsbHost_UsbhstErrTimeout",
    "UsbHost_UsbhstErrNack",
    "UsbHost_UsbhstErrStall",
    "UsbHost_UsbhstErrTransfer",
    "UsbHost_UsbhstErrUnexpectedPkt",
    "UsbHost_UsbhstErrBufferoverflow",
    "UsbHost_UsbhstErrSetupPipes",
    "VHL_ErrInvalidCardType",
    "VHL_ErrNotSupported",
    "VHL_ErrFormat",
    "DHWCtrlCommandGroupError",
    "DHWCtrl_ErrUnknownPort",
    "DHWCtrl_ErrMarshall",
    "DHWCtrl_ErrNoStartupRun",
    "DHWCtrl_ErrNoPowermgr",
    "DHWCtrl_ErrNoProdloader",
    "DHWCtrl_ErrPfid2NotAvailable",
    "DHWCtrl_ErrEepIndex",
    "DHWCtrl_ErrEepVerify",
    "DHWCtrl_ErrEepTimeout",
    "DHWCtrl_ErrDataflash",
    "DHWCtrl_ErrDataflashTimeout",
    "DHWCtrl_ErrDataflashVerify",
    "DHWCtrl_ErrDataflashParam",
    "DHWCtrl_ErrDataflashSpi",
    "DHWCtrl_ErrDataflashFlash",
    "DHWCtrl_ErrAvrProgSpi",
    "DHWCtrl_ErrAvrProgPdi",
    "DHWCtrl_ErrNicNoData",
    "DHWCtrl_ErrNicBufferFlow",
]