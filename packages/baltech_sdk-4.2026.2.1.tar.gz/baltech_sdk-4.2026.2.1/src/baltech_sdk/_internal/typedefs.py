
from typing import Optional, NamedTuple, Literal, TypedDict, List, Tuple, Any

from typing_extensions import Self, NotRequired

from ..generator_interface import LiteralParser
from .._public.typedefs import *
class Eth_GetNetworkStatus_Result(NamedTuple):
    PortStatus: 'int'
    StaticIPAdr: 'bytes'
    StaticIPNetmask: 'bytes'
    StaticIPGateway: 'bytes'
    DHCPAdr: 'bytes'
    DHCPNetmask: 'bytes'
    DHCPGateway: 'bytes'
    LinkLocalAdr: 'bytes'
    LinkLocalNetmask: 'bytes'
    LinkLocalGateway: 'bytes'
    DNSAdr: 'bytes'
    HostAdr: 'bytes'
    HostPort: 'int'
    AutocloseTimeout: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('PortStatus', self.PortStatus))
        args.append(('StaticIPAdr', self.StaticIPAdr))
        args.append(('StaticIPNetmask', self.StaticIPNetmask))
        args.append(('StaticIPGateway', self.StaticIPGateway))
        args.append(('DHCPAdr', self.DHCPAdr))
        args.append(('DHCPNetmask', self.DHCPNetmask))
        args.append(('DHCPGateway', self.DHCPGateway))
        args.append(('LinkLocalAdr', self.LinkLocalAdr))
        args.append(('LinkLocalNetmask', self.LinkLocalNetmask))
        args.append(('LinkLocalGateway', self.LinkLocalGateway))
        args.append(('DNSAdr', self.DNSAdr))
        args.append(('HostAdr', self.HostAdr))
        args.append(('HostPort', self.HostPort))
        args.append(('AutocloseTimeout', self.AutocloseTimeout))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class HID_PyramidRead_Result(NamedTuple):
    Len: 'int'
    Data: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('Len', self.Len))
        args.append(('Data', self.Data))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Iso14a_RequestLegacy_Result(NamedTuple):
    UIDSize: 'Iso14a_RequestLegacy_UIDSize'
    Coll: 'int'
    ProprietaryCoding: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('UIDSize', self.UIDSize))
        args.append(('Coll', self.Coll))
        args.append(('ProprietaryCoding', self.ProprietaryCoding))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Iso14a_TransparentCmdBitlen_Result(NamedTuple):
    RecvDataLen: 'int'
    CollisionPosition: 'int'
    RecvData: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('RecvDataLen', self.RecvDataLen))
        args.append(('CollisionPosition', self.CollisionPosition))
        args.append(('RecvData', self.RecvData))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Iso15_ReadBlock_Result(NamedTuple):
    LabelStat: 'int'
    BlockLen: 'Optional[int]' = None
    Data: 'Optional[List[Iso15_ReadBlock_Data_Entry]]' = None
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('LabelStat', self.LabelStat))
        if self.BlockLen != None:
            args.append(('BlockLen', self.BlockLen))
        if self.Data != None:
            args.append(('Data', self.Data))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Legic_TransparentCommand4000_Result(NamedTuple):
    Status: 'int'
    Resp: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('Status', self.Status))
        args.append(('Resp', self.Resp))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Legic_TransparentCommand6000_Result(NamedTuple):
    Status: 'int'
    Resp: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('Status', self.Status))
        args.append(('Resp', self.Resp))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Lga_TransparentCommand_Result(NamedTuple):
    Status: 'int'
    Resp: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('Status', self.Status))
        args.append(('Resp', self.Resp))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Main_Bf2Upload_Result(NamedTuple):
    ResultCode: 'Main_Bf2Upload_ResultCode'
    InvertedResultCode: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('ResultCode', self.ResultCode))
        args.append(('InvertedResultCode', self.InvertedResultCode))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Pki_Tunnel2_Result(NamedTuple):
    RspHMAC: 'bytes'
    EncryptedRsp: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('RspHMAC', self.RspHMAC))
        args.append(('EncryptedRsp', self.EncryptedRsp))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Sys_GetPlatformId_Result(NamedTuple):
    PlatformId: 'bytes'
    BootloaderId: 'int'
    BootloaderMajor: 'int'
    BootloaderMinor: 'int'
    BootloaderBuild: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('PlatformId', self.PlatformId))
        args.append(('BootloaderId', self.BootloaderId))
        args.append(('BootloaderMajor', self.BootloaderMajor))
        args.append(('BootloaderMinor', self.BootloaderMinor))
        args.append(('BootloaderBuild', self.BootloaderBuild))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class DHWCtrl_DataflashGetSize_Result(NamedTuple):
    PageCount: 'int'
    PageSize: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('PageCount', self.PageCount))
        args.append(('PageSize', self.PageSize))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class DHWCtrl_Run_Result(NamedTuple):
    Status: 'int'
    Response: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('Status', self.Status))
        args.append(('Response', self.Response))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class DHWCtrl_GetStartupRun_Result(NamedTuple):
    Status: 'int'
    Response: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('Status', self.Status))
        args.append(('Response', self.Response))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Device_CryptoKey_Entry_Result(NamedTuple):
    AccessRights: 'KeyAccessRights'
    Algorithm: 'CryptoAlgorithm'
    Key: 'str'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('AccessRights', self.AccessRights))
        args.append(('Algorithm', self.Algorithm))
        args.append(('Key', self.Key))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Device_HostSecurity_KeyInternal_Result(NamedTuple):
    AuthenticationMode: 'HostSecurityAuthenticationMode'
    DeriveKeyId: 'int'
    AesKey: 'str'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('AuthenticationMode', self.AuthenticationMode))
        args.append(('DeriveKeyId', self.DeriveKeyId))
        args.append(('AesKey', self.AesKey))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Custom_Crypto_Key_Result(NamedTuple):
    DenyIdentify: 'bool'
    DenyEncrypt: 'bool'
    DenyDecrypt: 'bool'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('DenyIdentify', self.DenyIdentify))
        args.append(('DenyEncrypt', self.DenyEncrypt))
        args.append(('DenyDecrypt', self.DenyDecrypt))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
    
    @classmethod
    def all(cls) -> Self:
        return cls(DenyIdentify=True, DenyEncrypt=True, DenyDecrypt=True)
    
    @classmethod
    def all_except(cls, *, DenyIdentify: Optional[Literal[False]] = None, DenyEncrypt: Optional[Literal[False]] = None, DenyDecrypt: Optional[Literal[False]] = None) -> Self:
        true_fields = [name for name, value in [('DenyIdentify', DenyIdentify), ('DenyEncrypt', DenyEncrypt), ('DenyDecrypt', DenyDecrypt)] if value is True]  # type: ignore[comparison-overlap]
        if true_fields:
            raise TypeError(f"all_except() only accepts False values, got {', '.join(f'{name}=True' for name in true_fields)}")
        kwargs = {name: False if value is False else True for name, value in [('DenyIdentify', DenyIdentify), ('DenyEncrypt', DenyEncrypt), ('DenyDecrypt', DenyDecrypt)]}
        return cls(**kwargs)
class Project_Bluetooth_AdvertizingChannels_Result(NamedTuple):
    Channel39: 'bool'
    Channel38: 'bool'
    Channel37: 'bool'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('Channel39', self.Channel39))
        args.append(('Channel38', self.Channel38))
        args.append(('Channel37', self.Channel37))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
    
    @classmethod
    def all(cls) -> Self:
        return cls(Channel39=True, Channel38=True, Channel37=True)
    
    @classmethod
    def all_except(cls, *, Channel39: Optional[Literal[False]] = None, Channel38: Optional[Literal[False]] = None, Channel37: Optional[Literal[False]] = None) -> Self:
        true_fields = [name for name, value in [('Channel39', Channel39), ('Channel38', Channel38), ('Channel37', Channel37)] if value is True]  # type: ignore[comparison-overlap]
        if true_fields:
            raise TypeError(f"all_except() only accepts False values, got {', '.join(f'{name}=True' for name in true_fields)}")
        kwargs = {name: False if value is False else True for name, value in [('Channel39', Channel39), ('Channel38', Channel38), ('Channel37', Channel37)]}
        return cls(**kwargs)
class Protocols_Lbus_OfflineCompanyId_Result(NamedTuple):
    Position: 'int'
    CompanyId: 'bytes'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('Position', self.Position))
        args.append(('CompanyId', self.CompanyId))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
class Custom_AdminData_FactoryResetFirmwareVersion_Value_Entry(NamedTuple):
    FirmwareId: 'int'
    FwVersionMajor: 'int'
    FwVersionMinor: 'int'
    FwVersionBuild: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('FirmwareId', self.FirmwareId))
        args.append(('FwVersionMajor', self.FwVersionMajor))
        args.append(('FwVersionMinor', self.FwVersionMinor))
        args.append(('FwVersionBuild', self.FwVersionBuild))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
DHWCtrl_AesDecrypt_WrappedKeyNr = Literal["WrapNone", "WrapDHUK"]
DHWCtrl_AesDecrypt_WrappedKeyNr_Parser = LiteralParser[DHWCtrl_AesDecrypt_WrappedKeyNr, int](
    name='DHWCtrl_AesDecrypt_WrappedKeyNr',
    literal_map={
        'WrapNone': 0,
        'WrapDHUK': 1,
    },
)
DHWCtrl_AesEncrypt_WrappedKeyNr = Literal["WrapNone", "WrapDHUK"]
DHWCtrl_AesEncrypt_WrappedKeyNr_Parser = LiteralParser[DHWCtrl_AesEncrypt_WrappedKeyNr, int](
    name='DHWCtrl_AesEncrypt_WrappedKeyNr',
    literal_map={
        'WrapNone': 0,
        'WrapDHUK': 1,
    },
)
DHWCtrl_AesWrapKey_WrappedKeyNr = Literal["WrapNone", "WrapDHUK"]
DHWCtrl_AesWrapKey_WrappedKeyNr_Parser = LiteralParser[DHWCtrl_AesWrapKey_WrappedKeyNr, int](
    name='DHWCtrl_AesWrapKey_WrappedKeyNr',
    literal_map={
        'WrapNone': 0,
        'WrapDHUK': 1,
    },
)
DHWCtrl_DispColor_Color = Literal["White", "Black"]
DHWCtrl_DispColor_Color_Parser = LiteralParser[DHWCtrl_DispColor_Color, int](
    name='DHWCtrl_DispColor_Color',
    literal_map={
        'White': 0,
        'Black': 255,
    },
)
DHWCtrl_GetReaderChipType_ChipType = Literal["RC500", "RC632", "RC663", "PN512"]
DHWCtrl_GetReaderChipType_ChipType_Parser = LiteralParser[DHWCtrl_GetReaderChipType_ChipType, int](
    name='DHWCtrl_GetReaderChipType_ChipType',
    literal_map={
        'RC500': 1,
        'RC632': 4,
        'RC663': 5,
        'PN512': 33,
    },
)
DHWCtrl_GetSamType_ChipType = Literal["TDA8007C2", "TDA8007C3"]
DHWCtrl_GetSamType_ChipType_Parser = LiteralParser[DHWCtrl_GetSamType_ChipType, int](
    name='DHWCtrl_GetSamType_ChipType',
    literal_map={
        'TDA8007C2': 1,
        'TDA8007C3': 2,
    },
)
DHWCtrl_HfAcquire_ModuleId = Literal["No", "RC", "Legic", "PN", "LegicAdvant", "RC125", "PN2", "RC663", "HTRC110"]
DHWCtrl_HfAcquire_ModuleId_Parser = LiteralParser[DHWCtrl_HfAcquire_ModuleId, int](
    name='DHWCtrl_HfAcquire_ModuleId',
    literal_map={
        'No': 0,
        'RC': 1,
        'Legic': 3,
        'PN': 17,
        'LegicAdvant': 19,
        'RC125': 24,
        'PN2': 26,
        'RC663': 34,
        'HTRC110': 36,
    },
)
DHWCtrl_PortConfig_Mode = Literal["OutputLow", "OutputHigh", "InputTristate", "InputPullup"]
DHWCtrl_PortConfig_Mode_Parser = LiteralParser[DHWCtrl_PortConfig_Mode, int](
    name='DHWCtrl_PortConfig_Mode',
    literal_map={
        'OutputLow': 0,
        'OutputHigh': 1,
        'InputTristate': 2,
        'InputPullup': 3,
    },
)
Device_Boot_ConfigCardState_Value = Literal["None", "Ok", "ReadFailure", "InvalidConfigSecurityCode", "InvalidCustomerKey"]
Device_Boot_ConfigCardState_Value_Parser = LiteralParser[Device_Boot_ConfigCardState_Value, int](
    name='Device_Boot_ConfigCardState_Value',
    literal_map={
        'None': 0,
        'Ok': 1,
        'ReadFailure': 2,
        'InvalidConfigSecurityCode': 3,
        'InvalidCustomerKey': 4,
    },
)
Device_Boot_LegicAdvantInitialization_Value = Literal["DelaysPowerup", "AfterPowerup"]
Device_Boot_LegicAdvantInitialization_Value_Parser = LiteralParser[Device_Boot_LegicAdvantInitialization_Value, int](
    name='Device_Boot_LegicAdvantInitialization_Value',
    literal_map={
        'DelaysPowerup': 1,
        'AfterPowerup': 0,
    },
)
Device_Rgb_MaximizeIntensity_Value = Literal["False", "True"]
Device_Rgb_MaximizeIntensity_Value_Parser = LiteralParser[Device_Rgb_MaximizeIntensity_Value, int](
    name='Device_Rgb_MaximizeIntensity_Value',
    literal_map={
        'False': 0,
        'True': 1,
    },
)
Device_Run_CardReadFailureLogging_Value = Literal["Disabled", "Enabled"]
Device_Run_CardReadFailureLogging_Value_Parser = LiteralParser[Device_Run_CardReadFailureLogging_Value, int](
    name='Device_Run_CardReadFailureLogging_Value',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
    },
)
Device_Run_UsbSuspendMode_SuspendMode = Literal["Disabled", "Enabled"]
Device_Run_UsbSuspendMode_SuspendMode_Parser = LiteralParser[Device_Run_UsbSuspendMode_SuspendMode, int](
    name='Device_Run_UsbSuspendMode_SuspendMode',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
    },
)
Device_VhlSettings125Khz_Baud_Baud = Literal["ModUnknown", "Baud32", "Baud64"]
Device_VhlSettings125Khz_Baud_Baud_Parser = LiteralParser[Device_VhlSettings125Khz_Baud_Baud, int](
    name='Device_VhlSettings125Khz_Baud_Baud',
    literal_map={
        'ModUnknown': 0,
        'Baud32': 32,
        'Baud64': 64,
    },
)
Device_VhlSettings125Khz_IndaspParityCheck_ParityDisable = Literal["Enable", "Disable"]
Device_VhlSettings125Khz_IndaspParityCheck_ParityDisable_Parser = LiteralParser[Device_VhlSettings125Khz_IndaspParityCheck_ParityDisable, int](
    name='Device_VhlSettings125Khz_IndaspParityCheck_ParityDisable',
    literal_map={
        'Enable': 0,
        'Disable': 1,
    },
)
Device_VhlSettings125Khz_ModulationType_TTFMod = Literal["ModManchester", "ModBiphase", "ModNRZ", "ModHID"]
Device_VhlSettings125Khz_ModulationType_TTFMod_Parser = LiteralParser[Device_VhlSettings125Khz_ModulationType_TTFMod, int](
    name='Device_VhlSettings125Khz_ModulationType_TTFMod',
    literal_map={
        'ModManchester': 16,
        'ModBiphase': 32,
        'ModNRZ': 48,
        'ModHID': 80,
    },
)
Device_VhlSettings_ForceReselect_Value = Literal["False", "True"]
Device_VhlSettings_ForceReselect_Value_Parser = LiteralParser[Device_VhlSettings_ForceReselect_Value, int](
    name='Device_VhlSettings_ForceReselect_Value',
    literal_map={
        'False': 0,
        'True': 1,
    },
)
EM_DecodeCfg_RxMod = Literal["Unknown", "Manchester", "Biphase", "NRZ"]
EM_DecodeCfg_RxMod_Parser = LiteralParser[EM_DecodeCfg_RxMod, int](
    name='EM_DecodeCfg_RxMod',
    literal_map={
        'Unknown': 0,
        'Manchester': 16,
        'Biphase': 32,
        'NRZ': 48,
    },
)
Eth_GetTcpConnectionStatus_Status = Literal["NotConnected", "ConnectionTrialRunning", "Connected"]
Eth_GetTcpConnectionStatus_Status_Parser = LiteralParser[Eth_GetTcpConnectionStatus_Status, int](
    name='Eth_GetTcpConnectionStatus_Status',
    literal_map={
        'NotConnected': 0,
        'ConnectionTrialRunning': 1,
        'Connected': 2,
    },
)
Eth_OpenTcpConnection_ConnectionReason = Literal["Powerup", "LinkChange", "SessionkeyTimeout", "Message", "UdpIntrospection", "Reset", "FailedConnectionTrials"]
Eth_OpenTcpConnection_ConnectionReason_Parser = LiteralParser[Eth_OpenTcpConnection_ConnectionReason, int](
    name='Eth_OpenTcpConnection_ConnectionReason',
    literal_map={
        'Powerup': 1,
        'LinkChange': 2,
        'SessionkeyTimeout': 4,
        'Message': 8,
        'UdpIntrospection': 16,
        'Reset': 32,
        'FailedConnectionTrials': 32768,
    },
)
Hitag_Request_Mode = Literal["StdHtg12S", "AdvHtg1S", "FAdvHS"]
Hitag_Request_Mode_Parser = LiteralParser[Hitag_Request_Mode, int](
    name='Hitag_Request_Mode',
    literal_map={
        'StdHtg12S': 0,
        'AdvHtg1S': 1,
        'FAdvHS': 2,
    },
)
Hitag_Request_TagType = Literal["HitagS", "Hitag1", "Hitag2Manchester", "Hitag2Biphase"]
Hitag_Request_TagType_Parser = LiteralParser[Hitag_Request_TagType, int](
    name='Hitag_Request_TagType',
    literal_map={
        'HitagS': 0,
        'Hitag1': 1,
        'Hitag2Manchester': 2,
        'Hitag2Biphase': 3,
    },
)
Hitag_Select_SelMode = Literal["Select", "Quiet", "AuthPwd", "H2AuthOnlyPwd"]
Hitag_Select_SelMode_Parser = LiteralParser[Hitag_Select_SelMode, int](
    name='Hitag_Select_SelMode',
    literal_map={
        'Select': 0,
        'Quiet': 1,
        'AuthPwd': 2,
        'H2AuthOnlyPwd': 3,
    },
)
class IoPortBitmask(NamedTuple):
    Gpio7: 'bool' = False
    Gpio6: 'bool' = False
    Gpio5: 'bool' = False
    Gpio4: 'bool' = False
    Gpio3: 'bool' = False
    Gpio2: 'bool' = False
    Gpio1: 'bool' = False
    Gpio0: 'bool' = False
    TamperAlarm: 'bool' = False
    BlueLed: 'bool' = False
    Input1: 'bool' = False
    Input0: 'bool' = False
    Relay: 'bool' = False
    Beeper: 'bool' = False
    RedLed: 'bool' = False
    GreenLed: 'bool' = False
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        if self.Gpio7 != False:
            args.append(('Gpio7', self.Gpio7))
        if self.Gpio6 != False:
            args.append(('Gpio6', self.Gpio6))
        if self.Gpio5 != False:
            args.append(('Gpio5', self.Gpio5))
        if self.Gpio4 != False:
            args.append(('Gpio4', self.Gpio4))
        if self.Gpio3 != False:
            args.append(('Gpio3', self.Gpio3))
        if self.Gpio2 != False:
            args.append(('Gpio2', self.Gpio2))
        if self.Gpio1 != False:
            args.append(('Gpio1', self.Gpio1))
        if self.Gpio0 != False:
            args.append(('Gpio0', self.Gpio0))
        if self.TamperAlarm != False:
            args.append(('TamperAlarm', self.TamperAlarm))
        if self.BlueLed != False:
            args.append(('BlueLed', self.BlueLed))
        if self.Input1 != False:
            args.append(('Input1', self.Input1))
        if self.Input0 != False:
            args.append(('Input0', self.Input0))
        if self.Relay != False:
            args.append(('Relay', self.Relay))
        if self.Beeper != False:
            args.append(('Beeper', self.Beeper))
        if self.RedLed != False:
            args.append(('RedLed', self.RedLed))
        if self.GreenLed != False:
            args.append(('GreenLed', self.GreenLed))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
    
    @classmethod
    def all(cls) -> Self:
        return cls(Gpio7=True, Gpio6=True, Gpio5=True, Gpio4=True, Gpio3=True, Gpio2=True, Gpio1=True, Gpio0=True, TamperAlarm=True, BlueLed=True, Input1=True, Input0=True, Relay=True, Beeper=True, RedLed=True, GreenLed=True)
    
    @classmethod
    def all_except(cls, *, Gpio7: Optional[Literal[False]] = None, Gpio6: Optional[Literal[False]] = None, Gpio5: Optional[Literal[False]] = None, Gpio4: Optional[Literal[False]] = None, Gpio3: Optional[Literal[False]] = None, Gpio2: Optional[Literal[False]] = None, Gpio1: Optional[Literal[False]] = None, Gpio0: Optional[Literal[False]] = None, TamperAlarm: Optional[Literal[False]] = None, BlueLed: Optional[Literal[False]] = None, Input1: Optional[Literal[False]] = None, Input0: Optional[Literal[False]] = None, Relay: Optional[Literal[False]] = None, Beeper: Optional[Literal[False]] = None, RedLed: Optional[Literal[False]] = None, GreenLed: Optional[Literal[False]] = None) -> Self:
        true_fields = [name for name, value in [('Gpio7', Gpio7), ('Gpio6', Gpio6), ('Gpio5', Gpio5), ('Gpio4', Gpio4), ('Gpio3', Gpio3), ('Gpio2', Gpio2), ('Gpio1', Gpio1), ('Gpio0', Gpio0), ('TamperAlarm', TamperAlarm), ('BlueLed', BlueLed), ('Input1', Input1), ('Input0', Input0), ('Relay', Relay), ('Beeper', Beeper), ('RedLed', RedLed), ('GreenLed', GreenLed)] if value is True]  # type: ignore[comparison-overlap]
        if true_fields:
            raise TypeError(f"all_except() only accepts False values, got {', '.join(f'{name}=True' for name in true_fields)}")
        kwargs = {name: False if value is False else True for name, value in [('Gpio7', Gpio7), ('Gpio6', Gpio6), ('Gpio5', Gpio5), ('Gpio4', Gpio4), ('Gpio3', Gpio3), ('Gpio2', Gpio2), ('Gpio1', Gpio1), ('Gpio0', Gpio0), ('TamperAlarm', TamperAlarm), ('BlueLed', BlueLed), ('Input1', Input1), ('Input0', Input0), ('Relay', Relay), ('Beeper', Beeper), ('RedLed', RedLed), ('GreenLed', GreenLed)]}
        return cls(**kwargs)
class IoPortBitmask_Dict(TypedDict):
    Gpio7: 'NotRequired[bool]'
    Gpio6: 'NotRequired[bool]'
    Gpio5: 'NotRequired[bool]'
    Gpio4: 'NotRequired[bool]'
    Gpio3: 'NotRequired[bool]'
    Gpio2: 'NotRequired[bool]'
    Gpio1: 'NotRequired[bool]'
    Gpio0: 'NotRequired[bool]'
    TamperAlarm: 'NotRequired[bool]'
    BlueLed: 'NotRequired[bool]'
    Input1: 'NotRequired[bool]'
    Input0: 'NotRequired[bool]'
    Relay: 'NotRequired[bool]'
    Beeper: 'NotRequired[bool]'
    RedLed: 'NotRequired[bool]'
    GreenLed: 'NotRequired[bool]'
Iso14a_RequestLegacy_UIDSize = Literal["SingleSize", "DoubleSize", "TripleSize"]
Iso14a_RequestLegacy_UIDSize_Parser = LiteralParser[Iso14a_RequestLegacy_UIDSize, int](
    name='Iso14a_RequestLegacy_UIDSize',
    literal_map={
        'SingleSize': 0,
        'DoubleSize': 1,
        'TripleSize': 2,
    },
)
class Iso15_ReadBlock_Data_Entry(NamedTuple):
    BlockData: 'bytes'
    BlockSecData: 'Optional[int]' = None
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('BlockData', self.BlockData))
        if self.BlockSecData != None:
            args.append(('BlockSecData', self.BlockSecData))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
Main_Bf2Upload_ResultCode = Literal["Success", "InvalidChecksum", "ProgrammingTimeout", "VerifyTimeout", "UnsupportedCodeType", "ProtocolError", "SecuredByConfigSecurityCode", "undefined"]
Main_Bf2Upload_ResultCode_Parser = LiteralParser[Main_Bf2Upload_ResultCode, int](
    name='Main_Bf2Upload_ResultCode',
    literal_map={
        'Success': 0,
        'InvalidChecksum': 1,
        'ProgrammingTimeout': 2,
        'VerifyTimeout': 3,
        'UnsupportedCodeType': 4,
        'ProtocolError': 5,
        'SecuredByConfigSecurityCode': 6,
        'undefined': -1,
    },
    undefined_literal='undefined',
)
Mce_Enable_Mode = Literal["Disable", "Enable"]
Mce_Enable_Mode_Parser = LiteralParser[Mce_Enable_Mode, int](
    name='Mce_Enable_Mode',
    literal_map={
        'Disable': 0,
        'Enable': 1,
    },
)
Project_Bluetooth_ConnectionMode_Value = Literal["NonConnectable", "Connectable"]
Project_Bluetooth_ConnectionMode_Value_Parser = LiteralParser[Project_Bluetooth_ConnectionMode_Value, int](
    name='Project_Bluetooth_ConnectionMode_Value',
    literal_map={
        'NonConnectable': 0,
        'Connectable': 1,
    },
)
Project_Bluetooth_DiscoveryMode_Value = Literal["NonDiscoverable", "LimitedDiscoverable", "GeneralDiscoverable"]
Project_Bluetooth_DiscoveryMode_Value_Parser = LiteralParser[Project_Bluetooth_DiscoveryMode_Value, int](
    name='Project_Bluetooth_DiscoveryMode_Value',
    literal_map={
        'NonDiscoverable': 0,
        'LimitedDiscoverable': 1,
        'GeneralDiscoverable': 2,
    },
)
Project_Mce_Mode_Value = Literal["Disabled", "Enabled"]
Project_Mce_Mode_Value_Parser = LiteralParser[Project_Mce_Mode_Value, int](
    name='Project_Mce_Mode_Value',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
    },
)
Project_VhlSettings125Khz_IndalaMode_Mode = Literal["Default", "NoParityCheck"]
Project_VhlSettings125Khz_IndalaMode_Mode_Parser = LiteralParser[Project_VhlSettings125Khz_IndalaMode_Mode, int](
    name='Project_VhlSettings125Khz_IndalaMode_Mode',
    literal_map={
        'Default': 0,
        'NoParityCheck': 1,
    },
)
Project_VhlSettings_HandleLegicCTCAsSinglePrimeTransponder_Value = Literal["False", "True"]
Project_VhlSettings_HandleLegicCTCAsSinglePrimeTransponder_Value_Parser = LiteralParser[Project_VhlSettings_HandleLegicCTCAsSinglePrimeTransponder_Value, int](
    name='Project_VhlSettings_HandleLegicCTCAsSinglePrimeTransponder_Value',
    literal_map={
        'False': 0,
        'True': 1,
    },
)
Protocols_Lbus_Channel_Value = Literal["Channel0", "Channel1"]
Protocols_Lbus_Channel_Value_Parser = LiteralParser[Protocols_Lbus_Channel_Value, int](
    name='Protocols_Lbus_Channel_Value',
    literal_map={
        'Channel0': 0,
        'Channel1': 1,
    },
)
Protocols_Lbus_OfflineIndication_Value = Literal["Disabled", "Enabled"]
Protocols_Lbus_OfflineIndication_Value_Parser = LiteralParser[Protocols_Lbus_OfflineIndication_Value, int](
    name='Protocols_Lbus_OfflineIndication_Value',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
    },
)
Protocols_Network_DetectIpEnable_Value = Literal["Yes", "No"]
Protocols_Network_DetectIpEnable_Value_Parser = LiteralParser[Protocols_Network_DetectIpEnable_Value, int](
    name='Protocols_Network_DetectIpEnable_Value',
    literal_map={
        'Yes': 1,
        'No': 0,
    },
)
Protocols_Network_LinkLocalMode_Value = Literal["Disabled", "Enabled", "Auto"]
Protocols_Network_LinkLocalMode_Value_Parser = LiteralParser[Protocols_Network_LinkLocalMode_Value, int](
    name='Protocols_Network_LinkLocalMode_Value',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
        'Auto': 2,
    },
)
Protocols_Network_NicFlowControl_Value = Literal["Enabled", "Disabled"]
Protocols_Network_NicFlowControl_Value_Parser = LiteralParser[Protocols_Network_NicFlowControl_Value, int](
    name='Protocols_Network_NicFlowControl_Value',
    literal_map={
        'Enabled': 1,
        'Disabled': 0,
    },
)
Protocols_Network_NicNetworkPortSpeedDuplexMode_Value = Literal["Autonegotiation", "HalfDuplex10Mbit", "FullDuplex10Mbit", "HalfDuplex100Mbit", "FullDuplex100Mbit"]
Protocols_Network_NicNetworkPortSpeedDuplexMode_Value_Parser = LiteralParser[Protocols_Network_NicNetworkPortSpeedDuplexMode_Value, int](
    name='Protocols_Network_NicNetworkPortSpeedDuplexMode_Value',
    literal_map={
        'Autonegotiation': 0,
        'HalfDuplex10Mbit': 1,
        'FullDuplex10Mbit': 2,
        'HalfDuplex100Mbit': 3,
        'FullDuplex100Mbit': 4,
    },
)
Protocols_Network_NicPrinterPortSpeedDuplexMode_Value = Literal["Autonegotiation", "HalfDuplex10Mbit", "FullDuplex10Mbit", "HalfDuplex100Mbit", "FullDuplex100Mbit", "Disabled"]
Protocols_Network_NicPrinterPortSpeedDuplexMode_Value_Parser = LiteralParser[Protocols_Network_NicPrinterPortSpeedDuplexMode_Value, int](
    name='Protocols_Network_NicPrinterPortSpeedDuplexMode_Value',
    literal_map={
        'Autonegotiation': 0,
        'HalfDuplex10Mbit': 1,
        'FullDuplex10Mbit': 2,
        'HalfDuplex100Mbit': 3,
        'FullDuplex100Mbit': 4,
        'Disabled': 255,
    },
)
Protocols_Network_RecoveryPointStatus_Value = Literal["RecoveryPointSet", "RecoveryPointRestored"]
Protocols_Network_RecoveryPointStatus_Value_Parser = LiteralParser[Protocols_Network_RecoveryPointStatus_Value, int](
    name='Protocols_Network_RecoveryPointStatus_Value',
    literal_map={
        'RecoveryPointSet': 1,
        'RecoveryPointRestored': 2,
    },
)
Protocols_Network_ResolverEnable_Value = Literal["Yes", "No"]
Protocols_Network_ResolverEnable_Value_Parser = LiteralParser[Protocols_Network_ResolverEnable_Value, int](
    name='Protocols_Network_ResolverEnable_Value',
    literal_map={
        'Yes': 1,
        'No': 0,
    },
)
Protocols_Network_SlpActiveDiscovery_Value = Literal["Disabled", "Enabled"]
Protocols_Network_SlpActiveDiscovery_Value_Parser = LiteralParser[Protocols_Network_SlpActiveDiscovery_Value, int](
    name='Protocols_Network_SlpActiveDiscovery_Value',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
    },
)
Protocols_Network_SlpEnable_Value = Literal["Yes", "No"]
Protocols_Network_SlpEnable_Value_Parser = LiteralParser[Protocols_Network_SlpEnable_Value, int](
    name='Protocols_Network_SlpEnable_Value',
    literal_map={
        'Yes': 1,
        'No': 0,
    },
)
Protocols_Network_SlpPassiveDiscovery_Value = Literal["Disabled", "Enabled"]
Protocols_Network_SlpPassiveDiscovery_Value_Parser = LiteralParser[Protocols_Network_SlpPassiveDiscovery_Value, int](
    name='Protocols_Network_SlpPassiveDiscovery_Value',
    literal_map={
        'Disabled': 0,
        'Enabled': 1,
    },
)
Protocols_Network_SlpUseBroadcast_Value = Literal["Yes", "No"]
Protocols_Network_SlpUseBroadcast_Value_Parser = LiteralParser[Protocols_Network_SlpUseBroadcast_Value, int](
    name='Protocols_Network_SlpUseBroadcast_Value',
    literal_map={
        'Yes': 1,
        'No': 0,
    },
)
Protocols_Network_UdpIntrospecEnable_Value = Literal["Yes", "No"]
Protocols_Network_UdpIntrospecEnable_Value_Parser = LiteralParser[Protocols_Network_UdpIntrospecEnable_Value, int](
    name='Protocols_Network_UdpIntrospecEnable_Value',
    literal_map={
        'Yes': 1,
        'No': 0,
    },
)
class Sys_SetRegister_RegisterAssignments_Entry(NamedTuple):
    ID: 'int'
    Value: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('ID', self.ID))
        args.append(('Value', self.Value))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
TTF_ReadByteStream_RxMod = Literal["Manchester", "Biphase", "Ind", "HIDP", "PSK", "SMPL"]
TTF_ReadByteStream_RxMod_Parser = LiteralParser[TTF_ReadByteStream_RxMod, int](
    name='TTF_ReadByteStream_RxMod',
    literal_map={
        'Manchester': 16,
        'Biphase': 32,
        'Ind': 48,
        'HIDP': 80,
        'PSK': 96,
        'SMPL': 112,
    },
)
Time = int
class UsbHost_SetupPipes_Pipes_Entry(NamedTuple):
    No: 'int'
    Type: 'Type'
    FrameSize: 'int'
    def __repr__(self) -> str:
        args: List[Tuple[str, Any]] = []
        args.append(('No', self.No))
        args.append(('Type', self.Type))
        args.append(('FrameSize', self.FrameSize))
        # Auto-format: positional for single field, keyword for multiple
        if len(args) == 1:
            formatted_args = [repr(args[0][1])]
        else:
            formatted_args = [f'{name}={repr(value)}' for name, value in args]
        return f'{type(self).__name__}({", ".join(formatted_args)})'
Type = Literal["Control", "Interrupt", "Bulk", "Isochronous"]
Type_Parser = LiteralParser[Type, int](
    name='Type',
    literal_map={
        'Control': 0,
        'Interrupt': 1,
        'Bulk': 2,
        'Isochronous': 3,
    },
)
UsbHost_SetupPipes_Type = Literal["Control", "Interrupt", "Bulk", "Isochronous"]
UsbHost_SetupPipes_Type_Parser = LiteralParser[UsbHost_SetupPipes_Type, int](
    name='UsbHost_SetupPipes_Type',
    literal_map={
        'Control': 0,
        'Interrupt': 1,
        'Bulk': 2,
        'Isochronous': 3,
    },
)
__all__: list[str] = [
    "Custom_AdminData_FactoryResetFirmwareVersion_Value_Entry",
    "Custom_Crypto_Key_Result",
    "DHWCtrl_AesDecrypt_WrappedKeyNr",
    "DHWCtrl_AesDecrypt_WrappedKeyNr_Parser",
    "DHWCtrl_AesEncrypt_WrappedKeyNr",
    "DHWCtrl_AesEncrypt_WrappedKeyNr_Parser",
    "DHWCtrl_AesWrapKey_WrappedKeyNr",
    "DHWCtrl_AesWrapKey_WrappedKeyNr_Parser",
    "DHWCtrl_DataflashGetSize_Result",
    "DHWCtrl_DispColor_Color",
    "DHWCtrl_DispColor_Color_Parser",
    "DHWCtrl_GetReaderChipType_ChipType",
    "DHWCtrl_GetReaderChipType_ChipType_Parser",
    "DHWCtrl_GetSamType_ChipType",
    "DHWCtrl_GetSamType_ChipType_Parser",
    "DHWCtrl_GetStartupRun_Result",
    "DHWCtrl_HfAcquire_ModuleId",
    "DHWCtrl_HfAcquire_ModuleId_Parser",
    "DHWCtrl_PortConfig_Mode",
    "DHWCtrl_PortConfig_Mode_Parser",
    "DHWCtrl_Run_Result",
    "Device_Boot_ConfigCardState_Value",
    "Device_Boot_ConfigCardState_Value_Parser",
    "Device_Boot_LegicAdvantInitialization_Value",
    "Device_Boot_LegicAdvantInitialization_Value_Parser",
    "Device_CryptoKey_Entry_Result",
    "Device_HostSecurity_KeyInternal_Result",
    "Device_Rgb_MaximizeIntensity_Value",
    "Device_Rgb_MaximizeIntensity_Value_Parser",
    "Device_Run_CardReadFailureLogging_Value",
    "Device_Run_CardReadFailureLogging_Value_Parser",
    "Device_Run_UsbSuspendMode_SuspendMode",
    "Device_Run_UsbSuspendMode_SuspendMode_Parser",
    "Device_VhlSettings125Khz_Baud_Baud",
    "Device_VhlSettings125Khz_Baud_Baud_Parser",
    "Device_VhlSettings125Khz_IndaspParityCheck_ParityDisable",
    "Device_VhlSettings125Khz_IndaspParityCheck_ParityDisable_Parser",
    "Device_VhlSettings125Khz_ModulationType_TTFMod",
    "Device_VhlSettings125Khz_ModulationType_TTFMod_Parser",
    "Device_VhlSettings_ForceReselect_Value",
    "Device_VhlSettings_ForceReselect_Value_Parser",
    "EM_DecodeCfg_RxMod",
    "EM_DecodeCfg_RxMod_Parser",
    "Eth_GetNetworkStatus_Result",
    "Eth_GetTcpConnectionStatus_Status",
    "Eth_GetTcpConnectionStatus_Status_Parser",
    "Eth_OpenTcpConnection_ConnectionReason",
    "Eth_OpenTcpConnection_ConnectionReason_Parser",
    "HID_PyramidRead_Result",
    "Hitag_Request_Mode",
    "Hitag_Request_Mode_Parser",
    "Hitag_Request_TagType",
    "Hitag_Request_TagType_Parser",
    "Hitag_Select_SelMode",
    "Hitag_Select_SelMode_Parser",
    "IoPortBitmask",
    "IoPortBitmask_Dict",
    "Iso14a_RequestLegacy_Result",
    "Iso14a_RequestLegacy_UIDSize",
    "Iso14a_RequestLegacy_UIDSize_Parser",
    "Iso14a_TransparentCmdBitlen_Result",
    "Iso15_ReadBlock_Data_Entry",
    "Iso15_ReadBlock_Result",
    "Legic_TransparentCommand4000_Result",
    "Legic_TransparentCommand6000_Result",
    "Lga_TransparentCommand_Result",
    "Main_Bf2Upload_Result",
    "Main_Bf2Upload_ResultCode",
    "Main_Bf2Upload_ResultCode_Parser",
    "Mce_Enable_Mode",
    "Mce_Enable_Mode_Parser",
    "Pki_Tunnel2_Result",
    "Project_Bluetooth_AdvertizingChannels_Result",
    "Project_Bluetooth_ConnectionMode_Value",
    "Project_Bluetooth_ConnectionMode_Value_Parser",
    "Project_Bluetooth_DiscoveryMode_Value",
    "Project_Bluetooth_DiscoveryMode_Value_Parser",
    "Project_Mce_Mode_Value",
    "Project_Mce_Mode_Value_Parser",
    "Project_VhlSettings125Khz_IndalaMode_Mode",
    "Project_VhlSettings125Khz_IndalaMode_Mode_Parser",
    "Project_VhlSettings_HandleLegicCTCAsSinglePrimeTransponder_Value",
    "Project_VhlSettings_HandleLegicCTCAsSinglePrimeTransponder_Value_Parser",
    "Protocols_Lbus_Channel_Value",
    "Protocols_Lbus_Channel_Value_Parser",
    "Protocols_Lbus_OfflineCompanyId_Result",
    "Protocols_Lbus_OfflineIndication_Value",
    "Protocols_Lbus_OfflineIndication_Value_Parser",
    "Protocols_Network_DetectIpEnable_Value",
    "Protocols_Network_DetectIpEnable_Value_Parser",
    "Protocols_Network_LinkLocalMode_Value",
    "Protocols_Network_LinkLocalMode_Value_Parser",
    "Protocols_Network_NicFlowControl_Value",
    "Protocols_Network_NicFlowControl_Value_Parser",
    "Protocols_Network_NicNetworkPortSpeedDuplexMode_Value",
    "Protocols_Network_NicNetworkPortSpeedDuplexMode_Value_Parser",
    "Protocols_Network_NicPrinterPortSpeedDuplexMode_Value",
    "Protocols_Network_NicPrinterPortSpeedDuplexMode_Value_Parser",
    "Protocols_Network_RecoveryPointStatus_Value",
    "Protocols_Network_RecoveryPointStatus_Value_Parser",
    "Protocols_Network_ResolverEnable_Value",
    "Protocols_Network_ResolverEnable_Value_Parser",
    "Protocols_Network_SlpActiveDiscovery_Value",
    "Protocols_Network_SlpActiveDiscovery_Value_Parser",
    "Protocols_Network_SlpEnable_Value",
    "Protocols_Network_SlpEnable_Value_Parser",
    "Protocols_Network_SlpPassiveDiscovery_Value",
    "Protocols_Network_SlpPassiveDiscovery_Value_Parser",
    "Protocols_Network_SlpUseBroadcast_Value",
    "Protocols_Network_SlpUseBroadcast_Value_Parser",
    "Protocols_Network_UdpIntrospecEnable_Value",
    "Protocols_Network_UdpIntrospecEnable_Value_Parser",
    "Sys_GetPlatformId_Result",
    "Sys_SetRegister_RegisterAssignments_Entry",
    "TTF_ReadByteStream_RxMod",
    "TTF_ReadByteStream_RxMod_Parser",
    "Time",
    "Type",
    "Type_Parser",
    "UsbHost_SetupPipes_Pipes_Entry",
    "UsbHost_SetupPipes_Type",
    "UsbHost_SetupPipes_Type_Parser",
]