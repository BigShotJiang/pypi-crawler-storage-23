
from io import BytesIO
from typing import Optional, Union, List, Dict, NamedTuple, Tuple, Any, Literal

from typing_extensions import Self

from ..generator_interface import safe_read_int_from_buffer, Command, FrameProcessor, PayloadTooLongError, PayloadTooShortError, PayloadFormatError
from .._public.typedefs import *
from .typedefs import *
from .._public.commands import PublicCommands
from .._public.protocols import BaltechScript
from .._public.protocols import BRP
from .._public.protocols import Template
class ASK_SecuraKeyRead(Command):
    CommandGroupId = 0x36
    CommandId = 0x01
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x36\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Data_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Data = _recv_buffer.read(_Data_len)
        if len(_Data) != _Data_len:
            raise PayloadTooShortError(_Data_len - len(_Data))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Data
class ASK_GproxRead(Command):
    CommandGroupId = 0x36
    CommandId = 0x02
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x36\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Data_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Data = _recv_buffer.read(_Data_len)
        if len(_Data) != _Data_len:
            raise PayloadTooShortError(_Data_len - len(_Data))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Data
class ASK_CotagRead(Command):
    CommandGroupId = 0x36
    CommandId = 0x03
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x36\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Data_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Data = _recv_buffer.read(_Data_len)
        if len(_Data) != _Data_len:
            raise PayloadTooShortError(_Data_len - len(_Data))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Data
class CardEmu_GetMaxFrameSize(Command):
    CommandGroupId = 0x47
    CommandId = 0x00
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x47\x00")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _MaxFrameSize = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _MaxFrameSize
class CardEmu_StartEmu(Command):
    CommandGroupId = 0x47
    CommandId = 0x01
    def build_frame(self, Snr: bytes, ATQA: int, SAK: int, Timeout: int, BrpTimeout: int = 1000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x47\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(b'\x00')
        if len(Snr) != 4:
            raise ValueError(Snr)
        _send_buffer.write(Snr)
        _send_buffer.write(ATQA.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(SAK.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Snr: bytes, ATQA: int, SAK: int, Timeout: int, BrpTimeout: int = 1000) -> bytes:
        request_frame = self.build_frame(Snr=Snr, ATQA=ATQA, SAK=SAK, Timeout=Timeout, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _FirstCmd_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _FirstCmd = _recv_buffer.read(_FirstCmd_len)
        if len(_FirstCmd) != _FirstCmd_len:
            raise PayloadTooShortError(_FirstCmd_len - len(_FirstCmd))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _FirstCmd
class CardEmu_TransparentCmd(Command):
    CommandGroupId = 0x47
    CommandId = 0x02
    def build_frame(self, Rsp: bytes, Timeout: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x47\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(int(len(Rsp)).to_bytes(2, byteorder='big'))
        _send_buffer.write(Rsp)
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Rsp: bytes, Timeout: int, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(Rsp=Rsp, Timeout=Timeout, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Cmd_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _Cmd = _recv_buffer.read(_Cmd_len)
        if len(_Cmd) != _Cmd_len:
            raise PayloadTooShortError(_Cmd_len - len(_Cmd))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Cmd
class CardEmu_GetExternalHfStatus(Command):
    CommandGroupId = 0x47
    CommandId = 0x03
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x47\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ExtFieldStat = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ExtFieldStat
class CardEmu_StartNfc(Command):
    CommandGroupId = 0x47
    CommandId = 0x04
    def build_frame(self, NfcAPassiv: bool = True, *, Snr: bytes, ATQA: int, SAK: int, Timeout: int, BrpTimeout: int = 1000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x47\x04")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (int(NfcAPassiv) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        if len(Snr) != 4:
            raise ValueError(Snr)
        _send_buffer.write(Snr)
        _send_buffer.write(ATQA.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(SAK.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, NfcAPassiv: bool = True, *, Snr: bytes, ATQA: int, SAK: int, Timeout: int, BrpTimeout: int = 1000) -> bytes:
        request_frame = self.build_frame(NfcAPassiv=NfcAPassiv, Snr=Snr, ATQA=ATQA, SAK=SAK, Timeout=Timeout, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _FirstCmd_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _FirstCmd = _recv_buffer.read(_FirstCmd_len)
        if len(_FirstCmd) != _FirstCmd_len:
            raise PayloadTooShortError(_FirstCmd_len - len(_FirstCmd))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _FirstCmd
class Dbg_ReadLogs(Command):
    CommandGroupId = 0xF3
    CommandId = 0x00
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xF3\x00")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> str:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _LogData_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _LogData_bytes = _recv_buffer.read(_LogData_len)
        _LogData = _LogData_bytes.decode('ascii')
        if len(_LogData) != _LogData_len:
            raise PayloadTooShortError(_LogData_len - len(_LogData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _LogData
class Dbg_RunCmd(Command):
    CommandGroupId = 0xF3
    CommandId = 0x01
    def build_frame(self, Cmd: str, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xF3\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if len(Cmd) != 1:
            raise ValueError(Cmd)
        _send_buffer.write(Cmd.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Cmd: str, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Cmd=Cmd, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class EM_DecodeCfg(Command):
    CommandGroupId = 0x31
    CommandId = 0x00
    def build_frame(self, RxMod: EM_DecodeCfg_RxMod = "Unknown", RxBaud: int = 0, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x31\x00")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(EM_DecodeCfg_RxMod_Parser.as_value(RxMod).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(RxBaud.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, RxMod: EM_DecodeCfg_RxMod = "Unknown", RxBaud: int = 0, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(RxMod=RxMod, RxBaud=RxBaud, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class EM_Read4100(Command):
    CommandGroupId = 0x31
    CommandId = 0x08
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x31\x08")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Data_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Data = _recv_buffer.read(_Data_len)
        if len(_Data) != _Data_len:
            raise PayloadTooShortError(_Data_len - len(_Data))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Data
class EM_Read4205(Command):
    CommandGroupId = 0x31
    CommandId = 0x10
    def build_frame(self, Address: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x31\x10")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Address.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Address: int, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(Address=Address, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Page = safe_read_int_from_buffer(_recv_buffer, 4)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Page
class EM_Write4205(Command):
    CommandGroupId = 0x31
    CommandId = 0x11
    def build_frame(self, Address: int, Page: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x31\x11")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Address.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Page.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Address: int, Page: int, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Address=Address, Page=Page, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class EM_Halt4205(Command):
    CommandGroupId = 0x31
    CommandId = 0x12
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x31\x12")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class EM_Login4205(Command):
    CommandGroupId = 0x31
    CommandId = 0x13
    def build_frame(self, Password: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x31\x13")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Password.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Password: int, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Password=Password, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class EM_Protect4205(Command):
    CommandGroupId = 0x31
    CommandId = 0x14
    def build_frame(self, ProtectMask: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x31\x14")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(ProtectMask.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, ProtectMask: int, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(ProtectMask=ProtectMask, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class EM_Read4469(Command):
    CommandGroupId = 0x31
    CommandId = 0x18
    def build_frame(self, Address: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x31\x18")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Address.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Address: int, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(Address=Address, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Page = safe_read_int_from_buffer(_recv_buffer, 4)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Page
class EM_Write4469(Command):
    CommandGroupId = 0x31
    CommandId = 0x19
    def build_frame(self, Address: int, Page: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x31\x19")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Address.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Page.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Address: int, Page: int, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Address=Address, Page=Page, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class EM_Halt4469(Command):
    CommandGroupId = 0x31
    CommandId = 0x1A
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x31\x1A")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class EM_Login4469(Command):
    CommandGroupId = 0x31
    CommandId = 0x1B
    def build_frame(self, Password: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x31\x1B")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Password.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Password: int, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Password=Password, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class EM_Read4450(Command):
    CommandGroupId = 0x31
    CommandId = 0x20
    def build_frame(self, StartAdr: int, EndAdr: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x31\x20")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(StartAdr.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(EndAdr.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, StartAdr: int, EndAdr: int, BrpTimeout: int = 100) -> List[int]:
        request_frame = self.build_frame(StartAdr=StartAdr, EndAdr=EndAdr, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _PageNr_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _PageNr = []  # type: ignore[var-annotated,unused-ignore]
        while not len(_PageNr) >= _PageNr_len:
            _Page = safe_read_int_from_buffer(_recv_buffer, 4)
            _PageNr.append(_Page)
        if len(_PageNr) != _PageNr_len:
            raise PayloadTooShortError(_PageNr_len - len(_PageNr))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _PageNr
class Eth_GetMacAdr(Command):
    CommandGroupId = 0x45
    CommandId = 0x00
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x45\x00")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _MAC = _recv_buffer.read(6)
        if len(_MAC) != 6:
            raise PayloadTooShortError(6 - len(_MAC))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _MAC
class Eth_GetConnDevIP(Command):
    CommandGroupId = 0x45
    CommandId = 0x01
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x45\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _IP = _recv_buffer.read(4)
        if len(_IP) != 4:
            raise PayloadTooShortError(4 - len(_IP))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _IP
class Eth_CreateRecoveryPoint(Command):
    CommandGroupId = 0x45
    CommandId = 0x02
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x45\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Eth_DelRecoveryPoint(Command):
    CommandGroupId = 0x45
    CommandId = 0x03
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x45\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Eth_GetNetworkStatus(Command):
    CommandGroupId = 0x45
    CommandId = 0x04
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x45\x04")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> Eth_GetNetworkStatus_Result:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _PortStatus = safe_read_int_from_buffer(_recv_buffer, 1)
        _StaticIPAdr = _recv_buffer.read(4)
        if len(_StaticIPAdr) != 4:
            raise PayloadTooShortError(4 - len(_StaticIPAdr))
        _StaticIPNetmask = _recv_buffer.read(4)
        if len(_StaticIPNetmask) != 4:
            raise PayloadTooShortError(4 - len(_StaticIPNetmask))
        _StaticIPGateway = _recv_buffer.read(4)
        if len(_StaticIPGateway) != 4:
            raise PayloadTooShortError(4 - len(_StaticIPGateway))
        _DHCPAdr = _recv_buffer.read(4)
        if len(_DHCPAdr) != 4:
            raise PayloadTooShortError(4 - len(_DHCPAdr))
        _DHCPNetmask = _recv_buffer.read(4)
        if len(_DHCPNetmask) != 4:
            raise PayloadTooShortError(4 - len(_DHCPNetmask))
        _DHCPGateway = _recv_buffer.read(4)
        if len(_DHCPGateway) != 4:
            raise PayloadTooShortError(4 - len(_DHCPGateway))
        _LinkLocalAdr = _recv_buffer.read(4)
        if len(_LinkLocalAdr) != 4:
            raise PayloadTooShortError(4 - len(_LinkLocalAdr))
        _LinkLocalNetmask = _recv_buffer.read(4)
        if len(_LinkLocalNetmask) != 4:
            raise PayloadTooShortError(4 - len(_LinkLocalNetmask))
        _LinkLocalGateway = _recv_buffer.read(4)
        if len(_LinkLocalGateway) != 4:
            raise PayloadTooShortError(4 - len(_LinkLocalGateway))
        _DNSAdr = _recv_buffer.read(4)
        if len(_DNSAdr) != 4:
            raise PayloadTooShortError(4 - len(_DNSAdr))
        _HostAdr = _recv_buffer.read(4)
        if len(_HostAdr) != 4:
            raise PayloadTooShortError(4 - len(_HostAdr))
        _HostPort = safe_read_int_from_buffer(_recv_buffer, 2)
        _AutocloseTimeout = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Eth_GetNetworkStatus_Result(_PortStatus, _StaticIPAdr, _StaticIPNetmask, _StaticIPGateway, _DHCPAdr, _DHCPNetmask, _DHCPGateway, _LinkLocalAdr, _LinkLocalNetmask, _LinkLocalGateway, _DNSAdr, _HostAdr, _HostPort, _AutocloseTimeout)
class Eth_GetMIBCounters(Command):
    CommandGroupId = 0x45
    CommandId = 0x05
    def build_frame(self, Port: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x45\x05")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Port.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Port: int, BrpTimeout: int = 100) -> List[int]:
        request_frame = self.build_frame(Port=Port, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _MIBCounterList_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _MIBCounterList = []  # type: ignore[var-annotated,unused-ignore]
        while not len(_MIBCounterList) >= _MIBCounterList_len:
            _Value = safe_read_int_from_buffer(_recv_buffer, 4)
            _MIBCounterList.append(_Value)
        if len(_MIBCounterList) != _MIBCounterList_len:
            raise PayloadTooShortError(_MIBCounterList_len - len(_MIBCounterList))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _MIBCounterList
class Eth_GetTcpConnectionStatus(Command):
    CommandGroupId = 0x45
    CommandId = 0x06
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x45\x06")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> Eth_GetTcpConnectionStatus_Status:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Status = Eth_GetTcpConnectionStatus_Status_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Status
class Eth_OpenTcpConnection(Command):
    CommandGroupId = 0x45
    CommandId = 0x07
    def build_frame(self, ConnectionReason: Eth_OpenTcpConnection_ConnectionReason, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x45\x07")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Eth_OpenTcpConnection_ConnectionReason_Parser.as_value(ConnectionReason).to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, ConnectionReason: Eth_OpenTcpConnection_ConnectionReason, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(ConnectionReason=ConnectionReason, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Eth_CloseTcpConnection(Command):
    CommandGroupId = 0x45
    CommandId = 0x08
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x45\x08")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class HID_IndalaRead(Command):
    CommandGroupId = 0x33
    CommandId = 0x00
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x33\x00")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Data_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Data = _recv_buffer.read(_Data_len)
        if len(_Data) != _Data_len:
            raise PayloadTooShortError(_Data_len - len(_Data))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Data
class HID_ProxRead(Command):
    CommandGroupId = 0x33
    CommandId = 0x01
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x33\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Data_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Data = _recv_buffer.read(_Data_len)
        if len(_Data) != _Data_len:
            raise PayloadTooShortError(_Data_len - len(_Data))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Data
class HID_AwidRead(Command):
    CommandGroupId = 0x33
    CommandId = 0x02
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x33\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Data_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Data = _recv_buffer.read(_Data_len)
        if len(_Data) != _Data_len:
            raise PayloadTooShortError(_Data_len - len(_Data))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Data
class HID_IoProxRead(Command):
    CommandGroupId = 0x33
    CommandId = 0x03
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x33\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Data_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Data = _recv_buffer.read(_Data_len)
        if len(_Data) != _Data_len:
            raise PayloadTooShortError(_Data_len - len(_Data))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Data
class HID_Prox32Read(Command):
    CommandGroupId = 0x33
    CommandId = 0x04
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x33\x04")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Data_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Data = _recv_buffer.read(_Data_len)
        if len(_Data) != _Data_len:
            raise PayloadTooShortError(_Data_len - len(_Data))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Data
class HID_PyramidRead(Command):
    CommandGroupId = 0x33
    CommandId = 0x05
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x33\x05")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> HID_PyramidRead_Result:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Data = _recv_buffer.read(-1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return HID_PyramidRead_Result(_Len, _Data)
class HID_IndalaSecureRead(Command):
    CommandGroupId = 0x33
    CommandId = 0x06
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x33\x06")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Data_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Data = _recv_buffer.read(_Data_len)
        if len(_Data) != _Data_len:
            raise PayloadTooShortError(_Data_len - len(_Data))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Data
class HID_IdteckRead(Command):
    CommandGroupId = 0x33
    CommandId = 0x07
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x33\x07")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Data_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Data = _recv_buffer.read(_Data_len)
        if len(_Data) != _Data_len:
            raise PayloadTooShortError(_Data_len - len(_Data))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Data
class Hitag_Request(Command):
    CommandGroupId = 0x30
    CommandId = 0x00
    def build_frame(self, TagType: Hitag_Request_TagType = "HitagS", Mode: Hitag_Request_Mode = "StdHtg12S", BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x30\x00")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Hitag_Request_TagType_Parser.as_value(TagType).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Hitag_Request_Mode_Parser.as_value(Mode).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, TagType: Hitag_Request_TagType = "HitagS", Mode: Hitag_Request_Mode = "StdHtg12S", BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(TagType=TagType, Mode=Mode, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Snr = safe_read_int_from_buffer(_recv_buffer, 4)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Snr
class Hitag_Select(Command):
    CommandGroupId = 0x30
    CommandId = 0x01
    def build_frame(self, SelMode: Optional[Hitag_Select_SelMode] = None, Pwd: Optional[int] = None, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x30\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if SelMode is None and (Pwd is not None):
            SelMode = "H2AuthOnlyPwd"
        if SelMode is None:
            SelMode = "Select"
        _send_buffer.write(Hitag_Select_SelMode_Parser.as_value(SelMode).to_bytes(length=1, byteorder='big'))
        if SelMode == "H2AuthOnlyPwd":
            if Pwd is None:
                raise TypeError("missing a required argument: 'Pwd'")
            _send_buffer.write(Pwd.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, SelMode: Optional[Hitag_Select_SelMode] = None, Pwd: Optional[int] = None, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(SelMode=SelMode, Pwd=Pwd, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Page1 = safe_read_int_from_buffer(_recv_buffer, 4)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Page1
class Hitag_Halt(Command):
    CommandGroupId = 0x30
    CommandId = 0x02
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x30\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Hitag_Read(Command):
    CommandGroupId = 0x30
    CommandId = 0x03
    def build_frame(self, Address: int, InvRead: bool = False, KeyB: bool = False, Encrypt: bool = False, BlockRead: bool = False, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x30\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Address.to_bytes(length=1, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (int(InvRead) & 0b1) << 3
        _var_0000_int |= (int(KeyB) & 0b1) << 2
        _var_0000_int |= (int(Encrypt) & 0b1) << 1
        _var_0000_int |= (int(BlockRead) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Address: int, InvRead: bool = False, KeyB: bool = False, Encrypt: bool = False, BlockRead: bool = False, BrpTimeout: int = 100) -> List[int]:
        request_frame = self.build_frame(Address=Address, InvRead=InvRead, KeyB=KeyB, Encrypt=Encrypt, BlockRead=BlockRead, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _PageNr_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _PageNr = []  # type: ignore[var-annotated,unused-ignore]
        while not len(_PageNr) >= _PageNr_len:
            _Page = safe_read_int_from_buffer(_recv_buffer, 4)
            _PageNr.append(_Page)
        if len(_PageNr) != _PageNr_len:
            raise PayloadTooShortError(_PageNr_len - len(_PageNr))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _PageNr
class Hitag_Write(Command):
    CommandGroupId = 0x30
    CommandId = 0x04
    def build_frame(self, Address: int, KeyB: bool = False, Encrypt: bool = False, BlockWrite: bool = False, *, PageNr: List[int], BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x30\x04")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Address.to_bytes(length=1, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (int(KeyB) & 0b1) << 2
        _var_0000_int |= (int(Encrypt) & 0b1) << 1
        _var_0000_int |= (int(BlockWrite) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(PageNr)).to_bytes(1, byteorder='big'))
        for _PageNr_Entry in PageNr:
            _Page = _PageNr_Entry
            _send_buffer.write(_Page.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Address: int, KeyB: bool = False, Encrypt: bool = False, BlockWrite: bool = False, *, PageNr: List[int], BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Address=Address, KeyB=KeyB, Encrypt=Encrypt, BlockWrite=BlockWrite, PageNr=PageNr, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Hitag_PersonaliseHtg(Command):
    CommandGroupId = 0x30
    CommandId = 0x10
    def build_frame(self, Reset: bool = False, HtgS: bool = False, *, Len: List[int], BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x30\x10")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (int(Reset) & 0b1) << 1
        _var_0000_int |= (int(HtgS) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(Len)).to_bytes(1, byteorder='big'))
        for _Len_Entry in Len:
            _Data = _Len_Entry
            _send_buffer.write(_Data.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Reset: bool = False, HtgS: bool = False, *, Len: List[int], BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Reset=Reset, HtgS=HtgS, Len=Len, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class I2c_SetSpeed(Command):
    CommandGroupId = 0x08
    CommandId = 0x01
    def build_frame(self, FastMode: bool = False, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x08\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(FastMode.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, FastMode: bool = False, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(FastMode=FastMode, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class I2c_Read(Command):
    CommandGroupId = 0x08
    CommandId = 0x02
    def build_frame(self, Address: int, ReadLen: int = 5, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x08\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Address.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(ReadLen.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Address: int, ReadLen: int = 5, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(Address=Address, ReadLen=ReadLen, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ReadData_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _ReadData = _recv_buffer.read(_ReadData_len)
        if len(_ReadData) != _ReadData_len:
            raise PayloadTooShortError(_ReadData_len - len(_ReadData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ReadData
class I2c_Write(Command):
    CommandGroupId = 0x08
    CommandId = 0x03
    def build_frame(self, Address: int, WriteData: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x08\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Address.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(WriteData)).to_bytes(1, byteorder='big'))
        _send_buffer.write(WriteData)
        return _send_buffer.getvalue()
    def __call__(self, Address: int, WriteData: bytes, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Address=Address, WriteData=WriteData, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class I2c_TxRx(Command):
    CommandGroupId = 0x08
    CommandId = 0x04
    def build_frame(self, Address: int, CmdData: bytes, ReadLen: int = 5, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x08\x04")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Address.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(CmdData)).to_bytes(1, byteorder='big'))
        _send_buffer.write(CmdData)
        _send_buffer.write(ReadLen.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Address: int, CmdData: bytes, ReadLen: int = 5, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(Address=Address, CmdData=CmdData, ReadLen=ReadLen, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ReadData_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _ReadData = _recv_buffer.read(_ReadData_len)
        if len(_ReadData) != _ReadData_len:
            raise PayloadTooShortError(_ReadData_len - len(_ReadData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ReadData
class Iso14a_RequestLegacy(Command):
    CommandGroupId = 0x13
    CommandId = 0x02
    def build_frame(self, ReqAll: bool = False, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x13\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (int(ReqAll) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, ReqAll: bool = False, BrpTimeout: int = 100) -> Iso14a_RequestLegacy_Result:
        request_frame = self.build_frame(ReqAll=ReqAll, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ATQA_int = safe_read_int_from_buffer(_recv_buffer, 2)
        _UIDSize = Iso14a_RequestLegacy_UIDSize_Parser.as_literal((_ATQA_int >> 14) & 0b11)
        _Coll = (_ATQA_int >> 8) & 0b11111
        _ProprietaryCoding = (_ATQA_int >> 0) & 0b1111
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Iso14a_RequestLegacy_Result(_UIDSize, _Coll, _ProprietaryCoding)
class Iso14a_Anticoll(Command):
    CommandGroupId = 0x13
    CommandId = 0x18
    def build_frame(self, BitCount: int = 0, *, PreSelectedSnr: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x13\x18")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(BitCount.to_bytes(length=1, byteorder='big'))
        if len(PreSelectedSnr) != 4:
            raise ValueError(PreSelectedSnr)
        _send_buffer.write(PreSelectedSnr)
        return _send_buffer.getvalue()
    def __call__(self, BitCount: int = 0, *, PreSelectedSnr: bytes, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(BitCount=BitCount, PreSelectedSnr=PreSelectedSnr, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _SelectedSnr = _recv_buffer.read(4)
        if len(_SelectedSnr) != 4:
            raise PayloadTooShortError(4 - len(_SelectedSnr))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _SelectedSnr
class Iso14a_SelectOnly(Command):
    CommandGroupId = 0x13
    CommandId = 0x19
    def build_frame(self, Snr: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x13\x19")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if len(Snr) != 4:
            raise ValueError(Snr)
        _send_buffer.write(Snr)
        return _send_buffer.getvalue()
    def __call__(self, Snr: bytes, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(Snr=Snr, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _SAK = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _SAK
class Iso14a_TransparentCmdBitlen(Command):
    CommandGroupId = 0x13
    CommandId = 0x23
    def build_frame(self, EnHighBaudOld: bool = False, *, EnParTx: bool, SendDataLen: int, Timeout: int = 26, DSI: DivisorInteger = "Kbps106", DRI: DivisorInteger = "Kbps106", SendData: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x13\x23")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (int(EnHighBaudOld) & 0b1) << 6
        _var_0000_int |= (int(EnParTx) & 0b1) << 5
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(SendDataLen.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        _var_0001_int = 0
        _var_0001_int |= (DivisorInteger_Parser.as_value(DSI) & 0b11) << 2
        _var_0001_int |= (DivisorInteger_Parser.as_value(DRI) & 0b11) << 0
        _send_buffer.write(_var_0001_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(SendData)
        return _send_buffer.getvalue()
    def __call__(self, EnHighBaudOld: bool = False, *, EnParTx: bool, SendDataLen: int, Timeout: int = 26, DSI: DivisorInteger = "Kbps106", DRI: DivisorInteger = "Kbps106", SendData: bytes, BrpTimeout: int = 100) -> Iso14a_TransparentCmdBitlen_Result:
        request_frame = self.build_frame(EnHighBaudOld=EnHighBaudOld, EnParTx=EnParTx, SendDataLen=SendDataLen, Timeout=Timeout, DSI=DSI, DRI=DRI, SendData=SendData, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _RecvDataLen = safe_read_int_from_buffer(_recv_buffer, 2)
        _CollisionPosition = safe_read_int_from_buffer(_recv_buffer, 2)
        _RecvData = _recv_buffer.read(-1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Iso14a_TransparentCmdBitlen_Result(_RecvDataLen, _CollisionPosition, _RecvData)
class Iso14CE_ActivateCardAPDU(Command):
    CommandGroupId = 0x4A
    CommandId = 0x01
    def build_frame(self, SpecifyTimeoutApdu: Optional[bool] = None, AutoWTX: bool = False, *, ATQA: int, Snr: bytes, DSEqualToDR: bool = False, DS8: bool = False, DS4: bool = False, DS2: bool = False, DR8: bool = False, DR4: bool = False, DR2: bool = False, FWT: int = 0, TimeoutPCD: int = 750, TimeoutApdu: Optional[int] = None, ATS: bytes, BrpTimeout: int = 2000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x4A\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if SpecifyTimeoutApdu is None and (TimeoutApdu is not None):
            SpecifyTimeoutApdu = True
        if SpecifyTimeoutApdu is None:
            SpecifyTimeoutApdu = False
        _var_0000_int = 0
        _var_0000_int |= (int(SpecifyTimeoutApdu) & 0b1) << 1
        _var_0000_int |= (int(AutoWTX) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(ATQA.to_bytes(length=2, byteorder='big'))
        if len(Snr) != 4:
            raise ValueError(Snr)
        _send_buffer.write(Snr)
        _var_0001_int = 0
        _var_0001_int |= (int(DSEqualToDR) & 0b1) << 7
        _var_0001_int |= (int(DS8) & 0b1) << 6
        _var_0001_int |= (int(DS4) & 0b1) << 5
        _var_0001_int |= (int(DS2) & 0b1) << 4
        _var_0001_int |= (int(DR8) & 0b1) << 2
        _var_0001_int |= (int(DR4) & 0b1) << 1
        _var_0001_int |= (int(DR2) & 0b1) << 0
        _send_buffer.write(_var_0001_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(FWT.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(TimeoutPCD.to_bytes(length=2, byteorder='big'))
        if SpecifyTimeoutApdu:
            if TimeoutApdu is None:
                raise TypeError("missing a required argument: 'TimeoutApdu'")
            _send_buffer.write(TimeoutApdu.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(int(len(ATS)).to_bytes(1, byteorder='big'))
        _send_buffer.write(ATS)
        return _send_buffer.getvalue()
    def __call__(self, SpecifyTimeoutApdu: Optional[bool] = None, AutoWTX: bool = False, *, ATQA: int, Snr: bytes, DSEqualToDR: bool = False, DS8: bool = False, DS4: bool = False, DS2: bool = False, DR8: bool = False, DR4: bool = False, DR2: bool = False, FWT: int = 0, TimeoutPCD: int = 750, TimeoutApdu: Optional[int] = None, ATS: bytes, BrpTimeout: int = 2000) -> bytes:
        request_frame = self.build_frame(SpecifyTimeoutApdu=SpecifyTimeoutApdu, AutoWTX=AutoWTX, ATQA=ATQA, Snr=Snr, DSEqualToDR=DSEqualToDR, DS8=DS8, DS4=DS4, DS2=DS2, DR8=DR8, DR4=DR4, DR2=DR2, FWT=FWT, TimeoutPCD=TimeoutPCD, TimeoutApdu=TimeoutApdu, ATS=ATS, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _FirstCmd_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _FirstCmd = _recv_buffer.read(_FirstCmd_len)
        if len(_FirstCmd) != _FirstCmd_len:
            raise PayloadTooShortError(_FirstCmd_len - len(_FirstCmd))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _FirstCmd
class Iso14CE_ExchangeCardAPDU(Command):
    CommandGroupId = 0x4A
    CommandId = 0x02
    def build_frame(self, Rsp: bytes, Timeout: int, BrpTimeout: int = 1000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x4A\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(int(len(Rsp)).to_bytes(2, byteorder='big'))
        _send_buffer.write(Rsp)
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Rsp: bytes, Timeout: int, BrpTimeout: int = 1000) -> bytes:
        request_frame = self.build_frame(Rsp=Rsp, Timeout=Timeout, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Cmd_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _Cmd = _recv_buffer.read(_Cmd_len)
        if len(_Cmd) != _Cmd_len:
            raise PayloadTooShortError(_Cmd_len - len(_Cmd))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Cmd
class Iso14CE_ExtendWaitingTime(Command):
    CommandGroupId = 0x4A
    CommandId = 0x03
    def build_frame(self, WaitingTimeout: int = 65535, WTXM: int = 1, RefreshTimeRatio: int = 90, BrpTimeout: int = 1000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x4A\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(WaitingTimeout.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(WTXM.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(RefreshTimeRatio.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, WaitingTimeout: int = 65535, WTXM: int = 1, RefreshTimeRatio: int = 90, BrpTimeout: int = 1000) -> None:
        request_frame = self.build_frame(WaitingTimeout=WaitingTimeout, WTXM=WTXM, RefreshTimeRatio=RefreshTimeRatio, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Iso14CE_GetExternalHfStatus(Command):
    CommandGroupId = 0x4A
    CommandId = 0x04
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x4A\x04")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ExtFieldStat = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ExtFieldStat
class Iso15_ReadBlock(Command):
    CommandGroupId = 0x21
    CommandId = 0x05
    def build_frame(self, BlockID: int = 0, BlockNum: int = 0, EnBlockSec: bool = True, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x21\x05")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(BlockID.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(BlockNum.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(EnBlockSec.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BlockID: int = 0, BlockNum: int = 0, EnBlockSec: bool = True, BrpTimeout: int = 100) -> Iso15_ReadBlock_Result:
        request_frame = self.build_frame(BlockID=BlockID, BlockNum=BlockNum, EnBlockSec=EnBlockSec, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _LabelStat = safe_read_int_from_buffer(_recv_buffer, 1)
        if _LabelStat == 0:
            _BlockLen = safe_read_int_from_buffer(_recv_buffer, 1)
            _Data = []  # type: ignore[var-annotated,unused-ignore]
            while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
                _BlockData = _recv_buffer.read(0)
                if len(_BlockData) != 0:
                    raise PayloadTooShortError(0 - len(_BlockData))
                if EnBlockSec:
                    _BlockSecData = safe_read_int_from_buffer(_recv_buffer, 1)
                else:
                    _BlockSecData = None
                _Data_Entry = Iso15_ReadBlock_Data_Entry(_BlockData, _BlockSecData)
                _Data.append(_Data_Entry)
        else:
            _BlockLen = None
            _Data = None
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Iso15_ReadBlock_Result(_LabelStat, _BlockLen, _Data)
class Iso15_WriteBlock(Command):
    CommandGroupId = 0x21
    CommandId = 0x06
    def build_frame(self, BlockID: int = 0, *, BlockNum: int, BlockLen: int, OptionFlag: bool = False, Data: List[bytes], BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x21\x06")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(BlockID.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(BlockNum.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(BlockLen.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(OptionFlag.to_bytes(length=1, byteorder='big'))
        for _Data_Entry in Data:
            _SingleBlock = _Data_Entry
            if len(_SingleBlock) != 0:
                raise ValueError(_SingleBlock)
            _send_buffer.write(_SingleBlock)
        return _send_buffer.getvalue()
    def __call__(self, BlockID: int = 0, *, BlockNum: int, BlockLen: int, OptionFlag: bool = False, Data: List[bytes], BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(BlockID=BlockID, BlockNum=BlockNum, BlockLen=BlockLen, OptionFlag=OptionFlag, Data=Data, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _LabelStat = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _LabelStat
class Iso15_TransparentCmdLegacy(Command):
    CommandGroupId = 0x21
    CommandId = 0x20
    def build_frame(self, EnRxWait: Optional[bool] = None, EnCRCRX: bool = True, EnCRCTX: bool = True, *, Len: int, Timeout: int = 26, Data: bytes, RxWait: Optional[int] = None, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x21\x20")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if EnRxWait is None and (RxWait is not None):
            EnRxWait = True
        if EnRxWait is None:
            EnRxWait = False
        _var_0000_int = 0
        _var_0000_int |= (int(EnRxWait) & 0b1) << 4
        _var_0000_int |= (int(EnCRCRX) & 0b1) << 3
        _var_0000_int |= (int(EnCRCTX) & 0b1) << 2
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Len.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        if len(Data) != 0:
            raise ValueError(Data)
        _send_buffer.write(Data)
        if EnRxWait:
            if RxWait is None:
                raise TypeError("missing a required argument: 'RxWait'")
            _send_buffer.write(RxWait.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, EnRxWait: Optional[bool] = None, EnCRCRX: bool = True, EnCRCTX: bool = True, *, Len: int, Timeout: int = 26, Data: bytes, RxWait: Optional[int] = None, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(EnRxWait=EnRxWait, EnCRCRX=EnCRCRX, EnCRCTX=EnCRCTX, Len=Len, Timeout=Timeout, Data=Data, RxWait=RxWait, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _LabelData_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _LabelData = _recv_buffer.read(_LabelData_len)
        if len(_LabelData) != _LabelData_len:
            raise PayloadTooShortError(_LabelData_len - len(_LabelData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _LabelData
class Iso78_SelectSlot(Command):
    CommandGroupId = 0x40
    CommandId = 0x00
    def build_frame(self, SlotIndex: int = 1, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x40\x00")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(SlotIndex.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, SlotIndex: int = 1, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(SlotIndex=SlotIndex, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Iso78_OpenSamLegacy(Command):
    CommandGroupId = 0x40
    CommandId = 0x01
    def build_frame(self, BrpTimeout: int = 1200) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x40\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 1200) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ATR_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _ATR = _recv_buffer.read(_ATR_len)
        if len(_ATR) != _ATR_len:
            raise PayloadTooShortError(_ATR_len - len(_ATR))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ATR
class Iso78_CloseSamLegacy(Command):
    CommandGroupId = 0x40
    CommandId = 0x02
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x40\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Iso78_ExchangeApduLegacy(Command):
    CommandGroupId = 0x40
    CommandId = 0x03
    def build_frame(self, SendData: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x40\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(int(len(SendData)).to_bytes(2, byteorder='big'))
        _send_buffer.write(SendData)
        return _send_buffer.getvalue()
    def __call__(self, SendData: bytes, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(SendData=SendData, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _RecvData_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _RecvData = _recv_buffer.read(_RecvData_len)
        if len(_RecvData) != _RecvData_len:
            raise PayloadTooShortError(_RecvData_len - len(_RecvData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _RecvData
class Legic_TransparentCommand4000(Command):
    CommandGroupId = 0x1E
    CommandId = 0x20
    def build_frame(self, CmdCode: int, CmdParams: bytes, Timeout: int = 100, BrpTimeout: int = 3000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1E\x20")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(CmdCode.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(CmdParams)).to_bytes(1, byteorder='big'))
        _send_buffer.write(CmdParams)
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, CmdCode: int, CmdParams: bytes, Timeout: int = 100, BrpTimeout: int = 3000) -> Legic_TransparentCommand4000_Result:
        request_frame = self.build_frame(CmdCode=CmdCode, CmdParams=CmdParams, Timeout=Timeout, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Status = safe_read_int_from_buffer(_recv_buffer, 1)
        _Resp_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Resp = _recv_buffer.read(_Resp_len)
        if len(_Resp) != _Resp_len:
            raise PayloadTooShortError(_Resp_len - len(_Resp))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Legic_TransparentCommand4000_Result(_Status, _Resp)
class Legic_TransparentCommand6000(Command):
    CommandGroupId = 0x1E
    CommandId = 0x21
    def build_frame(self, CmdCode: int, CmdParams: bytes, Timeout: int = 100, BrpTimeout: int = 3000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1E\x21")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(CmdCode.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(CmdParams)).to_bytes(1, byteorder='big'))
        _send_buffer.write(CmdParams)
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, CmdCode: int, CmdParams: bytes, Timeout: int = 100, BrpTimeout: int = 3000) -> Legic_TransparentCommand6000_Result:
        request_frame = self.build_frame(CmdCode=CmdCode, CmdParams=CmdParams, Timeout=Timeout, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Status = safe_read_int_from_buffer(_recv_buffer, 1)
        _Resp_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Resp = _recv_buffer.read(_Resp_len)
        if len(_Resp) != _Resp_len:
            raise PayloadTooShortError(_Resp_len - len(_Resp))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Legic_TransparentCommand6000_Result(_Status, _Resp)
class Lga_TransparentCommand(Command):
    CommandGroupId = 0x12
    CommandId = 0x20
    def build_frame(self, CmdCode: int, CmdParams: bytes, Timeout: int = 100, BrpTimeout: int = 3000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x12\x20")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(CmdCode.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(CmdParams)).to_bytes(1, byteorder='big'))
        _send_buffer.write(CmdParams)
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, CmdCode: int, CmdParams: bytes, Timeout: int = 100, BrpTimeout: int = 3000) -> Lga_TransparentCommand_Result:
        request_frame = self.build_frame(CmdCode=CmdCode, CmdParams=CmdParams, Timeout=Timeout, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Status = safe_read_int_from_buffer(_recv_buffer, 1)
        _Resp_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Resp = _recv_buffer.read(_Resp_len)
        if len(_Resp) != _Resp_len:
            raise PayloadTooShortError(_Resp_len - len(_Resp))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Lga_TransparentCommand_Result(_Status, _Resp)
class Main_Bf2Upload(Command):
    CommandGroupId = 0xF0
    CommandId = 0x01
    def build_frame(self, Bf2Line: bytes, BrpTimeout: int = 5000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xF0\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Bf2Line)
        return _send_buffer.getvalue()
    def __call__(self, Bf2Line: bytes, BrpTimeout: int = 5000) -> Main_Bf2Upload_Result:
        request_frame = self.build_frame(Bf2Line=Bf2Line, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ResultCode = Main_Bf2Upload_ResultCode_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _InvertedResultCode = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Main_Bf2Upload_Result(_ResultCode, _InvertedResultCode)
class Main_SwitchFW(Command):
    CommandGroupId = 0xF0
    CommandId = 0x02
    def build_frame(self, BrpTimeout: int = 5000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xF0\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 5000) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Main_MatchPlatformId2(Command):
    CommandGroupId = 0xF0
    CommandId = 0x04
    def build_frame(self, Filter: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xF0\x04")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Filter)
        return _send_buffer.getvalue()
    def __call__(self, Filter: bytes, BrpTimeout: int = 100) -> bool:
        request_frame = self.build_frame(Filter=Filter, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Matches = bool(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Matches
class Main_IsFirmwareUpToDate(Command):
    CommandGroupId = 0xF0
    CommandId = 0x05
    def build_frame(self, VersionDesc: bytes, BrpTimeout: int = 5000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xF0\x05")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(int(len(VersionDesc)).to_bytes(1, byteorder='big'))
        _send_buffer.write(VersionDesc)
        return _send_buffer.getvalue()
    def __call__(self, VersionDesc: bytes, BrpTimeout: int = 5000) -> None:
        request_frame = self.build_frame(VersionDesc=VersionDesc, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Mce_Enable(Command):
    CommandGroupId = 0x4D
    CommandId = 0x01
    def build_frame(self, Mode: Mce_Enable_Mode, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x4D\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Mce_Enable_Mode_Parser.as_value(Mode).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Mode: Mce_Enable_Mode, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Mode=Mode, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Mce_Request(Command):
    CommandGroupId = 0x4D
    CommandId = 0x02
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x4D\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Snr_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Snr = _recv_buffer.read(_Snr_len)
        if len(_Snr) != _Snr_len:
            raise PayloadTooShortError(_Snr_len - len(_Snr))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Snr
class Mif_Request(Command):
    CommandGroupId = 0x10
    CommandId = 0x01
    def build_frame(self, ReqAll: bool = False, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (int(ReqAll) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, ReqAll: bool = False, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(ReqAll=ReqAll, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ATQA = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ATQA
class Mif_Anticoll(Command):
    CommandGroupId = 0x10
    CommandId = 0x02
    def build_frame(self, BitCount: int = 0, *, PreSelSer: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(BitCount.to_bytes(length=1, byteorder='big'))
        if len(PreSelSer) != 4:
            raise ValueError(PreSelSer)
        _send_buffer.write(PreSelSer)
        return _send_buffer.getvalue()
    def __call__(self, BitCount: int = 0, *, PreSelSer: bytes, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(BitCount=BitCount, PreSelSer=PreSelSer, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Snr = _recv_buffer.read(4)
        if len(_Snr) != 4:
            raise PayloadTooShortError(4 - len(_Snr))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Snr
class Mif_Select(Command):
    CommandGroupId = 0x10
    CommandId = 0x03
    def build_frame(self, Snr: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if len(Snr) != 4:
            raise ValueError(Snr)
        _send_buffer.write(Snr)
        return _send_buffer.getvalue()
    def __call__(self, Snr: bytes, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(Snr=Snr, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _SAK = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _SAK
class Mif_Halt(Command):
    CommandGroupId = 0x10
    CommandId = 0x0B
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x10\x0B")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Pico_SetHfMode(Command):
    CommandGroupId = 0x1A
    CommandId = 0x00
    def build_frame(self, HfMode: int = 1, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1A\x00")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(HfMode.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, HfMode: int = 1, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(HfMode=HfMode, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Pico_RequestAnticoll(Command):
    CommandGroupId = 0x1A
    CommandId = 0x01
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1A\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ASNB_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _ASNB = _recv_buffer.read(_ASNB_len)
        if len(_ASNB) != _ASNB_len:
            raise PayloadTooShortError(_ASNB_len - len(_ASNB))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ASNB
class Pico_Select(Command):
    CommandGroupId = 0x1A
    CommandId = 0x02
    def build_frame(self, ASNB: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1A\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(int(len(ASNB)).to_bytes(1, byteorder='big'))
        _send_buffer.write(ASNB)
        return _send_buffer.getvalue()
    def __call__(self, ASNB: bytes, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(ASNB=ASNB, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Serial_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Serial = _recv_buffer.read(_Serial_len)
        if len(_Serial) != _Serial_len:
            raise PayloadTooShortError(_Serial_len - len(_Serial))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Serial
class Pico_Halt(Command):
    CommandGroupId = 0x1A
    CommandId = 0x03
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1A\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Pico_SelectBookPage(Command):
    CommandGroupId = 0x1A
    CommandId = 0x04
    def build_frame(self, Book: int = 0, Page: int = 0, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1A\x04")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Book.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Page.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Book: int = 0, Page: int = 0, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(Book=Book, Page=Page, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Page1_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Page1 = _recv_buffer.read(_Page1_len)
        if len(_Page1) != _Page1_len:
            raise PayloadTooShortError(_Page1_len - len(_Page1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Page1
class Pico_Authenticate(Command):
    CommandGroupId = 0x1A
    CommandId = 0x05
    def build_frame(self, IsDebitKey: bool = False, KeyIdx: int = 0, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1A\x05")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(IsDebitKey.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(KeyIdx.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, IsDebitKey: bool = False, KeyIdx: int = 0, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(IsDebitKey=IsDebitKey, KeyIdx=KeyIdx, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Pico_Read(Command):
    CommandGroupId = 0x1A
    CommandId = 0x06
    def build_frame(self, PageAdr: int = 0, PageNr: int = 0, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1A\x06")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(PageAdr.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(PageNr.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, PageAdr: int = 0, PageNr: int = 0, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(PageAdr=PageAdr, PageNr=PageNr, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _PageData_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _PageData = _recv_buffer.read(_PageData_len)
        if len(_PageData) != _PageData_len:
            raise PayloadTooShortError(_PageData_len - len(_PageData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _PageData
class Pico_Write(Command):
    CommandGroupId = 0x1A
    CommandId = 0x07
    def build_frame(self, PageAdr: int = 0, *, PageData: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x1A\x07")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(PageAdr.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(PageData)).to_bytes(1, byteorder='big'))
        _send_buffer.write(PageData)
        return _send_buffer.getvalue()
    def __call__(self, PageAdr: int = 0, *, PageData: bytes, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(PageAdr=PageAdr, PageData=PageData, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Pki_PfsGenKey(Command):
    CommandGroupId = 0x09
    CommandId = 0x01
    def build_frame(self, TmpHostPubKey: bytes, BrpTimeout: int = 16000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x09\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(int(len(TmpHostPubKey)).to_bytes(2, byteorder='big'))
        _send_buffer.write(TmpHostPubKey)
        return _send_buffer.getvalue()
    def __call__(self, TmpHostPubKey: bytes, BrpTimeout: int = 16000) -> bytes:
        request_frame = self.build_frame(TmpHostPubKey=TmpHostPubKey, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _TmpRdrPubKey_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _TmpRdrPubKey = _recv_buffer.read(_TmpRdrPubKey_len)
        if len(_TmpRdrPubKey) != _TmpRdrPubKey_len:
            raise PayloadTooShortError(_TmpRdrPubKey_len - len(_TmpRdrPubKey))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _TmpRdrPubKey
class Pki_PfsAuthHostCert(Command):
    CommandGroupId = 0x09
    CommandId = 0x02
    def build_frame(self, EncryptedPayload: bytes, BrpTimeout: int = 16000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x09\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(int(len(EncryptedPayload)).to_bytes(2, byteorder='big'))
        _send_buffer.write(EncryptedPayload)
        return _send_buffer.getvalue()
    def __call__(self, EncryptedPayload: bytes, BrpTimeout: int = 16000) -> None:
        request_frame = self.build_frame(EncryptedPayload=EncryptedPayload, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Pki_PfsAuthRdrCert(Command):
    CommandGroupId = 0x09
    CommandId = 0x03
    def build_frame(self, BrpTimeout: int = 16000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x09\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 16000) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _EncryptedResponse_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _EncryptedResponse = _recv_buffer.read(_EncryptedResponse_len)
        if len(_EncryptedResponse) != _EncryptedResponse_len:
            raise PayloadTooShortError(_EncryptedResponse_len - len(_EncryptedResponse))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _EncryptedResponse
class Pki_Tunnel2(Command):
    CommandGroupId = 0x09
    CommandId = 0x04
    def build_frame(self, SequenceCounter: int, CmdHMAC: bytes, EncryptedCmd: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x09\x04")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(SequenceCounter.to_bytes(length=4, byteorder='big'))
        if len(CmdHMAC) != 16:
            raise ValueError(CmdHMAC)
        _send_buffer.write(CmdHMAC)
        _send_buffer.write(int(len(EncryptedCmd)).to_bytes(2, byteorder='big'))
        _send_buffer.write(EncryptedCmd)
        return _send_buffer.getvalue()
    def __call__(self, SequenceCounter: int, CmdHMAC: bytes, EncryptedCmd: bytes, BrpTimeout: int = 100) -> Pki_Tunnel2_Result:
        request_frame = self.build_frame(SequenceCounter=SequenceCounter, CmdHMAC=CmdHMAC, EncryptedCmd=EncryptedCmd, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _RspHMAC = _recv_buffer.read(16)
        if len(_RspHMAC) != 16:
            raise PayloadTooShortError(16 - len(_RspHMAC))
        _EncryptedRsp_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _EncryptedRsp = _recv_buffer.read(_EncryptedRsp_len)
        if len(_EncryptedRsp) != _EncryptedRsp_len:
            raise PayloadTooShortError(_EncryptedRsp_len - len(_EncryptedRsp))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Pki_Tunnel2_Result(_RspHMAC, _EncryptedRsp)
class Pki_GetX509Csr(Command):
    CommandGroupId = 0x09
    CommandId = 0x10
    def build_frame(self, BrpTimeout: int = 16000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x09\x10")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 16000) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Csr_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _Csr = _recv_buffer.read(_Csr_len)
        if len(_Csr) != _Csr_len:
            raise PayloadTooShortError(_Csr_len - len(_Csr))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Csr
class Pki_StoreX509Cert(Command):
    CommandGroupId = 0x09
    CommandId = 0x11
    def build_frame(self, SecLevel: int, Cert: bytes, BrpTimeout: int = 16000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x09\x11")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(SecLevel.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(Cert)).to_bytes(2, byteorder='big'))
        _send_buffer.write(Cert)
        return _send_buffer.getvalue()
    def __call__(self, SecLevel: int, Cert: bytes, BrpTimeout: int = 16000) -> None:
        request_frame = self.build_frame(SecLevel=SecLevel, Cert=Cert, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Pki_StoreX509RootCert(Command):
    CommandGroupId = 0x09
    CommandId = 0x12
    def build_frame(self, SecLevel: int, Cert: bytes, BrpTimeout: int = 16000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x09\x12")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(SecLevel.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(Cert)).to_bytes(2, byteorder='big'))
        _send_buffer.write(Cert)
        return _send_buffer.getvalue()
    def __call__(self, SecLevel: int, Cert: bytes, BrpTimeout: int = 16000) -> None:
        request_frame = self.build_frame(SecLevel=SecLevel, Cert=Cert, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class QKey_Read(Command):
    CommandGroupId = 0x35
    CommandId = 0x00
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x35\x00")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Data_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Data = _recv_buffer.read(_Data_len)
        if len(_Data) != _Data_len:
            raise PayloadTooShortError(_Data_len - len(_Data))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Data
class Rtc_GetTime(Command):
    CommandGroupId = 0x04
    CommandId = 0x00
    def build_frame(self, ClockId: int = 255, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x04\x00")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(ClockId.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, ClockId: int = 255, BrpTimeout: int = 100) -> Time:
        request_frame = self.build_frame(ClockId=ClockId, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Now = safe_read_int_from_buffer(_recv_buffer, 4)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Now
class Rtc_SetTime(Command):
    CommandGroupId = 0x04
    CommandId = 0x01
    def build_frame(self, ClockId: int = 255, *, Now: Time, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x04\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(ClockId.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Now.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, ClockId: int = 255, *, Now: Time, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(ClockId=ClockId, Now=Now, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Srix_Select(Command):
    CommandGroupId = 0x24
    CommandId = 0x00
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x24\x00")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Snr_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Snr = _recv_buffer.read(_Snr_len)
        if len(_Snr) != _Snr_len:
            raise PayloadTooShortError(_Snr_len - len(_Snr))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Snr
class Srix_Read(Command):
    CommandGroupId = 0x24
    CommandId = 0x01
    def build_frame(self, Adr: int = 0, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x24\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Adr.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Adr: int = 0, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(Adr=Adr, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Data_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Data = _recv_buffer.read(_Data_len)
        if len(_Data) != _Data_len:
            raise PayloadTooShortError(_Data_len - len(_Data))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Data
class Srix_Write(Command):
    CommandGroupId = 0x24
    CommandId = 0x02
    def build_frame(self, Adr: int = 0, *, Data: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x24\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Adr.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(Data)).to_bytes(1, byteorder='big'))
        _send_buffer.write(Data)
        return _send_buffer.getvalue()
    def __call__(self, Adr: int = 0, *, Data: bytes, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Adr=Adr, Data=Data, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sys_GetPort(Command):
    CommandGroupId = 0x00
    CommandId = 0x06
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x06")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> IoPortBitmask:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _PortMask_int = safe_read_int_from_buffer(_recv_buffer, 2)
        _Gpio7 = bool((_PortMask_int >> 15) & 0b1)
        _Gpio6 = bool((_PortMask_int >> 14) & 0b1)
        _Gpio5 = bool((_PortMask_int >> 13) & 0b1)
        _Gpio4 = bool((_PortMask_int >> 12) & 0b1)
        _Gpio3 = bool((_PortMask_int >> 11) & 0b1)
        _Gpio2 = bool((_PortMask_int >> 10) & 0b1)
        _Gpio1 = bool((_PortMask_int >> 9) & 0b1)
        _Gpio0 = bool((_PortMask_int >> 8) & 0b1)
        _TamperAlarm = bool((_PortMask_int >> 7) & 0b1)
        _BlueLed = bool((_PortMask_int >> 6) & 0b1)
        _Input1 = bool((_PortMask_int >> 5) & 0b1)
        _Input0 = bool((_PortMask_int >> 4) & 0b1)
        _Relay = bool((_PortMask_int >> 3) & 0b1)
        _Beeper = bool((_PortMask_int >> 2) & 0b1)
        _RedLed = bool((_PortMask_int >> 1) & 0b1)
        _GreenLed = bool((_PortMask_int >> 0) & 0b1)
        _PortMask = IoPortBitmask(_Gpio7, _Gpio6, _Gpio5, _Gpio4, _Gpio3, _Gpio2, _Gpio1, _Gpio0, _TamperAlarm, _BlueLed, _Input1, _Input0, _Relay, _Beeper, _RedLed, _GreenLed)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _PortMask
class Sys_SetPort(Command):
    CommandGroupId = 0x00
    CommandId = 0x07
    def build_frame(self, PortMask: Union[IoPortBitmask, IoPortBitmask_Dict], BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x07")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if isinstance(PortMask, dict):
            PortMask = IoPortBitmask(**PortMask)
        PortMask_int = 0
        PortMask_int |= (int(PortMask.Gpio7) & 0b1) << 15
        PortMask_int |= (int(PortMask.Gpio6) & 0b1) << 14
        PortMask_int |= (int(PortMask.Gpio5) & 0b1) << 13
        PortMask_int |= (int(PortMask.Gpio4) & 0b1) << 12
        PortMask_int |= (int(PortMask.Gpio3) & 0b1) << 11
        PortMask_int |= (int(PortMask.Gpio2) & 0b1) << 10
        PortMask_int |= (int(PortMask.Gpio1) & 0b1) << 9
        PortMask_int |= (int(PortMask.Gpio0) & 0b1) << 8
        PortMask_int |= (int(PortMask.TamperAlarm) & 0b1) << 7
        PortMask_int |= (int(PortMask.BlueLed) & 0b1) << 6
        PortMask_int |= (int(PortMask.Input1) & 0b1) << 5
        PortMask_int |= (int(PortMask.Input0) & 0b1) << 4
        PortMask_int |= (int(PortMask.Relay) & 0b1) << 3
        PortMask_int |= (int(PortMask.Beeper) & 0b1) << 2
        PortMask_int |= (int(PortMask.RedLed) & 0b1) << 1
        PortMask_int |= (int(PortMask.GreenLed) & 0b1) << 0
        _send_buffer.write(PortMask_int.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, PortMask: Union[IoPortBitmask, IoPortBitmask_Dict], BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(PortMask=PortMask, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sys_CfgWriteTlvSector(Command):
    CommandGroupId = 0x00
    CommandId = 0x0D
    def build_frame(self, TlvBlock: bytes, BrpTimeout: int = 10000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x0D")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(TlvBlock)
        return _send_buffer.getvalue()
    def __call__(self, TlvBlock: bytes, BrpTimeout: int = 10000) -> None:
        request_frame = self.build_frame(TlvBlock=TlvBlock, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sys_ConfigPort(Command):
    CommandGroupId = 0x00
    CommandId = 0x0E
    def build_frame(self, InpOutp: Union[IoPortBitmask, IoPortBitmask_Dict], DefaultState: Union[IoPortBitmask, IoPortBitmask_Dict], BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x0E")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if isinstance(InpOutp, dict):
            InpOutp = IoPortBitmask(**InpOutp)
        InpOutp_int = 0
        InpOutp_int |= (int(InpOutp.Gpio7) & 0b1) << 15
        InpOutp_int |= (int(InpOutp.Gpio6) & 0b1) << 14
        InpOutp_int |= (int(InpOutp.Gpio5) & 0b1) << 13
        InpOutp_int |= (int(InpOutp.Gpio4) & 0b1) << 12
        InpOutp_int |= (int(InpOutp.Gpio3) & 0b1) << 11
        InpOutp_int |= (int(InpOutp.Gpio2) & 0b1) << 10
        InpOutp_int |= (int(InpOutp.Gpio1) & 0b1) << 9
        InpOutp_int |= (int(InpOutp.Gpio0) & 0b1) << 8
        InpOutp_int |= (int(InpOutp.TamperAlarm) & 0b1) << 7
        InpOutp_int |= (int(InpOutp.BlueLed) & 0b1) << 6
        InpOutp_int |= (int(InpOutp.Input1) & 0b1) << 5
        InpOutp_int |= (int(InpOutp.Input0) & 0b1) << 4
        InpOutp_int |= (int(InpOutp.Relay) & 0b1) << 3
        InpOutp_int |= (int(InpOutp.Beeper) & 0b1) << 2
        InpOutp_int |= (int(InpOutp.RedLed) & 0b1) << 1
        InpOutp_int |= (int(InpOutp.GreenLed) & 0b1) << 0
        _send_buffer.write(InpOutp_int.to_bytes(length=2, byteorder='big'))
        if isinstance(DefaultState, dict):
            DefaultState = IoPortBitmask(**DefaultState)
        DefaultState_int = 0
        DefaultState_int |= (int(DefaultState.Gpio7) & 0b1) << 15
        DefaultState_int |= (int(DefaultState.Gpio6) & 0b1) << 14
        DefaultState_int |= (int(DefaultState.Gpio5) & 0b1) << 13
        DefaultState_int |= (int(DefaultState.Gpio4) & 0b1) << 12
        DefaultState_int |= (int(DefaultState.Gpio3) & 0b1) << 11
        DefaultState_int |= (int(DefaultState.Gpio2) & 0b1) << 10
        DefaultState_int |= (int(DefaultState.Gpio1) & 0b1) << 9
        DefaultState_int |= (int(DefaultState.Gpio0) & 0b1) << 8
        DefaultState_int |= (int(DefaultState.TamperAlarm) & 0b1) << 7
        DefaultState_int |= (int(DefaultState.BlueLed) & 0b1) << 6
        DefaultState_int |= (int(DefaultState.Input1) & 0b1) << 5
        DefaultState_int |= (int(DefaultState.Input0) & 0b1) << 4
        DefaultState_int |= (int(DefaultState.Relay) & 0b1) << 3
        DefaultState_int |= (int(DefaultState.Beeper) & 0b1) << 2
        DefaultState_int |= (int(DefaultState.RedLed) & 0b1) << 1
        DefaultState_int |= (int(DefaultState.GreenLed) & 0b1) << 0
        _send_buffer.write(DefaultState_int.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, InpOutp: Union[IoPortBitmask, IoPortBitmask_Dict], DefaultState: Union[IoPortBitmask, IoPortBitmask_Dict], BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(InpOutp=InpOutp, DefaultState=DefaultState, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sys_SetRegister(Command):
    CommandGroupId = 0x00
    CommandId = 0x0F
    def build_frame(self, ResetRegister: bool = False, *, RegisterAssignments: List[Sys_SetRegister_RegisterAssignments_Entry], BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x0F")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(ResetRegister.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(RegisterAssignments)).to_bytes(1, byteorder='big'))
        for _RegisterAssignments_Entry in RegisterAssignments:
            _ID, _Value = _RegisterAssignments_Entry
            _send_buffer.write(_ID.to_bytes(length=2, byteorder='big'))
            _send_buffer.write(_Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, ResetRegister: bool = False, *, RegisterAssignments: List[Sys_SetRegister_RegisterAssignments_Entry], BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(ResetRegister=ResetRegister, RegisterAssignments=RegisterAssignments, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sys_GetRegister(Command):
    CommandGroupId = 0x00
    CommandId = 0x10
    def build_frame(self, ID: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x10")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(ID.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, ID: int, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(ID=ID, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
class Sys_PowerDown(Command):
    CommandGroupId = 0x00
    CommandId = 0x11
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x11")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sys_SetCommParam(Command):
    CommandGroupId = 0x00
    CommandId = 0x14
    def build_frame(self, NewBaudrate: Baudrate = "Baud115200", *, NewParity: Parity, CWT: int = 20, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x14")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Baudrate_Parser.as_value(NewBaudrate).to_bytes(length=2, byteorder='big'))
        _send_buffer.write(Parity_Parser.as_value(NewParity).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(CWT.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, NewBaudrate: Baudrate = "Baud115200", *, NewParity: Parity, CWT: int = 20, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(NewBaudrate=NewBaudrate, NewParity=NewParity, CWT=CWT, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sys_GetPlatformId(Command):
    CommandGroupId = 0x00
    CommandId = 0x17
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x17")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> Sys_GetPlatformId_Result:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _PlatformId = _recv_buffer.read(5)
        if len(_PlatformId) != 5:
            raise PayloadTooShortError(5 - len(_PlatformId))
        _BootloaderId = safe_read_int_from_buffer(_recv_buffer, 1)
        _BootloaderMajor = safe_read_int_from_buffer(_recv_buffer, 1)
        _BootloaderMinor = safe_read_int_from_buffer(_recv_buffer, 1)
        _BootloaderBuild = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Sys_GetPlatformId_Result(_PlatformId, _BootloaderId, _BootloaderMajor, _BootloaderMinor, _BootloaderBuild)
class Sys_FactoryResetLegacy(Command):
    CommandGroupId = 0x00
    CommandId = 0x22
    def build_frame(self, BrpTimeout: int = 30000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x22")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 30000) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class Sys_GetFwCrc(Command):
    CommandGroupId = 0x00
    CommandId = 0x7F
    def build_frame(self, BrpTimeout: int = 1000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x00\x7F")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 1000) -> int:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _CRC = safe_read_int_from_buffer(_recv_buffer, 4)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _CRC
class TTF_ReadByteStream(Command):
    CommandGroupId = 0x34
    CommandId = 0x02
    def build_frame(self, ResetDataPtr: bool = False, SamplingTime: int = 0, Rxlen: int = 256, RxMod: TTF_ReadByteStream_RxMod = "SMPL", BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x34\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (int(ResetDataPtr) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(SamplingTime.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Rxlen.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(TTF_ReadByteStream_RxMod_Parser.as_value(RxMod).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, ResetDataPtr: bool = False, SamplingTime: int = 0, Rxlen: int = 256, RxMod: TTF_ReadByteStream_RxMod = "SMPL", BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(ResetDataPtr=ResetDataPtr, SamplingTime=SamplingTime, Rxlen=Rxlen, RxMod=RxMod, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Data_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _Data = _recv_buffer.read(_Data_len)
        if len(_Data) != _Data_len:
            raise PayloadTooShortError(_Data_len - len(_Data))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Data
class UsbHost_Enable(Command):
    CommandGroupId = 0x44
    CommandId = 0x01
    def build_frame(self, Enable: bool = True, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x44\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Enable.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Enable: bool = True, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Enable=Enable, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class UsbHost_IsConnected(Command):
    CommandGroupId = 0x44
    CommandId = 0x02
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x44\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> bool:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Connected = bool(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Connected
class UsbHost_SetupPipes(Command):
    CommandGroupId = 0x44
    CommandId = 0x03
    def build_frame(self, Pipes: List[UsbHost_SetupPipes_Pipes_Entry], BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x44\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(int(len(Pipes)).to_bytes(1, byteorder='big'))
        for _Pipes_Entry in Pipes:
            _No, _Type, _FrameSize = _Pipes_Entry
            _send_buffer.write(_No.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(UsbHost_SetupPipes_Type_Parser.as_value(_Type).to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_FrameSize.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Pipes: List[UsbHost_SetupPipes_Pipes_Entry], BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Pipes=Pipes, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class UsbHost_SetAddr(Command):
    CommandGroupId = 0x44
    CommandId = 0x04
    def build_frame(self, Address: int = 1, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x44\x04")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Address.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Address: int = 1, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Address=Address, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class UsbHost_Reset(Command):
    CommandGroupId = 0x44
    CommandId = 0x05
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x44\x05")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class UsbHost_TransRawSetup(Command):
    CommandGroupId = 0x44
    CommandId = 0x06
    def build_frame(self, SetupData: bytes, PipeNo: int = 0, Timeout: int = 100, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x44\x06")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if len(SetupData) != 8:
            raise ValueError(SetupData)
        _send_buffer.write(SetupData)
        _send_buffer.write(PipeNo.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, SetupData: bytes, PipeNo: int = 0, Timeout: int = 100, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(SetupData=SetupData, PipeNo=PipeNo, Timeout=Timeout, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class UsbHost_TransSetupIn(Command):
    CommandGroupId = 0x44
    CommandId = 0x07
    def build_frame(self, SetupData: bytes, PipeNo: int = 0, Timeout: int = 100, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x44\x07")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if len(SetupData) != 8:
            raise ValueError(SetupData)
        _send_buffer.write(SetupData)
        _send_buffer.write(PipeNo.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, SetupData: bytes, PipeNo: int = 0, Timeout: int = 100, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(SetupData=SetupData, PipeNo=PipeNo, Timeout=Timeout, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _InData_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _InData = _recv_buffer.read(_InData_len)
        if len(_InData) != _InData_len:
            raise PayloadTooShortError(_InData_len - len(_InData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _InData
class UsbHost_TransSetupOut(Command):
    CommandGroupId = 0x44
    CommandId = 0x08
    def build_frame(self, SetupData: bytes, OutData: bytes, PipeNo: int = 0, Timeout: int = 100, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x44\x08")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if len(SetupData) != 8:
            raise ValueError(SetupData)
        _send_buffer.write(SetupData)
        _send_buffer.write(int(len(OutData)).to_bytes(2, byteorder='big'))
        _send_buffer.write(OutData)
        _send_buffer.write(PipeNo.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, SetupData: bytes, OutData: bytes, PipeNo: int = 0, Timeout: int = 100, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(SetupData=SetupData, OutData=OutData, PipeNo=PipeNo, Timeout=Timeout, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class UsbHost_TransIn(Command):
    CommandGroupId = 0x44
    CommandId = 0x09
    def build_frame(self, PipeNo: int, Timeout: int = 100, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x44\x09")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(PipeNo.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, PipeNo: int, Timeout: int = 100, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(PipeNo=PipeNo, Timeout=Timeout, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _InData_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _InData = _recv_buffer.read(_InData_len)
        if len(_InData) != _InData_len:
            raise PayloadTooShortError(_InData_len - len(_InData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _InData
class UsbHost_TransOut(Command):
    CommandGroupId = 0x44
    CommandId = 0x0A
    def build_frame(self, OutData: bytes, PipeNo: int, Continue: bool = False, Timeout: int = 100, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x44\x0A")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(int(len(OutData)).to_bytes(2, byteorder='big'))
        _send_buffer.write(OutData)
        _send_buffer.write(PipeNo.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Continue.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, OutData: bytes, PipeNo: int, Continue: bool = False, Timeout: int = 100, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(OutData=OutData, PipeNo=PipeNo, Continue=Continue, Timeout=Timeout, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class UsbHost_Suspend(Command):
    CommandGroupId = 0x44
    CommandId = 0x0B
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x44\x0B")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class UsbHost_Resume(Command):
    CommandGroupId = 0x44
    CommandId = 0x0C
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x44\x0C")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class VHL_GetLegacyATR(Command):
    CommandGroupId = 0x01
    CommandId = 0x05
    def build_frame(self, BrpTimeout: int = 1000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x01\x05")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 1000) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ATR_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _ATR = _recv_buffer.read(_ATR_len)
        if len(_ATR) != _ATR_len:
            raise PayloadTooShortError(_ATR_len - len(_ATR))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ATR
class VHL_SetupMifare(Command):
    CommandGroupId = 0x01
    CommandId = 0x08
    def build_frame(self, CustomKey: Optional[bool] = None, KeyA: bool = True, Key: Optional[bytes] = None, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x01\x08")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if CustomKey is None and (Key is not None):
            CustomKey = True
        if CustomKey is None:
            CustomKey = False
        _var_0000_int = 0
        _var_0000_int |= (int(CustomKey) & 0b1) << 1
        _var_0000_int |= (int(KeyA) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        if CustomKey:
            if Key is None:
                raise TypeError("missing a required argument: 'Key'")
            if len(Key) != 6:
                raise ValueError(Key)
            _send_buffer.write(Key)
        return _send_buffer.getvalue()
    def __call__(self, CustomKey: Optional[bool] = None, KeyA: bool = True, Key: Optional[bytes] = None, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(CustomKey=CustomKey, KeyA=KeyA, Key=Key, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class VHL_SetupLegic(Command):
    CommandGroupId = 0x01
    CommandId = 0x09
    def build_frame(self, StampLen: Optional[int] = None, SegmentID: Optional[int] = None, Stamp: Optional[bytes] = None, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x01\x09")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if StampLen is None and (SegmentID is not None):
            StampLen = 0
        if StampLen is None:
            StampLen = 0
        if SegmentID is None:
            SegmentID = 1
        _send_buffer.write(StampLen.to_bytes(length=1, byteorder='big'))
        if StampLen == 0:
            if SegmentID is None:
                raise TypeError("missing a required argument: 'SegmentID'")
            _send_buffer.write(SegmentID.to_bytes(length=1, byteorder='big'))
        if StampLen > 0:
            if Stamp is None:
                raise TypeError("missing a required argument: 'Stamp'")
            _send_buffer.write(Stamp)
        return _send_buffer.getvalue()
    def __call__(self, StampLen: Optional[int] = None, SegmentID: Optional[int] = None, Stamp: Optional[bytes] = None, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(StampLen=StampLen, SegmentID=SegmentID, Stamp=Stamp, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class VHL_SetupISO15(Command):
    CommandGroupId = 0x01
    CommandId = 0x0A
    def build_frame(self, FirstBlock: int = 0, BlockCount: int = 255, OptionFlag: bool = False, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x01\x0A")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(FirstBlock.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(BlockCount.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(OptionFlag.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, FirstBlock: int = 0, BlockCount: int = 255, OptionFlag: bool = False, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(FirstBlock=FirstBlock, BlockCount=BlockCount, OptionFlag=OptionFlag, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class VHL_Format(Command):
    CommandGroupId = 0x01
    CommandId = 0x0F
    def build_frame(self, Id: int, BrpTimeout: int = 4000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\x01\x0F")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Id.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Id: int, BrpTimeout: int = 4000) -> None:
        request_frame = self.build_frame(Id=Id, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_PortConfig(Command):
    CommandGroupId = 0xE0
    CommandId = 0x00
    def build_frame(self, Port: int, Mode: DHWCtrl_PortConfig_Mode, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x00")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Port.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(DHWCtrl_PortConfig_Mode_Parser.as_value(Mode).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Port: int, Mode: DHWCtrl_PortConfig_Mode, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Port=Port, Mode=Mode, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_PortGet(Command):
    CommandGroupId = 0xE0
    CommandId = 0x01
    def build_frame(self, Port: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x01")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Port.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Port: int, BrpTimeout: int = 100) -> bool:
        request_frame = self.build_frame(Port=Port, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Level = bool(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Level
class DHWCtrl_PortSet(Command):
    CommandGroupId = 0xE0
    CommandId = 0x02
    def build_frame(self, Port: int, Level: bool, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x02")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Port.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Level.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Port: int, Level: bool, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Port=Port, Level=Level, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_PortWait(Command):
    CommandGroupId = 0xE0
    CommandId = 0x05
    def build_frame(self, Port: int, Level: bool, Timeout: int = 65535, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x05")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Port.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Level.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Port: int, Level: bool, Timeout: int = 65535, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(Port=Port, Level=Level, Timeout=Timeout, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ReactionTime = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ReactionTime
class DHWCtrl_GetResetCause(Command):
    CommandGroupId = 0xE0
    CommandId = 0x06
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x06")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ResetCause = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ResetCause
class DHWCtrl_APortMeasure(Command):
    CommandGroupId = 0xE0
    CommandId = 0x07
    def build_frame(self, Port: int, Count: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x07")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Port.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Count.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Port: int, Count: int, BrpTimeout: int = 100) -> List[int]:
        request_frame = self.build_frame(Port=Port, Count=Count, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Voltages = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _Voltage = safe_read_int_from_buffer(_recv_buffer, 2)
            _Voltages.append(_Voltage)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Voltages
class DHWCtrl_SRAMTest(Command):
    CommandGroupId = 0xE0
    CommandId = 0x04
    def build_frame(self, SramSize: int, BrpTimeout: int = 1000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x04")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(SramSize.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, SramSize: int, BrpTimeout: int = 1000) -> bool:
        request_frame = self.build_frame(SramSize=SramSize, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Success = bool(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Success
class DHWCtrl_SetBaudrate(Command):
    CommandGroupId = 0xE0
    CommandId = 0x03
    def build_frame(self, NewBaudrate: Baudrate = "Baud115200", BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x03")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Baudrate_Parser.as_value(NewBaudrate).to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, NewBaudrate: Baudrate = "Baud115200", BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(NewBaudrate=NewBaudrate, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_MirrorData(Command):
    CommandGroupId = 0xE0
    CommandId = 0x08
    def build_frame(self, Data: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x08")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(int(len(Data)).to_bytes(2, byteorder='big'))
        _send_buffer.write(Data)
        return _send_buffer.getvalue()
    def __call__(self, Data: bytes, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(Data=Data, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _MirroredData_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _MirroredData = _recv_buffer.read(_MirroredData_len)
        if len(_MirroredData) != _MirroredData_len:
            raise PayloadTooShortError(_MirroredData_len - len(_MirroredData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _MirroredData
class DHWCtrl_DispEnable(Command):
    CommandGroupId = 0xE0
    CommandId = 0x10
    def build_frame(self, Enable: bool = True, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x10")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Enable.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Enable: bool = True, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Enable=Enable, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_DispBacklight(Command):
    CommandGroupId = 0xE0
    CommandId = 0x11
    def build_frame(self, Backlight: bool = True, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x11")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Backlight.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Backlight: bool = True, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Backlight=Backlight, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_DispColor(Command):
    CommandGroupId = 0xE0
    CommandId = 0x12
    def build_frame(self, Color: DHWCtrl_DispColor_Color = "Black", BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x12")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(DHWCtrl_DispColor_Color_Parser.as_value(Color).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Color: DHWCtrl_DispColor_Color = "Black", BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Color=Color, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_DispContrast(Command):
    CommandGroupId = 0xE0
    CommandId = 0x13
    def build_frame(self, Contrast: int = 128, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x13")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Contrast.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Contrast: int = 128, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Contrast=Contrast, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_DispBox(Command):
    CommandGroupId = 0xE0
    CommandId = 0x14
    def build_frame(self, X: int = 0, Y: int = 0, Width: int = 128, Height: int = 64, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x14")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(X.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Y.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Width.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Height.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, X: int = 0, Y: int = 0, Width: int = 128, Height: int = 64, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(X=X, Y=Y, Width=Width, Height=Height, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_Ser2Ctrl(Command):
    CommandGroupId = 0xE0
    CommandId = 0x15
    def build_frame(self, InterfaceID: int = 0, *, Enable: bool, NewBaudrate: Baudrate = "Baud115200", NewParity: Parity, Stopbits: int = 1, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x15")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(InterfaceID.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Enable.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Baudrate_Parser.as_value(NewBaudrate).to_bytes(length=2, byteorder='big'))
        _send_buffer.write(Parity_Parser.as_value(NewParity).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Stopbits.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, InterfaceID: int = 0, *, Enable: bool, NewBaudrate: Baudrate = "Baud115200", NewParity: Parity, Stopbits: int = 1, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(InterfaceID=InterfaceID, Enable=Enable, NewBaudrate=NewBaudrate, NewParity=NewParity, Stopbits=Stopbits, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_Ser2WriteRead(Command):
    CommandGroupId = 0xE0
    CommandId = 0x16
    def build_frame(self, MaxReadCount: int = 1, Timeout: int = 10, *, WriteData: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x16")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(MaxReadCount.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(int(len(WriteData)).to_bytes(2, byteorder='big'))
        _send_buffer.write(WriteData)
        return _send_buffer.getvalue()
    def __call__(self, MaxReadCount: int = 1, Timeout: int = 10, *, WriteData: bytes, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(MaxReadCount=MaxReadCount, Timeout=Timeout, WriteData=WriteData, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ReadData_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _ReadData = _recv_buffer.read(_ReadData_len)
        if len(_ReadData) != _ReadData_len:
            raise PayloadTooShortError(_ReadData_len - len(_ReadData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ReadData
class DHWCtrl_Ser2Flush(Command):
    CommandGroupId = 0xE0
    CommandId = 0x20
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x20")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_Delay1ms(Command):
    CommandGroupId = 0xE0
    CommandId = 0x17
    def build_frame(self, Delay: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x17")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Delay.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Delay: int, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Delay=Delay, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_Delay10us(Command):
    CommandGroupId = 0xE0
    CommandId = 0x18
    def build_frame(self, Delay: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x18")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Delay.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Delay: int, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Delay=Delay, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_PowermgrSuspend(Command):
    CommandGroupId = 0xE0
    CommandId = 0x19
    def build_frame(self, Delay: int = 65535, KeyboardWakeup: bool = False, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x19")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Delay.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(KeyboardWakeup.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Delay: int = 65535, KeyboardWakeup: bool = False, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Delay=Delay, KeyboardWakeup=KeyboardWakeup, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_ScanMatrix(Command):
    CommandGroupId = 0xE0
    CommandId = 0x1A
    def build_frame(self, Bitmask: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x1A")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Bitmask.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Bitmask: int, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Bitmask=Bitmask, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_GetReaderChipType(Command):
    CommandGroupId = 0xE0
    CommandId = 0x1B
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x1B")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> DHWCtrl_GetReaderChipType_ChipType:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ChipType = DHWCtrl_GetReaderChipType_ChipType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ChipType
class DHWCtrl_SelectAntenna(Command):
    CommandGroupId = 0xE0
    CommandId = 0x1C
    def build_frame(self, Ant: int = 0, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x1C")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Ant.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Ant: int = 0, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Ant=Ant, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_GetSamType(Command):
    CommandGroupId = 0xE0
    CommandId = 0x1D
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x1D")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> DHWCtrl_GetSamType_ChipType:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ChipType = DHWCtrl_GetSamType_ChipType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ChipType
class DHWCtrl_HfAcquire(Command):
    CommandGroupId = 0xE0
    CommandId = 0x1E
    def build_frame(self, ModuleId: DHWCtrl_HfAcquire_ModuleId = "No", BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x1E")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(DHWCtrl_HfAcquire_ModuleId_Parser.as_value(ModuleId).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, ModuleId: DHWCtrl_HfAcquire_ModuleId = "No", BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(ModuleId=ModuleId, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_EepromWrite(Command):
    CommandGroupId = 0xE0
    CommandId = 0x21
    def build_frame(self, Address: int, Data: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x21")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Address.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(int(len(Data)).to_bytes(2, byteorder='big'))
        _send_buffer.write(Data)
        return _send_buffer.getvalue()
    def __call__(self, Address: int, Data: bytes, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Address=Address, Data=Data, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_DataflashGetSize(Command):
    CommandGroupId = 0xE0
    CommandId = 0x22
    def build_frame(self, Device: int = 0, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x22")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Device.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Device: int = 0, BrpTimeout: int = 100) -> DHWCtrl_DataflashGetSize_Result:
        request_frame = self.build_frame(Device=Device, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _PageCount = safe_read_int_from_buffer(_recv_buffer, 2)
        _PageSize = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return DHWCtrl_DataflashGetSize_Result(_PageCount, _PageSize)
class DHWCtrl_DataflashErasePages(Command):
    CommandGroupId = 0xE0
    CommandId = 0x23
    def build_frame(self, Device: int = 0, StartPage: int = 0, Len: int = 1, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x23")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Device.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(StartPage.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(Len.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Device: int = 0, StartPage: int = 0, Len: int = 1, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Device=Device, StartPage=StartPage, Len=Len, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_DataflashRead(Command):
    CommandGroupId = 0xE0
    CommandId = 0x24
    def build_frame(self, Device: int = 0, Page: int = 0, StartAdr: int = 0, Len: int = 5, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x24")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Device.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Page.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(StartAdr.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(Len.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Device: int = 0, Page: int = 0, StartAdr: int = 0, Len: int = 5, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(Device=Device, Page=Page, StartAdr=StartAdr, Len=Len, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Data_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _Data = _recv_buffer.read(_Data_len)
        if len(_Data) != _Data_len:
            raise PayloadTooShortError(_Data_len - len(_Data))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Data
class DHWCtrl_DataflashWrite(Command):
    CommandGroupId = 0xE0
    CommandId = 0x25
    def build_frame(self, Device: int = 0, Mode: int = 1, Page: int = 0, StartAdr: int = 0, *, Data: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x25")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Device.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Mode.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Page.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(StartAdr.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(int(len(Data)).to_bytes(2, byteorder='big'))
        _send_buffer.write(Data)
        return _send_buffer.getvalue()
    def __call__(self, Device: int = 0, Mode: int = 1, Page: int = 0, StartAdr: int = 0, *, Data: bytes, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Device=Device, Mode=Mode, Page=Page, StartAdr=StartAdr, Data=Data, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_EepromRead(Command):
    CommandGroupId = 0xE0
    CommandId = 0x26
    def build_frame(self, StartAdr: int = 0, Len: int = 5, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x26")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(StartAdr.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(Len.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, StartAdr: int = 0, Len: int = 5, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(StartAdr=StartAdr, Len=Len, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Data_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _Data = _recv_buffer.read(_Data_len)
        if len(_Data) != _Data_len:
            raise PayloadTooShortError(_Data_len - len(_Data))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Data
class DHWCtrl_SecurityAndConfigReset(Command):
    CommandGroupId = 0xE0
    CommandId = 0x27
    def build_frame(self, BrpTimeout: int = 10000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x27")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 10000) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_PulseGenerate(Command):
    CommandGroupId = 0xE0
    CommandId = 0x28
    def build_frame(self, Port: int, Frequency: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x28")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Port.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Frequency.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Port: int, Frequency: int, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Port=Port, Frequency=Frequency, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_InitSer2(Command):
    CommandGroupId = 0xE0
    CommandId = 0x31
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x31")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_InitRtc(Command):
    CommandGroupId = 0xE0
    CommandId = 0x32
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x32")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_InitLcdDrv(Command):
    CommandGroupId = 0xE0
    CommandId = 0x33
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x33")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_InitRc(Command):
    CommandGroupId = 0xE0
    CommandId = 0x34
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x34")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_InitMf(Command):
    CommandGroupId = 0xE0
    CommandId = 0x35
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x35")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_InitIso14A(Command):
    CommandGroupId = 0xE0
    CommandId = 0x36
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x36")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_InitIso14B(Command):
    CommandGroupId = 0xE0
    CommandId = 0x37
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x37")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_InitIso15(Command):
    CommandGroupId = 0xE0
    CommandId = 0x38
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x38")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_InitLg(Command):
    CommandGroupId = 0xE0
    CommandId = 0x39
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x39")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_InitLga(Command):
    CommandGroupId = 0xE0
    CommandId = 0x3A
    def build_frame(self, BrpTimeout: int = 3000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x3A")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 3000) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_InitDf(Command):
    CommandGroupId = 0xE0
    CommandId = 0x3B
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x3B")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_InitRc125(Command):
    CommandGroupId = 0xE0
    CommandId = 0x3C
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x3C")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_InitCc(Command):
    CommandGroupId = 0xE0
    CommandId = 0x3D
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x3D")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_InitUsbHost(Command):
    CommandGroupId = 0xE0
    CommandId = 0x3E
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x3E")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_InitNic(Command):
    CommandGroupId = 0xE0
    CommandId = 0x3F
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x3F")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_BohEnable(Command):
    CommandGroupId = 0xE0
    CommandId = 0x41
    def build_frame(self, Enable: bool = True, Bug6WorkaroundEnabled: bool = True, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x41")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Enable.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Bug6WorkaroundEnabled.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Enable: bool = True, Bug6WorkaroundEnabled: bool = True, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Enable=Enable, Bug6WorkaroundEnabled=Bug6WorkaroundEnabled, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_NicEnable(Command):
    CommandGroupId = 0xE0
    CommandId = 0x42
    def build_frame(self, Enable: bool = True, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x42")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Enable.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Enable: bool = True, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Enable=Enable, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_NicGetChipType(Command):
    CommandGroupId = 0xE0
    CommandId = 0x43
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x43")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ChipType_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _ChipType = _recv_buffer.read(_ChipType_len)
        if len(_ChipType) != _ChipType_len:
            raise PayloadTooShortError(_ChipType_len - len(_ChipType))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ChipType
class DHWCtrl_NicGetLinkStatus(Command):
    CommandGroupId = 0xE0
    CommandId = 0x44
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x44")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _LinkStatus = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _LinkStatus
class DHWCtrl_NicSend(Command):
    CommandGroupId = 0xE0
    CommandId = 0x45
    def build_frame(self, SendData: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x45")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(int(len(SendData)).to_bytes(2, byteorder='big'))
        _send_buffer.write(SendData)
        return _send_buffer.getvalue()
    def __call__(self, SendData: bytes, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(SendData=SendData, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_NicReceive(Command):
    CommandGroupId = 0xE0
    CommandId = 0x46
    def build_frame(self, Timeout: int, BrpTimeout: int = 1000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x46")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Timeout: int, BrpTimeout: int = 1000) -> bytes:
        request_frame = self.build_frame(Timeout=Timeout, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _RecvData_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _RecvData = _recv_buffer.read(_RecvData_len)
        if len(_RecvData) != _RecvData_len:
            raise PayloadTooShortError(_RecvData_len - len(_RecvData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _RecvData
class DHWCtrl_NicSetMAC(Command):
    CommandGroupId = 0xE0
    CommandId = 0x47
    def build_frame(self, MAC: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x47")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        if len(MAC) != 6:
            raise ValueError(MAC)
        _send_buffer.write(MAC)
        return _send_buffer.getvalue()
    def __call__(self, MAC: bytes, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(MAC=MAC, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_ApspiSetSpeed(Command):
    CommandGroupId = 0xE0
    CommandId = 0x50
    def build_frame(self, Speed: int = 3390, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x50")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Speed.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Speed: int = 3390, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Speed=Speed, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_ApspiEnable(Command):
    CommandGroupId = 0xE0
    CommandId = 0x51
    def build_frame(self, Enable: bool = True, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x51")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Enable.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Enable: bool = True, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Enable=Enable, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_ApspiSingleSend(Command):
    CommandGroupId = 0xE0
    CommandId = 0x52
    def build_frame(self, CmdCode: int, Address: int, CmdData: int, Delay: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x52")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(CmdCode.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Address.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(CmdData.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Delay.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, CmdCode: int, Address: int, CmdData: int, Delay: int, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(CmdCode=CmdCode, Address=Address, CmdData=CmdData, Delay=Delay, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_ApspiSingleRecv(Command):
    CommandGroupId = 0xE0
    CommandId = 0x53
    def build_frame(self, CmdCode: int, Address: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x53")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(CmdCode.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Address.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, CmdCode: int, Address: int, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(CmdCode=CmdCode, Address=Address, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _CmdData = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _CmdData
class DHWCtrl_ApspiAlternateSend(Command):
    CommandGroupId = 0xE0
    CommandId = 0x54
    def build_frame(self, CmdCodeA: int, CmdCodeB: int, Address: int, CmdData: bytes, Delay: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x54")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(CmdCodeA.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(CmdCodeB.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Address.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(int(len(CmdData)).to_bytes(2, byteorder='big'))
        _send_buffer.write(CmdData)
        _send_buffer.write(Delay.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, CmdCodeA: int, CmdCodeB: int, Address: int, CmdData: bytes, Delay: int, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(CmdCodeA=CmdCodeA, CmdCodeB=CmdCodeB, Address=Address, CmdData=CmdData, Delay=Delay, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_ApspiAlternateRecv(Command):
    CommandGroupId = 0xE0
    CommandId = 0x55
    def build_frame(self, CmdCodeA: int, CmdCodeB: int, Address: int, CmdDataLen: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x55")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(CmdCodeA.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(CmdCodeB.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Address.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(CmdDataLen.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, CmdCodeA: int, CmdCodeB: int, Address: int, CmdDataLen: int, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(CmdCodeA=CmdCodeA, CmdCodeB=CmdCodeB, Address=Address, CmdDataLen=CmdDataLen, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _CmdData_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _CmdData = _recv_buffer.read(_CmdData_len)
        if len(_CmdData) != _CmdData_len:
            raise PayloadTooShortError(_CmdData_len - len(_CmdData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _CmdData
class DHWCtrl_PdiEnable(Command):
    CommandGroupId = 0xE0
    CommandId = 0x56
    def build_frame(self, Enable: bool = True, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x56")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Enable.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Enable: bool = True, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Enable=Enable, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_PdiEraseDevice(Command):
    CommandGroupId = 0xE0
    CommandId = 0x57
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x57")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_PdiReadFlash(Command):
    CommandGroupId = 0xE0
    CommandId = 0x58
    def build_frame(self, Adr: int, ReadLen: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x58")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Adr.to_bytes(length=4, byteorder='big'))
        _send_buffer.write(ReadLen.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Adr: int, ReadLen: int, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(Adr=Adr, ReadLen=ReadLen, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ReadData_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _ReadData = _recv_buffer.read(_ReadData_len)
        if len(_ReadData) != _ReadData_len:
            raise PayloadTooShortError(_ReadData_len - len(_ReadData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ReadData
class DHWCtrl_PdiEraseFlashPage(Command):
    CommandGroupId = 0xE0
    CommandId = 0x59
    def build_frame(self, Adr: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x59")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Adr.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Adr: int, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Adr=Adr, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_PdiWriteFlashPage(Command):
    CommandGroupId = 0xE0
    CommandId = 0x5A
    def build_frame(self, Adr: int, WriteData: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x5A")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Adr.to_bytes(length=4, byteorder='big'))
        _send_buffer.write(int(len(WriteData)).to_bytes(2, byteorder='big'))
        _send_buffer.write(WriteData)
        return _send_buffer.getvalue()
    def __call__(self, Adr: int, WriteData: bytes, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Adr=Adr, WriteData=WriteData, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_PdiProgramFlashPage(Command):
    CommandGroupId = 0xE0
    CommandId = 0x5B
    def build_frame(self, Adr: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x5B")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Adr.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Adr: int, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Adr=Adr, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_PdiReadEeprom(Command):
    CommandGroupId = 0xE0
    CommandId = 0x5C
    def build_frame(self, Adr: int, ReadLen: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x5C")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Adr.to_bytes(length=4, byteorder='big'))
        _send_buffer.write(ReadLen.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Adr: int, ReadLen: int, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(Adr=Adr, ReadLen=ReadLen, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ReadData_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _ReadData = _recv_buffer.read(_ReadData_len)
        if len(_ReadData) != _ReadData_len:
            raise PayloadTooShortError(_ReadData_len - len(_ReadData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ReadData
class DHWCtrl_PdiProgramEepromPage(Command):
    CommandGroupId = 0xE0
    CommandId = 0x5D
    def build_frame(self, Adr: int, WriteData: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x5D")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Adr.to_bytes(length=4, byteorder='big'))
        _send_buffer.write(int(len(WriteData)).to_bytes(2, byteorder='big'))
        _send_buffer.write(WriteData)
        return _send_buffer.getvalue()
    def __call__(self, Adr: int, WriteData: bytes, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Adr=Adr, WriteData=WriteData, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_PdiReadFuses(Command):
    CommandGroupId = 0xE0
    CommandId = 0x5E
    def build_frame(self, Adr: int, ReadLen: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x5E")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Adr.to_bytes(length=4, byteorder='big'))
        _send_buffer.write(ReadLen.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Adr: int, ReadLen: int, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(Adr=Adr, ReadLen=ReadLen, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ReadData_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _ReadData = _recv_buffer.read(_ReadData_len)
        if len(_ReadData) != _ReadData_len:
            raise PayloadTooShortError(_ReadData_len - len(_ReadData))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ReadData
class DHWCtrl_PdiWriteFuse(Command):
    CommandGroupId = 0xE0
    CommandId = 0x5F
    def build_frame(self, Adr: int, Fuse: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x5F")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Adr.to_bytes(length=4, byteorder='big'))
        _send_buffer.write(Fuse.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Adr: int, Fuse: int, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Adr=Adr, Fuse=Fuse, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_FlashGetPageSize(Command):
    CommandGroupId = 0xE0
    CommandId = 0x60
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x60")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _PageSize = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _PageSize
class DHWCtrl_FlashErasePage(Command):
    CommandGroupId = 0xE0
    CommandId = 0x61
    def build_frame(self, StartAdr: int = 0, *, Len: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x61")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(StartAdr.to_bytes(length=4, byteorder='big'))
        _send_buffer.write(Len.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, StartAdr: int = 0, *, Len: int, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(StartAdr=StartAdr, Len=Len, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_FlashRead(Command):
    CommandGroupId = 0xE0
    CommandId = 0x62
    def build_frame(self, StartAdr: int = 0, Len: int = 5, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x62")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(StartAdr.to_bytes(length=4, byteorder='big'))
        _send_buffer.write(Len.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, StartAdr: int = 0, Len: int = 5, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(StartAdr=StartAdr, Len=Len, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Data_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _Data = _recv_buffer.read(_Data_len)
        if len(_Data) != _Data_len:
            raise PayloadTooShortError(_Data_len - len(_Data))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Data
class DHWCtrl_FlashWritePage(Command):
    CommandGroupId = 0xE0
    CommandId = 0x63
    def build_frame(self, StartAdr: int = 0, *, Data: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x63")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(StartAdr.to_bytes(length=4, byteorder='big'))
        _send_buffer.write(int(len(Data)).to_bytes(2, byteorder='big'))
        _send_buffer.write(Data)
        return _send_buffer.getvalue()
    def __call__(self, StartAdr: int = 0, *, Data: bytes, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(StartAdr=StartAdr, Data=Data, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_FlashProgramPage(Command):
    CommandGroupId = 0xE0
    CommandId = 0x64
    def build_frame(self, StartAdr: int = 0, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x64")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(StartAdr.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, StartAdr: int = 0, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(StartAdr=StartAdr, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_RegisterRead(Command):
    CommandGroupId = 0xE0
    CommandId = 0x65
    def build_frame(self, RegAdr: int = 0, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x65")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(RegAdr.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, RegAdr: int = 0, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(RegAdr=RegAdr, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _RegValue = safe_read_int_from_buffer(_recv_buffer, 4)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _RegValue
class DHWCtrl_RegisterWrite(Command):
    CommandGroupId = 0xE0
    CommandId = 0x66
    def build_frame(self, RegAdr: int = 0, RegValue: int = 0, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x66")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(RegAdr.to_bytes(length=4, byteorder='big'))
        _send_buffer.write(RegValue.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, RegAdr: int = 0, RegValue: int = 0, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(RegAdr=RegAdr, RegValue=RegValue, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_AesWrapKey(Command):
    CommandGroupId = 0xE0
    CommandId = 0x68
    def build_frame(self, WrappedKeyNr: DHWCtrl_AesWrapKey_WrappedKeyNr, Key: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x68")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(DHWCtrl_AesWrapKey_WrappedKeyNr_Parser.as_value(WrappedKeyNr).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(Key)).to_bytes(1, byteorder='big'))
        _send_buffer.write(Key)
        return _send_buffer.getvalue()
    def __call__(self, WrappedKeyNr: DHWCtrl_AesWrapKey_WrappedKeyNr, Key: bytes, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(WrappedKeyNr=WrappedKeyNr, Key=Key, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _WrappedKey_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _WrappedKey = _recv_buffer.read(_WrappedKey_len)
        if len(_WrappedKey) != _WrappedKey_len:
            raise PayloadTooShortError(_WrappedKey_len - len(_WrappedKey))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _WrappedKey
class DHWCtrl_AesEncrypt(Command):
    CommandGroupId = 0xE0
    CommandId = 0x69
    def build_frame(self, WrappedKeyNr: DHWCtrl_AesEncrypt_WrappedKeyNr, Block: bytes, Key: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x69")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(DHWCtrl_AesEncrypt_WrappedKeyNr_Parser.as_value(WrappedKeyNr).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(Block)).to_bytes(1, byteorder='big'))
        _send_buffer.write(Block)
        _send_buffer.write(int(len(Key)).to_bytes(1, byteorder='big'))
        _send_buffer.write(Key)
        return _send_buffer.getvalue()
    def __call__(self, WrappedKeyNr: DHWCtrl_AesEncrypt_WrappedKeyNr, Block: bytes, Key: bytes, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(WrappedKeyNr=WrappedKeyNr, Block=Block, Key=Key, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _EncBlock_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _EncBlock = _recv_buffer.read(_EncBlock_len)
        if len(_EncBlock) != _EncBlock_len:
            raise PayloadTooShortError(_EncBlock_len - len(_EncBlock))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _EncBlock
class DHWCtrl_AesDecrypt(Command):
    CommandGroupId = 0xE0
    CommandId = 0x6A
    def build_frame(self, WrappedKeyNr: DHWCtrl_AesDecrypt_WrappedKeyNr, EncBlock: bytes, Key: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x6A")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(DHWCtrl_AesDecrypt_WrappedKeyNr_Parser.as_value(WrappedKeyNr).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(EncBlock)).to_bytes(1, byteorder='big'))
        _send_buffer.write(EncBlock)
        _send_buffer.write(int(len(Key)).to_bytes(1, byteorder='big'))
        _send_buffer.write(Key)
        return _send_buffer.getvalue()
    def __call__(self, WrappedKeyNr: DHWCtrl_AesDecrypt_WrappedKeyNr, EncBlock: bytes, Key: bytes, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(WrappedKeyNr=WrappedKeyNr, EncBlock=EncBlock, Key=Key, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Block_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Block = _recv_buffer.read(_Block_len)
        if len(_Block) != _Block_len:
            raise PayloadTooShortError(_Block_len - len(_Block))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Block
class DHWCtrl_GetPlatformId2(Command):
    CommandGroupId = 0xE0
    CommandId = 0x7B
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x7B")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> List[int]:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _HWCIdLst_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _HWCIdLst = []  # type: ignore[var-annotated,unused-ignore]
        while not len(_HWCIdLst) >= _HWCIdLst_len:
            _HWCId = safe_read_int_from_buffer(_recv_buffer, 2)
            _HWCIdLst.append(_HWCId)
        if len(_HWCIdLst) != _HWCIdLst_len:
            raise PayloadTooShortError(_HWCIdLst_len - len(_HWCIdLst))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _HWCIdLst
class DHWCtrl_GetProdLoader(Command):
    CommandGroupId = 0xE0
    CommandId = 0x7C
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x7C")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _LoaderBaudrate = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _LoaderBaudrate
class DHWCtrl_StartProdLoader(Command):
    CommandGroupId = 0xE0
    CommandId = 0x7D
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x7D")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_Run(Command):
    CommandGroupId = 0xE0
    CommandId = 0x7F
    def build_frame(self, CommandList: bytes, BrpTimeout: int = 20000) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x7F")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(CommandList)
        return _send_buffer.getvalue()
    def __call__(self, CommandList: bytes, BrpTimeout: int = 20000) -> DHWCtrl_Run_Result:
        request_frame = self.build_frame(CommandList=CommandList, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Status = safe_read_int_from_buffer(_recv_buffer, 1)
        _Response_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _Response = _recv_buffer.read(_Response_len)
        if len(_Response) != _Response_len:
            raise PayloadTooShortError(_Response_len - len(_Response))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return DHWCtrl_Run_Result(_Status, _Response)
class DHWCtrl_GetStartupRun(Command):
    CommandGroupId = 0xE0
    CommandId = 0x7E
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x7E")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> DHWCtrl_GetStartupRun_Result:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Status = safe_read_int_from_buffer(_recv_buffer, 1)
        _Response_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _Response = _recv_buffer.read(_Response_len)
        if len(_Response) != _Response_len:
            raise PayloadTooShortError(_Response_len - len(_Response))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return DHWCtrl_GetStartupRun_Result(_Status, _Response)
class DHWCtrl_InitBgm(Command):
    CommandGroupId = 0xE0
    CommandId = 0x80
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x80")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_BgmExec(Command):
    CommandGroupId = 0xE0
    CommandId = 0x81
    def build_frame(self, Cmd: bytes, Timeout: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x81")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(int(len(Cmd)).to_bytes(1, byteorder='big'))
        _send_buffer.write(Cmd)
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Cmd: bytes, Timeout: int, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(Cmd=Cmd, Timeout=Timeout, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Rsp_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _Rsp = _recv_buffer.read(_Rsp_len)
        if len(_Rsp) != _Rsp_len:
            raise PayloadTooShortError(_Rsp_len - len(_Rsp))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Rsp
class DHWCtrl_Sm4x00BootloaderStart(Command):
    CommandGroupId = 0xE0
    CommandId = 0x82
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x82")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _BootloaderString_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _BootloaderString = _recv_buffer.read(_BootloaderString_len)
        if len(_BootloaderString) != _BootloaderString_len:
            raise PayloadTooShortError(_BootloaderString_len - len(_BootloaderString))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _BootloaderString
class DHWCtrl_Sm4x00EraseFlash(Command):
    CommandGroupId = 0xE0
    CommandId = 0x83
    def build_frame(self, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x83")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class DHWCtrl_Sm4x00WaitForFlashErase(Command):
    CommandGroupId = 0xE0
    CommandId = 0x84
    def build_frame(self, Timeout: int, BrpTimeout: int = 1500) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x84")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Timeout: int, BrpTimeout: int = 1500) -> bytes:
        request_frame = self.build_frame(Timeout=Timeout, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _EraseResponse_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _EraseResponse = _recv_buffer.read(_EraseResponse_len)
        if len(_EraseResponse) != _EraseResponse_len:
            raise PayloadTooShortError(_EraseResponse_len - len(_EraseResponse))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _EraseResponse
class DHWCtrl_Sm4x00ProgramBlock(Command):
    CommandGroupId = 0xE0
    CommandId = 0x85
    def build_frame(self, IsLast: bool, FwBlock: bytes, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x85")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(IsLast.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(int(len(FwBlock)).to_bytes(1, byteorder='big'))
        _send_buffer.write(FwBlock)
        return _send_buffer.getvalue()
    def __call__(self, IsLast: bool, FwBlock: bytes, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(IsLast=IsLast, FwBlock=FwBlock, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _ProgramResponse_len = safe_read_int_from_buffer(_recv_buffer, 1)
        _ProgramResponse = _recv_buffer.read(_ProgramResponse_len)
        if len(_ProgramResponse) != _ProgramResponse_len:
            raise PayloadTooShortError(_ProgramResponse_len - len(_ProgramResponse))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ProgramResponse
class DHWCtrl_BgmRead(Command):
    CommandGroupId = 0xE0
    CommandId = 0x86
    def build_frame(self, Timeout: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x86")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Timeout.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Timeout: int, BrpTimeout: int = 100) -> bytes:
        request_frame = self.build_frame(Timeout=Timeout, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Rsp_len = safe_read_int_from_buffer(_recv_buffer, 2)
        _Rsp = _recv_buffer.read(_Rsp_len)
        if len(_Rsp) != _Rsp_len:
            raise PayloadTooShortError(_Rsp_len - len(_Rsp))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Rsp
class DHWCtrl_Rc5180EepromRead(Command):
    CommandGroupId = 0xE0
    CommandId = 0x90
    def build_frame(self, Address: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x90")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Address.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Address: int, BrpTimeout: int = 100) -> int:
        request_frame = self.build_frame(Address=Address, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _Data = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Data
class DHWCtrl_Rc5180EepromWrite(Command):
    CommandGroupId = 0xE0
    CommandId = 0x91
    def build_frame(self, Address: int, Data: int, BrpTimeout: int = 100) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b"\x00\xE0\x91")
        _send_buffer.write(int(BrpTimeout).to_bytes(4, byteorder='big'))
        _send_buffer.write(Address.to_bytes(length=2, byteorder='big'))
        _send_buffer.write(Data.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Address: int, Data: int, BrpTimeout: int = 100) -> None:
        request_frame = self.build_frame(Address=Address, Data=Data, BrpTimeout=BrpTimeout)
        _recv_buffer = BytesIO(self.process_frame(request_frame))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return None
class InternalCommands(PublicCommands):
    @property
    def ASK_SecuraKeyRead(self) -> ASK_SecuraKeyRead:
        """
        Returns data of SecuraKey tags (read only tag).
        """
        return ASK_SecuraKeyRead(self)
    @property
    def ASK_GproxRead(self) -> ASK_GproxRead:
        """
        Returns data of G-Prox tags (read only tag).
        """
        return ASK_GproxRead(self)
    @property
    def ASK_CotagRead(self) -> ASK_CotagRead:
        """
        Returns data of Cotag tags (read only tag).
        """
        return ASK_CotagRead(self)
    @property
    def CardEmu_GetMaxFrameSize(self) -> CardEmu_GetMaxFrameSize:
        """
        This command returns the maximum size of a single ISO14443-3 frame that may be sent/received via CardEmu.StartEmu or CardEmu.TransparentCmd.
        """
        return CardEmu_GetMaxFrameSize(self)
    @property
    def CardEmu_StartEmu(self) -> CardEmu_StartEmu:
        """
        Switch to Passive mode and wait for a ISO1443-3a Request/Anticoll/Select sequence and receive the first frame.
        """
        return CardEmu_StartEmu(self)
    @property
    def CardEmu_TransparentCmd(self) -> CardEmu_TransparentCmd:
        """
        Sends a response to the command returned by CardEmu.StartEmu or to the command returned by the last CardEmu.TransparentCmd.
        """
        return CardEmu_TransparentCmd(self)
    @property
    def CardEmu_GetExternalHfStatus(self) -> CardEmu_GetExternalHfStatus:
        """
        Returns _true_ if an external HF field is detected.
        """
        return CardEmu_GetExternalHfStatus(self)
    @property
    def CardEmu_StartNfc(self) -> CardEmu_StartNfc:
        """
        Switch to Passive mode and wait for an NFC powerup sequence
        """
        return CardEmu_StartNfc(self)
    @property
    def Dbg_ReadLogs(self) -> Dbg_ReadLogs:
        """
        Get next available block of debug data.
        """
        return Dbg_ReadLogs(self)
    @property
    def Dbg_RunCmd(self) -> Dbg_RunCmd:
        """
        Run a command by emulating the corresponding keypress in DebugCommandInterface.
        """
        return Dbg_RunCmd(self)
    @property
    def EM_DecodeCfg(self) -> EM_DecodeCfg:
        """
        Configures Mod and Baudtype of receiver. When _RxMod_ is set to _unknown_ , the Mod is automatically scanned. When _RxBaud_ is set to _unknown_ , the baudtype is automatically detected.
        """
        return EM_DecodeCfg(self)
    @property
    def EM_Read4100(self) -> EM_Read4100:
        """
        Reads the UID from EM4100/4102 labels.
        """
        return EM_Read4100(self)
    @property
    def EM_Read4205(self) -> EM_Read4205:
        """
        Reads a page from EM4205/4305 labels.
        """
        return EM_Read4205(self)
    @property
    def EM_Write4205(self) -> EM_Write4205:
        """
        Writes a page to EM4205/4305 labels.
        """
        return EM_Write4205(self)
    @property
    def EM_Halt4205(self) -> EM_Halt4205:
        """
        Disables a 4205 tag until next power on.
        """
        return EM_Halt4205(self)
    @property
    def EM_Login4205(self) -> EM_Login4205:
        """
        Login to a 4205 tag with data has to match block 1.
        """
        return EM_Login4205(self)
    @property
    def EM_Protect4205(self) -> EM_Protect4205:
        """
        Protects data from being modified.
        """
        return EM_Protect4205(self)
    @property
    def EM_Read4469(self) -> EM_Read4469:
        """
        Reads a page from EM4469/4569 labels.
        """
        return EM_Read4469(self)
    @property
    def EM_Write4469(self) -> EM_Write4469:
        """
        Writes a page to EM4469/4569 labels.
        """
        return EM_Write4469(self)
    @property
    def EM_Halt4469(self) -> EM_Halt4469:
        """
        Disables a EM4469/4569 tag until next power on.
        """
        return EM_Halt4469(self)
    @property
    def EM_Login4469(self) -> EM_Login4469:
        """
        Login to a EM4469/4569 tag with data has to match block 1.
        """
        return EM_Login4469(self)
    @property
    def EM_Read4450(self) -> EM_Read4450:
        """
        Reads pages from a EM4450 tag (start to end address).
        """
        return EM_Read4450(self)
    @property
    def Eth_GetMacAdr(self) -> Eth_GetMacAdr:
        """
        Retrieve the MAC address of the device.
        """
        return Eth_GetMacAdr(self)
    @property
    def Eth_GetConnDevIP(self) -> Eth_GetConnDevIP:
        """
        Retrieve the IP address of the directly connected network device.
        """
        return Eth_GetConnDevIP(self)
    @property
    def Eth_CreateRecoveryPoint(self) -> Eth_CreateRecoveryPoint:
        """
        Create a _Recovery Point_ , backing up all relevant Ethernet- and TCP/IP- settings.
        """
        return Eth_CreateRecoveryPoint(self)
    @property
    def Eth_DelRecoveryPoint(self) -> Eth_DelRecoveryPoint:
        """
        Remove a Recovery Point which was created via the Eth.CreateRecoveryPoint command.
        """
        return Eth_DelRecoveryPoint(self)
    @property
    def Eth_GetNetworkStatus(self) -> Eth_GetNetworkStatus:
        """
        Retrieve current network status.
        """
        return Eth_GetNetworkStatus(self)
    @property
    def Eth_GetMIBCounters(self) -> Eth_GetMIBCounters:
        """
        Retrieve current MIB counters.
        """
        return Eth_GetMIBCounters(self)
    @property
    def Eth_GetTcpConnectionStatus(self) -> Eth_GetTcpConnectionStatus:
        """
        Retrieve the BRP over TCP connection status. Checks if there is an open TCP connection.
        """
        return Eth_GetTcpConnectionStatus(self)
    @property
    def Eth_OpenTcpConnection(self) -> Eth_OpenTcpConnection:
        """
        Open a BRP over TCP connection to the configured host.
        """
        return Eth_OpenTcpConnection(self)
    @property
    def Eth_CloseTcpConnection(self) -> Eth_CloseTcpConnection:
        """
        Close the BRP over TCP connection.
        """
        return Eth_CloseTcpConnection(self)
    @property
    def HID_IndalaRead(self) -> HID_IndalaRead:
        """
        Returns data of Indala tags (read only tag).
        """
        return HID_IndalaRead(self)
    @property
    def HID_ProxRead(self) -> HID_ProxRead:
        """
        Returns raw data of HID prox tag (read only tag / 44 bit).
        """
        return HID_ProxRead(self)
    @property
    def HID_AwidRead(self) -> HID_AwidRead:
        """
        Returns number of a AWID tag (read only tag / 44 bit).
        """
        return HID_AwidRead(self)
    @property
    def HID_IoProxRead(self) -> HID_IoProxRead:
        """
        Returns number of a IoProx tag (read only tag / 64 bit).
        """
        return HID_IoProxRead(self)
    @property
    def HID_Prox32Read(self) -> HID_Prox32Read:
        """
        Returns raw data of HID prox 32 (orange) tag (read only tag / 32bit).
        """
        return HID_Prox32Read(self)
    @property
    def HID_PyramidRead(self) -> HID_PyramidRead:
        """
        Returns number of Farpointe Pyramid cards (variable bitlength).
        """
        return HID_PyramidRead(self)
    @property
    def HID_IndalaSecureRead(self) -> HID_IndalaSecureRead:
        """
        Returns data of indala tags (read only tag).
        """
        return HID_IndalaSecureRead(self)
    @property
    def HID_IdteckRead(self) -> HID_IdteckRead:
        """
        Returns data of idteck tags (read only tag).
        """
        return HID_IdteckRead(self)
    @property
    def Hitag_Request(self) -> Hitag_Request:
        """
        Request and AC / according to Mode byte you can request Hitag-1 and Hitag-S tags.
        """
        return Hitag_Request(self)
    @property
    def Hitag_Select(self) -> Hitag_Select:
        """
        Selects a Hitag-1 or Hitag-S tag and returns page 1.
        """
        return Hitag_Select(self)
    @property
    def Hitag_Halt(self) -> Hitag_Halt:
        """
        Sets a Hitag1/S label in halt mode.
        """
        return Hitag_Halt(self)
    @property
    def Hitag_Read(self) -> Hitag_Read:
        """
        Reads a Hitag1/S label.
        """
        return Hitag_Read(self)
    @property
    def Hitag_Write(self) -> Hitag_Write:
        """
        Writes data to a Hitag1/S label.
        """
        return Hitag_Write(self)
    @property
    def Hitag_PersonaliseHtg(self) -> Hitag_PersonaliseHtg:
        """
        Writes personalization data for Hitag1/2 to coprocessor.
        """
        return Hitag_PersonaliseHtg(self)
    @property
    def I2c_SetSpeed(self) -> I2c_SetSpeed:
        """
        Set speed of I2C interface.
        """
        return I2c_SetSpeed(self)
    @property
    def I2c_Read(self) -> I2c_Read:
        """
        Read data from I2C interface.
        """
        return I2c_Read(self)
    @property
    def I2c_Write(self) -> I2c_Write:
        """
        Write data to I2C interface.
        """
        return I2c_Write(self)
    @property
    def I2c_TxRx(self) -> I2c_TxRx:
        """
        Write data and directly after that read from I2C interface.
        """
        return I2c_TxRx(self)
    @property
    def Iso14a_RequestLegacy(self) -> Iso14a_RequestLegacy:
        """
        This commands scans for ISO 14443-3 (Type A) compliant PICCs in the field of the antenna. 
        
        If the _ReqAll_ parameter flag is set, both PICCs in idle state and PICCs in halt state will be switched to ready state. If this flag is not set, only PICCs in idle state will be switched to ready state. 
        
        **Only PICCs in ready state may be selected via the Iso14a.Select command.**
        
        **This command may return the Iso14a.ErrCollision status code when executed successfully, in case two or more PICCs of different types are present in the HF field of the reader. In this case, the selection PICC procedure can be carried out normally with the Iso14a.Select command.**
        
        This command covers the commands REQA and WAKE-UP as specified by the ISO 14443-3 standard. 
        
        **For new applications, the command Iso14a.Request should be used instead.**
        """
        return Iso14a_RequestLegacy(self)
    @property
    def Iso14a_Anticoll(self) -> Iso14a_Anticoll:
        """
        This command performs an anti-collision sequence.
        """
        return Iso14a_Anticoll(self)
    @property
    def Iso14a_SelectOnly(self) -> Iso14a_SelectOnly:
        """
        This command selects a PICC with a 4 Byte serial number.
        """
        return Iso14a_SelectOnly(self)
    @property
    def Iso14a_TransparentCmdBitlen(self) -> Iso14a_TransparentCmdBitlen:
        """
        This command is similar to _Iso14a.TransparentCmd_. The difference is that the length of data to send is given in bits instead of bytes.
        """
        return Iso14a_TransparentCmdBitlen(self)
    @property
    def Iso14CE_ActivateCardAPDU(self) -> Iso14CE_ActivateCardAPDU:
        """
        This command starts the reader's passive mode, emulating an ISO14443-4 compatible card, and returns the first APDU request received. 
        
        The emulated PICC answers all ISO14443-3 request, anticollision and select commands. It utilizes the 4-Byte serial number specified in the _Snr_ parameter. The Byte order corresponds to ISO14443-3: The first Byte (uid0) will be transmitted first to the reader. It has to be 0x08 as this indicates a random serial number. 
        
        To identify potential errors, the PCD starts a timer within which the PICC has to respond, after sending out each frame. This time duration is the so-called _frame waiting time_ (FWT). FWT is determined by the PICC during protocol activation and is valid for all further communication. This parameter should be chosen as large as required, but as small as possible. The communication speed between card emulator and host and the processing speed of the host should be taken into consideration. It is possible to increase the FWT temporarily for a single frame by calling the Iso14CE.ExtendWaitingTime command. Since the ISO14443 protocol specification only allows discrete FWT values, the firmware calculates the lowest value that meets the specified waiting time according to the equation 
        
        FWI = (256 * 16 / fc) * 2 ^ FWT, 
        
        where fc is the RFID carrier frequency. The highest possible FWT value is 4949 ms. 
        
        2 timeout parameters triggering a timer have to be specified for this command: 
        
          * The first timer, associated with the _TimeoutPCD_ parameter, is used for the card activation sequence. Card activation is complete once the emulated PICC has received the RATS command. If the emulated PICC doesn't receive the required protocol activation sequence within _TimeoutPCD_ , this command will return an Iso14CE.ErrIso144State status code. For _TimeoutPCD_ , we recommend a value of 1000 ms - this provides the best results for the protocol activation sequence. 
          * The second timer is optional (default value: 100 ms) and associated with the _TimeoutApdu_ parameter. It stops as soon as the emulated PICC has received an optional PPS command frame or an APDU Exchange command after the RATS command as defined in ISO14443-4. If the emulated PICC doesn't receive anything within _TimeoutApdu_ , this command will return an Iso14CE.ErrIso144State status code. Otherwise, the first APDU request is returned in the command's response. 
        
        
        
        The ATS (historical bytes) the card emulation shall use may be specified by the _ATS_ parameter if required. This parameter may also be left out, in which case no historical bytes are sent. 
        
        As already mentioned, ISO14443-4 specifies that a card has to send a response within _FWT_ ms. The command I4CE.ExtendWaitingTime can be called to extend this time temporarily if the host cannot prepare the APDU within the defined FWT time. A more convenient way to perform this action is to use the _automatic WTX mode_ : If the parameter _AutoWTX_ is set to 1, the card emulation will automatically transmit WTX requests periodically every 0.9 * FWT ms after the successful execution of the Iso14CE.StartEmu command and of all subsequent Iso14CE.ExchangeCardAPDU commands. In practice, this allows to ignore the FWT limits, since the card emulation itself keeps the communication with the PCD alive.
        """
        return Iso14CE_ActivateCardAPDU(self)
    @property
    def Iso14CE_ExchangeCardAPDU(self) -> Iso14CE_ExchangeCardAPDU:
        """
        Send an APDU response to the APDU request received during the last call of Iso14CE.ExchangeInverseAPDU or Iso14CE.ActivateCardAPDU, and receive the next PCD APDU request. 
        
        The _Timeout_ parameter specifies the maximum time in ms to wait for the next APDU. If no request could be received from the PCD, Iso14CE.ExchangeInverseAPDU returns the Iso14CE.ErrTimeout status code. 
        
        In case the received APDU does not fit into the internal buffer of the emulated PICC, the part of the frame which could be processed is returned together with an I4CE.ErrOverflow status code. The buffer size is firmware dependent and can be retrieved via the Sys.GetBufferSize command. 
        
        The command returns the Iso14CE.ErrIso144State status code if the PICC is not in the proper state to exchange ISO14443-4 APDUs. This is the case if Iso14CE.ActivateCardAPDU has not previously been successfully executed, or if the PCD has terminated the communication by e.g. executing the Iso14L4.Deselect command.
        """
        return Iso14CE_ExchangeCardAPDU(self)
    @property
    def Iso14CE_ExtendWaitingTime(self) -> Iso14CE_ExtendWaitingTime:
        """
        This command enables to extend the waiting time for the response from the PCD. This command is required in case the host needs a longer time than FWT (see description of the Iso14CE.ActivateCardAPDU command) to prepare a response APDU to the last request APDU from the PCD. After calling this command, the PICC repeatedly sends WTX requests to the PCD for _WaitingTimeout_ ms. 
        
        **This command should be run in BRP _Continuous Mode_ , since it can explicitly be stopped by the host by executing the _Break_ command. If this command is not run in BRP Continuous Mode, the reader has to wait for the _WaitingTimeout_ duration before finalizing the execution of the command.**
        
        The WTX request refresh interval may be accommodated with the _WTXM_ and _RefreshRatio_ parameters according to the formula: 
        
        t(refresh) = FWT * WTXM * RefreshRatio / 100. 
        
        By default, the waiting time is renewed every (0.9 * FWT) ms (WTXM = 1, RefreshRatio = 90). 
        
        Please note that according to the [ISO/IEC 14443-4:2008](https://www.iso.org/standard/50648.html) specification, the maximum allowed value for FWT and for the extension FWT * WTXM is 4949 ms. 
        
        **This command should only be used if the _AutoWTX_ parameter in the Iso14CE.ActivateCardAPDU command is set to 0. Otherwise, the card emulation automatically takes care of extending the frame waiting time.**
        """
        return Iso14CE_ExtendWaitingTime(self)
    @property
    def Iso14CE_GetExternalHfStatus(self) -> Iso14CE_GetExternalHfStatus:
        """
        Polls for an external HF field and returns the status in the _ExtFieldStat_ variable.
        """
        return Iso14CE_GetExternalHfStatus(self)
    @property
    def Iso15_ReadBlock(self) -> Iso15_ReadBlock:
        """
        **For new applications please use Iso15.WriteMultipleBlocks as this command is deprecated and may be removed in future.**
        
        This command reads one or multiple blocks from a label. 
        
        This command implements the "read single block" and "read multiple blocks" optional commands from the [ISO 15693-3 specification](http://www.iso.org/iso/catalogue_detail.htm?csnumber=43467).
        """
        return Iso15_ReadBlock(self)
    @property
    def Iso15_WriteBlock(self) -> Iso15_WriteBlock:
        """
        **For new applications please use Iso15.WriteMultipleBlocks as this command is deprecated and may be removed in future.**
        
        This command writes one or multiple blocks to a label. 
        
        This command implements the "write multiple blocks" optional commands from the [ISO 15693-3 specification](http://www.iso.org/iso/catalogue_detail.htm?csnumber=43467).
        """
        return Iso15_WriteBlock(self)
    @property
    def Iso15_TransparentCmdLegacy(self) -> Iso15_TransparentCmdLegacy:
        """
        **For new applications please use Iso15.TransparentCmd as this command is deprecated and may be removed in future.**
        
        This command sends a data stream to a label and returns the communication status and the received label data stream to the host. If no bytes are sent and the CRC check is disabled, only an EOF is sent to the label. After execution of this command, the _Mode_ parameter is reset to default. 
        
        **Please be aware that the _flag_ Byte (see the[ ISO 15693-3 specification](http://www.iso.org/iso/catalogue_detail.htm?csnumber=43467) , 2001 p.9) is not generated by the reader. This flag has to be transmitted as part of the _data_ string.**
        """
        return Iso15_TransparentCmdLegacy(self)
    @property
    def Iso78_SelectSlot(self) -> Iso78_SelectSlot:
        """
        This command can be used for readers with more than one SAM slot to switch between the slots. The slots are indexed starting at 0. At power up, slot 0 is selected. All following commands are routed to the SAM in the selected slot. 
        
        It is possible to switch the slots after opening a SAM.
        """
        return Iso78_SelectSlot(self)
    @property
    def Iso78_OpenSamLegacy(self) -> Iso78_OpenSamLegacy:
        """
        This command sets up a communication channel to the SAM in the currently selected slot. If Iso78.OpenSAM was executed successfully, Iso78.ExchangeApdu can then be used to communicate with the SAM. 
        
        To close the communication channel after data exchange, the Iso78.CloseSam command has to be called.
        """
        return Iso78_OpenSamLegacy(self)
    @property
    def Iso78_CloseSamLegacy(self) -> Iso78_CloseSamLegacy:
        """
        This command closes a communication channel previously opened via the Iso78.OpenSAM command. It is recommended to call this command before physically removing the SAM from its slot since it also powers down the SAM module.
        """
        return Iso78_CloseSamLegacy(self)
    @property
    def Iso78_ExchangeApduLegacy(self) -> Iso78_ExchangeApduLegacy:
        """
        This command sends an APDU command on the currently selected and opened SAM. Please note that the complete APDU command including the CLA, INS, P1, P2, Lc and Le values need part of the _SendData_ parameter.
        """
        return Iso78_ExchangeApduLegacy(self)
    @property
    def Legic_TransparentCommand4000(self) -> Legic_TransparentCommand4000:
        """
        Transparent command to directly access the LEGIC reader chip modules from the 4000 series, e.g. the SM-4200 or SM-4500. 
        
        Every command which is defined in the LEGIC documentation for the SM-4x00 chip may be executed using this pass-through command. 
        
        For the direct communication with the SM-4x00 LEGIC defines a protocol frame that consists of the following fields (refer also to LEGIC documentation): 
        
        LEN  |  CMD  |  DATA[]  |  CRC   
        ---|---|---|---  
          
        The reader firmware handles this frame protocol internally by calculating and appending the LEN and CRC fields automatically. The host application only specifies the fields CMD and DATA in the transparent command parameters. 
        
        The protocol frame for the response consists of the following fields: 
        
        LEN  |  CMD  |  STAT  |  DATA[]  |  CRC   
        ---|---|---|---|---  
          
        Similar to the command frame protocol also the response frame protocol is handled by the reader firmware. It verifies the CRC checksum and removes the LEN, CMD and CRC fields. Only STAT and DATA are returned to the host.
        """
        return Legic_TransparentCommand4000(self)
    @property
    def Legic_TransparentCommand6000(self) -> Legic_TransparentCommand6000:
        """
        Transparent command to directly access the LEGIC reader chip modules from the 6000 series, e.g. the SM-6300. 
        
        Every command which is defined in the LEGIC documentation for the SM-6x00 chip may be executed using this pass-through command. 
        
        For the direct communication with the SM-6x00 LEGIC defines a protocol frame that consists of the following fields (refer also to LEGIC documentation): 
        
        LEN  |  CMD  |  DATA[]  |  CRC   
        ---|---|---|---  
          
        The reader firmware handles this frame protocol internally by calculating and appending the LEN and CRC fields automatically. The host application only specifies the fields CMD and DATA in the transparent command parameters. 
        
        The protocol frame for the response consists of the following fields: 
        
        LEN  |  CMD  |  STAT  |  DATA[]  |  CRC   
        ---|---|---|---|---  
          
        Similar to the command frame protocol also the response frame protocol is handled by the reader firmware. It verifies the CRC checksum and removes the LEN, CMD and CRC fields. Only STAT and DATA are returned to the host.
        """
        return Legic_TransparentCommand6000(self)
    @property
    def Lga_TransparentCommand(self) -> Lga_TransparentCommand:
        """
        Transparent command to directly access the Legic reader chip module. 
        
        Every command which is defined in the LEGIC documentation for the SC-2560 module or the SM-4x00 chip may be executed using this pass-through command. 
        
        For the direct communication with the reader chips SC-2560 or SM-4x00 LEGIC defines a protocol frame that consists of the following fields (refer also to LEGIC documentation): 
        
        NUMBER OF BYTES/LEN  |  CMD  |  DATA[]  |  LRC/CRC   
        ---|---|---|---  
          
        The reader firmware handles this frame protocol internally by calculating and appending the NUMBER OF BYTES/LEN and LRC/CRC fields automatically. The host application only specifies the fields CMD and DATA in the transparent command parameters. 
        
        The protocol frame for the response consists of the following fields: 
        
        NUMBER OF BYTES/LEN  |  CMD  |  STAT  |  DATA[]  |  LRC/CRC   
        ---|---|---|---|---  
          
        Similar to the command frame protocol also the response frame protocol is handled by the reader firmware. It verifies the CRC checksum and removes the NUMBER OF BYTES/LEN, CMD and LRC/CRC fields. Only STAT and DATA are returned to the host.
        """
        return Lga_TransparentCommand(self)
    @property
    def Main_Bf2Upload(self) -> Main_Bf2Upload:
        """
        This command transfers a single line of a BF2 file starting with a colon to the reader (needed for firmware upload).
        """
        return Main_Bf2Upload(self)
    @property
    def Main_SwitchFW(self) -> Main_SwitchFW:
        """
        After uploading the complete firmware with Main.Bf2Upload, this command is needed to activate the new firmware and reboot the reader.
        """
        return Main_SwitchFW(self)
    @property
    def Main_MatchPlatformId2(self) -> Main_MatchPlatformId2:
        """
        This command checks if the PlatformID2 of the reader matches the PlatformID2 provided in the _Filter_ parameter. 
        
        **If this command is not available, the Sys.GetPlatformId command can be used as a fallback.**
        """
        return Main_MatchPlatformId2(self)
    @property
    def Main_IsFirmwareUpToDate(self) -> Main_IsFirmwareUpToDate:
        """
        This command checks if the following part of the firmware is already up to date. It must be called exactly in the order it occurs in the BF2 file: If the firmware is split in 2 parts and this command is in between them, it has to be called after transferring the first part and before loading the second part. Otherwise it is not guaranteed that it works correctly.
        """
        return Main_IsFirmwareUpToDate(self)
    @property
    def Mce_Enable(self) -> Mce_Enable:
        """
        This command enables/disables Mobile Card Emulation (MCE).
        """
        return Mce_Enable(self)
    @property
    def Mce_Request(self) -> Mce_Request:
        """
        This command is used to check if a Mobile Card Emulation (MCE) device (usually a smartphone running a particular app) is currently presented to the reader. As long as an MCE device is detected, the command returns the serial number that has been transferred from the device to the reader. 
        
        If no MCE device is detected, the status code Mce.ErrNoTag will be returned. In case MCE is not enabled on the reader, Mce.ErrDisabled will be returned.
        """
        return Mce_Request(self)
    @property
    def Mif_Request(self) -> Mif_Request:
        """
        Request labels in the field of the antenna. 
        
        _ATQA_ is a two byte value (MSB first). This value is called _tagtype_ and for MIFARE 1 CSCs, it is expected to be equal to 0x0004. 
        
        **For new applications, the Iso14a.Request command should be used instead.**
        """
        return Mif_Request(self)
    @property
    def Mif_Anticoll(self) -> Mif_Anticoll:
        """
        This command performs an anti-collision sequence. 
        
        A number of bits equal to the _BitCount_ value will be used in _PreSelSer_ for preselection of cards in the HF field of the antenna. This means that only cards with a serial number matching the first _BitCount_ bits of _PreSelSer_ will be taken into consideration. The command returns an unambiguous serial number in the _Snr_ value which may be used for the card selection procedure, using the Mif.Select command. 
        
        **For new applications, the Iso14a.Anticoll command should be used instead.**
        """
        return Mif_Anticoll(self)
    @property
    def Mif_Select(self) -> Mif_Select:
        """
        This command selects a card with a 4 Byte serial number specified in the _Snr_ parameter. 
        
        **This command is deprecated. For new applications, the Iso14a.Select command should be used instead.**
        """
        return Mif_Select(self)
    @property
    def Mif_Halt(self) -> Mif_Halt:
        """
        Switch card to halt state. The card has to be selected before it may be switched to halt state.
        """
        return Mif_Halt(self)
    @property
    def Pico_SetHfMode(self) -> Pico_SetHfMode:
        """
        Specify HF communication mode that should be used by the commands in this command-set.
        """
        return Pico_SetHfMode(self)
    @property
    def Pico_RequestAnticoll(self) -> Pico_RequestAnticoll:
        """
        Request PICCs and perform anticollision.
        """
        return Pico_RequestAnticoll(self)
    @property
    def Pico_Select(self) -> Pico_Select:
        """
        Select PICC.
        """
        return Pico_Select(self)
    @property
    def Pico_Halt(self) -> Pico_Halt:
        """
        Set PICC to halt mode.
        """
        return Pico_Halt(self)
    @property
    def Pico_SelectBookPage(self) -> Pico_SelectBookPage:
        """
        Selects book and page of a selected picopass label
        """
        return Pico_SelectBookPage(self)
    @property
    def Pico_Authenticate(self) -> Pico_Authenticate:
        """
        Authenticates a previously selected picopass label
        """
        return Pico_Authenticate(self)
    @property
    def Pico_Read(self) -> Pico_Read:
        """
        Reads a picopass label
        """
        return Pico_Read(self)
    @property
    def Pico_Write(self) -> Pico_Write:
        """
        Writes to picopass label
        """
        return Pico_Write(self)
    @property
    def Pki_PfsGenKey(self) -> Pki_PfsGenKey:
        """
        This command prepares a perfect forward secrecy (PFS) session by exchanging the public part of temporary elliptic curve cryptography (ECC) keys generated by host and reader. These are needed by the Pki.PfsAuthHostCert and Pki.PfsAuthRdrCert commands. 
        
        The next step in negotiating a session key can be performed by running the Pki.PfsAuthHostCert command. 
        
        If a session key was negotiated before running this command, it will be invalidated. For this reason, it is not possible to exchange encrypted commands until finalizing the session setup sequence. 
        
        The temporary keys generated by the host (_TmpHostPubKey_ parameter) and by the reader (_TmpRdrPubKey_ response variable) follow the Abstract Syntax Notation One (ASN.1) Distinguished Encoding Rules (DER) format. An example of the format for such keys is as follows: 
        
        30 59 30 13 06 07 2A 86 48 CE 3D 02 01 06 08 2A 86 48 CE 3D 03 01 07 03 42 00 04 0C C2 D2 24 16 47 4B DC A1 39 52 08 73 B7 6E A1 32 40 34 7B 8D 70 2F E1 FC CC 93 81 ED EF 65 8E 0C 49 A8 63 0F 23 65 07 5F C1 19 3A 3B 90 4F CA 35 E7 18 52 F7 95 AA CF FB FE 96 66 3D 44 0A BA 
        
        Please not that the initial part of the key (30 59 30 13 06 07 2A 86 48 CE 3D 02 01 06 08 2A 86 48 CE 3D 03 01 07) is the ASN.1 DER-specific header and must always be identical. 
        
        **This command needs a long timeout, since the ECC operations may take up to 15 seconds.**
        """
        return Pki_PfsGenKey(self)
    @property
    def Pki_PfsAuthHostCert(self) -> Pki_PfsAuthHostCert:
        """
        This command authenticates the host's certificate chain to the reader. If the certificate chain is longer than one certificate, this command has to be called multiple times with the _IsEndCert_ flag of the _EncryptedPayload_ parameter set to 0, until the last certificate has been reached in which case it must be set to 1. 
        
        The certificates must comply with the following limitations: 
        
          * Certificates have to be X.509 v3 certificates. 
          * As signing algorithms, only ECC P-256 and SHA256 are allowed. 
          * The only allowed extensions are _basicConstraints_ (indicating the certificate is a CA certificate) and the (optional) Baltech proprietary certificate _acMask_ using the ASN.1 object identifier (OID) _1.3.6.1.4.1.44885.1_. 
        
        The 32-bit _acMask_ extension makes it possible to further restrict the allowed operations by the reader in the Security Level corresponding to the certificate since it will be combined with the reader's internal 32-bit _Access Condition Mask_ , using a logical _AND_ operator. 
        
        
        
        
        If this command is called multiple times (since the certificate chain contains multiple entries), it is required that the _SecLevel_ and _SessionTimeout_ field always have the same value. 
        
        If the format of _HostCert_ is invalid or if the signature verification fails, the ERR_CERT status code is returned. 
        
        **This command needs a long timeout, since the ECC operations may take up to 15 seconds.**
        """
        return Pki_PfsAuthHostCert(self)
    @property
    def Pki_PfsAuthRdrCert(self) -> Pki_PfsAuthRdrCert:
        """
        After successfully authenticating the host against the reader using the Pki.PfsAuthHostCert command, the reader must return its own certificate to the host in order the host to verify it. 
        
        This command will finalize the PFS session setup and calculate the new AES-128 session key. This session key has to be used for all following calls of the Pki.Tunnel2 command. 
        
        **This command needs a long timeout, since the ECC operations may take up to 15 seconds.**
        """
        return Pki_PfsAuthRdrCert(self)
    @property
    def Pki_Tunnel2(self) -> Pki_Tunnel2:
        """
        Runs a command in the Security Level authenticated by the Pki.PfsGenKey, Pki.PfsAuthHostCert, Pki.PfsAuthRdrCert commands sequence. The command is encrypted with the session key calculated by Pki.PfsAuthRdrCert. 
        
        After the reader decrypts the received tunnelled command, it checks whether this command is blocked by the _Access Condition Mask_ assigned to the Security Level or by one of the Access Condition Masks of the certificates in the host certificate chain. If this command is blocked by one of these Access Condition Masks, it is not allowed to be executed in the given Security Level and the ErrAccessDenied status code is returned.
        """
        return Pki_Tunnel2(self)
    @property
    def Pki_GetX509Csr(self) -> Pki_GetX509Csr:
        """
        Every reader is shipped with a unique ECC P-256 key, generated at the time of manufacturing. This command returns a certificate signing request (CSR) over the public part of the reader's key, which can be signed by a certificate authority. To store the signed certificate on the reader, run the Pki.StoreX509Cert command afterwards.
        """
        return Pki_GetX509Csr(self)
    @property
    def Pki_StoreX509Cert(self) -> Pki_StoreX509Cert:
        """
        After signing a CSR using the Pki.GetX509Csr command, run this command to store the resulting in the reader's certificate store. The certificate store provides up to 3 slots (for security level 1-3). This means up to 3 different certificate authorities can store their certificates in a reader. 
        
        The certificates must comply with the following limitations: 
        
          * Only ECC P-256 and SHA256 are allowed as signing algorithms. 
          * The length of the tag containing the issuer distinguished name must not exceed 128 Bytes. 
          * No extensions are allowed. 
        
        
        
        A sample certificate matching all these limitations is the following: 
        
        30 82 01 6C 30 82 01 11 A0 03 02 01 02 02 01 01 30 0A 06 08 2A 86 48 CE 3D 04 03 02 30 3C 31 23 30 21 06 03 55 04 03 0C 1A 49 6E 74 65 72 6D 65 64 69 61 74 65 20 43 41 20 66 6F 72 20 52 65 61 64 65 72 31 15 30 13 06 03 55 04 0A 0C 0C 43 75 73 74 6F 6D 65 72 20 4F 6E 65 30 1E 17 0D 30 30 30 31 30 31 30 30 30 30 30 30 5A 17 0D 33 38 30 31 31 39 30 32 31 34 30 37 5A 30 42 31 14 30 12 06 03 55 04 03 0C 0B 53 23 20 31 31 31 31 31 31 31 31 31 13 30 11 06 03 55 04 0A 0C 0A 42 61 6C 74 65 63 68 20 41 47 31 15 30 13 06 03 55 04 07 0C 0C 48 61 6C 6C 62 65 72 67 6D 6F 6F 73 30 59 30 13 06 07 2A 86 48 CE 3D 02 01 06 08 2A 86 48 CE 3D 03 01 07 03 42 00 04 C3 4D 0E D2 EA 8F 94 88 93 E0 16 75 06 78 67 BB 96 14 5A A9 24 F8 95 02 4F 47 87 C7 1C B3 1F D5 83 CD 8C A3 FB B2 57 51 38 BF 81 AA 9C 26 DC CA 71 A6 FE 83 1B 2C 88 60 86 69 D3 53 93 08 39 D7 30 0A 06 08 2A 86 48 CE 3D 04 03 02 03 49 00 30 46 02 21 00 90 6F 97 EF C0 95 1C 9C FC 60 4C 1F F7 12 00 F4 C8 2C EA FE 4E 9D C9 F0 BE 29 75 C6 E6 42 3C 1B 02 21 00 BB 22 42 56 13 5A B5 BF D1 19 B7 40 EA 44 30 2B 14 3B 86 4E 0C 48 24 96 8F FB 49 69 24 71 CA DF 
        
        This sample certificate can be decoded using the following online tool: <https://redkestrel.co.uk/tools/decoder/>
        
        Furthermore, the access conditions mask of the security level running the Pki.StoreX509Cert command has to allow setting the corresponding key (SEC_SETKEY1, SEC_SETKEY2 or SEC_SETKEY3 bit of the access condition mask must be set). 
        
        **This command needs a long timeout, since the ECC operations may take up to 15 seconds.**
        """
        return Pki_StoreX509Cert(self)
    @property
    def Pki_StoreX509RootCert(self) -> Pki_StoreX509RootCert:
        """
        Every security level that should be usable with the PKI must be provided with a root certificate. The certificate chain provided in the Pki.PfsAuthHostCert command will be verified against this root certificate. 
        
        The root certificates must comply with the following limitations: 
        
          * Certificates have to be X.509 v3 certificates. 
          * Only ECC P-256 and SHA256 are allowed as signing algorithms. 
          * The length of the tags containing the Issuer Unique Identifier and the Subject Unique Identifier must not exceed 128 Bytes. 
          * The only allowed extension is _basicConstraints_ (indicating the certificate is a CA certificate) 
          * The validity period always has to be from "Jan 1 00:00:00 2000 GMT" to "Jan 19 02:14:07 2038 GMT". 
        
        
        
        A sample certificate matching all these limitations is the following: 
        
        30 82 01 9D 30 82 01 43 A0 03 02 01 02 02 01 01 30 0A 06 08 2A 86 48 CE 3D 04 03 02 30 41 31 19 30 17 06 03 55 04 03 0C 10 52 6F 6F 74 20 43 65 72 74 69 66 69 63 61 74 65 31 11 30 0F 06 03 55 04 0A 0C 08 45 71 75 69 74 72 61 63 31 11 30 0F 06 03 55 04 07 0C 08 57 61 74 65 72 6C 6F 6F 30 1E 17 0D 30 30 30 31 30 31 30 30 30 30 30 30 5A 17 0D 33 38 30 31 31 39 30 32 31 34 30 37 5A 30 41 31 19 30 17 06 03 55 04 03 0C 10 52 6F 6F 74 20 43 65 72 74 69 66 69 63 61 74 65 31 11 30 0F 06 03 55 04 0A 0C 08 45 71 75 69 74 72 61 63 31 11 30 0F 06 03 55 04 07 0C 08 57 61 74 65 72 6C 6F 6F 30 59 30 13 06 07 2A 86 48 CE 3D 02 01 06 08 2A 86 48 CE 3D 03 01 07 03 42 00 04 B0 13 B7 1F A6 61 47 8E 8D 2F FC C0 36 17 C0 51 5D 2A 39 C5 67 15 1A E3 85 2A 3B 9C 2E 93 FA 41 0A B5 F3 66 62 6A F8 04 D7 0E D1 DB 7A 2D 36 26 0A A5 77 D2 9C D4 65 24 70 DF 9A 74 40 C2 A7 B1 A3 2C 30 2A 30 0F 06 03 55 1D 13 01 01 FF 04 05 30 03 01 01 FF 30 17 06 09 2B 06 01 04 01 82 DE 55 01 01 01 FF 04 07 03 05 00 08 00 10 80 30 0A 06 08 2A 86 48 CE 3D 04 03 02 03 48 00 30 45 02 21 00 BB 42 BB 32 8C D5 68 39 E9 40 28 10 5F 63 E1 52 9A 63 06 BF B2 69 03 0A F8 9D A5 56 95 CF 0F B2 02 20 35 D6 FF 5C 9A 42 D9 85 5E F3 16 DA 7A 53 19 F7 74 81 A4 54 B3 D4 C9 74 26 78 D2 1D 11 52 2D 2A 
        
        This sample certificate can be decoded using the following online tool: <https://redkestrel.co.uk/tools/decoder/>
        
        Furthermore, the access conditions mask of the security llevel running the Pki.StoreX509RootCert command has to allow setting the corresponding key (SEC_SETKEY1, SEC_SETKEY2 or SEC_SETKEY3 bit of the access condition mask must be set). 
        
        **This command needs a long timeout, since the ECC operations may take up to 15 seconds.**
        """
        return Pki_StoreX509RootCert(self)
    @property
    def QKey_Read(self) -> QKey_Read:
        """
        Returns data of quadrakey tags (read only tag).
        """
        return QKey_Read(self)
    @property
    def Rtc_GetTime(self) -> Rtc_GetTime:
        """
        Retrieve current time of on-board RTC.
        """
        return Rtc_GetTime(self)
    @property
    def Rtc_SetTime(self) -> Rtc_SetTime:
        """
        Set the time of the on-board RTC.
        """
        return Rtc_SetTime(self)
    @property
    def Srix_Select(self) -> Srix_Select:
        """
        This command selects a label including anticollision.
        """
        return Srix_Select(self)
    @property
    def Srix_Read(self) -> Srix_Read:
        """
        This command reads a secure data page
        """
        return Srix_Read(self)
    @property
    def Srix_Write(self) -> Srix_Write:
        """
        This command writes data to a page address of a label.
        """
        return Srix_Write(self)
    @property
    def Sys_GetPort(self) -> Sys_GetPort:
        """
        This command retrieves the logic state for the custom I/O ports of the module. Each module can have up to 16 ports, with each bit of the returned _PortMask_ value corresponding to a port. _1_ corresponds to high state (VCC), while _0_ corresponds to low state (GND).
        """
        return Sys_GetPort(self)
    @property
    def Sys_SetPort(self) -> Sys_SetPort:
        """
        **Please use UI.Enable and UI.Disable instead of this command for new applications.**
        
        Sets/clears custom I/O ports of the module. Every bit in _PortMask_ is assigned to an I/O port. By calling this command all output ports are set. Some ports need to be configured as output ports before being set via this command.
        """
        return Sys_SetPort(self)
    @property
    def Sys_CfgWriteTlvSector(self) -> Sys_CfgWriteTlvSector:
        """
        **Please use Sys.CfgLoadBlock instead of this command for new applications.**
        
        This command parses the given TLV block and stores all its keys and values into the reader's configuration memory.
        """
        return Sys_CfgWriteTlvSector(self)
    @property
    def Sys_ConfigPort(self) -> Sys_ConfigPort:
        """
        Configures generic I/O ports for input/output. 
        
        **Some ports are unidirectional (only usable either as an input or as an output). Only bidirectional ports can be reconfigured via this command.**
        
        **I/O Port configuration can also be performed via scripts in the configuration editor. See the BaltechScript documentation for further details.**
        """
        return Sys_ConfigPort(self)
    @property
    def Sys_SetRegister(self) -> Sys_SetRegister:
        """
        Sets one or multiple of the reader's internal registers. 
        
        **To reset a register, its _Value_ should be set to 0xFFFF.**
        
        **If the parameter _ResetRegister_ is set to _True_ , all registers of the reader will be reset.**
        
        **Register setting operations are usually performed by changing the relevant configuration values.**
        """
        return Sys_SetRegister(self)
    @property
    def Sys_GetRegister(self) -> Sys_GetRegister:
        """
        Retrieves one of the reader's internal registers. 
        
        **Register setting operations are usually performed by changing the relevant configuration values.**
        """
        return Sys_GetRegister(self)
    @property
    def Sys_PowerDown(self) -> Sys_PowerDown:
        """
        Powers off the device. 
        
        This command is only supported by Baltech devices with special hardware support. 
        
        **_WARNING:_ This function has the wrong name. It does not put the device into _power down_ mode (low power sleep) but turns it off completely.**
        """
        return Sys_PowerDown(self)
    @property
    def Sys_SetCommParam(self) -> Sys_SetCommParam:
        """
        This command is only required when the _serial_ host-to-reader interface is in use. In case the protocol is running, this command can be used to change the settings of the serial line: 
        
          * Baud rate 
          * Parity 
          * Character Waiting Time (CWT) 
        
        
        
        Usually the reader uses the settings specified in the configuration of the reader under the Protocols/BrpSerial Key. If the corresponding configuration values do not exist, the default settings are used (Baud rate 115200; no parity; CWT 20 ms). 
        
        **The BRP response frame to this command is received according to the _old_ serial settings. The new serial settings are only in effect starting with the next BRP command frame.**
        
        **The parameters set by this command are lost when the reader is powered off or reset.**
        
        **CWT must never be smaller than the time needed for transferring a single byte. This is especially important when using baud rates smaller than 9600. It is good practice to adapt the CWT according to the following equation: CWT = 10 / baud rate + 10.**
        """
        return Sys_SetCommParam(self)
    @property
    def Sys_GetPlatformId(self) -> Sys_GetPlatformId:
        """
        Maintenance command only needed for Baltech internal use to get detailed information about the actually used hardware. 
        
        **This command must only be used if the Main.MatchPlatformId2 command is not supported by the current firmware.**
        """
        return Sys_GetPlatformId(self)
    @property
    def Sys_FactoryResetLegacy(self) -> Sys_FactoryResetLegacy:
        """
        **This is a legacy command! For new developments please use Sys.FactoryReset .**
        
        This command resets the device's configuration to the state it had, when leaving the factory. 
        
        A factory reset is only available on newer devices (about 2017 and later). When running it on a older Hardware Sys.ErrNotSupportedByHardware is returned. 
        
        **After a factory reset a Sys.Reset has to be done to ensure that the factory settings are fully activated.**
        """
        return Sys_FactoryResetLegacy(self)
    @property
    def Sys_GetFwCrc(self) -> Sys_GetFwCrc:
        """
        Maintenance command only needed for Baltech internal use to get the CRC of the firmware.
        """
        return Sys_GetFwCrc(self)
    @property
    def TTF_ReadByteStream(self) -> TTF_ReadByteStream:
        """
        Returns raw data of the 125 kHz HF interface.
        """
        return TTF_ReadByteStream(self)
    @property
    def UsbHost_Enable(self) -> UsbHost_Enable:
        """
        Enable/Disable the USB-Host-Interface of the uC.
        """
        return UsbHost_Enable(self)
    @property
    def UsbHost_IsConnected(self) -> UsbHost_IsConnected:
        """
        Check if a device is connected.
        """
        return UsbHost_IsConnected(self)
    @property
    def UsbHost_SetupPipes(self) -> UsbHost_SetupPipes:
        """
        Setup all Pipes Definitions (uC's internal configuration).
        """
        return UsbHost_SetupPipes(self)
    @property
    def UsbHost_SetAddr(self) -> UsbHost_SetAddr:
        """
        Set Address of device.
        """
        return UsbHost_SetAddr(self)
    @property
    def UsbHost_Reset(self) -> UsbHost_Reset:
        """
        Send a Reset via USB interface, Remove all Pipes Definitions and reset address of device to 0.
        """
        return UsbHost_Reset(self)
    @property
    def UsbHost_TransRawSetup(self) -> UsbHost_TransRawSetup:
        """
        Transfers a raw SETUP packet. Has to be combined with a call of UsbHost.TransSetupIn or UsbHost.TransSetupOut.
        """
        return UsbHost_TransRawSetup(self)
    @property
    def UsbHost_TransSetupIn(self) -> UsbHost_TransSetupIn:
        """
        Transfers a SETUP transaction with a IN DATA stage.
        """
        return UsbHost_TransSetupIn(self)
    @property
    def UsbHost_TransSetupOut(self) -> UsbHost_TransSetupOut:
        """
        Transfers a SETUP transaction with a OUT DATA stage.
        """
        return UsbHost_TransSetupOut(self)
    @property
    def UsbHost_TransIn(self) -> UsbHost_TransIn:
        """
        Transfers an IN transaction.
        """
        return UsbHost_TransIn(self)
    @property
    def UsbHost_TransOut(self) -> UsbHost_TransOut:
        """
        Transfers an OUT transaction.
        """
        return UsbHost_TransOut(self)
    @property
    def UsbHost_Suspend(self) -> UsbHost_Suspend:
        """
        Send a Suspend via USB interface.
        """
        return UsbHost_Suspend(self)
    @property
    def UsbHost_Resume(self) -> UsbHost_Resume:
        """
        Send a Resume via USB interface.
        """
        return UsbHost_Resume(self)
    @property
    def VHL_GetLegacyATR(self) -> VHL_GetLegacyATR:
        """
        This command is deprecated and should only be used for compatibility purposes with older firmware version. It returns the Answer To Reset (ATR) of the currently selected card in a legacy format, i.e. not conform with the [PC/SC specification, version 2](http://pcscworkgroup.com/Download/Specifications/pcsc3_v2.01.09.pdf). For new projects it is recommended to use the VHL.GetATR command instead. 
        
        If the VHL.Select command has not been successfully executed before this command, the VHL.ErrCardNotSelected status code will be returned. If the last selected card is no longer available in the field of the antenna, or if a read/write operation failed before executing this command, the returned ATR is undefined. 
        
        The returned _ATR_ variable always has the following format: 
        
          * 0x3B 
          * Length of card UID (in bytes) 
          * Card UID
        """
        return VHL_GetLegacyATR(self)
    @property
    def VHL_SetupMifare(self) -> VHL_SetupMifare:
        """
        This commands prepares the reader to access Mifare cards with the given Mifare key settings. It can be called before using VHL.Read and VHL.Write with Mifare cards without configuring the reader with a VHL-file, i.e. when the _ID_ parameter of VHL.Read or VHL.Write is set to 0xFF. 
        
        All data blocks of the card starting from sector 1 will be included in the ad hoc VHL-file. This only makes sense if all blocks can be accessed using the same key. If this assumption is too simplistic for your application, please use a normal VHL-file to set up the reader. 
        
        **After calling VHL.Select , VHL.Read or VHL.Write with an _ID_ parameter other than 0xFF, or after a reboot, the settings made by this command are lost.**
        
        **For new applications, the command VHL.Setup should be used instead.**
        """
        return VHL_SetupMifare(self)
    @property
    def VHL_SetupLegic(self) -> VHL_SetupLegic:
        """
        This commands prepares the reader to access LEGIC cards with the given settings. It can be called before using VHL.Read and VHL.Write with LEGIC cards without configuring the reader with a VHL-file, i.e. when the _ID_ parameter of VHL.Read or VHL.Write is set to 0xFF. 
        
        A distinct segment of the LEGIC card to access may be specified, either according to its fixed segment ID (through the _SegmentID_ parameter) or according to its stamp (through the _Stamp_ parameter). 
        
        This command works with a fixed address mapping for the application data: VHL address 0 corresponds to Protocol Header address 25, the first data byte after the longest possible LEGIC Prime stamp. If this assumption is too simplistic for your application, please use VHL.Setup or a normal VHL-file to set up the reader. 
        
        **After calling VHL.Select , VHL.Read or VHL.Write with an _ID_ parameter other than 0xFF, or after a reboot, the settings made by this command are lost.**
        
        **For new applications, the command VHL.Setup should be used instead.**
        """
        return VHL_SetupLegic(self)
    @property
    def VHL_SetupISO15(self) -> VHL_SetupISO15:
        """
        This commands prepares the reader to access ISO15693 cards with the given settings. It can be called before using VHL.Read and VHL.Write with ISO15693 cards without configuring the reader with a VHL-file, i.e. when the _ID_ parameter of VHL.Read or VHL.Write is set to 0xFF. 
        
        **After calling VHL.Select , VHL.Read or VHL.Write with an _ID_ parameter other than 0xFF, or after a reboot, the settings made by this command are lost.**
        
        **Firmware versions 1100 2.07.00 and above also support 16-bit length values for the FirstBlock and BlockCount parameters. This is not explicitly documented.**
        
        **For new applications, the command VHL.Setup should be used instead.**
        """
        return VHL_SetupISO15(self)
    @property
    def VHL_Format(self) -> VHL_Format:
        """
        This command formats a blank card based on a VHL file. In this file, you specify the card-specific memory structure. 
        
        **_VHL.Format_ only works with the[ standard VHL implementation](https://docs.baltech.de/developers/map-vhl.html) using a static VHL file. You cannot use a dynamic VHL file created with VHL.Setup .**
        """
        return VHL_Format(self)
    @property
    def DHWCtrl_PortConfig(self) -> DHWCtrl_PortConfig:
        """
        Configures a port.
        """
        return DHWCtrl_PortConfig(self)
    @property
    def DHWCtrl_PortGet(self) -> DHWCtrl_PortGet:
        """
        Reads the current input of a port.
        """
        return DHWCtrl_PortGet(self)
    @property
    def DHWCtrl_PortSet(self) -> DHWCtrl_PortSet:
        """
        Sets the state of a port.
        """
        return DHWCtrl_PortSet(self)
    @property
    def DHWCtrl_PortWait(self) -> DHWCtrl_PortWait:
        """
        Waits until a port has reached the specified level, or until timeout.
        """
        return DHWCtrl_PortWait(self)
    @property
    def DHWCtrl_GetResetCause(self) -> DHWCtrl_GetResetCause:
        """
        Returns the cause of the microcontroller's last reset.
        """
        return DHWCtrl_GetResetCause(self)
    @property
    def DHWCtrl_APortMeasure(self) -> DHWCtrl_APortMeasure:
        """
        The selected ADC Clock is MCU Clock / 128 (i.e. 13.56 Mhz / 128) 
        
        After 13 ADC Clock Ticks the first sample will measured. 13 ADC Clock Ticks are needed for one sample: 
        
        (1 / 13.56 Mhz) * 128 * 13 = 0.123 ms 
        
        So we have each 0.123ms one sample. As reference voltage the AVR internal 2.56V is used, the results are 10 bit values, so to get the voltage in Volt use the following formula: 
        
        Vin = float(result) / 1024 * 2.56V = float(result) / 400V
        """
        return DHWCtrl_APortMeasure(self)
    @property
    def DHWCtrl_SRAMTest(self) -> DHWCtrl_SRAMTest:
        """
        Tests the external SRAM.
        """
        return DHWCtrl_SRAMTest(self)
    @property
    def DHWCtrl_SetBaudrate(self) -> DHWCtrl_SetBaudrate:
        """
        Changes the baudrate. This command should not be called over BRP.
        """
        return DHWCtrl_SetBaudrate(self)
    @property
    def DHWCtrl_MirrorData(self) -> DHWCtrl_MirrorData:
        """
        Sends the exact same data back.
        """
        return DHWCtrl_MirrorData(self)
    @property
    def DHWCtrl_DispEnable(self) -> DHWCtrl_DispEnable:
        """
        Enables the Display.
        """
        return DHWCtrl_DispEnable(self)
    @property
    def DHWCtrl_DispBacklight(self) -> DHWCtrl_DispBacklight:
        """
        Enables the Baltech reader display's backlight.
        """
        return DHWCtrl_DispBacklight(self)
    @property
    def DHWCtrl_DispColor(self) -> DHWCtrl_DispColor:
        """
        Set the drawing color
        """
        return DHWCtrl_DispColor(self)
    @property
    def DHWCtrl_DispContrast(self) -> DHWCtrl_DispContrast:
        """
        Changes the display contrast.
        """
        return DHWCtrl_DispContrast(self)
    @property
    def DHWCtrl_DispBox(self) -> DHWCtrl_DispBox:
        """
        Draws a filled box.
        """
        return DHWCtrl_DispBox(self)
    @property
    def DHWCtrl_Ser2Ctrl(self) -> DHWCtrl_Ser2Ctrl:
        """
        Enable/Disable and setup the reader's 2nd RS-232/UART interface.
        """
        return DHWCtrl_Ser2Ctrl(self)
    @property
    def DHWCtrl_Ser2WriteRead(self) -> DHWCtrl_Ser2WriteRead:
        """
        Write/Read data to/from the reader's 2nd RS-232/UART interface.
        """
        return DHWCtrl_Ser2WriteRead(self)
    @property
    def DHWCtrl_Ser2Flush(self) -> DHWCtrl_Ser2Flush:
        """
        Wait until output to 2nd RS-232/UART interface is sent out.
        """
        return DHWCtrl_Ser2Flush(self)
    @property
    def DHWCtrl_Delay1ms(self) -> DHWCtrl_Delay1ms:
        """
        Sleeps for some milliseconds.
        """
        return DHWCtrl_Delay1ms(self)
    @property
    def DHWCtrl_Delay10us(self) -> DHWCtrl_Delay10us:
        """
        Sleeps for some microseconds.
        """
        return DHWCtrl_Delay10us(self)
    @property
    def DHWCtrl_PowermgrSuspend(self) -> DHWCtrl_PowermgrSuspend:
        """
        Takes the board into suspend mode, i.e. energy saving mode.
        """
        return DHWCtrl_PowermgrSuspend(self)
    @property
    def DHWCtrl_ScanMatrix(self) -> DHWCtrl_ScanMatrix:
        """
        Writes a bitmask to the 573, which is used for keyboard scanning.
        """
        return DHWCtrl_ScanMatrix(self)
    @property
    def DHWCtrl_GetReaderChipType(self) -> DHWCtrl_GetReaderChipType:
        """
        Returns the RC reader chip type.
        """
        return DHWCtrl_GetReaderChipType(self)
    @property
    def DHWCtrl_SelectAntenna(self) -> DHWCtrl_SelectAntenna:
        """
        Switch external antenna.
        """
        return DHWCtrl_SelectAntenna(self)
    @property
    def DHWCtrl_GetSamType(self) -> DHWCtrl_GetSamType:
        """
        Returns the RC reader chip type
        """
        return DHWCtrl_GetSamType(self)
    @property
    def DHWCtrl_HfAcquire(self) -> DHWCtrl_HfAcquire:
        """
        Acquire specific HF Subsystem.
        """
        return DHWCtrl_HfAcquire(self)
    @property
    def DHWCtrl_EepromWrite(self) -> DHWCtrl_EepromWrite:
        """
        Writes data to an arbitrary address in the EEPROM.
        """
        return DHWCtrl_EepromWrite(self)
    @property
    def DHWCtrl_DataflashGetSize(self) -> DHWCtrl_DataflashGetSize:
        """
        Retrieves the flash size.
        """
        return DHWCtrl_DataflashGetSize(self)
    @property
    def DHWCtrl_DataflashErasePages(self) -> DHWCtrl_DataflashErasePages:
        """
        Erase a group of pages.
        """
        return DHWCtrl_DataflashErasePages(self)
    @property
    def DHWCtrl_DataflashRead(self) -> DHWCtrl_DataflashRead:
        """
        Read data within a certain page.
        """
        return DHWCtrl_DataflashRead(self)
    @property
    def DHWCtrl_DataflashWrite(self) -> DHWCtrl_DataflashWrite:
        """
        Write data to a certain page.
        """
        return DHWCtrl_DataflashWrite(self)
    @property
    def DHWCtrl_EepromRead(self) -> DHWCtrl_EepromRead:
        """
        Reads data from the EEPROM.
        """
        return DHWCtrl_EepromRead(self)
    @property
    def DHWCtrl_SecurityAndConfigReset(self) -> DHWCtrl_SecurityAndConfigReset:
        """
        Reset configuration incl. "Encryption and Authorization" settings.
        """
        return DHWCtrl_SecurityAndConfigReset(self)
    @property
    def DHWCtrl_PulseGenerate(self) -> DHWCtrl_PulseGenerate:
        """
        Generates a pulse of specified frequency on a certain pin.
        """
        return DHWCtrl_PulseGenerate(self)
    @property
    def DHWCtrl_InitSer2(self) -> DHWCtrl_InitSer2:
        """
        Initializes the serial2 module.
        """
        return DHWCtrl_InitSer2(self)
    @property
    def DHWCtrl_InitRtc(self) -> DHWCtrl_InitRtc:
        """
        Initializes the rtc module.
        """
        return DHWCtrl_InitRtc(self)
    @property
    def DHWCtrl_InitLcdDrv(self) -> DHWCtrl_InitLcdDrv:
        """
        Initializes the display module.
        """
        return DHWCtrl_InitLcdDrv(self)
    @property
    def DHWCtrl_InitRc(self) -> DHWCtrl_InitRc:
        """
        Initializes the rc module.
        """
        return DHWCtrl_InitRc(self)
    @property
    def DHWCtrl_InitMf(self) -> DHWCtrl_InitMf:
        """
        Initializes the Mifare module.
        """
        return DHWCtrl_InitMf(self)
    @property
    def DHWCtrl_InitIso14A(self) -> DHWCtrl_InitIso14A:
        """
        Initializes the ISO14443A module.
        """
        return DHWCtrl_InitIso14A(self)
    @property
    def DHWCtrl_InitIso14B(self) -> DHWCtrl_InitIso14B:
        """
        Initializes the ISO14443B module.
        """
        return DHWCtrl_InitIso14B(self)
    @property
    def DHWCtrl_InitIso15(self) -> DHWCtrl_InitIso15:
        """
        Initializes the ISO15693 module.
        """
        return DHWCtrl_InitIso15(self)
    @property
    def DHWCtrl_InitLg(self) -> DHWCtrl_InitLg:
        """
        Initializes the Legic module.
        """
        return DHWCtrl_InitLg(self)
    @property
    def DHWCtrl_InitLga(self) -> DHWCtrl_InitLga:
        """
        Initializes the Legic Advant module.
        """
        return DHWCtrl_InitLga(self)
    @property
    def DHWCtrl_InitDf(self) -> DHWCtrl_InitDf:
        """
        Initializes the dataflash module.
        """
        return DHWCtrl_InitDf(self)
    @property
    def DHWCtrl_InitRc125(self) -> DHWCtrl_InitRc125:
        """
        Initializes the RC125 module.
        """
        return DHWCtrl_InitRc125(self)
    @property
    def DHWCtrl_InitCc(self) -> DHWCtrl_InitCc:
        """
        Initializes the TDA8007 or CCUART module.
        """
        return DHWCtrl_InitCc(self)
    @property
    def DHWCtrl_InitUsbHost(self) -> DHWCtrl_InitUsbHost:
        """
        Initializes the USB-Host module.
        """
        return DHWCtrl_InitUsbHost(self)
    @property
    def DHWCtrl_InitNic(self) -> DHWCtrl_InitNic:
        """
        Initializes the Network Interface (NIC) module.
        """
        return DHWCtrl_InitNic(self)
    @property
    def DHWCtrl_BohEnable(self) -> DHWCtrl_BohEnable:
        """
        Enables the BRP over HID interface.
        """
        return DHWCtrl_BohEnable(self)
    @property
    def DHWCtrl_NicEnable(self) -> DHWCtrl_NicEnable:
        """
        Enables the Network Interface.
        """
        return DHWCtrl_NicEnable(self)
    @property
    def DHWCtrl_NicGetChipType(self) -> DHWCtrl_NicGetChipType:
        """
        Returns the chip type of the Network Interface.
        """
        return DHWCtrl_NicGetChipType(self)
    @property
    def DHWCtrl_NicGetLinkStatus(self) -> DHWCtrl_NicGetLinkStatus:
        """
        Retrieve the Link status of the Network Interface.
        """
        return DHWCtrl_NicGetLinkStatus(self)
    @property
    def DHWCtrl_NicSend(self) -> DHWCtrl_NicSend:
        """
        Sends a frame via the Network Interface.
        """
        return DHWCtrl_NicSend(self)
    @property
    def DHWCtrl_NicReceive(self) -> DHWCtrl_NicReceive:
        """
        Receives a frame from the Network Interface.
        """
        return DHWCtrl_NicReceive(self)
    @property
    def DHWCtrl_NicSetMAC(self) -> DHWCtrl_NicSetMAC:
        """
        Set the MAC address of the Network Interface.
        """
        return DHWCtrl_NicSetMAC(self)
    @property
    def DHWCtrl_ApspiSetSpeed(self) -> DHWCtrl_ApspiSetSpeed:
        """
        Set the speed of SPI programming mode.
        """
        return DHWCtrl_ApspiSetSpeed(self)
    @property
    def DHWCtrl_ApspiEnable(self) -> DHWCtrl_ApspiEnable:
        """
        Enables/disables the SPI programming mode of a connected slave AVR.
        """
        return DHWCtrl_ApspiEnable(self)
    @property
    def DHWCtrl_ApspiSingleSend(self) -> DHWCtrl_ApspiSingleSend:
        """
        Send a single SPI programming instruction.
        """
        return DHWCtrl_ApspiSingleSend(self)
    @property
    def DHWCtrl_ApspiSingleRecv(self) -> DHWCtrl_ApspiSingleRecv:
        """
        Send a single SPI programming instruction and receive one data byte.
        """
        return DHWCtrl_ApspiSingleRecv(self)
    @property
    def DHWCtrl_ApspiAlternateSend(self) -> DHWCtrl_ApspiAlternateSend:
        """
        Send alternately SPI programming instructions. First CmdCodeA with address adr and the first byte in the data buffer, then CmdCodeB with the same address and the second byte in the buffer is sent. After that the address will be incremented. This is repeated as long as data bytes are in the buffer.
        """
        return DHWCtrl_ApspiAlternateSend(self)
    @property
    def DHWCtrl_ApspiAlternateRecv(self) -> DHWCtrl_ApspiAlternateRecv:
        """
        Send alternately SPI programming instructions and receive data bytes. Works similar to ApspiAlternateSend.
        """
        return DHWCtrl_ApspiAlternateRecv(self)
    @property
    def DHWCtrl_PdiEnable(self) -> DHWCtrl_PdiEnable:
        """
        Enables/disables the PDI programming mode of a connected target AVR.
        """
        return DHWCtrl_PdiEnable(self)
    @property
    def DHWCtrl_PdiEraseDevice(self) -> DHWCtrl_PdiEraseDevice:
        """
        Erases the target chip device.
        """
        return DHWCtrl_PdiEraseDevice(self)
    @property
    def DHWCtrl_PdiReadFlash(self) -> DHWCtrl_PdiReadFlash:
        """
        Read flash memory from target device.
        """
        return DHWCtrl_PdiReadFlash(self)
    @property
    def DHWCtrl_PdiEraseFlashPage(self) -> DHWCtrl_PdiEraseFlashPage:
        """
        Erase flash page.
        """
        return DHWCtrl_PdiEraseFlashPage(self)
    @property
    def DHWCtrl_PdiWriteFlashPage(self) -> DHWCtrl_PdiWriteFlashPage:
        """
        Write to internal flash page buffer.
        """
        return DHWCtrl_PdiWriteFlashPage(self)
    @property
    def DHWCtrl_PdiProgramFlashPage(self) -> DHWCtrl_PdiProgramFlashPage:
        """
        Program flash page. Page must be written with PdiWriteFlashPage before.
        """
        return DHWCtrl_PdiProgramFlashPage(self)
    @property
    def DHWCtrl_PdiReadEeprom(self) -> DHWCtrl_PdiReadEeprom:
        """
        Read eeprom memory from target device.
        """
        return DHWCtrl_PdiReadEeprom(self)
    @property
    def DHWCtrl_PdiProgramEepromPage(self) -> DHWCtrl_PdiProgramEepromPage:
        """
        Write an eeprom page to target device.
        """
        return DHWCtrl_PdiProgramEepromPage(self)
    @property
    def DHWCtrl_PdiReadFuses(self) -> DHWCtrl_PdiReadFuses:
        """
        Read fuse memory from target device.
        """
        return DHWCtrl_PdiReadFuses(self)
    @property
    def DHWCtrl_PdiWriteFuse(self) -> DHWCtrl_PdiWriteFuse:
        """
        Write a fuse byte to target device.
        """
        return DHWCtrl_PdiWriteFuse(self)
    @property
    def DHWCtrl_FlashGetPageSize(self) -> DHWCtrl_FlashGetPageSize:
        """
        Retrieves the page size of the program flash.
        """
        return DHWCtrl_FlashGetPageSize(self)
    @property
    def DHWCtrl_FlashErasePage(self) -> DHWCtrl_FlashErasePage:
        """
        Erases one or several consecutive program flash pages.
        """
        return DHWCtrl_FlashErasePage(self)
    @property
    def DHWCtrl_FlashRead(self) -> DHWCtrl_FlashRead:
        """
        Read data from program flash.
        """
        return DHWCtrl_FlashRead(self)
    @property
    def DHWCtrl_FlashWritePage(self) -> DHWCtrl_FlashWritePage:
        """
        Write to a temporary page buffer. Can be executed several times until the page buffer is filled.
        """
        return DHWCtrl_FlashWritePage(self)
    @property
    def DHWCtrl_FlashProgramPage(self) -> DHWCtrl_FlashProgramPage:
        """
        Program a page to program flash. The data has to be written to the temporary page buffer with FlashWritePage before.
        """
        return DHWCtrl_FlashProgramPage(self)
    @property
    def DHWCtrl_RegisterRead(self) -> DHWCtrl_RegisterRead:
        """
        Read processor register.
        """
        return DHWCtrl_RegisterRead(self)
    @property
    def DHWCtrl_RegisterWrite(self) -> DHWCtrl_RegisterWrite:
        """
        Write processor register.
        """
        return DHWCtrl_RegisterWrite(self)
    @property
    def DHWCtrl_AesWrapKey(self) -> DHWCtrl_AesWrapKey:
        """
        Wraps an AES key for secure storage
        """
        return DHWCtrl_AesWrapKey(self)
    @property
    def DHWCtrl_AesEncrypt(self) -> DHWCtrl_AesEncrypt:
        """
        Encrypts a block
        """
        return DHWCtrl_AesEncrypt(self)
    @property
    def DHWCtrl_AesDecrypt(self) -> DHWCtrl_AesDecrypt:
        """
        Decrypts a block
        """
        return DHWCtrl_AesDecrypt(self)
    @property
    def DHWCtrl_GetPlatformId2(self) -> DHWCtrl_GetPlatformId2:
        """
        This command retrieves the PlatformId2. A list of all supported HardwareComponents is returned.
        """
        return DHWCtrl_GetPlatformId2(self)
    @property
    def DHWCtrl_GetProdLoader(self) -> DHWCtrl_GetProdLoader:
        """
        Returns the baudrate Byte of the production-loader.
        """
        return DHWCtrl_GetProdLoader(self)
    @property
    def DHWCtrl_StartProdLoader(self) -> DHWCtrl_StartProdLoader:
        """
        Starts the production-loader.
        """
        return DHWCtrl_StartProdLoader(self)
    @property
    def DHWCtrl_Run(self) -> DHWCtrl_Run:
        """
        Executes a list of commands. The commands are stored sequentially in the buffer. Every command has as a header the command code and the length of the following parameters. Both are given in bytes. It is possible to execute every DHWCtrl command through this interface.
        """
        return DHWCtrl_Run(self)
    @property
    def DHWCtrl_GetStartupRun(self) -> DHWCtrl_GetStartupRun:
        """
        Returns the result of the execution of DHWCtrl-commands at the startup.
        """
        return DHWCtrl_GetStartupRun(self)
    @property
    def DHWCtrl_InitBgm(self) -> DHWCtrl_InitBgm:
        """
        Initializes the Bluetooth BGM12X chip.
        """
        return DHWCtrl_InitBgm(self)
    @property
    def DHWCtrl_BgmExec(self) -> DHWCtrl_BgmExec:
        """
        Execute a Bgm12X API command.
        """
        return DHWCtrl_BgmExec(self)
    @property
    def DHWCtrl_Sm4x00BootloaderStart(self) -> DHWCtrl_Sm4x00BootloaderStart:
        """
        Start SM4x00 Bootloader.
        """
        return DHWCtrl_Sm4x00BootloaderStart(self)
    @property
    def DHWCtrl_Sm4x00EraseFlash(self) -> DHWCtrl_Sm4x00EraseFlash:
        """
        Erase SM4x00 Flash. Must be issued directly after DHWCtrl.Sm4x00BootloaderStart. Erasing lasts about 20-30 seconds. Use DHWCtrl.Sm4x00WaitForFlashErase to find out when it has been finished.
        """
        return DHWCtrl_Sm4x00EraseFlash(self)
    @property
    def DHWCtrl_Sm4x00WaitForFlashErase(self) -> DHWCtrl_Sm4x00WaitForFlashErase:
        """
        Check if flash erasing has been finished.
        """
        return DHWCtrl_Sm4x00WaitForFlashErase(self)
    @property
    def DHWCtrl_Sm4x00ProgramBlock(self) -> DHWCtrl_Sm4x00ProgramBlock:
        """
        Program one 128 byte block of SM4x00 firmware.
        """
        return DHWCtrl_Sm4x00ProgramBlock(self)
    @property
    def DHWCtrl_BgmRead(self) -> DHWCtrl_BgmRead:
        """
        Read from Bgm12X.
        """
        return DHWCtrl_BgmRead(self)
    @property
    def DHWCtrl_Rc5180EepromRead(self) -> DHWCtrl_Rc5180EepromRead:
        """
        Reads EEPROM Data from RCxxx (PNxxx).
        """
        return DHWCtrl_Rc5180EepromRead(self)
    @property
    def DHWCtrl_Rc5180EepromWrite(self) -> DHWCtrl_Rc5180EepromWrite:
        """
        Writes EEPROM Data to the RCxxx (PNxxx).
        """
        return DHWCtrl_Rc5180EepromWrite(self)
__all__: list[str] = [
    "InternalCommands",
    "ASK_SecuraKeyRead",
    "ASK_GproxRead",
    "ASK_CotagRead",
    "CardEmu_GetMaxFrameSize",
    "CardEmu_StartEmu",
    "CardEmu_TransparentCmd",
    "CardEmu_GetExternalHfStatus",
    "CardEmu_StartNfc",
    "Dbg_ReadLogs",
    "Dbg_RunCmd",
    "EM_DecodeCfg",
    "EM_Read4100",
    "EM_Read4205",
    "EM_Write4205",
    "EM_Halt4205",
    "EM_Login4205",
    "EM_Protect4205",
    "EM_Read4469",
    "EM_Write4469",
    "EM_Halt4469",
    "EM_Login4469",
    "EM_Read4450",
    "Eth_GetMacAdr",
    "Eth_GetConnDevIP",
    "Eth_CreateRecoveryPoint",
    "Eth_DelRecoveryPoint",
    "Eth_GetNetworkStatus",
    "Eth_GetMIBCounters",
    "Eth_GetTcpConnectionStatus",
    "Eth_OpenTcpConnection",
    "Eth_CloseTcpConnection",
    "HID_IndalaRead",
    "HID_ProxRead",
    "HID_AwidRead",
    "HID_IoProxRead",
    "HID_Prox32Read",
    "HID_PyramidRead",
    "HID_IndalaSecureRead",
    "HID_IdteckRead",
    "Hitag_Request",
    "Hitag_Select",
    "Hitag_Halt",
    "Hitag_Read",
    "Hitag_Write",
    "Hitag_PersonaliseHtg",
    "I2c_SetSpeed",
    "I2c_Read",
    "I2c_Write",
    "I2c_TxRx",
    "Iso14a_RequestLegacy",
    "Iso14a_Anticoll",
    "Iso14a_SelectOnly",
    "Iso14a_TransparentCmdBitlen",
    "Iso14CE_ActivateCardAPDU",
    "Iso14CE_ExchangeCardAPDU",
    "Iso14CE_ExtendWaitingTime",
    "Iso14CE_GetExternalHfStatus",
    "Iso15_ReadBlock",
    "Iso15_WriteBlock",
    "Iso15_TransparentCmdLegacy",
    "Iso78_SelectSlot",
    "Iso78_OpenSamLegacy",
    "Iso78_CloseSamLegacy",
    "Iso78_ExchangeApduLegacy",
    "Legic_TransparentCommand4000",
    "Legic_TransparentCommand6000",
    "Lga_TransparentCommand",
    "Main_Bf2Upload",
    "Main_SwitchFW",
    "Main_MatchPlatformId2",
    "Main_IsFirmwareUpToDate",
    "Mce_Enable",
    "Mce_Request",
    "Mif_Request",
    "Mif_Anticoll",
    "Mif_Select",
    "Mif_Halt",
    "Pico_SetHfMode",
    "Pico_RequestAnticoll",
    "Pico_Select",
    "Pico_Halt",
    "Pico_SelectBookPage",
    "Pico_Authenticate",
    "Pico_Read",
    "Pico_Write",
    "Pki_PfsGenKey",
    "Pki_PfsAuthHostCert",
    "Pki_PfsAuthRdrCert",
    "Pki_Tunnel2",
    "Pki_GetX509Csr",
    "Pki_StoreX509Cert",
    "Pki_StoreX509RootCert",
    "QKey_Read",
    "Rtc_GetTime",
    "Rtc_SetTime",
    "Srix_Select",
    "Srix_Read",
    "Srix_Write",
    "Sys_GetPort",
    "Sys_SetPort",
    "Sys_CfgWriteTlvSector",
    "Sys_ConfigPort",
    "Sys_SetRegister",
    "Sys_GetRegister",
    "Sys_PowerDown",
    "Sys_SetCommParam",
    "Sys_GetPlatformId",
    "Sys_FactoryResetLegacy",
    "Sys_GetFwCrc",
    "TTF_ReadByteStream",
    "UsbHost_Enable",
    "UsbHost_IsConnected",
    "UsbHost_SetupPipes",
    "UsbHost_SetAddr",
    "UsbHost_Reset",
    "UsbHost_TransRawSetup",
    "UsbHost_TransSetupIn",
    "UsbHost_TransSetupOut",
    "UsbHost_TransIn",
    "UsbHost_TransOut",
    "UsbHost_Suspend",
    "UsbHost_Resume",
    "VHL_GetLegacyATR",
    "VHL_SetupMifare",
    "VHL_SetupLegic",
    "VHL_SetupISO15",
    "VHL_Format",
    "DHWCtrl_PortConfig",
    "DHWCtrl_PortGet",
    "DHWCtrl_PortSet",
    "DHWCtrl_PortWait",
    "DHWCtrl_GetResetCause",
    "DHWCtrl_APortMeasure",
    "DHWCtrl_SRAMTest",
    "DHWCtrl_SetBaudrate",
    "DHWCtrl_MirrorData",
    "DHWCtrl_DispEnable",
    "DHWCtrl_DispBacklight",
    "DHWCtrl_DispColor",
    "DHWCtrl_DispContrast",
    "DHWCtrl_DispBox",
    "DHWCtrl_Ser2Ctrl",
    "DHWCtrl_Ser2WriteRead",
    "DHWCtrl_Ser2Flush",
    "DHWCtrl_Delay1ms",
    "DHWCtrl_Delay10us",
    "DHWCtrl_PowermgrSuspend",
    "DHWCtrl_ScanMatrix",
    "DHWCtrl_GetReaderChipType",
    "DHWCtrl_SelectAntenna",
    "DHWCtrl_GetSamType",
    "DHWCtrl_HfAcquire",
    "DHWCtrl_EepromWrite",
    "DHWCtrl_DataflashGetSize",
    "DHWCtrl_DataflashErasePages",
    "DHWCtrl_DataflashRead",
    "DHWCtrl_DataflashWrite",
    "DHWCtrl_EepromRead",
    "DHWCtrl_SecurityAndConfigReset",
    "DHWCtrl_PulseGenerate",
    "DHWCtrl_InitSer2",
    "DHWCtrl_InitRtc",
    "DHWCtrl_InitLcdDrv",
    "DHWCtrl_InitRc",
    "DHWCtrl_InitMf",
    "DHWCtrl_InitIso14A",
    "DHWCtrl_InitIso14B",
    "DHWCtrl_InitIso15",
    "DHWCtrl_InitLg",
    "DHWCtrl_InitLga",
    "DHWCtrl_InitDf",
    "DHWCtrl_InitRc125",
    "DHWCtrl_InitCc",
    "DHWCtrl_InitUsbHost",
    "DHWCtrl_InitNic",
    "DHWCtrl_BohEnable",
    "DHWCtrl_NicEnable",
    "DHWCtrl_NicGetChipType",
    "DHWCtrl_NicGetLinkStatus",
    "DHWCtrl_NicSend",
    "DHWCtrl_NicReceive",
    "DHWCtrl_NicSetMAC",
    "DHWCtrl_ApspiSetSpeed",
    "DHWCtrl_ApspiEnable",
    "DHWCtrl_ApspiSingleSend",
    "DHWCtrl_ApspiSingleRecv",
    "DHWCtrl_ApspiAlternateSend",
    "DHWCtrl_ApspiAlternateRecv",
    "DHWCtrl_PdiEnable",
    "DHWCtrl_PdiEraseDevice",
    "DHWCtrl_PdiReadFlash",
    "DHWCtrl_PdiEraseFlashPage",
    "DHWCtrl_PdiWriteFlashPage",
    "DHWCtrl_PdiProgramFlashPage",
    "DHWCtrl_PdiReadEeprom",
    "DHWCtrl_PdiProgramEepromPage",
    "DHWCtrl_PdiReadFuses",
    "DHWCtrl_PdiWriteFuse",
    "DHWCtrl_FlashGetPageSize",
    "DHWCtrl_FlashErasePage",
    "DHWCtrl_FlashRead",
    "DHWCtrl_FlashWritePage",
    "DHWCtrl_FlashProgramPage",
    "DHWCtrl_RegisterRead",
    "DHWCtrl_RegisterWrite",
    "DHWCtrl_AesWrapKey",
    "DHWCtrl_AesEncrypt",
    "DHWCtrl_AesDecrypt",
    "DHWCtrl_GetPlatformId2",
    "DHWCtrl_GetProdLoader",
    "DHWCtrl_StartProdLoader",
    "DHWCtrl_Run",
    "DHWCtrl_GetStartupRun",
    "DHWCtrl_InitBgm",
    "DHWCtrl_BgmExec",
    "DHWCtrl_Sm4x00BootloaderStart",
    "DHWCtrl_Sm4x00EraseFlash",
    "DHWCtrl_Sm4x00WaitForFlashErase",
    "DHWCtrl_Sm4x00ProgramBlock",
    "DHWCtrl_BgmRead",
    "DHWCtrl_Rc5180EepromRead",
    "DHWCtrl_Rc5180EepromWrite",
]