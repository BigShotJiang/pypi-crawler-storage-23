
from io import BytesIO
from typing import Any, Optional, NamedTuple, Union, List, ClassVar, Tuple, Literal

from typing_extensions import Self

from ..generator_interface import safe_read_int_from_buffer, FrameProcessor, ConfigBase, ConfigValue, PayloadTooLongError, PayloadTooShortError, PayloadFormatError
from .._public.typedefs import *
from .typedefs import *
from .._public.configuration import PublicConfigAccessor
from .._public.protocols import BaltechScript
from .._public.protocols import BRP
from .._public.protocols import Template
class Scripts(ConfigBase):
    MasterKey: ClassVar[int] = 0x05
    MasterKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        self.process_frame(_send_buffer.getvalue())
class Scripts_Events(ConfigBase):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
class Scripts_Events_OnKeypressF(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x30
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 4
    def reset(self, OnKeypressF_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnKeypressF_ndx < 0 or OnKeypressF_ndx >= 4:
            raise IndexError(OnKeypressF_ndx)
        _send_buffer.write((48 + OnKeypressF_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, OnKeypressF_ndx: int, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnKeypressF_ndx < 0 or OnKeypressF_ndx >= 4:
            raise IndexError(OnKeypressF_ndx)
        _send_buffer.write((48 + OnKeypressF_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, OnKeypressF_ndx: int, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnKeypressF_ndx < 0 or OnKeypressF_ndx >= 4:
            raise IndexError(OnKeypressF_ndx)
        _send_buffer.write((48 + OnKeypressF_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, OnKeypressF_ndx: int, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(OnKeypressF_ndx=OnKeypressF_ndx, Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnKeypressEsc(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x34
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnKeypressClear(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x35
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'5')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'5')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'5')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnKeypressMenu(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x36
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'6')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'6')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'6')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnKeypressOk(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x37
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'7')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'7')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'7')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnKeypressStar(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x3A
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b':')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b':')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b':')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnKeypressSharp(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x3B
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b';')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b';')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b';')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnCustomEvent(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x60
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 3
    def reset(self, OnCustomEvent_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnCustomEvent_ndx < 0 or OnCustomEvent_ndx >= 3:
            raise IndexError(OnCustomEvent_ndx)
        _send_buffer.write((96 + OnCustomEvent_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, OnCustomEvent_ndx: int, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnCustomEvent_ndx < 0 or OnCustomEvent_ndx >= 3:
            raise IndexError(OnCustomEvent_ndx)
        _send_buffer.write((96 + OnCustomEvent_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, OnCustomEvent_ndx: int, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        if OnCustomEvent_ndx < 0 or OnCustomEvent_ndx >= 3:
            raise IndexError(OnCustomEvent_ndx)
        _send_buffer.write((96 + OnCustomEvent_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, OnCustomEvent_ndx: int, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(OnCustomEvent_ndx=OnCustomEvent_ndx, Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnNetworkBooted(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x90
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x90')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x90')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x90')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnLinkedNoPort(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x91
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x91')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x91')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x91')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnLinkedNetworkPort(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x92
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x92')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x92')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x92')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnLinkedDevicePort(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x93
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x93')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x93')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x93')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnLinkedAllPorts(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x94
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x94')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x94')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x94')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnWaitingForDHCP(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x95
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x95')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x95')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x95')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnSearchingForHost(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x96
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x96')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x96')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x96')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnUDPConnectFailure(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x97
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x97')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x97')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x97')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnHostConnectFailure(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x98
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x98')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x98')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x98')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnStaticIPFailure(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x99
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x99')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x99')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x99')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnHostFound(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x9A
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x9a')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x9a')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x9a')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnBleNoAlert(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0xA2
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\xa2')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\xa2')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\xa2')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnBleMildAlert(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0xA3
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\xa3')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\xa3')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\xa3')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Scripts_Events_OnBleHighAlert(ConfigValue):
    MasterKey: ClassVar[int] = 0x05
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0xA4
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\xa4')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> BaltechScript:
        _recv_buffer = BytesIO(frame)
        _Value = BaltechScript(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[BaltechScript] = None) -> Optional[BaltechScript]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\xa4')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[BaltechScript, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x05')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\xa4')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[BaltechScript, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device(ConfigBase):
    MasterKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
class Device_VhlSettings(ConfigBase):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x06
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        self.process_frame(_send_buffer.getvalue())
class Device_VhlSettings_ScanCardFamilies(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x06
    ValueKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> CardFamilies:
        _recv_buffer = BytesIO(frame)
        _Value_int = safe_read_int_from_buffer(_recv_buffer, 2)
        _LEGICPrime = bool((_Value_int >> 11) & 0b1)
        _BluetoothMce = bool((_Value_int >> 10) & 0b1)
        _Khz125Part2 = bool((_Value_int >> 9) & 0b1)
        _Srix = bool((_Value_int >> 8) & 0b1)
        _Khz125Part1 = bool((_Value_int >> 7) & 0b1)
        _Felica = bool((_Value_int >> 6) & 0b1)
        _IClass = bool((_Value_int >> 5) & 0b1)
        _IClassIso14B = bool((_Value_int >> 4) & 0b1)
        _Iso14443B = bool((_Value_int >> 3) & 0b1)
        _Iso15693 = bool((_Value_int >> 2) & 0b1)
        _Iso14443A = bool((_Value_int >> 0) & 0b1)
        _Value = CardFamilies(_LEGICPrime, _BluetoothMce, _Khz125Part2, _Srix, _Khz125Part1, _Felica, _IClass, _IClassIso14B, _Iso14443B, _Iso15693, _Iso14443A)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[CardFamilies] = None) -> Optional[CardFamilies]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x01')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[CardFamilies, CardFamilies_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x01')
        if isinstance(Value, dict):
            Value = CardFamilies(**Value)
        Value_int = 0
        Value_int |= (int(Value.LEGICPrime) & 0b1) << 11
        Value_int |= (int(Value.BluetoothMce) & 0b1) << 10
        Value_int |= (int(Value.Khz125Part2) & 0b1) << 9
        Value_int |= (int(Value.Srix) & 0b1) << 8
        Value_int |= (int(Value.Khz125Part1) & 0b1) << 7
        Value_int |= (int(Value.Felica) & 0b1) << 6
        Value_int |= (int(Value.IClass) & 0b1) << 5
        Value_int |= (int(Value.IClassIso14B) & 0b1) << 4
        Value_int |= (int(Value.Iso14443B) & 0b1) << 3
        Value_int |= (int(Value.Iso15693) & 0b1) << 2
        Value_int |= (int(Value.Iso14443A) & 0b1) << 0
        _send_buffer.write(Value_int.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[CardFamilies, CardFamilies_Dict]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_VhlSettings_ForceReselect(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x06
    ValueKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Device_VhlSettings_ForceReselect_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Device_VhlSettings_ForceReselect_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Device_VhlSettings_ForceReselect_Value] = None) -> Optional[Device_VhlSettings_ForceReselect_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x02')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Device_VhlSettings_ForceReselect_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x02')
        _send_buffer.write(Device_VhlSettings_ForceReselect_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Device_VhlSettings_ForceReselect_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_VhlSettings_DelayRequestATS(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x06
    ValueKey: ClassVar[int] = 0x03
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x03')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x03')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x03')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_VhlSettings_DelayPerformPPS(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x06
    ValueKey: ClassVar[int] = 0x04
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x04')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x04')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x04')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_VhlSettings_MaxBaudrateIso14443A(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x06
    ValueKey: ClassVar[int] = 0x10
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x10')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> MaxBaudrateIso14443:
        _recv_buffer = BytesIO(frame)
        _Value = MaxBaudrateIso14443_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[MaxBaudrateIso14443] = None) -> Optional[MaxBaudrateIso14443]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x10')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: MaxBaudrateIso14443) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x10')
        _send_buffer.write(MaxBaudrateIso14443_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: MaxBaudrateIso14443) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_VhlSettings_MaxBaudrateIso14443B(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x06
    ValueKey: ClassVar[int] = 0x20
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> MaxBaudrateIso14443:
        _recv_buffer = BytesIO(frame)
        _Value = MaxBaudrateIso14443_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[MaxBaudrateIso14443] = None) -> Optional[MaxBaudrateIso14443]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: MaxBaudrateIso14443) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(MaxBaudrateIso14443_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: MaxBaudrateIso14443) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_VhlSettings125Khz(ConfigBase):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x42
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        self.process_frame(_send_buffer.getvalue())
class Device_VhlSettings125Khz_ScanCardTypes(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x00
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x00')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> CardTypes125KhzPart1:
        _recv_buffer = BytesIO(frame)
        _Value_int = safe_read_int_from_buffer(_recv_buffer, 2)
        _TTF = bool((_Value_int >> 15) & 0b1)
        _Hitag2B = bool((_Value_int >> 14) & 0b1)
        _Hitag2M = bool((_Value_int >> 13) & 0b1)
        _Hitag1S = bool((_Value_int >> 12) & 0b1)
        _HidIoprox = bool((_Value_int >> 11) & 0b1)
        _HidProx = bool((_Value_int >> 10) & 0b1)
        _HidAwid = bool((_Value_int >> 9) & 0b1)
        _HidIndala = bool((_Value_int >> 8) & 0b1)
        _Quadrakey = bool((_Value_int >> 7) & 0b1)
        _Keri = bool((_Value_int >> 6) & 0b1)
        _HidProx32 = bool((_Value_int >> 5) & 0b1)
        _Pyramid = bool((_Value_int >> 4) & 0b1)
        _EM4450 = bool((_Value_int >> 3) & 0b1)
        _EM4100 = bool((_Value_int >> 1) & 0b1)
        _EM4205 = bool((_Value_int >> 0) & 0b1)
        _Value = CardTypes125KhzPart1(_TTF, _Hitag2B, _Hitag2M, _Hitag1S, _HidIoprox, _HidProx, _HidAwid, _HidIndala, _Quadrakey, _Keri, _HidProx32, _Pyramid, _EM4450, _EM4100, _EM4205)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[CardTypes125KhzPart1] = None) -> Optional[CardTypes125KhzPart1]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x00')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[CardTypes125KhzPart1, CardTypes125KhzPart1_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x00')
        if isinstance(Value, dict):
            Value = CardTypes125KhzPart1(**Value)
        Value_int = 0
        Value_int |= (int(Value.TTF) & 0b1) << 15
        Value_int |= (int(Value.Hitag2B) & 0b1) << 14
        Value_int |= (int(Value.Hitag2M) & 0b1) << 13
        Value_int |= (int(Value.Hitag1S) & 0b1) << 12
        Value_int |= (int(Value.HidIoprox) & 0b1) << 11
        Value_int |= (int(Value.HidProx) & 0b1) << 10
        Value_int |= (int(Value.HidAwid) & 0b1) << 9
        Value_int |= (int(Value.HidIndala) & 0b1) << 8
        Value_int |= (int(Value.Quadrakey) & 0b1) << 7
        Value_int |= (int(Value.Keri) & 0b1) << 6
        Value_int |= (int(Value.HidProx32) & 0b1) << 5
        Value_int |= (int(Value.Pyramid) & 0b1) << 4
        Value_int |= (int(Value.EM4450) & 0b1) << 3
        Value_int |= (int(Value.EM4100) & 0b1) << 1
        Value_int |= (int(Value.EM4205) & 0b1) << 0
        _send_buffer.write(Value_int.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[CardTypes125KhzPart1, CardTypes125KhzPart1_Dict]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_VhlSettings125Khz_ModulationType(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Device_VhlSettings125Khz_ModulationType_TTFMod:
        _recv_buffer = BytesIO(frame)
        _TTFMod = Device_VhlSettings125Khz_ModulationType_TTFMod_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _TTFMod
    def get(self, default: Optional[Device_VhlSettings125Khz_ModulationType_TTFMod] = None) -> Optional[Device_VhlSettings125Khz_ModulationType_TTFMod]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x01')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, TTFMod: Device_VhlSettings125Khz_ModulationType_TTFMod) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x01')
        _send_buffer.write(Device_VhlSettings125Khz_ModulationType_TTFMod_Parser.as_value(TTFMod).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, TTFMod: Device_VhlSettings125Khz_ModulationType_TTFMod) -> None:
        frame = self.build_frame(TTFMod=TTFMod)
        self.process_frame(frame)
class Device_VhlSettings125Khz_Baud(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Device_VhlSettings125Khz_Baud_Baud:
        _recv_buffer = BytesIO(frame)
        _Baud = Device_VhlSettings125Khz_Baud_Baud_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Baud
    def get(self, default: Optional[Device_VhlSettings125Khz_Baud_Baud] = None) -> Optional[Device_VhlSettings125Khz_Baud_Baud]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x02')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Baud: Device_VhlSettings125Khz_Baud_Baud) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x02')
        _send_buffer.write(Device_VhlSettings125Khz_Baud_Baud_Parser.as_value(Baud).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Baud: Device_VhlSettings125Khz_Baud_Baud) -> None:
        frame = self.build_frame(Baud=Baud)
        self.process_frame(frame)
class Device_VhlSettings125Khz_TTFHeaderLength(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x03
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x03')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x03')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x03')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_VhlSettings125Khz_TTFHeader(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x04
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x04')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> bytes:
        _recv_buffer = BytesIO(frame)
        _Value = _recv_buffer.read(-1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[bytes] = None) -> Optional[bytes]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x04')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: bytes) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x04')
        _send_buffer.write(Value)
        return _send_buffer.getvalue()
    def __call__(self, Value: bytes) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_VhlSettings125Khz_TTFDataLength(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x05
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x05')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x05')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x05')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_VhlSettings125Khz_TTFOkCounter(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x06
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x06')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x06')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x06')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_VhlSettings125Khz_IndaspDecode(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x07
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x07')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Template:
        _recv_buffer = BytesIO(frame)
        _Value = Template(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Template] = None) -> Optional[Template]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x07')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[Template, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x07')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[Template, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_VhlSettings125Khz_IndaspParityCheck(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x08
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x08')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Device_VhlSettings125Khz_IndaspParityCheck_ParityDisable:
        _recv_buffer = BytesIO(frame)
        _ParityDisable = Device_VhlSettings125Khz_IndaspParityCheck_ParityDisable_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _ParityDisable
    def get(self, default: Optional[Device_VhlSettings125Khz_IndaspParityCheck_ParityDisable] = None) -> Optional[Device_VhlSettings125Khz_IndaspParityCheck_ParityDisable]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x08')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, ParityDisable: Device_VhlSettings125Khz_IndaspParityCheck_ParityDisable) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x08')
        _send_buffer.write(Device_VhlSettings125Khz_IndaspParityCheck_ParityDisable_Parser.as_value(ParityDisable).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, ParityDisable: Device_VhlSettings125Khz_IndaspParityCheck_ParityDisable) -> None:
        frame = self.build_frame(ParityDisable=ParityDisable)
        self.process_frame(frame)
class Device_VhlSettings125Khz_IndaspOkCounter(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x09
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\t')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _OkCounter = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _OkCounter
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\t')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, OkCounter: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\t')
        _send_buffer.write(OkCounter.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, OkCounter: int) -> None:
        frame = self.build_frame(OkCounter=OkCounter)
        self.process_frame(frame)
class Device_VhlSettings125Khz_AwidOkCounter(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x0A
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\n')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _OkCounter = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _OkCounter
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\n')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, OkCounter: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\n')
        _send_buffer.write(OkCounter.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, OkCounter: int) -> None:
        frame = self.build_frame(OkCounter=OkCounter)
        self.process_frame(frame)
class Device_VhlSettings125Khz_HidProxOkCounter(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x0B
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x0b')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _OkCounter = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _OkCounter
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x0b')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, OkCounter: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x0b')
        _send_buffer.write(OkCounter.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, OkCounter: int) -> None:
        frame = self.build_frame(OkCounter=OkCounter)
        self.process_frame(frame)
class Device_Boot(ConfigBase):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
class Device_Boot_ConfigCardState(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x60
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'`')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Device_Boot_ConfigCardState_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Device_Boot_ConfigCardState_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Device_Boot_ConfigCardState_Value] = None) -> Optional[Device_Boot_ConfigCardState_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'`')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Device_Boot_ConfigCardState_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'`')
        _send_buffer.write(Device_Boot_ConfigCardState_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Device_Boot_ConfigCardState_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Boot_LegicAdvantInitialization(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x04
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x04')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Device_Boot_LegicAdvantInitialization_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Device_Boot_LegicAdvantInitialization_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Device_Boot_LegicAdvantInitialization_Value] = None) -> Optional[Device_Boot_LegicAdvantInitialization_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x04')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Device_Boot_LegicAdvantInitialization_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x04')
        _send_buffer.write(Device_Boot_LegicAdvantInitialization_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Device_Boot_LegicAdvantInitialization_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run(ConfigBase):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
class Device_Run_DeviceName(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x08
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_ProjectName(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x09
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\t')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\t')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\t')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_CardReadFailureLogging(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x16
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x16')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Device_Run_CardReadFailureLogging_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Device_Run_CardReadFailureLogging_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Device_Run_CardReadFailureLogging_Value] = None) -> Optional[Device_Run_CardReadFailureLogging_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x16')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Device_Run_CardReadFailureLogging_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x16')
        _send_buffer.write(Device_Run_CardReadFailureLogging_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Device_Run_CardReadFailureLogging_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_FirstVhlRc500Key(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x40
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'@')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'@')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'@')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_BusAdressByBACLegacy(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x10
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x10')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x10')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x10')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_ConfigCardMifareKeyBackup(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0xC1
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\xc1')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\xc1')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\xc1')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_CustomerKeyBackup(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0xC5
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\xc5')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\xc5')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\xc5')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_ConfigCardDesfireKeyBackup(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0xCF
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\xcf')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\xcf')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\xcf')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Run_UsbSuspendMode(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x48
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'H')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Device_Run_UsbSuspendMode_SuspendMode:
        _recv_buffer = BytesIO(frame)
        _SuspendMode = Device_Run_UsbSuspendMode_SuspendMode_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _SuspendMode
    def get(self, default: Optional[Device_Run_UsbSuspendMode_SuspendMode] = None) -> Optional[Device_Run_UsbSuspendMode_SuspendMode]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'H')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, SuspendMode: Device_Run_UsbSuspendMode_SuspendMode) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'H')
        _send_buffer.write(Device_Run_UsbSuspendMode_SuspendMode_Parser.as_value(SuspendMode).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, SuspendMode: Device_Run_UsbSuspendMode_SuspendMode) -> None:
        frame = self.build_frame(SuspendMode=SuspendMode)
        self.process_frame(frame)
class Device_Rgb(ConfigBase):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x0A
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\n')
        self.process_frame(_send_buffer.getvalue())
class Device_Rgb_MaximizeIntensity(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x0A
    ValueKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\n')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Device_Rgb_MaximizeIntensity_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Device_Rgb_MaximizeIntensity_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Device_Rgb_MaximizeIntensity_Value] = None) -> Optional[Device_Rgb_MaximizeIntensity_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\n')
        _send_buffer.write(b'\x01')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Device_Rgb_MaximizeIntensity_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\n')
        _send_buffer.write(b'\x01')
        _send_buffer.write(Device_Rgb_MaximizeIntensity_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Device_Rgb_MaximizeIntensity_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_CryptoKey(ConfigBase):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x30
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'0')
        self.process_frame(_send_buffer.getvalue())
class Device_CryptoKey_Entry(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x30
    ValueKey: ClassVar[int] = 0x80
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 64
    def reset(self, Entry_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'0')
        if Entry_ndx < 0 or Entry_ndx >= 64:
            raise IndexError(Entry_ndx)
        _send_buffer.write((128 + Entry_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Device_CryptoKey_Entry_Result:
        _recv_buffer = BytesIO(frame)
        _KeySettings_int = safe_read_int_from_buffer(_recv_buffer, 1)
        _IsVersion = bool((_KeySettings_int >> 7) & 0b1)
        _IsDivInfo = bool((_KeySettings_int >> 6) & 0b1)
        _IsDivInfoVhl = bool((_KeySettings_int >> 5) & 0b1)
        _DenyFormat = bool((_KeySettings_int >> 2) & 0b1)
        _DenyWrite = bool((_KeySettings_int >> 1) & 0b1)
        _DenyRead = bool((_KeySettings_int >> 0) & 0b1)
        _KeySettings = KeyAccessRights_KeySettings(_IsVersion, _IsDivInfo, _IsDivInfoVhl, _DenyFormat, _DenyWrite, _DenyRead)
        if _IsVersion:
            _Version = safe_read_int_from_buffer(_recv_buffer, 1)
        else:
            _Version = None
        if _IsDivInfo:
            _DiversificationMode = KeyAccessRights_DiversificationMode_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
            _DivIdx = safe_read_int_from_buffer(_recv_buffer, 1)
        else:
            _DiversificationMode = None
            _DivIdx = None
        _AccessRights = KeyAccessRights(_KeySettings, _Version, _DiversificationMode, _DivIdx)
        _Algorithm = CryptoAlgorithm_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _Key_bytes = _recv_buffer.read(-1)
        _Key = _Key_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Device_CryptoKey_Entry_Result(_AccessRights, _Algorithm, _Key)
    def get(self, Entry_ndx: int, default: Optional[Device_CryptoKey_Entry_Result] = None) -> Optional[Device_CryptoKey_Entry_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'0')
        if Entry_ndx < 0 or Entry_ndx >= 64:
            raise IndexError(Entry_ndx)
        _send_buffer.write((128 + Entry_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Entry_ndx: int, AccessRights: Union[KeyAccessRights, KeyAccessRights_Dict], Algorithm: CryptoAlgorithm, Key: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'0')
        if Entry_ndx < 0 or Entry_ndx >= 64:
            raise IndexError(Entry_ndx)
        _send_buffer.write((128 + Entry_ndx).to_bytes(1, byteorder='big'))
        if isinstance(AccessRights, dict):
            AccessRights = KeyAccessRights(**AccessRights)
        _KeySettings, _Version, _DiversificationMode, _DivIdx = AccessRights
        if isinstance(_KeySettings, dict):
            _KeySettings = KeyAccessRights_KeySettings(**_KeySettings)
        _KeySettings_int = 0
        _KeySettings_int |= (int(_KeySettings.IsVersion) & 0b1) << 7
        _KeySettings_int |= (int(_KeySettings.IsDivInfo) & 0b1) << 6
        _KeySettings_int |= (int(_KeySettings.IsDivInfoVhl) & 0b1) << 5
        _KeySettings_int |= (int(_KeySettings.DenyFormat) & 0b1) << 2
        _KeySettings_int |= (int(_KeySettings.DenyWrite) & 0b1) << 1
        _KeySettings_int |= (int(_KeySettings.DenyRead) & 0b1) << 0
        _send_buffer.write(_KeySettings_int.to_bytes(length=1, byteorder='big'))
        if _KeySettings.IsVersion:
            if _Version is None:
                raise TypeError("missing a required argument: '_Version'")
            _send_buffer.write(_Version.to_bytes(length=1, byteorder='big'))
        if _KeySettings.IsDivInfo:
            if _DiversificationMode is None:
                raise TypeError("missing a required argument: '_DiversificationMode'")
            if _DivIdx is None:
                raise TypeError("missing a required argument: '_DivIdx'")
            _send_buffer.write(KeyAccessRights_DiversificationMode_Parser.as_value(_DiversificationMode).to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_DivIdx.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(CryptoAlgorithm_Parser.as_value(Algorithm).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(Key.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Entry_ndx: int, AccessRights: Union[KeyAccessRights, KeyAccessRights_Dict], Algorithm: CryptoAlgorithm, Key: str) -> None:
        frame = self.build_frame(Entry_ndx=Entry_ndx, AccessRights=AccessRights, Algorithm=Algorithm, Key=Key)
        self.process_frame(frame)
class Device_MifareClassicKey(ConfigBase):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x31
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'1')
        self.process_frame(_send_buffer.getvalue())
class Device_MifareClassicKey_Entry(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x31
    ValueKey: ClassVar[int] = 0x80
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 32
    def reset(self, Entry_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'1')
        if Entry_ndx < 0 or Entry_ndx >= 32:
            raise IndexError(Entry_ndx)
        _send_buffer.write((128 + Entry_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(6)
        _Value = _Value_bytes.decode('ascii')
        if len(_Value) != 6:
            raise PayloadTooShortError(6 - len(_Value))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, Entry_ndx: int, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'1')
        if Entry_ndx < 0 or Entry_ndx >= 32:
            raise IndexError(Entry_ndx)
        _send_buffer.write((128 + Entry_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Entry_ndx: int, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'1')
        if Entry_ndx < 0 or Entry_ndx >= 32:
            raise IndexError(Entry_ndx)
        _send_buffer.write((128 + Entry_ndx).to_bytes(1, byteorder='big'))
        if len(Value) != 6:
            raise ValueError(Value)
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Entry_ndx: int, Value: str) -> None:
        frame = self.build_frame(Entry_ndx=Entry_ndx, Value=Value)
        self.process_frame(frame)
class Device_HostSecurity(ConfigBase):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x08
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        self.process_frame(_send_buffer.getvalue())
class Device_HostSecurity_PrivateKey(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x08
    ValueKey: ClassVar[int] = 0x85
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x85')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x85')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x85')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_HostSecurity_PublicKey(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x08
    ValueKey: ClassVar[int] = 0x06
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x06')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x06')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x06')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_HostSecurity_HostRootCertSubjectName(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x08
    ValueKey: ClassVar[int] = 0x10
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 4
    def reset(self, HostRootCertSubjectName_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if HostRootCertSubjectName_ndx < 0 or HostRootCertSubjectName_ndx >= 4:
            raise IndexError(HostRootCertSubjectName_ndx)
        _send_buffer.write((16 + HostRootCertSubjectName_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, HostRootCertSubjectName_ndx: int, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if HostRootCertSubjectName_ndx < 0 or HostRootCertSubjectName_ndx >= 4:
            raise IndexError(HostRootCertSubjectName_ndx)
        _send_buffer.write((16 + HostRootCertSubjectName_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, HostRootCertSubjectName_ndx: int, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if HostRootCertSubjectName_ndx < 0 or HostRootCertSubjectName_ndx >= 4:
            raise IndexError(HostRootCertSubjectName_ndx)
        _send_buffer.write((16 + HostRootCertSubjectName_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, HostRootCertSubjectName_ndx: int, Value: str) -> None:
        frame = self.build_frame(HostRootCertSubjectName_ndx=HostRootCertSubjectName_ndx, Value=Value)
        self.process_frame(frame)
class Device_HostSecurity_HostRootCertPubKey(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x08
    ValueKey: ClassVar[int] = 0x14
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 4
    def reset(self, HostRootCertPubKey_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if HostRootCertPubKey_ndx < 0 or HostRootCertPubKey_ndx >= 4:
            raise IndexError(HostRootCertPubKey_ndx)
        _send_buffer.write((20 + HostRootCertPubKey_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, HostRootCertPubKey_ndx: int, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if HostRootCertPubKey_ndx < 0 or HostRootCertPubKey_ndx >= 4:
            raise IndexError(HostRootCertPubKey_ndx)
        _send_buffer.write((20 + HostRootCertPubKey_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, HostRootCertPubKey_ndx: int, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if HostRootCertPubKey_ndx < 0 or HostRootCertPubKey_ndx >= 4:
            raise IndexError(HostRootCertPubKey_ndx)
        _send_buffer.write((20 + HostRootCertPubKey_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, HostRootCertPubKey_ndx: int, Value: str) -> None:
        frame = self.build_frame(HostRootCertPubKey_ndx=HostRootCertPubKey_ndx, Value=Value)
        self.process_frame(frame)
class Device_HostSecurity_HostRootCertSnr(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x08
    ValueKey: ClassVar[int] = 0x18
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 4
    def reset(self, HostRootCertSnr_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if HostRootCertSnr_ndx < 0 or HostRootCertSnr_ndx >= 4:
            raise IndexError(HostRootCertSnr_ndx)
        _send_buffer.write((24 + HostRootCertSnr_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, HostRootCertSnr_ndx: int, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if HostRootCertSnr_ndx < 0 or HostRootCertSnr_ndx >= 4:
            raise IndexError(HostRootCertSnr_ndx)
        _send_buffer.write((24 + HostRootCertSnr_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, HostRootCertSnr_ndx: int, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if HostRootCertSnr_ndx < 0 or HostRootCertSnr_ndx >= 4:
            raise IndexError(HostRootCertSnr_ndx)
        _send_buffer.write((24 + HostRootCertSnr_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, HostRootCertSnr_ndx: int, Value: str) -> None:
        frame = self.build_frame(HostRootCertSnr_ndx=HostRootCertSnr_ndx, Value=Value)
        self.process_frame(frame)
class Device_HostSecurity_ReaderCertSnr(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x08
    ValueKey: ClassVar[int] = 0x20
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 4
    def reset(self, ReaderCertSnr_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if ReaderCertSnr_ndx < 0 or ReaderCertSnr_ndx >= 4:
            raise IndexError(ReaderCertSnr_ndx)
        _send_buffer.write((32 + ReaderCertSnr_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, ReaderCertSnr_ndx: int, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if ReaderCertSnr_ndx < 0 or ReaderCertSnr_ndx >= 4:
            raise IndexError(ReaderCertSnr_ndx)
        _send_buffer.write((32 + ReaderCertSnr_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, ReaderCertSnr_ndx: int, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if ReaderCertSnr_ndx < 0 or ReaderCertSnr_ndx >= 4:
            raise IndexError(ReaderCertSnr_ndx)
        _send_buffer.write((32 + ReaderCertSnr_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, ReaderCertSnr_ndx: int, Value: str) -> None:
        frame = self.build_frame(ReaderCertSnr_ndx=ReaderCertSnr_ndx, Value=Value)
        self.process_frame(frame)
class Device_HostSecurity_ReaderCertIssuer(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x08
    ValueKey: ClassVar[int] = 0x24
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 4
    def reset(self, ReaderCertIssuer_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if ReaderCertIssuer_ndx < 0 or ReaderCertIssuer_ndx >= 4:
            raise IndexError(ReaderCertIssuer_ndx)
        _send_buffer.write((36 + ReaderCertIssuer_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, ReaderCertIssuer_ndx: int, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if ReaderCertIssuer_ndx < 0 or ReaderCertIssuer_ndx >= 4:
            raise IndexError(ReaderCertIssuer_ndx)
        _send_buffer.write((36 + ReaderCertIssuer_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, ReaderCertIssuer_ndx: int, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if ReaderCertIssuer_ndx < 0 or ReaderCertIssuer_ndx >= 4:
            raise IndexError(ReaderCertIssuer_ndx)
        _send_buffer.write((36 + ReaderCertIssuer_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, ReaderCertIssuer_ndx: int, Value: str) -> None:
        frame = self.build_frame(ReaderCertIssuer_ndx=ReaderCertIssuer_ndx, Value=Value)
        self.process_frame(frame)
class Device_HostSecurity_ReaderCertValidity(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x08
    ValueKey: ClassVar[int] = 0x28
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 4
    def reset(self, ReaderCertValidity_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if ReaderCertValidity_ndx < 0 or ReaderCertValidity_ndx >= 4:
            raise IndexError(ReaderCertValidity_ndx)
        _send_buffer.write((40 + ReaderCertValidity_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, ReaderCertValidity_ndx: int, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if ReaderCertValidity_ndx < 0 or ReaderCertValidity_ndx >= 4:
            raise IndexError(ReaderCertValidity_ndx)
        _send_buffer.write((40 + ReaderCertValidity_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, ReaderCertValidity_ndx: int, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if ReaderCertValidity_ndx < 0 or ReaderCertValidity_ndx >= 4:
            raise IndexError(ReaderCertValidity_ndx)
        _send_buffer.write((40 + ReaderCertValidity_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, ReaderCertValidity_ndx: int, Value: str) -> None:
        frame = self.build_frame(ReaderCertValidity_ndx=ReaderCertValidity_ndx, Value=Value)
        self.process_frame(frame)
class Device_HostSecurity_ReaderCertSignature(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x08
    ValueKey: ClassVar[int] = 0x2C
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 4
    def reset(self, ReaderCertSignature_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if ReaderCertSignature_ndx < 0 or ReaderCertSignature_ndx >= 4:
            raise IndexError(ReaderCertSignature_ndx)
        _send_buffer.write((44 + ReaderCertSignature_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, ReaderCertSignature_ndx: int, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if ReaderCertSignature_ndx < 0 or ReaderCertSignature_ndx >= 4:
            raise IndexError(ReaderCertSignature_ndx)
        _send_buffer.write((44 + ReaderCertSignature_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, ReaderCertSignature_ndx: int, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if ReaderCertSignature_ndx < 0 or ReaderCertSignature_ndx >= 4:
            raise IndexError(ReaderCertSignature_ndx)
        _send_buffer.write((44 + ReaderCertSignature_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, ReaderCertSignature_ndx: int, Value: str) -> None:
        frame = self.build_frame(ReaderCertSignature_ndx=ReaderCertSignature_ndx, Value=Value)
        self.process_frame(frame)
class Device_HostSecurity_AccessConditionMaskInternal(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x08
    ValueKey: ClassVar[int] = 0xC0
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 4
    def reset(self, AccessConditionMaskInternal_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if AccessConditionMaskInternal_ndx < 0 or AccessConditionMaskInternal_ndx >= 4:
            raise IndexError(AccessConditionMaskInternal_ndx)
        _send_buffer.write((192 + AccessConditionMaskInternal_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> HostSecurityAccessConditionBits:
        _recv_buffer = BytesIO(frame)
        _Value_int = safe_read_int_from_buffer(_recv_buffer, 4)
        _HostToHostAccess = bool((_Value_int >> 28) & 0b1)
        _AutoreadAccess = bool((_Value_int >> 27) & 0b1)
        _CryptoAccess = bool((_Value_int >> 26) & 0b1)
        _Bf2Upload = bool((_Value_int >> 25) & 0b1)
        _ExtendedAccess = bool((_Value_int >> 24) & 0b1)
        _FlashFileSystemWrite = bool((_Value_int >> 23) & 0b1)
        _FlashFileSystemRead = bool((_Value_int >> 22) & 0b1)
        _RtcWrite = bool((_Value_int >> 21) & 0b1)
        _VhlExchangeapdu = bool((_Value_int >> 20) & 0b1)
        _VhlFormat = bool((_Value_int >> 19) & 0b1)
        _VhlWrite = bool((_Value_int >> 18) & 0b1)
        _VhlRead = bool((_Value_int >> 17) & 0b1)
        _VhlSelect = bool((_Value_int >> 16) & 0b1)
        _ExtSamAccess = bool((_Value_int >> 15) & 0b1)
        _HfLowlevelAccess = bool((_Value_int >> 14) & 0b1)
        _GuiAccess = bool((_Value_int >> 13) & 0b1)
        _IoPortWrite = bool((_Value_int >> 12) & 0b1)
        _IoPortRead = bool((_Value_int >> 11) & 0b1)
        _ConfigReset = bool((_Value_int >> 10) & 0b1)
        _ConfigWrite = bool((_Value_int >> 9) & 0b1)
        _ConfigRead = bool((_Value_int >> 8) & 0b1)
        _SysReset = bool((_Value_int >> 7) & 0b1)
        _SetAccessConditionMask2 = bool((_Value_int >> 6) & 0b1)
        _SetAccessConditionMask1 = bool((_Value_int >> 5) & 0b1)
        _SetAccessConditionMask0 = bool((_Value_int >> 4) & 0b1)
        _SetKey3 = bool((_Value_int >> 3) & 0b1)
        _SetKey2 = bool((_Value_int >> 2) & 0b1)
        _SetKey1 = bool((_Value_int >> 1) & 0b1)
        _FactoryReset = bool((_Value_int >> 0) & 0b1)
        _Value = HostSecurityAccessConditionBits(_HostToHostAccess, _AutoreadAccess, _CryptoAccess, _Bf2Upload, _ExtendedAccess, _FlashFileSystemWrite, _FlashFileSystemRead, _RtcWrite, _VhlExchangeapdu, _VhlFormat, _VhlWrite, _VhlRead, _VhlSelect, _ExtSamAccess, _HfLowlevelAccess, _GuiAccess, _IoPortWrite, _IoPortRead, _ConfigReset, _ConfigWrite, _ConfigRead, _SysReset, _SetAccessConditionMask2, _SetAccessConditionMask1, _SetAccessConditionMask0, _SetKey3, _SetKey2, _SetKey1, _FactoryReset)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, AccessConditionMaskInternal_ndx: int, default: Optional[HostSecurityAccessConditionBits] = None) -> Optional[HostSecurityAccessConditionBits]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if AccessConditionMaskInternal_ndx < 0 or AccessConditionMaskInternal_ndx >= 4:
            raise IndexError(AccessConditionMaskInternal_ndx)
        _send_buffer.write((192 + AccessConditionMaskInternal_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, AccessConditionMaskInternal_ndx: int, Value: Union[HostSecurityAccessConditionBits, HostSecurityAccessConditionBits_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if AccessConditionMaskInternal_ndx < 0 or AccessConditionMaskInternal_ndx >= 4:
            raise IndexError(AccessConditionMaskInternal_ndx)
        _send_buffer.write((192 + AccessConditionMaskInternal_ndx).to_bytes(1, byteorder='big'))
        if isinstance(Value, dict):
            Value = HostSecurityAccessConditionBits(**Value)
        Value_int = 0
        Value_int |= (int(Value.HostToHostAccess) & 0b1) << 28
        Value_int |= (int(Value.AutoreadAccess) & 0b1) << 27
        Value_int |= (int(Value.CryptoAccess) & 0b1) << 26
        Value_int |= (int(Value.Bf2Upload) & 0b1) << 25
        Value_int |= (int(Value.ExtendedAccess) & 0b1) << 24
        Value_int |= (int(Value.FlashFileSystemWrite) & 0b1) << 23
        Value_int |= (int(Value.FlashFileSystemRead) & 0b1) << 22
        Value_int |= (int(Value.RtcWrite) & 0b1) << 21
        Value_int |= (int(Value.VhlExchangeapdu) & 0b1) << 20
        Value_int |= (int(Value.VhlFormat) & 0b1) << 19
        Value_int |= (int(Value.VhlWrite) & 0b1) << 18
        Value_int |= (int(Value.VhlRead) & 0b1) << 17
        Value_int |= (int(Value.VhlSelect) & 0b1) << 16
        Value_int |= (int(Value.ExtSamAccess) & 0b1) << 15
        Value_int |= (int(Value.HfLowlevelAccess) & 0b1) << 14
        Value_int |= (int(Value.GuiAccess) & 0b1) << 13
        Value_int |= (int(Value.IoPortWrite) & 0b1) << 12
        Value_int |= (int(Value.IoPortRead) & 0b1) << 11
        Value_int |= (int(Value.ConfigReset) & 0b1) << 10
        Value_int |= (int(Value.ConfigWrite) & 0b1) << 9
        Value_int |= (int(Value.ConfigRead) & 0b1) << 8
        Value_int |= (int(Value.SysReset) & 0b1) << 7
        Value_int |= (int(Value.SetAccessConditionMask2) & 0b1) << 6
        Value_int |= (int(Value.SetAccessConditionMask1) & 0b1) << 5
        Value_int |= (int(Value.SetAccessConditionMask0) & 0b1) << 4
        Value_int |= (int(Value.SetKey3) & 0b1) << 3
        Value_int |= (int(Value.SetKey2) & 0b1) << 2
        Value_int |= (int(Value.SetKey1) & 0b1) << 1
        Value_int |= (int(Value.FactoryReset) & 0b1) << 0
        _send_buffer.write(Value_int.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, AccessConditionMaskInternal_ndx: int, Value: Union[HostSecurityAccessConditionBits, HostSecurityAccessConditionBits_Dict]) -> None:
        frame = self.build_frame(AccessConditionMaskInternal_ndx=AccessConditionMaskInternal_ndx, Value=Value)
        self.process_frame(frame)
class Device_HostSecurity_KeyInternal(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x08
    ValueKey: ClassVar[int] = 0xD0
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 4
    def reset(self, KeyInternal_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if KeyInternal_ndx < 0 or KeyInternal_ndx >= 4:
            raise IndexError(KeyInternal_ndx)
        _send_buffer.write((208 + KeyInternal_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Device_HostSecurity_KeyInternal_Result:
        _recv_buffer = BytesIO(frame)
        _AuthenticationMode_int = safe_read_int_from_buffer(_recv_buffer, 1)
        _RequireContinuousIv = bool((_AuthenticationMode_int >> 7) & 0b1)
        _RequireEncrypted = bool((_AuthenticationMode_int >> 6) & 0b1)
        _RequireMac = bool((_AuthenticationMode_int >> 5) & 0b1)
        _RequireSessionKey = bool((_AuthenticationMode_int >> 4) & 0b1)
        _AuthenticationMode = HostSecurityAuthenticationMode(_RequireContinuousIv, _RequireEncrypted, _RequireMac, _RequireSessionKey)
        _DeriveKeyId = safe_read_int_from_buffer(_recv_buffer, 1)
        _AesKey_bytes = _recv_buffer.read(-1)
        _AesKey = _AesKey_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Device_HostSecurity_KeyInternal_Result(_AuthenticationMode, _DeriveKeyId, _AesKey)
    def get(self, KeyInternal_ndx: int, default: Optional[Device_HostSecurity_KeyInternal_Result] = None) -> Optional[Device_HostSecurity_KeyInternal_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if KeyInternal_ndx < 0 or KeyInternal_ndx >= 4:
            raise IndexError(KeyInternal_ndx)
        _send_buffer.write((208 + KeyInternal_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, KeyInternal_ndx: int, AuthenticationMode: Union[HostSecurityAuthenticationMode, HostSecurityAuthenticationMode_Dict], DeriveKeyId: int, AesKey: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        if KeyInternal_ndx < 0 or KeyInternal_ndx >= 4:
            raise IndexError(KeyInternal_ndx)
        _send_buffer.write((208 + KeyInternal_ndx).to_bytes(1, byteorder='big'))
        if isinstance(AuthenticationMode, dict):
            AuthenticationMode = HostSecurityAuthenticationMode(**AuthenticationMode)
        AuthenticationMode_int = 0
        AuthenticationMode_int |= (int(AuthenticationMode.RequireContinuousIv) & 0b1) << 7
        AuthenticationMode_int |= (int(AuthenticationMode.RequireEncrypted) & 0b1) << 6
        AuthenticationMode_int |= (int(AuthenticationMode.RequireMac) & 0b1) << 5
        AuthenticationMode_int |= (int(AuthenticationMode.RequireSessionKey) & 0b1) << 4
        _send_buffer.write(AuthenticationMode_int.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(DeriveKeyId.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(AesKey.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, KeyInternal_ndx: int, AuthenticationMode: Union[HostSecurityAuthenticationMode, HostSecurityAuthenticationMode_Dict], DeriveKeyId: int, AesKey: str) -> None:
        frame = self.build_frame(KeyInternal_ndx=KeyInternal_ndx, AuthenticationMode=AuthenticationMode, DeriveKeyId=DeriveKeyId, AesKey=AesKey)
        self.process_frame(frame)
class Device_Statistics(ConfigBase):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x44
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        self.process_frame(_send_buffer.getvalue())
class Device_Statistics_FirmwareId(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x44
    ValueKey: ClassVar[int] = 0x00
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x00')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x00')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x00')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Statistics_FirmwareRelease(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x44
    ValueKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 4)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x01')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x01')
        _send_buffer.write(Value.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Statistics_WatchdogResetCount(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x44
    ValueKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x02')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x02')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Statistics_StackOverflowCount(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x44
    ValueKey: ClassVar[int] = 0x03
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x03')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x03')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x03')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Statistics_StackOverflowTaskAddress(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x44
    ValueKey: ClassVar[int] = 0x04
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x04')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 4)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x04')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x04')
        _send_buffer.write(Value.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Statistics_BrownoutResetCount(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x44
    ValueKey: ClassVar[int] = 0x05
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x05')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x05')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x05')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Statistics_KeypadResetCount(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x44
    ValueKey: ClassVar[int] = 0x06
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x06')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x06')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x06')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Statistics_KeypadCommErrorCount(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x44
    ValueKey: ClassVar[int] = 0x07
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x07')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x07')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x07')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Statistics_AccessRestrictedTaskOverflowResetCount(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x44
    ValueKey: ClassVar[int] = 0x08
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x08')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x08')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\x08')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Device_Statistics_BleResetCount(ConfigValue):
    MasterKey: ClassVar[int] = 0x02
    SubKey: ClassVar[int] = 0x44
    ValueKey: ClassVar[int] = 0x09
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\t')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\t')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'D')
        _send_buffer.write(b'\t')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Custom(ConfigBase):
    MasterKey: ClassVar[int] = 0x06
    MasterKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        self.process_frame(_send_buffer.getvalue())
class Custom_Crypto(ConfigBase):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
class Custom_Crypto_Key(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x01
    ValueKey: ClassVar[int] = 0x80
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 128
    def reset(self, Key_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x01')
        if Key_ndx < 0 or Key_ndx >= 128:
            raise IndexError(Key_ndx)
        _send_buffer.write((128 + Key_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Custom_Crypto_Key_Result:
        _recv_buffer = BytesIO(frame)
        _Value_int = safe_read_int_from_buffer(_recv_buffer, 1)
        _DenyIdentify = bool((_Value_int >> 2) & 0b1)
        _DenyEncrypt = bool((_Value_int >> 1) & 0b1)
        _DenyDecrypt = bool((_Value_int >> 0) & 0b1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Custom_Crypto_Key_Result(_DenyIdentify, _DenyEncrypt, _DenyDecrypt)
    def get(self, Key_ndx: int, default: Optional[Custom_Crypto_Key_Result] = None) -> Optional[Custom_Crypto_Key_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x01')
        if Key_ndx < 0 or Key_ndx >= 128:
            raise IndexError(Key_ndx)
        _send_buffer.write((128 + Key_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Key_ndx: int, DenyIdentify: bool, DenyEncrypt: bool, DenyDecrypt: bool) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x01')
        if Key_ndx < 0 or Key_ndx >= 128:
            raise IndexError(Key_ndx)
        _send_buffer.write((128 + Key_ndx).to_bytes(1, byteorder='big'))
        _var_0000_int = 0
        _var_0000_int |= (int(DenyIdentify) & 0b1) << 2
        _var_0000_int |= (int(DenyEncrypt) & 0b1) << 1
        _var_0000_int |= (int(DenyDecrypt) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Key_ndx: int, DenyIdentify: bool, DenyEncrypt: bool, DenyDecrypt: bool) -> None:
        frame = self.build_frame(Key_ndx=Key_ndx, DenyIdentify=DenyIdentify, DenyEncrypt=DenyEncrypt, DenyDecrypt=DenyDecrypt)
        self.process_frame(frame)
class Custom_AdminData(ConfigBase):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x20
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        self.process_frame(_send_buffer.getvalue())
class Custom_AdminData_MasterCardNoRef(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x08
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x08')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 4)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x08')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x08')
        _send_buffer.write(Value.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Custom_AdminData_MasterCardNameRef(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x09
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\t')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\t')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\t')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Custom_AdminData_MasterCardNo(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x10
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x10')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x10')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x10')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Custom_AdminData_MasterCardName(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x11
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x11')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x11')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x11')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Custom_AdminData_DeviceSettingsTemplateBased(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x12
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x12')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> bool:
        _recv_buffer = BytesIO(frame)
        _Value = bool(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[bool] = None) -> Optional[bool]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x12')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: bool) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x12')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: bool) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Custom_AdminData_ProjectSettingsTemplateBased(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x13
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x13')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> bool:
        _recv_buffer = BytesIO(frame)
        _Value = bool(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[bool] = None) -> Optional[bool]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x13')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: bool) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x13')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: bool) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Custom_AdminData_UniqueDeviceName(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x14
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x14')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x14')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x14')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Custom_AdminData_DraftFlag(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x15
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x15')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> bool:
        _recv_buffer = BytesIO(frame)
        _Value = bool(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[bool] = None) -> Optional[bool]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x15')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: bool) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x15')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: bool) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Custom_AdminData_BaltechConfigID(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x16
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x16')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x16')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x16')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Custom_AdminData_DeviceSettingsCustomerNo(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x17
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x17')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 4)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x17')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x17')
        _send_buffer.write(Value.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Custom_AdminData_FactoryResetFirmwareVersion(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x18
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x18')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[Custom_AdminData_FactoryResetFirmwareVersion_Value_Entry]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _FirmwareId = safe_read_int_from_buffer(_recv_buffer, 2)
            _FwVersionMajor = safe_read_int_from_buffer(_recv_buffer, 1)
            _FwVersionMinor = safe_read_int_from_buffer(_recv_buffer, 1)
            _FwVersionBuild = safe_read_int_from_buffer(_recv_buffer, 1)
            _Value_Entry = Custom_AdminData_FactoryResetFirmwareVersion_Value_Entry(_FirmwareId, _FwVersionMajor, _FwVersionMinor, _FwVersionBuild)
            _Value.append(_Value_Entry)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[List[Custom_AdminData_FactoryResetFirmwareVersion_Value_Entry]] = None) -> Optional[List[Custom_AdminData_FactoryResetFirmwareVersion_Value_Entry]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x18')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: List[Custom_AdminData_FactoryResetFirmwareVersion_Value_Entry]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x18')
        for _Value_Entry in Value:
            _FirmwareId, _FwVersionMajor, _FwVersionMinor, _FwVersionBuild = _Value_Entry
            _send_buffer.write(_FirmwareId.to_bytes(length=2, byteorder='big'))
            _send_buffer.write(_FwVersionMajor.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_FwVersionMinor.to_bytes(length=1, byteorder='big'))
            _send_buffer.write(_FwVersionBuild.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: List[Custom_AdminData_FactoryResetFirmwareVersion_Value_Entry]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Custom_AdminData_BleFirmwareVersion(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x19
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x19')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x19')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x19')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Custom_AdminData_RequiresBusAddress(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x20
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b' ')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> bool:
        _recv_buffer = BytesIO(frame)
        _Value = bool(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[bool] = None) -> Optional[bool]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b' ')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: bool) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b' ')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: bool) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Custom_AdminData_V2eFormatIndicator(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x20
    ValueKey: ClassVar[int] = 0x80
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x80')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x80')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(b'\x80')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Custom_Cid10022(ConfigBase):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x21
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'!')
        self.process_frame(_send_buffer.getvalue())
class Custom_Cid10022_ProjectName(ConfigValue):
    MasterKey: ClassVar[int] = 0x06
    SubKey: ClassVar[int] = 0x21
    ValueKey: ClassVar[int] = 0x00
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'!')
        _send_buffer.write(b'\x00')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'!')
        _send_buffer.write(b'\x00')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'!')
        _send_buffer.write(b'\x00')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Registers(ConfigBase):
    MasterKey: ClassVar[int] = 0x07
    MasterKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x07')
        self.process_frame(_send_buffer.getvalue())
class Project(ConfigBase):
    MasterKey: ClassVar[int] = 0x08
    MasterKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        self.process_frame(_send_buffer.getvalue())
class Project_VhlSettings(ConfigBase):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x02
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        self.process_frame(_send_buffer.getvalue())
class Project_VhlSettings_HighPrioTaglist(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x21
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'!')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> List[CardType]:
        _recv_buffer = BytesIO(frame)
        _Value = []  # type: ignore[var-annotated,unused-ignore]
        while not _recv_buffer.tell() >= len(_recv_buffer.getvalue()):
            _HighPrioTag = CardType_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
            _Value.append(_HighPrioTag)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[List[CardType]] = None) -> Optional[List[CardType]]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'!')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: List[CardType]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'!')
        for _Value_Entry in Value:
            _HighPrioTag = _Value_Entry
            _send_buffer.write(CardType_Parser.as_value(_HighPrioTag).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: List[CardType]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings_HighPrioDelay(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x22
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'"')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'"')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'"')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings_HandleLegicCTCAsSinglePrimeTransponder(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x23
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'#')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_VhlSettings_HandleLegicCTCAsSinglePrimeTransponder_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Project_VhlSettings_HandleLegicCTCAsSinglePrimeTransponder_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Project_VhlSettings_HandleLegicCTCAsSinglePrimeTransponder_Value] = None) -> Optional[Project_VhlSettings_HandleLegicCTCAsSinglePrimeTransponder_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'#')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Project_VhlSettings_HandleLegicCTCAsSinglePrimeTransponder_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'#')
        _send_buffer.write(Project_VhlSettings_HandleLegicCTCAsSinglePrimeTransponder_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Project_VhlSettings_HandleLegicCTCAsSinglePrimeTransponder_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_VhlSettings_DesfireEV1RetryLoopTime(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x02
    ValueKey: ClassVar[int] = 0x24
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'$')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Time = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Time
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'$')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Time: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'$')
        _send_buffer.write(Time.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Time: int) -> None:
        frame = self.build_frame(Time=Time)
        self.process_frame(frame)
class Project_VhlSettingsLegic(ConfigBase):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x43
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'C')
        self.process_frame(_send_buffer.getvalue())
class Project_VhlSettings125Khz(ConfigBase):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        self.process_frame(_send_buffer.getvalue())
class Project_VhlSettings125Khz_IndaspOkCounter(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x09
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\t')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _OkCounter = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _OkCounter
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\t')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, OkCounter: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\t')
        _send_buffer.write(OkCounter.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, OkCounter: int) -> None:
        frame = self.build_frame(OkCounter=OkCounter)
        self.process_frame(frame)
class Project_VhlSettings125Khz_AwidOkCounter(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x0A
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\n')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _OkCounter = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _OkCounter
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\n')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, OkCounter: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\n')
        _send_buffer.write(OkCounter.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, OkCounter: int) -> None:
        frame = self.build_frame(OkCounter=OkCounter)
        self.process_frame(frame)
class Project_VhlSettings125Khz_HidProxOkCounter(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x0B
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x0b')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _OkCounter = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _OkCounter
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x0b')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, OkCounter: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x0b')
        _send_buffer.write(OkCounter.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, OkCounter: int) -> None:
        frame = self.build_frame(OkCounter=OkCounter)
        self.process_frame(frame)
class Project_VhlSettings125Khz_QuadrakeyOkCounter(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x0C
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x0c')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _OkCounter = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _OkCounter
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x0c')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, OkCounter: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x0c')
        _send_buffer.write(OkCounter.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, OkCounter: int) -> None:
        frame = self.build_frame(OkCounter=OkCounter)
        self.process_frame(frame)
class Project_VhlSettings125Khz_IoproxOkCounter(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x0D
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\r')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _OkCounter = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _OkCounter
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\r')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, OkCounter: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\r')
        _send_buffer.write(OkCounter.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, OkCounter: int) -> None:
        frame = self.build_frame(OkCounter=OkCounter)
        self.process_frame(frame)
class Project_VhlSettings125Khz_IndalaMode(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x15
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x15')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_VhlSettings125Khz_IndalaMode_Mode:
        _recv_buffer = BytesIO(frame)
        _Mode = Project_VhlSettings125Khz_IndalaMode_Mode_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Mode
    def get(self, default: Optional[Project_VhlSettings125Khz_IndalaMode_Mode] = None) -> Optional[Project_VhlSettings125Khz_IndalaMode_Mode]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x15')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Mode: Project_VhlSettings125Khz_IndalaMode_Mode) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x15')
        _send_buffer.write(Project_VhlSettings125Khz_IndalaMode_Mode_Parser.as_value(Mode).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Mode: Project_VhlSettings125Khz_IndalaMode_Mode) -> None:
        frame = self.build_frame(Mode=Mode)
        self.process_frame(frame)
class Project_VhlSettings125Khz_IsSelectedRetryCounter(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x18
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x18')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _RetryCounter = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _RetryCounter
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x18')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, RetryCounter: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x18')
        _send_buffer.write(RetryCounter.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, RetryCounter: int) -> None:
        frame = self.build_frame(RetryCounter=RetryCounter)
        self.process_frame(frame)
class Project_VhlSettings125Khz_GenericOkCounter(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x42
    ValueKey: ClassVar[int] = 0x17
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x17')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _OkCounter = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _OkCounter
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x17')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, OkCounter: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'B')
        _send_buffer.write(b'\x17')
        _send_buffer.write(OkCounter.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, OkCounter: int) -> None:
        frame = self.build_frame(OkCounter=OkCounter)
        self.process_frame(frame)
class Project_Bluetooth(ConfigBase):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x52
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        self.process_frame(_send_buffer.getvalue())
class Project_Bluetooth_DiscoveryMode(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x52
    ValueKey: ClassVar[int] = 0x21
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'!')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_Bluetooth_DiscoveryMode_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Project_Bluetooth_DiscoveryMode_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Project_Bluetooth_DiscoveryMode_Value] = None) -> Optional[Project_Bluetooth_DiscoveryMode_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'!')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Project_Bluetooth_DiscoveryMode_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'!')
        _send_buffer.write(Project_Bluetooth_DiscoveryMode_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Project_Bluetooth_DiscoveryMode_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_Bluetooth_ConnectionMode(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x52
    ValueKey: ClassVar[int] = 0x22
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'"')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_Bluetooth_ConnectionMode_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Project_Bluetooth_ConnectionMode_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Project_Bluetooth_ConnectionMode_Value] = None) -> Optional[Project_Bluetooth_ConnectionMode_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'"')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Project_Bluetooth_ConnectionMode_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'"')
        _send_buffer.write(Project_Bluetooth_ConnectionMode_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Project_Bluetooth_ConnectionMode_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_Bluetooth_AdvertisementData(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x52
    ValueKey: ClassVar[int] = 0x23
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'#')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'#')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'#')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_Bluetooth_ScanResponseData(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x52
    ValueKey: ClassVar[int] = 0x24
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'$')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'$')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'$')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_Bluetooth_MinAdvertisingInterval(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x52
    ValueKey: ClassVar[int] = 0x25
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'%')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'%')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'%')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_Bluetooth_MaxAdvertisingInterval(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x52
    ValueKey: ClassVar[int] = 0x26
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'&')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'&')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'&')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_Bluetooth_AdvertizingChannels(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x52
    ValueKey: ClassVar[int] = 0x27
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b"'")
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_Bluetooth_AdvertizingChannels_Result:
        _recv_buffer = BytesIO(frame)
        _ChannelMap_int = safe_read_int_from_buffer(_recv_buffer, 1)
        _Channel39 = bool((_ChannelMap_int >> 2) & 0b1)
        _Channel38 = bool((_ChannelMap_int >> 1) & 0b1)
        _Channel37 = bool((_ChannelMap_int >> 0) & 0b1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Project_Bluetooth_AdvertizingChannels_Result(_Channel39, _Channel38, _Channel37)
    def get(self, default: Optional[Project_Bluetooth_AdvertizingChannels_Result] = None) -> Optional[Project_Bluetooth_AdvertizingChannels_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b"'")
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Channel39: bool, Channel38: bool, Channel37: bool) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b"'")
        _var_0000_int = 0
        _var_0000_int |= (int(Channel39) & 0b1) << 2
        _var_0000_int |= (int(Channel38) & 0b1) << 1
        _var_0000_int |= (int(Channel37) & 0b1) << 0
        _send_buffer.write(_var_0000_int.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Channel39: bool, Channel38: bool, Channel37: bool) -> None:
        frame = self.build_frame(Channel39=Channel39, Channel38=Channel38, Channel37=Channel37)
        self.process_frame(frame)
class Project_Bluetooth_MinConnectionInterval(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x52
    ValueKey: ClassVar[int] = 0x28
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'(')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'(')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'(')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_Bluetooth_MaxConnectionInterval(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x52
    ValueKey: ClassVar[int] = 0x29
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b')')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b')')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b')')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_Bluetooth_ConnectionSupervisionTimeout(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x52
    ValueKey: ClassVar[int] = 0x2A
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'*')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'*')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'*')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_Bluetooth_DeviceNameLegacy(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x52
    ValueKey: ClassVar[int] = 0x30
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'0')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Template:
        _recv_buffer = BytesIO(frame)
        _Value = Template(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Template] = None) -> Optional[Template]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'0')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[Template, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'0')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[Template, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_Bluetooth_Appearance(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x52
    ValueKey: ClassVar[int] = 0x31
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'1')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'1')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'1')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_Bluetooth_AdvertizedDeviceName(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x52
    ValueKey: ClassVar[int] = 0x32
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'2')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Template:
        _recv_buffer = BytesIO(frame)
        _Value = Template(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Template] = None) -> Optional[Template]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'2')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[Template, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'2')
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[Template, bytes]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_Bluetooth_ScanInterval(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x52
    ValueKey: ClassVar[int] = 0x41
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'A')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'A')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'A')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_Bluetooth_ScanWindow(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x52
    ValueKey: ClassVar[int] = 0x42
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'B')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'B')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'R')
        _send_buffer.write(b'B')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Project_Mce(ConfigBase):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x54
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'T')
        self.process_frame(_send_buffer.getvalue())
class Project_Mce_Mode(ConfigValue):
    MasterKey: ClassVar[int] = 0x08
    SubKey: ClassVar[int] = 0x54
    ValueKey: ClassVar[int] = 0x00
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'T')
        _send_buffer.write(b'\x00')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Project_Mce_Mode_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Project_Mce_Mode_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Project_Mce_Mode_Value] = None) -> Optional[Project_Mce_Mode_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'T')
        _send_buffer.write(b'\x00')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Project_Mce_Mode_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x08')
        _send_buffer.write(b'T')
        _send_buffer.write(b'\x00')
        _send_buffer.write(Project_Mce_Mode_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Project_Mce_Mode_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class ProjectRegisters(ConfigBase):
    MasterKey: ClassVar[int] = 0x09
    MasterKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\t')
        self.process_frame(_send_buffer.getvalue())
class Protocols(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    MasterKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        self.process_frame(_send_buffer.getvalue())
class Protocols_Bpa9(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x11
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x11')
        self.process_frame(_send_buffer.getvalue())
class Protocols_Bpa9_BaudRate(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x11
    ValueKey: ClassVar[int] = 0x00
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x11')
        _send_buffer.write(b'\x00')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Baudrate:
        _recv_buffer = BytesIO(frame)
        _Value = Baudrate_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 2))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Baudrate] = None) -> Optional[Baudrate]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x11')
        _send_buffer.write(b'\x00')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Baudrate = "Baud115200") -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x11')
        _send_buffer.write(b'\x00')
        _send_buffer.write(Baudrate_Parser.as_value(Value).to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Baudrate = "Baud115200") -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Bpa9_DeviceId(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x11
    ValueKey: ClassVar[int] = 0x21
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x11')
        _send_buffer.write(b'!')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x11')
        _send_buffer.write(b'!')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x11')
        _send_buffer.write(b'!')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Bpa9_GroupId(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x11
    ValueKey: ClassVar[int] = 0x22
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x11')
        _send_buffer.write(b'"')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x11')
        _send_buffer.write(b'"')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x11')
        _send_buffer.write(b'"')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BrpTcp(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x06
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        self.process_frame(_send_buffer.getvalue())
class Protocols_BrpTcp_CmdWorkInterval(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x06
    ValueKey: ClassVar[int] = 0x15
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x15')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x15')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x15')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BrpTcp_RepeatModeMinDelay(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x06
    ValueKey: ClassVar[int] = 0x14
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x14')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x14')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'\x14')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BrpTcp_TcpPort(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x06
    ValueKey: ClassVar[int] = 0x20
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b' ')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BrpTcp_TcpHost(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x06
    ValueKey: ClassVar[int] = 0x21
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'!')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'!')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'!')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BrpTcp_TcpHostPort(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x06
    ValueKey: ClassVar[int] = 0x22
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'"')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'"')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'"')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BrpTcp_TcpAlternateHost(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x06
    ValueKey: ClassVar[int] = 0x23
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'#')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'#')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'#')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BrpTcp_TcpAlternateHostPort(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x06
    ValueKey: ClassVar[int] = 0x24
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'$')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'$')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'$')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BrpTcp_TcpAutoCloseTimeout(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x06
    ValueKey: ClassVar[int] = 0x25
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'%')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'%')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'%')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BrpTcp_TcpOutgoingPort(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x06
    ValueKey: ClassVar[int] = 0x27
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b"'")
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b"'")
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b"'")
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BrpTcp_TcpConnectTrialMinDelay(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x06
    ValueKey: ClassVar[int] = 0x28
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'(')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'(')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'(')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BrpTcp_TcpConnectTrialMaxDelay(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x06
    ValueKey: ClassVar[int] = 0x29
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b')')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b')')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b')')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BrpTcp_TcpSoftResetDelay(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x06
    ValueKey: ClassVar[int] = 0x2A
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'*')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'*')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'*')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BrpTcp_TcpMaskLinkChangeEventDelay(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x06
    ValueKey: ClassVar[int] = 0x2B
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'+')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'+')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b'+')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BrpTcp_TcpTtl(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x06
    ValueKey: ClassVar[int] = 0x2C
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b',')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b',')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        _send_buffer.write(b',')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BrpTcp_SlpAttributes(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x06
    ValueKey: ClassVar[int] = 0x30
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 16
    def reset(self, SlpAttributes_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        if SlpAttributes_ndx < 0 or SlpAttributes_ndx >= 16:
            raise IndexError(SlpAttributes_ndx)
        _send_buffer.write((48 + SlpAttributes_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, SlpAttributes_ndx: int, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        if SlpAttributes_ndx < 0 or SlpAttributes_ndx >= 16:
            raise IndexError(SlpAttributes_ndx)
        _send_buffer.write((48 + SlpAttributes_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, SlpAttributes_ndx: int, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        if SlpAttributes_ndx < 0 or SlpAttributes_ndx >= 16:
            raise IndexError(SlpAttributes_ndx)
        _send_buffer.write((48 + SlpAttributes_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, SlpAttributes_ndx: int, Value: str) -> None:
        frame = self.build_frame(SlpAttributes_ndx=SlpAttributes_ndx, Value=Value)
        self.process_frame(frame)
class Protocols_BrpTcp_HostMsgFormatTemplate(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x06
    ValueKey: ClassVar[int] = 0x40
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 4
    def reset(self, HostMsgFormatTemplate_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Template:
        _recv_buffer = BytesIO(frame)
        _Value = Template(_recv_buffer.read(-1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, HostMsgFormatTemplate_ndx: int, default: Optional[Template] = None) -> Optional[Template]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, HostMsgFormatTemplate_ndx: int, Value: Union[Template, bytes]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        if HostMsgFormatTemplate_ndx < 0 or HostMsgFormatTemplate_ndx >= 4:
            raise IndexError(HostMsgFormatTemplate_ndx)
        _send_buffer.write((64 + HostMsgFormatTemplate_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(bytes(Value))
        return _send_buffer.getvalue()
    def __call__(self, HostMsgFormatTemplate_ndx: int, Value: Union[Template, bytes]) -> None:
        frame = self.build_frame(HostMsgFormatTemplate_ndx=HostMsgFormatTemplate_ndx, Value=Value)
        self.process_frame(frame)
class Protocols_BrpTcp_AutoRunCommand(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x06
    ValueKey: ClassVar[int] = 0x50
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 16
    def reset(self, AutoRunCommand_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        if AutoRunCommand_ndx < 0 or AutoRunCommand_ndx >= 16:
            raise IndexError(AutoRunCommand_ndx)
        _send_buffer.write((80 + AutoRunCommand_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> AutoRunCommand:
        _recv_buffer = BytesIO(frame)
        _RunMode = AutoRunCommand_RunMode_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _DeviceCode = safe_read_int_from_buffer(_recv_buffer, 1)
        _CommandCode = safe_read_int_from_buffer(_recv_buffer, 1)
        _Parameter_bytes = _recv_buffer.read(-1)
        _Parameter = _Parameter_bytes.decode('ascii')
        _Value = AutoRunCommand(_RunMode, _DeviceCode, _CommandCode, _Parameter)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, AutoRunCommand_ndx: int, default: Optional[AutoRunCommand] = None) -> Optional[AutoRunCommand]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        if AutoRunCommand_ndx < 0 or AutoRunCommand_ndx >= 16:
            raise IndexError(AutoRunCommand_ndx)
        _send_buffer.write((80 + AutoRunCommand_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, AutoRunCommand_ndx: int, Value: Union[AutoRunCommand, AutoRunCommand_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x06')
        if AutoRunCommand_ndx < 0 or AutoRunCommand_ndx >= 16:
            raise IndexError(AutoRunCommand_ndx)
        _send_buffer.write((80 + AutoRunCommand_ndx).to_bytes(1, byteorder='big'))
        if isinstance(Value, dict):
            Value = AutoRunCommand(**Value)
        _RunMode, _DeviceCode, _CommandCode, _Parameter = Value
        _send_buffer.write(AutoRunCommand_RunMode_Parser.as_value(_RunMode).to_bytes(length=1, byteorder='big'))
        _send_buffer.write(_DeviceCode.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(_CommandCode.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(_Parameter.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, AutoRunCommand_ndx: int, Value: Union[AutoRunCommand, AutoRunCommand_Dict]) -> None:
        frame = self.build_frame(AutoRunCommand_ndx=AutoRunCommand_ndx, Value=Value)
        self.process_frame(frame)
class Protocols_Network(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        self.process_frame(_send_buffer.getvalue())
class Protocols_Network_DhcpLastAssignedIp(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x25
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'%')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'%')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'%')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network_DhcpVendorClassIdentifier(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x26
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'&')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'&')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'&')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network_LinkLocalLastAssignedIp(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x27
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b"'")
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b"'")
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b"'")
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network_LinkLocalMode(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x28
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'(')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_Network_LinkLocalMode_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_Network_LinkLocalMode_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_Network_LinkLocalMode_Value] = None) -> Optional[Protocols_Network_LinkLocalMode_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'(')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_Network_LinkLocalMode_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'(')
        _send_buffer.write(Protocols_Network_LinkLocalMode_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_Network_LinkLocalMode_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network_LinkLocalAcquireDelay(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x29
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b')')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b')')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b')')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network_DetectIpEnable(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x2A
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'*')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_Network_DetectIpEnable_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_Network_DetectIpEnable_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_Network_DetectIpEnable_Value] = None) -> Optional[Protocols_Network_DetectIpEnable_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'*')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_Network_DetectIpEnable_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'*')
        _send_buffer.write(Protocols_Network_DetectIpEnable_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_Network_DetectIpEnable_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network_ResolverEnable(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x2B
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'+')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_Network_ResolverEnable_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_Network_ResolverEnable_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_Network_ResolverEnable_Value] = None) -> Optional[Protocols_Network_ResolverEnable_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'+')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_Network_ResolverEnable_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'+')
        _send_buffer.write(Protocols_Network_ResolverEnable_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_Network_ResolverEnable_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network_ResolverInterval(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x2C
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b',')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b',')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b',')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network_UdpIntrospecEnable(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x2D
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'-')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_Network_UdpIntrospecEnable_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_Network_UdpIntrospecEnable_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_Network_UdpIntrospecEnable_Value] = None) -> Optional[Protocols_Network_UdpIntrospecEnable_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'-')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_Network_UdpIntrospecEnable_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'-')
        _send_buffer.write(Protocols_Network_UdpIntrospecEnable_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_Network_UdpIntrospecEnable_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network_SlpEnable(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x30
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'0')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_Network_SlpEnable_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_Network_SlpEnable_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_Network_SlpEnable_Value] = None) -> Optional[Protocols_Network_SlpEnable_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'0')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_Network_SlpEnable_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'0')
        _send_buffer.write(Protocols_Network_SlpEnable_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_Network_SlpEnable_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network_SlpScope(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x31
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'1')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'1')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'1')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network_SlpDirectoryAgent(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x32
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'2')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(-1)
        _Value = _Value_bytes.decode('ascii')
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'2')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'2')
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network_SlpActiveDiscovery(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x33
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'3')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_Network_SlpActiveDiscovery_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_Network_SlpActiveDiscovery_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_Network_SlpActiveDiscovery_Value] = None) -> Optional[Protocols_Network_SlpActiveDiscovery_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'3')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_Network_SlpActiveDiscovery_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'3')
        _send_buffer.write(Protocols_Network_SlpActiveDiscovery_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_Network_SlpActiveDiscovery_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network_SlpPassiveDiscovery(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x34
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'4')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_Network_SlpPassiveDiscovery_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_Network_SlpPassiveDiscovery_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_Network_SlpPassiveDiscovery_Value] = None) -> Optional[Protocols_Network_SlpPassiveDiscovery_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'4')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_Network_SlpPassiveDiscovery_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'4')
        _send_buffer.write(Protocols_Network_SlpPassiveDiscovery_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_Network_SlpPassiveDiscovery_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network_SlpMulticastTtl(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x35
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'5')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'5')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'5')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network_SlpRegistratonLifetime(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x36
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'6')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 2)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'6')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'6')
        _send_buffer.write(Value.to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network_SlpUseBroadcast(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x37
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'7')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_Network_SlpUseBroadcast_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_Network_SlpUseBroadcast_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_Network_SlpUseBroadcast_Value] = None) -> Optional[Protocols_Network_SlpUseBroadcast_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'7')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_Network_SlpUseBroadcast_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'7')
        _send_buffer.write(Protocols_Network_SlpUseBroadcast_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_Network_SlpUseBroadcast_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network_RecoveryPointStatus(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x38
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'8')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_Network_RecoveryPointStatus_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_Network_RecoveryPointStatus_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_Network_RecoveryPointStatus_Value] = None) -> Optional[Protocols_Network_RecoveryPointStatus_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'8')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_Network_RecoveryPointStatus_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'8')
        _send_buffer.write(Protocols_Network_RecoveryPointStatus_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_Network_RecoveryPointStatus_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network_NicNetworkPortSpeedDuplexMode(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x40
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'@')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_Network_NicNetworkPortSpeedDuplexMode_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_Network_NicNetworkPortSpeedDuplexMode_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_Network_NicNetworkPortSpeedDuplexMode_Value] = None) -> Optional[Protocols_Network_NicNetworkPortSpeedDuplexMode_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'@')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_Network_NicNetworkPortSpeedDuplexMode_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'@')
        _send_buffer.write(Protocols_Network_NicNetworkPortSpeedDuplexMode_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_Network_NicNetworkPortSpeedDuplexMode_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network_NicFlowControl(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x41
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'A')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_Network_NicFlowControl_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_Network_NicFlowControl_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_Network_NicFlowControl_Value] = None) -> Optional[Protocols_Network_NicFlowControl_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'A')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_Network_NicFlowControl_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'A')
        _send_buffer.write(Protocols_Network_NicFlowControl_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_Network_NicFlowControl_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Network_NicPrinterPortSpeedDuplexMode(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x34
    ValueKey: ClassVar[int] = 0x45
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'E')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_Network_NicPrinterPortSpeedDuplexMode_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_Network_NicPrinterPortSpeedDuplexMode_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_Network_NicPrinterPortSpeedDuplexMode_Value] = None) -> Optional[Protocols_Network_NicPrinterPortSpeedDuplexMode_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'E')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_Network_NicPrinterPortSpeedDuplexMode_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'4')
        _send_buffer.write(b'E')
        _send_buffer.write(Protocols_Network_NicPrinterPortSpeedDuplexMode_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_Network_NicPrinterPortSpeedDuplexMode_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Lbus(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x32
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        self.process_frame(_send_buffer.getvalue())
class Protocols_Lbus_BaudRate(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x32
    ValueKey: ClassVar[int] = 0x00
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'\x00')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Baudrate:
        _recv_buffer = BytesIO(frame)
        _Value = Baudrate_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 2))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Baudrate] = None) -> Optional[Baudrate]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'\x00')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Baudrate = "Baud115200") -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'\x00')
        _send_buffer.write(Baudrate_Parser.as_value(Value).to_bytes(length=2, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Baudrate = "Baud115200") -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Lbus_Channel(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x32
    ValueKey: ClassVar[int] = 0x20
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b' ')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_Lbus_Channel_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_Lbus_Channel_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_Lbus_Channel_Value] = None) -> Optional[Protocols_Lbus_Channel_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b' ')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_Lbus_Channel_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b' ')
        _send_buffer.write(Protocols_Lbus_Channel_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_Lbus_Channel_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Lbus_Address(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x32
    ValueKey: ClassVar[int] = 0x21
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'!')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'!')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'!')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Lbus_OfflineTimeout(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x32
    ValueKey: ClassVar[int] = 0x23
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'#')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'#')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'#')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Lbus_OrderNumber(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x32
    ValueKey: ClassVar[int] = 0x24
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'$')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> bytes:
        _recv_buffer = BytesIO(frame)
        _Value = _recv_buffer.read(-1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[bytes] = None) -> Optional[bytes]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'$')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: bytes) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'$')
        _send_buffer.write(Value)
        return _send_buffer.getvalue()
    def __call__(self, Value: bytes) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Lbus_CheckDigits(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x32
    ValueKey: ClassVar[int] = 0x25
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'%')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> bytes:
        _recv_buffer = BytesIO(frame)
        _Value = _recv_buffer.read(-1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[bytes] = None) -> Optional[bytes]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'%')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: bytes) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'%')
        _send_buffer.write(Value)
        return _send_buffer.getvalue()
    def __call__(self, Value: bytes) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Lbus_OfflineCompanyIdLegacy(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x32
    ValueKey: ClassVar[int] = 0x26
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'&')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> bytes:
        _recv_buffer = BytesIO(frame)
        _CompanyId = _recv_buffer.read(-1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _CompanyId
    def get(self, default: Optional[bytes] = None) -> Optional[bytes]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'&')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, CompanyId: bytes) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'&')
        _send_buffer.write(CompanyId)
        return _send_buffer.getvalue()
    def __call__(self, CompanyId: bytes) -> None:
        frame = self.build_frame(CompanyId=CompanyId)
        self.process_frame(frame)
class Protocols_Lbus_OfflineCompanyIdPositionLegacy(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x32
    ValueKey: ClassVar[int] = 0x27
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b"'")
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b"'")
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b"'")
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Lbus_OfflineIndication(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x32
    ValueKey: ClassVar[int] = 0x28
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'(')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_Lbus_OfflineIndication_Value:
        _recv_buffer = BytesIO(frame)
        _Value = Protocols_Lbus_OfflineIndication_Value_Parser.as_literal(safe_read_int_from_buffer(_recv_buffer, 1))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[Protocols_Lbus_OfflineIndication_Value] = None) -> Optional[Protocols_Lbus_OfflineIndication_Value]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'(')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Protocols_Lbus_OfflineIndication_Value) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'(')
        _send_buffer.write(Protocols_Lbus_OfflineIndication_Value_Parser.as_value(Value).to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Protocols_Lbus_OfflineIndication_Value) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Lbus_OfflineOutputTime(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x32
    ValueKey: ClassVar[int] = 0x29
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b')')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b')')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b')')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Lbus_OfflineGreenLedTime(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x32
    ValueKey: ClassVar[int] = 0x2A
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'*')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'*')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'*')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Lbus_OfflineRedLedTime(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x32
    ValueKey: ClassVar[int] = 0x2B
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'+')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> int:
        _recv_buffer = BytesIO(frame)
        _Value = safe_read_int_from_buffer(_recv_buffer, 1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[int] = None) -> Optional[int]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'+')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: int) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'+')
        _send_buffer.write(Value.to_bytes(length=1, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: int) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_Lbus_OfflineCompanyId(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x32
    ValueKey: ClassVar[int] = 0x31
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 10
    def reset(self, OfflineCompanyId_ndx: int) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        if OfflineCompanyId_ndx < 0 or OfflineCompanyId_ndx >= 10:
            raise IndexError(OfflineCompanyId_ndx)
        _send_buffer.write((49 + OfflineCompanyId_ndx).to_bytes(1, byteorder='big'))
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> Protocols_Lbus_OfflineCompanyId_Result:
        _recv_buffer = BytesIO(frame)
        _Position = safe_read_int_from_buffer(_recv_buffer, 1)
        _CompanyId = _recv_buffer.read(-1)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return Protocols_Lbus_OfflineCompanyId_Result(_Position, _CompanyId)
    def get(self, OfflineCompanyId_ndx: int, default: Optional[Protocols_Lbus_OfflineCompanyId_Result] = None) -> Optional[Protocols_Lbus_OfflineCompanyId_Result]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        if OfflineCompanyId_ndx < 0 or OfflineCompanyId_ndx >= 10:
            raise IndexError(OfflineCompanyId_ndx)
        _send_buffer.write((49 + OfflineCompanyId_ndx).to_bytes(1, byteorder='big'))
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, OfflineCompanyId_ndx: int, Position: int, CompanyId: bytes) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        if OfflineCompanyId_ndx < 0 or OfflineCompanyId_ndx >= 10:
            raise IndexError(OfflineCompanyId_ndx)
        _send_buffer.write((49 + OfflineCompanyId_ndx).to_bytes(1, byteorder='big'))
        _send_buffer.write(Position.to_bytes(length=1, byteorder='big'))
        _send_buffer.write(CompanyId)
        return _send_buffer.getvalue()
    def __call__(self, OfflineCompanyId_ndx: int, Position: int, CompanyId: bytes) -> None:
        frame = self.build_frame(OfflineCompanyId_ndx=OfflineCompanyId_ndx, Position=Position, CompanyId=CompanyId)
        self.process_frame(frame)
class Protocols_Lbus_Key(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x32
    ValueKey: ClassVar[int] = 0xC0
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'\xc0')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> str:
        _recv_buffer = BytesIO(frame)
        _Value_bytes = _recv_buffer.read(16)
        _Value = _Value_bytes.decode('ascii')
        if len(_Value) != 16:
            raise PayloadTooShortError(16 - len(_Value))
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[str] = None) -> Optional[str]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'\xc0')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: str) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'2')
        _send_buffer.write(b'\xc0')
        if len(Value) != 16:
            raise ValueError(Value)
        _send_buffer.write(Value.encode("ascii"))
        return _send_buffer.getvalue()
    def __call__(self, Value: str) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_BleHci(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x3B
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b';')
        self.process_frame(_send_buffer.getvalue())
class Protocols_AccessConditionBitsStd(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x60
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'`')
        self.process_frame(_send_buffer.getvalue())
class Protocols_AccessConditionBitsStd_Tcp(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x60
    ValueKey: ClassVar[int] = 0x86
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'`')
        _send_buffer.write(b'\x86')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> HostSecurityAccessConditionBits:
        _recv_buffer = BytesIO(frame)
        _Value_int = safe_read_int_from_buffer(_recv_buffer, 4)
        _HostToHostAccess = bool((_Value_int >> 28) & 0b1)
        _AutoreadAccess = bool((_Value_int >> 27) & 0b1)
        _CryptoAccess = bool((_Value_int >> 26) & 0b1)
        _Bf2Upload = bool((_Value_int >> 25) & 0b1)
        _ExtendedAccess = bool((_Value_int >> 24) & 0b1)
        _FlashFileSystemWrite = bool((_Value_int >> 23) & 0b1)
        _FlashFileSystemRead = bool((_Value_int >> 22) & 0b1)
        _RtcWrite = bool((_Value_int >> 21) & 0b1)
        _VhlExchangeapdu = bool((_Value_int >> 20) & 0b1)
        _VhlFormat = bool((_Value_int >> 19) & 0b1)
        _VhlWrite = bool((_Value_int >> 18) & 0b1)
        _VhlRead = bool((_Value_int >> 17) & 0b1)
        _VhlSelect = bool((_Value_int >> 16) & 0b1)
        _ExtSamAccess = bool((_Value_int >> 15) & 0b1)
        _HfLowlevelAccess = bool((_Value_int >> 14) & 0b1)
        _GuiAccess = bool((_Value_int >> 13) & 0b1)
        _IoPortWrite = bool((_Value_int >> 12) & 0b1)
        _IoPortRead = bool((_Value_int >> 11) & 0b1)
        _ConfigReset = bool((_Value_int >> 10) & 0b1)
        _ConfigWrite = bool((_Value_int >> 9) & 0b1)
        _ConfigRead = bool((_Value_int >> 8) & 0b1)
        _SysReset = bool((_Value_int >> 7) & 0b1)
        _SetAccessConditionMask2 = bool((_Value_int >> 6) & 0b1)
        _SetAccessConditionMask1 = bool((_Value_int >> 5) & 0b1)
        _SetAccessConditionMask0 = bool((_Value_int >> 4) & 0b1)
        _SetKey3 = bool((_Value_int >> 3) & 0b1)
        _SetKey2 = bool((_Value_int >> 2) & 0b1)
        _SetKey1 = bool((_Value_int >> 1) & 0b1)
        _FactoryReset = bool((_Value_int >> 0) & 0b1)
        _Value = HostSecurityAccessConditionBits(_HostToHostAccess, _AutoreadAccess, _CryptoAccess, _Bf2Upload, _ExtendedAccess, _FlashFileSystemWrite, _FlashFileSystemRead, _RtcWrite, _VhlExchangeapdu, _VhlFormat, _VhlWrite, _VhlRead, _VhlSelect, _ExtSamAccess, _HfLowlevelAccess, _GuiAccess, _IoPortWrite, _IoPortRead, _ConfigReset, _ConfigWrite, _ConfigRead, _SysReset, _SetAccessConditionMask2, _SetAccessConditionMask1, _SetAccessConditionMask0, _SetKey3, _SetKey2, _SetKey1, _FactoryReset)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[HostSecurityAccessConditionBits] = None) -> Optional[HostSecurityAccessConditionBits]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'`')
        _send_buffer.write(b'\x86')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[HostSecurityAccessConditionBits, HostSecurityAccessConditionBits_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'`')
        _send_buffer.write(b'\x86')
        if isinstance(Value, dict):
            Value = HostSecurityAccessConditionBits(**Value)
        Value_int = 0
        Value_int |= (int(Value.HostToHostAccess) & 0b1) << 28
        Value_int |= (int(Value.AutoreadAccess) & 0b1) << 27
        Value_int |= (int(Value.CryptoAccess) & 0b1) << 26
        Value_int |= (int(Value.Bf2Upload) & 0b1) << 25
        Value_int |= (int(Value.ExtendedAccess) & 0b1) << 24
        Value_int |= (int(Value.FlashFileSystemWrite) & 0b1) << 23
        Value_int |= (int(Value.FlashFileSystemRead) & 0b1) << 22
        Value_int |= (int(Value.RtcWrite) & 0b1) << 21
        Value_int |= (int(Value.VhlExchangeapdu) & 0b1) << 20
        Value_int |= (int(Value.VhlFormat) & 0b1) << 19
        Value_int |= (int(Value.VhlWrite) & 0b1) << 18
        Value_int |= (int(Value.VhlRead) & 0b1) << 17
        Value_int |= (int(Value.VhlSelect) & 0b1) << 16
        Value_int |= (int(Value.ExtSamAccess) & 0b1) << 15
        Value_int |= (int(Value.HfLowlevelAccess) & 0b1) << 14
        Value_int |= (int(Value.GuiAccess) & 0b1) << 13
        Value_int |= (int(Value.IoPortWrite) & 0b1) << 12
        Value_int |= (int(Value.IoPortRead) & 0b1) << 11
        Value_int |= (int(Value.ConfigReset) & 0b1) << 10
        Value_int |= (int(Value.ConfigWrite) & 0b1) << 9
        Value_int |= (int(Value.ConfigRead) & 0b1) << 8
        Value_int |= (int(Value.SysReset) & 0b1) << 7
        Value_int |= (int(Value.SetAccessConditionMask2) & 0b1) << 6
        Value_int |= (int(Value.SetAccessConditionMask1) & 0b1) << 5
        Value_int |= (int(Value.SetAccessConditionMask0) & 0b1) << 4
        Value_int |= (int(Value.SetKey3) & 0b1) << 3
        Value_int |= (int(Value.SetKey2) & 0b1) << 2
        Value_int |= (int(Value.SetKey1) & 0b1) << 1
        Value_int |= (int(Value.FactoryReset) & 0b1) << 0
        _send_buffer.write(Value_int.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[HostSecurityAccessConditionBits, HostSecurityAccessConditionBits_Dict]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_AccessConditionBitsAlt(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x61
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'a')
        self.process_frame(_send_buffer.getvalue())
class Protocols_AccessConditionBitsAlt_TcpMaintenanceMode(ConfigValue):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0x61
    ValueKey: ClassVar[int] = 0x86
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    ValueKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'a')
        _send_buffer.write(b'\x86')
        self.process_frame(_send_buffer.getvalue())
    def parse_frame(self, frame: bytes) -> HostSecurityAccessConditionBits:
        _recv_buffer = BytesIO(frame)
        _Value_int = safe_read_int_from_buffer(_recv_buffer, 4)
        _HostToHostAccess = bool((_Value_int >> 28) & 0b1)
        _AutoreadAccess = bool((_Value_int >> 27) & 0b1)
        _CryptoAccess = bool((_Value_int >> 26) & 0b1)
        _Bf2Upload = bool((_Value_int >> 25) & 0b1)
        _ExtendedAccess = bool((_Value_int >> 24) & 0b1)
        _FlashFileSystemWrite = bool((_Value_int >> 23) & 0b1)
        _FlashFileSystemRead = bool((_Value_int >> 22) & 0b1)
        _RtcWrite = bool((_Value_int >> 21) & 0b1)
        _VhlExchangeapdu = bool((_Value_int >> 20) & 0b1)
        _VhlFormat = bool((_Value_int >> 19) & 0b1)
        _VhlWrite = bool((_Value_int >> 18) & 0b1)
        _VhlRead = bool((_Value_int >> 17) & 0b1)
        _VhlSelect = bool((_Value_int >> 16) & 0b1)
        _ExtSamAccess = bool((_Value_int >> 15) & 0b1)
        _HfLowlevelAccess = bool((_Value_int >> 14) & 0b1)
        _GuiAccess = bool((_Value_int >> 13) & 0b1)
        _IoPortWrite = bool((_Value_int >> 12) & 0b1)
        _IoPortRead = bool((_Value_int >> 11) & 0b1)
        _ConfigReset = bool((_Value_int >> 10) & 0b1)
        _ConfigWrite = bool((_Value_int >> 9) & 0b1)
        _ConfigRead = bool((_Value_int >> 8) & 0b1)
        _SysReset = bool((_Value_int >> 7) & 0b1)
        _SetAccessConditionMask2 = bool((_Value_int >> 6) & 0b1)
        _SetAccessConditionMask1 = bool((_Value_int >> 5) & 0b1)
        _SetAccessConditionMask0 = bool((_Value_int >> 4) & 0b1)
        _SetKey3 = bool((_Value_int >> 3) & 0b1)
        _SetKey2 = bool((_Value_int >> 2) & 0b1)
        _SetKey1 = bool((_Value_int >> 1) & 0b1)
        _FactoryReset = bool((_Value_int >> 0) & 0b1)
        _Value = HostSecurityAccessConditionBits(_HostToHostAccess, _AutoreadAccess, _CryptoAccess, _Bf2Upload, _ExtendedAccess, _FlashFileSystemWrite, _FlashFileSystemRead, _RtcWrite, _VhlExchangeapdu, _VhlFormat, _VhlWrite, _VhlRead, _VhlSelect, _ExtSamAccess, _HfLowlevelAccess, _GuiAccess, _IoPortWrite, _IoPortRead, _ConfigReset, _ConfigWrite, _ConfigRead, _SysReset, _SetAccessConditionMask2, _SetAccessConditionMask1, _SetAccessConditionMask0, _SetKey3, _SetKey2, _SetKey1, _FactoryReset)
        _additional_data = _recv_buffer.read()
        if _additional_data:
            raise PayloadTooLongError(_additional_data)
        return _Value
    def get(self, default: Optional[HostSecurityAccessConditionBits] = None) -> Optional[HostSecurityAccessConditionBits]:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x00')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'a')
        _send_buffer.write(b'\x86')
        try:
            response_frame = self.process_frame(_send_buffer.getvalue())
        except KeyError:
            return default
        return self.parse_frame(response_frame)
    def build_frame(self, Value: Union[HostSecurityAccessConditionBits, HostSecurityAccessConditionBits_Dict]) -> bytes:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'a')
        _send_buffer.write(b'\x86')
        if isinstance(Value, dict):
            Value = HostSecurityAccessConditionBits(**Value)
        Value_int = 0
        Value_int |= (int(Value.HostToHostAccess) & 0b1) << 28
        Value_int |= (int(Value.AutoreadAccess) & 0b1) << 27
        Value_int |= (int(Value.CryptoAccess) & 0b1) << 26
        Value_int |= (int(Value.Bf2Upload) & 0b1) << 25
        Value_int |= (int(Value.ExtendedAccess) & 0b1) << 24
        Value_int |= (int(Value.FlashFileSystemWrite) & 0b1) << 23
        Value_int |= (int(Value.FlashFileSystemRead) & 0b1) << 22
        Value_int |= (int(Value.RtcWrite) & 0b1) << 21
        Value_int |= (int(Value.VhlExchangeapdu) & 0b1) << 20
        Value_int |= (int(Value.VhlFormat) & 0b1) << 19
        Value_int |= (int(Value.VhlWrite) & 0b1) << 18
        Value_int |= (int(Value.VhlRead) & 0b1) << 17
        Value_int |= (int(Value.VhlSelect) & 0b1) << 16
        Value_int |= (int(Value.ExtSamAccess) & 0b1) << 15
        Value_int |= (int(Value.HfLowlevelAccess) & 0b1) << 14
        Value_int |= (int(Value.GuiAccess) & 0b1) << 13
        Value_int |= (int(Value.IoPortWrite) & 0b1) << 12
        Value_int |= (int(Value.IoPortRead) & 0b1) << 11
        Value_int |= (int(Value.ConfigReset) & 0b1) << 10
        Value_int |= (int(Value.ConfigWrite) & 0b1) << 9
        Value_int |= (int(Value.ConfigRead) & 0b1) << 8
        Value_int |= (int(Value.SysReset) & 0b1) << 7
        Value_int |= (int(Value.SetAccessConditionMask2) & 0b1) << 6
        Value_int |= (int(Value.SetAccessConditionMask1) & 0b1) << 5
        Value_int |= (int(Value.SetAccessConditionMask0) & 0b1) << 4
        Value_int |= (int(Value.SetKey3) & 0b1) << 3
        Value_int |= (int(Value.SetKey2) & 0b1) << 2
        Value_int |= (int(Value.SetKey1) & 0b1) << 1
        Value_int |= (int(Value.FactoryReset) & 0b1) << 0
        _send_buffer.write(Value_int.to_bytes(length=4, byteorder='big'))
        return _send_buffer.getvalue()
    def __call__(self, Value: Union[HostSecurityAccessConditionBits, HostSecurityAccessConditionBits_Dict]) -> None:
        frame = self.build_frame(Value=Value)
        self.process_frame(frame)
class Protocols_AccessConditionBitsAlt2(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0xE2
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\xe2')
        self.process_frame(_send_buffer.getvalue())
class Protocols_AccessConditionBitsAlt3(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0xE3
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\xe3')
        self.process_frame(_send_buffer.getvalue())
class Protocols_NetworkBackup(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0xB9
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\xb9')
        self.process_frame(_send_buffer.getvalue())
class Protocols_BrpTcpBackup(ConfigBase):
    MasterKey: ClassVar[int] = 0x01
    SubKey: ClassVar[int] = 0xBA
    MasterKeyCount: ClassVar[int] = 1
    SubKeyCount: ClassVar[int] = 1
    def reset(self, ) -> None:
        _send_buffer = BytesIO()
        _send_buffer.write(b'\x02')
        _send_buffer.write(b'\x01')
        _send_buffer.write(b'\xba')
        self.process_frame(_send_buffer.getvalue())
class InternalConfigAccessor(PublicConfigAccessor):
    @property
    def Scripts_Events_OnKeypressF(self) -> Scripts_Events_OnKeypressF:
        """
        A function key on the keyboard (if present) was pressed.
        """
        return Scripts_Events_OnKeypressF(self)
    @property
    def Scripts_Events_OnKeypressEsc(self) -> Scripts_Events_OnKeypressEsc:
        """
        The Escape key on the keyboard (if present) was pressed.
        """
        return Scripts_Events_OnKeypressEsc(self)
    @property
    def Scripts_Events_OnKeypressClear(self) -> Scripts_Events_OnKeypressClear:
        """
        The C (clear) key on the keyboard (if present) was pressed.
        """
        return Scripts_Events_OnKeypressClear(self)
    @property
    def Scripts_Events_OnKeypressMenu(self) -> Scripts_Events_OnKeypressMenu:
        """
        The menu key on the keyboard (if present) was pressed.
        """
        return Scripts_Events_OnKeypressMenu(self)
    @property
    def Scripts_Events_OnKeypressOk(self) -> Scripts_Events_OnKeypressOk:
        """
        The Ok key on the keyboard (if present) was pressed.
        """
        return Scripts_Events_OnKeypressOk(self)
    @property
    def Scripts_Events_OnKeypressStar(self) -> Scripts_Events_OnKeypressStar:
        """
        The '*' key on the keyboard (if present) was pressed.
        """
        return Scripts_Events_OnKeypressStar(self)
    @property
    def Scripts_Events_OnKeypressSharp(self) -> Scripts_Events_OnKeypressSharp:
        """
        The '#' key on the keyboard (if present) was pressed.
        """
        return Scripts_Events_OnKeypressSharp(self)
    @property
    def Scripts_Events_OnCustomEvent(self) -> Scripts_Events_OnCustomEvent:
        """
        A custom event has been raised. The meaning of the event depends on the firmware.
        """
        return Scripts_Events_OnCustomEvent(self)
    @property
    def Scripts_Events_OnNetworkBooted(self) -> Scripts_Events_OnNetworkBooted:
        """
        This event will be fired when the network stack has been booted.
        """
        return Scripts_Events_OnNetworkBooted(self)
    @property
    def Scripts_Events_OnLinkedNoPort(self) -> Scripts_Events_OnLinkedNoPort:
        """
        This event will be fired when the ethernet reader has no links on its network interfaces.
        """
        return Scripts_Events_OnLinkedNoPort(self)
    @property
    def Scripts_Events_OnLinkedNetworkPort(self) -> Scripts_Events_OnLinkedNetworkPort:
        """
        This event will be fired when the ethernet reader has established a link on port 1 while port 2 is not linked or not available in hardware.
        """
        return Scripts_Events_OnLinkedNetworkPort(self)
    @property
    def Scripts_Events_OnLinkedDevicePort(self) -> Scripts_Events_OnLinkedDevicePort:
        """
        This event will be fired when the ethernet reader has established a link on port 2 while port 1 is not linked.
        """
        return Scripts_Events_OnLinkedDevicePort(self)
    @property
    def Scripts_Events_OnLinkedAllPorts(self) -> Scripts_Events_OnLinkedAllPorts:
        """
        This event will be fired when the ethernet reader has established a link on all available ports.
        """
        return Scripts_Events_OnLinkedAllPorts(self)
    @property
    def Scripts_Events_OnWaitingForDHCP(self) -> Scripts_Events_OnWaitingForDHCP:
        """
        This event will be fired when the ethernet reader has started the DHCP client.
        """
        return Scripts_Events_OnWaitingForDHCP(self)
    @property
    def Scripts_Events_OnSearchingForHost(self) -> Scripts_Events_OnSearchingForHost:
        """
        This event will be fired when the ethernet reader has acquired an IP address starting to search for a host.
        """
        return Scripts_Events_OnSearchingForHost(self)
    @property
    def Scripts_Events_OnUDPConnectFailure(self) -> Scripts_Events_OnUDPConnectFailure:
        """
        This event will be fired when the ethernet reader has received an UDP introspection packet, but the connection trial to the received host failed.
        """
        return Scripts_Events_OnUDPConnectFailure(self)
    @property
    def Scripts_Events_OnHostConnectFailure(self) -> Scripts_Events_OnHostConnectFailure:
        """
        This event will be fired when a connection trial to the configured host failed.
        """
        return Scripts_Events_OnHostConnectFailure(self)
    @property
    def Scripts_Events_OnStaticIPFailure(self) -> Scripts_Events_OnStaticIPFailure:
        """
        This event will be fired when the ethernet reader has detected an IP conflict: the assigned IP address is already in use by another network device.
        """
        return Scripts_Events_OnStaticIPFailure(self)
    @property
    def Scripts_Events_OnHostFound(self) -> Scripts_Events_OnHostFound:
        """
        This event will be fired when the ethernet reader has connected to the host successfully for the first time.
        """
        return Scripts_Events_OnHostFound(self)
    @property
    def Scripts_Events_OnBleNoAlert(self) -> Scripts_Events_OnBleNoAlert:
        """
        The reader has received a "No Alert" message via the BLE service _Immediate Alert_. 
        
        The _default action_ for this event is to disable the blue LED. 
        
        **The Immediate Alert service is only active if the Mobile Card Emulation (MCE) functionality is enabled.**
        
        **If you configure a custom action, it will replace the default action. To perform _both actions_ , you need to run the DefaultAction command.**
        """
        return Scripts_Events_OnBleNoAlert(self)
    @property
    def Scripts_Events_OnBleMildAlert(self) -> Scripts_Events_OnBleMildAlert:
        """
        The reader has received a "Mild Alert" message via the BLE service _Immediate Alert_. 
        
        The _default action_ for this event is to enable the blue LED. 
        
        **The Immediate Alert service is only active if the Mobile Card Emulation (MCE) functionality is enabled.**
        
        **If you configure a custom action, it will replace the default action. To perform _both actions_ , you need to run the DefaultAction command.**
        """
        return Scripts_Events_OnBleMildAlert(self)
    @property
    def Scripts_Events_OnBleHighAlert(self) -> Scripts_Events_OnBleHighAlert:
        """
        The reader has received a "High Alert" message via the BLE service _Immediate Alert_. 
        
        The _default action_ for this event is to toggle the blue LED every 500 ms. 
        
        **The Immediate Alert service is only active if the Mobile Card Emulation (MCE) functionality is enabled.**
        
        **If you configure a custom action, it will replace the default action. To perform _both actions_ , you need to run the DefaultAction command.**
        """
        return Scripts_Events_OnBleHighAlert(self)
    @property
    def Device_VhlSettings(self) -> Device_VhlSettings:
        """
        **These values should not be used any more! They were replaced by Project/VhlSettings .**
        
        These value are usually set implicitly when activating the corresponding ConfigEditor Filter. For details see EQT-368.
        """
        return Device_VhlSettings(self)
    @property
    def Device_VhlSettings_ScanCardFamilies(self) -> Device_VhlSettings_ScanCardFamilies:
        """
        This value is replaced by Project/VhlSettings/ScanCardFamilies. Please refer to that value for further details.
        """
        return Device_VhlSettings_ScanCardFamilies(self)
    @property
    def Device_VhlSettings_ForceReselect(self) -> Device_VhlSettings_ForceReselect:
        """
        Setting this value to True enforces a Reselect on every VHLSelect.
        """
        return Device_VhlSettings_ForceReselect(self)
    @property
    def Device_VhlSettings_DelayRequestATS(self) -> Device_VhlSettings_DelayRequestATS:
        """
        Specifies the delay in ms that shall be waited after detecting an ISO14443 card and before requesting its ATS (Answer To Select).
        """
        return Device_VhlSettings_DelayRequestATS(self)
    @property
    def Device_VhlSettings_DelayPerformPPS(self) -> Device_VhlSettings_DelayPerformPPS:
        """
        Specifies the delay in ms that shall be waited after receiving the ATS of an ISO14443 card and before performing its PPS.
        """
        return Device_VhlSettings_DelayPerformPPS(self)
    @property
    def Device_VhlSettings_MaxBaudrateIso14443A(self) -> Device_VhlSettings_MaxBaudrateIso14443A:
        """
        When VHLSelect / autoread detects a Iso14443/A card it negotiates the send and the receive baudrate automatically. Usually it tries to communicate as fast as possible (that means as fast as the card is supporting). If the performance shall be limited (i.e. due to HF instabilities) this value can be used to set a Maximum value for DSI (=reader to card baudrate) and DRI (=card to reader baudrate).
        """
        return Device_VhlSettings_MaxBaudrateIso14443A(self)
    @property
    def Device_VhlSettings_MaxBaudrateIso14443B(self) -> Device_VhlSettings_MaxBaudrateIso14443B:
        """
        When VHLSelect / autoread detects a Iso14443/B card it negotiates the send and the receive baudrate automatically. Usually it tries to communicate as fast as possible (that means as fast as the card is supporting). If the performance shall be limited (i.e. due to HF instabilities) this value can be used to set a Maximum value for DSI (=reader to card baudrate) and DRI (=card to reader baudrate).
        """
        return Device_VhlSettings_MaxBaudrateIso14443B(self)
    @property
    def Device_VhlSettings125Khz(self) -> Device_VhlSettings125Khz:
        """
        **These values should not be used any more! They were replaced by Project/VhlSettings125Khz .**
        
        These value are usually set implicitly when activating the corresponding ConfigEditor Filter. For details see EQT-368.
        """
        return Device_VhlSettings125Khz(self)
    @property
    def Device_VhlSettings125Khz_ScanCardTypes(self) -> Device_VhlSettings125Khz_ScanCardTypes:
        """
        Legacy value, please use Project/VhlSettings125Khz/ScanCardTypesPart1 and Project/VhlSettings125Khz/ScanCardTypesPart2 instead.
        """
        return Device_VhlSettings125Khz_ScanCardTypes(self)
    @property
    def Device_VhlSettings125Khz_ModulationType(self) -> Device_VhlSettings125Khz_ModulationType:
        """
        Legacy value, please use Project/VhlSettings125Khz/TTFModType instead.
        """
        return Device_VhlSettings125Khz_ModulationType(self)
    @property
    def Device_VhlSettings125Khz_Baud(self) -> Device_VhlSettings125Khz_Baud:
        """
        Legacy value, please use Project/VhlSettings125Khz/TTFBaudrate instead.
        """
        return Device_VhlSettings125Khz_Baud(self)
    @property
    def Device_VhlSettings125Khz_TTFHeaderLength(self) -> Device_VhlSettings125Khz_TTFHeaderLength:
        """
        Specifies the pattern length in bit, the reader searches for. Legacy value, please use Project/VhlSettings125Khz/TTFHeaderLength instead.
        """
        return Device_VhlSettings125Khz_TTFHeaderLength(self)
    @property
    def Device_VhlSettings125Khz_TTFHeader(self) -> Device_VhlSettings125Khz_TTFHeader:
        """
        Pattern which has to match. Legacy value, please use Project/VhlSettings125Khz/TTFHeader instead.
        """
        return Device_VhlSettings125Khz_TTFHeader(self)
    @property
    def Device_VhlSettings125Khz_TTFDataLength(self) -> Device_VhlSettings125Khz_TTFDataLength:
        """
        Card data length (includes also Pattern Length). Legacy value, please use Project/VhlSettings125Khz/TTFDataLength instead.
        """
        return Device_VhlSettings125Khz_TTFDataLength(self)
    @property
    def Device_VhlSettings125Khz_TTFOkCounter(self) -> Device_VhlSettings125Khz_TTFOkCounter:
        """
        Number of consecutive successfully reads until a card searched by a pattern is reported as detected by VHL. Legacy value, please use Project/VhlSettings125Khz/TTFOkCounter instead.
        """
        return Device_VhlSettings125Khz_TTFOkCounter(self)
    @property
    def Device_VhlSettings125Khz_IndaspDecode(self) -> Device_VhlSettings125Khz_IndaspDecode:
        """
        Legacy value, please use Project/VhlSettings125Khz/IndaspDecode instead.
        """
        return Device_VhlSettings125Khz_IndaspDecode(self)
    @property
    def Device_VhlSettings125Khz_IndaspParityCheck(self) -> Device_VhlSettings125Khz_IndaspParityCheck:
        """
        Legacy value, please use Project/VhlSettings125kHz/IndaspParityCheck instead.
        """
        return Device_VhlSettings125Khz_IndaspParityCheck(self)
    @property
    def Device_VhlSettings125Khz_IndaspOkCounter(self) -> Device_VhlSettings125Khz_IndaspOkCounter:
        """
        Legacy value, please use Project/VhlSettings125Khz/IndaspDecode instead.
        """
        return Device_VhlSettings125Khz_IndaspOkCounter(self)
    @property
    def Device_VhlSettings125Khz_AwidOkCounter(self) -> Device_VhlSettings125Khz_AwidOkCounter:
        """
        Legacy value, please use Project/VhlSettings125Khz/AwidOkCounter instead.
        """
        return Device_VhlSettings125Khz_AwidOkCounter(self)
    @property
    def Device_VhlSettings125Khz_HidProxOkCounter(self) -> Device_VhlSettings125Khz_HidProxOkCounter:
        """
        Legacy value, please use Project/VhlSettings125Khz/HidProxOkCounter instead.
        """
        return Device_VhlSettings125Khz_HidProxOkCounter(self)
    @property
    def Device_Boot_ConfigCardState(self) -> Device_Boot_ConfigCardState:
        """
        When a ConfigCard is presented, the reader stores the result of the reconfiguration process in this variable. After resetting the device this variable is checked by firmware and the corresponding user feedback is done.
        """
        return Device_Boot_ConfigCardState(self)
    @property
    def Device_Boot_LegicAdvantInitialization(self) -> Device_Boot_LegicAdvantInitialization:
        """
        Specify if powerup of legic advant firmware shall be delayed until the legic advant functionality is completely initialized. This may take up to 2 seconds in worst case (depending on hardware).
        """
        return Device_Boot_LegicAdvantInitialization(self)
    @property
    def Device_Run_DeviceName(self) -> Device_Run_DeviceName:
        """
        This value was used to store the name of the device settings (is replaced by Custom/AdminData/DeviceSettingsName)
        """
        return Device_Run_DeviceName(self)
    @property
    def Device_Run_ProjectName(self) -> Device_Run_ProjectName:
        """
        This value was used to store the name of the project settings (is replaced by Custom/AdminData/DeviceSettingsName)
        """
        return Device_Run_ProjectName(self)
    @property
    def Device_Run_CardReadFailureLogging(self) -> Device_Run_CardReadFailureLogging:
        """
        To get more information about the cause of failed card reads in autoread mode this value can be set. The reader will then collect internal data and report it via AR.GetMessage. This data can be used by Baltech to analyze the reason of failure.
        """
        return Device_Run_CardReadFailureLogging(self)
    @property
    def Device_Run_FirstVhlRc500Key(self) -> Device_Run_FirstVhlRc500Key:
        """
        Usually Mifare Classic VHL files are transferring their keys from the configuration into the RC500 eeprom for security reasons. This value specifies the begin of the key address range the VHL subsystem may occupy in the RC.
        """
        return Device_Run_FirstVhlRc500Key(self)
    @property
    def Device_Run_BusAdressByBACLegacy(self) -> Device_Run_BusAdressByBACLegacy:
        """
        If the bus address of the reader is set via a BALTECH AdrCard (BAC), the address is stored within this configuration value. This address value works across all bus protocols - no DIP switch required. 
        
        This value is only for internal use. With firmware 1100 v2.20.00, it has been replaced by BusAdressByBAC32Bit; however, to maintain compatibility with earlier versions, it is still supported.
        """
        return Device_Run_BusAdressByBACLegacy(self)
    @property
    def Device_Run_ConfigCardMifareKeyBackup(self) -> Device_Run_ConfigCardMifareKeyBackup:
        """
        Internal Backup of Device/Run/ConfigCardMifareKey.
        """
        return Device_Run_ConfigCardMifareKeyBackup(self)
    @property
    def Device_Run_CustomerKeyBackup(self) -> Device_Run_CustomerKeyBackup:
        """
        Internal Backup of Device/Run/ConfigCardEncryptKey.
        """
        return Device_Run_CustomerKeyBackup(self)
    @property
    def Device_Run_ConfigCardDesfireKeyBackup(self) -> Device_Run_ConfigCardDesfireKeyBackup:
        """
        Internal Backup of Device/Run/ConfigCardDesfireKey.
        """
        return Device_Run_ConfigCardDesfireKeyBackup(self)
    @property
    def Device_Run_UsbSuspendMode(self) -> Device_Run_UsbSuspendMode:
        """
        Enables or disables USB suspend mode.
        """
        return Device_Run_UsbSuspendMode(self)
    @property
    def Device_Rgb(self) -> Device_Rgb:
        """
        This key contains RGB LED related settings.
        """
        return Device_Rgb(self)
    @property
    def Device_Rgb_MaximizeIntensity(self) -> Device_Rgb_MaximizeIntensity:
        """
        This value allows you to disable the hardware-dependent intensity compensation values to gain the maximum possible RGB LED intensity.
        """
        return Device_Rgb_MaximizeIntensity(self)
    @property
    def Device_CryptoKey(self) -> Device_CryptoKey:
        """
        Keys container used by the crypto manager for crypto operations.
        """
        return Device_CryptoKey(self)
    @property
    def Device_CryptoKey_Entry(self) -> Device_CryptoKey_Entry:
        """
        Key entry which contains a key and its according CryptoAlgorithm with KeyAccessRights used by the crypto manager.
        """
        return Device_CryptoKey_Entry(self)
    @property
    def Device_MifareClassicKey(self) -> Device_MifareClassicKey:
        """
        MIFARE Classic key storage
        """
        return Device_MifareClassicKey(self)
    @property
    def Device_MifareClassicKey_Entry(self) -> Device_MifareClassicKey_Entry:
        """
        Storage entry containing a MIFARE Classic key
        """
        return Device_MifareClassicKey_Entry(self)
    @property
    def Device_HostSecurity_PrivateKey(self) -> Device_HostSecurity_PrivateKey:
        """
        Private key of the reader (PKI).
        """
        return Device_HostSecurity_PrivateKey(self)
    @property
    def Device_HostSecurity_PublicKey(self) -> Device_HostSecurity_PublicKey:
        """
        Public key of the reader (PKI).
        """
        return Device_HostSecurity_PublicKey(self)
    @property
    def Device_HostSecurity_HostRootCertSubjectName(self) -> Device_HostSecurity_HostRootCertSubjectName:
        """
        If PKI is enabled for a specific security level, this value must contain the ASN.1 DER encoded tag, that represents the distuingished subject name of the X503 host root certificate. The reader creates the host root certificate from this value, HostRootCertPubKey and HostRootCertSnr to verify the host certificate chain. 
        
        Please keep in mind, that the issuer name is the same as the subject name of the certificate. Thus the issuer name needs not to be stored separately in the configuration. 
        
        **RootCertSubjectName[0] must not be used, since security level 0 works unencrypted.**
        """
        return Device_HostSecurity_HostRootCertSubjectName(self)
    @property
    def Device_HostSecurity_HostRootCertPubKey(self) -> Device_HostSecurity_HostRootCertPubKey:
        """
        If PKI is enabled for a specific security level, this value must contain the ASN.1 DER encoded tag, that represents the public key of the X503 host root certificate. The reader creates the host root certificate from this value, HostRootCertSubjectName and HostRootCertSnr to verify the host certificate chain. 
        
        **Only the raw bits are stored in this field. The crypto algorithms have to be always ECC-P256 with SHA256.**
        
        **RootCertPubKey[0] must not be used, since security level 0 works unencrypted.**
        """
        return Device_HostSecurity_HostRootCertPubKey(self)
    @property
    def Device_HostSecurity_HostRootCertSnr(self) -> Device_HostSecurity_HostRootCertSnr:
        """
        If PKI is enabled for a specific security level, this value must contain the ASN.1 DER encoded tag, that represents the serial number of the X503 host root certificate. The reader creates the host root certificate from this value, HostRootCertSubjectName and HostRootCertPubKey to verify the host certificate chain. 
        
        **RootCertSnr[0] must not be used, since security level 0 works unencrypted.**
        """
        return Device_HostSecurity_HostRootCertSnr(self)
    @property
    def Device_HostSecurity_ReaderCertSnr(self) -> Device_HostSecurity_ReaderCertSnr:
        """
        If PKI is enabled for a specific security level, this value must contain the ASN.1 DER encoded tag, that represents the serial number of the X503 certificate of the reader. 
        
        **ReaderCertSnr[0] must not be used, since security level 0 works unencrypted.**
        """
        return Device_HostSecurity_ReaderCertSnr(self)
    @property
    def Device_HostSecurity_ReaderCertIssuer(self) -> Device_HostSecurity_ReaderCertIssuer:
        """
        If PKI is enabled for a specific security level, this value must contain the ASN.1 DER encoded tag, that represents the distinguished issuer name of the X503 certificate of the reader. 
        
        **ReaderCertIssuer[0] must not be used, since security level 0 works unencrypted.**
        """
        return Device_HostSecurity_ReaderCertIssuer(self)
    @property
    def Device_HostSecurity_ReaderCertValidity(self) -> Device_HostSecurity_ReaderCertValidity:
        """
        If PKI is enabled for a specific security level, this value must contain the ASN.1 DER encoded tag, that represents the time range, in which this certificate is valid. 
        
        **ReaderCertValidity[0] must not be used, since security level 0 works unencrypted.**
        """
        return Device_HostSecurity_ReaderCertValidity(self)
    @property
    def Device_HostSecurity_ReaderCertSignature(self) -> Device_HostSecurity_ReaderCertSignature:
        """
        If PKI is enabled for a specific security level, this value must contain the ASN.1 DER encoded tag, that represents the signature created by the issuer over the whole reader certificate. 
        
        **ReaderCertValidity[0] must not be used, since security level 0 works unencrypted.**
        """
        return Device_HostSecurity_ReaderCertSignature(self)
    @property
    def Device_HostSecurity_AccessConditionMaskInternal(self) -> Device_HostSecurity_AccessConditionMaskInternal:
        """
        These values define the internal storage of the access condition bitmask for each security level. 
        
        **These values are used internally by the firmware and can't be accessed directly. Use AccessConditionMask .**
        """
        return Device_HostSecurity_AccessConditionMaskInternal(self)
    @property
    def Device_HostSecurity_KeyInternal(self) -> Device_HostSecurity_KeyInternal:
        """
        These values defines the internal storage of the authentication key for each security Level. 
        
        **These values are used internally by the firmware and can't be accessed directly. Use Key instead.**
        """
        return Device_HostSecurity_KeyInternal(self)
    @property
    def Device_Statistics(self) -> Device_Statistics:
        """
        This key contains values that are only for Baltech internal use. They will be set on firmware failure to log unexpected states. Must not be set/cleared by customers. 
        
        Device/Statistics/FirmwareId & Device/Statistics/FirmwareRelease are identifing the Firmware that was the cause of the failure (may be different from current firmware)
        """
        return Device_Statistics(self)
    @property
    def Device_Statistics_FirmwareId(self) -> Device_Statistics_FirmwareId:
        """
        Contains the ID of the firmware (e.g. 1100 for ID-engine Z) that produced the logged errors. When an error is detected and this value does not correspond to the current firwmare ID, all statistics counters are reset.
        """
        return Device_Statistics_FirmwareId(self)
    @property
    def Device_Statistics_FirmwareRelease(self) -> Device_Statistics_FirmwareRelease:
        """
        Contains the firmware version that produced the logged errors. When an error is detected and this value does not correspond to the current firwmare ID, all statistics counters are reset.
        """
        return Device_Statistics_FirmwareRelease(self)
    @property
    def Device_Statistics_WatchdogResetCount(self) -> Device_Statistics_WatchdogResetCount:
        """
        Contains the number of watchdog resets caused by the firmware that is specified in the FirmwareId and FirmwareRelease values.
        """
        return Device_Statistics_WatchdogResetCount(self)
    @property
    def Device_Statistics_StackOverflowCount(self) -> Device_Statistics_StackOverflowCount:
        """
        Contains the number of stack overflows caused by the firmware that is specified in the FirmwareId and FirmwareRelease values.
        """
        return Device_Statistics_StackOverflowCount(self)
    @property
    def Device_Statistics_StackOverflowTaskAddress(self) -> Device_Statistics_StackOverflowTaskAddress:
        """
        Contains the address of the Task that caused the last stackoverflow. To assign this address to a name simply search for this hexvalue in the listingfile.
        """
        return Device_Statistics_StackOverflowTaskAddress(self)
    @property
    def Device_Statistics_BrownoutResetCount(self) -> Device_Statistics_BrownoutResetCount:
        """
        Contains the number of brownouts registered by the firmware that is specified in the FirmwareId and FirmwareRelease values.
        """
        return Device_Statistics_BrownoutResetCount(self)
    @property
    def Device_Statistics_KeypadResetCount(self) -> Device_Statistics_KeypadResetCount:
        """
        Contains the number of unintended keypad controller resets registered by the firmware that is specified in the FirmwareId and FirmwareRelease values.
        """
        return Device_Statistics_KeypadResetCount(self)
    @property
    def Device_Statistics_KeypadCommErrorCount(self) -> Device_Statistics_KeypadCommErrorCount:
        """
        Contains the number of communication errors with the keypad controller registered by the firmware that is specified in the FirmwareId and FirmwareRelease values.
        """
        return Device_Statistics_KeypadCommErrorCount(self)
    @property
    def Device_Statistics_AccessRestrictedTaskOverflowResetCount(self) -> Device_Statistics_AccessRestrictedTaskOverflowResetCount:
        """
        Contains the number of resets caused due to an overflow of access-restricted tasks registered by the firmware that is specified in the FirmwareId and FirmwareRelease values.
        """
        return Device_Statistics_AccessRestrictedTaskOverflowResetCount(self)
    @property
    def Device_Statistics_BleResetCount(self) -> Device_Statistics_BleResetCount:
        """
        Contains the number of unintended BLE controller resets registered by the firmware that is specified in the FirmwareId and FirmwareRelease values.
        """
        return Device_Statistics_BleResetCount(self)
    @property
    def Custom_Crypto(self) -> Custom_Crypto:
        """
        List of skipjack keys that can be used by the Crypto commands to encrypt-/decrypt user data. The primary purpose of these keys is to encode configurations. 
        
        **Must not be mixed up with Host Interface Security or with Desfire Crypto / Mifare Plus Crypto.**
        """
        return Custom_Crypto(self)
    @property
    def Custom_Crypto_Key(self) -> Custom_Crypto_Key:
        """
        Specifies a list of keys that can be referred by the crypro commands via index.
        """
        return Custom_Crypto_Key(self)
    @property
    def Custom_AdminData_MasterCardNoRef(self) -> Custom_AdminData_MasterCardNoRef:
        """
        This Mastercardnumber refers to a MasterCard that has to be used to create configuration cards (or encrypted .bec files) from this configuration. The default value of 1 means that no custom Mastercard is used but the Baltech standard mastercard.
        """
        return Custom_AdminData_MasterCardNoRef(self)
    @property
    def Custom_AdminData_MasterCardNameRef(self) -> Custom_AdminData_MasterCardNameRef:
        """
        This field contains the corresponding name of the mastercard (see MasterCardNoRef)
        """
        return Custom_AdminData_MasterCardNameRef(self)
    @property
    def Custom_AdminData_MasterCardNo(self) -> Custom_AdminData_MasterCardNo:
        """
        Must only be set if this _is_ a MasterCard. It must not contain any configuration components other than a VHL file with ID #240 and crypto keys for encrypting the configuration. This ID is the unique identification of the mastercard and has to be referred by configurations via MasterCardNoRef)
        """
        return Custom_AdminData_MasterCardNo(self)
    @property
    def Custom_AdminData_MasterCardName(self) -> Custom_AdminData_MasterCardName:
        """
        This field contains the corresponding name of the mastercard (see MasterCardNo)
        """
        return Custom_AdminData_MasterCardName(self)
    @property
    def Custom_AdminData_DeviceSettingsTemplateBased(self) -> Custom_AdminData_DeviceSettingsTemplateBased:
        """
        This value is not used any more
        """
        return Custom_AdminData_DeviceSettingsTemplateBased(self)
    @property
    def Custom_AdminData_ProjectSettingsTemplateBased(self) -> Custom_AdminData_ProjectSettingsTemplateBased:
        """
        This value is not used any more
        """
        return Custom_AdminData_ProjectSettingsTemplateBased(self)
    @property
    def Custom_AdminData_UniqueDeviceName(self) -> Custom_AdminData_UniqueDeviceName:
        """
        This value contains a unique ASCII-string that identifies the device containing this value. It is currently only used for Ethernet devices that support SLP. This name can be retrieved as SLP attribute.
        """
        return Custom_AdminData_UniqueDeviceName(self)
    @property
    def Custom_AdminData_DraftFlag(self) -> Custom_AdminData_DraftFlag:
        """
        The ConfigEditor sets this value (without any content) for configurations that are in draft mode. If this value is not defined, the configuration is released.
        """
        return Custom_AdminData_DraftFlag(self)
    @property
    def Custom_AdminData_BaltechConfigID(self) -> Custom_AdminData_BaltechConfigID:
        """
        This value contains a 18 byte string formatted like "aaaaa-bbbb-cccc-dd" (without zero-terminator!). If this configuration was created at Baltech this value is the configuration id. If the configuration was modified at a customer this value refers to the baltech configuration id, which the customer used as base for his modifications.
        """
        return Custom_AdminData_BaltechConfigID(self)
    @property
    def Custom_AdminData_DeviceSettingsCustomerNo(self) -> Custom_AdminData_DeviceSettingsCustomerNo:
        """
        The unique Customer's ID of the device settings. see also CustomerNo. As this value was introduced much later than CustomerNo a lot of configurations do not contain this value. In this case the reader has to fallback to the value of CustomerNo.
        """
        return Custom_AdminData_DeviceSettingsCustomerNo(self)
    @property
    def Custom_AdminData_FactoryResetFirmwareVersion(self) -> Custom_AdminData_FactoryResetFirmwareVersion:
        """
        This value contains information to pinpoint exactly which firmware should be loaded upon a factory reset: - the firmware ID (like 1055) - the firmware version (like 1.16.17), where each of the numbers is stored separately in BCD encoding.
        """
        return Custom_AdminData_FactoryResetFirmwareVersion(self)
    @property
    def Custom_AdminData_BleFirmwareVersion(self) -> Custom_AdminData_BleFirmwareVersion:
        """
        This value contains information about the version of the firmware, which is currently active in the BLE communication chip. 
        
        **This value is used internally by the firmware and should not be changed!**
        """
        return Custom_AdminData_BleFirmwareVersion(self)
    @property
    def Custom_AdminData_RequiresBusAddress(self) -> Custom_AdminData_RequiresBusAddress:
        """
        This value indicates if the upload software tool must request the user to specify a bus address. It's not used by the firmware. 
        
        Use this value in combination with SetBusAdrOnUploadViaIso14443 and/or AccessRightsOfBAC when you want to enable an NFC-based addressing mechanism.
        """
        return Custom_AdminData_RequiresBusAddress(self)
    @property
    def Custom_AdminData_V2eFormatIndicator(self) -> Custom_AdminData_V2eFormatIndicator:
        """
        This value is not used by firmware. It should even never occur in a real configuration. It is needed internally for implementing v2e configuration format.
        """
        return Custom_AdminData_V2eFormatIndicator(self)
    @property
    def Custom_Cid10022(self) -> Custom_Cid10022:
        """
        Customer-specific subkey for customer ID 10022.
        """
        return Custom_Cid10022(self)
    @property
    def Custom_Cid10022_ProjectName(self) -> Custom_Cid10022_ProjectName:
        """
        Customer-specific project name, see [FW-445](https://baltech-wiki.atlassian.net/browse/FW-445).
        """
        return Custom_Cid10022_ProjectName(self)
    @property
    def Registers(self) -> Registers:
        """
        This masterkey contains baltech internal values for the register manager.
        """
        return Registers(self)
    @property
    def Project_VhlSettings_HighPrioTaglist(self) -> Project_VhlSettings_HighPrioTaglist:
        """
        If this list of card types exists card types will be prioritized in descending order.
        """
        return Project_VhlSettings_HighPrioTaglist(self)
    @property
    def Project_VhlSettings_HighPrioDelay(self) -> Project_VhlSettings_HighPrioDelay:
        """
        This parameter indicates the delay present between the scanning of different cards in the VHL priority list.
        """
        return Project_VhlSettings_HighPrioDelay(self)
    @property
    def Project_VhlSettings_HandleLegicCTCAsSinglePrimeTransponder(self) -> Project_VhlSettings_HandleLegicCTCAsSinglePrimeTransponder:
        """
        This parameter allows to enable a special handling for Legic CTC4096 transponders by ignoring the ISO14443A and ISO15693 interfaces of this transponder. 
        
        Legic CTC4096 transponders support several RFID interfaces (Legic prime, ISO14443A and optionally ISO15693). They behave similar like a multichip card. VHL normally addresses every interface successively thus returning a different card type and a different UID for each RF interface of the CTC. 
        
        If this parameter is set to True, VHL ignores the ISO interfaces and handles a CTC transponder like a card that contains a Legic prime chip only. 
        
        A common use case for this parameter is a configuration that reads UIDs via Autoread. In the normal case this configuration returns two/three UIDs on a CTC card presentation. If this parameter is set to True then only one UID is returned.
        """
        return Project_VhlSettings_HandleLegicCTCAsSinglePrimeTransponder(self)
    @property
    def Project_VhlSettings_DesfireEV1RetryLoopTime(self) -> Project_VhlSettings_DesfireEV1RetryLoopTime:
        """
        If the card is not yet close enough to the reader for DESFire VHL.Read/Write, retries are carried out. The maximum time can be adjusted here.
        """
        return Project_VhlSettings_DesfireEV1RetryLoopTime(self)
    @property
    def Project_VhlSettingsLegic(self) -> Project_VhlSettingsLegic:
        """
        Contains generic settings for Legic Readers that are working with VHL/Autoread.
        """
        return Project_VhlSettingsLegic(self)
    @property
    def Project_VhlSettings125Khz_IndaspOkCounter(self) -> Project_VhlSettings125Khz_IndaspOkCounter:
        """
        Number of consecutive successfully reads until a Indala ASP card is reported as detected by VHL.
        """
        return Project_VhlSettings125Khz_IndaspOkCounter(self)
    @property
    def Project_VhlSettings125Khz_AwidOkCounter(self) -> Project_VhlSettings125Khz_AwidOkCounter:
        """
        Number of consecutive successfully reads until a Awid card is reported as detected by VHL.
        """
        return Project_VhlSettings125Khz_AwidOkCounter(self)
    @property
    def Project_VhlSettings125Khz_HidProxOkCounter(self) -> Project_VhlSettings125Khz_HidProxOkCounter:
        """
        Number of consecutive successfully reads until a HID Prox card is reported as detected by VHL.
        """
        return Project_VhlSettings125Khz_HidProxOkCounter(self)
    @property
    def Project_VhlSettings125Khz_QuadrakeyOkCounter(self) -> Project_VhlSettings125Khz_QuadrakeyOkCounter:
        """
        Number of consecutive successfully reads until a Quadrakey card is reported as detected by VHL.
        """
        return Project_VhlSettings125Khz_QuadrakeyOkCounter(self)
    @property
    def Project_VhlSettings125Khz_IoproxOkCounter(self) -> Project_VhlSettings125Khz_IoproxOkCounter:
        """
        Number of consecutive successfully reads until a Ioprox card is reported as detected by VHL.
        """
        return Project_VhlSettings125Khz_IoproxOkCounter(self)
    @property
    def Project_VhlSettings125Khz_IndalaMode(self) -> Project_VhlSettings125Khz_IndalaMode:
        """
        This value selects the mode for reading data from Indala cards.
        """
        return Project_VhlSettings125Khz_IndalaMode(self)
    @property
    def Project_VhlSettings125Khz_IsSelectedRetryCounter(self) -> Project_VhlSettings125Khz_IsSelectedRetryCounter:
        """
        This value specifies the number of retries to determine if a TTF transponder is still available.
        """
        return Project_VhlSettings125Khz_IsSelectedRetryCounter(self)
    @property
    def Project_VhlSettings125Khz_GenericOkCounter(self) -> Project_VhlSettings125Khz_GenericOkCounter:
        """
        Number of consecutive successfully reads until a TTF card is reported as detected by VHL.
        """
        return Project_VhlSettings125Khz_GenericOkCounter(self)
    @property
    def Project_Bluetooth(self) -> Project_Bluetooth:
        """
        This key contains values that allow parameterizing Bluetooth Low Energy functionality.
        """
        return Project_Bluetooth(self)
    @property
    def Project_Bluetooth_DiscoveryMode(self) -> Project_Bluetooth_DiscoveryMode:
        """
        This value defines the Generic Access Profile (GAP) discovery mode of the BLE reader device.
        """
        return Project_Bluetooth_DiscoveryMode(self)
    @property
    def Project_Bluetooth_ConnectionMode(self) -> Project_Bluetooth_ConnectionMode:
        """
        This value defines the Generic Access Profile (GAP) connection mode of the BLE reader device.
        """
        return Project_Bluetooth_ConnectionMode(self)
    @property
    def Project_Bluetooth_AdvertisementData(self) -> Project_Bluetooth_AdvertisementData:
        """
        This value defines the advertisement data which shall be contained in the Protocol Data Unit (PDU) of the GAP advertising packet.
        """
        return Project_Bluetooth_AdvertisementData(self)
    @property
    def Project_Bluetooth_ScanResponseData(self) -> Project_Bluetooth_ScanResponseData:
        """
        This value defines the scan response data which the device shall send in response to a Scan Request from a BLE central device. It usually contains the device name or services that couldn't be placed in the advertising packet.
        """
        return Project_Bluetooth_ScanResponseData(self)
    @property
    def Project_Bluetooth_MinAdvertisingInterval(self) -> Project_Bluetooth_MinAdvertisingInterval:
        """
        Minimum interval in units of 0.625 ms for advertisement packets to be sent by the device.
        """
        return Project_Bluetooth_MinAdvertisingInterval(self)
    @property
    def Project_Bluetooth_MaxAdvertisingInterval(self) -> Project_Bluetooth_MaxAdvertisingInterval:
        """
        Maximum interval in units of 0.625 ms for advertisement packets to be sent by the device. 
        
        This value must be chosen at least equal or greater than Project/Bluetooth/MinAdvertisingInterval!
        """
        return Project_Bluetooth_MaxAdvertisingInterval(self)
    @property
    def Project_Bluetooth_AdvertizingChannels(self) -> Project_Bluetooth_AdvertizingChannels:
        """
        This value specifies which of the three available channels should be used for advertizing.
        """
        return Project_Bluetooth_AdvertizingChannels(self)
    @property
    def Project_Bluetooth_MinConnectionInterval(self) -> Project_Bluetooth_MinConnectionInterval:
        """
        Minimum value for the connection event interval in units of 1.25 ms.
        """
        return Project_Bluetooth_MinConnectionInterval(self)
    @property
    def Project_Bluetooth_MaxConnectionInterval(self) -> Project_Bluetooth_MaxConnectionInterval:
        """
        Maximum value for the connection event interval in units of 1.25 ms. 
        
        This value must be chosen at least equal or greater than Project/Bluetooth/MinConnectionInterval!
        """
        return Project_Bluetooth_MaxConnectionInterval(self)
    @property
    def Project_Bluetooth_ConnectionSupervisionTimeout(self) -> Project_Bluetooth_ConnectionSupervisionTimeout:
        """
        This value specifies the supervision timeout in units of 10 ms. This timeout defines for how long a connection is maintained despite the device being unable to communicate at the currently configured connection intervals. 
        
        It is recommended that the supervision timeout is set at a value which allows communication attempts over at least a few connection intervals.
        """
        return Project_Bluetooth_ConnectionSupervisionTimeout(self)
    @property
    def Project_Bluetooth_DeviceNameLegacy(self) -> Project_Bluetooth_DeviceNameLegacy:
        """
        This value was used to define the Generic Access Profile (GAP) characteristic Device Name, which is advertized by the reader. It is replaced by Project.Bluetooth.AdvertizedDeviceName.
        """
        return Project_Bluetooth_DeviceNameLegacy(self)
    @property
    def Project_Bluetooth_Appearance(self) -> Project_Bluetooth_Appearance:
        """
        This value defines the Generic Access Profile (GAP) characteristic Appearance. This value is readable from a BLE GATT client by accessing the GAP profile of the device.
        """
        return Project_Bluetooth_Appearance(self)
    @property
    def Project_Bluetooth_AdvertizedDeviceName(self) -> Project_Bluetooth_AdvertizedDeviceName:
        """
        This value defines the Generic Access Profile (GAP) characteristic Device Name, which is advertized by the reader. 
        
        This value is a template which allows you to insert the reader serial number or the Bluetooth MAC address (use SerialNr for this purpose) into the name string. 
        
        **The length of the resulting string may not exceed 24 digits!**
        """
        return Project_Bluetooth_AdvertizedDeviceName(self)
    @property
    def Project_Bluetooth_ScanInterval(self) -> Project_Bluetooth_ScanInterval:
        """
        This value defines the BLE scan interval, i.e. the interval at which the reader scans for advertisement packets. 
        
        This parameter is defined in units of 0.625 ms. It has a range between 4 and 0xFFFF resulting in a time range of 2.5 ms to 40.96 s.
        """
        return Project_Bluetooth_ScanInterval(self)
    @property
    def Project_Bluetooth_ScanWindow(self) -> Project_Bluetooth_ScanWindow:
        """
        This value defines the BLE scan window, i.e. the duration of the scan. It must be less than or equal to the ScanInterval. 
        
        This parameter is defined in units of 0.625 ms. It has a range between 4 and 0xFFFF resulting in a time range of 2.5 ms to 40.96 s.
        """
        return Project_Bluetooth_ScanWindow(self)
    @property
    def Project_Mce(self) -> Project_Mce:
        """
        This key contains values to set up the Mobile Card Emulation (MCE) functionality.
        """
        return Project_Mce(self)
    @property
    def Project_Mce_Mode(self) -> Project_Mce_Mode:
        """
        This value allows you to enable/disable MCE.
        """
        return Project_Mce_Mode(self)
    @property
    def ProjectRegisters(self) -> ProjectRegisters:
        """
        This masterkey contains all values specific to the RFID interface component for register management (see also Registers.
        """
        return ProjectRegisters(self)
    @property
    def Protocols_Bpa9_BaudRate(self) -> Protocols_Bpa9_BaudRate:
        """
        Baudrate used by the BPA/9 protocol (unit: value in 100 bits per second)
        """
        return Protocols_Bpa9_BaudRate(self)
    @property
    def Protocols_Bpa9_DeviceId(self) -> Protocols_Bpa9_DeviceId:
        """
        The device ID specifies the bus address of the reader used by the BPA/9 protococol. 
        
        Usually the address is set via BALTECH AdrCard. This value may be used to set a fixed bus address if the AdrCard feature is disabled.
        """
        return Protocols_Bpa9_DeviceId(self)
    @property
    def Protocols_Bpa9_GroupId(self) -> Protocols_Bpa9_GroupId:
        """
        This value specifies the group ID used by the BPA/9 protococol.
        """
        return Protocols_Bpa9_GroupId(self)
    @property
    def Protocols_BrpTcp(self) -> Protocols_BrpTcp:
        """
        This subkey specifies all protocol parameters needed for the BRP over TCP protocol.
        """
        return Protocols_BrpTcp(self)
    @property
    def Protocols_BrpTcp_CmdWorkInterval(self) -> Protocols_BrpTcp_CmdWorkInterval:
        """
        Time in ms between 2 CMD_WORK messages if a BRP command is executed in continuous or repeat mode. 
        
        When this value is set to 0xFFFF (default), no CMD_WORK message is sent until the command is finished.
        """
        return Protocols_BrpTcp_CmdWorkInterval(self)
    @property
    def Protocols_BrpTcp_RepeatModeMinDelay(self) -> Protocols_BrpTcp_RepeatModeMinDelay:
        """
        This value specifies the minimum time in ms between two responses sent in repeat mode. If not set, a default of 100ms is assumed.
        """
        return Protocols_BrpTcp_RepeatModeMinDelay(self)
    @property
    def Protocols_BrpTcp_TcpPort(self) -> Protocols_BrpTcp_TcpPort:
        """
        This is the local TCP port used for the BRP protocol. The reader listens on this port for incoming connection requests.
        """
        return Protocols_BrpTcp_TcpPort(self)
    @property
    def Protocols_BrpTcp_TcpHost(self) -> Protocols_BrpTcp_TcpHost:
        """
        This is the preferred host that shall be contacted in case the reader operates in standalone mode and a card is presented. 
        
        As soon as the reader detects a card it tries to establish a TCP connection to this host. In case the host is not available the reader tries to contact the alternate host TcpAlternateHost. If this is successful the reader switches priority internally, which means it will prefer the alternate host the next time.
        """
        return Protocols_BrpTcp_TcpHost(self)
    @property
    def Protocols_BrpTcp_TcpHostPort(self) -> Protocols_BrpTcp_TcpHostPort:
        """
        This is the TCP port of the preferred host (TcpHost).
        """
        return Protocols_BrpTcp_TcpHostPort(self)
    @property
    def Protocols_BrpTcp_TcpAlternateHost(self) -> Protocols_BrpTcp_TcpAlternateHost:
        """
        This is the alternate host that shall be contacted in case of card presentation if the preferred host (TcpHost) is not available. 
        
        In the case that the preferred host is not available but the alternate host can be contacted instead, the reader switches internally the preferred and the alternate host.
        """
        return Protocols_BrpTcp_TcpAlternateHost(self)
    @property
    def Protocols_BrpTcp_TcpAlternateHostPort(self) -> Protocols_BrpTcp_TcpAlternateHostPort:
        """
        This is the TCP port of the alternate host (TcpAlternateHost).
        """
        return Protocols_BrpTcp_TcpAlternateHostPort(self)
    @property
    def Protocols_BrpTcp_TcpAutoCloseTimeout(self) -> Protocols_BrpTcp_TcpAutoCloseTimeout:
        """
        This is the timeout for closing unused open connections. 
        
        If this time elapses without having received a BRP command from the host, the reader will automatically close an opened TCP connection. 
        
        If this value is set to 0, the auto-close feature is disabled, i.e. the reader keeps a connection always open. It is the matter of the host to close open connections.
        """
        return Protocols_BrpTcp_TcpAutoCloseTimeout(self)
    @property
    def Protocols_BrpTcp_TcpOutgoingPort(self) -> Protocols_BrpTcp_TcpOutgoingPort:
        """
        This is the TCP port number that is used for the BRP protocol in case a BRP communication session is initiated by the reader. 
        
        For BRP communication that the host initiates refer to (TcpPort). 
        
        If this value is not set, a port number is chosen incidentally on every connection trial.
        """
        return Protocols_BrpTcp_TcpOutgoingPort(self)
    @property
    def Protocols_BrpTcp_TcpConnectTrialMinDelay(self) -> Protocols_BrpTcp_TcpConnectTrialMinDelay:
        """
        This is the minimum time in seconds the reader will wait after an unsuccessful connection request before it starts the next trial. 
        
        The actual delay is chosen randomly within the limits of this minimum value and (TcpConnectTrialMaxDelay).
        """
        return Protocols_BrpTcp_TcpConnectTrialMinDelay(self)
    @property
    def Protocols_BrpTcp_TcpConnectTrialMaxDelay(self) -> Protocols_BrpTcp_TcpConnectTrialMaxDelay:
        """
        This is the maximum time in seconds the reader will wait after an unsuccessful connection request before it starts the next trial. 
        
        The actual delay is chosen randomly within the limits of (TcpConnectTrialMinDelay) and this value.
        """
        return Protocols_BrpTcp_TcpConnectTrialMaxDelay(self)
    @property
    def Protocols_BrpTcp_TcpSoftResetDelay(self) -> Protocols_BrpTcp_TcpSoftResetDelay:
        """
        This is the time in milliseconds the reader will wait after a software reset before it tries to reconnect to the host. This delay, which is only applied in case the connection was initiated by the host and not by the reader, allows the host for reconnecting the reader after it has rebooted.
        """
        return Protocols_BrpTcp_TcpSoftResetDelay(self)
    @property
    def Protocols_BrpTcp_TcpMaskLinkChangeEventDelay(self) -> Protocols_BrpTcp_TcpMaskLinkChangeEventDelay:
        """
        This is the time in milliseconds the reader won't report link change events to the host after reboot.
        """
        return Protocols_BrpTcp_TcpMaskLinkChangeEventDelay(self)
    @property
    def Protocols_BrpTcp_TcpTtl(self) -> Protocols_BrpTcp_TcpTtl:
        """
        TTL (Time to Live) value used in the IPv4 packet header for BRP communication
        """
        return Protocols_BrpTcp_TcpTtl(self)
    @property
    def Protocols_BrpTcp_SlpAttributes(self) -> Protocols_BrpTcp_SlpAttributes:
        """
        These are up to 16 application specific attributes the SLP protocol will advertise if requested by a host.
        """
        return Protocols_BrpTcp_SlpAttributes(self)
    @property
    def Protocols_BrpTcp_HostMsgFormatTemplate(self) -> Protocols_BrpTcp_HostMsgFormatTemplate:
        """
        Specifies the way the ascii decimal number read from the card by autoread shall be converted to the lowlevel format needed by this protocol.
        """
        return Protocols_BrpTcp_HostMsgFormatTemplate(self)
    @property
    def Protocols_BrpTcp_AutoRunCommand(self) -> Protocols_BrpTcp_AutoRunCommand:
        """
        A list of BRP command frames that shall be executed automatically at powerup (including sending their responses to the host) before starting with normal operation. 
        
        **These commands are executed in order (_first_ StartupRunCmd[0],_then_ StartupRunCmd[1], ...) until the first index without corresponding StartupRunCmd value.**
        """
        return Protocols_BrpTcp_AutoRunCommand(self)
    @property
    def Protocols_Network_DhcpLastAssignedIp(self) -> Protocols_Network_DhcpLastAssignedIp:
        """
        The DHCP client stores here the IP address that has been assigned to it the last time. It will request this address again in case of restarts. 
        
        **This value is normally only used internally.**
        """
        return Protocols_Network_DhcpLastAssignedIp(self)
    @property
    def Protocols_Network_DhcpVendorClassIdentifier(self) -> Protocols_Network_DhcpVendorClassIdentifier:
        """
        This value defines the Vendor class identifier the reader advertises in its DHCP discover and request messages (DHCP option 60). 
        
        **Option 60 is omitted if this value is set to an empty string "".**
        """
        return Protocols_Network_DhcpVendorClassIdentifier(self)
    @property
    def Protocols_Network_LinkLocalLastAssignedIp(self) -> Protocols_Network_LinkLocalLastAssignedIp:
        """
        Here the Link-local IP address is stored that has been acquired the last time. The reader tries to re-acquire this address again in case of restarts. 
        
        **This value is normally only used internally.**
        """
        return Protocols_Network_LinkLocalLastAssignedIp(self)
    @property
    def Protocols_Network_LinkLocalMode(self) -> Protocols_Network_LinkLocalMode:
        """
        Activates/deactivates Link-Local address acquirement. 
        
        In case Link-Local is enabled the reader tries to get a link-local address ("169.254.x.x") at startup. 
        
        If the auto mode is selected then the reader starts Link-Local acquirement delayed. If a DHCP address can be acquired during this delay Link-Local will not be started (refer to LinkLocalAcquireDelay). 
        
        As default Link-local is disabled.
        """
        return Protocols_Network_LinkLocalMode(self)
    @property
    def Protocols_Network_LinkLocalAcquireDelay(self) -> Protocols_Network_LinkLocalAcquireDelay:
        """
        Specifies the delay of the Link-Local address acquirement at startup of the reader in case of Link-Local auto mode (refer to LinkLocalMode). 
        
        To avoid excessive network traffic at startup the Firmware supports the following mechanism: A Link-Local address is only acquired with an initial delay. In case the reader gets an IP address from a DHCP server within this time, it won't request a link-local address any more as this address is only required if no other addressing mechanism is available. 
        
        **The delay should be chosen large enough to ensure that the reader is able to retrieve a DHCP address in case a DHCP server is available.**
        """
        return Protocols_Network_LinkLocalAcquireDelay(self)
    @property
    def Protocols_Network_DetectIpEnable(self) -> Protocols_Network_DetectIpEnable:
        """
        Activates/deactivates IP detection of a connected network device. 
        
        If this value is set to "Yes" the reader investigates incoming frames to find out the IP address of a network device (e.g. printer) that is directly connected to the reader switch. The host can retrieve this IP address from the reader via BRP over TCP.
        """
        return Protocols_Network_DetectIpEnable(self)
    @property
    def Protocols_Network_ResolverEnable(self) -> Protocols_Network_ResolverEnable:
        """
        Activates/deactivates DNS resolver. 
        
        If this value is set to "Yes" the reader tries to resolve host names to IP addresses. This will only work if the reader has the IP address of a valid DNS server (either through DHCP or static configuration - refer to IpDnsServer).
        """
        return Protocols_Network_ResolverEnable(self)
    @property
    def Protocols_Network_ResolverInterval(self) -> Protocols_Network_ResolverInterval:
        """
        Specifies the time interval the reader should restart resolving host names. This is done to keep updated in case of IP address changes in the network.
        """
        return Protocols_Network_ResolverInterval(self)
    @property
    def Protocols_Network_UdpIntrospecEnable(self) -> Protocols_Network_UdpIntrospecEnable:
        """
        Activates/deactivates UDP introspection. 
        
        If this value is set to "Yes" the reader investigates all frames that arrive at the reader switch in order to find a certain UDP packet the host is sending to the directly connected network device (e.g. printer). Once this frame has been detected the reader extracts the IP address and port and opens a TCP connection to the host.
        """
        return Protocols_Network_UdpIntrospecEnable(self)
    @property
    def Protocols_Network_SlpEnable(self) -> Protocols_Network_SlpEnable:
        """
        Activates/deactivates Service Location Protocol (SLP). 
        
        If this value is set to "Yes" the reader activates SLP. A User Agent can find the reader then by searching for the SLP service "service:x-proxreader".
        """
        return Protocols_Network_SlpEnable(self)
    @property
    def Protocols_Network_SlpScope(self) -> Protocols_Network_SlpScope:
        """
        This value configures the SLP scope. The device will only reply to service requests for this scope. 
        
        The reader supports one scope consisting of 10 characters. If this value does not exist, the reader uses the default scope ("DEFAULT"). 
        
        **Only lower-case letters are allowed!**
        """
        return Protocols_Network_SlpScope(self)
    @property
    def Protocols_Network_SlpDirectoryAgent(self) -> Protocols_Network_SlpDirectoryAgent:
        """
        This value specifies the SLP Directory Agent (DA). The reader device will register its service to the DA if available. 
        
        In case the IP address of the DA is not specified directly but only the host name, the reader tries to resolve the name using DNS resolver (refer to ResolverEnable).
        """
        return Protocols_Network_SlpDirectoryAgent(self)
    @property
    def Protocols_Network_SlpActiveDiscovery(self) -> Protocols_Network_SlpActiveDiscovery:
        """
        Activates/deactivates SLP active discovery of Directory Agents (DA). 
        
        If this value is set to "Disabled" the reader will _not_ actively try to find DAs by sending out Multicast/Broadcast DA-Request messages.
        """
        return Protocols_Network_SlpActiveDiscovery(self)
    @property
    def Protocols_Network_SlpPassiveDiscovery(self) -> Protocols_Network_SlpPassiveDiscovery:
        """
        Activates/deactivates SLP passive discovery of Directory Agents (DA). 
        
        If this value is set to "Disabled" the reader will _not_ react to received DA-Advert messages.
        """
        return Protocols_Network_SlpPassiveDiscovery(self)
    @property
    def Protocols_Network_SlpMulticastTtl(self) -> Protocols_Network_SlpMulticastTtl:
        """
        Specifies the time to live (TTL) value for outgoing multicast requests. 
        
        The TTL field of a frame is decreased by every host that passes the frame by at least 1. If it reaches 0 the frame is not forwarded any more.
        """
        return Protocols_Network_SlpMulticastTtl(self)
    @property
    def Protocols_Network_SlpRegistratonLifetime(self) -> Protocols_Network_SlpRegistratonLifetime:
        """
        Specifies the lifetime of service registrations. The reader starts to re-register its service at the DA as soon as 75% of this time has elapsed.
        """
        return Protocols_Network_SlpRegistratonLifetime(self)
    @property
    def Protocols_Network_SlpUseBroadcast(self) -> Protocols_Network_SlpUseBroadcast:
        """
        If this value is set to "Yes" the reader will use Broadcasts instead of Multicasts. 
        
        This feature is intended for smaller networks that doesn't support Multicast.
        """
        return Protocols_Network_SlpUseBroadcast(self)
    @property
    def Protocols_Network_RecoveryPointStatus(self) -> Protocols_Network_RecoveryPointStatus:
        """
        Status of actual recovery point. 
        
        This value is managed by the reader firmware. Don't change its value manually!
        """
        return Protocols_Network_RecoveryPointStatus(self)
    @property
    def Protocols_Network_NicNetworkPortSpeedDuplexMode(self) -> Protocols_Network_NicNetworkPortSpeedDuplexMode:
        """
        Select Speed and Duplex mode for Network port.
        """
        return Protocols_Network_NicNetworkPortSpeedDuplexMode(self)
    @property
    def Protocols_Network_NicFlowControl(self) -> Protocols_Network_NicFlowControl:
        """
        Enable/Disable Flow Control. Enables/Disabled the pause packet for high/low water threshold control.
        """
        return Protocols_Network_NicFlowControl(self)
    @property
    def Protocols_Network_NicPrinterPortSpeedDuplexMode(self) -> Protocols_Network_NicPrinterPortSpeedDuplexMode:
        """
        Select Speed and Duplex mode for Printer/Device port. 
        
        Note: To allow for Maintenance Mode being entered without difficulty printer port is forced to operate in Autonegotiation mode as soon as Network port link gets lost.
        """
        return Protocols_Network_NicPrinterPortSpeedDuplexMode(self)
    @property
    def Protocols_Lbus(self) -> Protocols_Lbus:
        """
        If the LBus protocol is enabled (see Device/Run/EnabledProtocols), you can fine-tune it with these values.
        """
        return Protocols_Lbus(self)
    @property
    def Protocols_Lbus_BaudRate(self) -> Protocols_Lbus_BaudRate:
        """
        Baudrate used by the LBus protocol (unit: value in 100 bits per second)
        """
        return Protocols_Lbus_BaudRate(self)
    @property
    def Protocols_Lbus_Channel(self) -> Protocols_Lbus_Channel:
        """
        Specifies the RS-232/UART interface to be used for communication with the LBus host. 
        
        **This value is only relevant for ID-engine SD and ACCESS 100 readers providing 2 RS-232/UART interfaces. All other reader types feature only 1 RS-232/UART interface and should not use this value.**
        """
        return Protocols_Lbus_Channel(self)
    @property
    def Protocols_Lbus_Address(self) -> Protocols_Lbus_Address:
        """
        LBus device ID used by reader (0-15)
        """
        return Protocols_Lbus_Address(self)
    @property
    def Protocols_Lbus_OfflineTimeout(self) -> Protocols_Lbus_OfflineTimeout:
        """
        Offline timeout in seconds (0-65). If the reader is not polled by the LBus host within this timeframe, it switches from online to offline mode. If timeout is set to 0, the reader never enters offline mode.
        """
        return Protocols_Lbus_OfflineTimeout(self)
    @property
    def Protocols_Lbus_OrderNumber(self) -> Protocols_Lbus_OrderNumber:
        """
        Order number (up to 16 ASCII characters)
        """
        return Protocols_Lbus_OrderNumber(self)
    @property
    def Protocols_Lbus_CheckDigits(self) -> Protocols_Lbus_CheckDigits:
        """
        Check digits (4 ASCII characters)
        """
        return Protocols_Lbus_CheckDigits(self)
    @property
    def Protocols_Lbus_OfflineCompanyIdLegacy(self) -> Protocols_Lbus_OfflineCompanyIdLegacy:
        """
        Company ID to be checked by a reader in offline mode 
        
        **This value is deprecated. It has been replaced by Protocols.Lbus.OfflineCompanyId .**
        """
        return Protocols_Lbus_OfflineCompanyIdLegacy(self)
    @property
    def Protocols_Lbus_OfflineCompanyIdPositionLegacy(self) -> Protocols_Lbus_OfflineCompanyIdPositionLegacy:
        """
        Offset when reading the company ID to be checked by a reader in offline mode 
        
        **This value is deprecated. It has been replaced by Protocols.Lbus.OfflineCompanyId .**
        """
        return Protocols_Lbus_OfflineCompanyIdPositionLegacy(self)
    @property
    def Protocols_Lbus_OfflineIndication(self) -> Protocols_Lbus_OfflineIndication:
        """
        If set to _True_ , this value indicates offline mode by toggling the yellow LED (on ACCESS100 and ID-engine SD) or blue LED (on newer reader types).
        """
        return Protocols_Lbus_OfflineIndication(self)
    @property
    def Protocols_Lbus_OfflineOutputTime(self) -> Protocols_Lbus_OfflineOutputTime:
        """
        Duration (in 0.4-second units) for which the relay is activated after a successful company ID check in offline mode
        """
        return Protocols_Lbus_OfflineOutputTime(self)
    @property
    def Protocols_Lbus_OfflineGreenLedTime(self) -> Protocols_Lbus_OfflineGreenLedTime:
        """
        Duration (in 0.4-second units) for which the green LED is activated after a successful company ID check in offline mode
        """
        return Protocols_Lbus_OfflineGreenLedTime(self)
    @property
    def Protocols_Lbus_OfflineRedLedTime(self) -> Protocols_Lbus_OfflineRedLedTime:
        """
        Duration (in 0.4-second units) for which the red LED is activated after a failed company ID check in offline mode
        """
        return Protocols_Lbus_OfflineRedLedTime(self)
    @property
    def Protocols_Lbus_OfflineCompanyId(self) -> Protocols_Lbus_OfflineCompanyId:
        """
        These values define up to 10 company IDs to be checked by the reader in offline mode.
        """
        return Protocols_Lbus_OfflineCompanyId(self)
    @property
    def Protocols_Lbus_Key(self) -> Protocols_Lbus_Key:
        """
        Secure key for LBus protocol encryption (16 bytes)
        """
        return Protocols_Lbus_Key(self)
    @property
    def Protocols_BleHci(self) -> Protocols_BleHci:
        """
        This subkey specifies all parameters needed for the BLE HCI protocol. This USB protocol allows the BLE component to be controlled via Host Controller Interface (HCI) as specified in the Bluetooth Core Specification.
        """
        return Protocols_BleHci(self)
    @property
    def Protocols_AccessConditionBitsStd_Tcp(self) -> Protocols_AccessConditionBitsStd_Tcp:
        """
        Specifies the access rights when running Tcp protocol unencrypted
        """
        return Protocols_AccessConditionBitsStd_Tcp(self)
    @property
    def Protocols_AccessConditionBitsAlt_TcpMaintenanceMode(self) -> Protocols_AccessConditionBitsAlt_TcpMaintenanceMode:
        """
        Limits the access rights when running Tcp in maintenance mode (= _only_ the second ethernet link is connected).
        """
        return Protocols_AccessConditionBitsAlt_TcpMaintenanceMode(self)
    @property
    def Protocols_AccessConditionBitsAlt2(self) -> Protocols_AccessConditionBitsAlt2:
        """
        This subkey is reserved for future use.
        """
        return Protocols_AccessConditionBitsAlt2(self)
    @property
    def Protocols_AccessConditionBitsAlt3(self) -> Protocols_AccessConditionBitsAlt3:
        """
        This subkey is reserved for future use.
        """
        return Protocols_AccessConditionBitsAlt3(self)
    @property
    def Protocols_NetworkBackup(self) -> Protocols_NetworkBackup:
        """
        This subkey is used internally by the reader firmware to create or restore a recovery point. It mirrors the network settings from subkey Protocols / Network.
        """
        return Protocols_NetworkBackup(self)
    @property
    def Protocols_BrpTcpBackup(self) -> Protocols_BrpTcpBackup:
        """
        This subkey is used internally by the reader firmware to create or restore a recovery point. It mirrors the BRP TCP settings from subkey Protocols / BrpTcp.
        """
        return Protocols_BrpTcpBackup(self)
__all__: list[str] = [
    "InternalConfigAccessor",
    "Scripts",
    "Scripts_Events",
    "Scripts_Events_OnKeypressF",
    "Scripts_Events_OnKeypressEsc",
    "Scripts_Events_OnKeypressClear",
    "Scripts_Events_OnKeypressMenu",
    "Scripts_Events_OnKeypressOk",
    "Scripts_Events_OnKeypressStar",
    "Scripts_Events_OnKeypressSharp",
    "Scripts_Events_OnCustomEvent",
    "Scripts_Events_OnNetworkBooted",
    "Scripts_Events_OnLinkedNoPort",
    "Scripts_Events_OnLinkedNetworkPort",
    "Scripts_Events_OnLinkedDevicePort",
    "Scripts_Events_OnLinkedAllPorts",
    "Scripts_Events_OnWaitingForDHCP",
    "Scripts_Events_OnSearchingForHost",
    "Scripts_Events_OnUDPConnectFailure",
    "Scripts_Events_OnHostConnectFailure",
    "Scripts_Events_OnStaticIPFailure",
    "Scripts_Events_OnHostFound",
    "Scripts_Events_OnBleNoAlert",
    "Scripts_Events_OnBleMildAlert",
    "Scripts_Events_OnBleHighAlert",
    "Device",
    "Device_VhlSettings",
    "Device_VhlSettings_ScanCardFamilies",
    "Device_VhlSettings_ForceReselect",
    "Device_VhlSettings_DelayRequestATS",
    "Device_VhlSettings_DelayPerformPPS",
    "Device_VhlSettings_MaxBaudrateIso14443A",
    "Device_VhlSettings_MaxBaudrateIso14443B",
    "Device_VhlSettings125Khz",
    "Device_VhlSettings125Khz_ScanCardTypes",
    "Device_VhlSettings125Khz_ModulationType",
    "Device_VhlSettings125Khz_Baud",
    "Device_VhlSettings125Khz_TTFHeaderLength",
    "Device_VhlSettings125Khz_TTFHeader",
    "Device_VhlSettings125Khz_TTFDataLength",
    "Device_VhlSettings125Khz_TTFOkCounter",
    "Device_VhlSettings125Khz_IndaspDecode",
    "Device_VhlSettings125Khz_IndaspParityCheck",
    "Device_VhlSettings125Khz_IndaspOkCounter",
    "Device_VhlSettings125Khz_AwidOkCounter",
    "Device_VhlSettings125Khz_HidProxOkCounter",
    "Device_Boot",
    "Device_Boot_ConfigCardState",
    "Device_Boot_LegicAdvantInitialization",
    "Device_Run",
    "Device_Run_DeviceName",
    "Device_Run_ProjectName",
    "Device_Run_CardReadFailureLogging",
    "Device_Run_FirstVhlRc500Key",
    "Device_Run_BusAdressByBACLegacy",
    "Device_Run_ConfigCardMifareKeyBackup",
    "Device_Run_CustomerKeyBackup",
    "Device_Run_ConfigCardDesfireKeyBackup",
    "Device_Run_UsbSuspendMode",
    "Device_Rgb",
    "Device_Rgb_MaximizeIntensity",
    "Device_CryptoKey",
    "Device_CryptoKey_Entry",
    "Device_MifareClassicKey",
    "Device_MifareClassicKey_Entry",
    "Device_HostSecurity",
    "Device_HostSecurity_PrivateKey",
    "Device_HostSecurity_PublicKey",
    "Device_HostSecurity_HostRootCertSubjectName",
    "Device_HostSecurity_HostRootCertPubKey",
    "Device_HostSecurity_HostRootCertSnr",
    "Device_HostSecurity_ReaderCertSnr",
    "Device_HostSecurity_ReaderCertIssuer",
    "Device_HostSecurity_ReaderCertValidity",
    "Device_HostSecurity_ReaderCertSignature",
    "Device_HostSecurity_AccessConditionMaskInternal",
    "Device_HostSecurity_KeyInternal",
    "Device_Statistics",
    "Device_Statistics_FirmwareId",
    "Device_Statistics_FirmwareRelease",
    "Device_Statistics_WatchdogResetCount",
    "Device_Statistics_StackOverflowCount",
    "Device_Statistics_StackOverflowTaskAddress",
    "Device_Statistics_BrownoutResetCount",
    "Device_Statistics_KeypadResetCount",
    "Device_Statistics_KeypadCommErrorCount",
    "Device_Statistics_AccessRestrictedTaskOverflowResetCount",
    "Device_Statistics_BleResetCount",
    "Custom",
    "Custom_Crypto",
    "Custom_Crypto_Key",
    "Custom_AdminData",
    "Custom_AdminData_MasterCardNoRef",
    "Custom_AdminData_MasterCardNameRef",
    "Custom_AdminData_MasterCardNo",
    "Custom_AdminData_MasterCardName",
    "Custom_AdminData_DeviceSettingsTemplateBased",
    "Custom_AdminData_ProjectSettingsTemplateBased",
    "Custom_AdminData_UniqueDeviceName",
    "Custom_AdminData_DraftFlag",
    "Custom_AdminData_BaltechConfigID",
    "Custom_AdminData_DeviceSettingsCustomerNo",
    "Custom_AdminData_FactoryResetFirmwareVersion",
    "Custom_AdminData_BleFirmwareVersion",
    "Custom_AdminData_RequiresBusAddress",
    "Custom_AdminData_V2eFormatIndicator",
    "Custom_Cid10022",
    "Custom_Cid10022_ProjectName",
    "Registers",
    "Project",
    "Project_VhlSettings",
    "Project_VhlSettings_HighPrioTaglist",
    "Project_VhlSettings_HighPrioDelay",
    "Project_VhlSettings_HandleLegicCTCAsSinglePrimeTransponder",
    "Project_VhlSettings_DesfireEV1RetryLoopTime",
    "Project_VhlSettingsLegic",
    "Project_VhlSettings125Khz",
    "Project_VhlSettings125Khz_IndaspOkCounter",
    "Project_VhlSettings125Khz_AwidOkCounter",
    "Project_VhlSettings125Khz_HidProxOkCounter",
    "Project_VhlSettings125Khz_QuadrakeyOkCounter",
    "Project_VhlSettings125Khz_IoproxOkCounter",
    "Project_VhlSettings125Khz_IndalaMode",
    "Project_VhlSettings125Khz_IsSelectedRetryCounter",
    "Project_VhlSettings125Khz_GenericOkCounter",
    "Project_Bluetooth",
    "Project_Bluetooth_DiscoveryMode",
    "Project_Bluetooth_ConnectionMode",
    "Project_Bluetooth_AdvertisementData",
    "Project_Bluetooth_ScanResponseData",
    "Project_Bluetooth_MinAdvertisingInterval",
    "Project_Bluetooth_MaxAdvertisingInterval",
    "Project_Bluetooth_AdvertizingChannels",
    "Project_Bluetooth_MinConnectionInterval",
    "Project_Bluetooth_MaxConnectionInterval",
    "Project_Bluetooth_ConnectionSupervisionTimeout",
    "Project_Bluetooth_DeviceNameLegacy",
    "Project_Bluetooth_Appearance",
    "Project_Bluetooth_AdvertizedDeviceName",
    "Project_Bluetooth_ScanInterval",
    "Project_Bluetooth_ScanWindow",
    "Project_Mce",
    "Project_Mce_Mode",
    "ProjectRegisters",
    "Protocols",
    "Protocols_Bpa9",
    "Protocols_Bpa9_BaudRate",
    "Protocols_Bpa9_DeviceId",
    "Protocols_Bpa9_GroupId",
    "Protocols_BrpTcp",
    "Protocols_BrpTcp_CmdWorkInterval",
    "Protocols_BrpTcp_RepeatModeMinDelay",
    "Protocols_BrpTcp_TcpPort",
    "Protocols_BrpTcp_TcpHost",
    "Protocols_BrpTcp_TcpHostPort",
    "Protocols_BrpTcp_TcpAlternateHost",
    "Protocols_BrpTcp_TcpAlternateHostPort",
    "Protocols_BrpTcp_TcpAutoCloseTimeout",
    "Protocols_BrpTcp_TcpOutgoingPort",
    "Protocols_BrpTcp_TcpConnectTrialMinDelay",
    "Protocols_BrpTcp_TcpConnectTrialMaxDelay",
    "Protocols_BrpTcp_TcpSoftResetDelay",
    "Protocols_BrpTcp_TcpMaskLinkChangeEventDelay",
    "Protocols_BrpTcp_TcpTtl",
    "Protocols_BrpTcp_SlpAttributes",
    "Protocols_BrpTcp_HostMsgFormatTemplate",
    "Protocols_BrpTcp_AutoRunCommand",
    "Protocols_Network",
    "Protocols_Network_DhcpLastAssignedIp",
    "Protocols_Network_DhcpVendorClassIdentifier",
    "Protocols_Network_LinkLocalLastAssignedIp",
    "Protocols_Network_LinkLocalMode",
    "Protocols_Network_LinkLocalAcquireDelay",
    "Protocols_Network_DetectIpEnable",
    "Protocols_Network_ResolverEnable",
    "Protocols_Network_ResolverInterval",
    "Protocols_Network_UdpIntrospecEnable",
    "Protocols_Network_SlpEnable",
    "Protocols_Network_SlpScope",
    "Protocols_Network_SlpDirectoryAgent",
    "Protocols_Network_SlpActiveDiscovery",
    "Protocols_Network_SlpPassiveDiscovery",
    "Protocols_Network_SlpMulticastTtl",
    "Protocols_Network_SlpRegistratonLifetime",
    "Protocols_Network_SlpUseBroadcast",
    "Protocols_Network_RecoveryPointStatus",
    "Protocols_Network_NicNetworkPortSpeedDuplexMode",
    "Protocols_Network_NicFlowControl",
    "Protocols_Network_NicPrinterPortSpeedDuplexMode",
    "Protocols_Lbus",
    "Protocols_Lbus_BaudRate",
    "Protocols_Lbus_Channel",
    "Protocols_Lbus_Address",
    "Protocols_Lbus_OfflineTimeout",
    "Protocols_Lbus_OrderNumber",
    "Protocols_Lbus_CheckDigits",
    "Protocols_Lbus_OfflineCompanyIdLegacy",
    "Protocols_Lbus_OfflineCompanyIdPositionLegacy",
    "Protocols_Lbus_OfflineIndication",
    "Protocols_Lbus_OfflineOutputTime",
    "Protocols_Lbus_OfflineGreenLedTime",
    "Protocols_Lbus_OfflineRedLedTime",
    "Protocols_Lbus_OfflineCompanyId",
    "Protocols_Lbus_Key",
    "Protocols_BleHci",
    "Protocols_AccessConditionBitsStd",
    "Protocols_AccessConditionBitsStd_Tcp",
    "Protocols_AccessConditionBitsAlt",
    "Protocols_AccessConditionBitsAlt_TcpMaintenanceMode",
    "Protocols_AccessConditionBitsAlt2",
    "Protocols_AccessConditionBitsAlt3",
    "Protocols_NetworkBackup",
    "Protocols_BrpTcpBackup",
]