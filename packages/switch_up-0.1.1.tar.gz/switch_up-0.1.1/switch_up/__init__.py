"""switch-up: A secure Nintendo Switch updater for macOS."""

__version__ = "0.1.1"
