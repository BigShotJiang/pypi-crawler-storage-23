# Attocode Python - Project Guidelines

## Architecture Overview

Attocode Python is a production AI coding agent (~73,500 LOC, 315 files). Modular architecture:

```
src/
├── attocode/                Main agent package (~41,400 LOC)
│   ├── cli.py               Entry point (Click CLI, 22 options)
│   ├── commands.py           57 slash commands (~2,750L)
│   ├── config.py             Multi-level config loader
│   ├── adapters.py           Provider adapter bridge, TUI bridge protocols
│   ├── defaults.py           System defaults, 8 budget presets
│   ├── errors/               Error hierarchy (AgentError → 7 subtypes)
│   ├── shared/               Cross-agent state (5 files)
│   │   ├── budget_tracker.py
│   │   ├── context_engine.py
│   │   ├── persistence.py
│   │   ├── shared_context_state.py
│   │   └── shared_economics_state.py
│   ├── agent/                Agent core (7 files, ~2,400L)
│   │   ├── agent.py          ProductionAgent orchestrator
│   │   ├── builder.py        AgentBuilder fluent API
│   │   ├── context.py        AgentContext shared state
│   │   ├── feature_initializer.py
│   │   ├── message_builder.py
│   │   └── session_api.py
│   ├── core/                 Execution engine (7 files, ~1,500L)
│   │   ├── loop.py           Main ReAct loop
│   │   ├── agent_state_machine.py  8 lifecycle states
│   │   ├── completion.py     Completion analysis
│   │   ├── response_handler.py     LLM dispatch
│   │   ├── subagent_spawner.py
│   │   └── tool_executor.py
│   ├── tools/                13 tools (13 files, ~1,766L)
│   ├── providers/            7 LLM providers + infrastructure (12 files)
│   ├── integrations/         14 domains (127+ files)
│   ├── tui/                  Textual TUI (56+ files, 7 subdirs)
│   ├── tracing/              42 event kinds, JSONL + analysis
│   ├── tricks/               7 context engineering techniques
│   └── types/                Type definitions
├── attoswarm/                Standalone swarm package (~2,686 LOC)
└── attocode_core/            Shared AST indexing
```

## CLI Flags

All 22 Click options on `cli.py`:

| Flag | Description |
|------|-------------|
| `--model/-m` | LLM model to use |
| `--provider` | `anthropic\|openrouter\|openai\|zai\|azure` |
| `--max-tokens` | Maximum response tokens |
| `--temperature` | LLM temperature |
| `--max-iterations/-i` | Maximum agent iterations |
| `--timeout` | Request timeout (seconds) |
| `--permission/-p` | `strict\|interactive\|auto-safe\|yolo` |
| `--yolo` | Shorthand for `--permission yolo` |
| `--resume` | Resume session by ID |
| `--trace` | Save JSONL traces to `.traces/` |
| `--tui/--no-tui` | Force TUI or REPL mode |
| `--theme` | `dark\|light\|auto` |
| `--task/-t` | Task description (alt to positional) |
| `--swarm` | Swarm mode with optional config path |
| `--swarm-resume` | Resume a swarm session |
| `--hybrid` | Standalone attoswarm orchestrator |
| `--paid-only` | Only paid models |
| `--record` | Record for visual replay |
| `--debug` | Debug logging |
| `--version` | Show version |
| `--non-interactive` | CI/pipeline mode |

## Slash Commands (57)

**Core** (9): `/help`, `/status`, `/budget`, `/extend`, `/model`, `/compact`, `/save`, `/clear`, `/quit`

**Session** (7): `/sessions`, `/load`, `/resume`, `/checkpoint`, `/checkpoints`, `/reset`, `/handoff`

**Mode** (5): `/mode`, `/plan`, `/show-plan`, `/approve`, `/reject`

**Agent** (5): `/agents`, `/spawn`, `/find`, `/suggest`, `/auto`

**Thread** (5): `/fork`, `/threads`, `/switch`, `/rollback`, `/restore`

**Goals** (1): `/goals` (list/add/done/all)

**Tool/Integration** (4): `/mcp`, `/skills`, `/undo`, `/diff`

**Context** (2): `/context`, `/repomap` (symbols/deps/analyze)

**Debug** (3): `/trace`, `/grants`, `/audit`

**Info** (4): `/powers`, `/sandbox`, `/lsp`, `/tui`

**Swarm** (5): `/swarm` (init/start/status/stop/config), `/swarm-monitor`

**Config** (5): `/init`, `/theme`, `/config`, `/setup`, `/dashboard`

## Providers (7 + infrastructure)

All providers implement `LLMProvider` base in `providers/base.py`. Add new in `providers/`.

| Provider | File | Notes |
|----------|------|-------|
| Anthropic | `anthropic.py` | Primary, caching + extended thinking |
| OpenRouter | `openrouter.py` | Multi-model routing |
| OpenAI | `openai.py` | GPT-4o, o1, etc. |
| Azure | `azure.py` | Azure OpenAI endpoints |
| ZAI | `zai.py` | GLM-5 models |
| Mock | `mock.py` | Testing provider |
| Registry | `registry.py` | Provider selection/instantiation |

**Infrastructure:** `resilient_provider.py` (retry + circuit breaker), `fallback_chain.py` (provider cascading), `model_cache.py` (model metadata cache)

**ProviderCapability enum:** CHAT, STREAMING, TOOL_USE, VISION, EXTENDED_THINKING, CACHING, JSON_MODE, SYSTEM_PROMPT, MULTI_TURN, EMBEDDINGS

**Env vars:** `ANTHROPIC_API_KEY`, `OPENROUTER_API_KEY`, `OPENAI_API_KEY`, `ZAI_API_KEY`, `AZURE_OPENAI_API_KEY`

## Tools (13)

| Tool | Signature | Description |
|------|-----------|-------------|
| `read_file` | `(path, offset?, limit?)` | Read with line numbering |
| `write_file` | `(path, content)` | Create/overwrite files |
| `edit_file` | `(path, old_string, new_string, replace_all?)` | String replacement |
| `list_files` | `(path)` | Directory listing |
| `glob` | `(pattern)` | File pattern matching |
| `grep` | `(pattern, path?, glob?, max_results?, case_insensitive?)` | Regex search |
| `bash` | `(command, timeout?, cwd?)` | Shell exec with sandbox + danger classification |
| `codebase_overview` | `(mode?, directory?, symbol_type?, max_tokens?)` | Repo map / symbols |
| `ast_query` | `(...)` | AST-based code queries |
| `spawn_agent` | `(task, model?)` | Subagent delegation |
| `task_*` | various | Task management tools |
| `permission` | `(action, tool?)` | Permission management |
| Standard tools registered via `tools/registry.py` and `tools/standard.py` |

## Execution Engine

**`core/loop.py`** — Main ReAct loop with extracted helpers:
- `checkIterationBudget()` — Budget pre-flight with recovery
- `handleAutoCompaction()` — Compaction + context recovery
- `applyContextOverflowGuard()` — Mass tool result truncation

**`core/agent_state_machine.py`** — 8 lifecycle states:
`IDLE → INITIALIZING → RUNNING → PAUSED → COMPLETING → ERROR → DISPOSED`

**`core/completion.py`** — `analyze_completion()` determines stop conditions (tool_calls, max_tokens, future_intent, open_tasks, budget_limit)

**`core/response_handler.py`** — LLM dispatch (streaming/non-streaming)

## Integrations (14 domains, 127+ files)

Each subdirectory has its own `__init__.py` barrel.

| Domain | Files | Key modules |
|--------|-------|-------------|
| **agents/** | 7 | registry, async_subagent, blackboard, delegation, multi_agent, result_synthesizer, subagent_output_store |
| **budget/** | 8 | economics, loop_detector, phase_tracker, budget_pool, dynamic_budget, cancellation, injection_budget, resources |
| **context/** | 13 | codebase_context, codebase_ast, code_analyzer, code_selector, context_engineering, auto_compaction, compaction, file_cache, semantic_cache, ast_service, ast_server, ast_client, cross_references |
| **lsp/** | 1 | LSP client with builtin server configs (Python, JS, TS, Go, Rust) |
| **mcp/** | 7 | client, client_manager, config, tool_search, tool_validator, custom_tools, meta_tools |
| **persistence/** | 2 | store (12 SQLite tables), history |
| **quality/** | 6 | learning_store, auto_checkpoint, health_check, self_improvement, tool_recommendation, dead_letter_queue |
| **recording/** | 5 | graph_types (11 NodeKinds, 6 EdgeKinds), recorder, playback, exploration_tracker, assembly |
| **safety/** | 3+4 sandbox | policy_engine, bash_policy, edit_validator + sandbox/ (basic, seatbelt, landlock, docker) |
| **skills/** | 4 | loader, executor, dependency_graph, state |
| **streaming/** | 2 | handler (adapt_anthropic_stream, adapt_openrouter_stream), pty_shell |
| **swarm/** | 20 | orchestrator, execution, lifecycle, recovery, worker_pool, task_queue, quality_gate, model_selector, config_loader, event_bridge, helpers, swarm_budget, swarm_state_store, failure_classifier, cc_spawner, request_throttle, roles, critic, types |
| **tasks/** | 9 | task_manager, decomposer (ComplexityTier), interactive_planning, pending_plan, work_log, planning, task_splitter, dependency_analyzer, verification_gate |
| **utilities/** | 24 | resilience, routing, file_change_tracker, mode_manager, thread_manager, capabilities, hooks, memory, hierarchical_config, undo, execution_policy, complexity_classifier, rules, thinking_strategy, tool_coercion, ignore, retry, resilient_fetch, environment_facts, diff_utils, logger, token_estimate |

## TUI Architecture

Textual-based TUI in `tui/` (56+ files across 7 subdirectories):

- **Core** (6): `app.py`, `theme.py`, `events.py`, `event_hooks.py`, `__init__.py`
- **widgets/** (26): message_log, input_area, status_bar, command_palette, plan_panel, thinking_panel, tool_calls, streaming_buffer, debug_panel, diagnostics_panel, diff_view, side_by_side_diff, collapsible_diff, file_change_summary, error_detail_panel, metrics_table, token_sparkline, transparency_panel, welcome_banner, mascot, tasks_panel, agents_panel, agent_internals_panel, swarm_panel
- **widgets/swarm/** (14): agent_grid, ast_blackboard_pane, dag_view, decisions_pane, detail_inspector, event_timeline, file_activity_map, files_pane, model_health_pane, overview_pane, quality_pane, task_board, tasks_pane, workers_pane
- **widgets/dashboard/** (5+viz): compare_pane, live_dashboard, session_browser, session_detail, swarm_activity_pane + `viz/` (ascii_table, bar_chart, percent_bar, severity_badge, sparkline, tree_renderer)
- **dialogs/** (4): approval, budget, learning_validation, setup
- **screens/** (6): dashboard, focus_screen, swarm_dashboard, swarm_monitor, task_detail_screen, timeline_screen
- **bridges/** (2): approval_bridge, swarm_bridge
- **styles/** (5 TCSS): app, dashboard, dialogs, swarm_dashboard, swarm

## Tracing

42 event kinds across 16 categories in `tracing/types.py`:

| Category | Events |
|----------|--------|
| SESSION | session_start, session_end |
| ITERATION | iteration_start, iteration_end |
| LLM | llm_request, llm_response, llm_error, llm_retry |
| TOOL | tool_start, tool_end, tool_error, tool_approval |
| BUDGET | budget_check, budget_warning, budget_exhausted |
| COMPACTION | compaction_start, compaction_end, context_overflow |
| SUBAGENT | subagent_spawn, subagent_complete, subagent_error, subagent_timeout |
| SWARM | swarm_start, swarm_complete, swarm_wave_start, swarm_wave_complete, swarm_task_start, swarm_task_complete, swarm_task_failed |
| PLAN | plan_created, plan_step_start, plan_step_complete |
| QUALITY | quality_check, learning_proposed |
| ERROR | error, recovery |
| MODE | mode_change |
| MCP | mcp_connect, mcp_disconnect |
| FILE | file_change |
| CHECKPOINT | checkpoint |
| CUSTOM | custom |

**Analysis** (`tracing/analysis/`): inefficiency_detector, session_analyzer, token_analyzer, views

## Context Engineering (Tricks)

7 techniques in `tricks/`:
- `reversible_compaction.py` — Summarize with retrieval references
- `kv_cache.py` — KV-cache optimization
- `failure_evidence.py` — Track and learn from failures
- `recitation.py` — Goal persistence/recitation
- `recursive_context.py` — Nested context handling
- `serialization_diversity.py` — Diverse serialization strategies
- `json_utils.py` — JSON serialization utilities

## Error Hierarchy

`errors/__init__.py` defines a typed error tree:

```
AgentError (base, category + retryable + details)
├── LLMError           (empty response, malformed output)
├── ProviderError      (rate limit, network, auth; has provider + status_code)
├── ToolError          (execution failures; has tool_name)
│   ├── ToolNotFoundError
│   └── ToolTimeoutError
├── BudgetExhaustedError
├── CancellationError
├── PermissionDeniedError  (has tool_name)
└── ConfigurationError
```

`ErrorCategory` enum: LLM, PROVIDER, TOOL, BUDGET, CANCELLATION, PERMISSION, CONFIGURATION, INTERNAL

## Config System

`config.py` loads `AttoConfig` with multi-level priority: **CLI > env vars > project config > user config > defaults**

Key fields:
- **Provider:** provider, model, api_key
- **Execution:** max_tokens, temperature, max_iterations, timeout
- **Budget:** budget_max_tokens, budget_max_cost, budget_max_duration
- **Features:** sandbox_mode, debug, record, trace
- **Permission:** strict | interactive | auto-safe | yolo

`defaults.py` budget presets: QUICK, STANDARD, DEEP, SUBAGENT, LARGE, UNLIMITED, SWARM_WORKER, SWARM_ORCHESTRATOR

## Key Patterns

### Builder Pattern
Agent construction uses `AgentBuilder` fluent API in `agent/builder.py`.

### Policy Engine
Tool permissions use `PolicyEngine` with configurable rules. Default safe tools (read_file, glob, grep) are auto-allowed.

### Integrations
Each subdirectory under `integrations/` has its own `__init__.py` barrel.

## Common Commands

```bash
# Development
uv sync --all-extras             # Install everything (creates .venv)
uv run pytest tests/             # Run all tests
uv run pytest tests/unit/ -x -q  # Quick unit tests
uv run ruff check src/ tests/    # Linting

# Running
uv run attocode                          # Interactive TUI
uv run attocode "Fix the bug"            # Single-turn
uv run attocode --swarm "Build feature"  # Swarm mode
uv run attocode --resume <id>            # Resume session
uv run attocode --debug                  # Debug logging
uv run attocode --record                 # Record for replay
uv run attocode --hybrid "Build feat"    # Standalone attoswarm
uv run attocode --provider zai "task"    # ZAI provider
uv run attocode --trace                  # Enable tracing
uv run attocode --permission yolo "task" # Auto-approve all
uv run attocode --non-interactive "task" # CI mode

# Fallback (pip)
# pip install -e ".[dev]" && pytest tests/
```

## Code Style

- Python 3.12+ with `from __future__ import annotations`
- `@dataclass(slots=True)` for data classes
- `StrEnum` for string enums
- Type hints on all public APIs
- `Any` for integration boundaries (lazy imports)

## Testing

```bash
uv run pytest tests/unit/ -x -q          # Quick unit tests
uv run pytest tests/ --cov=src/attocode  # With coverage
uv run ruff check src/ tests/            # Linting
```

Tests in `tests/` directory:
- `tests/unit/` - Unit tests (fast, no I/O)
- `tests/integration/` - Integration tests
- Pre-existing failures: `test_mcp.py::test_empty_when_no_files`, `test_attoswarm_smoke.py`

## Session Persistence

SQLite store in `integrations/persistence/store.py` (`.attocode/sessions/sessions.db`):
- Auto-initialized when agent starts
- 12 tables: sessions, checkpoints, goals, tool_calls, file_changes, etc.
- `--resume <id>` flag restores conversation from checkpoint

## Sandbox System

Platform-aware isolation in `integrations/safety/sandbox/`:
- **BasicSandbox** - Allowlist/blocklist validation
- **SeatbeltSandbox** - macOS sandbox-exec
- **LandlockSandbox** - Linux Landlock LSM (ctypes syscalls)
- **DockerSandbox** - Container isolation

## Recording System

Full session graph recording in `integrations/recording/`:
- `SessionGraph` - Unified DAG (11 NodeKinds, 6 EdgeKinds)
- `PlaybackEngine` - Frame-by-frame replay with filtering
- `ExplorationGraph` - File navigation DAG (legacy, still used)

## Skills System

`integrations/skills/`:
- Dependency resolution via topological sort
- Version compatibility checks
- Lifecycle modes: simple (prompt injection) or long_running (init/execute/cleanup)
- State persistence via `SkillStateStore`

## Swarm Mode

```bash
uv run attocode --swarm "Build a REST API"           # Auto config
uv run attocode --swarm .attocode/swarm.yaml "task"  # Custom config
uv run attocode --swarm-resume <SESSION_ID>           # Resume
uv run attocode --hybrid "task"                       # Standalone attoswarm
```

20 modules in `integrations/swarm/` (~10,343L): orchestrator, execution, lifecycle, recovery, worker_pool, task_queue, quality_gate, model_selector, config_loader, event_bridge, helpers, swarm_budget, swarm_state_store, failure_classifier, cc_spawner, request_throttle, roles, critic, types

## Publishing to PyPI

Package is on PyPI as `attocode`. Published via `uv build` + `uv publish`.

```bash
# Manual release
uv build                                  # produces dist/*.whl + *.tar.gz
uv publish --token $UV_PUBLISH_TOKEN dist/*
```

**GitHub Actions (preferred):** Trusted publisher configured on PyPI (owner: `eren23`, workflow: `release.yml`, environment: `pypi`). To release:

```bash
git tag v0.1.9 && git push origin v0.1.9  # triggers .github/workflows/release.yml
```
