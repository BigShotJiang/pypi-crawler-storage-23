"""Dependency graph utilities."""
