"""AST indexing utilities."""
