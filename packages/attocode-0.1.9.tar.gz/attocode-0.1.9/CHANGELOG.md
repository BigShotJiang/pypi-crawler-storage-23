# Changelog

All notable changes to the Attocode Python agent will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Planned

- Fix `attoswarm tui` not picking up new TUI widgets when installed via `uv tool install`
- Enabling code understanding tools of attocode to other AI coders as a skill system

## [0.1.9] - 2026-03-03

### Added

- **7 new MCP code-intel tools** (18 total): `lsp_definition`, `lsp_references`, `lsp_hover`,
  `lsp_diagnostics`, `explore_codebase`, `security_scan`, `semantic_search`
- **Import resolution fix for `src/` layout** — `_detect_source_prefixes()` +
  `_build_file_index()` in `codebase_context.py` fixes dependency graph for projects using
  `src/` package layout (orphan rate: ~100% → 8%, edges: 0 → 1,062)
- **Hierarchical codebase explorer** — `hierarchical_explorer.py` with single-level drill-down,
  importance scores, and symbol annotations
- **Security scanner** — `integrations/security/` with pattern-based secret detection,
  anti-pattern scanning, dependency audit
- **Semantic search** — `integrations/context/semantic_search.py` with keyword-based fallback
  (embedding support optional)
- **Vector store + embeddings** — `vector_store.py` and `embeddings.py` for optional
  embedding-powered search
- **LSP tools** — `tools/lsp.py` registers go-to-definition, references, hover, diagnostics
  as agent tools
- **Explore tool** — `tools/explore.py` for hierarchical codebase navigation
- **Security tool** — `tools/security.py` for codebase security scanning
- **Semantic search tool** — `tools/semantic_search.py` for natural language code search
- **File change notifications** — `_notify_file_changed()` in tool executor notifies codebase
  context, hierarchical explorer, and AST service on file writes/edits
- **LSP enabled by default** — lazy initialization means no cost until first LSP tool call
- **Swarm TUI differential updates** — `AgentsDataTable` and `TasksDataTable` preserve cursor
  position across refreshes
- **AoT graph enhancements** — partial-dependency execution support, timeout overrides per task,
  agent assignment annotations in `DependencyTree`
- **attoswarm decomposer** — new `coordinator/decompose.py` module
- **Project metadata** — authors, keywords, classifiers, and project URLs added to `pyproject.toml`

### Changed

- MCP code-intel server expanded from 11 to 18 tools
- `FeatureConfig.enable_lsp` default changed from `False` to `True`
- `PolicyEngine` — new safe tool rules for explore, security, and LSP tools
- Barrel exports updated in `integrations/__init__.py` and `integrations/context/__init__.py`

### Fixed

- **Dependency graph completely broken for `src/` layout projects** — imports like
  `from attocode.core.loop import ...` were unresolvable because the file index only contained
  `src/attocode/core/loop.py` keys; the resolver looked up `attocode/core/loop.py` which didn't
  match. Now `_build_file_index()` adds prefix-stripped alternate keys. This fixes
  `dependency_graph`, `dependencies`, `impact_analysis`, `hotspots`, and `project_summary`
  MCP tools.

### Tests

- `test_decompose.py` — new decomposer tests
- Updated `test_aot_graph.py`, `test_scheduler.py`

## [0.1.8] - 2026-03-02

### Added

- **Hotspots: percentile-based scoring** — composite scores now use project-relative
  percentile ranks (0.0-1.0) instead of raw values, adapting to any project size
- **Hotspots: adaptive category thresholds** — god-file, hub, coupling-magnet, and
  new wide-api categories use P90 of project distribution with minimum floors
- **Hotspots: function-level hotspots** — "Longest functions" section shows top 10
  functions by composite complexity (length + params + missing return type)
- **Hotspots: public API surface** — `pub=N` metric per file, `wide-api` category
  for files with many public symbols
- **Conventions: per-directory divergence** — detects when directories (e.g. tests/)
  diverge > 20pp from project-wide type hint or docstring rates
- **Conventions: error hierarchy detection** — scans for Exception subclasses,
  reports root exceptions and subtypes
- **Conventions: `__all__` detection** — counts files defining `__all__` exports
- **Conventions: `slots=True` / `frozen=True`** — enhanced dataclass decorator parsing
- **Conventions: visibility distribution** — reports public/private function percentages
- **Conventions: method types** — reports @staticmethod, @classmethod, @property counts
- **Code-intel MCP server** — `attocode-code-intel` standalone MCP server exposing 11
  code intelligence tools (repo_map, symbols, search_symbols, dependencies,
  impact_analysis, cross_references, file_analysis, dependency_graph,
  project_summary, hotspots, conventions) for use by any MCP-compatible AI assistant
- **Code-intel installer** — `attocode code-intel install <target>` installs the MCP
  server into Claude Code, Cursor, Windsurf, or Codex; `uninstall` and `status` commands
- **Codex installer support** — `attocode code-intel install codex` writes
  `.codex/config.toml` (TOML-based config) with `--global` for user-level install
- **`tomli_w` dependency** — added for TOML writing support (Codex config)

## [0.1.7] - 2026-03-01

### Added

- **Swarm TUI overhaul** — TabbedContent layout with 5 tabs (Overview, Tasks, Agents, Events, Messages)
- `TasksDataTable`, `AgentsDataTable` — DataTable widgets with row selection and status icons
- `EventsLog` — RichLog with delta-append, auto-scroll, color-coded events
- `DependencyTree` — Tree widget with collapsible task dependency hierarchy
- `MessagesLog` — orchestrator-worker inbox/outbox message viewer
- `SwarmSummaryBar` — always-visible phase/counts/cost/elapsed summary
- `dag_summary` and `elapsed_s` fields in SwarmState
- Enriched DAG nodes with description, task_kind, role_hint, assigned_agent, target_files, result_summary, attempts
- `read_all_messages()` in StateStore for unified inbox/outbox timeline
- Richer task transition events with `assigned_agent`; `model` field in `_active_agents()`

### Fixed

- Tasks stuck in PENDING column — status_map missing `running`, `reviewing`, `blocked`, `done` statuses
- Agent status override (was always "running"/"idle", now uses actual status from state)
- Footer showing 0/0 (dag_summary and elapsed_s not written to state)
- Event timeline flicker (switched from Static full-rerender to RichLog delta-append)
- Double-click requirement for task/agent selection (switched to DataTable cursor_type="row")

### Known Bugs

- `attoswarm tui` shows old layout when installed via `uv tool install .` — tool snapshot doesn't pick up working-tree widget changes from `attocode` package. Workaround: use `uv run attoswarm tui` from project dir, or commit and reinstall.

## [0.1.6] - 2026-03-01

### Added

- **Tool argument normalization** — `_normalize_tool_arguments()` with alias mapping, fuzzy matching, and type coercion for non-Anthropic LLMs (GLM-5 etc.)
- **Improved tool descriptions** — explicit parameter names in write_file, edit_file, read_file, list_files, glob_files, bash
- **New provider tests** — Azure, OpenAI, OpenRouter, fallback chain, resilient provider
- **New integration tests** — MCP split, quality, tasks, verification gate, interactive planning
- **New tricks tests** — failure evidence, KV cache, recitation, reversible compaction

### Changed

- Tool executor wires `coerce_tool_arguments()` into execution pipeline (was built but never called)
- Various provider, integration, and safety module improvements

### Fixed

- Mermaid diagrams not rendering on GitHub Pages documentation (added mermaid.js CDN + init script)
- Recording gallery HTML not rendering exploration graph mermaid diagrams (switched to `<div class="mermaid">` + mermaid.js)

## [0.1.5] - 2026-02-28

### Added

- **Session resume & persisted permission grants** — `/resume` works in-session; grants loaded from DB on startup
- **Skill system overhaul** — long-running lifecycle (init/execute/cleanup), `SkillStateStore` for persistent state, `SkillDependencyGraph` with topological sort and version compatibility
- **Unified session graph recording** — `SessionGraph` DAG covering all event types (LLM, tools, subagents, budget, compaction); `PlaybackEngine` for frame-by-frame replay with filtering; Mermaid diagram export
- **Landlock sandbox enforcement** — actual Linux ctypes syscall wrappers (`PR_SET_NO_NEW_PRIVS`, `ruleset_create`/`add_rule`/`restrict_self`) replacing shell fallback
- **Swarm TUI data enrichment** — per-task JSON persistence, DAG+event fallback reconstruction, agent cards show task titles and model info, `TaskDetailScreen` modal, `agent_id` in all swarm events
- **Thread manager serialization** — `snapshot_all()`, `restore_snapshots()`, `to_dict()`/`from_dict()` for DB persistence
- **Policy engine grant loading** — `load_grants()` bulk import, `approved_commands` property
- **TUI theme management** — `set_theme()` with dark/light/auto, `active_theme_name` property
- **Documentation** — Architecture, Providers, Sandbox, Budget, MCP, Testing guides; Contributing guide; LICENSE file
- **CI/CD pipeline** — `.github/workflows/` with GitHub Actions
- **Package typing markers** — `py.typed` for `attocode_core` and `attoswarm`
- **Example swarm project** — [attocodepy_swarmtester_3](https://github.com/eren23/attocodepy_swarmtester_3) demonstrates hybrid swarm orchestration

### Changed

- Swarm orchestrator writes enriched `active_agents` (model, task_title) and per-task JSON files
- `SubagentManager._emit_status()` propagates model through all lifecycle phases
- `StateStore.build_task_detail()` falls back to DAG+event reconstruction when task files missing
- `StateStore.build_agent_detail()` enriched with task_title, duration from events, result message
- Agent grid shows task title (30 chars) instead of raw task_id
- Task board column headers include "click to inspect" hint
- Detail inspector shows task_title/duration/result for agents, agent/model/duration for tasks

### Tests

- New test modules for: agent state machine, subagent spawner, blackboard, delegation, budget pool, dynamic budget, graph types, playback, docker/landlock/seatbelt sandboxes, skill dependency graph, skill state, skill executor, thread manager

## [0.1.4] - 2026-02-27

### Added

- **MCP integration overhaul**
  - `MCPClient.connect()` now expands `${VAR}` env references via `_expand_env()` and inherits parent `os.environ` (previously child process lost PATH)
  - Agent uses `MCPClientManager` for MCP lifecycle (eager + lazy loading)
  - `/mcp list` shows real connection state (connected/failed/pending) instead of always "configured"; failed servers show error message
  - `/mcp tools`, `/mcp search`, `/mcp stats` fallback to `_registry` when ctx is not yet available
  - `ToolRegistry.set_tool_resolver()` for lazy MCP tool discovery

- **Swarm system enhancements**
  - New modules: `cc_spawner.py` (Claude Code subprocess spawner), `critic.py` (wave review + fixup tasks), `roles.py` (role config with scout/critic/judge)
  - Wave review: critic role can assess completed waves and generate fixup tasks
  - Scout pre-execution: read-only agent gathers codebase context before implementation tasks
  - Quality gate wired to execution with LLM judge scoring, threshold relaxation for foundation tasks, retry with feedback
  - Model failover on consecutive timeouts/rate-limits
  - Hollow detection emits `swarm.hollow_detected` events
  - Task completion events now include output, files_modified, tool_calls, session_id, num_turns, stderr

- **`/swarm` command group** — 7 subcommands: `init`, `start`, `status`, `stop`, `dashboard`, `config`, `help`
  - `/swarm init` auto-generates `.attocode/swarm.yaml` from current model
  - `/swarm start <task>` launches swarm execution inline
  - `/swarm status` shows live task/worker/phase state

- **TUI improvements**
  - Swarm dashboard: 8 new dedicated panes (overview, tasks, workers, quality, files, decisions, model health, AST blackboard)
  - `swarm_dashboard.tcss` stylesheet
  - Focus screen refactored with improved layout
  - Swarm monitor: enhanced rendering and state display
  - Status bar: new swarm-aware metrics
  - Tool calls widget: expanded display
  - Event system: new event types and hooks for swarm integration
  - `AgentInternalsPanel` widget

- **Timeline screen** — `TimelineScreen` accepts `state_fn` callback for live polling with 0.5s timer and proper `on_unmount` cleanup

- **`AgentConfig`** gains `provider` and `api_key` fields
- **`PolicyEngine`** — new safe rules for `codebase_overview`, `get_repo_map`, `get_tree_view`
- **`TraceCollector._increment_counters()`** internal API + `TraceWriter` wired to it

### Changed

- **Timeout defaults** increased from 120s → 600s across all providers (Anthropic, OpenAI, OpenRouter, Azure, ZAI, resilient provider)
- **Subagent timeouts** tripled (e.g. default 5min → 15min, researcher 7min → 20min)
- **Subagent max iterations** doubled (e.g. default 15 → 30, researcher 25 → 50)
- **Timeout extension on progress** 60s → 120s; budget max duration 3600s → 7200s
- **`AgentBuilder.with_provider()`** now forwards `timeout` kwarg
- **Streaming failure fallback** — execution loop now falls back to non-streaming before erroring
- **`httpx.StreamError`** now caught in OpenAI/OpenRouter `chat_stream()`
- **`_describe_request_error()`** helper for OpenAI/OpenRouter — better error messages for httpx timeouts
- **`InefficiencyDetector._detect_empty_responses()`** skips events lacking token data (fewer false positives)
- **Agent's `_run_with_swarm()`** rewritten: uses `cc_spawner`, `SwarmEventBridge`, AST server sharing, proper result mapping
- **`SwarmConfig`** gains new fields; barrel re-exports for cc_spawner, roles, critic
- **attoswarm CLI** — major refactor with proper backend command building (`_build_backend_cmd`), environment variable stripping for nested agent sessions (`_STRIP_ENV_VARS`), `RoleConfig` support in schema

## [0.1.3] - 2026-02-26

### Added

- **Recording integration** — `integrations/recording/` with `RecordingSessionManager` for session capture; `--record` CLI flag and `record` config option; HTML export for visual replay
- **Codebase tools** — `tools/codebase.py` with `get_repo_map`, `get_tree_view`; auto-registered when codebase context is available; preseed repo map injected on first run so the LLM has project structure from turn 1
- **AST services** — `ast_service.py`, `cross_references.py` with `ASTService`, `CrossRefIndex`, `SymbolLocation`, `SymbolRef`; exported from context integration
- **Model cache** — `providers/model_cache.py` with `init_model_cache()` and model context-window lookup; replaces hardcoded 200k default with per-model values
- **attoswarm coordinator** — `coordinator/aot_graph.py`, `event_bus.py`, `orchestrator.py`, `subagent_manager.py`; `workspace/file_ledger.py`, `reconciler.py` for multi-agent file coordination
- **attoswarm TUI** — Swarm dashboard, focus screen, timeline screen; `swarm_bridge.py`; `swarm/` widgets; `swarm.tcss` styles
- **CLI** — `--version` flag; `--record` flag
- **Config** — `record` option for session recording

### Changed

- **Conversation persistence** — Messages persist across TUI runs; subsequent prompts carry over prior conversation; `/clear` resets conversation history in addition to screen
- **Doom loop blocking** — Tool calls identical 5+ times are hard-blocked before execution with `LoopDetector.peek()`; blocked calls return structured error for the LLM
- **Completion analysis** — Removed future-intent and incomplete-action heuristics from `analyze_completion()`
- **Tool events** — `TOOL_START`, `TOOL_COMPLETE`, `TOOL_ERROR` now include `args` and `iteration` metadata
- **Codebase context** — Extended with preseed map, symbol extraction; `get_preseed_map()` for first-turn injection

### Tests

- `test_aot_graph.py`, `test_event_bus.py`, `test_file_ledger.py`, `test_reconciler.py`, `test_stores.py` — attoswarm coordinator and workspace
- `test_ast_service.py` — AST service
- `test_model_cache.py` — model cache pricing and context lookup
- `test_recording/` — recording integration
- Updated `test_codebase_context.py`, `test_completion.py`, `test_anthropic.py`, `test_attoswarm_snapshots.py`

## [0.1.2] - 2026-02-24

### Added

- **`attoswarm` package** — standalone hybrid swarm orchestrator with file-based coordination protocol
  - `coordinator/loop.py` — `HybridCoordinator` main loop with task state machine, dependency DAG, watchdog, budget enforcement
  - `coordinator/scheduler.py` — dependency-aware task assignment matching roles to free agents
  - `coordinator/merge_queue.py` — completion claim tracking with judge/critic quality gates
  - `coordinator/state_writer.py` — atomic state snapshot persistence
  - `coordinator/budget.py` — token + cost tracking with hard-limit enforcement
  - `coordinator/watchdog.py` — heartbeat-based agent health monitoring
  - `adapters/` — subprocess-based agent adapters for Claude, Codex, Aider, and Attocode backends with stdin/stdout line protocol
  - `protocol/` — `TaskSpec`, `RoleSpec`, `SwarmManifest`, `InboxMessage`, `OutboxEvent` models; atomic JSON I/O; file-based locks
  - `workspace/worktree.py` — git worktree isolation per agent with branch lifecycle and graceful fallback when `.git` missing
  - `config/` — YAML config loader with `SwarmYamlConfig` schema (roles, budget, merge, orchestration, watchdog, retries)
  - `cli.py` — Click CLI with `run`, `start`, `tui`, `resume`, `inspect`, `doctor`, `init` commands
  - `tui/` — Textual dashboard for live run monitoring (phase, tasks, agents, events)
  - `replay/` — `attocode_bridge.py` for replaying swarm runs
  - Decomposition modes: `manual`, `fast`, `parallel`, `heuristic`, `llm` (falls back to `parallel`)
  - Heartbeat wrapper script with `[HEARTBEAT]`/`[TASK_DONE]`/`[TASK_FAILED]` protocol markers and debug mode
  - Task state machine: `pending → ready → running → reviewing → done/failed` with transition validation
- **`attocode_core` package** — shared utilities extracted for cross-package use
  - `ast_index/indexer.py` — `CodeIndex.build()` scans Python/TS/JS files for symbols (functions, classes, imports)
  - `dependency_graph/graph.py` — `DependencyGraph.from_index()` with `impacted_files()` transitive closure
- **TUI swarm monitor** (`src/attocode/tui/screens/swarm_monitor.py`) — fleet-level Textual screen
  - Auto-discovers runs via `**/swarm.state.json` glob
  - Fleet view with phase, task counts, agent counts, error counts
  - Per-run detail: tasks table (state, kind, role, attempts, title, error), events table (heartbeat/stderr filtered), agents table (CWD, restarts)
  - Budget display in title bar (tokens + USD)
  - File change events shown inline in events table
  - `Ctrl+M` binding and `/swarm-monitor` command
- **CLI hybrid swarm integration**
  - `--hybrid` flag routes to `attoswarm` coordinator
  - `attocode swarm <subcommand>` passthrough (start, run, doctor, init, tui, inspect, resume)
  - `attocode swarm monitor` aliased to `attoswarm tui`
- **`TraceVerifier`** (`tests/helpers/trace_verifier.py`) — post-run integrity checker
  - 7 checks: poisoned prompts, task transition FSM, terminal events, stuck agents, budget limits, exit code propagation, coding task output evidence
  - `run_all()` + `summary()` for CI/manual use
- **`SyntheticRunSpec`** test fixtures (`tests/helpers/fixtures.py`) — builds complete fake run directories for deterministic TUI/integration testing
- **Example config** (`.attocode/swarm.hybrid.yaml.example`) — ready-to-copy hybrid swarm config
- **Operations guide** (`docs/hybrid-swarm-operations.md`) — runbook covering prerequisites, commands, observability, configs, test matrix, TUI ops, failure modes
- **`swarm-verify` skill** (`.attocode/skills/swarm-verify/`) — skill for verifying swarm run integrity
- **File change detection on task completion** — `_detect_file_changes()` runs `git diff --name-only HEAD` + `git ls-files --others` in agent worktree, emits `task.files_changed` event
- **Workspace mode in spawn events** — `agent.spawned` events include `cwd`, `workspace_mode`, `workspace_effective`

### Changed

- `_run_single_turn()` now exits with code 1 when `result.success` is False
- Version test no longer asserts specific version number

### Tests

- **`tests/unit/attoswarm/`** (9 files, ~60 tests) — scheduler dependency resolution, worktree creation/fallback/cleanup, heartbeat wrapper generation, merge queue roundtrip, budget overflow, CLI commands, adapter parsing, resume, spawn logging
- **`tests/unit/attocode_core/`** (1 file) — `CodeIndex.build()` Python symbol extraction
- **`tests/unit/tui/test_attoswarm_snapshots.py`** (5 snapshot tests) — empty init, executing, completed, failed with errors, many agents
- **`tests/unit/test_trace_verifier.py`** (22 tests) — all 7 verifier checks with pass/fail cases
- **`tests/integration/test_attoswarm_smoke.py`** — deterministic smoke tests using fake worker scripts
- **`tests/integration/test_attoswarm_live_smoke.py`** — opt-in live backend tests (`ATTO_LIVE_SWARM=1`)
- **`tests/unit/test_cli.py`** — swarm passthrough dispatch, exit code propagation (success + failure)

## [0.1.1] - 2026-02-22

### Fixed

- **Dashboard CSS ID mismatch** — Tab bar (`#dashboard-tab-bar`) and footer bar (`#dashboard-footer-bar`) were unstyled because CSS selectors targeted non-existent `#dashboard-header` and `#dashboard-footer` IDs. Selectors now match the actual widget IDs rendered in `DashboardScreen.compose()`.
- **Deleted files silently failing in incremental AST updates** — `CodebaseContextManager.update_dirty_files()` would throw on `Path.read_text()` for deleted files and silently `continue`, leaving the file permanently in `_dirty_files`. Now checks `Path.exists()` first; if deleted, removes the file from `_ast_cache`, `_file_mtimes`, and all forward/reverse dependency graph edges, and emits `SymbolChange(kind="removed")` for each symbol so downstream consumers are notified.
- **Memory leak from empty sets in reverse dependency graph** — After `rev.discard(rel_path)`, empty sets remained as keys in `_dep_graph.reverse`. Now cleaned up with `del self._dep_graph.reverse[target]` when the set becomes empty.
- **Dead code in `loop.py`** — Removed unreachable `_codebase_ast` and `_code_analyzer` invalidation branches in `_handle_file_edit()`. These attributes are never initialized on the agent context; only the `codebase_context.mark_file_dirty()` + `update_dirty_files()` path is live.

### Added

- **LLM streaming events wired to live dashboard** — `LLMStreamEnd` events (the majority of LLM calls) now feed `LiveTraceAccumulator.record_llm()`. Previously only non-streaming `LLMCompleted` events were tracked, making the live dashboard blind to most LLM activity.
- **Budget warning tracking in live dashboard** — `LiveTraceAccumulator` now has `budget_warnings` and `last_budget_pct` fields. `on_budget_warning()` feeds these, and the Session Stats box in the live dashboard displays budget warning count and last reported percentage.
- **JS/TS class method extraction** — `parse_javascript()` now tracks `current_class` with brace depth and extracts methods into `ClassDef.methods`, matching the Python parser's behavior. Previously JS class methods were invisible to `diff_file_ast()` and the repo map.
- **JS/TS function return type capture** — `parse_javascript()` now captures return type annotations (e.g., `: Promise<void>`) for both top-level functions and class methods via an extended regex pattern.
- **Session sorting in browser** — Session browser pane supports `s` key to cycle through sort modes: newest first (default), cost descending, efficiency descending, iterations descending. Sort is applied after text filtering.
- **Per-iteration cost column in token flow view** — Token flow table in session detail now shows an "Iter Cost" column (`cumulative_cost - prev_cost`) alongside the existing cumulative cost, making it easy to identify expensive iterations.
- **Empty/loading states for dashboard panes** — Session detail shows "Select a session from the Sessions tab to view details." when no session is loaded. Compare pane shows updated guidance. Session browser shows descriptive message when no trace directory or files exist.

### Tests

- **`test_live_dashboard.py`** (14 tests) — `LiveTraceAccumulator`: LLM recording, rolling windows, tool counting, error tracking, cache rate calculation, top tools sorting, empty defaults, iteration recording, budget warning fields.
- **`test_viz_widgets.py`** (27 tests) — `SparkLine`: empty/single/uniform/normal data, max width. `BarChart`: empty/single/aligned items, zero values. `PercentBar`: 0%/50%/100%/clamped values, threshold colors (green/yellow/red), labels. `ASCIITable`: empty/single row, alignment, separator, missing cells, content height. `SeverityBadge`: all severity levels, unknown fallback, case insensitivity, bracket formatting.
- **`test_analysis.py`** (22 tests) — `SessionAnalyzer`: summary metrics, efficiency score range, zero-iteration safety, timeline ordering/structure, token flow cumulative cost/sorting, tree grouping by iteration. `InefficiencyDetector`: excessive iterations (spinning detection, no false positives with tools), repeated tool calls (doom loop, threshold), token spikes (detection, uniform data). `TokenAnalyzer`: cache efficiency, token breakdown, total cost, cost by iteration, token flow points.
- **`test_dashboard_panes.py`** (21 tests) — `SessionInfo` dataclass creation and slots. `DashboardScreen`: tab definitions, keys, labels, pane IDs, default/custom init, tab cycling math, detail flag. `SessionDetailPane`: sub-tab keys and labels. `ComparePane`: initial state.

## [0.1.0] - 2026-02-20

### Added

- **Core agent** — `ProductionAgent` with ReAct execution loop, tool registry, and event system
- **LLM providers** — Anthropic, OpenRouter, OpenAI, Azure, ZAI adapters with fallback chains
- **Built-in tools** — file operations (read/write/edit/glob/grep), bash executor, search, agent delegation
- **TUI** — Textual-based terminal interface with message log, streaming buffer, tool call panel, status bar, thinking panel, swarm panel, and keyboard shortcuts
- **Budget system** — execution economics, loop detection, phase tracking, dynamic budget pools, cancellation tokens
- **Context engineering** — auto-compaction, reversible compaction, KV-cache optimization, failure evidence tracking, goal recitation, serialization diversity
- **Safety** — policy engine, bash classification, sandbox system (seatbelt/landlock/docker/basic)
- **Persistence** — SQLite session store with checkpoints
- **MCP integration** — client, tool search, tool validation, config loader
- **Swarm mode** — multi-agent orchestrator with task queue, worker pool, quality gates, wave execution, recovery, event bridge
- **Tasks** — smart decomposer, dependency analyzer, interactive planning, verification gates
- **Quality** — learning store, self-improvement, auto-checkpoint, dead letter queue, health checks
- **Utilities** — hooks, rules, routing, retry, diff utils, ignore patterns, thinking strategy, complexity classifier, mode manager, file change tracker, undo
- **CLI** — Click-based with `--model`, `--provider`, `--swarm`, `--tui/--no-tui`, `--yolo`, `--trace`, `--resume` flags
- **Tracing** — JSONL execution trace writer with cache boundary detection
- **Skills & agents** — loader, executor, registry for `.attocode/` directory system
- **LSP integration** — language server protocol client
