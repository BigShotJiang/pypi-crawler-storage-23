"""
This module contains the base classes for constraints in the fandango library.
"""

LEGACY = False
