from abstra_internals.interface.sdk.user_exceptions import DeprecatedModule

raise DeprecatedModule("You must call use_legacy_threads before importing this module")
