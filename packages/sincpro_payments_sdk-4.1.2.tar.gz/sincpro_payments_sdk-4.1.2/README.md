## Sincpro payments

> Allow easy interface to interact with the payment gateway

- Cybersource Linkser as provider
- BNB QR API




 