"""Exceptions module."""

from typing import Any


class SincproBaseError(Exception):
    """Base exception for all Sincpro SDK errors.

    Consumers can catch this single type for any SDK error.
    """

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)


class SincproValidationError(SincproBaseError):
    """Validation error exception."""


class SincproProgrammingError(SincproBaseError):
    """Programming / developer error.

    Raised when the SDK encounters a situation that indicates a bug
    in the integration code or an unexpected response shape
    (e.g. missing dict keys, wrong types).
    """


class SincproExternalServiceError(SincproBaseError):
    """External service error exception."""


class SincproHTTPError(SincproExternalServiceError):
    """HTTP error with status code and response details.

    Raised by ClientAPI when the external service returns an HTTP error (4xx/5xx)
    or a network-level failure (ConnectionError, Timeout).

    Inherits from SincproExternalServiceError so catching the parent
    covers both simple service errors and HTTP-specific ones.
    """

    def __init__(
        self,
        message: str,
        http_code: int | None = None,
        reason: str | None = None,
        content: Any = None,
        text: str | None = None,
    ) -> None:
        self.http_code = http_code
        self.reason = reason
        self.content = content
        self.text = text
        detail = text or content or ""
        full_message = f"{message}: {detail}" if detail else message
        super().__init__(full_message)
