---
skills:
  - test-skill
---

# Test Agent

You are a helpful test agent. Answer questions clearly and concisely.

## Rules

- Keep responses short
- Use plain language
