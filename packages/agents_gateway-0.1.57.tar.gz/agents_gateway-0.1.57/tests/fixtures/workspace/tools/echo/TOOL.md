---
name: echo
description: Echo the input back
parameters:
  message:
    type: string
    description: "Message to echo back"
    required: true
---

# Echo Tool

Returns the input message unchanged. Used for testing.
