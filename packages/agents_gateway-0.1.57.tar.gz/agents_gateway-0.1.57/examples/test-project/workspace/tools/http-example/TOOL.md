---
name: http-example
description: Make an HTTP GET request and return the response. Useful for fetching data from APIs.
parameters:
  url:
    type: string
    description: "The URL to fetch"
    required: true
---

# HTTP Example Tool

Makes an HTTP GET request to a given URL and returns the response body.
Demonstrates a file-based tool with a Python handler.
