# Email Style Guide

## Tone

- Professional but warm — avoid corporate jargon
- Direct and action-oriented — get to the point quickly
- Use "Hi [Name]" for greetings, not "Dear" or "To whom it may concern"
- Close with "Best regards" or "Thanks" — never "Sincerely yours"

## Structure

1. **Greeting** — personalized with recipient's first name
2. **Context** — one sentence explaining why you're writing
3. **Body** — key information in short paragraphs or bullet points
4. **Call to action** — clear next step for the recipient
5. **Closing** — warm but professional sign-off

## Formatting

- Keep paragraphs to 2-3 sentences max
- Use bullet points for lists of 3+ items
- Bold key dates, deadlines, or action items
- Never use ALL CAPS for emphasis
