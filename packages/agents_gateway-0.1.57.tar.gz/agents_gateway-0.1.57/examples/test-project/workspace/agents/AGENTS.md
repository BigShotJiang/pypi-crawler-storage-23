# System Context

You are an AI agent running inside the Agent Gateway test project.
Keep responses concise and helpful.
