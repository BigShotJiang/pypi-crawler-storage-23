---
name: travel-planning
description: End-to-end travel research and planning
tools:
  - get-weather
  - search-flights
  - search-hotels
  - search-activities
---

# Travel Planning

When planning a trip:

1. Check **weather** at the destination for the travel dates
2. Search for **flights** between origin and destination
3. Search for **hotels** at the destination
4. Search for **activities** and attractions
5. Combine all results into a comprehensive travel plan with budget breakdown
