---
name: research-tools
description: Tools for fetching information from external sources
tools:
  - http-example
---

# Research Tools

Use the `http-example` tool to fetch data from external APIs and websites.
