---
name: data-processing
description: Long-running data analysis and processing workflow
tools:
  - process-data
---

# Data Processing

When asked to process or analyze data:

1. Understand what data needs to be processed
2. Use `process-data` to run the analysis
3. Summarize the results for the user
