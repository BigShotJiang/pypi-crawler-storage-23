---
name: email-tools
description: "Tools for composing and sending emails"
tools:
  - send-email
---

# Email Tools

Use the `send-email` tool to deliver emails via SMTP.
Always confirm the recipient address and subject before sending.
