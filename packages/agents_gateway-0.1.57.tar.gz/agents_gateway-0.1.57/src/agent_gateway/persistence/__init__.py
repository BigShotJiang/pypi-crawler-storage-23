"""Persistence layer for Agent Gateway — SQLAlchemy async models and repositories."""
