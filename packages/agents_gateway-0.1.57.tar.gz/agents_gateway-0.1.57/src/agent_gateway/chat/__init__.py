"""Chat session management for multi-turn conversations."""
