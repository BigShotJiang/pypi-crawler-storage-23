import unittest

from montage import MontageError
from montage.prompt import Prompt


class PromptCompileTests(unittest.TestCase):
    def make_prompt(self):
        return Prompt(
            id="p1",
            slug="slug",
            name="Name",
            messages=[
                {"role": "system", "content": "Hello {{name}}"},
                {"role": "user", "content": "Company: {{company}}"},
            ],
            temperature=0.3,
            max_tokens=500,
            version=1,
            variable_metadata={
                "name": {"required": True},
                "company": {"required": False, "defaultValue": "Montage"},
            },
        )

    def test_compile_with_kwargs(self):
        prompt = self.make_prompt()
        compiled = prompt.compile(name="Jeremy")
        self.assertEqual(compiled.messages[0]["content"], "Hello Jeremy")
        self.assertEqual(compiled.messages[1]["content"], "Company: Montage")

    def test_compile_with_mapping(self):
        prompt = self.make_prompt()
        compiled = prompt.compile({"name": "Sam", "company": "Acme"})
        self.assertEqual(compiled.messages[0]["content"], "Hello Sam")
        self.assertEqual(compiled.messages[1]["content"], "Company: Acme")

    def test_missing_required_variable_raises(self):
        prompt = self.make_prompt()
        with self.assertRaises(MontageError) as ctx:
            prompt.compile(company="Acme")

        self.assertEqual(ctx.exception.code, "missing_variable")
        self.assertEqual(ctx.exception.status, 400)

    def test_variables_extracted_in_order(self):
        prompt = self.make_prompt()
        self.assertEqual(prompt.variables, ["name", "company"])


if __name__ == "__main__":
    unittest.main()
