import unittest
from unittest.mock import patch

from montage import Montage, MontageError


class FakeResponse:
    def __init__(self, status_code=200, payload=None):
        self.status_code = status_code
        self._payload = payload if payload is not None else {}

    @property
    def ok(self):
        return 200 <= self.status_code < 300

    def json(self):
        return self._payload


class FakeSession:
    def __init__(self, responses):
        self._responses = list(responses)
        self.calls = []

    def get(self, url, headers=None, timeout=None):
        self.calls.append({"url": url, "headers": headers, "timeout": timeout})
        if not self._responses:
            raise AssertionError("No fake responses left")
        return self._responses.pop(0)


def sample_prompt_payload():
    return {
        "id": "p_123",
        "slug": "customer-support",
        "name": "Customer Support",
        "messages": [{"role": "system", "content": "Hello {{name}}"}],
        "temperature": 0.7,
        "max_tokens": 400,
        "version": 3,
        "variable_metadata": {"name": {"required": True}},
    }


class MontageClientTests(unittest.TestCase):
    def test_get_returns_prompt_and_uses_cache(self):
        session = FakeSession([FakeResponse(200, sample_prompt_payload())])
        sdk = Montage(api_key="mt_live_test", session=session)

        first = sdk.get("customer-support")
        second = sdk.get("customer-support")

        self.assertEqual(first.slug, "customer-support")
        self.assertEqual(first.version, 3)
        self.assertEqual(len(session.calls), 1)
        self.assertEqual(first, second)

    def test_skip_cache_forces_refetch(self):
        session = FakeSession([
            FakeResponse(200, sample_prompt_payload()),
            FakeResponse(200, sample_prompt_payload()),
        ])
        sdk = Montage(api_key="mt_live_test", session=session)

        sdk.get("customer-support")
        sdk.get("customer-support", skip_cache=True)

        self.assertEqual(len(session.calls), 2)

    def test_non_200_raises_montage_error(self):
        session = FakeSession([FakeResponse(404, {"error": "not_found", "message": "Prompt not found"})])
        sdk = Montage(api_key="mt_live_test", session=session)

        with self.assertRaises(MontageError) as ctx:
            sdk.get("missing")

        self.assertEqual(ctx.exception.code, "not_found")
        self.assertEqual(ctx.exception.status, 404)

    def test_invalid_payload_raises(self):
        session = FakeSession([FakeResponse(200, {"slug": "x"})])
        sdk = Montage(api_key="mt_live_test", session=session)

        with self.assertRaises(MontageError) as ctx:
            sdk.get("bad")

        self.assertEqual(ctx.exception.code, "invalid_response")

    def test_reads_api_key_from_env(self):
        session = FakeSession([FakeResponse(200, sample_prompt_payload())])
        with patch.dict("os.environ", {"MONTAGE_API_KEY": "mt_test_from_env"}, clear=False):
            sdk = Montage(session=session)
            prompt = sdk.get("customer-support")

        self.assertEqual(prompt.slug, "customer-support")
        self.assertEqual(len(session.calls), 1)


if __name__ == "__main__":
    unittest.main()
