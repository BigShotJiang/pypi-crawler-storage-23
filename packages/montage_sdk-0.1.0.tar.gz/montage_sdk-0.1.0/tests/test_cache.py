import time
import unittest

from montage.cache import TTLCache


class TTLCacheTests(unittest.TestCase):
    def test_set_get_and_expiry(self):
        cache = TTLCache[str]()
        cache.set("k", "v", ttl_seconds=0.02)
        self.assertEqual(cache.get("k"), "v")
        time.sleep(0.03)
        self.assertIsNone(cache.get("k"))

    def test_delete_and_clear(self):
        cache = TTLCache[str]()
        cache.set("a", "1", ttl_seconds=10)
        cache.set("b", "2", ttl_seconds=10)
        cache.delete("a")
        self.assertIsNone(cache.get("a"))
        self.assertEqual(cache.get("b"), "2")
        cache.clear()
        self.assertIsNone(cache.get("b"))


if __name__ == "__main__":
    unittest.main()
