# montage-sdk (Python)

Official Python SDK for Montage runtime prompt retrieval.

## Install

```bash
pip install montage-sdk
```

## Quickstart

```python
from montage import Montage

montage = Montage(api_key="mt_live_xxx")
# or: montage = Montage()  # reads MONTAGE_API_KEY

prompt = montage.get("customer-support")
print(prompt.messages)
print(prompt.temperature)
print(prompt.max_tokens)
print(prompt.version)
print(prompt.variables)

compiled = prompt.compile(user_name="Sarah", company="Acme")
print(compiled.messages)
```

## Configuration

```python
montage = Montage(
    api_key="mt_live_xxx",
    base_url="https://montage.sh/api/v1",
    cache_ttl=60,
    timeout=10.0,
)
```

## Errors

SDK errors raise `MontageError`:

- `code` (e.g. `unauthorized`, `not_found`, `rate_limit_exceeded`)
- `status` (HTTP status when available)
- `message`

## Cache controls

```python
montage.invalidate("customer-support")
montage.clear_cache()
```
