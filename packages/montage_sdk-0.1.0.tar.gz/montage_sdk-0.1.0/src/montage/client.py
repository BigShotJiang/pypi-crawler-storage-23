import os
from typing import Any, Mapping, Optional

import requests

from .cache import TTLCache
from .errors import MontageError
from .prompt import Prompt


class Montage:
    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: str = "https://montage.sh/api/v1",
        cache_ttl: int = 60,
        timeout: float = 10.0,
        session: Optional[requests.Session] = None,
    ) -> None:
        resolved_key = api_key or os.getenv("MONTAGE_API_KEY")
        if not resolved_key:
            raise ValueError("Montage: api_key is required (or set MONTAGE_API_KEY)")
        if not (resolved_key.startswith("mt_live_") or resolved_key.startswith("mt_test_")):
            raise ValueError("Montage: invalid api_key format")

        self._api_key = resolved_key
        self._base_url = base_url.rstrip("/")
        self._default_cache_ttl = max(0, int(cache_ttl))
        self._timeout = timeout
        self._session = session or requests.Session()
        self._cache: TTLCache[Prompt] = TTLCache()

    @staticmethod
    def _parse_prompt(data: Mapping[str, Any]) -> Prompt:
        required = ["id", "slug", "name", "messages", "version"]
        missing = [key for key in required if key not in data]
        if missing:
            raise MontageError(
                f"Invalid prompt response, missing fields: {', '.join(missing)}",
                code="invalid_response",
                status=500,
            )

        messages = data.get("messages")
        if not isinstance(messages, list):
            raise MontageError("Invalid prompt response: messages must be an array", code="invalid_response", status=500)

        return Prompt(
            id=str(data["id"]),
            slug=str(data["slug"]),
            name=str(data["name"]),
            messages=messages,
            temperature=(float(data["temperature"]) if data.get("temperature") is not None else None),
            max_tokens=(int(data["max_tokens"]) if data.get("max_tokens") is not None else None),
            version=int(data["version"]),
            variable_metadata=data.get("variable_metadata") or None,
        )

    def get(
        self,
        slug: str,
        *,
        skip_cache: bool = False,
        cache_ttl: Optional[int] = None,
    ) -> Prompt:
        cache_key = f"prompt:{slug}"
        resolved_ttl = self._default_cache_ttl if cache_ttl is None else max(0, int(cache_ttl))

        if not skip_cache:
            cached = self._cache.get(cache_key)
            if cached is not None:
                return cached

        url = f"{self._base_url}/prompts/{slug}"
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }

        try:
            response = self._session.get(url, headers=headers, timeout=self._timeout)
        except requests.RequestException as exc:
            raise MontageError("Network error while fetching prompt", code="network_error", status=0) from exc

        payload: Mapping[str, Any]
        try:
            payload = response.json()
            if not isinstance(payload, dict):
                payload = {"error": "invalid_response", "message": "Invalid JSON response"}
        except ValueError:
            payload = {"error": "unknown", "message": "Unknown error"}

        if not response.ok:
            raise MontageError(
                str(payload.get("message") or "Failed to fetch prompt"),
                code=str(payload.get("error") or "unknown"),
                status=response.status_code,
            )

        prompt = self._parse_prompt(payload)
        if resolved_ttl > 0:
            self._cache.set(cache_key, prompt, ttl_seconds=resolved_ttl)
        return prompt

    def clear_cache(self) -> None:
        self._cache.clear()

    def invalidate(self, slug: str) -> None:
        self._cache.delete(f"prompt:{slug}")
