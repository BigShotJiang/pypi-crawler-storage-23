class MontageError(Exception):
    """Structured error raised by the Montage SDK."""

    def __init__(self, message: str, code: str = "unknown", status: int = 0) -> None:
        super().__init__(message)
        self.message = message
        self.code = code
        self.status = status

    def __str__(self) -> str:
        if self.status:
            return f"{self.message} (code={self.code}, status={self.status})"
        return f"{self.message} (code={self.code})"
