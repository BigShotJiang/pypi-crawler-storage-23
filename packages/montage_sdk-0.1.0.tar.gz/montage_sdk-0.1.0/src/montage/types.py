from typing import NotRequired, TypedDict


class PromptMessage(TypedDict):
    role: str
    content: str


class VariableMetadata(TypedDict):
    required: NotRequired[bool]
    defaultValue: NotRequired[str]
    description: NotRequired[str]
