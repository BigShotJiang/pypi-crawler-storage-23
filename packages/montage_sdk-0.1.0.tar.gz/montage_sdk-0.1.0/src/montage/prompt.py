import re
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Mapping, Optional

from .errors import MontageError
from .types import PromptMessage, VariableMetadata

_VARIABLE_RE = re.compile(r"\{\{(\w+)\}\}")


@dataclass(frozen=True)
class CompiledPrompt:
    messages: List[PromptMessage]
    temperature: Optional[float]
    max_tokens: Optional[int]


class Prompt:
    def __init__(
        self,
        *,
        id: str,
        slug: str,
        name: str,
        messages: Iterable[PromptMessage],
        temperature: Optional[float],
        max_tokens: Optional[int],
        version: int,
        variable_metadata: Optional[Mapping[str, VariableMetadata]] = None,
    ) -> None:
        self.id = id
        self.slug = slug
        self.name = name
        self.messages: List[PromptMessage] = [
            {"role": str(m["role"]), "content": str(m["content"])} for m in messages
        ]
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.version = int(version)
        self.variable_metadata: Dict[str, VariableMetadata] = dict(variable_metadata or {})
        self.variables = self._extract_variables(self.messages)

    @staticmethod
    def _extract_variables(messages: Iterable[PromptMessage]) -> List[str]:
        seen = set()
        ordered: List[str] = []
        for message in messages:
            for match in _VARIABLE_RE.findall(message.get("content", "")):
                if match not in seen:
                    seen.add(match)
                    ordered.append(match)
        return ordered

    def _resolve_variable(self, key: str, values: Mapping[str, Any]) -> str:
        if key in values:
            return str(values[key])

        meta = self.variable_metadata.get(key)
        if meta and meta.get("required") is False and "defaultValue" in meta:
            return str(meta["defaultValue"])

        raise MontageError(
            f"Missing required variable: {key}",
            code="missing_variable",
            status=400,
        )

    def compile(
        self,
        values: Optional[Mapping[str, Any]] = None,
        **kwargs: Any,
    ) -> CompiledPrompt:
        merged_values: Dict[str, Any] = {}
        if values:
            merged_values.update(dict(values))
        if kwargs:
            merged_values.update(kwargs)

        compiled_messages: List[PromptMessage] = []
        for message in self.messages:
            content = message["content"]
            replaced = _VARIABLE_RE.sub(
                lambda m: self._resolve_variable(m.group(1), merged_values),
                content,
            )
            compiled_messages.append({"role": message["role"], "content": replaced})

        return CompiledPrompt(
            messages=compiled_messages,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
        )
