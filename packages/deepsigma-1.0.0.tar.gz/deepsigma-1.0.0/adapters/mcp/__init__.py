"""MCP (Model Context Protocol) adapter for Σ OVERWATCH."""
