"""Allow running mesh as: python -m mesh.cli"""

from mesh.cli import main

main()
