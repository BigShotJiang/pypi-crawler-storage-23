"""Allow running coherence_ops as a module: python -m coherence_ops."""
from coherence_ops.cli import main

main()
