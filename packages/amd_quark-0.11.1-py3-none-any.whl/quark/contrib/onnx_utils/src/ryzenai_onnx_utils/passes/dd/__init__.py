# Copyright (C) 2024 - 2025 Advanced Micro Devices, Inc. All rights reserved.

import enum

import ryzenai_onnx_utils.passes

PATTERN, REPLACEMENT, __all__ = ryzenai_onnx_utils.passes.pass_loader(__file__)
