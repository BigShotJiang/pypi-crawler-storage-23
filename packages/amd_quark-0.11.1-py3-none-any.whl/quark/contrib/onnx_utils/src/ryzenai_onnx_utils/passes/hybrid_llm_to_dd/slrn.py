# Copyright (C) 2025 Advanced Micro Devices, Inc. All rights reserved.

import numpy as np
import onnx

import ryzenai_onnx_utils.matcher
import ryzenai_onnx_utils.transform.cast as cast
import ryzenai_onnx_utils.utils
from ryzenai_onnx_utils.strategy_builder import MladfVersion
from ryzenai_onnx_utils.typing import PassOutputArgs


def replacement(
    extractor: onnx.utils.Extractor,
    pass_id: str,
    subgraph: list[onnx.NodeProto],
    params: ryzenai_onnx_utils.ReplaceParams,
) -> PassOutputArgs:
    domain = params.get_domain("MLADFRMSNORM")

    reshape_0 = subgraph[0]
    if len(subgraph) == 3:
        ssln = subgraph[1]
        reshape_1 = subgraph[2]
    else:
        ssln = subgraph[2]
        reshape_1 = subgraph[4]

    new_nodes = []
    new_tvis = []
    eps = onnx.helper.get_node_attr_value(ssln, "epsilon")
    eps_tensor = ryzenai_onnx_utils.utils.float_numpy_to_bfloat_tensor(np.array([eps]), f"eps_{pass_id}")
    reshaped_shape = ryzenai_onnx_utils.matcher.get_shape(reshape_0.output[0], extractor)
    op_version = MladfVersion(params.attributes["mladf_version"])
    seq_len_multi = 1
    if op_version == MladfVersion.AIE2_V2:
        reshaped_shape_in = ryzenai_onnx_utils.matcher.get_shape(reshape_0.input[0], extractor)
        seq_len_multi = reshaped_shape_in[-1] // reshaped_shape[-1]
        reshaped_shape = reshaped_shape_in
    input_cast_0, input_cast_0_tvis = cast.add_cast_dtype_to_bfloat16_auto(
        reshape_0.input[0], pass_id, domain, extractor, shape=reshaped_shape
    )
    new_nodes.extend(input_cast_0)
    new_tvis.extend(input_cast_0_tvis)

    output_cast_1, output_cast_1_tvis = cast.add_cast_bfloat16_to_dtype_auto(
        reshape_1.output[0], pass_id, domain, extractor
    )
    new_nodes.extend(output_cast_1)
    new_tvis.extend(output_cast_1_tvis)

    gamma = ryzenai_onnx_utils.matcher.get_initializer_as_numpy(ssln.input[1], extractor)
    gamma_bf = ryzenai_onnx_utils.utils.float_numpy_to_bfloat_tensor(gamma, ssln.input[1])

    rms_norm = onnx.helper.make_node(
        "MLADFRMSNORM",
        inputs=[input_cast_0[0].output[0], gamma_bf.name, eps_tensor.name],
        outputs=[output_cast_1[0].input[0]],
        name=f"rms_norm_{pass_id}",
        domain=domain,
    )

    pdi_id = int(params.attributes.get("pdi_id", 0))
    if pdi_id != 0:
        ryzenai_onnx_utils.matcher.add_attribute(rms_norm, "pdi_id", int(pdi_id))
    ryzenai_onnx_utils.matcher.add_attribute(rms_norm, "op_version", str(op_version))
    ryzenai_onnx_utils.matcher.add_attribute(rms_norm, "m_x", seq_len_multi)
    enable_ctrl_pkt = params.get_bool_attr("enable_ctrl_pkt", False)
    if enable_ctrl_pkt:
        ryzenai_onnx_utils.matcher.add_attribute(rms_norm, "enable_ctrl_pkt", True)
    new_nodes.append(rms_norm)

    return new_nodes, [eps_tensor, gamma_bf], new_tvis


PATTERN = [
    [
        "Reshape([?, ?], [a1])",
        "SimplifiedLayerNormalization([a1,?], a2)",
        "Reshape([a2, ?], [?])",
    ],
    [
        "Reshape([?, ?], [a1])",
        "Cast([a1], [a11])",
        "SimplifiedLayerNormalization([a11,?], a2)",
        "Cast([a2], [a22])",
        "Reshape([a22, ?], [?])",
    ],
]
REPLACEMENT = [replacement] * 2
