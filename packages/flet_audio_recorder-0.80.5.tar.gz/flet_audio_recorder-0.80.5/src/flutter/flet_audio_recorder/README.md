# Flet `AudioRecorder` control

`AudioRecorder` control to use in Flet apps.
