import os

__version__ = "0.4.5"  # Update this manually when needed
__SOURCE_COMMIT_CORE__ = os.getenv("SOURCE_COMMIT_CORE", "")