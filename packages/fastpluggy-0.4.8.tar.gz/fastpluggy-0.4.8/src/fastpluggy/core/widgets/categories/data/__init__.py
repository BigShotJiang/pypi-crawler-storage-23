"""
Data category widgets for displaying data in various formats.
"""

from .model import ModelWidget
from .table import TableWidget
from .table_model import TableModelWidget

__all__ = [
    'ModelWidget',
    'TableWidget',
    'TableModelWidget',
]