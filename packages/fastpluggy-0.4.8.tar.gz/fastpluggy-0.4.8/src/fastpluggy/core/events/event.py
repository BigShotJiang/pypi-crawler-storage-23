from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


@dataclass
class Event:
    """
    Generic event envelope passed to every listener.

    Attributes:
        name:      Topic string, e.g. ``"user.login"`` or ``"fp.app_ready"``.
        source:    Module name of the emitting plugin, e.g. ``"auth_user"``.
        payload:   Arbitrary key/value data supplied by the emitter.
        timestamp: UTC timestamp set at construction time.
    """
    name: str
    source: str = ""
    payload: dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
