from fastapi import Request
from fastapi.templating import Jinja2Templates
from jinja2 import PackageLoader, Environment


def _get_templates(request: Request) -> Jinja2Templates:
    templates = getattr(request.app.state, "jinja_templates", None)
    if templates is None:
        templates = Jinja2Templates(env=Environment(loader=PackageLoader("fastpluggy", "templates")))
    return templates


def not_found_handler(request: Request, exc):
    return _get_templates(request).TemplateResponse("404.html.j2", {
        "request": request,
        "title": "Page Not Found",
    }, status_code=404)


async def unauthorized_handler(request: Request, exc):
    """Redirect to login if an auth manager is configured, otherwise show 401 page."""
    fp = getattr(request.app.state, "fastpluggy", None)
    auth_manager = getattr(fp, "auth_manager", None) if fp else None
    if auth_manager and hasattr(auth_manager, "on_authenticate_error"):
        result = await auth_manager.on_authenticate_error(request)
        if result is not None:
            return result
    return _get_templates(request).TemplateResponse("404.html.j2", {
        "request": request,
        "title": "Unauthorized",
    }, status_code=401)


def forbidden_handler(request: Request, exc):
    return _get_templates(request).TemplateResponse("403.html.j2", {
        "request": request,
        "title": "Access Denied",
    }, status_code=403)
