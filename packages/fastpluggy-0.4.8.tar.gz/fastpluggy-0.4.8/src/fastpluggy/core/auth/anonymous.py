class FPAnonymousUser:
    is_authenticated = False
    is_admin = False
    display_name = "Guest"
    profile_picture = None
    roles: list = []
