/* scripts.js — FastPluggy Admin UI */

// ------------------------------------------------------
// Toast Notification
// ------------------------------------------------------
function showNotification(message, level = "info", link = null) {
    const container = document.getElementById("notifications");

    if (!container) {
        console.warn("[Notification] Container not found");
        return;
    }

    const levelClasses = {
        info:    "bg-primary text-white",
        warning: "bg-warning text-dark",
        error:   "bg-danger text-white",
        success: "bg-success text-white"
    };
    const colorClass = levelClasses[level] || "bg-primary text-white";

    const notification = document.createElement("div");
    notification.className = "toast show mb-3 " + colorClass;
    notification.role = "alert";

    const toastHeader = document.createElement("div");
    toastHeader.className = "toast-header";

    const strong = document.createElement("strong");
    strong.className = "me-auto";
    strong.textContent = "Task Update";

    const closeBtn = document.createElement("button");
    closeBtn.type = "button";
    closeBtn.className = "btn-close ms-2 mb-1";
    closeBtn.setAttribute("data-bs-dismiss", "toast");
    closeBtn.setAttribute("aria-label", "Close");

    toastHeader.appendChild(strong);
    toastHeader.appendChild(closeBtn);

    const toastBody = document.createElement("div");
    toastBody.className = "toast-body";
    toastBody.textContent = message;

    if (link) {
        const linkDiv = document.createElement("div");
        linkDiv.className = "mt-2";
        const anchor = document.createElement("a");
        anchor.href = link;
        anchor.target = "_blank";
        anchor.className = "text-white text-decoration-underline";
        anchor.rel = "noopener noreferrer";
        anchor.textContent = "View details";
        linkDiv.appendChild(anchor);
        toastBody.appendChild(linkDiv);
    }

    notification.appendChild(toastHeader);
    notification.appendChild(toastBody);
    container.appendChild(notification);

    setTimeout(() => {
        if (container.contains(notification)) container.removeChild(notification);
    }, 5000);

    closeBtn.addEventListener('click', () => {
        if (container.contains(notification)) container.removeChild(notification);
    });
}

// ------------------------------------------------------
// Auto LocalStorage for Form Elements
// ------------------------------------------------------
(function () {
    function loadFromLocalStorage(key, defaultValue = null) {
        try {
            const value = localStorage.getItem(key);
            return value !== null ? JSON.parse(value) : defaultValue;
        } catch (e) {
            console.warn("Error loading key:", key, e);
            return defaultValue;
        }
    }

    function saveToLocalStorage(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
        } catch (e) {
            console.warn("Error saving key:", key, e);
        }
    }

    function initAutoLocalStorage() {
        document.querySelectorAll('[data-ls-key]').forEach(el => {
            const key = el.dataset.lsKey;
            const saved = loadFromLocalStorage(key);
            if (saved !== null) {
                if (el.type === 'checkbox') {
                    el.checked = !!saved;
                } else {
                    el.value = saved;
                }
            }
            const eventType = (el.type === 'checkbox' || el.tagName === 'SELECT') ? 'change' : 'input';
            el.addEventListener(eventType, () => {
                const value = (el.type === 'checkbox') ? el.checked : el.value;
                saveToLocalStorage(key, value);
            });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initAutoLocalStorage);
    } else {
        initAutoLocalStorage();
    }
})();

// ------------------------------------------------------
// Theme Toggle (Dark / Light)
// Key: fp-theme | Sets: data-theme + data-bs-theme
// ------------------------------------------------------
(function() {
    function applyTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        document.documentElement.setAttribute('data-bs-theme', theme);

        const icon  = document.getElementById('theme-icon');
        const label = document.getElementById('theme-label');

        if (icon) {
            icon.className = theme === 'dark' ? 'ti ti-sun' : 'ti ti-moon';
        }
        if (label) {
            label.textContent = theme === 'dark' ? 'Light' : 'Dark';
        }

        const btn = document.getElementById('theme-toggle');
        if (btn) {
            btn.setAttribute('title', theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode');
        }
    }

    function initThemeToggle() {
        const btn = document.getElementById('theme-toggle');
        if (!btn) return;

        // Anti-FOUC already applied the saved theme — just sync the icon
        const currentTheme = document.documentElement.getAttribute('data-theme') || 'dark';
        applyTheme(currentTheme);

        btn.addEventListener('click', function() {
            const current = document.documentElement.getAttribute('data-theme') || 'dark';
            const next = current === 'dark' ? 'light' : 'dark';
            applyTheme(next);
            localStorage.setItem('fp-theme', next);
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initThemeToggle);
    } else {
        initThemeToggle();
    }
})();

// ------------------------------------------------------
// Sidebar Toggle — collapses via html.sidebar-collapsed
// Key: fp-sidebar | Values: 'collapsed' / 'expanded'
// ------------------------------------------------------
(function() {
    function applySidebarState(collapsed) {
        if (collapsed) {
            document.documentElement.classList.add('sidebar-collapsed');
        } else {
            document.documentElement.classList.remove('sidebar-collapsed');
        }
    }

    function initSidebarToggle() {
        const btn = document.getElementById('sidebar-toggle');
        if (!btn) return;

        // Anti-FOUC already applied the saved state — just keep it in sync
        const savedState = localStorage.getItem('fp-sidebar');
        applySidebarState(savedState === 'collapsed');

        btn.addEventListener('click', function() {
            const isCollapsed = document.documentElement.classList.contains('sidebar-collapsed');
            const next = !isCollapsed;
            applySidebarState(next);
            localStorage.setItem('fp-sidebar', next ? 'collapsed' : 'expanded');
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initSidebarToggle);
    } else {
        initSidebarToggle();
    }
})();

// ------------------------------------------------------
// Layout Toggle — container-xl ↔ fluid
// Key: fp-layout | Values: 'fluid' / (absent)
// ------------------------------------------------------
(function() {
    function applyLayout(fluid) {
        if (fluid) {
            document.documentElement.classList.add('layout-fluid');
        } else {
            document.documentElement.classList.remove('layout-fluid');
        }
        const icon = document.getElementById('layout-icon');
        if (icon) {
            icon.className = fluid ? 'ti ti-minimize' : 'ti ti-maximize';
        }
        const btn = document.getElementById('layout-toggle');
        if (btn) {
            btn.setAttribute('title', fluid ? 'Switch to fixed width' : 'Switch to full width');
        }
    }

    function initLayoutToggle() {
        const btn = document.getElementById('layout-toggle');
        if (!btn) return;

        // Anti-FOUC already applied the saved state — just sync the icon
        const isFluid = document.documentElement.classList.contains('layout-fluid');
        applyLayout(isFluid);

        btn.addEventListener('click', function() {
            const next = !document.documentElement.classList.contains('layout-fluid');
            applyLayout(next);
            if (next) {
                localStorage.setItem('fp-layout', 'fluid');
            } else {
                localStorage.removeItem('fp-layout');
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initLayoutToggle);
    } else {
        initLayoutToggle();
    }
})();

// ------------------------------------------------------
// Collapse Button Chevron Toggle
// ------------------------------------------------------
(function() {
    function initCollapseChevrons() {
        document.querySelectorAll('[data-bs-toggle="collapse"]').forEach(function(btn) {
            btn.addEventListener('click', function() {
                const icon = this.querySelector('i');
                if (!icon) return;
                const isUp = icon.classList.contains('ti-chevron-up');
                icon.classList.toggle('ti-chevron-up', !isUp);
                icon.classList.toggle('ti-chevron-down', isUp);
            });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initCollapseChevrons);
    } else {
        initCollapseChevrons();
    }
})();

// ------------------------------------------------------
// Active Nav Link Highlighting
// ------------------------------------------------------
(function() {
    function initActiveNavLinks() {
        const currentPath = window.location.pathname;
        document.querySelectorAll('#sidebar .nav-link, #sidebar .dropdown-item').forEach(item => {
            const href = item.getAttribute('href');
            if (href && href !== '#' && currentPath.startsWith(href) && href !== '/') {
                item.classList.add('active');
                // Open parent dropdown if inside one (Bootstrap 5 requires show on toggle + menu)
                const parentDropdown = item.closest('.nav-item.dropdown');
                if (parentDropdown) {
                    parentDropdown.classList.add('show');
                    const toggle = parentDropdown.querySelector('.dropdown-toggle');
                    if (toggle) {
                        toggle.classList.add('show');
                        toggle.setAttribute('aria-expanded', 'true');
                    }
                    const menu = parentDropdown.querySelector('.dropdown-menu');
                    if (menu) menu.classList.add('show');
                }
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initActiveNavLinks);
    } else {
        initActiveNavLinks();
    }
})();
