"""Argus - Vision AI dataset toolkit."""

__version__ = "1.8.2"
