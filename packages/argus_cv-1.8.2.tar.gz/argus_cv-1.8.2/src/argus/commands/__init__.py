"""CLI commands for argus."""
