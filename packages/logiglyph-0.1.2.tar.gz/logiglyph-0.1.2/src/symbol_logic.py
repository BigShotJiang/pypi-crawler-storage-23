from __future__ import annotations

from dataclasses import dataclass
from typing import List, Tuple


SEMANTIC_CLASSES = ["entity", "action", "quality", "relation", "abstract"]
ONSETS = ["p", "t", "k", "m", "n", "s", "l", "r", "h", "w", "y"]
VOWELS = ["a", "e", "i", "o", "u"]
CODAS = ["", "n", "k", "s", "m", "l", "r"]

CLASS_TAG = {
    "entity": "e",
    "action": "a",
    "quality": "q",
    "relation": "r",
    "abstract": "x",
}


@dataclass(frozen=True)
class RootSpec:
    root: str
    gloss: str
    semantic_class: str
    onset: str
    vowel: str
    coda: str
    symbol_id: str

    @property
    def symbol(self) -> str:
        return ascii_symbol(self.semantic_class, self.onset, self.vowel, self.coda)


def compose_root(onset: str, vowel: str, coda: str) -> str:
    return f"{onset}{vowel}{coda}"


def symbol_id(semantic_class: str, onset: str, vowel: str, coda: str) -> str:
    return f"{semantic_class}:{onset}:{vowel}:{coda or '_'}"


def ascii_symbol(semantic_class: str, onset: str, vowel: str, coda: str) -> str:
    tag = CLASS_TAG.get(semantic_class, "e")
    return f"lg_{tag}_{onset}{vowel}{coda or '_'}"


def enumerate_symbol_space(limit: int) -> List[Tuple[str, str, str, str]]:
    out: List[Tuple[str, str, str, str]] = []
    for sc in SEMANTIC_CLASSES:
        for o in ONSETS:
            for v in VOWELS:
                for c in CODAS:
                    out.append((sc, o, v, c))
                    if len(out) >= limit:
                        return out
    return out
