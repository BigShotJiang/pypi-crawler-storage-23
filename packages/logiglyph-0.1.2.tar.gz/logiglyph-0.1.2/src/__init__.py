"""Agglutinative language toolkit package."""

from .api import LanguageModule, TranslationResult

__all__ = ["LanguageModule", "TranslationResult"]
