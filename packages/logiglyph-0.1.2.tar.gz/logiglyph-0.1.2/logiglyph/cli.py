from src.tool import main

__all__ = ["main"]

