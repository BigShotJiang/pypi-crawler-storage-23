# Agglutinative Language Toolkit

This project builds a small synthetic language and translates between:

- English gloss tokens (example: `person_0`)
- ASCII language symbols (example: `lg_e_pa_`)

## Setup

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
pip install -e .
```

## Generate Dictionary

```powershell
python -m src.tool generate-dictionary --count 96 --out data/dictionary.json
```

## Translate

```powershell
python -m src.tool translate --dict data/dictionary.json --text "the person builds a house"
python -m src.tool translate --dict data/dictionary.json --text "lg_e_pa_ lg_e_pan lg_e_pak" --reverse
```

## Dictionary Schema

Each entry in `data/dictionary.json` has:

- `root`: phonological root (`pa`, `pan`, ...)
- `gloss`: English key used by translator (`person_0`, `house_1`, ...)
- `semantic_class`: one of `entity|action|quality|relation|abstract`
- `onset`, `vowel`, `coda`: compositional sound parts
- `symbol_id`: structured id (`entity:p:a:_`)
- `symbol`: deterministic ASCII symbol (`lg_<class>_<root>`)

## Python API

```python
from logiglyph import LanguageModule

lang = LanguageModule("data/dictionary.json")
res = lang.translate("person_0 house_1 water_2")
print(res.text)               # lg_e_pa_ lg_e_pan lg_e_pak
print(lang.reverse(res.text)) # person_0 house_1 water_2
```
