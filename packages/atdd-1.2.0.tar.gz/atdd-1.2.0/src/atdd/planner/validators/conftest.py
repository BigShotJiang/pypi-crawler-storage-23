"""
Shared fixtures for planner tests.
"""
# Import all shared fixtures from coach via absolute import
from atdd.coach.validators.shared_fixtures import *
