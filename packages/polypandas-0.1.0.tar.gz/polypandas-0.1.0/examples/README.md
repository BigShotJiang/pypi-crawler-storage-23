# Examples

Run from the project root:

```bash
# Basic usage (dataclasses, build_dicts, build_dataframe)
python examples/basic_usage.py

# Nested structs (optional PyArrow for proper struct column)
python examples/nested_structs.py
```

Each example prints real output. Sample output is also documented in the docstring at the top of each file.
