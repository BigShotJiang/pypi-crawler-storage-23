// No defer/async/module to prevent FOUC. Use before any CSS (<link>, <style>).
try {
  const LIGHT = "light";
  const DARK = "dark";

  const stored = localStorage.getItem("theme");
  if (stored) {
    document.documentElement.dataset.theme = stored;
  } else {
    const prefersDark = window.matchMedia(
      "(prefers-color-scheme: dark)",
    ).matches;
    document.documentElement.dataset.theme = prefersDark ? DARK : LIGHT;
  }

  // Make it callable from HTML or other scripts
  window.toggleMode = () => {
    const current = document.documentElement.dataset.theme;
    const next = current === DARK ? LIGHT : DARK;
    document.documentElement.dataset.theme = next;
    localStorage.setItem("theme", next);
  };
} catch (e) {
  // localStorage can fail in some privacy modes; silently ignore
}
