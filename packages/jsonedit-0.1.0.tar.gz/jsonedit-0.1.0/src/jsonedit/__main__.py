from .jsonedit import main

main()
