"""Evaluation harness for measuring llmdebug impact.

This package is not part of the llmdebug library distribution. It lives in the
repo for local experimentation and research workflows.
"""
