X = int(input())
if X == 0:
    print("No")
elif X < 100:
    print("No")
elif X % 100 == 0:
    print("Yes")
