s1 = input()
s2 = input()

if [s1, s2] == ["#.", ".#"] or [".#", "#."]:
    print("No")
    exit()
else:
    print("Yes")
