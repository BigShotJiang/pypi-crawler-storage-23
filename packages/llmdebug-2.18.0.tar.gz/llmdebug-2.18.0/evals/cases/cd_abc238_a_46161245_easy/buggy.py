n = int(input())
print("Yes" if n > 2 else "No")
