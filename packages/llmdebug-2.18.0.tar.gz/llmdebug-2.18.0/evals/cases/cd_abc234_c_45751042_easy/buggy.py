n = 11
s = bin(n).replace("0b", "").replace("1", "2")
print(s)
