# CHANGELOG

## Unreleased

### Bug Fixes

- Return structured JSON error envelopes for MCP evidence tools when `response_format="json"` (with stable `error.code` + `metadata.status="error"` fields).
- Preserve requested `metadata.with_rca` in JSON error envelopes and normalize error `metadata.evidence_schema` to valid values.

## v2.14.3 (2026-02-23)

### Refactoring

- Move eval/report analytics dependencies (`polars`, `scipy`, `scikit-learn`) to the `evals` extra while keeping dev installs ergonomic.

### Bug Fixes

- Improve snapshot-index fallback observability with explicit warnings when sqlite index reads fail and filesystem scan fallback is used.

### Performance

- Add stable capture-overhead benchmark workflow (`just bench-capture`, `just bench-capture-compare`) and prompt-freeze guardrails for eval prompt drift detection.

## v2.14.2 (2026-02-19)

### Bug Fixes

- Improve eval Slurm throughput reporting (parallel ETA) and default A100 flash-attn behavior.

### Documentation

- Document the `sbatch --export` comma-value gotcha in Slurm runbooks.
- Polish docs content for the academic/reporting workflow.

## v2.14.1 (2026-02-19)

### Bug Fixes

- Enforce source-first patch prompts and budget guardrails in eval flows.
- Track test-touch patch metrics and remove hypothesis hint surfaces from eval prompting.

## v2.14.0 (2026-02-19)

### Features

- Add SWE-Bench Lite hybrid pipeline support and smoke gates.

### Refactoring

- Sanitize Slurm defaults via local env overrides.

## v2.13.1 (2026-02-19)

### Bug Fixes

- Harden OpenAI transport reuse and Slurm runtime-dir handling.

### Notes

- Additional maintenance script updates.

## v2.13.0 (2026-02-19)

### Features

- Add top-3 importer pipeline and related tests.
- Add run report metrics tooling and long-context preset support.

### Bug Fixes

- Harden OpenAI-compatible patch parsing and fallback behavior.

## v2.12.0 (2026-02-18)

### Features

- Generalize the GGUF eval workflow and harden HAICore deployment scripts.

### Documentation

- Add HAICore enroot eval runbook and Slurm quickstart documentation.

### Notes

- Additional eval script hardening and changelog maintenance updates.

## v2.11.4 (2026-02-18)

### Bug Fixes

- Add flush=True to eval progress prints for SSH/redirect visibility

## v2.11.3 (2026-02-18)

### Performance

- Reuse Docker containers via pool and show LLM/test timing in progress

## v2.11.2 (2026-02-18)

### Bug Fixes

- Suppress reportUnknownVariableType in jupyter_plugin.py

## v2.11.1 (2026-02-18)

### Bug Fixes

- Stabilize pyright strict across IPython stubs versions
- Restore defense-in-depth isinstance guards after pyright strict migration

### Refactoring

- Raise xenon gate to C and pyright to strict mode

### Evals

- Add retry-history telemetry and z.ai key fallback

## v2.11.0 (2026-02-17)

### Features

- Add resumable eval progress and harden sqlite WAL setup

## v2.10.1 (2026-02-17)

### Bug Fixes

- Implement quick wins for capture, privacy, and coverage gating

## v2.10.0 (2026-02-16)

### Features

- Add delta-first retry packaging and pairwise eval stats

## v2.9.0 (2026-02-16)

### Features

- Implement evidence-first MCP outputs and structured eval retry protocol

## v2.8.5 (2026-02-16)

### Performance

- Add sqlite state store and snapshot indexing

## v2.8.4 (2026-02-16)

### Notes

- Maintenance release (detailed notes were not present in this changelog history).

## v2.8.3 (2026-02-15)

### Notes

- Maintenance release (detailed notes were not present in this changelog history).

## v2.8.2 (2026-02-14)

### Notes

- Maintenance release (detailed notes were not present in this changelog history).

## v2.8.1 (2026-02-14)

### Notes

- Maintenance release (detailed notes were not present in this changelog history).

## v2.8.0 (2026-02-13)

### Notes

- Maintenance release (detailed notes were not present in this changelog history).

## v2.7.0 (2026-02-13)

### Notes

- Maintenance release (detailed notes were not present in this changelog history).

## v2.6.0 (2026-02-11)

### Notes

- Maintenance release (detailed notes were not present in this changelog history).

## v2.5.1 (2026-02-10)

### Notes

- Maintenance release (detailed notes were not present in this changelog history).

## v2.5.0 (2026-02-10)

### Notes

- Maintenance release (detailed notes were not present in this changelog history).

## v2.4.0 (2026-02-10)

### Notes

- Maintenance release (detailed notes were not present in this changelog history).

## v2.3.0 (2026-02-10)

### Notes

- Maintenance release (detailed notes were not present in this changelog history).

## v2.2.0 (2026-02-10)

### Notes

- Maintenance release (detailed notes were not present in this changelog history).

## v2.0.1 (2026-02-08)

### Notes

- Patch release (detailed notes were not present in this changelog history).

## v2.1.0 (2026-02-08)

### Features

- **Layered snapshot disclosure**: Read-time filter with three detail levels (`crash`, `full`, `context`) to control token usage. Wired into CLI (`--detail` flag), MCP server (`detail` parameter), and Python API (`filter_snapshot()`)
- **Hypothesis generation engine**: 10 pattern detectors that auto-generate ranked debugging hypotheses from snapshot data. New CLI command (`hypothesize`) and MCP tool (`llmdebug_hypothesize`)
- **Coverage-guided snapshot enrichment**: Extracts pytest-cov execution data (executed/missing lines, branch stats) for stack trace files into snapshots under `pytest.coverage`. Gracefully degrades when pytest-cov is absent

### Bug Fixes

- Eliminate silent failures across capture pipeline: replace bare `except Exception: pass` blocks with error sentinels, warnings, and visible error reporting across 14 modules
- Bootstrap CI off-by-one fix in stats module
- ASGI server IndexError guard in middleware
- Negative index validation in snapshot_diff
- CLI clean command now reports failed deletions
- Stale latest.json warning and temp file cleanup in output module
- Path traversal guard in snapshot loader
- Query string PII redaction in WSGI/ASGI middleware

## v2.0.0 (2026-01-31)

### BREAKING CHANGES

- Default `output_format` changed from `"json"` to `"json_compact"`. Snapshots now use abbreviated keys by default for ~40% smaller files. Use `output_format="json"` or `LLMDEBUG_OUTPUT_FORMAT=json` to restore previous behavior.

### Features

- **Compact output formats**: `json_compact` (default, ~40% smaller) and `toon` (optional, ~50% smaller)
- **Git context capture**: commit hash, branch name, dirty status
- **Error categorization**: auto-classify exceptions with actionable suggestions
- **Async context capture**: asyncio task name and coroutine info
- **Function arguments**: captured separately from locals
- **Array statistics**: optional min/max/mean/std computation
- **Log capture**: capture recent log records for pre-crash context
- CLI for viewing and managing snapshots (`show`, `list`, `frames`, `clean`)
- MCP server for IDE integration (`llmdebug-mcp`) with 4 tools: `diagnose`, `show`, `list`, `frame`
- Snapshot diffing via CLI (`diff` command) and MCP (`llmdebug_diff`)
- Production exception hooks (`install_hooks` / `uninstall_hooks`) with rate limiting and PII redaction
- WSGI and ASGI middleware for web framework integration

## v1.0.1 (2026-01-28)

### Bug Fixes

- Set `major_on_zero=false` for proper semver during 0.x development

## v1.0.0 (2026-01-28)

### Features

- `max_snapshots` config for automatic storage cleanup (0 = unlimited)
- CI/CD pipeline with GitHub Actions

## v0.1.4 (2026-01-27)

### Features

- ML tensor introspection: NaN/Inf detection, device tracking, requires_grad
- Pytest-specific context capture: test nodeid, outcome, stdout/stderr
- Project logo

### Bug Fixes

- Deprecated datetime.utcnow() usage
- Handle None line numbers in frame extraction

## v0.1.0 (2026-01-27)

### Features

- Initial release
- Exception capture with structured JSON snapshots
- Pytest plugin for automatic capture on test failures
- Smart array summarization for NumPy arrays
- Atomic file writes for snapshot output
