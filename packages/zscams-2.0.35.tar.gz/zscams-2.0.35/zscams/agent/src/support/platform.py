import platform


def is_linux():
    """Check if the platform is Linux."""
    return platform.system().lower().startswith("linux")


def is_freebsd():
    """Check if the platform is ZscalerOS or FreeBSD"""
    _platform = platform.system().lower()
    return _platform in ("freebsd", "zscaleros")
