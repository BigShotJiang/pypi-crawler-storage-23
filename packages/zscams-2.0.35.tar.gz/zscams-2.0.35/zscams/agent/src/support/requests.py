import requests
import ssl
from urllib3.poolmanager import PoolManager
from requests.adapters import HTTPAdapter


class SNIAdapter(HTTPAdapter):
    def __init__(self, server_hostname, **kwargs):
        self.server_hostname = server_hostname
        super().__init__(**kwargs)

    def init_poolmanager(self, *args, **kwargs):
        context = ssl.create_default_context()
        kwargs["ssl_context"] = context
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        self.poolmanager = PoolManager(*args, **kwargs)
        self.poolmanager.connection_pool_kw["server_hostname"] = self.server_hostname


def create_session_with_sni_adapter(sni: str):
    session = requests.Session()
    adapter = SNIAdapter(sni)
    session.mount("https://", adapter)
    return session
