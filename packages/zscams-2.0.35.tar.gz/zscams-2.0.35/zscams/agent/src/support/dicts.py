"""Dict utilities"""


def merge(source: dict, destination: dict) -> dict:
    """
    Recursively merge two dictionaries. Values from the source dictionary will override those in the destination dictionaries.

    >>> a = { 'first': { 'all_rows': { 'pass': 'dog', 'number': 1 } } }
    >>> b = { 'first': { 'all_rows': { 'fail': 'cat', 'number': 5 } } }
    >>> merge(b, a) == { 'first': { 'all_rows': { 'pass': 'dog', 'fail': 'cat', 'number': 5 } } }
    True
    """
    for key, value in source.items():
        if isinstance(value, dict):
            node = destination.setdefault(key, {})
            merge(value, node)
        else:
            destination[key] = value
    return destination
