import json
from pathlib import Path
import requests

from typing import Optional

from zscams.agent.src.support.machine_id import get_machine_id, set_machine_id
from zscams.agent.src.support.requests import create_session_with_sni_adapter

from .exceptions import AgentBootstrapError

from zscams.agent.src.support.configuration import (
    ROOT_PATH,
    config,
)
from zscams.agent.src.support.yaml import (
    resolve_placeholders,
    assert_no_placeholders_left,
)
from zscams.agent.src.support.filesystem import ensure_dir, is_file_exists
from zscams.agent.src.support.network import get_local_hostname, get_local_ip_address
from zscams.agent.src.support.openssl import (
    generate_csr_from_private_key,
    generate_private_key,
)
from zscams.agent.src.support.logger import get_logger


class BackendClient:
    """Client to interact with the backend service."""

    MACHINE_INFO_FILENAME = "machine_info.json"

    def __init__(self):
        self.services_config = config.get("services", [], valtyp=list)
        self.bootstrap_config = config.get("bootstrap", {}, valtyp=dict)
        self.url = self.bootstrap_config.get("base_url")
        self.agent_id = get_machine_id()
        self.logger = get_logger("backend_client")

        self.backend_server_cert = config.get("bootstrap.verify_backend_cert")
        if (
            self.backend_server_cert
            and isinstance(self.backend_server_cert, str)
            and not self.backend_server_cert.startswith("/")
        ):
            self.backend_server_cert = ROOT_PATH.joinpath(self.backend_server_cert)

        self.session = create_session_with_sni_adapter(config.must_get("bootstrap.sni"))

        self.__cache_dir = ROOT_PATH.parent.joinpath(
            self.bootstrap_config.get("cache_dir", ".cache"),
        )

        self.__machine_cache_path = self.__cache_dir.joinpath(
            self.MACHINE_INFO_FILENAME
        )

        self.custom_config_dir = Path(config.get("config_dir", must_resolve=True))

        self.private_key_path = self.custom_config_dir.joinpath(
            config.must_get("remote.client_key")
        ).absolute()
        self.client_cert_path = self.custom_config_dir.joinpath(
            config.must_get("remote.client_cert")
        ).absolute()
        self.ca_chain_path = self.custom_config_dir.joinpath(
            config.must_get("remote.ca_chain")
        ).absolute()
        self.autoport_key_path = self.custom_config_dir.joinpath(
            config.must_get("remote.autoport_key")
        ).absolute()

    def bootstrap(self, equipment_name: str):
        """Bootstrap the agent with the backend."""

        if self.agent_id:
            self.logger.info(
                "Agent ID %s already exists. Skipping bootstrapping.",
                self.agent_id,
            )
            return

        if not self.is_authenticated():
            self.logger.error("Couldn't authenticate")
            raise AgentBootstrapError(
                "Client is not authenticated to bootstrap. Please login first."
            )

        self.logger.info("Bootstrapping agent...")

        csr_info = self.bootstrap_config.get("csr", {})

        self.logger.info("Generating the private key...")
        private_key_content = generate_private_key(self.private_key_path)

        self.logger.info("Generated the private key at %s", self.private_key_path)

        common_name = (
            f"{equipment_name}.orangecyberdefense.com"
            if equipment_name
            else csr_info.get("default_common_name")
        )

        ip = get_local_ip_address()
        csr = generate_csr_from_private_key(
            private_key_content,
            csr_info.get("country"),
            csr_info.get("state"),
            csr_info.get("locality"),
            csr_info.get("organization"),
            common_name,
        )

        payload = {
            "private_ip": ip,
            "lan_ip": ip,
            "hostname": get_local_hostname(),
            "equipment_name": equipment_name,
            "csr": csr,
            "services": [
                service.get("name")
                for service in self.services_config
                if service.get("custom_port_name", None)
            ],
            "blacklist_ports": self.bootstrap_config.get("blacklist_ports", []),
            "cert_issuer": self.bootstrap_config.get("cert_issuer", None),
        }

        self.logger.debug(
            "bootstrapping agent with payload %s",
            json.dumps(payload, indent=2),
        )

        res = self._post("agent-bootstrap/", payload)

        res_json = res.json()

        self.logger.debug("backend response: %s", json.dumps(res_json, indent=2))

        if not res.ok or res_json.get("success", False) is False:
            message = (
                res_json.get("message", None)
                or res_json.get("error", None)
                or res_json.get("errors", None)
                or "Unknown error"
            )
            raise AgentBootstrapError(
                f"Bootstrapping failed on backend request: {message}"
            )

        self.logger.info("Signed the cert")
        self.logger.debug("Signed cert response: %s", json.dumps(res_json, indent=2))

        customer_machine = res_json.get("response", {})
        ca_chain: list[str] = customer_machine.get("ca_chain", [])
        signed_cert: str = customer_machine.get("signed_certificate", "")
        autoport_key: str = customer_machine.get("autoport_key", "")
        self._write_keys_and_certificates(ca_chain, signed_cert, autoport_key)

        self.agent_id = customer_machine.get("machine_id")
        set_machine_id(self.agent_id)

        # To cache the machine info
        self.get_machine_info(ignore_cache=True)

        self.__override_config_services_ports(customer_machine.get("services", []))

        return customer_machine

    def unbootstrap(self):
        """This will remove the machine from the db and revoke the agent's certificate"""

        if not self.agent_id:
            self.session.cert = None
            return None

        if not self.is_authenticated():
            self.logger.error("Couldn't authenticate")
            raise AgentBootstrapError(
                "Client is not authenticated to unbootstrap. Please login first."
            )

        res = self._delete(f"agent-bootstrap/{self.agent_id}")
        json_response = res.json().get("response")

        self.agent_id = None
        self.session.cert = None

        return json_response

    def get_machine_info(self, ignore_cache: bool = False):
        """Get machine information from the backend."""

        if not ignore_cache and is_file_exists(self.__machine_cache_path, self.logger):
            return self.__load_machine_info_from_cache()

        res = self._get(f"customers-machines/machine-id/{self.agent_id}")
        res.raise_for_status()

        machine_info = res.json().get("response", {})
        self.logger.debug(
            "Fetched machine info: %s", json.dumps(machine_info, indent=2)
        )
        self.__cache_machine_info(machine_info)
        return machine_info

    def __load_machine_info_from_cache(self):
        """Cache machine information to a local file."""

        self.logger.info(
            "Loading machine info from cache at %s", self.__machine_cache_path
        )
        with open(self.__machine_cache_path, "r", encoding="utf-8") as cache_file:
            return json.load(cache_file)

    def __cache_machine_info(self, machine_info: dict):
        """Cache machine information to a local file."""

        ensure_dir(self.__machine_cache_path.parent)
        self.logger.info("Caching machine info to %s", self.__machine_cache_path)
        with open(self.__machine_cache_path, "w", encoding="utf-8") as cache_file:
            json.dump(machine_info, cache_file, indent=2)

    def _write_keys_and_certificates(
        self, ca_chain: list[str], cert: str, autoport_key: str
    ):
        """Write the signed certificate and CA chain to the specified paths."""

        if cert:
            self.logger.info("Writing signed certificate to %s", self.client_cert_path)
            ensure_dir(self.client_cert_path.parent)
            self.client_cert_path.write_text(cert, encoding="utf-8")
        else:
            self.logger.warning(
                "No signed certificate provided by the backend. Skipping writing signed certificate."
            )

        if ca_chain:
            self.logger.info("Writing CA chain to %s", self.ca_chain_path)
            ensure_dir(self.ca_chain_path.parent)
            self.ca_chain_path.write_text("\n\n".join(ca_chain), encoding="utf-8")
        else:
            self.logger.warning(
                "No CA chain provided by the backend. Skipping writing CA chain."
            )

        if autoport_key:
            self.logger.info("Writing Autoport Key to %s", self.autoport_key_path)
            ensure_dir(self.autoport_key_path.parent)
            self.autoport_key_path.write_text(autoport_key, encoding="utf-8")
        else:
            self.logger.warning(
                "No autoport key provided by the backend. Skipping writing autoport key."
            )

    def is_bootstrapped(self) -> bool:
        """Check if the agent is bootstrapped."""

        if (
            not self.agent_id
            or not self.client_cert_path
            or not self.private_key_path
            or not self.client_cert_path.exists()
            or not self.private_key_path.exists()
        ):
            return False

        try:
            is_bootstrapped_res = self._get(
                f"agent-bootstrap/{self.agent_id}/is-bootstrapped"
            )
            is_bootstrapped_res.raise_for_status()

            return (
                is_bootstrapped_res.json()
                .get("response", {})
                .get("is-bootstrapped", False)
            )
        except requests.RequestException as e:
            self.logger.debug("Error checking if agent is bootstrapped: %s", str(e))
            return False

    def _get(self, path: str):
        """Perform a GET request to the backend."""
        return self.__make_request("GET", path)

    def _post(self, path: str, body: dict):
        """Perform a POST request to the backend."""
        return self.__make_request("POST", path, body)

    def _put(self, path: str, body: dict):
        """Perform a PUT request to the backend."""
        return self.__make_request("PUT", path, body)

    def _delete(self, path: str):
        """Perform a DELETE request to the backend."""
        return self.__make_request("DELETE", path)

    def __make_request(self, method: str, path: str, body: Optional[dict] = None):
        """General method to make a request to the backend."""
        self._prepare_session()

        request_method = getattr(self.session, method.lower())
        if not request_method:
            raise ValueError(f"Unsupported HTTP method: {method}")

        res = request_method(
            self.__prepare_path(path),
            json=body,
            verify=self.backend_server_cert or False,
        )
        res.raise_for_status()
        return res

    def _prepare_session(self):
        if self.session.cert is not None:
            return

        if (
            not self.client_cert_path
            or not self.private_key_path
            or not self.client_cert_path.exists()
            or not self.private_key_path.exists()
        ):
            return

        self.session.cert = (self.client_cert_path.absolute(), self.private_key_path.absolute())  # type: ignore

    def login(self, username: str, totp: str):
        """Perform login to the backend using username and TOTP."""

        if self.is_authenticated():
            self.logger.info("Already authenticated with cached token. Skipping login.")
            return None

        payload = {
            "username": username,
            "totp": totp,
            "client_id": "account",
            "grant_type": "password",
        }

        self.logger.info("Logging in to backend as %s", username)

        response = self._post("authentication/temp/login", payload)
        if not response.ok:
            self.logger.error(
                "Login failed with status code %d: %s",
                response.status_code,
                response.text,
            )

        response.raise_for_status()

        token = response.json().get("access_token")
        if token:
            self.session.headers.update({"Authorization": f"Bearer {token}"})

        self.logger.info("Login successful")

        return response.json()

    def is_authenticated(self) -> bool:
        """
        Check if the client is authenticated. After populating the auth from
        cache, it checks if the Authorization header is set.
        """
        try:
            if not self.session.headers.get("Authorization"):
                return False
            self._get("authentication/token/validate")
            return True
        except requests.RequestException:
            return False

    def __prepare_path(self, path):
        if self.url is None:
            self.url = self.bootstrap_config.get("base_url")
        return f"{self.url}/{path.lstrip('/')}"

    def __override_config_services_ports(self, cm_services: list[dict]):
        self.logger.debug("Overriding configuration services ports...")

        _config = config.to_dict()
        custom_ports = {}
        for cm_service in cm_services:
            for cfg_service_idx, cfg_service in enumerate(
                config.get("services", [], valtyp=list[dict])
            ):
                if cm_service.get("name") == cfg_service.get("name"):

                    if not _config["services"][cfg_service_idx]["params"]:
                        _config["services"][cfg_service_idx]["params"] = {}

                    port_field_name = cfg_service.get("custom_port_name", None)
                    if port_field_name:
                        custom_ports[port_field_name] = cm_service.get("port")
                        _config["services"][cfg_service_idx]["params"][
                            port_field_name
                        ] = cm_service.get("port")
        resolve_placeholders(_config, custom_ports)
        assert_no_placeholders_left(_config)
        self.logger.debug("Done overriding the configurations")

        return config.override_config(_config)


backend_client = BackendClient()
