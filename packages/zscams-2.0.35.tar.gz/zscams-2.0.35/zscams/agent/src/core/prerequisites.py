from pathlib import Path
from zscams.agent.src.support.logger import get_logger
from zscams.agent.src.core import running_services
from zscams.agent.src.support.network import is_port_open, is_service_running
from zscams.agent.src.support.configuration import config

logger = get_logger("service_prerequisites")
custom_config_dir = Path(config.must_get("config_dir"))


def check_prerequisites(prereqs: dict) -> bool:
    """
    Perform a one-shot prerequisites check (no waiting or retry).
    Returns True only if all listed conditions are satisfied.
    """
    if not prereqs:
        return True

    results = []

    # Check file prerequisites
    for path in prereqs.get("files", []):
        results.append(custom_config_dir.joinpath(path).exists())

    # Check port prerequisites
    for port in prereqs.get("ports", []):
        results.append(is_port_open("localhost", port, logger))

    # Check service prerequisites
    for svc in prereqs.get("services", []):
        results.append(is_service_running(svc, running_services, logger))

    all_ok = all(results)
    if not all_ok:
        logger.warning("Some prerequisites failed for this service.")
    else:
        logger.info("All prerequisites satisfied.")
    return all_ok
