from age_orm import Database, Edge, Vertex


class Person(Vertex):
    __label__ = "Person"

    name: str
    age: int | None = None


class Knows(Edge):
    __label__ = "Knows"

    how: str | None = None


if __name__ == "__main__":
    with Database("postgresql://kashif:compulife@localhost:5432/age_tutorial") as db:
        graph = db.graph("tutorial_graph", create=True)

        alice = Person(name="Alice", age=30)
        bob = Person(name="Bob", age=25)
        graph.add(alice)
        graph.add(bob)

        graph.connect(alice, Knows(how="met at a conference"), bob)

        q = graph.query(Person).filter("n.age > $min", min=20).sort("n.name")

        print(q)

        # MATCH (p:Person {name: 'Alice'})-[k:Knows]-(other:Person) RETURN p, k, other
        for person in q:
            print(f"{person.name} is {person.age} years old.")