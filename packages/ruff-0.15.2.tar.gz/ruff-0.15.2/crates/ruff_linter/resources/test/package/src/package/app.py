from package.core import method

if __name__ == "__main__":
    method()
