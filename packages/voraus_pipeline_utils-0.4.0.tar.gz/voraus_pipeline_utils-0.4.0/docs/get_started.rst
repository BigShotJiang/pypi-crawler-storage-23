CLI interface
=============

The **voraus-pipeline-utils** come with a well-documented and tested CLI interface:

.. click:: voraus_pipeline_utils.cli.main:typer_click_object
   :prog: vpu
   :nested: full
