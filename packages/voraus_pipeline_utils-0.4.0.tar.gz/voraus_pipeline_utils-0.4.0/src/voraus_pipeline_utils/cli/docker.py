"""This module defines the typer docker wrapper."""

from pathlib import Path
from typing import Annotated

import typer

from voraus_pipeline_utils.methods.docker import (
    docker_build_wrapper,
    docker_list_tags_wrapper,
    docker_push_wrapper,
    docker_save_wrapper,
    get_tags_from_common_vars,
)

app = typer.Typer(name="docker")


@app.command("build", help="Wrapper for docker build that optionally uses JFrog CLI and auto generates image tags")
def _cli_docker_build(
    image_name: Annotated[
        str | None,
        typer.Option(help="Docker image name. Ignored, if tag(s) are provided."),
    ] = None,
    tag: Annotated[
        list[str] | None,
        typer.Option(help="Docker image tag(s)"),
    ] = None,
    repository: Annotated[
        list[str] | None,
        typer.Option(help="Docker repository or repositories"),
    ] = None,
    registry: Annotated[
        str | None,
        typer.Option(help="Docker registry. Ignored, if tag(s) are provided."),
    ] = None,
    dockerfile: Annotated[
        Path,
        typer.Option("--file", "-f", help="Dockerfile to use for building the image"),
    ] = Path("Dockerfile"),
) -> None:
    tags = get_tags_from_common_vars(tags=tag, registry=registry, repositories=repository, image_name=image_name)
    docker_build_wrapper(tags=tags, dockerfile=dockerfile)


@app.command("push", help="Wrapper for docker push that optionally uses JFrog CLI and auto uses generated image tags")
def _cli_docker_push(
    image_name: Annotated[
        str | None,
        typer.Option(help="Docker image name. Ignored, if tag(s) are provided."),
    ] = None,
    tag: Annotated[
        list[str] | None,
        typer.Option(help="Docker image tag(s)"),
    ] = None,
    repository: Annotated[
        list[str] | None,
        typer.Option(help="Docker repository or repositories"),
    ] = None,
) -> None:
    tags = get_tags_from_common_vars(tags=tag, repositories=repository, image_name=image_name)
    docker_push_wrapper(tags=tags)


@app.command("list-tags", help="Lists the docker tags that are generated from the build environment")
def _cli_docker_tags(
    image_name: Annotated[
        str | None,
        typer.Option(help="Docker image name. Ignored, if tag(s) are provided."),
    ] = None,
    tag: Annotated[
        list[str] | None,
        typer.Option(help="Docker image tag(s)"),
    ] = None,
    repository: Annotated[
        list[str] | None,
        typer.Option(help="Docker repository or repositories"),
    ] = None,
    registry: Annotated[
        str | None,
        typer.Option(help="Docker registry. Ignored, if tag(s) are provided."),
    ] = None,
    file: Annotated[
        Path | None,
        typer.Option(help="Optional file to write the docker tags to (JSON format)."),
    ] = None,
) -> None:
    tags = get_tags_from_common_vars(tags=tag, registry=registry, repositories=repository, image_name=image_name)
    docker_list_tags_wrapper(tags=tags, file=file)


@app.command("save", help="Saves the docker images that are generated from the build environment to an archive")
def _cli_docker_save(
    output: Annotated[
        Path,
        typer.Option(help="The output file."),
    ],
    image_name: Annotated[
        str | None,
        typer.Option(help="Docker image name. Ignored, if tag(s) are provided."),
    ] = None,
    tag: Annotated[
        list[str] | None,
        typer.Option(help="Docker image tag(s)"),
    ] = None,
    repository: Annotated[
        list[str] | None,
        typer.Option(help="Docker repository or repositories"),
    ] = None,
    registry: Annotated[
        str | None,
        typer.Option(help="Docker registry. Ignored, if tag(s) are provided."),
    ] = None,
) -> None:
    tags = get_tags_from_common_vars(tags=tag, registry=registry, repositories=repository, image_name=image_name)
    docker_save_wrapper(tags=tags, output=output)
