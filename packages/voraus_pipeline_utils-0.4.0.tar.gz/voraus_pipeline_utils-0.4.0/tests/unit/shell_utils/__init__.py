"""Contains all unit tests for the shell helpers."""
