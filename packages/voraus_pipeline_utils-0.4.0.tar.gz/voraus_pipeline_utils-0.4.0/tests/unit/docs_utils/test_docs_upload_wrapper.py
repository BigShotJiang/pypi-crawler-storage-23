"""Contains all tests for the docs_upload_wrapper function."""

import zipfile
from pathlib import Path
from unittest.mock import MagicMock, patch

from voraus_pipeline_utils.methods.docs import docs_upload_wrapper


@patch("voraus_pipeline_utils.methods.docs.TemporaryDirectory")
@patch("voraus_pipeline_utils.methods.docs.requests.post")
def test_docs_upload_wrapper(post_request_mock: MagicMock, temp_dir_class_mock: MagicMock, tmp_path: Path) -> None:
    build_dir = tmp_path / "build"
    build_dir.mkdir()
    (build_dir / "index.html").write_text("Hello")
    temp_dir_class_mock.return_value.__enter__.return_value = tmp_path
    docs_upload_wrapper(
        build_dir=build_dir,
        api_url="https://example.com/api/",
        project_name="my-project",
        project_version="1.0.0",
        api_user="user",
        api_token="token",  # noqa: S106
    )
    temp_dir_class_mock.assert_called_once()
    expected_docs_zip = tmp_path / "docs.zip"
    assert expected_docs_zip.is_file()
    with zipfile.ZipFile(expected_docs_zip, "r") as zip_handler:
        assert zip_handler.namelist() == ["index.html"]
        assert zip_handler.read("index.html").decode() == "Hello"
    post_request_mock.assert_called_once()
