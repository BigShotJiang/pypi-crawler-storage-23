"""Contains all application utility functions."""

import pytest

from voraus_pipeline_utils import get_app_name, get_app_version


def test_get_app_name() -> None:
    assert get_app_name() == "voraus-pipeline-utils"


def test_get_app_version(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("voraus_pipeline_utils.__version__", "42.0.0")
    assert get_app_version() == "42.0.0"
