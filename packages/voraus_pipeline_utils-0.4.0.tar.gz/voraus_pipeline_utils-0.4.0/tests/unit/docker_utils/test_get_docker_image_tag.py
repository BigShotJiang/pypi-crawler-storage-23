"""Contains all tests for the get_docker_image_tag method."""

from voraus_pipeline_utils.methods.docker import get_docker_image_tag


def test_get_docker_image_tag() -> None:
    assert (
        get_docker_image_tag(name="my-name", version_tag="latest", target_repo="example", registry="example.com")
        == "example.com/example/my-name:latest"
    )
