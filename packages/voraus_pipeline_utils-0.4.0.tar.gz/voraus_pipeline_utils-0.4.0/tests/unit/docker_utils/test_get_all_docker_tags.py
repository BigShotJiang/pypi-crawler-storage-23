"""Contains all unit tests for the get_all_docker_tags method."""

import pytest

from voraus_pipeline_utils.methods.docker import get_all_docker_tags


@pytest.mark.parametrize("image_name", ["", None])
def test_get_all_docker_tags_invalid_image_name(image_name: str | None) -> None:
    with pytest.raises(ValueError, match="Invalid image name"):
        get_all_docker_tags(repositories=["docker"], image_name=image_name, registry="example.com")


def test_get_all_docker_tags_branch_name_missing_build_number() -> None:
    with pytest.raises(ValueError, match="Build number must be provided when branch name is given"):
        get_all_docker_tags(repositories=["docker"], image_name="test", branch_name="test", registry="example.com")


def test_get_all_docker_tags_branch_name_missing_repositories() -> None:
    with pytest.raises(ValueError, match="No repositories provided"):
        get_all_docker_tags(repositories=[], image_name="test", branch_name="test", registry="example.com")


def test_test_get_all_docker_tags_branch() -> None:
    assert get_all_docker_tags(
        repositories=["docker"],
        image_name="test",
        branch_name="test",
        build_number=1,
        registry="example.com",
    ) == [
        "example.com/docker/test:test-latest",
        "example.com/docker/test:test-1",
    ]


def test_test_get_all_docker_tags_tag() -> None:
    assert get_all_docker_tags(
        repositories=["docker"], image_name="test", tag="my-tag", registry="artifactory.vorausrobotik.com"
    ) == [
        "artifactory.vorausrobotik.com/docker/test:my-tag",
        "artifactory.vorausrobotik.com/docker/test:latest",
    ]


def test_test_get_all_docker_tags_branch_and_tag() -> None:
    assert get_all_docker_tags(
        repositories=["docker"],
        image_name="test",
        branch_name="whatever",
        build_number=1,
        tag="1.2.0",
        registry="artifactory.vorausrobotik.com",
    ) == [
        "artifactory.vorausrobotik.com/docker/test:1.2.0",
        "artifactory.vorausrobotik.com/docker/test:latest",
    ]
