"""Contains all tests for the docker_build_wrapper function."""

from unittest.mock import MagicMock, patch

import pytest

from voraus_pipeline_utils.methods.docker import docker_build_wrapper


@pytest.mark.parametrize("is_ci", [True, False])
@patch("voraus_pipeline_utils.methods.docker.is_ci")
@patch("voraus_pipeline_utils.methods.docker.execute_command")
def test_docker_build_wrapper(execute_command_mock: MagicMock, is_ci_mock: MagicMock, is_ci: bool) -> None:
    is_ci_mock.return_value = is_ci
    docker_build_wrapper(tags=["test:latest", "test:main-42"])
    execute_command_mock.assert_called_once_with(
        command=[
            *(["jf"] if is_ci else []),
            "docker",
            "build",
            "--pull",
            "-t test:latest",
            "-t test:main-42",
            "-f",
            "Dockerfile",
            ".",
        ]
    )
