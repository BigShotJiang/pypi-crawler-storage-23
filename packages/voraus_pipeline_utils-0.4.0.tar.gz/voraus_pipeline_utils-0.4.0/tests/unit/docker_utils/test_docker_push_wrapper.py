"""Contains all tests for the docker_push_wrapper function."""

from unittest.mock import MagicMock, call, patch

import pytest

from voraus_pipeline_utils.methods.docker import docker_push_wrapper


@pytest.mark.parametrize("is_ci", [True, False])
@patch("voraus_pipeline_utils.methods.docker.is_ci")
@patch("voraus_pipeline_utils.methods.docker.execute_command")
def test_docker_push_wrapper(execute_command_mock: MagicMock, is_ci_mock: MagicMock, is_ci: bool) -> None:
    is_ci_mock.return_value = is_ci
    docker_push_wrapper(tags=["test:latest", "test:main-42"])
    execute_command_mock.assert_has_calls(
        [
            call(command=[*(["jf"] if is_ci else []), "docker", "push", "test:latest"]),
            call(command=[*(["jf"] if is_ci else []), "docker", "push", "test:main-42"]),
        ]
    )
