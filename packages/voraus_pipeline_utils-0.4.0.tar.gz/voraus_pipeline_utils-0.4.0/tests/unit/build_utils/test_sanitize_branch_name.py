"""Contains all unit tests for build utils."""

import pytest

from voraus_pipeline_utils.methods.build import sanitize_branch_name


@pytest.mark.parametrize(
    ("branch_name", "expected_output"),
    [
        ("test%20branch", "test-branch"),
        ("special%25characters", "special-characters"),
        ("valid-branch_name.123", "valid-branch_name.123"),
        ("a%2Fb%5Cc", "a-b-c"),  # a/b\c becomes a-b-c
        ("%21%40%23%24%25%5E", "------"),  # !@#$%^ becomes ------
        ("branch%2Fname", "branch-name"),  # branch/name becomes branch-name
        ("branch%5Cname", "branch-name"),  # branch\name becomes branch-name
        (
            "multiple%2Fslashes%2Fand%5Cbackslashes",
            "multiple-slashes-and-backslashes",
        ),  # multiple/slashes/and\backslashes becomes multiple-slashes-and-backslashes
    ],
)
def test_sanitize_branch_name(branch_name: str, expected_output: str) -> None:
    assert sanitize_branch_name(branch_name) == expected_output
