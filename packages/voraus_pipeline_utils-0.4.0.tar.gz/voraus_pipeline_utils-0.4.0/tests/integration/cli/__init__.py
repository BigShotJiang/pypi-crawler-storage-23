"""Contains all unit tests for the CLI."""
