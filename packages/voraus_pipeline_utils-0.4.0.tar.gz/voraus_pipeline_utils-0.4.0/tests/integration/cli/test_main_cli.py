"""Contains all unit tests for the main CLI."""

import os
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from voraus_pipeline_utils import get_app_name
from voraus_pipeline_utils.cli.main import app
from voraus_pipeline_utils.constants import ENV_VAR_LOG_LEVEL


@patch("voraus_pipeline_utils.cli.main.get_app_version")
def test_main_app(get_app_version_mock: MagicMock, cli_runner: CliRunner) -> None:
    get_app_version_mock.return_value = 42
    result = cli_runner.invoke(app, ["--version"])
    assert result.stdout == "42\n"


@patch("voraus_pipeline_utils.cli.docker.get_tags_from_common_vars")
@patch("voraus_pipeline_utils.cli.docker.docker_build_wrapper")
def test_log_level(_mock1: MagicMock, _mock2: MagicMock, cli_runner: CliRunner) -> None:  # noqa: PT019
    with patch.dict(os.environ, clear=True):
        result = cli_runner.invoke(app=app, args=["docker", "list-tags"])
        assert f"Using {get_app_name()}" in result.stdout
    with patch.dict(os.environ, {ENV_VAR_LOG_LEVEL: "WARNING"}):
        result = cli_runner.invoke(app=app, args=["docker", "list-tags"])
        assert f"Using {get_app_name()}" not in result.stdout
