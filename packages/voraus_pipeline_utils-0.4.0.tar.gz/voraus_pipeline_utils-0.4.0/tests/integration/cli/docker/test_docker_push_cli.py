"""Contains all unit tests for the push CLI."""

from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from voraus_pipeline_utils.cli.main import app


@patch("voraus_pipeline_utils.cli.docker.get_tags_from_common_vars")
@patch("voraus_pipeline_utils.cli.docker.docker_push_wrapper")
def test_docker_push_success(
    docker_push_wrapper_mock: MagicMock, get_tags_from_common_vars_mock: MagicMock, cli_runner: CliRunner
) -> None:
    get_tags_from_common_vars_mock.return_value = ["A", "B"]
    result = cli_runner.invoke(app=app, args=["docker", "push"])
    assert result.exit_code == 0

    get_tags_from_common_vars_mock.assert_called_once_with(tags=None, repositories=None, image_name=None)
    docker_push_wrapper_mock.assert_called_once_with(tags=["A", "B"])


@patch("voraus_pipeline_utils.cli.docker.get_tags_from_common_vars")
@patch("voraus_pipeline_utils.cli.docker.docker_push_wrapper")
def test_docker_push_success_with_tags(
    docker_push_wrapper_mock: MagicMock, get_tags_from_common_vars_mock: MagicMock, cli_runner: CliRunner
) -> None:
    get_tags_from_common_vars_mock.return_value = ["A", "B"]
    result = cli_runner.invoke(app=app, args=["docker", "push", "--tag", "main-42", "--tag", "latest"])
    assert result.exit_code == 0

    get_tags_from_common_vars_mock.assert_called_once_with(
        tags=["main-42", "latest"], repositories=None, image_name=None
    )
    docker_push_wrapper_mock.assert_called_once_with(tags=["A", "B"])
