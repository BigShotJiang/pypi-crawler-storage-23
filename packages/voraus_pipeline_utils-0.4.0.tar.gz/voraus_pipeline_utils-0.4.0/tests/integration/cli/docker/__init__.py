"""Contains all unit tests for the docker CLI."""
