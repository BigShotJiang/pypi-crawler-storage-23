"""Contains all unit tests for the build CLI."""

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from voraus_pipeline_utils.cli.main import app


@pytest.mark.parametrize("export_file", [True, False])
@patch("voraus_pipeline_utils.cli.docker.get_tags_from_common_vars")
def test_list_docker_tags_success(
    get_tags_from_common_vars_mock: MagicMock, cli_runner: CliRunner, tmp_path: Path, export_file: bool
) -> None:
    get_tags_from_common_vars_mock.return_value = ["A", "B"]

    args = ["docker", "list-tags"]
    output_file = tmp_path / "tags.json"
    if export_file:
        args.extend(["--file", str(output_file)])

    result = cli_runner.invoke(app=app, args=args)
    assert result.exit_code == 0

    get_tags_from_common_vars_mock.assert_called_once_with(tags=None, registry=None, repositories=None, image_name=None)

    assert "The following tags have been generated" in result.stdout
    assert "- A" in result.stdout
    assert "- B" in result.stdout

    if export_file:
        assert output_file.exists()
        assert output_file.read_text() == '["A", "B"]'
        assert "Tags have been written to file" in result.stdout
        assert str(output_file) in result.stdout
    else:
        assert not output_file.exists()
