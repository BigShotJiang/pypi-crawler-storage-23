"""Contains all unit tests for the build CLI."""

from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from voraus_pipeline_utils.cli.main import app


@patch("voraus_pipeline_utils.cli.docker.get_tags_from_common_vars")
@patch("voraus_pipeline_utils.cli.docker.docker_build_wrapper")
def test_docker_build_success(
    docker_build_wrapper_mock: MagicMock, get_tags_from_common_vars_mock: MagicMock, cli_runner: CliRunner
) -> None:
    get_tags_from_common_vars_mock.return_value = ["A", "B"]
    result = cli_runner.invoke(app=app, args=["docker", "build", "-f", "Dockerfile.prod"])
    assert result.exit_code == 0

    get_tags_from_common_vars_mock.assert_called_once_with(tags=None, registry=None, repositories=None, image_name=None)
    docker_build_wrapper_mock.assert_called_once_with(tags=["A", "B"], dockerfile=Path("Dockerfile.prod"))


@patch("voraus_pipeline_utils.cli.docker.get_tags_from_common_vars")
@patch("voraus_pipeline_utils.cli.docker.docker_build_wrapper")
def test_docker_build_success_with_tags(
    docker_build_wrapper_mock: MagicMock, get_tags_from_common_vars_mock: MagicMock, cli_runner: CliRunner
) -> None:
    get_tags_from_common_vars_mock.return_value = ["A", "B"]
    result = cli_runner.invoke(app=app, args=["docker", "build", "--tag", "main-42", "--tag", "latest"])
    assert result.exit_code == 0

    get_tags_from_common_vars_mock.assert_called_once_with(
        tags=["main-42", "latest"], registry=None, repositories=None, image_name=None
    )
    docker_build_wrapper_mock.assert_called_once_with(tags=["A", "B"], dockerfile=Path("Dockerfile"))
