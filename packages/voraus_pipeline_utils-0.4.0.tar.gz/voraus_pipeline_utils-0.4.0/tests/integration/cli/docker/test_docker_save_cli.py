"""Contains all integration tests for the docker save CLI."""

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from voraus_pipeline_utils.cli.main import app


@pytest.mark.skipif(sys.platform != "linux", reason="Only supported on linux because it requires docker")
@patch("voraus_pipeline_utils.cli.docker.get_tags_from_common_vars")
def test_docker_save_cli(
    get_tags_from_common_vars_mock: MagicMock, cli_runner: CliRunner, dummy_images: list[str], tmp_path: Path
) -> None:
    get_tags_from_common_vars_mock.return_value = dummy_images

    output_file = tmp_path / "archive.tar"

    result = cli_runner.invoke(app=app, args=["docker", "save", "--output", str(output_file)])
    assert result.exit_code == 0
    assert output_file.is_file()
