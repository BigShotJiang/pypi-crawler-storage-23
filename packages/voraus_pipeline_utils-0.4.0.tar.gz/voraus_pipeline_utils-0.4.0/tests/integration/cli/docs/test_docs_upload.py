"""Contains all unit tests for the docs CLI."""

import os
from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from voraus_pipeline_utils.cli.main import app


@patch.dict(
    os.environ,
    {
        "API_URL": "https://api.example.com",
        "PROJECT_NAME": "my-project",
        "PROJECT_VERSION": "1.0.0",
        "API_USER": "user",
        "API_TOKEN": "token",
    },
)
@patch("voraus_pipeline_utils.cli.docs.docs_upload_wrapper")
def test_docs_upload_success(docs_upload_wrapper_mock: MagicMock, cli_runner: CliRunner) -> None:
    result = cli_runner.invoke(app=app, args=["docs", "upload", "/path/to/docs"])
    assert result.exit_code == 0

    docs_upload_wrapper_mock.assert_called_once_with(
        build_dir=Path("/path/to/docs"),
        api_url="https://api.example.com",
        project_name="my-project",
        project_version="1.0.0",
        api_user="user",
        api_token="token",  # noqa: S106
    )
