"""Contains all unit tests for the docs CLI."""
