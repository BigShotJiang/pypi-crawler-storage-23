"""This module contains pytest fixtures."""

from pathlib import Path

import pytest
from typer.testing import CliRunner

from voraus_pipeline_utils.methods.shell import execute_command


@pytest.fixture(scope="session", name="resource_dir")
def resource_dir_fixture() -> Path:
    """Returns the path to the test resource directory.

    Returns:
        Path: The resource directory path.
    """
    return Path(__file__).parent.joinpath("resources")


@pytest.fixture(scope="session", name="cli_runner")
def cli_runner_fixture() -> CliRunner:
    """Returns a typer/click CliRunner with increased terminal width.

    Returns:
        The CliRunner object for testing the CLI.
    """
    return CliRunner(env={"COLUMNS": "160"})


@pytest.fixture(scope="session", name="dummy_images")
def dummy_images_fixture() -> list[str]:
    """Pulls some dummy docker images.

    Returns:
        The list of docker images that have been pulled.
    """
    dummy_images = ["alpine:latest", "alpine:edge"]
    for tag in dummy_images:
        execute_command(["docker", "pull", tag])
    return dummy_images
