"""This package contains resources, utility functions, and the tests of the test suite."""
