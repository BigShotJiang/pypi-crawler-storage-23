# voraus Pipeline Utils

A library containing pipeline utils for both, local usage and usage in Jenkins.

## Installation

Install **voraus-pipeline-utils** in your venv.

```bash
pip install voraus-pipeline-utils

# Or via uv
uv add --dev voraus-pipeline-utils
```

## Basic usage

Get help for any CLI command with
```bash
vpu --help
```

## Documentation

Please read the [documentation](https://vorausrobotik.github.io/voraus-pipeline-utils/)_ for more a more
detailed introduction.

