# SPDX-FileCopyrightText: 2026 Christian-Hauke Poensgen
# SPDX-FileCopyrightText: 2026 Maximilian Dolling
# SPDX-FileContributor: AUTHORS.md
#
# SPDX-License-Identifier: BSD-3-Clause

"""Public package entrypoints for Celery Root."""

from __future__ import annotations

import functools
import importlib
import os
import sys
from pathlib import Path
from typing import TYPE_CHECKING

from .config import (
    BeatConfig,
    CeleryRootConfig,
    DatabaseConfigBase,
    DatabaseConfigSqlite,
    FrontendConfig,
    McpConfig,
    OpenTelemetryConfig,
    PrometheusConfig,
    get_settings,
    set_settings,
)
from .core.db.adapters.base import BaseDBController
from .core.db.adapters.sqlite import SQLiteController
from .core.logging import LogQueueRuntime, create_log_runtime
from .core.process_manager import ProcessManager
from .core.registry import WorkerRegistry

if TYPE_CHECKING:
    import logging
    from collections.abc import Callable
    from types import ModuleType

    from celery import Celery


_RETENTION_ARG_POSITIVE_ERROR = "retention_days must be positive"


class CeleryRoot:
    """Bootstrap class for Celery Command & Control."""

    def __init__(
        self,
        *workers: Celery | str,
        config: CeleryRootConfig | None = None,
        db_controller: BaseDBController | Callable[[], BaseDBController] | None = None,
        purge_db: bool | None = None,
        retention_days: int | None = None,
        logger: logging.Logger | None = None,
    ) -> None:
        """Initialize the Root service with worker targets and configuration."""
        if config is None:
            config = get_settings()
        if retention_days is not None:
            if retention_days <= 0:
                raise ValueError(_RETENTION_ARG_POSITIVE_ERROR)
            if isinstance(config.database, DatabaseConfigSqlite):
                config = config.model_copy(
                    update={
                        "database": config.database.model_copy(
                            update={"retention_days": retention_days},
                        ),
                    },
                )
        if purge_db is not None and isinstance(config.database, DatabaseConfigSqlite):
            config = config.model_copy(
                update={
                    "database": config.database.model_copy(
                        update={"purge_db": purge_db},
                    ),
                },
            )

        config = self._ensure_worker_import_paths(config, workers)
        set_settings(config)
        self.config = config
        self.registry = WorkerRegistry(workers)
        self._db_controller = db_controller
        self._process_manager: ProcessManager | None = None
        self._log_runtime: LogQueueRuntime | None = None
        self._logger = logger
        self._ensure_sqlite_db_path()
        if isinstance(self.config.database, DatabaseConfigSqlite) and self.config.database.purge_db:
            self._purge_existing_db()

    def run(self) -> None:
        """Start all subprocesses and block until shutdown."""
        controller_factory = self._resolve_db_controller_factory()
        log_runtime = create_log_runtime(self._logger)
        self._log_runtime = log_runtime
        manager = ProcessManager(self.registry, self.config, controller_factory, log_runtime.config)
        self._process_manager = manager
        log_runtime.start()
        try:
            manager.run()
        finally:
            log_runtime.stop()

    def _resolve_db_controller_factory(self) -> Callable[[], BaseDBController] | None:
        if self._db_controller is not None and callable(self._db_controller):
            return self._db_controller
        if isinstance(self._db_controller, SQLiteController):
            path = getattr(self._db_controller, "_path", None)
            resolved = Path(path).expanduser().resolve() if path is not None else None
            db_path = resolved
            if isinstance(self.config.database, DatabaseConfigSqlite):
                db_config = self.config.database.model_copy(update={"db_path": db_path})
            else:
                db_config = DatabaseConfigSqlite(db_path=db_path)
            self.config = self.config.model_copy(update={"database": db_config})
            return None
        if isinstance(self._db_controller, BaseDBController):
            controller = self._db_controller
            return functools.partial(_return_controller, controller)
        return None

    def _ensure_sqlite_db_path(self) -> None:
        controller = self._db_controller
        if controller is not None:
            if isinstance(controller, SQLiteController):
                raw_path = getattr(controller, "_path", None)
                if raw_path is None:
                    if isinstance(self.config.database, DatabaseConfigSqlite):
                        db_config = self.config.database.model_copy(update={"db_path": None})
                    else:
                        db_config = DatabaseConfigSqlite(db_path=None)
                    self.config = self.config.model_copy(update={"database": db_config})
                    return
                resolved = Path(raw_path).expanduser().resolve()
                if isinstance(self.config.database, DatabaseConfigSqlite):
                    db_config = self.config.database.model_copy(update={"db_path": resolved})
                else:
                    db_config = DatabaseConfigSqlite(db_path=resolved)
                self.config = self.config.model_copy(update={"database": db_config})
                return
            if isinstance(controller, BaseDBController) or callable(controller):
                return
        if not isinstance(self.config.database, DatabaseConfigSqlite):
            return

        db_path = self.config.database.db_path
        if db_path is None:
            return
        path = Path(db_path).expanduser()
        path = (Path.cwd() / path).resolve() if not path.is_absolute() else path.resolve()
        self.config.database.db_path = path

    def _purge_existing_db(self) -> None:
        if not isinstance(self.config.database, DatabaseConfigSqlite):
            return
        path = self._resolve_purge_path()
        if path is None:
            return
        resolved = Path(path).expanduser().resolve()
        if not resolved.exists():
            return
        if resolved.is_dir():
            msg = f"SQLite database path points to a directory: {resolved}"
            raise RuntimeError(msg)
        try:
            resolved.unlink()
        except OSError as exc:  # pragma: no cover - depends on OS permissions
            msg = f"Failed to purge SQLite database at {resolved}: {exc}"
            raise RuntimeError(msg) from exc

    def _resolve_purge_path(self) -> Path | None:
        controller = self._db_controller
        if controller is None:
            if isinstance(self.config.database, DatabaseConfigSqlite):
                return self.config.database.db_path
            return None
        if isinstance(controller, SQLiteController):
            raw_path = getattr(controller, "_path", None)
            if raw_path is not None:
                return Path(raw_path)
            if isinstance(self.config.database, DatabaseConfigSqlite):
                return self.config.database.db_path
            return None
        return None

    @staticmethod
    def _ensure_worker_import_paths(
        config: CeleryRootConfig,
        workers: tuple[Celery | str, ...],
    ) -> CeleryRootConfig:
        if config.worker_import_paths:
            return config
        paths = _parse_worker_paths(os.getenv("CELERY_ROOT_WORKERS"))
        if not paths:
            paths = _derive_worker_import_paths(workers)
        if not paths:
            return config
        return config.model_copy(update={"worker_import_paths": paths})


def _make_sqlite_controller(path: Path | None) -> BaseDBController:
    """Create a SQLite controller; multiprocessing-safe factory."""
    return SQLiteController(path)


def _return_controller(controller: BaseDBController) -> BaseDBController:
    """Return the provided controller instance."""
    return controller


def _parse_worker_paths(raw: str | None) -> list[str]:
    if not raw:
        return []
    return [item.strip() for item in raw.split(",") if item.strip()]


def _derive_worker_import_paths(workers: tuple[Celery | str, ...]) -> list[str]:
    paths: list[str] = []
    seen: set[str] = set()
    for worker in workers:
        if isinstance(worker, str):
            if worker and worker not in seen:
                seen.add(worker)
                paths.append(worker)
            continue
        path = _resolve_app_import_path(worker)
        if path and path not in seen:
            seen.add(path)
            paths.append(path)
    return paths


def _resolve_app_import_path(app: Celery) -> str | None:
    candidates: list[str] = []
    raw_main = getattr(app, "main", None)
    if raw_main:
        candidates.append(str(raw_main))
    conf_main = app.conf.get("main") if getattr(app, "conf", None) else None
    if conf_main and str(conf_main) not in candidates:
        candidates.append(str(conf_main))
    for module_name in candidates:
        module = _load_module(module_name)
        if module is None:
            continue
        attr = _find_app_attr(module, app)
        if attr:
            return f"{module.__name__}:{attr}"
    for module in list(sys.modules.values()):
        if module is None:
            continue
        attr = _find_app_attr(module, app)
        if attr:
            return f"{module.__name__}:{attr}"
    return None


def _load_module(name: str) -> ModuleType | None:
    try:
        return importlib.import_module(name)
    except (ImportError, AttributeError, ModuleNotFoundError, TypeError, ValueError):  # pragma: no cover - best effort
        return None


def _find_app_attr(module: ModuleType, app: Celery) -> str | None:
    try:
        items = vars(module).items()
    except (AttributeError, TypeError):  # pragma: no cover - best effort
        return None
    for attr, value in items:
        if value is app:
            return str(attr)
    return None


__all__ = [
    "BeatConfig",
    "CeleryRoot",
    "CeleryRootConfig",
    "DatabaseConfigBase",
    "DatabaseConfigSqlite",
    "FrontendConfig",
    "McpConfig",
    "OpenTelemetryConfig",
    "PrometheusConfig",
]
