"""
Rayobyte Stealth Browser

A Playwright-based browser automation library with advanced fingerprint spoofing
and bot detection evasion capabilities.

Lightweight install (Docker users): Only `create_browser` is available.
Full install (daemon/standalone): All features including `rayobrowse_sync`.

Install full deps with: pip install rayobrowse[daemon]
"""

import logging
import os

logger = logging.getLogger(__name__)

# Version -- single source of truth is pyproject.toml (read via installed metadata)
from importlib.metadata import version as _get_version
try:
    __version__ = _get_version("rayobrowse")
except Exception:
    __version__ = "0.0.0"

# --- Lightweight client (always available) ---
from .daemon.client import create_browser

__all__ = ["create_browser"]

# --- Full features (only when daemon dependencies are installed) ---
# These require the optional [daemon] dependencies (geoip2, numpy, etc.)
# They are always available inside the Docker container.
def _is_full_install() -> bool:
    try:
        import geoip2  # noqa: F401 — daemon-only dependency
        return True
    except ImportError:
        return False


if _is_full_install():
    try:
        from .config import configure_logging
        configure_logging()

        def _check_and_update_resources():
            """Check for Chromium, GeoLite2, and font updates on import."""
            try:
                if os.environ.get("STEALTH_BROWSER_CHROME_EXECUTABLE", "").strip():
                    logger.debug("Auto-update skipped due to STEALTH_BROWSER_CHROME_EXECUTABLE override")
                    return

                from .updater import ensure_latest_chromium, ensure_geolite2_db, ensure_fonts
                from . import config, paths

                try:
                    ensure_latest_chromium()
                    logger.debug("Chromium version check complete")
                    config.DEFAULT_CONFIG["chrome_executable"] = paths.get_chrome_executable()
                    logger.debug(f"Chrome executable path: {config.DEFAULT_CONFIG['chrome_executable']}")
                    ensure_geolite2_db()
                    logger.debug("GeoLite2 database check complete")
                    ensure_fonts()
                    logger.debug("Font files check complete")
                except Exception as e:
                    logger.debug(f"Auto-update check failed: {e}")
                    logger.debug("Continuing with existing installation...")
            except Exception as e:
                logger.debug(f"Auto-update initialization skipped: {e}")

        _check_and_update_resources()

        from .session_sync import rayobrowse_sync
        __all__.extend(["rayobrowse_sync"])

    except Exception:
        pass
