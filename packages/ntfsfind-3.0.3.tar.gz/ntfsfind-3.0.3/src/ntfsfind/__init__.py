# coding: utf-8
from .core import ntfsfind

__all__ = ["ntfsfind"]
