import json
import os
from datetime import datetime

from setuptools import setup, find_packages
from pathlib import Path
from setuptools import setup

def read_version():
    ns = {}
    exec(Path("querycraft/__init__.py").read_text(encoding="utf-8"), ns)
    return ns["__version__"]

# Lire les dépendances depuis requirements.txt
# with open("./requirements.txt") as f: required = f.read().splitlines()

def maj_codemata(path, nouvelle_version):
    # Charger
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    # Modifier
    data["version"] = nouvelle_version
    data["dateModified"] = datetime.now().strftime("%Y-%m-%d")

    # Sauvegarder
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

version = read_version()

maj_codemata("querycraft/config/codemata.json", version)

setup(name='querycraft',
      version=version,
      author='Emmanuel Desmontils',
      author_email='emmanuel.desmontils@univ-nantes.fr',
      maintainer='Emmanuel Desmontils',
      maintainer_email=' emmanuel.desmontils@univ-nantes.fr',
      keywords='SQL Step-By-Step Query Database LLM IA',
      classifiers=['Topic :: Education', "Programming Language :: Python :: 3",
                   "Operating System :: OS Independent"],
      url='https://gitlab.univ-nantes.fr/ls2n-didactique/querycraft',
      packages=find_packages(),
      python_requires=">=3.11.0",
      install_requires=['argparse>=1.4.0', 'openai>=2.9.0', 'tincan>=1.0.0','SQLAlchemy>=2.0.40','jinja2>=3.1.6',
                        'mysql-connector-python>=9.0.0', 'lmstudio>=1.5.0','psycopg2-binary==2.9.10',
                        'ollama>=0.4.7', 'keyboard>=0.13.5', 'google-genai>=1.61.0','markdown>=3.5.0',
                        'sqlglot==25.33.0', 'colorama>=0.4.6', 'flask>=3.0.0'],
      entry_points={'console_scripts': ['pgsql-sbs = querycraft.sqlsbs:pgsql',
                                        'sqlite-sbs = querycraft.sqlsbs:sqlite',
                                        'mysql-sbs = querycraft.sqlsbs:mysql',
                                        'sbs = querycraft.sqlsbs:main',
                                        'admin-sbs = querycraft.sqlsbs:admin',
                                        'exos-sbs = querycraft.sqlsbs:exos',
                                        'web-sbs = querycraft.web_sbs:main']},
      include_package_data=True,
      package_data={'querycraft': ['data/*', 'config/*', 'cookies/*', 'cache/*', 'templates/*', 'exos/*', 'logs/*']},
      description='Provide usefully SQL classes and functions to execute SQL queries step by step',
      long_description=open(os.path.join(os.path.dirname(__file__), 'README.md')).read(),
      long_description_content_type="text/markdown",
      license='GPL V3',
      platforms='ALL',
      )
