..
   SPDX-FileCopyrightText: 2026 Andrew Grimberg <tykeal@bardicgrove.org>
   SPDX-License-Identifier: Apache-2.0

Changelog
=========

Unreleased
----------

* Initial release of pylocal-akuvox
* Async-only Python library for Akuvox local HTTP API
* Device connection and info retrieval
* User and PIN management (CRUD)
* Relay control (trigger and status)
* Access schedule management (CRUD)
* Door and call log retrieval
* Authentication: None, AllowList, Basic, Digest
* SSL support with self-signed certificate handling
* Typed exception hierarchy for error handling
