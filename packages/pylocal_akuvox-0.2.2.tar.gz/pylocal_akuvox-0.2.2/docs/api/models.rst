..
   SPDX-FileCopyrightText: 2026 Andrew Grimberg <tykeal@bardicgrove.org>
   SPDX-License-Identifier: Apache-2.0

Data Models
===========

.. automodule:: pylocal_akuvox.models
   :members:
   :undoc-members:
   :show-inheritance:
