"""Tests for the secondary loop module."""
