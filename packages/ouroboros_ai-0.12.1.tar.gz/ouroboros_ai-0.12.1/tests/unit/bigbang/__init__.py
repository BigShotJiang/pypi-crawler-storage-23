"""Tests for Big Bang phase - Interactive interview."""
