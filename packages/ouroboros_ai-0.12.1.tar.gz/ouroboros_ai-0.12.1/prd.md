PRD: 가사 기획노동 봇 (내부서버/스냅샷 기반) MVP
0. 문서 메타

문서명: HouseOps MVP PRD (가칭)

버전: v0.1

기준일: 2026-02-17 (KST)

제품 형태: 로컬(내부서버) 웹앱 + 백엔드 서비스 + 스케줄러/워커

핵심 차별점: “집 상태 관측(스냅샷) → 자동 계획 → 버튼 합의(갈등 최소화) → 실행 체크 → 주간 자동 리밸런싱”

1. 문제 정의
1.1 해결하려는 핵심 문제(Top 3)

가사 ‘기획노동’이 특정 사람에게 몰림

무엇을 해야 하는지 판단, 우선순위, 타이밍, 누락 관리가 지속적으로 발생

부부 갈등의 트리거는 ‘실행’이 아니라 ‘인지·표현·공정성’

“내가 더 한다” 체감 불일치

“사진/증거” 기반 말싸움으로 확전

체크리스트 앱은 ‘집 상태’를 몰라서 결국 사람이 입력함

입력 피로 → 방치 → 갈등 원점 회귀

1.2 제품 가설(가장 중요한 한 줄)

“공용공간 스냅샷으로 집 상태를 숫자로 만들고, AI/룰이 오늘 할 일 2안을 제시하며, 부부가 버튼으로 합의하게 하면, ‘말싸움 비용’과 ‘기획노동’을 크게 줄일 수 있다.”

2. 목표 및 성공 지표
2.1 MVP 목표(Goal)

매일 1회 “오늘의 플랜(2안)”을 자동 생성

**합의 UI(버튼 4개)**로 “협상 대화량”을 감소

주간 단위로 “편향(누적 과부하)”을 완화하는 자동 제안

2.2 MVP 성공 지표(Success Metrics)

제품 내부 측정 지표(로컬 저장):

DAU/2인 사용률: 하루 1회 이상 플랜 화면 열람

Plan Acceptance Rate: 플랜 A/B 중 하나가 “동의/생존모드/연기/교환”으로 처리되는 비율 ≥ 60%

Swap/Delay Usage: 교환/연기 버튼 사용이 일정 비율(예: 10~30%) 발생
→ “말로 싸우는 대신 UI로 해결”이 작동 중이라는 시그널

House State Trend: 주방/거실 지표의 주간 평균이 개선(또는 악화 속도 둔화)

Setup Time: 설치 후 “카메라 연결+마스킹+스케줄” 완료까지 15분 내

3. 범위 정의
3.1 MVP In-Scope (P0)
(A) 고정캠 스냅샷

RTSP 카메라 최대 2대

Camera 1: 주방(싱크대/조리대)

Camera 2: 거실(테이블/바닥)

스냅샷 모드

기본: 하루 1회(저녁 추천) 자동 캡처

수동: “지금 업데이트” 버튼으로 추가 캡처

프라이버시 마스킹 필수

사용자가 사각형 영역 지정(예: 소파, 창문 바깥, 침실 방향)

이미지 저장 정책(선택)

기본값: “단기 보관(예: 24h) 또는 분석 후 폐기” 중 하나를 설치 마법사에서 선택

(B) 집 상태 지표(2개만)

SinkLoad (0~100): 주방 “설거지/싱크대 누적도”

LivingReset (0~100): 거실 “10분 리셋 필요도”

지표 산출에는 **신뢰도(confidence 0~1)**를 함께 저장

사용자가 지표를 1탭으로 수정(“과대/정확/과소”)할 수 있게 하여 빠른 튜닝 데이터 확보

(C) 플랜 생성(오늘 2안)

매일 자동 생성:

플랜 A: 10~15분 (생존/최소 회복)

플랜 B: 20~30분 (표준 회복)

플랜은 “할 일” 뿐 아니라 누가 무엇을 할지(자동 배분) 포함

(D) 공정성 엔진(초간단)

각 작업에 포인트 부여(시간 기반)

최근 7일 누적 포인트를 기준으로 자동 배분

“컨디션 낮음” 토글(1클릭) 제공 → 그날 배분 가중치 완화

(E) 부부갈등 최소화 UI(핵심)

플랜 카드에 항상 4버튼

✅ 동의(이대로 진행)

🔁 교환(배정만 스왑)

⏸ 연기(내일로)

🧯 생존모드(플랜 A로 다운시프트)

메인 화면 기본은 사진이 아니라 ‘지표+추세’

사진은 “검증용”으로 접어서 숨김(기본 숨김)

(F) 실행 체크(최소)

각 작업 “완료” 버튼

완료 시각 기록

(MVP에서는) 완료 검증을 위해 추가 사진 촬영 요구하지 않음(갈등/감시 인상 방지)

(G) 주간 리포트(매주 1회 자동)

이번 주 집 상태 추세(주방/거실)

이번 주 누적 포인트 균형(편향 알림)

다음 주 “리밸런싱 제안 2안” 생성

(H) 내부서버 원클릭 설치(Docker Compose)

install.sh 실행 → 웹 설치 마법사 진입

서비스 구성 최소:

backend-api

frontend-web

worker/scheduler

db (SQLite 또는 Postgres)

로컬 네트워크 기본(외부 노출 기본값 OFF)

3.2 Out-of-Scope (MVP에서 제외)

상시 녹화/NVR(영상 저장/재생)

침실/욕실 등 민감 공간 지원

쓰레기통 채움/세탁 바구니 채움 등 “집마다 튜닝 지옥” 기능

음성 비서/스피커 연동

클라우드 로그인/결제/원격 접근 자동 구성(포트포워딩)

복잡한 역할/가족(3인 이상) 지원(부부 2인만)

4. 사용자/페르소나
페르소나 A: 맞벌이 부부(핵심 타깃)

시간 부족, 피로 누적

갈등이 “누가 더 했냐”로 번짐

앱 입력은 귀찮아서 안 함
→ 자동 플랜 + 버튼 합의가 잘 먹힘

페르소나 B: 스마트홈/홈서버 사용자(초기 얼리어답터)

IP카메라/RTSP/도커 설치 가능

로컬/프라이버시 민감도 높음
→ “로컬-퍼스트”를 강점으로 인식

5. 핵심 사용자 여정(User Journey)
5.1 최초 설치(15분 목표)

install.sh 실행

웹 설치 마법사

관리자 계정 생성

파트너 초대(초대코드/QR)

카메라 1~2대 RTSP 등록 → 테스트 스냅샷 확인

마스킹 영역 지정

스냅샷 시간 설정(기본: 저녁 1회)

완료 → “오늘 플랜” 화면으로 이동

5.2 매일 사용(2분 루프)

알림/접속

집 상태 요약(주방/거실 지표)

플랜 A/B 확인

✅/🔁/⏸/🧯 중 하나 클릭

작업 완료 체크(최소)

5.3 갈등 상황(30초 탈출)

한쪽이 “오늘 힘듦”

UI에서 🔁 교환 또는 🧯 생존모드로 즉시 다운시프트
→ “말로 설득” 없이 버튼으로 해결

5.4 주간 정산(1~3분)

리포트에서 편향 확인

“다음 주 자동 보정” 토글(동의/거절)

6. 기능 요구사항(상세)
6.1 카메라 관리

[P0] RTSP URL 등록/수정/삭제

[P0] 연결 테스트(스냅샷 1장 캡처)

[P0] 마스킹 영역(다각형은 P1, MVP는 사각형 1~N)

[P0] 스냅샷 스케줄 설정(요일/시간)

[P1] “게스트 모드”(지정 시간 동안 캡처 중단)

수용 기준

RTSP 연결 실패 시 이유(타임아웃/인증 실패)를 사용자에게 명확히 노출

마스킹 영역은 분석/저장 모두에 적용되어야 함

6.2 스냅샷 파이프라인

[P0] 스케줄러가 캡처 → 마스킹 적용 → 분석 → 지표 저장

[P0] 실패 시 재시도(예: 2회, 30초 간격)

[P0] 이미지 저장 정책

“분석 후 폐기” 또는 “24시간 보관”을 설정에서 선택

6.3 상태 지표 산출

[P0] SinkLoad, LivingReset 산출 및 저장

[P0] 신뢰도(confidence) 저장

[P0] 사용자 피드백(과대/정확/과소) 1탭 입력

수용 기준

지표는 “왜 그렇게 나왔는지”를 한 줄 설명(예: “싱크대 객체 밀도 높음(0.78)”)
→ 단, 공격적 표현 금지

6.4 작업/플랜 엔진

[P0] 지표 임계치 기반으로 작업 후보 생성

[P0] 플랜 A/B 구성

[P0] 작업 배정(공정성 엔진 결과 반영)

[P0] 조정 버튼 반영(교환/연기/생존모드)

수용 기준

플랜은 매일 “한 번” 생성되어야 하며, 수동 재생성 버튼 제공(남용 방지: 하루 3회 제한)

6.5 공정성 엔진

[P0] 최근 7일 누적 포인트 기반

[P0] 컨디션 토글로 가중치 조정

[P0] 주간 리포트에 편향 표시

수용 기준

사용자가 “공정성 기준”을 이해할 수 있도록 1문장 안내

6.6 UI/UX(갈등 최소화 원칙 내장)

[P0] 메인=지표/추세 중심, 사진은 접힘

[P0] 4버튼(동의/교환/연기/생존모드) 고정

[P0] 상대 비난/감시로 해석될 문구 금지

금지 예: “오늘도 안 했네요”, “왜 이렇게 더럽죠?”

권장 예: “오늘은 최소 회복 플랜을 추천해요”

6.7 주간 리포트

[P0] 자동 생성(예: 매주 일요일 밤/월요일 아침)

[P0] 집 상태 추세 + 공정성 + 다음 주 제안 2안

[P0] 리포트 톤 가이드 준수(비난 금지)

7. 비기능 요구사항(NFR)
7.1 보안

로컬 네트워크 우선(기본값 외부 노출 OFF)

계정/세션: 최소한의 로그인(부부 2인)

관리자 권한 분리(카메라/보안 설정은 관리자만)

7.2 프라이버시(제품 신뢰의 핵심)

“민감 공간” 안내 및 경고(설정 마법사에서 강조)

마스킹 필수

이미지 저장 최소화(옵션으로도 제공하되 기본은 보수적으로)

7.3 성능/안정성

스냅샷 2대 × 하루 1~5회 수준에서 안정 동작

분석 실패 시에도 “룰 기반 플랜”으로 폴백(서비스 중단 방지)

7.4 운영/관측

로그: 캡처 성공/실패, 분석 시간, 지표 생성 여부

간단 상태 페이지(Health/Ready)

8. 시스템 아키텍처(권장)
8.1 논리 구조

snapshot-service: RTSP → 이미지 캡처(FFmpeg 등), 마스킹

analyzer: 이미지 → 지표 산출(로컬 모델/규칙, 플러그형)

planner: 지표/히스토리 → 플랜 A/B + 배분

web UI: 합의/체크/리포트

DB: 유저/카메라/지표/플랜/이력

8.2 배포 구조(Docker Compose)

frontend-web (Next.js 등)

backend-api (FastAPI 등)

worker (스케줄러/큐 소비)

db (SQLite=진짜 MVP / Postgres=권장)

9. 데이터 모델(초안)
핵심 엔티티

Household(id, name, created_at)

User(id, household_id, role[admin/member], display_name, created_at)

Camera(id, household_id, name, rtsp_url, enabled, created_at)

MaskRegion(id, camera_id, x, y, w, h, enabled)

Snapshot(id, camera_id, captured_at, storage_mode, image_path_nullable, masked_image_path_nullable)

MetricRecord(id, household_id, camera_id, captured_at, metric_type, value_0_100, confidence_0_1)

TaskType(id, key, default_points, default_duration_min)

TaskInstance(id, household_id, task_type, scheduled_for_date, assigned_user_id, status, points, created_at, completed_at)

Plan(id, household_id, date, variant[A/B], status[proposed/accepted/delayed], created_at)

PlanItem(id, plan_id, task_instance_id, order)

PlanDecision(id, plan_id, action[accept/swap/delay/survival], actor_user_id, created_at, payload_json)

WeeklyReport(id, household_id, week_start, generated_at, payload_json)

10. API 설계(초안)
Auth

POST /api/auth/login

POST /api/auth/logout

GET /api/me

Setup

POST /api/household

POST /api/household/invite (초대코드 생성)

POST /api/household/join (코드로 참여)

Cameras

POST /api/cameras

GET /api/cameras

POST /api/cameras/{id}/test-snapshot

PUT /api/cameras/{id}

POST /api/cameras/{id}/mask-regions

DELETE /api/mask-regions/{id}

Metrics

GET /api/metrics/latest?metric_type=SinkLoad

GET /api/metrics/range?from=...&to=...

Plans

POST /api/plans/generate?date=YYYY-MM-DD

GET /api/plans/today

POST /api/plans/{id}/decision (accept/swap/delay/survival)

POST /api/tasks/{id}/complete

Reports

GET /api/reports/weekly/latest

GET /api/reports/weekly?week_start=YYYY-MM-DD

Health

GET /health

GET /ready

11. 카피/톤 가이드(갈등 방지 규칙)

금지

“왜 안 했어요?”

“또 더럽네요”

“당신이 해야죠”

권장

“오늘은 최소 회복 플랜을 추천해요.”

“이번 주는 일정이 빡빡했어서 자동으로 부담을 분산했어요.”

“교환/연기/생존모드 중 편한 걸로 고르세요.”

12. 테스트 계획(최소)
기능 테스트(P0)

RTSP 연결 성공/실패 케이스

마스킹 적용 여부(저장/분석 모두)

스케줄 캡처 실행/재시도

지표 생성/저장/피드백 입력

플랜 A/B 생성, 4버튼 동작

완료 체크 → 주간 리포트 반영

사용자 테스트(인터뷰 기반)

“감시당하는 느낌” 여부 체크(정성)

교환/연기 버튼이 실제로 갈등을 흡수하는지(정성)

사진 기본 숨김이 신뢰에 도움 되는지(정성)

13. Ouroboros(플러그인) 적용 방식(스펙 루프)

당신이 링크 준 Ouroboros는 “Socratic interview → Seed(불변 스펙)” 흐름을 핵심으로 하고, 플러그인 모드에서 ooo interview와 ooo seed로 스펙을 생성하는 사용법을 제시하고 있어요.
또 Seed 예시 스키마(goal/constraints/acceptance_criteria/ontology_schema/metadata)를 문서에서 보여주고, “모호도 점수”를 낮춰 스펙을 굳히는 흐름을 강조합니다.
아키텍처 문서에서는 플러그인 레이어(스킬/에이전트), 불변 Seed 모델, 이벤트 소싱/SQLite 이벤트스토어 등을 설명합니다.

실무 적용(추천)

PRD(이 문서) → Ouroboros 인터뷰로 빈 구멍 찾기 (ooo interview)

인터뷰 결과를 반영해 Seed YAML 생성 (ooo seed)

Seed를 “스펙 단일 원천(SSOT)”로 관리

이후 기능 추가/변경은 Seed 업데이트 → 평가(테스트/AC)로 드리프트 관리
