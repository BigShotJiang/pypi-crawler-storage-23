"""
TLM Compliance Checker -- Validates staged changes against active spec.

Checks git diff against the latest spec file and sends to server API
for compliance analysis.

Adapted from MVP's engine.py ComplianceChecker to work without the Project class.
"""

import json
import subprocess
from pathlib import Path


class ComplianceChecker:
    """Validates staged changes against active spec."""

    def __init__(self, project_root: str, api_client, project_id: str):
        self.root = Path(project_root).resolve()
        self.tlm_dir = self.root / ".tlm"
        self.api_client = api_client
        self.project_id = project_id

    def _get_profile(self) -> str:
        profile_file = self.tlm_dir / "profile.md"
        if profile_file.exists():
            return profile_file.read_text()
        return "(not scanned yet)"

    def _get_enforcement_summary(self) -> str:
        enforcement_file = self.tlm_dir / "enforcement.json"
        if enforcement_file.exists():
            try:
                config = json.loads(enforcement_file.read_text())
                return json.dumps(config, indent=2)
            except (json.JSONDecodeError, OSError):
                pass
        return "(no enforcement config)"

    def check(self, spec_path: str = None) -> str:
        """Run compliance check against a spec.

        Args:
            spec_path: Path to spec file. If None, uses the latest spec in .tlm/specs/.

        Returns:
            Compliance check result string from the server.
        """
        diff = self._get_diff()
        if not diff:
            return "No changes detected. Stage changes with `git add` first."

        if spec_path:
            spec = Path(spec_path).read_text()
        else:
            specs_dir = self.tlm_dir / "specs"
            if not specs_dir.exists():
                return "No specs found. Run `tlm build` first."
            specs = sorted(specs_dir.glob("*.md"), reverse=True)
            if not specs:
                return "No specs found. Run `tlm build` first."
            spec = specs[0].read_text()

        result = self.api_client.compliance_check(
            self.project_id, spec, diff,
            self._get_profile(),
            self._get_enforcement_summary(),
        )
        return result["result"]

    def _get_diff(self) -> str:
        """Get git diff — staged first, then unstaged."""
        try:
            result = subprocess.run(
                ["git", "diff", "--cached"], capture_output=True, text=True,
                cwd=str(self.root)
            )
            if result.stdout.strip():
                return result.stdout
            result = subprocess.run(
                ["git", "diff"], capture_output=True, text=True,
                cwd=str(self.root)
            )
            return result.stdout
        except FileNotFoundError:
            return ""
