"""
TLM Drift Detector -- Hash-based config file change detection.

Detects if project setup files have changed since the enforcement config
was approved. Uses EnforcementConfig's hash-based drift detection, then
asks the server API if the changes are meaningful.

Adapted from MVP's engine.py DriftDetector to work without the Project class.
"""

from pathlib import Path

from tlm.enforcer import EnforcementConfig


class DriftDetector:
    """Detects if project setup has changed since config was approved."""

    def __init__(self, project_root: str, api_client, project_id: str):
        self.root = Path(project_root).resolve()
        self.tlm_dir = self.root / ".tlm"
        self.api_client = api_client
        self.project_id = project_id
        self._enforcement = EnforcementConfig(str(self.tlm_dir))

    def check(self) -> dict:
        """Quick check: have drift indicator files changed?

        Returns: {"drifted": bool, "stale": bool, "changed_files": [...], "reason": str}
        """
        if not self._enforcement.approved:
            return {"drifted": False, "stale": False, "changed_files": [], "reason": ""}

        drift = self._enforcement.check_drift()

        if not drift["drifted"]:
            return {"drifted": False, "stale": False, "changed_files": [], "reason": ""}

        # Files changed — ask server if it's meaningful
        config = self._enforcement.load()

        # Read current contents of changed files
        file_contents = {}
        for filename in drift["changed_files"]:
            filepath = self.root / filename
            if filepath.exists():
                try:
                    file_contents[filename] = filepath.read_text()[:3000]
                except Exception:
                    file_contents[filename] = "(unreadable)"
            else:
                file_contents[filename] = "(deleted)"

        result = self.api_client.check_drift(
            self.project_id, config, drift["details"], file_contents
        )
        return {
            "drifted": True,
            "stale": result.get("stale", True),
            "changed_files": drift["changed_files"],
            "reason": result.get("reason", ""),
            "affected_sections": result.get("affected_sections", []),
        }
