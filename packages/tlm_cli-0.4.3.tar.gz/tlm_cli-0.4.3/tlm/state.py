"""State management — .tlm/state.json read/write.

Tracks current phase (idle, tlm_active, implementation, deployment),
activity type, and active spec.
"""

import json
import datetime
from pathlib import Path

DEFAULT_STATE = {
    "phase": "idle",
    "activity_type": None,
    "active_spec": None,
    "last_updated": None,
}


def read_state(project_root: str) -> dict:
    """Read state from .tlm/state.json. Returns defaults if missing."""
    state_path = Path(project_root) / ".tlm" / "state.json"
    if not state_path.exists():
        return dict(DEFAULT_STATE)
    try:
        data = json.loads(state_path.read_text())
        result = dict(DEFAULT_STATE)
        result.update(data)
        return result
    except (json.JSONDecodeError, OSError):
        return dict(DEFAULT_STATE)


def write_state(project_root: str, state: dict):
    """Write state to .tlm/state.json with timestamp."""
    state_path = Path(project_root) / ".tlm" / "state.json"
    state_path.parent.mkdir(parents=True, exist_ok=True)

    full_state = dict(DEFAULT_STATE)
    full_state.update(state)
    full_state["last_updated"] = datetime.datetime.now().isoformat()

    state_path.write_text(json.dumps(full_state, indent=2))


def set_phase(project_root: str, phase: str):
    """Update just the phase, preserving other fields."""
    current = read_state(project_root)
    current["phase"] = phase
    write_state(project_root, current)
