"""TLM — AI Tech Lead that enforces TDD, tests, and spec compliance in Claude Code."""

__version__ = "0.4.0"
