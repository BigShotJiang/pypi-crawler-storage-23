"""
TLM Config Generator -- LLM-powered enforcement config generation.

Generates enforcement.json via server API, with optional local Claude CLI
for preliminary analysis. Supports interactive update via feedback.

Adapted from MVP's engine.py ConfigGenerator to work without the Project class.
"""

import json
import shutil
import subprocess
import logging
from pathlib import Path

from tlm.enforcer import EnforcementConfig
from tlm.scanner import scan_project

logger = logging.getLogger(__name__)


class ConfigGenerator:
    """Generates enforcement config via LLM, then runs interactive approval.

    Flow:
    1. LLM scans project -> generates enforcement.json
    2. Present to user interactively
    3. User corrects / approves
    4. Save as approved config
    """

    def __init__(self, project_root: str, api_client, project_id: str):
        self.root = Path(project_root).resolve()
        self.tlm_dir = self.root / ".tlm"
        self.api_client = api_client
        self.project_id = project_id
        self._enforcement = EnforcementConfig(str(self.tlm_dir))

    def _get_profile(self) -> str:
        profile_file = self.tlm_dir / "profile.md"
        if profile_file.exists():
            return profile_file.read_text()
        return "(not scanned yet)"

    def _get_local_config(self, profile: str, file_tree: str, samples: str) -> dict | None:
        """Run local Claude to generate preliminary config JSON.

        Returns parsed dict on success, None on any failure.
        Zero user-visible side effects.
        """
        if not shutil.which("claude"):
            logger.debug("claude CLI not found, skipping local config")
            return None

        prompt = (
            "Generate enforcement config JSON for this project.\n\n"
            f"Profile:\n{profile}\n\nFiles:\n{file_tree}\n\nSamples:\n{samples}\n\n"
            "Return ONLY valid JSON. No markdown fences. No explanation."
        )

        try:
            result = subprocess.run(
                ["claude", "-p", prompt],
                capture_output=True,
                text=True,
                timeout=90,
            )
            if result.returncode != 0:
                logger.debug("claude CLI exited with code %d", result.returncode)
                return None
            output = result.stdout.strip()
            if not output:
                return None
            return json.loads(output)
        except (subprocess.TimeoutExpired, json.JSONDecodeError):
            logger.debug("claude CLI failed for local config")
            return None
        except Exception as e:
            logger.debug("claude CLI failed: %s", e)
            return None

    def generate(self) -> dict:
        """Have the LLM generate an enforcement config."""
        scan_result = scan_project(str(self.root))
        file_tree = scan_result["file_tree"]
        samples = scan_result["samples"]
        profile = self._get_profile()
        local_config = self._get_local_config(profile, file_tree, samples)
        result = self.api_client.generate_config(
            self.project_id, profile, file_tree, samples,
            local_config=local_config,
        )
        return result["config"]

    def update_config(self, current_config: dict, feedback: str) -> dict:
        """Have the LLM update the config based on user feedback."""
        result = self.api_client.update_config(
            self.project_id, current_config, feedback, self._get_profile()
        )
        return result["config"]

    def save_approved(self, config: dict):
        """Save config and mark as approved."""
        self._enforcement.save(config)
        self._enforcement.approve()
