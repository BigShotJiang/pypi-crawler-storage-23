"""Tests for HTTP client — sync client with proper error handling."""

import pytest
from unittest.mock import patch, MagicMock

import httpx
import respx

from tlm.client import TLMClient


# ── Fixture ──────────────────────────────────────────────────

@pytest.fixture
def client():
    return TLMClient(server_url="http://test-server:8000", api_key="test-key-123")


# ── Exception classes exist ──────────────────────────────────

class TestExceptions:
    """Custom exceptions should exist and be importable."""

    def test_auth_error_exists(self):
        from tlm.client import TLMAuthError
        assert issubclass(TLMAuthError, Exception)

    def test_credits_error_exists(self):
        from tlm.client import TLMCreditsError
        assert issubclass(TLMCreditsError, Exception)

    def test_project_limit_error_exists(self):
        from tlm.client import TLMProjectLimitError
        assert issubclass(TLMProjectLimitError, Exception)

    def test_server_error_exists(self):
        from tlm.client import TLMServerError
        assert issubclass(TLMServerError, Exception)

    def test_connection_error_exists(self):
        from tlm.client import TLMConnectionError
        assert issubclass(TLMConnectionError, Exception)


# ── Error response mapping ───────────────────────────────────

class TestErrorHandling:
    """_handle_response() should map status codes to exceptions."""

    @patch("httpx.get")
    def test_401_raises_auth_error(self, mock_get, client):
        from tlm.client import TLMAuthError
        mock_resp = MagicMock()
        mock_resp.status_code = 401
        mock_resp.json.return_value = {"detail": "Invalid token"}
        mock_get.return_value = mock_resp

        with pytest.raises(TLMAuthError):
            client.me()

    @patch("httpx.post")
    def test_402_raises_credits_error(self, mock_post, client):
        from tlm.client import TLMCreditsError
        mock_resp = MagicMock()
        mock_resp.status_code = 402
        mock_resp.json.return_value = {
            "detail": {"credits_remaining": 0, "tier": "free"}
        }
        mock_post.return_value = mock_resp

        with pytest.raises(TLMCreditsError):
            client.scan(1, "tree", "samples")

    @patch("httpx.get")
    def test_403_raises_auth_error(self, mock_get, client):
        from tlm.client import TLMAuthError
        mock_resp = MagicMock()
        mock_resp.status_code = 403
        mock_resp.json.return_value = {"detail": "Forbidden"}
        mock_get.return_value = mock_resp

        with pytest.raises(TLMAuthError):
            client.me()

    @patch("httpx.post")
    def test_403_project_limit_raises_project_limit_error(self, mock_post, client):
        from tlm.client import TLMProjectLimitError
        mock_resp = MagicMock()
        mock_resp.status_code = 403
        mock_resp.json.return_value = {
            "detail": {"error": "project_limit_reached", "limit": 3}
        }
        mock_post.return_value = mock_resp

        with pytest.raises(TLMProjectLimitError):
            client.create_project("test", "fp")

    @patch("httpx.get")
    def test_500_raises_server_error(self, mock_get, client):
        from tlm.client import TLMServerError
        mock_resp = MagicMock()
        mock_resp.status_code = 500
        mock_resp.json.return_value = {"detail": "Internal error"}
        mock_get.return_value = mock_resp

        with pytest.raises(TLMServerError):
            client.me()

    @patch("httpx.get")
    def test_connection_error_on_timeout(self, mock_get, client):
        from tlm.client import TLMConnectionError
        mock_get.side_effect = httpx.TimeoutException("timed out")

        with pytest.raises(TLMConnectionError):
            client.me()

    @patch("httpx.get")
    def test_connection_error_on_connect_failure(self, mock_get, client):
        from tlm.client import TLMConnectionError
        mock_get.side_effect = httpx.ConnectError("refused")

        with pytest.raises(TLMConnectionError):
            client.me()


# ── Auth header ──────────────────────────────────────────────

class TestAuthHeaders:
    """Client should send Authorization header on all requests."""

    @patch("httpx.get")
    def test_sends_bearer_token(self, mock_get, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"user_id": "u1"}
        mock_get.return_value = mock_resp

        client.me()

        call_args = mock_get.call_args
        headers = call_args[1].get("headers", call_args.kwargs.get("headers", {}))
        assert headers.get("Authorization") == "Bearer test-key-123"


# ── V1 Endpoints (sync) ─────────────────────────────────────

class TestV1Endpoints:
    """V1 endpoints should work synchronously."""

    @patch("httpx.get")
    def test_me(self, mock_get, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"user_id": "u1", "email": "test@example.com"}
        mock_get.return_value = mock_resp

        result = client.me()
        assert result["user_id"] == "u1"

    @patch("httpx.post")
    def test_create_project(self, mock_post, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"project_id": 42, "name": "my-proj"}
        mock_post.return_value = mock_resp

        result = client.create_project("my-proj", "fp123")
        assert result["project_id"] == 42

    @patch("httpx.get")
    def test_list_projects(self, mock_get, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"projects": [{"id": 1}]}
        mock_get.return_value = mock_resp

        result = client.list_projects()
        assert "projects" in result

    @patch("httpx.delete")
    def test_delete_project(self, mock_delete, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"deleted": True}
        mock_delete.return_value = mock_resp

        result = client.delete_project("proj_1")
        assert result["deleted"] is True

    @patch("httpx.post")
    def test_scan(self, mock_post, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"gaps": [], "profile": {"stack": "Python"}}
        mock_post.return_value = mock_resp

        result = client.scan(1, "file_tree", "samples")
        assert "profile" in result

    @patch("httpx.post")
    def test_exchange_firebase_token(self, mock_post, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"api_key": "tlm_sk_abc", "user_id": 1}
        mock_post.return_value = mock_resp

        result = client.exchange_firebase_token("firebase-jwt")
        assert result["api_key"] == "tlm_sk_abc"


# ── Missing V1 endpoints from MVP ───────────────────────────

class TestMVPEndpoints:
    """Endpoints ported from MVP that V2 was missing."""

    @patch("httpx.get")
    def test_usage(self, mock_get, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "credits_total": 150, "credits_used": 50,
            "credits_remaining": 100, "tier": "free",
        }
        mock_get.return_value = mock_resp

        result = client.usage()
        assert result["credits_remaining"] == 100
        call_url = mock_get.call_args[0][0]
        assert "/usage" in call_url

    @patch("httpx.post")
    def test_generate_config(self, mock_post, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"config": {"checks": []}}
        mock_post.return_value = mock_resp

        result = client.generate_config("proj_1", "profile", "tree", "samples")
        assert "config" in result

    @patch("httpx.post")
    def test_update_config(self, mock_post, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"config": {"checks": [{"name": "tests"}]}}
        mock_post.return_value = mock_resp

        result = client.update_config("proj_1", {"checks": []}, "add test check", "profile")
        assert "config" in result

    @patch("httpx.post")
    def test_compliance_check(self, mock_post, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"verdict": "pass", "issues": []}
        mock_post.return_value = mock_resp

        result = client.compliance_check("proj_1", "spec", "diff", "profile", "config")
        assert result["verdict"] == "pass"

    @patch("httpx.post")
    def test_analyze_commit(self, mock_post, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"category": "feature", "patterns": []}
        mock_post.return_value = mock_resp

        result = client.analyze_commit("proj_1", {"hash": "abc", "message": "feat"})
        assert result["category"] == "feature"

    @patch("httpx.post")
    def test_synthesize(self, mock_post, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"patterns": [], "lessons": []}
        mock_post.return_value = mock_resp

        result = client.synthesize("proj_1", [{"hash": "abc"}])
        assert "patterns" in result

    @patch("httpx.get")
    def test_sync(self, mock_get, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"knowledge": "", "profile": ""}
        mock_get.return_value = mock_resp

        result = client.sync("proj_1")
        assert "knowledge" in result

    @patch("httpx.post")
    def test_embed(self, mock_post, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"embeddings": [[0.1, 0.2]]}
        mock_post.return_value = mock_resp

        result = client.embed(["hello world"])
        assert "embeddings" in result

    @patch("httpx.post")
    def test_learn_session(self, mock_post, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"rules": [], "patterns": []}
        mock_post.return_value = mock_resp

        result = client.learn_session({"prompts": []}, "knowledge")
        assert "rules" in result

    @patch("httpx.post")
    def test_report_error_swallows_exceptions(self, mock_post, client):
        """report_error should never raise."""
        mock_post.side_effect = Exception("network failure")

        # Should not raise
        client.report_error("proj_1", "test_error", "detail", "context")


# ── V2 Endpoints (sync) ─────────────────────────────────────

class TestV2Endpoints:
    """V2 endpoints should work synchronously."""

    @patch("httpx.post")
    def test_assess(self, mock_post, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"recommendations": [], "profile": {}}
        mock_post.return_value = mock_resp

        result = client.assess(1, "tree", "samples")
        assert "recommendations" in result

    @patch("httpx.post")
    def test_get_interview(self, mock_post, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"questions": [], "intro": "Hi"}
        mock_post.return_value = mock_resp

        result = client.get_interview(1, "cicd", {}, "standard")
        assert "questions" in result

    @patch("httpx.post")
    def test_build_context(self, mock_post, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"system_prompt": "...", "instructions": "..."}
        mock_post.return_value = mock_resp

        result = client.build_context(1, "cicd", {"q": "a"}, {}, "standard")
        assert "system_prompt" in result

    @patch("httpx.post")
    def test_review_plan(self, mock_post, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"verdict": "pass", "feedback": []}
        mock_post.return_value = mock_resp

        result = client.review_plan(1, "cicd", "plan output", {}, "standard")
        assert result["verdict"] == "pass"

    @patch("httpx.post")
    def test_review_code(self, mock_post, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"combined_verdict": "pass", "reviews": []}
        mock_post.return_value = mock_resp

        result = client.review_code(
            project_id=1, spec="spec", code="diff",
            files_changed=["app.py"],
        )
        assert result["combined_verdict"] == "pass"

    @patch("httpx.post")
    def test_review_spec(self, mock_post, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"severity": "pass", "gaps": []}
        mock_post.return_value = mock_resp

        result = client.review_spec(
            project_id=1, spec="spec",
            project_knowledge="rules", quality_level="high",
        )
        assert result["severity"] == "pass"


# ── Scan retry on timeout ────────────────────────────────────

class TestScanRetry:
    """scan() should retry on timeout, matching MVP behavior."""

    @patch("httpx.post")
    def test_scan_retries_on_timeout(self, mock_post, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"gaps": []}
        mock_post.side_effect = [
            httpx.TimeoutException("timed out"),
            mock_resp,
        ]

        result = client.scan(1, "tree", "samples")
        assert result == {"gaps": []}
        assert mock_post.call_count == 2

    @patch("httpx.post")
    def test_scan_raises_after_max_retries(self, mock_post, client):
        from tlm.client import TLMConnectionError
        mock_post.side_effect = httpx.TimeoutException("timed out")

        with pytest.raises(TLMConnectionError):
            client.scan(1, "tree", "samples")
        assert mock_post.call_count == 3  # 3 attempts
