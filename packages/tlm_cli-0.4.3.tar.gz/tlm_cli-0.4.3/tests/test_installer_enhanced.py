"""Tests for enhanced installer — CLAUDE.md, rules, hooks, git hooks, uninstall."""

import json
import os
import stat
import pytest

from tlm.installer import Installer


SAMPLE_CONFIG = {
    "checks": [
        {"name": "Tests", "command": "pytest tests/ -v", "blocker": True, "category": "testing"},
        {"name": "Lint", "command": "flake8 .", "blocker": False, "category": "linting"},
    ],
    "environments": {
        "staging": {"deploy_command": "deploy staging", "verify_command": "curl staging"},
        "production": {"deploy_command": "deploy prod", "verify_command": "curl prod"},
    },
    "coverage": {"command": "pytest --cov", "min_line_coverage": 70},
}

TLM_START_MARKER = "<!-- TLM:START -->"
TLM_END_MARKER = "<!-- TLM:END -->"


@pytest.fixture
def project_dir(tmp_path):
    """Create a project directory with .tlm/enforcement.json and .git/hooks/."""
    # Create .tlm directory with enforcement config
    tlm_dir = tmp_path / ".tlm"
    tlm_dir.mkdir(parents=True)
    (tlm_dir / "specs").mkdir()
    (tlm_dir / "cache").mkdir()
    enforcement_file = tlm_dir / "enforcement.json"
    enforcement_file.write_text(json.dumps(SAMPLE_CONFIG, indent=2))

    # Create .git/hooks directory for git hook tests
    git_hooks_dir = tmp_path / ".git" / "hooks"
    git_hooks_dir.mkdir(parents=True)

    return tmp_path


class TestInstallClaudeMd:
    def test_generate_claude_md_creates_file_with_tlm_markers(self, project_dir):
        """generate_claude_md() should create CLAUDE.md with TLM start/end markers."""
        installer = Installer(str(project_dir))
        installer.generate_claude_md()

        claude_md = project_dir / "CLAUDE.md"
        assert claude_md.exists(), "CLAUDE.md should be created"
        content = claude_md.read_text()
        assert TLM_START_MARKER in content
        assert TLM_END_MARKER in content

    def test_generate_claude_md_has_tdd_content(self, project_dir):
        """generate_claude_md() should include TDD protocol content."""
        installer = Installer(str(project_dir))
        installer.generate_claude_md()

        content = (project_dir / "CLAUDE.md").read_text()
        assert "TDD" in content

    def test_generate_claude_md_preserves_existing_content(self, project_dir):
        """generate_claude_md() should preserve existing non-TLM content."""
        existing_content = "# My Project\n\nThis is my custom content.\n\n"
        (project_dir / "CLAUDE.md").write_text(existing_content)

        installer = Installer(str(project_dir))
        installer.generate_claude_md()

        content = (project_dir / "CLAUDE.md").read_text()
        assert "# My Project" in content
        assert "This is my custom content." in content
        assert TLM_START_MARKER in content

    def test_generate_claude_md_replaces_existing_tlm_section(self, project_dir):
        """generate_claude_md() should replace an existing TLM section, not duplicate."""
        old_content = (
            "# My Project\n\n"
            f"{TLM_START_MARKER}\nOld TLM content here\n{TLM_END_MARKER}\n\n"
            "# Other stuff\n"
        )
        (project_dir / "CLAUDE.md").write_text(old_content)

        installer = Installer(str(project_dir))
        installer.generate_claude_md()

        content = (project_dir / "CLAUDE.md").read_text()
        assert content.count(TLM_START_MARKER) == 1
        assert content.count(TLM_END_MARKER) == 1
        assert "Old TLM content here" not in content
        assert "# My Project" in content
        assert "# Other stuff" in content

    def test_install_full_does_not_create_claude_md(self, project_dir):
        """install_full() should NOT create CLAUDE.md (handled by rules files instead)."""
        installer = Installer(str(project_dir))
        installer.install_full()

        claude_md = project_dir / "CLAUDE.md"
        assert not claude_md.exists(), "install_full() should not create CLAUDE.md"


class TestInstallRuleFiles:
    def test_install_creates_tdd_rule(self, project_dir):
        """install() should create .claude/rules/tlm-tdd.md."""
        installer = Installer(str(project_dir))
        installer.install_full()

        tdd_rule = project_dir / ".claude" / "rules" / "tlm-tdd.md"
        assert tdd_rule.exists(), ".claude/rules/tlm-tdd.md should be created"
        content = tdd_rule.read_text()
        assert "TDD" in content

    def test_install_creates_deploy_rule_when_envs_exist(self, project_dir):
        """install() should create .claude/rules/tlm-deploy.md when environments configured."""
        installer = Installer(str(project_dir))
        installer.install_full()

        deploy_rule = project_dir / ".claude" / "rules" / "tlm-deploy.md"
        assert deploy_rule.exists(), ".claude/rules/tlm-deploy.md should be created"
        content = deploy_rule.read_text()
        assert "staging" in content
        assert "production" in content


class TestInstallHookScripts:
    def test_install_creates_hooks_directory(self, project_dir):
        """install() should create .claude/hooks/ directory."""
        installer = Installer(str(project_dir))
        installer.install_full()

        hooks_dir = project_dir / ".claude" / "hooks"
        assert hooks_dir.is_dir(), ".claude/hooks/ directory should be created"

    def test_install_creates_hook_wrapper_scripts(self, project_dir):
        """install() should create wrapper scripts in .claude/hooks/."""
        installer = Installer(str(project_dir))
        installer.install_full()

        hooks_dir = project_dir / ".claude" / "hooks"
        # Should have at least one script file in hooks
        hook_files = list(hooks_dir.iterdir()) if hooks_dir.exists() else []
        assert len(hook_files) > 0, "Should create at least one hook wrapper script"


class TestInstallGitHooks:
    def test_install_creates_git_post_commit_hook(self, project_dir):
        """install() should install a git post-commit hook."""
        installer = Installer(str(project_dir))
        installer.install_full()

        post_commit = project_dir / ".git" / "hooks" / "post-commit"
        assert post_commit.exists(), ".git/hooks/post-commit should be created"

    def test_git_hook_is_executable(self, project_dir):
        """The git post-commit hook should be executable."""
        installer = Installer(str(project_dir))
        installer.install_full()

        post_commit = project_dir / ".git" / "hooks" / "post-commit"
        if post_commit.exists():
            mode = post_commit.stat().st_mode
            assert mode & stat.S_IXUSR, "post-commit hook should be user-executable"


class TestUninstallClaudeMd:
    def test_uninstall_removes_tlm_section(self, project_dir):
        """uninstall() should remove TLM section from CLAUDE.md."""
        installer = Installer(str(project_dir))
        # generate_claude_md() is separate from install_full() now
        installer.generate_claude_md()

        content = (project_dir / "CLAUDE.md").read_text()
        assert TLM_START_MARKER in content

        installer.uninstall()

        claude_md = project_dir / "CLAUDE.md"
        if claude_md.exists():
            content = claude_md.read_text()
            assert TLM_START_MARKER not in content
            assert TLM_END_MARKER not in content

    def test_uninstall_keeps_non_tlm_content(self, project_dir):
        """uninstall() should preserve non-TLM content in CLAUDE.md."""
        custom_content = "# My Project\n\nCustom rules here.\n"
        (project_dir / "CLAUDE.md").write_text(custom_content)

        installer = Installer(str(project_dir))
        installer.generate_claude_md()

        content = (project_dir / "CLAUDE.md").read_text()
        assert "# My Project" in content
        assert TLM_START_MARKER in content

        installer.uninstall()

        content = (project_dir / "CLAUDE.md").read_text()
        assert "# My Project" in content
        assert "Custom rules here." in content
        assert TLM_START_MARKER not in content


class TestUninstallHooksAndRules:
    def test_uninstall_removes_hook_scripts(self, project_dir):
        """uninstall() should remove .claude/hooks/ wrapper scripts."""
        installer = Installer(str(project_dir))
        installer.install_full()

        hooks_dir = project_dir / ".claude" / "hooks"
        if hooks_dir.exists():
            assert len(list(hooks_dir.iterdir())) > 0

        installer.uninstall()

        # Hooks directory should be empty or removed
        if hooks_dir.exists():
            tlm_hooks = [f for f in hooks_dir.iterdir() if "tlm" in f.name.lower()]
            assert len(tlm_hooks) == 0, "TLM hook scripts should be removed"

    def test_uninstall_removes_rule_files(self, project_dir):
        """uninstall() should remove TLM rule files from .claude/rules/."""
        installer = Installer(str(project_dir))
        installer.install_full()

        rules_dir = project_dir / ".claude" / "rules"
        assert (rules_dir / "tlm-tdd.md").exists() or (rules_dir / "tlm-deploy.md").exists()

        installer.uninstall()

        assert not (rules_dir / "tlm-tdd.md").exists(), "tlm-tdd.md should be removed"
        assert not (rules_dir / "tlm-deploy.md").exists(), "tlm-deploy.md should be removed"

    def test_uninstall_removes_git_hooks(self, project_dir):
        """uninstall() should remove the git post-commit hook."""
        installer = Installer(str(project_dir))
        installer.install_full()

        post_commit = project_dir / ".git" / "hooks" / "post-commit"
        if post_commit.exists():
            installer.uninstall()
            assert not post_commit.exists(), "post-commit hook should be removed"


class TestUninstallSettingsHooks:
    """Tests for settings.json hook removal during uninstall."""

    def test_uninstall_removes_settings_hooks(self, project_dir):
        """install_full → uninstall → settings.json has no 'hooks' key."""
        installer = Installer(str(project_dir))
        installer.install_full()

        settings_file = project_dir / ".claude" / "settings.json"
        assert settings_file.exists()
        settings = json.loads(settings_file.read_text())
        assert "hooks" in settings

        installer.uninstall()

        settings = json.loads(settings_file.read_text())
        assert "hooks" not in settings

    def test_uninstall_preserves_other_settings(self, project_dir):
        """Non-hook keys in settings.json should survive uninstall."""
        installer = Installer(str(project_dir))
        installer.install_full()

        # Add a non-hook setting
        settings_file = project_dir / ".claude" / "settings.json"
        settings = json.loads(settings_file.read_text())
        settings["permissions"] = {"allow": ["Read", "Glob"]}
        settings["custom_key"] = "preserve_me"
        settings_file.write_text(json.dumps(settings, indent=2))

        installer.uninstall()

        settings = json.loads(settings_file.read_text())
        assert "hooks" not in settings
        assert settings.get("permissions") == {"allow": ["Read", "Glob"]}
        assert settings.get("custom_key") == "preserve_me"

    def test_uninstall_safe_no_hooks_key(self, project_dir):
        """settings.json without hooks key doesn't error on uninstall."""
        settings_dir = project_dir / ".claude"
        settings_dir.mkdir(parents=True, exist_ok=True)
        settings_file = settings_dir / "settings.json"
        settings_file.write_text(json.dumps({"permissions": {"allow": []}}))

        installer = Installer(str(project_dir))
        installer.uninstall()  # Should not raise

    def test_uninstall_safe_no_settings_file(self, tmp_path):
        """No settings.json doesn't error on uninstall."""
        installer = Installer(str(tmp_path))
        installer.uninstall()  # Should not raise

    def test_uninstall_safe_corrupt_settings(self, project_dir):
        """Corrupt settings.json doesn't error on uninstall."""
        settings_dir = project_dir / ".claude"
        settings_dir.mkdir(parents=True, exist_ok=True)
        settings_file = settings_dir / "settings.json"
        settings_file.write_text("not valid json {{{")

        installer = Installer(str(project_dir))
        installer.uninstall()  # Should not raise


class TestUninstallTlmDirectory:
    """Tests for .tlm/ directory removal during uninstall."""

    def test_uninstall_removes_tlm_directory(self, project_dir):
        """.tlm/ should be gone after uninstall."""
        installer = Installer(str(project_dir))
        installer.install_full()

        tlm_dir = project_dir / ".tlm"
        assert tlm_dir.exists()

        installer.uninstall()

        assert not tlm_dir.exists()

    def test_uninstall_removes_enforcement_json(self, project_dir):
        """.tlm/enforcement.json should be gone (part of .tlm/ removal)."""
        enforcement = project_dir / ".tlm" / "enforcement.json"
        assert enforcement.exists()

        installer = Installer(str(project_dir))
        installer.uninstall()

        assert not enforcement.exists()


class TestUninstallSafety:
    def test_uninstall_safe_when_nothing_installed(self, project_dir):
        """uninstall() should not error when nothing is installed."""
        installer = Installer(str(project_dir))
        # Do NOT call install() first
        # uninstall() should complete without raising
        installer.uninstall()

    def test_uninstall_safe_when_no_claude_md(self, tmp_path):
        """uninstall() should not error when CLAUDE.md doesn't exist."""
        # Minimal setup - no .tlm, no CLAUDE.md, no .git
        installer = Installer(str(tmp_path))
        installer.uninstall()

    def test_uninstall_safe_when_no_git_dir(self, tmp_path):
        """uninstall() should not error when .git/ doesn't exist."""
        installer = Installer(str(tmp_path))
        installer.uninstall()
