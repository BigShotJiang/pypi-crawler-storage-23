"""
Tests for gap extraction from profile markdown.

Tests extract_gaps_from_profile() and is_prerequisite_gap() in gaps.py.
Adapted from mvp/tests/test_gaps.py::TestExtractGapsFromProfile.
"""

import pytest


PROFILE_WITH_GAPS = """# Technical Project Profile

## Stack
- **Language(s)**: Python
- **Framework(s)**: FastAPI

## Testing
- **Test Framework**: pytest

## Gaps
- **CI/CD Pipeline**: No GitHub Actions, Jenkins, or other CI configuration detected
- **SSL/TLS Configuration**: No HTTPS/SSL configuration visible
- **Backup Strategy**: No database backup configuration detected
- **Logging Configuration**: No logging setup files detected
- **Rate Limiting**: No rate limiting middleware or configuration detected
- **Documentation**: No README.md in root, API documentation unclear
"""

PROFILE_NO_GAPS = """# Technical Project Profile

## Stack
- **Language(s)**: Python

## Testing
- **Test Framework**: pytest
"""

PROFILE_EMPTY_GAPS = """# Technical Project Profile

## Stack
- Python

## Gaps
"""


class TestExtractGapsFromProfile:
    def test_extracts_all_gaps(self):
        from tlm.gaps import extract_gaps_from_profile
        gaps = extract_gaps_from_profile(PROFILE_WITH_GAPS)
        assert len(gaps) == 6

    def test_gap_has_required_fields(self):
        from tlm.gaps import extract_gaps_from_profile
        gaps = extract_gaps_from_profile(PROFILE_WITH_GAPS)
        for gap in gaps:
            assert "id" in gap
            assert "category" in gap
            assert "description" in gap
            assert "severity" in gap
            assert "dismissed" in gap

    def test_dismissed_defaults_false(self):
        from tlm.gaps import extract_gaps_from_profile
        gaps = extract_gaps_from_profile(PROFILE_WITH_GAPS)
        for gap in gaps:
            assert gap["dismissed"] is False

    def test_high_severity_for_security(self):
        from tlm.gaps import extract_gaps_from_profile
        gaps = extract_gaps_from_profile(PROFILE_WITH_GAPS)
        ssl_gap = next(g for g in gaps if "SSL" in g["category"])
        assert ssl_gap["severity"] == "high"

    def test_high_severity_for_cicd(self):
        from tlm.gaps import extract_gaps_from_profile
        gaps = extract_gaps_from_profile(PROFILE_WITH_GAPS)
        cicd_gap = next(g for g in gaps if "CI/CD" in g["category"])
        assert cicd_gap["severity"] == "high"

    def test_high_severity_for_backup(self):
        from tlm.gaps import extract_gaps_from_profile
        gaps = extract_gaps_from_profile(PROFILE_WITH_GAPS)
        backup_gap = next(g for g in gaps if "Backup" in g["category"])
        assert backup_gap["severity"] == "high"

    def test_medium_severity_for_logging(self):
        from tlm.gaps import extract_gaps_from_profile
        gaps = extract_gaps_from_profile(PROFILE_WITH_GAPS)
        log_gap = next(g for g in gaps if "Logging" in g["category"])
        assert log_gap["severity"] == "medium"

    def test_medium_severity_for_rate_limiting(self):
        from tlm.gaps import extract_gaps_from_profile
        gaps = extract_gaps_from_profile(PROFILE_WITH_GAPS)
        rl_gap = next(g for g in gaps if "Rate Limiting" in g["category"])
        assert rl_gap["severity"] == "medium"

    def test_low_severity_for_documentation(self):
        from tlm.gaps import extract_gaps_from_profile
        gaps = extract_gaps_from_profile(PROFILE_WITH_GAPS)
        doc_gap = next(g for g in gaps if "Documentation" in g["category"])
        assert doc_gap["severity"] == "low"

    def test_stable_ids(self):
        from tlm.gaps import extract_gaps_from_profile
        gaps = extract_gaps_from_profile(PROFILE_WITH_GAPS)
        ids = [g["id"] for g in gaps]
        assert "no-ci-cd-pipeline" in ids
        assert "no-ssl-tls-configuration" in ids

    def test_no_gaps_section_returns_empty(self):
        from tlm.gaps import extract_gaps_from_profile
        gaps = extract_gaps_from_profile(PROFILE_NO_GAPS)
        assert gaps == []

    def test_empty_gaps_section_returns_empty(self):
        from tlm.gaps import extract_gaps_from_profile
        gaps = extract_gaps_from_profile(PROFILE_EMPTY_GAPS)
        assert gaps == []

    def test_empty_string_returns_empty(self):
        from tlm.gaps import extract_gaps_from_profile
        gaps = extract_gaps_from_profile("")
        assert gaps == []

    def test_description_matches_profile(self):
        from tlm.gaps import extract_gaps_from_profile
        gaps = extract_gaps_from_profile(PROFILE_WITH_GAPS)
        cicd_gap = next(g for g in gaps if "CI/CD" in g["category"])
        assert "No GitHub Actions" in cicd_gap["description"]


class TestIsPrerequisiteGap:
    def test_test_environment_is_prerequisite(self):
        from tlm.gaps import is_prerequisite_gap
        assert is_prerequisite_gap({"id": "no-test-environment"}) is True

    def test_testing_is_prerequisite(self):
        from tlm.gaps import is_prerequisite_gap
        assert is_prerequisite_gap({"id": "no-testing"}) is True

    def test_test_framework_is_prerequisite(self):
        from tlm.gaps import is_prerequisite_gap
        assert is_prerequisite_gap({"id": "no-test-framework"}) is True

    def test_environment_promotion_is_prerequisite(self):
        from tlm.gaps import is_prerequisite_gap
        assert is_prerequisite_gap({"id": "no-environment-promotion"}) is True

    def test_environments_is_prerequisite(self):
        from tlm.gaps import is_prerequisite_gap
        assert is_prerequisite_gap({"id": "no-environments"}) is True

    def test_cicd_not_prerequisite(self):
        from tlm.gaps import is_prerequisite_gap
        assert is_prerequisite_gap({"id": "no-ci-cd-pipeline"}) is False

    def test_logging_not_prerequisite(self):
        from tlm.gaps import is_prerequisite_gap
        assert is_prerequisite_gap({"id": "no-logging-configuration"}) is False

    def test_keyword_match_in_id(self):
        from tlm.gaps import is_prerequisite_gap
        assert is_prerequisite_gap({"id": "no-proper-test-environment-setup"}) is True

    def test_empty_id(self):
        from tlm.gaps import is_prerequisite_gap
        assert is_prerequisite_gap({"id": ""}) is False
        assert is_prerequisite_gap({}) is False
