"""Tests for hooks — 7 hook handlers with server-backed intelligence."""

import json
import time
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

from tlm.hooks import (
    hook_session_start,
    hook_prompt_submit,
    hook_guard,
    hook_compliance_gate,
    hook_deployment_gate,
    hook_plan_approved,
    hook_stop,
    _find_latest_plan,
    _is_likely_source_code,
    _tlm_block,
    _tlm_caution,
    _tlm_ok,
)
from tlm.state import write_state, read_state
from tlm.config import save_project_config
from tlm.gaps import add_gap, GapStatus


@pytest.fixture
def tlm_project(tmp_path):
    """Create a project with TLM initialized."""
    tlm_dir = tmp_path / ".tlm"
    tlm_dir.mkdir()
    (tlm_dir / "specs").mkdir()
    (tlm_dir / "cache").mkdir()
    write_state(str(tmp_path), {"phase": "idle"})
    save_project_config(str(tmp_path), {
        "quality_control": "standard",
        "project_id": "proj_1",
    })
    return tmp_path


class TestHookSessionStart:
    def test_returns_context_when_tlm_exists(self, tlm_project):
        """Session start should return context when .tlm/ exists."""
        result = hook_session_start(str(tlm_project))
        assert isinstance(result, str)
        assert "TLM" in result

    def test_returns_install_message_when_no_tlm(self, tmp_path):
        """Should tell user to run tlm install when .tlm/ missing."""
        result = hook_session_start(str(tmp_path))
        assert "install" in result.lower()

    def test_includes_phase_info(self, tlm_project):
        """Session start should show current phase."""
        result = hook_session_start(str(tlm_project))
        assert "idle" in result.lower()

    def test_includes_quality_level(self, tlm_project):
        """Session start should show quality level."""
        result = hook_session_start(str(tlm_project))
        assert "standard" in result.lower()

    def test_includes_active_gaps(self, tlm_project):
        """Session start should show active gaps."""
        add_gap(str(tlm_project), {
            "id": "cicd", "type": "cicd", "category": "CI/CD",
            "severity": "critical", "description": "No CI/CD pipeline",
        })

        result = hook_session_start(str(tlm_project))
        assert "gap" in result.lower() or "CI/CD" in result


class TestHookSessionStartEnforcement:
    def test_high_quality_shows_blocked_rules(self, tlm_project):
        """Session start with HIGH should show BLOCKED enforcement rules."""
        save_project_config(str(tlm_project), {"quality_control": "high"})
        result = hook_session_start(str(tlm_project))
        assert "BLOCKED" in result

    def test_standard_quality_shows_warned_rules(self, tlm_project):
        """Session start with STANDARD should show WARNED rules."""
        result = hook_session_start(str(tlm_project))
        assert "WARNED" in result

    def test_relaxed_quality_shows_advisory(self, tlm_project):
        """Session start with RELAXED should show advisory mode."""
        save_project_config(str(tlm_project), {"quality_control": "relaxed"})
        result = hook_session_start(str(tlm_project))
        assert "advisory" in result.lower() or "Advisory" in result


class TestHookSessionStartBold:
    def test_has_visual_banner(self, tlm_project):
        result = hook_session_start(str(tlm_project))
        assert "\u2501" in result

    def test_shows_active_label(self, tlm_project):
        result = hook_session_start(str(tlm_project))
        assert "ACTIVE" in result

    def test_high_shows_red_blocked(self, tlm_project):
        save_project_config(str(tlm_project), {"quality_control": "high"})
        result = hook_session_start(str(tlm_project))
        assert "BLOCKED" in result
        assert "\033[31m" in result  # Red ANSI

    def test_standard_shows_yellow_warned(self, tlm_project):
        result = hook_session_start(str(tlm_project))
        assert "WARNED" in result or "ENFORCED" in result

    def test_relaxed_shows_advisory(self, tlm_project):
        save_project_config(str(tlm_project), {"quality_control": "relaxed"})
        result = hook_session_start(str(tlm_project))
        assert "Advisory" in result or "advisory" in result


class TestHookPromptSubmit:
    def test_idle_phase_returns_classify_context(self, tlm_project):
        """In idle phase, should tell Claude to classify the request."""
        result = hook_prompt_submit(str(tlm_project), "Add auth")
        assert "additionalContext" in result
        assert "classify" in result["additionalContext"].lower()

    def test_tlm_active_returns_interview_context(self, tlm_project):
        """In tlm_active phase, should remind Claude of interview mode."""
        write_state(str(tlm_project), {"phase": "tlm_active", "activity_type": "feature"})

        result = hook_prompt_submit(str(tlm_project), "What about OAuth?")
        assert "additionalContext" in result
        assert "interview" in result["additionalContext"].lower()

    def test_implementation_returns_tdd_context(self, tlm_project):
        """In implementation phase, should remind Claude of TDD."""
        write_state(str(tlm_project), {"phase": "implementation"})

        result = hook_prompt_submit(str(tlm_project), "Let me code this")
        assert "additionalContext" in result
        assert "TDD" in result["additionalContext"] or "test" in result["additionalContext"].lower()

    def test_idle_high_returns_enforcement_context(self, tlm_project):
        """In idle+HIGH, should tell Claude writes are BLOCKED."""
        save_project_config(str(tlm_project), {"quality_control": "high"})
        result = hook_prompt_submit(str(tlm_project), "Add auth")
        assert "BLOCKED" in result.get("additionalContext", "")

    def test_idle_relaxed_returns_no_context(self, tlm_project):
        """In idle+RELAXED, should not inject idle context."""
        save_project_config(str(tlm_project), {"quality_control": "relaxed"})
        result = hook_prompt_submit(str(tlm_project), "Add auth")
        ctx = result.get("additionalContext", "")
        # Should not contain any classify/interview instructions
        assert "classify" not in ctx.lower()

    def test_gap_warning_when_prompt_matches_gap(self, tlm_project):
        """Should warn when user mentions something related to an active gap."""
        add_gap(str(tlm_project), {
            "id": "auth", "type": "auth", "category": "Security",
            "severity": "critical", "description": "No authentication implemented",
        })

        result = hook_prompt_submit(str(tlm_project), "auth isn't working")
        assert "additionalContext" in result
        # Should mention the gap
        ctx = result["additionalContext"]
        assert "auth" in ctx.lower() or "gap" in ctx.lower()


class TestHookGuard:
    def test_idle_relaxed_allows_writes(self, tlm_project):
        """In idle+relaxed phase, writes should be allowed."""
        save_project_config(str(tlm_project), {"quality_control": "relaxed"})
        result = hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(tlm_project / "app.py")},
        })
        assert result.get("decision") != "block"

    def test_tlm_active_blocks_source_writes(self, tlm_project):
        """In tlm_active phase, source code writes should be blocked."""
        write_state(str(tlm_project), {"phase": "tlm_active", "activity_type": "feature"})

        result = hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(tlm_project / "app.py")},
        })
        assert result.get("decision") == "block"

    def test_tlm_active_allows_test_writes(self, tlm_project):
        """In tlm_active phase, test file writes should be allowed."""
        write_state(str(tlm_project), {"phase": "tlm_active", "activity_type": "feature"})

        result = hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(tlm_project / "tests" / "test_app.py")},
        })
        assert result.get("decision") != "block"

    def test_tlm_active_allows_tlm_file_writes(self, tlm_project):
        """In tlm_active phase, .tlm/ file writes should be allowed."""
        write_state(str(tlm_project), {"phase": "tlm_active", "activity_type": "feature"})

        result = hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(tlm_project / ".tlm" / "specs" / "auth.md")},
        })
        assert result.get("decision") != "block"

    def test_implementation_blocks_without_tests(self, tlm_project):
        """In implementation phase, source writes should block if no tests written."""
        write_state(str(tlm_project), {
            "phase": "implementation",
            "spec_review_status": "approved",
        })

        result = hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(tlm_project / "app.py")},
        })
        assert result.get("decision") == "block"
        assert "test" in result.get("reason", "").lower()

    def test_implementation_allows_after_test_write(self, tlm_project):
        """In implementation phase, source writes allowed after writing tests."""
        write_state(str(tlm_project), {
            "phase": "implementation",
            "spec_review_status": "approved",
        })

        # First write a test file
        hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(tlm_project / "tests" / "test_app.py")},
        })

        # Now source write should be allowed
        result = hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(tlm_project / "app.py")},
        })
        assert result.get("decision") != "block"

    def test_non_write_tools_pass_through(self, tlm_project):
        """Non-Write/Edit tools should pass through."""
        result = hook_guard(str(tlm_project), {
            "tool_name": "Read",
            "tool_input": {"file_path": str(tlm_project / "app.py")},
        })
        assert result == {}

    def test_idle_high_blocks_source_writes(self, tlm_project):
        """In idle+HIGH, source code writes should be blocked."""
        save_project_config(str(tlm_project), {"quality_control": "high"})
        result = hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(tlm_project / "app.py")},
        })
        assert result.get("decision") == "block"

    def test_idle_high_auto_transitions_to_tlm_active(self, tlm_project):
        """In idle+HIGH, blocking a source write should auto-transition to tlm_active."""
        save_project_config(str(tlm_project), {"quality_control": "high"})
        hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(tlm_project / "app.py")},
        })
        state = read_state(str(tlm_project))
        assert state["phase"] == "tlm_active"

    def test_idle_high_allows_config_files(self, tlm_project):
        """In idle+HIGH, config/doc files should NOT be blocked."""
        save_project_config(str(tlm_project), {"quality_control": "high"})
        for f in ["config.json", "docker-compose.yml", "README.md"]:
            result = hook_guard(str(tlm_project), {
                "tool_name": "Write",
                "tool_input": {"file_path": str(tlm_project / f)},
            })
            assert result.get("decision") != "block", f"Should not block {f}"

    def test_idle_high_allows_test_files(self, tlm_project):
        """In idle+HIGH, test files should NOT be blocked."""
        save_project_config(str(tlm_project), {"quality_control": "high"})
        result = hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(tlm_project / "tests" / "test_app.py")},
        })
        assert result.get("decision") != "block"

    def test_idle_standard_warns_not_blocks(self, tlm_project):
        """In idle+STANDARD, source writes should warn (additionalContext) not block."""
        result = hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(tlm_project / "app.py")},
        })
        assert result.get("decision") != "block"
        assert "additionalContext" in result

    def test_idle_relaxed_allows_all(self, tlm_project):
        """In idle+RELAXED, source writes should be fully allowed."""
        save_project_config(str(tlm_project), {"quality_control": "relaxed"})
        result = hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(tlm_project / "app.py")},
        })
        assert result.get("decision") != "block"

    def test_gap_warning_on_related_file(self, tlm_project):
        """Writing to a file related to a known gap should warn (relaxed quality)."""
        save_project_config(str(tlm_project), {"quality_control": "relaxed"})
        add_gap(str(tlm_project), {
            "id": "auth", "type": "auth", "category": "Security",
            "severity": "critical", "description": "No authentication",
        })

        result = hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(tlm_project / "auth.py")},
        })
        # Should contain a warning about the gap (not a block in relaxed)
        ctx = result.get("additionalContext", "")
        assert "auth" in ctx.lower() or "gap" in ctx.lower() or result == {}


class TestHookGuardOutOfTree:
    """hook_guard should allow writes to files outside the project root."""

    def test_out_of_tree_write_allowed_in_tlm_active(self, tlm_project):
        """Writing ~/.claude/plans/my-plan.md during tlm_active should NOT be blocked."""
        write_state(str(tlm_project), {"phase": "tlm_active", "activity_type": "feature"})
        result = hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/home/user/.claude/plans/my-plan.md"},
        })
        assert result.get("decision") != "block"

    def test_out_of_tree_write_allowed_in_idle_high(self, tlm_project):
        """Writing /tmp/notes.txt during idle+HIGH should NOT be blocked."""
        save_project_config(str(tlm_project), {"quality_control": "high"})
        result = hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/tmp/notes.txt"},
        })
        assert result.get("decision") != "block"

    def test_in_tree_write_still_blocked_in_tlm_active(self, tlm_project):
        """Writing <project>/app.py during tlm_active should still be blocked."""
        write_state(str(tlm_project), {"phase": "tlm_active", "activity_type": "feature"})
        result = hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(tlm_project / "app.py")},
        })
        assert result.get("decision") == "block"


class TestHookComplianceGate:
    def test_non_commit_passes_through(self, tlm_project):
        """Non-git-commit commands should pass through."""
        result = hook_compliance_gate(str(tlm_project), {
            "command": "python -m pytest tests/",
        })
        assert result.get("decision") != "block"

    def test_git_commit_gets_context(self, tlm_project):
        """git commit should get compliance context."""
        result = hook_compliance_gate(str(tlm_project), {
            "command": "git commit -m 'test'",
        })
        # Should return context or block (depending on quality level)
        assert "additionalContext" in result or "decision" in result


class TestHookDeploymentGate:
    def test_non_deploy_passes_through(self, tlm_project):
        """Non-deployment commands should pass through."""
        result = hook_deployment_gate(str(tlm_project), {
            "command": "python app.py",
        })
        assert result == {}

    def test_firebase_deploy_blocked(self, tlm_project):
        """firebase deploy should be blocked."""
        result = hook_deployment_gate(str(tlm_project), {
            "command": "firebase deploy",
        })
        assert result.get("decision") == "block"

    def test_docker_push_blocked(self, tlm_project):
        """docker push should be blocked."""
        result = hook_deployment_gate(str(tlm_project), {
            "command": "docker push myapp:latest",
        })
        assert result.get("decision") == "block"

    def test_git_push_prod_blocked(self, tlm_project):
        """git push to production should be blocked."""
        result = hook_deployment_gate(str(tlm_project), {
            "command": "git push origin production",
        })
        assert result.get("decision") == "block"


class TestHookPlanApproved:
    """hook_plan_approved — PostToolUse hook for ExitPlanMode."""

    def test_no_plan_files_returns_caution(self, tlm_project, tmp_path):
        """No plan file in plans dir should return yellow caution."""
        plans_dir = tmp_path / "empty_plans"
        plans_dir.mkdir()
        result = hook_plan_approved(str(tlm_project), {}, plans_dir=plans_dir)
        assert "additionalContext" in result
        assert "NO PLAN FOUND" in result["additionalContext"]

    def test_finds_most_recent_plan_file(self, tmp_path):
        """Should pick the newest .md file in the plans directory."""
        plans_dir = tmp_path / "plans"
        plans_dir.mkdir()
        (plans_dir / "old.md").write_text("old plan")
        time.sleep(0.05)
        (plans_dir / "new.md").write_text("new plan")

        result = _find_latest_plan(plans_dir)
        assert result is not None
        assert result.name == "new.md"

    def test_review_pass_transitions_to_implementation(self, tlm_project, tmp_path):
        """Review pass should transition to implementation phase."""
        plans_dir = tmp_path / "plans"
        plans_dir.mkdir()
        plan_file = plans_dir / "feature.md"
        plan_file.write_text("# Feature Plan\n\nDetails here.")

        with patch("tlm.hooks._run_spec_review") as mock:
            mock.return_value = {"severity": "pass", "gaps": []}
            result = hook_plan_approved(str(tlm_project), {}, plans_dir=plans_dir)

        state = read_state(str(tlm_project))
        assert state["phase"] == "implementation"
        assert state["spec_review_status"] == "approved"
        assert state["active_spec"] == str(plan_file)
        assert "PLAN APPROVED" in result.get("additionalContext", "")

    def test_review_fail_sets_plan_review_pending(self, tlm_project, tmp_path):
        """Review fail should set plan_review_pending and stay in tlm_active."""
        plans_dir = tmp_path / "plans"
        plans_dir.mkdir()
        (plans_dir / "feature.md").write_text("# Bad Plan")

        with patch("tlm.hooks._run_spec_review") as mock:
            mock.return_value = {"severity": "fail", "gaps": [{"description": "Missing auth", "severity": "high"}]}
            result = hook_plan_approved(str(tlm_project), {}, plans_dir=plans_dir)

        state = read_state(str(tlm_project))
        assert state["phase"] == "tlm_active"
        assert state.get("plan_review_pending") is True
        assert state["spec_review_status"] == "rejected"
        assert "PLAN NEEDS WORK" in result.get("additionalContext", "")
        assert "Accept Risks" in result.get("additionalContext", "")

    def test_relaxed_auto_approves(self, tlm_project, tmp_path):
        """Relaxed quality should auto-approve without server call."""
        save_project_config(str(tlm_project), {"quality_control": "relaxed"})
        plans_dir = tmp_path / "plans"
        plans_dir.mkdir()
        (plans_dir / "feature.md").write_text("# Plan")

        with patch("tlm.hooks._run_spec_review") as mock:
            result = hook_plan_approved(str(tlm_project), {}, plans_dir=plans_dir)
            mock.assert_not_called()

        state = read_state(str(tlm_project))
        assert state["phase"] == "implementation"
        assert "AUTO-APPROVED" in result.get("additionalContext", "")

    def test_server_unavailable_degrades(self, tlm_project, tmp_path):
        """Server error should approve with warning (graceful degradation)."""
        plans_dir = tmp_path / "plans"
        plans_dir.mkdir()
        (plans_dir / "feature.md").write_text("# Plan")

        with patch("tlm.hooks._run_spec_review") as mock:
            mock.return_value = {"error": "Connection refused"}
            result = hook_plan_approved(str(tlm_project), {}, plans_dir=plans_dir)

        state = read_state(str(tlm_project))
        assert state["phase"] == "implementation"
        assert "REVIEW UNAVAILABLE" in result.get("additionalContext", "")

    def test_active_spec_points_to_original_plan(self, tlm_project, tmp_path):
        """active_spec should point to original plan path, NOT a .tlm/specs/ copy."""
        plans_dir = tmp_path / "plans"
        plans_dir.mkdir()
        plan_file = plans_dir / "feature.md"
        plan_file.write_text("# Plan")

        with patch("tlm.hooks._run_spec_review") as mock:
            mock.return_value = {"severity": "pass", "gaps": []}
            hook_plan_approved(str(tlm_project), {}, plans_dir=plans_dir)

        state = read_state(str(tlm_project))
        assert state["active_spec"] == str(plan_file)
        assert ".tlm/specs/" not in state["active_spec"]


class TestHookPromptSubmitAcceptRisks:
    """Accept risks flow in hook_prompt_submit."""

    def test_accept_risks_transitions_to_implementation(self, tlm_project):
        """plan_review_pending=True + 'accept risks' should transition to implementation."""
        write_state(str(tlm_project), {
            "phase": "tlm_active",
            "plan_review_pending": True,
            "spec_review_status": "rejected",
        })
        result = hook_prompt_submit(str(tlm_project), "accept risks and continue")
        state = read_state(str(tlm_project))
        assert state["phase"] == "implementation"
        assert state["spec_review_status"] == "approved"
        assert state.get("plan_review_pending") is False
        assert "RISKS ACCEPTED" in result.get("additionalContext", "")

    def test_accept_risks_case_insensitive(self, tlm_project):
        """'Accept Risks' (capitalized) should also work."""
        write_state(str(tlm_project), {
            "phase": "tlm_active",
            "plan_review_pending": True,
        })
        result = hook_prompt_submit(str(tlm_project), "Accept Risks and continue without fixes")
        state = read_state(str(tlm_project))
        assert state["phase"] == "implementation"

    def test_no_false_positive_without_flag(self, tlm_project):
        """'accept risks' without plan_review_pending flag should NOT transition."""
        write_state(str(tlm_project), {"phase": "tlm_active", "activity_type": "feature"})
        result = hook_prompt_submit(str(tlm_project), "accept risks")
        state = read_state(str(tlm_project))
        assert state["phase"] == "tlm_active"  # unchanged


class TestHookStop:
    def test_returns_empty_when_no_tlm(self, tmp_path):
        """Should return empty when .tlm/ doesn't exist."""
        result = hook_stop(str(tmp_path))
        assert result == {}

    def test_returns_dict(self, tlm_project):
        """Should return a dict."""
        result = hook_stop(str(tlm_project))
        assert isinstance(result, dict)

    def test_resets_tlm_active_to_idle(self, tlm_project):
        """hook_stop should reset tlm_active phase back to idle."""
        write_state(str(tlm_project), {"phase": "tlm_active"})
        hook_stop(str(tlm_project))
        assert read_state(str(tlm_project))["phase"] == "idle"

    def test_does_not_reset_implementation(self, tlm_project):
        """hook_stop should NOT reset implementation phase."""
        write_state(str(tlm_project), {"phase": "implementation"})
        hook_stop(str(tlm_project))
        assert read_state(str(tlm_project))["phase"] == "implementation"

    def test_clears_plan_review_pending(self, tlm_project):
        """hook_stop should remove plan_review_pending from state."""
        write_state(str(tlm_project), {
            "phase": "tlm_active",
            "plan_review_pending": True,
        })
        hook_stop(str(tlm_project))
        state = read_state(str(tlm_project))
        assert "plan_review_pending" not in state


class TestIsLikelySourceCode:
    def test_python_is_source(self):
        assert _is_likely_source_code("/project/app.py") is True

    def test_javascript_is_source(self):
        assert _is_likely_source_code("/project/index.js") is True

    def test_typescript_is_source(self):
        assert _is_likely_source_code("/project/app.ts") is True

    def test_go_is_source(self):
        assert _is_likely_source_code("/project/main.go") is True

    def test_json_is_not_source(self):
        assert _is_likely_source_code("/project/config.json") is False

    def test_markdown_is_not_source(self):
        assert _is_likely_source_code("/project/README.md") is False

    def test_no_extension_is_not_source(self):
        assert _is_likely_source_code("/project/Makefile") is False

    def test_txt_is_not_source(self):
        assert _is_likely_source_code("/project/requirements.txt") is False

    def test_yaml_is_not_source(self):
        assert _is_likely_source_code("/project/docker-compose.yml") is False

    def test_toml_is_not_source(self):
        assert _is_likely_source_code("/project/pyproject.toml") is False


class TestTlmMessageHelpers:
    def test_block_returns_decision_block(self):
        result = _tlm_block("TEST", "detail")
        assert result["decision"] == "block"
        assert "TEST" in result["reason"]
        assert "\u25a0" in result["reason"]

    def test_caution_returns_additional_context(self):
        result = _tlm_caution("TEST", "detail")
        assert "additionalContext" in result
        assert "decision" not in result
        assert "\u25b2 TLM" in result["additionalContext"]
        assert "Display this TLM status" in result["additionalContext"]

    def test_ok_returns_additional_context(self):
        result = _tlm_ok("TEST", "detail")
        assert "additionalContext" in result
        assert "\u2713 TLM" in result["additionalContext"]
        assert "Display this TLM status" in result["additionalContext"]

    def test_block_has_ansi_red(self):
        result = _tlm_block("X", "Y")
        assert "\033[31m" in result["reason"]

    def test_caution_has_markdown_block(self):
        result = _tlm_caution("WARN", "info")
        assert "```" in result["additionalContext"]

    def test_ok_has_markdown_block(self):
        result = _tlm_ok("GOOD", "info")
        assert "```" in result["additionalContext"]
