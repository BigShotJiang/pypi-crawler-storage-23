"""
Tests for drift.py — Hash-based config file change detection.

Adapted from mvp/tests/test_engine_api.py::TestDriftDetectorAPI.
DriftDetector uses direct file paths (no Project class).
"""

import json
from unittest.mock import MagicMock
from pathlib import Path

import pytest


SAMPLE_CONFIG = {
    "project_summary": "Python FastAPI app",
    "environments": {
        "staging": {"description": "Staging"},
        "production": {"description": "Production"},
    },
    "checks": [
        {"name": "Tests", "command": "pytest", "blocker": True, "when": "pre_commit"},
    ],
    "drift_files": ["requirements.txt"],
}


@pytest.fixture
def project_dir(tmp_path):
    """Set up a .tlm/ directory with approved enforcement config."""
    tlm = tmp_path / ".tlm"
    tlm.mkdir()
    return tmp_path


@pytest.fixture
def mock_client():
    return MagicMock()


class TestDriftDetectorNoDrift:
    def test_no_drift_returns_clean_result(self, project_dir, mock_client):
        from tlm.drift import DriftDetector
        from tlm.enforcer import EnforcementConfig

        # Set up approved config without drift files
        ec = EnforcementConfig(str(project_dir / ".tlm"))
        config_no_drift = {**SAMPLE_CONFIG, "drift_files": []}
        ec.save(config_no_drift)
        ec.approve()

        detector = DriftDetector(str(project_dir), mock_client, "proj_123")
        result = detector.check()

        assert result["drifted"] is False
        assert result["stale"] is False
        assert result["changed_files"] == []
        mock_client.check_drift.assert_not_called()

    def test_no_drift_when_files_unchanged(self, project_dir, mock_client):
        from tlm.drift import DriftDetector
        from tlm.enforcer import EnforcementConfig

        # Create drift file BEFORE approval
        req_file = project_dir / "requirements.txt"
        req_file.write_text("flask==3.0")

        ec = EnforcementConfig(str(project_dir / ".tlm"))
        ec.save(SAMPLE_CONFIG)
        ec.approve()  # Snapshots hash of requirements.txt

        detector = DriftDetector(str(project_dir), mock_client, "proj_123")
        result = detector.check()

        assert result["drifted"] is False
        mock_client.check_drift.assert_not_called()


class TestDriftDetectorWithDrift:
    def test_drift_detected_calls_api(self, project_dir, mock_client):
        from tlm.drift import DriftDetector
        from tlm.enforcer import EnforcementConfig

        ec = EnforcementConfig(str(project_dir / ".tlm"))
        ec.save(SAMPLE_CONFIG)
        ec.approve()

        # Create drift file AFTER approval
        req_file = project_dir / "requirements.txt"
        req_file.write_text("flask==3.0")

        mock_client.check_drift.return_value = {
            "stale": False,
            "reason": "Minor dependency update",
            "affected_sections": [],
        }

        detector = DriftDetector(str(project_dir), mock_client, "proj_123")
        result = detector.check()

        assert result["drifted"] is True
        assert "requirements.txt" in result["changed_files"]
        mock_client.check_drift.assert_called_once()

    def test_drift_returns_api_stale_flag(self, project_dir, mock_client):
        from tlm.drift import DriftDetector
        from tlm.enforcer import EnforcementConfig

        ec = EnforcementConfig(str(project_dir / ".tlm"))
        ec.save(SAMPLE_CONFIG)
        ec.approve()

        # Trigger drift
        (project_dir / "requirements.txt").write_text("django==5.0")

        mock_client.check_drift.return_value = {
            "stale": True,
            "reason": "Major framework change",
            "affected_sections": ["checks", "environments"],
        }

        detector = DriftDetector(str(project_dir), mock_client, "proj_123")
        result = detector.check()

        assert result["stale"] is True
        assert result["reason"] == "Major framework change"
        assert "checks" in result["affected_sections"]

    def test_drift_passes_file_contents_to_api(self, project_dir, mock_client):
        from tlm.drift import DriftDetector
        from tlm.enforcer import EnforcementConfig

        ec = EnforcementConfig(str(project_dir / ".tlm"))
        ec.save(SAMPLE_CONFIG)
        ec.approve()

        (project_dir / "requirements.txt").write_text("newpackage==1.0")

        mock_client.check_drift.return_value = {
            "stale": False,
            "reason": "Minor",
            "affected_sections": [],
        }

        detector = DriftDetector(str(project_dir), mock_client, "proj_123")
        detector.check()

        # Verify file contents were passed to API
        call_args = mock_client.check_drift.call_args
        file_contents = call_args[0][3]  # 4th positional arg
        assert "newpackage==1.0" in file_contents.get("requirements.txt", "")

    def test_drift_deleted_file_marked(self, project_dir, mock_client):
        from tlm.drift import DriftDetector
        from tlm.enforcer import EnforcementConfig

        # Create file, approve, then delete
        (project_dir / "requirements.txt").write_text("flask==3.0")
        ec = EnforcementConfig(str(project_dir / ".tlm"))
        ec.save(SAMPLE_CONFIG)
        ec.approve()
        (project_dir / "requirements.txt").unlink()

        mock_client.check_drift.return_value = {
            "stale": True,
            "reason": "File deleted",
            "affected_sections": [],
        }

        detector = DriftDetector(str(project_dir), mock_client, "proj_123")
        result = detector.check()

        assert result["drifted"] is True
        # File contents should show "(deleted)"
        call_args = mock_client.check_drift.call_args
        file_contents = call_args[0][3]
        assert file_contents.get("requirements.txt") == "(deleted)"


class TestDriftDetectorNoConfig:
    def test_no_approved_config_returns_clean(self, project_dir, mock_client):
        from tlm.drift import DriftDetector

        detector = DriftDetector(str(project_dir), mock_client, "proj_123")
        result = detector.check()

        assert result["drifted"] is False
        assert result["stale"] is False
