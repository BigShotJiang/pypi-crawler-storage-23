"""Tests for interviewer — Q&A presentation and answer collection."""

import pytest
from unittest.mock import patch
from io import StringIO

from tlm.interviewer import Interviewer


SAMPLE_QUESTIONS = [
    {
        "id": "deploy_target",
        "question": "Where will this application be deployed?",
        "options": ["AWS", "GCP", "Heroku", "VPS"],
        "default": "Heroku",
        "context": "Determines CI/CD config",
    },
    {
        "id": "ci_tool",
        "question": "Which CI/CD tool?",
        "options": ["GitHub Actions", "GitLab CI", "CircleCI"],
        "default": "GitHub Actions",
        "context": "Most common for OSS",
    },
]


class TestInterviewer:
    def test_interviewer_creates_with_questions(self):
        """Interviewer should accept questions list."""
        iv = Interviewer(SAMPLE_QUESTIONS)
        assert len(iv.questions) == 2

    @patch("tlm.interviewer._read_line", side_effect=["1", "2"])
    def test_interviewer_collects_answers(self, mock_input):
        """Interviewer should collect answers for each question."""
        iv = Interviewer(SAMPLE_QUESTIONS)
        answers = iv.run()
        assert "deploy_target" in answers
        assert "ci_tool" in answers

    @patch("tlm.interviewer._read_line", side_effect=["", ""])
    def test_interviewer_uses_defaults_on_empty(self, mock_input):
        """Empty input should use default value."""
        iv = Interviewer(SAMPLE_QUESTIONS)
        answers = iv.run()
        assert answers["deploy_target"] == "Heroku"
        assert answers["ci_tool"] == "GitHub Actions"

    @patch("tlm.interviewer._read_line", side_effect=["3", "1"])
    def test_interviewer_selects_by_number(self, mock_input):
        """Numeric input selects from options list."""
        iv = Interviewer(SAMPLE_QUESTIONS)
        answers = iv.run()
        assert answers["deploy_target"] == "Heroku"  # option 3
        assert answers["ci_tool"] == "GitHub Actions"  # option 1

    @patch("tlm.interviewer._read_line", side_effect=["custom answer", ""])
    def test_interviewer_accepts_freeform(self, mock_input):
        """Non-numeric input should be accepted as freeform answer."""
        iv = Interviewer(SAMPLE_QUESTIONS)
        answers = iv.run()
        assert answers["deploy_target"] == "custom answer"

    def test_interviewer_handles_empty_questions(self):
        """Interviewer should handle empty questions list."""
        iv = Interviewer([])
        answers = iv.run()
        assert answers == {}
