"""Tests for config — credential persistence + project config."""

import json
import os
import pytest

from tlm.config import (
    get_server_url,
    get_api_key,
    save_credentials,
    load_credentials,
    save_project_config,
    load_project_config,
    DEFAULT_SERVER_URL,
    CREDENTIALS_PATH,
)


class TestCredentials:
    def test_save_and_load_credentials(self, tmp_path, monkeypatch):
        """Credentials should persist to ~/.tlm/credentials.json."""
        cred_path = tmp_path / ".tlm" / "credentials.json"
        monkeypatch.setattr("tlm.config.CREDENTIALS_PATH", str(cred_path))

        save_credentials("http://example.com:8003", "my-api-key-123")

        creds = load_credentials()
        assert creds["server_url"] == "http://example.com:8003"
        assert creds["api_key"] == "my-api-key-123"

    def test_load_credentials_returns_empty_when_missing(self, tmp_path, monkeypatch):
        """Missing credentials file should return empty dict."""
        cred_path = tmp_path / ".tlm" / "credentials.json"
        monkeypatch.setattr("tlm.config.CREDENTIALS_PATH", str(cred_path))

        creds = load_credentials()
        assert creds == {}

    def test_credentials_file_has_restricted_permissions(self, tmp_path, monkeypatch):
        """Credentials file should be chmod 600."""
        cred_path = tmp_path / ".tlm" / "credentials.json"
        monkeypatch.setattr("tlm.config.CREDENTIALS_PATH", str(cred_path))

        save_credentials("http://example.com", "key")

        mode = oct(os.stat(str(cred_path)).st_mode)[-3:]
        assert mode == "600"

    def test_get_api_key_from_credentials(self, tmp_path, monkeypatch):
        """get_api_key() should read from credentials file."""
        cred_path = tmp_path / ".tlm" / "credentials.json"
        monkeypatch.setattr("tlm.config.CREDENTIALS_PATH", str(cred_path))
        monkeypatch.delenv("TLM_API_KEY", raising=False)

        save_credentials("http://example.com", "cred-key")
        assert get_api_key() == "cred-key"

    def test_get_api_key_env_overrides_credentials(self, tmp_path, monkeypatch):
        """TLM_API_KEY env var should override credentials file."""
        cred_path = tmp_path / ".tlm" / "credentials.json"
        monkeypatch.setattr("tlm.config.CREDENTIALS_PATH", str(cred_path))
        monkeypatch.setenv("TLM_API_KEY", "env-key")

        save_credentials("http://example.com", "cred-key")
        assert get_api_key() == "env-key"

    def test_get_server_url_from_credentials(self, tmp_path, monkeypatch):
        """get_server_url() should read from credentials file."""
        cred_path = tmp_path / ".tlm" / "credentials.json"
        monkeypatch.setattr("tlm.config.CREDENTIALS_PATH", str(cred_path))
        monkeypatch.delenv("TLM_SERVER_URL", raising=False)

        save_credentials("http://myserver:9000", "key")
        assert get_server_url() == "http://myserver:9000"

    def test_get_server_url_env_overrides_credentials(self, tmp_path, monkeypatch):
        """TLM_SERVER_URL env var should override credentials file."""
        cred_path = tmp_path / ".tlm" / "credentials.json"
        monkeypatch.setattr("tlm.config.CREDENTIALS_PATH", str(cred_path))
        monkeypatch.setenv("TLM_SERVER_URL", "http://env-server:8000")

        save_credentials("http://cred-server:9000", "key")
        assert get_server_url() == "http://env-server:8000"

    def test_get_server_url_default(self, tmp_path, monkeypatch):
        """get_server_url() should return default when nothing configured."""
        cred_path = tmp_path / ".tlm" / "credentials.json"
        monkeypatch.setattr("tlm.config.CREDENTIALS_PATH", str(cred_path))
        monkeypatch.delenv("TLM_SERVER_URL", raising=False)

        assert get_server_url() == DEFAULT_SERVER_URL


class TestDefaultServerUrl:
    def test_default_server_url_is_production(self):
        """DEFAULT_SERVER_URL should point to production API."""
        assert DEFAULT_SERVER_URL == "https://api.tlmforge.dev"


class TestProjectConfig:
    def test_save_and_load_project_config(self, tmp_path):
        """Project config should persist to .tlm/config.json."""
        save_project_config(str(tmp_path), {
            "quality_control": "high",
            "project_id": "proj_123",
        })

        config = load_project_config(str(tmp_path))
        assert config["quality_control"] == "high"
        assert config["project_id"] == "proj_123"

    def test_load_project_config_returns_empty_when_missing(self, tmp_path):
        """Missing config should return empty dict."""
        config = load_project_config(str(tmp_path))
        assert config == {}

    def test_save_project_config_creates_tlm_dir(self, tmp_path):
        """save_project_config should create .tlm/ if missing."""
        save_project_config(str(tmp_path), {"quality_control": "standard"})
        assert (tmp_path / ".tlm" / "config.json").exists()

    def test_save_project_config_merges(self, tmp_path):
        """Saving config should merge with existing values."""
        save_project_config(str(tmp_path), {"quality_control": "high"})
        save_project_config(str(tmp_path), {"project_id": "proj_456"})

        config = load_project_config(str(tmp_path))
        assert config["quality_control"] == "high"
        assert config["project_id"] == "proj_456"
