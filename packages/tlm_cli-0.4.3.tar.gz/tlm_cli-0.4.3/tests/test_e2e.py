"""E2E tests — full flow: auth → install → scan → gaps → hooks intercept."""

import json
import pytest
from unittest.mock import patch, MagicMock, AsyncMock
from click.testing import CliRunner
from pathlib import Path

from tlm.cli import main
from tlm.gaps import load_gaps, get_active_gaps, add_gap, update_gap_status, GapStatus
from tlm.state import read_state, write_state
from tlm.config import save_project_config, load_project_config
from tlm.hooks import (
    hook_session_start,
    hook_prompt_submit,
    hook_guard,
    hook_compliance_gate,
    hook_deployment_gate,
    hook_plan_approved,
    hook_spec_review,
    hook_stop,
)


MOCK_ASSESS = {
    "recommendations": [
        {"id": "cicd", "type": "cicd", "category": "CI/CD",
         "severity": "critical", "description": "No CI/CD pipeline detected", "fixable": True},
        {"id": "testing", "type": "testing", "category": "Testing",
         "severity": "critical", "description": "No tests found", "fixable": True},
        {"id": "staging", "type": "staging", "category": "Infrastructure",
         "severity": "high", "description": "No staging environment", "fixable": True},
        {"id": "monitoring", "type": "monitoring", "category": "Ops",
         "severity": "medium", "description": "No monitoring setup", "fixable": True},
    ],
    "profile": {"stack": "Python Flask", "has_ci": False},
}


class TestFullInstallFlow:
    @patch("tlm.cli.ConfigGenerator")
    @patch("tlm.cli.Installer")
    def test_install_creates_full_project_structure(self, mock_installer_cls, mock_cg_cls, tmp_path):
        """Full install flow should: scan → config gen → approve → quality → gaps → install_full."""
        mock_installer = MagicMock()
        mock_installer.scan_project.return_value = {"file_tree": "app.py", "samples": "code"}
        mock_installer.ensure_project.return_value = 42
        mock_installer.assess.return_value = MOCK_ASSESS
        mock_installer_cls.return_value = mock_installer

        mock_config_gen = MagicMock()
        mock_config_gen.generate.return_value = {
            "checks": [{"name": "tests", "command": "pytest", "blocker": True}],
            "environments": {},
            "coverage": {},
        }
        mock_cg_cls.return_value = mock_config_gen

        runner = CliRunner()
        # Input: approve config + accept high quality
        result = runner.invoke(main, ["install", "--path", str(tmp_path)], input="a\n\n")

        assert result.exit_code == 0
        mock_installer.init_project_dir.assert_called_once()
        mock_installer.scan_project.assert_called_once()
        mock_installer.assess.assert_called_once()
        mock_config_gen.generate.assert_called_once()
        mock_config_gen.save_approved.assert_called_once()
        mock_installer.save_quality_tier.assert_called_once_with("high")
        mock_installer.populate_gaps.assert_called_once()
        mock_installer.install_full.assert_called_once()


class TestGapLifecycleE2E:
    def test_gap_detect_defer_resolve(self, tmp_path):
        """Gaps should flow: detected → deferred → re-detected next session."""
        # Install creates gaps
        (tmp_path / ".tlm").mkdir(parents=True)
        add_gap(str(tmp_path), {
            "id": "cicd", "type": "cicd", "category": "CI/CD",
            "severity": "critical", "description": "No CI/CD",
        })
        add_gap(str(tmp_path), {
            "id": "testing", "type": "testing", "category": "Testing",
            "severity": "critical", "description": "No tests",
        })

        # User defers one
        update_gap_status(str(tmp_path), "cicd", GapStatus.DEFERRED)

        active = get_active_gaps(str(tmp_path))
        assert len(active) == 2  # Deferred is still active (warns next session)
        assert any(g["id"] == "cicd" and g["status"] == "deferred" for g in active)

        # User resolves one
        update_gap_status(str(tmp_path), "testing", GapStatus.RESOLVED)

        active = get_active_gaps(str(tmp_path))
        assert len(active) == 1
        assert active[0]["id"] == "cicd"

    def test_gap_dismiss_suppresses_permanently(self, tmp_path):
        """Dismissed gaps should be permanently suppressed."""
        (tmp_path / ".tlm").mkdir(parents=True)
        add_gap(str(tmp_path), {
            "id": "monitoring", "type": "monitoring", "category": "Ops",
            "severity": "medium", "description": "No monitoring",
        })

        update_gap_status(str(tmp_path), "monitoring", GapStatus.DISMISSED,
                         reason="Not needed for MVP")

        active = get_active_gaps(str(tmp_path))
        assert len(active) == 0


class TestHookInterceptionE2E:
    def test_session_start_shows_gaps_after_install(self, tmp_path):
        """Session start after install should show detected gaps."""
        (tmp_path / ".tlm").mkdir(parents=True)
        (tmp_path / ".tlm" / "specs").mkdir()
        (tmp_path / ".tlm" / "cache").mkdir()
        write_state(str(tmp_path), {"phase": "idle"})
        save_project_config(str(tmp_path), {"quality_control": "high"})
        add_gap(str(tmp_path), {
            "id": "cicd", "type": "cicd", "category": "CI/CD",
            "severity": "critical", "description": "No CI/CD pipeline",
        })

        result = hook_session_start(str(tmp_path))
        assert "TLM" in result
        assert "gap" in result.lower() or "CI/CD" in result

    def test_interview_blocks_source_writes(self, tmp_path):
        """During interview phase, source code writes should be blocked."""
        (tmp_path / ".tlm").mkdir(parents=True)
        write_state(str(tmp_path), {"phase": "tlm_active", "activity_type": "feature"})

        result = hook_guard(str(tmp_path), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(tmp_path / "app.py")},
        })
        assert result["decision"] == "block"

        # But test files pass
        result = hook_guard(str(tmp_path), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(tmp_path / "tests" / "test_app.py")},
        })
        assert result.get("decision") != "block"

    def test_tdd_enforcement_during_implementation(self, tmp_path):
        """Implementation phase should enforce TDD: tests before source."""
        (tmp_path / ".tlm").mkdir(parents=True)
        (tmp_path / ".tlm" / "cache").mkdir()
        write_state(str(tmp_path), {
            "phase": "implementation",
            "spec_review_status": "approved",
        })

        # Try writing source first → blocked
        result = hook_guard(str(tmp_path), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(tmp_path / "app.py")},
        })
        assert result["decision"] == "block"
        assert "test" in result["reason"].lower()

        # Write test first
        hook_guard(str(tmp_path), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(tmp_path / "tests" / "test_app.py")},
        })

        # Now source write should pass
        result = hook_guard(str(tmp_path), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(tmp_path / "app.py")},
        })
        assert result.get("decision") != "block"

    def test_deployment_always_blocked(self, tmp_path):
        """Deploy commands should always be blocked."""
        (tmp_path / ".tlm").mkdir(parents=True)
        write_state(str(tmp_path), {"phase": "idle"})

        for cmd in ["firebase deploy", "docker push myapp", "git push origin production"]:
            result = hook_deployment_gate(str(tmp_path), {"command": cmd})
            assert result.get("decision") == "block", f"Expected block for: {cmd}"

    def test_prompt_warns_about_matching_gap(self, tmp_path):
        """Prompt mentioning a gap keyword should get a warning."""
        (tmp_path / ".tlm").mkdir(parents=True)
        write_state(str(tmp_path), {"phase": "idle"})
        add_gap(str(tmp_path), {
            "id": "auth", "type": "auth", "category": "Security",
            "severity": "critical", "description": "No authentication system",
        })

        result = hook_prompt_submit(str(tmp_path), "the auth is broken")
        ctx = result.get("additionalContext", "")
        assert "auth" in ctx.lower() or "gap" in ctx.lower()


class TestQualityTierEffects:
    def test_high_quality_shows_in_session_start(self, tmp_path):
        """High quality should be visible in session context."""
        (tmp_path / ".tlm").mkdir(parents=True)
        write_state(str(tmp_path), {"phase": "idle"})
        save_project_config(str(tmp_path), {"quality_control": "high"})

        result = hook_session_start(str(tmp_path))
        assert "high" in result.lower()

    def test_quality_persists_across_reads(self, tmp_path):
        """Quality tier should persist across config reads."""
        (tmp_path / ".tlm").mkdir(parents=True)
        save_project_config(str(tmp_path), {"quality_control": "relaxed"})

        config = load_project_config(str(tmp_path))
        assert config["quality_control"] == "relaxed"


class TestScanWithoutProjectId:
    @patch("tlm.cli.Installer")
    def test_scan_no_project_id_needed(self, mock_installer_cls, tmp_path):
        """Scan should work without --project-id (V2 doesn't need it from user)."""
        mock_installer = MagicMock()
        mock_installer.scan_project.return_value = {"file_tree": "app.py", "samples": "code"}
        mock_installer.assess.return_value = {
            "recommendations": [
                {"id": "cicd", "type": "cicd", "category": "CI/CD",
                 "severity": "critical", "description": "No CI/CD", "fixable": True},
            ],
            "profile": {"stack": "Python"},
        }
        mock_installer_cls.return_value = mock_installer

        runner = CliRunner()
        result = runner.invoke(main, ["scan", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "CI/CD" in result.output or "cicd" in result.output


class TestIdleEnforcementE2E:
    """Full flow: idle → blocked → tlm_active → spec approved → implementation → TDD."""

    def _setup_project(self, tmp_path, quality="high"):
        """Create a project with TLM initialized at given quality."""
        (tmp_path / ".tlm").mkdir(parents=True)
        (tmp_path / ".tlm" / "specs").mkdir()
        (tmp_path / ".tlm" / "cache").mkdir()
        write_state(str(tmp_path), {"phase": "idle"})
        save_project_config(str(tmp_path), {"quality_control": quality})
        return tmp_path

    def test_high_quality_full_flow(self, tmp_path):
        """idle → blocked → tlm_active → spec approved → implementation → TDD enforced."""
        proj = self._setup_project(tmp_path, "high")

        # Step 1: Source write in idle+HIGH → BLOCKED, auto-transitions to tlm_active
        result = hook_guard(str(proj), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(proj / "app.py")},
        })
        assert result.get("decision") == "block", "Step 1: Should block source write in idle+HIGH"
        state = read_state(str(proj))
        assert state["phase"] == "tlm_active", "Step 1: Should auto-transition to tlm_active"

        # Step 1b: Git commit also blocked in tlm_active
        commit_result = hook_compliance_gate(str(proj), {"command": "git commit -m 'wip'"})
        assert commit_result.get("decision") == "block", "Step 1b: Should block commit in tlm_active"

        # Step 2: Source write in tlm_active → still BLOCKED
        result = hook_guard(str(proj), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(proj / "app.py")},
        })
        assert result.get("decision") == "block", "Step 2: Should still block in tlm_active"

        # Step 3: .tlm/ write in tlm_active → allowed (spec writing)
        spec_path = str(proj / ".tlm" / "specs" / "feature.md")
        result = hook_guard(str(proj), {
            "tool_name": "Write",
            "tool_input": {"file_path": spec_path},
        })
        assert result.get("decision") != "block", "Step 3: Should allow .tlm/ writes"

        # Step 4: Simulate spec approval → state → implementation
        (Path(spec_path)).write_text("# Feature Spec\n\nImplement the feature.")
        with patch("tlm.hooks._run_spec_review") as mock_review:
            mock_review.return_value = {"severity": "pass", "gaps": [], "follow_up_questions": []}
            hook_spec_review(str(proj), {
                "tool_name": "Write",
                "tool_input": {"file_path": spec_path},
            })
        state = read_state(str(proj))
        assert state["phase"] == "implementation", "Step 4: Should transition to implementation"
        assert state["spec_review_status"] == "approved", "Step 4: Spec should be approved"

        # Step 5: Source write without tests → BLOCKED (TDD enforcement)
        result = hook_guard(str(proj), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(proj / "app.py")},
        })
        assert result.get("decision") == "block", "Step 5: Should block source without tests (TDD)"
        assert "test" in result.get("reason", "").lower(), "Step 5: Should mention tests"

        # Step 6: Write test → allowed
        result = hook_guard(str(proj), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(proj / "tests" / "test_app.py")},
        })
        assert result.get("decision") != "block", "Step 6: Should allow test writes"

        # Step 7: Source write after test → allowed
        result = hook_guard(str(proj), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(proj / "app.py")},
        })
        assert result.get("decision") != "block", "Step 7: Should allow source after test"

    def test_standard_quality_warns_but_allows(self, tmp_path):
        """Standard quality: warns on source writes but doesn't block."""
        proj = self._setup_project(tmp_path, "standard")

        result = hook_guard(str(proj), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(proj / "app.py")},
        })
        assert result.get("decision") != "block", "Standard should not block"
        assert "additionalContext" in result, "Standard should warn"

    def test_deploy_blocked_throughout_flow(self, tmp_path):
        """Deploy commands should be blocked at any phase via compliance gate."""
        proj = self._setup_project(tmp_path, "high")

        for phase in ["idle", "tlm_active", "implementation"]:
            write_state(str(proj), {"phase": phase})
            result = hook_compliance_gate(str(proj), {"command": "firebase deploy"})
            assert result.get("decision") == "block", f"Deploy should be blocked in {phase}"

    def test_hook_stop_resets_abandoned_interview(self, tmp_path):
        """hook_stop should reset tlm_active back to idle for next session."""
        proj = self._setup_project(tmp_path, "high")

        # Simulate: source write blocks and transitions to tlm_active
        hook_guard(str(proj), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(proj / "app.py")},
        })
        assert read_state(str(proj))["phase"] == "tlm_active"

        # Session ends without completing interview
        hook_stop(str(proj))
        assert read_state(str(proj))["phase"] == "idle"

    def test_plan_approval_transitions_to_implementation(self, tmp_path):
        """Approved plan should transition from idle to implementation."""
        proj = self._setup_project(tmp_path, "high")
        plans_dir = tmp_path / "plans"
        plans_dir.mkdir()
        plan_file = plans_dir / "test.md"
        plan_file.write_text("# Feature Plan\n\nDetails here.")

        with patch("tlm.hooks._run_spec_review") as mock:
            mock.return_value = {"severity": "pass", "gaps": []}
            result = hook_plan_approved(str(proj), {}, plans_dir=plans_dir)

        state = read_state(str(proj))
        assert state["phase"] == "implementation"
        assert state["active_spec"] == str(plans_dir / "test.md")  # points to original

    def test_out_of_tree_writes_not_blocked(self, tmp_path):
        """Files outside project root (like plan files) should never be blocked."""
        proj = self._setup_project(tmp_path, "high")

        # Auto-transition to tlm_active first
        hook_guard(str(proj), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(proj / "app.py")},
        })
        assert read_state(str(proj))["phase"] == "tlm_active"

        # Write to a file outside the project should NOT be blocked
        result = hook_guard(str(proj), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/home/user/.claude/plans/my-plan.md"},
        })
        assert result.get("decision") != "block"
