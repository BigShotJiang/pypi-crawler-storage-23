"""Tests for tlm.knowledge_db -- KnowledgeDB SQLite knowledge store."""

import json

import pytest

from tlm.knowledge_db import KnowledgeDB


@pytest.fixture
def db(tmp_path):
    """Create a KnowledgeDB rooted in tmp_path."""
    kdb = KnowledgeDB(str(tmp_path))
    kdb.init_db()
    yield kdb
    kdb.close()


# --- Initialization ---

class TestInitDB:
    def test_init_db_creates_tables(self, tmp_path):
        kdb = KnowledgeDB(str(tmp_path))
        kdb.init_db()
        # Verify the four tables exist
        rows = kdb.conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
        ).fetchall()
        table_names = sorted([r["name"] for r in rows])
        assert "rules" in table_names
        assert "specs" in table_names
        assert "commits" in table_names
        assert "metrics" in table_names
        kdb.close()


# --- Rules ---

class TestRules:
    def test_add_rule_and_list_rules(self, db):
        rule_id = db.add_rule("Always use type hints", source="base", tags=["python"])
        assert rule_id >= 1

        rules = db.list_rules()
        assert len(rules) == 1
        assert rules[0]["rule_text"] == "Always use type hints"
        assert rules[0]["source"] == "base"
        assert rules[0]["relevance_tags"] == ["python"]

    def test_disable_rule_and_enable_rule_toggle(self, db):
        rule_id = db.add_rule("Use TDD", source="base")
        assert len(db.list_rules()) == 1

        db.disable_rule(rule_id)
        # Disabled rules excluded by default
        assert len(db.list_rules()) == 0

        db.enable_rule(rule_id)
        assert len(db.list_rules()) == 1

    def test_list_rules_excludes_disabled_by_default(self, db):
        id1 = db.add_rule("Rule 1")
        id2 = db.add_rule("Rule 2")
        db.disable_rule(id1)

        active = db.list_rules(include_disabled=False)
        assert len(active) == 1
        assert active[0]["rule_text"] == "Rule 2"

        all_rules = db.list_rules(include_disabled=True)
        assert len(all_rules) == 2

    def test_get_rule_by_id(self, db):
        rule_id = db.add_rule("Specific rule", source="learned", tags=["api"])
        rule = db.get_rule(rule_id)
        assert rule is not None
        assert rule["rule_text"] == "Specific rule"
        assert rule["source"] == "learned"
        assert rule["relevance_tags"] == ["api"]

    def test_get_rule_returns_none_for_missing(self, db):
        assert db.get_rule(9999) is None

    def test_search_rules_by_tags_finds_matching(self, db):
        db.add_rule("Rule about APIs", tags=["api", "rest"])
        db.add_rule("Rule about databases", tags=["database", "sql"])
        db.add_rule("Rule about testing", tags=["testing"])

        results = db.search_rules_by_tags(["api"])
        assert len(results) == 1
        assert results[0]["rule_text"] == "Rule about APIs"

    def test_search_rules_by_tags_case_insensitive(self, db):
        db.add_rule("Rule with tags", tags=["Python", "API"])
        results = db.search_rules_by_tags(["python"])
        assert len(results) == 1

    def test_search_rules_by_tags_returns_empty_on_no_match(self, db):
        db.add_rule("Rule", tags=["unrelated"])
        results = db.search_rules_by_tags(["nonexistent"])
        assert len(results) == 0


# --- Specs ---

class TestSpecs:
    def test_add_spec_and_list_specs(self, db):
        spec_id = db.add_spec(
            feature_name="Auth Feature",
            spec_content="## Auth\nImplement JWT auth.",
            review_result={"approved": True},
        )
        assert spec_id >= 1

        specs = db.list_specs()
        assert len(specs) == 1
        assert specs[0]["feature_name"] == "Auth Feature"
        assert specs[0]["spec_content"] == "## Auth\nImplement JWT auth."
        assert specs[0]["review_result"] == {"approved": True}

    def test_list_specs_ordered_desc(self, db):
        db.add_spec("First", "content1")
        db.add_spec("Second", "content2")
        specs = db.list_specs()
        assert specs[0]["feature_name"] == "Second"
        assert specs[1]["feature_name"] == "First"


# --- Commits ---

class TestCommits:
    def test_add_commit_and_list_commits(self, db):
        commit_id = db.add_commit(
            hash="abc123",
            category="feature",
            patterns_extracted=["use_factory_pattern"],
        )
        assert commit_id >= 1

        commits = db.list_commits()
        assert len(commits) == 1
        assert commits[0]["hash"] == "abc123"
        assert commits[0]["category"] == "feature"
        assert commits[0]["patterns_extracted"] == ["use_factory_pattern"]

    def test_add_duplicate_commit_ignored(self, db):
        db.add_commit(hash="abc123", category="feature")
        db.add_commit(hash="abc123", category="bugfix")  # duplicate hash

        commits = db.list_commits()
        assert len(commits) == 1
        # First insert wins (INSERT OR IGNORE)
        assert commits[0]["category"] == "feature"


# --- Metrics ---

class TestMetrics:
    def test_add_metric_and_list_metrics(self, db):
        metric_id = db.add_metric(
            week_number="2025-W20",
            spec_accuracy=85.0,
            total_commits=10,
            planned_commits=8,
            unplanned_commits=2,
            bugs_caught_by_review=3,
        )
        assert metric_id >= 1

        metrics = db.list_metrics()
        assert len(metrics) == 1
        assert metrics[0]["week_number"] == "2025-W20"
        assert metrics[0]["spec_accuracy"] == 85.0
        assert metrics[0]["total_commits"] == 10
        assert metrics[0]["planned_commits"] == 8
        assert metrics[0]["unplanned_commits"] == 2
        assert metrics[0]["bugs_caught_by_review"] == 3


# --- Migration ---

class TestMigration:
    def test_migrate_from_flat_files(self, tmp_path):
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        # knowledge.md
        knowledge_file = tlm_dir / "knowledge.md"
        knowledge_file.write_text(
            "# Knowledge\n\n"
            "- Always run tests before deploying\n"
            "- Use type hints in all Python code\n"
            "---\n"
            "Short\n"  # too short, should be skipped (<=10 chars)
        )

        # specs dir
        specs_dir = tlm_dir / "specs"
        specs_dir.mkdir()
        (specs_dir / "auth.md").write_text("# Auth Feature\nImplement JWT auth.\n")

        # commits dir
        commits_dir = tlm_dir / "commits"
        commits_dir.mkdir()
        (commits_dir / "abc123.json").write_text(json.dumps({
            "hash": "abc123",
            "category": "feature",
            "lessons": ["Use factory pattern"],
        }))

        # lessons dir (synthesis files)
        lessons_dir = tlm_dir / "lessons"
        lessons_dir.mkdir()
        (lessons_dir / "2025-01-15-synthesis.json").write_text(json.dumps({
            "period": "2025-W03",
            "spec_accuracy_percent": 80,
            "total_commits": 5,
            "planned_commits": 4,
            "unplanned_commits": 1,
            "interview_improvements": ["Ask about error handling early"],
        }))

        kdb = KnowledgeDB(str(tlm_dir))
        kdb.init_db()
        imported = kdb.migrate_from_flat_files()

        # Should import 2 rules from knowledge.md + 1 from interview_improvements
        assert imported["rules"] >= 3
        assert imported["specs"] == 1
        assert imported["commits"] == 1
        assert imported["metrics"] == 1

        # Verify data in DB
        rules = kdb.list_rules()
        rule_texts = [r["rule_text"] for r in rules]
        assert "Always run tests before deploying" in rule_texts
        assert "Use type hints in all Python code" in rule_texts

        specs = kdb.list_specs()
        assert len(specs) == 1
        assert specs[0]["feature_name"] == "Auth Feature"

        commits = kdb.list_commits()
        assert len(commits) == 1
        assert commits[0]["hash"] == "abc123"

        metrics = kdb.list_metrics()
        assert len(metrics) == 1
        assert metrics[0]["week_number"] == "2025-W03"

        kdb.close()
