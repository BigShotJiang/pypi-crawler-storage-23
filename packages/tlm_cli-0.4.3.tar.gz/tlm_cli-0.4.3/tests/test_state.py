"""Tests for state management — .tlm/state.json read/write."""

import json
import pytest

from tlm.state import read_state, write_state, set_phase


class TestState:
    def test_read_state_returns_defaults_when_missing(self, tmp_path):
        """Missing state.json should return default idle state."""
        state = read_state(str(tmp_path))
        assert state["phase"] == "idle"
        assert state["activity_type"] is None
        assert state["active_spec"] is None

    def test_write_and_read_state(self, tmp_path):
        """State should persist to .tlm/state.json."""
        write_state(str(tmp_path), {
            "phase": "tlm_active",
            "activity_type": "feature",
            "active_spec": ".tlm/specs/auth.md",
        })

        state = read_state(str(tmp_path))
        assert state["phase"] == "tlm_active"
        assert state["activity_type"] == "feature"
        assert state["active_spec"] == ".tlm/specs/auth.md"

    def test_set_phase(self, tmp_path):
        """set_phase() should update phase and preserve other fields."""
        write_state(str(tmp_path), {
            "phase": "tlm_active",
            "activity_type": "feature",
        })

        set_phase(str(tmp_path), "implementation")

        state = read_state(str(tmp_path))
        assert state["phase"] == "implementation"
        assert state["activity_type"] == "feature"

    def test_write_state_creates_tlm_dir(self, tmp_path):
        """write_state should create .tlm/ if missing."""
        write_state(str(tmp_path), {"phase": "idle"})
        assert (tmp_path / ".tlm" / "state.json").exists()

    def test_state_includes_last_updated(self, tmp_path):
        """State should include last_updated timestamp."""
        write_state(str(tmp_path), {"phase": "implementation"})
        state = read_state(str(tmp_path))
        assert "last_updated" in state
        assert state["last_updated"] is not None
