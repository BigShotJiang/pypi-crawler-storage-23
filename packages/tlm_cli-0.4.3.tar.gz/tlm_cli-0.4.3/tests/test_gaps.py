"""Tests for gap lifecycle — detect, fix, defer, dismiss, re-detect."""

import json
import pytest

from tlm.gaps import (
    load_gaps,
    save_gaps,
    add_gap,
    update_gap_status,
    get_active_gaps,
    get_gap_by_id,
    GapStatus,
)


class TestGapStorage:
    def test_load_gaps_returns_empty_when_missing(self, tmp_path):
        """Missing gaps.json should return empty list."""
        gaps = load_gaps(str(tmp_path))
        assert gaps == []

    def test_save_and_load_gaps(self, tmp_path):
        """Gaps should persist to .tlm/gaps.json."""
        gaps = [
            {
                "id": "cicd",
                "type": "cicd",
                "category": "CI/CD",
                "severity": "critical",
                "description": "No CI/CD pipeline detected",
                "status": "detected",
                "dismiss_reason": None,
                "detected_at": "2026-02-20",
                "resolved_at": None,
            }
        ]
        save_gaps(str(tmp_path), gaps)

        loaded = load_gaps(str(tmp_path))
        assert len(loaded) == 1
        assert loaded[0]["id"] == "cicd"
        assert loaded[0]["status"] == "detected"


class TestGapLifecycle:
    def test_add_gap(self, tmp_path):
        """add_gap() should append a new gap."""
        add_gap(str(tmp_path), {
            "id": "testing",
            "type": "testing",
            "category": "Testing",
            "severity": "critical",
            "description": "No tests detected",
        })

        gaps = load_gaps(str(tmp_path))
        assert len(gaps) == 1
        assert gaps[0]["id"] == "testing"
        assert gaps[0]["status"] == "detected"
        assert gaps[0]["detected_at"] is not None

    def test_add_multiple_gaps(self, tmp_path):
        """Multiple gaps should accumulate."""
        add_gap(str(tmp_path), {"id": "cicd", "type": "cicd", "category": "CI/CD",
                                 "severity": "critical", "description": "No CI/CD"})
        add_gap(str(tmp_path), {"id": "testing", "type": "testing", "category": "Testing",
                                 "severity": "critical", "description": "No tests"})

        gaps = load_gaps(str(tmp_path))
        assert len(gaps) == 2

    def test_add_gap_deduplicates_by_id(self, tmp_path):
        """Adding a gap with existing ID should not duplicate."""
        add_gap(str(tmp_path), {"id": "cicd", "type": "cicd", "category": "CI/CD",
                                 "severity": "critical", "description": "No CI/CD"})
        add_gap(str(tmp_path), {"id": "cicd", "type": "cicd", "category": "CI/CD",
                                 "severity": "critical", "description": "No CI/CD (updated)"})

        gaps = load_gaps(str(tmp_path))
        assert len(gaps) == 1

    def test_update_gap_to_fixing(self, tmp_path):
        """Gap should transition detected → fixing."""
        add_gap(str(tmp_path), {"id": "cicd", "type": "cicd", "category": "CI/CD",
                                 "severity": "critical", "description": "No CI/CD"})

        update_gap_status(str(tmp_path), "cicd", GapStatus.FIXING)

        gap = get_gap_by_id(str(tmp_path), "cicd")
        assert gap["status"] == "fixing"

    def test_update_gap_to_resolved(self, tmp_path):
        """Gap should transition fixing → resolved."""
        add_gap(str(tmp_path), {"id": "cicd", "type": "cicd", "category": "CI/CD",
                                 "severity": "critical", "description": "No CI/CD"})
        update_gap_status(str(tmp_path), "cicd", GapStatus.FIXING)
        update_gap_status(str(tmp_path), "cicd", GapStatus.RESOLVED)

        gap = get_gap_by_id(str(tmp_path), "cicd")
        assert gap["status"] == "resolved"
        assert gap["resolved_at"] is not None

    def test_update_gap_to_deferred(self, tmp_path):
        """Gap should transition detected → deferred."""
        add_gap(str(tmp_path), {"id": "cicd", "type": "cicd", "category": "CI/CD",
                                 "severity": "critical", "description": "No CI/CD"})
        update_gap_status(str(tmp_path), "cicd", GapStatus.DEFERRED)

        gap = get_gap_by_id(str(tmp_path), "cicd")
        assert gap["status"] == "deferred"

    def test_update_gap_to_dismissed(self, tmp_path):
        """Gap should transition detected → dismissed with reason."""
        add_gap(str(tmp_path), {"id": "cicd", "type": "cicd", "category": "CI/CD",
                                 "severity": "critical", "description": "No CI/CD"})
        update_gap_status(str(tmp_path), "cicd", GapStatus.DISMISSED, reason="Not needed for MVP")

        gap = get_gap_by_id(str(tmp_path), "cicd")
        assert gap["status"] == "dismissed"
        assert gap["dismiss_reason"] == "Not needed for MVP"

    def test_get_active_gaps(self, tmp_path):
        """get_active_gaps() should exclude resolved and dismissed."""
        add_gap(str(tmp_path), {"id": "cicd", "type": "cicd", "category": "CI/CD",
                                 "severity": "critical", "description": "No CI/CD"})
        add_gap(str(tmp_path), {"id": "testing", "type": "testing", "category": "Testing",
                                 "severity": "critical", "description": "No tests"})
        add_gap(str(tmp_path), {"id": "monitoring", "type": "monitoring", "category": "Ops",
                                 "severity": "medium", "description": "No monitoring"})

        update_gap_status(str(tmp_path), "cicd", GapStatus.RESOLVED)
        update_gap_status(str(tmp_path), "monitoring", GapStatus.DISMISSED)

        active = get_active_gaps(str(tmp_path))
        assert len(active) == 1
        assert active[0]["id"] == "testing"

    def test_get_gap_by_id_not_found(self, tmp_path):
        """get_gap_by_id() should return None for unknown ID."""
        gap = get_gap_by_id(str(tmp_path), "nonexistent")
        assert gap is None
