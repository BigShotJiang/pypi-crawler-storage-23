"""Runtime helpers for minidic."""
