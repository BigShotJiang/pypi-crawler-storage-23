from . import program1, program2, program3, program4
from . import program5, program6, program7, program8
from . import program9, program10, program11, program12


def main():

    print("\n==============================")
    print("      JACK88 LAB MENU")
    print("==============================")

    print("1  - Lab Program 1")
    print("2  - Lab Program 2")
    print("3  - Lab Program 3")
    print("4  - Lab Program 4")
    print("5  - Lab Program 5")
    print("6  - Lab Program 6")
    print("7  - Lab Program 7")
    print("8  - Lab Program 8")
    print("9  - Lab Program 9")
    print("10 - Lab Program 10")
    print("11 - Lab Program 11")
    print("12 - Lab Program 12")

    choice = int(input("\nEnter your choice: "))

    if choice == 1:
        program1.run()

    elif choice == 2:
        program2.run()

    elif choice == 3:
        program3.run()

    elif choice == 4:
        program4.run()

    elif choice == 5:
        program5.run()

    elif choice == 6:
        program6.run()

    elif choice == 7:
        program7.run()

    elif choice == 8:
        program8.run()

    elif choice == 9:
        program9.run()

    elif choice == 10:
        program10.run()

    elif choice == 11:
        program11.run()

    elif choice == 12:
        program12.run()

    else:
        print("Invalid choice")