def run():
    print("Lab Program 1")
    print("Hello World")