from __future__ import annotations

from hacxgent.cli.textual_ui.handlers.event_handler import EventHandler

__all__ = ["EventHandler"]
