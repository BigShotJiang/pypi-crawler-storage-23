from __future__ import annotations

from pathlib import Path

HACXGENT_ROOT = Path(__file__).parent
__version__ = "1.0.0"
