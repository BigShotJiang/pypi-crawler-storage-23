from __future__ import annotations

__all__ = ["run_programmatic"]

from hacxgent.core.programmatic import run_programmatic
