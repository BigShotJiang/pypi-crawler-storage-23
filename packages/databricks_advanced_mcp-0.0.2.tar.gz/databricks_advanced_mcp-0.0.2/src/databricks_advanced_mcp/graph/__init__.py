"""Graph modules for dependency graph construction and caching."""
