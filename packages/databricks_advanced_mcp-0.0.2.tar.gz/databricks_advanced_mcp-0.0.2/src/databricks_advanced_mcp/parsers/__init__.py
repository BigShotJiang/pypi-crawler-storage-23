"""Parsers for extracting table/column references from SQL, notebooks, and DLT pipelines."""
