"""Databricks Advanced MCP Server.

An advanced MCP server for Databricks workspace intelligence — dependency
scanning, impact analysis, notebook review, and job/pipeline operations.
"""

__version__ = "0.0.2"
