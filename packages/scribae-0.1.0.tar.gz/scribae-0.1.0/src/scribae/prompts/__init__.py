"""Prompt templates used by Scribae CLI commands."""

__all__ = [
    "brief",
    "write",
    "idea",
    "meta",
]
