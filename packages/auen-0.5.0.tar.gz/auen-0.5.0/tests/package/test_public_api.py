from __future__ import annotations

import auen

EXPECTED_PUBLIC_API = {
    "ALL_OPERATIONS",
    "AllowAll",
    "AsyncCrudRepository",
    "AsyncSqlModelRepository",
    "AuenError",
    "AuthConfig",
    "ConfigurationError",
    "ConflictError",
    "CrudPolicy",
    "CrudRouterBuilder",
    "FilterConfig",
    "FilterFieldConfig",
    "FilterOp",
    "ForbiddenError",
    "HooksConfig",
    "NestedRelationConfig",
    "NestedWriteConfig",
    "NotFoundError",
    "Operation",
    "PaginationConfig",
    "SchemaConfig",
    "SchemaContainer",
    "__version__",
    "derive_schema_container",
    "derive_schemas",
}


def test_public_api_exports_are_curated() -> None:
    assert set(auen.__all__) == EXPECTED_PUBLIC_API
    for name in EXPECTED_PUBLIC_API:
        assert hasattr(auen, name)
