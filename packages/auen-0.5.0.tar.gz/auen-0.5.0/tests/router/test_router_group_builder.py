"""CrudRouterBuilder explicit multi-model loop tests."""

from __future__ import annotations

from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient
from sqlmodel import Field, SQLModel
from tests.conftest import Book, SessionFactory

from auen import CrudRouterBuilder, Operation


class Author(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    name: str


async def test_build_registers_multiple_routers(get_session: SessionFactory) -> None:
    app = FastAPI()
    for model in (Book, Author):
        app.include_router(
            CrudRouterBuilder()
            .with_operations({Operation.LIST})
            .build_routers(models=[model], session_dep=get_session)[0]
        )

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        resp = await client.get("/books/")
        assert resp.status_code == 200
        assert resp.json() == []

        resp = await client.get("/authors/")
        assert resp.status_code == 200
        assert resp.json() == []
