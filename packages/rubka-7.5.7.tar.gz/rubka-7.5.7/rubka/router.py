from typing import Callable, Awaitable, Any
from collections import defaultdict

class Router:
    def __init__(self, prefix: str = ""):
        self.prefix = prefix.rstrip()
        self._handlers: dict[str, list[Callable]] = defaultdict(list)

    def message(self, *filters):
        def decorator(func: Callable[..., Awaitable[Any]]):
            async def wrapped(bot, update, *args, **kwargs):
                text = update.get("text", "")
                if self.prefix and not text.startswith(self.prefix):
                    return
                if all(f(update) for f in filters):
                    await func(bot, update, *args, **kwargs)
            self._handlers["message"].append(wrapped)
            return wrapped
        return decorator

    def include_router(self, other: "Router"):
        for event, handlers in other._handlers.items():
            self._handlers[event].extend(handlers)

    async def dispatch(self, event: str, *args, **kwargs):
        for handler in self._handlers.get(event, []):
            try:
                await handler(*args, **kwargs)
            except Exception as e:
                print(f"{e}")