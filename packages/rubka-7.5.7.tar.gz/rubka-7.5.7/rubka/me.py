from typing import Optional, Dict, Any
import asyncio

class asproperty:
    def __init__(self, func):
        self.func = func
        self._cache_name = f"_{func.__name__}_cache"
    def __get__(self, instance, owner):
        if instance is None:
            return self
        return aspropertyWrapper(instance, self.func, self._cache_name)
class aspropertyWrapper:
    def __init__(self, instance, func, cache_name=None):
        self.instance = instance
        self.func = func
        self.cache_name = cache_name
    def __call__(self):
        return self._run_coro(self.func(self.instance))
    def __await__(self):
        return self.func(self.instance).__await__()
    def __str__(self):
        return str(self._run_coro(self.func(self.instance)))
    def __repr__(self):
        return repr(self._run_coro(self.func(self.instance)))
    def _run_coro(self, coro):
        try:
            loop = asyncio.get_running_loop()
            if loop.is_running():return coro
        except RuntimeError:pass
        return asyncio.run(coro)
class Me:
    def __init__(self, bot_instance):
        self.bot = bot_instance
        self._cache: Optional[Dict[str, Any]] = None
    async def _fetch(self) -> Dict[str, Any]:
        if self._cache is None:
            res = await self.bot.get_me()
            self._cache = res.get("data", {}).get("bot", {})
        return self._cache
    @asproperty
    async def chat_id(self) -> Optional[str]:
        bot = await self._fetch()
        return bot.get("bot_id") if bot else None
    @asproperty
    async def username(self) -> Optional[str]:
        bot = await self._fetch()
        username = bot.get("username") if bot else None
        return f"@{username}" if username else None
    @asproperty
    async def title(self) -> Optional[str]:
        bot = await self._fetch()
        return bot.get("bot_title") if bot else None
    @asproperty
    async def description(self) -> Optional[str]:
        bot = await self._fetch()
        return bot.get("description") if bot else None
    @asproperty
    async def start_message(self) -> Optional[str]:
        bot = await self._fetch()
        return bot.get("start_message") if bot else None
    @asproperty
    async def share_url(self) -> Optional[str]:
        bot = await self._fetch()
        return bot.get("share_url") if bot else None
    @asproperty
    async def avatar(self) -> Optional[Dict[str, Any]]:
        bot = await self._fetch()
        return bot.get("avatar") if bot else None
    @asproperty
    async def avatar_file_id(self) -> Optional[str]:
        avatar = await self.avatar()
        return avatar.get("file_id") if avatar else None
    @asproperty
    async def avatar_file_name(self) -> Optional[str]:
        avatar = await self.avatar()
        return avatar.get("file_name") if avatar else None
    @asproperty
    async def avatar_size(self) -> Optional[int]:
        avatar = await self.avatar()
        return avatar.get("size") if avatar else None