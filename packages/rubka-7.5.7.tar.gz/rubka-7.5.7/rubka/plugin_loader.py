import importlib.metadata
import importlib.util
from pathlib import Path
from typing import Any

from .router import Router

class PluginLoader:
    @staticmethod
    def get_installed_plugins() -> list[str]:
        return [ep.name for ep in importlib.metadata.entry_points(group="rubka.plugins")]

    @staticmethod
    def load_plugin(plugin_name: str, bot: Any) -> bool:
        success = False
        module = None
        try:
            module = importlib.import_module(plugin_name)
        except ImportError:
            pass
        if module is None:
            try:
                module = importlib.import_module(f"{plugin_name}.plugin")
            except ImportError:
                print(f"Error : {plugin_name}")
                return False

        register_func = None
        if hasattr(module, "register"):
            register_func = module.register
        elif hasattr(module, "plugin") and hasattr(module.plugin, "register"):
            register_func = module.plugin.register

        if register_func:
            try:
                register_func(bot)
                print(f"Load Ok : {plugin_name}")
                success = True
            except Exception as e:
                print(f"erro : {plugin_name}: {e}")
        else:
            print(f"پلاگین {plugin_name} تابع register ندارد")

        return success

    @staticmethod
    def auto_load_all(bot: Any):
        plugins = PluginLoader.get_installed_plugins()
        for name in plugins:
            PluginLoader.load_plugin(name, bot)