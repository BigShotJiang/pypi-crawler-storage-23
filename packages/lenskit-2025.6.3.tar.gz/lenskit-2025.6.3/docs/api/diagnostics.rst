Diagnostic APIs
===============

.. py:module:: lenskit.diagnostics

Warnings
--------

.. autoclass:: DataWarning

.. autoclass:: ConfigWarning
