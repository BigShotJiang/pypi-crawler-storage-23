Basic Data Types
================

.. py:module:: lenskit.data.types


Entity Identifiers
~~~~~~~~~~~~~~~~~~

.. autodata:: ID
.. autodata:: CoreID
.. autodata:: NPID

.. autodata:: IDArray
.. autodata:: IDSequence

Containers
~~~~~~~~~~

.. autoclass:: UIPair
