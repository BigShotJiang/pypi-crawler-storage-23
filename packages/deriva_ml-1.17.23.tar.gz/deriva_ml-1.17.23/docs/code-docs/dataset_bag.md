# DatasetBag Class

The DatasetBag class represents a downloaded dataset packaged as a BDBag.
It provides methods to access dataset contents, metadata, and associated files
from the local filesystem.

::: deriva_ml.dataset.dataset_bag
    handler: python
