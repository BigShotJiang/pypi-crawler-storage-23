"""Tools package.

Tool Implementation Pattern
===========================

All tools should follow this pattern for session access:

    from mcp_guide.session import get_current_session

    async def my_tool(project_name: str) -> dict:
        session = get_current_session(project_name)

        if session is None:
            return {"success": False, "error": "No active session"}

        project = await session.get_project()
        # Use project config...

        return {"success": True, "data": ...}

Note: Actual tool implementations will be added in separate changes.
"""

# Import Arguments as ToolArguments for backward compatibility
from mcp_guide.core.arguments import Arguments as ToolArguments
from mcp_guide.tools.tool_result import prompt_result, tool_result

__all__ = ["ToolArguments", "tool_result", "prompt_result"]
