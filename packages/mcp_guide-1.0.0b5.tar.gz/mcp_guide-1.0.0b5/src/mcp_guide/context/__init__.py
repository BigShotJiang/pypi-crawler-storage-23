"""Client context module."""
