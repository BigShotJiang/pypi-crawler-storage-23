"""Client tools for MCP."""

import json
from typing import Any

from mcp.types import TextContent, Tool

from ..client import Platform2StepClient

CLIENT_TOOLS: list[Tool] = [
    Tool(
        name="list_clients",
        description="List clients for a company. Returns client IDs, names, emails, and phones. To create, update, or delete clients, use the create_batch tool.",
        inputSchema={
            "type": "object",
            "properties": {
                "company_id": {
                    "type": "integer",
                    "description": "Company ID to list clients for",
                },
                "page": {
                    "type": "integer",
                    "description": "Page number (default 1)",
                },
                "per_page": {
                    "type": "integer",
                    "description": "Results per page (default 25, max 100)",
                },
            },
            "required": ["company_id"],
            "additionalProperties": False,
        },
    ),
    Tool(
        name="get_client",
        description="Get details of a specific client. To create, update, or delete clients, use the create_batch tool.",
        inputSchema={
            "type": "object",
            "properties": {
                "client_id": {
                    "type": "integer",
                    "description": "Client ID",
                },
            },
            "required": ["client_id"],
            "additionalProperties": False,
        },
    ),
]


async def handle_client_tool(
    name: str,
    arguments: dict[str, Any],
    client: Platform2StepClient,
) -> list[TextContent]:
    """Handle client tool calls.

    Args:
        name: Tool name.
        arguments: Tool arguments.
        client: Platform2Step HTTP client.

    Returns:
        List of TextContent with the result.
    """
    if name == "list_clients":
        result = await client.list_clients(
            company_id=arguments["company_id"],
            page=arguments.get("page", 1),
            per_page=arguments.get("per_page", 25),
        )
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    elif name == "get_client":
        result = await client.get_client(
            client_id=arguments["client_id"],
        )
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    raise ValueError(f"Unknown client tool: {name}")
