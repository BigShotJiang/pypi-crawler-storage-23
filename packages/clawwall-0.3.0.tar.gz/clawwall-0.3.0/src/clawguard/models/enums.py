from __future__ import annotations

from enum import Enum


class PolicyAction(str, Enum):
    """Actions that can be configured in policy rules."""
    ALLOW = "ALLOW"
    BLOCK = "BLOCK"
    REDACT = "REDACT"


class Action(str, Enum):
    ALLOW = "ALLOW"
    BLOCK = "BLOCK"
    REDACT = "REDACT"
    PROMPT = "PROMPT"


class Severity(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class ScannerType(str, Enum):
    SECRET = "SECRET"
    PII = "PII"
    CUSTOM = "CUSTOM"


class RedactStrategy(str, Enum):
    MASK = "mask"
    HASH = "hash"
    REMOVE = "remove"
