"""ClawGuard — DLP Surveillance Layer for OpenClaw."""

__version__ = "0.3.0"
