"""Shared Mattermost API helpers for node implementations."""

import logging
from typing import Any

import httpx
from flowire_sdk import FieldOption

logger = logging.getLogger(__name__)


async def fetch_channels(credential_data: dict[str, Any]) -> list[FieldOption]:
    """Fetch channels the authenticated user has access to.

    Returns a sorted list of FieldOption with channel ID as value and
    display name (with type indicator) as the label.
    """
    server_url = credential_data.get("server_url", "").rstrip("/")
    access_token = credential_data.get("access_token", "")

    if not server_url or not access_token:
        return []

    headers = {
        "Authorization": f"Bearer {access_token}",
    }

    type_labels = {
        "O": "Public",
        "P": "Private",
        "G": "Group",
    }

    try:
        channels: list[dict[str, Any]] = []
        page = 0
        per_page = 200

        async with httpx.AsyncClient() as client:
            while True:
                response = await client.get(
                    f"{server_url}/api/v4/users/me/channels",
                    headers=headers,
                    params={"page": page, "per_page": per_page},
                    timeout=15,
                )

                if response.status_code != 200:
                    logger.warning(
                        "Mattermost channels API returned %d",
                        response.status_code,
                    )
                    return []

                batch = response.json()
                if not batch:
                    break
                channels.extend(batch)
                if len(batch) < per_page:
                    break
                page += 1

        options: list[FieldOption] = []
        for ch in channels:
            ch_type = ch.get("type", "")
            # Skip direct messages — not useful as a channel target
            if ch_type == "D":
                continue

            display_name = ch.get("display_name") or ch.get("name", ch["id"])
            type_label = type_labels.get(ch_type, ch_type)
            description = f"{type_label} channel"

            options.append(
                FieldOption(
                    id=ch["id"],
                    name=display_name,
                    description=description,
                )
            )

        options.sort(key=lambda o: o.name.lower())
        return options

    except Exception:
        logger.warning("Failed to fetch Mattermost channels", exc_info=True)
        return []
