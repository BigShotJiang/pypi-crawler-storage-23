"""Shared Mattermost token validation logic."""

from typing import Any

from flowire_sdk import NodeExecutionContext


async def validate_mattermost_token(
    inputs: dict[str, Any],
    body: dict[str, Any],
    context: NodeExecutionContext,
    source_type: str,
) -> None:
    """Validate a Mattermost token from an incoming request.

    Checks that the expected token is configured, that the request body
    contains a token, and that they match. Registers the token as a secret
    so it is redacted from execution logs.

    Args:
        inputs: The node's parsed input configuration (must contain 'token' key).
        body: The request body from Mattermost (must contain 'token' key).
        context: The node execution context for publishing errors and registering secrets.
        source_type: A human-readable source label (e.g. "webhook", "slash command")
            used in error messages.

    Raises:
        PermissionError: If the token is not configured, missing from the request,
            or does not match the expected value.
    """
    expected_token = inputs.get("token")

    if not expected_token:
        error = (
            "Token validation is enabled but no token is configured. "
            "Set the 'token' field in the node configuration."
        )
        context.publish_webhook_error(error, status_code=500)
        raise PermissionError(error)

    actual_token = body.get("token", "")

    if not actual_token:
        error = f"Missing token in Mattermost {source_type} request"
        context.publish_webhook_error(error, status_code=401)
        raise PermissionError(error)

    if actual_token != expected_token:
        error = f"Invalid Mattermost {source_type} token"
        context.publish_webhook_error(error, status_code=403)
        raise PermissionError(error)

    # Register the token as a secret so it's redacted from logs
    context.register_secret(expected_token)
