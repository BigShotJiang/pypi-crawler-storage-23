"""Tests for MattermostStreamTriggerNode."""

import json

import pytest

from fw_nodes_mattermost.nodes.stream_trigger import MattermostStreamTriggerNode


@pytest.fixture
def stream_trigger_node():
    """Create a MattermostStreamTriggerNode for testing."""
    return MattermostStreamTriggerNode()


@pytest.mark.asyncio
async def test_posted_event_parsing(stream_trigger_node, mock_context):
    """Test parsing of a 'posted' event with JSON post string."""
    post_data = {
        "id": "post_abc123",
        "message": "Hello, world!",
        "user_id": "user_sender_1",
        "channel_id": "channel_general",
    }
    inputs = {
        "_trigger_data": {
            "event_type": "posted",
            "event_data": {
                "post": json.dumps(post_data),
                "sender_name": "john.doe",
                "channel_id": "channel_general",
            },
            "broadcast": {
                "user_id": "user_sender_1",
                "channel_id": "channel_general",
                "team_id": "team_xyz",
            },
        },
    }

    result = await stream_trigger_node.execute(inputs, mock_context)

    assert result.event_type == "posted"
    assert result.message == "Hello, world!"
    assert result.user_id == "user_sender_1"
    assert result.channel_id == "channel_general"
    assert result.post_id == "post_abc123"
    assert result.team_id == "team_xyz"
    assert result.sender_name == "john.doe"


@pytest.mark.asyncio
async def test_reaction_event_parsing(stream_trigger_node, mock_context):
    """Test parsing of a 'reaction_added' event with reaction data."""
    reaction_data = {
        "user_id": "user_reactor",
        "post_id": "post_reacted_to",
        "emoji_name": "thumbsup",
    }
    inputs = {
        "_trigger_data": {
            "event_type": "reaction_added",
            "event_data": {
                "reaction": json.dumps(reaction_data),
            },
            "broadcast": {
                "channel_id": "channel_reactions",
                "team_id": "team_abc",
            },
        },
    }

    result = await stream_trigger_node.execute(inputs, mock_context)

    assert result.event_type == "reaction_added"
    assert result.emoji_name == "thumbsup"
    assert result.post_id == "post_reacted_to"
    assert result.user_id == "user_reactor"
    assert result.channel_id == "channel_reactions"
    assert result.team_id == "team_abc"


@pytest.mark.asyncio
async def test_missing_trigger_data(stream_trigger_node, mock_context):
    """Test that missing _trigger_data produces safe defaults."""
    inputs = {}

    result = await stream_trigger_node.execute(inputs, mock_context)

    assert result.event_type == ""
    assert result.user_id == ""
    assert result.channel_id == ""
    assert result.team_id == ""
    assert result.post_id is None
    assert result.message is None
    assert result.emoji_name is None
    assert result.sender_name is None
    assert result.raw_event == {"event_data": {}}


@pytest.mark.asyncio
async def test_posted_event_invalid_json(stream_trigger_node, mock_context):
    """Test that invalid JSON in post field does not crash the node."""
    inputs = {
        "_trigger_data": {
            "event_type": "posted",
            "event_data": {
                "post": "this is not valid json {{{",
                "sender_name": "broken_user",
            },
            "broadcast": {
                "user_id": "user_123",
                "channel_id": "channel_456",
                "team_id": "team_789",
            },
        },
    }

    result = await stream_trigger_node.execute(inputs, mock_context)

    assert result.event_type == "posted"
    # Post fields should be None since JSON parsing failed and post becomes {}
    assert result.post_id is None
    assert result.message is None
    # broadcast fields should still be extracted
    assert result.user_id == "user_123"
    assert result.channel_id == "channel_456"
    assert result.team_id == "team_789"
    assert result.sender_name == "broken_user"


@pytest.mark.asyncio
async def test_raw_event_has_parsed_json(stream_trigger_node, mock_context):
    """Test that raw_event contains parsed JSON strings in event_data."""
    post_data = {
        "id": "post_raw_test",
        "message": "Check raw event",
        "user_id": "user_raw",
        "channel_id": "channel_raw",
    }
    inputs = {
        "_trigger_data": {
            "event_type": "posted",
            "event_data": {
                "post": json.dumps(post_data),
                "sender_name": "raw_user",
            },
            "broadcast": {
                "user_id": "user_raw",
                "channel_id": "channel_raw",
                "team_id": "team_raw",
            },
        },
    }

    result = await stream_trigger_node.execute(inputs, mock_context)

    # raw_event.event_data.post should be a parsed dict, not a JSON string
    raw_post = result.raw_event["event_data"]["post"]
    assert isinstance(raw_post, dict)
    assert raw_post["id"] == "post_raw_test"
    assert raw_post["message"] == "Check raw event"

    # sender_name is a plain string, should remain as-is
    assert result.raw_event["event_data"]["sender_name"] == "raw_user"

    # broadcast should be passed through unchanged
    assert result.raw_event["broadcast"]["team_id"] == "team_raw"
