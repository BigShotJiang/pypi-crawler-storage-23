# antaris-forge

**Memory, safety, and context for Antaris Forge bots.**

`antaris-forge` is the stable runtime package for Forge-powered AI agents. It bundles the three core infrastructure packages in a single install.

## Packages

| Package | Purpose |
|---------|---------|
| [`antaris-memory`](antaris-memory/) | File-based persistent memory — BM25 search, audit logging, semantic re-ranking, PPMI co-occurrence |
| [`antaris-guard`](antaris-guard/) | Prompt safety screening and injection detection |
| [`antaris-context`](antaris-context/) | Token budget management and context window optimization |

## Install

```bash
pip install antaris-forge
```

With semantic search (transformer embeddings):

```bash
pip install antaris-forge[semantic]
```

## Quick Start

```python
from antaris_memory import MemoryStore
from antaris_guard import GuardEngine
from antaris_context import ContextManager

# Memory
store = MemoryStore("./workspace")
store.add("Patient: John, 42M, elevated liver enzymes noted on 2024-01-15")
results = store.search("liver")

# Safety
guard = GuardEngine()
safe = guard.check("Tell me about liver function tests")

# Context
ctx = ContextManager(max_tokens=4096)
ctx.add("system", "You are a helpful medical assistant.")
window = ctx.get_window()
```

## Design

- **File-based** — JSON/JSONL storage, zero databases
- **Zero mandatory dependencies** — pure Python core
- **Thread-safe** — concurrent reads and writes handled correctly
- **Privacy-first** — HMAC-SHA256 PII anonymization, local-only by default

## Versioning

`antaris-forge` is the stable Forge fork of [`antaris-suite`](https://github.com/Antaris-Analytics/antaris-suite). 

- Bug fixes and security patches land here
- New features and experimental work land in `antaris-suite` first
- Production Forge bots should pin to `antaris-forge~=1.0`

## License

MIT — see [LICENSE](LICENSE)
