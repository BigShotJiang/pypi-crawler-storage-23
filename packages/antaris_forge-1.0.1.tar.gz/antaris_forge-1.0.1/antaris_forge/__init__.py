"""
antaris-forge v1.0.0

Memory, safety, and context for Antaris Forge bots.

Packages:
    antaris_memory  — BM25 + semantic search, audit logging, co-occurrence PPMI
    antaris_guard   — Prompt safety screening and injection detection
    antaris_context — Token budget management and context windowing

Install:
    pip install antaris-forge            # core
    pip install antaris-forge[semantic]  # + transformer embeddings
"""

__version__ = "1.0.1"
__all__ = ["__version__"]
