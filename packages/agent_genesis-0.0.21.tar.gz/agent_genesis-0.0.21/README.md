# agent-genesis

An evaluation SDK for building, registering, and running agent-based coding challenges with dual-sandbox isolation.

## Features

- Define problems with multi-phase evaluation pipelines
- Dual-sandbox architecture: isolated judge + user containers per test case
- gRPC-based communication between judge and user runtimes
- Template image pool with LRU garbage collection for fast container startup
- Concurrency control: global sandbox limits + per-submission parallelism caps
- Built-in problem registry, artifact management, and revision workflows

## Install

```bash
pip install agent-genesis
```

For server-side deployment (Docker sandbox + gRPC transport):

```bash
pip install "agent-genesis[server]"
```

## Documentation

Full usage guide and examples: [https://agent-genesis-ai.com/docs](https://agent-genesis-ai.com/docs)

## License

Apache License 2.0
