"""
AgentGuard Python SDK

Monitor and protect yourself with AI agent budget controls,
approval workflows, and anomaly detection.

Usage:
    from agentguard import AgentGuard

    guard = AgentGuard(api_key="ag_your_api_key")

    # Wrap any function for automatic protection
    chat = guard.wrap(
        my_chat_function,
        action="openai_chat",
        estimated_cost=0.05,
    )
    result = await chat("Hello!")

    # Or use as a decorator
    @guard.protect(action="openai_chat", estimated_cost=0.05)
    async def chat(prompt):
        return await openai.chat(prompt)
"""

import asyncio
import time
import json
from typing import Any, Callable, Dict, List, Optional, TypeVar, ParamSpec
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
from dataclasses import dataclass, field

__version__ = "0.1.0"

# ============================================================================
# TYPES
# ============================================================================

@dataclass
class CheckResult:
    """Result of a pre-action check."""
    allowed: bool
    reason: Optional[str] = None
    message: Optional[str] = None
    requires_approval: bool = False
    approval_threshold: Optional[float] = None
    budget_status: Optional[Dict[str, Any]] = None


@dataclass
class LogResult:
    """Result of logging an action."""
    success: bool
    log: Optional[Dict[str, Any]] = None
    blocked: bool = False
    block_reason: Optional[str] = None
    approval_required: bool = False
    approval_id: Optional[str] = None
    budget_status: Optional[Dict[str, Any]] = None


@dataclass
class BudgetStatus:
    """Current budget status for an agent."""
    agent_id: str
    budget_limit: Optional[float] = None
    budget_period: str = "DAILY"
    budget_spent: float = 0
    budget_remaining: Optional[float] = None
    percent_used: Optional[float] = None
    is_blocked: bool = False
    hard_limit: bool = False
    reset_at: Optional[str] = None


@dataclass
class BudgetCheckResult:
    """Result of a budget check."""
    allowed: bool
    reason: Optional[str] = None
    budget_limit: Optional[float] = None
    budget_spent: float = 0
    budget_remaining: Optional[float] = None
    estimated_cost: Optional[float] = None


@dataclass
class Approval:
    """An approval request."""
    id: str
    action: str
    status: str  # PENDING, APPROVED, REJECTED, EXPIRED
    estimated_cost: Optional[float] = None
    decided_by: Optional[str] = None
    decided_at: Optional[str] = None
    decision_note: Optional[str] = None


# ============================================================================
# ERRORS
# ============================================================================

class AgentGuardError(Exception):
    """Base error for AgentGuard SDK."""

    def __init__(self, code: str, message: str, details: Any = None):
        super().__init__(message)
        self.code = code
        self.details = details


class AgentPausedError(AgentGuardError):
    """Raised when the agent is paused."""

    def __init__(self, message: str = "Agent is paused"):
        super().__init__("AGENT_PAUSED", message)


class AgentBlockedError(AgentGuardError):
    """Raised when the agent is blocked (kill switch)."""

    def __init__(self, message: str = "Agent is blocked"):
        super().__init__("AGENT_BLOCKED", message)


class BudgetExceededError(AgentGuardError):
    """Raised when the budget limit is exceeded."""

    def __init__(self, message: str = "Budget limit exceeded"):
        super().__init__("BUDGET_EXCEEDED", message)


class ApprovalRequiredError(AgentGuardError):
    """Raised when an action requires human approval."""

    def __init__(
        self,
        message: str = "Action requires approval",
        threshold: Optional[float] = None,
        approval_id: Optional[str] = None,
    ):
        super().__init__("APPROVAL_REQUIRED", message, {"approval_id": approval_id, "threshold": threshold})
        self.approval_id = approval_id
        self.threshold = threshold


# ============================================================================
# MAIN CLASS
# ============================================================================

class AgentGuard:
    """
    AgentGuard SDK client.

    Args:
        api_key: Your agent API key (starts with 'ag_'). Get it from app.agent-guard.io
        base_url: API base URL (default: https://api.agent-guard.io)
        timeout: Request timeout in seconds (default: 10)
        debug: Enable debug logging (default: False)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://agentguard-production-0f46.up.railway.app",
        timeout: int = 10,
        debug: bool = False,
    ):
        if not api_key:
            raise ValueError("API key is required")
        if not api_key.startswith("ag_"):
            raise ValueError('Invalid API key format. API keys should start with "ag_"')

        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.debug = debug

    # ========================================================================
    # CHECK — Pre-action validation
    # ========================================================================

    def check(self, action: str, estimated_cost: Optional[float] = None) -> CheckResult:
        """
        Check if an action is allowed BEFORE running it.

        Args:
            action: Action type (e.g., 'openai_chat', 'send_email')
            estimated_cost: Estimated cost of the action in USD

        Returns:
            CheckResult with allowed status and details

        Example::

            result = guard.check("openai_chat", estimated_cost=0.05)
            if result.allowed:
                # Safe to proceed
                response = openai.chat(prompt="Hello")
            else:
                print(f"Blocked: {result.message}")
        """
        body = {"action": action}
        if estimated_cost is not None:
            body["estimatedCost"] = estimated_cost

        data = self._request("POST", "/v1/logs/check", body)
        return CheckResult(
            allowed=data.get("allowed", False),
            reason=data.get("reason"),
            message=data.get("message"),
            requires_approval=data.get("requiresApproval", False),
            approval_threshold=data.get("approvalThreshold"),
            budget_status=data.get("budgetStatus"),
        )

    def ensure_allowed(self, action: str, estimated_cost: Optional[float] = None) -> None:
        """
        Check if an action is allowed, raise an error if not.

        Args:
            action: Action type
            estimated_cost: Estimated cost in USD

        Raises:
            AgentPausedError: If agent is paused
            AgentBlockedError: If agent is blocked
            BudgetExceededError: If budget exceeded
            ApprovalRequiredError: If action needs approval
        """
        result = self.check(action, estimated_cost)

        if not result.allowed:
            reason = result.reason
            if reason == "AGENT_PAUSED":
                raise AgentPausedError(result.message or "Agent is paused")
            elif reason in ("AGENT_NOT_FOUND", "BLOCKED"):
                raise AgentBlockedError(result.message or "Agent is blocked")
            elif reason in ("BUDGET_EXCEEDED", "WOULD_EXCEED"):
                raise BudgetExceededError(result.message or "Budget exceeded")
            elif reason == "APPROVAL_REQUIRED":
                raise ApprovalRequiredError(
                    result.message or "Action requires approval",
                    threshold=result.approval_threshold,
                )
            else:
                raise AgentGuardError(reason or "UNKNOWN", result.message or "Action not allowed")

    # ========================================================================
    # LOGGING
    # ========================================================================

    def log(
        self,
        action: str,
        *,
        provider: Optional[str] = None,
        model: Optional[str] = None,
        request: Any = None,
        response: Any = None,
        metadata: Any = None,
        cost: Optional[float] = None,
        input_tokens: Optional[int] = None,
        output_tokens: Optional[int] = None,
        duration_ms: Optional[int] = None,
        status: str = "SUCCESS",
        error_message: Optional[str] = None,
    ) -> LogResult:
        """
        Log an agent action.

        Args:
            action: Action type (e.g., 'api_call', 'tool_use')
            provider: Provider name (e.g., 'openai', 'anthropic')
            model: Model name (e.g., 'gpt-4', 'claude-3-opus')
            request: Request data
            response: Response data
            metadata: Additional metadata
            cost: Cost in USD
            input_tokens: Number of input tokens
            output_tokens: Number of output tokens
            duration_ms: Duration in milliseconds
            status: 'SUCCESS' or 'FAILED'
            error_message: Error message if failed

        Returns:
            LogResult with logging details

        Example::

            guard.log(
                "api_call",
                provider="openai",
                model="gpt-4",
                cost=0.05,
                input_tokens=10,
                output_tokens=25,
            )
        """
        body: Dict[str, Any] = {"action": action, "status": status}

        if provider is not None:
            body["provider"] = provider
        if model is not None:
            body["model"] = model
        if request is not None:
            body["request"] = request
        if response is not None:
            body["response"] = response
        if metadata is not None:
            body["metadata"] = metadata
        if cost is not None:
            body["cost"] = cost
        if input_tokens is not None:
            body["inputTokens"] = input_tokens
        if output_tokens is not None:
            body["outputTokens"] = output_tokens
        if duration_ms is not None:
            body["durationMs"] = duration_ms
        if error_message is not None:
            body["errorMessage"] = error_message

        data = self._request("POST", "/v1/logs", body)

        result = LogResult(
            success=data.get("success", True),
            log=data.get("log"),
            blocked=data.get("blocked", False),
            block_reason=data.get("blockReason"),
            approval_required=data.get("approvalRequired", False),
            approval_id=data.get("approvalId"),
            budget_status=data.get("budgetStatus"),
        )

        if result.blocked:
            raise AgentBlockedError(result.block_reason or "Action blocked")
        if result.approval_required:
            raise ApprovalRequiredError(approval_id=result.approval_id)

        return result

    def track(self, action: str, **initial_data) -> Callable:
        """
        Start tracking an action. Returns a function to call when done.

        Args:
            action: Action type
            **initial_data: Initial log data (provider, model, etc.)

        Returns:
            A callable that logs the completed action with duration

        Example::

            done = guard.track("openai_chat", provider="openai")
            result = openai.chat(prompt="Hello")
            done(cost=0.05, response=result)
        """
        start_time = time.time()

        def finish(**final_data) -> LogResult:
            duration_ms = int((time.time() - start_time) * 1000)
            merged = {**initial_data, **final_data}
            return self.log(action, duration_ms=duration_ms, **merged)

        return finish

    # ========================================================================
    # BUDGET
    # ========================================================================

    def get_budget(self) -> BudgetStatus:
        """
        Get current budget status.

        Returns:
            BudgetStatus with current spending and limits
        """
        data = self._request("GET", "/v1/budget")
        return BudgetStatus(
            agent_id=data.get("agentId", ""),
            budget_limit=data.get("budgetLimit"),
            budget_period=data.get("budgetPeriod", "DAILY"),
            budget_spent=data.get("budgetSpent", 0),
            budget_remaining=data.get("budgetRemaining"),
            percent_used=data.get("percentUsed"),
            is_blocked=data.get("isBlocked", False),
            hard_limit=data.get("hardLimit", False),
            reset_at=data.get("resetAt"),
        )

    def check_budget(self, estimated_cost: Optional[float] = None) -> BudgetCheckResult:
        """
        Check if an action is within budget.

        Args:
            estimated_cost: Estimated cost of the action

        Returns:
            BudgetCheckResult with allowed status
        """
        path = f"/v1/budget/check?cost={estimated_cost}" if estimated_cost else "/v1/budget/check"
        data = self._request("GET", path)
        return BudgetCheckResult(
            allowed=data.get("allowed", False),
            reason=data.get("reason"),
            budget_limit=data.get("budgetLimit"),
            budget_spent=data.get("budgetSpent", 0),
            budget_remaining=data.get("budgetRemaining"),
            estimated_cost=estimated_cost,
        )

    def ensure_budget(self, estimated_cost: Optional[float] = None) -> None:
        """
        Ensure action is within budget, raise if not.

        Args:
            estimated_cost: Estimated cost of the action

        Raises:
            BudgetExceededError: If budget would be exceeded
            AgentBlockedError: If agent is blocked
        """
        result = self.check_budget(estimated_cost)

        if not result.allowed:
            if result.reason == "BLOCKED":
                raise AgentBlockedError()
            raise BudgetExceededError(
                f"Budget {'would be ' if result.reason == 'WOULD_EXCEED' else ''}exceeded. "
                f"Spent: ${result.budget_spent:.2f}, "
                f"Limit: ${result.budget_limit:.2f}" if result.budget_limit else "unlimited"
            )

    # ========================================================================
    # APPROVALS
    # ========================================================================

    def request_approval(
        self,
        action: str,
        *,
        description: Optional[str] = None,
        estimated_cost: Optional[float] = None,
        metadata: Any = None,
        expires_in_minutes: int = 60,
    ) -> Approval:
        """
        Request approval for an action.

        Args:
            action: Action requiring approval
            description: Description for the approver
            estimated_cost: Estimated cost in USD
            metadata: Additional context
            expires_in_minutes: Minutes until approval expires (default: 60)

        Returns:
            Approval object with id and status

        Example::

            approval = guard.request_approval(
                "send_bulk_email",
                description="Send marketing email to 10k users",
                estimated_cost=45.00,
            )
            print(f"Approval ID: {approval.id}")
        """
        body: Dict[str, Any] = {
            "action": action,
            "expiresInMinutes": expires_in_minutes,
        }
        if description is not None:
            body["description"] = description
        if estimated_cost is not None:
            body["estimatedCost"] = estimated_cost
        if metadata is not None:
            body["metadata"] = metadata

        data = self._request("POST", "/v1/approvals", body)
        return self._parse_approval(data)

    def get_approval_status(self, approval_id: str) -> Approval:
        """
        Get the current status of an approval.

        Args:
            approval_id: The approval ID

        Returns:
            Approval with current status
        """
        data = self._request("GET", f"/v1/approvals/{approval_id}/status")
        return self._parse_approval(data)

    def wait_for_approval(
        self,
        approval_id: str,
        poll_interval: float = 5.0,
        timeout: float = 3600.0,
    ) -> Approval:
        """
        Wait for an approval to be decided. Polls until approved, rejected, or expired.

        Args:
            approval_id: The approval ID to wait for
            poll_interval: Seconds between polls (default: 5)
            timeout: Max seconds to wait (default: 3600 = 1 hour)

        Returns:
            The decided Approval

        Raises:
            AgentGuardError: If approval is rejected or expires
            AgentGuardError: If timeout is reached

        Example::

            approval = guard.request_approval("send_email", estimated_cost=5.00)
            try:
                decided = guard.wait_for_approval(approval.id, timeout=300)
                print("Approved!")
            except AgentGuardError as e:
                print(f"Not approved: {e}")
        """
        start_time = time.time()

        while time.time() - start_time < timeout:
            approval = self.get_approval_status(approval_id)

            if approval.status == "APPROVED":
                return approval
            if approval.status == "REJECTED":
                raise AgentGuardError("APPROVAL_REJECTED", "Approval was rejected", {"approval_id": approval_id})
            if approval.status == "EXPIRED":
                raise AgentGuardError("APPROVAL_EXPIRED", "Approval has expired", {"approval_id": approval_id})

            time.sleep(poll_interval)

        raise AgentGuardError("APPROVAL_TIMEOUT", "Timed out waiting for approval", {"approval_id": approval_id, "timeout": timeout})

    # ========================================================================
    # WRAP & PROTECT — The easiest way to protect functions
    # ========================================================================

    def wrap(
        self,
        fn: Callable,
        action: str,
        *,
        provider: Optional[str] = None,
        model: Optional[str] = None,
        estimated_cost: Optional[float] = None,
        get_cost: Optional[Callable] = None,
        get_tokens: Optional[Callable] = None,
    ) -> Callable:
        """
        Wrap a function for automatic protection.

        Automatically checks permissions, runs the function, and logs the result.

        Args:
            fn: The function to protect
            action: Action type
            provider: Provider name
            model: Model name
            estimated_cost: Estimated cost for pre-check
            get_cost: Function to extract cost from result
            get_tokens: Function to extract (input, output) token counts from result

        Returns:
            A protected version of the function

        Example::

            chat = guard.wrap(
                openai_chat,
                action="openai_chat",
                provider="openai",
                model="gpt-4",
                estimated_cost=0.05,
                get_cost=lambda r: r.usage.total_cost,
            )
            result = chat("Hello!")
        """
        def wrapper(*args, **kwargs):
            # Check if action is allowed
            self.ensure_allowed(action, estimated_cost)

            start_time = time.time()
            result = None
            error = None

            try:
                result = fn(*args, **kwargs)
                return result
            except Exception as e:
                error = e
                raise
            finally:
                duration_ms = int((time.time() - start_time) * 1000)

                log_kwargs: Dict[str, Any] = {
                    "provider": provider,
                    "model": model,
                    "duration_ms": duration_ms,
                }

                if error:
                    log_kwargs["status"] = "FAILED"
                    log_kwargs["error_message"] = str(error)
                elif result is not None:
                    log_kwargs["status"] = "SUCCESS"

                    if get_cost:
                        try:
                            log_kwargs["cost"] = get_cost(result)
                        except Exception:
                            pass

                    if get_tokens:
                        try:
                            input_t, output_t = get_tokens(result)
                            log_kwargs["input_tokens"] = input_t
                            log_kwargs["output_tokens"] = output_t
                        except Exception:
                            pass

                try:
                    self.log(action, **log_kwargs)
                except Exception:
                    if self.debug:
                        import traceback
                        traceback.print_exc()

        return wrapper

    def protect(
        self,
        action: str,
        *,
        provider: Optional[str] = None,
        model: Optional[str] = None,
        estimated_cost: Optional[float] = None,
        get_cost: Optional[Callable] = None,
        get_tokens: Optional[Callable] = None,
    ) -> Callable:
        """
        Decorator to protect a function. Same as wrap() but as a decorator.

        Example::

            @guard.protect(action="openai_chat", estimated_cost=0.05)
            def chat(prompt):
                return openai.chat(prompt=prompt)

            result = chat("Hello!")
        """
        def decorator(fn: Callable) -> Callable:
            return self.wrap(
                fn, action,
                provider=provider,
                model=model,
                estimated_cost=estimated_cost,
                get_cost=get_cost,
                get_tokens=get_tokens,
            )
        return decorator

    # ========================================================================
    # PRIVATE
    # ========================================================================

    def _request(self, method: str, path: str, body: Optional[Dict] = None) -> Dict:
        """Make an HTTP request to the AgentGuard API."""
        url = f"{self.base_url}{path}"

        if self.debug:
            print(f"[AgentGuard] {method} {url}", body or "")

        data = json.dumps(body).encode("utf-8") if body else None

        req = Request(
            url,
            data=data,
            method=method,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
        )

        try:
            with urlopen(req, timeout=self.timeout) as resp:
                response_data = json.loads(resp.read().decode("utf-8"))

                if self.debug:
                    print(f"[AgentGuard] Response:", response_data)

                if not response_data.get("success") and response_data.get("error"):
                    err = response_data["error"]
                    raise AgentGuardError(
                        err.get("code", "UNKNOWN"),
                        err.get("message", "Request failed"),
                        err.get("details"),
                    )

                return response_data.get("data", response_data)

        except HTTPError as e:
            try:
                error_body = json.loads(e.read().decode("utf-8"))
                err = error_body.get("error", {})
                raise AgentGuardError(
                    err.get("code", f"HTTP_{e.code}"),
                    err.get("message", f"HTTP {e.code}: {e.reason}"),
                    err.get("details"),
                )
            except (json.JSONDecodeError, AgentGuardError):
                if isinstance(e, AgentGuardError):
                    raise
                raise AgentGuardError(f"HTTP_{e.code}", f"HTTP {e.code}: {e.reason}")

        except URLError as e:
            raise AgentGuardError("NETWORK_ERROR", str(e.reason))

        except TimeoutError:
            raise AgentGuardError("TIMEOUT", "Request timed out")

    def _parse_approval(self, data: Dict) -> Approval:
        """Parse approval data from API response."""
        return Approval(
            id=data.get("id", ""),
            action=data.get("action", ""),
            status=data.get("status", "PENDING"),
            estimated_cost=data.get("estimatedCost"),
            decided_by=data.get("decidedBy"),
            decided_at=data.get("decidedAt"),
            decision_note=data.get("decisionNote"),
        )
