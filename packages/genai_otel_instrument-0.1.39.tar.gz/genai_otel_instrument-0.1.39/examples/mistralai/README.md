# Mistral AI Example
```bash
pip install genai-otel-instrument[mistral]
cp .env.example .env
python example.py
```
