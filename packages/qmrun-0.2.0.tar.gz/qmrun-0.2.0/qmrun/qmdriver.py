import platform
import os
from qmrun import qmparser
from qmrun import qmwriter
import sys
import subprocess
import argparse


def description():
    print("A program for the Orca input file generation and batch execution of orca files")
    print("Basic usage: qmrun file.sdf pre.txt post.txt")
    print("file.sdf:"," ","a V2000 SDF file containing initial geometries")
    print("pre.txt:"," ","a text file containing Orca keywords before *xyz block")
    print("A typical pre.txt file may look like:")
    print("!PAL8")
    print("B3LYP def2-SVP NMR")
    print("post.txt (optional):"," ","a text file containing Orca keywords after *xyz block")
    print("A typical post.txt file may look like:")
    print("%eprnmr\n","Nuclei = all\n","{ssfc}\n","SpinSpinRThresh\n","500.0\n","end")


def Run():
    ap = argparse.ArgumentParser("qmrun",
                                 description=description(),
                                 )
    ap.add_argument("filename",help="A V2000 sdf file containing one or more structures")
    ap.add_argument("header",help="orca header file")
    ap.add_argument("footer",nargs='?',help="orca footer file",default=None)
    ap.add_argument("--start",help="start computation from this structure number",type=int)
    ap.add_argument("--stop",help="stop computation at this structure number",type=int)
    ap.add_argument("--charge",help="Molecular charge to be used in input file, default 0", type=int)
    ap.add_argument("--multiplicity",help="Multiplicity to be used in input file, default 1",type=int)
    
    #ap.add_argument("--generate",help="generate header and footer files")
    args=ap.parse_args()


    rootname=args.filename[0:args.filename.rfind(".")]
    if not os.path.exists(rootname):
      os.mkdir(rootname)
    conformers = qmparser.ParseFile(args.filename, format="sdf")
    print(len(conformers)," structures read from file")

    filestorun=[]
    postf=None
    minidx=None
    maxidx=None
    if args.footer:
        postf=args.footer
    if args.start:
        minidx=args.start
    if args.stop:
        maxidx=args.stop
    if minidx == None:
        minidx=1
    if maxidx == None:
       maxidx=len(conformers)
    print("nconf=",len(conformers))
    for idx, mol in enumerate(conformers):
        if (idx+1) < minidx or (idx+1) > maxidx:
            continue
        fname = rootname + "_"+str(idx + 1)+".inp"
        fname=rootname+"/"+fname
        filestorun.append(fname[0:fname.rfind(".")])
        print(fname)
        wr = qmwriter.Writer(mol, fname, pre=sys.argv[2], post=postf)
        if args.charge:
            wr.SetCharge(args.charge)
        if args.multiplicity:
            wr.SetMultiplicity(args.multiplicity)

        wr.Write()
    #and now run
    for f in filestorun:
        print("f=",f)
        arguments=[]
        print("arguments=",arguments)
        print(platform.system())
        if platform.system() != "Windows":
            arguments.append("qmrun-orca6")
        else:
            arguments.append("powershell")
            arguments.append("qmrun-orca6.ps1")
        arguments.append(f)
        print(arguments)
        subprocess.call(arguments)


if __name__ == "__main__":
    Run()
