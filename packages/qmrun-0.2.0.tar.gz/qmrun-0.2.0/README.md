<h1 align="center"> qmrun </h1>

qmrun is a small python utility for running Orca6 computations all over the structures in a V2000 SDF file


<h2>Requirements </h2>
python3
rdkit

<h2>Installation  </h2>
pip install qmrun

<h2>Running qmrun </h2>
In windows qmrun must be run inside a powershell console. The orca.exe file should be in the path
In MacOS and Linux the orca executable file should be installed in $HOME/software/orca_6/orca





