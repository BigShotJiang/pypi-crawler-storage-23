"""Marginal slopes computation.

This module provides marginal slope computation for continuous focal variables.

Three strategies are available:
- **Coefficient extraction** (``compute_slopes``): fast path for Gaussian
  identity-link models without interactions involving the focal variable.
- **Finite differences** (``compute_slopes_finite_diff``): general path for
  GLMs and/or models with interactions.  Produces the Average Marginal Effect
  (AME) by building perturbed design matrices and averaging over a reference
  grid of factor-level combinations.
- **Conditional slopes** (``compute_conditional_slopes``): per-group slopes
  incorporating BLUPs for mixed models.

Internal exports:
    compute_slopes: Coefficient-extraction slopes (Gaussian identity, no interactions)
    compute_slopes_finite_diff: Finite-difference AME slopes
    compute_conditional_slopes: Per-group conditional slopes with BLUPs
"""

from __future__ import annotations

import re
import warnings
from typing import TYPE_CHECKING

import numpy as np
import polars as pl

from bossanova.internal.containers.builders.state import build_mee_state
from bossanova.internal.containers.structs.state import MeeState
from bossanova.internal.marginal.validation import validate_focal_var

if TYPE_CHECKING:
    from bossanova.internal.containers.structs.data import DataBundle
    from bossanova.internal.containers.structs.formula import FormulaSpec
    from bossanova.internal.containers.structs.specs import ModelSpec
    from bossanova.internal.containers.structs.state import FitState

__all__ = [
    "compute_conditional_slopes",
    "compute_slopes",
    "compute_slopes_crossed",
    "compute_slopes_finite_diff",
]


def compute_slopes(
    bundle: "DataBundle",
    fit: "FitState",
    focal_var: str,
    explore_formula: str,
    *,
    spec: object | None = None,
    effect_scale: str = "link",
) -> MeeState:
    """Compute marginal slope for a continuous focal variable.

    For a linear model, this extracts the coefficient for the variable.
    For models with interactions, this would need to average marginal
    effects across the grid (future enhancement).

    Marginal slopes answer: "By how much does the predicted outcome change
    for a one-unit increase in this variable?"

    Args:
        bundle: DataBundle with model data. Used to extract:
            - X_names: to locate the variable's coefficient index
        fit: FitState with fitted coefficients.
        focal_var: Name of the continuous variable to get slope for.
        explore_formula: The explore formula string (for result metadata).
        spec: ModelSpec with link/family info (for effect_scale="response").
        effect_scale: Scale of estimates: ``"link"`` or ``"response"``.

    Returns:
        MeeState with marginal slope estimate.

    Raises:
        ValueError: If focal_var not found in bundle.X_names.

    Examples:
        Compute marginal effect of age::

            from bossanova.internal.marginal import compute_slopes
            mee = compute_slopes(bundle, fit, "age", "age")
            # For y ~ age: returns MeeState with estimate = [coef_age]

    Note:
        This is the fast path for Gaussian identity-link models without
        interactions.  For models with interactions or GLMs (non-identity
        link), the dispatcher routes to ``compute_slopes_finite_diff``
        which handles both cases via centered finite differences.
    """
    validate_focal_var(bundle, focal_var)

    # Find the coefficient for this variable
    X_names = list(bundle.X_names)

    if focal_var not in X_names:
        raise ValueError(
            f"Variable '{focal_var}' not found in model coefficients. "
            f"Available: {X_names}"
        )

    idx = X_names.index(focal_var)
    slope = fit.coef[idx]

    # Create selector row for delta method inference
    # L_matrix selects the focal coefficient: L @ coef = coef[idx]
    n_coef = len(X_names)
    L_row = np.zeros((1, n_coef))
    L_row[0, idx] = 1.0

    estimate = np.array([slope])
    L_matrix = L_row

    if effect_scale == "response" and spec is not None and spec.link != "identity":
        from bossanova.internal.maths.family.links import apply_link_inverse_deriv

        # Compute η at reference point (population mean)
        X_means = bundle.X.mean(axis=0)
        eta_pop = X_means @ fit.coef

        # dμ/dη at population reference point
        d = np.asarray(apply_link_inverse_deriv(spec.link, np.array([eta_pop])))
        estimate = slope * d
        L_matrix = d[:, np.newaxis] * L_row

    # Create a single-row grid for the marginal slope
    grid = pl.DataFrame({focal_var: ["marginal_effect"]})

    return build_mee_state(
        grid=grid,
        estimate=estimate,
        explore_formula=explore_formula,
        focal_var=focal_var,
        mee_type="slopes",
        effect_scale=effect_scale,
        L_matrix=L_matrix,
    )


def compute_conditional_slopes(
    bundle: "DataBundle",
    fit: "FitState",
    focal_var: str,
    explore_formula: str,
    *,
    spec: object,
    varying_offsets: object,
    grouping_var: str,
    effect_scale: str = "link",
) -> MeeState:
    """Compute per-group conditional slopes incorporating BLUPs.

    For each group, the conditional slope is:
        slope_g = β_x + b_x_g  (random slopes model)
        slope_g = β_x           (random intercepts only)

    When effect_scale="response" and the link is non-identity, the
    response-scale slope is:
        slope_response_g = slope_link_g × dμ/dη(η_g)

    where η_g is the linear predictor at the reference point for group g.

    Args:
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        focal_var: Name of the continuous variable to get slopes for.
        explore_formula: The explore formula string (for result metadata).
        spec: ModelSpec with link function info.
        varying_offsets: VaryingState with BLUPs per group.
        grouping_var: Name of the grouping variable.
        effect_scale: Scale of estimates: ``"link"`` or ``"response"``.

    Returns:
        MeeState with per-group slope estimates.
    """
    from bossanova.internal.containers.structs.state import VaryingState

    validate_focal_var(bundle, focal_var)

    X_names = list(bundle.X_names)
    if focal_var not in X_names:
        raise ValueError(
            f"Variable '{focal_var}' not found in model coefficients. "
            f"Available: {X_names}"
        )

    idx = X_names.index(focal_var)
    beta_x = fit.coef[idx]

    # Get per-group random slope BLUPs (zero if RI-only model)
    assert isinstance(varying_offsets, VaryingState)
    n_groups = varying_offsets.n_groups
    b_x = varying_offsets.effects.get(focal_var, np.zeros(n_groups))

    # Link-scale slopes: β_x + b_x_g
    slopes_link = beta_x + b_x

    # Build L_matrix: each row selects β_x (BLUPs are not parameters)
    n_coef = len(X_names)
    L_matrix = np.zeros((n_groups, n_coef))
    L_matrix[:, idx] = 1.0

    estimates = slopes_link

    if effect_scale == "response" and spec.link != "identity":
        from bossanova.internal.maths.family.links import apply_link_inverse_deriv

        # Compute η_g at reference point for each group
        X_means = bundle.X.mean(axis=0)
        eta_pop = X_means @ fit.coef

        # Add group-specific BLUP contributions to η
        eta_g = np.full(n_groups, eta_pop)
        for effect_name, blups in varying_offsets.effects.items():
            if effect_name == "Intercept":
                eta_g += blups
            elif effect_name in X_names:
                # Add slope BLUP × mean of that covariate
                cov_idx = X_names.index(effect_name)
                eta_g += blups * X_means[cov_idx]

        # dμ/dη at each group's reference point
        d_g = apply_link_inverse_deriv(spec.link, eta_g)

        estimates = np.asarray(slopes_link * d_g)
        # Scale L_matrix rows for delta method
        L_matrix = np.asarray(d_g)[:, np.newaxis] * L_matrix

    # Build grid with group levels (grid has "group"/"level" columns)
    grid_levels = varying_offsets.grid["level"].to_list()
    grid = pl.DataFrame({grouping_var: grid_levels})

    return build_mee_state(
        grid=grid,
        estimate=estimates,
        explore_formula=explore_formula,
        focal_var=focal_var,
        mee_type="slopes",
        effect_scale=effect_scale,
        L_matrix=L_matrix,
    )


def compute_slopes_finite_diff(
    bundle: DataBundle,
    fit: FitState,
    focal_var: str,
    explore_formula: str,
    *,
    spec: ModelSpec,
    formula_spec: FormulaSpec,
    data: pl.DataFrame,
    how: str = "mem",
    effect_scale: str = "link",
    delta_frac: float = 0.001,
) -> MeeState:
    """Compute marginal slopes via centered finite differences.

    Supports two averaging methods via the ``how`` parameter:

    - ``"mem"``: Average over a balanced reference grid (Cartesian product
      of categorical levels, continuous covariates at means).  Matches R's
      ``emmeans::emtrends``.
    - ``"ame"``: Average over actual data rows.  Gives a true Average
      Marginal Effect (AME) that preserves the observed covariate distribution.

    For linear models (identity link), both approaches give identical results.

    Algorithm:
        1. ``delta = delta_frac × range(focal_var)``
        2. Build evaluation grid (balanced or observed data)
        3. Perturb: ``grid_plus = grid[focal + delta/2]``,
           ``grid_minus = grid[focal − delta/2]``
        4. ``X_plus, X_minus = evaluate_newdata(formula_spec, grid_*)``
        5. ``L_diff = (X_plus − X_minus) / delta``  (link-scale functional)
        6. If ``effect_scale="response"`` and ``how="ame"``:
           ``J_i = [f'(η_i+) X_i+ − f'(η_i−) X_i−] / delta``
           (per-observation Jacobian with f' at perturbed points)
        7. ``L_avg = mean(J, axis=0, keepdims=True)``

    Args:
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        focal_var: Continuous variable to compute the slope for.
        explore_formula: Explore formula string (for result metadata).
        spec: ModelSpec with family/link info.
        formula_spec: FormulaSpec with learned encoding for ``evaluate_newdata``.
        data: Raw model data (for computing ranges and covariate means).
        how: ``"mem"`` for balanced reference grid, ``"ame"`` for actual
            data rows.
        effect_scale: ``"link"`` (linear predictor scale) or ``"response"``
            (inverse-link / data scale).
        delta_frac: Fraction of the focal variable's range used as the
            finite-difference step size.  Default ``0.001`` matches R's
            ``emmeans``.

    Returns:
        MeeState with a single-row AME estimate and L_matrix for
        delta-method inference.

    Raises:
        ValueError: If the focal variable has zero range (constant column).
    """
    from bossanova.internal.maths.family.links import (
        apply_link_inverse,
        apply_link_inverse_deriv,
    )
    from bossanova.internal.formula.evaluate_newdata import evaluate_newdata

    validate_focal_var(bundle, focal_var)

    # --- drop rows with missing values in model variables -----------------
    # The caller may pass raw data that includes rows dropped during fitting.
    # Null/NaN values propagate through matrix multiplication and corrupt the
    # AME estimate, so filter to complete cases on the model's columns.
    model_cols = [c for c in bundle.X_names if c in data.columns]
    if bundle.y_name in data.columns:
        model_cols.append(bundle.y_name)
    data = data.drop_nulls(subset=model_cols)

    # --- step size --------------------------------------------------------
    focal_col = data[focal_var].cast(pl.Float64).to_numpy()
    var_range = float(focal_col.max() - focal_col.min())
    if var_range == 0.0:
        raise ValueError(
            f"Variable '{focal_var}' has zero range (constant column); "
            "cannot compute finite-difference slope."
        )
    delta = delta_frac * var_range

    # --- evaluation grid --------------------------------------------------
    # how="ame": use actual data rows (true AME)
    # how="mem": use balanced reference grid (emtrends-style)
    if how == "ame":
        # Use actual data rows, dropping the response column
        grid_cols = [c for c in data.columns if c != bundle.y_name]
        grid = data.select(grid_cols)
    else:
        grid = _build_slopes_data_grid(bundle, data)

    # --- perturbed grids --------------------------------------------------
    grid_plus = grid.with_columns(
        (pl.col(focal_var).cast(pl.Float64) + delta / 2).alias(focal_var)
    )
    grid_minus = grid.with_columns(
        (pl.col(focal_var).cast(pl.Float64) - delta / 2).alias(focal_var)
    )

    # --- design matrices --------------------------------------------------
    X_plus = evaluate_newdata(formula_spec, grid_plus, on_unseen_level="ignore")
    X_minus = evaluate_newdata(formula_spec, grid_minus, on_unseen_level="ignore")

    # --- response-scale Jacobian ------------------------------------------
    if effect_scale == "response" and spec.link != "identity":
        # Per-observation Jacobian: evaluate f' at perturbed points, not center.
        # J_i = [f'(η_i+) * X_i+ - f'(η_i-) * X_i-] / delta
        # This matches R's marginaleffects approach for correct AME SEs.
        eta_plus = X_plus @ fit.coef
        eta_minus = X_minus @ fit.coef
        d_plus = np.asarray(apply_link_inverse_deriv(spec.link, eta_plus))
        d_minus = np.asarray(apply_link_inverse_deriv(spec.link, eta_minus))
        L_response = (
            d_plus[:, np.newaxis] * X_plus - d_minus[:, np.newaxis] * X_minus
        ) / delta

        # Estimate = mean of per-observation response-scale predictions
        pred_plus = np.asarray(apply_link_inverse(spec.link, eta_plus))
        pred_minus = np.asarray(apply_link_inverse(spec.link, eta_minus))
        estimate = np.array([(pred_plus - pred_minus).mean() / delta])
    else:
        # Link-scale difference functional
        L_diff = (X_plus - X_minus) / delta  # (n_grid, n_coef)
        L_response = L_diff
        estimate = None  # computed from L_avg below

    # --- average across grid (AME) ----------------------------------------
    L_avg = L_response.mean(axis=0, keepdims=True)  # (1, n_coef)
    if estimate is None:
        estimate = (L_avg @ fit.coef).ravel()  # scalar AME

    # --- single-row result grid -------------------------------------------
    result_grid = pl.DataFrame({focal_var: ["marginal_effect"]})

    # For AME on response scale, use response-scale delta method directly
    # (no link/L_matrix_link back-transformation), matching EMM g-comp path.
    return build_mee_state(
        grid=result_grid,
        estimate=estimate,
        explore_formula=explore_formula,
        focal_var=focal_var,
        mee_type="slopes",
        how=how,
        effect_scale=effect_scale,
        L_matrix=L_avg,
        link=None,
        L_matrix_link=None,
    )


def compute_slopes_crossed(
    bundle: "DataBundle",
    fit: "FitState",
    focal_var: str,
    *,
    resolved: object,
    data: pl.DataFrame,
    spec: "ModelSpec | None" = None,
    formula_spec: "FormulaSpec | None" = None,
    effect_scale: str = "link",
    delta_frac: float = 0.001,
) -> MeeState:
    """Compute crossed slopes over focal variable x condition grid.

    Builds a Cartesian product of condition levels (grid categoricals,
    grid numerics, scalar pins) and computes a finite-difference AME
    for each combination.  Analogous to ``_compute_emm_crossed`` but
    for continuous focal variables.

    Args:
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        focal_var: Continuous variable to compute slopes for.
        resolved: ResolvedConditions with grid and scalar conditions.
        data: Raw model data (for computing ranges and covariate means).
        spec: ModelSpec with family/link info.
        formula_spec: FormulaSpec with learned encoding for ``evaluate_newdata``.
        effect_scale: ``"link"`` (linear predictor scale) or ``"response"``
            (inverse-link / data scale).
        delta_frac: Fraction of the focal variable's range used as the
            finite-difference step size.

    Returns:
        MeeState with one slope estimate per condition combination.

    Raises:
        ValueError: If the focal variable has zero range or formula_spec
            is missing.
    """
    from itertools import product as cartesian

    from bossanova.internal.maths.family.links import apply_link_inverse_deriv
    from bossanova.internal.formula.evaluate_newdata import evaluate_newdata

    validate_focal_var(bundle, focal_var)

    if formula_spec is None:
        raise ValueError(
            "formula_spec is required for crossed slope computation "
            "(needed by evaluate_newdata)."
        )

    # --- drop rows with missing values in model variables -----------------
    model_cols = [c for c in bundle.X_names if c in data.columns]
    if bundle.y_name in data.columns:
        model_cols.append(bundle.y_name)
    data = data.drop_nulls(subset=model_cols)

    # --- step size --------------------------------------------------------
    focal_col = data[focal_var].cast(pl.Float64).to_numpy()
    var_range = float(focal_col.max() - focal_col.min())
    if var_range == 0.0:
        raise ValueError(
            f"Variable '{focal_var}' has zero range (constant column); "
            "cannot compute finite-difference slope."
        )
    delta = delta_frac * var_range

    # --- collect grid variables and their levels/values -------------------
    grid_vars: list[str] = []
    grid_vals: list[list[object]] = []
    for var, levels in resolved.grid_categoricals.items():
        grid_vars.append(var)
        grid_vals.append(levels)
    for var, values in resolved.grid_numerics.items():
        grid_vars.append(var)
        grid_vals.append(values)

    grid_combos = list(cartesian(*grid_vals)) if grid_vals else [()]

    # --- build reference grid (Cartesian of all factor levels × means) ----
    base_grid = _build_slopes_data_grid(bundle, data)

    if resolved.at_overrides:
        unmatched = set(resolved.at_overrides) - set(base_grid.columns)
        if unmatched:
            warnings.warn(
                f"at-override keys {unmatched} don't match any model column; "
                f"overrides ignored. If the variable has a transform "
                f"(e.g. center(x)), use the raw name with "
                f"inverse_transforms=True (default).",
                stacklevel=4,
            )

    # --- compute one AME per condition combo ------------------------------
    L_rows: list[np.ndarray] = []
    result_data: dict[str, list[object]] = {focal_var: []}
    for gv in grid_vars:
        result_data[gv] = []

    for combo in grid_combos:
        # Apply conditions to the base grid for this combo
        combo_grid = base_grid.clone()

        # Apply scalar categorical pins (set_categoricals)
        for cat_var, cat_val in resolved.set_categoricals.items():
            if cat_var in combo_grid.columns:
                combo_grid = combo_grid.filter(pl.col(cat_var) == cat_val)

        # Apply scalar numeric overrides (at_overrides)
        for num_var, num_val in resolved.at_overrides.items():
            if num_var in combo_grid.columns:
                combo_grid = combo_grid.with_columns(
                    pl.lit(num_val).cast(pl.Float64).alias(num_var)
                )

        # Apply this combo's conditions
        for i, gv in enumerate(grid_vars):
            val = combo[i]
            if isinstance(val, str):
                # Categorical: filter rows to this level
                if gv in combo_grid.columns:
                    combo_grid = combo_grid.filter(pl.col(gv) == val)
            else:
                # Numeric: override column value
                if gv in combo_grid.columns:
                    combo_grid = combo_grid.with_columns(pl.lit(float(val)).alias(gv))

        # If filtering emptied the grid, skip
        if len(combo_grid) == 0:
            continue

        # Perturb focal variable ± delta/2
        grid_plus = combo_grid.with_columns(
            (pl.col(focal_var).cast(pl.Float64) + delta / 2).alias(focal_var)
        )
        grid_minus = combo_grid.with_columns(
            (pl.col(focal_var).cast(pl.Float64) - delta / 2).alias(focal_var)
        )

        # Build design matrices
        X_plus = evaluate_newdata(formula_spec, grid_plus, on_unseen_level="ignore")
        X_minus = evaluate_newdata(formula_spec, grid_minus, on_unseen_level="ignore")

        # Link-scale difference functional
        L_diff = (X_plus - X_minus) / delta  # (n_grid, n_coef)

        # Response-scale transform (if needed)
        if effect_scale == "response" and spec is not None and spec.link != "identity":
            # Per-observation Jacobian at perturbed points (not center)
            eta_plus = X_plus @ fit.coef
            eta_minus = X_minus @ fit.coef
            d_plus = np.asarray(apply_link_inverse_deriv(spec.link, eta_plus))
            d_minus = np.asarray(apply_link_inverse_deriv(spec.link, eta_minus))
            L_response = (
                d_plus[:, np.newaxis] * X_plus - d_minus[:, np.newaxis] * X_minus
            ) / delta
        else:
            L_response = L_diff

        # Average across grid rows for this combo → one L row
        L_avg = L_response.mean(axis=0)  # (n_coef,)
        L_rows.append(L_avg)

        # Record condition values
        result_data[focal_var].append("marginal_effect")
        for i, gv in enumerate(grid_vars):
            result_data[gv].append(combo[i])

    # --- stack into L_matrix and compute estimates ------------------------
    L_matrix = np.stack(L_rows, axis=0)  # (n_combos, n_coef)
    estimates = (L_matrix @ fit.coef).ravel()

    # --- build result grid ------------------------------------------------
    result_grid = pl.DataFrame(result_data)
    if grid_vars:
        result_grid = result_grid.select(
            grid_vars + [c for c in result_grid.columns if c not in grid_vars]
        )

    cond_str = " ~ " + ", ".join(grid_vars) if grid_vars else ""
    return build_mee_state(
        grid=result_grid,
        estimate=estimates,
        explore_formula=f"{focal_var}{cond_str}",
        focal_var=focal_var,
        mee_type="slopes",
        effect_scale=effect_scale,
        L_matrix=L_matrix,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_slopes_data_grid(
    bundle: DataBundle,
    data: pl.DataFrame,
) -> pl.DataFrame:
    """Build a reference grid for finite-difference slope evaluation.

    Constructs a Cartesian product of all categorical factor levels
    (from ``bundle.factor_levels``) with continuous predictors set to
    their column means.  The response variable (``bundle.y_name``) is
    excluded.

    Args:
        bundle: DataBundle with ``factor_levels``, ``X_names``, ``y_name``.
        data: Raw data DataFrame for computing column means.

    Returns:
        Polars DataFrame with one row per grid point.
    """
    from bossanova.internal.marginal.grid import build_cartesian_product

    factor_levels = bundle.factor_levels or {}

    # Categorical part — Cartesian product of all factor levels
    cat_dict: dict[str, list[str]] = {
        name: list(levels) for name, levels in factor_levels.items()
    }

    grid = (
        build_cartesian_product(cat_dict) if cat_dict else pl.DataFrame({"_dummy": [0]})
    )

    # Continuous part — each numeric predictor at its column mean
    # Collect the raw variable names that appear in X_names (strip
    # interaction markers; interactions are rebuilt by evaluate_newdata).
    raw_numeric_vars: set[str] = set()
    for xname in bundle.X_names:
        if xname == "Intercept":
            continue
        # Interaction columns like "x:treatmentB" contain ":"
        parts = xname.split(":")
        for part in parts:
            # Skip levels that look like factor encodings (e.g. "treatmentB")
            if part not in factor_levels and part in data.columns:
                raw_numeric_vars.add(part)
            elif part not in factor_levels:
                # Unwrap transform names like "center(x)" → "x"
                m = re.match(r"^\w+\((.+)\)$", part)
                if m and m.group(1) in data.columns:
                    raw_numeric_vars.add(m.group(1))

    # Remove the response variable
    raw_numeric_vars.discard(bundle.y_name)

    for var in sorted(raw_numeric_vars):
        col = data[var]
        if col.dtype in (pl.Utf8, pl.Categorical):
            continue
        mean_val = float(col.cast(pl.Float64).mean())  # type: ignore[arg-type]
        grid = grid.with_columns(pl.lit(mean_val).alias(var))

    # Drop dummy column if it was used
    if "_dummy" in grid.columns:
        grid = grid.drop("_dummy")

    return grid


def _has_focal_interaction(
    focal_var: str, X_names: tuple[str, ...] | list[str]
) -> bool:
    """Check whether ``focal_var`` participates in any interaction term.

    Args:
        focal_var: Name of the focal continuous variable.
        X_names: Design matrix column names (may contain ``"a:b"`` interaction terms).

    Returns:
        True if any X_name is an interaction (contains ``":"``) that includes
        ``focal_var`` as one of the interacting terms.
    """
    return any(":" in name and focal_var in name.split(":") for name in X_names)
