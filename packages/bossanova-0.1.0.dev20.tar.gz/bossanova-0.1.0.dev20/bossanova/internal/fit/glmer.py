"""GLMM fitting via Penalized IRLS (PIRLS)."""

from __future__ import annotations

import numpy as np
import scipy.sparse as sp

from bossanova.internal.containers import (
    DataBundle,
    FitState,
    ModelSpec,
    build_fit_state,
)
from bossanova.internal.maths.inference.diagnostics import compute_leverage
from bossanova.internal.maths.family import create_family
from bossanova.internal.maths.linalg.schur import compute_vcov_schur_sparse

__all__ = [
    "fit_glmer_pirls",
]


def fit_glmer_pirls(
    spec: ModelSpec,
    bundle: DataBundle,
    *,
    max_iter: int = 25,
    max_outer_iter: int = 10000,
    tol: float = 1e-7,
    verbose: bool = False,
    nAGQ: int = 1,
    use_hessian: bool = False,
) -> FitState:
    """Fit generalized linear mixed model using Penalized IRLS.

    This adapter wraps the PIRLS implementation from bossanova.internal.maths.solvers.glmer.
    PIRLS combines IRLS (for the GLM part) with PLS (for random effects),
    using Laplace approximation to integrate out the random effects.

    Algorithm:
        Outer loop (BOBYQA optimization over theta):
            For each theta:
            1. Build Lambda from theta

            Inner loop (PIRLS iterations):
                a. Compute working weights from current eta/mu
                b. Compute working response
                c. Solve weighted PLS for beta and u
                d. Update eta = X @ beta + Z @ Lambda @ u
                e. Update mu = g^{-1}(eta)
                f. Step-halving if deviance increased
                g. Check convergence

            2. Return Laplace deviance

        Select theta minimizing Laplace deviance

    Args:
        spec: Model specification containing:
            - family: Distribution family
            - link: Link function
            - random_terms: Parsed random effect specifications
        bundle: Data bundle containing:
            - X: Fixed effects design matrix
            - Z: Random effects design matrix (sparse)
            - y: Response vector
            - re_metadata: Grouping structure
        max_iter: Maximum PIRLS iterations per theta (default: 25).
        max_outer_iter: Maximum BOBYQA iterations (default: 10000).
        tol: PIRLS convergence tolerance (default: 1e-7).
        verbose: Print optimization progress (default: False).
        nAGQ: Quadrature points (0 or 1, default: 1).
        use_hessian: Use Hessian-based vcov (default: False). The default
            Schur complement approach matches lme4's ``vcov()`` with
            ``use.hessian=FALSE`` and avoids expensive numerical
            differentiation. Set to True for observed-information vcov.

    Returns:
        FitState containing:
            - coef: Fixed effect coefficient estimates
            - vcov: Variance-covariance (observed information or Schur complement)
            - fitted: Predicted values on response scale (mu)
            - residuals: Response residuals (y - mu)
            - leverage: Approximate leverage values
            - df_resid: Residual degrees of freedom
            - loglik: Laplace-approximated log-likelihood
            - dispersion: Dispersion (1.0 for binomial/poisson)
            - theta: Optimized relative covariance parameters
            - u: Spherical random effects
            - converged: Whether both PIRLS and BOBYQA converged
            - n_iter: Number of optimizer evaluations

    See Also:
        - bossanova.internal.maths.solvers.glmer: Underlying PIRLS implementation
    """
    from bossanova.internal.maths.solvers.glmer import (
        compute_irls_quantities,
        fit_glmm_pirls,
    )
    from bossanova.internal.maths.solvers.lambda_builder import build_lambda_sparse

    # Extract data from bundle
    X = bundle.X
    y = bundle.y
    Z = bundle.Z

    if Z is None:
        raise ValueError(
            "Z matrix is required for GLMER fitting. "
            "Ensure the formula contains random effects and data is properly prepared."
        )

    # Ensure Z is CSC format
    if not sp.isspmatrix_csc(Z):
        Z = Z.tocsc()

    # Extract RE metadata
    re_meta = bundle.re_metadata
    if re_meta is None:
        raise ValueError(
            "re_metadata is required for GLMER fitting. "
            "Ensure the DataBundle was built with random effects information."
        )

    n, p = X.shape
    n_groups_list = re_meta.n_groups_list
    re_structure = re_meta.re_structure
    metadata = re_meta.metadata

    # Create Family object from spec
    # GLMER supports binomial, poisson, and gamma. For Gaussian, use lmer.
    if spec.family == "gaussian":
        raise ValueError(
            "Gaussian family is not supported for GLMER. Use lmer instead."
        )

    family = create_family(spec.family, spec.link)

    weights = bundle.weights

    # Validate nAGQ > 1 restrictions: scalar random intercept only
    if nAGQ > 1:
        if re_structure != "intercept" or len(n_groups_list) != 1:
            raise ValueError(
                f"nAGQ={nAGQ} requires a single scalar random intercept "
                f"(e.g., '(1|group)'). Models with random slopes or "
                f"crossed/nested random effects must use nAGQ=0 or nAGQ=1."
            )

    # Pass group_ids when nAGQ > 1 for per-group quadrature
    group_ids = re_meta.group_ids_list[0] if nAGQ > 1 else None

    # Fit the model using two-stage PIRLS + BOBYQA optimization
    fit_result = fit_glmm_pirls(
        X=X,
        Z=Z,
        y=y,
        family=family,
        n_groups_list=n_groups_list,
        re_structure=re_structure,
        metadata=metadata,
        prior_weights=weights,
        max_outer_iter=max_outer_iter,
        pirls_max_iter=max_iter,
        pirls_tol=tol,
        verbose=verbose,
        two_stage=(nAGQ >= 1),  # nAGQ=0 skips Stage 2 for faster fitting
        nAGQ=nAGQ,
        group_ids=group_ids,
    )

    # Extract results
    theta = fit_result["theta"]
    beta = fit_result["beta"]
    u = fit_result["u"]
    eta = fit_result["eta"]
    mu = fit_result["mu"]
    loglik = fit_result["loglik"]
    converged = fit_result["converged"]
    n_iter = fit_result["n_func_evals"]

    # Compute IRLS weights once (needed by both vcov paths and for XtWX_inv)
    working_weights, _ = compute_irls_quantities(y, eta, family)
    if weights is not None:
        total_weights = weights * working_weights
    else:
        total_weights = working_weights

    # Compute variance-covariance matrix of beta
    if use_hessian:
        from bossanova.internal.maths.solvers.glmer import compute_hessian_vcov

        vcov, _ = compute_hessian_vcov(
            theta=theta,
            beta=beta,
            X=X,
            Z=Z,
            y=y,
            family=family,
            n_groups_list=n_groups_list,
            re_structure=re_structure,
            metadata=metadata,
            prior_weights=weights,
            pirls_max_iter=max_iter,
            pirls_tol=tol,
            eta_init=eta,  # Use optimal eta as starting point
        )
    else:
        # Schur complement-based vcov (analytical, matches lme4 vcov(use.hessian=FALSE))
        Lambda = build_lambda_sparse(theta, n_groups_list, re_structure, metadata)
        vcov = compute_vcov_schur_sparse(X, Z, Lambda, weights=total_weights)

    # Compute fitted values and residuals
    fitted = mu
    residuals = y - mu

    # Compute approximate leverage (diagonal of hat matrix for fixed effects)
    leverage = compute_leverage(X)

    # Degrees of freedom
    df_resid = float(n - p)

    # XtWX_inv for sandwich/cluster-robust SEs (reuse total_weights)
    XtWX = X.T @ (X * total_weights[:, np.newaxis])
    XtWX_inv = np.linalg.inv(XtWX)

    return build_fit_state(
        coef=beta,
        vcov=vcov,
        fitted=fitted,
        residuals=residuals,
        leverage=leverage,
        df_resid=df_resid,
        loglik=loglik,
        dispersion=1.0,  # Fixed at 1.0 for binomial/poisson
        theta=theta,
        u=u,
        converged=converged,
        n_iter=n_iter,
        irls_weights=total_weights,
        XtWX_inv=XtWX_inv,
    )
