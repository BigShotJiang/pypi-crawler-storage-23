#!/usr/bin/env python3
from ldap3.extend.standard.PagedSearch import paged_search_generator, paged_search_accumulator
from powerview.lib.adws.extend.standard.PagedSearch import adws_paged_search_generator, adws_paged_search_accumulator
from ldap3.extend import StandardExtendedOperations, ExtendedOperationsRoot
from ldap3 import SUBTREE, DEREF_ALWAYS
from .obfuscate import (
	FilterParser,
	DNParser,
	AttributeParser,
	LdapObfuscate
)

import logging
from powerview.utils.storage import Storage
from powerview.modules.vulnerabilities import VulnerabilityDetector
from powerview.utils.helpers import strip_entry
from powerview.utils.hints import patch_ldap3_exceptions

# Patch ldap3's LDAPOperationResult to include error hints
patch_ldap3_exceptions()

class CustomStandardExtendedOperations(StandardExtendedOperations):
	def __init__(self, connection, server=None, obfuscate=False, no_cache=False, no_vuln_check=False, use_adws=False, raw=False):
		super().__init__(connection)
		self.server = server
		self.obfuscate = obfuscate
		self.no_cache = no_cache
		self.no_vuln_check = no_vuln_check
		self.use_adws = use_adws
		self.raw = raw
		self.storage = Storage()
		self.vulnerability_detector = VulnerabilityDetector(self.storage)
	
	def _format_vulnerability(self, vuln_dict):
		"""Format a vulnerability dictionary as a string"""
		vuln_id = vuln_dict.get('id', 'VULN')
		description = vuln_dict.get('description', '')
		sev_colored = vuln_dict.get('severity_colored')
		if sev_colored:
			formatted = f"[{vuln_id}] {description} ({sev_colored})"
		else:
			severity = vuln_dict.get('severity', '').upper()
			formatted = f"[{vuln_id}] {description} ({severity})"
		if 'details' in vuln_dict:
			formatted += f" - {vuln_dict['details']}"
		return formatted

	def paged_search(self,
					 search_base,
					 search_filter,
					 search_scope=SUBTREE,
					 dereference_aliases=DEREF_ALWAYS,
					 attributes=None,
					 size_limit=0,
					 time_limit=0,
					 types_only=False,
					 get_operational_attributes=False,
					 controls=None,
					 paged_size=100,
					 paged_criticality=False,
					 generator=True,
					 no_cache=False,
					 no_vuln_check=False,
					 strip_entries=True,
					 raw=False):
		
		no_cache = no_cache or self.no_cache
		no_vuln_check = no_vuln_check or self.no_vuln_check
		raw = raw or self.raw

		original_formatter = None
		if raw and self.server and hasattr(self.server, 'custom_formatter'):
			logging.debug("[CustomStandardExtendedOperations] Unsetting custom formatter")
			original_formatter = self.server.custom_formatter
			self.server.custom_formatter = None

		try:
			if not no_cache:
				cached_results = self.storage.get_cached_results(search_base, search_filter, search_scope, attributes, host=self.server.host, raw=raw)
				if cached_results is not None:
					logging.debug("[CustomStandardExtendedOperations] Returning cached results for query")
					
					for entry in cached_results:
						if 'attributes' in entry:
							entry['from_cache'] = True
					
					if not no_vuln_check:
						for entry in cached_results:
							if 'attributes' in entry:
								vulnerabilities = self.vulnerability_detector.detect_vulnerabilities(entry['attributes'])
								if vulnerabilities:
									entry['attributes']['vulnerabilities'] = [self._format_vulnerability(v) for v in vulnerabilities]
					
					return cached_results
			
			modified_filter = search_filter
			modified_dn = search_base
			modified_attributes = attributes

			if self.obfuscate:
				parser = FilterParser(search_filter)
				parser.parse()

				# OID: converts attr names to OID dotted notation + trailing spaces.
				# max_zeros=0, include_prefix=False because ldap3 rejects OID zero-padding
				# and the "oID." prefix. Only attr-to-OID conversion + spacing is effective.
				parser.oid_attribute_obfuscation(max_spaces=3, max_zeros=0, include_prefix=False)
				parser.random_casing(probability=0.7)

				parser.prepend_zeros_obfuscation(max_zeros=5)
				parser.hex_value_obfuscation(probability=0.5)
				parser.spacing_obfuscation(max_spaces=3)

				# NOTE: ~= (approximate match) changes query semantics — may return
				# broader results than exact equality. This is intentional for evasion.
				parser.equality_to_approximation_obfuscation()
				parser.wildcard_expansion_obfuscation()

				parser.anr_attribute_obfuscation()

				parser.random_spacing()

				modified_filter = parser.convert_to_ldap()
				logging.debug("[CustomStandardExtendedOperations] Modified Filter: {}".format(modified_filter))

				dn_parser = DNParser(search_base)
				dn_parser.parse()
				dn_parser.dn_hex()
				dn_parser.dn_randomcase()
				dn_parser.random_spacing()
				modified_dn = dn_parser.convert_to_dn()
				logging.debug("[CustomStandardExtendedOperations] Modified DN: {}".format(modified_dn))

				attribute_parser = AttributeParser(attributes)
				attribute_parser.random_oid()
				attribute_parser.random_casing()
				modified_attributes = attribute_parser.get_attributes()
				logging.debug("[CustomStandardExtendedOperations] Modified Attributes: {}".format(modified_attributes))

			if generator:
				if self.use_adws:
					results = list(adws_paged_search_generator(self._connection, modified_dn, modified_filter, search_scope, modified_attributes, size_limit, time_limit, types_only, get_operational_attributes, controls, paged_size, paged_criticality))
				else:
					results = list(paged_search_generator(self._connection,
												modified_dn,
												modified_filter,
												search_scope,
												dereference_aliases,
												modified_attributes,
												size_limit,
												time_limit,
												types_only,
												get_operational_attributes,
												controls,
												paged_size,
												paged_criticality))
			else:
				if self.use_adws:
					results = list(adws_paged_search_accumulator(
						self._connection,
						modified_dn,
						modified_filter,
						search_scope,
						modified_attributes,
						size_limit,
						time_limit,
						types_only,
						get_operational_attributes,
						controls,
						paged_size,
						paged_criticality
					))
				else:
					results = list(paged_search_accumulator(
						self._connection,
						modified_dn,
						modified_filter,
						search_scope,
						dereference_aliases,
						modified_attributes,
						size_limit,
						time_limit,
						types_only,
						get_operational_attributes,
						controls,
						paged_size,
						paged_criticality
					))

			filtered_results = []
			for entry in results:
				if entry.get('type') != 'searchResEntry':
					continue

				if strip_entries:
					strip_entry(entry)

				filtered_results.append(entry)

			if not no_vuln_check:
				for entry in filtered_results:
					if 'attributes' in entry:
						vulnerabilities = self.vulnerability_detector.detect_vulnerabilities(entry['attributes'])
						if vulnerabilities:
							entry['attributes']['vulnerabilities'] = [self._format_vulnerability(v) for v in vulnerabilities]

			if not no_cache:
				for entry in filtered_results:
					if 'attributes' in entry and 'from_cache' in entry['attributes']:
						del entry['attributes']['from_cache']

				self.storage.cache_results(search_base, search_filter, search_scope, attributes, host=self.server.host, results=filtered_results, raw=raw)
			return filtered_results
		finally:
			if raw and original_formatter is not None and self.server:
				self.server.custom_formatter = original_formatter

class CustomExtendedOperationsRoot(ExtendedOperationsRoot):
	def __init__(self, connection, server=None, obfuscate=False, no_cache=False, no_vuln_check=False, use_adws=False, raw=False):
		super().__init__(connection)
		self.standard = CustomStandardExtendedOperations(self._connection, server, obfuscate, no_cache, no_vuln_check, use_adws, raw)
