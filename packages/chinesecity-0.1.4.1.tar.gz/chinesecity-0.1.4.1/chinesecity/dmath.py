from math import *
from functools import reduce
def dgcd(*数组):
    return reduce(gcd,数组)
def dlcm(*数组):
    return reduce(lcm,数组)
def factorial(*nums):
    def single_factorial(n):
        if not isinstance(n, int) or n < 0:
            raise ValueError(f"{n} 不是非负整数，无法计算阶乘")
        return 1 if n == 0 else n * single_factorial(n - 1)
    
    return [single_factorial(n) for n in nums]
