__version__ = "0.1.4"

from .devecho import dprint,fdprint,dinput,fdinput
from .devert import fanyi
from .devebox import password
from .dmath import dgcd,dlcm,factorial
