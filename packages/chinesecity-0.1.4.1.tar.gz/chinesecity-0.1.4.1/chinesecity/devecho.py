import time
def search_rainbow(索引):    
    颜色列表 = [
        '\033[91m',  # 红色
        '\033[93m',  # 黄色
        '\033[92m',  # 绿色
        '\033[94m',  # 蓝色
        '\033[95m',  # 紫色
        '\033[96m'   # 青色
        '\033[97m'   # 白色
    ]
    return 颜色列表[索引 % len(颜色列表)]
def dprint(文本, 延迟=0.01):
    for 索引, 字符 in enumerate(文本):
        颜色 = search_rainbow(索引)
        print(f"{颜色}{字符}", end='', flush=True)
        time.sleep(延迟)
    # 重置颜色
    print('\033[0m')
    
def fdprint(文本, 延迟=0.00000000000001):
    for 索引, 字符 in enumerate(文本):
        颜色 = search_rainbow(索引)
        print(f"{颜色}{字符}", end='', flush=True)
        time.sleep(延迟)
    print('\033[0m')
def dinput(text):
    dprint(text)
    输入=input()
    return 输入
    
def fdinput(text):
    fdprint(text)
    输入=input()
    return 输入
