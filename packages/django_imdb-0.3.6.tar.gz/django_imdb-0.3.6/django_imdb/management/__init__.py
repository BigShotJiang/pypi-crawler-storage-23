"""Management commands for django-imdb."""
