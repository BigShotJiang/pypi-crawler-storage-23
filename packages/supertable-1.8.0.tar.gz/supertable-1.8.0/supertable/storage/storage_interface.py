import abc
from typing import Any, Dict, List, Optional
import pyarrow as pa

class StorageInterface(abc.ABC):
    """
    Abstract base class for a storage interface that can handle both local and
    cloud/object storage in a unified manner.
    """


    @abc.abstractmethod
    def read_json(self, path: str) -> Dict[str, Any]:
        """
        Reads and returns JSON data from the given path.
        Raises FileNotFoundError, ValueError, etc. on error.
        """
        pass

    @abc.abstractmethod
    def write_json(self, path: str, data: Dict[str, Any]) -> None:
        """
        Writes JSON data to the given path.
        Overwrites if it already exists.
        """
        pass

    @abc.abstractmethod
    def exists(self, path: str) -> bool:
        """
        Returns True if the given path exists, False otherwise.
        For cloud storage, 'path' might be a prefix / object key.
        """
        pass

    @abc.abstractmethod
    def size(self, path: str) -> int:
        """
        Returns the size (in bytes) of the object at the given path.
        Raises FileNotFoundError if not found.
        """
        pass

    @abc.abstractmethod
    def makedirs(self, path: str) -> None:
        """
        Creates directories (or the equivalent in cloud storage) if needed.
        No-op if already present.
        """
        pass

    @abc.abstractmethod
    def list_files(self, path: str, pattern: str = "*") -> List[str]:
        """
        Returns a list of files/objects found in `path` matching the given pattern.
        This may be limited to a single "directory" level, depending on implementation.
        For recursive scans, either extend with a `recursive=True` parameter or
        provide an additional method.
        """
        pass

    @abc.abstractmethod
    def delete(self, path: str) -> None:
        """
        Deletes a file/object at the given path.
        Raises FileNotFoundError if the path does not exist.
        """
        pass

    @abc.abstractmethod
    def get_directory_structure(self, path: str) -> dict:
        """
        Recursively builds and returns a nested dictionary representing
        the folder structure under 'path'. For local storage, uses os.walk.
        For S3/MinIO, lists objects by prefix. The dictionary format might look like:
            {
                "subfolderA": {
                    "file1.parquet": None,
                    "file2.json": None
                },
                "subfolderB": {
                    "nested": {
                        "file3.parquet": None
                    }
                }
            }
        """
        pass

    @abc.abstractmethod
    def write_parquet(self, table: pa.Table, path: str) -> None:
        """
        Writes a PyArrow table to the given path (local or cloud/object storage) in Parquet format.
        For local, use pyarrow.parquet.write_table.
        For cloud, you may rely on s3fs or a custom upload method.
        """
        pass

    @abc.abstractmethod
    def read_parquet(self, path: str) -> pa.Table:
        """
        Reads and returns a PyArrow Table from the given Parquet path.
        Raises FileNotFoundError, ValueError, etc. on error.
        """
        pass

    # -------------------------
    # Byte / text / copy operations
    # -------------------------
    @abc.abstractmethod
    def write_bytes(self, path: str, data: bytes) -> None:
        """
        Writes raw bytes to the given path.
        Creates parent directories/prefixes as needed.
        """
        pass

    @abc.abstractmethod
    def read_bytes(self, path: str) -> bytes:
        """
        Reads and returns raw bytes from the given path.
        Raises FileNotFoundError if the path does not exist.
        """
        pass

    @abc.abstractmethod
    def write_text(self, path: str, text: str, encoding: str = "utf-8") -> None:
        """
        Writes a string to the given path using the specified encoding.
        """
        pass

    @abc.abstractmethod
    def read_text(self, path: str, encoding: str = "utf-8") -> str:
        """
        Reads and returns text from the given path using the specified encoding.
        Raises FileNotFoundError if the path does not exist.
        """
        pass

    @abc.abstractmethod
    def copy(self, src_path: str, dst_path: str) -> None:
        """
        Copies an object from src_path to dst_path within the same storage backend.
        """
        pass

    # -------------------------
    # Optional parity helpers (object stores)
    # -------------------------
    def to_duckdb_path(self, key: str, prefer_httpfs: Optional[bool] = None) -> str:
        """
        Return a path usable by DuckDB readers.

        Implementations may return either:
        - s3://bucket/key
        - http(s)://... URLs (when prefer_httpfs=True)
        """
        raise NotImplementedError(f"{self.__class__.__name__} does not implement to_duckdb_path()")

    def presign(self, key: str, expiry_seconds: int = 3600) -> str:
        """
        Return a presigned GET URL for the object.
        """
        raise NotImplementedError(f"{self.__class__.__name__} does not implement presign()")