# Copyright (c) 2025 Airbyte, Inc., all rights reserved.
"""CI-side script for the human-in-the-loop escalation workflow.

This module runs inside GitHub Actions to resolve person identifiers to
Slack user IDs (using the roster artifact) and post a formatted Block Kit
message to the ``#human-in-the-loop`` Slack channel.

It is invoked by the ``human-in-the-loop.yml`` workflow and should NOT be
imported at MCP runtime. The Slack token (``SLACK_BOT_TOKEN_HITL``) is only
available in CI.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from urllib.parse import urlparse

import requests

_SLACK_ID_PATTERN = re.compile(r"^U[A-Z0-9]{8,}$")


def _load_roster(roster_file: str) -> list[dict[str, str | int | None]]:
    """Load the roster JSON file.

    Handles both the raw list format and the ``{"members": [...]}`` wrapper.
    """
    with open(roster_file) as f:
        data = json.load(f)

    if isinstance(data, dict) and "members" in data:
        return data["members"]
    if isinstance(data, list):
        return data
    return []


def _resolve_to_slack_id(
    identifier: str,
    roster: list[dict[str, str | int | None]],
) -> str | None:
    """Resolve a person identifier to a Slack user ID using the roster.

    Tries matching against email, GitHub handle, and Slack ID fields.

    Returns:
        Slack user ID string if found, None otherwise.
    """
    identifier = identifier.strip()
    if identifier.startswith("@"):
        identifier = identifier[1:]
        if not identifier:
            return None

    if _SLACK_ID_PATTERN.match(identifier):
        return identifier

    identifier_lower = identifier.lower()

    for person in roster:
        slack_email = person.get("slack_email")
        if (
            slack_email
            and isinstance(slack_email, str)
            and slack_email.lower() == identifier_lower
        ):
            slack_id = person.get("slack_id")
            if slack_id and isinstance(slack_id, str):
                return slack_id

        github_handle = person.get("github_handle")
        if (
            github_handle
            and isinstance(github_handle, str)
            and github_handle.lower() == identifier_lower
        ):
            slack_id = person.get("slack_id")
            if slack_id and isinstance(slack_id, str):
                return slack_id

        github_email = person.get("github_public_email")
        if (
            github_email
            and isinstance(github_email, str)
            and github_email.lower() == identifier_lower
        ):
            slack_id = person.get("slack_id")
            if slack_id and isinstance(slack_id, str):
                return slack_id

    return None


def _format_mention(identifier: str, slack_id: str | None) -> str:
    """Format a person as a Slack mention or fallback plain text."""
    if slack_id:
        return f"<@{slack_id}>"
    return f"`{identifier}` (could not resolve to Slack)"


def _derive_agent_name(agent_session_url: str) -> str:
    """Derive an agent display name from the session URL.

    For ``https://app.devin.ai/sessions/...`` returns ``Devin.ai``.
    Falls back to the full hostname if the domain has fewer than two parts.
    """
    hostname = urlparse(agent_session_url).hostname or ""
    parts = hostname.rsplit(".", 2)
    if len(parts) >= 2:
        base = f"{parts[-2]}.{parts[-1]}"
        return base[0].upper() + base[1:]
    return hostname.capitalize() if hostname else "Agent"


def _build_slack_blocks(
    target_person: str,
    target_slack_id: str | None,
    cc_mentions: list[str],
    message: str,
    agent_session_url: str,
    pr_url: str | None,
    issue_url: str | None,
    additional_actions: dict[str, str] | None,
    sender_name: str = "Agent (No-Reply)",
) -> list[dict]:
    """Build Slack Block Kit blocks for the escalation message."""
    blocks: list[dict] = []

    target_mention = _format_mention(target_person, target_slack_id)
    to_line = f":man-raising-hand: *Human-in-the-loop request for {target_mention}:*"
    if cc_mentions:
        to_line += f"\n*CC:* {', '.join(cc_mentions)}"

    blocks.append(
        {
            "type": "section",
            "text": {"type": "mrkdwn", "text": to_line},
        }
    )

    blocks.append({"type": "divider"})

    blocks.append(
        {
            "type": "section",
            "text": {"type": "mrkdwn", "text": message},
        }
    )

    blocks.append({"type": "divider"})

    buttons: list[dict] = []
    if pr_url:
        buttons.append(
            {
                "type": "button",
                "text": {"type": "plain_text", "text": "View PR", "emoji": True},
                "url": pr_url,
                "action_id": "view_pr",
            }
        )
    if issue_url:
        buttons.append(
            {
                "type": "button",
                "text": {"type": "plain_text", "text": "View Issue", "emoji": True},
                "url": issue_url,
                "action_id": "view_issue",
            }
        )
    if additional_actions:
        for label, url in additional_actions.items():
            buttons.append(
                {
                    "type": "button",
                    "text": {
                        "type": "plain_text",
                        "text": label[:75],
                        "emoji": True,
                    },
                    "url": url,
                    "action_id": f"extra_{label[:50]}",
                }
            )

    if buttons:
        buttons[0]["style"] = "primary"
        blocks.append({"type": "actions", "elements": buttons})

    blocks.append(
        {
            "type": "context",
            "elements": [
                {
                    "type": "mrkdwn",
                    "text": (
                        f"Sent by *{sender_name}* from <{agent_session_url}|this session>. "
                        "Please respond in the linked session or PR, not in this thread."
                    ),
                }
            ],
        }
    )

    return blocks


def _post_slack_message(
    token: str,
    channel: str,
    blocks: list[dict],
    fallback_text: str,
    username: str | None = None,
) -> None:
    """Post a message to Slack using the Web API."""
    payload: dict = {
        "channel": channel,
        "blocks": blocks,
        "text": fallback_text,
    }
    if username:
        payload["username"] = username
    response = requests.post(
        "https://slack.com/api/chat.postMessage",
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json; charset=utf-8",
        },
        json=payload,
        timeout=30,
    )
    response.raise_for_status()
    data = response.json()
    if not data.get("ok"):
        raise RuntimeError(f"Slack API error: {data.get('error', 'unknown')}")

    print(f"Message posted to #{channel} successfully.", file=sys.stderr)


def main() -> None:
    """CLI entrypoint for the CI-side HITL script."""
    parser = argparse.ArgumentParser(
        description="Resolve person identifiers and post HITL escalation to Slack."
    )
    parser.add_argument(
        "--roster-file", required=True, help="Path to roster JSON file."
    )
    parser.add_argument(
        "--target-person",
        required=True,
        help="Primary person identifier (email, GitHub handle, or Slack ID).",
    )
    parser.add_argument("--message", required=True, help="Message body.")
    parser.add_argument("--agent-session-url", required=True, help="Agent session URL.")
    parser.add_argument(
        "--cc-persons",
        default="",
        help="Comma-separated additional person identifiers.",
    )
    parser.add_argument("--pr-url", default=None, help="Optional PR URL.")
    parser.add_argument("--issue-url", default=None, help="Optional issue URL.")
    parser.add_argument(
        "--additional-actions",
        default=None,
        help="JSON object of label -> URL pairs for extra action buttons.",
    )

    args = parser.parse_args()

    slack_token = os.environ.get("SLACK_BOT_TOKEN_HITL")
    if not slack_token:
        print(
            "Error: SLACK_BOT_TOKEN_HITL environment variable is required.",
            file=sys.stderr,
        )
        sys.exit(1)

    channel = os.environ.get("SLACK_CHANNEL_HITL", "human-in-the-loop")

    roster = _load_roster(args.roster_file)
    print(f"Loaded roster with {len(roster)} members.", file=sys.stderr)

    target_slack_id = _resolve_to_slack_id(args.target_person, roster)
    if target_slack_id:
        print(
            f"Resolved target '{args.target_person}' -> Slack ID {target_slack_id}",
            file=sys.stderr,
        )
    else:
        print(
            f"Warning: Could not resolve '{args.target_person}' to a Slack ID.",
            file=sys.stderr,
        )

    cc_mentions: list[str] = []
    if args.cc_persons:
        for person in args.cc_persons.split(","):
            person = person.strip()
            if not person:
                continue
            cc_slack_id = _resolve_to_slack_id(person, roster)
            cc_mentions.append(_format_mention(person, cc_slack_id))

    extra_actions: dict[str, str] | None = None
    if args.additional_actions:
        extra_actions = json.loads(args.additional_actions)

    agent_name = _derive_agent_name(args.agent_session_url)
    print(f"Derived agent name: {agent_name}", file=sys.stderr)

    sender_name = f"{agent_name} (No-Reply)"

    blocks = _build_slack_blocks(
        target_person=args.target_person,
        target_slack_id=target_slack_id,
        cc_mentions=cc_mentions,
        message=args.message,
        agent_session_url=args.agent_session_url,
        pr_url=args.pr_url,
        issue_url=args.issue_url,
        additional_actions=extra_actions,
        sender_name=sender_name,
    )

    target_mention = _format_mention(args.target_person, target_slack_id)
    fallback_text = f"HITL Escalation for {target_mention}: {args.message}"

    _post_slack_message(
        slack_token, channel, blocks, fallback_text, username=sender_name
    )


if __name__ == "__main__":
    main()
