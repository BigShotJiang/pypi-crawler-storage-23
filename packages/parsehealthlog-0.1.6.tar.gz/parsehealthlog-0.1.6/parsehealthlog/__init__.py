"""parsehealthlog - AI-powered tool for structuring and auditing personal health logs."""

__version__ = "0.1.6"
