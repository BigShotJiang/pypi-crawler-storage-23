"""Tests for PydanticAI schema extraction and graph building."""

from typing import Any

from pydantic import BaseModel
from pydantic_ai import Agent

from uipath_pydantic_ai.runtime.schema import (
    get_agent_schema,
    get_deps_type,
    get_entrypoints_schema,
    parse_input_to_deps,
)

# ============= TEST MODELS =============


class TranslationOutput(BaseModel):
    """Test output model for translations."""

    original_text: str
    translated_text: str
    target_language: str


class TranslationInput(BaseModel):
    """Test input model for structured translation requests."""

    text: str
    source_language: str
    target_language: str


class ReviewInput(BaseModel):
    """Test input model with messages field."""

    messages: str
    review_type: str
    max_issues: int = 10


# ============= TEST AGENTS =============


# Conversational agent (no deps_type, no output_type)
agent_plain = Agent(
    "test",
    name="test_agent_plain",
)

# Structured output only
agent_with_output = Agent(
    "test",
    name="test_agent_with_output",
    output_type=TranslationOutput,
)

# Structured input only (deps_type)
agent_with_deps = Agent(
    "test",
    name="test_agent_with_deps",
    deps_type=TranslationInput,
)

# Structured input AND output
agent_structured = Agent(
    "test",
    name="test_agent_structured",
    deps_type=TranslationInput,
    output_type=TranslationOutput,
)

# Structured input with messages field
agent_with_messages_deps = Agent(
    "test",
    name="test_agent_messages_deps",
    deps_type=ReviewInput,
)


def get_weather(ctx, location: str) -> str:
    """Get the current weather for a location.

    Args:
        ctx: The agent context.
        location: The city and state.

    Returns:
        Weather information.
    """
    return f"Sunny in {location}"


def get_time(ctx, timezone: str) -> str:
    """Get the current time in a timezone.

    Args:
        ctx: The agent context.
        timezone: The timezone.

    Returns:
        Time information.
    """
    return f"12:00 PM in {timezone}"


# Agent with tools
agent_with_tools = Agent(
    "test",
    name="tools_agent",
    tools=[get_weather, get_time],
)


# ============= STRUCTURED INPUT TESTS =============


def test_deps_type_detection():
    """Test that deps_type is correctly detected."""
    assert get_deps_type(agent_plain) is None
    assert get_deps_type(agent_with_output) is None
    assert get_deps_type(agent_with_deps) is TranslationInput
    assert get_deps_type(agent_structured) is TranslationInput


def test_schema_structured_input():
    """Test that deps_type Pydantic model becomes the input schema."""
    schema = get_entrypoints_schema(agent_with_deps)

    input_schema = schema["input"]
    assert "text" in input_schema["properties"]
    assert "source_language" in input_schema["properties"]
    assert "target_language" in input_schema["properties"]

    # messages should NOT be in the schema — it's the deps model, not conversational
    assert "messages" not in input_schema["properties"]

    # All fields are required (no defaults)
    assert "text" in input_schema["required"]
    assert "source_language" in input_schema["required"]
    assert "target_language" in input_schema["required"]


def test_schema_structured_input_and_output():
    """Test agent with both deps_type and output_type."""
    schema = get_entrypoints_schema(agent_structured)

    # Input is the deps model
    assert "text" in schema["input"]["properties"]
    assert "source_language" in schema["input"]["properties"]
    assert "messages" not in schema["input"]["properties"]

    # Output is the output_type model
    assert "original_text" in schema["output"]["properties"]
    assert "translated_text" in schema["output"]["properties"]
    assert schema["output"].get("title") == "TranslationOutput"


def test_schema_deps_with_messages_field():
    """Test deps model that has a 'messages' field — it stays as a deps field."""
    schema = get_entrypoints_schema(agent_with_messages_deps)

    input_schema = schema["input"]
    # messages is part of the deps model, not the conversational fallback
    assert "messages" in input_schema["properties"]
    assert "review_type" in input_schema["properties"]
    assert "max_issues" in input_schema["properties"]

    assert input_schema.get("title") == "ReviewInput"


def test_parse_input_to_deps():
    """Test parsing a dict into a deps Pydantic model."""
    deps = parse_input_to_deps(
        {"text": "Hello", "source_language": "en", "target_language": "es"},
        TranslationInput,
    )
    assert isinstance(deps, TranslationInput)
    assert deps.text == "Hello"
    assert deps.source_language == "en"
    assert deps.target_language == "es"


def test_parse_input_to_deps_with_defaults():
    """Test deps parsing with default values."""
    deps = parse_input_to_deps(
        {"messages": "Review this", "review_type": "security"},
        ReviewInput,
    )
    assert isinstance(deps, ReviewInput)
    assert deps.messages == "Review this"
    assert deps.review_type == "security"
    assert deps.max_issues == 10


# ============= STRUCTURED OUTPUT TESTS =============


def test_schema_with_output_type():
    """Test that output schema is correctly inferred from agent's output_type."""
    schema = get_entrypoints_schema(agent_with_output)

    # Input should be conversational (no deps_type)
    assert "messages" in schema["input"]["properties"]

    # Output should be the model
    assert "original_text" in schema["output"]["properties"]
    assert "translated_text" in schema["output"]["properties"]
    assert "target_language" in schema["output"]["properties"]

    assert "original_text" in schema["output"]["required"]
    assert schema["output"].get("title") == "TranslationOutput"


def test_schema_fallback_without_output_type():
    """Test that schema falls back to UiPath conversation messages when no output_type."""
    schema = get_entrypoints_schema(agent_plain)

    assert "messages" in schema["input"]["properties"]
    # Output should be UiPath conversation messages, not a generic "result"
    assert "messages" in schema["output"]["properties"]
    output_messages = schema["output"]["properties"]["messages"]
    assert output_messages["type"] == "array"


def test_schema_with_plain_agent():
    """Test schema extraction with a plain agent (str output)."""
    schema = get_entrypoints_schema(agent_plain)

    assert "messages" in schema["input"]["properties"]
    assert "messages" in schema["output"]["properties"]


# ============= GRAPH TESTS =============


def test_graph_basic_agent():
    """Test graph building for a simple agent without tools."""
    graph = get_agent_schema(agent_plain)

    node_ids = {node.id for node in graph.nodes}

    assert "__start__" in node_ids
    assert "__end__" in node_ids
    assert "test_agent_plain" in node_ids
    assert len(graph.nodes) == 3


def test_graph_agent_with_tools():
    """Test graph building for an agent with tools."""
    graph = get_agent_schema(agent_with_tools)

    node_ids = {node.id for node in graph.nodes}

    assert "__start__" in node_ids
    assert "__end__" in node_ids
    assert "tools_agent" in node_ids
    assert "tools_agent_tools" in node_ids
    assert len(graph.nodes) == 4


def test_graph_node_types():
    """Test that nodes have correct types."""
    graph = get_agent_schema(agent_with_tools)

    node_types = {node.id: node.type for node in graph.nodes}

    assert node_types["__start__"] == "__start__"
    assert node_types["__end__"] == "__end__"
    assert node_types["tools_agent"] == "model"
    assert node_types["tools_agent_tools"] == "tool"


def test_graph_control_edges():
    """Test that control flow edges are correctly created."""
    graph = get_agent_schema(agent_with_tools)

    edges = [(edge.source, edge.target, edge.label) for edge in graph.edges]

    assert ("__start__", "tools_agent", "input") in edges
    assert ("tools_agent", "__end__", "output") in edges


def test_graph_tool_edges():
    """Test that bidirectional tool edges exist."""
    graph = get_agent_schema(agent_with_tools)

    edges = [(edge.source, edge.target, edge.label) for edge in graph.edges]

    assert ("tools_agent", "tools_agent_tools", None) in edges
    assert ("tools_agent_tools", "tools_agent", None) in edges


def test_graph_agent_model_metadata():
    """Test that agent nodes with a model have model_name metadata."""
    graph = get_agent_schema(agent_with_tools)

    node_map = {node.id: node for node in graph.nodes}
    agent_node = node_map["tools_agent"]
    assert agent_node.type == "model"
    assert agent_node.metadata is not None
    assert agent_node.metadata["model_name"] == "test"


def test_graph_agent_without_model():
    """Test that agent nodes without a model use type=node."""
    no_model_agent = Agent(None, name="no_model", defer_model_check=True)
    graph = get_agent_schema(no_model_agent)

    node_map = {node.id: node for node in graph.nodes}
    agent_node = node_map["no_model"]
    assert agent_node.type == "node"
    assert agent_node.metadata is None


def test_graph_tools_metadata():
    """Test that tools nodes have correct metadata."""
    graph = get_agent_schema(agent_with_tools)

    node_metadata = {node.id: node.metadata for node in graph.nodes}

    tools_metadata = node_metadata["tools_agent_tools"]
    assert tools_metadata is not None
    assert tools_metadata["tool_count"] == 2
    assert "get_weather" in tools_metadata["tool_names"]
    assert "get_time" in tools_metadata["tool_names"]


def test_graph_edge_count():
    """Test total number of edges for agent with tools."""
    graph = get_agent_schema(agent_with_tools)

    # 2 control edges + 2 tool edges = 4
    assert len(graph.edges) == 4


def test_graph_no_subgraphs():
    """Test that all nodes have None subgraph (flat structure)."""
    graph = get_agent_schema(agent_with_tools)

    for node in graph.nodes:
        assert node.subgraph is None


# ============= UIPATH CONVERSATION MESSAGE FORMAT TESTS =============


def _validate_conversation_message_schema(schema: dict[str, Any]) -> None:
    """Helper to validate that a schema matches the UiPath conversation message format."""
    assert schema["type"] == "object"
    assert "messages" in schema["properties"]
    assert "messages" in schema["required"]

    messages_prop = schema["properties"]["messages"]
    assert messages_prop["type"] == "array"
    assert "items" in messages_prop

    item = messages_prop["items"]
    assert item["type"] == "object"
    assert "role" in item["properties"]
    assert item["properties"]["role"]["type"] == "string"
    assert "contentParts" in item["properties"]
    assert "role" in item["required"]
    assert "contentParts" in item["required"]

    content_parts = item["properties"]["contentParts"]
    assert content_parts["type"] == "array"
    cp_item = content_parts["items"]
    assert cp_item["type"] == "object"
    assert "data" in cp_item["properties"]
    assert "data" in cp_item["required"]

    data_prop = cp_item["properties"]["data"]
    assert data_prop["type"] == "object"
    assert "inline" in data_prop["properties"]
    assert "inline" in data_prop["required"]


def test_default_input_schema_is_uipath_messages():
    """Test that conversational agents get UiPath conversation message input schema."""
    schema = get_entrypoints_schema(agent_plain)
    _validate_conversation_message_schema(schema["input"])


def test_default_output_schema_is_uipath_messages():
    """Test that conversational agents get UiPath conversation message output schema."""
    schema = get_entrypoints_schema(agent_plain)
    _validate_conversation_message_schema(schema["output"])


def test_output_only_agent_has_uipath_messages_input():
    """Test agent with output_type still uses UiPath messages for input."""
    schema = get_entrypoints_schema(agent_with_output)
    _validate_conversation_message_schema(schema["input"])
    # Output should be the structured model, not messages
    assert "original_text" in schema["output"]["properties"]


def test_deps_only_agent_has_uipath_messages_output():
    """Test agent with deps_type still uses UiPath messages for output."""
    schema = get_entrypoints_schema(agent_with_deps)
    _validate_conversation_message_schema(schema["output"])
    # Input should be the structured model, not messages
    assert "text" in schema["input"]["properties"]


def test_message_schema_has_optional_fields():
    """Test that the message schema includes optional fields like toolCalls and interrupts."""
    schema = get_entrypoints_schema(agent_plain)
    item = schema["input"]["properties"]["messages"]["items"]
    assert "toolCalls" in item["properties"]
    assert "interrupts" in item["properties"]
    assert "mimeType" in item["properties"]["contentParts"]["items"]["properties"]
    assert "citations" in item["properties"]["contentParts"]["items"]["properties"]


def test_message_schema_structure():
    """Test that the default message schema has the correct UiPath structure."""
    schema = get_entrypoints_schema(agent_plain)
    input_schema = schema["input"]

    messages_prop = input_schema["properties"]["messages"]
    assert messages_prop["title"] == "Messages"
    assert messages_prop["description"] == "UiPath conversation messages"

    item = messages_prop["items"]
    # toolCalls and interrupts should be arrays of objects
    assert item["properties"]["toolCalls"] == {
        "type": "array",
        "items": {"type": "object"},
    }
    assert item["properties"]["interrupts"] == {
        "type": "array",
        "items": {"type": "object"},
    }
