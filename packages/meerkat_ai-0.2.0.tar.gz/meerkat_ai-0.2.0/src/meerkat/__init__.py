"""
Meerkat AI — Python SDK

Lightweight client for the Meerkat Governance API. Adds a trust and safety
layer to any AI pipeline: prompt shielding, output verification, and audit.

    pip install meerkat-ai

Usage:

    from meerkat import MeerkatClient

    mk = MeerkatClient("mk_live_...", domain="healthcare")
    result = mk.verify(output=llm_response, context=source)
    print(f"Trust: {result.trust_score}  Status: {result.status}")
"""

from meerkat.client import (
    MeerkatClient,
    ShieldResult,
    VerifyResult,
    AuditResult,
    MeerkatError,
    MeerkatBlockError,
    __version__,
)

__all__ = [
    "MeerkatClient",
    "ShieldResult",
    "VerifyResult",
    "AuditResult",
    "MeerkatError",
    "MeerkatBlockError",
    "__version__",
]
