"""
Document-level verification for the Meerkat Agent SDK.

Extracts text and table claims from .docx files, verifies each against
source data via the MeerkatClient, and returns a structured result.
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path

from meerkat.client import MeerkatClient


@dataclass
class VerificationResult:
    total: int
    verified: int
    flagged: int
    text_claims: list[dict] = field(default_factory=list)
    table_claims: list[dict] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return self.flagged == 0

    def save_report(self, path: str) -> None:
        """Write the verification result as JSON."""
        with open(path, "w") as f:
            json.dump(asdict(self), f, indent=2)


def _extract_text_claims(doc) -> list[str]:
    """Extract non-empty paragraphs as text claims."""
    return [p.text.strip() for p in doc.paragraphs if p.text.strip()]


def _extract_table_claims(doc) -> list[dict]:
    """Extract table cells containing digits as tabular claims."""
    claims: list[dict] = []
    for i, table in enumerate(doc.tables):
        seen: set[str] = set()
        for r, row in enumerate(table.rows):
            for c, cell in enumerate(row.cells):
                text = cell.text.strip()
                if not text or text in seen:
                    continue
                seen.add(text)
                if re.search(r"\d", text):
                    claims.append({
                        "claim": text,
                        "type": "tabular_numerical",
                        "table_index": i,
                        "row": r,
                        "col": c,
                    })
    return claims


def verify_document(
    document_path: str,
    doc_type: str = "docx",
    data_sources: list[str] | None = None,
) -> VerificationResult:
    """
    Verify all claims in a document against provided data sources.

    Args:
        document_path: Path to the .docx file to verify.
        doc_type: Document type (currently only "docx" supported).
        data_sources: List of file paths whose contents form the source context.

    Returns:
        VerificationResult with per-claim details and pass/fail tally.
    """
    from docx import Document

    doc = Document(document_path)

    text_claims = _extract_text_claims(doc)
    table_claims = _extract_table_claims(doc)

    # Build combined context from data sources
    combined_context = ""
    if data_sources:
        parts = []
        for src_path in data_sources:
            parts.append(Path(src_path).read_text(encoding="utf-8"))
        combined_context = "\n\n".join(parts)

    client = MeerkatClient(
        api_key=os.environ.get("MEERKAT_API_KEY", ""),
        domain="healthcare",
    )

    verified = 0
    flagged = 0
    text_results: list[dict] = []
    table_results: list[dict] = []

    # Verify text claims
    for claim in text_claims:
        result = client.verify(output=claim, context=combined_context)
        is_ok = result.status != "BLOCK"
        if is_ok:
            verified += 1
        else:
            flagged += 1
        text_results.append({
            "claim": claim,
            "trust_score": result.trust_score,
            "status": result.status,
            "audit_id": result.audit_id,
        })

    # Verify table claims
    for tc in table_claims:
        result = client.verify(output=tc["claim"], context=combined_context)
        is_ok = result.status != "BLOCK"
        if is_ok:
            verified += 1
        else:
            flagged += 1
        table_results.append({
            "claim": tc["claim"],
            "trust_score": result.trust_score,
            "status": result.status,
            "audit_id": result.audit_id,
            "table_index": tc["table_index"],
            "row": tc["row"],
            "col": tc["col"],
        })

    return VerificationResult(
        total=len(text_claims) + len(table_claims),
        verified=verified,
        flagged=flagged,
        text_claims=text_results,
        table_claims=table_results,
    )
