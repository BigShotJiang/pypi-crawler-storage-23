from .verify import verify_document, VerificationResult
