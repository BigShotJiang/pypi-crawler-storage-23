"""Tests for meerkat.agent.verify — verify_document() end-to-end."""

import json
from unittest.mock import patch

import pytest

from meerkat.agent.verify import verify_document, VerificationResult
from meerkat.client import VerifyResult


def _make_test_docx(path: str) -> None:
    """Create a minimal .docx with 1 paragraph and a 2x2 table."""
    from docx import Document

    doc = Document()
    doc.add_paragraph("The p-value was 0.031")

    table = doc.add_table(rows=2, cols=2)
    table.cell(0, 0).text = "Metric"
    table.cell(0, 1).text = "Value"
    table.cell(1, 0).text = "OR"
    table.cell(1, 1).text = "1.54"

    doc.save(path)


def _mock_verify_result(**overrides) -> VerifyResult:
    defaults = dict(
        trust_score=85,
        status="PASS",
        checks={},
        audit_id="aud_test_001",
        session_id="sess_test_001",
        attempt=1,
        verification_mode="standard",
        recommendations=[],
        remediation=None,
        raw={},
    )
    defaults.update(overrides)
    return VerifyResult(**defaults)


class TestVerifyDocument:
    def test_basic_verification(self, tmp_path):
        docx_path = str(tmp_path / "test.docx")
        _make_test_docx(docx_path)

        context_file = tmp_path / "source.txt"
        context_file.write_text("The p-value was 0.031. OR=1.54.")

        with patch("meerkat.agent.verify.MeerkatClient") as MockClient:
            instance = MockClient.return_value
            instance.verify.return_value = _mock_verify_result()

            result = verify_document(
                docx_path,
                data_sources=[str(context_file)],
            )

        assert result.total > 0
        assert result.passed is True
        assert len(result.text_claims) >= 1
        assert len(result.table_claims) >= 1

    def test_flagged_claims(self, tmp_path):
        docx_path = str(tmp_path / "test.docx")
        _make_test_docx(docx_path)

        context_file = tmp_path / "source.txt"
        context_file.write_text("Source data.")

        with patch("meerkat.agent.verify.MeerkatClient") as MockClient:
            instance = MockClient.return_value
            instance.verify.return_value = _mock_verify_result(
                trust_score=20, status="BLOCK"
            )

            result = verify_document(
                docx_path,
                data_sources=[str(context_file)],
            )

        assert result.flagged > 0
        assert result.passed is False

    def test_save_report(self, tmp_path):
        docx_path = str(tmp_path / "test.docx")
        _make_test_docx(docx_path)

        context_file = tmp_path / "source.txt"
        context_file.write_text("Source.")

        with patch("meerkat.agent.verify.MeerkatClient") as MockClient:
            instance = MockClient.return_value
            instance.verify.return_value = _mock_verify_result()

            result = verify_document(
                docx_path,
                data_sources=[str(context_file)],
            )

        report_path = str(tmp_path / "report.json")
        result.save_report(report_path)

        with open(report_path) as f:
            data = json.load(f)

        assert "total" in data
        assert "verified" in data
        assert "flagged" in data
        assert "text_claims" in data
        assert "table_claims" in data
