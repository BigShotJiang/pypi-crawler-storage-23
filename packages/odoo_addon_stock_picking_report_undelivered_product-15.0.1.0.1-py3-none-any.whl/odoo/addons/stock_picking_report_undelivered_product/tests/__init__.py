# Copyright 2020 Sergio Teruel - Tecnativa <sergio.teruel@tecnativa.com>

from . import test_stock_picking_report_undelivered_product
