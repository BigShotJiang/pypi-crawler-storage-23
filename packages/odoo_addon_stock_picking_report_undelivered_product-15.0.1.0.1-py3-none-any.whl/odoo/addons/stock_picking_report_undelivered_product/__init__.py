# Copyright 2020 Sergio Teruel - Tecnativa <sergio.teruel@tecnativa.com>
from . import models
