from . import product_template
from . import res_config_settings
from . import res_partner
from . import stock_move
from . import stock_move_line
