#. Go to *'Inventory > Configuration > Settings'*.
#. Select the option to display lines (All, only partially lines or only
   completely lines).
#. Go to *'Sales > Orders > Customers'*.
#. Check "Display undelivered in picking" in a customer.
#. Go to *'Sales > Catalog > Products'*.
#. Check "Display undelivered in picking" in a product.
#. Go to *'Sales > Orders > Order'*.
#. Do a order for this customer with a product with the
   "Display undelivered in picking" field checked.
#. Confirm the order.
#. Open the related picking and print the "Delivery slip".
#. Now you can view in report products that have not been sent.
