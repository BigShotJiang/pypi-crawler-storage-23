This module extends the functionality of stock module to allow to
display undelivered products in the delivery slip report.

You have three options to display lines:

* Display all undelivered product lines.
* Display only partially undelivered product lines.
* Display only completely undelivered product lines.

You can choose by partner and product if you want to display undelivered
products.
