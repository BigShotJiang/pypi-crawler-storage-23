# ⚡ VexRay

**Interactive ML/DL Concept Explorer** — learn machine learning and deep learning with live graphs, interactive playgrounds, and beautiful visualizations. All from your terminal.

## Install

```bash
pip install vexray
```

## 🚀 CLI Commands

VexRay works directly from your terminal — no setup, no notebooks, no config.

```bash
# List all available topics and playgrounds
vexray list
vexray list --playgrounds

# Open a beautiful topic page in your browser
vexray start "linear regression"
vexray start svm
vexray start transformers

# Launch an interactive playground — tweak params with sliders, see graphs update live
vexray playground "linear regression"
vexray playground svm
vexray playground "bias variance"
```

## 🐍 Python API

```python
import vexray

# Learn a topic
vexray.start("linear regression")

# Interactive playground
vexray.playground("svm")

# See what's available
print(vexray.list_topics())
```

## 📚 23 Topics

| Category | Topics |
|----------|--------|
| **Regression** | Linear Regression, Logistic Regression |
| **Classification** | KNN, SVM, Naive Bayes, Decision Trees |
| **Ensemble** | Random Forest, Gradient Boosting |
| **Unsupervised** | K-Means, PCA |
| **Concepts** | Regularization, Bias-Variance, Cross-Validation |
| **Deep Learning** | Neural Networks, Backpropagation, CNNs, RNNs/LSTMs, Transformers |
| **Generative** | GANs, Autoencoders |
| **Building Blocks** | Activation Functions, Loss Functions, Optimizers |

## 🧪 13 Interactive Playgrounds

Tweak parameters with sliders and watch ML algorithms update in real-time.

| Playground | CLI Command |
|------------|-------------|
| Linear Regression | `vexray playground lr` |
| KNN | `vexray playground knn` |
| K-Means | `vexray playground kmeans` |
| Decision Tree | `vexray playground dt` |
| SVM | `vexray playground svm` |
| Logistic Regression | `vexray playground logistic` |
| Random Forest | `vexray playground rf` |
| Gradient Boosting | `vexray playground gbm` |
| PCA | `vexray playground pca` |
| Regularization | `vexray playground regularization` |
| Bias-Variance | `vexray playground "bias variance"` |
| Naive Bayes | `vexray playground nb` |
| Activation Functions | `vexray playground activations` |

## ✨ Features

- 🖥️ **CLI-First** — `vexray start`, `vexray playground`, `vexray list`
- 🧪 **Live Playgrounds** — tweak parameters with sliders, see results instantly
- 📈 **Interactive Plotly Graphs** — scatter plots, 3D surfaces, decision boundaries
- 🧮 **KaTeX Math** — publication-quality formulas
- 💻 **Code Examples** — copy-paste-ready Python with syntax highlighting
- 🌙 **Dark / Light Theme** — toggle with one click
- ⚡ **Zero Config** — just `pip install vexray` and go
