"""
Playground Registry — maps user-friendly names to playground compute modules.
"""

from vexray.playgrounds import (
    linear_regression,
    knn,
    kmeans,
    decision_tree,
    svm,
    logistic_regression,
    random_forest,
    gradient_boosting,
    pca,
    regularization,
    bias_variance,
    naive_bayes,
    activation_functions,
)

_PLAYGROUND_MAP = {
    # Linear Regression
    "linear regression": linear_regression,
    "linear_regression": linear_regression,
    "lr": linear_regression,

    # KNN
    "k-nearest neighbors": knn,
    "k nearest neighbors": knn,
    "knn": knn,

    # K-Means
    "k-means": kmeans,
    "k-means clustering": kmeans,
    "kmeans": kmeans,

    # Decision Tree
    "decision tree": decision_tree,
    "decision_tree": decision_tree,
    "decision trees": decision_tree,
    "dt": decision_tree,

    # SVM
    "support vector machine": svm,
    "support vector machines": svm,
    "svm": svm,

    # Logistic Regression
    "logistic regression": logistic_regression,
    "logistic_regression": logistic_regression,
    "logistic": logistic_regression,

    # Random Forest
    "random forest": random_forest,
    "random_forest": random_forest,
    "rf": random_forest,

    # Gradient Boosting
    "gradient boosting": gradient_boosting,
    "gradient_boosting": gradient_boosting,
    "gbm": gradient_boosting,
    "xgboost": gradient_boosting,

    # PCA
    "principal component analysis": pca,
    "pca": pca,

    # Regularization
    "regularization": regularization,
    "ridge": regularization,
    "lasso": regularization,

    # Bias-Variance
    "bias-variance tradeoff": bias_variance,
    "bias variance tradeoff": bias_variance,
    "bias variance": bias_variance,
    "bias_variance": bias_variance,

    # Naive Bayes
    "naive bayes": naive_bayes,
    "naive_bayes": naive_bayes,
    "nb": naive_bayes,

    # Activation Functions
    "activation functions": activation_functions,
    "activation_functions": activation_functions,
    "activations": activation_functions,
    "relu": activation_functions,
}


def get_playground(name: str):
    """Resolve a playground name to its module."""
    key = name.strip().lower()
    if key in _PLAYGROUND_MAP:
        return _PLAYGROUND_MAP[key]

    available = sorted(set(
        m.META["title"] for m in _PLAYGROUND_MAP.values()
    ))
    raise ValueError(
        f"Unknown playground: '{name}'.\n"
        f"Available playgrounds: {', '.join(available)}"
    )


def list_playgrounds() -> list[str]:
    """Return canonical playground names."""
    seen = set()
    result = []
    for m in _PLAYGROUND_MAP.values():
        title = m.META["title"]
        if title not in seen:
            seen.add(title)
            result.append(title)
    return sorted(result)
