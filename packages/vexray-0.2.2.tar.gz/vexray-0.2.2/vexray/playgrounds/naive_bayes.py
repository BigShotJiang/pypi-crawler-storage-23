"""
Naive Bayes Playground — interactive parameter exploration.
"""

import numpy as np

META = {
    "title": "Naive Bayes",
    "icon": "🎲",
    "description": (
        "Visualize how Gaussian Naive Bayes models each class as a Gaussian "
        "distribution and draws decision boundaries based on probability. "
        "Adjust the spread and separation to see how the classifier adapts."
    ),
}

PARAMS = [
    {
        "name": "separation",
        "label": "Class Separation",
        "type": "slider",
        "min": 1.0,
        "max": 6.0,
        "step": 0.25,
        "default": 3.0,
    },
    {
        "name": "noise",
        "label": "Noise / Spread",
        "type": "slider",
        "min": 0.3,
        "max": 2.5,
        "step": 0.1,
        "default": 1.0,
    },
    {
        "name": "n_points",
        "label": "Points per Class",
        "type": "slider",
        "min": 20,
        "max": 150,
        "step": 10,
        "default": 60,
    },
]


def compute(params: dict) -> dict:
    sep = float(params.get("separation", 3.0))
    noise = float(params.get("noise", 1.0))
    n = int(params.get("n_points", 60))

    np.random.seed(42)
    c0 = np.random.randn(n, 2) * noise + [0, 0]
    c1 = np.random.randn(n, 2) * noise + [sep, sep]
    c2 = np.random.randn(n, 2) * noise + [sep, 0]
    X = np.vstack([c0, c1, c2])
    y = np.array([0] * n + [1] * n + [2] * n)

    from sklearn.naive_bayes import GaussianNB
    clf = GaussianNB()
    clf.fit(X, y)

    margin = 2
    x_min, x_max = X[:, 0].min() - margin, X[:, 0].max() + margin
    y_min, y_max = X[:, 1].min() - margin, X[:, 1].max() + margin
    res = 100
    xx, yy = np.meshgrid(np.linspace(x_min, x_max, res), np.linspace(y_min, y_max, res))
    Z = clf.predict(np.c_[xx.ravel(), yy.ravel()]).reshape(xx.shape).astype(float)
    accuracy = clf.score(X, y)

    colors = ["#6C63FF", "#FF6584", "#34d399"]
    data = [
        {
            "z": Z.tolist(),
            "x": np.linspace(x_min, x_max, res).tolist(),
            "y": np.linspace(y_min, y_max, res).tolist(),
            "type": "heatmap",
            "colorscale": [[0, "rgba(108,99,255,0.2)"], [0.5, "rgba(255,101,132,0.2)"], [1, "rgba(52,211,153,0.2)"]],
            "showscale": False, "hoverinfo": "skip",
        },
    ]
    for i, (cls_data, name) in enumerate(zip([c0, c1, c2], ["Class 0", "Class 1", "Class 2"])):
        data.append({
            "x": cls_data[:, 0].tolist(), "y": cls_data[:, 1].tolist(),
            "mode": "markers", "type": "scatter", "name": name,
            "marker": {"size": 7, "color": colors[i], "opacity": 0.8, "line": {"width": 1, "color": "#fff"}},
        })

    # Mark class means
    means = clf.theta_
    data.append({
        "x": means[:, 0].tolist(), "y": means[:, 1].tolist(),
        "mode": "markers", "type": "scatter", "name": "Class Means",
        "marker": {"size": 16, "color": "#fbbf24", "symbol": "diamond",
                    "line": {"width": 2, "color": "#fff"}},
    })

    layout = {
        "template": "plotly_dark",
        "paper_bgcolor": "rgba(0,0,0,0)", "plot_bgcolor": "rgba(0,0,0,0)",
        "title": {"text": f"Naive Bayes — sep={sep}, acc={accuracy:.1%}", "font": {"size": 20}},
        "xaxis": {"title": "Feature 1", "gridcolor": "rgba(255,255,255,0.08)"},
        "yaxis": {"title": "Feature 2", "gridcolor": "rgba(255,255,255,0.08)", "scaleanchor": "x"},
        "legend": {"x": 0.02, "y": 0.98},
        "margin": {"l": 60, "r": 30, "t": 60, "b": 50},
    }
    return {"data": data, "layout": layout}
