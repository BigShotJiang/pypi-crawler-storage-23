"""
VexRay — Interactive ML/DL Concept Explorer
============================================

Usage:
    import vexray
    vexray.start("linear regression")
    vexray.playground("linear regression")
"""

from .server import start, start_playground as playground
from .registry import list_topics

__version__ = "0.1.0"
__all__ = ["start", "playground", "list_topics"]
