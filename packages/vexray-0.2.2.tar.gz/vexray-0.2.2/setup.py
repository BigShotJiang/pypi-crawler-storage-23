from setuptools import setup, find_packages
from pathlib import Path

long_description = (Path(__file__).parent / "README.md").read_text(encoding="utf-8")

setup(
    name="vexray",
    version="0.2.2",
    description="Interactive ML/DL concept explorer — learn with live graphs, code, and playgrounds",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="VexRay",
    url="https://github.com/vexray/vexray",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "vexray": [
            "templates/*.html",
            "static/*.css",
            "static/*.svg",
        ],
    },
    install_requires=[
        "flask>=3.0",
        "numpy>=1.24",
        "scikit-learn>=1.3",
        "scipy>=1.11",
    ],
    python_requires=">=3.9",
    entry_points={
        "console_scripts": [
            "vexray=vexray.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Education",
    ],
    keywords="machine-learning deep-learning visualization education interactive",
)
