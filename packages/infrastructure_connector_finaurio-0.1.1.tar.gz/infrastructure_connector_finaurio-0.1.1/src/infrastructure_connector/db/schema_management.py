from typing import Optional
from sqlalchemy.orm import Session
from infrastructure_connector.models.models import SchemaVersion
from infrastructure_connector._connector import __schema_version__

def initialize_schema_version(session: Session) -> None:
    existing = session.query(SchemaVersion).first()
    
    if not existing:
        print("Initializing SchemaVersion in DB...")
        session.add(SchemaVersion(version=__schema_version__))
        session.commit()
        print("SchemaVersion added:", __schema_version__)
    else:
        print("Existing SchemaVersion found:", existing.version)

def verify_schema_compatibility(session: Session) -> None:
    existing: Optional[SchemaVersion] = (
        session.query(SchemaVersion).first()
    )

    if existing is None:
        raise RuntimeError("Schema version table is not initialized.")

    if existing.version != __schema_version__:
        raise RuntimeError(
            f"Database schema version ({existing.version}) "
            f"does not match package version ({__schema_version__})"
        )