"""Database models reflected from PostgreSQL schema."""

from sqlalchemy import (
    Column, Integer, String, Numeric, Boolean, 
    Text, Time, JSON, func
)
from datetime import datetime

from sqlalchemy.orm import declarative_base,Mapped,mapped_column
from sqlalchemy.sql import func

# Single Base instance used throughout the application
Base = declarative_base()

class SchemaVersion(Base):
    __tablename__ = "schema_version"
    version: Mapped[str] = mapped_column(primary_key=True)

    applied_at: Mapped[datetime] = mapped_column(
        server_default=func.now()
    )

class Agents(Base):
    __tablename__ = "agents"

    id = Column(Integer, primary_key=True, nullable=False)
    name = Column(String)
    type = Column(String)


class AgentsSources(Base):
    __tablename__ = "agents_sources"

    agent_id = Column(Integer, primary_key=True, nullable=False)
    news_source_id = Column(Integer, primary_key=True, nullable=False)
    reliability_score = Column(Numeric)


class AlembicVersion(Base):
    __tablename__ = "alembic_version"

    version_num = Column(String(32), primary_key=True, nullable=False)


class Alerts(Base):
    __tablename__ = "alerts"

    id = Column(Integer, primary_key=True, nullable=False)
    user_id = Column(Integer, nullable=False)
    type = Column(String(9))


class AnalysisArtifacts(Base):
    __tablename__ = "analysis_artifacts"

    id = Column(Integer, primary_key=True, nullable=False)
    analysis_id = Column(Integer, nullable=False)
    artifact_type = Column(String(8))
    uri = Column(String)
    checksum = Column(String)
    created_at = Column(Time)


class AnalysisAssets(Base):
    __tablename__ = "analysis_assets"

    id = Column(Integer, primary_key=True, nullable=False)
    analysis_id = Column(Integer, nullable=False)
    asset_id = Column(Integer, nullable=False)
    bias = Column(String(7))
    expected_move_pct = Column(Numeric)
    expected_price_low = Column(Numeric)
    expected_price_high = Column(Numeric)
    expected_volatility = Column(Numeric)
    confidence_level = Column(Numeric)
    score = Column(Numeric)
    created_at = Column(Time)


class AnalysisHistory(Base):
    __tablename__ = "analysis_history"

    id = Column(Integer, primary_key=True, nullable=False)
    analysis_id = Column(Integer)
    snapshot = Column(JSON)
    recorded_at = Column(Time)


class AnalysisIndicators(Base):
    __tablename__ = "analysis_indicators"

    id = Column(Integer, primary_key=True, nullable=False)
    analysis_id = Column(Integer, nullable=False)
    indicator_id = Column(Integer, nullable=False)
    raw_value = Column(Numeric)
    normalized_value = Column(Numeric)
    score = Column(Numeric)
    weight = Column(Numeric)
    signal = Column(String(8))
    created_at = Column(Time)


class AnalysisNewsSources(Base):
    __tablename__ = "analysis_news_sources"

    analysis_id = Column(Integer, primary_key=True, nullable=False)
    source_id = Column(Integer, primary_key=True, nullable=False)


class AssetSpecificExposures(Base):
    __tablename__ = "asset_specific_exposures"

    id = Column(Integer, primary_key=True, nullable=False)
    macro_regime_id = Column(Integer, nullable=False)
    asset_id = Column(Integer, nullable=False)
    exposure = Column(Numeric)
    override = Column(Boolean)
    created_at = Column(Time)
    updated_at = Column(Time)


class Assets(Base):
    __tablename__ = "assets"

    id = Column(Integer, primary_key=True, nullable=False)
    symbol = Column(String)
    name = Column(String)
    asset_class = Column(String(11))
    asset_subclass = Column(String(8))
    currency = Column(String)
    base_currency = Column(String)
    quote_currency = Column(String)
    lot_unit = Column(Numeric)
    price_tick = Column(Numeric)
    quantity_step = Column(Numeric)
    liquidity_profile = Column(String(9))
    volatility_profile = Column(String(6))
    trading_hours = Column(String)
    market = Column(String(3))


class AssetsAlerts(Base):
    __tablename__ = "assets_alerts"

    alert_id = Column(Integer, primary_key=True, nullable=False)
    asset_id = Column(Integer, primary_key=True, nullable=False)
    asset_price = Column(Numeric)


class BehavioralStats(Base):
    __tablename__ = "behavioral_stats"

    id = Column(Integer, primary_key=True, nullable=False)
    portfolio_id = Column(Integer, nullable=False)
    trade_frequency = Column(Numeric)
    overtrading_score = Column(Numeric)
    avg_holding_time = Column(Numeric)
    deviation_from_expected_horizon = Column(Numeric)
    revenge_trading_score = Column(Numeric)
    consistency_score = Column(Numeric)
    created_at = Column(Time)


class EconomicCalendar(Base):
    __tablename__ = "economic_calendar"

    id = Column(Integer, primary_key=True, nullable=False)
    fundamental_indicator_id = Column(Integer, nullable=False)
    previous_value = Column(Numeric)
    forecast_value = Column(Numeric)
    actual_value = Column(Numeric)
    event_name = Column(String)
    country = Column(String)
    impact_level = Column(String)
    event_date = Column(Time)


class ExecutionStats(Base):
    __tablename__ = "execution_stats"

    id = Column(Integer, primary_key=True, nullable=False)
    portfolio_id = Column(Integer, nullable=False)
    avg_slippage = Column(Numeric)
    avg_fees = Column(Numeric)
    slippage_ratio = Column(Numeric)
    fill_rate = Column(Numeric)
    avg_time_to_execution = Column(Numeric)
    created_at = Column(Time)


class FundamentalIndicators(Base):
    __tablename__ = "fundamental_indicators"

    id = Column(Integer, primary_key=True, nullable=False)
    name = Column(String)
    code = Column(String)
    description = Column(Text)
    category = Column(String)
    sub_category = Column(String)
    unit = Column(String)
    value_type = Column(String(6))
    directionality = Column(String(5))
    typical_frequency = Column(String(9))
    leading_status = Column(String(7))
    created_at = Column(Time)


class GeneratedAnalyses(Base):
    __tablename__ = "generated_analyses"

    id = Column(Integer, primary_key=True, nullable=False)
    macro_regime_id = Column(Integer, nullable=False)
    agent_id = Column(Integer, nullable=False)
    analysis_type = Column(String(8))
    time_horizon = Column(String(8))
    global_score = Column(Numeric)
    confidence_level = Column(Numeric)
    bias = Column(String(7))
    valid_from = Column(Time)
    valid_until = Column(Time)
    created_at = Column(Time)


class IndicatorScores(Base):
    __tablename__ = "indicator_scores"

    id = Column(Integer, primary_key=True, nullable=False)
    indicator_id = Column(Integer, nullable=False)
    macro_regime_id = Column(Integer, nullable=False)
    publication_id = Column(Integer, nullable=False)
    country_code = Column(String)
    score_naive = Column(Integer)
    score_weighted = Column(Numeric)
    signal_direction = Column(String(5))
    created_at = Column(Time)


class IndicatorScoresRules(Base):
    __tablename__ = "indicator_scores_rules"

    id = Column(Integer, primary_key=True, nullable=False)
    indicator_id = Column(Integer, nullable=False)
    macro_regime_id = Column(Integer, nullable=False)
    score_naive = Column(Integer)
    threshold_low = Column(Numeric)
    threshold_high = Column(Numeric)
    weight = Column(Numeric)
    created_at = Column(Time)
    updated_at = Column(Time)


class MacroAssetClassExposures(Base):
    __tablename__ = "macro_asset_class_exposures"

    id = Column(Integer, primary_key=True, nullable=False)
    macro_regime_id = Column(Integer, nullable=False)
    asset_class = Column(String(11))
    default_exposure = Column(Numeric)
    created_at = Column(Time)
    updated_at = Column(Time)


class MacroRegimes(Base):
    __tablename__ = "macro_regimes"

    id = Column(Integer, primary_key=True, nullable=False)
    name = Column(String)
    description = Column(Text)
    growth_trend = Column(String(9))
    inflation_trend = Column(String(7))
    monetary_policy = Column(String(10))
    risk_appetite = Column(String(8))
    expected_volatility = Column(String(6))
    liquidity_level = Column(String(6))
    confidence_score = Column(Numeric)
    valid_from = Column(Time)
    valid_to = Column(Time)


class NewsSources(Base):
    __tablename__ = "news_sources"

    id = Column(Integer, primary_key=True, nullable=False)
    name = Column(String)
    category = Column(String)
    country_code = Column(String(3))


class ObjectiveHistory(Base):
    __tablename__ = "objective_history"

    id = Column(Integer, primary_key=True, nullable=False)
    objective_id = Column(Integer)
    snapshot = Column(JSON)
    recorded_at = Column(Time)


class Objectives(Base):
    __tablename__ = "objectives"

    id = Column(Integer, primary_key=True, nullable=False)
    portfolio_id = Column(Integer, nullable=False)
    type = Column(String)
    target_return = Column(Numeric)
    max_drawdown = Column(Numeric)
    asset_class = Column(String(11))
    exposure = Column(Numeric)
    time_horizon = Column(String(8))
    priority = Column(Integer)
    status = Column(String(22))
    created_at = Column(Time)


class OperationHistory(Base):
    __tablename__ = "operation_history"

    id = Column(Integer, primary_key=True, nullable=False)
    operation_id = Column(Integer)
    snapshot = Column(JSON)
    recorded_at = Column(Time)


class Operations(Base):
    __tablename__ = "operations"

    id = Column(Integer, primary_key=True, nullable=False)
    portfolio_id = Column(Integer, nullable=False)
    asset_id = Column(Integer, nullable=False)
    strategy_id = Column(Integer)
    opportunity_id = Column(Integer)
    direction = Column(String(5))
    operation_type = Column(String(13))
    time_horizon = Column(String(8))
    quantity = Column(Numeric)
    price = Column(Numeric)
    notional = Column(Numeric)
    stop_loss = Column(Numeric)
    take_profit = Column(Numeric)
    fees = Column(Numeric)
    slippage = Column(Numeric)
    status = Column(String(8))
    executed_at = Column(Time)
    created_at = Column(Time)


class Opportunities(Base):
    __tablename__ = "opportunities"

    id = Column(Integer, primary_key=True, nullable=False)
    asset_id = Column(Integer, nullable=False)
    strategy_id = Column(Integer, nullable=False)
    analysis_id = Column(Integer, nullable=False)
    direction = Column(String(5))
    confidence_score = Column(Numeric)
    entry_price = Column(Numeric)
    stop_loss = Column(Numeric)
    take_profit = Column(Numeric)
    expected_return = Column(Numeric)
    risk_reward_ratio = Column(Numeric)
    status = Column(String(9))
    valid_from = Column(Time)
    valid_until = Column(Time)
    detected_at = Column(Time)
    closed_at = Column(Time)


class OpportunityHistory(Base):
    __tablename__ = "opportunity_history"

    id = Column(Integer, primary_key=True, nullable=False)
    opportunity_id = Column(Integer)
    snapshot = Column(JSON)
    recorded_at = Column(Time)


class PerformanceReturns(Base):
    __tablename__ = "performance_returns"

    id = Column(Integer, primary_key=True, nullable=False)
    portfolio_id = Column(Integer, nullable=False)
    period = Column(String(8))
    total_return = Column(Numeric)
    win_rate = Column(Numeric)
    avg_win = Column(Numeric)
    avg_loss = Column(Numeric)
    created_at = Column(Time)


class PerformanceRisk(Base):
    __tablename__ = "performance_risk"

    id = Column(Integer, primary_key=True, nullable=False)
    portfolio_id = Column(Integer, nullable=False)
    volatility = Column(Numeric)
    max_drawdown = Column(Numeric)
    avg_drawdown = Column(Numeric)
    drawdown_duration = Column(Integer)
    sharpe_ratio = Column(Numeric)
    sortino_ratio = Column(Numeric)
    calmar_ratio = Column(Numeric)
    tail_risk = Column(Numeric)
    created_at = Column(Time)


class PortfolioHistory(Base):
    __tablename__ = "portfolio_history"

    id = Column(Integer, primary_key=True, nullable=False)
    portfolio_id = Column(Integer)
    snapshot = Column(JSON)
    recorded_at = Column(Time)


class Portfolios(Base):
    __tablename__ = "portfolios"

    id = Column(Integer, primary_key=True, nullable=False)
    user_id = Column(Integer, nullable=False)
    name = Column(String)
    description = Column(Text)
    base_currency = Column(String)
    initial_capital = Column(Numeric)
    current_capital = Column(Numeric)
    risk_profile = Column(String)
    benchmark = Column(String)
    created_at = Column(Time)
    updated_at = Column(Time)


class PriceHistory(Base):
    __tablename__ = "price_history"

    id = Column(Integer, primary_key=True, nullable=False)
    asset_id = Column(Integer)
    high = Column(Numeric)
    low = Column(Numeric)
    open = Column(Numeric)
    close = Column(Numeric)
    created_at = Column(Time)
    time_unit = Column(String)


class PublicationAlerts(Base):
    __tablename__ = "publication_alerts"

    alert_id = Column(Integer, primary_key=True, nullable=False)
    publication_id = Column(Integer, primary_key=True, nullable=False)
    estimated_date = Column(Time)


class Strategies(Base):
    __tablename__ = "strategies"

    id = Column(Integer, primary_key=True, nullable=False)
    name = Column(String)
    asset_class = Column(String(11))
    strategy_type = Column(String(13))
    creator_id = Column(Integer, nullable=False)
    created_at = Column(Time)
    max_position_size = Column(Numeric)
    expected_return = Column(Numeric)
    risk_estimate = Column(Numeric)
    leverage = Column(Numeric)


class StrategyHistory(Base):
    __tablename__ = "strategy_history"

    id = Column(Integer, primary_key=True, nullable=False)
    strategy_id = Column(Integer)
    snapshot = Column(JSON)
    recorded_at = Column(Time)


class StrategyObjectives(Base):
    __tablename__ = "strategy_objectives"

    id = Column(Integer, primary_key=True, nullable=False)
    strategy_id = Column(Integer, nullable=False)
    objective_id = Column(Integer, nullable=False)
    correlation_ratio = Column(Numeric)


class Users(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, nullable=False)
    email = Column(String, nullable=False)
    password_hash = Column(String)
    role = Column(String)
    created_at = Column(Time)

