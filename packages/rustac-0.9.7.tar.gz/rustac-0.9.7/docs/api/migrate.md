---
description: Migrate STAC to another version
---

# Migration

::: rustac.migrate
