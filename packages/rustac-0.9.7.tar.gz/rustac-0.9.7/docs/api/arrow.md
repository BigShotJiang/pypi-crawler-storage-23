---
description: Go to and from arrow
---

# Arrow

These functions require the `arrow` extra, e.g.:

```shell
python -m pip install 'rustac[arrow]'
```

::: rustac.to_arrow
::: rustac.from_arrow
