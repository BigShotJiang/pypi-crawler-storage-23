# Microsoft Azure

::: rustac.store.AzureStore
::: rustac.store.AzureAccessKey
::: rustac.store.AzureConfig
    options:
        show_if_no_docstring: true
::: rustac.store.AzureSASToken
::: rustac.store.AzureBearerToken
::: rustac.store.AzureCredential
::: rustac.store.AzureCredentialProvider
