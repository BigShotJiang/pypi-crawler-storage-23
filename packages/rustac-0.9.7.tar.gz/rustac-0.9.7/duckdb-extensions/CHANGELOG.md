# Changelog

## [1.4.4-0](https://github.com/stac-utils/rustac-py/compare/rustac-duckdb-extensions-v1.4.4-0...rustac-duckdb-extensions-v1.4.4-0) (2026-02-28)


### Features

* duckdb extensions via download ([#242](https://github.com/stac-utils/rustac-py/issues/242)) ([fa6937e](https://github.com/stac-utils/rustac-py/commit/fa6937e1c0145bbe31b79e3408edda1c1da732f6))


### Bug Fixes

* pre-release for duckdb versioning ([9c9022a](https://github.com/stac-utils/rustac-py/commit/9c9022a4ce4c1ed473235955b6a6d5e8b7fa3f91))
