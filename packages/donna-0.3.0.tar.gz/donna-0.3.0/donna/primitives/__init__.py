"""Concrete implementations for Donna primitives."""
