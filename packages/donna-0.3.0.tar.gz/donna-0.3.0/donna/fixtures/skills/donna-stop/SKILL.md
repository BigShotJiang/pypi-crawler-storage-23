---
name: donna-stop
description: Stop using Donna to perform work, do nothing else. Use this skill when the developer explicitly told you to use it.
---

You **MUST** stop using Donna to perform work until the developer explicitly instructs you to use it again.
