from donna.cli.application import app  # noqa: F401
from donna.cli.commands import artifacts  # noqa: F401
from donna.cli.commands import journal  # noqa: F401
from donna.cli.commands import sessions  # noqa: F401
from donna.cli.commands import version  # noqa: F401
from donna.cli.commands import workspaces  # noqa: F401

app()
