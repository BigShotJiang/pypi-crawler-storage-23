"""Shared source constructor instances for default configuration."""

from donna.workspaces.sources.markdown import MarkdownSourceConstructor

markdown = MarkdownSourceConstructor()
