from typing import NewType

Milliseconds = NewType("Milliseconds", int)
