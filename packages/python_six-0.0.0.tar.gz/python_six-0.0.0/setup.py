"""
Empty setup.py for python-six
Target: HackerOne Bug Bounty - amazon-archives
"""
from setuptools import setup

setup(
    name="python-six",
    version="0.0.0",
    description="Empty placeholder package - reserved for amazon-archives",
    author="Package Protector",
    author_email="protector@example.com",
    py_modules=[],
)
