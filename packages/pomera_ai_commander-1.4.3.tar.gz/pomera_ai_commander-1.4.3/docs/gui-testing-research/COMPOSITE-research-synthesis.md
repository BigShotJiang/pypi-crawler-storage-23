# Tkinter GUI Testing — Research Composite

> Synthesized from deep research by **ChatGPT**, **Claude**, and **Gemini** (February 2026).
> All three sources independently validated the same core patterns — consensus items are marked with ✅.

---

## 1. Consensus Findings (All Three Agree)

### 1.1 MockApp with Real Widgets Is Sound ✅

All three reports confirm: **instantiate real `tk.Tk()` and `tk.Text` widgets in tests**. This is the pattern used by CPython's own IDLE test suite (`Lib/idlelib/idle_test/`).

- **Do NOT use `MagicMock` for `tk.Text`** — it cannot replicate Tk's index math (`"end-1c"`), trailing newline behavior, or tag operations (Gemini, ChatGPT, Claude all flag this as an anti-pattern).
- Always call `root.withdraw()` immediately after `tk.Tk()` to hide the window.

### 1.2 `widget.invoke()` Is the Recommended Button Simulation ✅

All three recommend `.invoke()` over both direct callback calls and `event_generate()`:

| Method | When to Use | All 3 Agree? |
|--------|------------|:---:|
| `widget.invoke()` | **Default for 95% of tests** — validates command wiring through Tcl | ✅ |
| Direct callback call | Pure unit tests of callback logic only | ✅ |
| `event_generate('<Button-1>')` | Only for testing custom event bindings — requires focus, geometry, `update()` | ✅ |

### 1.3 Never Call `mainloop()` in Tests ✅

All three are explicit: `mainloop()` blocks indefinitely. Use `update_idletasks()` instead.

### 1.4 `update_idletasks()` Not `update()` ✅

| Method | What It Does | Use in Tests? |
|--------|-------------|:---:|
| `update_idletasks()` | Flushes geometry/redraw queue only | ✅ Safe |
| `update()` | Processes ALL events including user input | ⚠️ Avoid — causes re-entrancy |

Call `update_idletasks()` **before assertions** and **before `destroy()`**.

### 1.5 One `Tk()` Root at a Time ✅

Python docs: *"Don't create more than one instance of `Tk` at a time."* Multiple roots share event queues and cause unpredictable behavior. Options:

- **Function-scoped fixture** (safest, ~150-200ms overhead per test)
- **Session-scoped fixture** (fastest, requires cleanup discipline — used by IDLE)

### 1.6 Windows CI Works Out of the Box ✅

GitHub Actions Windows runners have an active desktop session — no Xvfb needed. Linux requires `pytest-xvfb` or `xvfb-run`.

### 1.7 No `pytest-tkinter` Plugin Exists ✅

All three confirmed: **no equivalent to `pytest-qt` for Tkinter**. The ecosystem relies on custom fixtures + `pytest-xvfb`. IDLE's test suite is the gold standard reference.

---

## 2. Key Patterns (Agreed Best Practices)

### 2.1 Fixture Pattern (from CPython/IDLE)

```python
# conftest.py
import pytest
import tkinter as tk

@pytest.fixture
def tk_root():
    root = tk.Tk()
    root.withdraw()
    try:
        yield root
    finally:
        try:
            root.update_idletasks()
        except tk.TclError:
            pass
        try:
            root.destroy()
        except tk.TclError:
            pass
```

### 2.2 Text Widget Assertions

```python
# Always use "end-1c" to strip Tk's automatic trailing newline
content = text_widget.get("1.0", "end-1c")
assert content == "expected output"
```

### 2.3 Diff Viewer Tag Verification

```python
# Test logical tags, not visual pixels
added_ranges = text_widget.tag_ranges("diff_add")
assert len(added_ranges) >= 2  # At least one start/end pair
tagged_text = text_widget.get(str(added_ranges[0]), str(added_ranges[1]))
assert tagged_text == "new content"
```

### 2.4 Non-Deterministic Output (Generators)

**Strategy 1 — Seed forcing** (for `random`-based tools):
```python
random.seed(42)
result = generate_password(length=16)
assert result == "known_output_for_seed_42"
```

**Strategy 2 — Property validation** (for `uuid4`, `secrets`, etc.):
```python
result = generate_uuid()
assert re.match(r'^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$', result)
```

> **Gemini insight**: `uuid.uuid4()` uses `os.urandom()`, ignoring `random.seed()`. Mock `uuid.uuid4` with `unittest.mock.patch` for deterministic UUIDs.

---

## 3. Strategic Disagreements / Unique Insights

### 3.1 Coverage Depth (Claude vs ChatGPT/Gemini)

| Source | Widget Test Scope | Rationale |
|--------|------------------|-----------|
| **Claude** | 10-15 representative tools (not all 37) | Processor + routing catches ~90% of bugs; widget tests have 150-200× slower execution |
| **ChatGPT** | All tools that bypass `process_text()` | Special I/O tools (Folder Reporter, Diff Viewer) have unique bugs only widget tests find |
| **Gemini** | All tools, but with performance optimization | Use `wrap="none"` on test `tk.Text` to avoid layout calculation slowdowns |

**Resolution**: Test all tools at processor level (T1). Widget-level tests (T2) for tools that bypass `process_text()` or have unique I/O. Skip widget tests for simple processor-only tools.

### 3.2 Snapshot Testing

| Source | Recommendation |
|--------|---------------|
| **Claude** | Use **Syrupy** — automated `.ambr` snapshot files with matchers |
| **ChatGPT** | Use **pytest-regtest** — serialized baseline comparison |
| **Gemini** | Use **golden files** manually in `tests/fixtures/` |

**Resolution**: Use property assertions as primary (parameterized), golden files for complex multi-line outputs (Folder Reporter, Diff Viewer). Evaluate Syrupy if maintenance burden grows.

### 3.3 TextBuffer Abstraction (ChatGPT Unique)

ChatGPT uniquely suggested a `TextBuffer` adapter interface:
```python
class TextBuffer:
    def read(self) -> str: ...
    def write(self, value: str) -> None: ...
```
This would let tool logic be tested without any Tk dependency. However, this requires refactoring the tools — a future improvement, not needed for current testing.

---

## 4. CI/CD Recommendations

### 4.1 GitHub Actions Windows (Primary Target)

```yaml
- uses: actions/setup-python@v4
  with:
    python-version: '3.12'
- run: pip install pytest
- run: pytest tests/ -v
```

No special configuration needed. Windows runners provide GUI environment.

### 4.2 Pre-Check Guard (from PyInstaller pattern)

```python
# conftest.py
import pytest

def pytest_configure(config):
    try:
        import tkinter as tk
        root = tk.Tk()
        root.destroy()
    except Exception:
        pytest.skip("Tkinter not available", allow_module_level=True)
```

### 4.3 CI Performance Tip (Gemini Unique)

Initialize test `tk.Text` widgets with `wrap="none"` to bypass expensive line-wrapping calculation:
```python
text = tk.Text(root, wrap="none")
```

---

## 5. Testing Pyramid for 37 Tools

| Layer | Tests | Runtime | Bug-Finding Value |
|-------|-------|---------|-------------------|
| **T1: Processor** (all 37 × 4-5 cases) | ~170 | < 1 second | Very High |
| **T3: Routing** verification | ~37 | < 1 second | High |
| **T2: Widget** smoke (6-10 representative) | ~15 | ~3 seconds | Medium |
| **T4: Special I/O** (Folder Reporter, Diff) | ~5 | ~2 seconds | Medium |
| **Total** | **~227** | **~6 seconds** | |

**Effort split**: 70% processor, 10% routing, 15% widget, 5% special I/O.

---

## 6. Action Items for Implementation Plan

Based on all three reports, update our testing approach:

1. ✅ **Keep real `tk.Text` widgets** — do NOT use MagicMock for text widgets
2. ✅ **Use `widget.invoke()`** for button simulation, not direct callback calls
3. ✅ **Single `tk_root` fixture** in `conftest.py` with `withdraw()` + `update_idletasks()` + `destroy()`
4. ✅ **Add `wrap="none"`** to test text widgets for CI performance
5. ✅ **Property-based assertions** for non-deterministic tools (UUID, password)
6. ✅ **Tag-based assertions** for Diff Viewer (not visual/pixel testing)
7. ✅ **`tmp_path` fixture** for Folder File Reporter
8. ✅ **Guard fixture** that skips all GUI tests if Tkinter unavailable
9. 🔄 **Consider Syrupy/golden files** after initial suite is stable for complex outputs
10. 🔄 **Consider TextBuffer abstraction** as future refactoring (not blocking)

---

## Sources

- **ChatGPT Deep Research**: CPython IDLE tests, PyInstaller patterns, Tkinter Tcl/Tk architecture, pytest ecosystem
- **Claude Research**: IDLE `mock_tk.py`, practitioner ActiveState TDD analysis, testing pyramid economics, Syrupy plugin
- **Gemini Deep Research**: CPython `test_tkinter/`, TkDocs tutorials, Tcl/Tk core developers (invoke vs event_generate), 47 academic/technical citations
