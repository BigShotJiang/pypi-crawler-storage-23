# Extension for pyPhasesRecordloader

Extension to load records from the Sleep Heart Health Study (SHHS) database. Includes both parts (shhs1 and shhs2).

The extension requires a downloaded version of the shhs dataset. The location can be set using the `shhs-path' configuration value.

## Usage

In a phase you can access the data through the `RecordLoader`:

Add the plugins and config values to your project.yaml::

```yaml
name: SHHSProject
plugins:
  - pyPhasesML
  - pyPhasesRecordloaderSHHS
  - pyPhasesRecordloader

phases:
  - name: MyPhase

config:
  shhs-path: C:/datasets/shhs

```

In a phase (`phases/MyPhase.py`) you can access the records using the `RecordLoader`:

```python
from pyPhasesRecordloader import RecordLoader
from pyPhases import Phase

class MyPhase(Phase):
    def run(self):
      recordIds = recordLoader.getRecordList()
      for recordId in recordIds:
        record = recordLoader.getRecord(recordId)
```

Run your project with `python -m phases run MyPhase`.

## Annotations

|   Count | EventConcept                                                 |
| ------: | :----------------------------------------------------------- |
| 1588062 | Hypopnea\|Hypopnea                                           |
| 1151606 | SpO2 desaturation\|SpO2 desaturation                         |
| 1072561 | Arousal\|Arousal ()                                          |
|  391562 | Stage 2 sleep\|2                                             |
|  286898 | SpO2 artifact\|SpO2 artifact                                 |
|  260624 | Wake\|0                                                      |
|  238656 | Obstructive apnea\|Obstructive Apnea                         |
|  229582 | Stage 3 sleep\|3                                             |
|  159595 | Stage 1 sleep\|1                                             |
|   77963 | REM sleep\|5                                                 |
|   38217 | Central apnea\|Central Apnea                                 |
|   22813 | Stage 4 sleep\|4                                             |
|   12345 | Arousal\|Arousal (STANDARD)                                  |
|    8444 | Recording Start Time                                         |
|    3429 | ASDA arousal\|Arousal (ASDA)                                 |
|    1219 | Unsure\|Unsure                                               |
|    1103 | Arousal\|Arousal (Standard)                                  |
|     980 | Arousal resulting from Chin EMG\|Arousal (CHESHIRE)          |
|     530 | Mixed apnea\|Mixed Apnea                                     |
|     198 | Unscored\|9                                                  |
|     120 | External arousal\|Arousal (External Arousal)                 |
|     111 | Arousal resulting from respiratory effort\|Arousal (ARO RES) |
|       7 | Respiratory artifact\|Respiratory artifact                   |
|       2 | Movement\|6                                                  |
|       1 | Periodic breathing\|Periodic Breathing                       |
|       1 | Arousal resulting from Chin EMG\|Arousal (Cheshire)          |
|         |                                                              |

### SHHS 1
|  Count | EventConcept                                        |
| -----: | :-------------------------------------------------- |
| 256748 | Stage 2 sleep\|2                                    |
| 177240 | SpO2 artifact\|SpO2 artifact                        |
| 176623 | Obstructive apnea\|Obstructive Apnea                |
| 170456 | Wake\|0                                             |
| 151230 | Stage 3 sleep\|3                                    |
| 102257 | Stage 1 sleep\|1                                    |
|  50576 | REM sleep\|5                                        |
|  23963 | Central apnea\|Central Apnea                        |
|  17605 | Stage 4 sleep\|4                                    |
|  12345 | Arousal\|Arousal (STANDARD)                         |
|   5793 | Recording Start Time                                |
|   2061 | ASDA arousal\|Arousal (ASDA)                        |
|   1213 | Unsure\|Unsure                                      |
|   1103 | Arousal\|Arousal (Standard)                         |
|    980 | Arousal resulting from Chin EMG\|Arousal (CHESHIRE) |
|    455 | Mixed apnea\|Mixed Apnea                            |
|    120 | External arousal\|Arousal (External Arousal)        |
|     88 | Unscored\|9                                         |
|      6 | Respiratory artifact\|Respiratory artifact          |
|      1 | Movement\|6                                         |
|      1 | Arousal resulting from Chin EMG\|Arousal (Cheshire) |

### SHHS 2

|  Count | EventConcept                                                 |
| -----: | :----------------------------------------------------------- |
| 393179 | Hypopnea\|Hypopnea                                           |
| 344808 | Arousal\|Arousal ()                                          |
| 310012 | SpO2 desaturation\|SpO2 desaturation                         |
| 134814 | Stage 2 sleep\|2                                             |
| 109658 | SpO2 artifact\|SpO2 artifact                                 |
|  90168 | Wake\|0                                                      |
|  78352 | Stage 3 sleep\|3                                             |
|  62033 | Obstructive apnea\|Obstructive Apnea                         |
|  57338 | Stage 1 sleep\|1                                             |
|  27387 | REM sleep\|5                                                 |
|  14254 | Central apnea\|Central Apnea                                 |
|   5208 | Stage 4 sleep\|4                                             |
|   2651 | Recording Start Time                                         |
|   1368 | ASDA arousal\|Arousal (ASDA)                                 |
|    111 | Arousal resulting from respiratory effort\|Arousal (ARO RES) |
|    110 | Unscored\|9                                                  |
|     75 | Mixed apnea\|Mixed Apnea                                     |
|      6 | Unsure\|Unsure                                               |
|      1 | Respiratory artifact\|Respiratory artifact                   |
|      1 | Periodic breathing\|Periodic Breathing                       |
|      1 | Movement\|6                                                  |