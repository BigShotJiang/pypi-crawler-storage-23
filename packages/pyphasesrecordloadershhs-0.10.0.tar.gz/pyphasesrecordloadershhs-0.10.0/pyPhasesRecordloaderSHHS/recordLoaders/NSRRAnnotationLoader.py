from typing import List

from pyPhasesRecordloader import AnnotationInvalid, AnnotationNotFound, Event
from pyPhasesRecordloader.recordLoaders.XMLAnnotationLoader import XMLAnnotationLoader


class NSRRAnnotationLoader(XMLAnnotationLoader):

    # grep -rh 'EventConcept' . | grep -oP "(?<=<EventConcept>)[^<]+" | sort | uniq -c | sort -rn
    # 2 Blood pressure artifact|Blood pressure artifact
    eventMaps = {
        "Stages|Stages": {
            "Wake|0": "W",
            "Stage 1 sleep|1": "N1",
            "Stage 2 sleep|2": "N2",
            "Stage 3 sleep|3": "N3",
            "Stage 4 sleep|4": "N3",
            "REM sleep|5": "R",
            "Movement|6": "undefined",
            "Unscored|9": "undefined",
        },
        "Arousals|Arousals": {
            "Arousal|Arousal (STANDARD)": "arousal",
            "Arousal|Arousal (Standard)": "arousal",
            "Arousal|Arousal (Arousal)": "arousal",
            "ASDA arousal|Arousal (ASDA)": "arousal_asda",
            "ASDA arousal|Arousal (ADSA)": "arousal_asda", # typo ? seen in CFS
            "Arousal|Arousal (Asda)": "arousal_asda",
            "External arousal|Arousal (External Arousal)": "arousal_external",
            "Arousal|Arousal ()": "arousal",
            "Arousal resulting from Chin EMG|Arousal (CHESHIRE)": "arousal_chin",
            "Arousal resulting from Chin EMG|Arousal (Cheshire)": "arousal_chin",
            "Arousal|Arousal (ARO Limb)": "arousal_limb",
            "Arousal resulting from periodic leg movement|Arousal (PLM)": "arousal_plm",
            "Arousal resulting from periodic leg movement|Arousal (PLM ARO)": "arousal_plm",
            "Arousal resulting from respiratory effort|Arousal (ARO RES)": "arousal_respiratory",
            "Arousal resulting from respiratory effort|Arousal (RESP ARO)": "arousal_rera",
            "Spontaneous arousal|Arousal (ARO SPONT)": "arousal_spontaneous",
            "Spontaneous arousal|Arousal (apon aro)": "arousal_spontaneous",
            "Spontaneous arousal|Arousal (spon aro)": "arousal_spontaneous",
            "Spontaneous arousal|Arousal (SPON ARO)": "arousal_spontaneous",
        },
        "Respiratory|Respiratory": {
            "Mixed apnea|Mixed Apnea": "resp_mixedapnea",
            "Central apnea|Central Apnea": "resp_centralapnea",
            "Obstructive apnea|Obstructive Apnea": "resp_obstructiveapnea",
            "Hypopnea|Hypopnea": "resp_hypopnea", # means hypopneas with  30 - 50 % reduction
            "Unsure|Unsure": "resp_hypopnea", # means hypopneas with > 50 % reduction, see https://sleepdata.org/datasets/mros/pages/polysomnography-introduction.md#hypopnea-event-tags
            "Respiratory effort related arousal|RERA": "resp_rera",
            "SpO2 desaturation|SpO2 desaturation": "spo2_desaturation",
            "SpO2 artifact|SpO2 artifact": "spo2_artifact",
            "Respiratory artifact|Respiratory artifact": "resp_artifact",
            "Periodic breathing|Periodic Breathing": "resp_periodicbreathing",
        },
        "Limb Movement|Limb Movement": {
            "Periodic leg movement - right|PLM (Right)": "PLM-Right",
            "Periodic leg movement - left|PLM (Left)": "PLM-Left",
            "Limb movement - left|Limb Movement (Left)": "LegMovement-Left",
            "Limb movement - right|Limb Movement (Right)": "LegMovement-Right",
        },
        "Electrocardiogram|Electrocardiogram": {
            "Narrow complex tachycardia|Narrow Complex Tachycardia": "tachycardia_complex_narrow",
            "Tachycardia|Tachycardia": "sinus_tachycardia",
        }

    }


    def getPath(self, xml, path):
        path = "./ScoredEvents/ScoredEvent" + path
        return xml.findall(path)

    def loadEvents(
        self,
        path,
        eventMap,
        durationChild="Duration",
        startChild="Start",
        typeChild="EventType",
        conceptChild="EventConcept",
        defaultState="ignore",
        minDuration=0,
        replaceName=None,
    ):
        tags = self.getPath(self.metaXML, path)
        if tags is None:
            raise AnnotationNotFound(path)

        events = []

        lastDefaultEvent = None
        for tag in tags:
            name = tag.find(conceptChild).text
            startValue = float(tag.find(startChild).text)
            if startValue is None:
                raise AnnotationInvalid(path + [startChild])

            startInSeconds = float(startValue)
            # if the name is in the eventMap it will be added to the annotations
            if name in eventMap:
                event = Event()
                event.start = startInSeconds
                event.manual = True
                eventName = replaceName(tag) if replaceName else eventMap[name]

                event.name = eventName

                if durationChild is not None:
                    # if there is a duration the event will be saved as as 2 events:
                    # startTime, "(eventName"
                    # endTime, "eventName)"
                    durationValue = float(tag.find(durationChild).text)
                    if durationValue is None:
                        raise AnnotationInvalid(path + [durationChild])

                    durationInSeconds = float(durationValue)
                    if durationInSeconds > minDuration:
                        event.duration = durationInSeconds
                        events.append(event)
                else:
                    # if its without a duration, it is considered a permanent state change
                    # that will persist until it is changed again
                    if lastDefaultEvent is not None:
                        lastDefaultEvent.duration = event.start - lastDefaultEvent.start
                    events.append(event)
                    lastDefaultEvent = event
            # else:
            #     self.logWarning("Event " + name + " not in EventMap.")

        if lastDefaultEvent is not None and self.lightOn is not None:
            lastDefaultEvent.duration = self.lightOn - lastDefaultEvent.start

        return events

    def loadAnnotation(self, xmlFile) -> List[Event]:
        self.loadXmlFile(xmlFile)

        allEvents = []

        for eventType, eventmap in self.eventMaps.items():
            allEvents += self.loadEvents(f"[EventType='{eventType}']", eventmap)

        self.lightOff = 0
        self.lightOn = None

        return allEvents

    def fillRecord(self, record, xmlFile):
        pass

