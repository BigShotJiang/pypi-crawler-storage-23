..
   SPDX-FileCopyrightText: 2026 Andrew Grimberg <tykeal@bardicgrove.org>
   SPDX-License-Identifier: Apache-2.0

Device
======

.. automodule:: pylocal_akuvox.device
   :members:
   :undoc-members:
   :show-inheritance:
