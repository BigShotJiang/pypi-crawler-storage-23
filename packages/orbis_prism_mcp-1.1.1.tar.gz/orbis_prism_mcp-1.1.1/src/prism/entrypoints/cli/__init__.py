# Paquete CLI: comandos context/ctx, query, mcp, lang, config.

from .main import main
from .help import print_help

__all__ = ["main", "print_help"]
