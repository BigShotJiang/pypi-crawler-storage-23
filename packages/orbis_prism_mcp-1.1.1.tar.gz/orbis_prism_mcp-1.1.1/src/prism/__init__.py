# Orbis Prism - Engineering tools for the Hytale modding ecosystem.
# "Deconstruct the engine, illuminate the API."

__version__ = "1.1.0"
