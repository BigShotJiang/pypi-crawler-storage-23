# src/prism/infrastructure/extractor.py
#? API extractor from decompiled Java code (regex). Feeds SQLite + FTS5.

import re
import sys
from pathlib import Path

#_ from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn

from . import config_impl
from . import db
from ..entrypoints.cli import out

#_ Files processed between each commit to reduce transaction size and memory
BATCH_COMMIT_FILES = 1000

#_ Same regex as Server/Scripts/generate_api_context.py (but improved)
RE_PACKAGE = re.compile(r"package\s+([\w\.]+);")
RE_CLASS = re.compile(
    r"public\s+(?:abstract\s+|final\s+)?(class|interface|record|enum)\s+(\w+)"
    r"(?:\s+extends\s+([\w\<\>\.,\s]+?))?"
    r"(?:\s+implements\s+([\w\<\>\.,\s]+?))?"
    r"\s*\{"
)
RE_METHOD = re.compile(
    r"(@\w+\s+)?public\s+(?:abstract\s+|static\s+|final\s+|synchronized\s+|native\s+)*([\w\<\>\[\]\.]+)\s+(\w+)\s*\(([^\)]*)\)"
)
RE_CONSTANT = re.compile(
    r"public\s+static\s+final\s+([\w\<\>\[\]\.]+)\s+(\w+)\s*=\s*(.*?);"
)


def _extract_from_java(content: str, file_path: str) -> list[tuple[str, str, str, list[dict], str | None, str | None, list[dict]]]:
    """
    Extracts from a Java file: package, class_name, kind, methods, parent, interfaces, and constants.
    Uses bracket tracking to correctly attribute items to inner/multiple classes.
    """
    pkg_match = RE_PACKAGE.search(content)
    if not pkg_match:
        return []
    pkg = pkg_match.group(1)

    classes_found = list(RE_CLASS.finditer(content))
    if not classes_found:
        return []

    final_results = []
    
    for class_match in classes_found:
        kind = class_match.group(1)
        name = class_match.group(2)
        parent = class_match.group(3).strip() if class_match.group(3) else None
        interfaces = class_match.group(4).strip() if class_match.group(4) else None
        
        #_ Clean generics from parent/interfaces for better indexing/linking
        if parent: parent = re.sub(r"\<.*?\>", "", parent).strip()
        if interfaces: interfaces = re.sub(r"\<.*?\>", "", interfaces).strip()

        start_search = class_match.end()
        
        #_ Find the first '{' (which is actually part of the RE_CLASS match, but let's be careful)
        #_ Actually RE_CLASS ends at '{', so start_search is right after '{'
        first_brace = class_match.end() - 1 #_ Position of '{'
        
        #_ Track braces to find the closing '}'
        depth = 1
        end_search = -1
        for i in range(first_brace + 1, len(content)):
            if content[i] == '{': depth += 1
            elif content[i] == '}':
                depth -= 1
                if depth == 0:
                    end_search = i
                    break
        
        if end_search == -1: end_search = len(content)
        
        #_ Extract items only within [first_brace, end_search]
        class_content = content[first_brace:end_search]
        
        #_ Methods
        methods = []
        for m in RE_METHOD.finditer(class_content):
            #_ RE_METHOD groups: 1:@Annotation, 2:Returns, 3:Name, 4:Params
            m_name = m.group(3)
            if m_name == name: continue #_ Constructor
            
            #_ Capture the full signature as a snippet
            snippet = m.group(0).strip()
            
            methods.append({
                "method": m_name,
                "returns": m.group(2),
                "params": m.group(4).strip(),
                "is_static": "static" in m.group(0),
                "annotation": m.group(1).strip() if m.group(1) else None,
                "snippet": snippet
            })
        
        #_ Constants
        constants = []
        for c in RE_CONSTANT.finditer(class_content):
            #_ RE_CONSTANT groups: 1:Type, 2:Name, 3:Value
            constants.append({
                "name": c.group(2),
                "type": c.group(1),
                "value": c.group(3).strip().strip('"'),
                "snippet": c.group(0).strip()
            })
        
        final_results.append((pkg, name, kind, methods, parent, interfaces, constants))
        
    return final_results


def run_index(root: Path | None = None, version: str = "release") -> tuple[bool, str | tuple[int, int, int]]:
    """
    Walks through workspace/decompiled/<version>, extracts classes, methods and constants with regex,
    and fills prism_api_<version>.db. Returns (True, (num_classes, num_methods, num_constants));
    (False, "no_decompiled") if no code; (False, "db_error") if DB fails.
    """
    root = root or config_impl.get_project_root()
    sources_dir = config_impl.get_sources_dir(root, version)
    if not sources_dir.is_dir():
        return (False, "no_decompiled")
    java_files = list(sources_dir.rglob("*.java"))
    if not java_files:
        return (False, "no_decompiled")

    db_path = config_impl.get_db_path(root, version)
    try:
        with db.connection(db_path) as conn, out.progress() as progress:
            db.init_schema(conn)
            db.clear_tables(conn)
            files_processed = 0
            
            task = progress.add_task(f"[green]Indexing {version}", total=len(java_files), filename="")

            for jpath in java_files:
                try:
                    content = jpath.read_text(encoding="utf-8", errors="replace")
                except OSError:
                    progress.update(task, advance=1)
                    continue
                #_ Relative path to the decompiled directory for storage
                try:
                    rel_path = jpath.relative_to(sources_dir)
                except ValueError:
                    rel_path = jpath
                file_path_str = str(rel_path).replace("\\", "/")
                
                #_ Extract and insert
                results = _extract_from_java(content, file_path_str)
                for pkg, class_name, kind, methods, parent, interfaces, constants in results:
                    class_id = db.insert_class(conn, pkg, class_name, kind, file_path_str, parent, interfaces)
                    
                    #_ Insert class itself into FTS with its kind as snippet
                    db.insert_fts_row(conn, pkg, class_name, kind, snippet=f"public {kind} {class_name}")
                    
                    #_ Insert methods
                    for m in methods:
                        db.insert_method(
                            conn,
                            class_id,
                            m["method"],
                            m["returns"],
                            m["params"],
                            m["is_static"],
                            m["annotation"],
                        )
                        db.insert_fts_row(
                            conn,
                            pkg,
                            class_name,
                            kind,
                            method_name=m["method"],
                            returns=m["returns"],
                            params=m["params"],
                            snippet=m["snippet"]
                        )
                    
                    #_ Insert constants
                    for c in constants:
                        db.insert_constant(
                            conn,
                            class_id,
                            c["name"],
                            c["type"],
                            c["value"],
                        )
                        db.insert_fts_row(
                            conn,
                            pkg,
                            class_name,
                            kind,
                            const_name=c["name"],
                            const_value=c["value"],
                            snippet=c["snippet"]
                        )
                
                files_processed += 1
                if files_processed % BATCH_COMMIT_FILES == 0:
                    conn.commit()
                
                progress.update(task, advance=1)

            conn.commit()
            stats = db.get_stats(conn)
        return (True, stats)
    except Exception as e:
        import traceback
        traceback.print_exc() #_ Log to stderr for the agent/user to see
        return (False, "db_error")
