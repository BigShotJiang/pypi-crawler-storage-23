# Shared domain types.

from typing import Literal

ServerVersion = Literal["release", "prerelease"]
