#!/usr/bin/env python3
"""Cursor View — browse and search Cursor AI chat histories locally.

Run with: streamlit run streamlit_app.py
"""

import json
import logging
import os
import pathlib
import platform
import sqlite3
from collections import defaultdict
from typing import Any, Dict, Iterable

import streamlit as st

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Path resolution
# ---------------------------------------------------------------------------


def default_cursor_root() -> pathlib.Path:
    """Return the platform-specific default location of Cursor's data directory."""
    home = pathlib.Path.home()
    system = platform.system()
    if system == "Darwin":
        return home / "Library" / "Application Support" / "Cursor"
    if system == "Windows":
        return home / "AppData" / "Roaming" / "Cursor"
    if system == "Linux":
        return home / ".config" / "Cursor"
    raise RuntimeError(f"Unsupported OS: {system}")


def config_file() -> pathlib.Path:
    """Return the path to the user-level config file."""
    return pathlib.Path.home() / ".cursor-viewer" / "config.json"


def load_config() -> dict:
    """Read the config file; return an empty dict if it doesn't exist or is invalid."""
    path = config_file()
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text())
    except Exception:
        return {}


def save_config(data: dict) -> None:
    """Write *data* to the config file, creating the directory if needed."""
    path = config_file()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2))


def clear_config() -> None:
    """Remove the config file if it exists."""
    path = config_file()
    if path.exists():
        path.unlink()


def resolve_cursor_path() -> tuple[str, str]:
    """Return (path, source) using the priority chain: env var > config file > auto-detect."""
    env = os.environ.get("CURSOR_DATA_PATH", "").strip()
    if env:
        return env, "env: CURSOR_DATA_PATH"

    cfg = load_config()
    if cfg.get("cursor_path"):
        return cfg["cursor_path"], "config file"

    return str(default_cursor_root()), "auto-detected"


def global_storage_path(base: pathlib.Path) -> pathlib.Path | None:
    """Locate the global state.vscdb (or its sqlite equivalent) under *base*."""
    direct = base / "User" / "globalStorage" / "state.vscdb"
    if direct.exists():
        return direct
    for subdir in [
        base / "User" / "globalStorage" / "cursor.cursor",
        base / "User" / "globalStorage" / "cursor",
    ]:
        if subdir.exists():
            for f in subdir.glob("*.sqlite"):
                return f
    return None


def workspaces(base: pathlib.Path) -> Iterable[tuple[str, pathlib.Path]]:
    """Yield (workspace_id, state.vscdb path) for every workspace under *base*."""
    ws_root = base / "User" / "workspaceStorage"
    if not ws_root.exists():
        return
    for folder in ws_root.iterdir():
        db = folder / "state.vscdb"
        if db.exists():
            yield folder.name, db


# ---------------------------------------------------------------------------
# SQLite helpers
# ---------------------------------------------------------------------------


def _jget(cur: sqlite3.Cursor, table: str, key: str) -> Any:
    """Fetch a single row from *table* by *key* and JSON-decode it."""
    cur.execute(f"SELECT value FROM {table} WHERE key=?", (key,))
    row = cur.fetchone()
    if row:
        try:
            return json.loads(row[0])
        except Exception:
            pass
    return None


def _format_tool_call(bubble: dict) -> str:
    """Render a toolFormerData bubble as a readable markdown block."""
    tf = bubble.get("toolFormerData", {})
    name = tf.get("name", "unknown")
    status = tf.get("status", "")
    raw_args = tf.get("rawArgs") or ""
    params = tf.get("params") or ""
    result = tf.get("result", "")

    # rawArgs is sometimes an empty object "{}"; fall back to params in that case.
    args_src = raw_args if raw_args.strip() and raw_args.strip() != "{}" else params
    try:
        args_display = json.dumps(json.loads(args_src), indent=2)
    except Exception:
        args_display = args_src

    parts = [f"**`{name}`** - *{status}*\n```json\n{args_display}\n```"]
    if result:
        try:
            result_display = json.dumps(json.loads(result), indent=2)
        except Exception:
            result_display = str(result)
        parts.append(f"**Result:**\n```\n{result_display}\n```")

    return "\n\n".join(parts)


# ---------------------------------------------------------------------------
# Message iterators
# ---------------------------------------------------------------------------


def iter_bubbles_from_disk_kv(db: pathlib.Path) -> Iterable[tuple]:
    """Yield (composerId, role, content, db_path, created_at) from cursorDiskKV."""
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
        cur = con.cursor()
        cur.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='cursorDiskKV'"
        )
        if not cur.fetchone():
            con.close()
            return
        cur.execute("SELECT key, value FROM cursorDiskKV WHERE key LIKE 'bubbleId:%'")
    except sqlite3.DatabaseError as exc:
        logger.debug("DB error %s: %s", db, exc)
        return

    bubbles = []
    for key, value in cur.fetchall():
        try:
            if value is None:
                continue
            bubble = json.loads(value)
        except Exception:
            continue

        created_at = bubble.get("createdAt", "")
        role = "user" if bubble.get("type") == 1 else "assistant"
        parts = key.split(":")
        composer_id = parts[1] if len(parts) > 1 else parts[0]

        tool_former = bubble.get("toolFormerData")
        if isinstance(tool_former, dict) and tool_former.get("name"):
            bubbles.append(
                (composer_id, "tool", _format_tool_call(bubble), str(db), created_at)
            )
            continue

        text = (bubble.get("text") or bubble.get("richText") or "").strip()
        if text:
            bubbles.append((composer_id, role, text, str(db), created_at))

    con.close()
    bubbles.sort(key=lambda x: x[4])
    yield from bubbles


def iter_chat_from_item_table(db: pathlib.Path) -> Iterable[tuple]:
    """Yield (composerId, role, text, db_path) from ItemTable chat records."""
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
        cur = con.cursor()

        chat_data = _jget(
            cur, "ItemTable", "workbench.panel.aichat.view.aichat.chatdata"
        )
        if chat_data and "tabs" in chat_data:
            for tab in chat_data.get("tabs", []):
                tab_id = tab.get("tabId", "unknown")
                for bubble in tab.get("bubbles", []):
                    bubble_type = bubble.get("type")
                    if not bubble_type:
                        continue
                    parts = []
                    text = bubble.get("text") or bubble.get("content") or ""
                    if text and isinstance(text, str):
                        parts.append(text)
                    for tc in bubble.get("toolCalls") or []:
                        if isinstance(tc, dict):
                            tc_name = tc.get("toolName", "unknown")
                            tc_input = tc.get("toolInput", {})
                            parts.append(
                                f"\n**Tool Call: {tc_name}**\n```json\n{json.dumps(tc_input, indent=2)}\n```"
                            )
                    for tr in bubble.get("toolResults") or []:
                        if isinstance(tr, dict):
                            tr_name = tr.get("toolName", "unknown")
                            tr_content = tr.get("content") or tr.get("result") or ""
                            parts.append(f"\n**Tool Result: {tr_name}**\n{tr_content}")
                    final = "".join(parts).strip()
                    if final:
                        role = "user" if bubble_type == "user" else "assistant"
                        yield tab_id, role, final, str(db)

        composer_data = _jget(cur, "ItemTable", "composer.composerData")
        if composer_data:
            for comp in composer_data.get("allComposers", []):
                comp_id = comp.get("composerId", "unknown")
                for msg in comp.get("messages", []):
                    content = msg.get("content", "")
                    if content:
                        yield comp_id, msg.get("role", "assistant"), content, str(db)

        # Older Cursor format: aiService.prompts / aiService.generations
        for key_prefix in ["aiService.prompts", "aiService.generations"]:
            try:
                cur.execute(
                    "SELECT key, value FROM ItemTable WHERE key LIKE ?",
                    (f"{key_prefix}%",),
                )
                for _key, raw in cur.fetchall():
                    try:
                        data = json.loads(raw)
                        if isinstance(data, list):
                            for item in data:
                                if "id" in item and "text" in item:
                                    role = (
                                        "user"
                                        if "prompts" in key_prefix
                                        else "assistant"
                                    )
                                    yield (
                                        item.get("id", "unknown"),
                                        role,
                                        item.get("text", ""),
                                        str(db),
                                    )
                    except json.JSONDecodeError:
                        continue
            except sqlite3.Error:
                continue

    except sqlite3.DatabaseError as exc:
        logger.debug("ItemTable error %s: %s", db, exc)
    finally:
        if "con" in locals():
            con.close()


def iter_composer_data(db: pathlib.Path) -> Iterable[tuple]:
    """Yield (composerId, composerData dict, db_path) from cursorDiskKV."""
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
        cur = con.cursor()
        cur.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='cursorDiskKV'"
        )
        if not cur.fetchone():
            con.close()
            return
        cur.execute(
            "SELECT key, value FROM cursorDiskKV WHERE key LIKE 'composerData:%'"
        )
    except sqlite3.DatabaseError as exc:
        logger.debug("DB error %s: %s", db, exc)
        return

    for key, value in cur.fetchall():
        try:
            if value is None:
                continue
            composer_data = json.loads(value)
            composer_id = key.split(":")[1]
            yield composer_id, composer_data, str(db)
        except Exception:
            continue

    con.close()


# ---------------------------------------------------------------------------
# Workspace metadata
# ---------------------------------------------------------------------------


def _project_name_from_path(root_path: str) -> str:
    if not root_path or root_path == "/":
        return "Root"
    parts = [p for p in root_path.split("/") if p]
    username = os.path.basename(os.path.expanduser("~"))
    home_idx = -1
    for i, part in enumerate(parts):
        if part in ("Users", "home"):
            home_idx = i + 1
            break
    if 0 <= home_idx < len(parts) and parts[home_idx] == username:
        if len(parts) <= home_idx + 1:
            return "Home Directory"
    containers = {"Documents", "Projects", "Code", "workspace", "repos", "git", "src", "codebase"}
    system_dirs = {"Library", "Applications", "System", "var", "opt", "tmp"}
    start = home_idx + 1 if home_idx >= 0 else 0
    for part in reversed(parts[start:]):
        if part not in containers and part not in system_dirs and part != username:
            return part
    return parts[-1] if parts else "Unknown Project"


def _project_name_from_git(db: pathlib.Path) -> str | None:
    """Try to extract a project name from the git repo recorded in a workspace DB."""
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
        cur = con.cursor()
        git_data = _jget(cur, "ItemTable", "scm:view:visibleRepositories")
        con.close()
        if not isinstance(git_data, dict):
            return None
        for repo in git_data.get("all", []):
            if isinstance(repo, str) and "git:Git:file:///" in repo:
                path_parts = [p for p in repo.split("file:///")[-1].split("/") if p]
                if path_parts:
                    return path_parts[-1]
    except Exception:
        pass
    return None


def workspace_info(db: pathlib.Path) -> tuple[dict, dict]:
    """Return (project_dict, composer_metadata_dict) for a workspace DB."""
    proj = {"name": "(unknown)", "rootPath": "(unknown)"}
    comp_meta: dict = {}
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
        cur = con.cursor()

        entries = _jget(cur, "ItemTable", "history.entries") or []
        paths = [
            e.get("editor", {}).get("resource", "")[len("file:///"):]
            for e in entries
            if e.get("editor", {}).get("resource", "").startswith("file:///")
        ]
        if paths:
            prefix = os.path.commonprefix(paths)
            root_dir = prefix[: prefix.rfind("/")]
            if root_dir:
                proj = {
                    "name": _project_name_from_path(root_dir),
                    "rootPath": "/" + root_dir.lstrip("/"),
                }

        if proj["name"] in ("(unknown)", "Home Directory"):
            sel = _jget(cur, "ItemTable", "debug.selectedroot")
            if isinstance(sel, str) and sel.startswith("file:///"):
                path = "/" + sel[len("file:///"):].strip("/")
                name = _project_name_from_path(path)
                if name not in ("Home Directory", "Root"):
                    proj = {"name": name, "rootPath": path}

        if proj["name"] in ("(unknown)", "Home Directory"):
            git_name = _project_name_from_git(db)
            if git_name:
                proj["name"] = git_name

        cd = _jget(cur, "ItemTable", "composer.composerData") or {}
        for c in cd.get("allComposers", []):
            comp_meta[c["composerId"]] = {
                "title": c.get("name", "(untitled)"),
                "createdAt": c.get("createdAt"),
                "lastUpdatedAt": c.get("lastUpdatedAt"),
            }
        chat_data = (
            _jget(cur, "ItemTable", "workbench.panel.aichat.view.aichat.chatdata") or {}
        )
        for tab in chat_data.get("tabs", []):
            tid = tab.get("tabId")
            if tid and tid not in comp_meta:
                comp_meta[tid] = {
                    "title": f"Chat {tid[:8]}",
                    "createdAt": None,
                    "lastUpdatedAt": None,
                }

    except sqlite3.DatabaseError as exc:
        logger.debug("workspace_info error %s: %s", db, exc)
    finally:
        if "con" in locals():
            con.close()

    return proj, comp_meta


# ---------------------------------------------------------------------------
# Extraction pipeline
# ---------------------------------------------------------------------------


def get_all_chats(root: pathlib.Path) -> list[Dict[str, Any]]:
    ws_proj: Dict[str, Dict] = {}
    comp_meta: Dict[str, Dict] = {}
    comp2ws: Dict[str, str] = {}
    sessions: Dict[str, Dict] = defaultdict(lambda: {"messages": []})

    for ws_id, db in workspaces(root):
        proj, meta = workspace_info(db)
        ws_proj[ws_id] = proj
        for cid, m in meta.items():
            comp_meta[cid] = m
            comp2ws[cid] = ws_id
        for cid, role, text, db_path in iter_chat_from_item_table(db):
            sessions[cid]["messages"].append({"role": role, "content": text})
            sessions[cid].setdefault("db_path", db_path)
            comp_meta.setdefault(
                cid,
                {"title": f"Chat {cid[:8]}", "createdAt": None, "lastUpdatedAt": None},
            )
            comp2ws.setdefault(cid, ws_id)

    global_db = global_storage_path(root)
    if global_db:
        for cid, role, text, db_path, created_at in iter_bubbles_from_disk_kv(global_db):
            sessions[cid]["messages"].append(
                {"role": role, "content": text, "created_at": created_at}
            )
            sessions[cid].setdefault("db_path", db_path)
            comp_meta.setdefault(
                cid,
                {"title": f"Chat {cid[:8]}", "createdAt": None, "lastUpdatedAt": None},
            )
            comp2ws.setdefault(cid, "(global)")

        for cid, data, db_path in iter_composer_data(global_db):
            comp_meta.setdefault(
                cid,
                {
                    "title": f"Chat {cid[:8]}",
                    "createdAt": data.get("createdAt"),
                    "lastUpdatedAt": data.get("createdAt"),
                },
            )
            comp2ws.setdefault(cid, "(global)")
            sessions[cid].setdefault("db_path", db_path)
            for msg in data.get("conversation", []):
                msg_type = msg.get("type")
                if msg_type is None:
                    continue
                role = "user" if msg_type == 1 else "assistant"
                content = msg.get("text", "")
                if content and isinstance(content, str):
                    sessions[cid]["messages"].append({"role": role, "content": content})

        try:
            con = sqlite3.connect(f"file:{global_db}?mode=ro", uri=True)
            chat_data = _jget(
                con.cursor(),
                "ItemTable",
                "workbench.panel.aichat.view.aichat.chatdata",
            )
            if chat_data:
                for tab in chat_data.get("tabs", []):
                    tid = tab.get("tabId")
                    if not tid:
                        continue
                    comp_meta.setdefault(
                        tid,
                        {
                            "title": f"Global Chat {tid[:8]}",
                            "createdAt": None,
                            "lastUpdatedAt": None,
                        },
                    )
                    comp2ws.setdefault(tid, "(global)")
                    for bubble in tab.get("bubbles", []):
                        parts = []
                        text = bubble.get("text") or bubble.get("content") or ""
                        if text and isinstance(text, str):
                            parts.append(text)
                        for tc in bubble.get("toolCalls") or []:
                            if isinstance(tc, dict):
                                tc_name = tc.get("toolName", "unknown")
                                tc_input = tc.get("toolInput", {})
                                parts.append(
                                    f"\n**Tool Call: {tc_name}**\n```json\n{json.dumps(tc_input, indent=2)}\n```"
                                )
                        for tr in bubble.get("toolResults") or []:
                            if isinstance(tr, dict):
                                tr_name = tr.get("toolName", "unknown")
                                tr_content = tr.get("content") or tr.get("result") or ""
                                parts.append(f"\n**Tool Result: {tr_name}**\n{tr_content}")
                        final = "".join(parts).strip()
                        if final:
                            role = "user" if bubble.get("type") == "user" else "assistant"
                            sessions[tid]["messages"].append({"role": role, "content": final})
            con.close()
        except Exception as exc:
            logger.debug("Global ItemTable error: %s", exc)

    out = []
    for cid, data in sessions.items():
        if not data["messages"]:
            continue
        msgs = data["messages"]
        if any(m.get("created_at") for m in msgs):
            msgs = sorted(msgs, key=lambda m: m.get("created_at") or "")
        msgs = [{"role": m["role"], "content": m["content"]} for m in msgs]

        entry = {
            "session_id": cid,
            "project": ws_proj.get(
                comp2ws.get(cid, ""), {"name": "(unknown)", "rootPath": "(unknown)"}
            ),
            "session": {
                "composerId": cid,
                **comp_meta.get(
                    cid,
                    {"title": "(untitled)", "createdAt": None, "lastUpdatedAt": None},
                ),
            },
            "messages": msgs,
        }
        if "db_path" in data:
            entry["db_path"] = data["db_path"]
        out.append(entry)

    out.sort(key=lambda s: str(s["session"].get("lastUpdatedAt") or ""), reverse=True)
    return out


# ---------------------------------------------------------------------------
# Streamlit UI
# ---------------------------------------------------------------------------

def chat_preview(chat: dict) -> str:
    for msg in chat.get("messages", []):
        if msg["role"] == "user" and msg.get("content"):
            preview = msg["content"].strip().replace("\n", " ")
            return preview[:80] + ("..." if len(preview) > 80 else "")
    return "(no user message)"


def render_messages(messages: list) -> None:
    for msg in messages:
        role = msg.get("role", "assistant")
        content = msg.get("content", "")

        if role == "tool":
            first_line = content.split("\n")[0] if content else "Tool call"
            tool_label = (
                first_line.replace("**", "").replace("`", "").replace("*", "").strip()
            )
            with st.expander(f"[tool] {tool_label}", expanded=False):
                st.markdown(content)
        elif role == "user":
            with st.chat_message("user"):
                st.markdown(content)
        else:
            with st.chat_message("assistant"):
                st.markdown(content)


def _run_ui() -> None:
    st.set_page_config(
        page_title="Cursor View",
        page_icon=None,
        layout="wide",
        initial_sidebar_state="expanded",
    )
    st.markdown(
        """
<style>
[data-testid="stExpander"] { border: 1px solid #9c7cf4; border-radius: 6px; margin-bottom: 4px; }
</style>
""",
        unsafe_allow_html=True,
    )

    @st.cache_data(ttl=60, show_spinner="Scanning Cursor databases...")
    def load_chats(cursor_path: str) -> list:
        return get_all_chats(pathlib.Path(cursor_path))

    if "cursor_path" not in st.session_state:
        path, source = resolve_cursor_path()
        st.session_state.cursor_path = path
        st.session_state.cursor_path_source = source

    with st.sidebar:
        st.title("Cursor View")

        with st.expander("Settings", expanded=False):
            st.caption(f"Source: *{st.session_state.cursor_path_source}*")

            new_path = st.text_input(
                "Cursor data path",
                value=st.session_state.cursor_path,
                help=(
                    "Path to Cursor's data directory. "
                    "Change this to point at a backup or a non-default install."
                ),
            )
            if new_path != st.session_state.cursor_path:
                st.session_state.cursor_path = new_path
                st.session_state.cursor_path_source = "session (unsaved)"
                st.cache_data.clear()
                st.rerun()

            col_save, col_clear = st.columns(2)
            if col_save.button("Save as default", use_container_width=True):
                save_config({"cursor_path": st.session_state.cursor_path})
                st.session_state.cursor_path_source = "config file"
                st.success("Saved to ~/.cursor-viewer/config.json")

            has_saved = config_file().exists()
            if col_clear.button(
                "Clear default",
                use_container_width=True,
                disabled=not has_saved,
            ):
                clear_config()
                path, source = resolve_cursor_path()
                st.session_state.cursor_path = path
                st.session_state.cursor_path_source = source
                st.cache_data.clear()
                st.rerun()

        active_path = st.session_state.cursor_path
        root = pathlib.Path(active_path)

        if not root.exists():
            st.error(f"Path not found:\n`{active_path}`")
            st.stop()

        chats = load_chats(active_path)
        projects: Dict[str, list] = defaultdict(list)
        for chat in chats:
            projects[chat["project"].get("name", "(unknown)")].append(chat)

        st.caption(f"{len(chats)} chats · {len(projects)} projects")

        if st.button("Refresh", use_container_width=True):
            st.cache_data.clear()
            st.rerun()

        st.divider()

        query = st.text_input("Search", placeholder="project name or message content...")

        def matches(chat: dict) -> bool:
            if not query:
                return True
            q = query.lower()
            if q in chat["project"].get("name", "").lower():
                return True
            return any(
                q in (m.get("content") or "").lower() for m in chat.get("messages", [])
            )

        filtered: Dict[str, list] = defaultdict(list)
        for chat in chats:
            if matches(chat):
                filtered[chat["project"].get("name", "(unknown)")].append(chat)

        if "selected_id" not in st.session_state:
            st.session_state.selected_id = None

        for proj_name, proj_chats in filtered.items():
            with st.expander(f"{proj_name}  ({len(proj_chats)})", expanded=False):
                for chat in proj_chats:
                    label = chat_preview(chat)
                    if st.button(label, key=f"btn_{chat['session_id']}", use_container_width=True):
                        st.session_state.selected_id = chat["session_id"]

    selected = next(
        (c for c in chats if c["session_id"] == st.session_state.get("selected_id")),
        None,
    )

    if selected is None:
        st.markdown("## Cursor Chat History")
        st.info("Select a chat from the sidebar to view it.")
        st.markdown(
            f"**{len(chats)}** chats indexed across **{len(projects)}** projects."
        )
        st.stop()

    proj = selected["project"]
    session = selected["session"]
    msgs = selected.get("messages", [])

    st.markdown(f"## {proj.get('name', '(unknown)')}")
    col1, col2, col3 = st.columns(3)
    col1.caption(f"`{proj.get('rootPath', '')}`")
    updated = session.get("lastUpdatedAt") or session.get("createdAt") or ""
    updated_str = str(updated)[:19].replace("T", " ") if updated else "unknown"
    col2.caption(f"Updated: {updated_str}")
    col3.caption(f"{len(msgs)} messages")
    st.divider()

    render_messages(msgs)


def main():
    """CLI entry point — used by pipx / pip install."""
    import argparse
    import sys
    from streamlit.web import cli as stcli

    parser = argparse.ArgumentParser(
        prog="cursor-viewer",
        description="Browse and search Cursor AI chat histories in your browser.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
configuration priority:
  1. --cursor-path flag          (highest)
  2. CURSOR_DATA_PATH env var
  3. ~/.cursor-viewer/config.json  (saved via the Settings panel in the UI)
  4. platform default              (lowest)

examples:
  cursor-viewer
  cursor-viewer --cursor-path /Volumes/Backup/Library/Application\\ Support/Cursor
  cursor-viewer --port 8080
  CURSOR_DATA_PATH=/path/to/cursor cursor-viewer
""",
    )
    parser.add_argument(
        "--cursor-path",
        metavar="PATH",
        help="path to Cursor's data directory (overrides env var and config file)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8501,
        metavar="PORT",
        help="port to run the web UI on (default: 8501)",
    )
    args = parser.parse_args()

    if args.cursor_path:
        os.environ["CURSOR_DATA_PATH"] = args.cursor_path

    sys.argv = ["streamlit", "run", __file__, f"--server.port={args.port}"]
    sys.exit(stcli.main())


if __name__ == "__main__":
    _run_ui()
