"""Whisper-style CLI for Qwen3-TTS."""

__version__ = "0.4.0"
