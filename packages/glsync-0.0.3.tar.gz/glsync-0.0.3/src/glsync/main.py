#!/usr/bin/env python3
"""
Gestionnaire d'arborescence GitLab
Clone les projets GitLab et analyse l'état des branches et des modifications
"""

import json
import subprocess
from pathlib import Path
from typing import Dict, List, Set, Tuple, Optional
import typer
import urllib.request
import urllib.parse
import urllib.error
from tabulate import tabulate


class GitLabManager:
    def __init__(self, creds_file: str = "creds.json", base_dir: str = "./repos", gitlab_url: Optional[str] = None):
        """
        Initialise le gestionnaire GitLab
        
        Args:
            creds_file: Chemin vers le fichier contenant les tokens GitLab
            base_dir: Répertoire de base pour cloner les projets
            gitlab_url: URL GitLab à utiliser (si None, sera déterminée depuis l'URL du groupe)
        """
        self.creds_file = creds_file
        self.base_dir = Path(base_dir)
        self.creds = self._load_creds()
        self.gitlab_url = gitlab_url or 'https://gitlab.com'
        self.token = self._get_token_for_url(self.gitlab_url)
        
    def _load_creds(self) -> Dict[str, str]:
        """Charge les credentials depuis creds.json"""
        try:
            with open(self.creds_file, 'r') as f:
                creds = json.load(f)
                if not isinstance(creds, dict):
                    raise ValueError(f"Format invalide dans {self.creds_file}: doit être un objet JSON")
                return creds
        except FileNotFoundError:
            raise FileNotFoundError(f"Fichier {self.creds_file} introuvable")
        except json.JSONDecodeError:
            raise ValueError(f"Fichier {self.creds_file} invalide")
    
    @staticmethod
    def _extract_base_url_static(url: str) -> str:
        """
        Extrait l'URL de base GitLab depuis une URL complète (méthode statique)
        
        Args:
            url: URL complète (ex: https://gitlab.com/organisation/example)
            
        Returns:
            URL de base (ex: https://gitlab.com)
        """
        # Déterminer le protocole
        protocol = 'https://'
        if url.startswith('http://'):
            protocol = 'http://'
        
        # Nettoyer l'URL
        clean_url = url.replace('http://', '').replace('https://', '')
        
        # Extraire le domaine
        if '/' in clean_url:
            domain = clean_url.split('/', 1)[0]
        else:
            domain = clean_url
        
        # Reconstruire l'URL avec le protocole
        return f"{protocol}{domain}"
    
    def _get_token_for_url(self, gitlab_url: str) -> str:
        """
        Récupère le token pour une URL GitLab donnée
        
        Args:
            gitlab_url: URL GitLab (ex: https://gitlab.com)
            
        Returns:
            Token GitLab
        """
        # Normaliser l'URL (enlever le slash final)
        normalized_url = gitlab_url.rstrip('/')
        
        # Chercher le token exact
        if normalized_url in self.creds:
            token = self.creds[normalized_url]
            if not token or token == "[TOKEN]" or token == "[OTHER TOKEN]":
                raise ValueError(f"Token non configuré pour {normalized_url} dans {self.creds_file}")
            return token
        
        # Chercher avec http si https n'est pas trouvé (et vice versa)
        if normalized_url.startswith('https://'):
            http_url = normalized_url.replace('https://', 'http://')
            if http_url in self.creds:
                token = self.creds[http_url]
                if not token or token == "[TOKEN]" or token == "[OTHER TOKEN]":
                    raise ValueError(f"Token non configuré pour {http_url} dans {self.creds_file}")
                return token
        elif normalized_url.startswith('http://'):
            https_url = normalized_url.replace('http://', 'https://')
            if https_url in self.creds:
                token = self.creds[https_url]
                if not token or token == "[TOKEN]" or token == "[OTHER TOKEN]":
                    raise ValueError(f"Token non configuré pour {https_url} dans {self.creds_file}")
                return token
        
        raise ValueError(f"Aucun token trouvé pour {normalized_url} dans {self.creds_file}")
    
    def _run_command(self, command: List[str], cwd: Optional[Path] = None, 
                     capture_output: bool = True) -> Tuple[int, str, str]:
        """
        Exécute une commande dans un subshell
        
        Args:
            command: Liste des arguments de la commande
            cwd: Répertoire de travail
            capture_output: Si True, capture stdout et stderr
            
        Returns:
            Tuple (code_retour, stdout, stderr)
        """
        try:
            result = subprocess.run(
                command,
                cwd=cwd,
                capture_output=capture_output,
                text=True,
                check=False
            )
            return result.returncode, result.stdout, result.stderr
        except Exception as e:
            return 1, "", str(e)
    
    def clone_project(self, project_url: str, project_path: Path) -> bool:
        """
        Clone un projet GitLab via SSH
        
        Args:
            project_url: URL SSH du projet GitLab (format: git@gitlab.com:user/repo.git)
            project_path: Chemin local où cloner le projet
            
        Returns:
            True si le clone a réussi, False sinon
        """
        # Convertir l'URL en format SSH si nécessaire
        ssh_url = self._convert_to_ssh_url(project_url)
        
        print(f"Clonage de {ssh_url} vers {project_path}...")
        
        # Créer le répertoire parent si nécessaire
        project_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Cloner avec git clone dans un subshell via SSH
        code, stdout, stderr = self._run_command(
            ['git', 'clone', ssh_url, str(project_path)]
        )
        
        if code == 0:
            print(f"✓ Cloné avec succès: {project_path}")
            return True
        else:
            print(f"✗ Erreur lors du clonage: {stderr}")
            return False
    
    def _fetch_and_merge(self, repo_path: Path) -> bool:
        """
        Fait un git fetch puis un git merge --ff-only de la branche courante
        
        Args:
            repo_path: Chemin vers le dépôt Git
            
        Returns:
            True si le fetch et le merge ont réussi, False sinon
        """
        if not (repo_path / '.git').exists():
            return False
        
        # Faire un git fetch
        print(f"Récupération des références distantes pour {repo_path}...")
        code, stdout, stderr = self._run_command(
            ['git', 'fetch', '--all'],
            cwd=repo_path
        )
        if code != 0:
            print(f"⚠ Erreur lors du fetch: {stderr}")
            return False
        
        print(f"✓ Fetch réussi pour {repo_path}")
        
        # Récupérer la branche courante
        code, stdout, _ = self._run_command(
            ['git', 'rev-parse', '--abbrev-ref', 'HEAD'],
            cwd=repo_path
        )
        if code != 0:
            print(f"⚠ Impossible de déterminer la branche courante")
            return False
        
        current_branch = stdout.strip()
        if not current_branch:
            print(f"⚠ Aucune branche courante détectée")
            return False
        
        # Récupérer le nom du remote (généralement 'origin')
        code, stdout, _ = self._run_command(
            ['git', 'remote'],
            cwd=repo_path
        )
        if code != 0:
            print(f"⚠ Impossible de déterminer le remote")
            return False
        
        remote_name = stdout.strip().split('\n')[0] if stdout.strip() else 'origin'
        
        # Faire un merge --ff-only de la branche distante
        remote_branch = f"{remote_name}/{current_branch}"
        print(f"Fusion fast-forward uniquement de {remote_branch} vers {current_branch}...")
        code, stdout, stderr = self._run_command(
            ['git', 'merge', '--ff-only', remote_branch],
            cwd=repo_path
        )
        if code == 0:
            print(f"✓ Merge réussi pour {repo_path}")
            return True
        else:
            # Le merge --ff-only peut échouer si la branche a divergé, c'est normal
            if "Not possible to fast-forward" in stderr or "fatal: Not possible to fast-forward" in stderr:
                print(f"⚠ Merge fast-forward impossible (branche divergée ou en avance): {repo_path}")
            else:
                print(f"⚠ Erreur lors du merge: {stderr}")
            return False
    
    def _convert_to_ssh_url(self, url: str) -> str:
        """
        Convertit une URL HTTP/HTTPS en URL SSH
        
        Args:
            url: URL du projet (HTTP, HTTPS ou SSH)
            
        Returns:
            URL SSH (format: git@gitlab.com:user/repo.git)
        """
        # Si c'est déjà une URL SSH, la retourner telle quelle
        if url.startswith('git@'):
            return url
        
        # Supprimer les préfixes HTTP/HTTPS
        clean_url = url.replace('https://', '').replace('http://', '').rstrip('/')
        
        # Supprimer .git à la fin si présent
        if clean_url.endswith('.git'):
            clean_url = clean_url[:-4]
        
        # Extraire le domaine et le chemin
        if '/' in clean_url:
            parts = clean_url.split('/', 1)
            domain = parts[0]
            path = parts[1]
            
            # Construire l'URL SSH
            return f"git@{domain}:{path}.git"
        else:
            # Si pas de slash, utiliser le domaine GitLab configuré
            domain = self.gitlab_url.replace('https://', '').replace('http://', '').rstrip('/')
            return f"git@{domain}:{clean_url}.git"
    
    def _extract_group_path(self, url: str) -> str:
        """
        Extrait le chemin du groupe/namespace depuis une URL GitLab
        
        Args:
            url: URL GitLab (ex: https://gitlab.com/organisation/example)
            
        Returns:
            Chemin du groupe (ex: organisation/example)
        """
        # Nettoyer l'URL
        url = url.replace('https://', '').replace('http://', '').rstrip('/')
        
        # Extraire le domaine et le chemin
        if '/' in url:
            parts = url.split('/', 1)
            domain = parts[0]
            path = parts[1] if len(parts) > 1 else ''
            
            # Si c'est gitlab.com ou un domaine personnalisé, retourner le chemin
            if 'gitlab' in domain or domain == self.gitlab_url.replace('https://', '').replace('http://', ''):
                return path
            else:
                # Sinon, tout après le domaine est le chemin
                return path
        
        return url
    
    def _get_group_id(self, group_path: str) -> Optional[int]:
        """
        Récupère l'ID d'un groupe GitLab depuis son chemin
        
        Args:
            group_path: Chemin du groupe (ex: organisation/example)
            
        Returns:
            ID du groupe ou None si introuvable
        """
        # Encoder le chemin pour l'URL
        encoded_path = urllib.parse.quote(group_path, safe='')
        api_url = f"{self.gitlab_url}/api/v4/groups/{encoded_path}"
        
        try:
            request = urllib.request.Request(api_url)
            request.add_header('PRIVATE-TOKEN', self.token)
            
            with urllib.request.urlopen(request) as response:
                data = json.loads(response.read().decode())
                return data.get('id')
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return None
            raise
        except Exception as e:
            raise Exception(f"Erreur lors de la récupération du groupe: {e}")
    
    def _fetch_projects_from_group(self, group_path: str) -> List[Dict[str, str]]:
        """
        Récupère la liste des projets d'un groupe GitLab via l'API
        
        Args:
            group_path: Chemin du groupe (ex: organisation/example)
            
        Returns:
            Liste de dictionnaires avec 'url' (SSH) et 'path'
        """
        # Encoder le chemin pour l'URL
        encoded_path = urllib.parse.quote(group_path, safe='')
        api_url = f"{self.gitlab_url}/api/v4/groups/{encoded_path}/projects"
        
        projects = []
        page = 1
        per_page = 100
        
        while True:
            # Ajouter la pagination
            paginated_url = f"{api_url}?page={page}&per_page={per_page}&include_subgroups=true"
            
            try:
                request = urllib.request.Request(paginated_url)
                request.add_header('PRIVATE-TOKEN', self.token)
                
                with urllib.request.urlopen(request) as response:
                    data = json.loads(response.read().decode())
                    
                    if not data:
                        break
                    
                    for project in data:
                        # Récupérer l'URL SSH du projet
                        ssh_url = project.get('ssh_url_to_repo', '')
                        if not ssh_url:
                            # Si pas d'URL SSH, construire depuis le path_with_namespace
                            path_with_namespace = project.get('path_with_namespace', '')
                            if path_with_namespace:
                                # Extraire le domaine depuis gitlab_url
                                domain = self.gitlab_url.replace('https://', '').replace('http://', '').rstrip('/')
                                ssh_url = f"git@{domain}:{path_with_namespace}.git"
                        
                        # Utiliser path_with_namespace pour préserver l'arborescence
                        path_with_namespace = project.get('path_with_namespace', '')
                        project_name = project.get('path', '')
                        project_id = project.get('id')  # ID du projet GitLab
                        
                        projects.append({
                            'url': ssh_url,
                            'path': project_name,
                            'path_with_namespace': path_with_namespace,
                            'id': project_id
                        })
                    
                    # Vérifier s'il y a une page suivante
                    if len(data) < per_page:
                        break
                    
                    page += 1
                    
            except urllib.error.HTTPError as e:
                if e.code == 404:
                    raise ValueError(f"Groupe '{group_path}' introuvable")
                raise Exception(f"Erreur API GitLab: {e.code} - {e.reason}")
            except Exception as e:
                raise Exception(f"Erreur lors de la récupération des projets: {e}")
        
        return projects
    
    def clone_projects_from_list(self, projects: List[Dict[str, str]]):
        """
        Clone une liste de projets GitLab en préservant l'arborescence
        
        Args:
            projects: Liste de dictionnaires avec 'url', 'path' et 'path_with_namespace'
        """
        self.base_dir.mkdir(parents=True, exist_ok=True)
        
        for project in projects:
            project_url = project['url']
            
            # Utiliser path_with_namespace pour reproduire l'arborescence GitLab
            if 'path_with_namespace' in project and project['path_with_namespace']:
                # path_with_namespace contient le chemin complet (ex: organisation/example/projet)
                # On l'utilise pour créer la structure de dossiers locale
                namespace_path = project['path_with_namespace']
                project_path = self.base_dir / namespace_path
            elif 'path' in project and project['path']:
                # Fallback sur path si path_with_namespace n'est pas disponible
                project_path = self.base_dir / project['path']
            else:
                # Dernier recours : extraire le nom du projet depuis l'URL
                project_name = project_url.rstrip('/').split('/')[-1].replace('.git', '')
                project_path = self.base_dir / project_name
            
            # Ne pas cloner si le répertoire existe déjà, mais faire un fetch et merge
            if project_path.exists():
                print(f"⚠ Répertoire existant: {project_path}")
                # Vérifier si c'est un dépôt Git valide
                if (project_path / '.git').exists():
                    # Faire un git fetch et merge même si le répertoire existe déjà
                    self._fetch_and_merge(project_path)
                else:
                    print(f"⚠ Le répertoire existe mais n'est pas un dépôt Git valide")
                continue
            
            # Cloner le projet
            if self.clone_project(project_url, project_path):
                # Faire un git fetch et merge après le clone réussi
                self._fetch_and_merge(project_path)
    
    def get_branches(self, repo_path: Path) -> Tuple[Set[str], Set[str]]:
        """
        Récupère les branches locales et distantes d'un dépôt
        
        Args:
            repo_path: Chemin vers le dépôt Git
            
        Returns:
            Tuple (branches_locales, branches_distantes)
        """
        local_branches = set()
        remote_branches = set()
        
        if not (repo_path / '.git').exists():
            return local_branches, remote_branches
        
        # Récupérer les branches locales
        code, stdout, _ = self._run_command(
            ['git', 'branch', '--format=%(refname:short)'],
            cwd=repo_path
        )
        if code == 0:
            local_branches = {b.strip() for b in stdout.strip().split('\n') if b.strip()}
        
        # Récupérer les branches distantes avec for-each-ref pour un meilleur contrôle
        code, stdout, _ = self._run_command(
            ['git', 'for-each-ref', '--format=%(refname:short)', 'refs/remotes/'],
            cwd=repo_path
        )
        if code == 0:
            # Nettoyer les références
            remote_branches = set()
            for branch in stdout.strip().split('\n'):
                branch = branch.strip()
                if not branch:
                    continue
                
                # Ignorer les références HEAD et les remotes sans branche
                if branch.endswith('/HEAD') or '/' not in branch:
                    continue
                
                # Enlever le préfixe remote (ex: 'origin/master' -> 'master')
                # Format attendu: origin/branch-name ou remote-name/branch-name
                parts = branch.split('/', 1)
                if len(parts) == 2:
                    remote_name = parts[0]
                    branch_name = parts[1]
                    # Ignorer si c'est juste le nom du remote sans branche
                    # Ignorer les branches qui commencent par "renovate/"
                    if branch_name and branch_name != 'HEAD' and not branch_name.startswith('renovate/'):
                        remote_branches.add(branch_name)
        
        return local_branches, remote_branches
    
    def get_branch_status(self, repo_path: Path, branch: str) -> Optional[str]:
        """
        Vérifie si une branche locale est synchronisée avec la distante
        
        Args:
            repo_path: Chemin vers le dépôt Git
            branch: Nom de la branche
            
        Returns:
            'ahead', 'behind', 'diverged', 'synced', ou None si pas de tracking
        """
        if not (repo_path / '.git').exists():
            return None
        
        # Récupérer la branche de tracking
        code, stdout, _ = self._run_command(
            ['git', 'rev-parse', '--abbrev-ref', '--symbolic-full-name', f'{branch}@{{upstream}}'],
            cwd=repo_path
        )
        
        if code != 0:
            return None  # Pas de branche de tracking
        
        tracking_branch = stdout.strip()
        
        # Comparer les commits
        code, stdout, _ = self._run_command(
            ['git', 'rev-list', '--left-right', '--count', f'{branch}...{tracking_branch}'],
            cwd=repo_path
        )
        
        if code != 0:
            return None
        
        ahead, behind = map(int, stdout.strip().split('\t'))
        
        if ahead > 0 and behind > 0:
            return 'diverged'
        elif ahead > 0:
            return 'ahead'
        elif behind > 0:
            return 'behind'
        else:
            return 'synced'
    
    def has_uncommitted_changes(self, repo_path: Path) -> bool:
        """
        Vérifie si un dépôt a des fichiers non commités
        
        Args:
            repo_path: Chemin vers le dépôt Git
            
        Returns:
            True si des fichiers non commités existent
        """
        if not (repo_path / '.git').exists():
            return False
        
        code, stdout, _ = self._run_command(
            ['git', 'status', '--porcelain'],
            cwd=repo_path
        )
        
        return code == 0 and stdout.strip() != ''
    
    def get_repo_http_url(self, repo_path: Path) -> Optional[str]:
        """
        Récupère l'URL HTTP du dépôt depuis le remote
        
        Args:
            repo_path: Chemin vers le dépôt Git
            
        Returns:
            URL HTTP du dépôt ou None si introuvable
        """
        if not (repo_path / '.git').exists():
            return None
        
        # Récupérer l'URL du remote origin
        code, stdout, _ = self._run_command(
            ['git', 'remote', 'get-url', 'origin'],
            cwd=repo_path
        )
        
        if code != 0:
            return None
        
        remote_url = stdout.strip()
        
        # Convertir l'URL SSH en URL HTTP si nécessaire
        if remote_url.startswith('git@'):
            # Format: git@gitlab.com:user/repo.git
            url = remote_url.replace('git@', '').replace(':', '/', 1)
            if url.endswith('.git'):
                url = url[:-4]
            return f"https://{url}"
        elif remote_url.startswith('http://') or remote_url.startswith('https://'):
            return remote_url
        
        return None
    
    def get_repo_path_with_namespace(self, repo_path: Path) -> Optional[str]:
        """
        Récupère le path_with_namespace d'un dépôt local depuis son remote
        
        Args:
            repo_path: Chemin vers le dépôt Git
            
        Returns:
            path_with_namespace (ex: organisation/example/projet) ou None si introuvable
        """
        if not (repo_path / '.git').exists():
            return None
        
        # Récupérer l'URL du remote origin
        code, stdout, _ = self._run_command(
            ['git', 'remote', 'get-url', 'origin'],
            cwd=repo_path
        )
        
        if code != 0:
            return None
        
        remote_url = stdout.strip()
        
        # Extraire le path_with_namespace depuis l'URL
        if remote_url.startswith('git@'):
            # Format: git@gitlab.com:user/repo.git
            url = remote_url.replace('git@', '').replace(':', '/', 1)
            if url.endswith('.git'):
                url = url[:-4]
            # Extraire le domaine et le chemin
            if '/' in url:
                parts = url.split('/', 1)
                if len(parts) == 2:
                    return parts[1]  # Retourner le chemin après le domaine
        elif remote_url.startswith('http://') or remote_url.startswith('https://'):
            # Format: https://gitlab.com/user/repo.git
            url = remote_url.replace('http://', '').replace('https://', '')
            if url.endswith('.git'):
                url = url[:-4]
            # Extraire le domaine et le chemin
            if '/' in url:
                parts = url.split('/', 1)
                if len(parts) == 2:
                    return parts[1]  # Retourner le chemin après le domaine
        
        return None
    
    def _normalize_ssh_url(self, ssh_url: str) -> str:
        """
        Normalise une URL SSH pour la comparaison
        
        Args:
            ssh_url: URL SSH (ex: git@gitlab.com:user/repo.git)
            
        Returns:
            URL SSH normalisée
        """
        if not ssh_url:
            return ''
        
        # Normaliser : enlever les espaces, mettre en minuscule, enlever .git à la fin
        normalized = ssh_url.strip()
        if normalized.endswith('.git'):
            normalized = normalized[:-4]
        
        return normalized
    
    def _get_repo_ssh_url(self, repo_path: Path) -> Optional[str]:
        """
        Récupère l'URL SSH du dépôt depuis le remote
        
        Args:
            repo_path: Chemin vers le dépôt Git
            
        Returns:
            URL SSH du dépôt ou None si introuvable
        """
        if not (repo_path / '.git').exists():
            return None
        
        # Récupérer l'URL du remote origin
        code, stdout, _ = self._run_command(
            ['git', 'remote', 'get-url', 'origin'],
            cwd=repo_path
        )
        
        if code != 0:
            return None
        
        return stdout.strip()
    
    def _get_repo_project_id_from_remote(self, repo_path: Path) -> Optional[int]:
        """
        Tente de récupérer l'ID du projet GitLab depuis le remote (via API)
        
        Args:
            repo_path: Chemin vers le dépôt Git
            
        Returns:
            ID du projet GitLab ou None si introuvable
        """
        http_url = self.get_repo_http_url(repo_path)
        if not http_url:
            return None
        
        # Extraire le path_with_namespace depuis l'URL HTTP
        # Format: https://gitlab.com/organisation/example/projet
        url_parts = http_url.replace('https://', '').replace('http://', '')
        if '/' in url_parts:
            domain = url_parts.split('/', 1)[0]
            path_with_namespace = url_parts.split('/', 1)[1]
            
            # Appeler l'API GitLab pour obtenir l'ID du projet
            try:
                encoded_path = urllib.parse.quote(path_with_namespace, safe='')
                api_url = f"{self.gitlab_url}/api/v4/projects/{encoded_path}"
                
                request = urllib.request.Request(api_url)
                request.add_header('PRIVATE-TOKEN', self.token)
                
                with urllib.request.urlopen(request) as response:
                    data = json.loads(response.read().decode())
                    return data.get('id')
            except Exception:
                return None
        
        return None
    
    def check_local_repos_against_gitlab(self, group_path: str) -> Tuple[List[Path], List[Tuple[Path, str]]]:
        """
        Compare les dépôts locaux avec ceux de GitLab
        
        Args:
            group_path: Chemin du groupe GitLab (ex: organisation/example)
            
        Returns:
            Tuple (dépôts manquants dans GitLab, dépôts déplacés (ancien_path, nouveau_path_with_namespace))
        """
        # Récupérer tous les projets GitLab du groupe
        gitlab_projects = self._fetch_projects_from_group(group_path)
        # Créer un dictionnaire path_with_namespace -> projet pour retrouver facilement
        gitlab_projects_by_path = {project.get('path_with_namespace', ''): project for project in gitlab_projects}
        gitlab_paths = set(gitlab_projects_by_path.keys())
        
        # Créer un dictionnaire par URL SSH normalisée pour trouver les projets déplacés
        gitlab_projects_by_ssh_url = {}
        for project in gitlab_projects:
            ssh_url = project.get('url', '')
            if ssh_url:
                normalized_ssh = self._normalize_ssh_url(ssh_url)
                if normalized_ssh:
                    gitlab_projects_by_ssh_url[normalized_ssh] = project
        
        # Créer un dictionnaire par ID de projet pour une détection plus fiable
        gitlab_projects_by_id = {}
        for project in gitlab_projects:
            project_id = project.get('id')
            if project_id:
                gitlab_projects_by_id[project_id] = project
        
        # Créer aussi un dictionnaire par nom de projet (path) pour une détection alternative
        gitlab_projects_by_name = {}
        for project in gitlab_projects:
            project_name = project.get('path', '')
            if project_name:
                if project_name not in gitlab_projects_by_name:
                    gitlab_projects_by_name[project_name] = []
                gitlab_projects_by_name[project_name].append(project)
        
        # Récupérer tous les dépôts locaux
        local_repos = self.list_all_repos()
        
        # Comparer et trouver les dépôts locaux qui n'existent pas dans GitLab
        missing_in_gitlab = []
        moved_repos = []
        
        for repo_path in local_repos:
            local_path_with_namespace = self.get_repo_path_with_namespace(repo_path)
            local_ssh_url = self._get_repo_ssh_url(repo_path)
            
            found_in_gitlab = False
            project_id = None
            
            # Méthode 1: Essayer de récupérer l'ID du projet depuis l'ancien path_with_namespace
            if local_path_with_namespace:
                try:
                    encoded_path = urllib.parse.quote(local_path_with_namespace, safe='')
                    api_url = f"{self.gitlab_url}/api/v4/projects/{encoded_path}"
                    request = urllib.request.Request(api_url)
                    request.add_header('PRIVATE-TOKEN', self.token)
                    with urllib.request.urlopen(request) as response:
                        data = json.loads(response.read().decode())
                        project_id = data.get('id')
                        if project_id:
                            # Le projet existe toujours avec cet ID, vérifier s'il a été déplacé
                            if project_id in gitlab_projects_by_id:
                                gitlab_project = gitlab_projects_by_id[project_id]
                                gitlab_path_with_namespace = gitlab_project.get('path_with_namespace', '')
                                if gitlab_path_with_namespace != local_path_with_namespace:
                                    # Le projet a été déplacé !
                                    moved_repos.append((repo_path, gitlab_path_with_namespace))
                                    found_in_gitlab = True
                                    continue
                                else:
                                    # Le projet est au bon endroit
                                    found_in_gitlab = True
                                    continue
                except urllib.error.HTTPError as e:
                    if e.code == 404:
                        # L'ancien path n'existe plus, le projet a peut-être été déplacé ou supprimé
                        pass
                    else:
                        # Autre erreur HTTP
                        pass
                except Exception:
                    pass
            
            # Méthode 2: Comparer par URL SSH (si l'URL SSH n'a pas changé après le déplacement)
            if not found_in_gitlab and local_ssh_url:
                normalized_local_ssh = self._normalize_ssh_url(local_ssh_url)
                
                # Chercher ce dépôt dans les projets GitLab par URL SSH
                if normalized_local_ssh in gitlab_projects_by_ssh_url:
                    gitlab_project = gitlab_projects_by_ssh_url[normalized_local_ssh]
                    gitlab_path_with_namespace = gitlab_project.get('path_with_namespace', '')
                    gitlab_project_id = gitlab_project.get('id')
                    
                    # Si on a un project_id local, vérifier qu'il correspond
                    if project_id and gitlab_project_id and project_id == gitlab_project_id:
                        # C'est le même projet, vérifier s'il a été déplacé
                        if local_path_with_namespace and local_path_with_namespace != gitlab_path_with_namespace:
                            moved_repos.append((repo_path, gitlab_path_with_namespace))
                            found_in_gitlab = True
                            continue
                        else:
                            found_in_gitlab = True
                            continue
                    elif not project_id:
                        # On n'a pas pu récupérer l'ID, mais l'URL SSH correspond
                        # Vérifier si le path_with_namespace est différent
                        if local_path_with_namespace and local_path_with_namespace != gitlab_path_with_namespace:
                            moved_repos.append((repo_path, gitlab_path_with_namespace))
                            found_in_gitlab = True
                            continue
                        elif not local_path_with_namespace:
                            # On ne connaît pas le path_with_namespace local, mais GitLab en a un
                            # Vérifier si le dépôt est au bon endroit
                            expected_local_path = self.base_dir / gitlab_path_with_namespace if gitlab_path_with_namespace else None
                            current_local_path = repo_path.resolve()
                            if expected_local_path and expected_local_path.resolve() != current_local_path:
                                moved_repos.append((repo_path, gitlab_path_with_namespace))
                                found_in_gitlab = True
                                continue
                        else:
                            found_in_gitlab = True
                            continue
            
            # Si on arrive ici, le dépôt n'a pas été trouvé dans GitLab
            if not found_in_gitlab:
                if local_path_with_namespace and local_path_with_namespace not in gitlab_paths:
                    # Le path_with_namespace n'existe pas dans GitLab
                    missing_in_gitlab.append(repo_path)
                elif not local_path_with_namespace:
                    # On ne peut pas déterminer si le dépôt existe dans GitLab
                    # On l'ignore pour l'instant
                    pass
        
        return missing_in_gitlab, moved_repos
    
    def move_repo_to_new_path(self, old_path: Path, new_path_with_namespace: str) -> bool:
        """
        Déplace un dépôt vers son nouveau chemin selon GitLab et met à jour l'URL du remote
        
        Args:
            old_path: Ancien chemin du dépôt
            new_path_with_namespace: Nouveau path_with_namespace depuis GitLab
            
        Returns:
            True si le déplacement a réussi, False sinon
        """
        new_path = self.base_dir / new_path_with_namespace
        
        # Si le nouveau chemin est le même que l'ancien, rien à faire
        if old_path.resolve() == new_path.resolve():
            return True
        
        # Vérifier si le nouveau chemin existe déjà
        if new_path.exists():
            print(f"⚠️  Le chemin de destination existe déjà: {new_path}")
            return False
        
        try:
            # Récupérer la nouvelle URL SSH du projet depuis GitLab
            new_ssh_url = None
            try:
                encoded_path = urllib.parse.quote(new_path_with_namespace, safe='')
                api_url = f"{self.gitlab_url}/api/v4/projects/{encoded_path}"
                request = urllib.request.Request(api_url)
                request.add_header('PRIVATE-TOKEN', self.token)
                with urllib.request.urlopen(request) as response:
                    project_data = json.loads(response.read().decode())
                    new_ssh_url = project_data.get('ssh_url_to_repo', '')
                    if not new_ssh_url:
                        # Si pas d'URL SSH, construire depuis le path_with_namespace
                        domain = self.gitlab_url.replace('https://', '').replace('http://', '').rstrip('/')
                        new_ssh_url = f"git@{domain}:{new_path_with_namespace}.git"
            except Exception as e:
                print(f"⚠️  Impossible de récupérer la nouvelle URL SSH depuis GitLab: {e}")
                # On continue quand même le déplacement, mais sans mettre à jour l'URL
        
            # Créer les répertoires parents si nécessaire
            new_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Déplacer le dépôt
            old_path.rename(new_path)
            
            # Mettre à jour l'URL du remote origin si on a récupéré la nouvelle URL
            if new_ssh_url:
                code, _, stderr = self._run_command(
                    ['git', 'remote', 'set-url', 'origin', new_ssh_url],
                    cwd=new_path
                )
                if code == 0:
                    print(f"✓ URL du remote origin mise à jour: {new_ssh_url}")
                else:
                    print(f"⚠️  Impossible de mettre à jour l'URL du remote origin: {stderr}")
            
            print(f"✓ Déplacé: {old_path.relative_to(self.base_dir)} -> {new_path.relative_to(self.base_dir)}")
            return True
        except Exception as e:
            print(f"✗ Erreur lors du déplacement de {old_path}: {e}")
            return False
    
    def archive_repo(self, repo_path: Path) -> bool:
        """
        Archive un dépôt supprimé dans _archived/[old_path]
        
        Args:
            repo_path: Chemin du dépôt à archiver
            
        Returns:
            True si l'archivage a réussi, False sinon
        """
        # Calculer le chemin relatif depuis base_dir
        try:
            relative_path = repo_path.relative_to(self.base_dir)
        except ValueError:
            # Le dépôt n'est pas dans base_dir, utiliser le nom du dépôt
            relative_path = Path(repo_path.name)
        
        # Construire le chemin d'archivage
        archive_path = self.base_dir / "_archived" / relative_path
        
        # Si le chemin d'archivage est le même que l'ancien, rien à faire
        if repo_path.resolve() == archive_path.resolve():
            return True
        
        # Vérifier si le chemin d'archivage existe déjà
        if archive_path.exists():
            typer.echo(f"⚠️  Le chemin d'archivage existe déjà: {archive_path.relative_to(self.base_dir)}")
            return False
        
        try:
            # Créer les répertoires parents si nécessaire
            archive_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Déplacer le dépôt vers l'archive
            repo_path.rename(archive_path)
            
            typer.echo(f"✓ Archivé: {relative_path} -> {archive_path.relative_to(self.base_dir)}")
            return True
        except Exception as e:
            typer.echo(f"✗ Erreur lors de l'archivage de {repo_path}: {e}")
            return False
    
    def get_uncommitted_files(self, repo_path: Path) -> List[str]:
        """
        Récupère la liste des fichiers non commités
        
        Args:
            repo_path: Chemin vers le dépôt Git
            
        Returns:
            Liste des fichiers non commités
        """
        if not (repo_path / '.git').exists():
            return []
        
        code, stdout, _ = self._run_command(
            ['git', 'status', '--porcelain'],
            cwd=repo_path
        )
        
        if code != 0:
            return []
        
        files = []
        for line in stdout.strip().split('\n'):
            if line.strip():
                # Extraire le nom du fichier (après les 2 premiers caractères de statut)
                file_path = line[3:].strip()
                files.append(file_path)
        
        return files
    
    def analyze_repo(self, repo_path: Path) -> Dict:
        """
        Analyse un dépôt Git et retourne son état
        
        Args:
            repo_path: Chemin vers le dépôt Git
            
        Returns:
            Dictionnaire avec l'état du dépôt
        """
        if not repo_path.exists():
            return {'error': 'Répertoire inexistant'}
        
        if not (repo_path / '.git').exists():
            return {'error': 'Pas un dépôt Git'}
        
        local_branches, remote_branches = self.get_branches(repo_path)
        
        # Analyser les différences de branches
        only_local = local_branches - remote_branches
        only_remote = remote_branches - local_branches
        common = local_branches & remote_branches
        
        # Analyser la synchronisation des branches communes
        branch_status = {}
        unsynced_branches = []
        for branch in common:
            status = self.get_branch_status(repo_path, branch)
            branch_status[branch] = status
            if status and status != 'synced':
                # Formater le statut pour l'affichage
                status_text = {
                    'ahead': '⬆ en avance',
                    'behind': '⬇ en retard',
                    'diverged': '↕ divergée',
                    None: '? inconnu'
                }.get(status, '? inconnu')
                unsynced_branches.append(f"{branch} ({status_text})")
        
        has_uncommitted = self.has_uncommitted_changes(repo_path)
        uncommitted_files = self.get_uncommitted_files(repo_path) if has_uncommitted else []
        http_url = self.get_repo_http_url(repo_path)
        
        return {
            'http_url': http_url or 'N/A',
            'local_branches': sorted(local_branches),
            'remote_branches': sorted(remote_branches),
            'only_local': sorted(only_local),
            'only_remote': sorted(only_remote),
            'common_branches': sorted(common),
            'branch_status': branch_status,
            'unsynced_branches': unsynced_branches,
            'has_uncommitted': has_uncommitted,
            'uncommitted_files': uncommitted_files
        }
    
    def list_all_repos(self) -> List[Path]:
        """
        Liste tous les dépôts Git dans le répertoire de base (recherche récursive)
        Exclut les dépôts dans _archived
        
        Returns:
            Liste des chemins vers les dépôts Git
        """
        repos = []
        if not self.base_dir.exists():
            return repos
        
        # Recherche récursive de tous les dépôts Git
        for item in self.base_dir.rglob('*'):
            if item.is_dir() and (item / '.git').exists():
                # Exclure les dépôts dans _archived
                try:
                    relative_path = item.relative_to(self.base_dir)
                    if relative_path.parts[0] == '_archived':
                        continue
                except ValueError:
                    pass
                repos.append(item)
        
        return repos
    
    def get_repo_table_row(self, repo_path: Path) -> Optional[List[str]]:
        """
        Récupère une ligne de tableau pour un dépôt
        
        Args:
            repo_path: Chemin vers le dépôt Git
            
        Returns:
            Liste avec les valeurs pour chaque colonne ou None si erreur
        """
        analysis = self.analyze_repo(repo_path)
        
        if 'error' in analysis:
            return None
        
        # URL HTTP
        http_url = analysis.get('http_url', 'N/A')
        
        # Branches locales non présentes en remote
        only_local = analysis.get('only_local', [])
        only_local_str = ', '.join(only_local) if only_local else ' '
        
        # Branches remote non présentes en local
        only_remote = analysis.get('only_remote', [])
        only_remote_str = ', '.join(only_remote) if only_remote else ' '
        
        # Branches non synchronisées
        unsynced_branches = analysis.get('unsynced_branches', [])
        unsynced_str = ', '.join(unsynced_branches) if unsynced_branches else ' '
        
        # Fichiers non commités
        uncommitted_files = analysis.get('uncommitted_files', [])
        uncommitted_str = ', '.join(uncommitted_files[:5]) if uncommitted_files else ' '
        if len(uncommitted_files) > 5:
            uncommitted_str += f" (+{len(uncommitted_files) - 5} autres)"
        
        return [
            http_url,
            only_local_str,
            only_remote_str,
            unsynced_str,
            uncommitted_str
        ]
    
    def print_repo_analysis_table(self, repos: List[Path]):
        """
        Affiche l'analyse de plusieurs dépôts dans un tableau formaté
        
        Args:
            repos: Liste des chemins vers les dépôts Git
        """
        headers = [
            "URL HTTP",
            "Branches locales\nnon présentes\nen remote",
            "Branches remote\nnon présentes\nen local",
            "Branches non\nsynchronisées",
            "Fichiers non\ncommités"
        ]
        
        table_data = []
        for repo_path in repos:
            row = self.get_repo_table_row(repo_path)
            if row:
                table_data.append(row)
        
        if not table_data:
            print("Aucun dépôt valide à afficher")
            return
        
        print(tabulate(table_data, headers=headers, tablefmt="grid", maxcolwidths=[50, 30, 30, 40, 40]))
    
    def print_repo_analysis(self, repo_path: Path):
        """
        Affiche l'analyse détaillée d'un dépôt (ancien format)
        
        Args:
            repo_path: Chemin vers le dépôt Git
        """
        print(f"\n{'='*80}")
        print(f"📁 Dépôt: {repo_path.name}")
        print(f"{'='*80}")
        
        analysis = self.analyze_repo(repo_path)
        
        if 'error' in analysis:
            print(f"❌ Erreur: {analysis['error']}")
            return
        
        # Afficher les branches locales
        if analysis['local_branches']:
            print(f"\n🌿 Branches locales ({len(analysis['local_branches'])}):")
            for branch in analysis['local_branches']:
                status_icon = '✓' if branch in analysis['common_branches'] else '⚠'
                print(f"  {status_icon} {branch}")
        else:
            print("\n🌿 Aucune branche locale")
        
        # Afficher les branches distantes
        if analysis['remote_branches']:
            print(f"\n🌐 Branches distantes ({len(analysis['remote_branches'])}):")
            for branch in analysis['remote_branches']:
                status_icon = '✓' if branch in analysis['common_branches'] else '⚠'
                print(f"  {status_icon} {branch}")
        else:
            print("\n🌐 Aucune branche distante")
        
        # Afficher les différences
        if analysis['only_local']:
            print(f"\n⚠️  Branches uniquement en local ({len(analysis['only_local'])}):")
            for branch in analysis['only_local']:
                print(f"  - {branch}")
        
        if analysis['only_remote']:
            print(f"\n⚠️  Branches uniquement distantes (manquantes en local) ({len(analysis['only_remote'])}):")
            for branch in analysis['only_remote']:
                print(f"  - {branch}")
        
        # Afficher le statut de synchronisation
        if analysis['branch_status']:
            print(f"\n🔄 Statut de synchronisation:")
            for branch, status in analysis['branch_status'].items():
                if status == 'synced':
                    icon = '✓'
                    text = 'synchronisée'
                elif status == 'ahead':
                    icon = '⬆'
                    text = 'en avance'
                elif status == 'behind':
                    icon = '⬇'
                    text = 'en retard'
                elif status == 'diverged':
                    icon = '↕'
                    text = 'divergée'
                else:
                    icon = '?'
                    text = 'inconnu'
                print(f"  {icon} {branch}: {text}")
        
        # Afficher les fichiers non commités
        if analysis['has_uncommitted']:
            print(f"\n⚠️  ⚠️  FICHIERS NON COMMITÉS DÉTECTÉS ⚠️  ⚠️")
            code, stdout, _ = self._run_command(
                ['git', 'status', '--short'],
                cwd=repo_path
            )
            if code == 0:
                for line in stdout.strip().split('\n'):
                    if line.strip():
                        print(f"  {line}")
        else:
            print(f"\n✓ Aucun fichier non commité")


app = typer.Typer(help="Gestionnaire d'arborescence GitLab")


@app.command()
def clone(
    group_url: str = typer.Argument(..., help="URL GitLab du groupe/namespace (ex: https://gitlab.com/organisation/example)"),
    creds: str = typer.Option("creds.json", "--creds", "-c", help="Fichier contenant les credentials"),
    base_dir: str = typer.Option("./repos", "--base-dir", "-d", help="Répertoire de base pour les dépôts"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Accepter automatiquement les déplacements et archivages sans confirmation")
):
    """
    Cloner tous les projets GitLab d'un groupe/namespace
    
    Exemple:
        python gitlab_manager.py clone https://gitlab.com/organisation/example
    """
    try:
        # Déterminer l'URL GitLab depuis l'URL du groupe
        gitlab_url = GitLabManager._extract_base_url_static(group_url)
        
        # Initialiser le gestionnaire avec l'URL GitLab déterminée
        manager = GitLabManager(creds_file=creds, base_dir=base_dir, gitlab_url=gitlab_url)
        
        # Extraire le chemin du groupe depuis l'URL
        group_path = manager._extract_group_path(group_url)
        
        if not group_path:
            typer.echo(f"Erreur: Impossible d'extraire le chemin du groupe depuis l'URL: {group_url}", err=True)
            raise typer.Exit(1)
        
        typer.echo(f"Utilisation de l'instance GitLab: {gitlab_url}")
        typer.echo(f"Récupération des projets du groupe '{group_path}' via l'API GitLab...")
        
        # Récupérer la liste des projets via l'API
        projects = manager._fetch_projects_from_group(group_path)
        
        if not projects:
            typer.echo(f"Aucun projet trouvé dans le groupe '{group_path}'")
            raise typer.Exit(0)
        
        typer.echo(f"✓ {len(projects)} projet(s) trouvé(s)")
        
        # Vérifier et déplacer les dépôts locaux qui ont été déplacés dans GitLab
        try:
            typer.echo(f"Vérification des dépôts locaux déplacés...")
            missing_repos, moved_repos = manager.check_local_repos_against_gitlab(group_path)
            
            # Afficher et déplacer les dépôts déplacés
            if moved_repos:
                typer.echo(f"\n📦 {len(moved_repos)} dépôt(s) ont été déplacé(s) dans GitLab:")
                for old_path, new_path_with_namespace in moved_repos:
                    old_relative = old_path.relative_to(manager.base_dir)
                    typer.echo(f"  - {old_relative} -> {new_path_with_namespace}")
                
                # Demander confirmation pour déplacer (sauf si --yes)
                if yes:
                    typer.echo("\n✓ Déplacement automatique accepté (--yes)")
                    for old_path, new_path_with_namespace in moved_repos:
                        manager.move_repo_to_new_path(old_path, new_path_with_namespace)
                else:
                    response = typer.prompt("\nVoulez-vous déplacer ces dépôts vers leur nouveau chemin ? (O/n)", default="O")
                    if response.upper() in ['O', 'OUI', 'Y', 'YES']:
                        for old_path, new_path_with_namespace in moved_repos:
                            manager.move_repo_to_new_path(old_path, new_path_with_namespace)
                typer.echo()  # Ligne vide
            
            # Afficher et archiver les dépôts supprimés
            if missing_repos:
                typer.echo(f"\n🗑️  {len(missing_repos)} dépôt(s) supprimé(s) de GitLab détecté(s):")
                for missing_repo in missing_repos:
                    relative_path = missing_repo.relative_to(manager.base_dir)
                    typer.echo(f"  - {relative_path}")
                
                # Demander confirmation pour archiver (sauf si --yes)
                if yes:
                    typer.echo("\n✓ Archivage automatique accepté (--yes)")
                    for missing_repo in missing_repos:
                        manager.archive_repo(missing_repo)
                else:
                    response = typer.prompt("\nVoulez-vous archiver ces dépôts dans _archived/ ? (O/n)", default="O")
                    if response.upper() in ['O', 'OUI', 'Y', 'YES']:
                        for missing_repo in missing_repos:
                            manager.archive_repo(missing_repo)
                typer.echo()  # Ligne vide
        except Exception as e:
            typer.echo(f"⚠️  Erreur lors de la vérification des dépôts locaux: {e}", err=True)
            typer.echo()  # Ligne vide
        
        # Cloner les projets
        manager.clone_projects_from_list(projects)
        
    except ValueError as e:
        typer.echo(f"Erreur: {e}", err=True)
        raise typer.Exit(1)
    except Exception as e:
        typer.echo(f"Erreur: {e}", err=True)
        raise typer.Exit(1)


@app.command()
def analyze(
    repo: Optional[str] = typer.Option(None, "--repo", "-r", help="Analyser un dépôt spécifique (chemin relatif ou absolu)"),
    group_url: Optional[str] = typer.Option(None, "--group", "-g", help="URL GitLab du groupe pour comparer les dépôts locaux (ex: https://gitlab.com/organisation/example)"),
    creds: str = typer.Option("creds.json", "--creds", "-c", help="Fichier contenant les credentials"),
    base_dir: str = typer.Option("./repos", "--base-dir", "-d", help="Répertoire de base pour les dépôts")
):
    """
    Analyser les dépôts Git
    
    Exemples:
        python gitlab_manager.py analyze
        python gitlab_manager.py analyze --repo ./repos/mon-projet
        python gitlab_manager.py analyze --group https://gitlab.com/organisation/example
    """
    manager = GitLabManager(creds_file=creds, base_dir=base_dir)
    
    if repo:
        # Analyser un dépôt spécifique (format détaillé)
        repo_path = Path(repo)
        if not repo_path.is_absolute():
            repo_path = manager.base_dir / repo_path
        manager.print_repo_analysis(repo_path)
    else:
        # Analyser tous les dépôts (format tableau)
        repos = manager.list_all_repos()
        if not repos:
            typer.echo(f"Aucun dépôt trouvé dans {manager.base_dir}")
            raise typer.Exit(0)
        
        # Vérifier les dépôts locaux contre GitLab si un groupe est fourni (avertissements uniquement)
        if group_url:
            try:
                # Déterminer l'URL GitLab depuis l'URL du groupe
                gitlab_url = GitLabManager._extract_base_url_static(group_url)
                manager.gitlab_url = gitlab_url
                manager.token = manager._get_token_for_url(gitlab_url)
                
                # Extraire le chemin du groupe
                group_path = manager._extract_group_path(group_url)
                
                if group_path:
                    typer.echo(f"Comparaison des dépôts locaux avec le groupe GitLab '{group_path}'...")
                    missing_repos, _ = manager.check_local_repos_against_gitlab(group_path)
                    
                    # Afficher uniquement les dépôts manquants (les déplacements sont gérés dans clone)
                    if missing_repos:
                        typer.echo(f"\n⚠️  AVERTISSEMENT: {len(missing_repos)} dépôt(s) local(aux) n'existe(nt) pas dans GitLab:", err=True)
                        for missing_repo in missing_repos:
                            relative_path = missing_repo.relative_to(manager.base_dir)
                            typer.echo(f"  - {relative_path}", err=True)
                        typer.echo()  # Ligne vide
            except Exception as e:
                typer.echo(f"⚠️  Erreur lors de la comparaison avec GitLab: {e}", err=True)
                typer.echo()  # Ligne vide
        
        typer.echo(f"Analyse de {len(repos)} dépôt(s)...\n")
        manager.print_repo_analysis_table(repos)


def main():
    """Point d'entrée principal"""
    app()


if __name__ == '__main__':
    main()
