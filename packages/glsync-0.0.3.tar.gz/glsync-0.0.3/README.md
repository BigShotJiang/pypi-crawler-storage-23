# Glsync

Gestionnaire d'arborescence de projets GitLab permettant de cloner des projets et d'analyser l'état des branches et des modifications.

## Installation

Installez les dépendances :
```bash
pip install -r requirements.txt
```

## Configuration

1. Créez un fichier `creds.json` basé sur `creds.json.example` :
```json
{
  "https://gitlab.com": "votre_token_gitlab_ici",
  "https://privateinstance.com": "autre_token_ici"
}
```

**Format** :** Le fichier `creds.json` est un objet JSON où chaque clé est l'URL d'une instance GitLab et la valeur est le token d'accès correspondant. Cela permet de gérer plusieurs instances GitLab avec des tokens différents.

Pour obtenir un token GitLab :
- Allez dans GitLab > Settings > Access Tokens
- Créez un token avec les permissions `read_api` (pour lister les projets) et `read_repository`

## Utilisation

### Cloner des projets

Le programme récupère automatiquement la liste des projets depuis l'API GitLab d'un groupe/namespace :

```bash
python gitlab_manager.py clone https://gitlab.com/organisation/example
```

Le programme :
1. Appelle l'API GitLab pour récupérer tous les projets du groupe/namespace
2. Clone chaque projet via SSH dans le répertoire `./repos` par défaut
3. **Préserve l'arborescence GitLab** : la structure des groupes est reproduite localement (ex: `repos/organisation/example/projet`)
4. Inclut automatiquement les sous-groupes (`include_subgroups=true`)

**Important** : 
- Le token GitLab dans `creds.json` doit avoir les permissions `read_api` pour lister les projets
- Les projets sont clonés via SSH (format `git@gitlab.com:user/repo.git`)
- Assurez-vous d'avoir configuré vos clés SSH avec GitLab

### Analyser les dépôts

Pour analyser tous les dépôts dans le répertoire de base :
```bash
python gitlab_manager.py analyze
```

Pour analyser un dépôt spécifique :
```bash
python gitlab_manager.py analyze --repo ./repos/mon-projet
```

## Fonctionnalités

- ✅ Clonage de projets GitLab via SSH (pas d'OAuth ni d'HTTP)
- ✅ Liste des branches locales et distantes
- ✅ Détection des branches manquantes (uniquement distantes)
- ✅ Détection des branches uniquement locales
- ✅ Analyse de la synchronisation des branches (en avance, en retard, divergées)
- ✅ Détection des fichiers non commités

**Note** : Pour utiliser SSH, assurez-vous d'avoir configuré vos clés SSH avec GitLab.

## Options

- `--creds FILE` : Spécifier le fichier de credentials (défaut: `creds.json`)
- `--base-dir DIR` : Spécifier le répertoire de base pour les dépôts (défaut: `./repos`)
