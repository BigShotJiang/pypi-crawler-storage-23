"""Exception classes for wl-registry SDK."""

from __future__ import annotations


class WlRegistryError(Exception):
    """Base exception for wl-registry SDK."""


class ServiceUnavailable(WlRegistryError):
    """Raised when the registry service is unavailable."""

    def __init__(
        self,
        message: str = "WL-Registry service is unavailable",
        url: str | None = None,
    ) -> None:
        super().__init__(message)
        self.url = url


class AuthenticationError(WlRegistryError):
    """Raised when authentication fails (401/403)."""

    def __init__(self, message: str = "Authentication failed") -> None:
        super().__init__(message)


class NotFoundError(WlRegistryError):
    """Raised when a resource is not found (404)."""

    def __init__(self, message: str = "Resource not found", resource_id: str | None = None) -> None:
        super().__init__(message)
        self.resource_id = resource_id


class ValidationError(WlRegistryError):
    """Raised when request validation fails (400/422)."""

    def __init__(self, message: str = "Validation error", details: str | None = None) -> None:
        super().__init__(message)
        self.details = details


class ConflictError(WlRegistryError):
    """Raised on resource conflicts (409)."""

    def __init__(self, message: str = "Resource conflict") -> None:
        super().__init__(message)
