"""wl-registry: Python SDK for Watchlight AI Registry.

AI agent and MCP server registry — register, discover, and manage
agents, servers, scanners, and permissions.
"""

__version__ = "0.1.0"

from .client import (
    WlRegistryAdminClient,
    WlRegistryAdminSyncClient,
    WlRegistryAgentClient,
    WlRegistryAgentSyncClient,
    WlRegistryClient,
    WlRegistryScannerClient,
    WlRegistryScannerSyncClient,
    WlRegistrySyncClient,
)
from .exceptions import (
    AuthenticationError,
    ConflictError,
    NotFoundError,
    ServiceUnavailable,
    ValidationError,
    WlRegistryError,
)
from .models import (
    AccessibleServer,
    AgentDetail,
    AgentListItem,
    AgentStatsResponse,
    AgentStatus,
    AgentType,
    CapabilityInput,
    CapabilityType,
    CreateAgentRequest,
    CreateAgentResponse,
    CreateRegistrationTokenRequest,
    CreateScannerRequest,
    CreateScannerResponse,
    GrantPermissionRequest,
    HealthResponse,
    HeartbeatRequest,
    HeartbeatResponse,
    ListAccessibleServersResponse,
    ListAgentsResponse,
    ListPermissionsResponse,
    ListRegistrationTokensResponse,
    ListScannersResponse,
    ListServersResponse,
    PermissionListItem,
    RegisterServerRequest,
    RegisterServerResponse,
    RegistrationConfigResponse,
    RegistrationTokenListItem,
    RegistrationTokenResponse,
    RotateKeyResponse,
    ScannerListItem,
    SelfRegisterAgentRequest,
    SelfRegisterAgentResponse,
    ServerDetail,
    ServerListItem,
    ServerStatus,
    TransportType,
    TrustState,
    UpdateAgentRequest,
    UpdateTrustRequest,
    UpdateTrustResponse,
)

__all__ = [
    # Version
    "__version__",
    # Async clients
    "WlRegistryClient",
    "WlRegistryScannerClient",
    "WlRegistryAgentClient",
    "WlRegistryAdminClient",
    # Sync clients
    "WlRegistrySyncClient",
    "WlRegistryScannerSyncClient",
    "WlRegistryAgentSyncClient",
    "WlRegistryAdminSyncClient",
    # Exceptions
    "WlRegistryError",
    "ServiceUnavailable",
    "AuthenticationError",
    "NotFoundError",
    "ValidationError",
    "ConflictError",
    # Enums
    "TrustState",
    "ServerStatus",
    "AgentStatus",
    "AgentType",
    "TransportType",
    "CapabilityType",
    # Server models
    "CapabilityInput",
    "RegisterServerRequest",
    "RegisterServerResponse",
    "HeartbeatRequest",
    "HeartbeatResponse",
    "UpdateTrustRequest",
    "UpdateTrustResponse",
    "ServerListItem",
    "ServerDetail",
    "ListServersResponse",
    # Agent models
    "SelfRegisterAgentRequest",
    "SelfRegisterAgentResponse",
    "CreateAgentRequest",
    "CreateAgentResponse",
    "UpdateAgentRequest",
    "AgentListItem",
    "AgentDetail",
    "ListAgentsResponse",
    "AgentStatsResponse",
    "AccessibleServer",
    "ListAccessibleServersResponse",
    # Permission models
    "GrantPermissionRequest",
    "PermissionListItem",
    "ListPermissionsResponse",
    # Scanner models
    "CreateScannerRequest",
    "CreateScannerResponse",
    "ScannerListItem",
    "ListScannersResponse",
    "RotateKeyResponse",
    # Registration token models
    "CreateRegistrationTokenRequest",
    "RegistrationTokenResponse",
    "RegistrationTokenListItem",
    "ListRegistrationTokensResponse",
    # Config & Health
    "RegistrationConfigResponse",
    "HealthResponse",
]
