"""
PixelFrame - The Professional Visual Regression & Responsive Testing Engine.
"""

__version__ = "0.2.0"
