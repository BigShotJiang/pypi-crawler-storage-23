"""Shared test configuration for flask-silo."""
