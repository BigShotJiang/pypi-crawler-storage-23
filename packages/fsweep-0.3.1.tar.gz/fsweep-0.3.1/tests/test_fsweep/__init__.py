"""Test package for fsweep."""
