"""fsweep package."""
