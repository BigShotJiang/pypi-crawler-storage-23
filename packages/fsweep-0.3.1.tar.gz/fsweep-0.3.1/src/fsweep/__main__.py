"""Module entry point for `python -m fsweep`."""

from fsweep.cli import app

app()
