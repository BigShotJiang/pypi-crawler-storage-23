#!/usr/bin/env bash

set -e

echo "🚀 Setting up agent-cli services on macOS..."

# Check if Homebrew is installed
if ! command -v brew &> /dev/null; then
    echo "❌ Homebrew is not installed. Please install Homebrew first:"
    echo "/bin/bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\""
    exit 1
fi

# Check if uv is installed
if ! command -v uv &> /dev/null; then
    echo "📦 Installing uv..."
    brew install uv
fi

# Install Ollama
echo "🧠 Checking Ollama..."
if ! command -v ollama &> /dev/null; then
    echo "🍺 Installing Ollama via Homebrew..."
    brew install ollama
    echo "✅ Ollama installed successfully"
else
    echo "✅ Ollama is already installed"
fi

# Check if zellij is installed
if ! command -v zellij &> /dev/null; then
    echo "📺 Installing zellij..."
    brew install zellij
fi

# Install agent-cli
echo "🤖 Installing/upgrading agent-cli..."
uv tool install --upgrade agent-cli

# Start Ollama as a background service
echo "🧠 Starting Ollama as a background service..."
brew services start ollama

# Preload default Ollama model
echo "⬇️ Preloading default Ollama model (gemma3:4b)..."
echo "⏳ This may take a few minutes depending on your internet connection..."
sleep 2  # Give Ollama service time to start
ollama pull gemma3:4b

# Install whisper and tts as launchd daemons
echo "🎤 Installing whisper and tts-kokoro as background daemons..."
agent-cli daemon install whisper tts-kokoro -y

echo ""
echo "✅ Setup complete! You can now run the services:"
echo ""
echo "Option 1 - Run all services at once:"
echo "  ./start-all-services.sh"
echo ""
echo "Option 2 - Run services individually:"
echo "  1. Ollama: running as brew service (brew services start ollama)"
echo "  2. Whisper: running as launchd daemon (agent-cli daemon status whisper)"
echo "  3. TTS: running as launchd daemon (agent-cli daemon status tts-kokoro)"
echo "  4. OpenWakeWord: ./run-openwakeword.sh"
echo ""
echo "🎉 agent-cli has been installed and is ready to use!"
