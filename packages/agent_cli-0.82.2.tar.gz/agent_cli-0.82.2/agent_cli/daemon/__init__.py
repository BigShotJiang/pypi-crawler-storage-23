"""Daemon management for agent-cli background services."""
