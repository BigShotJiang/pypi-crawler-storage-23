# freesialabs

Official Python package for [Freesia Labs](https://freesialabs.io).

> 🚧 Under development — stay tuned.

## Installation

```bash
pip install freesialabs
```

## License

MIT — Freesia Labs Inc.
