"""Freesia Labs - AI/ML tools and utilities."""

__version__ = "0.0.1"
__author__ = "Freesia Labs Inc."
__url__ = "https://freesialabs.io"
