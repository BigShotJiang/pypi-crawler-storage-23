from neurotidy.cli import main
main()
