"""NeuroTidy — AI-Powered Python & Deep Learning Code Analyzer."""

__version__ = "0.1.0"

# Default API endpoint (deployed on AWS)
DEFAULT_API_ENDPOINT = "https://1d21iee6x0.execute-api.us-east-1.amazonaws.com/prod"
