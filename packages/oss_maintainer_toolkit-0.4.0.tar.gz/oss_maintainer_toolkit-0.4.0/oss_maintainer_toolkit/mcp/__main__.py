"""Allow running the MCP server via python -m oss_maintainer_toolkit.mcp."""

from oss_maintainer_toolkit.mcp.server import mcp

mcp.run()
