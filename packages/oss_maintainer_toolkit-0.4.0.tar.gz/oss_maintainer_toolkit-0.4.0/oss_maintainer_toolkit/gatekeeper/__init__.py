"""Gatekeeper module — three-tier gated pipeline for PR risk assessment."""
