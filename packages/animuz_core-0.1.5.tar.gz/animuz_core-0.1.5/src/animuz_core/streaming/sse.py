"""Server-Sent Events (SSE) formatting helpers."""
import json


def format_sse_event(data: dict) -> str:
    """Format a dict as an SSE data line."""
    return f"data: {json.dumps(data, ensure_ascii=False)}\n\n"


def format_sse_error(message: str, status_code: int) -> str:
    """Format an error as an SSE event."""
    error_data = {
        "type": "error",
        "message": message,
        "statusCode": status_code
    }
    return f"data: {json.dumps(error_data)}\n\n"
