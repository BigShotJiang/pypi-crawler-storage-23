"""EvalView MCP Server — exposes evalview check/snapshot as MCP tools for Claude Code."""

import json
import os
import shutil
import subprocess
import sys
from importlib.metadata import version as _pkg_version, PackageNotFoundError
from typing import Any, Dict, Optional

try:
    _EVALVIEW_VERSION = _pkg_version("evalview")
except PackageNotFoundError:
    _EVALVIEW_VERSION = "dev"

TOOLS = [
    {
        "name": "create_test",
        "description": (
            "Create a new EvalView test case YAML file for an agent. "
            "Call this when the user asks to add a test, or when you want to capture "
            "expected agent behavior. After creating a test, call run_snapshot to establish "
            "the baseline. No YAML knowledge required — just describe the test."
        ),
        "inputSchema": {
            "type": "object",
            "required": ["name", "query"],
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Test name (e.g. 'calculator-division', 'weather-lookup')",
                },
                "query": {
                    "type": "string",
                    "description": "The input query to send to the agent",
                },
                "description": {
                    "type": "string",
                    "description": "Human-readable description of what this test covers",
                },
                "expected_tools": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Tool names the agent should call (e.g. ['calculator', 'search'])",
                },
                "expected_output_contains": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Strings that must appear in the agent's output",
                },
                "min_score": {
                    "type": "number",
                    "description": "Minimum passing score 0-100 (default: 70)",
                },
                "test_path": {
                    "type": "string",
                    "description": "Directory to save the test file (default: tests)",
                },
            },
        },
    },
    {
        "name": "run_check",
        "description": (
            "Check for regressions against the golden baseline. "
            "Returns diff output showing what changed vs the last snapshot. "
            "A regression means the agent's behavior changed unexpectedly. "
            "Use this after refactoring agent code to confirm nothing broke."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "test": {
                    "type": "string",
                    "description": "Check only this specific test by name (optional, checks all by default)",
                },
                "test_path": {
                    "type": "string",
                    "description": "Path to the test directory (default: tests)",
                },
            },
        },
    },
    {
        "name": "run_snapshot",
        "description": (
            "Run tests and save passing results as the new golden baseline. "
            "Use this to establish or update the expected behavior after an intentional change. "
            "Future `run_check` calls will compare against this snapshot."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "test": {
                    "type": "string",
                    "description": "Snapshot only this specific test by name (optional, snapshots all by default)",
                },
                "notes": {
                    "type": "string",
                    "description": "Human-readable note about why this snapshot was taken",
                },
                "test_path": {
                    "type": "string",
                    "description": "Path to the test directory (default: tests)",
                },
            },
        },
    },
    {
        "name": "list_tests",
        "description": (
            "List all available golden baselines in this EvalView project. "
            "Shows test names, variant counts, and when each baseline was last updated."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
]


class MCPServer:
    """Synchronous stdio JSON-RPC MCP server for EvalView."""

    def __init__(self, test_path: str = "tests") -> None:
        self.test_path = test_path

    def serve(self) -> None:
        """Run the synchronous stdin/stdout JSON-RPC loop."""
        for raw_line in sys.stdin:
            line = raw_line.strip()
            if not line:
                continue
            try:
                request = json.loads(line)
            except json.JSONDecodeError:
                continue
            response = self._handle(request)
            if response is not None:
                sys.stdout.write(json.dumps(response) + "\n")
                sys.stdout.flush()

    def _handle(self, req: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        method = req.get("method", "")
        req_id = req.get("id")
        params = req.get("params", {})

        if method == "initialize":
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {"tools": {}},
                    "serverInfo": {"name": "evalview", "version": _EVALVIEW_VERSION},
                },
            }

        if method == "notifications/initialized":
            return None  # notifications don't get a response

        if method == "tools/list":
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {"tools": TOOLS},
            }

        if method == "tools/call":
            tool_name = params.get("name", "")
            arguments = params.get("arguments", {})
            output = self._call_tool(tool_name, arguments)
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [{"type": "text", "text": output}],
                    "isError": False,
                },
            }

        # Unknown method — return error only if it has an id (i.e. it's a request not a notification)
        if req_id is not None:
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "error": {"code": -32601, "message": f"Unknown method: {method}"},
            }

        return None

    def _create_test(self, args: Dict[str, Any]) -> str:
        test_name = args.get("name", "").strip()
        query = args.get("query", "").strip()
        if not test_name or not query:
            return "Error: 'name' and 'query' are required."

        test_path = args.get("test_path", self.test_path)
        slug = test_name.lower().replace(" ", "-").replace("_", "-")
        filename = os.path.join(test_path, f"{slug}.yaml")

        if os.path.exists(filename):
            return f"Error: test already exists at {filename}. Delete it first or choose a different name."

        os.makedirs(test_path, exist_ok=True)

        lines = [f'name: "{test_name}"']

        description = args.get("description", "")
        if description:
            lines.append(f'description: "{description}"')

        lines += ["", "input:", f'  query: "{query}"', "", "expected:"]

        expected_tools = args.get("expected_tools", [])
        if expected_tools:
            lines.append("  tools:")
            for t in expected_tools:
                lines.append(f"    - {t}")

        expected_output = args.get("expected_output_contains", [])
        if expected_output:
            lines.append("  output:")
            lines.append("    contains:")
            for s in expected_output:
                lines.append(f'      - "{s}"')

        min_score = args.get("min_score", 70)
        lines += ["", "thresholds:", f"  min_score: {int(min_score)}"]

        with open(filename, "w") as f:
            f.write("\n".join(lines) + "\n")

        summary_parts = [f"query: {query}"]
        if expected_tools:
            summary_parts.append(f"tools: {', '.join(expected_tools)}")
        if expected_output:
            summary_parts.append(f"output contains: {', '.join(expected_output)}")

        return (
            f"Created {filename}\n"
            + "\n".join(f"  {p}" for p in summary_parts)
            + "\n\nRun run_snapshot to capture the baseline for this test."
        )

    def _call_tool(self, name: str, args: Dict[str, Any]) -> str:
        if name == "create_test":
            return self._create_test(args)

        if not shutil.which("evalview"):
            return "Error: evalview not found in PATH. Run: pip install -e ."

        if name == "run_check":
            cmd = ["evalview", "check", args.get("test_path", self.test_path), "--json"]
            if args.get("test"):
                cmd += ["--test", args["test"]]

        elif name == "run_snapshot":
            cmd = ["evalview", "snapshot", args.get("test_path", self.test_path)]
            if args.get("test"):
                cmd += ["--test", args["test"]]
            if args.get("notes"):
                cmd += ["--notes", args["notes"]]

        elif name == "list_tests":
            cmd = ["evalview", "golden", "list"]

        else:
            return f"Unknown tool: {name}"

        env = {**os.environ, "NO_COLOR": "1", "FORCE_COLOR": "0"}
        result = subprocess.run(cmd, capture_output=True, text=True, env=env)
        output = result.stdout
        if result.stderr:
            output += result.stderr
        return output.strip() or f"Command exited with code {result.returncode}"
