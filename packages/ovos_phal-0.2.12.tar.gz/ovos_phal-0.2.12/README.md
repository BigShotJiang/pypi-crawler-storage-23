# ovos_PHAL

Plugin based Hardware Abstraction Layer

a wrapper for software system level abstraction, where based on the environment either through known configuration or via fingerprinting, only specific plugins load to interface with the system and specific hardware

A PHAL plugin can provide anything from hardware integrations (respeaker, mk1, mk2....) or system integrations (network manager, ovos shell)
