[GitHub source](https://github.com/SeequentEvo/evo-python-sdk/blob/main/packages/evo-files/src/evo/files/client.py)
::: evo.files.client.FileAPIClient
