[GitHub source](https://github.com/SeequentEvo/evo-python-sdk/blob/main/packages/evo-colormaps/src/evo/colormaps/client.py)
::: evo.colormaps.client.ColormapAPIClient
