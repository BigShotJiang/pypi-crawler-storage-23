[GitHub source](https://github.com/SeequentEvo/evo-python-sdk/blob/main/packages/evo-blockmodels/src/evo/blockmodels/client.py)
::: evo.blockmodels.client.BlockModelAPIClient
