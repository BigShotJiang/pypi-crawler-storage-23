[GitHub source](https://github.com/SeequentEvo/evo-python-sdk/blob/main/packages/evo-sdk-common/src/evo/workspaces/client.py)
::: evo.workspaces.client.WorkspaceAPIClient
