from .cli.cli import cli

cli()
