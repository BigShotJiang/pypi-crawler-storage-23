"""Hauba skill system — .md skill files and .yaml strategies."""
