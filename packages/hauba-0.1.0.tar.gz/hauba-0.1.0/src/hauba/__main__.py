"""Allow running hauba as a module: python -m hauba."""

from hauba.cli import app

app()
