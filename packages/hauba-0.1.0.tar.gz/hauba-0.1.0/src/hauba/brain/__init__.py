"""Hauba brain module — LLM routing, intent parsing, deliberation, planning."""
