"""Hauba Compose — Declarative agent teams via hauba.yaml."""
