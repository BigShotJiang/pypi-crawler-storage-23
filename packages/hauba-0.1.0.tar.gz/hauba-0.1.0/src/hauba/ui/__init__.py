"""Hauba UI module — terminal and web interfaces."""

from hauba.ui.terminal import TerminalUI

__all__ = ["TerminalUI"]
