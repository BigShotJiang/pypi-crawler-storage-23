"""Hauba agents module."""

from hauba.agents.base import BaseAgent
from hauba.agents.director import DirectorAgent

__all__ = ["BaseAgent", "DirectorAgent"]
