"""Compatibility import for ConfigurationManager."""

from .manager import ConfigurationManager

__all__ = ["ConfigurationManager"]
