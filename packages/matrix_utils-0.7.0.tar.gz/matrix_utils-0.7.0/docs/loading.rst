Loading packages
================

.. autofunction:: bw_processing.loading.load_package
