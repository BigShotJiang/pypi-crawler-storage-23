Saving packages
===============

Most of the time, one only needs to use the ``create_package`` function.

.. autofunction:: bw_processing.calculation_package.create_package

Lower level functions
---------------------

.. autofunction:: bw_processing.calculation_package.format_calculation_resource
