# Endpoint-Spezifikation: `get_revenue_by_billing_date`
**Pipedrive MCP Connector · Liquiditätsplanung · v1.0**

---

## 1. Überblick

Dieser Endpoint liefert aggregierte Umsatzdaten für die monatliche Liquiditätsplanung, gefiltert nach dem Pipedrive Custom Field **"Datum der vsl. Rechnungsstellung"**. Er ermöglicht einen vollständigen Jahres-Report mit genau 12 API-Calls und ersetzt aufwändige Bulk-Abfragen über `list_deals`, die bei großen Datenmengen zu übergroßen API-Responses führen ("Tool result too large for context").

**Verwendungszweck:** Management-Reporting und monatliche Liquiditätsplanung auf Basis des geplanten Abrechnungsdatums aller gewonnenen Deals — analog zur Dashboard-Kachel "Monat YYYY – beauftragt" in Pipedrive Insights.

---

## 2. Endpoint-Definition

### Methode und Pfad

```
GET /mcp/pipedrive/get_revenue_by_billing_date
```

### Parameter

| Parameter | Typ | Pflicht | Beschreibung |
|---|---|---|---|
| `billing_date_from` | string | **Ja** | Beginn Abrechnungszeitraum. Format: `YYYY-MM-DD`. Bsp: `"2026-01-01"` |
| `billing_date_to` | string | **Ja** | Ende Abrechnungszeitraum. Format: `YYYY-MM-DD`. Bsp: `"2026-01-31"` |
| `pipeline_id` | integer | Nein | Pipedrive Pipeline-ID. Fehlt dieser Parameter, werden alle Pipelines einbezogen. |
| `status` | string | Nein | Erlaubte Werte: `won`, `open`. Standard: `won` |

---

## 3. Interne Filterlogik

Der Endpoint kombiniert folgende Pipedrive-Filter — analog zur Dashboard-Kachel in Pipedrive Insights:

| Filter-Kriterium | Bedingung |
|---|---|
| **Status** | `= won` (oder übergebener `status`-Parameter) |
| **Datum der vsl. Rechnungsstellung** | `>= billing_date_from` UND `<= billing_date_to` |
| **Prognosezeitraum (fixer Rahmen)** | `01.10.2024 – 31.12.2026` (analog Pipedrive Insights Dashboard) |
| **pipeline_id** | Nur wenn Parameter übergeben, sonst alle Pipelines |

Pipedrive Custom Field Key für "Datum der vsl. Rechnungsstellung":

```
f691421dded49b1c3c21614c939303925b67b2a2
```

---

## 4. Response

### HTTP 200 — Erfolg

| Feld | Typ | Beschreibung |
|---|---|---|
| `total_value` | float | Summe aller Deal-Werte im angefragten Zeitraum |
| `count` | integer | Anzahl der gefundenen Deals |
| `currency` | string | Währung der Summe (immer `EUR`) |
| `deals` | array | Liste der einzelnen Deals (siehe Deal-Objekt unten) |
| `deals[].id` | integer | Pipedrive Deal-ID |
| `deals[].title` | string | Name des Deals |
| `deals[].value` | float | Deal-Wert in EUR |
| `deals[].billing_date` | string | Datum der vsl. Rechnungsstellung (`YYYY-MM-DD`) |
| `deals[].owner_id` | integer | Pipedrive User-ID des Deal-Owners |

### Beispiel-Response

```json
{
  "total_value": 310000.00,
  "count": 3,
  "currency": "EUR",
  "deals": [
    {
      "id": 6510,
      "title": "AUDI AG - Driving Experience Setup MS 2",
      "value": 30000.00,
      "billing_date": "2026-06-01",
      "owner_id": 23904106
    },
    {
      "id": 6512,
      "title": "AUDI AG - Driving Experience Setup MS 4",
      "value": 80000.00,
      "billing_date": "2026-06-15",
      "owner_id": 23904106
    }
  ]
}
```

---

## 5. Fehlerbehandlung

| HTTP-Status | Fehlercode | Beschreibung |
|---|---|---|
| `400` | `INVALID_DATE_FORMAT` | `billing_date_from` oder `billing_date_to` entspricht nicht dem Format `YYYY-MM-DD` |
| `400` | `INVALID_DATE_RANGE` | `billing_date_from` liegt nach `billing_date_to` |
| `400` | `INVALID_STATUS` | Übergebener `status`-Wert ist nicht erlaubt (nur `won` oder `open`) |
| `404` | `PIPELINE_NOT_FOUND` | Die übergebene `pipeline_id` existiert nicht |
| `500` | `INTERNAL_ERROR` | Interner Serverfehler beim Abruf der Pipedrive-Daten |

### Fehler-Response Format

```json
{
  "error": "INVALID_DATE_FORMAT",
  "message": "billing_date_from must be in format YYYY-MM-DD"
}
```

---

## 6. Verwendung durch Claude / MCP-Client

### Jahres-Report 2026 (12 sequenzielle Calls)

```
Januar:    billing_date_from=2026-01-01  →  billing_date_to=2026-01-31
Februar:   billing_date_from=2026-02-01  →  billing_date_to=2026-02-28
März:      billing_date_from=2026-03-01  →  billing_date_to=2026-03-31
April:     billing_date_from=2026-04-01  →  billing_date_to=2026-04-30
Mai:       billing_date_from=2026-05-01  →  billing_date_to=2026-05-31
Juni:      billing_date_from=2026-06-01  →  billing_date_to=2026-06-30
Juli:      billing_date_from=2026-07-01  →  billing_date_to=2026-07-31
August:    billing_date_from=2026-08-01  →  billing_date_to=2026-08-31
September: billing_date_from=2026-09-01  →  billing_date_to=2026-09-30
Oktober:   billing_date_from=2026-10-01  →  billing_date_to=2026-10-31
November:  billing_date_from=2026-11-01  →  billing_date_to=2026-11-30
Dezember:  billing_date_from=2026-12-01  →  billing_date_to=2026-12-31
```

### Vorteil gegenüber `list_deals`

`list_deals` gibt bei mehr als 500 Deals Antworten zurück, die zu groß für den MCP-Kontext sind. Dieser Endpoint liefert ausschließlich aggregierte Werte plus eine kompakte Deal-Liste — kein externes Datei-Parsing notwendig.

---

## 7. Implementierungshinweise

- **Datenbasis:** Für die Liquiditätsplanung sind primär Deals aus Pipeline `3` (AirLST 2026) relevant. `pipeline_id` bleibt dennoch optionaler Parameter für Erweiterbarkeit.
- **Datumsformat:** Das Custom Field speichert Datumsangaben als ISO-String (`YYYY-MM-DD`). Kein UTC-Offset nötig.
- **Fehlende Abrechnungsdaten:** Deals ohne gesetztes Custom Field werden nicht berücksichtigt und nicht in der Response zurückgegeben.
- **Paginierung:** Für einen einzelnen Monat wird keine Paginierung benötigt. Bei Bedarf können optionale Parameter `limit`/`offset` ergänzt werden.
- **Caching:** Empfohlen: 5 Minuten TTL für den laufenden Monat, 1 Stunde für vergangene Monate.

---

## 8. Referenz

| Element | Wert |
|---|---|
| Custom Field Key (Abrechnungsdatum) | `f691421dded49b1c3c21614c939303925b67b2a2` |
| Pipeline AirLST 2026 | `pipeline_id = 3` |
| Stage "Beauftragt" | `stage_id = 27` |
| Fixer Prognosezeitraum | `01.10.2024 – 31.12.2026` |
| Pipedrive Domain | `airlstgmbh.pipedrive.com` |
