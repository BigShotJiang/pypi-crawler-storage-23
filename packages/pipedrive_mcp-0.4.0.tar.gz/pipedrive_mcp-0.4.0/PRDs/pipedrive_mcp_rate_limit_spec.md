# Pipedrive MCP – Rate Limit Handling: Technische Spezifikation

**Erstellt:** 05.03.2026  
**Kontext:** AirLST GmbH – Pipedrive MCP Connector  
**Priorität:** Hoch

---

## Hintergrund

Bei intensiver Nutzung des Pipedrive MCP Connectors (z.B. Batch-Abfragen von Deals, Activities oder Persons) kommt es wiederholt zu HTTP `429 Too Many Requests`-Fehlern. Die Pipedrive REST API hat folgende Rate Limits:

- **Standard:** 80 Requests / 2 Sekunden pro Company-Token
- **Daily Limit:** 80.000 Requests / Tag
- Die API antwortet bei Überschreitung mit HTTP `429` und dem Header `Retry-After: <Sekunden>`

---

## Anforderungen

### 1. Retry-Logik mit Exponential Backoff

Jeder API-Call im MCP soll bei einem `429`-Response **automatisch wiederholt** werden, ohne dass Claude oder der User eingreifen muss.

**Implementierung:**

```typescript
async function callPipedriveAPI(endpoint: string, options: RequestOptions): Promise<Response> {
  const MAX_RETRIES = 5;
  const BASE_DELAY_MS = 1000; // 1 Sekunde

  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    const response = await fetch(endpoint, options);

    if (response.status !== 429) {
      return response; // Erfolg oder anderer Fehler → direkt zurückgeben
    }

    if (attempt === MAX_RETRIES) {
      throw new Error(`Pipedrive API rate limit exceeded after ${MAX_RETRIES} retries.`);
    }

    // Retry-After Header auslesen (Pipedrive liefert Sekunden)
    const retryAfter = response.headers.get('Retry-After');
    const waitMs = retryAfter
      ? parseInt(retryAfter) * 1000
      : BASE_DELAY_MS * Math.pow(2, attempt); // Exponential Backoff als Fallback

    console.warn(`[Pipedrive MCP] Rate limit hit. Retrying in ${waitMs}ms (attempt ${attempt + 1}/${MAX_RETRIES})`);
    await sleep(waitMs);
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}
```

**Backoff-Sequenz (ohne Retry-After Header):**

| Versuch | Wartezeit |
|---------|-----------|
| 1 | 1 Sekunde |
| 2 | 2 Sekunden |
| 3 | 4 Sekunden |
| 4 | 8 Sekunden |
| 5 | 16 Sekunden |

---

### 2. Sequenzielles Throttling bei Batch-Operationen

Bei Tools, die intern mehrere API-Calls ausführen (z.B. `list_activities` gefolgt von mehreren `get_person`-Calls), soll zwischen den Requests ein minimales Delay eingebaut werden.

**Implementierung:**

```typescript
const THROTTLE_DELAY_MS = 150; // ~6-7 Requests/Sekunde → deutlich unter dem Limit von 40/Sekunde

async function batchFetch<T>(
  ids: number[],
  fetchFn: (id: number) => Promise<T>
): Promise<T[]> {
  const results: T[] = [];

  for (const id of ids) {
    const result = await fetchFn(id);
    results.push(result);
    await sleep(THROTTLE_DELAY_MS);
  }

  return results;
}
```

**Betrifft folgende Tools besonders:**
- `list_activities` → anschließende `get_person`-Calls für Kontaktdetails
- `list_deals` → anschließende `get_deal`-Calls für Custom Fields / owner_id
- Jede Operation, die über eine Liste iteriert und pro Item einen weiteren Call macht

---

### 3. Fehlerbehandlung & Benutzer-Feedback

Wenn das Retry-Limit erschöpft ist, soll Claude eine **verständliche Fehlermeldung** erhalten, die weitergegeben werden kann:

```typescript
// Fehlerformat das der MCP zurückgeben soll:
{
  "error": "RATE_LIMIT_EXCEEDED",
  "message": "Die Pipedrive API hat zu viele Anfragen erhalten. Bitte in 30-60 Sekunden erneut versuchen.",
  "retryAfterSeconds": 30
}
```

---

### 4. Request-Logging (optional, empfohlen)

Für Debugging und Monitoring:

```typescript
// Pro Request loggen:
console.log(`[Pipedrive MCP] ${method} ${endpoint} → ${statusCode} (${durationMs}ms)`);

// Rate-Limit-Events separat loggen:
console.warn(`[Pipedrive MCP] 429 received for ${endpoint}. Retry-After: ${retryAfter}s`);
```

---

## Betroffene MCP Tools (Priorität)

| Tool | Risiko | Grund |
|---|---|---|
| `list_activities` + `get_person` | 🔴 Hoch | Viele sequenzielle Calls bei großen Listen |
| `list_deals` + `get_deal` | 🔴 Hoch | 2800+ Deals im System |
| `search_deals` / `search_persons` | 🟡 Mittel | Einzelcalls, aber häufig genutzt |
| `create_activity` / `update_deal` | 🟢 Niedrig | Einzelne Schreiboperationen |

---

## Akzeptanzkriterien

- [ ] Ein `429`-Response führt **nie** zu einem direkten Fehler an Claude — immer erst Retry
- [ ] Der `Retry-After`-Header wird korrekt ausgelesen und respektiert
- [ ] Bei Batch-Operationen (>5 sequenzielle Calls) wird automatisch gedrosselt
- [ ] Nach Erschöpfen aller Retries wird eine strukturierte Fehlermeldung zurückgegeben
- [ ] Alle Rate-Limit-Events werden geloggt

---

## Referenz

- [Pipedrive API Rate Limits Dokumentation](https://pipedrive.readme.io/docs/core-api-concepts-rate-limiting)
- Aktuelle Limits: 80 req / 2 sec, 80.000 req / Tag (Stand: 2026)
