# Synodic Client

An application frontend for [porringer](https://www.github.com/synodic/porringer) that helps manage and download package managers and their dependents.

## Documentation

See the [full documentation](https://synodic.github.io/synodic-client) for installation, usage, and development guides.
