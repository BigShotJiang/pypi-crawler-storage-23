"""The `synodic_client.application` package contains the GUI application logic for the Synodic Client."""
