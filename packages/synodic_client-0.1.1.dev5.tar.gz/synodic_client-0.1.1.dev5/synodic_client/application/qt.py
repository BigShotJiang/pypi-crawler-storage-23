"""gui"""

import logging
import sys
from typing import LiteralString

from porringer.api import API, APIParameters
from porringer.schema import ListPluginsParameters, LocalConfiguration
from PySide6.QtWidgets import QApplication

from synodic_client.application.screen.screen import Screen
from synodic_client.application.screen.tray import TrayScreen
from synodic_client.client import Client
from synodic_client.updater import UpdateChannel, UpdateConfig

icon: LiteralString = 'icon.png'


def application() -> None:
    """Entrypoint"""
    client = Client()

    logger = logging.getLogger('synodic_client')
    logging.basicConfig(level=logging.INFO)

    local_config = LocalConfiguration()
    api_params = APIParameters(logger)
    porringer = API(local_config, api_params)

    # Initialize the updater
    # Use DEVELOPMENT channel if running from source (not frozen)
    is_dev = not getattr(sys, 'frozen', False)
    update_channel = UpdateChannel.DEVELOPMENT if is_dev else UpdateChannel.STABLE
    update_config = UpdateConfig(channel=update_channel)
    client.initialize_updater(porringer, update_config)

    logger.info('Synodic Client v%s started (channel: %s)', client.version, update_channel.name)

    list_params = ListPluginsParameters()
    porringer.plugin.list(list_params)

    app = QApplication([])
    app.setQuitOnLastWindowClosed(False)

    screen = Screen()

    # Store tray screen as instance attribute using object.__setattr__
    # to avoid type checking issues with dynamic attributes
    tray_screen = TrayScreen(app, client, icon, screen.window)
    object.__setattr__(app, 'tray', tray_screen)

    app.exec_()


if __name__ == '__main__':
    application()
