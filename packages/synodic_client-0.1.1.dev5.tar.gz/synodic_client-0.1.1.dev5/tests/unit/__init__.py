"""The `tests.unit` package contains unit tests for individual components of the Synodic Client application."""
