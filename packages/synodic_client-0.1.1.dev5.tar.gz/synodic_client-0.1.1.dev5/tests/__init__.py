"""The `tests` package contains unit tests for the Synodic Client application."""
