"""Documentation for ogdrb."""
