"""Benchmarking for ogdrb."""
