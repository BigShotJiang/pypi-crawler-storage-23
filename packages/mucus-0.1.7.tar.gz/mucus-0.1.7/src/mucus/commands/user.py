import json

import click

import mucus.command


class Command(mucus.command.Command):
    def __call__(self, client, **kwargs):
        click.echo(json.dumps(client.data._data, indent=2))
