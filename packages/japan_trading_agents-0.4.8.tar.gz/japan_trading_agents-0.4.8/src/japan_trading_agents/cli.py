"""CLI interface for japan-trading-agents."""

from __future__ import annotations

import asyncio
import sys

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from japan_trading_agents import __version__
from japan_trading_agents.config import Config
from japan_trading_agents.data.adapters import check_available_sources

console = Console()


@click.group()
@click.version_option(version=__version__)
def cli() -> None:
    """japan-trading-agents: Multi-agent AI trading analysis for Japanese stocks."""


@cli.command()
@click.argument("code")
@click.option("--model", "-m", default="gpt-4o-mini", help="LLM model identifier (litellm format)")
@click.option("--temperature", "-t", default=0.2, type=float, help="LLM temperature")
@click.option("--edinet-code", "-e", default=None, help="EDINET code override")
@click.option("--debate-rounds", "-d", default=1, type=int, help="Bull vs Bear debate rounds")
@click.option("--json-output", is_flag=True, help="Output as JSON")
@click.option("--timeout", default=30.0, type=float, help="Per-agent timeout in seconds")
@click.option(
    "--lang",
    "-l",
    default="ja",
    type=click.Choice(["ja", "en"]),
    help="Output language: ja (Japanese) or en (English)",
)
@click.option(
    "--notify", is_flag=True, help="Send result to Telegram (requires TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID)"
)
def analyze(
    code: str,
    model: str,
    temperature: float,
    edinet_code: str | None,
    debate_rounds: int,
    json_output: bool,
    timeout: float,
    lang: str,
    notify: bool,
) -> None:
    """Analyze a Japanese stock using multi-agent pipeline.

    CODE is a Japanese stock code (e.g. 7203 for Toyota).
    """
    config = Config(
        model=model,
        temperature=temperature,
        edinet_code=edinet_code,
        debate_rounds=debate_rounds,
        json_output=json_output,
        task_timeout=timeout,
        language=lang,
        notify=notify,
    )

    asyncio.run(_run_analyze(code, config))


_UI: dict[str, dict[str, str]] = {
    "ja": {
        "current": "💰 現在値:  ¥{price:,.0f}",
        "target": "🎯 目標株価: ¥{price:,.0f}",
        "stop": "🛑 損切り:  ¥{price:,.0f}",
        "upside": "（{sign}{pct:.1f}% 想定）",
        "downside": "（{sign}{pct:.1f}% 下値）",
        "confidence": "確度",
        "position": "ポジション",
        "thesis": "📋 投資テーゼ",
        "key_facts": "📊 根拠データ",
        "watch": "👀 テーゼ無効化条件",
        "decision_header": "--- 投資判断 ---",
        "risk_header": "--- リスクレビュー ---",
        "concerns": "懸念事項:",
        "max_pos": "最大ポジション: {pct}%",
    },
    "en": {
        "current": "💰 Current:    ¥{price:,.0f}",
        "target": "🎯 Target:     ¥{price:,.0f}",
        "stop": "🛑 Stop Loss:  ¥{price:,.0f}",
        "upside": "({sign}{pct:.1f}% upside)",
        "downside": "({sign}{pct:.1f}% downside)",
        "confidence": "Confidence",
        "position": "Position",
        "thesis": "📋 Investment Thesis",
        "key_facts": "📊 Key Facts",
        "watch": "👀 Watch Conditions",
        "decision_header": "--- Trading Decision ---",
        "risk_header": "--- Risk Review ---",
        "concerns": "Concerns:",
        "max_pos": "Max Position: {pct}%",
    },
}


async def _run_analyze(code: str, config: Config) -> None:
    """Run analysis and display results."""
    from japan_trading_agents.graph import run_analysis

    console.print(
        Panel(
            f"[bold]japan-trading-agents[/bold] - Analysis: {code}\n"
            f"Model: {config.model} | Debate rounds: {config.debate_rounds}",
            title="JTA",
            border_style="blue",
        )
    )

    with console.status("[bold green]Running analysis pipeline..."):
        result = await run_analysis(code, config)

    if config.json_output:
        click.echo(result.model_dump_json(indent=2))
        return

    lang = config.language if config.language in ("ja", "en") else "ja"
    T = _UI[lang]

    # Header
    sources_count = len(result.sources_used)
    console.print(
        f"\n[bold]Sources: {sources_count}[/bold] "
        f"({', '.join(result.sources_used) if result.sources_used else 'none'})"
    )
    if result.company_name:
        console.print(f"[bold]Company: {result.company_name}[/bold]")

    # Analyst reports
    console.print("\n[bold cyan]--- Analyst Reports ---[/bold cyan]")
    for i, report in enumerate(result.analyst_reports, 1):
        console.print(
            Panel(
                report.content[:800],
                title=f"[{i}/{len(result.analyst_reports)}] {report.display_name}",
                border_style="green",
            )
        )

    # Debate
    if result.debate:
        console.print("\n[bold cyan]--- Bull vs Bear Debate ---[/bold cyan]")
        console.print(
            Panel(
                result.debate.bull_case.content[:600],
                title="Bull Case",
                border_style="green",
            )
        )
        console.print(
            Panel(
                result.debate.bear_case.content[:600],
                title="Bear Case",
                border_style="red",
            )
        )

    # Trading decision — investment memo format
    if result.decision:
        d = result.decision
        color = {"BUY": "green", "SELL": "red", "HOLD": "yellow"}.get(d.action, "white")

        # Price info
        stock_price = result.raw_data.get("stock_price") if result.raw_data else None
        current_price: float | None = None
        if isinstance(stock_price, dict):
            current_price = stock_price.get("current_price") or stock_price.get("close")

        price_lines = []
        if current_price:
            price_lines.append(T["current"].format(price=current_price))
        if d.target_price:
            suffix = ""
            if current_price:
                pct = (d.target_price - current_price) / current_price * 100
                suffix = "  " + T["upside"].format(sign="+" if pct >= 0 else "", pct=pct)
            price_lines.append(T["target"].format(price=d.target_price) + suffix)
        if d.stop_loss:
            suffix = ""
            if current_price:
                pct = (d.stop_loss - current_price) / current_price * 100
                suffix = "  " + T["downside"].format(sign="+" if pct >= 0 else "", pct=pct)
            price_lines.append(T["stop"].format(price=d.stop_loss) + suffix)

        # Build decision panel content
        decision_content = (
            f"[bold {color}]{d.action}[/bold {color}]"
            f"  |  {T['confidence']}: {d.confidence:.0%}"
            f"  |  {T['position']}: {d.position_size or 'N/A'}\n"
        )
        if price_lines:
            decision_content += "\n" + "\n".join(price_lines) + "\n"
        if d.thesis:
            decision_content += f"\n[bold]{T['thesis']}[/bold]\n{d.thesis}\n"
        if d.key_facts:
            decision_content += f"\n[bold]{T['key_facts']}[/bold]\n"
            for kf in d.key_facts:
                src = f"  [dim]({kf.source})[/dim]" if kf.source else ""
                decision_content += f"• {kf.fact}{src}\n"
        if d.watch_conditions:
            decision_content += f"\n[bold]{T['watch']}[/bold]\n"
            for cond in d.watch_conditions:
                decision_content += f"• {cond}\n"

        console.print(f"\n[bold cyan]{T['decision_header']}[/bold cyan]")
        console.print(Panel(decision_content.strip(), title="Decision", border_style=color))

    # Risk review
    if result.risk_review:
        approved = result.risk_review.approved
        status = "[green]✅ Approved[/green]" if approved else "[red]❌ Rejected[/red]"
        concerns_text = ""
        if result.risk_review.concerns:
            concerns_text = f"\n[bold]{T['concerns']}[/bold]\n" + "\n".join(
                f"• {c}" for c in result.risk_review.concerns
            )
        max_pos = (
            "\n" + T["max_pos"].format(pct=result.risk_review.max_position_pct)
            if result.risk_review.max_position_pct
            else ""
        )
        console.print(f"\n[bold cyan]{T['risk_header']}[/bold cyan]")
        console.print(
            Panel(
                f"Status: {status}{max_pos}\n\n{result.risk_review.reasoning}{concerns_text}",
                title="Risk Manager",
                border_style="green" if approved else "red",
            )
        )

    # Disclaimer
    console.print(
        "\n[dim]This is not financial advice. For educational and research purposes only.[/dim]"
    )

    # Telegram notification
    if config.notify:
        from japan_trading_agents.notifier import TelegramNotifier

        notifier = TelegramNotifier(
            bot_token=config.telegram_bot_token,
            chat_id=config.telegram_chat_id,
        )
        if not notifier.is_configured():
            console.print(
                "[yellow]⚠️  Telegram not configured. "
                "Set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID.[/yellow]"
            )
        else:
            with console.status("[bold]Sending Telegram alert..."):
                sent = await notifier.send(result)
            if sent:
                console.print("[green]✅ Telegram alert sent.[/green]")
            else:
                console.print("[red]❌ Telegram alert failed.[/red]")


@cli.command()
def check() -> None:
    """Check which data sources are available."""
    sources = check_available_sources()

    table = Table(title="Data Sources")
    table.add_column("Source", style="cyan")
    table.add_column("Package", style="white")
    table.add_column("Status", style="white")

    packages = {
        "edinet": "edinet-mcp",
        "tdnet": "tdnet-disclosure-mcp",
        "estat": "estat-mcp",
        "boj": "boj-mcp",
        "news": "japan-news-mcp",
        "jquants": "jquants-mcp",
    }

    for name, available in sources.items():
        status = "[green]Installed[/green]" if available else "[red]Not installed[/red]"
        table.add_row(name, packages.get(name, ""), status)

    console.print(table)

    installed = sum(1 for v in sources.values() if v)
    console.print(f"\n{installed}/{len(sources)} data sources available")

    if installed < len(sources):
        console.print('\n[dim]Install all: pip install "japan-trading-agents[all-data]"[/dim]')


@cli.command()
def serve() -> None:
    """Start the MCP server (requires fastmcp)."""
    try:
        from japan_trading_agents.server import mcp

        mcp.run()
    except ImportError:
        console.print("[red]FastMCP not installed. Run: pip install fastmcp[/red]")
        sys.exit(1)
