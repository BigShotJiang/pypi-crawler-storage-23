from typing import Any, Dict, List, Optional, Tuple


class NDCAParseError(Exception):
    def __init__(self, message: str, line: int = 1, col: int = 1):
        super().__init__(f"{message} (line {line}, col {col})")
        self.line = line
        self.col = col
        self.message = message


class NDCAParser:
    def __init__(self, text: str, allow_duplicate_keys: bool = False, bool_case_insensitive: bool = True):
        self.text = text
        self.i = 0
        self.n = len(text)
        self.line = 1
        self.col = 1
        self.allow_duplicate_keys = allow_duplicate_keys
        self.bool_case_insensitive = bool_case_insensitive

    def _peek(self) -> str:
        if self.i < self.n:
            return self.text[self.i]
        return ""

    def _next(self) -> str:
        ch = self._peek()
        if ch:
            self.i += 1
            if ch == "\n":
                self.line += 1
                self.col = 1
            else:
                self.col += 1
        return ch

    def _error(self, msg: str) -> None:
        raise NDCAParseError(msg, line=self.line, col=self.col)

    def _skip_whitespace_and_comments(self) -> None:
        while True:
            ch = self._peek()
            if ch == "" :
                return
            if ch.isspace():
                self._next()
                continue
            if ch == "*":
                self._next()
                self._skip_comment()
                continue
            return

    def _skip_comment(self) -> None:
        depth = 1
        while True:
            ch = self._next()
            if ch == "":
                self._error("unterminated comment")
            if ch == "*":
                depth -= 1
                if depth <= 0:
                    return

    def parse(self) -> Dict[str, Any]:
        self._skip_whitespace_and_comments()
        if self._peek() != "<":
            self._error("document must start with '<'")
        obj = self._parse_object()
        self._skip_whitespace_and_comments()
        if self.i < self.n:
            rest = self.text[self.i:].strip()
            if rest != "":
                self._error("extra data after document")
        return obj

    def _parse_object(self) -> Dict[str, Any]:
        if self._next() != "<":
            self._error("expected '<' to start object")
        result: Dict[str, Any] = {}
        self._skip_whitespace_and_comments()
        while True:
            self._skip_whitespace_and_comments()
            if self._peek() == ">":
                self._next()
                break
            if self._peek() != "[":
                self._error("expected '[' for key")
            key = self._parse_key()
            if key == "":
                self._error("empty key is not allowed")
            self._skip_whitespace_and_comments()
            if self._next() != "=":
                self._error("expected '=' after key")
            self._skip_whitespace_and_comments()
            value = self._parse_value()
            if not self.allow_duplicate_keys and key in result:
                self._error(f"duplicate key '{key}'")
            result[key] = value
            self._skip_whitespace_and_comments()
            ch = self._peek()
            if ch == ";":
                self._next()
                self._skip_whitespace_and_comments()
                continue
            if ch == ">":
                self._next()
                break
            self._error("expected ';' or '>' after value")
        return result

    def _parse_key(self) -> str:
        if self._next() != "[":
            self._error("expected '[' to start key")
        start = self.i
        while True:
            ch = self._peek()
            if ch == "":
                self._error("unterminated key")
            if ch == "]":
                end = self.i
                self._next()
                break
            self._next()
        key = self.text[start:end]
        return key

    def _parse_value(self) -> Any:
        self._skip_whitespace_and_comments()
        ch = self._peek()
        if ch == "":
            self._error("unexpected EOF when parsing value")
        if ch == "\"":
            return self._parse_string()
        if ch == "<":
            return self._parse_object()
        if ch == "(":
            return self._parse_list()
        token = self._parse_token()
        if token == "":
            self._error("expected token as value")
        token_for_bool = token
        if self.bool_case_insensitive:
            token_for_bool = token.lower()
        if token_for_bool in ("true", "false", "null"):
            if token_for_bool == "true":
                return True
            if token_for_bool == "false":
                return False
            return None
        num = self._try_parse_number(token)
        if num is not None:
            return num
        return token

    def _parse_string(self) -> str:
        if self._next() != "\"":
            self._error("expected '\"' to start string")
        buf: List[str] = []
        while True:
            ch = self._next()
            if ch == "":
                self._error("unterminated string")
            if ch == "\\":
                esc = self._next()
                if esc == "":
                    self._error("unterminated escape sequence")
                if esc == "n":
                    buf.append("\n")
                elif esc == "r":
                    buf.append("\r")
                elif esc == "t":
                    buf.append("\t")
                elif esc == "\\":
                    buf.append("\\")
                elif esc == "\"":
                    buf.append("\"")
                else:
                    buf.append("\\" + esc)
                continue
            if ch == "\"":
                break
            buf.append(ch)
        return "".join(buf)

    def _parse_list(self) -> List[Any]:
        if self._next() != "(":
            self._error("expected '(' to start list")
        arr: List[Any] = []
        self._skip_whitespace_and_comments()
        while True:
            self._skip_whitespace_and_comments()
            if self._peek() == ")":
                self._next()
                break
            value = self._parse_value()
            arr.append(value)
            self._skip_whitespace_and_comments()
            ch = self._peek()
            if ch == ";":
                self._next()
                self._skip_whitespace_and_comments()
                continue
            if ch == ")":
                self._next()
                break
            self._error("expected ';' or ')' in list")
        return arr

    def _parse_token(self) -> str:
        self._skip_whitespace_and_comments()
        start = self.i
        stop_chars = set(";()<>]=\"[]")
        while True:
            ch = self._peek()
            if ch == "" or ch.isspace() or ch in stop_chars:
                break
            self._next()
        tok = self.text[start:self.i]
        if tok == "":
            self._error("expected token")
        return tok

    def _try_parse_number(self, s: str) -> Optional[Any]:
        if s == "":
            return None
        neg = False
        s2 = s
        if s2[0] in "+-":
            if s2[0] == "-":
                neg = True
            s2 = s2[1:]
        if s2 == "":
            return None
        has_dot = "." in s2
        has_exp = "e" in s2 or "E" in s2
        if has_dot or has_exp:
            try:
                v = float(s)
                return v
            except Exception:
                return None
        try:
            v = int(s)
            return v
        except Exception:
            return None