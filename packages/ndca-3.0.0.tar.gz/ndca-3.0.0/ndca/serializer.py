import math
from typing import Any, Dict, List, Optional, Set
from collections.abc import Mapping, Sequence


def _escape_string(s: str) -> str:
    def _to_hex(u: int) -> str:
        return "\\u" + hex(u)[2:].zfill(4)
    out_chars: List[str] = ['"']
    for ch in s:
        code = ord(ch)
        if ch == '"':
            out_chars.append('\\"')
        elif ch == '\\':
            out_chars.append('\\\\')
        elif ch == '\n':
            out_chars.append('\\n')
        elif ch == '\r':
            out_chars.append('\\r')
        elif ch == '\t':
            out_chars.append('\\t')
        elif 0x20 <= code <= 0x7E:
            out_chars.append(ch)
        else:
            out_chars.append(_to_hex(code))
    out_chars.append('"')
    return "".join(out_chars)


def _format_float(f: float) -> str:
    if not math.isfinite(f):
        return "null"
    s = repr(f)
    if "e" in s or "E" in s or "." in s:
        return s
    return s + ".0"


def _ensure_valid_key(k: str) -> None:
    if not isinstance(k, str):
        raise TypeError("keys must be strings")
    if k == "":
        raise TypeError("empty string is not allowed as a key")
    if "\n" in k or "\r" in k:
        raise TypeError("keys must not contain newlines")


def _serialize_value(value: Any, _seen: Optional[Set[int]] = None) -> str:
    if _seen is None:
        _seen = set()
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int) and not isinstance(value, bool):
        return str(value)
    if isinstance(value, float):
        return _format_float(value)
    if isinstance(value, str):
        return _escape_string(value)
    vid = id(value)
    if vid in _seen:
        raise TypeError("circular reference detected")
    if isinstance(value, Mapping):
        _seen.add(vid)
        try:
            return _serialize_object(dict(value), _seen)
        finally:
            _seen.discard(vid)
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        _seen.add(vid)
        try:
            parts: List[str] = []
            parts.append("(")
            first = True
            for item in value:
                parts.append(_serialize_value(item, _seen))
                parts.append(";")
                first = False
            parts.append(")")
            return "".join(parts)
        finally:
            _seen.discard(vid)
    raise TypeError(f"unsupported type: {type(value).__name__}")


def _serialize_object(d: Dict[str, Any], _seen: Optional[Set[int]] = None) -> str:
    if _seen is None:
        _seen = set()
    vid = id(d)
    if vid in _seen:
        raise TypeError("circular reference detected in object")
    _seen.add(vid)
    try:
        keys = list(d.keys())
        for k in keys:
            _ensure_valid_key(k)
        keys_sorted = sorted(keys)
        parts: List[str] = []
        parts.append("<")
        for k in keys_sorted:
            v = d[k]
            parts.append("[")
            parts.append(k)
            parts.append("]")
            parts.append("=")
            parts.append(_serialize_value(v, _seen))
            parts.append(";")
        parts.append(">")
        return "".join(parts)
    finally:
        _seen.discard(vid)


def serialize_object(d: Dict[str, Any]) -> str:
    if not isinstance(d, dict):
        raise TypeError("serialize_object expects a dict")
    return _serialize_object(d)