from setuptools import setup, find_packages

setup(
    name='ai_test_package',                    # Your package name
    version='0.1.1',                        # Version number
    packages=find_packages(),             # Automatically find packages
    install_requires=[],                  # List dependencies if any
    author='KingsleyAsare',                   # Your name
    author_email='kingsleyasare20@yahoo.com',# Your email
    description='A brief description of your package',
    url='https://github.com/KLightiam/ai_test_package', # Your project URL
)


