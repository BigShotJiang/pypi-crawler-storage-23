# Video Search & Discovery

You have tools for finding and inspecting videos across the web and the local library.

## Tools

- **video_search** — Search online across YouTube, Vimeo, Dailymotion, and other platforms
- **video_search_local** — Search previously downloaded videos in the local library
- **video_get_info** — Get detailed metadata for a specific video URL (title, duration, uploader, available qualities)

## When to use

Use video tools when the user wants to:
- Find or discover videos on a topic
- Get video recommendations
- Look up a specific video or channel
- Compare video options before watching or downloading

## Strategy

1. **Check local first**: If the user might have relevant downloaded videos, try `video_search_local` before going online.
2. **Broad search**: Use `video_search` with a clear query. Start with the default 20 results.
3. **Refine if needed**: If results are too broad, search again with more specific terms or use the `platform` filter (youtube, vimeo, dailymotion).
4. **Inspect before recommending**: Use `video_get_info` on specific URLs to verify duration, quality options, or content before suggesting them.

## Platform filter

Set the `platform` parameter to target a specific site:
- `"youtube"` — YouTube only
- `"vimeo"` — Vimeo only
- `"dailymotion"` — Dailymotion only
- `"all"` (default) — search everywhere

## Presenting results

When responding in chat, present results conversationally:
- Highlight the most relevant 3-5 results rather than listing all 20
- Mention duration so users know what they're committing to
- Note the platform if it matters (e.g. Vimeo for higher quality, YouTube for breadth)
- If the user asked for short videos, filter by duration in your response
