import pytest


def test_basic_component(page, start_falk_app):
    """
    This test tests basic requests handling and partial re rendering by setting
    up a counter component that can be incremented if a button is clicked.

    The test is successful if:

      - The page shows a heading with the class name `title`
      - The component shows `1` as its initial value
      - The component shows `2` after it is clickd

      - The component changed its class name from `button-1` to `button-2`
        after it was clicked

    """

    from falk.components import HTML5Base

    def Counter(template_context, state, initial_render):
        if initial_render:
            state["counter"] = 1

        def increment():
            state["counter"] += 1

        template_context.update({
            "increment": increment,
        })

        return """
            <button
              id="button-{{ state.counter }}"
              onclick="{{ falk.run_callback(increment) }}">

                {{ state.counter }}
            </button>
        """

    def Index(template_context, HTML5Base=HTML5Base, Counter=Counter):
        return """
            <HTML5Base title="Counter">
                <h1 id="title">Counter</h1>
                <Counter />
            </HTML5Base>
        """

    def configure_app(add_route):
        add_route(r"/", Index)

    _, base_url, _ = start_falk_app(
        configure_app=configure_app,
    )

    # run test
    # go to the base URL and wait for the counter to appear
    page.goto(base_url)
    page.wait_for_selector("h1#title")
    page.wait_for_selector("#button-1")

    assert page.title() == "Counter"

    # increment counter
    assert page.inner_text("#button-1") == "1"

    page.click("#button-1")
    page.wait_for_selector("#button-2")

    assert page.inner_text("#button-2") == "2"


@pytest.mark.only_browser("chromium")
def test_prop_passing(page, start_falk_app):
    """
    This test tests whether passing all props of a component to another
    component works by defining three components: An outer component, a mid
    component and an inner component.
    The outer component calls the inner component with a prop, the mid
    component is forwarding all props it is given and the inner component
    is rendering the prop given by the outer component.

    The test does not use the HTML5Base component on purpose. This ensures
    that this rendering mechanism works without any client side hydration.

    The test is successful if the inner component gets rendered with the outer
    component text and attributes.

    """

    def InnerComponent(props):
        return """
            <div id="inner-component" foo="{{ props.foo }}">
                {{ props.children }}
            </div>
        """

    def MidComponent(props, InnerComponent=InnerComponent):
        return """
            <InnerComponent props="{{ props }}">
                {{ props.children }}
            </InnerComponent>
        """

    def OuterComponent(MidComponent=MidComponent):
        return """
            <MidComponent foo="bar">
                Outer Component Text
            </MidComponent>
        """

    def configure_app(add_route):
        add_route(r"/", OuterComponent)

    _, base_url, _ = start_falk_app(
        configure_app=configure_app,
    )

    # run test
    page.goto(base_url)
    page.inner_text("#inner-component[foo=bar]") == "Outer Component Text"


@pytest.mark.only_browser("chromium")
def test_dynamic_attribute_rendering(page, start_falk_app):
    """
    This test tests dynamic attribute rendering (templating syntax within
    a tag using the `_` meta attribute) by rendering a simple component that
    has one static attribute and a list of attributes generated in a
    Jinja loop.
    The test component does not use the HTML5Base component on purpose. This
    ensures that this rendering mechanism works without any
    client side hydration.
    The underscore attribute should only be available in HTML tags, not in
    component calls.

    The test is successful if the test component shows up in the browser
    with all static and dynamic attributes and the test text.
    The test fails if the underscore can be used in component calls.
    """

    def Component():
        return """
            <div id="component" _='
                {% for i in ["a", "b", "c"] %}
                    {{ i }}="{{ i * 3 }}"
                {% endfor %}
            '>
                Component Text
            </div>
        """

    def InvalidComponentCalling(Component=Component):
        return """
            <Component _="foo='bar'" />
        """

    def configure_app(add_route, mutable_settings):
        mutable_settings["debug"] = True

        add_route(r"/component(/)", Component)
        add_route(r"/invalid-component-calling(/)", InvalidComponentCalling)

    _, base_url, _ = start_falk_app(
        configure_app=configure_app,
    )

    # component
    page.goto(base_url + "/component")
    page.inner_text("#component[a=aaa][b=bbb][c=ccc]") == "Component Text"

    # invalid component calling
    page.goto(base_url + "/invalid-component-calling")
    exception_text = page.inner_html(".falk-error pre")

    assert ".InvalidComponentError:" in exception_text
    assert ".test_dynamic_attribute_rendering." in exception_text
    assert ".InvalidComponentCalling: " in exception_text
    assert "the underscore attribute is not available in component calls" in exception_text  # NOQA


@pytest.mark.only_browser("chromium")
def test_html5_base_component(page, start_falk_app):
    """
    This test tests `falk.components.HTML5Base` with custom styles, custom
    scripts and custom html- and body classes and ids.
    """

    from falk.components import HTML5Base

    def View(HTML5Base=HTML5Base):
        return """
            <style data-falk-id="test-style"></style>

            <HTML5Base
              title="Test Title"
              html_id="html-id"
              html_class="html-class-1 html-class-2"
              body_id="body-id"
              body_class="body-class-1 body-class-2">

              Test Text
            </HTML5Base>

            <script data-falk-id="test-script"></script>
        """

    def configure_app(add_route):
        add_route(r"/", View)

    _, base_url, _ = start_falk_app(
        configure_app=configure_app,
    )

    # run test
    page.goto(base_url)
    page.inner_text("body") == "Test Text"
    page.wait_for_selector("html#html-id.html-class-1.html-class-2")
    page.wait_for_selector("body#body-id.body-class-1.body-class-2")
    page.wait_for_selector("style[data-falk-id=test-style]", state="hidden")
    page.wait_for_selector("script[data-falk-id=test-script]", state="hidden")

    assert page.title() == "Test Title"


@pytest.mark.only_browser("chromium")
def test_component_event_checks(page, start_falk_app):
    """
    This test tests the component event checks by defining a component that
    defines a `oninitialrender` event handler on non-root node.

    The test is successful if the component raises a `InvalidComponentError`
    when we try to render it.
    """

    from falk.components import HTML5Base

    def TestComponent():
        return """
            <div>
                <div oninitialrender="alert('this should not work');"></div>
            </div>
        """

    def View(
            HTML5Base=HTML5Base,
            TestComponent=TestComponent,
    ):

        return """
            <HTML5Base>
                <TestComponent />
            </HTML5Base>
        """

    def configure_app(add_route, mutable_settings):
        mutable_settings["debug"] = True

        add_route(r"/", View)

    _, base_url, _ = start_falk_app(
        configure_app=configure_app,
    )

    # run test
    page.goto(base_url)
    exception_text = page.inner_html(".falk-error pre")

    assert "InvalidComponentError: " in exception_text
    assert "oninitialrender can only be used on the root node" in exception_text  # NOQA


@pytest.mark.only_browser("chromium")
def test_component_execution_errors(page, start_falk_app):
    """
    This test tests ComponentExecutionErrors that get raised if a component
    or a component callback raises an exception that is not a FalkError.

    The test makes sure that crashing components and component callbacks
    contain all information necessary for debugging (component name, component
    module, original exception).
    The error message should contain the falk error type, the component name
    and its module and a repr of the originial error.
    """

    from falk.components import HTML5Base

    def CrashingComponent(HTML5Base=HTML5Base):
        1 / 0  # raises a ZeroDivisionError

        return """
            <HTML5Base>
                <div>this should not be visible</div>
            </HTML5Base>
        """

    def ComponentWithCrashingCallback(template_context, HTML5Base=HTML5Base):
        def crashing_callback():
            1 / 0  # raises a ZeroDivisionError

        template_context.update({
            "crashing_callback": crashing_callback,
        })

        return """
            <HTML5Base>
                <button
                  id="crash"
                  onclick="{{ falk.run_callback(crashing_callback) }}">
                </button>
            </HTML5Base>
        """

    def configure_app(add_route, mutable_settings):
        mutable_settings["debug"] = True

        add_route(r"/crashing-component(/)", CrashingComponent)
        add_route(r"/crashing-callback(/)", ComponentWithCrashingCallback)

    _, base_url, _ = start_falk_app(
        configure_app=configure_app,
    )

    # test crashing component
    page.goto(base_url + "/crashing-component")
    exception_text = page.inner_html(".falk-error pre")

    # The error message should contain the falk error type, the component name
    # and its module and a repr of the originial error.
    assert ".ComponentExecutionError:" in exception_text
    assert ".test_component_execution_errors." in exception_text
    assert ".CrashingComponent: " in exception_text
    assert "ZeroDivisionError" in exception_text

    # test crashing callback
    page.goto(base_url + "/crashing-callback")
    page.click("button#crash")
    exception_text = page.inner_html(".falk-error")

    # The error message should contain the falk error type, the component name
    # and its module, the crashing callbacks name, and a repr of the
    # originial error.
    assert "Error 500:" in exception_text
    assert ".ComponentExecutionError:" in exception_text
    assert ".test_component_execution_errors." in exception_text

    assert (
        ".ComponentWithCrashingCallback::crashing_callback:" in exception_text
    )

    assert "ZeroDivisionError" in exception_text


@pytest.mark.only_browser("chromium")
def test_component_templating_errors(page, start_falk_app):
    """
    This test tests ComponentTemplatingErrors that get raised if a component
    contains either a valid component template that contains invalid Jinja2
    syntax, or if an exception gets raisde during Jinja2 rendering.

    The test makes sure that crashing components and component callbacks
    contain all information necessary for debugging (component name, component
    module, original exception).
    The error message should contain the falk error type, the component name
    and its module and a repr of the originial error.
    """

    from falk.components import HTML5Base

    def InvalidTemplateComponent(HTML5Base=HTML5Base):
        return """
            <HTML5Base>
                <div>
                    {%
                </div>
            </HTML5Base>
        """

    def CrashingTemplateComponent(HTML5Base=HTML5Base):
        return """
            <HTML5Base>
                <div a="{{ 1 / 0 }}"></div>
            </HTML5Base>
        """

    def configure_app(add_route, mutable_settings):
        mutable_settings["debug"] = True

        add_route(r"/invalid-template(/)", InvalidTemplateComponent)
        add_route(r"/crashing-template(/)", CrashingTemplateComponent)

    _, base_url, _ = start_falk_app(
        configure_app=configure_app,
    )

    # invalid template component
    page.goto(base_url + "/invalid-template")
    exception_text = page.inner_html(".falk-error pre")

    assert ".ComponentTemplatingError:" in exception_text
    assert ".test_component_templating_errors." in exception_text
    assert ".InvalidTemplateComponent: " in exception_text
    assert "TemplateSyntaxError" in exception_text

    # crashing template component
    page.goto(base_url + "/crashing-template")
    exception_text = page.inner_html(".falk-error pre")

    assert ".ComponentTemplatingError:" in exception_text
    assert ".test_component_templating_errors." in exception_text
    assert ".CrashingTemplateComponent: " in exception_text
    assert "ZeroDivisionError" in exception_text
