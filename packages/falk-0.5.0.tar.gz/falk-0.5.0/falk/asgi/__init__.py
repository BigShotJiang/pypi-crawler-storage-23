from falk.asgi.app import get_asgi_app  # NOQA
