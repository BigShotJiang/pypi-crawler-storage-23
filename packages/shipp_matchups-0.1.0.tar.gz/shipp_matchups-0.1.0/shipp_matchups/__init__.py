"""
shipp-matchups: Head-to-head team and player matchup analysis for NBA, MLB, and Soccer.
"""
__version__ = "0.1.0"
