from .sekejap import *

__doc__ = sekejap.__doc__
if hasattr(sekejap, "__all__"):
    __all__ = sekejap.__all__