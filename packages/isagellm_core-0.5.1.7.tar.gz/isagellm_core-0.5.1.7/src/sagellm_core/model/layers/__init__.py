"""Custom model layers with kernel injection support.

This module provides custom layer implementations that support
backend kernel injection for performance optimization.

Components:
- CustomLinear: Linear layer with kernel injection support
- CustomRMSNorm: RMSNorm layer with kernel injection support
- CustomLayerNorm: LayerNorm layer with kernel injection support
- FusedSiLUMul: Fused SiLU activation with element-wise multiply
- FusedAddRMSNorm: Fused residual add + RMS normalization
- FusedQKVProjection: Fused Query-Key-Value projection
- replace_layers_in_model: Utility to replace standard layers with custom layers

These layers address issue #38 and #39.
"""

from __future__ import annotations

from sagellm_core.model.layers.linear import CustomLinear
from sagellm_core.model.layers.normalization import CustomLayerNorm, CustomRMSNorm
from sagellm_core.model.layers.fused_layers import (
    FusedSiLUMul,
    FusedAddRMSNorm,
    FusedQKVProjection,
)
from sagellm_core.model.layers.layer_replacement import (
    replace_layers_in_model,
    replace_linear_with_custom,
    replace_rmsnorm_with_custom,
)

__all__ = [
    "CustomLinear",
    "CustomRMSNorm",
    "CustomLayerNorm",
    "FusedSiLUMul",
    "FusedAddRMSNorm",
    "FusedQKVProjection",
    "replace_layers_in_model",
    "replace_linear_with_custom",
    "replace_rmsnorm_with_custom",
]
