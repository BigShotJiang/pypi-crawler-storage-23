"""Scheduler - Request scheduling for Continuous Batching.

The Scheduler is responsible for:
1. Selecting which requests to run in the next step (via pluggable policies)
2. Managing KV cache allocation (via SchedulerKVBridge)
3. Separating prefill vs decode batches
4. Preemption decisions (future)

Key Components:
- ContinuousBatchingScheduler: Main scheduler class
- SchedulerKVBridge: Thin wrapper around sagellm-kv-cache
- SchedulerPolicy: Pluggable admission control (FCFS, Priority, etc.)
- Batch: Prefill or decode batch with block_tables
"""

from sagellm_core.engine_core.scheduler.base import (
    SchedulerPolicy,
    get_policy,
    list_policies,
    register_policy,
)
from sagellm_core.engine_core.scheduler.batch import Batch
from sagellm_core.engine_core.scheduler.metrics import RequestMetadata, SchedulerMetrics
from sagellm_core.engine_core.scheduler.scheduler import (
    ContinuousBatchingScheduler,
    SchedulerConfig,
    SchedulerOutput,
)
from sagellm_core.engine_core.scheduler.scheduler_kv_bridge import SchedulerKVBridge

__all__ = [
    # Main classes
    "ContinuousBatchingScheduler",
    "SchedulerConfig",
    "SchedulerOutput",
    "Batch",
    # KV bridge
    "SchedulerKVBridge",
    # Policy system
    "SchedulerPolicy",
    "register_policy",
    "get_policy",
    "list_policies",
    # Metrics
    "SchedulerMetrics",
    "RequestMetadata",
]
