# How-to Guides

Task-oriented instructions for common Artisan framework operations. Each guide follows a consistent format: prerequisites, step-by-step instructions, and a verification step to confirm success.

## Operations

- [Writing Creator Operations](writing-creator-operations.md) — Build
  operations that produce new artifacts
- [Writing Curator Operations](writing-curator-operations.md) — Build
  operations that filter, merge, or transform collections
- [Creating Artifact Types](creating-artifact-types.md) — Define custom
  artifact types for your domain

## Pipelines

- [Building a Pipeline](building-a-pipeline.md) — Create, wire, and execute
  a pipeline from scratch

## Configuration

- [Configuring Execution](configuring-execution.md) — Resource allocation,
  batching, and SLURM configuration

## Results

- [Inspecting Provenance](inspecting-provenance.md) — Query lineage and trace
  artifact history
- [Exporting Results](exporting-results.md) — Extract data from Delta tables
  and export artifacts

## Cross-References

- [Concepts](../concepts/index.md) -- Understand the design decisions behind the tasks in these guides
- [Reference](../reference/index.md) -- API details and schema specifications for types used in these guides
- [Tutorials](../tutorials/index.md) -- Hands-on walkthroughs that introduce the framework interactively
