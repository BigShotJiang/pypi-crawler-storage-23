"""Tests for curator operations."""
