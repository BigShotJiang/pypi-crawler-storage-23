import importlib.metadata
import pathlib

from ._core import (
    Auth,
    AuthorizationCodeConfig,
    AuthorizationCodeFlow,
    CallbackResponseLocalizedTexts,
    CallbackResponseTexts,
    ClientCredentialsAuth,
    ClientCredentialsClientSecretAutoAuth,
    ClientCredentialsClientSecretBasicAuth,
    ClientCredentialsClientSecretPostAuth,
    ClientCredentialsConfig,
    ClientCredentialsFlow,
    ClientCredentialsPrivateKeyJwtAuth,
    ClientCredentialsTlsClientAuth,
    Flow,
    JwtBearerConfig,
    JwtBearerFlow,
    authorization_code_flow,
    client_credentials_flow,
    jwt_bearer_execute,
)
from ._lib import Scope, Url
from ._lib.jwt import SignerConfig, SignerFilePrivateKey, SignerInlinePrivateKey, SignerPrivateKey

MODULE_DIR = pathlib.Path(__file__).absolute().parent
PACKAGE_NAME = MODULE_DIR.name

__version__ = importlib.metadata.version(PACKAGE_NAME)

__all__ = [
    'Auth',
    'AuthorizationCodeConfig',
    'AuthorizationCodeFlow',
    'AuthorizationCodeFlow',
    'CallbackResponseLocalizedTexts',
    'CallbackResponseTexts',
    'ClientCredentialsAuth',
    'ClientCredentialsClientSecretAutoAuth',
    'ClientCredentialsClientSecretBasicAuth',
    'ClientCredentialsClientSecretPostAuth',
    'ClientCredentialsConfig',
    'ClientCredentialsFlow',
    'ClientCredentialsFlow',
    'ClientCredentialsPrivateKeyJwtAuth',
    'ClientCredentialsTlsClientAuth',
    'Flow',
    'Flow',
    'JwtBearerConfig',
    'JwtBearerFlow',
    'JwtBearerFlow',
    'Scope',
    'SignerConfig',
    'SignerFilePrivateKey',
    'SignerInlinePrivateKey',
    'SignerPrivateKey',
    'Url',
    'authorization_code_flow',
    'client_credentials_flow',
    'jwt_bearer_execute',
]
