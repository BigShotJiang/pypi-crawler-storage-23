import dataclasses
import datetime
import pathlib
import time
import typing as t
import uuid

import jwt as jwtlib
import pydantic
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec, ed448, ed25519, rsa

from ._types import Url

AllowedPrivateKeys: t.TypeAlias = (
    rsa.RSAPrivateKey
    | ec.EllipticCurvePrivateKey
    | ed25519.Ed25519PrivateKey
    | ed448.Ed448PrivateKey
)


class SignerInlinePrivateKey(pydantic.BaseModel):
    pem: str


class SignerFilePrivateKey(pydantic.BaseModel):
    path: pathlib.Path
    password: bytes


type SignerPrivateKey = SignerInlinePrivateKey | SignerFilePrivateKey


class SignerConfig(pydantic.BaseModel, frozen=True):
    private_key: SignerPrivateKey
    jwt_duration: datetime.timedelta | None = None
    algorithm: str | None = None
    key_id: str | None = None

    def get_jwt_duration(self) -> datetime.timedelta:
        if self.jwt_duration is not None:
            return self.jwt_duration

        return datetime.timedelta(minutes=5)


@dataclasses.dataclass(frozen=True, slots=True)
class Signer:
    jwt_duration: datetime.timedelta
    private_key: AllowedPrivateKeys
    algorithm: str | None
    key_id: str | None

    @staticmethod
    def from_config(config: SignerConfig) -> 'Signer':
        match config.private_key:
            case SignerInlinePrivateKey():
                private_key = serialization.load_pem_private_key(
                    config.private_key.pem.encode('ascii'), password=None
                )
            case SignerFilePrivateKey():
                private_key = serialization.load_pem_private_key(
                    config.private_key.path.read_bytes(), password=config.private_key.password
                )

        if not isinstance(private_key, AllowedPrivateKeys):
            msg = f'Private key type is not allowed: {type(private_key)}'
            raise TypeError(msg)

        return Signer(
            jwt_duration=config.get_jwt_duration(),
            private_key=private_key,
            algorithm=config.algorithm,
            key_id=config.key_id,
        )

    def get_default_algorithm(self) -> str:
        match self.private_key:
            case rsa.RSAPrivateKey():
                return 'RS256'
            case ec.EllipticCurvePrivateKey():
                curve = self.private_key.curve
                if isinstance(curve, ec.SECP256R1):
                    return 'ES256'
                if isinstance(curve, ec.SECP384R1):
                    return 'ES384'
                if isinstance(curve, ec.SECP521R1):
                    return 'ES512'
                msg = f'Unsupported EC Curve: {curve.name}'
                raise ValueError(msg)
            case ed25519.Ed25519PrivateKey() | ed448.Ed448PrivateKey():
                return 'EdDSA'

    def sign(self, issuer: str, subject: str, audience: str | Url) -> str:
        now = time.time()
        return jwtlib.encode(
            headers={'kid': self.key_id} if self.key_id is not None else {},
            payload={
                'iss': issuer,
                'sub': subject,
                'aud': str(audience),
                'jti': str(uuid.uuid4()),
                'exp': int(now + self.jwt_duration.total_seconds()),
                'iat': int(now),
            },
            key=self.private_key,
            algorithm=self.algorithm or self.get_default_algorithm(),
        )


@dataclasses.dataclass(frozen=True, slots=True)
class ParsedPayload(pydantic.BaseModel):
    iss: str | None
    client_id: str | None
    exp: int | float | None


def parse_payload(token: str) -> ParsedPayload:
    try:
        payload = jwtlib.decode(token, options={'verify_signature': False})
    except jwtlib.PyJWTError as e:
        msg = 'Could not decode access_token. Is it a valid JWT?'
        raise ValueError(msg) from e

    iss = payload.get('iss')
    if iss is not None and not isinstance(iss, str):
        msg = f'Invalid iss claim: {iss!r}'
        raise TypeError(msg)

    client_id = payload.get('client_id')
    if client_id is not None and not isinstance(client_id, str):
        msg = f'Invalid client_id claim: {client_id!r}'
        raise TypeError(msg)

    exp = payload.get('exp')
    if exp is not None and not isinstance(exp, (int, float)):
        msg = f'Invalid exp claim: {exp!r}'
        raise TypeError(msg)

    return ParsedPayload(iss=iss, client_id=client_id, exp=exp)
