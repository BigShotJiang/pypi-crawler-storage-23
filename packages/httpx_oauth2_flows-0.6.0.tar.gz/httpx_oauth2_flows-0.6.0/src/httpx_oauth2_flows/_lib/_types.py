import typing as t

import httpx
import pydantic
import pydantic_core


class Url(httpx.URL):
    _PYDANTIC_ADAPTER = pydantic.TypeAdapter[pydantic.HttpUrl](pydantic.HttpUrl)

    def __init__(self, url: str | httpx.URL, **kwargs: object) -> None:
        super().__init__(url, **kwargs)

    def __truediv__(self, other: str) -> t.Self:
        self_ends_with_slash = self.path.endswith('/')
        other_starts_with_slash = other.startswith('/')
        if self_ends_with_slash and other_starts_with_slash:
            other = other.removeprefix('/')
        if not (self_ends_with_slash or other_starts_with_slash):
            other = '/' + other

        return self.__class__(httpx.URL(self, path=self.path + other))

    def with_params(
        self,
        params: httpx.QueryParams
        | t.Mapping[
            str, str | int | float | bool | None | t.Sequence[str | int | float | bool | None]
        ],
    ) -> t.Self:
        return self.__class__(httpx.URL(self, params=self.params.merge(params)))

    @classmethod
    def __get_pydantic_core_schema__(
        cls, _source_type: object, _handler: pydantic.GetCoreSchemaHandler
    ) -> pydantic_core.core_schema.PlainValidatorFunctionSchema:
        return pydantic_core.core_schema.no_info_plain_validator_function(
            cls.validate,
            serialization=pydantic_core.core_schema.plain_serializer_function_ser_schema(str),
        )

    @classmethod
    def __get_pydantic_json_schema__(
        cls,
        _core_schema: pydantic_core.core_schema.CoreSchema,
        _handler: pydantic.GetJsonSchemaHandler,
    ) -> dict[str, str]:
        return {'type': 'string', 'format': 'URL'}

    @classmethod
    def validate(cls, value: object) -> t.Self:
        if isinstance(value, cls):
            return value
        return cls(str(cls._PYDANTIC_ADAPTER.validate_python(value)))


class Error:
    def __init__(self, message: str) -> None:
        self.message = message


class Scope:
    __slots__ = ('_values',)

    def __init__(self, *values: t.Iterable[str] | str) -> None:
        self._values = frozenset(
            value
            for value_it_or_str in values
            for value in (
                [value_it_or_str] if isinstance(value_it_or_str, str) else value_it_or_str
            )
        )

    @property
    def formated(self) -> str:
        return ' '.join(sorted(self._values))

    _PYDANTIC_ADAPTER = pydantic.TypeAdapter(list[str])

    @classmethod
    def __get_pydantic_core_schema__(
        cls, _source_type: object, _handler: pydantic.GetCoreSchemaHandler
    ) -> pydantic_core.core_schema.PlainValidatorFunctionSchema:
        return pydantic_core.core_schema.no_info_plain_validator_function(
            cls.validate,
            serialization=pydantic_core.core_schema.plain_serializer_function_ser_schema(
                cls.serialize
            ),
        )

    @classmethod
    def __get_pydantic_json_schema__(
        cls,
        _core_schema: pydantic_core.core_schema.CoreSchema,
        _handler: pydantic.GetJsonSchemaHandler,
    ) -> dict[str, str]:
        return cls._PYDANTIC_ADAPTER.json_schema()

    def serialize(self) -> list[str]:
        return sorted(self._values)

    @classmethod
    def validate(cls, value: object) -> t.Self:
        if isinstance(value, cls):
            return value
        return cls(cls._PYDANTIC_ADAPTER.validate_python(value))


type RequestData = t.MutableMapping[str, str]
