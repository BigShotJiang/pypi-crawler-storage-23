import httpx
import pydantic

from httpx_oauth2_flows._lib import RequestData, Scope, Url, jwt, openid

from .grant_type import GrantType
from .token_response import SuccessfulTokenResponse, handle_token_response

# Public Types


GRANT_TYPE = GrantType.JWT_BEARER


class Config(jwt.SignerConfig, frozen=True):
    auth_server: Url
    client_id: str
    user_id: str | None = None
    scope: Scope | None = None

    def get_user_id(self) -> str:
        if self.user_id is not None:
            return self.user_id

        return self.client_id


# Private Impl


class _OpenID(pydantic.BaseModel):
    auth_server: Url
    issuer: str
    token_endpoint: Url


async def _fetch_openid(config: Config, http_client: httpx.AsyncClient) -> _OpenID:
    openid_configuration = await openid.fetch_configuration(
        config.auth_server, http_client, check_support_grant_type=GRANT_TYPE.value
    )

    if openid_configuration.token_endpoint is None:
        msg = f'{config.auth_server} does not provide a token endpoint'
        raise RuntimeError(msg)

    return _OpenID(
        auth_server=config.auth_server,
        issuer=openid_configuration.issuer,
        token_endpoint=openid_configuration.token_endpoint,
    )


# Public Api


async def execute(config: Config, http_client: httpx.AsyncClient) -> SuccessfulTokenResponse:
    openid = await _fetch_openid(config, http_client)
    signer = jwt.Signer.from_config(config)
    data: RequestData = {
        'grant_type': GRANT_TYPE.value,
        'assertion': signer.sign(
            issuer=config.client_id, subject=config.get_user_id(), audience=openid.issuer
        ),
    }
    if config.scope:
        data['scope'] = config.scope.formated
    response = await http_client.post(url=openid.token_endpoint, data=data)
    return handle_token_response(response)
