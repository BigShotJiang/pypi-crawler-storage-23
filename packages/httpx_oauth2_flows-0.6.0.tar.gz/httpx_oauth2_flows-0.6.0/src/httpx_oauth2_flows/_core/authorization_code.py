import dataclasses
import datetime
import enum
import hashlib
import http
import secrets
import string
import traceback
import typing as t
import webbrowser

import httpx
import pydantic

from httpx_oauth2_flows._lib import Error, RequestData, Scope, Url, openid, util, webserver
from httpx_oauth2_flows._resources import RESOURCES_DIR

from .exceptions import (
    AuthorizeCallbackParamsError,
    AuthorizeCallbackStateError,
    AuthorizeCallbackWebServerError,
    BaseError,
)
from .grant_type import GrantType
from .token_response import SuccessfulTokenResponse, handle_token_response

# Public types

GRANT_TYPE = GrantType.AUTHORIZATION_CODE


class CallbackResponseTexts(pydantic.BaseModel, frozen=True):
    title: str
    body: str
    body_male: str | None
    body_female: str | None
    button_text: str
    footer_text: str


type CallbackResponseLocalizedTexts = t.Mapping[str, CallbackResponseTexts]


class Config(pydantic.BaseModel, frozen=True):
    auth_server: Url
    client_id: str
    scope: Scope | None = None
    callback_path: str | None = None
    callback_max_wait: datetime.timedelta | None = None
    callback_response_html: str | None = None
    callback_response_localized_texts: CallbackResponseLocalizedTexts | None = None
    callback_response_default_texts: CallbackResponseTexts | None = None
    callback_response_default_locale: str | None = None

    def get_callback_path(self) -> str:
        if self.callback_path is not None:
            return self.callback_path
        return '/authorize-callback'

    def get_callback_max_wait(self) -> datetime.timedelta:
        if self.callback_max_wait is not None:
            return self.callback_max_wait
        return datetime.timedelta(minutes=5)

    def get_callback_response_html(self) -> str:
        if self.callback_response_html is not None:
            return self.callback_response_html
        return (RESOURCES_DIR / 'callback-response.html').read_text()

    def get_callback_response_localized_texts(self) -> CallbackResponseLocalizedTexts:
        if self.callback_response_localized_texts is not None:
            return self.callback_response_localized_texts

        return pydantic.TypeAdapter[CallbackResponseLocalizedTexts](
            CallbackResponseLocalizedTexts
        ).validate_json((RESOURCES_DIR / 'callback-response-texts.json').read_text())

    def get_callback_response_default_texts(self) -> CallbackResponseTexts:
        if self.callback_response_default_texts is not None:
            return self.callback_response_default_texts

        return CallbackResponseTexts(
            title='Authentication Complete',
            body='Welcome, $username.'
            ' The process is finished and you can now return to the program.',
            body_male=None,
            body_female=None,
            button_text='Close Tab',
            footer_text='This window can be safely closed.',
        )

    def get_callback_response_default_locale(self) -> str:
        if self.callback_response_default_locale is not None:
            return self.callback_response_default_locale

        return 'en'


# Private impl


class _CodeChallengeMethod(enum.Enum):
    S256 = 'S256'


class _OpenID(pydantic.BaseModel):
    authorization_endpoint: Url
    token_endpoint: Url
    code_challenge_method: _CodeChallengeMethod


async def _fetch_openid(config: Config, http_client: httpx.AsyncClient) -> _OpenID:
    openid_configuration = await openid.fetch_configuration(
        config.auth_server, http_client, check_support_grant_type=GRANT_TYPE.value
    )

    if (
        openid_configuration.code_challenge_methods_supported is None
        or _CodeChallengeMethod.S256.value in openid_configuration.code_challenge_methods_supported
    ):
        code_challenge_method = _CodeChallengeMethod.S256
    else:
        msg = f'{config.auth_server} does not support the S256 code challenge method'
        raise RuntimeError(msg)

    if openid_configuration.authorization_endpoint is None:
        msg = f'{config.auth_server} does not provide an authorization endpoint'
        raise RuntimeError(msg)

    if openid_configuration.token_endpoint is None:
        msg = f'{config.auth_server} does not provide a token endpoint'
        raise RuntimeError(msg)

    return _OpenID(
        authorization_endpoint=openid_configuration.authorization_endpoint,
        token_endpoint=openid_configuration.token_endpoint,
        code_challenge_method=code_challenge_method,
    )


@dataclasses.dataclass(frozen=True, slots=True)
class _Pkce:
    verifier: str
    challenge: str


def _generate_pkce(code_challenge_method: _CodeChallengeMethod) -> _Pkce:
    verifier = util.base64url_encode(secrets.token_bytes(32))
    match code_challenge_method:
        case _CodeChallengeMethod.S256:
            digest = hashlib.sha256(verifier.encode()).digest()

    return _Pkce(verifier=verifier, challenge=util.base64url_encode(digest))


@dataclasses.dataclass(frozen=True, slots=True)
class _State:
    token: str


def _generate_state() -> _State:
    return _State(token=secrets.token_hex(16))


def _validate_single_query_param(param: str, request: webserver.Request) -> str | Error:
    it = iter(request.query.get(param, []))
    first_value = next(it, None)
    if first_value is None:
        return Error('missing')

    second_value = next(it, None)
    if second_value is not None:
        return Error(f'multiple values: {[second_value, *it]}')

    return first_value


class _AuthorizeResponse(pydantic.BaseModel):
    code: str
    state: str


def _validate_callback_request(request: webserver.Request) -> _AuthorizeResponse:
    code = _validate_single_query_param('code', request)
    state = _validate_single_query_param('state', request)

    if isinstance(code, str) and isinstance(state, str):
        return _AuthorizeResponse(code=code, state=state)

    errors: t.Mapping[str, str] = {}
    if isinstance(code, Error):
        errors['code'] = code.message
    if isinstance(state, Error):
        errors['state'] = state.message
    raise AuthorizeCallbackParamsError(request, errors=errors)


@dataclasses.dataclass(frozen=True, slots=True)
class _Context:
    config: Config
    http_client: httpx.AsyncClient
    openid: _OpenID
    pkce: _Pkce
    state: _State
    server_url: Url

    @property
    def redirect_uri(self) -> Url:
        return self.server_url / self.config.get_callback_path()

    def create_authorize_request_url(self) -> Url:
        data: RequestData = {
            'response_type': 'code',
            'client_id': self.config.client_id,
            'redirect_uri': str(self.redirect_uri),
            'state': self.state.token,
            'code_challenge': self.pkce.challenge,
            'code_challenge_method': self.openid.code_challenge_method.value,
        }
        if self.config.scope:
            data['scope'] = self.config.scope.formated

        return self.openid.authorization_endpoint.with_params(data)

    async def fetch_token(self, authorize_response: _AuthorizeResponse) -> SuccessfulTokenResponse:
        data: RequestData = {
            'grant_type': GRANT_TYPE.value,
            'client_id': self.config.client_id,
            'redirect_uri': str(self.redirect_uri),
            'code': authorize_response.code,
            'code_verifier': self.pkce.verifier,
        }
        response = await self.http_client.post(self.openid.token_endpoint, data=data)
        return handle_token_response(response)


async def _on_server_ready(
    server_url: Url, config: Config, http_client: httpx.AsyncClient
) -> _Context:
    openid = await _fetch_openid(config, http_client)
    ctx = _Context(
        config=config,
        http_client=http_client,
        openid=openid,
        pkce=_generate_pkce(openid.code_challenge_method),
        state=_generate_state(),
        server_url=server_url,
    )

    authorize_request_url = ctx.create_authorize_request_url()

    success = webbrowser.open(str(authorize_request_url), new=1)
    if not success:
        msg = 'There was an unknown error while opening the authorize request url in a web browser'
        raise RuntimeError(msg)

    return ctx


def _error_result(error: BaseError) -> webserver.Result[BaseError]:
    return (
        error,
        webserver.Response(
            content='\n'.join(traceback.format_exception_only(error)),
            status=http.HTTPStatus.BAD_REQUEST,
        ),
    )


def _get_username(user_info: openid.UserInfo) -> str:
    return (
        user_info.preferred_username
        or user_info.name
        or user_info.given_name
        or user_info.nickname
        or user_info.email
        or f'user {user_info.sub}'
    )


def _success_response(user_info: openid.UserInfo, config: Config) -> webserver.Response:
    username = _get_username(user_info)

    locale = user_info.locale or config.get_callback_response_default_locale()

    lang = locale.split('-')[0].split('_')[0].lower()

    texts = config.get_callback_response_localized_texts().get(
        lang, config.get_callback_response_default_texts()
    )

    body = texts.body
    if user_info.gender == 'male' and texts.body_male is not None:
        body = texts.body_male
    if user_info.gender == 'female' and texts.body_female is not None:
        body = texts.body_female

    html_content = string.Template(config.get_callback_response_html()).safe_substitute(
        title=texts.title,
        body=string.Template(body).safe_substitute(username=username),
        button_text=texts.button_text,
        footer_text=texts.footer_text,
        lang=lang,
    )
    return webserver.Response(content_type='text/html', content=html_content)


async def _on_callback(
    request: webserver.Request, ctx: _Context
) -> webserver.Result[SuccessfulTokenResponse | BaseError]:
    try:
        authorize_response = _validate_callback_request(request)

        if authorize_response.state != ctx.state.token:
            raise AuthorizeCallbackStateError(request)

        token = await ctx.fetch_token(authorize_response)
        user_info = await openid.fetch_user_info(token, ctx.config.auth_server, ctx.http_client)
        return (token, _success_response(user_info, ctx.config))

    except BaseError as err:
        return _error_result(err)


# Public Api


async def execute(config: Config, http_client: httpx.AsyncClient) -> SuccessfulTokenResponse:
    match await webserver.wait_for_request(
        webserver.Config(
            method=http.HTTPMethod.GET,
            path=config.get_callback_path(),
            max_wait=config.get_callback_max_wait(),
            bind_host='127.0.0.1',
            on_ready=lambda url: _on_server_ready(url, config, http_client),
            handler=_on_callback,
        )
    ):
        case Error() as error:
            raise AuthorizeCallbackWebServerError(error.message)
        case BaseError() as error:
            raise error
        case SuccessfulTokenResponse() as token:
            return token
