import base64
import contextlib
import dataclasses
import enum
import pathlib
import typing as t

import httpx
import pydantic

from httpx_oauth2_flows._lib import RequestData, Scope, Url, jwt, openid

from .exceptions import SupportedAuthMethodError
from .grant_type import GrantType
from .token_response import SuccessfulTokenResponse, handle_token_response

# Base Types


class _BaseClientSecretAuth(pydantic.BaseModel, frozen=True):
    client_secret: str


# Public Types

GRANT_TYPE = GrantType.CLIENT_CREDENTIALS


class ClientSecretBasicAuth(_BaseClientSecretAuth, frozen=True):
    kind: t.Literal['client_secret_basic'] = 'client_secret_basic'
    header_name: str | None = None


class ClientSecretPostAuth(_BaseClientSecretAuth, frozen=True):
    kind: t.Literal['client_secret_post'] = 'client_secret_post'


class ClientSecretAutoAuth(_BaseClientSecretAuth, frozen=True):
    kind: t.Literal['client_secret_auto'] = 'client_secret_auto'


class PrivateKeyJwtAuth(jwt.SignerConfig, frozen=True):
    kind: t.Literal['private_key_jwt'] = 'private_key_jwt'


class TlsClientAuth(pydantic.BaseModel, frozen=True):
    kind: t.Literal['tls_client_auth'] = 'tls_client_auth'
    certfile: pathlib.Path
    keyfile: pathlib.Path | None = None
    password: str | None = None


type Auth = (
    ClientSecretBasicAuth
    | ClientSecretPostAuth
    | ClientSecretAutoAuth
    | PrivateKeyJwtAuth
    | TlsClientAuth
)


class Config(pydantic.BaseModel, frozen=True):
    auth_server: Url
    client_id: str
    auth: Auth
    scope: Scope | None = None


# Private Impl


class _AuthMethod(enum.Enum):
    CLIENT_SECRET_BASIC = 'client_secret_basic'
    CLIENT_SECRET_POST = 'client_secret_post'
    PRIVATE_KEY_JWT = 'private_key_jwt'
    TLS_CLIENT_AUTH = 'tls_client_auth'


class _OpenID(pydantic.BaseModel):
    auth_server: Url
    token_endpoint: Url
    supported_auth_methods: t.Set[str]


async def _fetch_openid(config: Config, http_client: httpx.AsyncClient) -> _OpenID:
    openid_configuration = await openid.fetch_configuration(
        config.auth_server, http_client, check_support_grant_type=GRANT_TYPE.value
    )

    if openid_configuration.token_endpoint is None:
        msg = f'{config.auth_server} does not provide a token endpoint'
        raise RuntimeError(msg)

    if openid_configuration.token_endpoint_auth_methods_supported is not None:
        supported_auth_methods = openid_configuration.token_endpoint_auth_methods_supported
    else:
        supported_auth_methods = {am.value for am in _AuthMethod}

    return _OpenID(
        auth_server=config.auth_server,
        token_endpoint=openid_configuration.token_endpoint,
        supported_auth_methods=supported_auth_methods,
    )


type _ResolvedAuth = (
    ClientSecretBasicAuth | ClientSecretPostAuth | PrivateKeyJwtAuth | TlsClientAuth
)


def _to_client_secret_basic(auth: ClientSecretAutoAuth) -> ClientSecretBasicAuth:
    return ClientSecretBasicAuth(client_secret=auth.client_secret)


def _to_client_secret_post(auth: ClientSecretAutoAuth) -> ClientSecretPostAuth:
    return ClientSecretPostAuth(client_secret=auth.client_secret)


def _resolve_client_secret_auth(auth: ClientSecretAutoAuth, openid: _OpenID) -> _ResolvedAuth:
    auth_methods = [_AuthMethod.CLIENT_SECRET_BASIC, _AuthMethod.CLIENT_SECRET_POST]
    converters = [_to_client_secret_basic, _to_client_secret_post]
    for auth_method, converter in zip(auth_methods, converters, strict=True):
        if auth_method.value in openid.supported_auth_methods:
            return converter(auth)

    raise SupportedAuthMethodError(
        auth_server=openid.auth_server,
        needed=[am.value for am in auth_methods],
        supported=openid.supported_auth_methods,
    )


def _check_auth_method_support(auth: _ResolvedAuth, openid: _OpenID) -> None:
    match auth:
        case ClientSecretBasicAuth():
            method = _AuthMethod.CLIENT_SECRET_BASIC
        case ClientSecretPostAuth():
            method = _AuthMethod.CLIENT_SECRET_POST
        case PrivateKeyJwtAuth():
            method = _AuthMethod.PRIVATE_KEY_JWT
        case TlsClientAuth():
            method = _AuthMethod.TLS_CLIENT_AUTH

    if method.value not in openid.supported_auth_methods:
        raise SupportedAuthMethodError(
            auth_server=openid.auth_server,
            needed=[method.value],
            supported=openid.supported_auth_methods,
        )


def _resolve_auth(auth: Auth, openid: _OpenID) -> _ResolvedAuth:
    match auth:
        case ClientSecretAutoAuth():
            return _resolve_client_secret_auth(auth, openid)
        case _:
            _check_auth_method_support(auth, openid)
            return auth


@dataclasses.dataclass
class _TokenRequest:
    config: Config
    data: RequestData
    http_client: httpx.AsyncClient
    openid: _OpenID

    @contextlib.asynccontextmanager
    async def handle_client_secret_basic(
        self, auth: ClientSecretBasicAuth
    ) -> t.AsyncIterator[httpx.AsyncClient]:
        secret_string = f'{self.config.client_id}:{auth.client_secret}'
        encoded_secret = base64.b64encode(secret_string.encode()).decode()
        header_name = auth.header_name or 'Authorization'
        previous_header_value = self.http_client.headers.get(header_name)
        self.http_client.headers[header_name] = f'Basic {encoded_secret}'
        try:
            yield self.http_client
        finally:
            self.http_client.headers[header_name] = previous_header_value

    @contextlib.asynccontextmanager
    async def handle_client_secret_post(
        self, auth: ClientSecretPostAuth
    ) -> t.AsyncIterator[httpx.AsyncClient]:
        self.data['client_id'] = self.config.client_id
        self.data['client_secret'] = auth.client_secret
        yield self.http_client

    @contextlib.asynccontextmanager
    async def handle_private_key_jwt(
        self, auth: PrivateKeyJwtAuth
    ) -> t.AsyncIterator[httpx.AsyncClient]:
        signer = jwt.Signer.from_config(auth)
        assertion = signer.sign(
            issuer=self.config.client_id,
            subject=self.config.client_id,
            audience=self.openid.token_endpoint,
        )
        self.data['client_assertion'] = assertion
        self.data['client_assertion_type'] = (
            'urn:ietf:params:oauth:client-assertion-type:jwt-bearer'
        )
        yield self.http_client

    @contextlib.asynccontextmanager
    async def handle_tls_client_auth(
        self, auth: TlsClientAuth
    ) -> t.AsyncIterator[httpx.AsyncClient]:
        if auth.keyfile is None:
            cert = str(auth.certfile)
        elif auth.password is None:
            cert = (str(auth.certfile), str(auth.keyfile))
        else:
            cert = (str(auth.certfile), str(auth.keyfile), auth.password)

        async with httpx.AsyncClient(cert=cert) as http_client:
            yield http_client

    @contextlib.asynccontextmanager
    async def handle_auth(self, auth: _ResolvedAuth) -> t.AsyncIterator[httpx.AsyncClient]:
        match auth:
            case ClientSecretBasicAuth():
                handler = self.handle_client_secret_basic(auth)
            case ClientSecretPostAuth():
                handler = self.handle_client_secret_post(auth)
            case PrivateKeyJwtAuth():
                handler = self.handle_private_key_jwt(auth)
            case TlsClientAuth():
                handler = self.handle_tls_client_auth(auth)

        async with handler as http_client:
            yield http_client


def _get_token_request_data(config: Config) -> RequestData:
    data: RequestData = {'grant_type': GRANT_TYPE.value, 'client_id': config.client_id}
    if config.scope is not None:
        data['scope'] = config.scope.formated
    return data


# Public Api


async def execute(config: Config, http_client: httpx.AsyncClient) -> SuccessfulTokenResponse:
    openid = await _fetch_openid(config, http_client)
    auth = _resolve_auth(config.auth, openid)

    request = _TokenRequest(
        config=config, http_client=http_client, openid=openid, data=_get_token_request_data(config)
    )

    async with request.handle_auth(auth) as request_http_client:
        response = await request_http_client.post(openid.token_endpoint, data=request.data)

    return handle_token_response(response)
