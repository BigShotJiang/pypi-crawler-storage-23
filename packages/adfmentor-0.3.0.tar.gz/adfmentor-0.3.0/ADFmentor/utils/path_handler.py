from pathlib import Path
from ADFmentor.utils import extract_zip_to_temp

def prepare_answer_path(answer_path: str) -> str:
    path = Path(answer_path).resolve()

    if not path.exists():
        raise FileNotFoundError(
            f"Submission path not found: {answer_path}\n"
            f"Resolved to: {path}\n"
            f"Current working directory: {Path.cwd()}\n"
            f"Please check that the path is correct."
        )

    if path.is_dir():
        return str(path)

    if path.is_file() and path.suffix.lower() == ".zip":
        return extract_zip_to_temp(str(path))

    if path.is_file() and path.suffix.lower() == ".json":
        return str(path)

    raise ValueError(
        f"Invalid submission path: {answer_path}\n"
        f"Path must be a directory, ZIP file, or a single JSON file.\n"
        f"Found: {path.suffix} file"
    )
