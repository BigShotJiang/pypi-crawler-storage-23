import re
from typing import Dict, Optional

def parse_lesson_questions(text: str) -> Dict[str, Optional[str]]:
    """Parse lesson text into separate question blocks.

    Extracts questions based on specific markers:
    - "PIPELINE002": ADF Pipeline evaluation questions
    - "TEXT001": Written explanation questions

    Args:
        text: The full lesson text containing questions

    Returns:
        Dictionary with keys 'pipeline', 'text' containing
        the parsed question strings or None if not found.
    """
    blocks = {
        "pipeline": None,
        "text": None,
    }

    if not isinstance(text, str):
        return blocks

    patterns = {
        "pipeline": r'"PIPELINE002"[\s\n]+(.*?)(?="TEXT001"|$)',
        "text": r'"TEXT001"[\s\n]+(.*?)(?="PIPELINE002"|$)',
    }

    try:
        for key, pattern in patterns.items():
            match = re.search(pattern, text, re.IGNORECASE | re.DOTALL)
            if match:
                qs = match.group(1).strip()
                if qs:
                    blocks[key] = qs
    except Exception as e:
        print(f"Warning: Failed to parse lesson questions: {e}")

    return blocks