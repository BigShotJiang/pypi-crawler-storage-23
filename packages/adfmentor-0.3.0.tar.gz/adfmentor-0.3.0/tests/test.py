from pprint import pprint
from ADFmentor import ADFMentor
import os
questions = """
    ## Lesson 3
    **Topic:** ADF Pipeline Development — Sales Data Pipeline
    **Prerequisites:** Azure subscription, Storage Account, SQL Database

    "PIPELINE002"
    3. Azure Blob Storage dagi CSV fayllarni Azure SQL Database ga ko'chiruvchi pipeline yarating.
    4. Pipeline da GetMetadata va Filter activity ishlatib, faqat .csv fayllarni tanlang.
    5. ForEach activity bilan har bir faylni alohida ko'chiring.
    6. Pipeline parametrlari orqali source folder va target table ni dinamik qiling.
    7. Muvaffaqiyatli bajarilgandan keyin bildirishnoma yuboruvchi activity qo'shing.
"""

prompts = {
        "pipeline": """You are evaluating an Azure Data Factory pipeline submission. Assess the following:

    CORRECTNESS (70 points):
    - Does the pipeline correctly copy CSV files from Blob Storage to SQL Database?
    - Are GetMetadata, Filter, ForEach, and Copy activities configured properly?
    - Is the activity dependency chain correct?
    - Does it handle multiple files?

    BEST PRACTICES (10 points):
    - Proper use of parameterization
    - Efficient pipeline design
    - Clear naming conventions
    - Appropriate use of linked services and datasets

    PERFORMANCE (10 points):
    - Is ForEach set to parallel (isSequential: false)?
    - Efficient data movement patterns

    REQUIREMENTS ALIGNMENT (10 points):
    - Does it include all required activities (GetMetadata, Filter, ForEach, Copy, notification)?
    - Are parameters defined for sourceFolder and targetTable?

    Provide a score out of 100 and concise feedback (50-75 words).""",


        "text": """You are evaluating a written response about Azure Data Factory concepts. Assess:

    ACCURACY (70 points):
    - Is the information technically correct?
    - Are concepts explained accurately?

    COMPLETENESS (15 points):
    - Does the answer fully address the question?
    - Are key points covered?

    CLARITY (15 points):
    - Is the explanation clear and well-organized?

    Provide a score out of 100 and concise feedback (50-75 words).""",
}

import os
current_dir = os.path.dirname(os.path.abspath(__file__))

mentor = ADFMentor(api_key="AIzaSyA_rAFfWAakSmkH65Aa2H1tFCXSScSfvsk", model_name="gemini-2.5-flash-lite")

results = mentor.evaluate_all(
    answer_path=os.path.join(current_dir, "files", "lesson-3.zip"),
    questions=questions,
    prompts=prompts
)

print(results['feedback'])
print(results['score'])