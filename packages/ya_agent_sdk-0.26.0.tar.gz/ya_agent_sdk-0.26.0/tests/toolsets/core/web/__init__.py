"""Tests for ya_agent_sdk.toolsets.core.web module."""
