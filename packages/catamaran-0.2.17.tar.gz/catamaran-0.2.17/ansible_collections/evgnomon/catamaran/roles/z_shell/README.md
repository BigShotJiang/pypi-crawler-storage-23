# z\_shell Role

Runs user commands in a shell which has proper environment variables set for Zygote applications.

## Requirements

- Ansible 2.9 or higher
- Supported platforms:
  - EL 7
  - EL 8

## Role Variables


## Example Playbook

```yaml
- hosts: all
  roles:
    - role: z_shell
```
