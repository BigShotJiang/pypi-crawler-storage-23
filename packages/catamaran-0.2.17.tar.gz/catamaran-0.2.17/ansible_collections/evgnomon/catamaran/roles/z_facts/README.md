# z\_facts Role

This role loads essential facts for the system.

## Requirements

- Ansible 2.9 or higher
- Supported platforms:
  - EL 7
  - EL 8

## Role Variables


## Example Playbook

```yaml
- hosts: all
  roles:
    - role: z_facts
```
