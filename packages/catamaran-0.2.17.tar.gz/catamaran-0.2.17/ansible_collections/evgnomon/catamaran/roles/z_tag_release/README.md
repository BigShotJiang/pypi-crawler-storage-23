# z\_tag\_release Role

Make a github release out of dist dir.
This role is triggered by a tag event.

## Example Playbook

```yaml
- hosts: localhost
  roles:
    - role: z_tag_release
```
