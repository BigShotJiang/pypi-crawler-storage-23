"""Async low-level client for the Codex app-server JSON-RPC protocol."""

from __future__ import annotations

import asyncio
import logging
import shutil
from collections.abc import Awaitable, Callable
from itertools import count
from typing import Any, TypeVar

from codex_app_server_client.protocol.jsonrpc import (
    JSONRPCError,
    JSONRPCNotification,
    JSONRPCRequest,
    JSONRPCResponse,
    parse_jsonrpc_message,
)
from codex_app_server_client.protocol.transport import AsyncStdioTransport
from codex_app_server_client.types.auth import (
    GetAccountParams,
    GetAccountRateLimitsResponse,
    GetAccountResponse,
    LoginAccountParams,
)
from codex_app_server_client.types.common import (
    ClientInfo,
    InitializeCapabilities,
    InitializeResponse,
)
from codex_app_server_client.types.events import ThreadEvent, parse_notification_event
from codex_app_server_client.types.misc import (
    AppsListParams,
    AppsListResponse,
    CommandExecParams,
    CommandExecResponse,
    ConfigBatchWriteParams,
    ConfigReadParams,
    ConfigReadResponse,
    ConfigRequirementsReadResponse,
    ConfigValueWriteParams,
    ConfigWriteResponse,
    ExperimentalFeatureListParams,
    ExperimentalFeatureListResponse,
    FeedbackUploadParams,
    FeedbackUploadResponse,
    ListMcpServerStatusParams,
    ListMcpServerStatusResponse,
    McpServerOauthLoginParams,
    McpServerOauthLoginResponse,
    McpServerRefreshResponse,
    ModelListParams,
    ModelListResponse,
    SkillsConfigWriteParams,
    SkillsConfigWriteResponse,
    SkillsListParams,
    SkillsListResponse,
    SkillsRemoteReadParams,
    SkillsRemoteReadResponse,
    SkillsRemoteWriteParams,
    SkillsRemoteWriteResponse,
    WindowsSandboxSetupStartParams,
    WindowsSandboxSetupStartResponse,
)
from codex_app_server_client.types.threads import (
    ReviewStartParams,
    ReviewStartResponse,
    ThreadCompactStartParams,
    ThreadForkParams,
    ThreadForkResponse,
    ThreadListParams,
    ThreadListResponse,
    ThreadLoadedListResponse,
    ThreadReadParams,
    ThreadReadResponse,
    ThreadResumeParams,
    ThreadResumeResponse,
    ThreadRollbackParams,
    ThreadRollbackResponse,
    ThreadStartParams,
    ThreadStartResponse,
    ThreadUnarchiveParams,
    ThreadUnarchiveResponse,
    TurnInterruptParams,
    TurnStartParams,
    TurnStartResponse,
    TurnSteerParams,
    TurnSteerResponse,
)

logger = logging.getLogger(__name__)

T = TypeVar("T")

NotificationCallback = Callable[[str, ThreadEvent], Awaitable[None] | None]
ServerRequestCallback = Callable[[str, dict[str, Any]], Awaitable[dict[str, Any]]]

_DEFAULT_CODEX_BIN = "codex"


def _find_codex_bin() -> str:
    """Try to find the codex binary on PATH."""
    found = shutil.which("codex")
    return found if found else _DEFAULT_CODEX_BIN


class AsyncCodexClient:
    """Low-level async client for the Codex app-server JSON-RPC protocol.

    Manages subprocess lifecycle, request/response correlation, notification
    dispatch, and server-initiated request handling (approvals).
    """

    def __init__(
        self,
        codex_bin: str | None = None,
        client_name: str = "codex_python_sdk",
        client_title: str = "Codex Python SDK",
        client_version: str = "0.1.0",
        experimental_api: bool = True,
        opt_out_notification_methods: list[str] | None = None,
        extra_args: list[str] | None = None,
        env: dict[str, str] | None = None,
    ) -> None:
        self._transport = AsyncStdioTransport(
            codex_bin=codex_bin or _find_codex_bin(),
            extra_args=extra_args,
            env=env,
        )
        self._client_info = ClientInfo(
            name=client_name,
            title=client_title,
            version=client_version,
        )
        self._experimental_api = experimental_api
        self._opt_out_notification_methods = opt_out_notification_methods

        self._pending: dict[int, asyncio.Future[Any]] = {}
        self._id_counter = count(1)
        self._reader_task: asyncio.Task[None] | None = None
        self._started = False

        # Notification handlers: method → callback
        self._notification_handlers: dict[str, list[NotificationCallback]] = {}
        self._global_notification_handlers: list[NotificationCallback] = []

        # Server request handlers (approvals, tool calls)
        self._server_request_handlers: dict[str, ServerRequestCallback] = {}

    @property
    def is_started(self) -> bool:
        return self._started

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> InitializeResponse:
        """Start the subprocess and perform the initialization handshake."""
        if self._started:
            raise RuntimeError("Client is already started")

        await self._transport.start()
        self._reader_task = asyncio.create_task(self._read_loop())

        # Initialize handshake
        caps = InitializeCapabilities(
            experimental_api=self._experimental_api,
            opt_out_notification_methods=self._opt_out_notification_methods,
        )
        result = await self.request(
            "initialize",
            {
                "clientInfo": self._client_info.model_dump(by_alias=True),
                "capabilities": caps.model_dump(by_alias=True, exclude_none=True),
            },
            timeout_s=30,
        )
        await self.notify("initialized", {})
        self._started = True
        return InitializeResponse.model_validate(result)

    async def close(self) -> None:
        """Shutdown the client and terminate the subprocess."""
        if self._reader_task:
            self._reader_task.cancel()
            self._reader_task = None

        for fut in self._pending.values():
            if not fut.done():
                fut.cancel()
        self._pending.clear()

        await self._transport.close()
        self._started = False

    async def restart(self) -> InitializeResponse:
        """Restart the subprocess and re-initialize."""
        await self.close()
        return await self.start()

    # ------------------------------------------------------------------
    # Raw JSON-RPC
    # ------------------------------------------------------------------

    async def request(
        self,
        method: str,
        params: dict[str, Any] | None = None,
        timeout_s: float = 60,
    ) -> Any:
        """Send a JSON-RPC request and wait for the response."""
        req_id = next(self._id_counter)
        payload: dict[str, Any] = {"id": req_id, "method": method}
        if params is not None:
            payload["params"] = params

        loop = asyncio.get_running_loop()
        fut: asyncio.Future[Any] = loop.create_future()
        self._pending[req_id] = fut

        await self._transport.write(payload)

        try:
            return await asyncio.wait_for(fut, timeout=timeout_s)
        finally:
            self._pending.pop(req_id, None)

    async def notify(self, method: str, params: dict[str, Any] | None = None) -> None:
        """Send a JSON-RPC notification (fire-and-forget)."""
        payload: dict[str, Any] = {"method": method}
        if params is not None:
            payload["params"] = params
        await self._transport.write(payload)

    # ------------------------------------------------------------------
    # Notification / server-request handler registration
    # ------------------------------------------------------------------

    def on_notification(
        self,
        method: str | None,
        callback: NotificationCallback,
    ) -> None:
        """Register a notification handler.

        If *method* is ``None``, the callback receives all notifications.
        """
        if method is None:
            self._global_notification_handlers.append(callback)
        else:
            self._notification_handlers.setdefault(method, []).append(callback)

    def on_server_request(self, method: str, callback: ServerRequestCallback) -> None:
        """Register a handler for server-initiated requests (approvals, tool calls)."""
        self._server_request_handlers[method] = callback

    # ------------------------------------------------------------------
    # Thread lifecycle
    # ------------------------------------------------------------------

    async def thread_start(self, params: ThreadStartParams | None = None) -> ThreadStartResponse:
        """``thread/start`` — create a new thread."""
        p = (params or ThreadStartParams()).model_dump(by_alias=True, exclude_none=True)
        result = await self.request("thread/start", p, timeout_s=30)
        return ThreadStartResponse.model_validate(result)

    async def thread_resume(self, params: ThreadResumeParams) -> ThreadResumeResponse:
        """``thread/resume`` — reopen an existing thread."""
        result = await self.request(
            "thread/resume",
            params.model_dump(by_alias=True, exclude_none=True),
            timeout_s=30,
        )
        return ThreadResumeResponse.model_validate(result)

    async def thread_fork(self, params: ThreadForkParams) -> ThreadForkResponse:
        """``thread/fork`` — fork an existing thread."""
        result = await self.request(
            "thread/fork",
            params.model_dump(by_alias=True, exclude_none=True),
            timeout_s=30,
        )
        return ThreadForkResponse.model_validate(result)

    async def thread_list(self, params: ThreadListParams | None = None) -> ThreadListResponse:
        """``thread/list`` — list stored threads."""
        p = (params or ThreadListParams()).model_dump(by_alias=True, exclude_none=True)
        result = await self.request("thread/list", p, timeout_s=30)
        return ThreadListResponse.model_validate(result)

    async def thread_loaded_list(self) -> ThreadLoadedListResponse:
        """``thread/loaded/list`` — list currently loaded thread ids."""
        result = await self.request("thread/loaded/list", {}, timeout_s=30)
        return ThreadLoadedListResponse.model_validate(result)

    async def thread_read(self, params: ThreadReadParams) -> ThreadReadResponse:
        """``thread/read`` — read a thread without resuming it."""
        result = await self.request(
            "thread/read",
            params.model_dump(by_alias=True, exclude_none=True),
            timeout_s=30,
        )
        return ThreadReadResponse.model_validate(result)

    async def thread_archive(self, thread_id: str) -> dict[str, Any]:
        """``thread/archive`` — archive a thread."""
        return await self.request("thread/archive", {"threadId": thread_id}, timeout_s=30)  # type: ignore[no-any-return]

    async def thread_unarchive(self, params: ThreadUnarchiveParams) -> ThreadUnarchiveResponse:
        """``thread/unarchive`` — unarchive a thread."""
        result = await self.request(
            "thread/unarchive",
            params.model_dump(by_alias=True, exclude_none=True),
            timeout_s=30,
        )
        return ThreadUnarchiveResponse.model_validate(result)

    async def thread_compact_start(self, params: ThreadCompactStartParams) -> dict[str, Any]:
        """``thread/compact/start`` — trigger compaction."""
        return await self.request(  # type: ignore[no-any-return]
            "thread/compact/start",
            params.model_dump(by_alias=True, exclude_none=True),
            timeout_s=30,
        )

    async def thread_rollback(self, params: ThreadRollbackParams) -> ThreadRollbackResponse:
        """``thread/rollback`` — drop last N turns."""
        result = await self.request(
            "thread/rollback",
            params.model_dump(by_alias=True, exclude_none=True),
            timeout_s=30,
        )
        return ThreadRollbackResponse.model_validate(result)

    async def thread_set_name(self, thread_id: str, name: str) -> dict[str, Any]:
        """``thread/name/set`` — set thread name."""
        return await self.request(  # type: ignore[no-any-return]
            "thread/name/set", {"threadId": thread_id, "name": name}, timeout_s=30
        )

    async def thread_background_terminals_clean(self, thread_id: str) -> dict[str, Any]:
        """``thread/backgroundTerminals/clean`` — terminate background terminals."""
        return await self.request(  # type: ignore[no-any-return]
            "thread/backgroundTerminals/clean", {"threadId": thread_id}, timeout_s=30
        )

    # ------------------------------------------------------------------
    # Turns
    # ------------------------------------------------------------------

    async def turn_start(self, params: TurnStartParams) -> TurnStartResponse:
        """``turn/start`` — begin a new turn."""
        result = await self.request(
            "turn/start",
            params.model_dump(by_alias=True, exclude_none=True),
            timeout_s=30,
        )
        return TurnStartResponse.model_validate(result)

    async def turn_steer(self, params: TurnSteerParams) -> TurnSteerResponse:
        """``turn/steer`` — append input to active turn."""
        result = await self.request(
            "turn/steer",
            params.model_dump(by_alias=True, exclude_none=True),
            timeout_s=30,
        )
        return TurnSteerResponse.model_validate(result)

    async def turn_interrupt(self, params: TurnInterruptParams) -> dict[str, Any]:
        """``turn/interrupt`` — cancel an in-flight turn."""
        return await self.request(  # type: ignore[no-any-return]
            "turn/interrupt",
            params.model_dump(by_alias=True, exclude_none=True),
            timeout_s=10,
        )

    # ------------------------------------------------------------------
    # Review
    # ------------------------------------------------------------------

    async def review_start(self, params: ReviewStartParams) -> ReviewStartResponse:
        """``review/start`` — start automated review."""
        result = await self.request(
            "review/start",
            params.model_dump(by_alias=True, exclude_none=True),
            timeout_s=30,
        )
        return ReviewStartResponse.model_validate(result)

    # ------------------------------------------------------------------
    # Auth
    # ------------------------------------------------------------------

    async def account_read(self, refresh_token: bool = False) -> GetAccountResponse:
        """``account/read`` — fetch current account info."""
        result = await self.request(
            "account/read",
            GetAccountParams(refresh_token=refresh_token).model_dump(by_alias=True),
            timeout_s=30,
        )
        return GetAccountResponse.model_validate(result)

    async def account_login_start(self, params: LoginAccountParams) -> dict[str, Any]:
        """``account/login/start`` — begin login flow."""
        return await self.request(  # type: ignore[no-any-return]
            "account/login/start",
            params.model_dump(by_alias=True, exclude_none=True),
            timeout_s=30,
        )

    async def account_login_cancel(self, login_id: str) -> dict[str, Any]:
        """``account/login/cancel`` — cancel a pending login."""
        return await self.request(  # type: ignore[no-any-return]
            "account/login/cancel", {"loginId": login_id}, timeout_s=30
        )

    async def account_logout(self) -> dict[str, Any]:
        """``account/logout`` — sign out."""
        return await self.request("account/logout", None, timeout_s=30)  # type: ignore[no-any-return]

    async def account_rate_limits_read(self) -> GetAccountRateLimitsResponse:
        """``account/rateLimits/read`` — fetch rate limits."""
        result = await self.request("account/rateLimits/read", None, timeout_s=30)
        return GetAccountRateLimitsResponse.model_validate(result)

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    async def model_list(self, params: ModelListParams | None = None) -> ModelListResponse:
        """``model/list`` — list available models."""
        p = (params or ModelListParams()).model_dump(by_alias=True, exclude_none=True)
        result = await self.request("model/list", p, timeout_s=30)
        return ModelListResponse.model_validate(result)

    async def command_exec(self, params: CommandExecParams) -> CommandExecResponse:
        """``command/exec`` — run a one-off command."""
        result = await self.request(
            "command/exec",
            params.model_dump(by_alias=True, exclude_none=True),
            timeout_s=60,
        )
        return CommandExecResponse.model_validate(result)

    async def config_read(self, params: ConfigReadParams | None = None) -> ConfigReadResponse:
        """``config/read`` — fetch effective config."""
        p = (params or ConfigReadParams()).model_dump(by_alias=True, exclude_none=True)
        result = await self.request("config/read", p, timeout_s=30)
        return ConfigReadResponse.model_validate(result)

    async def config_value_write(self, params: ConfigValueWriteParams) -> ConfigWriteResponse:
        """``config/value/write`` — write a single config key."""
        result = await self.request(
            "config/value/write",
            params.model_dump(by_alias=True, exclude_none=True),
            timeout_s=30,
        )
        return ConfigWriteResponse.model_validate(result)

    async def config_batch_write(self, params: ConfigBatchWriteParams) -> ConfigWriteResponse:
        """``config/batchWrite`` — write multiple config keys."""
        result = await self.request(
            "config/batchWrite",
            params.model_dump(by_alias=True, exclude_none=True),
            timeout_s=30,
        )
        return ConfigWriteResponse.model_validate(result)

    async def config_requirements_read(self) -> ConfigRequirementsReadResponse:
        """``configRequirements/read`` — read config requirements."""
        result = await self.request("configRequirements/read", {}, timeout_s=30)
        return ConfigRequirementsReadResponse.model_validate(result)

    async def config_mcp_server_reload(self) -> McpServerRefreshResponse:
        """``config/mcpServer/reload`` — reload MCP server configs."""
        result = await self.request("config/mcpServer/reload", {}, timeout_s=30)
        return McpServerRefreshResponse.model_validate(result)

    async def feedback_upload(self, params: FeedbackUploadParams) -> FeedbackUploadResponse:
        """``feedback/upload`` — submit feedback."""
        result = await self.request(
            "feedback/upload",
            params.model_dump(by_alias=True, exclude_none=True),
            timeout_s=30,
        )
        return FeedbackUploadResponse.model_validate(result)

    # ------------------------------------------------------------------
    # Skills
    # ------------------------------------------------------------------

    async def skills_list(self, params: SkillsListParams | None = None) -> SkillsListResponse:
        """``skills/list`` — list available skills."""
        p = (params or SkillsListParams()).model_dump(by_alias=True, exclude_none=True)
        result = await self.request("skills/list", p, timeout_s=30)
        return SkillsListResponse.model_validate(result)

    async def skills_remote_list(self, params: SkillsRemoteReadParams | None = None) -> SkillsRemoteReadResponse:
        """``skills/remote/list`` — list remote skills."""
        p = (params or SkillsRemoteReadParams()).model_dump(by_alias=True, exclude_none=True)
        result = await self.request("skills/remote/list", p, timeout_s=30)
        return SkillsRemoteReadResponse.model_validate(result)

    async def skills_remote_export(self, params: SkillsRemoteWriteParams) -> SkillsRemoteWriteResponse:
        """``skills/remote/export`` — export a remote skill."""
        result = await self.request(
            "skills/remote/export",
            params.model_dump(by_alias=True, exclude_none=True),
            timeout_s=30,
        )
        return SkillsRemoteWriteResponse.model_validate(result)

    async def skills_config_write(self, params: SkillsConfigWriteParams) -> SkillsConfigWriteResponse:
        """``skills/config/write`` — enable/disable a skill."""
        result = await self.request(
            "skills/config/write",
            params.model_dump(by_alias=True, exclude_none=True),
            timeout_s=30,
        )
        return SkillsConfigWriteResponse.model_validate(result)

    # ------------------------------------------------------------------
    # Apps
    # ------------------------------------------------------------------

    async def apps_list(self, params: AppsListParams | None = None) -> AppsListResponse:
        """``app/list`` — list available apps."""
        p = (params or AppsListParams()).model_dump(by_alias=True, exclude_none=True)
        result = await self.request("app/list", p, timeout_s=30)
        return AppsListResponse.model_validate(result)

    # ------------------------------------------------------------------
    # Experimental features
    # ------------------------------------------------------------------

    async def experimental_feature_list(
        self, params: ExperimentalFeatureListParams | None = None
    ) -> ExperimentalFeatureListResponse:
        """``experimentalFeature/list`` — list experimental features."""
        p = (params or ExperimentalFeatureListParams()).model_dump(by_alias=True, exclude_none=True)
        result = await self.request("experimentalFeature/list", p, timeout_s=30)
        return ExperimentalFeatureListResponse.model_validate(result)

    # ------------------------------------------------------------------
    # MCP server management
    # ------------------------------------------------------------------

    async def mcp_server_oauth_login(self, params: McpServerOauthLoginParams) -> McpServerOauthLoginResponse:
        """``mcpServer/oauth/login`` — start MCP server OAuth login."""
        result = await self.request(
            "mcpServer/oauth/login",
            params.model_dump(by_alias=True, exclude_none=True),
            timeout_s=60,
        )
        return McpServerOauthLoginResponse.model_validate(result)

    async def mcp_server_status_list(
        self, params: ListMcpServerStatusParams | None = None
    ) -> ListMcpServerStatusResponse:
        """``mcpServerStatus/list`` — list MCP server statuses."""
        p = (params or ListMcpServerStatusParams()).model_dump(by_alias=True, exclude_none=True)
        result = await self.request("mcpServerStatus/list", p, timeout_s=30)
        return ListMcpServerStatusResponse.model_validate(result)

    # ------------------------------------------------------------------
    # Windows sandbox
    # ------------------------------------------------------------------

    async def windows_sandbox_setup_start(
        self, params: WindowsSandboxSetupStartParams
    ) -> WindowsSandboxSetupStartResponse:
        """``windowsSandbox/setupStart`` — start Windows sandbox setup."""
        result = await self.request(
            "windowsSandbox/setupStart",
            params.model_dump(by_alias=True, exclude_none=True),
            timeout_s=60,
        )
        return WindowsSandboxSetupStartResponse.model_validate(result)

    # ------------------------------------------------------------------
    # Internal: message reading loop
    # ------------------------------------------------------------------

    async def _read_loop(self) -> None:
        """Background task that reads messages and dispatches them."""
        while True:
            data = await self._transport.read_line()
            if data is None:
                # Stream closed — cancel all pending requests
                for fut in self._pending.values():
                    if not fut.done():
                        fut.set_exception(RuntimeError("Codex app-server process terminated"))
                self._pending.clear()
                break
            try:
                message = parse_jsonrpc_message(data)
            except ValueError:
                logger.warning("Could not parse JSON-RPC message: %s", str(data)[:200])
                continue

            await self._handle_message(message)

    async def _handle_message(
        self,
        message: JSONRPCResponse | JSONRPCError | JSONRPCRequest | JSONRPCNotification,
    ) -> None:
        if isinstance(message, JSONRPCResponse):
            req_id = message.id
            if isinstance(req_id, int) and req_id in self._pending:
                fut = self._pending[req_id]
                if not fut.done():
                    fut.set_result(message.result)
            return

        if isinstance(message, JSONRPCError):
            err_id = message.id  # may be None for parse errors
            if isinstance(err_id, int) and err_id in self._pending:
                fut = self._pending[err_id]
                if not fut.done():
                    fut.set_exception(RuntimeError(f"JSON-RPC error {message.error.code}: {message.error.message}"))
            return

        if isinstance(message, JSONRPCRequest):
            await self._handle_server_request(message)
            return

        if isinstance(message, JSONRPCNotification):
            await self._handle_notification(message)

    async def _handle_notification(self, notification: JSONRPCNotification) -> None:
        method = notification.method
        params = notification.params or {}

        event = parse_notification_event(method, params)
        if event is None:
            return

        # Method-specific handlers
        for handler in self._notification_handlers.get(method, []):
            try:
                result = handler(method, event)
                if asyncio.iscoroutine(result):
                    await result
            except Exception:
                logger.exception("Notification handler error for %s", method)

        # Global handlers
        for handler in self._global_notification_handlers:
            try:
                result = handler(method, event)
                if asyncio.iscoroutine(result):
                    await result
            except Exception:
                logger.exception("Global notification handler error for %s", method)

    async def _handle_server_request(self, request: JSONRPCRequest) -> None:
        """Handle server-initiated requests (approvals, tool calls)."""
        method = request.method
        params = request.params or {}
        req_id = request.id

        # Check for registered handler
        handler = self._server_request_handlers.get(method)
        if handler is not None:
            try:
                response_data = await handler(method, params)
                await self._transport.write({"id": req_id, "result": response_data})
            except Exception:
                logger.exception("Server request handler error for %s", method)
                await self._transport.write(
                    {
                        "id": req_id,
                        "error": {"code": -32603, "message": "Internal handler error"},
                    }
                )
            return

        # Default: auto-decline approval requests
        if method.endswith("/requestApproval"):
            await self._transport.write({"id": req_id, "result": {"decision": "decline"}})
            return

        # Unknown server request — return method-not-found error
        await self._transport.write(
            {
                "id": req_id,
                "error": {"code": -32601, "message": f"Method not handled: {method}"},
            }
        )
