"""Synchronous low-level client for the Codex app-server JSON-RPC protocol."""

from __future__ import annotations

import logging
import shutil
import threading
from collections.abc import Callable
from itertools import count
from typing import Any

from codex_app_server_client.protocol.jsonrpc import (
    JSONRPCError,
    JSONRPCNotification,
    JSONRPCRequest,
    JSONRPCResponse,
    parse_jsonrpc_message,
)
from codex_app_server_client.protocol.transport import SyncStdioTransport
from codex_app_server_client.types.auth import (
    GetAccountParams,
    GetAccountRateLimitsResponse,
    GetAccountResponse,
    LoginAccountParams,
)
from codex_app_server_client.types.common import (
    ClientInfo,
    InitializeCapabilities,
    InitializeResponse,
)
from codex_app_server_client.types.events import ThreadEvent, parse_notification_event
from codex_app_server_client.types.misc import (
    AppsListParams,
    AppsListResponse,
    CommandExecParams,
    CommandExecResponse,
    ConfigBatchWriteParams,
    ConfigReadParams,
    ConfigReadResponse,
    ConfigRequirementsReadResponse,
    ConfigValueWriteParams,
    ConfigWriteResponse,
    ExperimentalFeatureListParams,
    ExperimentalFeatureListResponse,
    FeedbackUploadParams,
    FeedbackUploadResponse,
    ListMcpServerStatusParams,
    ListMcpServerStatusResponse,
    McpServerOauthLoginParams,
    McpServerOauthLoginResponse,
    McpServerRefreshResponse,
    ModelListParams,
    ModelListResponse,
    SkillsConfigWriteParams,
    SkillsConfigWriteResponse,
    SkillsListParams,
    SkillsListResponse,
    SkillsRemoteReadParams,
    SkillsRemoteReadResponse,
    SkillsRemoteWriteParams,
    SkillsRemoteWriteResponse,
    WindowsSandboxSetupStartParams,
    WindowsSandboxSetupStartResponse,
)
from codex_app_server_client.types.threads import (
    ReviewStartParams,
    ReviewStartResponse,
    ThreadCompactStartParams,
    ThreadForkParams,
    ThreadForkResponse,
    ThreadListParams,
    ThreadListResponse,
    ThreadLoadedListResponse,
    ThreadReadParams,
    ThreadReadResponse,
    ThreadResumeParams,
    ThreadResumeResponse,
    ThreadRollbackParams,
    ThreadRollbackResponse,
    ThreadStartParams,
    ThreadStartResponse,
    ThreadUnarchiveParams,
    ThreadUnarchiveResponse,
    TurnInterruptParams,
    TurnStartParams,
    TurnStartResponse,
    TurnSteerParams,
    TurnSteerResponse,
)

logger = logging.getLogger(__name__)

SyncNotificationCallback = Callable[[str, ThreadEvent], None]
SyncServerRequestCallback = Callable[[str, dict[str, Any]], dict[str, Any]]

_DEFAULT_CODEX_BIN = "codex"


def _find_codex_bin() -> str:
    found = shutil.which("codex")
    return found if found else _DEFAULT_CODEX_BIN


class SyncCodexClient:
    """Synchronous low-level client for the Codex app-server JSON-RPC protocol.

    Uses a background reader thread and ``threading.Event``-based correlation
    to provide a blocking API that mirrors :class:`AsyncCodexClient`.
    """

    def __init__(
        self,
        codex_bin: str | None = None,
        client_name: str = "codex_python_sdk",
        client_title: str = "Codex Python SDK",
        client_version: str = "0.1.0",
        experimental_api: bool = True,
        opt_out_notification_methods: list[str] | None = None,
        extra_args: list[str] | None = None,
        env: dict[str, str] | None = None,
    ) -> None:
        self._transport = SyncStdioTransport(
            codex_bin=codex_bin or _find_codex_bin(),
            extra_args=extra_args,
            env=env,
        )
        self._client_info = ClientInfo(
            name=client_name,
            title=client_title,
            version=client_version,
        )
        self._experimental_api = experimental_api
        self._opt_out_notification_methods = opt_out_notification_methods

        self._pending: dict[int, threading.Event] = {}
        self._results: dict[int, Any] = {}
        self._errors: dict[int, Exception] = {}
        self._id_counter = count(1)
        self._reader_thread: threading.Thread | None = None
        self._started = False

        self._notification_handlers: dict[str, list[SyncNotificationCallback]] = {}
        self._global_notification_handlers: list[SyncNotificationCallback] = []
        self._server_request_handlers: dict[str, SyncServerRequestCallback] = {}

    @property
    def is_started(self) -> bool:
        return self._started

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> InitializeResponse:
        """Start the subprocess and perform the initialization handshake."""
        if self._started:
            raise RuntimeError("Client is already started")

        self._transport.start()
        self._reader_thread = threading.Thread(target=self._read_loop, daemon=True)
        self._reader_thread.start()

        caps = InitializeCapabilities(
            experimental_api=self._experimental_api,
            opt_out_notification_methods=self._opt_out_notification_methods,
        )
        result = self.request(
            "initialize",
            {
                "clientInfo": self._client_info.model_dump(by_alias=True),
                "capabilities": caps.model_dump(by_alias=True, exclude_none=True),
            },
            timeout_s=30,
        )
        self.notify("initialized", {})
        self._started = True
        return InitializeResponse.model_validate(result)

    def close(self) -> None:
        """Shutdown the client and terminate the subprocess."""
        # Unblock any pending requests
        for evt in self._pending.values():
            evt.set()
        self._pending.clear()
        self._transport.close()
        self._reader_thread = None
        self._started = False

    def restart(self) -> InitializeResponse:
        """Restart the subprocess and re-initialize."""
        self.close()
        return self.start()

    # ------------------------------------------------------------------
    # Raw JSON-RPC
    # ------------------------------------------------------------------

    def request(
        self,
        method: str,
        params: dict[str, Any] | None = None,
        timeout_s: float = 60,
    ) -> Any:
        """Send a JSON-RPC request and block until the response arrives."""
        req_id = next(self._id_counter)
        payload: dict[str, Any] = {"id": req_id, "method": method}
        if params is not None:
            payload["params"] = params

        event = threading.Event()
        self._pending[req_id] = event

        self._transport.write(payload)

        if not event.wait(timeout=timeout_s):
            self._pending.pop(req_id, None)
            raise TimeoutError(f"Request {method} (id={req_id}) timed out after {timeout_s}s")

        self._pending.pop(req_id, None)

        if req_id in self._errors:
            raise self._errors.pop(req_id)

        return self._results.pop(req_id, None)

    def notify(self, method: str, params: dict[str, Any] | None = None) -> None:
        """Send a JSON-RPC notification (fire-and-forget)."""
        payload: dict[str, Any] = {"method": method}
        if params is not None:
            payload["params"] = params
        self._transport.write(payload)

    # ------------------------------------------------------------------
    # Handler registration
    # ------------------------------------------------------------------

    def on_notification(self, method: str | None, callback: SyncNotificationCallback) -> None:
        """Register a notification handler."""
        if method is None:
            self._global_notification_handlers.append(callback)
        else:
            self._notification_handlers.setdefault(method, []).append(callback)

    def on_server_request(self, method: str, callback: SyncServerRequestCallback) -> None:
        """Register a handler for server-initiated requests (approvals, tool calls)."""
        self._server_request_handlers[method] = callback

    # ------------------------------------------------------------------
    # Thread lifecycle
    # ------------------------------------------------------------------

    def thread_start(self, params: ThreadStartParams | None = None) -> ThreadStartResponse:
        p = (params or ThreadStartParams()).model_dump(by_alias=True, exclude_none=True)
        result = self.request("thread/start", p, timeout_s=30)
        return ThreadStartResponse.model_validate(result)

    def thread_resume(self, params: ThreadResumeParams) -> ThreadResumeResponse:
        result = self.request("thread/resume", params.model_dump(by_alias=True, exclude_none=True), timeout_s=30)
        return ThreadResumeResponse.model_validate(result)

    def thread_fork(self, params: ThreadForkParams) -> ThreadForkResponse:
        result = self.request("thread/fork", params.model_dump(by_alias=True, exclude_none=True), timeout_s=30)
        return ThreadForkResponse.model_validate(result)

    def thread_list(self, params: ThreadListParams | None = None) -> ThreadListResponse:
        p = (params or ThreadListParams()).model_dump(by_alias=True, exclude_none=True)
        result = self.request("thread/list", p, timeout_s=30)
        return ThreadListResponse.model_validate(result)

    def thread_loaded_list(self) -> ThreadLoadedListResponse:
        result = self.request("thread/loaded/list", {}, timeout_s=30)
        return ThreadLoadedListResponse.model_validate(result)

    def thread_read(self, params: ThreadReadParams) -> ThreadReadResponse:
        result = self.request("thread/read", params.model_dump(by_alias=True, exclude_none=True), timeout_s=30)
        return ThreadReadResponse.model_validate(result)

    def thread_archive(self, thread_id: str) -> dict[str, Any]:
        return self.request("thread/archive", {"threadId": thread_id}, timeout_s=30)  # type: ignore[no-any-return]

    def thread_unarchive(self, params: ThreadUnarchiveParams) -> ThreadUnarchiveResponse:
        result = self.request("thread/unarchive", params.model_dump(by_alias=True, exclude_none=True), timeout_s=30)
        return ThreadUnarchiveResponse.model_validate(result)

    def thread_compact_start(self, params: ThreadCompactStartParams) -> dict[str, Any]:
        return self.request(  # type: ignore[no-any-return]
            "thread/compact/start", params.model_dump(by_alias=True, exclude_none=True), timeout_s=30
        )

    def thread_rollback(self, params: ThreadRollbackParams) -> ThreadRollbackResponse:
        result = self.request("thread/rollback", params.model_dump(by_alias=True, exclude_none=True), timeout_s=30)
        return ThreadRollbackResponse.model_validate(result)

    def thread_set_name(self, thread_id: str, name: str) -> dict[str, Any]:
        return self.request("thread/name/set", {"threadId": thread_id, "name": name}, timeout_s=30)  # type: ignore[no-any-return]

    def thread_background_terminals_clean(self, thread_id: str) -> dict[str, Any]:
        return self.request("thread/backgroundTerminals/clean", {"threadId": thread_id}, timeout_s=30)  # type: ignore[no-any-return]

    # ------------------------------------------------------------------
    # Turns
    # ------------------------------------------------------------------

    def turn_start(self, params: TurnStartParams) -> TurnStartResponse:
        result = self.request("turn/start", params.model_dump(by_alias=True, exclude_none=True), timeout_s=30)
        return TurnStartResponse.model_validate(result)

    def turn_steer(self, params: TurnSteerParams) -> TurnSteerResponse:
        result = self.request("turn/steer", params.model_dump(by_alias=True, exclude_none=True), timeout_s=30)
        return TurnSteerResponse.model_validate(result)

    def turn_interrupt(self, params: TurnInterruptParams) -> dict[str, Any]:
        return self.request(  # type: ignore[no-any-return]
            "turn/interrupt", params.model_dump(by_alias=True, exclude_none=True), timeout_s=10
        )

    # ------------------------------------------------------------------
    # Review
    # ------------------------------------------------------------------

    def review_start(self, params: ReviewStartParams) -> ReviewStartResponse:
        result = self.request("review/start", params.model_dump(by_alias=True, exclude_none=True), timeout_s=30)
        return ReviewStartResponse.model_validate(result)

    # ------------------------------------------------------------------
    # Auth
    # ------------------------------------------------------------------

    def account_read(self, refresh_token: bool = False) -> GetAccountResponse:
        result = self.request(
            "account/read", GetAccountParams(refresh_token=refresh_token).model_dump(by_alias=True), timeout_s=30
        )
        return GetAccountResponse.model_validate(result)

    def account_login_start(self, params: LoginAccountParams) -> dict[str, Any]:
        return self.request(  # type: ignore[no-any-return]
            "account/login/start", params.model_dump(by_alias=True, exclude_none=True), timeout_s=30
        )

    def account_login_cancel(self, login_id: str) -> dict[str, Any]:
        return self.request("account/login/cancel", {"loginId": login_id}, timeout_s=30)  # type: ignore[no-any-return]

    def account_logout(self) -> dict[str, Any]:
        return self.request("account/logout", None, timeout_s=30)  # type: ignore[no-any-return]

    def account_rate_limits_read(self) -> GetAccountRateLimitsResponse:
        result = self.request("account/rateLimits/read", None, timeout_s=30)
        return GetAccountRateLimitsResponse.model_validate(result)

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    def model_list(self, params: ModelListParams | None = None) -> ModelListResponse:
        p = (params or ModelListParams()).model_dump(by_alias=True, exclude_none=True)
        result = self.request("model/list", p, timeout_s=30)
        return ModelListResponse.model_validate(result)

    def command_exec(self, params: CommandExecParams) -> CommandExecResponse:
        result = self.request("command/exec", params.model_dump(by_alias=True, exclude_none=True), timeout_s=60)
        return CommandExecResponse.model_validate(result)

    def config_read(self, params: ConfigReadParams | None = None) -> ConfigReadResponse:
        """``config/read`` — fetch effective config."""
        p = (params or ConfigReadParams()).model_dump(by_alias=True, exclude_none=True)
        result = self.request("config/read", p, timeout_s=30)
        return ConfigReadResponse.model_validate(result)

    def config_value_write(self, params: ConfigValueWriteParams) -> ConfigWriteResponse:
        """``config/value/write`` — write a single config key."""
        result = self.request("config/value/write", params.model_dump(by_alias=True, exclude_none=True), timeout_s=30)
        return ConfigWriteResponse.model_validate(result)

    def config_batch_write(self, params: ConfigBatchWriteParams) -> ConfigWriteResponse:
        """``config/batchWrite`` — write multiple config keys."""
        result = self.request("config/batchWrite", params.model_dump(by_alias=True, exclude_none=True), timeout_s=30)
        return ConfigWriteResponse.model_validate(result)

    def config_requirements_read(self) -> ConfigRequirementsReadResponse:
        """``configRequirements/read`` — read config requirements."""
        result = self.request("configRequirements/read", {}, timeout_s=30)
        return ConfigRequirementsReadResponse.model_validate(result)

    def config_mcp_server_reload(self) -> McpServerRefreshResponse:
        """``config/mcpServer/reload`` — reload MCP server configs."""
        result = self.request("config/mcpServer/reload", {}, timeout_s=30)
        return McpServerRefreshResponse.model_validate(result)

    def feedback_upload(self, params: FeedbackUploadParams) -> FeedbackUploadResponse:
        """``feedback/upload`` — submit feedback."""
        result = self.request("feedback/upload", params.model_dump(by_alias=True, exclude_none=True), timeout_s=30)
        return FeedbackUploadResponse.model_validate(result)

    # ------------------------------------------------------------------
    # Skills
    # ------------------------------------------------------------------

    def skills_list(self, params: SkillsListParams | None = None) -> SkillsListResponse:
        """``skills/list`` — list available skills."""
        p = (params or SkillsListParams()).model_dump(by_alias=True, exclude_none=True)
        result = self.request("skills/list", p, timeout_s=30)
        return SkillsListResponse.model_validate(result)

    def skills_remote_list(self, params: SkillsRemoteReadParams | None = None) -> SkillsRemoteReadResponse:
        """``skills/remote/list`` — list remote skills."""
        p = (params or SkillsRemoteReadParams()).model_dump(by_alias=True, exclude_none=True)
        result = self.request("skills/remote/list", p, timeout_s=30)
        return SkillsRemoteReadResponse.model_validate(result)

    def skills_remote_export(self, params: SkillsRemoteWriteParams) -> SkillsRemoteWriteResponse:
        """``skills/remote/export`` — export a remote skill."""
        result = self.request("skills/remote/export", params.model_dump(by_alias=True, exclude_none=True), timeout_s=30)
        return SkillsRemoteWriteResponse.model_validate(result)

    def skills_config_write(self, params: SkillsConfigWriteParams) -> SkillsConfigWriteResponse:
        """``skills/config/write`` — enable/disable a skill."""
        result = self.request("skills/config/write", params.model_dump(by_alias=True, exclude_none=True), timeout_s=30)
        return SkillsConfigWriteResponse.model_validate(result)

    # ------------------------------------------------------------------
    # Apps
    # ------------------------------------------------------------------

    def apps_list(self, params: AppsListParams | None = None) -> AppsListResponse:
        """``app/list`` — list available apps."""
        p = (params or AppsListParams()).model_dump(by_alias=True, exclude_none=True)
        result = self.request("app/list", p, timeout_s=30)
        return AppsListResponse.model_validate(result)

    # ------------------------------------------------------------------
    # Experimental features
    # ------------------------------------------------------------------

    def experimental_feature_list(
        self, params: ExperimentalFeatureListParams | None = None
    ) -> ExperimentalFeatureListResponse:
        """``experimentalFeature/list`` — list experimental features."""
        p = (params or ExperimentalFeatureListParams()).model_dump(by_alias=True, exclude_none=True)
        result = self.request("experimentalFeature/list", p, timeout_s=30)
        return ExperimentalFeatureListResponse.model_validate(result)

    # ------------------------------------------------------------------
    # MCP server management
    # ------------------------------------------------------------------

    def mcp_server_oauth_login(self, params: McpServerOauthLoginParams) -> McpServerOauthLoginResponse:
        """``mcpServer/oauth/login`` — start MCP server OAuth login."""
        result = self.request(
            "mcpServer/oauth/login", params.model_dump(by_alias=True, exclude_none=True), timeout_s=60
        )
        return McpServerOauthLoginResponse.model_validate(result)

    def mcp_server_status_list(self, params: ListMcpServerStatusParams | None = None) -> ListMcpServerStatusResponse:
        """``mcpServerStatus/list`` — list MCP server statuses."""
        p = (params or ListMcpServerStatusParams()).model_dump(by_alias=True, exclude_none=True)
        result = self.request("mcpServerStatus/list", p, timeout_s=30)
        return ListMcpServerStatusResponse.model_validate(result)

    # ------------------------------------------------------------------
    # Windows sandbox
    # ------------------------------------------------------------------

    def windows_sandbox_setup_start(self, params: WindowsSandboxSetupStartParams) -> WindowsSandboxSetupStartResponse:
        """``windowsSandbox/setupStart`` — start Windows sandbox setup."""
        result = self.request(
            "windowsSandbox/setupStart", params.model_dump(by_alias=True, exclude_none=True), timeout_s=60
        )
        return WindowsSandboxSetupStartResponse.model_validate(result)

    # ------------------------------------------------------------------
    # Internal: reader loop
    # ------------------------------------------------------------------

    def _read_loop(self) -> None:
        """Background thread that reads messages and dispatches them."""
        for data in self._transport.read_lines():
            try:
                message = parse_jsonrpc_message(data)
            except ValueError:
                logger.warning("Could not parse JSON-RPC message: %s", str(data)[:200])
                continue
            self._handle_message(message)

        # Stream ended — unblock all pending requests
        for req_id, evt in self._pending.items():
            if req_id not in self._errors:
                self._errors[req_id] = RuntimeError("Codex app-server process terminated")
            evt.set()

    def _handle_message(
        self,
        message: JSONRPCResponse | JSONRPCError | JSONRPCRequest | JSONRPCNotification,
    ) -> None:
        if isinstance(message, JSONRPCResponse):
            req_id = message.id
            if isinstance(req_id, int) and req_id in self._pending:
                self._results[req_id] = message.result
                self._pending[req_id].set()
            return

        if isinstance(message, JSONRPCError):
            err_id = message.id  # may be None for parse errors
            if isinstance(err_id, int) and err_id in self._pending:
                self._errors[err_id] = RuntimeError(f"JSON-RPC error {message.error.code}: {message.error.message}")
                self._pending[err_id].set()
            return

        if isinstance(message, JSONRPCRequest):
            self._handle_server_request(message)
            return

        if isinstance(message, JSONRPCNotification):
            self._handle_notification(message)

    def _handle_notification(self, notification: JSONRPCNotification) -> None:
        method = notification.method
        params = notification.params or {}
        event = parse_notification_event(method, params)
        if event is None:
            return

        for handler in self._notification_handlers.get(method, []):
            try:
                handler(method, event)
            except Exception:
                logger.exception("Notification handler error for %s", method)

        for handler in self._global_notification_handlers:
            try:
                handler(method, event)
            except Exception:
                logger.exception("Global notification handler error for %s", method)

    def _handle_server_request(self, request: JSONRPCRequest) -> None:
        method = request.method
        params = request.params or {}
        req_id = request.id

        handler = self._server_request_handlers.get(method)
        if handler is not None:
            try:
                response_data = handler(method, params)
                self._transport.write({"id": req_id, "result": response_data})
            except Exception:
                logger.exception("Server request handler error for %s", method)
                self._transport.write(
                    {
                        "id": req_id,
                        "error": {"code": -32603, "message": "Internal handler error"},
                    }
                )
            return

        if method.endswith("/requestApproval"):
            self._transport.write({"id": req_id, "result": {"decision": "decline"}})
            return

        self._transport.write(
            {
                "id": req_id,
                "error": {"code": -32601, "message": f"Method not handled: {method}"},
            }
        )
