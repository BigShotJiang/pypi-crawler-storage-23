"""High-level entry points for the Codex app-server SDK.

Usage (async)::

    async with CodexAppServer() as server:
        thread = await server.start_thread()
        result = await thread.run("Explain this codebase")

Usage (sync)::

    with SyncCodexAppServer() as server:
        thread = server.start_thread()
        result = thread.run("Explain this codebase")
"""

from __future__ import annotations

from types import TracebackType
from typing import Any

from codex_app_server_client._async_client import AsyncCodexClient
from codex_app_server_client._sync_client import SyncCodexClient
from codex_app_server_client.thread import AsyncThread, SyncThread
from codex_app_server_client.types.common import InitializeResponse
from codex_app_server_client.types.threads import (
    ThreadResumeParams,
    ThreadStartParams,
)


class CodexAppServer:
    """High-level async interface to the Codex app-server.

    Wraps :class:`AsyncCodexClient` and provides ergonomic thread management.
    Supports ``async with`` for automatic lifecycle management.
    """

    def __init__(
        self,
        codex_bin: str | None = None,
        client_name: str = "codex_python_sdk",
        client_title: str = "Codex Python SDK",
        client_version: str = "0.1.0",
        experimental_api: bool = True,
        opt_out_notification_methods: list[str] | None = None,
        extra_args: list[str] | None = None,
        env: dict[str, str] | None = None,
    ) -> None:
        self._low = AsyncCodexClient(
            codex_bin=codex_bin,
            client_name=client_name,
            client_title=client_title,
            client_version=client_version,
            experimental_api=experimental_api,
            opt_out_notification_methods=opt_out_notification_methods,
            extra_args=extra_args,
            env=env,
        )
        self._init_response: InitializeResponse | None = None

    @property
    def low_level(self) -> AsyncCodexClient:
        """Access the underlying low-level client for advanced use."""
        return self._low

    @property
    def server_info(self) -> InitializeResponse | None:
        """Server capabilities returned during initialization."""
        return self._init_response

    # -- Lifecycle ---------------------------------------------------------

    async def start(self) -> InitializeResponse:
        """Start the app-server subprocess and complete the handshake."""
        self._init_response = await self._low.start()
        return self._init_response

    async def close(self) -> None:
        """Shutdown the app-server subprocess."""
        await self._low.close()

    async def __aenter__(self) -> CodexAppServer:
        await self.start()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.close()

    # -- Thread management -------------------------------------------------

    async def start_thread(
        self,
        params: ThreadStartParams | None = None,
    ) -> AsyncThread:
        """Create a new thread and return a high-level :class:`AsyncThread`."""
        resp = await self._low.thread_start(params)
        return AsyncThread(client=self._low, thread_id=resp.thread.id)

    async def resume_thread(
        self,
        thread_id: str,
        **kwargs: Any,
    ) -> AsyncThread:
        """Resume an existing thread."""
        await self._low.thread_resume(ThreadResumeParams(thread_id=thread_id, **kwargs))
        return AsyncThread(client=self._low, thread_id=thread_id)


class SyncCodexAppServer:
    """High-level synchronous interface to the Codex app-server.

    Wraps :class:`SyncCodexClient` and provides ergonomic thread management.
    Supports ``with`` for automatic lifecycle management.
    """

    def __init__(
        self,
        codex_bin: str | None = None,
        client_name: str = "codex_python_sdk",
        client_title: str = "Codex Python SDK",
        client_version: str = "0.1.0",
        experimental_api: bool = True,
        opt_out_notification_methods: list[str] | None = None,
        extra_args: list[str] | None = None,
        env: dict[str, str] | None = None,
    ) -> None:
        self._low = SyncCodexClient(
            codex_bin=codex_bin,
            client_name=client_name,
            client_title=client_title,
            client_version=client_version,
            experimental_api=experimental_api,
            opt_out_notification_methods=opt_out_notification_methods,
            extra_args=extra_args,
            env=env,
        )
        self._init_response: InitializeResponse | None = None

    @property
    def low_level(self) -> SyncCodexClient:
        return self._low

    @property
    def server_info(self) -> InitializeResponse | None:
        return self._init_response

    def start(self) -> InitializeResponse:
        self._init_response = self._low.start()
        return self._init_response

    def close(self) -> None:
        self._low.close()

    def __enter__(self) -> SyncCodexAppServer:
        self.start()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        self.close()

    def start_thread(
        self,
        params: ThreadStartParams | None = None,
    ) -> SyncThread:
        resp = self._low.thread_start(params)
        return SyncThread(client=self._low, thread_id=resp.thread.id)

    def resume_thread(
        self,
        thread_id: str,
        **kwargs: Any,
    ) -> SyncThread:
        self._low.thread_resume(ThreadResumeParams(thread_id=thread_id, **kwargs))
        return SyncThread(client=self._low, thread_id=thread_id)
