"""Shared types used across the Codex app-server protocol."""

from __future__ import annotations

from enum import StrEnum
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


def _to_camel(name: str) -> str:
    """Convert snake_case to camelCase."""
    parts = name.split("_")
    return parts[0] + "".join(w.capitalize() for w in parts[1:])


class CamelModel(BaseModel):
    """Base model with camelCase alias generation for wire format."""

    model_config = ConfigDict(
        populate_by_name=True,
        alias_generator=_to_camel,
    )


class CamelModelExtra(BaseModel):
    """CamelModel variant that permits unknown fields (use sparingly)."""

    model_config = ConfigDict(
        populate_by_name=True,
        alias_generator=_to_camel,
        extra="allow",
    )


# ---------------------------------------------------------------------------
# Initialization
# ---------------------------------------------------------------------------


class ClientInfo(CamelModel):
    """Client identification sent during ``initialize``."""

    name: str
    title: str | None = None
    version: str


class InitializeCapabilities(CamelModel):
    """Client-declared capabilities negotiated during ``initialize``."""

    experimental_api: bool = False
    opt_out_notification_methods: list[str] | None = None


class InitializeParams(CamelModel):
    """Parameters for the ``initialize`` request."""

    client_info: ClientInfo
    capabilities: InitializeCapabilities | None = None


class InitializeResponse(CamelModel):
    """Response from the ``initialize`` request."""

    user_agent: str


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class ApprovalPolicySimple(StrEnum):
    """Simple (non-struct) approval policy variants."""

    NEVER = "never"
    UNTRUSTED = "untrusted"
    ON_FAILURE = "on-failure"
    ON_REQUEST = "on-request"


class RejectApprovalPolicy(CamelModel):
    """Reject approval policy with granular overrides."""

    type: Literal["reject"] = "reject"
    sandbox_approval: bool = False
    rules: bool = False
    mcp_elicitations: bool = False


ApprovalPolicy = ApprovalPolicySimple | RejectApprovalPolicy
"""Approval policy — simple enum or structured reject."""


class Personality(StrEnum):
    """Agent personality."""

    FRIENDLY = "friendly"
    PRAGMATIC = "pragmatic"
    NONE = "none"


class ReasoningEffort(StrEnum):
    """Model reasoning effort level."""

    MINIMAL = "minimal"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    XHIGH = "xhigh"


class ReasoningSummary(StrEnum):
    """Reasoning summary verbosity."""

    CONCISE = "concise"
    DETAILED = "detailed"
    NONE = "none"


class WebSearchMode(StrEnum):
    """Web search mode."""

    DISABLED = "disabled"
    CACHED = "cached"
    LIVE = "live"


class InputModality(StrEnum):
    """Model input modality."""

    TEXT = "text"
    IMAGE = "image"


# ---------------------------------------------------------------------------
# Sandbox policy (discriminated union)
# ---------------------------------------------------------------------------


class ReadOnlyAccess(CamelModel):
    """Read-only access configuration."""

    type: str = "fullAccess"
    include_platform_defaults: bool = True
    readable_roots: list[str] | None = None


class ReadOnlySandboxPolicy(CamelModel):
    """Read-only sandbox policy."""

    type: str = "readOnly"
    access: ReadOnlyAccess | None = None


class WorkspaceWriteSandboxPolicy(CamelModel):
    """Workspace-write sandbox policy."""

    type: str = "workspaceWrite"
    writable_roots: list[str] | None = None
    read_only_access: ReadOnlyAccess | None = None
    network_access: bool | None = None
    exclude_tmpdir_env_var: bool | None = None
    exclude_slash_tmp: bool | None = None


class DangerFullAccessSandboxPolicy(CamelModel):
    """Full access sandbox policy — use with caution."""

    type: str = "dangerFullAccess"


class ExternalSandboxPolicy(CamelModel):
    """External sandbox policy (client manages its own sandbox)."""

    type: str = "externalSandbox"
    network_access: str | None = None  # "restricted" | "enabled"


SandboxPolicy = (
    ReadOnlySandboxPolicy | WorkspaceWriteSandboxPolicy | DangerFullAccessSandboxPolicy | ExternalSandboxPolicy
)


# ---------------------------------------------------------------------------
# User input
# ---------------------------------------------------------------------------


class ByteRange(CamelModel):
    """Byte range within a text buffer."""

    start: int
    end: int


class TextElement(CamelModel):
    """UI-defined span within a text buffer."""

    byte_range: ByteRange
    placeholder: str | None = None


class TextInput(CamelModel):
    """Text user input."""

    type: str = "text"
    text: str
    text_elements: list[TextElement] | None = None


class ImageInput(CamelModel):
    """Remote image user input."""

    type: str = "image"
    url: str


class LocalImageInput(CamelModel):
    """Local file image user input."""

    type: str = "localImage"
    path: str


class SkillInput(CamelModel):
    """Skill invocation input."""

    type: str = "skill"
    name: str
    path: str


class MentionInput(CamelModel):
    """App mention input."""

    type: str = "mention"
    name: str
    path: str


UserInput = TextInput | ImageInput | LocalImageInput | SkillInput | MentionInput


# ---------------------------------------------------------------------------
# Dynamic tools (experimental)
# ---------------------------------------------------------------------------


class DynamicToolSpec(CamelModel):
    """Dynamic tool specification for ``thread/start``."""

    name: str
    description: str
    input_schema: dict[str, Any] = Field(default_factory=dict)
