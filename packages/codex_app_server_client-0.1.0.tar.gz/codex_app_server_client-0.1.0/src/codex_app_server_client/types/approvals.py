"""Approval types for server-initiated requests (command execution, file changes, tool calls)."""

from __future__ import annotations

from enum import StrEnum
from typing import Any

from pydantic import Field

from codex_app_server_client.types.common import CamelModel

# ---------------------------------------------------------------------------
# Command execution approval
# ---------------------------------------------------------------------------


class CommandExecutionApprovalRequest(CamelModel):
    """Parameters for ``item/commandExecution/requestApproval`` server request."""

    thread_id: str
    turn_id: str
    item_id: str
    approval_id: str | None = None
    reason: str | None = None
    command: str | None = None
    cwd: str | None = None
    command_actions: list[dict[str, Any]] | None = None
    network_approval_context: dict[str, Any] | None = None
    proposed_execpolicy_amendment: dict[str, Any] | None = None


class ApprovalDecision(StrEnum):
    """Decision for an approval request."""

    ACCEPT = "accept"
    DECLINE = "decline"
    CANCEL = "cancel"


class CommandExecutionApprovalResponse(CamelModel):
    """Response to ``item/commandExecution/requestApproval``."""

    decision: ApprovalDecision
    accept_settings: dict[str, Any] | None = None


# ---------------------------------------------------------------------------
# File change approval
# ---------------------------------------------------------------------------


class FileChangeApprovalRequest(CamelModel):
    """Parameters for ``item/fileChange/requestApproval`` server request."""

    thread_id: str
    turn_id: str
    item_id: str
    reason: str | None = None
    grant_root: str | None = None


class FileChangeApprovalResponse(CamelModel):
    """Response to ``item/fileChange/requestApproval``."""

    decision: ApprovalDecision


# ---------------------------------------------------------------------------
# Dynamic tool call (experimental)
# ---------------------------------------------------------------------------


class ToolCallContentItem(CamelModel):
    """Content item in a tool call response."""

    type: str  # "inputText" | "inputImage"
    text: str | None = None
    image_url: str | None = None


class ToolCallRequest(CamelModel):
    """Parameters for ``item/tool/call`` server request."""

    thread_id: str
    turn_id: str
    call_id: str
    tool: str
    arguments: dict[str, Any] = Field(default_factory=dict)


class ToolCallResponse(CamelModel):
    """Response to ``item/tool/call``."""

    content_items: list[ToolCallContentItem] = Field(default_factory=list)
    success: bool = True
