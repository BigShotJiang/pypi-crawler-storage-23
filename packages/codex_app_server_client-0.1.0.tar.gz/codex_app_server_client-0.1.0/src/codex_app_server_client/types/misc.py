"""Miscellaneous protocol types: models, skills, apps, config, command exec, feedback."""

from __future__ import annotations

from enum import StrEnum
from typing import Any

from pydantic import Field

from codex_app_server_client.types.common import CamelModel, InputModality, ReasoningEffort, SandboxPolicy

# ---------------------------------------------------------------------------
# Model list
# ---------------------------------------------------------------------------


class ReasoningEffortOption(CamelModel):
    """A supported reasoning effort option for a model."""

    reasoning_effort: ReasoningEffort
    description: str = ""


class ModelInfo(CamelModel):
    """Information about an available model."""

    id: str
    model: str = ""
    upgrade: str | None = None
    display_name: str = ""
    description: str = ""
    hidden: bool = False
    supported_reasoning_efforts: list[ReasoningEffortOption] = Field(default_factory=list)
    default_reasoning_effort: ReasoningEffort = ReasoningEffort.MEDIUM
    input_modalities: list[InputModality] = Field(default_factory=list)
    supports_personality: bool = False
    is_default: bool = False


class ModelListParams(CamelModel):
    """Parameters for ``model/list``."""

    cursor: str | None = None
    limit: int | None = None
    include_hidden: bool | None = None


class ModelListResponse(CamelModel):
    """Response from ``model/list``."""

    data: list[ModelInfo] = Field(default_factory=list)
    next_cursor: str | None = None


# ---------------------------------------------------------------------------
# Experimental features
# ---------------------------------------------------------------------------


class ExperimentalFeatureInfo(CamelModel):
    """An experimental feature flag."""

    name: str
    stage: str | None = None
    display_name: str | None = None
    description: str | None = None
    announcement: str | None = None
    enabled: bool = False
    default_enabled: bool = False


class ExperimentalFeatureListParams(CamelModel):
    """Parameters for ``experimentalFeature/list``."""

    cursor: str | None = None
    limit: int | None = None


class ExperimentalFeatureListResponse(CamelModel):
    """Response from ``experimentalFeature/list``."""

    data: list[ExperimentalFeatureInfo] = Field(default_factory=list)
    next_cursor: str | None = None


# ---------------------------------------------------------------------------
# Skills
# ---------------------------------------------------------------------------


class SkillScope(StrEnum):
    """Scope of a skill."""

    USER = "user"
    REPO = "repo"
    SYSTEM = "system"
    ADMIN = "admin"


class SkillInterface(CamelModel):
    """Skill UI metadata."""

    display_name: str | None = None
    short_description: str | None = None
    icon_small: str | None = None
    icon_large: str | None = None
    brand_color: str | None = None
    default_prompt: str | None = None


class SkillToolDependency(CamelModel):
    """A tool dependency declared by a skill."""

    type: str
    value: str
    description: str | None = None
    transport: str | None = None
    command: str | None = None
    url: str | None = None


class SkillDependencies(CamelModel):
    """Dependencies declared by a skill."""

    tools: list[SkillToolDependency] = Field(default_factory=list)


class SkillMetadata(CamelModel):
    """Full skill metadata returned by ``skills/list``."""

    name: str
    description: str = ""
    short_description: str | None = None
    interface: SkillInterface | None = None
    dependencies: SkillDependencies | None = None
    path: str = ""
    scope: SkillScope = SkillScope.USER
    enabled: bool = True


class SkillErrorInfo(CamelModel):
    """Error info for a skill."""

    path: str
    message: str


class SkillsListEntry(CamelModel):
    """Skills for a specific cwd."""

    cwd: str
    skills: list[SkillMetadata] = Field(default_factory=list)
    errors: list[SkillErrorInfo] = Field(default_factory=list)


# Keep legacy alias
SkillInfo = SkillMetadata
SkillsListCwdEntry = SkillsListEntry


class SkillsListExtraRootsForCwd(CamelModel):
    """Per-cwd extra roots for skills scanning."""

    cwd: str
    extra_user_roots: list[str] = Field(default_factory=list)


class SkillsListParams(CamelModel):
    """Parameters for ``skills/list``."""

    cwds: list[str] | None = None
    force_reload: bool = False
    per_cwd_extra_user_roots: list[SkillsListExtraRootsForCwd] | None = None


class SkillsListResponse(CamelModel):
    """Response from ``skills/list``."""

    data: list[SkillsListEntry] = Field(default_factory=list)


class SkillsConfigWriteParams(CamelModel):
    """Parameters for ``skills/config/write``."""

    path: str
    enabled: bool


class SkillsConfigWriteResponse(CamelModel):
    """Response from ``skills/config/write``."""

    effective_enabled: bool = True


# ---------------------------------------------------------------------------
# Remote skills
# ---------------------------------------------------------------------------


class HazelnutScope(StrEnum):
    """Hazelnut scope for remote skills."""

    EXAMPLE = "example"
    WORKSPACE_SHARED = "workspace-shared"
    ALL_SHARED = "all-shared"
    PERSONAL = "personal"


class ProductSurface(StrEnum):
    """Product surface for remote skills."""

    CHATGPT = "chatgpt"
    CODEX = "codex"
    API = "api"
    ATLAS = "atlas"


class SkillsRemoteReadParams(CamelModel):
    """Parameters for ``skills/remote/list``."""

    hazelnut_scope: HazelnutScope = HazelnutScope.EXAMPLE
    product_surface: ProductSurface = ProductSurface.CODEX
    enabled: bool = False


class RemoteSkillSummary(CamelModel):
    """Summary of a remote skill."""

    id: str
    name: str
    description: str = ""


class SkillsRemoteReadResponse(CamelModel):
    """Response from ``skills/remote/list``."""

    data: list[RemoteSkillSummary] = Field(default_factory=list)


class SkillsRemoteWriteParams(CamelModel):
    """Parameters for ``skills/remote/export``."""

    hazelnut_id: str


class SkillsRemoteWriteResponse(CamelModel):
    """Response from ``skills/remote/export``."""

    id: str
    path: str


# ---------------------------------------------------------------------------
# Apps
# ---------------------------------------------------------------------------


class AppBranding(CamelModel):
    """App branding metadata."""

    category: str | None = None
    developer: str | None = None
    website: str | None = None
    privacy_policy: str | None = None
    terms_of_service: str | None = None
    is_discoverable_app: bool = False


class AppReview(CamelModel):
    """App review status."""

    status: str


class AppScreenshot(CamelModel):
    """App screenshot."""

    url: str | None = None
    file_id: str | None = None
    user_prompt: str = ""


class AppMetadataInfo(CamelModel):
    """App metadata."""

    review: AppReview | None = None
    categories: list[str] | None = None
    sub_categories: list[str] | None = None
    seo_description: str | None = None
    screenshots: list[AppScreenshot] | None = None
    developer: str | None = None
    version: str | None = None
    version_id: str | None = None
    version_notes: str | None = None
    first_party_type: str | None = None
    first_party_requires_install: bool | None = None
    show_in_composer_when_unlinked: bool | None = None


class AppInfo(CamelModel):
    """Information about an app/connector."""

    id: str
    name: str = ""
    description: str | None = None
    logo_url: str | None = None
    logo_url_dark: str | None = None
    distribution_channel: str | None = None
    branding: AppBranding | None = None
    app_metadata: AppMetadataInfo | None = None
    labels: dict[str, str] | None = None
    install_url: str | None = None
    is_accessible: bool = False
    is_enabled: bool = True


class AppsListParams(CamelModel):
    """Parameters for ``app/list``."""

    cursor: str | None = None
    limit: int | None = None
    thread_id: str | None = None
    force_refetch: bool = False


class AppsListResponse(CamelModel):
    """Response from ``app/list``."""

    data: list[AppInfo] = Field(default_factory=list)
    next_cursor: str | None = None


# ---------------------------------------------------------------------------
# Command execution (one-off)
# ---------------------------------------------------------------------------


class CommandExecParams(CamelModel):
    """Parameters for ``command/exec``."""

    command: list[str]
    timeout_ms: int | None = None
    cwd: str | None = None
    sandbox_policy: SandboxPolicy | None = None


class CommandExecResponse(CamelModel):
    """Response from ``command/exec``."""

    exit_code: int = 0
    stdout: str = ""
    stderr: str = ""


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------


class ConfigReadParams(CamelModel):
    """Parameters for ``config/read``."""

    include_layers: bool = False
    cwd: str | None = None


class ConfigLayerMetadata(CamelModel):
    """Metadata for a config layer."""

    name: dict[str, Any] | str  # ConfigLayerSource is a tagged union; accept loosely
    version: str = ""


class ConfigLayer(CamelModel):
    """A config layer with source, version, and config data."""

    name: dict[str, Any] | str
    version: str = ""
    config: dict[str, Any] = Field(default_factory=dict)
    disabled_reason: str | None = None


class ConfigReadResponse(CamelModel):
    """Response from ``config/read``."""

    config: dict[str, Any] = Field(default_factory=dict)
    origins: dict[str, ConfigLayerMetadata] = Field(default_factory=dict)
    layers: list[ConfigLayer] | None = None


class MergeStrategy(StrEnum):
    """Merge strategy for config writes."""

    REPLACE = "replace"
    UPSERT = "upsert"


class ConfigEdit(CamelModel):
    """A single config edit in a batch write."""

    key_path: str
    value: Any
    merge_strategy: MergeStrategy = MergeStrategy.REPLACE


class ConfigValueWriteParams(CamelModel):
    """Parameters for ``config/value/write``."""

    key_path: str
    value: Any
    merge_strategy: MergeStrategy = MergeStrategy.REPLACE
    file_path: str | None = None
    expected_version: str | None = None


class ConfigBatchWriteParams(CamelModel):
    """Parameters for ``config/batchWrite``."""

    edits: list[ConfigEdit] = Field(default_factory=list)
    file_path: str | None = None
    expected_version: str | None = None


class OverriddenMetadata(CamelModel):
    """Metadata about an overridden config value."""

    message: str
    overriding_layer: ConfigLayerMetadata
    effective_value: Any = None


class ConfigWriteResponse(CamelModel):
    """Response from ``config/value/write`` and ``config/batchWrite``."""

    status: str = ""  # "ok" | "okOverridden"
    version: str = ""
    file_path: str = ""
    overridden_metadata: OverriddenMetadata | None = None


class ConfigRequirementsReadResponse(CamelModel):
    """Response from ``configRequirements/read``."""

    requirements: dict[str, Any] | None = None


# ---------------------------------------------------------------------------
# MCP server status
# ---------------------------------------------------------------------------


class McpServerOauthLoginParams(CamelModel):
    """Parameters for ``mcpServer/oauth/login``."""

    name: str
    scopes: list[str] | None = None
    timeout_secs: int | None = None


class McpServerOauthLoginResponse(CamelModel):
    """Response from ``mcpServer/oauth/login``."""

    authorization_url: str


class ListMcpServerStatusParams(CamelModel):
    """Parameters for ``mcpServerStatus/list``."""

    cursor: str | None = None
    limit: int | None = None


class McpServerStatusInfo(CamelModel):
    """Status of a configured MCP server."""

    name: str
    tools: dict[str, Any] = Field(default_factory=dict)
    resources: list[dict[str, Any]] = Field(default_factory=list)
    resource_templates: list[dict[str, Any]] = Field(default_factory=list)
    auth_status: str | None = None


class ListMcpServerStatusResponse(CamelModel):
    """Response from ``mcpServerStatus/list``."""

    data: list[McpServerStatusInfo] = Field(default_factory=list)
    next_cursor: str | None = None


class McpServerRefreshResponse(CamelModel):
    """Response from ``config/mcpServer/reload``."""

    pass


# ---------------------------------------------------------------------------
# Collaboration modes
# ---------------------------------------------------------------------------


class CollaborationModeInfo(CamelModel):
    """A collaboration mode preset."""

    id: str
    name: str | None = None
    description: str | None = None


class CollaborationModeListResponse(CamelModel):
    """Response from ``collaborationMode/list``."""

    data: list[CollaborationModeInfo] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Feedback
# ---------------------------------------------------------------------------


class FeedbackUploadParams(CamelModel):
    """Parameters for ``feedback/upload``."""

    classification: str
    reason: str | None = None
    thread_id: str | None = None
    include_logs: bool = False
    extra_log_files: list[str] | None = None


class FeedbackUploadResponse(CamelModel):
    """Response from ``feedback/upload``."""

    thread_id: str = ""


# ---------------------------------------------------------------------------
# Windows sandbox
# ---------------------------------------------------------------------------


class WindowsSandboxSetupStartParams(CamelModel):
    """Parameters for ``windowsSandbox/setupStart``."""

    mode: str  # "elevated" | "unelevated"


class WindowsSandboxSetupStartResponse(CamelModel):
    """Response from ``windowsSandbox/setupStart``."""

    started: bool = False
