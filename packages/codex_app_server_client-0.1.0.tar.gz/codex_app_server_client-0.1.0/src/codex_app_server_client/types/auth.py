"""Authentication types for the Codex app-server protocol."""

from __future__ import annotations

from codex_app_server_client.types.common import CamelModel

# ---------------------------------------------------------------------------
# Account
# ---------------------------------------------------------------------------


class AccountInfo(CamelModel):
    """Account information from ``account/read``."""

    type: str | None = None  # "apiKey" | "chatgpt"
    email: str | None = None
    plan_type: str | None = None


class GetAccountParams(CamelModel):
    """Parameters for ``account/read``."""

    refresh_token: bool = False


class GetAccountResponse(CamelModel):
    """Response from ``account/read``."""

    account: AccountInfo | None = None
    requires_openai_auth: bool = False


# ---------------------------------------------------------------------------
# Login
# ---------------------------------------------------------------------------


class LoginAccountParams(CamelModel):
    """Parameters for ``account/login/start``.

    Supports apiKey, chatgpt, and chatgptAuthTokens login types.
    """

    type: str  # "apiKey" | "chatgpt" | "chatgptAuthTokens"
    api_key: str | None = None
    # chatgptAuthTokens fields
    access_token: str | None = None
    chatgpt_account_id: str | None = None
    chatgpt_plan_type: str | None = None


class LoginApiKeyResponse(CamelModel):
    """Response from ``account/login/start`` with type=apiKey."""

    type: str = "apiKey"


class LoginChatGptResponse(CamelModel):
    """Response from ``account/login/start`` with type=chatgpt."""

    type: str = "chatgpt"
    login_id: str
    auth_url: str


class LoginChatGptAuthTokensResponse(CamelModel):
    """Response from ``account/login/start`` with type=chatgptAuthTokens."""

    type: str = "chatgptAuthTokens"


LoginAccountResponse = LoginApiKeyResponse | LoginChatGptResponse | LoginChatGptAuthTokensResponse


class CancelLoginAccountParams(CamelModel):
    """Parameters for ``account/login/cancel``."""

    login_id: str


class CancelLoginAccountResponse(CamelModel):
    """Response from ``account/login/cancel``."""

    status: str  # "canceled" | "notFound"


# ---------------------------------------------------------------------------
# Rate limits
# ---------------------------------------------------------------------------


class CreditsSnapshot(CamelModel):
    """Credits balance snapshot."""

    has_credits: bool = False
    unlimited: bool = False
    balance: str | None = None


class RateLimitWindow(CamelModel):
    """A single rate-limit window."""

    used_percent: int = 0
    window_duration_mins: int | None = None
    resets_at: int | None = None


class RateLimitSnapshot(CamelModel):
    """Rate limit snapshot for a metering bucket."""

    limit_id: str | None = None
    limit_name: str | None = None
    primary: RateLimitWindow | None = None
    secondary: RateLimitWindow | None = None
    credits: CreditsSnapshot | None = None
    plan_type: str | None = None


# Keep legacy alias
RateLimits = RateLimitSnapshot


class GetAccountRateLimitsResponse(CamelModel):
    """Response from ``account/rateLimits/read``."""

    rate_limits: RateLimitSnapshot | None = None
    rate_limits_by_limit_id: dict[str, RateLimitSnapshot] | None = None
