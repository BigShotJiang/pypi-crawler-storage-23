"""Thread, turn, and item types for the Codex app-server protocol."""

from __future__ import annotations

from enum import StrEnum
from typing import Annotated, Any, Literal

from pydantic import Discriminator, Field, Tag

from codex_app_server_client.types.common import (
    ApprovalPolicy,
    CamelModel,
    DynamicToolSpec,
    Personality,
    ReasoningEffort,
    ReasoningSummary,
    SandboxPolicy,
    UserInput,
)

# ---------------------------------------------------------------------------
# Thread
# ---------------------------------------------------------------------------


class ThreadStatus(CamelModel):
    """Status of a thread."""

    type: str  # "notLoaded", "idle", "systemError", "active"
    active_flags: list[str] | None = None


class GitInfo(CamelModel):
    """Git metadata captured when a thread was created."""

    sha: str | None = None
    branch: str | None = None
    origin_url: str | None = None


class ThreadInfo(CamelModel):
    """Information about a thread returned by start/resume/list/read."""

    id: str
    preview: str = ""
    model_provider: str = ""
    created_at: int = 0
    updated_at: int = 0
    status: ThreadStatus | None = None
    path: str | None = None
    cwd: str = ""
    cli_version: str = ""
    source: str = ""
    agent_nickname: str | None = None
    agent_role: str | None = None
    git_info: GitInfo | None = None
    name: str | None = None
    turns: list[TurnInfo] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Turn
# ---------------------------------------------------------------------------


class TurnStatus(StrEnum):
    """Status of a turn."""

    IN_PROGRESS = "inProgress"
    COMPLETED = "completed"
    INTERRUPTED = "interrupted"
    FAILED = "failed"


class CodexErrorInfo(CamelModel):
    """Structured error info from codex."""

    type: str | None = None  # ContextWindowExceeded, UsageLimitExceeded, etc.
    http_status_code: int | None = None


class TurnError(CamelModel):
    """Error payload on a failed turn."""

    message: str
    codex_error_info: CodexErrorInfo | None = None
    additional_details: str | None = None


class TokenUsageBreakdown(CamelModel):
    """Token usage breakdown for a single request or aggregate."""

    total_tokens: int = 0
    input_tokens: int = 0
    cached_input_tokens: int = 0
    output_tokens: int = 0
    reasoning_output_tokens: int = 0


class ThreadTokenUsage(CamelModel):
    """Token usage for a thread/turn."""

    total: TokenUsageBreakdown = Field(default_factory=TokenUsageBreakdown)
    last: TokenUsageBreakdown = Field(default_factory=TokenUsageBreakdown)
    model_context_window: int | None = None


# Keep legacy alias for backward compatibility
TokenUsage = TokenUsageBreakdown


class TurnInfo(CamelModel):
    """Information about a turn."""

    id: str
    status: TurnStatus = TurnStatus.IN_PROGRESS
    items: list[Any] = Field(default_factory=list)
    error: TurnError | None = None


# ---------------------------------------------------------------------------
# Thread items (discriminated union via "type" field)
# ---------------------------------------------------------------------------


class UserMessageItem(CamelModel):
    """User message item."""

    type: Literal["userMessage"] = "userMessage"
    id: str
    content: list[dict[str, Any]] = Field(default_factory=list)


class AgentMessageItem(CamelModel):
    """Agent response message."""

    type: Literal["agentMessage"] = "agentMessage"
    id: str
    text: str = ""
    phase: str | None = None


class PlanItem(CamelModel):
    """Plan item."""

    type: Literal["plan"] = "plan"
    id: str
    text: str = ""


class ReasoningItem(CamelModel):
    """Agent reasoning summary."""

    type: Literal["reasoning"] = "reasoning"
    id: str
    summary: list[str] = Field(default_factory=list)
    content: list[str] = Field(default_factory=list)


class CommandExecutionStatus(StrEnum):
    """Status of a command execution."""

    IN_PROGRESS = "inProgress"
    COMPLETED = "completed"
    FAILED = "failed"
    DECLINED = "declined"


class CommandExecutionItem(CamelModel):
    """A command executed by the agent."""

    type: Literal["commandExecution"] = "commandExecution"
    id: str
    command: str | None = None
    cwd: str | None = None
    process_id: str | None = None
    status: CommandExecutionStatus = CommandExecutionStatus.IN_PROGRESS
    aggregated_output: str | None = None
    exit_code: int | None = None
    duration_ms: int | None = None
    command_actions: list[dict[str, Any]] | None = None


class PatchChangeKind(CamelModel):
    """Kind of a file patch change (add/delete/update)."""

    type: str  # "add", "delete", "update"
    move_path: str | None = None


class FileUpdateChange(CamelModel):
    """Individual file change."""

    path: str
    kind: PatchChangeKind | str  # Accept both typed and plain string
    diff: str = ""


class PatchApplyStatus(StrEnum):
    """Status of a file change."""

    IN_PROGRESS = "inProgress"
    COMPLETED = "completed"
    FAILED = "failed"
    DECLINED = "declined"


class FileChangeItem(CamelModel):
    """A set of file changes by the agent."""

    type: Literal["fileChange"] = "fileChange"
    id: str
    changes: list[FileUpdateChange] = Field(default_factory=list)
    status: PatchApplyStatus = PatchApplyStatus.IN_PROGRESS


class McpToolCallStatus(StrEnum):
    """Status of an MCP tool call."""

    IN_PROGRESS = "inProgress"
    COMPLETED = "completed"
    FAILED = "failed"


class McpToolCallItem(CamelModel):
    """MCP tool call item."""

    type: Literal["mcpToolCall"] = "mcpToolCall"
    id: str
    server: str = ""
    tool: str = ""
    status: McpToolCallStatus = McpToolCallStatus.IN_PROGRESS
    arguments: Any | None = None
    result: dict[str, Any] | None = None
    error: dict[str, Any] | None = None
    duration_ms: int | None = None


class CollabAgentToolCallStatus(StrEnum):
    """Status of a collab agent tool call."""

    IN_PROGRESS = "inProgress"
    COMPLETED = "completed"
    FAILED = "failed"


class CollabAgentState(CamelModel):
    """State of a collaborating agent."""

    status: str
    message: str | None = None


class CollabAgentToolCallItem(CamelModel):
    """Collaboration agent tool call item."""

    type: Literal["collabAgentToolCall"] = "collabAgentToolCall"
    id: str
    tool: str = ""
    status: CollabAgentToolCallStatus = CollabAgentToolCallStatus.IN_PROGRESS
    sender_thread_id: str = ""
    receiver_thread_ids: list[str] = Field(default_factory=list)
    prompt: str | None = None
    agents_states: dict[str, CollabAgentState] = Field(default_factory=dict)


class WebSearchItem(CamelModel):
    """Web search request item."""

    type: Literal["webSearch"] = "webSearch"
    id: str
    query: str = ""
    action: dict[str, Any] | None = None


class ImageViewItem(CamelModel):
    """Image view item."""

    type: Literal["imageView"] = "imageView"
    id: str
    path: str = ""


class EnteredReviewModeItem(CamelModel):
    """Entered review mode item."""

    type: Literal["enteredReviewMode"] = "enteredReviewMode"
    id: str
    review: str = ""


class ExitedReviewModeItem(CamelModel):
    """Exited review mode item with review content."""

    type: Literal["exitedReviewMode"] = "exitedReviewMode"
    id: str
    review: str = ""


class ContextCompactionItem(CamelModel):
    """Context compaction item."""

    type: Literal["contextCompaction"] = "contextCompaction"
    id: str


def _get_item_type(data: Any) -> str:
    if isinstance(data, dict):
        return str(data.get("type", ""))
    return ""


ThreadItem = Annotated[
    Annotated[UserMessageItem, Tag("userMessage")]
    | Annotated[AgentMessageItem, Tag("agentMessage")]
    | Annotated[PlanItem, Tag("plan")]
    | Annotated[ReasoningItem, Tag("reasoning")]
    | Annotated[CommandExecutionItem, Tag("commandExecution")]
    | Annotated[FileChangeItem, Tag("fileChange")]
    | Annotated[McpToolCallItem, Tag("mcpToolCall")]
    | Annotated[CollabAgentToolCallItem, Tag("collabAgentToolCall")]
    | Annotated[WebSearchItem, Tag("webSearch")]
    | Annotated[ImageViewItem, Tag("imageView")]
    | Annotated[EnteredReviewModeItem, Tag("enteredReviewMode")]
    | Annotated[ExitedReviewModeItem, Tag("exitedReviewMode")]
    | Annotated[ContextCompactionItem, Tag("contextCompaction")],
    Discriminator(_get_item_type),
]
"""Discriminated union of all thread item types."""


# ---------------------------------------------------------------------------
# Request/response params
# ---------------------------------------------------------------------------


class ThreadStartParams(CamelModel):
    """Parameters for ``thread/start``."""

    model: str | None = None
    model_provider: str | None = None
    cwd: str | None = None
    approval_policy: ApprovalPolicy | None = None
    sandbox: str | None = None
    config: dict[str, Any] | None = None
    base_instructions: str | None = None
    developer_instructions: str | None = None
    personality: Personality | None = None
    ephemeral: bool | None = None
    dynamic_tools: list[DynamicToolSpec] | None = None
    persist_extended_history: bool | None = None


class ThreadStartResponse(CamelModel):
    """Response from ``thread/start``."""

    thread: ThreadInfo
    model: str = ""
    model_provider: str = ""
    cwd: str = ""
    approval_policy: Any | None = None
    sandbox: Any | None = None
    reasoning_effort: ReasoningEffort | None = None


class ThreadResumeParams(CamelModel):
    """Parameters for ``thread/resume``."""

    thread_id: str
    model: str | None = None
    model_provider: str | None = None
    cwd: str | None = None
    approval_policy: ApprovalPolicy | None = None
    sandbox: str | None = None
    config: dict[str, Any] | None = None
    base_instructions: str | None = None
    developer_instructions: str | None = None
    personality: Personality | None = None
    persist_extended_history: bool | None = None


class ThreadResumeResponse(CamelModel):
    """Response from ``thread/resume``."""

    thread: ThreadInfo
    model: str = ""
    model_provider: str = ""
    cwd: str = ""
    approval_policy: Any | None = None
    sandbox: Any | None = None
    reasoning_effort: ReasoningEffort | None = None


class ThreadForkParams(CamelModel):
    """Parameters for ``thread/fork``."""

    thread_id: str
    model: str | None = None
    model_provider: str | None = None
    cwd: str | None = None
    approval_policy: ApprovalPolicy | None = None
    sandbox: str | None = None
    config: dict[str, Any] | None = None
    base_instructions: str | None = None
    developer_instructions: str | None = None
    persist_extended_history: bool | None = None


class ThreadForkResponse(CamelModel):
    """Response from ``thread/fork``."""

    thread: ThreadInfo
    model: str = ""
    model_provider: str = ""
    cwd: str = ""
    approval_policy: Any | None = None
    sandbox: Any | None = None
    reasoning_effort: ReasoningEffort | None = None


class ThreadListParams(CamelModel):
    """Parameters for ``thread/list``."""

    cursor: str | None = None
    limit: int | None = None
    sort_key: str | None = None  # "created_at" | "updated_at"
    model_providers: list[str] | None = None
    source_kinds: list[str] | None = None
    archived: bool | None = None
    cwd: str | None = None


class ThreadListResponse(CamelModel):
    """Response from ``thread/list``."""

    data: list[ThreadInfo] = Field(default_factory=list)
    next_cursor: str | None = None


class ThreadLoadedListResponse(CamelModel):
    """Response from ``thread/loaded/list``."""

    data: list[str] = Field(default_factory=list)
    next_cursor: str | None = None


class ThreadReadParams(CamelModel):
    """Parameters for ``thread/read``."""

    thread_id: str
    include_turns: bool = False


class ThreadReadResponse(CamelModel):
    """Response from ``thread/read``."""

    thread: ThreadInfo


class ThreadArchiveParams(CamelModel):
    """Parameters for ``thread/archive``."""

    thread_id: str


class ThreadUnarchiveParams(CamelModel):
    """Parameters for ``thread/unarchive``."""

    thread_id: str


class ThreadUnarchiveResponse(CamelModel):
    """Response from ``thread/unarchive``."""

    thread: ThreadInfo


class ThreadCompactStartParams(CamelModel):
    """Parameters for ``thread/compact/start``."""

    thread_id: str


class ThreadRollbackParams(CamelModel):
    """Parameters for ``thread/rollback``."""

    thread_id: str
    num_turns: int = 1


class ThreadRollbackResponse(CamelModel):
    """Response from ``thread/rollback``."""

    thread: ThreadInfo


class ThreadSetNameParams(CamelModel):
    """Parameters for ``thread/name/set``."""

    thread_id: str
    name: str


class ThreadBackgroundTerminalsCleanParams(CamelModel):
    """Parameters for ``thread/backgroundTerminals/clean``."""

    thread_id: str


class TurnStartParams(CamelModel):
    """Parameters for ``turn/start``."""

    thread_id: str
    input: list[UserInput]
    model: str | None = None
    cwd: str | None = None
    approval_policy: ApprovalPolicy | None = None
    sandbox_policy: SandboxPolicy | None = None
    effort: ReasoningEffort | None = None
    summary: ReasoningSummary | None = None
    personality: Personality | None = None
    output_schema: dict[str, Any] | None = None


class TurnStartResponse(CamelModel):
    """Response from ``turn/start``."""

    turn: TurnInfo


class TurnSteerParams(CamelModel):
    """Parameters for ``turn/steer``."""

    thread_id: str
    input: list[UserInput]
    expected_turn_id: str


class TurnSteerResponse(CamelModel):
    """Response from ``turn/steer``."""

    turn_id: str


class TurnInterruptParams(CamelModel):
    """Parameters for ``turn/interrupt``."""

    thread_id: str
    turn_id: str


class ReviewTarget(CamelModel):
    """Review target specification."""

    type: str  # "uncommittedChanges", "baseBranch", "commit", "custom"
    branch: str | None = None
    sha: str | None = None
    title: str | None = None
    instructions: str | None = None


class ReviewStartParams(CamelModel):
    """Parameters for ``review/start``."""

    thread_id: str
    target: ReviewTarget
    delivery: str | None = None  # "inline" | "detached"


class ReviewStartResponse(CamelModel):
    """Response from ``review/start``."""

    turn: TurnInfo
    review_thread_id: str | None = None
