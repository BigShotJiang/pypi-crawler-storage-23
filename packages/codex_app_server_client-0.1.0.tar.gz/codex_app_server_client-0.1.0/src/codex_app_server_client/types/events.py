"""Notification / event types streamed by the Codex app-server."""

from __future__ import annotations

from typing import Any

from pydantic import Field

from codex_app_server_client.types.common import CamelModel
from codex_app_server_client.types.threads import (
    ThreadInfo,
    ThreadTokenUsage,
    TurnError,
    TurnInfo,
)

# ---------------------------------------------------------------------------
# Thread lifecycle notifications
# ---------------------------------------------------------------------------


class ThreadStartedEvent(CamelModel):
    """``thread/started`` notification."""

    thread: ThreadInfo


class ThreadArchivedEvent(CamelModel):
    """``thread/archived`` notification."""

    thread_id: str


class ThreadUnarchivedEvent(CamelModel):
    """``thread/unarchived`` notification."""

    thread_id: str


class ThreadStatusChangedEvent(CamelModel):
    """``thread/status/changed`` notification."""

    thread_id: str
    status: dict[str, Any] = Field(default_factory=dict)


class ThreadNameUpdatedEvent(CamelModel):
    """``thread/name/updated`` notification."""

    thread_id: str
    thread_name: str | None = None


class ThreadTokenUsageUpdatedEvent(CamelModel):
    """``thread/tokenUsage/updated`` notification."""

    thread_id: str
    turn_id: str = ""
    token_usage: ThreadTokenUsage | None = None


class ContextCompactedEvent(CamelModel):
    """``thread/compacted`` notification (deprecated)."""

    thread_id: str
    turn_id: str = ""


# ---------------------------------------------------------------------------
# Turn lifecycle notifications
# ---------------------------------------------------------------------------


class TurnStartedEvent(CamelModel):
    """``turn/started`` notification."""

    thread_id: str
    turn: TurnInfo


class TurnCompletedEvent(CamelModel):
    """``turn/completed`` notification."""

    thread_id: str
    turn: TurnInfo


class TurnDiffUpdatedEvent(CamelModel):
    """``turn/diff/updated`` notification."""

    thread_id: str
    turn_id: str
    diff: str = ""


class PlanStepInfo(CamelModel):
    """A step in a plan update."""

    step: str
    status: str = "pending"  # "pending" | "inProgress" | "completed"


class TurnPlanUpdatedEvent(CamelModel):
    """``turn/plan/updated`` notification."""

    thread_id: str
    turn_id: str
    explanation: str | None = None
    plan: list[PlanStepInfo] = Field(default_factory=list)


class ModelReroutedEvent(CamelModel):
    """``model/rerouted`` notification."""

    thread_id: str
    turn_id: str
    from_model: str
    to_model: str
    reason: str = ""


# ---------------------------------------------------------------------------
# Error / warning notifications
# ---------------------------------------------------------------------------


class ErrorNotificationEvent(CamelModel):
    """``error`` notification — non-fatal error during a turn."""

    error: TurnError
    will_retry: bool = False
    thread_id: str
    turn_id: str


class DeprecationNoticeEvent(CamelModel):
    """``deprecationNotice`` notification."""

    summary: str
    details: str | None = None


class TextPosition(CamelModel):
    """1-based text position."""

    line: int = 0
    column: int = 0


class TextRange(CamelModel):
    """Text range (start/end positions)."""

    start: TextPosition = Field(default_factory=TextPosition)
    end: TextPosition = Field(default_factory=TextPosition)


class ConfigWarningEvent(CamelModel):
    """``configWarning`` notification."""

    summary: str
    details: str | None = None
    path: str | None = None
    range: TextRange | None = None


# ---------------------------------------------------------------------------
# Item lifecycle notifications
# ---------------------------------------------------------------------------


class ItemStartedEvent(CamelModel):
    """``item/started`` notification — emitted when a new item begins."""

    item: dict[str, Any] = Field(default_factory=dict)
    thread_id: str = ""
    turn_id: str = ""


class ItemCompletedEvent(CamelModel):
    """``item/completed`` notification — authoritative final state of an item."""

    item: dict[str, Any] = Field(default_factory=dict)
    thread_id: str = ""
    turn_id: str = ""


class RawResponseItemCompletedEvent(CamelModel):
    """``rawResponseItem/completed`` notification (internal/Codex Cloud)."""

    thread_id: str
    turn_id: str
    item: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Item delta notifications
# ---------------------------------------------------------------------------


class AgentMessageDeltaEvent(CamelModel):
    """``item/agentMessage/delta`` — streamed text delta for agent message."""

    thread_id: str = ""
    turn_id: str = ""
    item_id: str = ""
    delta: str = ""


class PlanDeltaEvent(CamelModel):
    """``item/plan/delta`` — streamed plan text delta."""

    thread_id: str = ""
    turn_id: str = ""
    item_id: str = ""
    delta: str = ""


class ReasoningSummaryTextDeltaEvent(CamelModel):
    """``item/reasoning/summaryTextDelta`` — streamed reasoning summary."""

    thread_id: str = ""
    turn_id: str = ""
    item_id: str = ""
    delta: str = ""
    summary_index: int = 0


class ReasoningSummaryPartAddedEvent(CamelModel):
    """``item/reasoning/summaryPartAdded`` — boundary between reasoning sections."""

    thread_id: str = ""
    turn_id: str = ""
    item_id: str = ""
    summary_index: int = 0


class ReasoningTextDeltaEvent(CamelModel):
    """``item/reasoning/textDelta`` — raw reasoning text delta."""

    thread_id: str = ""
    turn_id: str = ""
    item_id: str = ""
    delta: str = ""
    content_index: int = 0


class CommandExecutionOutputDeltaEvent(CamelModel):
    """``item/commandExecution/outputDelta`` — streamed command output."""

    thread_id: str = ""
    turn_id: str = ""
    item_id: str = ""
    delta: str = ""


class TerminalInteractionEvent(CamelModel):
    """``item/commandExecution/terminalInteraction`` — terminal stdin interaction."""

    thread_id: str
    turn_id: str
    item_id: str
    process_id: str
    stdin: str = ""


class FileChangeOutputDeltaEvent(CamelModel):
    """``item/fileChange/outputDelta`` — tool call response delta."""

    thread_id: str = ""
    turn_id: str = ""
    item_id: str = ""
    delta: str = ""


class McpToolCallProgressEvent(CamelModel):
    """``item/mcpToolCall/progress`` — MCP tool call progress update."""

    thread_id: str
    turn_id: str
    item_id: str
    message: str = ""


# ---------------------------------------------------------------------------
# Auth notifications
# ---------------------------------------------------------------------------


class AccountLoginCompletedEvent(CamelModel):
    """``account/login/completed`` notification."""

    login_id: str | None = None
    success: bool = False
    error: str | None = None


class AccountUpdatedEvent(CamelModel):
    """``account/updated`` notification."""

    auth_mode: str | None = None  # "apiKey" | "chatgpt" | null


class AccountRateLimitsUpdatedEvent(CamelModel):
    """``account/rateLimits/updated`` notification."""

    rate_limits: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# MCP / misc notifications
# ---------------------------------------------------------------------------


class McpServerOauthLoginCompletedEvent(CamelModel):
    """``mcpServer/oauthLogin/completed`` notification."""

    name: str
    success: bool = False
    error: str | None = None


class AppListUpdatedEvent(CamelModel):
    """``app/list/updated`` notification."""

    data: list[dict[str, Any]] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Windows notifications
# ---------------------------------------------------------------------------


class WindowsSandboxSetupCompletedEvent(CamelModel):
    """``windowsSandbox/setupCompleted`` notification."""

    mode: str  # "elevated" | "unelevated"
    success: bool = False
    error: str | None = None


class WindowsWorldWritableWarningEvent(CamelModel):
    """``windows/worldWritableWarning`` notification."""

    sample_paths: list[str] = Field(default_factory=list)
    extra_count: int = 0
    failed_scan: bool = False


# ---------------------------------------------------------------------------
# Fuzzy file search notifications
# ---------------------------------------------------------------------------


class FuzzyFileSearchResult(CamelModel):
    """A single file match from fuzzy search."""

    root: str = ""
    path: str = ""
    file_name: str = ""
    score: int = 0
    indices: list[int] | None = None


class FuzzyFileSearchSessionUpdatedEvent(CamelModel):
    """``fuzzyFileSearch/sessionUpdated`` notification."""

    session_id: str
    query: str = ""
    files: list[FuzzyFileSearchResult] = Field(default_factory=list)


class FuzzyFileSearchSessionCompletedEvent(CamelModel):
    """``fuzzyFileSearch/sessionCompleted`` notification."""

    session_id: str


# ---------------------------------------------------------------------------
# Union type for all events
# ---------------------------------------------------------------------------

ThreadEvent = (
    ThreadStartedEvent
    | ThreadArchivedEvent
    | ThreadUnarchivedEvent
    | ThreadStatusChangedEvent
    | ThreadNameUpdatedEvent
    | ThreadTokenUsageUpdatedEvent
    | ContextCompactedEvent
    | TurnStartedEvent
    | TurnCompletedEvent
    | TurnDiffUpdatedEvent
    | TurnPlanUpdatedEvent
    | ModelReroutedEvent
    | ErrorNotificationEvent
    | DeprecationNoticeEvent
    | ConfigWarningEvent
    | ItemStartedEvent
    | ItemCompletedEvent
    | RawResponseItemCompletedEvent
    | AgentMessageDeltaEvent
    | PlanDeltaEvent
    | ReasoningSummaryTextDeltaEvent
    | ReasoningSummaryPartAddedEvent
    | ReasoningTextDeltaEvent
    | CommandExecutionOutputDeltaEvent
    | TerminalInteractionEvent
    | FileChangeOutputDeltaEvent
    | McpToolCallProgressEvent
    | AccountLoginCompletedEvent
    | AccountUpdatedEvent
    | AccountRateLimitsUpdatedEvent
    | McpServerOauthLoginCompletedEvent
    | AppListUpdatedEvent
    | WindowsSandboxSetupCompletedEvent
    | WindowsWorldWritableWarningEvent
    | FuzzyFileSearchSessionUpdatedEvent
    | FuzzyFileSearchSessionCompletedEvent
)
"""Union of all notification event types."""


# ---------------------------------------------------------------------------
# Notification method → event type mapping
# ---------------------------------------------------------------------------

NOTIFICATION_TYPE_MAP: dict[str, type[CamelModel]] = {
    "thread/started": ThreadStartedEvent,
    "thread/archived": ThreadArchivedEvent,
    "thread/unarchived": ThreadUnarchivedEvent,
    "thread/status/changed": ThreadStatusChangedEvent,
    "thread/name/updated": ThreadNameUpdatedEvent,
    "thread/tokenUsage/updated": ThreadTokenUsageUpdatedEvent,
    "thread/compacted": ContextCompactedEvent,
    "turn/started": TurnStartedEvent,
    "turn/completed": TurnCompletedEvent,
    "turn/diff/updated": TurnDiffUpdatedEvent,
    "turn/plan/updated": TurnPlanUpdatedEvent,
    "model/rerouted": ModelReroutedEvent,
    "error": ErrorNotificationEvent,
    "deprecationNotice": DeprecationNoticeEvent,
    "configWarning": ConfigWarningEvent,
    "item/started": ItemStartedEvent,
    "item/completed": ItemCompletedEvent,
    "rawResponseItem/completed": RawResponseItemCompletedEvent,
    "item/agentMessage/delta": AgentMessageDeltaEvent,
    "item/plan/delta": PlanDeltaEvent,
    "item/reasoning/summaryTextDelta": ReasoningSummaryTextDeltaEvent,
    "item/reasoning/summaryPartAdded": ReasoningSummaryPartAddedEvent,
    "item/reasoning/textDelta": ReasoningTextDeltaEvent,
    "item/commandExecution/outputDelta": CommandExecutionOutputDeltaEvent,
    "item/commandExecution/terminalInteraction": TerminalInteractionEvent,
    "item/fileChange/outputDelta": FileChangeOutputDeltaEvent,
    "item/mcpToolCall/progress": McpToolCallProgressEvent,
    "account/login/completed": AccountLoginCompletedEvent,
    "account/updated": AccountUpdatedEvent,
    "account/rateLimits/updated": AccountRateLimitsUpdatedEvent,
    "mcpServer/oauthLogin/completed": McpServerOauthLoginCompletedEvent,
    "app/list/updated": AppListUpdatedEvent,
    "windowsSandbox/setupCompleted": WindowsSandboxSetupCompletedEvent,
    "windows/worldWritableWarning": WindowsWorldWritableWarningEvent,
    "fuzzyFileSearch/sessionUpdated": FuzzyFileSearchSessionUpdatedEvent,
    "fuzzyFileSearch/sessionCompleted": FuzzyFileSearchSessionCompletedEvent,
}


def parse_notification_event(method: str, params: dict[str, Any] | None) -> ThreadEvent | None:
    """Parse a notification into a typed event, or ``None`` if unrecognised."""
    event_cls = NOTIFICATION_TYPE_MAP.get(method)
    if event_cls is None:
        return None
    return event_cls.model_validate(params or {})  # type: ignore[return-value]
