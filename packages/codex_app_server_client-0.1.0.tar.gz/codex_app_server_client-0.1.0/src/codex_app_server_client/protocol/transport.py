"""Stdio transports for communicating with ``codex app-server`` over JSONL."""

from __future__ import annotations

import asyncio
import json
import logging
import subprocess
import threading
from collections.abc import Iterator
from typing import Any

logger = logging.getLogger(__name__)


class AsyncStdioTransport:
    """Async transport that spawns ``codex app-server`` and talks JSONL over stdio."""

    def __init__(
        self,
        codex_bin: str,
        extra_args: list[str] | None = None,
        env: dict[str, str] | None = None,
    ) -> None:
        self._codex_bin = codex_bin
        self._extra_args = extra_args or []
        self._env = env
        self._proc: asyncio.subprocess.Process | None = None
        self._write_lock = asyncio.Lock()
        self._stderr_task: asyncio.Task[None] | None = None

    @property
    def is_running(self) -> bool:
        return self._proc is not None and self._proc.returncode is None

    async def start(self) -> None:
        """Spawn the ``codex app-server`` subprocess."""
        args = [self._codex_bin, *self._extra_args, "app-server", "--listen", "stdio://"]
        self._proc = await asyncio.create_subprocess_exec(
            *args,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=self._env,
        )
        self._stderr_task = asyncio.create_task(self._read_stderr())

    async def close(self) -> None:
        """Terminate the subprocess gracefully."""
        if self._stderr_task:
            self._stderr_task.cancel()
            self._stderr_task = None

        if self._proc and self._proc.returncode is None:
            self._proc.terminate()
            try:
                await asyncio.wait_for(self._proc.wait(), timeout=5)
            except TimeoutError:
                self._proc.kill()
                await self._proc.wait()
        self._proc = None

    async def write(self, payload: dict[str, Any]) -> None:
        """Write a JSON-RPC message as a single JSONL line to stdin."""
        if not self._proc or not self._proc.stdin:
            raise RuntimeError("Transport is not running")
        line = json.dumps(payload, separators=(",", ":")) + "\n"
        async with self._write_lock:
            self._proc.stdin.write(line.encode("utf-8"))
            await self._proc.stdin.drain()

    async def read_line(self) -> dict[str, Any] | None:
        """Read one JSONL line from stdout and parse it.

        Returns ``None`` when the stream is closed.
        """
        if not self._proc or not self._proc.stdout:
            return None
        while True:
            raw = await self._proc.stdout.readline()
            if not raw:
                return None
            text = raw.decode("utf-8").strip()
            if not text:
                continue
            try:
                return json.loads(text)  # type: ignore[no-any-return]
            except json.JSONDecodeError:
                logger.warning("Ignoring non-JSON stdout line: %s", text[:200])

    async def _read_stderr(self) -> None:
        assert self._proc and self._proc.stderr
        while True:
            line = await self._proc.stderr.readline()
            if not line:
                break
            logger.debug("codex-app-server stderr: %s", line.decode("utf-8", "replace").rstrip())


class SyncStdioTransport:
    """Synchronous transport that spawns ``codex app-server`` and talks JSONL over stdio.

    A background thread reads stdout lines and places parsed dicts into a queue.
    """

    def __init__(
        self,
        codex_bin: str,
        extra_args: list[str] | None = None,
        env: dict[str, str] | None = None,
    ) -> None:
        self._codex_bin = codex_bin
        self._extra_args = extra_args or []
        self._env = env
        self._proc: subprocess.Popen[bytes] | None = None
        self._write_lock = threading.Lock()
        self._reader_thread: threading.Thread | None = None
        self._lines: list[dict[str, Any]] = []
        self._line_event = threading.Event()
        self._closed = False

    @property
    def is_running(self) -> bool:
        return self._proc is not None and self._proc.poll() is None

    def start(self) -> None:
        """Spawn the subprocess."""
        args = [self._codex_bin, *self._extra_args, "app-server", "--listen", "stdio://"]
        self._proc = subprocess.Popen(
            args,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=self._env,
        )
        self._reader_thread = threading.Thread(target=self._read_stdout, daemon=True)
        self._reader_thread.start()
        # Also start a stderr logger
        threading.Thread(target=self._read_stderr, daemon=True).start()

    def close(self) -> None:
        """Terminate the subprocess."""
        self._closed = True
        self._line_event.set()  # unblock any waiters
        if self._proc and self._proc.poll() is None:
            self._proc.terminate()
            try:
                self._proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._proc.kill()
                self._proc.wait()
        self._proc = None

    def write(self, payload: dict[str, Any]) -> None:
        """Write a JSON-RPC message."""
        if not self._proc or not self._proc.stdin:
            raise RuntimeError("Transport is not running")
        line = json.dumps(payload, separators=(",", ":")) + "\n"
        with self._write_lock:
            self._proc.stdin.write(line.encode("utf-8"))
            self._proc.stdin.flush()

    def read_lines(self) -> Iterator[dict[str, Any]]:
        """Blocking iterator yielding parsed JSONL dicts from stdout."""
        while not self._closed:
            self._line_event.wait()
            self._line_event.clear()
            while self._lines:
                yield self._lines.pop(0)

    def read_line(self, timeout: float | None = None) -> dict[str, Any] | None:
        """Read a single line, blocking up to *timeout* seconds."""
        deadline_remaining = timeout
        while not self._closed:
            if self._lines:
                return self._lines.pop(0)
            if not self._line_event.wait(timeout=deadline_remaining):
                return None
            self._line_event.clear()
            if self._lines:
                return self._lines.pop(0)
            # Could have been spurious, try again if we still have time
            if deadline_remaining is not None:
                return None
        return None

    def _read_stdout(self) -> None:
        assert self._proc and self._proc.stdout
        for raw in self._proc.stdout:
            if self._closed:
                break
            text = raw.decode("utf-8", "replace").strip()
            if not text:
                continue
            try:
                parsed: dict[str, Any] = json.loads(text)
            except json.JSONDecodeError:
                logger.warning("Ignoring non-JSON stdout line: %s", text[:200])
                continue
            self._lines.append(parsed)
            self._line_event.set()
        # Signal EOF
        self._line_event.set()

    def _read_stderr(self) -> None:
        assert self._proc and self._proc.stderr
        for raw in self._proc.stderr:
            if self._closed:
                break
            logger.debug("codex-app-server stderr: %s", raw.decode("utf-8", "replace").rstrip())
