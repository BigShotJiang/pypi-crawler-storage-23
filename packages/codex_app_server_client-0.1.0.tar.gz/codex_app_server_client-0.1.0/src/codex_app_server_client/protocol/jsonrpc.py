"""JSON-RPC 2.0 message types for the Codex app-server wire protocol.

The app-server omits the ``"jsonrpc": "2.0"`` envelope key on the wire, so
these models do not include it.  Messages are newline-delimited JSON (JSONL)
when using the stdio transport.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict


class JSONRPCRequest(BaseModel):
    """A JSON-RPC request (client → server or server → client)."""

    model_config = ConfigDict(populate_by_name=True)

    id: int | str
    method: str
    params: dict[str, Any] | None = None


class JSONRPCResponse(BaseModel):
    """A successful JSON-RPC response."""

    model_config = ConfigDict(populate_by_name=True)

    id: int | str
    result: Any


class JSONRPCErrorData(BaseModel):
    """The ``error`` payload inside a JSON-RPC error response."""

    model_config = ConfigDict(populate_by_name=True)

    code: int
    message: str
    data: Any | None = None


class JSONRPCError(BaseModel):
    """A JSON-RPC error response."""

    model_config = ConfigDict(populate_by_name=True)

    id: int | str | None = None
    error: JSONRPCErrorData


class JSONRPCNotification(BaseModel):
    """A JSON-RPC notification (no ``id``)."""

    model_config = ConfigDict(populate_by_name=True)

    method: str
    params: dict[str, Any] | None = None


# ---------------------------------------------------------------------------
# Discriminated union helper
# ---------------------------------------------------------------------------

JSONRPCMessage = JSONRPCResponse | JSONRPCError | JSONRPCRequest | JSONRPCNotification


def parse_jsonrpc_message(data: dict[str, Any]) -> JSONRPCMessage:
    """Parse a raw JSON dict into the appropriate JSON-RPC message type.

    Discrimination logic (mirrors the app-server wire format):
    * Has ``id`` + ``result``              → Response
    * Has ``id`` + ``error``               → Error
    * Has ``id`` + ``method``              → Request (server → client)
    * Has ``method`` but no ``id``         → Notification
    """
    has_id = "id" in data
    has_method = "method" in data
    has_result = "result" in data
    has_error = "error" in data

    if has_id and has_result:
        return JSONRPCResponse.model_validate(data)
    if has_id and has_error:
        return JSONRPCError.model_validate(data)
    if has_id and has_method:
        return JSONRPCRequest.model_validate(data)
    if has_method and not has_id:
        return JSONRPCNotification.model_validate(data)

    msg = f"Cannot classify JSON-RPC message: {data!r}"
    raise ValueError(msg)
