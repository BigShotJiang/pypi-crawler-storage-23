"""High-level Thread abstraction for driving turns via the Codex app-server.

Unlike the TS SDK (which uses ``codex exec`` one-shot subprocesses), these
thread classes drive turns over the persistent app-server JSON-RPC connection.
"""

from __future__ import annotations

import asyncio
import logging
import queue
import threading
from collections.abc import AsyncGenerator, Callable, Generator
from dataclasses import dataclass, field
from enum import StrEnum

# TYPE_CHECKING-only imports to avoid circular dependency at runtime
from typing import TYPE_CHECKING, Any

from codex_app_server_client.types.common import TextInput, UserInput
from codex_app_server_client.types.events import (
    AgentMessageDeltaEvent,
    ItemCompletedEvent,
    ThreadEvent,
    ThreadTokenUsageUpdatedEvent,
    TurnCompletedEvent,
    TurnStartedEvent,
)
from codex_app_server_client.types.threads import (
    ThreadTokenUsage,
    TurnError,
    TurnInterruptParams,
    TurnStartParams,
)

if TYPE_CHECKING:
    from codex_app_server_client._async_client import AsyncCodexClient
    from codex_app_server_client._sync_client import SyncCodexClient

logger = logging.getLogger(__name__)

Input = str | list[UserInput]
"""Convenience input type: a plain string or a list of :class:`UserInput`."""


class EventAction(StrEnum):
    """Action returned by an ``on_event`` callback to control turn execution."""

    CONTINUE = "continue"
    """Keep processing the turn (default)."""

    INTERRUPT = "interrupt"
    """Request the turn be interrupted. The SDK will call ``turn/interrupt``
    once and continue draining events until the turn terminates."""


@dataclass
class TurnResult:
    """Completed turn result — analogous to ``RunResult`` in the TS SDK."""

    status: str = "completed"
    """Terminal turn status: ``completed``, ``interrupted``, or ``failed``."""

    turn_id: str = ""
    """The turn ID assigned by the server."""

    items: list[dict[str, Any]] = field(default_factory=list)
    """Completed items collected from ``item/completed`` events."""

    final_response: str = ""
    """Text from the last ``agentMessage`` item/completed event."""

    streamed_response: str = ""
    """Aggregated text from ``agentMessage/delta`` events (fallback)."""

    usage: ThreadTokenUsage | None = None
    """Token usage snapshot (last ``thread/tokenUsage/updated``)."""

    error: TurnError | None = None
    """Error payload when ``status`` is ``failed``."""


#: Callback type for ``on_event`` — receives (method, event) and may return an
#: :class:`EventAction` or ``None`` (treated as CONTINUE).
OnEventCallback = Callable[[str, ThreadEvent], EventAction | None]


def _normalize_input(input_: Input) -> list[UserInput]:
    """Normalise a string or ``UserInput`` list into the wire format."""
    if isinstance(input_, str):
        return [TextInput(type="text", text=input_)]
    return input_


# ---------------------------------------------------------------------------
# Async Thread
# ---------------------------------------------------------------------------


class AsyncThread:
    """Async thread bound to an app-server connection.

    Created via :meth:`CodexAppServer.start_thread` or
    :meth:`CodexAppServer.resume_thread`.
    """

    def __init__(self, *, client: AsyncCodexClient, thread_id: str) -> None:
        self._client = client
        self._thread_id = thread_id

    @property
    def id(self) -> str:
        return self._thread_id

    async def run(
        self,
        input_: Input,
        *,
        model: str | None = None,
        timeout_s: float = 300,
        on_event: OnEventCallback | None = None,
        **kwargs: Any,
    ) -> TurnResult:
        """Send input, wait for the turn to complete, and return the result.

        Args:
            input_: User text or structured input.
            model: Optional model override for this turn.
            timeout_s: Maximum seconds to wait for turn completion.
            on_event: Optional callback invoked for every event. Return
                :attr:`EventAction.INTERRUPT` to request turn interruption.
            **kwargs: Forwarded to :class:`TurnStartParams`.
        """
        result = TurnResult()
        delta_chunks: list[str] = []
        interrupted_once = False

        async for method, event in self._run_streamed_with_method(input_, model=model, timeout_s=timeout_s, **kwargs):
            # --- Callback hook ---
            if on_event is not None:
                action = on_event(method, event)
                if action is EventAction.INTERRUPT and not interrupted_once:
                    interrupted_once = True
                    turn_id = result.turn_id
                    if turn_id:
                        try:
                            await self._client.turn_interrupt(
                                TurnInterruptParams(thread_id=self._thread_id, turn_id=turn_id)
                            )
                        except Exception:
                            logger.exception("Failed to interrupt turn %s", turn_id)

            # --- Collect into result ---
            if isinstance(event, TurnStartedEvent):
                result.turn_id = event.turn.id

            elif isinstance(event, AgentMessageDeltaEvent):
                if event.delta:
                    delta_chunks.append(event.delta)

            elif isinstance(event, ItemCompletedEvent):
                result.items.append(event.item)
                item_type = event.item.get("type") if isinstance(event.item, dict) else None
                if item_type == "agentMessage":
                    result.final_response = event.item.get("text", "")

            elif isinstance(event, TurnCompletedEvent):
                result.status = event.turn.status.value
                if event.turn.error:
                    result.error = event.turn.error

            elif isinstance(event, ThreadTokenUsageUpdatedEvent):
                result.usage = event.token_usage

        # Fallback: use aggregated deltas when no final item text
        result.streamed_response = "".join(delta_chunks)
        if not result.final_response and result.streamed_response:
            result.final_response = result.streamed_response.strip()

        return result

    async def run_streamed(
        self,
        input_: Input,
        *,
        model: str | None = None,
        timeout_s: float = 300,
        **kwargs: Any,
    ) -> AsyncGenerator[ThreadEvent, None]:
        """Send input and yield events as they arrive until the turn completes."""
        async for _method, event in self._run_streamed_with_method(input_, model=model, timeout_s=timeout_s, **kwargs):
            yield event

    async def _run_streamed_with_method(
        self,
        input_: Input,
        *,
        model: str | None = None,
        timeout_s: float = 300,
        **kwargs: Any,
    ) -> AsyncGenerator[tuple[str, ThreadEvent], None]:
        """Core implementation: start turn, subscribe to events, yield (method, event) until done."""
        event_queue: asyncio.Queue[tuple[str, ThreadEvent] | None] = asyncio.Queue()
        turn_done = asyncio.Event()
        active_turn_id: str | None = None

        def _on_event(method: str, event: ThreadEvent) -> None:
            nonlocal active_turn_id
            # Filter by thread_id
            evt_thread_id = getattr(event, "thread_id", None)
            if evt_thread_id is not None and evt_thread_id != self._thread_id:
                return
            # Capture turn_id from turn/started
            if isinstance(event, TurnStartedEvent):
                active_turn_id = event.turn.id
            # Filter by turn_id once known
            evt_turn_id = getattr(event, "turn_id", None)
            if active_turn_id and evt_turn_id and evt_turn_id != active_turn_id:
                return
            event_queue.put_nowait((method, event))
            if isinstance(event, TurnCompletedEvent):
                turn_done.set()

        self._client.on_notification(None, _on_event)

        try:
            params = TurnStartParams(
                thread_id=self._thread_id,
                input=_normalize_input(input_),
                model=model,
                **kwargs,
            )
            await self._client.turn_start(params)

            deadline = asyncio.get_event_loop().time() + timeout_s
            while not turn_done.is_set():
                remaining = deadline - asyncio.get_event_loop().time()
                if remaining <= 0:
                    raise TimeoutError(f"Turn did not complete within {timeout_s}s")
                try:
                    item = await asyncio.wait_for(event_queue.get(), timeout=min(remaining, 1.0))
                    if item is not None:
                        yield item
                        if isinstance(item[1], TurnCompletedEvent):
                            break
                except TimeoutError:
                    continue

            # Drain remaining queued events
            while not event_queue.empty():
                item = event_queue.get_nowait()
                if item is not None:
                    yield item
        finally:
            if _on_event in self._client._global_notification_handlers:
                self._client._global_notification_handlers.remove(_on_event)


# ---------------------------------------------------------------------------
# Sync Thread
# ---------------------------------------------------------------------------


class SyncThread:
    """Synchronous thread bound to an app-server connection.

    Created via :meth:`SyncCodexAppServer.start_thread` or
    :meth:`SyncCodexAppServer.resume_thread`.
    """

    def __init__(self, *, client: SyncCodexClient, thread_id: str) -> None:
        self._client = client
        self._thread_id = thread_id

    @property
    def id(self) -> str:
        return self._thread_id

    def run(
        self,
        input_: Input,
        *,
        model: str | None = None,
        timeout_s: float = 300,
        on_event: OnEventCallback | None = None,
        **kwargs: Any,
    ) -> TurnResult:
        """Send input, block until the turn completes, and return the result.

        Args:
            input_: User text or structured input.
            model: Optional model override for this turn.
            timeout_s: Maximum seconds to wait for turn completion.
            on_event: Optional callback invoked for every event. Return
                :attr:`EventAction.INTERRUPT` to request turn interruption.
            **kwargs: Forwarded to :class:`TurnStartParams`.
        """
        result = TurnResult()
        delta_chunks: list[str] = []
        interrupted_once = False

        for method, event in self._run_streamed_with_method(input_, model=model, timeout_s=timeout_s, **kwargs):
            # --- Callback hook ---
            if on_event is not None:
                action = on_event(method, event)
                if action is EventAction.INTERRUPT and not interrupted_once:
                    interrupted_once = True
                    turn_id = result.turn_id
                    if turn_id:
                        try:
                            self._client.turn_interrupt(TurnInterruptParams(thread_id=self._thread_id, turn_id=turn_id))
                        except Exception:
                            logger.exception("Failed to interrupt turn %s", turn_id)

            # --- Collect into result ---
            if isinstance(event, TurnStartedEvent):
                result.turn_id = event.turn.id

            elif isinstance(event, AgentMessageDeltaEvent):
                if event.delta:
                    delta_chunks.append(event.delta)

            elif isinstance(event, ItemCompletedEvent):
                result.items.append(event.item)
                item_type = event.item.get("type") if isinstance(event.item, dict) else None
                if item_type == "agentMessage":
                    result.final_response = event.item.get("text", "")

            elif isinstance(event, TurnCompletedEvent):
                result.status = event.turn.status.value
                if event.turn.error:
                    result.error = event.turn.error

            elif isinstance(event, ThreadTokenUsageUpdatedEvent):
                result.usage = event.token_usage

        # Fallback: use aggregated deltas when no final item text
        result.streamed_response = "".join(delta_chunks)
        if not result.final_response and result.streamed_response:
            result.final_response = result.streamed_response.strip()

        return result

    def run_streamed(
        self,
        input_: Input,
        *,
        model: str | None = None,
        timeout_s: float = 300,
        **kwargs: Any,
    ) -> Generator[ThreadEvent, None, None]:
        """Send input and yield events as they arrive until the turn completes."""
        for _method, event in self._run_streamed_with_method(input_, model=model, timeout_s=timeout_s, **kwargs):
            yield event

    def _run_streamed_with_method(
        self,
        input_: Input,
        *,
        model: str | None = None,
        timeout_s: float = 300,
        **kwargs: Any,
    ) -> Generator[tuple[str, ThreadEvent], None, None]:
        """Core implementation: start turn, subscribe to events, yield (method, event) until done."""
        event_q: queue.Queue[tuple[str, ThreadEvent] | None] = queue.Queue()
        turn_done = threading.Event()
        active_turn_id: str | None = None

        def _on_event(method: str, event: ThreadEvent) -> None:
            nonlocal active_turn_id
            # Filter by thread_id
            evt_thread_id = getattr(event, "thread_id", None)
            if evt_thread_id is not None and evt_thread_id != self._thread_id:
                return
            # Capture turn_id from turn/started
            if isinstance(event, TurnStartedEvent):
                active_turn_id = event.turn.id
            # Filter by turn_id once known
            evt_turn_id = getattr(event, "turn_id", None)
            if active_turn_id and evt_turn_id and evt_turn_id != active_turn_id:
                return
            event_q.put((method, event))
            if isinstance(event, TurnCompletedEvent):
                turn_done.set()

        self._client.on_notification(None, _on_event)

        try:
            params = TurnStartParams(
                thread_id=self._thread_id,
                input=_normalize_input(input_),
                model=model,
                **kwargs,
            )
            self._client.turn_start(params)

            import time

            deadline = time.monotonic() + timeout_s
            while not turn_done.is_set():
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError(f"Turn did not complete within {timeout_s}s")
                try:
                    item = event_q.get(timeout=min(remaining, 1.0))
                    if item is not None:
                        yield item
                        if isinstance(item[1], TurnCompletedEvent):
                            break
                except queue.Empty:
                    continue

            # Drain remaining
            while not event_q.empty():
                try:
                    item = event_q.get_nowait()
                    if item is not None:
                        yield item
                except queue.Empty:
                    break
        finally:
            if _on_event in self._client._global_notification_handlers:
                self._client._global_notification_handlers.remove(_on_event)
