# AGENTS.md — Codex App Server Client SDK

## Overview
Python client SDK for the Codex app-server JSON-RPC protocol. Provides both async and sync clients with full type safety via pydantic models.

Package name: `codex-app-server-client`
Import path: `codex_app_server_client`

## Setup
```bash
uv sync --all-extras   # install all deps including dev tools
```
Requires Python ≥ 3.11.

## Dev Commands

Use the Makefile (preferred):
```bash
make install      # uv sync --all-extras
make test         # uv run pytest --cov
make test-quick   # uv run pytest
make lint         # uv run ruff check src/ tests/
make format       # uv run ruff format src/ tests/
make type-check   # uv run mypy src/
make fix          # uv run ruff check --fix src/ tests/
make pre-commit   # run format-check, lint, type-check, test
make clean        # remove cache files
```

Or run `uv` commands directly:
```bash
uv run pytest                        # run tests
uv run pytest --cov                  # run tests with coverage
uv run ruff check src/ tests/        # lint
uv run ruff format src/ tests/       # format
uv run mypy src/                     # typecheck (strict mode)
```

## Architecture

### Package Layout
```
src/codex_app_server_client/
├── __init__.py              # Public re-exports
├── client.py                # High-level: CodexAppServer, SyncCodexAppServer
├── thread.py                # High-level: AsyncThread, SyncThread, TurnResult
├── _async_client.py         # Low-level: AsyncCodexClient (full protocol surface)
├── _sync_client.py          # Low-level: SyncCodexClient (sync mirror)
├── protocol/
│   ├── jsonrpc.py           # JSON-RPC message types and parser
│   └── transport.py         # AsyncStdioTransport, SyncStdioTransport
└── types/
    ├── common.py            # CamelModel base, enums, InitializeResponse, SandboxPolicy, UserInput
    ├── threads.py           # ThreadInfo, TurnInfo, ThreadItem union (15 variants), params/responses
    ├── events.py            # 25+ notification event types, ThreadEvent union, parse_notification_event()
    ├── auth.py              # Account/login types
    ├── approvals.py         # Approval request/response models
    └── misc.py              # ModelList, CommandExec, Config, etc.
```

### Key Design Decisions
- **CamelModel base**: All wire-format models extend `CamelModel` which uses `alias_generator=_to_camel` for automatic snake_case ↔ camelCase conversion.
- **Discriminated unions**: `ThreadItem` (15 variants) and `ThreadEvent` (25+ variants) are Python type unions. Use `isinstance()` checks, not string matching.
- **Bidirectional JSON-RPC**: The protocol is bidirectional — the server sends requests to the client (approvals, tool calls). The client handles these via `on_server_request()` callbacks. Default behavior: auto-decline approvals.
- **No `"jsonrpc":"2.0"` on wire**: The Codex app-server omits the standard JSON-RPC version field.
- **Init handshake**: Every session starts with `initialize` request → `initialized` notification.
- **Async-first**: `AsyncCodexClient` uses `asyncio.subprocess`. `SyncCodexClient` mirrors it with `subprocess.Popen` + background reader thread.

## Coding Guidelines
- **Type checking**: mypy strict mode. All functions must have complete type annotations.
- **Linting**: ruff with E, W, F, I, B, C4, UP rules. Line length 120.
- **Wire types**: Always use pydantic `CamelModel` subclasses. Serialize with `model_dump(by_alias=True, exclude_none=True)`.
- **New notification types**: Add model in `types/events.py`, add to `ThreadEvent` union and `NOTIFICATION_TYPE_MAP`.
- **New protocol methods**: Add typed params/response in `types/`, add convenience method in both `_async_client.py` and `_sync_client.py`.
- **Tests**: Use pytest + pytest-asyncio. Tests live in `tests/`. Mock transports for client tests.
