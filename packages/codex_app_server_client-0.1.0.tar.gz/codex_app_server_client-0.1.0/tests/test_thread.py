"""Tests for the AsyncThread turn-watching logic."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock

import pytest

from codex_app_server_client.thread import AsyncThread, EventAction, TurnResult
from codex_app_server_client.types.events import (
    AgentMessageDeltaEvent,
    ItemCompletedEvent,
    ThreadEvent,
    ThreadTokenUsageUpdatedEvent,
    TurnCompletedEvent,
    TurnStartedEvent,
)
from codex_app_server_client.types.threads import (
    ThreadTokenUsage,
    TokenUsageBreakdown,
    TurnError,
    TurnInfo,
    TurnInterruptParams,
    TurnStartResponse,
    TurnStatus,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class FakeAsyncClient:
    """Minimal mock of AsyncCodexClient for thread tests.

    After ``turn_start()`` returns, all queued events are emitted (in order)
    via the registered global notification callback.
    """

    def __init__(self, events: list[tuple[str, ThreadEvent]]) -> None:
        self._global_notification_handlers: list[Any] = []
        self._events = events
        self.turn_start = AsyncMock(side_effect=self._emit_events)
        self.turn_interrupt = AsyncMock()

    def on_notification(self, method: str | None, callback: Any) -> None:
        if method is None:
            self._global_notification_handlers.append(callback)

    async def _emit_events(self, params: Any) -> TurnStartResponse:
        # Fire all queued events synchronously through the handler so they
        # land in the thread's queue before the read loop finishes.
        for method, event in self._events:
            for handler in list(self._global_notification_handlers):
                handler(method, event)
        return TurnStartResponse(turn=TurnInfo(id="t1", status=TurnStatus.IN_PROGRESS))


def _turn_started(thread_id: str = "th1", turn_id: str = "t1") -> tuple[str, TurnStartedEvent]:
    return (
        "turn/started",
        TurnStartedEvent(thread_id=thread_id, turn=TurnInfo(id=turn_id, status=TurnStatus.IN_PROGRESS)),
    )


def _turn_completed(
    thread_id: str = "th1",
    turn_id: str = "t1",
    status: TurnStatus = TurnStatus.COMPLETED,
    error: TurnError | None = None,
) -> tuple[str, TurnCompletedEvent]:
    return (
        "turn/completed",
        TurnCompletedEvent(thread_id=thread_id, turn=TurnInfo(id=turn_id, status=status, error=error)),
    )


def _delta(delta: str, thread_id: str = "th1", turn_id: str = "t1") -> tuple[str, AgentMessageDeltaEvent]:
    return ("item/agentMessage/delta", AgentMessageDeltaEvent(thread_id=thread_id, turn_id=turn_id, delta=delta))


def _item_completed(
    item: dict[str, Any],
    thread_id: str = "th1",
    turn_id: str = "t1",
) -> tuple[str, ItemCompletedEvent]:
    return ("item/completed", ItemCompletedEvent(thread_id=thread_id, turn_id=turn_id, item=item))


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestNormalCompletion:
    async def test_basic_turn(self) -> None:
        events = [
            _turn_started(),
            _item_completed({"type": "agentMessage", "id": "i1", "text": "Hello!"}),
            _turn_completed(),
        ]
        client = FakeAsyncClient(events)
        thread = AsyncThread(client=client, thread_id="th1")  # type: ignore[arg-type]
        result = await thread.run("Hi", timeout_s=5)

        assert isinstance(result, TurnResult)
        assert result.status == "completed"
        assert result.turn_id == "t1"
        assert result.final_response == "Hello!"
        assert len(result.items) == 1
        assert result.error is None

    async def test_usage_captured(self) -> None:
        usage = ThreadTokenUsage(
            total=TokenUsageBreakdown(total_tokens=100, input_tokens=80, output_tokens=20),
        )
        events = [
            _turn_started(),
            ("thread/tokenUsage/updated", ThreadTokenUsageUpdatedEvent(thread_id="th1", token_usage=usage)),
            _turn_completed(),
        ]
        client = FakeAsyncClient(events)
        thread = AsyncThread(client=client, thread_id="th1")  # type: ignore[arg-type]
        result = await thread.run("Hi", timeout_s=5)

        assert result.usage is not None
        assert result.usage.total.total_tokens == 100


class TestDeltaAggregation:
    async def test_deltas_form_streamed_response(self) -> None:
        events = [
            _turn_started(),
            _delta("Hello"),
            _delta(" world"),
            _turn_completed(),
        ]
        client = FakeAsyncClient(events)
        thread = AsyncThread(client=client, thread_id="th1")  # type: ignore[arg-type]
        result = await thread.run("Hi", timeout_s=5)

        assert result.streamed_response == "Hello world"
        # No item/completed text, so final_response falls back to streamed
        assert result.final_response == "Hello world"

    async def test_item_text_preferred_over_deltas(self) -> None:
        events = [
            _turn_started(),
            _delta("partial"),
            _item_completed({"type": "agentMessage", "id": "i1", "text": "Full response"}),
            _turn_completed(),
        ]
        client = FakeAsyncClient(events)
        thread = AsyncThread(client=client, thread_id="th1")  # type: ignore[arg-type]
        result = await thread.run("Hi", timeout_s=5)

        assert result.final_response == "Full response"
        assert result.streamed_response == "partial"


class TestFailedTurn:
    async def test_failed_status_and_error(self) -> None:
        err = TurnError(message="context window exceeded")
        events = [
            _turn_started(),
            _turn_completed(status=TurnStatus.FAILED, error=err),
        ]
        client = FakeAsyncClient(events)
        thread = AsyncThread(client=client, thread_id="th1")  # type: ignore[arg-type]
        result = await thread.run("Hi", timeout_s=5)

        assert result.status == "failed"
        assert result.error is not None
        assert result.error.message == "context window exceeded"


class TestInterruptedTurn:
    async def test_interrupted_status(self) -> None:
        events = [
            _turn_started(),
            _delta("partial"),
            _turn_completed(status=TurnStatus.INTERRUPTED),
        ]
        client = FakeAsyncClient(events)
        thread = AsyncThread(client=client, thread_id="th1")  # type: ignore[arg-type]
        result = await thread.run("Hi", timeout_s=5)

        assert result.status == "interrupted"
        assert result.streamed_response == "partial"


class TestCorrelationFiltering:
    async def test_different_thread_ignored(self) -> None:
        """Events for a different thread_id are filtered out."""
        events = [
            _turn_started(),
            # This item belongs to a different thread — should be ignored
            _item_completed({"type": "agentMessage", "id": "i1", "text": "wrong"}, thread_id="other"),
            _item_completed({"type": "agentMessage", "id": "i2", "text": "right"}, thread_id="th1"),
            _turn_completed(),
        ]
        client = FakeAsyncClient(events)
        thread = AsyncThread(client=client, thread_id="th1")  # type: ignore[arg-type]
        result = await thread.run("Hi", timeout_s=5)

        assert result.final_response == "right"
        # Only the matching item should be collected
        assert len(result.items) == 1

    async def test_different_turn_ignored(self) -> None:
        """Events for a different turn_id (after turn/started) are filtered out."""
        events = [
            _turn_started(turn_id="t1"),
            _item_completed({"type": "agentMessage", "id": "i1", "text": "wrong"}, turn_id="t_other"),
            _item_completed({"type": "agentMessage", "id": "i2", "text": "right"}, turn_id="t1"),
            _turn_completed(turn_id="t1"),
        ]
        client = FakeAsyncClient(events)
        thread = AsyncThread(client=client, thread_id="th1")  # type: ignore[arg-type]
        result = await thread.run("Hi", timeout_s=5)

        assert result.final_response == "right"
        assert len(result.items) == 1


class TestCallbackInterrupt:
    async def test_interrupt_on_blocked_item(self) -> None:
        """on_event returning INTERRUPT triggers turn_interrupt."""
        events = [
            _turn_started(),
            _item_completed({"type": "commandExecution", "id": "i1", "command": "rm -rf /"}),
            _turn_completed(status=TurnStatus.INTERRUPTED),
        ]
        client = FakeAsyncClient(events)
        thread = AsyncThread(client=client, thread_id="th1")  # type: ignore[arg-type]

        seen_events: list[str] = []

        def policy_callback(method: str, event: ThreadEvent) -> EventAction | None:
            seen_events.append(method)
            if isinstance(event, ItemCompletedEvent):
                item = event.item if isinstance(event.item, dict) else {}
                if item.get("type") == "commandExecution":
                    return EventAction.INTERRUPT
            return None

        result = await thread.run("Do something dangerous", on_event=policy_callback, timeout_s=5)

        assert result.status == "interrupted"
        assert client.turn_interrupt.await_count == 1
        # Verify the interrupt was called with correct params
        call_args = client.turn_interrupt.call_args[0][0]
        assert isinstance(call_args, TurnInterruptParams)
        assert call_args.thread_id == "th1"
        assert call_args.turn_id == "t1"
        assert len(seen_events) >= 2  # at least turn/started + item/completed

    async def test_interrupt_only_called_once(self) -> None:
        """Multiple INTERRUPT returns should only trigger one turn_interrupt call."""
        events = [
            _turn_started(),
            _item_completed({"type": "commandExecution", "id": "i1", "command": "cmd1"}),
            _item_completed({"type": "commandExecution", "id": "i2", "command": "cmd2"}),
            _turn_completed(status=TurnStatus.INTERRUPTED),
        ]
        client = FakeAsyncClient(events)
        thread = AsyncThread(client=client, thread_id="th1")  # type: ignore[arg-type]

        def always_interrupt(method: str, event: ThreadEvent) -> EventAction | None:
            if isinstance(event, ItemCompletedEvent):
                return EventAction.INTERRUPT
            return None

        await thread.run("x", on_event=always_interrupt, timeout_s=5)
        assert client.turn_interrupt.await_count == 1

    async def test_continue_does_not_interrupt(self) -> None:
        """on_event returning CONTINUE (or None) does not trigger interrupt."""
        events = [
            _turn_started(),
            _item_completed({"type": "agentMessage", "id": "i1", "text": "ok"}),
            _turn_completed(),
        ]
        client = FakeAsyncClient(events)
        thread = AsyncThread(client=client, thread_id="th1")  # type: ignore[arg-type]

        def noop_callback(method: str, event: ThreadEvent) -> EventAction | None:
            return EventAction.CONTINUE

        result = await thread.run("Hi", on_event=noop_callback, timeout_s=5)
        assert result.status == "completed"
        assert client.turn_interrupt.await_count == 0


class TestTimeout:
    async def test_timeout_raises(self) -> None:
        """Turn that never completes should raise TimeoutError."""
        # Only emit turn/started — no turn/completed
        events = [_turn_started()]
        client = FakeAsyncClient(events)
        thread = AsyncThread(client=client, thread_id="th1")  # type: ignore[arg-type]

        with pytest.raises(TimeoutError, match="did not complete"):
            await thread.run("Hi", timeout_s=0.1)
