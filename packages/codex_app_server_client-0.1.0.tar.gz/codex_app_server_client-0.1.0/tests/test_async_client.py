"""Tests for AsyncCodexClient using mocked transport."""

from __future__ import annotations

import asyncio
from typing import Any
from unittest.mock import AsyncMock, patch

import pytest

from codex_app_server_client._async_client import AsyncCodexClient
from codex_app_server_client.types.events import TurnCompletedEvent


@pytest.fixture
def client() -> AsyncCodexClient:
    return AsyncCodexClient(codex_bin="/fake/codex")


class TestAsyncCodexClientInit:
    def test_not_started_initially(self, client: AsyncCodexClient) -> None:
        assert not client.is_started

    def test_default_properties(self) -> None:
        c = AsyncCodexClient()
        assert not c.is_started


class TestAsyncCodexClientHandshake:
    async def test_start_performs_handshake(self, client: AsyncCodexClient) -> None:
        """Verify start() sends initialize request and initialized notification."""
        messages_written: list[dict[str, Any]] = []
        read_idx = 0
        # Fake responses: first call returns the initialize response,
        # subsequent calls block forever (simulating no more messages).
        init_response = {
            "id": 1,
            "result": {
                "userAgent": "codex-app-server/0.1.0",
            },
        }

        async def fake_read() -> dict[str, Any] | None:
            nonlocal read_idx
            read_idx += 1
            if read_idx == 1:
                return init_response
            # Block to simulate waiting for messages
            await asyncio.sleep(100)
            return None

        async def fake_write(payload: dict[str, Any]) -> None:
            messages_written.append(payload)

        with (
            patch.object(client._transport, "start", new_callable=AsyncMock),
            patch.object(client._transport, "read_line", side_effect=fake_read),
            patch.object(client._transport, "write", side_effect=fake_write),
            patch.object(client._transport, "close", new_callable=AsyncMock),
        ):
            resp = await client.start()
            assert client.is_started
            assert resp.user_agent == "codex-app-server/0.1.0"

            # Should have written: initialize request, then initialized notification
            assert len(messages_written) >= 2
            assert messages_written[0]["method"] == "initialize"
            assert "id" in messages_written[0]
            assert messages_written[1]["method"] == "initialized"
            assert "id" not in messages_written[1]

            await client.close()
            assert not client.is_started


class TestAsyncCodexClientNotifications:
    async def test_notification_handler_called(self, client: AsyncCodexClient) -> None:
        """Verify notification handlers are called when events arrive."""
        received_events: list[Any] = []

        def handler(method: str, event: Any) -> None:
            received_events.append((method, event))

        client.on_notification("turn/completed", handler)

        # Simulate the message handling directly
        from codex_app_server_client.protocol.jsonrpc import JSONRPCNotification

        notification = JSONRPCNotification(
            method="turn/completed",
            params={"threadId": "th1", "turn": {"id": "t1", "status": "completed"}},
        )
        await client._handle_notification(notification)

        assert len(received_events) == 1
        method, event = received_events[0]
        assert method == "turn/completed"
        assert isinstance(event, TurnCompletedEvent)

    async def test_global_handler_receives_all(self, client: AsyncCodexClient) -> None:
        received: list[str] = []

        def handler(method: str, event: Any) -> None:
            received.append(method)

        client.on_notification(None, handler)

        from codex_app_server_client.protocol.jsonrpc import JSONRPCNotification

        n1 = JSONRPCNotification(
            method="turn/completed", params={"threadId": "th1", "turn": {"id": "t1", "status": "completed"}}
        )
        n2 = JSONRPCNotification(method="item/agentMessage/delta", params={"delta": "hi"})

        await client._handle_notification(n1)
        await client._handle_notification(n2)

        assert len(received) == 2
        assert "turn/completed" in received
        assert "item/agentMessage/delta" in received


class TestAsyncCodexClientServerRequests:
    async def test_default_decline_approval(self, client: AsyncCodexClient) -> None:
        """Unhandled approval requests should be auto-declined."""
        written: list[dict[str, Any]] = []

        async def fake_write(payload: dict[str, Any]) -> None:
            written.append(payload)

        with patch.object(client._transport, "write", side_effect=fake_write):
            from codex_app_server_client.protocol.jsonrpc import JSONRPCRequest

            req = JSONRPCRequest(id=42, method="item/commandExecution/requestApproval", params={"command": "rm -rf /"})
            await client._handle_server_request(req)

        assert len(written) == 1
        assert written[0]["id"] == 42
        assert written[0]["result"]["decision"] == "decline"

    async def test_custom_handler_overrides_default(self, client: AsyncCodexClient) -> None:
        written: list[dict[str, Any]] = []

        async def fake_write(payload: dict[str, Any]) -> None:
            written.append(payload)

        async def approve_handler(method: str, params: dict[str, Any]) -> dict[str, Any]:
            return {"decision": "approve"}

        client.on_server_request("item/commandExecution/requestApproval", approve_handler)

        with patch.object(client._transport, "write", side_effect=fake_write):
            from codex_app_server_client.protocol.jsonrpc import JSONRPCRequest

            req = JSONRPCRequest(id=43, method="item/commandExecution/requestApproval", params={"command": "ls"})
            await client._handle_server_request(req)

        assert len(written) == 1
        assert written[0]["result"]["decision"] == "approve"
