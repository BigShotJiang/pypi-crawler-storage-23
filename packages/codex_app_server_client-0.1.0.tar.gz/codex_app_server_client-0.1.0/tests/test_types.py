"""Tests for type models: serialization, aliases, discriminated unions."""

from __future__ import annotations

from pydantic import TypeAdapter

from codex_app_server_client.types.common import (
    ApprovalPolicySimple,
    ClientInfo,
    InitializeCapabilities,
    Personality,
    ReasoningEffort,
    TextInput,
)
from codex_app_server_client.types.events import (
    AgentMessageDeltaEvent,
    ConfigWarningEvent,
    ContextCompactedEvent,
    DeprecationNoticeEvent,
    ErrorNotificationEvent,
    FuzzyFileSearchSessionCompletedEvent,
    FuzzyFileSearchSessionUpdatedEvent,
    ItemCompletedEvent,
    McpToolCallProgressEvent,
    RawResponseItemCompletedEvent,
    TerminalInteractionEvent,
    ThreadNameUpdatedEvent,
    ThreadStartedEvent,
    TurnCompletedEvent,
    WindowsSandboxSetupCompletedEvent,
    WindowsWorldWritableWarningEvent,
    parse_notification_event,
)
from codex_app_server_client.types.threads import (
    AgentMessageItem,
    CommandExecutionItem,
    FileChangeItem,
    ThreadInfo,
    ThreadItem,
    ThreadStartParams,
    TokenUsage,
    TurnInfo,
    TurnStartParams,
    TurnStatus,
    UserMessageItem,
)


class TestCamelModelSerialization:
    def test_client_info_camel_alias(self) -> None:
        info = ClientInfo(name="test", title="Test App", version="1.0")
        dumped = info.model_dump(by_alias=True)
        assert dumped == {"name": "test", "title": "Test App", "version": "1.0"}

    def test_initialize_capabilities_camel(self) -> None:
        caps = InitializeCapabilities(experimental_api=True, opt_out_notification_methods=["foo/bar"])
        dumped = caps.model_dump(by_alias=True, exclude_none=True)
        assert "experimentalApi" in dumped
        assert "optOutNotificationMethods" in dumped

    def test_thread_start_params_camel(self) -> None:
        params = ThreadStartParams(model="gpt-5.2-codex", cwd="/tmp", approval_policy=ApprovalPolicySimple.ON_FAILURE)
        dumped = params.model_dump(by_alias=True, exclude_none=True)
        assert dumped["approvalPolicy"] == "on-failure"
        assert dumped["model"] == "gpt-5.2-codex"
        assert dumped["cwd"] == "/tmp"

    def test_turn_start_params_camel(self) -> None:
        params = TurnStartParams(
            thread_id="t1",
            input=[TextInput(type="text", text="hello")],
            effort=ReasoningEffort.HIGH,
        )
        dumped = params.model_dump(by_alias=True, exclude_none=True)
        assert dumped["threadId"] == "t1"
        assert dumped["effort"] == "high"
        assert dumped["input"][0]["text"] == "hello"

    def test_token_usage(self) -> None:
        usage = TokenUsage(input_tokens=100, cached_input_tokens=50, output_tokens=200)
        dumped = usage.model_dump(by_alias=True)
        assert dumped["inputTokens"] == 100
        assert dumped["cachedInputTokens"] == 50
        assert dumped["outputTokens"] == 200


class TestThreadItemDiscriminatedUnion:
    def test_parse_user_message(self) -> None:
        data = {"type": "userMessage", "id": "u1", "content": [{"type": "text", "text": "hi"}]}
        adapter = TypeAdapter(ThreadItem)
        item = adapter.validate_python(data)
        assert isinstance(item, UserMessageItem)
        assert item.id == "u1"

    def test_parse_agent_message(self) -> None:
        data = {"type": "agentMessage", "id": "a1", "text": "Hello!"}
        adapter = TypeAdapter(ThreadItem)
        item = adapter.validate_python(data)
        assert isinstance(item, AgentMessageItem)
        assert item.text == "Hello!"

    def test_parse_command_execution(self) -> None:
        data = {
            "type": "commandExecution",
            "id": "c1",
            "command": "ls -la",
            "status": "completed",
            "exitCode": 0,
        }
        adapter = TypeAdapter(ThreadItem)
        item = adapter.validate_python(data)
        assert isinstance(item, CommandExecutionItem)
        assert item.exit_code == 0

    def test_parse_file_change(self) -> None:
        data = {
            "type": "fileChange",
            "id": "f1",
            "changes": [{"path": "foo.py", "kind": "update", "diff": "+hello"}],
            "status": "completed",
        }
        adapter = TypeAdapter(ThreadItem)
        item = adapter.validate_python(data)
        assert isinstance(item, FileChangeItem)
        assert len(item.changes) == 1
        assert item.changes[0].path == "foo.py"


class TestEventParsing:
    def test_parse_thread_started(self) -> None:
        params = {"thread": {"id": "t123", "preview": "test"}}
        event = parse_notification_event("thread/started", params)
        assert isinstance(event, ThreadStartedEvent)
        assert event.thread.id == "t123"

    def test_parse_turn_completed(self) -> None:
        params = {
            "threadId": "th1",
            "turn": {
                "id": "turn1",
                "status": "completed",
            },
        }
        event = parse_notification_event("turn/completed", params)
        assert isinstance(event, TurnCompletedEvent)
        assert event.thread_id == "th1"
        assert event.turn.status == TurnStatus.COMPLETED

    def test_parse_agent_message_delta(self) -> None:
        params = {"itemId": "a1", "delta": "chunk"}
        event = parse_notification_event("item/agentMessage/delta", params)
        assert isinstance(event, AgentMessageDeltaEvent)
        assert event.delta == "chunk"
        assert event.item_id == "a1"

    def test_parse_item_completed(self) -> None:
        params = {"item": {"type": "agentMessage", "id": "a1", "text": "Done"}}
        event = parse_notification_event("item/completed", params)
        assert isinstance(event, ItemCompletedEvent)
        assert event.item["type"] == "agentMessage"

    def test_unknown_method_returns_none(self) -> None:
        event = parse_notification_event("unknown/method", {})
        assert event is None


class TestEnums:
    def test_approval_policy_values(self) -> None:
        assert ApprovalPolicySimple.NEVER.value == "never"
        assert ApprovalPolicySimple.ON_FAILURE.value == "on-failure"
        assert ApprovalPolicySimple.ON_REQUEST.value == "on-request"

    def test_personality_values(self) -> None:
        assert Personality.FRIENDLY.value == "friendly"
        assert Personality.PRAGMATIC.value == "pragmatic"

    def test_reasoning_effort_values(self) -> None:
        assert ReasoningEffort.LOW.value == "low"
        assert ReasoningEffort.HIGH.value == "high"

    def test_turn_status_values(self) -> None:
        assert TurnStatus.COMPLETED.value == "completed"
        assert TurnStatus.FAILED.value == "failed"
        assert TurnStatus.INTERRUPTED.value == "interrupted"


class TestThreadInfo:
    def test_thread_info_parse(self) -> None:
        data = {
            "id": "t1",
            "preview": "hello world",
            "createdAt": 1700000000,
            "status": {"type": "idle"},
        }
        info = ThreadInfo.model_validate(data)
        assert info.id == "t1"
        assert info.preview == "hello world"
        assert info.created_at == 1700000000
        assert info.status is not None
        assert info.status.type == "idle"

    def test_turn_info_with_error(self) -> None:
        data = {
            "id": "turn1",
            "status": "failed",
            "error": {"message": "boom"},
        }
        turn = TurnInfo.model_validate(data)
        assert turn.status == TurnStatus.FAILED
        assert turn.error is not None
        assert turn.error.message == "boom"


class TestNewNotificationEvents:
    """Tests for the 12 newly added notification event types."""

    def test_parse_error_notification(self) -> None:
        params = {
            "threadId": "th1",
            "turnId": "tu1",
            "error": {"message": "rate limit"},
            "willRetry": True,
        }
        event = parse_notification_event("error", params)
        assert isinstance(event, ErrorNotificationEvent)
        assert event.thread_id == "th1"
        assert event.will_retry is True
        assert event.error.message == "rate limit"

    def test_parse_config_warning(self) -> None:
        params = {"summary": "bad key", "details": "key X deprecated", "path": "/config.yaml"}
        event = parse_notification_event("configWarning", params)
        assert isinstance(event, ConfigWarningEvent)
        assert event.summary == "bad key"
        assert event.path == "/config.yaml"

    def test_parse_deprecation_notice(self) -> None:
        params = {"summary": "v1 deprecated"}
        event = parse_notification_event("deprecationNotice", params)
        assert isinstance(event, DeprecationNoticeEvent)
        assert event.summary == "v1 deprecated"

    def test_parse_thread_name_updated(self) -> None:
        params = {"threadId": "th1", "threadName": "My Thread"}
        event = parse_notification_event("thread/name/updated", params)
        assert isinstance(event, ThreadNameUpdatedEvent)
        assert event.thread_name == "My Thread"

    def test_parse_terminal_interaction(self) -> None:
        params = {"threadId": "th1", "turnId": "tu1", "itemId": "i1", "processId": "p1", "stdin": "y\n"}
        event = parse_notification_event("item/commandExecution/terminalInteraction", params)
        assert isinstance(event, TerminalInteractionEvent)
        assert event.process_id == "p1"
        assert event.stdin == "y\n"

    def test_parse_mcp_tool_call_progress(self) -> None:
        params = {"threadId": "th1", "turnId": "tu1", "itemId": "i1", "message": "50%"}
        event = parse_notification_event("item/mcpToolCall/progress", params)
        assert isinstance(event, McpToolCallProgressEvent)
        assert event.message == "50%"

    def test_parse_windows_sandbox_setup_completed(self) -> None:
        params = {"mode": "elevated", "success": True}
        event = parse_notification_event("windowsSandbox/setupCompleted", params)
        assert isinstance(event, WindowsSandboxSetupCompletedEvent)
        assert event.success is True

    def test_parse_windows_world_writable_warning(self) -> None:
        params = {"samplePaths": ["/tmp/foo"], "extraCount": 5, "failedScan": False}
        event = parse_notification_event("windows/worldWritableWarning", params)
        assert isinstance(event, WindowsWorldWritableWarningEvent)
        assert event.sample_paths == ["/tmp/foo"]
        assert event.extra_count == 5

    def test_parse_raw_response_item_completed(self) -> None:
        params = {"threadId": "th1", "turnId": "tu1", "item": {"foo": "bar"}}
        event = parse_notification_event("rawResponseItem/completed", params)
        assert isinstance(event, RawResponseItemCompletedEvent)
        assert event.item == {"foo": "bar"}

    def test_parse_context_compacted(self) -> None:
        params = {"threadId": "th1", "turnId": "tu1"}
        event = parse_notification_event("thread/compacted", params)
        assert isinstance(event, ContextCompactedEvent)
        assert event.thread_id == "th1"

    def test_parse_fuzzy_search_session_updated(self) -> None:
        params = {
            "sessionId": "s1",
            "query": "foo",
            "files": [{"root": "/", "path": "foo.py", "fileName": "foo.py", "score": 100}],
        }
        event = parse_notification_event("fuzzyFileSearch/sessionUpdated", params)
        assert isinstance(event, FuzzyFileSearchSessionUpdatedEvent)
        assert event.session_id == "s1"
        assert len(event.files) == 1
        assert event.files[0].score == 100

    def test_parse_fuzzy_search_session_completed(self) -> None:
        params = {"sessionId": "s1"}
        event = parse_notification_event("fuzzyFileSearch/sessionCompleted", params)
        assert isinstance(event, FuzzyFileSearchSessionCompletedEvent)
        assert event.session_id == "s1"
