"""Tests for JSON-RPC protocol layer."""

from __future__ import annotations

import pytest

from codex_app_server_client.protocol.jsonrpc import (
    JSONRPCError,
    JSONRPCNotification,
    JSONRPCRequest,
    JSONRPCResponse,
    parse_jsonrpc_message,
)


class TestParseJSONRPCMessage:
    def test_response_with_result(self) -> None:
        data = {"id": 1, "result": {"foo": "bar"}}
        msg = parse_jsonrpc_message(data)
        assert isinstance(msg, JSONRPCResponse)
        assert msg.id == 1
        assert msg.result == {"foo": "bar"}

    def test_response_with_null_result(self) -> None:
        data = {"id": 1, "result": None}
        msg = parse_jsonrpc_message(data)
        assert isinstance(msg, JSONRPCResponse)
        assert msg.result is None

    def test_error_response(self) -> None:
        data = {"id": 2, "error": {"code": -32600, "message": "Invalid Request"}}
        msg = parse_jsonrpc_message(data)
        assert isinstance(msg, JSONRPCError)
        assert msg.id == 2
        assert msg.error.code == -32600
        assert msg.error.message == "Invalid Request"

    def test_request_with_params(self) -> None:
        data = {"id": 3, "method": "item/commandExecution/requestApproval", "params": {"command": "ls"}}
        msg = parse_jsonrpc_message(data)
        assert isinstance(msg, JSONRPCRequest)
        assert msg.id == 3
        assert msg.method == "item/commandExecution/requestApproval"
        assert msg.params == {"command": "ls"}

    def test_notification(self) -> None:
        data = {"method": "thread/started", "params": {"thread": {"id": "abc"}}}
        msg = parse_jsonrpc_message(data)
        assert isinstance(msg, JSONRPCNotification)
        assert msg.method == "thread/started"
        assert msg.params == {"thread": {"id": "abc"}}

    def test_notification_without_params(self) -> None:
        data = {"method": "initialized"}
        msg = parse_jsonrpc_message(data)
        assert isinstance(msg, JSONRPCNotification)
        assert msg.method == "initialized"
        assert msg.params is None

    def test_invalid_message_raises(self) -> None:
        with pytest.raises(ValueError, match="Cannot classify"):
            parse_jsonrpc_message({"foo": "bar"})

    def test_response_with_jsonrpc_field(self) -> None:
        """The app-server omits jsonrpc but some messages might include it."""
        data = {"jsonrpc": "2.0", "id": 5, "result": {}}
        msg = parse_jsonrpc_message(data)
        assert isinstance(msg, JSONRPCResponse)
        assert msg.id == 5

    def test_error_with_data(self) -> None:
        data = {"id": 6, "error": {"code": -32603, "message": "Internal", "data": {"detail": "oops"}}}
        msg = parse_jsonrpc_message(data)
        assert isinstance(msg, JSONRPCError)
        assert msg.error.data == {"detail": "oops"}

    def test_request_without_params(self) -> None:
        data = {"id": 10, "method": "shutdown"}
        msg = parse_jsonrpc_message(data)
        assert isinstance(msg, JSONRPCRequest)
        assert msg.params is None
