# Design Document — Codex App Server Client SDK

## Overview

This SDK provides a Python client for the Codex app-server, an AI agent runtime that executes turns (request/response cycles) within persistent conversation threads. The SDK abstracts the JSON-RPC protocol, subprocess management, and event streaming, exposing both high-level ergonomic APIs and low-level protocol access.

**Problem solved**: Building an AI application requires managing:
1. Subprocess lifecycle (spawn, stdio communication, graceful shutdown)
2. Bidirectional JSON-RPC (requests, responses, notifications, server-initiated approvals)
3. Event streaming and real-time delta aggregation
4. Thread/turn correlation and state tracking
5. Type-safe protocol interactions

This SDK handles all of the above so you can focus on application logic.

## Core Concepts

### Thread
A **thread** is a persistent conversation context. It stores the full history of turns, maintains working directory state, and can be resumed across sessions. Think of it as a stateful chat session with filesystem access.

### Turn
A **turn** is a single request/response cycle within a thread. You send user input, the agent reasons and acts (file edits, command execution, web search), and returns a response. Turns produce **items** (messages, plans, command outputs) and emit real-time **events**.

### Events
During turn execution, the server streams **notifications** (events) to the client:
- `turn/started` — turn begins, provides turn ID
- `item/agentMessage/delta` — streaming text chunks
- `item/completed` — an item (message, command, file edit) finishes
- `turn/completed` — turn ends with status (`completed`, `interrupted`, `failed`)

The SDK aggregates these into structured `TurnResult` objects.

### Bidirectional Protocol
The protocol is bidirectional: the server can send **requests** to the client, primarily for **approval workflows**. Example: before executing `rm -rf /`, the server sends `commandExecution/approve` and waits for the client to respond `{decision: "approve"}` or `{decision: "decline"}`.

## Architecture

The SDK is organized in four layers, each with clear responsibilities:

```
┌────────────────────────────────────────────────────────────┐
│  High-level API (client.py, thread.py)                     │
│  CodexAppServer, AsyncThread, TurnResult                   │
│  WHY: Ergonomic wrappers. Hide protocol details, focus on  │
│       turns and conversations.                              │
├────────────────────────────────────────────────────────────┤
│  Low-level Client (_async_client.py, _sync_client.py)      │
│  AsyncCodexClient, SyncCodexClient                         │
│  WHY: Full protocol surface. Request/response correlation, │
│       notification routing, server request handling.        │
├────────────────────────────────────────────────────────────┤
│  Protocol Layer (protocol/jsonrpc.py)                      │
│  JSONRPCRequest, JSONRPCResponse, parse_jsonrpc_message()  │
│  WHY: Parse non-standard JSON-RPC (no "jsonrpc" field).    │
│       Discriminate message types by field presence.         │
├────────────────────────────────────────────────────────────┤
│  Transport Layer (protocol/transport.py)                   │
│  AsyncStdioTransport, SyncStdioTransport                   │
│  WHY: Manage codex subprocess, read/write newline-delimited│
│       JSON over stdin/stdout.                               │
└────────────────────────────────────────────────────────────┘
```

### Why Four Layers?

1. **Transport**: Isolates subprocess mechanics. Async uses `asyncio.create_subprocess_exec`, sync uses `subprocess.Popen` + background thread.
2. **Protocol**: Handles JSON-RPC quirks (missing `"jsonrpc":"2.0"` field). Enables testing without subprocess.
3. **Low-level client**: Provides typed wrappers for every protocol method. Manages pending requests (futures/condition variables), dispatches notifications to callbacks.
4. **High-level API**: Hides protocol details. `thread.run(input)` internally calls `turn_start()`, subscribes to events, aggregates deltas, waits for `turn/completed`, and returns a `TurnResult`.

## Turn Lifecycle Deep Dive

When you call `await thread.run("Hello")`, here's what happens:

### 1. Setup
- Registers a global notification handler that filters events by `thread_id`
- Calls `client.turn_start(TurnStartParams(thread_id=..., input=[TextInput(text="Hello")], ...))`
- Creates an internal event queue

### 2. Event Loop
The SDK enters a loop, waiting for events:

```python
while not turn_done:
    method, event = await event_queue.get()
    
    # Capture turn_id from first event
    if isinstance(event, TurnStartedEvent):
        active_turn_id = event.turn.id
    
    # Filter by turn_id once known
    if active_turn_id and event.turn_id != active_turn_id:
        continue  # ignore events from other turns
    
    # Invoke user callback
    if on_event:
        action = on_event(method, event)
        if action == EventAction.INTERRUPT and not interrupted:
            await client.turn_interrupt(...)
            interrupted = True
    
    # Aggregate deltas
    if isinstance(event, AgentMessageDeltaEvent):
        delta_chunks.append(event.delta)
    
    # Collect completed items
    if isinstance(event, ItemCompletedEvent):
        items.append(event.item)
        if event.item.get("type") == "agentMessage":
            final_response = event.item.get("text")
    
    # Check for turn end
    if isinstance(event, TurnCompletedEvent):
        status = event.turn.status
        error = event.turn.error
        break
```

### 3. Result Assembly
- `final_response` = last `agentMessage` item text, or fall back to aggregated `delta_chunks`
- `streamed_response` = `"".join(delta_chunks)`
- Return `TurnResult(status, turn_id, items, final_response, streamed_response, usage, error)`

### 4. Cleanup
- Unregister the notification handler
- Return control to caller

### Event Filtering (Turn-ID Correlation)

Why filter by `turn_id`? Because notifications from *other* turns (e.g., background compaction) can arrive while your turn is running. The SDK:

1. Filters by `thread_id` first (events have `thread_id` field)
2. Captures `turn_id` from `TurnStartedEvent`
3. Once `turn_id` is known, ignores events with different `turn_id`

This ensures you only see events for *your* turn.

### Delta Aggregation

As the agent streams its response, `item/agentMessage/delta` events arrive with text chunks:

```json
{"method": "item/agentMessage/delta", "params": {"delta": "Hello"}}
{"method": "item/agentMessage/delta", "params": {"delta": " world"}}
```

The SDK accumulates these into `streamed_response = "Hello world"`. When `item/completed` arrives with the final `agentMessage` item, that item's `text` field becomes `final_response`. If no `agentMessage` item completes (rare), `final_response` falls back to `streamed_response`.

### Interrupt Mechanism

If the `on_event` callback returns `EventAction.INTERRUPT`, the SDK:

1. Calls `client.turn_interrupt(TurnInterruptParams(thread_id, turn_id))` **once**
2. Sets `interrupted = True` to prevent duplicate calls
3. Continues draining events until `turn/completed` arrives with `status = "interrupted"`

The turn doesn't stop immediately — it transitions to interrupted state and finishes gracefully.

## Type System

### CamelModel: Snake Case ↔ Camel Case

All protocol models extend `CamelModel`:

```python
class CamelModel(BaseModel):
    model_config = ConfigDict(
        populate_by_name=True,
        alias_generator=_to_camel,  # converts snake_case → camelCase
    )
```

Python uses `snake_case`, JSON-RPC uses `camelCase`. The SDK handles conversion automatically:

```python
params = TurnStartParams(thread_id="t1", input=[...])
wire = params.model_dump(by_alias=True, exclude_none=True)
# wire = {"threadId": "t1", "input": [...]}
```

### Discriminated Unions

#### ThreadItem (15 variants)

`ThreadItem` is a union of 15 item types:

```python
ThreadItem = (
    UserMessageItem
    | AgentMessageItem
    | PlanItem
    | ReasoningItem
    | CommandExecutionItem
    | FileChangeItem
    | McpToolCallItem
    | ...
)
```

Each variant has a `type` field. Pydantic uses a discriminator to deserialize the correct class. In your code, use `isinstance()` checks:

```python
for item in result.items:
    if isinstance(item, dict) and item.get("type") == "commandExecution":
        print(f"Command: {item.get('command')}")
```

(Items are dicts in `TurnResult.items` because they come from `ItemCompletedEvent.item`, which is `dict[str, Any]` to allow forward compatibility.)

#### ThreadEvent (25+ variants)

Similarly, `ThreadEvent` is a union of notification event types:

```python
ThreadEvent = (
    TurnStartedEvent
    | TurnCompletedEvent
    | ItemCompletedEvent
    | AgentMessageDeltaEvent
    | ...
)
```

The SDK parses notifications via `parse_notification_event(method, params)`, which looks up the event class in `NOTIFICATION_TYPE_MAP`:

```python
NOTIFICATION_TYPE_MAP = {
    "turn/started": TurnStartedEvent,
    "turn/completed": TurnCompletedEvent,
    "item/agentMessage/delta": AgentMessageDeltaEvent,
    ...
}
```

When you register a notification handler, you receive typed events:

```python
def handler(method: str, event: ThreadEvent) -> None:
    if isinstance(event, AgentMessageDeltaEvent):
        print(event.delta)
```

## Protocol Quirks

The Codex app-server protocol is JSON-RPC-like but non-standard:

1. **No `"jsonrpc": "2.0"` field**: Standard JSON-RPC includes this. Codex omits it.
2. **Message discrimination by field presence**:
   - Request: has `id` + `method`
   - Response: has `id` + (`result` or `error`)
   - Notification: has `method`, no `id`
3. **Bidirectional**: Both client and server can send requests.
4. **Initialization handshake**: Must call `initialize` → `initialized` before other methods.

The `parse_jsonrpc_message()` function handles discrimination:

```python
if "id" in msg and "method" in msg:
    return JSONRPCRequest(...)
elif "id" in msg and ("result" in msg or "error" in msg):
    return JSONRPCResponse(...)
elif "method" in msg:
    return JSONRPCNotification(...)
```

## Sync vs Async

The SDK provides mirrored APIs for both async and sync usage.

### When to Use Each

- **Async**: If your application uses `asyncio`, FastAPI, or other async frameworks.
- **Sync**: For traditional synchronous Python (Flask, CLI tools, Jupyter notebooks).

### Implementation Differences

| Aspect | Async | Sync |
|--------|-------|------|
| Subprocess | `asyncio.create_subprocess_exec` | `subprocess.Popen` |
| Reader loop | `asyncio.Task` | `threading.Thread` |
| Pending requests | `asyncio.Future` | `threading.Condition` + dict |
| Notification queue | `asyncio.Queue` | `queue.Queue` |
| API calls | `await client.request(...)` | `client.request(...)` |

### Shared API Surface

Both clients expose identical methods. Example:

```python
# Async
client = AsyncCodexClient()
await client.start()
resp = await client.thread_start()

# Sync
client = SyncCodexClient()
client.start()
resp = client.thread_start()
```

The only difference is the presence (or absence) of `await`.

## Extension Points

The SDK is designed to be extended:

### Custom Event Handlers

Register callbacks for specific notification types:

```python
def on_item_completed(method: str, event: ThreadEvent) -> None:
    if isinstance(event, ItemCompletedEvent):
        log_item_to_database(event.item)

client.on_notification("item/completed", on_item_completed)
```

### Server Request Handlers

Handle bidirectional requests:

```python
async def custom_approval(method: str, params: dict) -> dict:
    if method == "commandExecution/approve":
        # custom approval logic
        return {"decision": "approve", "reason": "safe command"}
    return {"decision": "decline"}

client.on_server_request("commandExecution/approve", custom_approval)
```

### Policy Callbacks

Control turn execution in real-time:

```python
def policy(method: str, event: ThreadEvent) -> EventAction | None:
    if isinstance(event, ItemCompletedEvent):
        if event.item.get("type") == "commandExecution":
            return EventAction.INTERRUPT  # block all commands
    return None

result = await thread.run("Do something", on_event=policy)
```
