"""Prompt templates for different languages."""
