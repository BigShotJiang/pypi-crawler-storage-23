# from typing import Protocol
#
# from chap_core.datatypes import ClimateData, Shape
# from chap_core.time_period import TimePeriod
#
# __all__ = ["ClimateData", "Shape", "TimePeriod", "Protocol"]
#
#
