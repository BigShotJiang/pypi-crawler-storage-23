from .file_paths import get_results_path

__all__ = ["get_results_path"]
