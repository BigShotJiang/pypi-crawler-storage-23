from chap_core.runners.runner import Runner


class CondaRunner(Runner):
    def __init__(self, conda_yaml_file: str):
        pass
