from ..geometry import get_area_polygons

__all__ = ["get_area_polygons"]
