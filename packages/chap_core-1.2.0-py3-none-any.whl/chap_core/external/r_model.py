from pathlib import Path
from typing import TypeVar

from chap_core.datatypes import ClimateData, ClimateHealthTimeSeries, HealthData
from chap_core.spatio_temporal_data.temporal_dataclass import DataSet
from chap_core.time_period import Month
from chap_core.time_period.date_util_wrapper import TimeDelta


class ExternalRModel:
    def __init__(self, r_script: str, lead_time=Month, adaptors=None):
        self.r_script = r_script
        self.lead_time = lead_time
        self.adaptors = adaptors

    def get_predictions(self, train_data: ClimateHealthTimeSeries, future_climate_data: ClimateData) -> HealthData:  # type: ignore[empty-body]
        ...


FeatureType = TypeVar("FeatureType")


class ExternalLaggedRModel[FeatureType]:
    def __init__(
        self,
        script_file_name: str,
        data_type: type[FeatureType],
        tmp_dir: Path,
        lag_period: TimeDelta,
    ):
        self._script_file_name = script_file_name
        self._data_type = data_type
        self._tmp_dir = tmp_dir
        self._lag_period = lag_period
        self._saved_state = None
        self._model_filename = self._tmp_dir / "model.rds"

    def train(self, train_data: DataSet[FeatureType]):  # type: ignore[type-var]
        training_data_file = self._tmp_dir / "training_data.csv"
        train_data.to_csv(training_data_file)  # type: ignore[arg-type]
        end_timestamp = train_data.end_timestamp
        self._saved_state = train_data.restrict_time_period(end_timestamp - self._lag_period, None)  # type: ignore[call-arg, arg-type, assignment]
        self._run_train_script(self._script_file_name, training_data_file, self._model_filename)  # type: ignore[attr-defined]

    def predict(self, future_data: DataSet[FeatureType]) -> DataSet[FeatureType]:  # type: ignore[type-var]
        full_data = self._join_state_and_future(future_data)  # type: ignore[attr-defined]
        full_data_path = self._tmp_dir / "full_data.csv"
        full_data.to_csv(full_data_path)
        output_file = self._tmp_dir / "output.csv"
        self._run_predict_script(self._script_file_name, self._model_filename, full_data_path, output_file)  # type: ignore[attr-defined]
        return self._read_output(output_file)  # type: ignore[attr-defined, no-any-return]
