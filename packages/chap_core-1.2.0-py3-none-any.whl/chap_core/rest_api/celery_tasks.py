import inspect
import json
import logging
import os
from collections.abc import Callable
from datetime import datetime
from typing import TypeVar, cast

import celery
from celery import Celery, Task, shared_task
from celery.result import AsyncResult
from celery.utils.log import get_task_logger
from dotenv import find_dotenv, load_dotenv
from pydantic import BaseModel
from redis import Redis
from sqlalchemy import create_engine

from ..database.database import SessionWrapper
from ..log_config import CHAP_LOGS_DIR, get_status_logger

ReturnType = TypeVar("ReturnType")

# We use get_task_logger to ensure we get the Celery-friendly logger
# but you could also just use logging.getLogger(__name__) if you prefer.
logger = get_task_logger(__name__)
logger.setLevel(logging.INFO)


# Send database url in function queue call. Have a dict in module of database url to engines. Look up engine in dict
class JobDescription(BaseModel):
    id: str
    type: str
    name: str
    status: str
    start_time: str | None
    end_time: str | None
    result: str | None


def read_environment_variables():
    load_dotenv(find_dotenv())
    host = os.getenv("CELERY_BROKER", "redis://localhost:6379")
    return host


# Setup celery
url = read_environment_variables()
logger.info(f"Connecting to {url}")
app = Celery("worker", broker=url, backend=url)
app.conf.update(
    task_serializer="pickle",
    accept_content=["pickle"],  # Allow pickle serialization
    result_serializer="pickle",
    # Enables tracking of job lifecycle
    task_track_started=True,
    task_send_sent_event=True,
    worker_send_task_events=True,
)


# Setup Redis connection (for job metadata)
# TODO: switch to using utils.load_redis()?
redis_url = "redis" if "localhost" not in url else "localhost"
r = Redis(host=redis_url, port=6379, db=2, decode_responses=True)  # TODO: how to set this better?


# logger.warning("No database URL set")
# This is hacky, but defaults to using the test database. Should be synched with what is setup in conftest
# engine = create_engine("sqlite:///test.db", connect_args={"check_same_thread": False})


class TrackedTask(Task):
    def __call__(self, *args, **kwargs):
        # Extract the current task id
        task_id = self.request.id

        # Ensure logs directory exists
        CHAP_LOGS_DIR.mkdir(parents=True, exist_ok=True)

        # Create debug log file handler (full debug logs, server access only)
        debug_file_handler = logging.FileHandler(CHAP_LOGS_DIR / f"task_{task_id}.debug.txt")
        debug_formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
        debug_file_handler.setFormatter(debug_formatter)

        # Create status log file handler (user-facing progress, exposed via API)
        status_file_handler = logging.FileHandler(CHAP_LOGS_DIR / f"task_{task_id}.status.txt")
        status_formatter = logging.Formatter("%(asctime)s: %(message)s")
        status_file_handler.setFormatter(status_formatter)

        # Remember old handlers so we can restore them later.
        # Note: We use handler replacement rather than a dedicated child logger because
        # log calls throughout the codebase use this module's logger directly. The
        # try/finally pattern ensures handlers are always restored even if the task fails.
        old_handlers = logger.handlers[:]

        # Also add debug handler to the root-logger, so that logging done by other packages is also logged
        root_logger = logging.getLogger()
        old_root_handlers = root_logger.handlers[:]
        root_logger.addHandler(debug_file_handler)

        # Replace the logger handlers with our per-task debug file handler
        logger.handlers = [debug_file_handler]
        # Also add stdout handler so logs appear in container logs (docker logs) for debugging
        logger.addHandler(logging.StreamHandler())

        # Configure status logger for this task
        status_logger = get_status_logger()
        old_status_handlers = status_logger.handlers[:]
        status_logger.handlers = [status_file_handler]
        status_logger.setLevel(logging.INFO)

        try:
            # Mark as started when the task is actually executing
            r.hmset(
                f"job_meta:{task_id}",
                {
                    "status": "STARTED",
                    # "start_time": datetime.now().isoformat(), # update the start time
                },
            )
            # Execute the actual task
            return super().__call__(*args, **kwargs)

        finally:
            # Close the file handlers and restore old handlers after the task is done.
            # This cleanup runs even if the task raises an exception.
            debug_file_handler.close()
            status_file_handler.close()
            logger.handlers = old_handlers
            root_logger.handlers = old_root_handlers
            status_logger.handlers = old_status_handlers

    def apply_async(self, args=None, kwargs=None, **options):
        # print('apply async', args, kwargs, options)
        job_name = kwargs.pop(JOB_NAME_KW, None) or "Unnamed"
        job_type = kwargs.pop(JOB_TYPE_KW, None) or "Unspecified"
        result = super().apply_async(args=args, kwargs=kwargs, **options)

        r.hmset(
            f"job_meta:{result.id}",
            {"job_name": job_name, "job_type": job_type, "status": "PENDING", "start_time": datetime.now().isoformat()},
        )

        return result

    def on_success(self, retval, task_id, args, kwargs):
        logger.info("Task %s succeeded", task_id)
        # start = float(r.hget(f"job_meta:{task_id}", "start_time") or time.time())
        # duration = time.time() - start
        try:
            retval = json.dumps(retval)
        except TypeError:
            logger.error("RETVAL: Could not serialize return value to JSON")
            logger.error(str(retval))
            r.hmset(
                f"job_meta:{task_id}",
                {
                    "status": "FAILURE",
                    # "duration": duration,
                    "error": "Could not serialize return value to JSON",
                    "end_time": datetime.now().isoformat(),
                },
            )
            raise Exception("Could not serialize return value to JSON. Return value is:" + str(retval)) from None

        r.hmset(
            f"job_meta:{task_id}",
            {
                "status": "SUCCESS",
                # "duration": duration,
                "result": retval,
                "end_time": datetime.now().isoformat(),
            },
        )

    def on_failure(self, exc, task_id, args, kwargs, einfo):
        logger.error("Task %s failed: %s", task_id, exc)
        # start = float(r.hget(f"job_meta:{task_id}", "start_time") or time.time())
        # duration = time.time() - start

        r.hmset(
            f"job_meta:{task_id}",
            {
                "status": "FAILURE",
                # "duration": duration,
                "error": str(exc),
                "traceback": str(einfo.traceback),
                "end_time": datetime.now().isoformat(),
            },
        )


@shared_task(name="celery.ping")
def ping():
    return "pong"


def add_numbers(a: int, b: int):
    logger.info(f"Adding {a} + {b}")
    return a + b


# set base to TrackedTask to enable per-task logging
@app.task(base=TrackedTask)
def celery_run(func, *args, **kwargs):
    return func(*args, **kwargs)


ENGINES_CACHE = {}


@app.task(base=TrackedTask)
def celery_run_with_session(func, *args, **kwargs):
    database_url = kwargs.pop("database_url")
    if database_url not in ENGINES_CACHE:
        ENGINES_CACHE[database_url] = create_engine(database_url)
    engine = ENGINES_CACHE[database_url]

    named_args = inspect.getfullargspec(func).args
    logger.info(f"Running {named_args}")
    with SessionWrapper(engine) as session:
        ret = func(*args, **kwargs | {"session": session})
        return ret


JOB_TYPE_KW = "__job_type__"
JOB_NAME_KW = "__job_name__"


class CeleryJob[ReturnType]:
    """Wrapper for a Celery Job"""

    def __init__(self, job: celery.Task, app: Celery):
        self._job = job
        self._app = app

    @property
    def _result(self) -> AsyncResult:
        return AsyncResult(self._job.id, app=self._app)

    @property
    def status(self) -> str:
        return cast("str", self._result.state)

    @property
    def result(self) -> ReturnType:
        return cast("ReturnType", self._result.result)

    @property
    def progress(self) -> float:
        return 0

    def cancel(self):
        self._result.revoke(terminate=True)

        # Update Redis metadata to reflect the cancellation
        r.hmset(
            f"job_meta:{self._job.id}",
            {
                "status": "REVOKED",
                "end_time": datetime.now().isoformat(),
            },
        )

    @property
    def id(self):
        return self._job.id

    @property
    def is_finished(self) -> bool:
        return self._result.state in ("SUCCESS", "FAILURE", "REVOKED")

    @property
    def exception_info(self) -> str:
        return str(self._result.traceback or "")

    def get_logs(self) -> str:
        """Get user-facing status logs for this job.

        Returns the status logs which contain safe, user-facing progress messages.
        Debug logs with potentially sensitive information are not exposed via API.
        """
        log_file = CHAP_LOGS_DIR / f"task_{self._job.id}.status.txt"
        logger.info(f"Looking for log file at {log_file}")
        logger.info(f"Job id is: {self._job.id}")
        if log_file.exists():
            logs = log_file.read_text()
            job_meta = get_job_meta(self.id)
            if job_meta and job_meta.get("status") == "FAILURE":
                logs += "\n" + job_meta.get("traceback", "")
            return logs
        else:
            # Fallback to traceback if log file not found
            return self.exception_info


class CeleryPool[ReturnType]:
    """Simple abstraction for a Celery Worker"""

    def __init__(self, celery: Celery = None):
        assert celery is None
        self._celery = app

    def queue(self, func: Callable[..., ReturnType], *args, **kwargs) -> CeleryJob[ReturnType]:
        job = celery_run.delay(func, *args, **kwargs)
        return CeleryJob(job, app=self._celery)

    def queue_db(self, func: Callable[..., ReturnType], *args, **kwargs) -> CeleryJob[ReturnType]:
        job = celery_run_with_session.delay(func, *args, **kwargs)
        return CeleryJob(job, app=self._celery)

    def get_job(self, task_id: str) -> CeleryJob[ReturnType]:
        return CeleryJob(AsyncResult(task_id, app=self._celery), app=self._celery)

    # def _describe_job(self, job_info: dict) -> str:
    #    func, *args = job_info["args"]
    #    func_name = func.__name__
    #    return f"{func_name}({', '.join(map(str, args))})"

    # def list_jobs(self) -> List[JobDescription]:
    #     all_jobs = {'active': self._celery.control.inspect().active(),}
    #                 #'scheduled': self._celery.control.inspect().scheduled(),
    #                 #'reserved': self._celery.control.inspect().reserved()}
    #     print(all_jobs)

    #     return [JobDescription(id=info['id'],
    #                            description=self._describe_job(info),
    #                            status=status,
    #                            start_time=datetime.fromtimestamp(info["time_start"]),
    #                            hostname=hostname,
    #                            type=self._get_job_type(info))
    #             for status, host_dict in all_jobs.items() for hostname, jobs in host_dict.items() for info in jobs]

    def list_jobs(self, status: str | None = None) -> list[JobDescription]:
        """List all tracked jobs stored by Redis. Optional filter by status: PENDING, STARTED, SUCCESS, FAILURE, REVOKED"""
        keys: list[str] = r.keys("job_meta:*")  # type: ignore[assignment]
        jobs: list[dict[str, str]] = []

        for key in keys:
            task_id = key.split(":")[1]
            meta: dict[str, str] = r.hgetall(key)  # type: ignore[assignment]
            meta["task_id"] = task_id
            if status is None or meta.get("status") == status:
                jobs.append(meta)

        return [
            JobDescription(
                id=meta["task_id"],
                type=meta.get("job_type", "Unspecified"),
                name=meta.get("job_name", "Unnamed"),
                status=meta["status"],
                start_time=meta.get("start_time", None),
                end_time=meta.get("end_time", None),
                result=meta.get("result", None),
            )
            for meta in sorted(jobs, key=lambda x: x.get("start_time", datetime(1900, 1, 1).isoformat()), reverse=True)
        ]


def get_job_meta(task_id: str):
    """Fetch Redis metadata for a job by task ID."""
    key = f"job_meta:{task_id}"
    if not r.exists(key):
        return None
    return r.hgetall(key)
