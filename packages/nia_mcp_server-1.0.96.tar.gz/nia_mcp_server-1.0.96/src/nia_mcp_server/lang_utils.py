"""
Shared language detection utilities.

Mirrors backend/services/read_service.py LANG_MAP for the knowledge-agent
(separate process, cannot import backend modules directly).
"""

import os
from typing import Dict

# Shared language extension map – keep in sync with backend/services/read_service.py
LANG_MAP: Dict[str, str] = {
    ".py": "python",
    ".js": "javascript",
    ".ts": "typescript",
    ".jsx": "javascript",
    ".tsx": "typescript",
    ".java": "java",
    ".go": "go",
    ".rs": "rust",
    ".rb": "ruby",
    ".php": "php",
    ".c": "c",
    ".cpp": "cpp",
    ".h": "c",
    ".hpp": "cpp",
    ".cs": "csharp",
    ".swift": "swift",
    ".kt": "kotlin",
    ".scala": "scala",
    ".r": "r",
    ".m": "objc",
    ".sh": "bash",
    ".yml": "yaml",
    ".yaml": "yaml",
    ".json": "json",
    ".xml": "xml",
    ".html": "html",
    ".css": "css",
    ".scss": "scss",
    ".md": "markdown",
    ".sql": "sql",
}


def detect_language(file_path: str) -> str:
    """Detect programming language from file extension using LANG_MAP."""
    _, ext = os.path.splitext(file_path)
    return LANG_MAP.get(ext.lower(), "text")
