# mcpzoo-csv-gen

> CSV 生成 — 从 JSON 数据生成 CSV 文本

## Installation

```bash
uvx mcpzoo-csv-gen
```

## uvx JSON

```json
{
  "mcpServers": {
    "csv-gen": {
      "args": ["mcpzoo-csv-gen"],
      "command": "uvx"
    }
  }
}
```
