import json
import csv
import io
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("csv-gen")

@mcp.tool()
def gen_csv(data: str) -> str:
    """从结构化 JSON 数组生成 CSV 文本。"""
    try:
        items = json.loads(data)
    except json.JSONDecodeError as e:
        return f"JSON 解析失败: {e}"
        
    if not isinstance(items, list) or not items:
        return "错误: 输入必须是非空的 JSON 数组"
        
    if not isinstance(items[0], dict):
        return "错误: JSON 数组的元素必须是对象（字典）"
        
    # 收集所有的 fieldnames
    fieldnames = []
    for item in items:
        if isinstance(item, dict):
            for k in item.keys():
                if k not in fieldnames:
                    fieldnames.append(k)
                    
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=fieldnames)
    
    writer.writeheader()
    for item in items:
        if isinstance(item, dict):
            writer.writerow(item)
            
    return output.getvalue()

def main():
    mcp.run()

if __name__ == "__main__":
    main()
