"""
Test runner for executing security tests via CLI.

Phase 5 switchover: Uses LangGraph workflow instead of test_orchestrated.py.
"""

import asyncio
import sys
from pathlib import Path

# Add root directory to path (still needed for configs)
ROOT_DIR = Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT_DIR))

from rich.console import Console  # noqa: E402
from rich.panel import Panel  # noqa: E402
from rich.table import Table  # noqa: E402
from rich import box  # noqa: E402

from src.cli.config_loader import load_config  # noqa: E402
from src.connectors.factory import create_connector  # noqa: E402

console = Console()


async def run_test(args):
    """
    Execute full orchestrated test using LangGraph workflow.

    Enhanced with:
    - --agents: Select specific agents
    - --dry-run: Preview without executing
    - --output: Specify report output
    - --phase: Start at specific phase
    - --verbose: Detailed output
    """
    verbose = getattr(args, "verbose", False)

    # ═══════════════════════════════════════════════════════════════════════════
    # Load Configuration
    # ═══════════════════════════════════════════════════════════════════════════
    console.print()
    console.print(
        Panel.fit(
            "[bold cyan]PenBot Security Testing Framework[/bold cyan]\n"
            "[dim]Multi-agent adversarial testing for AI chatbots[/dim]",
            border_style="cyan",
        )
    )
    console.print()

    console.print(f"📂 Loading config: [cyan]{args.config}[/cyan]")

    try:
        config = load_config(args.config)
    except FileNotFoundError:
        console.print(f"[red]❌ Config file not found: {args.config}[/red]")
        return
    except Exception as e:
        console.print(f"[red]❌ Failed to load config: {e}[/red]")
        return

    target_name = config["target"]["name"]
    console.print(f"✅ Target: [green]{target_name}[/green]")

    # ═══════════════════════════════════════════════════════════════════════════
    # Agent Selection
    # ═══════════════════════════════════════════════════════════════════════════
    if args.agents:
        from src.cli.agents_cmd import validate_agent_list

        valid_agents, invalid_agents = validate_agent_list(args.agents)

        if invalid_agents:
            console.print(f"[yellow]⚠️  Unknown agents: {', '.join(invalid_agents)}[/yellow]")

        if not valid_agents:
            console.print("[red]❌ No valid agents specified[/red]")
            console.print("[dim]Use 'penbot agents' to see available agents[/dim]")
            return

        # Override config with selected agents
        config["test"]["agents"] = valid_agents
        console.print(f"🤖 Agents: [cyan]{', '.join(valid_agents)}[/cyan]")
    else:
        agents_in_config = config["test"].get("agents", [])
        console.print(
            f"🤖 Agents: [cyan]{', '.join(agents_in_config) if agents_in_config else 'All available'}[/cyan]"
        )

    # ═══════════════════════════════════════════════════════════════════════════
    # Determine Attack Count
    # ═══════════════════════════════════════════════════════════════════════════
    max_attacks = args.max_attacks
    if not max_attacks:
        max_attacks = config["test"].get("max_attacks", 30)

    if args.quick:
        max_attacks = 3
        console.print(f"⚡ Quick mode: [yellow]{max_attacks} attacks[/yellow]")
    else:
        console.print(f"🎯 Max Attacks: [cyan]{max_attacks}[/cyan]")

    # ═══════════════════════════════════════════════════════════════════════════
    # Campaign Phase
    # ═══════════════════════════════════════════════════════════════════════════
    start_phase = getattr(args, "phase", None)
    if start_phase:
        console.print(f"📍 Starting Phase: [cyan]{start_phase}[/cyan]")

    # ═══════════════════════════════════════════════════════════════════════════
    # Output Configuration
    # ═══════════════════════════════════════════════════════════════════════════
    output_dir = Path(args.output) if getattr(args, "output", None) else Path("reports")
    output_dir.mkdir(parents=True, exist_ok=True)

    console.print(f"📄 Reports: [cyan]{output_dir}[/cyan]")
    console.print()

    # ═══════════════════════════════════════════════════════════════════════════
    # Dry Run Mode
    # ═══════════════════════════════════════════════════════════════════════════
    if getattr(args, "dry_run", False):
        await _dry_run(config, max_attacks)
        return

    # ═══════════════════════════════════════════════════════════════════════════
    # Initialize Connector (unified factory)
    # ═══════════════════════════════════════════════════════════════════════════
    conn_type = config["target"]["connection"].get("type", "rest")
    target_type = "playwright" if conn_type == "playwright" else "api"

    if target_type == "playwright":
        console.print("🌐 Using Playwright browser automation")
    else:
        console.print("🔌 Using REST API connector")

    connector = create_connector(target_type, config["target"])

    with console.status("[bold green]Initializing connector..."):
        await connector.initialize()

    console.print("✅ Connector initialized")
    console.print()

    # ═══════════════════════════════════════════════════════════════════════════
    # Test Configuration Summary
    # ═══════════════════════════════════════════════════════════════════════════
    summary_table = Table(box=box.ROUNDED, show_header=False, title="📋 Test Configuration")
    summary_table.add_column("Setting", style="bold")
    summary_table.add_column("Value", style="cyan")

    summary_table.add_row("Target", target_name)
    summary_table.add_row("Platform", config["target"].get("platform", "unknown"))
    summary_table.add_row("Max Attacks", str(max_attacks))
    summary_table.add_row("Agents", str(len(config["test"].get("agents", []))) + " active")
    summary_table.add_row("Engine", "LangGraph")
    if start_phase:
        summary_table.add_row("Start Phase", start_phase)

    console.print(summary_table)
    console.print()

    # ═══════════════════════════════════════════════════════════════════════════
    # Execute Campaign via LangGraph
    # ═══════════════════════════════════════════════════════════════════════════
    from src.workflow.graph import create_pentest_workflow
    from src.workflow.state import create_initial_state
    from src.workflow.streaming import stream_workflow_to_websocket, print_node_output
    from src.utils.helpers import generate_uuid
    from langgraph.types import Command

    console.print("🚀 [bold green]Starting LangGraph campaign...[/bold green]")
    console.print()

    # Start operational metrics tracking
    from src.utils.operational_metrics import get_metrics
    from src.utils.config import settings as app_settings

    metrics = get_metrics()
    metrics.start_session()

    if app_settings.inter_round_delay > 0:
        console.print(f"⏱  Inter-round delay: [cyan]{app_settings.inter_round_delay}s[/cyan]")

    session_id = generate_uuid()

    # Build target config with vision/RAG/agentic flags
    target_config_enriched = {
        **config["target"].get("connection", {}),
        "name": target_name,
        "endpoint": config["target"].get("connection", {}).get("endpoint", ""),
        "supports_images": config["target"].get("supports_images", False),
        "image_format": config["target"].get("image_format", "openai"),
        "is_rag": config["target"].get("is_rag", False),
        "is_agentic": config["target"].get("is_agentic", False),
    }

    # Create initial state
    initial_state = create_initial_state(
        target_name=target_name,
        target_type=target_type,
        target_config=target_config_enriched,
        attack_group=config["test"].get("attack_group", "prompt_engineering"),
        max_attempts=max_attacks,
        attack_graph_enabled=True,
        session_id=session_id,
    )

    # ── Initialize checkpointer (SQLite for persistence) ──────────────
    # AsyncSqliteSaver.from_conn_string() is an async context manager in
    # langgraph-checkpoint-sqlite v3.x — must be entered before use.
    from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver

    async with AsyncSqliteSaver.from_conn_string("pentest_sessions.db") as checkpointer:
        # Create LangGraph workflow with durable SQLite checkpointer
        app = create_pentest_workflow(checkpointer=checkpointer)

        # Runtime config — carries non-serializable objects via configurable
        # These objects persist across all node calls within a single execution.
        langgraph_config = {
            "recursion_limit": max(max_attacks * 14 + 20, 250),
            "configurable": {
                "thread_id": session_id,
                "connector": connector,
                # Runtime objects (lazy-initialized by nodes on first access):
                # "canned_detector": <created by execute_attack>
                # "target_fingerprinter": <created by execute_attack>
                # "attack_graph": <created by coordinate_agents>
                # "attack_memory": <created by trigger_agent_learning>
            },
        }

        # Track the latest state snapshot for graceful interrupt saving
        last_state_snapshot: dict = {}

        try:
            # Emit test_started WebSocket event
            try:
                from src.workflow.streaming import emit_ws_event_http

                await emit_ws_event_http(
                    session_id,
                    "test_started",
                    {
                        "target_name": target_name,
                        "max_attacks": max_attacks,
                        "attack_group": config["test"].get("attack_group", "prompt_engineering"),
                        "agents": [a for a in config["test"].get("agents", [])],
                        "session_id": session_id,
                    },
                )
            except Exception:
                pass  # Dashboard may not be running

            # Stream execution with interrupt handling for critical findings
            input_value = initial_state
            last_round_completed = 0  # Track for inter-round delay

            while True:
                has_interrupt = False

                async for chunk in app.astream(
                    input_value, langgraph_config, stream_mode="updates"
                ):
                    # Check for interrupt (critical findings pause)
                    if "__interrupt__" in chunk:
                        has_interrupt = True
                        interrupt_data = chunk["__interrupt__"]
                        console.print()
                        console.print(
                            "[bold yellow]⚠️  Critical vulnerability detected — "
                            "human review requested[/bold yellow]"
                        )
                        for item in interrupt_data:
                            value = item.value if hasattr(item, "value") else item
                            if isinstance(value, dict):
                                console.print(
                                    f"  Findings: {value.get('findings_count', '?')} critical"
                                )
                        console.print(
                            "[dim]Auto-continuing (use API/dashboard for manual review)[/dim]"
                        )
                        break

                    # Normal node output: chunk is {node_name: state_update}
                    for node_name, state_update in chunk.items():
                        # Guard: nodes that return {} produce None state_update
                        if state_update is None:
                            continue

                        # Track latest state for graceful interrupt
                        last_state_snapshot.update(state_update)

                        round_num = state_update.get(
                            "current_attempt",
                            initial_state.get("current_attempt", 0),
                        )
                        if node_name == "generate_attack":
                            # Inter-round delay (rate limiting / politeness)
                            if last_round_completed > 0 and app_settings.inter_round_delay > 0:
                                await asyncio.sleep(app_settings.inter_round_delay)

                            max_attacks = initial_state.get("max_attempts", "?")
                            console.print()
                            console.print(f"[bold cyan]{'─' * 60}[/bold cyan]")
                            console.print(
                                f"[bold cyan]  ⚔  ROUND {round_num}/{max_attacks}[/bold cyan]"
                            )
                            console.print(f"[bold cyan]{'─' * 60}[/bold cyan]")
                            last_round_completed = round_num

                        print_node_output(node_name, state_update)

                        # WebSocket streaming
                        try:
                            await stream_workflow_to_websocket(session_id, node_name, state_update)
                        except Exception:
                            pass  # Dashboard may not be running

                if has_interrupt:
                    # Resume after interrupt — auto-continue in CLI mode
                    input_value = Command(resume={"continue": True})
                else:
                    break  # Graph completed normally

            console.print()
            console.print("[bold green]✅ Campaign completed successfully.[/bold green]")

        except (KeyboardInterrupt, asyncio.CancelledError):
            console.print()
            console.print("[yellow]⚠️  Campaign interrupted by user.[/yellow]")

            # Cancel lingering tasks (MCP subprocesses, etc.) to avoid
            # "Attempted to exit cancel scope in a different task" tracebacks.
            for task in asyncio.all_tasks():
                if task is not asyncio.current_task() and not task.done():
                    task.cancel()
            await asyncio.sleep(0.1)

            # Graceful interrupt: Save partial session state
            if last_state_snapshot:
                try:
                    import json
                    from datetime import datetime, timezone

                    sessions_dir = Path("sessions")
                    sessions_dir.mkdir(exist_ok=True)
                    interrupt_path = sessions_dir / f"{session_id}_interrupted.json"

                    interrupt_data = {
                        "session_id": session_id,
                        "target_name": target_name,
                        "status": "interrupted",
                        "interrupted_at": datetime.now(timezone.utc).isoformat(),
                        "rounds_completed": last_state_snapshot.get("current_attempt", 0),
                        "security_findings": last_state_snapshot.get("security_findings", []),
                        "vulnerability_score": last_state_snapshot.get("vulnerability_score", 0),
                        "attack_attempts_count": len(
                            last_state_snapshot.get("attack_attempts", [])
                        ),
                    }

                    def _json_serial(obj):
                        if hasattr(obj, "isoformat"):
                            return obj.isoformat()
                        if hasattr(obj, "model_dump"):
                            return obj.model_dump()
                        if hasattr(obj, "dict"):
                            return obj.dict()
                        return str(obj)

                    with open(interrupt_path, "w", encoding="utf-8") as f:
                        json.dump(interrupt_data, f, default=_json_serial, indent=2)

                    console.print(f"[dim]Partial session saved: {interrupt_path}[/dim]")
                except Exception as save_err:
                    console.print(f"[dim]Could not save partial state: {save_err}[/dim]")

        except Exception as e:
            console.print()
            console.print(f"[red]❌ Campaign failed: {e}[/red]")
            if verbose:
                import traceback

                traceback.print_exc()
        finally:
            await connector.close()
            # Allow background checkpoint writes to flush before
            # the async-with block closes the SQLite connection.
            await asyncio.sleep(0.5)

    # ═══════════════════════════════════════════════════════════════════════════
    # Post-Test Summary
    # ═══════════════════════════════════════════════════════════════════════════
    console.print()
    console.print("[dim]Use 'penbot sessions' to view past sessions[/dim]")
    console.print("[dim]Use 'penbot report --latest' to generate a report[/dim]")


async def _dry_run(config: dict, max_attacks: int):
    """
    Preview what would be tested without actually executing.

    Shows:
    - Target configuration
    - Active agents
    - Sample attack patterns
    """
    console.print()
    console.print(
        Panel.fit(
            "[bold yellow]🔍 DRY RUN MODE[/bold yellow]\n"
            "[dim]Preview only - no attacks will be executed[/dim]",
            border_style="yellow",
        )
    )
    console.print()

    # Show target info
    target = config["target"]
    console.print("[bold]Target Configuration:[/bold]")
    console.print(f"  • Name: {target.get('name', 'Unknown')}")
    console.print(f"  • Platform: {target.get('platform', 'Unknown')}")
    console.print(f"  • Endpoint: {target.get('connection', {}).get('endpoint', 'Unknown')}")
    console.print()

    # Show agents
    agents = config["test"].get("agents", [])
    console.print("[bold]Active Agents:[/bold]")

    if agents:
        from src.cli.agents_cmd import AGENT_REGISTRY

        for agent_id in agents:
            if agent_id in AGENT_REGISTRY:
                info = AGENT_REGISTRY[agent_id]
                console.print(f"  • [cyan]{agent_id}[/cyan] - {info['description'][:50]}...")
            else:
                console.print(f"  • [cyan]{agent_id}[/cyan]")
    else:
        console.print("  [dim]All available agents will be used[/dim]")

    console.print()

    # Show sample patterns
    console.print("[bold]Sample Attack Patterns:[/bold]")
    console.print()

    try:
        from src.agents.jailbreak import JailbreakAgent

        agent = JailbreakAgent(llm_client=None, config={})
        patterns = agent.get_attack_patterns()[:5]  # First 5

        for i, pattern in enumerate(patterns, 1):
            name = pattern.get("name", "unknown")
            desc = pattern.get("description", "No description")[:60]
            severity = pattern.get("severity_if_success", "unknown")
            console.print(f"  {i}. [cyan]{name}[/cyan]")
            console.print(f"     {desc}")
            console.print(f"     Severity: {severity}")
            console.print()

    except Exception as e:
        console.print(f"  [dim]Could not load patterns: {e}[/dim]")

    # Estimated duration
    # Each round includes: agent coordination (~10-15s), subagent pipeline (~10-15s),
    # attack execution (~2-5s), response analysis (~2-5s), optional Think-MCP (~10-20s).
    # Realistic average: ~45-60 seconds per attack.
    avg_time_per_attack = 50  # seconds (conservative middle estimate)
    total_time = max_attacks * avg_time_per_attack
    hours = total_time // 3600
    minutes = (total_time % 3600) // 60
    seconds = total_time % 60

    console.print()
    if hours > 0:
        console.print(
            f"[bold]Estimated Duration:[/bold] ~{hours}h {minutes}m for {max_attacks} attacks"
        )
    else:
        console.print(
            f"[bold]Estimated Duration:[/bold] ~{minutes}m {seconds}s for {max_attacks} attacks"
        )
    console.print()
    console.print("[dim]To execute, run without --dry-run flag[/dim]")
