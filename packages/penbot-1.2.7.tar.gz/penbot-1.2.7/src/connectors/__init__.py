"""Target chatbot connectors for API and Web UI."""

from .base import BaseConnector, TargetConnector
from .rest_connector import GenericRestConnector
from .factory import create_connector

# Backward compatibility: APITargetConnector is still importable
# but GenericRestConnector is the preferred unified connector.
from .api_connector import APITargetConnector

__all__ = [
    "BaseConnector",
    "TargetConnector",
    "GenericRestConnector",
    "APITargetConnector",
    "create_connector",
]
