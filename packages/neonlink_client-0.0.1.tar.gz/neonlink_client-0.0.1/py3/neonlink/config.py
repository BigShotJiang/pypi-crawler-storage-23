"""Configuration for connecting to a Kafka-compatible broker."""

from __future__ import annotations

import os
from dataclasses import dataclass, field


@dataclass
class Config:
    """Holds all configuration for connecting to a Kafka-compatible broker.

    Environment variables (loaded via ``new_config_from_env``):

        REDPANDA_BROKERS              comma-separated broker addresses
        REDPANDA_TLS_ENABLED          "true" / "false"
        REDPANDA_TLS_CA_FILE          path to CA certificate
        REDPANDA_TLS_CERT_FILE        path to client certificate
        REDPANDA_TLS_KEY_FILE         path to client private key
        REDPANDA_SASL_MECHANISM       PLAIN, SCRAM-SHA-256, SCRAM-SHA-512
        REDPANDA_SASL_USERNAME        SASL username
        REDPANDA_SASL_PASSWORD        SASL password
        REDPANDA_CONSUMER_GROUP       consumer group name
        REDPANDA_MAX_POLL_RECORDS     max records per poll
        REDPANDA_SESSION_TIMEOUT_SEC  session timeout in seconds
        REDPANDA_MAX_POLL_INTERVAL_SEC max poll interval in seconds
        REDPANDA_AUTO_OFFSET_RESET    "earliest" or "latest"
        REDPANDA_CB_MAX_FAILURES      circuit breaker max failures
        REDPANDA_CB_RESET_TIMEOUT_SEC circuit breaker reset timeout seconds
        REDPANDA_RETRY_MAX_ATTEMPTS   max retry attempts
        REDPANDA_DLQ_TOPIC            DLQ topic name
        REDPANDA_POISON_THRESHOLD     poison pill threshold
        REDPANDA_CLIENT_ID            client ID for broker connections
    """

    brokers: list[str] = field(default_factory=lambda: ["localhost:9092"])

    # TLS
    tls_enabled: bool = False
    tls_ca_file: str = ""
    tls_cert_file: str = ""
    tls_key_file: str = ""

    # SASL
    sasl_mechanism: str = ""
    sasl_username: str = ""
    sasl_password: str = ""

    # Consumer
    consumer_group: str = ""
    max_poll_records: int = 10
    session_timeout_sec: int = 30
    max_poll_interval_sec: int = 300
    auto_offset_reset: str = "earliest"

    # Producer
    required_acks: str = "all"  # "all", "1", "0"

    # Circuit breaker
    cb_max_failures: int = 5
    cb_reset_timeout_sec: int = 30

    # Retry
    retry_max_attempts: int = 3

    # DLQ
    dlq_topic: str = "errors-dlq"
    poison_pill_threshold: int = 5

    # Operational
    client_id: str = ""

    def to_confluent_config(self) -> dict[str, str]:
        """Build a confluent-kafka compatible config dict for the producer or consumer."""
        conf: dict[str, str] = {
            "bootstrap.servers": ",".join(self.brokers),
        }

        if self.client_id:
            conf["client.id"] = self.client_id

        if self.tls_enabled:
            conf["security.protocol"] = "SSL"
            if self.tls_ca_file:
                conf["ssl.ca.location"] = self.tls_ca_file
            if self.tls_cert_file:
                conf["ssl.certificate.location"] = self.tls_cert_file
            if self.tls_key_file:
                conf["ssl.key.location"] = self.tls_key_file

        if self.sasl_mechanism:
            protocol = "SASL_SSL" if self.tls_enabled else "SASL_PLAINTEXT"
            conf["security.protocol"] = protocol
            conf["sasl.mechanism"] = self.sasl_mechanism
            conf["sasl.username"] = self.sasl_username
            conf["sasl.password"] = self.sasl_password

        return conf

    def to_producer_config(self) -> dict[str, str]:
        """Build confluent-kafka producer config."""
        conf = self.to_confluent_config()
        conf["acks"] = self.required_acks
        conf["retries"] = str(self.retry_max_attempts)
        conf["retry.backoff.ms"] = "500"
        conf["delivery.timeout.ms"] = "30000"
        return conf

    def to_consumer_config(self) -> dict[str, str]:
        """Build confluent-kafka consumer config."""
        conf = self.to_confluent_config()
        conf["group.id"] = self.consumer_group
        conf["auto.offset.reset"] = self.auto_offset_reset
        conf["enable.auto.commit"] = "false"
        conf["session.timeout.ms"] = str(self.session_timeout_sec * 1000)
        conf["max.poll.interval.ms"] = str(self.max_poll_interval_sec * 1000)
        return conf

    def validate(self) -> None:
        """Raise ValueError if configuration is invalid."""
        if not self.brokers:
            raise ValueError("neonlink: at least one broker address required")
        for b in self.brokers:
            if not b:
                raise ValueError("neonlink: broker address cannot be empty")
        if self.tls_enabled and not self.tls_ca_file and not self.tls_cert_file:
            raise ValueError("neonlink: TLS enabled but no CA or cert file provided")
        if self.sasl_mechanism:
            if self.sasl_mechanism not in ("PLAIN", "SCRAM-SHA-256", "SCRAM-SHA-512"):
                raise ValueError(f"neonlink: unsupported SASL mechanism: {self.sasl_mechanism}")
            if not self.sasl_username or not self.sasl_password:
                raise ValueError("neonlink: SASL mechanism set but username/password missing")
        if self.poison_pill_threshold < 1:
            raise ValueError("neonlink: poison pill threshold must be >= 1")


def new_config_from_env() -> Config:
    """Load configuration from environment variables with sensible defaults."""
    brokers_str = os.environ.get("REDPANDA_BROKERS", "localhost:9092")
    brokers = [b.strip() for b in brokers_str.split(",") if b.strip()]

    return Config(
        brokers=brokers,
        tls_enabled=os.environ.get("REDPANDA_TLS_ENABLED", "").lower() == "true",
        tls_ca_file=os.environ.get("REDPANDA_TLS_CA_FILE", ""),
        tls_cert_file=os.environ.get("REDPANDA_TLS_CERT_FILE", ""),
        tls_key_file=os.environ.get("REDPANDA_TLS_KEY_FILE", ""),
        sasl_mechanism=os.environ.get("REDPANDA_SASL_MECHANISM", ""),
        sasl_username=os.environ.get("REDPANDA_SASL_USERNAME", ""),
        sasl_password=os.environ.get("REDPANDA_SASL_PASSWORD", ""),
        consumer_group=os.environ.get("REDPANDA_CONSUMER_GROUP", ""),
        max_poll_records=int(os.environ.get("REDPANDA_MAX_POLL_RECORDS", "10")),
        session_timeout_sec=int(os.environ.get("REDPANDA_SESSION_TIMEOUT_SEC", "30")),
        max_poll_interval_sec=int(os.environ.get("REDPANDA_MAX_POLL_INTERVAL_SEC", "300")),
        auto_offset_reset=os.environ.get("REDPANDA_AUTO_OFFSET_RESET", "earliest"),
        cb_max_failures=int(os.environ.get("REDPANDA_CB_MAX_FAILURES", "5")),
        cb_reset_timeout_sec=int(os.environ.get("REDPANDA_CB_RESET_TIMEOUT_SEC", "30")),
        retry_max_attempts=int(os.environ.get("REDPANDA_RETRY_MAX_ATTEMPTS", "3")),
        dlq_topic=os.environ.get("REDPANDA_DLQ_TOPIC", "errors-dlq"),
        poison_pill_threshold=int(os.environ.get("REDPANDA_POISON_THRESHOLD", "5")),
        client_id=os.environ.get("REDPANDA_CLIENT_ID", ""),
    )
