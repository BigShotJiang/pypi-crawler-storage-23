"""Record type wrapping a Kafka message with typed header accessors."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


# Header key constants.
HEADER_MESSAGE_TYPE = "message_type"
HEADER_SOURCE_SERVICE = "source_service"
HEADER_TARGET_SERVICE = "target_service"
HEADER_MESSAGE_ID = "message_id"
HEADER_CORRELATION_ID = "correlation_id"
HEADER_IDENTITY_CTX = "identity_context"
HEADER_RETRY_COUNT = "retry_count"
HEADER_TRACEPARENT = "traceparent"
HEADER_TRACESTATE = "tracestate"

Headers = dict[str, str]


@dataclass
class Record:
    """A message consumed from or produced to a broker topic."""

    topic: str = ""
    key: Optional[bytes] = None
    value: Optional[bytes] = None
    headers: Headers = field(default_factory=dict)
    partition: int = 0
    offset: int = 0

    def get_header(self, key: str) -> str:
        """Return header value, or empty string if not found."""
        return self.headers.get(key, "")

    def set_header(self, key: str, value: str) -> None:
        """Set a header key-value pair."""
        self.headers[key] = value

    @property
    def message_type(self) -> str:
        return self.get_header(HEADER_MESSAGE_TYPE)

    @property
    def correlation_id(self) -> str:
        return self.get_header(HEADER_CORRELATION_ID)

    @property
    def message_id(self) -> str:
        return self.get_header(HEADER_MESSAGE_ID)
