"""Simple circuit breaker for protecting broker operations."""

from __future__ import annotations

import threading
import time
from enum import Enum
from typing import Callable


class CircuitBreakerState(Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitBreakerOpen(Exception):
    """Raised when the circuit breaker is open and rejecting calls."""

    pass


class CircuitBreaker:
    """Thread-safe circuit breaker.

    - Closed (normal): all calls pass through.
    - Open (tripped): after max_failures consecutive errors, all calls fail
      immediately for reset_timeout_sec.
    - Half-Open: after timeout, one call is allowed through.
    """

    def __init__(
        self, name: str, max_failures: int = 5, reset_timeout_sec: int = 30
    ) -> None:
        self._name = name
        self._max_failures = max_failures
        self._reset_timeout = reset_timeout_sec
        self._state = CircuitBreakerState.CLOSED
        self._failure_count = 0
        self._last_failure_time = 0.0
        self._lock = threading.Lock()

    @property
    def state(self) -> CircuitBreakerState:
        with self._lock:
            return self._evaluate_state()

    def execute(self, fn: Callable[[], None]) -> None:
        """Execute fn through the circuit breaker.

        Raises:
            CircuitBreakerOpen: if the breaker is open.
        """
        with self._lock:
            state = self._evaluate_state()
            if state == CircuitBreakerState.OPEN:
                raise CircuitBreakerOpen(
                    f"neonlink: circuit breaker '{self._name}' is open"
                )

        try:
            fn()
        except Exception:
            with self._lock:
                self._failure_count += 1
                self._last_failure_time = time.monotonic()
                if self._failure_count >= self._max_failures:
                    self._state = CircuitBreakerState.OPEN
            raise
        else:
            with self._lock:
                self._failure_count = 0
                self._state = CircuitBreakerState.CLOSED

    def _evaluate_state(self) -> CircuitBreakerState:
        """Determine current state (must be called under lock)."""
        if self._state == CircuitBreakerState.OPEN:
            elapsed = time.monotonic() - self._last_failure_time
            if elapsed >= self._reset_timeout:
                self._state = CircuitBreakerState.HALF_OPEN
                return CircuitBreakerState.HALF_OPEN
        return self._state
