"""Dead letter queue routing for failed records."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING

from neonlink.record import HEADER_RETRY_COUNT, Record

if TYPE_CHECKING:
    from neonlink.producer import Producer


def route_to_dlq(
    dlq_producer: Producer,
    dlq_topic: str,
    original: Record,
    processing_error: Exception,
) -> None:
    """Publish a failed record to the DLQ topic with error metadata.

    The original record's headers, key, and value are preserved.
    Additional DLQ metadata headers are added.
    """
    dlq_headers = dict(original.headers)
    dlq_headers["dlq_original_topic"] = original.topic
    dlq_headers["dlq_original_partition"] = str(original.partition)
    dlq_headers["dlq_original_offset"] = str(original.offset)
    dlq_headers["dlq_error"] = str(processing_error)
    dlq_headers["dlq_timestamp"] = time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime())
    dlq_headers["dlq_reason"] = _classify_reason(original)

    dlq_producer.publish(dlq_topic, original.key, original.value, dlq_headers)


def _classify_reason(rec: Record) -> str:
    """Return a human-readable reason for DLQ routing."""
    retry_str = rec.get_header(HEADER_RETRY_COUNT)
    if retry_str:
        try:
            count = int(retry_str)
            if count > 0:
                return f"MAX_RETRIES_EXCEEDED(retry_count={count})"
        except ValueError:
            pass
    return "NON_RETRIABLE_ERROR"
