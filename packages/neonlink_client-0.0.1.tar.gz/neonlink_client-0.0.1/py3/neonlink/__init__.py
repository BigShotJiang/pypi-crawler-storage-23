"""NeonLink Kafka client library for Python services.

Thin wrapper around confluent-kafka-python providing:
- Producer with circuit breaker and retry
- Consumer with manual offset commit and poison pill detection
- DLQ routing on handler error
- OpenTelemetry W3C trace context propagation via Kafka headers
"""

from neonlink.config import Config, new_config_from_env
from neonlink.producer import Producer
from neonlink.consumer import Consumer, MessageHandler
from neonlink.record import Record, Headers
from neonlink.dlq import route_to_dlq
from neonlink.poison import is_poison_pill, get_retry_count, increment_retry_count
from neonlink.tracing import inject_trace_context, extract_trace_context

__all__ = [
    "Config",
    "new_config_from_env",
    "Producer",
    "Consumer",
    "MessageHandler",
    "Record",
    "Headers",
    "route_to_dlq",
    "is_poison_pill",
    "get_retry_count",
    "increment_retry_count",
    "inject_trace_context",
    "extract_trace_context",
]
