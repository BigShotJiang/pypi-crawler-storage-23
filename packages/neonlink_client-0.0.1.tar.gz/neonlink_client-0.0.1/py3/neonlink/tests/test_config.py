"""Tests for neonlink.config."""

import os
import pytest

from neonlink.config import Config, new_config_from_env


class TestDefaultConfig:
    def test_defaults(self):
        cfg = Config()
        assert cfg.brokers == ["localhost:9092"]
        assert cfg.max_poll_records == 10
        assert cfg.session_timeout_sec == 30
        assert cfg.auto_offset_reset == "earliest"
        assert cfg.required_acks == "all"
        assert cfg.cb_max_failures == 5
        assert cfg.retry_max_attempts == 3
        assert cfg.dlq_topic == "errors-dlq"
        assert cfg.poison_pill_threshold == 5


class TestNewConfigFromEnv:
    def test_loads_from_env(self, monkeypatch):
        monkeypatch.setenv("REDPANDA_BROKERS", "broker1:9092,broker2:9092")
        monkeypatch.setenv("REDPANDA_TLS_ENABLED", "true")
        monkeypatch.setenv("REDPANDA_CONSUMER_GROUP", "test-group")
        monkeypatch.setenv("REDPANDA_MAX_POLL_RECORDS", "50")
        monkeypatch.setenv("REDPANDA_SESSION_TIMEOUT_SEC", "45")
        monkeypatch.setenv("REDPANDA_AUTO_OFFSET_RESET", "latest")
        monkeypatch.setenv("REDPANDA_CB_MAX_FAILURES", "10")
        monkeypatch.setenv("REDPANDA_RETRY_MAX_ATTEMPTS", "5")
        monkeypatch.setenv("REDPANDA_DLQ_TOPIC", "custom-dlq")
        monkeypatch.setenv("REDPANDA_POISON_THRESHOLD", "3")
        monkeypatch.setenv("REDPANDA_CLIENT_ID", "test-client")

        cfg = new_config_from_env()

        assert cfg.brokers == ["broker1:9092", "broker2:9092"]
        assert cfg.tls_enabled is True
        assert cfg.consumer_group == "test-group"
        assert cfg.max_poll_records == 50
        assert cfg.session_timeout_sec == 45
        assert cfg.auto_offset_reset == "latest"
        assert cfg.cb_max_failures == 10
        assert cfg.retry_max_attempts == 5
        assert cfg.dlq_topic == "custom-dlq"
        assert cfg.poison_pill_threshold == 3
        assert cfg.client_id == "test-client"


class TestConfigValidate:
    def test_valid_default(self):
        Config().validate()

    def test_no_brokers(self):
        with pytest.raises(ValueError, match="at least one broker"):
            Config(brokers=[]).validate()

    def test_empty_broker(self):
        with pytest.raises(ValueError, match="cannot be empty"):
            Config(brokers=[""]).validate()

    def test_tls_without_certs(self):
        with pytest.raises(ValueError, match="TLS enabled"):
            Config(tls_enabled=True).validate()

    def test_sasl_without_credentials(self):
        with pytest.raises(ValueError, match="username/password"):
            Config(sasl_mechanism="PLAIN").validate()

    def test_unsupported_sasl(self):
        with pytest.raises(ValueError, match="unsupported SASL"):
            Config(
                sasl_mechanism="KERBEROS",
                sasl_username="u",
                sasl_password="p",
            ).validate()

    def test_valid_sasl_plain(self):
        Config(
            sasl_mechanism="PLAIN",
            sasl_username="u",
            sasl_password="p",
        ).validate()

    def test_valid_sasl_scram256(self):
        Config(
            sasl_mechanism="SCRAM-SHA-256",
            sasl_username="u",
            sasl_password="p",
        ).validate()

    def test_poison_threshold_zero(self):
        with pytest.raises(ValueError, match="poison pill threshold"):
            Config(poison_pill_threshold=0).validate()


class TestConfluentConfig:
    def test_basic(self):
        cfg = Config(brokers=["b1:9092", "b2:9092"], client_id="test")
        conf = cfg.to_confluent_config()
        assert conf["bootstrap.servers"] == "b1:9092,b2:9092"
        assert conf["client.id"] == "test"

    def test_tls(self):
        cfg = Config(
            tls_enabled=True,
            tls_ca_file="/ca.pem",
            tls_cert_file="/cert.pem",
            tls_key_file="/key.pem",
        )
        conf = cfg.to_confluent_config()
        assert conf["security.protocol"] == "SSL"
        assert conf["ssl.ca.location"] == "/ca.pem"

    def test_sasl_plain(self):
        cfg = Config(
            sasl_mechanism="PLAIN",
            sasl_username="user",
            sasl_password="pass",
        )
        conf = cfg.to_confluent_config()
        assert conf["security.protocol"] == "SASL_PLAINTEXT"
        assert conf["sasl.mechanism"] == "PLAIN"
        assert conf["sasl.username"] == "user"

    def test_sasl_with_tls(self):
        cfg = Config(
            tls_enabled=True,
            tls_ca_file="/ca.pem",
            sasl_mechanism="SCRAM-SHA-512",
            sasl_username="user",
            sasl_password="pass",
        )
        conf = cfg.to_confluent_config()
        assert conf["security.protocol"] == "SASL_SSL"

    def test_producer_config(self):
        cfg = Config()
        conf = cfg.to_producer_config()
        assert conf["acks"] == "all"
        assert conf["retries"] == "3"

    def test_consumer_config(self):
        cfg = Config(consumer_group="test-group")
        conf = cfg.to_consumer_config()
        assert conf["group.id"] == "test-group"
        assert conf["enable.auto.commit"] == "false"
        assert conf["auto.offset.reset"] == "earliest"
