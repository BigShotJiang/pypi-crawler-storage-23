"""Tests for neonlink.circuit_breaker."""

import time

import pytest

from neonlink.circuit_breaker import (
    CircuitBreaker,
    CircuitBreakerOpen,
    CircuitBreakerState,
)


class TestCircuitBreaker:
    def test_success_keeps_closed(self):
        cb = CircuitBreaker("test", max_failures=3, reset_timeout_sec=1)
        for _ in range(5):
            cb.execute(lambda: None)
        assert cb.state == CircuitBreakerState.CLOSED

    def test_trips_after_max_failures(self):
        cb = CircuitBreaker("test", max_failures=3, reset_timeout_sec=1)

        for _ in range(3):
            with pytest.raises(ValueError):
                cb.execute(_raise_value_error)

        with pytest.raises(CircuitBreakerOpen):
            cb.execute(lambda: None)

    def test_half_open_after_timeout(self):
        cb = CircuitBreaker("test", max_failures=2, reset_timeout_sec=0.1)

        for _ in range(2):
            with pytest.raises(ValueError):
                cb.execute(_raise_value_error)

        assert cb.state == CircuitBreakerState.OPEN

        time.sleep(0.15)
        assert cb.state == CircuitBreakerState.HALF_OPEN

        # Successful call closes it.
        cb.execute(lambda: None)
        assert cb.state == CircuitBreakerState.CLOSED

    def test_half_open_failure_reopens(self):
        cb = CircuitBreaker("test", max_failures=1, reset_timeout_sec=0.1)

        with pytest.raises(ValueError):
            cb.execute(_raise_value_error)

        time.sleep(0.15)
        assert cb.state == CircuitBreakerState.HALF_OPEN

        with pytest.raises(ValueError):
            cb.execute(_raise_value_error)

        assert cb.state == CircuitBreakerState.OPEN

    def test_success_resets_failure_count(self):
        cb = CircuitBreaker("test", max_failures=3, reset_timeout_sec=1)

        # 2 failures, then success.
        for _ in range(2):
            with pytest.raises(ValueError):
                cb.execute(_raise_value_error)

        cb.execute(lambda: None)

        # 2 more failures should not trip (count was reset).
        for _ in range(2):
            with pytest.raises(ValueError):
                cb.execute(_raise_value_error)

        assert cb.state == CircuitBreakerState.CLOSED


def _raise_value_error():
    raise ValueError("test error")
