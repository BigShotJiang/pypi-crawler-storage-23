"""Tests for neonlink.dlq."""

from neonlink.dlq import _classify_reason
from neonlink.record import HEADER_RETRY_COUNT, Record


class TestClassifyReason:
    def test_with_retry_count(self):
        rec = Record(topic="t", headers={HEADER_RETRY_COUNT: "5"})
        assert _classify_reason(rec) == "MAX_RETRIES_EXCEEDED(retry_count=5)"

    def test_without_retry_count(self):
        rec = Record(topic="t", headers={})
        assert _classify_reason(rec) == "NON_RETRIABLE_ERROR"

    def test_zero_retry_count(self):
        rec = Record(topic="t", headers={HEADER_RETRY_COUNT: "0"})
        assert _classify_reason(rec) == "NON_RETRIABLE_ERROR"

    def test_invalid_retry_count(self):
        rec = Record(topic="t", headers={HEADER_RETRY_COUNT: "bad"})
        assert _classify_reason(rec) == "NON_RETRIABLE_ERROR"
