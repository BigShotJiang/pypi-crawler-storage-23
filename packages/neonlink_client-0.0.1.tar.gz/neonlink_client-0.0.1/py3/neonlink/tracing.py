"""OpenTelemetry W3C trace context propagation via Kafka headers."""

from __future__ import annotations

from typing import Optional

from neonlink.record import HEADER_TRACEPARENT, HEADER_TRACESTATE, Record

try:
    from opentelemetry import context as otel_context
    from opentelemetry import trace
    from opentelemetry.trace.propagation import TraceContextTextMapPropagator

    _HAS_OTEL = True
    _propagator = TraceContextTextMapPropagator()
except ImportError:
    _HAS_OTEL = False
    _propagator = None


class _RecordCarrier:
    """Adapter between Record headers and OTel TextMapPropagator."""

    def __init__(self, record: Record) -> None:
        self._record = record

    def get(self, key: str) -> Optional[str]:
        return self._record.get_header(key) or None

    def set(self, key: str, value: str) -> None:
        self._record.set_header(key, value)

    def keys(self) -> list[str]:
        return list(self._record.headers.keys())


def inject_trace_context(record: Record) -> None:
    """Inject the current span's W3C trace context into record headers.

    Call this before producing a record. If OpenTelemetry is not installed,
    this is a no-op.
    """
    if not _HAS_OTEL:
        return
    _propagator.inject(carrier=_RecordCarrier(record))


def extract_trace_context(record: Record) -> Optional[object]:
    """Extract W3C trace context from record headers.

    Returns an OTel Context object with the remote span context attached.
    If OpenTelemetry is not installed, returns None.
    """
    if not _HAS_OTEL:
        return None
    return _propagator.extract(carrier=_RecordCarrier(record))
