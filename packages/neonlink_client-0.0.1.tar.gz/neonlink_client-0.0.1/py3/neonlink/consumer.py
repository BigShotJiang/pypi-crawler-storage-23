"""Kafka consumer with manual offset commit and poison pill detection."""

from __future__ import annotations

import logging
import threading
from typing import Optional, Protocol

from confluent_kafka import Consumer as ConfluentConsumer, KafkaError, KafkaException, Message

from neonlink.circuit_breaker import CircuitBreaker
from neonlink.config import Config
from neonlink.record import HEADER_RETRY_COUNT, Record

logger = logging.getLogger(__name__)


class MessageHandler(Protocol):
    """Protocol for message handlers."""

    def handle_message(self, record: Record) -> None:
        """Process a single record.

        Return normally to acknowledge (commit offset).
        Raise an exception to skip commit — Kafka redelivers on next poll.
        """
        ...


class Consumer:
    """Subscribes to Kafka topics and dispatches records to a MessageHandler.

    On handler success: offset is committed.
    On handler error: offset is NOT committed. Kafka redelivers on next poll.
    If retry_count >= poison pill threshold: offset is committed (skip past).
    """

    def __init__(self, cfg: Config, topics: list[str]) -> None:
        cfg.validate()
        if not cfg.consumer_group:
            raise ValueError("neonlink: consumer group is required")
        if not topics:
            raise ValueError("neonlink: at least one topic is required")

        self._consumer = ConfluentConsumer(cfg.to_consumer_config())
        self._topics = topics
        self._cfg = cfg
        self._cb = CircuitBreaker(
            name="consumer",
            max_failures=cfg.cb_max_failures,
            reset_timeout_sec=cfg.cb_reset_timeout_sec,
        )
        self._stop_event = threading.Event()
        self._closed = False

    def subscribe(self, handler: MessageHandler) -> None:
        """Start the consume loop, blocking until stop() is called.

        Args:
            handler: MessageHandler implementation to process each record.
        """
        self._consumer.subscribe(self._topics)
        logger.info(
            "neonlink: consumer starting, group=%s topics=%s",
            self._cfg.consumer_group,
            self._topics,
        )

        try:
            while not self._stop_event.is_set():
                msg = self._poll_one()
                if msg is None:
                    continue

                record = _from_confluent_message(msg)

                try:
                    handler.handle_message(record)
                    self._commit(msg)
                except Exception as exc:
                    self._handle_processing_error(record, msg, exc)
        finally:
            self._consumer.close()
            logger.info("neonlink: consumer stopped")

    def subscribe_with_dlq(
        self,
        handler: MessageHandler,
        dlq_producer: "neonlink.producer.Producer",
    ) -> None:
        """Start the consume loop with DLQ routing for poison pills.

        On poison pill detection, the record is published to the DLQ topic
        and the offset is committed to skip past it.
        """
        wrapped = _DLQHandler(
            inner=handler,
            dlq_producer=dlq_producer,
            dlq_topic=self._cfg.dlq_topic,
            threshold=self._cfg.poison_pill_threshold,
        )
        self.subscribe(wrapped)

    def stop(self) -> None:
        """Request graceful shutdown of the consume loop."""
        self._stop_event.set()

    def close(self) -> None:
        """Stop and close the consumer."""
        if self._closed:
            return
        self._closed = True
        self.stop()

    def _poll_one(self) -> Optional[Message]:
        """Poll for a single message with circuit breaker."""
        msg: Optional[Message] = None

        def _do_poll() -> None:
            nonlocal msg
            msg = self._consumer.poll(timeout=1.0)

        try:
            self._cb.execute(_do_poll)
        except Exception:
            return None

        if msg is None:
            return None

        if msg.error():
            if msg.error().code() == KafkaError._PARTITION_EOF:
                return None
            logger.warning("neonlink: consumer error: %s", msg.error())
            return None

        return msg

    def _commit(self, msg: Message) -> None:
        """Commit offset for the consumed message."""
        try:
            self._consumer.commit(message=msg, asynchronous=False)
        except KafkaException as exc:
            logger.warning(
                "neonlink: offset commit error topic=%s partition=%s offset=%s: %s",
                msg.topic(),
                msg.partition(),
                msg.offset(),
                exc,
            )

    def _handle_processing_error(
        self, record: Record, msg: Message, exc: Exception
    ) -> None:
        """Decide whether to skip (commit) or leave for redelivery."""
        retry_count = _get_retry_count(record)

        if retry_count >= self._cfg.poison_pill_threshold:
            logger.error(
                "neonlink: poison pill detected, skipping "
                "topic=%s partition=%s offset=%s retry_count=%d: %s",
                record.topic,
                record.partition,
                record.offset,
                retry_count,
                exc,
            )
            self._commit(msg)
            return

        logger.warning(
            "neonlink: handler error, will redeliver "
            "topic=%s partition=%s offset=%s retry_count=%d: %s",
            record.topic,
            record.partition,
            record.offset,
            retry_count,
            exc,
        )


class _DLQHandler:
    """Internal wrapper that routes poison pills to DLQ before acknowledging."""

    def __init__(
        self,
        inner: MessageHandler,
        dlq_producer: "neonlink.producer.Producer",
        dlq_topic: str,
        threshold: int,
    ) -> None:
        self._inner = inner
        self._dlq_producer = dlq_producer
        self._dlq_topic = dlq_topic
        self._threshold = threshold

    def handle_message(self, record: Record) -> None:
        try:
            self._inner.handle_message(record)
        except Exception as exc:
            retry_count = _get_retry_count(record)
            if retry_count < self._threshold:
                raise

            from neonlink.dlq import route_to_dlq

            try:
                route_to_dlq(self._dlq_producer, self._dlq_topic, record, exc)
                logger.warning(
                    "neonlink: poison pill routed to DLQ "
                    "topic=%s offset=%s retry_count=%d",
                    record.topic,
                    record.offset,
                    retry_count,
                )
            except Exception as dlq_exc:
                logger.error(
                    "neonlink: failed to route to DLQ: %s (original: %s)",
                    dlq_exc,
                    exc,
                )
                raise exc from dlq_exc


def _from_confluent_message(msg: Message) -> Record:
    """Convert a confluent-kafka Message to a Record."""
    headers: dict[str, str] = {}
    raw_headers = msg.headers()
    if raw_headers:
        for key, val in raw_headers:
            if val is not None:
                headers[key] = val.decode("utf-8", errors="replace")

    return Record(
        topic=msg.topic() or "",
        key=msg.key(),
        value=msg.value(),
        headers=headers,
        partition=msg.partition() or 0,
        offset=msg.offset() or 0,
    )


def _get_retry_count(record: Record) -> int:
    """Extract retry_count from record headers."""
    val = record.get_header(HEADER_RETRY_COUNT)
    if not val:
        return 0
    try:
        return int(val)
    except ValueError:
        return 0
