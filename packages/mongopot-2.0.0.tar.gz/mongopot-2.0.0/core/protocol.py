
#from binascii import hexlify
from collections import OrderedDict
from datetime import datetime
from ipaddress import ip_address, ip_network
from random import randint
from struct import pack, unpack
from sys import version_info
from time import time
from uuid import uuid4

from core.tools import (
    decode,
    get_local_ip,
    get_utc_time,
    printable,
    write_event
)

from bson import BSON
from bson.binary import Binary
from bson.codec_options import CodecOptions
from pytz import timezone
from twisted.internet.protocol import Factory, Protocol
from twisted.python.log import msg


if version_info[0] >= 3:
    def ord(x):
        return x
    def unicode(x):
        return x

class SimpleMongoDBProtocol(Protocol):
    def __init__(self, cfg):
        self.buffer = b''
        self.client_ip = None
        self.client_port = None
        self.request_id = 0
        self.server_request_id = 0
        self.max_bson_size = 16 * 1024 * 1024
        self.max_message_size = 64 * 1024 * 1024
        self.connection_id = randint(1, 5000000)
        self.cfg = cfg

    def connectionMade(self):
        peer = self.transport.getPeer()
        self.client_ip = peer.host
        self.client_port = peer.port
        self.session = uuid4().hex[:12]
        self.report_event('connect')

    def connectionLost(self, reason):
        self.report_event('disconnect', reason.value)
        self.session = None

    def dataReceived(self, data):
        self.buffer += data
        if len(self.buffer) > self.max_message_size * 2:
            self.transport.loseConnection()
            return

        while True:
            if len(self.buffer) < 16:
                break

            try:
                length, request_id, response_to, op_code = unpack('<iiii', self.buffer[:16])
            except Exception:
                self.transport.loseConnection()
                return

            if length < 16 or length > self.max_message_size:
                self.transport.loseConnection()
                return

            if length > len(self.buffer):
                break

            full_msg = self.buffer[:length]
            self.buffer = self.buffer[length:]

            #self.log_raw_message(full_msg, request_id, response_to, op_code)

            try:
                self.handleMessage(full_msg, request_id, op_code)
            except Exception as e:
                msg('Error handling message: {}'.format(e))
                self.transport.loseConnection()
                return

    def report_event(self, operation, username='', nonce='', application=''):
        operation = operation.lower()
        unix_time = time()
        ip = self.client_ip
        for network in self.cfg['blacklist']:
            if ip_address(unicode(ip)) in ip_network(unicode(network)):
                return
        port = self.client_port
        event = {
            'eventid': 'mongopot.' + operation,
            'operation': operation,
            'timestamp': get_utc_time(unix_time),
            'unixtime': unix_time,
            'src_ip': ip,
            'src_port': port,
            'dst_port': self.cfg['port'],
            'sensor': self.cfg['sensor'],
            'dst_ip': self.cfg['public_ip'] if self.cfg['report_public_ip'] else get_local_ip(),
            'session': self.session
        }
        if operation == 'login':
            event['username'] = printable(username)
            event['nonce'] = printable(nonce)
            message = 'Login with username: "{}", nonce: "{}" from {}:{}.'.format(
                event['username'],
                event['nonce'],
                ip,
                port
            )
        elif operation == 'connect':
            message = 'Connection made from {}:{}.'.format(ip, port)
        elif operation == 'command':
            command = printable(username)
            event['command'] = command
            if nonce:
                event['database'] = printable(nonce)
                database = ', database: ' + event['database']
            else:
                event['database'] = ''
                database = ''
            if application:
                event['application'] = printable(application)
                app = ', application: ' + application
            else:
                event['application'] = ''
                app = ''
            message = 'Command: {}{}{} from {}:{}.'.format(command, database, app, ip, port)
        elif operation == 'disconnect':
            message = '{}:{} disconnected. Reason: {}'.format(ip, port, username)
        else:
            command = printable(username)
            event['command'] = command
            message = 'Unknown operation "{}" from {}:{}.'.format(command, ip, port)
        msg(message)
        write_event(event, self.cfg)

    def next_server_request_id(self):
        self.server_request_id = (self.server_request_id + 1) & 0x7fffffff
        if self.server_request_id == 0:
            self.server_request_id = 1
        return self.server_request_id

    # def log_raw_message(self, full_msg, request_id, response_to, op_code):
    #     try:
    #         max_dump = 4096
    #         chunk = full_msg[:max_dump]
    #         hex_data = hexlify(chunk)
    #         suffix = '' if len(full_msg) <= max_dump else '... (truncated, {}B)'.format(len(full_msg))
    #         msg(
    #             '[RAW] {}:{} op={} request_id={} response_to={} len={} data={}{}'.format(
    #                 self.client_ip,
    #                 self.client_port,
    #                 op_code,
    #                 request_id,
    #                 response_to,
    #                 len(full_msg),
    #                 hex_data,
    #                 suffix
    #             )
    #         )
    #     except Exception as e:
    #         msg('Error: {}'.format(e))

    def handleMessage(self, full_msg, request_id, op_code):
        if op_code == 2013:
            self.handle_op_msg(full_msg, request_id)
            return
        if op_code == 2004:
            self.handle_op_query(full_msg, request_id)
            return
        self.transport.loseConnection()

    def parse_bson_doc(self, bts, offset=0):
        if offset + 4 > len(bts):
            return None, offset
        dlen = unpack('<i', bts[offset:offset + 4])[0]
        if dlen < 5 or offset + dlen > len(bts):
            return None, offset
        options = CodecOptions(document_class=OrderedDict)
        doc = BSON(bts[offset:offset + dlen]).decode(codec_options=options)
        return doc, offset + dlen

    def handle_op_msg(self, full_msg, request_id):
        payload = full_msg[16:]
        if len(payload) < 5:
            self.send_op_msg_response(request_id, {
                'ok': 0,
                'errmsg':
                'Malformed OP_MSG',
                'code': 9,
                'codeName':
                'FailedToParse'
            })
            return

        try:
            #_flags = unpack('<I', payload[:4])[0]
            payload = payload[4:]

            body_doc = None

            while payload:
                kind = ord(payload[0])
                payload = payload[1:]

                if kind == 0:
                    doc, new_off = self.parse_bson_doc(payload, 0)
                    if isinstance(doc, dict):
                        body_doc = doc
                    break

                if kind == 1:
                    if len(payload) < 4:
                        break
                    size = unpack('<i', payload[:4])[0]
                    if size < 5 or size > len(payload):
                        break
                    block = payload[:size]
                    payload = payload[size:]

                    nul = block.find(b'\x00', 4)
                    if nul == -1:
                        continue
                    pos = nul + 1
                    while pos < len(block):
                        doc, pos2 = self.parse_bson_doc(block, pos)
                        if doc is None:
                            break
                        pos = pos2
                    continue

                break

            if not isinstance(body_doc, dict):
                self.send_op_msg_response(
                    request_id,
                    {
                        'ok': 0,
                        'errmsg': 'Malformed OP_MSG',
                        'code': 9,
                        'codeName': 'FailedToParse'
                    },
                )
                return

            self.process_op_msg_body(body_doc, request_id)

        except Exception as e:
            response = {'ok': 0, 'errmsg': str(e), 'code': 13, 'codeName': 'Unauthorized'}
            self.send_op_msg_response(request_id, response)

    def process_op_msg_body(self, doc, request_id):
        cmd_name = next(iter(doc)) if doc else 'unknown'
        self.log_command(doc, cmd_name)

        cmd_lc = str(cmd_name).lower()
        if cmd_lc in ('ismaster', 'hello', 'hellook'):
            self.send_ismaster_response(request_id, requested_cmd=cmd_lc, is_op_msg=True)
            return
        if cmd_lc == 'saslstart' or cmd_lc == 'saslcontinue':
            self.handle_sasl_start(doc, request_id)
            return
        if cmd_lc == 'ping':
            self.send_ping_response(request_id, is_op_msg=True)
            return
        if cmd_lc == 'buildinfo':
            self.send_buildinfo_response(request_id, is_op_msg=True)
            return
        if cmd_lc == 'connectionstatus':
            self.send_connectionstatus_response(request_id, is_op_msg=True)
            return
        if cmd_lc == 'listcommands':
            self.send_listcommands_response(request_id, is_op_msg=True)
            return
        if cmd_lc == 'autoauthorize':
            self.report_event('login')
            self.send_auth_failure(request_id, is_op_msg=True)
            return

        self.send_unauthorized(request_id, cmd_name, is_op_msg=True)

    def handle_op_query(self, full_msg, request_id):
        payload = full_msg[16:]
        try:
            if len(payload) < 4:
                self.transport.loseConnection()
                return

            #_flags = unpack('<i', payload[:4])[0]
            payload = payload[4:]

            nul = payload.find(b'\x00')
            if nul == -1:
                self.transport.loseConnection()
                return

            collection_name = decode(payload[:nul])
            payload = payload[nul + 1:]

            if len(payload) < 8:
                self.transport.loseConnection()
                return

            #_skip, _return_count = unpack('<ii', payload[:8])
            payload = payload[8:]

            query_doc, off = self.parse_bson_doc(payload, 0)
            if not isinstance(query_doc, dict):
                self.send_unauthorized(request_id, is_op_msg=False)
                return

            if '$query' in query_doc and isinstance(query_doc.get('$query'), dict):
                base = query_doc.get('$query') or {}
                extras = {k: v for k, v in query_doc.items() if k != '$query'}
                merged = dict(base)
                merged.update(extras)
                query_doc = merged

            db_name = collection_name.split('.')[0] if '.' in collection_name else collection_name
            if '$db' not in query_doc:
                query_doc['$db'] = db_name

            cmd_name = next(iter(query_doc)) if query_doc else 'unknown'
            self.log_command(query_doc, cmd_name)

            cmd_lc = str(cmd_name).lower()
            if cmd_lc in ('ismaster', 'hello', 'hellook'):
                self.send_ismaster_response(request_id, requested_cmd=cmd_lc, is_op_msg=False)
                return
            if cmd_lc == 'ping':
                self.send_ping_response(request_id, is_op_msg=False)
                return
            if cmd_lc == 'buildinfo':
                self.send_buildinfo_response(request_id, is_op_msg=False)
                return
            if cmd_lc == 'connectionstatus':
                self.send_connectionstatus_response(request_id, is_op_msg=False)
                return
            if cmd_lc == 'listcommands':
                self.send_listcommands_response(request_id, is_op_msg=False)
                return
            if cmd_lc == 'saslstart' or cmd_lc == 'saslcontinue':
                self.handle_sasl_start(query_doc, request_id)
                return

            self.send_unauthorized(request_id, cmd_name, is_op_msg=False)

        except Exception as e:
            msg('Error handling OP_QUERY: {}'.format(e))
            self.send_unauthorized(request_id, is_op_msg=False)

    def log_command(self, doc, cmd_name):
        client = doc.get('client', {}) if isinstance(doc, dict) else {}
        app_info = client.get('application', {}) if isinstance(client, dict) else {}
        driver_info = client.get('driver', {}) if isinstance(client, dict) else {}
        os_info = client.get('os', {}) if isinstance(client, dict) else {}

        application_name = app_info.get('name', '')
        platform = app_info.get('platform', '')
        if platform:
            application_name += ' ({})'.format(platform)
        application_name += ' | {} {}'.format(
            driver_info.get('name', ''),
            driver_info.get('version', '')
        ).strip(' |').strip()
        os_str = '{} {} {}'.format(
            os_info.get('name', ''),
            os_info.get('architecture', ''),
            os_info.get('version', '')
        ).strip()

        command = cmd_name if cmd_name else 'unknown'
        if isinstance(doc, dict):
            database = doc.get('$db', '')
        if os_str:
            application_name += ', os: ' + os_str
        self.report_event('command', command, database, application_name)

    def handle_sasl_start(self, doc, request_id):
        username = ''
        client_nonce = ''
        try:
            payload = doc.get('payload', b'') if isinstance(doc, dict) else b''
            if isinstance(payload, Binary):
                payload = bytes(payload)
            if isinstance(payload, (bytes, bytearray)) and payload:
                payload_str = decode(payload)
                parts = dict(p.split('=', 1) for p in payload_str.split(',') if '=' in p)
                username = parts.get('n', '')
                client_nonce = parts.get('r', '')
        except Exception as e:
            msg('Error parsing SASL payload: {}'.format(e))

        self.report_event('login', username, client_nonce)
        self.send_auth_failure(request_id, is_op_msg=True)

    def build_op_reply(self, request_id, response_doc):
        response_payload = BSON.encode(response_doc)
        if len(response_payload) > self.max_bson_size:
            response_payload = self.create_error_response('BSON size too large')

        response_flags = 0
        cursor_id = 0
        starting_from = 0
        number_returned = 1

        reply_body = pack('<i', response_flags)
        reply_body += pack('<q', cursor_id)
        reply_body += pack('<i', starting_from)
        reply_body += pack('<i', number_returned)
        reply_body += response_payload

        total_length = 16 + len(reply_body)
        header = pack('<iiii', total_length, self.next_server_request_id(), request_id, 1)
        return header + reply_body

    def create_error_response(self, message):
        return BSON.encode({'ok': 0, 'errmsg': message, 'code': 13, 'codeName': 'Unauthorized'})

    def send_op_reply_response(self, request_id, response_doc):
        try:
            reply = self.build_op_reply(request_id, response_doc)
            self.transport.write(reply)
        except Exception:
            pass

    def send_op_msg_response(self, request_id, response_doc):
        try:
            payload = BSON.encode(response_doc)
            if len(payload) > self.max_bson_size:
                payload = self.create_error_response('Response too large')

            flags = 0
            message = pack('<I', flags)
            message += b'\x00'
            message += payload

            total_length = 16 + len(message)
            header = pack('<iiii', total_length, self.next_server_request_id(), request_id, 2013)
            self.transport.write(header + message)
        except Exception as e:
            msg('Error sending OP_MSG response: {}'.format(e))

    def wire_version_from_version(self):
        try:
            major = int(str(self.cfg['version'] or '').split('.', 1)[0])
        except Exception:
            major = 5
        wv_map = {4: 9, 5: 13, 6: 17, 7: 21, 8: 25}
        return wv_map.get(major, 13)

    def send_ismaster_response(self, request_id, requested_cmd='ismaster', is_op_msg=True):
        max_wv = self.wire_version_from_version()
        response = OrderedDict([
            ('ismaster', True),
            ('isWritablePrimary', True),
            ('maxBsonObjectSize', self.max_bson_size),
            ('maxMessageSizeBytes', self.max_message_size),
            ('maxWriteBatchSize', 1000),
            ('localTime', datetime.now(timezone('UTC'))),
            ('logicalSessionTimeoutMinutes', 30),
            ('connectionId', self.connection_id),
            ('minWireVersion', 0),
            ('maxWireVersion', max_wv),
            ('readOnly', False),
            ('ok', 1.0),
            ('compression', ['none']),
            ('saslSupportedMechs', ['SCRAM-SHA-1', 'SCRAM-SHA-256']),
        ])
        if str(requested_cmd).lower() == 'hello':
            #response['helloOk'] = True
            response.pop('ismaster')
            #response.pop('compression')
            #response.pop('saslSupportedMechs')

        if is_op_msg:
            self.send_op_msg_response(request_id, response)
        else:
            self.send_op_reply_response(request_id, response)

    def send_ping_response(self, request_id, is_op_msg=True):
        response = {'ok': 1.0, 'ping': 'pong'}
        if is_op_msg:
            self.send_op_msg_response(request_id, response)
        else:
            self.send_op_reply_response(request_id, response)

    def send_buildinfo_response(self, request_id, is_op_msg=True):
        self.cfg['buildInfo']['version'] = self.cfg['version']
        self.cfg['buildInfo']['versionArray'] = [int(x) for x in self.cfg['version'].split('.')] + [0]
        response = self.cfg['buildInfo']
        if is_op_msg:
            self.send_op_msg_response(request_id, response)
        else:
            self.send_op_reply_response(request_id, response)

    def send_connectionstatus_response(self, request_id, is_op_msg=True):
        response = self.cfg['connectionStatus']
        if is_op_msg:
            self.send_op_msg_response(request_id, response)
        else:
            self.send_op_reply_response(request_id, response)

    def send_listcommands_response(self, request_id, is_op_msg=True):
        response = self.cfg['listCommands']
        if is_op_msg:
            self.send_op_msg_response(request_id, response)
        else:
            self.send_op_reply_response(request_id, response)

    def send_auth_failure(self, request_id, is_op_msg=True):
        response = {
            'ok': 0,
            'errmsg': 'Authentication failed',
            'code': 18,
            'codeName': 'AuthenticationFailed',
            'conversationId': 1,
            'done': True,
        }
        if is_op_msg:
            self.send_op_msg_response(request_id, response)
        else:
            self.send_op_reply_response(request_id, response)

    def send_unauthorized(self, request_id, cmd_name='', is_op_msg=True):
        err_msg = 'Command {} requires authentication'.format(cmd_name) if cmd_name else 'Unauthorized'
        response = OrderedDict([('ok', 0.0), ('errmsg', err_msg), ('code', 13), ('codeName', 'Unauthorized')])
        if is_op_msg:
            self.send_op_msg_response(request_id, response)
        else:
            self.send_op_reply_response(request_id, response)


class MongoFactory(Factory):
    def __init__(self, options):
        self.cfg = options

    def buildProtocol(self, addr):
        return SimpleMongoDBProtocol(self.cfg)
