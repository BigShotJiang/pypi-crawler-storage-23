
from os import linesep
from os.path import basename, dirname
from time import gmtime, strftime

from core import output
from core.config import CONFIG
from core.tools import mkdir
from core.logfile import HoneypotDailyLogFile

class Output(output.Output):

    def start(self):
        fn = CONFIG.get('output_textlog', 'logfile')
        dirs = dirname(fn)
        base = basename(fn)
        mkdir(dirs)
        self.outfile = HoneypotDailyLogFile(base, dirs, defaultMode=0o664)

    def stop(self):
        self.outfile.flush()

    def write(self, event):
        operation = event['operation'].lower()
        message = '[{} UTC] [MongoPot on {} ({})]: {}'.format(
            strftime('%Y-%m-%d %H:%M:%S', gmtime(event['unixtime'])),
            event['sensor'], event['session'], operation.capitalize()
        )
        if operation == 'unknown':
            message += ' operation: "{}"'.format(event['username'])
        elif operation == 'command':
            message += ': {}'.format(event['command'])
            if event['database']:
                message += ', database: {}'.format(event['database'])
            if event['application']:
                message += ', application: {}'.format(event['application'])
        elif operation == 'login':
            message += ': username: "{}", nonce: "{}"'.format(
                event['username'], event['nonce']
            )
        message += ' from {}:{}.'.format(event['src_ip'], event['dst_port']) + linesep

        self.outfile.write(message)
        self.outfile.flush()
