
from json import dumps
from redis import from_url

from core import output
from core.config import CONFIG

from twisted.python.log import msg


SEND_METHODS = {
    'lpush': lambda redis_client, key, message: redis_client.lpush(key, message),
    'rpush': lambda redis_client, key, message: redis_client.rpush(key, message),
    'publish': lambda redis_client, key, message: redis_client.publish(key, message),
}


class Output(output.Output):

    def start(self):
        host = CONFIG.get('output_redisdb', 'host')
        port = CONFIG.get('output_redisdb', 'port')
        db = CONFIG.get('output_redisdb', 'db', fallback='0')
        password = CONFIG.get('output_redisdb', 'password', fallback=None, raw=True)
        self.debug = CONFIG.get('output_redisdb', 'debug', fallback=False)
        service_uri = 'rediss://{}:{}@{}:{}'.format(db, password, host, port)
        self.redis_client = from_url(service_uri)
        self.keyname = CONFIG.get('output_redisdb', 'keyname')
        method = CONFIG.get('output_redisdb', 'send_method', fallback='lpush')
        try:
            self.send_method = SEND_METHODS[method]
        except KeyError:
            self.send_method = SEND_METHODS['lpush']

    def stop(self):
        pass

    def write(self, event):
        if self.debug:
            msg(dumps(event))
        self.send_method(self.redis_client, self.keyname, dumps(event))
