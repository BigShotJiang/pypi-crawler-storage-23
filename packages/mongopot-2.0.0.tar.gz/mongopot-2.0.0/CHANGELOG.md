# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.0.0]

### Added in version 2.0.0

* Made the project installable from PyPi.
* Sanity checks for the `blacklist` key in the config file.
* Commands for starting and stopping the honeypot.
* Added documentation for installing the honeypot on Windows.
* The program version now exists in a single place.

### Changed in version 2.0.0

* Bumped the version number.
* Fixed the default port in the documentation and the config file.
* Restructured the MySQL, PostgreSQL, and SQLite database schemas. Note that
  this makes these databases incompatible with version 1.0.1. If you have any
  such databases left over from that version, discard them and start anew.
* Improved the Python 2.x compatibility of the MySQL output plugin.
* Switched to a hardened Docker image for Python and made many improvements
  to the `Dockerfile`.
* The depenency installation now allows you to install only the dependencies for
  the modules that you actually intend to use, instead of all of them; see the
  documentation.

## [1.0.0]

### Added in version 1.0.0

* Initial release
* Config file support
* Log rotation
* Support for the `report_public_ip` config file option
* A script for starting, stopping, and restarting the honeypot
* Documentation
* Output plugin support
* Output plugins for
  * CouchDB
  * Datadog
  * Discord
  * Elasticsearch
  * HPFeeds
  * InfluxDB 2.0
  * JSON
  * Kafka
  * MongoDB
  * MySQL
  * NLCV API
  * PostgeSQL
  * Redis
  * RethinkDB
  * Slack
  * Socket
  * SQLite3
  * Syslog
  * Telegram
  * text
  * XMPP
