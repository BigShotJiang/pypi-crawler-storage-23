#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import absolute_import


from io import open
from os import makedirs, sep, walk
from os.path import (
    abspath,
    dirname,
    exists,
    isdir,
    join,
    relpath,
)
from re import search, IGNORECASE
from setuptools import setup
from setuptools.command.build_py import build_py as _build_py
from setuptools.command.egg_info import egg_info as _egg_info
from shutil import copy2, rmtree
from wheel.bdist_wheel import bdist_wheel as _bdist_wheel


try:
    class bdist_wheel(_bdist_wheel):
        """
        Remove the egg-info directory after building the wheel.
        pip 19.x (Python 2.7) mistakes a leftover egg-info in the source tree
        for an existing installation and skips both copying files to
        site-packages and generating the entry point script.
        """
        def run(self):
            _bdist_wheel.run(self)
            here = dirname(abspath(__file__))
            egg_info = join(here, 'mongopot.egg-info')
            if isdir(egg_info):
                rmtree(egg_info)
    _have_wheel = True
except ImportError:
    _have_wheel = False


class egg_info(_egg_info):
    """
    Redirect the egg-info directory into build/ instead of the source root.

    When a user runs 'python setup.py bdist_wheel' the default behaviour is to
    write mongopot.egg-info into the source tree. pip2 (19.x) then finds this
    egg-info and mistakenly treats the source directory as an existing
    installation, causing 'pip2 install dist/mongopot-*.whl' to silently skip
    installing to site-packages and skip generating the console entry point.

    Redirecting to build/ avoids this: build/ is cleaned between builds and
    pip never looks there for installed packages.
    """
    def initialize_options(self):
        _egg_info.initialize_options(self)
        here = dirname(abspath(__file__))
        build_dir = join(here, 'build')
        if not isdir(build_dir):
            makedirs(build_dir)
        self.egg_base = build_dir


class build_py(_build_py):
    """
    Sync honeypot.py from the repo root into mongopot/ before building.
    This keeps a single source of truth (the root-level script) while ensuring
    the installed package contains it for use by the entry point.

    Note: 'python -m build' uses an isolated PEP 517 environment. The sdist
    already contains honeypot.py at the root, so when the wheel is built from
    the sdist the copy is present and this hook finds it correctly.
    """
    def run(self):
        here = dirname(abspath(__file__))
        src = join(here, 'honeypot.py')
        dst = join(here, 'mongopot', 'honeypot.py')
        if exists(src):
            copy2(src, dst)
        # Also copy Dockerfile from repo root into mongopot/data/ so that
        # `mongopot init` can place it in the working directory.
        dockerfile_src = join(here, 'Dockerfile')
        dockerfile_dst = join(here, 'mongopot', 'data', 'Dockerfile')
        if exists(dockerfile_src):
            copy2(dockerfile_src, dockerfile_dst)
        _build_py.run(self)


def get_package_data():
    """
    Walk mongopot/ and return every non-.py file as a package_data entry.
    Files under data/ are always included even if they have a .py extension
    (e.g. data/test/test.py). Using os.walk means new files are picked up
    automatically without needing to update this list manually.
    """
    here = dirname(abspath(__file__))
    pkg_root = join(here, 'mongopot')
    result = []
    for dirpath, dirnames, filenames in walk(pkg_root):
        dirnames[:] = [d for d in dirnames
                       if d not in ('__pycache__', 'mongopot.egg-info')]
        for filename in filenames:
            abs_path = join(dirpath, filename)
            rel_path = relpath(abs_path, pkg_root)
            is_under_data = rel_path.startswith('data' + sep) or rel_path == 'data'
            # Regular .py package modules are handled by packages=; skip them.
            # Exception: honeypot.py lives directly in mongopot/ and is the
            # main script, included here so the entry point can import it.
            if filename.endswith('.py') and not is_under_data and filename != 'honeypot.py':
                continue
            # Dockerfile is copied into mongopot/data/ by the build hook;
            # include it explicitly even if it isn't present in the source tree.
            result.append(rel_path.replace(sep, '/'))
    # Always include these hook-generated files, whether present yet or not.
    for extra in ('honeypot.py', join('data', 'Dockerfile')):
        entry = extra.replace(sep, '/')
        if entry not in result:
            result.append(entry)
    return result


def get_version():
    here = dirname(abspath(__file__))
    with open(join(here, 'honeypot.py')) as fh:
        content = fh.read()
    match = search(r"__VERSION__\s*=\s*['\"]([^'\"]+)['\"]", content, IGNORECASE)
    if not match:
        raise RuntimeError('Cannot find __VERSION__ in honeypot.py')
    return match.group(1)


# Copy hook-generated files into the package directory before setup() runs,
# so they are present when setuptools assembles the wheel's file list.
# This is necessary because get_package_data() is called at setup() time,
# before any build hooks run, so the files must already exist on disk.
_here = dirname(abspath(__file__))
for _src, _dst in [
    (join(_here, 'honeypot.py'), join(_here, 'mongopot', 'honeypot.py')),
    (join(_here, 'Dockerfile'),  join(_here, 'mongopot', 'data', 'Dockerfile')),
]:
    if exists(_src):
        copy2(_src, _dst)


with open('README.md', encoding='utf-8') as fh:
    long_description = fh.read()


setup(
    name='mongopot',
    version=get_version(),
    description='A MongoDB Honeypot',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='Vesselin Bontchev',
    author_email='vbontchev@yahoo.com',
    url='https://gitlab.com/bontchev/mongopot',
    license='GPLv3',
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Environment :: Console',
        'Intended Audience :: Information Technology',
        'Intended Audience :: Science/Research',
        'Intended Audience :: System Administrators',
        'License :: OSI Approved :: GNU General Public License v3 (GPLv3)',
        'Operating System :: Microsoft :: Windows',
        'Operating System :: POSIX :: Linux',
        'Programming Language :: Python :: 2',
        'Programming Language :: Python :: 2.7',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Programming Language :: Python :: 3.13',
        'Programming Language :: Python :: 3.14',
        'Topic :: Security',
    ],
    python_requires='>=2.7, !=3.0.*, !=3.1.*, !=3.2.*, !=3.3.*, !=3.4.*, !=3.5.*',

    # -------------------------------------------------------------------------
    # Installed packages:
    #   - mongopot       the console entry point + all bundled data assets
    #   - core           the honeypot engine (config, protocol, tools, ...)
    #   - output_plugins one module per output backend
    # -------------------------------------------------------------------------
    packages=['mongopot', 'core', 'output_plugins'],
    package_data={
        'mongopot': get_package_data(),
    },

    cmdclass=dict(
        {'build_py': build_py},
        **({'bdist_wheel': bdist_wheel} if _have_wheel else {})
    ),

    entry_points={
        'console_scripts': [
            'mongopot = mongopot.cli:main',
        ],
    },

    install_requires=[
        'configparser>=3.5.0',
        'geoip2>=2.7.0',
        'ipaddress;python_version<"3"',
        'maxminddb>=1.3.0',
        'pymongo',
        'pytz',
        'requests',
        'service_identity>=18.1.0',
        'twisted>=20.3.0',
    ],

    extras_require={
        'couchdb': ['couchdb'],
        'datadog': [
            'cryptography<=2.2.2',
            'pyOpenSSL<=18.0.0',
        ],
        'elastic': [
            'elasticsearch<=7.13',
            'numpy<=1.26.4',
        ],
        'discord': [],
        'hpfeeds': ['hpfeeds>=3.0.0'],
        'influx2': ['influxdb-client'],		# Python 3 only
        'jsonlog': [],
        'kafka': ['confluent-kafka'],
        'localsyslog': [],
        'mysql': ['mysqlclient>=1.3.12'],
        'nlcvapi': ['pyOpenSSL<=18.0.0'],
        'postgres': ['psycopg2-binary'],
        'redisdb': ['redis'],
        'rethinkdblog': ['rethinkdb>=2.4'],
        'slack': ['slack', 'slackclient'],
        'socketlog': [],
        'sqlite': [],
        'telegram': [],
        'textlog': [],
        'xmpp': ['xmpppy'],
        'all': [
            'couchdb',
            'elasticsearch<=7.13',
            'numpy<=1.26.4',
            'hpfeeds>=3.0.0',
            'influxdb-client',
            'confluent-kafka',
            'mysqlclient>=1.3.12',
            'pyOpenSSL<=18.0.0',
            'cryptography<=2.2.2',
            'psycopg2-binary',
            'redis',
            'rethinkdb>=2.4',
            'slack',
            'slackclient',
            'xmpppy',
        ],
    },
)
