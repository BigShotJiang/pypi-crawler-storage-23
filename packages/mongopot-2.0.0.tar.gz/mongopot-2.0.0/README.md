# MongoPot: a MongoDB Honeypot

This is a honeypot simulating a MongoDB server. It borrows some ideas (mostly -
the communication protocol) from the [Simple MongoDB Honeypot
Server](https://github.com/0xNslabs/mongodb-honeypot) package. However, it has
many improvements, output plug-ins, and so on.

The honeypot does not emulate a full MongoDB server with databases and so on -
it only records the IP of the attacker, the username used, if any, any
pre-authentication commands, and returns an authentication error. It does not
attempt to record the passwords used by the attacker, since these are not
visible when the SCRAM authentication method is used.

## Prerequisites

- a working database server (only if you use an output plugin that outputs to a
database - e.g., MySQL)

## Usage

Check the [installation document](mongopot/data/docs/INSTALL.md) for more information how to
properly install, configure, and run the honeypot.
