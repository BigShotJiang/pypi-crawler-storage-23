# mongopot: the installable Python package for the mongopot honeypot.
#
# After `pip install mongopot`, use the `mongopot` command:
#
#   mongopot init    -- scaffold a working directory
#   mongopot run     -- start the honeypot in the foreground
#   mongopot start   -- start the honeypot in the background
#   mongopot stop    -- stop the background honeypot
#   mongopot status  -- show running status
#
# NOTE: mongopot/honeypot.py is generated at build time by the build_py
# hook in setup.py - it is a copy of the top-level honeypot.py bundled so
# that the `mongopot run/start` entry point can locate and run it.
# It is listed in .gitignore and should not be committed.
#
# Contents:
#   cli.py        the `mongopot` console entry point (init/run/start/stop/status)
#   honeypot.py   the main honeypot script (copied from repo root at build time)
#   data/         bundled read-only assets copied to the working directory
#                 by `mongopot init`:
#     etc/        default configuration templates
#     responses/  MongoDB wire-protocol response stubs
#     docs/       documentation and SQL schema files
#     test/       test.py for verifying a running honeypot
