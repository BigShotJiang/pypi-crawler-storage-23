#!/usr/bin/env python

from argparse import ArgumentParser

from pymongo import MongoClient


__VERSION__ = '1.0.0'
__description__ = 'Test connection to a MongoDB database'
__license__ = 'GPL'
__author__ = 'Vesselin Bontchev'
__email__ = 'vbontchev@yahoo.com'


def get_options():
    parser = ArgumentParser(description=__description__)

    parser.add_argument('-v', '--version', action='version', version='%(prog)s version ' + __VERSION__)
    parser.add_argument('-H', '--host', type=str, default='127.0.0.1',
                        help='Host (default: "%(default)s")')
    parser.add_argument('-P', '--port', type=int, default=27017,
                        help='Port (default: %(default)d)')
    parser.add_argument('-u', '--user', type=str, default='',
                        help='User (default: "%(default)s")')
    parser.add_argument('-p', '--password', type=str, default='',
                        help='Password (default: "%(default)s")')
    args = parser.parse_args()
    return args


def main():
    args = get_options()
    if args.user or args.password:
        uri = 'mongodb://{}:{}@{}:{}/'.format(args.user, args.password, args.host, args.port)
    else:
        uri = 'mongodb://{}:{}/'.format(args.host, args.port)
    try:
        client = MongoClient(uri)
        result = client.admin.command('buildInfo')
        print(result)
        result = client.admin.command('connectionStatus')
        print(result)
        #result = client.admin.command('listCommands')
        #print(result)
        db_list = client.list_database_names()
        print(db_list)
    except Exception as e:
        print('Error: {}'.format(e))


if __name__ == '__main__':
    main()
