
from kafka import KafkaConsumer

site = 'related-elf-6380-eu2-kafka.upstash.io'
port = 9092
username = 'cmVsYXRlZC1lbGYtNjM4MCRRI8ir-97TsOFg0IzoTchxbjXGOF8QUrnSvlihphw'
password = 'ZjZiOWQxNjgtODRiOS00OTM5LWFhYjgtMGQxODY3M2QyZGEw'
topic = 'mssqlpot'

consumer = KafkaConsumer(
    topic,
    bootstrap_servers='{}:{}'.format(site, port),
    sasl_mechanism='SCRAM-SHA-256',
    security_protocol='SASL_SSL',
    sasl_plain_username=username,
    sasl_plain_password=password,
    group_id='TEST_CONSUMER_GROUP',
    auto_offset_reset='earliest'
)

try:
    for message in consumer:
        print('Received message: {}'.format(message.value.decode()))
except KeyboardInterrupt:
    pass
finally:
    consumer.close()
