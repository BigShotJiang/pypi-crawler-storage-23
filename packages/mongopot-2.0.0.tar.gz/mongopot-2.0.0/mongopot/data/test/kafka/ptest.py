
from json import dumps

from kafka import KafkaProducer

site = 'related-elf-6380-eu2-kafka.upstash.io'
port = 9092
username = 'cmVsYXRlZC1lbGYtNjM4MCRRI8ir-97TsOFg0IzoTchxbjXGOF8QUrnSvlihphw'
password = 'ZjZiOWQxNjgtODRiOS00OTM5LWFhYjgtMGQxODY3M2QyZGEw'
topic = 'mssqlpot'

producer = KafkaProducer(
    bootstrap_servers='{}:{}'.format(site, port),
    value_serializer=lambda v: bytes(str(dumps(v)).encode('utf-8')),
    sasl_mechanism='SCRAM-SHA-256',
    security_protocol='SASL_SSL',
    sasl_plain_username=username,
    sasl_plain_password=password
)

event = {
    'session': '07fe771ae1eb',
    'eventid': 'mssqlpot.connect',
    'operation': 'connect',
    'timestamp': '2024-06-25T14:27:59.532996Z',
    'unixtime': 1719325679.5329962,
    'src_ip': '77.85.32.132',
    'src_port': 64008,
    'dst_port': 1433,
    'sensor': 'Vess-Laptop',
    'dst_ip': '192.168.0.100'
}

try:
    producer.send(topic, event)
    producer.flush()
    print('Message sent.')
except Exception as e:
    print('Error producing message: {}'.format(e))
finally:
    producer.close()

