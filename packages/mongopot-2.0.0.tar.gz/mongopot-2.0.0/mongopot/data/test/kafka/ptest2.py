
from json import dumps

import asyncio

from aiokafka import AIOKafkaProducer
from aiokafka.helpers import create_ssl_context

site = 'related-elf-6380-eu2-kafka.upstash.io'
port = 9092
username = 'cmVsYXRlZC1lbGYtNjM4MCRRI8ir-97TsOFg0IzoTchxbjXGOF8QUrnSvlihphw'
password = 'ZjZiOWQxNjgtODRiOS00OTM5LWFhYjgtMGQxODY3M2QyZGEw'
topic = 'mssqlpot'

event = {
    'session': '07fe771ae1eb',
    'eventid': 'mssqlpot.connect',
    'operation': 'connect',
    'timestamp': '2024-06-25T14:27:59.532996Z',
    'unixtime': 1719325679.5329962,
    'src_ip': '77.85.32.132',
    'src_port': 64008,
    'dst_port': 1433,
    'sensor': 'Vess-Laptop',
    'dst_ip': '192.168.0.100'
}

async def send_one():
    producer = AIOKafkaProducer(
        bootstrap_servers='{}:{}'.format(site, port),
        value_serializer=lambda v: bytes(str(dumps(v)).encode('utf-8')),
        sasl_mechanism='SCRAM-SHA-256',
        security_protocol='SASL_SSL',
        sasl_plain_username=username,
        sasl_plain_password=password,
        ssl_context=create_ssl_context()
    )

    await producer.start()
    try:
        # Produce message
        await producer.send_and_wait(topic, event)
    finally:
        # Wait for all pending messages to be delivered or expire.
        await producer.stop()

asyncio.run(send_one())
