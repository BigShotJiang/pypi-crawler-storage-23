
from json import dumps
from sys import stderr

from confluent_kafka import Producer

site = 'related-elf-6380-eu2-kafka.upstash.io'
port = 9092
username = 'cmVsYXRlZC1lbGYtNjM4MCRRI8ir-97TsOFg0IzoTchxbjXGOF8QUrnSvlihphw'
password = 'ZjZiOWQxNjgtODRiOS00OTM5LWFhYjgtMGQxODY3M2QyZGEw'
topic = 'mempot'

producer = Producer({
    'bootstrap.servers': '{}:{}'.format(site, port),
    #'value.serializer': lambda v: bytes(str(dumps(v)).encode('utf-8')),
    'sasl.mechanism': 'SCRAM-SHA-256',
    'security.protocol': 'SASL_SSL',
    'sasl.username': username,
    'sasl.password': password
})

event = {
    'session': '07fe771ae1eb',
    'eventid': 'mempot.connect',
    'operation': 'connect',
    'timestamp': '2024-06-25T14:27:59.532996Z',
    'unixtime': 1719325679.5329962,
    'src_ip': '77.85.32.132',
    'src_port': 64008,
    'dst_port': 1433,
    'sensor': 'Vess-Laptop',
    'dst_ip': '192.168.0.100'
}

def delivery_callback(err, msg):
    if err:
        stderr.write('%% Message failed delivery: %s\n' % err)
    else:
        stderr.write('%% Message delivered to %s [%d] @ %d\n' %
                     (msg.topic(), msg.partition(), msg.offset()))

try:
    producer.produce(
        topic,
        bytes(str(dumps(event)).encode('utf-8')),
        callback=delivery_callback
    )
    producer.poll(0)
    print('Message sent.')
except Exception as e:
    print('Error producing message: {}'.format(e))
finally:
    producer.flush()

