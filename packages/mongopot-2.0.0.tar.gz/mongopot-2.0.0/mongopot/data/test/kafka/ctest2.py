
from sys import stderr

from confluent_kafka import Consumer

site = 'related-elf-6380-eu2-kafka.upstash.io'
port = 9092
username = 'cmVsYXRlZC1lbGYtNjM4MCRRI8ir-97TsOFg0IzoTchxbjXGOF8QUrnSvlihphw'
password = 'ZjZiOWQxNjgtODRiOS00OTM5LWFhYjgtMGQxODY3M2QyZGEw'
topic = 'mempot'

consumer = Consumer({
    'bootstrap.servers': '{}:{}'.format(site, port),
    'sasl.mechanism': 'SCRAM-SHA-256',
    'security.protocol': 'SASL_SSL',
    'sasl.username': username,
    'sasl.password': password,
    'group.id': 'TEST_CONSUMER_GROUP',
    'auto.offset.reset': 'earliest'
})

consumer.subscribe([topic])

try:
    while True:
        msg = consumer.poll(timeout=1.0)
        if msg is None:
            continue
        stderr.write('%% %s [%d] at offset %d with key %s:\n' %
                     (msg.topic(), msg.partition(), msg.offset(),
                      str(msg.key())))
        print('Received message: {}'.format(msg.value().decode('utf-8')))
        #consumer.store_offsets(msg)
except KeyboardInterrupt:
    print('Stopped.')
finally:
    consumer.close()
