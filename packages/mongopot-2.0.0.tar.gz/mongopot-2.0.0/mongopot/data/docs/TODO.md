# Planned Future Improvements

* Additional output plugins for:
  * DShield
  * Graylog
  * InfluxDB
  * Oracle Cloud
  * Splunk
