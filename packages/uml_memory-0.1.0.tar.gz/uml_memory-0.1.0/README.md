# uml-memory

MCP server for [Unified Memory Layer](https://github.com/unified-memory-layer/uml) — persistent memory across AI coding tools.

## Quick Start

```bash
pip install uml-memory
```

Add to your MCP config (`~/.cursor/mcp.json` for Cursor):

```json
{
  "mcpServers": {
    "uml": {
      "command": "uvx",
      "args": ["uml-memory"],
      "env": {
        "UML_API_URL": "https://your-server.com",
        "UML_API_TOKEN": "your-token-here"
      }
    }
  }
}
```

Restart your IDE. The MCP tools will appear automatically.

## What It Does

Once configured, your AI coding agent will automatically:

- **Compose context** at the start of every task (loads relevant decisions, constraints, and patterns)
- **Save memories** when important decisions or insights emerge during conversations
- **Check lessons learned** before risky operations like deployments or migrations

## Available Tools

| Tool | Description |
|------|-------------|
| `uml_compose` | Load relevant context at the start of a task |
| `uml_save_memory` | Save a decision, constraint, or insight |
| `uml_search` | Search memories by keyword or meaning |
| `uml_list_projects` | List all projects with saved memories |
| `uml_save_conversation` | Extract insights from a conversation |
| `uml_detect_memories` | Analyze text for high-value content |
| `uml_check_lessons` | Check lessons learned before risky operations |
| `uml_generate_rules` | Generate AGENTS.md or .cursor/rules from memories |
| `uml_import_transcript` | Import conversation transcripts |

## Getting Your Token

1. Log in to your UML instance
2. Go to **Settings**
3. Click **Generate API Token**
4. Copy the token into your `mcp.json`
