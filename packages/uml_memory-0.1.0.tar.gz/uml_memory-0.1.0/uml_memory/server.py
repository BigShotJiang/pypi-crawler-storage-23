"""
UML MCP Server — persistent memory across AI coding tools.

A thin protocol adapter that exposes the UML REST API as MCP tools
for AI coding agents (Cursor, Claude Code, Windsurf, VS Code).

Configuration via environment variables:
    UML_API_URL   — Base URL of the UML backend (default: http://localhost:8000)
    UML_API_TOKEN — Bearer token for authentication (required)

Install:
    pip install uml-memory

Cursor configuration (~/.cursor/mcp.json):
    {
      "mcpServers": {
        "uml": {
          "command": "uvx",
          "args": ["uml-memory"],
          "env": {
            "UML_API_URL": "https://your-server.com",
            "UML_API_TOKEN": "<your-bearer-token>"
          }
        }
      }
    }
"""
from __future__ import annotations

import json
import logging
import os
import sys
from typing import Any

import httpx
from mcp.server.fastmcp import FastMCP

logging.basicConfig(level=logging.INFO, stream=sys.stderr)
logger = logging.getLogger("uml-mcp")

UML_API_URL = os.environ.get("UML_API_URL", "http://localhost:8000").rstrip("/")
UML_API_TOKEN = os.environ.get("UML_API_TOKEN", "")

if not UML_API_TOKEN:
    logger.warning(
        "UML_API_TOKEN is not set. All tool calls will fail with 401. "
        "Set it via environment variable when configuring the MCP server."
    )

mcp = FastMCP(
    "uml-memory",
    instructions=(
        "UML (Unified Memory Layer) is your persistent memory across all AI sessions. "
        "You MUST follow these behaviors:\n"
        "\n"
        "1. COMPOSE FIRST — ALWAYS call uml_compose at the START of every task, "
        "conversation, or new request BEFORE doing any work. Do not ask the user; just do it. "
        "This loads relevant decisions, constraints, and context from past sessions.\n"
        "\n"
        "2. SAVE PROACTIVELY — ALWAYS call uml_save_memory when ANY of these occur "
        "during the conversation:\n"
        "   - A technical decision is made (e.g., choosing a library, architecture pattern, API design)\n"
        "   - A constraint or requirement is discovered\n"
        "   - A bug is diagnosed and a root cause identified\n"
        "   - A non-obvious insight, workaround, or pattern is established\n"
        "   - The user states a preference about how they want things done\n"
        "   Do NOT wait for the user to ask you to save. Save as decisions emerge.\n"
        "\n"
        "3. CHECK LESSONS — Call uml_check_lessons before risky operations "
        "(deployments, migrations, security changes, infrastructure modifications).\n"
        "\n"
        "These are not suggestions. They are mandatory behaviors."
    ),
)

# ---------------------------------------------------------------------------
# HTTP client helpers
# ---------------------------------------------------------------------------

_TIMEOUT = httpx.Timeout(30.0, connect=10.0)


async def _api_request(
    method: str,
    path: str,
    *,
    json_body: dict[str, Any] | None = None,
    params: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Make an authenticated request to the UML backend."""
    headers = {"Authorization": f"Bearer {UML_API_TOKEN}"}
    url = f"{UML_API_URL}/v1{path}"

    clean_params = {k: v for k, v in (params or {}).items() if v is not None}

    async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
        resp = await client.request(
            method,
            url,
            headers=headers,
            json=json_body,
            params=clean_params or None,
        )
        if resp.status_code == 401:
            return {"error": "Authentication failed. Check your UML_API_TOKEN."}
        if resp.status_code >= 400:
            detail = resp.text[:500]
            try:
                detail = resp.json().get("detail", detail)
            except Exception:
                pass
            return {"error": f"API error ({resp.status_code}): {detail}"}
        return resp.json()


# ---------------------------------------------------------------------------
# MCP Tools
# ---------------------------------------------------------------------------


@mcp.tool()
async def uml_compose(
    task: str,
    project: str | None = None,
    max_tokens: int = 12000,
) -> str:
    """MANDATORY: Call this FIRST at the start of EVERY task before doing any work.

    This loads decisions, constraints, patterns, and context from past sessions
    across all AI tools. The context pack is intent-aware — it understands what
    you're doing and surfaces the most relevant memories.

    Do NOT skip this step. Do NOT ask the user if they want context loaded.
    Always call this proactively as your first action on any new request.

    Args:
        task: Description of what you're working on (e.g., "implement JWT auth middleware")
        project: Optional project name to scope memories (e.g., "my-saas-app")
        max_tokens: Maximum context pack size in tokens (default 12000)
    """
    result = await _api_request("POST", "/context/compose", json_body={
        "task": task,
        "project": project,
        "max_tokens": max_tokens,
        "tool": "mcp",
    })

    if "error" in result:
        return f"Error: {result['error']}"

    pack = result.get("context_pack", "")
    count = len(result.get("selected_memories", []))
    intent = result.get("intent", "general")

    if not pack.strip():
        return "No relevant memories found for this task. Start saving memories with uml_save_memory."

    return f"[{count} memories | intent: {intent}]\n\n{pack}"


@mcp.tool()
async def uml_save_memory(
    text: str,
    project: str | None = None,
    tags: str | None = None,
    source: str = "mcp",
    importance: int = 3,
) -> str:
    """MANDATORY: Save knowledge as a persistent memory whenever decisions or insights emerge.

    You MUST call this proactively — do NOT wait for the user to ask. Save when ANY of these
    occur in the conversation:
    - A technical decision is made (library choice, architecture, API design, config)
    - A constraint or hard requirement is discovered
    - A bug root cause is identified or a non-obvious fix is applied
    - A useful pattern, workaround, or insight is established
    - The user expresses a preference about workflow, style, or approach
    - A significant trade-off is discussed and a direction is chosen

    These memories persist across ALL AI tools and sessions — they are the user's
    institutional knowledge. When in doubt, save it. Redundancy is handled automatically.

    Args:
        text: The content to save — be specific and include the WHY, not just the WHAT
        project: Project name to associate with (e.g., "my-saas-app")
        tags: Optional comma-separated tags (e.g., "auth, security, decision")
        source: Source identifier (default "mcp")
        importance: 1-5 importance level (3=normal, 4=important decision, 5=critical constraint)
    """
    tag_list = [t.strip() for t in tags.split(",") if t.strip()] if tags else []

    body: dict[str, Any] = {
        "text": text,
        "source": source,
        "importance": importance,
    }
    if project:
        body["project"] = project
    if tag_list:
        body["tags"] = tag_list

    result = await _api_request("POST", "/memory/ingest", json_body=body)

    if "error" in result:
        return f"Error: {result['error']}"

    mid = result.get("memory_id", "?")
    status = result.get("status", "unknown")
    return f"Memory saved (id: {mid}, status: {status}). It will be classified and embedded shortly."


@mcp.tool()
async def uml_search(
    query: str,
    project: str | None = None,
    tags: str | None = None,
    type: str | None = None,
    limit: int = 10,
) -> str:
    """Search your memory bank for specific knowledge by keyword or meaning.

    Use for targeted lookups when you need a specific decision, constraint,
    or piece of context. For broad task-based context loading, use uml_compose instead.

    Args:
        query: Search query (supports semantic similarity + keyword matching)
        project: Optional project filter
        tags: Optional comma-separated tag filters (e.g., "auth, security")
        type: Optional type filter (decision, constraint, preference, goal, context, fact, note)
        limit: Max results (default 10)
    """
    params: dict[str, Any] = {"q": query, "limit": limit}
    if project:
        params["project"] = project
    if type:
        params["type"] = type
    if tags:
        params["tags"] = [t.strip() for t in tags.split(",") if t.strip()]

    result = await _api_request("GET", "/memory", params=params)

    if isinstance(result, dict) and "error" in result:
        return f"Error: {result['error']}"

    if not isinstance(result, list):
        return "No results found."

    if not result:
        return "No memories match your search."

    lines = [f"Found {len(result)} memories:\n"]
    for i, mem in enumerate(result, 1):
        text = mem.get("text", "")
        preview = text[:300] + "..." if len(text) > 300 else text
        mtype = ""
        if mem.get("derived") and mem["derived"].get("type"):
            mtype = f" [{mem['derived']['type']}]"
        proj = f" (project: {mem['project']})" if mem.get("project") else ""
        tags_str = f" tags: {mem['tags']}" if mem.get("tags") else ""

        lines.append(f"--- Memory {i} (id: {mem['id']}){mtype}{proj}{tags_str}")
        lines.append(preview)
        lines.append("")

    return "\n".join(lines)


@mcp.tool()
async def uml_list_projects() -> str:
    """List all projects in your memory bank.

    Returns the names of all projects that have associated memories.
    Use these project names with other tools to scope operations.
    """
    result = await _api_request("GET", "/memory/projects")

    if isinstance(result, dict) and "error" in result:
        return f"Error: {result['error']}"

    if not isinstance(result, list) or not result:
        return "No projects found. Save memories with a project name to create projects."

    return "Projects:\n" + "\n".join(f"  - {p}" for p in result)


@mcp.tool()
async def uml_save_conversation(
    messages: str,
    source: str = "mcp",
    project: str | None = None,
) -> str:
    """Save a multi-turn conversation and extract valuable insights from it.

    The conversation will be analyzed by an LLM to extract decisions,
    constraints, insights, and other high-value content as separate memories.

    Args:
        messages: JSON string of conversation messages, e.g. '[{"role":"user","content":"..."},{"role":"assistant","content":"..."}]'
        source: Source identifier (e.g., "cursor", "claude-code", "chatgpt")
        project: Optional project to associate extracted insights with
    """
    try:
        parsed_messages = json.loads(messages) if isinstance(messages, str) else messages
    except (json.JSONDecodeError, TypeError):
        return "Error: messages must be a valid JSON array of {role, content} objects."

    body: dict[str, Any] = {
        "messages": parsed_messages,
        "source": source,
    }
    if project:
        body["project"] = project

    result = await _api_request("POST", "/memory/ingest-conversation", json_body=body)

    if isinstance(result, dict) and "error" in result:
        return f"Error: {result['error']}"

    count = result.get("insights_extracted", 0)
    memories = result.get("memories", [])

    if count == 0:
        return "No insights could be extracted from this conversation."

    lines = [f"Extracted {count} insights from the conversation:\n"]
    for m in memories:
        lines.append(f"  - [{m.get('type', '?')}] {m.get('summary', '')}")

    return "\n".join(lines)


@mcp.tool()
async def uml_detect_memories(
    text: str,
) -> str:
    """Analyze text for high-value content worth saving as persistent memories.

    Call this after significant work sessions — debugging, architecture discussions,
    research synthesis — to detect decisions, constraints, and insights that
    should be persisted. Returns suggestions with confidence scores.
    Then call uml_save_memory for each suggestion worth keeping.

    Args:
        text: Conversation or work text to analyze
    """
    result = await _api_request("POST", "/memory/detect", json_body={
        "text": text,
        "min_confidence": 0.7,
    })

    if isinstance(result, dict) and "error" in result:
        return f"Error: {result['error']}"

    suggestions = result.get("suggestions", [])
    if not suggestions:
        return "No high-value content detected in this text."

    lines = [f"Found {len(suggestions)} memories worth saving:\n"]
    for i, s in enumerate(suggestions, 1):
        lines.append(f"{i}. [{s['type']}] (confidence: {s['confidence']}) {s['text']}")
        lines.append("")

    lines.append("Call uml_save_memory for each suggestion you want to keep.")
    return "\n".join(lines)


@mcp.tool()
async def uml_check_lessons(
    task: str,
    project: str | None = None,
) -> str:
    """Check for relevant lessons learned before risky operations. Call proactively.

    ALWAYS call this before: deployments, database migrations, security changes,
    infrastructure modifications, or working in areas with known past issues.
    Do not wait for the user to ask — check proactively when the task involves risk.

    Args:
        task: Description of what you're about to do
        project: Optional project to scope the lesson check
    """
    params: dict[str, Any] = {"task": task}
    if project:
        params["project"] = project

    result = await _api_request("POST", "/lessons/check", json_body=params)

    if isinstance(result, dict) and "error" in result:
        return f"Error: {result['error']}"

    lessons = result.get("lessons", [])
    if not lessons:
        return "No relevant lessons found for this task. Proceed with normal caution."

    lines = [f"Found {len(lessons)} relevant lesson(s):\n"]
    for i, les in enumerate(lessons, 1):
        lines.append(f"--- Lesson {i}: {les.get('title', 'Untitled')}")
        if les.get("trigger"):
            lines.append(f"  Trigger: {les['trigger']}")
        if les.get("impact"):
            lines.append(f"  Impact: {les['impact']}")
        if les.get("prevention"):
            lines.append(f"  Prevention: {les['prevention']}")
        lines.append("")

    return "\n".join(lines)


@mcp.tool()
async def uml_generate_rules(
    project: str | None = None,
    format: str = "agents_md",
) -> str:
    """Generate AGENTS.md, .cursor/rules, or CLAUDE.md from your project memories.

    Composes structured project rules from your decisions, constraints,
    preferences, and other project knowledge. Write the output to the
    appropriate file in your project root.

    Args:
        project: Project to generate rules for (None for all memories)
        format: Output format — "agents_md" (AGENTS.md), "cursor_rules" (.cursor/rules), "claude_md" (CLAUDE.md)
    """
    result = await _api_request("POST", "/export/rules", json_body={
        "format": format,
        "project": project,
    })

    if isinstance(result, dict) and "error" in result:
        return f"Error: {result['error']}"

    content = result.get("content", "")
    rules = result.get("rules_count", 0)
    memories = result.get("memories_used", 0)

    if not content.strip():
        return "No rules could be generated. Save some decision/constraint/preference memories first."

    filename = {
        "agents_md": "AGENTS.md",
        "cursor_rules": ".cursor/rules/uml-rules.mdc",
        "claude_md": "CLAUDE.md",
    }.get(format, "AGENTS.md")

    return f"Generated {rules} rules from {memories} memories. Write this to `{filename}`:\n\n{content}"


@mcp.tool()
async def uml_import_transcript(
    content: str,
    format: str | None = None,
    project: str | None = None,
    source: str = "transcript",
) -> str:
    """Import a conversation transcript and extract insights as memories.

    Supports Claude Code JSONL, Cursor transcripts, ChatGPT export JSON,
    and generic markdown conversations. Format is auto-detected.

    Args:
        content: Raw transcript content (paste the file contents)
        format: Explicit format hint (claude_code, cursor_transcript, chatgpt_export, or auto-detect)
        project: Project to associate extracted insights with
        source: Source identifier
    """
    body: dict[str, Any] = {"source": source}
    if format:
        body["format"] = format
    if project:
        body["project"] = project

    headers = {
        "Authorization": f"Bearer {UML_API_TOKEN}",
    }
    url = f"{UML_API_URL}/v1/memory/import-transcript"

    async with httpx.AsyncClient(timeout=httpx.Timeout(60.0, connect=10.0)) as client:
        resp = await client.post(
            url,
            headers=headers,
            files={"file": ("transcript.txt", content.encode(), "text/plain")},
            data={k: str(v) for k, v in body.items()},
        )

    if resp.status_code >= 400:
        detail = resp.text[:500]
        try:
            detail = resp.json().get("detail", detail)
        except Exception:
            pass
        return f"Error: API error ({resp.status_code}): {detail}"

    result = resp.json()
    count = result.get("insights_extracted", 0)
    fmt = result.get("format_detected", format or "auto")
    convs = result.get("conversations_found", 0)

    return f"Imported {convs} conversation(s), extracted {count} insights (format: {fmt})"


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    """Run the UML MCP server over stdio."""
    if not UML_API_TOKEN:
        print(
            "ERROR: UML_API_TOKEN environment variable is required.\n"
            "Get your token from UML Settings page, then configure it in mcp.json.\n"
            "See: https://github.com/unified-memory-layer/uml",
            file=sys.stderr,
        )
        sys.exit(1)

    logger.info("Starting UML MCP server (api_url=%s)", UML_API_URL)
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
