"""UML Memory — MCP server for Unified Memory Layer."""

__version__ = "0.1.0"
