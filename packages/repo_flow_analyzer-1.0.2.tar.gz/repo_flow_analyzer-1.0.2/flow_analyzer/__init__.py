"""
Repo Flow Analyzer - Universal code flow analysis tool
"""

__version__ = "1.0.2"
__author__ = "Platform Team"

from .analyzer import FlowAnalyzer
from .config import Config

__all__ = ["FlowAnalyzer", "Config"]