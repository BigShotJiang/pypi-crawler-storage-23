"""
Command-line interface for Flow Analyzer
"""

import click
import sys
from pathlib import Path
from .analyzer import FlowAnalyzer
from .config import Config
from .formatters import MarkdownFormatter, MermaidFormatter, JSONFormatter

@click.command()
@click.argument('keyword')
@click.option('--format', '-f', type=click.Choice(['markdown', 'mermaid', 'json']), 
              default='markdown', help='Output format')
@click.option('--output', '-o', type=click.Path(), help='Output file (default: stdout)')
@click.option('--config', '-c', type=click.Path(exists=True), help='Path to custom config file')
@click.option('--base-path', '-p', type=click.Path(exists=True), default='.', 
              help='Base path of the repository')
@click.version_option(version='1.0.2', prog_name='repo-flow-analyzer')
def main(keyword, format, output, config, base_path):
    """
    Analyze code flow in any repository by searching for keywords.
    
    KEYWORD: The search term to find in your codebase
    
    Examples:
    
      flow-analyzer credit
      
      flow-analyzer user --format=mermaid --output=user-flow.mmd
      
      flow-analyzer payment --format=json --config=.flow-analyzer.yaml
    """
    try:
        # Load configuration
        cfg = Config(config)
        
        # Initialize analyzer
        analyzer = FlowAnalyzer(base_path, cfg)
        
        # Perform analysis
        click.echo(f"🔍 Analyzing flow for keyword: '{keyword}'...")
        flow_data = analyzer.analyze(keyword)
        
        # Format output
        if format == 'markdown':
            formatter = MarkdownFormatter(cfg)
            result = formatter.format(flow_data)
        elif format == 'mermaid':
            formatter = MermaidFormatter(cfg)
            result = formatter.format(flow_data)
        else:  # json
            formatter = JSONFormatter(cfg)
            result = formatter.format(flow_data)
        
        # Write output
        if output:
            Path(output).write_text(result, encoding='utf-8')
            click.echo(f"✅ Flow analysis saved to: {output}")
        else:
            click.echo("\n" + result)
            
    except Exception as e:
        click.echo(f"❌ Error: {str(e)}", err=True)
        sys.exit(1)

@click.command()
@click.option('--output', '-o', default='.flow-analyzer.yaml', help='Output file path')
def init(output):
    """Generate a template configuration file"""
    try:
        config = Config()
        config.save_template(output)
        click.echo(f"✅ Configuration template created: {output}")
    except Exception as e:
        click.echo(f"❌ Error: {str(e)}", err=True)
        sys.exit(1)

if __name__ == '__main__':
    main()