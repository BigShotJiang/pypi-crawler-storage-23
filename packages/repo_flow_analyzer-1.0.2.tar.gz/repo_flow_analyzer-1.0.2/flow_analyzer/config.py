"""
Configuration management for Flow Analyzer
"""

import os
import yaml
from pathlib import Path
from typing import Dict, List, Optional


class Config:
    """Configuration loader and manager"""
    
    DEFAULT_CONFIG = {
        "languages": {
            "java": {
                "extensions": [".java"],
                "component_patterns": {
                    "controller": ["controller", "resource", "endpoint"],
                    "service": ["service", "manager", "handler"],
                    "repository": ["repository", "dao", "mapper"],
                    "model": ["model", "dto", "entity", "pojo"],
                    "config": ["config", "configuration"],
                    "connector": ["connector", "client", "adapter"],
                    "consumer": ["consumer", "listener", "subscriber"],
                    "producer": ["producer", "publisher"],
                    "filter": ["filter", "interceptor"],
                    "utility": ["util", "helper", "tool"]
                },
                "method_pattern": r'(?:public|private|protected)\s+(?:static\s+)?(?:<[\w\s,<>]+>\s+)?(\w+(?:<[\w\s,<>]+>)?)\s+(\w+)\s*\([^)]*\)',
                "class_pattern": r'public\s+(?:class|interface|enum)\s+(\w+)',
                "package_pattern": r'package\s+([\w.]+);',
                "import_pattern": r'import\s+([\w.]+);',
                "annotation_pattern": r'@(\w+)(?:\([^)]*\))?'
            },
            "python": {
                "extensions": [".py"],
                "component_patterns": {
                    "controller": ["controller", "view", "api", "endpoint"],
                    "service": ["service", "manager", "handler", "processor"],
                    "repository": ["repository", "dao", "store", "db"],
                    "model": ["model", "schema", "entity", "dto"],
                    "config": ["config", "settings"],
                    "connector": ["connector", "client", "adapter"],
                    "consumer": ["consumer", "listener", "subscriber"],
                    "producer": ["producer", "publisher"],
                    "middleware": ["middleware"],
                    "utility": ["util", "helper", "tool"]
                },
                "method_pattern": r'def\s+(\w+)\s*\(',
                "class_pattern": r'class\s+(\w+)',
                "import_pattern": r'(?:from\s+[\w.]+\s+)?import\s+([\w.,\s]+)'
            },
            "javascript": {
                "extensions": [".js", ".jsx", ".ts", ".tsx"],
                "component_patterns": {
                    "controller": ["controller", "route", "handler"],
                    "service": ["service", "manager"],
                    "repository": ["repository", "dao", "model"],
                    "component": ["component"],
                    "config": ["config"],
                    "connector": ["client", "api"],
                    "middleware": ["middleware"],
                    "utility": ["util", "helper"]
                },
                "method_pattern": r'(?:function\s+(\w+)|(\w+)\s*[=:]\s*(?:async\s+)?(?:function|\(.*?\)\s*=>))',
                "class_pattern": r'class\s+(\w+)',
                "import_pattern": r'import\s+.*?from\s+[\'"]([^\'"]+)[\'"]'
            },
            "go": {
                "extensions": [".go"],
                "component_patterns": {
                    "controller": ["controller", "handler"],
                    "service": ["service", "manager"],
                    "repository": ["repository", "dao", "store"],
                    "model": ["model", "entity"],
                    "config": ["config"],
                    "connector": ["client"],
                    "utility": ["util", "helper"]
                },
                "method_pattern": r'func\s+(?:\([^)]*\)\s+)?(\w+)\s*\(',
                "struct_pattern": r'type\s+(\w+)\s+struct',
                "import_pattern": r'import\s+"([^"]+)"'
            },
            "csharp": {
                "extensions": [".cs"],
                "component_patterns": {
                    "controller": ["controller"],
                    "service": ["service", "manager"],
                    "repository": ["repository", "dao"],
                    "model": ["model", "dto", "entity"],
                    "config": ["config"],
                    "connector": ["client", "adapter"],
                    "utility": ["util", "helper"]
                },
                "method_pattern": r'(?:public|private|protected)\s+(?:static\s+)?(?:async\s+)?[\w<>]+\s+(\w+)\s*\(',
                "class_pattern": r'(?:public|internal)\s+(?:class|interface)\s+(\w+)',
                "namespace_pattern": r'namespace\s+([\w.]+)',
                "using_pattern": r'using\s+([\w.]+);'
            }
        },
        "analysis": {
            "max_files": 10000,
            "max_file_size_mb": 10,
            "exclude_patterns": [
                "**/node_modules/**",
                "**/target/**",
                "**/build/**",
                "**/dist/**",
                "**/.git/**",
                "**/venv/**",
                "**/__pycache__/**",
                "**/bin/**",
                "**/obj/**"
            ],
            "max_methods_display": 15,
            "max_dependencies_display": 20
        },
        "output": {
            "mermaid": {
                "max_nodes": 50,
                "show_connections": True,
                "color_scheme": {
                    "controller": "#e1f5ff",
                    "service": "#f3e5f5",
                    "repository": "#e8f5e9",
                    "connector": "#fff3e0",
                    "consumer": "#fce4ec",
                    "producer": "#e0f2f1"
                }
            },
            "markdown": {
                "include_methods": True,
                "include_dependencies": True,
                "include_annotations": True,
                "max_items_per_section": 100
            }
        }
    }
    
    def __init__(self, config_path: Optional[str] = None):
        """Initialize configuration
        
        Args:
            config_path: Path to custom config file (YAML)
        """
        self.config = self.DEFAULT_CONFIG.copy()
        
        # Load custom config if provided
        if config_path and Path(config_path).exists():
            self.load_config(config_path)
        
        # Check for .flow-analyzer.yaml in current directory
        local_config = Path.cwd() / ".flow-analyzer.yaml"
        if local_config.exists():
            self.load_config(str(local_config))
    
    def load_config(self, config_path: str):
        """Load configuration from YAML file"""
        try:
            with open(config_path, 'r') as f:
                custom_config = yaml.safe_load(f)
                self._merge_config(custom_config)
        except Exception as e:
            print(f"Warning: Could not load config from {config_path}: {e}")
    
    def _merge_config(self, custom_config: Dict):
        """Recursively merge custom config into default config"""
        def merge_dict(base: Dict, updates: Dict):
            for key, value in updates.items():
                if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                    merge_dict(base[key], value)
                else:
                    base[key] = value
        
        merge_dict(self.config, custom_config)
    
    def get(self, key, *nested_keys, default=None):
        """Get configuration value by key(s)
        
        Args:
            key: The first/main key
            *nested_keys: Additional nested keys for deep access
            default: Default value if key not found
        
        Examples:
            config.get("languages")  # Returns languages dict or None
            config.get("languages", {})  # Returns languages dict or {}
            config.get("languages", default={})  # Returns languages dict or {}
            config.get("analysis", "max_files", default=10000)
        """
        # Special case: if first nested_key is not a string/int, treat it as default
        # This handles: config.get("languages", {})
        if nested_keys and len(nested_keys) == 1 and not isinstance(nested_keys[0], (str, int)):
            default = nested_keys[0]
            nested_keys = ()
        
        # If no nested keys, treat like dict.get(key, default)
        if not nested_keys:
            return self.config.get(key, default)
        
        # Navigate nested structure
        value = self.config.get(key)
        if value is None:
            return default
            
        for nested_key in nested_keys:
            if not isinstance(nested_key, (str, int)):
                return default
            if isinstance(value, dict) and nested_key in value:
                value = value[nested_key]
            else:
                return default
        return value
    
    def get_language_config(self, file_extension: str) -> Optional[Dict]:
        """Get language configuration based on file extension"""
        for lang, lang_config in self.config["languages"].items():
            if file_extension in lang_config["extensions"]:
                return {
                    "name": lang,
                    **lang_config
                }
        return None
    
    def is_excluded(self, path: Path, base_path: Path) -> bool:
        """Check if path should be excluded from analysis"""
        relative_path = str(path.relative_to(base_path))
        exclude_patterns = self.config["analysis"]["exclude_patterns"]
        
        from fnmatch import fnmatch
        for pattern in exclude_patterns:
            if fnmatch(relative_path, pattern) or fnmatch(str(path), pattern):
                return True
        return False
    
    def save_template(self, output_path: str = ".flow-analyzer.yaml"):
        """Save a template configuration file"""
        with open(output_path, 'w') as f:
            yaml.dump(self.DEFAULT_CONFIG, f, default_flow_style=False, sort_keys=False)
        print(f"Configuration template saved to: {output_path}")