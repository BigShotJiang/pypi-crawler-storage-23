"""
Output formatters for Flow Analyzer
"""

import json
from typing import Dict
from .config import Config

class BaseFormatter:
    """Base class for formatters"""
    
    def __init__(self, config: Config):
        self.config = config
    
    def format(self, flow_data: Dict) -> str:
        """Format the flow data"""
        raise NotImplementedError

class MarkdownFormatter(BaseFormatter):
    """Format flow data as Markdown"""
    
    def format(self, flow_data: Dict) -> str:
        lines = []
        lines.append(f"# API Flow Analysis: '{flow_data['keyword']}'")
        lines.append(f"\n**Total Files Found:** {flow_data['total_files']}\n")
        
        # Flow Summary
        lines.append("## 📊 Flow Summary\n")
        lines.append("```")
        lines.extend(flow_data["flow_summary"])
        lines.append("```\n")
        
        # Detailed sections
        sections = [
            ("controller", "🌐 API Controllers (Entry Points)", "These handle incoming HTTP requests"),
            ("service", "⚙️ Business Logic Services", "Core business logic implementation"),
            ("repository", "💾 Data Access Objects", "Database operations"),
            ("connector", "🔌 External Connectors", "Integration with external systems"),
            ("consumer", "📬 Message Consumers", "Message queue consumers"),
            ("producer", "📤 Message Producers", "Message queue producers"),
            ("config", "⚙️ Configuration Classes", "Application configuration"),
            ("model", "📦 Models & DTOs", "Data transfer objects and entities"),
        ]
        
        max_items = self.config.get("output", "markdown", "max_items_per_section", default=100)
        include_methods = self.config.get("output", "markdown", "include_methods", default=True)
        
        for key, title, desc in sections:
            components = flow_data["components"].get(key, [])
            if components:
                lines.append(f"## {title}\n")
                lines.append(f"*{desc}*\n")
                
                for comp in components[:max_items]:
                    class_name = comp.get("class_name") or comp["file"].split("/")[-1].replace(".java", "").replace(".py", "").replace(".js", "")
                    lines.append(f"### `{class_name}`")
                    lines.append(f"- **File:** `{comp['file']}`")
                    lines.append(f"- **Language:** {comp['language']}")
                    
                    if include_methods and comp.get("methods"):
                        lines.append(f"- **Methods ({len(comp['methods'])}):**")
                        for method in comp["methods"][:10]:
                            lines.append(f"  - `{method}()`")
                        if len(comp["methods"]) > 10:
                            lines.append(f"  - *...and {len(comp['methods']) - 10} more*")
                    
                    lines.append("")
                
                if len(components) > max_items:
                    lines.append(f"*...and {len(components) - max_items} more components*\n")
        
        return "\n".join(lines)

class MermaidFormatter(BaseFormatter):
    """Format flow data as Mermaid diagram"""
    
    def format(self, flow_data: Dict) -> str:
        lines = ["```mermaid", "graph TD"]
        
        max_nodes = self.config.get("output", "mermaid", "max_nodes", default=50)
        color_scheme = self.config.get("output", "mermaid", "color_scheme", default={})
        
        node_id = 0
        node_map = {}
        
        # Add nodes
        sections = [
            ("controller", "⭐"),
            ("service", "⚙️"),
            ("repository", "💾"),
            ("connector", "🔌"),
            ("consumer", "📬"),
            ("producer", "📤"),
        ]
        
        all_nodes = 0
        for key, icon in sections:
            components = flow_data["components"].get(key, [])
            for comp in components:
                if all_nodes >= max_nodes:
                    break
                    
                class_name = comp.get("class_name") or comp["file"].split("/")[-1].split(".")[0]
                node_name = f"{icon} {class_name}"
                node_map[class_name] = f"N{node_id}"
                
                # Add node with style
                if key == "controller":
                    lines.append(f"    N{node_id}[{node_name}]:::controller")
                elif key == "service":
                    lines.append(f"    N{node_id}[{node_name}]:::service")
                elif key == "repository":
                    lines.append(f"    N{node_id}[({node_name})]:::repository")
                elif key == "connector":
                    lines.append(f"    N{node_id}{{{{{node_name}}}}}:::connector")
                else:
                    lines.append(f"    N{node_id}[{node_name}]:::{key}")
                
                node_id += 1
                all_nodes += 1
            
            if all_nodes >= max_nodes:
                break
        
        # Add simple connections (inferred from typical patterns)
        controllers = flow_data["components"].get("controller", [])
        services = flow_data["components"].get("service", [])
        repos = flow_data["components"].get("repository", [])
        
        # Connect controllers to services
        for i, ctrl in enumerate(controllers[:5]):
            ctrl_name = ctrl.get("class_name") or ctrl["file"].split("/")[-1].split(".")[0]
            if ctrl_name in node_map and i < len(services):
                svc = services[i]
                svc_name = svc.get("class_name") or svc["file"].split("/")[-1].split(".")[0]
                if svc_name in node_map:
                    lines.append(f"    {node_map[ctrl_name]} --> {node_map[svc_name]}")
        
        # Connect services to repositories
        for i, svc in enumerate(services[:5]):
            svc_name = svc.get("class_name") or svc["file"].split("/")[-1].split(".")[0]
            if svc_name in node_map and i < len(repos):
                repo = repos[i]
                repo_name = repo.get("class_name") or repo["file"].split("/")[-1].split(".")[0]
                if repo_name in node_map:
                    lines.append(f"    {node_map[svc_name]} --> {node_map[repo_name]}")
        
        # Add styles
        lines.append("")
        lines.append(f"    classDef controller fill:{color_scheme.get('controller', '#e1f5ff')},stroke:#01579b,stroke-width:2px")
        lines.append(f"    classDef service fill:{color_scheme.get('service', '#f3e5f5')},stroke:#4a148c,stroke-width:2px")
        lines.append(f"    classDef repository fill:{color_scheme.get('repository', '#e8f5e9')},stroke:#1b5e20,stroke-width:2px")
        lines.append(f"    classDef connector fill:{color_scheme.get('connector', '#fff3e0')},stroke:#e65100,stroke-width:2px")
        lines.append(f"    classDef consumer fill:{color_scheme.get('consumer', '#fce4ec')},stroke:#880e4f,stroke-width:2px")
        lines.append(f"    classDef producer fill:{color_scheme.get('producer', '#e0f2f1')},stroke:#004d40,stroke-width:2px")
        lines.append("```")
        
        return "\n".join(lines)

class JSONFormatter(BaseFormatter):
    """Format flow data as JSON"""
    
    def format(self, flow_data: Dict) -> str:
        return json.dumps(flow_data, indent=2, ensure_ascii=False)