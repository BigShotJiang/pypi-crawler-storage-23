class ValidationWarning(Warning):
    """A warning indicating a potential issue with OME-Zarr storage or metadata."""
