def test_bf2raw_v04():
    from yaozarrs.v04._bf2raw import Bf2Raw

    Bf2Raw(bioformats2raw_layout=3)  # type: ignore
