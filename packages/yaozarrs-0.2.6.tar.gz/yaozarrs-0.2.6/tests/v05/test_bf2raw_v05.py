def test_bf2raw_v05():
    from yaozarrs.v05._bf2raw import Bf2Raw

    Bf2Raw(bioformats2raw_layout=3)  # type: ignore
