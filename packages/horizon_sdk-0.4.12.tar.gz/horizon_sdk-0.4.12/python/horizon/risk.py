"""Risk configuration builder."""

from __future__ import annotations

from horizon._horizon import RiskConfig


class Risk:
    """Declarative risk config builder.

    Usage:
        Risk(max_position=100, max_drawdown_pct=5)
    """

    def __init__(
        self,
        max_position: float = 100.0,
        max_notional: float = 1000.0,
        max_drawdown_pct: float = 5.0,
        max_order_size: float = 50.0,
        rate_limit: int = 50,
        rate_burst: int = 300,
    ):
        self.max_position = max_position
        self.max_notional = max_notional
        self.max_drawdown_pct = max_drawdown_pct
        self.max_order_size = max_order_size
        self.rate_limit = rate_limit
        self.rate_burst = rate_burst

    def to_config(self) -> RiskConfig:
        """Convert to the Rust RiskConfig."""
        return RiskConfig(
            max_position_per_market=self.max_position,
            max_portfolio_notional=self.max_notional,
            max_daily_drawdown_pct=self.max_drawdown_pct,
            max_order_size=self.max_order_size,
            rate_limit_sustained=self.rate_limit,
            rate_limit_burst=self.rate_burst,
        )
