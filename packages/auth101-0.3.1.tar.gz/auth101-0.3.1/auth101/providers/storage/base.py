from abc import ABC, abstractmethod
from datetime import datetime
from typing import List, Optional

from ...domain import Account, Session, User, Verification


class UserStore(ABC):
    """Abstract user store interface.

    Implementations must be synchronous and simple: create/get/update.
    """

    @abstractmethod
    def create_user(self, user: User) -> User:
        raise NotImplementedError()

    @abstractmethod
    def get_user_by_email(self, email: str) -> Optional[User]:
        raise NotImplementedError()

    @abstractmethod
    def update_user(self, user: User) -> User:
        raise NotImplementedError()


class SessionStore(ABC):
    """Abstract session store for refresh-token revocation and rotation."""

    @abstractmethod
    def create_session(self, user_id: str, jti: str, expires_at: datetime) -> Session:
        raise NotImplementedError()

    @abstractmethod
    def get_session_by_jti(self, jti: str) -> Optional[Session]:
        raise NotImplementedError()

    @abstractmethod
    def delete_session_by_jti(self, jti: str) -> None:
        raise NotImplementedError()

    @abstractmethod
    def delete_sessions_for_user(self, user_id: str) -> None:
        raise NotImplementedError()


class AccountStore(ABC):
    """Abstract account store (one row per provider per user)."""

    @abstractmethod
    def create_account(self, account: Account) -> Account:
        raise NotImplementedError()

    @abstractmethod
    def get_account_by_user_and_provider(
        self, user_id: str, provider_id: str
    ) -> Optional[Account]:
        raise NotImplementedError()

    @abstractmethod
    def get_accounts_by_user(self, user_id: str) -> List[Account]:
        raise NotImplementedError()

    @abstractmethod
    def update_account(self, account: Account) -> Account:
        raise NotImplementedError()


class VerificationStore(ABC):
    """Abstract verification store (email verification, password reset tokens, etc.)."""

    @abstractmethod
    def create(self, verification: Verification) -> Verification:
        raise NotImplementedError()

    @abstractmethod
    def get_by_id(self, id: str) -> Optional[Verification]:
        raise NotImplementedError()

    @abstractmethod
    def get_by_identifier_and_value(
        self, identifier: str, value: str
    ) -> Optional[Verification]:
        raise NotImplementedError()

    @abstractmethod
    def delete(self, id: str) -> None:
        raise NotImplementedError()
