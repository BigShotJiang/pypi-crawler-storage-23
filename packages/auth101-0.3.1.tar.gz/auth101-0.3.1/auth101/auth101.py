"""
Auth101 - Simple email/password authentication for Python.

Access + refresh token auth with session table for revocation.

    from auth101 import Auth101
    from auth101.adapters import SQLAlchemyAdapter

    adapter = SQLAlchemyAdapter("sqlite:///auth.db")
    auth = Auth101(secret="...", database=adapter)

    # user = customize the table auth101 creates and manages (migrate will create it).
    auth = Auth101(
        secret="...",
        database=adapter,
        user={"model_name": "users", "fields": {"name": "full_name", "email": "email_address"}},
        session={"model_name": "my_sessions"},
        # account and verification omitted → use default tables, migrate will create them
    )

    # user_field_mapping = use your own user table (you manage it); include table_name + mapping.
    auth = Auth101(
        secret="...",
        database=adapter,
        user_field_mapping={"table_name": "app_user", "fields": {"email": "email_address", "name": "full_name"}},
    )

    # FastAPI
    app.include_router(auth.fastapi_router(), prefix="/auth")
    # Flask
    app.register_blueprint(auth.flask_blueprint(), url_prefix="/auth")
    # Django
    # urls.py  →  path("auth/", include(auth.django_urls()))
    # settings.py  →  MIDDLEWARE = [..., auth.get_django_middleware()]

Endpoints (relative to mount prefix):
    POST /sign-up/email   { email, password }  → { user, access_token, refresh_token, expires_in }
    POST /sign-in/email   { email, password }  → { user, access_token, refresh_token, expires_in }
    POST /refresh         { refresh_token }   → { user, access_token, refresh_token, expires_in }
    POST /revoke          { refresh_token }   → { success }
    POST /sign-out        Bearer access_token → { success }
    GET  /session         Bearer access_token → { user }
"""

from typing import Any, Dict, Optional

from .adapters.base import DatabaseAdapter
from .domain import User
from .factory import Auth101Wiring, build_auth101_wiring


class Auth101:
    """Main Auth101 facade providing authentication and framework integration."""

    def __init__(
        self,
        secret: Optional[str] = None,
        database: Optional[DatabaseAdapter] = None,
        user: Optional[Dict[str, Any]] = None,
        session: Optional[Dict[str, Any]] = None,
        account: Optional[Dict[str, Any]] = None,
        verification: Optional[Dict[str, Any]] = None,
        user_field_mapping: Optional[Dict[str, Any]] = None,
        access_token_expires_in: int = 60,
        refresh_token_expires_in: int = 60 * 24 * 7,
        *,
        _wiring: Optional[Auth101Wiring] = None,
    ) -> None:
        """Initialize Auth101 with configuration and storage.

        Args:
            secret: Secret key for JWT token signing (required unless _wiring is provided).
            database: Database adapter (e.g. SQLAlchemyAdapter(engine), DjangoAdapter(UserModel)).
            user: Optional. Customize the user table that **auth101 creates and manages**.
                Use {"model_name": "users", "fields": {"name": "full_name", ...}}.
                Migrations will create this table; you only customize its name and column names.
            session: Optional entity config for session table. Omit to use default and let migrate create it.
            account: Optional entity config for account table. Omit to use default and let migrate create it.
            verification: Optional entity config for verification table. Omit to use default and let migrate create it.
            user_field_mapping: Optional. Use **your own** user table (you create and manage it).
                Must include "table_name" (or "model_name") and optionally "fields" (auth101 field -> your column).
                Example: {"table_name": "app_user", "fields": {"email": "email_address"}}.
                Auth101 never creates or migrates this table; we only use it via the mapping.
                Mutually exclusive with user: if both are provided, user wins.
            access_token_expires_in: Access token TTL in minutes (default: 60).
            refresh_token_expires_in: Refresh token TTL in minutes (default: 7 days).

        Raises:
            ValueError: If secret is missing, database is None, or user_field_mapping missing table_name.
        """
        if _wiring is not None:
            w = _wiring
        else:
            w = build_auth101_wiring(
                secret=secret,
                database=database,
                user=user,
                session=session,
                account=account,
                verification=verification,
                user_field_mapping=user_field_mapping,
                access_token_expires_in=access_token_expires_in,
                refresh_token_expires_in=refresh_token_expires_in,
            )
        self._wiring = w

    def sign_up(self, email: str, password: str) -> Dict[str, Any]:
        """Register a new user.

        Returns:
            ``{"user": {...}, "access_token": "...", "refresh_token": "...", "expires_in": N}`` on success
            ``{"error": {"message": ..., "code": ...}}`` on failure
        """
        return self._wiring.email_password_service.sign_up(email, password)

    def sign_in(self, email: str, password: str) -> Dict[str, Any]:
        """Authenticate an existing user.

        Returns:
            ``{"user": {...}, "access_token": "...", "refresh_token": "...", "expires_in": N}`` on success
            ``{"error": {...}}`` on failure
        """
        return self._wiring.email_password_service.sign_in(email, password)

    def refresh(self, refresh_token: str) -> Dict[str, Any]:
        """Exchange a refresh token for new access and refresh tokens (rotation).

        Returns:
            ``{"user": {...}, "access_token": "...", "refresh_token": "...", "expires_in": N}`` on success
            ``{"error": {...}}`` on failure
        """
        return self._wiring.session_service.refresh(refresh_token)

    def revoke_session(self, refresh_token: str) -> Dict[str, Any]:
        """Revoke the session for the given refresh token (e.g. on logout).

        Returns:
            ``{"success": True}`` on success
            ``{"error": {...}}`` on failure
        """
        return self._wiring.session_service.revoke_session(refresh_token)

    def sign_out(self, token: str) -> Dict[str, Any]:
        """Validate an access token and acknowledge sign-out.

        Call revoke_session(refresh_token) to invalidate the session server-side.

        Returns:
            ``{"success": True}`` if the token is valid
            ``{"error": {...}}`` if the token is invalid/expired
        """
        return self._wiring.session_service.sign_out(token)

    def get_session(self, token: str) -> Dict[str, Any]:
        """Return the user associated with an access token.

        Returns:
            ``{"user": {...}}`` if valid
            ``{"error": {...}}`` if not
        """
        return self._wiring.session_service.get_session(token)

    def verify_token(self, token: str) -> Optional[User]:
        """Verify an access token and return the corresponding User, or None.

        Args:
            token: JWT access token (Bearer)

        Returns:
            User instance if valid, None otherwise
        """
        return self._wiring.session_service.verify_token(token)

    def fastapi_router(self):
        """Return a FastAPI ``APIRouter`` with all auth endpoints pre-wired."""
        from .integrations.fastapi import create_router

        return create_router(self)

    def flask_blueprint(self, name: str = "auth101"):
        """Return a Flask ``Blueprint`` with all auth endpoints pre-wired."""
        from .integrations.flask import create_blueprint

        return create_blueprint(self, name)

    def django_urls(self):
        """Return a list of Django ``path()`` entries for all auth endpoints."""
        from .integrations.django import create_url_patterns

        return create_url_patterns(self)

    def get_django_middleware(self):
        """Return a Django middleware *class* that attaches ``request.auth_user``.

        Usage in settings.py::

            from myapp.auth import auth
            Auth101Middleware = auth.get_django_middleware()

            MIDDLEWARE = [
                "myapp.auth.Auth101Middleware",
                ...
            ]
        """
        from .integrations.django import make_middleware

        return make_middleware(self)

    def django_login_required(self):
        """Return a Django view decorator that enforces authentication."""
        from .integrations.django import create_login_required_decorator

        return create_login_required_decorator(self)

    def fastapi_current_user(self):
        """Return a FastAPI dependency that resolves to the authenticated User."""
        from .integrations.fastapi import create_current_user_dependency

        return create_current_user_dependency(self)

    def flask_login_required(self):
        """Return a Flask route decorator that enforces authentication."""
        from .integrations.flask import create_login_required_decorator

        return create_login_required_decorator(self)
