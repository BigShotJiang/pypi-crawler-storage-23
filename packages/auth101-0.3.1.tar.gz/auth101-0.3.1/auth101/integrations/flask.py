"""Flask integration for Auth101.

Usage::

    from flask import Flask
    from auth101 import Auth101

    from auth101.adapters import SQLAlchemyAdapter
    auth = Auth101(secret="...", database=SQLAlchemyAdapter("sqlite:///auth.db"))

    app = Flask(__name__)
    app.register_blueprint(auth.flask_blueprint(), url_prefix="/auth")

Endpoints:
    POST /auth/sign-up/email
    POST /auth/sign-in/email
    POST /auth/refresh
    POST /auth/revoke
    POST /auth/sign-out
    GET  /auth/session

To protect your own routes, use the provided decorator::

    from myapp.auth import auth

    @app.get("/me")
    @auth.flask_login_required()
    def me():
        from flask import g
        return {"email": g.auth_user.email}
"""

from __future__ import annotations

from functools import wraps
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from ..auth101 import Auth101


def create_blueprint(auth: "Auth101", name: str = "auth101"):
    """Create Flask blueprint with all auth endpoints."""
    try:
        from flask import Blueprint, jsonify, request
    except ImportError:
        raise ImportError("Flask is required: pip install flask")

    bp = Blueprint(name, __name__)

    @bp.post("/sign-up/email")
    def sign_up():
        data = _json_body(request)
        result = auth.sign_up(data.get("email", ""), data.get("password", ""))
        if "error" in result:
            return jsonify(result), 400
        return jsonify(result), 201

    @bp.post("/sign-in/email")
    def sign_in():
        data = _json_body(request)
        result = auth.sign_in(data.get("email", ""), data.get("password", ""))
        if "error" in result:
            status = 401 if result["error"]["code"] == "INVALID_CREDENTIALS" else 400
            return jsonify(result), status
        return jsonify(result)

    @bp.post("/refresh")
    def refresh():
        data = _json_body(request)
        refresh_token = data.get("refresh_token", "")
        if not refresh_token:
            return jsonify({"error": {"message": "refresh_token required", "code": "VALIDATION_ERROR"}}), 400
        result = auth.refresh(refresh_token)
        if "error" in result:
            return jsonify(result), 401
        return jsonify(result)

    @bp.post("/revoke")
    def revoke():
        data = _json_body(request)
        refresh_token = data.get("refresh_token", "")
        if not refresh_token:
            return jsonify({"error": {"message": "refresh_token required", "code": "VALIDATION_ERROR"}}), 400
        result = auth.revoke_session(refresh_token)
        if "error" in result:
            return jsonify(result), 401
        return jsonify(result)

    @bp.post("/sign-out")
    def sign_out():
        token = _extract_token(request.headers.get("Authorization", ""))
        if not token:
            return jsonify({"error": {"message": "No token provided", "code": "UNAUTHORIZED"}}), 401
        result = auth.sign_out(token)
        if "error" in result:
            return jsonify(result), 401
        return jsonify(result)

    @bp.get("/session")
    def get_session():
        token = _extract_token(request.headers.get("Authorization", ""))
        if not token:
            return jsonify({"error": {"message": "Unauthorized", "code": "UNAUTHORIZED"}}), 401
        result = auth.get_session(token)
        if "error" in result:
            return jsonify(result), 401
        return jsonify(result)

    return bp


def create_login_required_decorator(auth: "Auth101"):
    """Return a Flask route decorator that enforces authentication."""
    try:
        from flask import g, jsonify, request
    except ImportError:
        raise ImportError("Flask is required: pip install flask")

    def login_required(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            token = _extract_token(request.headers.get("Authorization", ""))
            if not token:
                return jsonify({"error": {"message": "Unauthorized", "code": "UNAUTHORIZED"}}), 401
            user = auth.verify_token(token)
            if not user:
                return jsonify({"error": {"message": "Unauthorized", "code": "UNAUTHORIZED"}}), 401
            g.auth_user = user
            return f(*args, **kwargs)

        return decorated

    return login_required


def _json_body(request) -> dict:
    try:
        return request.get_json(force=True) or {}
    except Exception:
        return {}


def _extract_token(authorization: str) -> Optional[str]:
    if authorization.startswith("Bearer "):
        return authorization[7:]
    return None
