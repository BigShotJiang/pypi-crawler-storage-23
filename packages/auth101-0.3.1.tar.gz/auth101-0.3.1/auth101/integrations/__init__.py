"""Framework integrations for Auth101."""
