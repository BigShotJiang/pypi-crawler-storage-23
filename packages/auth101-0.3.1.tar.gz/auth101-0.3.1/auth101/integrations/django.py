"""Django integration for Auth101.

Usage::

    # myapp/auth.py
    from auth101 import Auth101
    from myapp.models import AuthUser, AuthSession

    from auth101.adapters import DjangoAdapter
    auth = Auth101(secret=settings.SECRET_KEY, database=DjangoAdapter(AuthUser, session_model=AuthSession))

    # Expose the middleware class so Django can import it by dotted path
    Auth101Middleware = auth.get_django_middleware()

    # myproject/settings.py
    MIDDLEWARE = [
        "myapp.auth.Auth101Middleware",
        ...
    ]

    # myproject/urls.py
    from django.urls import include, path
    from myapp.auth import auth

    urlpatterns = [
        path("auth/", include(auth.django_urls())),
        ...
    ]

Endpoints:
    POST /auth/sign-up/email
    POST /auth/sign-in/email
    POST /auth/refresh
    POST /auth/revoke
    POST /auth/sign-out
    GET  /auth/session

The middleware sets ``request.auth_user`` to the authenticated User on every
request that carries a valid Bearer token, or ``None`` otherwise.

To protect views, use the provided decorator::

    from myapp.auth import auth

    @auth.django_login_required()
    def my_view(request):
        return JsonResponse({"email": request.auth_user.email})
"""

from __future__ import annotations

import json
from functools import wraps
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from ..auth101 import Auth101


def create_url_patterns(auth: "Auth101"):
    """Return a list of ``path()`` entries for the four auth endpoints."""
    try:
        from django.http import JsonResponse
        from django.urls import path
        from django.views import View
        from django.views.decorators.csrf import csrf_exempt
    except ImportError:
        raise ImportError("Django is required: pip install django")

    class SignUpView(View):
        def post(self, request):
            data = _json_body(request)
            result = auth.sign_up(data.get("email", ""), data.get("password", ""))
            if "error" in result:
                return JsonResponse(result, status=400)
            return JsonResponse(result, status=201)

    class SignInView(View):
        def post(self, request):
            data = _json_body(request)
            result = auth.sign_in(data.get("email", ""), data.get("password", ""))
            if "error" in result:
                status = 401 if result["error"]["code"] == "INVALID_CREDENTIALS" else 400
                return JsonResponse(result, status=status)
            return JsonResponse(result)

    class RefreshView(View):
        def post(self, request):
            data = _json_body(request)
            refresh_token = data.get("refresh_token", "")
            if not refresh_token:
                return JsonResponse(
                    {"error": {"message": "refresh_token required", "code": "VALIDATION_ERROR"}},
                    status=400,
                )
            result = auth.refresh(refresh_token)
            if "error" in result:
                return JsonResponse(result, status=401)
            return JsonResponse(result)

    class RevokeView(View):
        def post(self, request):
            data = _json_body(request)
            refresh_token = data.get("refresh_token", "")
            if not refresh_token:
                return JsonResponse(
                    {"error": {"message": "refresh_token required", "code": "VALIDATION_ERROR"}},
                    status=400,
                )
            result = auth.revoke_session(refresh_token)
            if "error" in result:
                return JsonResponse(result, status=401)
            return JsonResponse(result)

    class SignOutView(View):
        def post(self, request):
            token = _extract_token(request)
            if not token:
                return JsonResponse(
                    {"error": {"message": "No token provided", "code": "UNAUTHORIZED"}},
                    status=401,
                )
            result = auth.sign_out(token)
            if "error" in result:
                return JsonResponse(result, status=401)
            return JsonResponse(result)

    class SessionView(View):
        def get(self, request):
            token = _extract_token(request)
            if not token:
                return JsonResponse(
                    {"error": {"message": "Unauthorized", "code": "UNAUTHORIZED"}},
                    status=401,
                )
            result = auth.get_session(token)
            if "error" in result:
                return JsonResponse(result, status=401)
            return JsonResponse(result)

    return [
        path("sign-up/email", csrf_exempt(SignUpView.as_view())),
        path("sign-in/email", csrf_exempt(SignInView.as_view())),
        path("refresh", csrf_exempt(RefreshView.as_view())),
        path("revoke", csrf_exempt(RevokeView.as_view())),
        path("sign-out", csrf_exempt(SignOutView.as_view())),
        path("session", csrf_exempt(SessionView.as_view())),
    ]


def make_middleware(auth: "Auth101"):
    """Return a Django middleware class configured for this Auth101 instance."""

    class Auth101Middleware:
        def __init__(self, get_response):
            self.get_response = get_response

        def __call__(self, request):
            token = _extract_token(request)
            request.auth_user = auth.verify_token(token) if token else None
            return self.get_response(request)

    return Auth101Middleware


def create_login_required_decorator(auth: "Auth101"):
    """Return a view decorator that enforces authentication."""
    try:
        from django.http import JsonResponse
    except ImportError:
        raise ImportError("Django is required: pip install django")

    def login_required(view_func):
        @wraps(view_func)
        def wrapper(request, *args, **kwargs):
            token = _extract_token(request)
            if not token:
                return JsonResponse(
                    {"error": {"message": "Unauthorized", "code": "UNAUTHORIZED"}},
                    status=401,
                )
            user = auth.verify_token(token)
            if not user:
                return JsonResponse(
                    {"error": {"message": "Unauthorized", "code": "UNAUTHORIZED"}},
                    status=401,
                )
            request.auth_user = user
            return view_func(request, *args, **kwargs)

        return wrapper

    return login_required


def _extract_token(request) -> Optional[str]:
    auth_header = request.META.get("HTTP_AUTHORIZATION", "")
    if auth_header.startswith("Bearer "):
        return auth_header[7:]
    return None


def _json_body(request) -> dict:
    try:
        return json.loads(request.body) if request.body else {}
    except (json.JSONDecodeError, ValueError):
        return {}
