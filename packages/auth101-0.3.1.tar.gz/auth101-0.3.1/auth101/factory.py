"""
Auth101 factory: config resolution and object graph wiring.

Builds stores, token issuer, and services from config. Auth101 uses this
internally so the main class focuses on the API surface; you can also call
create_auth101() directly for explicit composition.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Dict, Optional, Tuple

if TYPE_CHECKING:
    from .auth101 import Auth101

from .adapters.base import (
    DEFAULT_ACCOUNT_TABLE,
    DEFAULT_SESSION_TABLE,
    DEFAULT_USER_TABLE,
    DEFAULT_VERIFICATION_TABLE,
    DatabaseAdapter,
    USER_FIELDS,
    normalize_account_field_mapping,
    normalize_field_mapping,
    normalize_session_field_mapping,
    normalize_verification_field_mapping,
)
from .features.email_password.service import EmailPasswordService
from .features.sessions.service import SessionService
from .features.sessions.token_issuer import TokenIssuer
from .providers.storage.base import AccountStore, SessionStore, UserStore, VerificationStore

_USER_FIELD_MAPPING_RESERVED = frozenset(("table_name", "model_name", "fields"))


def _parse_user_field_mapping(
    user_field_mapping: Dict[str, Any],
) -> Tuple[str, Dict[str, str]]:
    """Parse user_field_mapping (own-table config) into table_name and field mapping."""
    table_name = user_field_mapping.get("table_name") or user_field_mapping.get("model_name")
    if not table_name:
        raise ValueError(
            "user_field_mapping must include 'table_name' (or 'model_name') when using your own user table. "
            "Example: user_field_mapping={'table_name': 'app_user', 'fields': {'email': 'email_address'}}"
        )
    fields = user_field_mapping.get("fields")
    if fields is not None:
        return str(table_name), normalize_field_mapping(fields)
    flat = {k: v for k, v in user_field_mapping.items() if k not in _USER_FIELD_MAPPING_RESERVED}
    return str(table_name), normalize_field_mapping(flat if flat else None)


def _resolve_entity_config(
    config: Optional[Dict[str, Any]],
    default_table: str,
    normalize_fn,
) -> Tuple[Optional[Dict[str, Any]], str, Dict[str, str]]:
    """Return (raw_config_or_none, table_name, field_mapping)."""
    if not config:
        return None, default_table, normalize_fn(None)
    raw = dict(config)
    model_name = raw.get("model_name")
    table_name = model_name if model_name is not None else default_table
    fields = raw.get("fields")
    field_mapping = normalize_fn(fields)
    return raw, table_name, field_mapping


@dataclass
class Auth101Wiring:
    """Result of config resolution and object graph construction.

    Holds adapter, entity config, resolved table/mappings, and wired services.
    Used by Auth101 and by the CLI for migrations.
    """

    adapter: DatabaseAdapter
    user_table_managed_by_auth101: bool
    entity_config: Dict[str, Optional[Dict[str, Any]]]
    resolved_tables: Dict[str, str]
    resolved_mappings: Dict[str, Dict[str, str]]
    email_password_service: EmailPasswordService
    session_service: SessionService
    store: UserStore


def build_auth101_wiring(
    secret: str,
    database: DatabaseAdapter,
    user: Optional[Dict[str, Any]] = None,
    session: Optional[Dict[str, Any]] = None,
    account: Optional[Dict[str, Any]] = None,
    verification: Optional[Dict[str, Any]] = None,
    user_field_mapping: Optional[Dict[str, Any]] = None,
    access_token_expires_in: int = 60,
    refresh_token_expires_in: int = 60 * 24 * 7,
) -> Auth101Wiring:
    """Resolve config and build the Auth101 object graph.

    Validates secret and database, resolves entity config, obtains stores
    from the adapter, and creates TokenIssuer, EmailPasswordService, and
    SessionService.

    Raises:
        ValueError: If secret is missing, database is None, or user_field_mapping is invalid.
    """
    if not secret:
        raise ValueError("'secret' is required")
    if database is None:
        raise ValueError(
            "'database' is required. "
            "Example: from auth101.adapters import SQLAlchemyAdapter; "
            "database=SQLAlchemyAdapter('sqlite:///auth.db')"
        )

    if user is not None:
        _, user_table, user_mapping = _resolve_entity_config(
            user, DEFAULT_USER_TABLE, normalize_field_mapping
        )
        user_table_managed_by_auth101 = True
        entity_config_user = user
    elif user_field_mapping is not None:
        user_table, user_mapping = _parse_user_field_mapping(user_field_mapping)
        user_table_managed_by_auth101 = False
        entity_config_user = None
    else:
        _, user_table, user_mapping = _resolve_entity_config(
            None, DEFAULT_USER_TABLE, normalize_field_mapping
        )
        user_table_managed_by_auth101 = True
        entity_config_user = None

    _, session_table, session_mapping = _resolve_entity_config(
        session, DEFAULT_SESSION_TABLE, normalize_session_field_mapping
    )
    _, account_table, account_mapping = _resolve_entity_config(
        account, DEFAULT_ACCOUNT_TABLE, normalize_account_field_mapping
    )
    _, verification_table, verification_mapping = _resolve_entity_config(
        verification, DEFAULT_VERIFICATION_TABLE, normalize_verification_field_mapping
    )

    def _model(c: Optional[Dict[str, Any]]) -> Any:
        return c.get("model") if c else None

    store: UserStore = database.get_user_store(
        table_name=user_table,
        model=_model(entity_config_user),
        field_mapping=user_mapping,
    )
    session_store: SessionStore = database.get_session_store(
        table_name=session_table,
        model=_model(session),
        field_mapping=session_mapping,
    )
    account_store: AccountStore = database.get_account_store(
        table_name=account_table,
        model=_model(account),
        field_mapping=account_mapping,
    )
    verification_store: VerificationStore = database.get_verification_store(
        table_name=verification_table,
        model=_model(verification),
        field_mapping=verification_mapping,
    )

    token_issuer = TokenIssuer(
        session_store,
        secret,
        access_token_expires_in,
        refresh_token_expires_in,
    )
    email_password_service = EmailPasswordService(
        store,
        account_store,
        token_issuer,
    )
    session_service = SessionService(
        store,
        session_store,
        token_issuer,
        secret,
    )

    return Auth101Wiring(
        adapter=database,
        user_table_managed_by_auth101=user_table_managed_by_auth101,
        entity_config={
            "user": entity_config_user,
            "session": session,
            "account": account,
            "verification": verification,
        },
        resolved_tables={
            "user": user_table,
            "session": session_table,
            "account": account_table,
            "verification": verification_table,
        },
        resolved_mappings={
            "user": user_mapping,
            "session": session_mapping,
            "account": account_mapping,
            "verification": verification_mapping,
        },
        email_password_service=email_password_service,
        session_service=session_service,
        store=store,
    )


def create_auth101(
    secret: str,
    database: DatabaseAdapter,
    user: Optional[Dict[str, Any]] = None,
    session: Optional[Dict[str, Any]] = None,
    account: Optional[Dict[str, Any]] = None,
    verification: Optional[Dict[str, Any]] = None,
    user_field_mapping: Optional[Dict[str, Any]] = None,
    access_token_expires_in: int = 60,
    refresh_token_expires_in: int = 60 * 24 * 7,
) -> Auth101:
    """Build Auth101 from config via the factory (explicit composition).

    Equivalent to Auth101(secret=..., database=..., ...). Use this when you
    want to separate wiring from the facade, or to obtain Auth101Wiring first.
    """
    from .auth101 import Auth101 as Auth101Class

    wiring = build_auth101_wiring(
        secret=secret,
        database=database,
        user=user,
        session=session,
        account=account,
        verification=verification,
        user_field_mapping=user_field_mapping,
        access_token_expires_in=access_token_expires_in,
        refresh_token_expires_in=refresh_token_expires_in,
    )
    return Auth101Class(_wiring=wiring)
