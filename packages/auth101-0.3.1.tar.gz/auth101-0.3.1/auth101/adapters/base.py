"""
Database adapter base and field mapping.

Entity config (user, session, account, verification) is passed to Auth101, not to the adapter.
Adapters receive table_name (or model) and field_mapping when get_*_store() is called.

User table semantics (Auth101):
  - user=... : Auth101 creates and manages the user table; migrate creates it (optional model_name/fields).
  - user_field_mapping=... (with table_name): Integrator's own table; Auth101 never migrates it; we only use it via mapping.
Session/account/verification: present in config = skip migrate; omitted = migrate creates the table.
"""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Dict, Optional, Type

if TYPE_CHECKING:
    from ..providers.storage.base import (
        AccountStore,
        SessionStore,
        UserStore,
        VerificationStore,
    )

# --- Default table names (used when entity is not customized) ---
DEFAULT_USER_TABLE = "users"
DEFAULT_SESSION_TABLE = "session"
DEFAULT_ACCOUNT_TABLE = "account"
DEFAULT_VERIFICATION_TABLE = "verification"

# --- User ---
USER_FIELDS = (
    "id",
    "name",
    "email",
    "email_verified",
    "image",
    "is_active",
    "created_at",
    "updated_at",
)
DEFAULT_USER_FIELD_MAPPING: Dict[str, str] = {
    "id": "id",
    "name": "name",
    "email": "email",
    "email_verified": "email_verified",
    "image": "image",
    "is_active": "is_active",
    "created_at": "created_at",
    "updated_at": "updated_at",
}

# --- Session ---
SESSION_FIELDS = (
    "id",
    "token",
    "expires_at",
    "user_id",
    "ip_address",
    "user_agent",
    "created_at",
    "updated_at",
)
DEFAULT_SESSION_FIELD_MAPPING: Dict[str, str] = {
    "id": "id",
    "token": "token",
    "expires_at": "expires_at",
    "user_id": "user_id",
    "ip_address": "ip_address",
    "user_agent": "user_agent",
    "created_at": "created_at",
    "updated_at": "updated_at",
}

# --- Account ---
ACCOUNT_FIELDS = (
    "id",
    "account_id",
    "provider_id",
    "user_id",
    "password",
    "access_token",
    "refresh_token",
    "id_token",
    "access_token_expires_at",
    "refresh_token_expires_at",
    "scope",
    "created_at",
    "updated_at",
)
DEFAULT_ACCOUNT_FIELD_MAPPING: Dict[str, str] = {
    "id": "id",
    "account_id": "account_id",
    "provider_id": "provider_id",
    "user_id": "user_id",
    "password": "password",
    "access_token": "access_token",
    "refresh_token": "refresh_token",
    "id_token": "id_token",
    "access_token_expires_at": "access_token_expires_at",
    "refresh_token_expires_at": "refresh_token_expires_at",
    "scope": "scope",
    "created_at": "created_at",
    "updated_at": "updated_at",
}

# --- Verification ---
VERIFICATION_FIELDS = (
    "id",
    "identifier",
    "value",
    "expires_at",
    "created_at",
    "updated_at",
)
DEFAULT_VERIFICATION_FIELD_MAPPING: Dict[str, str] = {
    "id": "id",
    "identifier": "identifier",
    "value": "value",
    "expires_at": "expires_at",
    "created_at": "created_at",
    "updated_at": "updated_at",
}


def normalize_field_mapping(
    mapping: Optional[Dict[str, str]] = None,
    *,
    fields_tuple: tuple = USER_FIELDS,
    default_mapping: Optional[Dict[str, str]] = None,
) -> Dict[str, str]:
    """Merge optional mapping with defaults. Missing keys use internal name."""
    if default_mapping is None:
        default_mapping = DEFAULT_USER_FIELD_MAPPING
    out = dict(default_mapping)
    if mapping:
        for k in fields_tuple:
            if k in mapping:
                out[k] = mapping[k]
    return out


def normalize_session_field_mapping(
    mapping: Optional[Dict[str, str]] = None,
) -> Dict[str, str]:
    return normalize_field_mapping(
        mapping,
        fields_tuple=SESSION_FIELDS,
        default_mapping=DEFAULT_SESSION_FIELD_MAPPING,
    )


def normalize_account_field_mapping(
    mapping: Optional[Dict[str, str]] = None,
) -> Dict[str, str]:
    return normalize_field_mapping(
        mapping,
        fields_tuple=ACCOUNT_FIELDS,
        default_mapping=DEFAULT_ACCOUNT_FIELD_MAPPING,
    )


def normalize_verification_field_mapping(
    mapping: Optional[Dict[str, str]] = None,
) -> Dict[str, str]:
    return normalize_field_mapping(
        mapping,
        fields_tuple=VERIFICATION_FIELDS,
        default_mapping=DEFAULT_VERIFICATION_FIELD_MAPPING,
    )


def has_custom_mapping(mapping: Optional[Dict[str, str]] = None) -> bool:
    """True if the user provided a non-identity mapping (custom column names)."""
    if not mapping:
        return False
    normalized = normalize_field_mapping(mapping)
    return normalized != DEFAULT_USER_FIELD_MAPPING or set(mapping) != set(USER_FIELDS)


# Entity config: passed to Auth101. "model_name" = table name (SQLAlchemy); "model" = Django model class.
EntityConfigDict = Dict[str, Any]  # e.g. {"model_name": "users", "fields": {...}} or {"model": UserModel, "fields": {...}}


class DatabaseAdapter(ABC):
    """
    Database adapter: provides stores and optional migration.

    Auth101 passes table_name (and optionally model for Django) and field_mapping
    when calling get_*_store(). Adapter does not store table names in constructor.
    """

    @abstractmethod
    def get_user_store(
        self,
        *,
        table_name: Optional[str] = None,
        model: Optional[Type[Any]] = None,
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> "UserStore":
        """Return a UserStore. SQLAlchemy uses table_name; Django uses model (or constructor default)."""
        raise NotImplementedError()

    @abstractmethod
    def get_session_store(
        self,
        *,
        table_name: Optional[str] = None,
        model: Optional[Type[Any]] = None,
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> "SessionStore":
        """Return a SessionStore."""
        raise NotImplementedError()

    @abstractmethod
    def get_account_store(
        self,
        *,
        table_name: Optional[str] = None,
        model: Optional[Type[Any]] = None,
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> "AccountStore":
        """Return an AccountStore."""
        raise NotImplementedError()

    @abstractmethod
    def get_verification_store(
        self,
        *,
        table_name: Optional[str] = None,
        model: Optional[Type[Any]] = None,
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> "VerificationStore":
        """Return a VerificationStore."""
        raise NotImplementedError()

    def supports_migrate(self) -> bool:
        """Whether this adapter can create tables (e.g. CLI migrate)."""
        return False

    def migrate_user_table(
        self,
        table_name: str = DEFAULT_USER_TABLE,
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> None:
        """Create or ensure the user table exists. Only run for non-customized user."""
        raise NotImplementedError(
            f"{type(self).__name__} does not support migrate_user_table"
        )

    def migrate_sessions_table(
        self,
        table_name: str = DEFAULT_SESSION_TABLE,
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> None:
        """Create or ensure the session table exists. Only run for non-customized session."""
        raise NotImplementedError(
            f"{type(self).__name__} does not support migrate_sessions_table"
        )

    def migrate_account_table(
        self,
        table_name: str = DEFAULT_ACCOUNT_TABLE,
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> None:
        """Create or ensure the account table exists. Only run for non-customized account."""
        raise NotImplementedError(
            f"{type(self).__name__} does not support migrate_account_table"
        )

    def migrate_verification_table(
        self,
        table_name: str = DEFAULT_VERIFICATION_TABLE,
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> None:
        """Create or ensure the verification table exists. Only run for non-customized verification."""
        raise NotImplementedError(
            f"{type(self).__name__} does not support migrate_verification_table"
        )
