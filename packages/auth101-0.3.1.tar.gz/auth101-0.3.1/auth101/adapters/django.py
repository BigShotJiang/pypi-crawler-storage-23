"""Django ORM database adapter (user, account, session, verification)."""

from datetime import datetime
from typing import Any, Dict, List, Optional, Type

from ..domain import Account, Session as SessionModel, User, Verification
from ..providers.storage.base import AccountStore, SessionStore, UserStore, VerificationStore
from .base import DatabaseAdapter, normalize_field_mapping


class DjangoUserStore(UserStore):
    """
    User store backed by a Django model (name, email, email_verified, image, is_active, created_at, updated_at).
    """

    def __init__(
        self,
        model_class: Type[Any],
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> None:
        self.model = model_class
        self._mapping = normalize_field_mapping(field_mapping)

    def _get_attr(self, instance: Any, internal_name: str) -> Any:
        return getattr(instance, self._mapping[internal_name])

    def _set_attr(self, instance: Any, internal_name: str, value: Any) -> None:
        setattr(instance, self._mapping[internal_name], value)

    def _to_model(self, db_user: Any) -> User:
        return User(
            id=str(self._get_attr(db_user, "id")),
            name=str(self._get_attr(db_user, "name") or ""),
            email=str(self._get_attr(db_user, "email") or ""),
            email_verified=bool(self._get_attr(db_user, "email_verified")),
            image=str(self._get_attr(db_user, "image") or ""),
            is_active=bool(self._get_attr(db_user, "is_active")),
            created_at=self._get_attr(db_user, "created_at"),
            updated_at=self._get_attr(db_user, "updated_at"),
            extra={},
        )

    def _to_db(self, user: User) -> Any:
        return self.model(
            **{
                self._mapping["id"]: user.id,
                self._mapping["name"]: user.name or "",
                self._mapping["email"]: user.email,
                self._mapping["email_verified"]: user.email_verified,
                self._mapping["image"]: user.image or "",
                self._mapping["is_active"]: user.is_active,
                self._mapping["created_at"]: user.created_at,
                self._mapping["updated_at"]: user.updated_at,
            }
        )

    def create_user(self, user: User) -> User:
        email_col = self._mapping["email"]
        if self.model.objects.filter(**{email_col: user.email}).exists():
            raise ValueError("user already exists")
        db_user = self._to_db(user)
        db_user.save()
        return self._to_model(db_user)

    def get_user_by_email(self, email: str) -> Optional[User]:
        email_col = self._mapping["email"]
        try:
            db_user = self.model.objects.get(**{email_col: email})
            return self._to_model(db_user)
        except self.model.DoesNotExist:
            return None

    def update_user(self, user: User) -> User:
        try:
            db_user = self.model.objects.get(pk=user.id)
            self._set_attr(db_user, "name", user.name or "")
            self._set_attr(db_user, "email", user.email)
            self._set_attr(db_user, "email_verified", user.email_verified)
            self._set_attr(db_user, "image", user.image or "")
            self._set_attr(db_user, "is_active", user.is_active)
            self._set_attr(db_user, "updated_at", datetime.utcnow())
            db_user.save()
            return self._to_model(db_user)
        except self.model.DoesNotExist:
            raise ValueError("user not found")


class DjangoSessionStore(SessionStore):
    """
    Session store backed by a Django model: token, expires_at, user_id, ip_address, user_agent.
    jti is stored as token.
    """

    def __init__(self, model_class: Type[Any]) -> None:
        self.model = model_class

    def create_session(self, user_id: str, jti: str, expires_at: datetime) -> SessionModel:
        now = datetime.utcnow()
        obj = self.model(
            token=jti,
            expires_at=expires_at,
            user_id=user_id,
            created_at=now,
            updated_at=now,
        )
        obj.save()
        return SessionModel(
            id=str(obj.pk),
            token=jti,
            expires_at=expires_at,
            user_id=user_id,
            created_at=now,
            updated_at=now,
        )

    def get_session_by_jti(self, jti: str) -> Optional[SessionModel]:
        try:
            obj = self.model.objects.get(token=jti)
            return SessionModel(
                id=str(obj.pk),
                token=obj.token,
                expires_at=obj.expires_at,
                user_id=obj.user_id,
                ip_address=getattr(obj, "ip_address", None),
                user_agent=getattr(obj, "user_agent", None),
                created_at=getattr(obj, "created_at", None),
                updated_at=getattr(obj, "updated_at", None),
            )
        except self.model.DoesNotExist:
            return None

    def delete_session_by_jti(self, jti: str) -> None:
        self.model.objects.filter(token=jti).delete()

    def delete_sessions_for_user(self, user_id: str) -> None:
        self.model.objects.filter(user_id=user_id).delete()


class DjangoAccountStore(AccountStore):
    """Account store backed by a Django model."""

    def __init__(self, model_class: Type[Any]) -> None:
        self.model = model_class

    def create_account(self, account: Account) -> Account:
        obj = self.model(
            id=account.id,
            account_id=account.account_id,
            provider_id=account.provider_id,
            user_id=account.user_id,
            password=account.password,
            access_token=account.access_token,
            refresh_token=account.refresh_token,
            id_token=account.id_token,
            access_token_expires_at=account.access_token_expires_at,
            refresh_token_expires_at=account.refresh_token_expires_at,
            scope=account.scope,
            created_at=account.created_at,
            updated_at=account.updated_at,
        )
        obj.save()
        return Account(
            id=str(obj.pk),
            account_id=obj.account_id,
            provider_id=obj.provider_id,
            user_id=obj.user_id,
            password=obj.password,
            created_at=obj.created_at,
            updated_at=obj.updated_at,
        )

    def get_account_by_user_and_provider(
        self, user_id: str, provider_id: str
    ) -> Optional[Account]:
        try:
            obj = self.model.objects.get(user_id=user_id, provider_id=provider_id)
            return Account(
                id=str(obj.pk),
                account_id=obj.account_id,
                provider_id=obj.provider_id,
                user_id=obj.user_id,
                password=getattr(obj, "password", None),
                access_token=getattr(obj, "access_token", None),
                refresh_token=getattr(obj, "refresh_token", None),
                id_token=getattr(obj, "id_token", None),
                access_token_expires_at=getattr(obj, "access_token_expires_at", None),
                refresh_token_expires_at=getattr(obj, "refresh_token_expires_at", None),
                scope=getattr(obj, "scope", None),
                created_at=obj.created_at,
                updated_at=obj.updated_at,
            )
        except self.model.DoesNotExist:
            return None

    def get_accounts_by_user(self, user_id: str) -> List[Account]:
        objs = self.model.objects.filter(user_id=user_id)
        return [
            Account(
                id=str(o.pk),
                account_id=o.account_id,
                provider_id=o.provider_id,
                user_id=o.user_id,
                password=getattr(o, "password", None),
                created_at=o.created_at,
                updated_at=o.updated_at,
            )
            for o in objs
        ]

    def update_account(self, account: Account) -> Account:
        obj = self.model.objects.get(pk=account.id)
        obj.password = account.password
        obj.updated_at = datetime.utcnow()
        obj.save()
        return self.get_account_by_user_and_provider(account.user_id, account.provider_id) or account


class DjangoVerificationStore(VerificationStore):
    """Verification store backed by a Django model."""

    def __init__(self, model_class: Type[Any]) -> None:
        self.model = model_class

    def create(self, verification: Verification) -> Verification:
        obj = self.model(
            id=verification.id,
            identifier=verification.identifier,
            value=verification.value,
            expires_at=verification.expires_at,
            created_at=verification.created_at,
            updated_at=verification.updated_at,
        )
        obj.save()
        return verification

    def get_by_id(self, id: str) -> Optional[Verification]:
        try:
            obj = self.model.objects.get(pk=id)
            return Verification(
                id=str(obj.pk),
                identifier=obj.identifier,
                value=obj.value,
                expires_at=obj.expires_at,
                created_at=getattr(obj, "created_at", None),
                updated_at=getattr(obj, "updated_at", None),
            )
        except self.model.DoesNotExist:
            return None

    def get_by_identifier_and_value(
        self, identifier: str, value: str
    ) -> Optional[Verification]:
        try:
            obj = self.model.objects.get(identifier=identifier, value=value)
            return Verification(
                id=str(obj.pk),
                identifier=obj.identifier,
                value=obj.value,
                expires_at=obj.expires_at,
                created_at=getattr(obj, "created_at", None),
                updated_at=getattr(obj, "updated_at", None),
            )
        except self.model.DoesNotExist:
            return None

    def delete(self, id: str) -> None:
        self.model.objects.filter(pk=id).delete()


def _get_default_session_model() -> Type[Any]:
    from auth101.contrib.django.models import Auth101Session
    return Auth101Session


def _get_default_account_model() -> Type[Any]:
    from auth101.contrib.django.models import Auth101Account
    return Auth101Account


def _get_default_verification_model() -> Type[Any]:
    from auth101.contrib.django.models import Auth101Verification
    return Auth101Verification


class DjangoAdapter(DatabaseAdapter):
    """
    Django ORM adapter. One adapter; session/account/verification are optional.

    **Zero-config (use auth101's default tables):**
    Add to settings.py::
        INSTALLED_APPS = [..., "auth101.contrib.django"]
    Then: python manage.py makemigrations && python manage.py migrate

    Use default user model too::
        from auth101.adapters import DjangoAdapter
        from auth101.contrib.django.models import Auth101User
        adapter = DjangoAdapter(Auth101User)
        auth = Auth101(secret=settings.SECRET_KEY, database=adapter)

    Or pass only your User model; session/account/verification use auth101 defaults::
        adapter = DjangoAdapter(MyUser)  # session_model, account_model, verification_model optional
        auth = Auth101(secret=settings.SECRET_KEY, database=adapter)

    **Custom models:** Pass session_model, account_model, verification_model to use your own tables.
    """

    def __init__(
        self,
        model_class: Type[Any],
        session_model: Optional[Type[Any]] = None,
        account_model: Optional[Type[Any]] = None,
        verification_model: Optional[Type[Any]] = None,
    ) -> None:
        self._model_class = model_class
        self._session_model = session_model
        self._account_model = account_model
        self._verification_model = verification_model

    def get_user_store(
        self,
        *,
        table_name: Optional[str] = None,
        model: Optional[Type[Any]] = None,
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> UserStore:
        user_model = model if model is not None else self._model_class
        return DjangoUserStore(user_model, field_mapping=field_mapping)

    def get_session_store(
        self,
        *,
        table_name: Optional[str] = None,
        model: Optional[Type[Any]] = None,
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> SessionStore:
        session_model = model if model is not None else self._session_model
        if session_model is None:
            session_model = _get_default_session_model()
        return DjangoSessionStore(session_model)

    def get_account_store(
        self,
        *,
        table_name: Optional[str] = None,
        model: Optional[Type[Any]] = None,
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> AccountStore:
        account_model = model if model is not None else self._account_model
        if account_model is None:
            account_model = _get_default_account_model()
        return DjangoAccountStore(account_model)

    def get_verification_store(
        self,
        *,
        table_name: Optional[str] = None,
        model: Optional[Type[Any]] = None,
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> VerificationStore:
        verification_model = model if model is not None else self._verification_model
        if verification_model is None:
            verification_model = _get_default_verification_model()
        return DjangoVerificationStore(verification_model)

    def supports_migrate(self) -> bool:
        return False

    def migrate_user_table(
        self,
        table_name: str = "user",
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> None:
        raise NotImplementedError(
            "Django adapter does not create tables; define your models and run manage.py migrate"
        )
