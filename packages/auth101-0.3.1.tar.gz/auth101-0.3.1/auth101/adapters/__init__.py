"""Database adapters: use an adapter instead of a raw connection string."""

from .base import (
    DatabaseAdapter,
    DEFAULT_USER_FIELD_MAPPING,
    normalize_field_mapping,
)
from .django import DjangoAdapter
from .sqlalchemy import SQLAlchemyAdapter

__all__ = [
    "DatabaseAdapter",
    "DEFAULT_USER_FIELD_MAPPING",
    "DjangoAdapter",
    "normalize_field_mapping",
    "SQLAlchemyAdapter",
]
