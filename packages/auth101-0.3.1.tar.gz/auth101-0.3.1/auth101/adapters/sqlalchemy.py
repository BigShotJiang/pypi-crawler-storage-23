"""SQLAlchemy database adapter with optional field mapping and migrate support.

4 tables (user, account, session, verification).
"""

import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional, Union

from sqlalchemy import Boolean, Column, DateTime, MetaData, String, Table, Text, create_engine
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session as SASession, sessionmaker

from ..domain import Account, Session as SessionModel, User, Verification
from ..providers.storage.base import AccountStore, SessionStore, UserStore, VerificationStore
from .base import (
    DEFAULT_ACCOUNT_TABLE,
    DEFAULT_SESSION_TABLE,
    DEFAULT_USER_TABLE,
    DEFAULT_VERIFICATION_TABLE,
    DatabaseAdapter,
    normalize_account_field_mapping,
    normalize_field_mapping,
    normalize_session_field_mapping,
    normalize_verification_field_mapping,
)


def _build_user_table(
    table_name: str,
    field_mapping: Dict[str, str],
    metadata: Optional[MetaData] = None,
) -> Table:
    """Build SQLAlchemy Table for users."""
    if metadata is None:
        metadata = MetaData()
    return Table(
        table_name,
        metadata,
        Column(field_mapping["id"], String(36), primary_key=True),
        Column(field_mapping["name"], String(255), nullable=False, default=""),
        Column(field_mapping["email"], String(255), unique=True, nullable=False, index=True),
        Column(field_mapping["email_verified"], Boolean, default=False, nullable=False),
        Column(field_mapping["image"], String(512), nullable=True),
        Column(field_mapping["is_active"], Boolean, default=True, nullable=False),
        Column(field_mapping["created_at"], DateTime, nullable=False),
        Column(field_mapping["updated_at"], DateTime, nullable=False),
    )


def _build_account_table(
    table_name: str = "account",
    metadata: Optional[MetaData] = None,
    field_mapping: Optional[Dict[str, str]] = None,
) -> Table:
    """Build SQLAlchemy Table for accounts (credential + future OAuth)."""
    if metadata is None:
        metadata = MetaData()
    m = normalize_account_field_mapping(field_mapping)
    return Table(
        table_name,
        metadata,
        Column(m["id"], String(36), primary_key=True),
        Column(m["account_id"], String(255), nullable=False, index=True),
        Column(m["provider_id"], String(64), nullable=False, index=True),
        Column(m["user_id"], String(36), nullable=False, index=True),
        Column(m["password"], String(255), nullable=True),
        Column(m["access_token"], Text, nullable=True),
        Column(m["refresh_token"], Text, nullable=True),
        Column(m["id_token"], Text, nullable=True),
        Column(m["access_token_expires_at"], DateTime, nullable=True),
        Column(m["refresh_token_expires_at"], DateTime, nullable=True),
        Column(m["scope"], String(512), nullable=True),
        Column(m["created_at"], DateTime, nullable=False),
        Column(m["updated_at"], DateTime, nullable=False),
    )


def _build_sessions_table(
    table_name: str = "session",
    metadata: Optional[MetaData] = None,
    field_mapping: Optional[Dict[str, str]] = None,
) -> Table:
    """Build SQLAlchemy Table for sessions (token, expiresAt, userId)."""
    if metadata is None:
        metadata = MetaData()
    m = normalize_session_field_mapping(field_mapping)
    return Table(
        table_name,
        metadata,
        Column(m["id"], String(36), primary_key=True),
        Column(m["token"], String(36), unique=True, nullable=False, index=True),
        Column(m["expires_at"], DateTime, nullable=False),
        Column(m["user_id"], String(36), nullable=False, index=True),
        Column(m["ip_address"], String(45), nullable=True),
        Column(m["user_agent"], String(512), nullable=True),
        Column(m["created_at"], DateTime, nullable=False),
        Column(m["updated_at"], DateTime, nullable=False),
    )


def _build_verification_table(
    table_name: str = "verification",
    metadata: Optional[MetaData] = None,
    field_mapping: Optional[Dict[str, str]] = None,
) -> Table:
    """Build SQLAlchemy Table for verification (email verification, password reset)."""
    if metadata is None:
        metadata = MetaData()
    m = normalize_verification_field_mapping(field_mapping)
    return Table(
        table_name,
        metadata,
        Column(m["id"], String(36), primary_key=True),
        Column(m["identifier"], String(255), nullable=False, index=True),
        Column(m["value"], String(255), nullable=False, index=True),
        Column(m["expires_at"], DateTime, nullable=False),
        Column(m["created_at"], DateTime, nullable=True),
        Column(m["updated_at"], DateTime, nullable=True),
    )


class SQLAlchemyUserStore(UserStore):
    """User store backed by SQLAlchemy with configurable column names via field mapping."""

    def __init__(
        self,
        engine: Engine,
        table_name: str = "users",
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> None:
        self.engine = engine
        self.table_name = table_name
        self._mapping = normalize_field_mapping(field_mapping)
        self._metadata = MetaData()
        self._table = _build_user_table(table_name, self._mapping, self._metadata)
        self._table.create(self.engine, checkfirst=True)
        self.SessionLocal = sessionmaker(bind=engine)

    def _col(self, internal_name: str) -> str:
        return self._mapping[internal_name]

    def _row_to_user(self, row: Any) -> User:
        c = self._table.c
        return User(
            id=str(row._mapping[c[self._col("id")]]),
            name=str(row._mapping.get(c[self._col("name")], "") or ""),
            email=str(row._mapping[c[self._col("email")]] or ""),
            email_verified=bool(row._mapping.get(c[self._col("email_verified")], False)),
            image=str(row._mapping.get(c[self._col("image")], "") or ""),
            is_active=bool(row._mapping.get(c[self._col("is_active")], True)),
            created_at=row._mapping.get(c[self._col("created_at")]) or datetime.utcnow(),
            updated_at=row._mapping.get(c[self._col("updated_at")]) or datetime.utcnow(),
            extra={},
        )

    def _user_to_row(self, user: User) -> Dict[str, Any]:
        return {
            self._col("id"): user.id,
            self._col("name"): user.name or "",
            self._col("email"): user.email,
            self._col("email_verified"): user.email_verified,
            self._col("image"): user.image or "",
            self._col("is_active"): user.is_active,
            self._col("created_at"): user.created_at,
            self._col("updated_at"): user.updated_at,
        }

    def create_user(self, user: User) -> User:
        session: SASession = self.SessionLocal()
        try:
            sel = self._table.select().where(
                self._table.c[self._col("email")] == user.email
            )
            existing = session.execute(sel).first()
            if existing:
                raise ValueError("user already exists")
            ins = self._table.insert().values(**self._user_to_row(user))
            session.execute(ins)
            session.commit()
            return self.get_user_by_email(user.email) or user
        finally:
            session.close()

    def get_user_by_email(self, email: str) -> Optional[User]:
        session: SASession = self.SessionLocal()
        try:
            sel = self._table.select().where(
                self._table.c[self._col("email")] == email
            )
            row = session.execute(sel).first()
            if not row:
                return None
            return self._row_to_user(row)
        finally:
            session.close()

    def update_user(self, user: User) -> User:
        session: SASession = self.SessionLocal()
        try:
            now = datetime.utcnow()
            upd = (
                self._table.update()
                .where(self._table.c[self._col("id")] == user.id)
                .values(
                    **{
                        self._col("name"): user.name or "",
                        self._col("email"): user.email,
                        self._col("email_verified"): user.email_verified,
                        self._col("image"): user.image or "",
                        self._col("is_active"): user.is_active,
                        self._col("updated_at"): now,
                    }
                )
            )
            session.execute(upd)
            session.commit()
            return self.get_user_by_email(user.email) or user
        finally:
            session.close()


class SQLAlchemySessionStore(SessionStore):
    """Session store backed by SQLAlchemy (session table). jti is stored as token."""

    def __init__(
        self,
        engine: Engine,
        table_name: str = "session",
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> None:
        self.engine = engine
        self.table_name = table_name
        self._mapping = normalize_session_field_mapping(field_mapping)
        self._metadata = MetaData()
        self._table = _build_sessions_table(table_name, self._metadata, self._mapping)
        self._table.create(self.engine, checkfirst=True)
        self.SessionLocal = sessionmaker(bind=engine)

    def _col(self, internal_name: str) -> str:
        return self._mapping[internal_name]

    def create_session(self, user_id: str, jti: str, expires_at: datetime) -> SessionModel:
        session: SASession = self.SessionLocal()
        try:
            sid = str(uuid.uuid4())
            now = datetime.utcnow()
            col = self._col
            ins = self._table.insert().values(
                **{
                    col("id"): sid,
                    col("token"): jti,
                    col("expires_at"): expires_at,
                    col("user_id"): user_id,
                    col("ip_address"): None,
                    col("user_agent"): None,
                    col("created_at"): now,
                    col("updated_at"): now,
                }
            )
            session.execute(ins)
            session.commit()
            return SessionModel(
                id=sid,
                token=jti,
                expires_at=expires_at,
                user_id=user_id,
                ip_address=None,
                user_agent=None,
                created_at=now,
                updated_at=now,
            )
        finally:
            session.close()

    def get_session_by_jti(self, jti: str) -> Optional[SessionModel]:
        session: SASession = self.SessionLocal()
        try:
            sel = self._table.select().where(self._table.c[self._col("token")] == jti)
            row = session.execute(sel).first()
            if not row:
                return None
            r = row._mapping
            return SessionModel(
                id=r[self._col("id")],
                token=r[self._col("token")],
                expires_at=r[self._col("expires_at")],
                user_id=r[self._col("user_id")],
                ip_address=r.get(self._col("ip_address")),
                user_agent=r.get(self._col("user_agent")),
                created_at=r.get(self._col("created_at")),
                updated_at=r.get(self._col("updated_at")),
            )
        finally:
            session.close()

    def delete_session_by_jti(self, jti: str) -> None:
        session: SASession = self.SessionLocal()
        try:
            session.execute(
                self._table.delete().where(self._table.c[self._col("token")] == jti)
            )
            session.commit()
        finally:
            session.close()

    def delete_sessions_for_user(self, user_id: str) -> None:
        session: SASession = self.SessionLocal()
        try:
            session.execute(
                self._table.delete().where(self._table.c[self._col("user_id")] == user_id)
            )
            session.commit()
        finally:
            session.close()


class SQLAlchemyAccountStore(AccountStore):
    """Account store backed by SQLAlchemy (account table)."""

    def __init__(
        self,
        engine: Engine,
        table_name: str = "account",
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> None:
        self.engine = engine
        self._mapping = normalize_account_field_mapping(field_mapping)
        self._metadata = MetaData()
        self._table = _build_account_table(table_name, self._metadata, self._mapping)
        self._table.create(engine, checkfirst=True)
        self.SessionLocal = sessionmaker(bind=engine)

    def _col(self, internal_name: str) -> str:
        return self._mapping[internal_name]

    def _row_to_account(self, r: Any) -> Account:
        c = self._col
        return Account(
            id=r[c("id")],
            account_id=r[c("account_id")],
            provider_id=r[c("provider_id")],
            user_id=r[c("user_id")],
            password=r.get(c("password")),
            access_token=r.get(c("access_token")),
            refresh_token=r.get(c("refresh_token")),
            id_token=r.get(c("id_token")),
            access_token_expires_at=r.get(c("access_token_expires_at")),
            refresh_token_expires_at=r.get(c("refresh_token_expires_at")),
            scope=r.get(c("scope")),
            created_at=r.get(c("created_at")),
            updated_at=r.get(c("updated_at")),
        )

    def create_account(self, account: Account) -> Account:
        session: SASession = self.SessionLocal()
        try:
            now = datetime.utcnow()
            c = self._col
            ins = self._table.insert().values(
                **{
                    c("id"): account.id,
                    c("account_id"): account.account_id,
                    c("provider_id"): account.provider_id,
                    c("user_id"): account.user_id,
                    c("password"): account.password,
                    c("access_token"): account.access_token,
                    c("refresh_token"): account.refresh_token,
                    c("id_token"): account.id_token,
                    c("access_token_expires_at"): account.access_token_expires_at,
                    c("refresh_token_expires_at"): account.refresh_token_expires_at,
                    c("scope"): account.scope,
                    c("created_at"): account.created_at or now,
                    c("updated_at"): account.updated_at or now,
                }
            )
            session.execute(ins)
            session.commit()
            return self.get_account_by_user_and_provider(account.user_id, account.provider_id) or account
        finally:
            session.close()

    def get_account_by_user_and_provider(
        self, user_id: str, provider_id: str
    ) -> Optional[Account]:
        session: SASession = self.SessionLocal()
        try:
            c = self._col
            sel = self._table.select().where(
                self._table.c[c("user_id")] == user_id,
                self._table.c[c("provider_id")] == provider_id,
            )
            row = session.execute(sel).first()
            if not row:
                return None
            return self._row_to_account(row._mapping)
        finally:
            session.close()

    def get_accounts_by_user(self, user_id: str) -> List[Account]:
        session: SASession = self.SessionLocal()
        try:
            c = self._col
            sel = self._table.select().where(self._table.c[c("user_id")] == user_id)
            rows = session.execute(sel).all()
            return [self._row_to_account(r._mapping) for r in rows]
        finally:
            session.close()

    def update_account(self, account: Account) -> Account:
        session: SASession = self.SessionLocal()
        try:
            now = datetime.utcnow()
            c = self._col
            session.execute(
                self._table.update()
                .where(self._table.c[c("id")] == account.id)
                .values(
                    **{
                        c("password"): account.password,
                        c("access_token"): account.access_token,
                        c("refresh_token"): account.refresh_token,
                        c("id_token"): account.id_token,
                        c("access_token_expires_at"): account.access_token_expires_at,
                        c("refresh_token_expires_at"): account.refresh_token_expires_at,
                        c("scope"): account.scope,
                        c("updated_at"): now,
                    }
                )
            )
            session.commit()
            return self.get_account_by_user_and_provider(account.user_id, account.provider_id) or account
        finally:
            session.close()


class SQLAlchemyVerificationStore(VerificationStore):
    """Verification store backed by SQLAlchemy (verification table)."""

    def __init__(
        self,
        engine: Engine,
        table_name: str = "verification",
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> None:
        self.engine = engine
        self._mapping = normalize_verification_field_mapping(field_mapping)
        self._metadata = MetaData()
        self._table = _build_verification_table(table_name, self._metadata, self._mapping)
        self._table.create(engine, checkfirst=True)
        self.SessionLocal = sessionmaker(bind=engine)

    def _col(self, internal_name: str) -> str:
        return self._mapping[internal_name]

    def create(self, verification: Verification) -> Verification:
        session: SASession = self.SessionLocal()
        try:
            now = datetime.utcnow()
            c = self._col
            session.execute(
                self._table.insert().values(
                    **{
                        c("id"): verification.id,
                        c("identifier"): verification.identifier,
                        c("value"): verification.value,
                        c("expires_at"): verification.expires_at,
                        c("created_at"): verification.created_at or now,
                        c("updated_at"): verification.updated_at or now,
                    }
                )
            )
            session.commit()
            return verification
        finally:
            session.close()

    def get_by_id(self, id: str) -> Optional[Verification]:
        session: SASession = self.SessionLocal()
        try:
            c = self._col
            row = session.execute(
                self._table.select().where(self._table.c[c("id")] == id)
            ).first()
            if not row:
                return None
            r = row._mapping
            return Verification(
                id=r[c("id")],
                identifier=r[c("identifier")],
                value=r[c("value")],
                expires_at=r[c("expires_at")],
                created_at=r.get(c("created_at")),
                updated_at=r.get(c("updated_at")),
            )
        finally:
            session.close()

    def get_by_identifier_and_value(
        self, identifier: str, value: str
    ) -> Optional[Verification]:
        session: SASession = self.SessionLocal()
        try:
            c = self._col
            row = session.execute(
                self._table.select().where(
                    self._table.c[c("identifier")] == identifier,
                    self._table.c[c("value")] == value,
                )
            ).first()
            if not row:
                return None
            r = row._mapping
            return Verification(
                id=r[c("id")],
                identifier=r[c("identifier")],
                value=r[c("value")],
                expires_at=r[c("expires_at")],
                created_at=r.get(c("created_at")),
                updated_at=r.get(c("updated_at")),
            )
        finally:
            session.close()

    def delete(self, id: str) -> None:
        session: SASession = self.SessionLocal()
        try:
            c = self._col
            session.execute(self._table.delete().where(self._table.c[c("id")] == id))
            session.commit()
        finally:
            session.close()


class SQLAlchemyAdapter(DatabaseAdapter):
    """
    SQL database adapter using SQLAlchemy (user, account, session, verification).

    Table names and field mappings are passed from Auth101 when get_*_store() is called;
    do not pass them to the adapter constructor.

    Example:
        from auth101.adapters import SQLAlchemyAdapter
        adapter = SQLAlchemyAdapter("sqlite:///auth.db")
        auth = Auth101(secret="...", database=adapter, user={"model_name": "users", "fields": {...}})
    """

    def __init__(self, engine_or_url: Union[Engine, str]) -> None:
        if isinstance(engine_or_url, str):
            try:
                self._engine = create_engine(engine_or_url)
            except ImportError:
                raise ImportError("SQLAlchemy is required: pip install sqlalchemy")
        else:
            self._engine = engine_or_url

    def get_user_store(
        self,
        *,
        table_name: Optional[str] = None,
        model: Optional[Any] = None,
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> UserStore:
        name = table_name or DEFAULT_USER_TABLE
        mapping = normalize_field_mapping(field_mapping)
        return SQLAlchemyUserStore(self._engine, table_name=name, field_mapping=mapping)

    def get_session_store(
        self,
        *,
        table_name: Optional[str] = None,
        model: Optional[Any] = None,
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> SessionStore:
        name = table_name or DEFAULT_SESSION_TABLE
        mapping = normalize_session_field_mapping(field_mapping)
        return SQLAlchemySessionStore(
            self._engine, table_name=name, field_mapping=mapping
        )

    def get_account_store(
        self,
        *,
        table_name: Optional[str] = None,
        model: Optional[Any] = None,
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> AccountStore:
        name = table_name or DEFAULT_ACCOUNT_TABLE
        mapping = normalize_account_field_mapping(field_mapping)
        return SQLAlchemyAccountStore(
            self._engine, table_name=name, field_mapping=mapping
        )

    def get_verification_store(
        self,
        *,
        table_name: Optional[str] = None,
        model: Optional[Any] = None,
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> VerificationStore:
        name = table_name or DEFAULT_VERIFICATION_TABLE
        mapping = normalize_verification_field_mapping(field_mapping)
        return SQLAlchemyVerificationStore(
            self._engine, table_name=name, field_mapping=mapping
        )

    def supports_migrate(self) -> bool:
        return True

    def migrate_user_table(
        self,
        table_name: str = DEFAULT_USER_TABLE,
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> None:
        mapping = normalize_field_mapping(field_mapping)
        meta = MetaData()
        table = _build_user_table(table_name, mapping, meta)
        table.create(self._engine, checkfirst=True)

    def migrate_sessions_table(
        self,
        table_name: str = DEFAULT_SESSION_TABLE,
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> None:
        mapping = normalize_session_field_mapping(field_mapping)
        meta = MetaData()
        table = _build_sessions_table(table_name, meta, mapping)
        table.create(self._engine, checkfirst=True)

    def migrate_account_table(
        self,
        table_name: str = DEFAULT_ACCOUNT_TABLE,
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> None:
        mapping = normalize_account_field_mapping(field_mapping)
        meta = MetaData()
        table = _build_account_table(table_name, meta, mapping)
        table.create(self._engine, checkfirst=True)

    def migrate_verification_table(
        self,
        table_name: str = DEFAULT_VERIFICATION_TABLE,
        field_mapping: Optional[Dict[str, str]] = None,
    ) -> None:
        mapping = normalize_verification_field_mapping(field_mapping)
        meta = MetaData()
        table = _build_verification_table(table_name, meta, mapping)
        table.create(self._engine, checkfirst=True)
