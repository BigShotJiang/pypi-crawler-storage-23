"""Verification entity (email verification, password reset tokens, etc.)."""

from dataclasses import dataclass
from datetime import datetime
from typing import Optional


@dataclass
class Verification:
    """Verification record (e.g. email verification, password reset)."""

    id: str
    identifier: str  # e.g. email
    value: str  # e.g. token
    expires_at: datetime
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
