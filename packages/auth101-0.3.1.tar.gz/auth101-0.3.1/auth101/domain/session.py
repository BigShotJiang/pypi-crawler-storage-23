"""Session entity (token, expiresAt, userId, ipAddress, userAgent)."""

from dataclasses import dataclass
from datetime import datetime
from typing import Optional


@dataclass
class Session:
    """Stored session. token is the session/refresh identifier (we use jti as token)."""

    id: str
    token: str  # unique session token (same as jti for refresh flow)
    expires_at: datetime
    user_id: str
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
