"""Account entity (one row per provider per user; password/OAuth here)."""

from dataclasses import dataclass
from datetime import datetime
from typing import Optional


@dataclass
class Account:
    """Account links a user to a provider (e.g. credential, google). Password hash for credential provider."""

    id: str
    account_id: str  # provider's account id (e.g. user email for credential)
    provider_id: str  # e.g. "credential", "google"
    user_id: str
    password: Optional[str] = None  # for credential provider
    access_token: Optional[str] = None
    refresh_token: Optional[str] = None
    id_token: Optional[str] = None
    access_token_expires_at: Optional[datetime] = None
    refresh_token_expires_at: Optional[datetime] = None
    scope: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
