"""Domain layer: shared entities for Auth101.

No dependencies on features, adapters, or framework code.
"""

from .account import Account
from .session import Session
from .user import User
from .verification import Verification

__all__ = ["Account", "Session", "User", "Verification"]
