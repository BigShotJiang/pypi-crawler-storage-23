"""JWT token creation and verification.

Provides access and refresh token types for session-based auth.
"""
import jwt
from datetime import datetime, timedelta
from typing import Any, Dict, Optional

TOKEN_TYPE_ACCESS = "access"
TOKEN_TYPE_REFRESH = "refresh"


def create_token(
    user_id: str,
    secret_key: str,
    algorithm: str = "HS256",
    expires_in_minutes: int = 60,
    token_type: Optional[str] = None,
    jti: Optional[str] = None,
    **extra_claims: Any,
) -> str:
    """Create a JWT token for a user.

    Args:
        user_id: The unique identifier for the user
        secret_key: Secret key used to sign the token
        algorithm: JWT algorithm (default: HS256)
        expires_in_minutes: Token expiration time in minutes (default: 60)
        token_type: Optional "access" or "refresh"
        jti: Optional JWT ID (required for refresh tokens used with session store)
        **extra_claims: Additional claims to include in the token payload

    Returns:
        Encoded JWT token string
    """
    now = datetime.utcnow()
    expiration = now + timedelta(minutes=expires_in_minutes)

    payload: Dict[str, Any] = {
        "sub": user_id,
        "iat": now,
        "exp": expiration,
        **extra_claims,
    }
    if token_type is not None:
        payload["type"] = token_type
    if jti is not None:
        payload["jti"] = jti

    token = jwt.encode(payload, secret_key, algorithm=algorithm)
    return token


def create_access_token(
    user_id: str,
    secret_key: str,
    email: str,
    algorithm: str = "HS256",
    expires_in_minutes: int = 60,
    **extra_claims: Any,
) -> str:
    """Create a short-lived access token (Bearer token for API calls)."""
    return create_token(
        user_id=user_id,
        secret_key=secret_key,
        algorithm=algorithm,
        expires_in_minutes=expires_in_minutes,
        token_type=TOKEN_TYPE_ACCESS,
        email=email,
        **extra_claims,
    )


def create_refresh_token(
    user_id: str,
    secret_key: str,
    jti: str,
    email: str,
    algorithm: str = "HS256",
    expires_in_minutes: int = 60 * 24 * 7,
    **extra_claims: Any,
) -> str:
    """Create a long-lived refresh token (use only with POST /auth/refresh)."""
    return create_token(
        user_id=user_id,
        secret_key=secret_key,
        algorithm=algorithm,
        expires_in_minutes=expires_in_minutes,
        token_type=TOKEN_TYPE_REFRESH,
        jti=jti,
        email=email,
        **extra_claims,
    )


def verify_token(
    token: str,
    secret_key: str,
    algorithm: str = "HS256",
) -> Optional[Dict[str, Any]]:
    """Verify and decode a JWT token.

    Args:
        token: The JWT token string to verify
        secret_key: Secret key used to verify the token signature
        algorithm: JWT algorithm (default: HS256)

    Returns:
        Decoded token payload if valid, None if invalid or expired
    """
    try:
        payload = jwt.decode(token, secret_key, algorithms=[algorithm])
        return payload
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None


def verify_access_token(
    token: str,
    secret_key: str,
    algorithm: str = "HS256",
) -> Optional[Dict[str, Any]]:
    """Verify token and require type access (or legacy token with no type)."""
    payload = verify_token(token, secret_key, algorithm)
    if not payload:
        return None
    t = payload.get("type")
    if t is not None and t != TOKEN_TYPE_ACCESS:
        return None
    return payload


def verify_refresh_token(
    token: str,
    secret_key: str,
    algorithm: str = "HS256",
) -> Optional[Dict[str, Any]]:
    """Verify token and require type refresh."""
    payload = verify_token(token, secret_key, algorithm)
    if not payload:
        return None
    if payload.get("type") != TOKEN_TYPE_REFRESH:
        return None
    return payload


def get_user_id_from_token(
    token: str,
    secret_key: str,
    algorithm: str = "HS256",
) -> Optional[str]:
    """Extract user_id from a valid JWT token."""
    payload = verify_token(token, secret_key, algorithm)
    if payload:
        return payload.get("sub")
    return None
