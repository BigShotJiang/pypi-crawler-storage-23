"""Password hashing utilities.

Provides secure password hashing and verification using passlib.
Default configuration uses argon2 with bcrypt fallback.
"""
from typing import Optional
from passlib.context import CryptContext


DEFAULT_PWD_CTX = CryptContext(schemes=["argon2", "bcrypt"], deprecated="auto")


def hash_password(password: str, pwd_ctx: Optional[CryptContext] = None) -> str:
    """Hash a plaintext password.
    
    Args:
        password: The plaintext password to hash
        pwd_ctx: Optional custom CryptContext (uses DEFAULT_PWD_CTX if None)
    
    Returns:
        The hashed password string
    """
    ctx = pwd_ctx or DEFAULT_PWD_CTX
    return ctx.hash(password)


def verify_password(password: str, password_hash: str, pwd_ctx: Optional[CryptContext] = None) -> bool:
    """Verify a plaintext password against a hash.
    
    Args:
        password: The plaintext password to verify
        password_hash: The hashed password to check against
        pwd_ctx: Optional custom CryptContext (uses DEFAULT_PWD_CTX if None)
    
    Returns:
        True if password matches the hash, False otherwise
    """
    ctx = pwd_ctx or DEFAULT_PWD_CTX
    try:
        return ctx.verify(password, password_hash)
    except Exception:
        return False
