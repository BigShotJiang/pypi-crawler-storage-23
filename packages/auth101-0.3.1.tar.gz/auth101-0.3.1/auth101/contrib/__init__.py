"""Optional auth101 components (e.g. Django app with default models)."""
