"""
Django app with default auth101 models (user, account, session, verification).

Add to INSTALLED_APPS and run migrate so tables are created::

    INSTALLED_APPS = [
        ...
        "auth101.contrib.django",
    ]

Then: python manage.py makemigrations && python manage.py migrate

Use with DjangoAdapter without passing session/account/verification models::

    from auth101 import Auth101
    from auth101.adapters import DjangoAdapter
    from auth101.contrib.django.models import Auth101User

    adapter = DjangoAdapter(Auth101User)  # session, account, verification use defaults
    auth = Auth101(secret=settings.SECRET_KEY, database=adapter)
"""
