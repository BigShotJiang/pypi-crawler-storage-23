from django.apps import AppConfig


class Auth101ContribDjangoConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "auth101.contrib.django"
    label = "auth101_contrib_django"
    verbose_name = "Auth101 (default models)"
