"""
Default Django models for auth101 (schema).

Use these when you don't want to define your own: add auth101.contrib.django
to INSTALLED_APPS, run migrate, and pass only your user model (or use Auth101User)
to DjangoAdapter.
"""
import uuid

from django.db import models


def _default_uuid():
    return str(uuid.uuid4())


class Auth101User(models.Model):
    """Default user model (no password on user)."""
    id = models.CharField(max_length=36, primary_key=True, default=_default_uuid, editable=False)
    name = models.CharField(max_length=255, default="", blank=True)
    email = models.EmailField(unique=True, db_index=True)
    email_verified = models.BooleanField(default=False)
    image = models.CharField(max_length=512, blank=True, default="")
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "auth101_user"
        app_label = "auth101_contrib_django"


class Auth101Session(models.Model):
    """Default session model (token = jti for refresh flow)."""
    id = models.CharField(max_length=36, primary_key=True, default=_default_uuid, editable=False)
    token = models.CharField(max_length=36, unique=True, db_index=True)
    expires_at = models.DateTimeField()
    user_id = models.CharField(max_length=36, db_index=True)
    ip_address = models.CharField(max_length=45, null=True, blank=True)
    user_agent = models.CharField(max_length=512, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "auth101_session"
        app_label = "auth101_contrib_django"


class Auth101Account(models.Model):
    """Default account model (credential + future OAuth)."""
    id = models.CharField(max_length=36, primary_key=True, default=_default_uuid, editable=False)
    account_id = models.CharField(max_length=255, db_index=True)
    provider_id = models.CharField(max_length=64, db_index=True)
    user_id = models.CharField(max_length=36, db_index=True)
    password = models.CharField(max_length=255, null=True, blank=True)
    access_token = models.TextField(null=True, blank=True)
    refresh_token = models.TextField(null=True, blank=True)
    id_token = models.TextField(null=True, blank=True)
    access_token_expires_at = models.DateTimeField(null=True, blank=True)
    refresh_token_expires_at = models.DateTimeField(null=True, blank=True)
    scope = models.CharField(max_length=512, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "auth101_account"
        app_label = "auth101_contrib_django"


class Auth101Verification(models.Model):
    """Default verification model (email verification, password reset, etc.)."""
    id = models.CharField(max_length=36, primary_key=True, default=_default_uuid, editable=False)
    identifier = models.CharField(max_length=255, db_index=True)
    value = models.CharField(max_length=255, db_index=True)
    expires_at = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True, null=True, blank=True)

    class Meta:
        db_table = "auth101_verification"
        app_label = "auth101_contrib_django"
