"""
Auth101 CLI. Use `auth101 migrate` to create or update auth tables.

Config module must export either:
  - auth: Auth101 instance (preferred; entity config is read from it), or
  - database: DatabaseAdapter and optionally user_field_mapping (legacy).

User table:
  - If auth101 manages the user table (user=... or neither), migrate creates it.
  - If you use your own user table (user_field_mapping with table_name), migrate skips it.
Session/account/verification: present in config = skip migrate; omitted = migrate creates them.

Example (e.g. myapp/auth_config.py):

  from auth101 import Auth101
  from auth101.adapters import SQLAlchemyAdapter
  adapter = SQLAlchemyAdapter("sqlite:///auth.db")
  auth = Auth101(secret="...", database=adapter)
  # Or auth101-managed with custom name: user={"model_name": "users", "fields": {...}}
  # Or your own table: user_field_mapping={"table_name": "app_user", "fields": {...}}

Then: auth101 migrate --config myapp.auth_config
"""

import importlib
import sys
from typing import Any, Dict, Optional, Tuple


def _load_config(config_path: str) -> Tuple[Any, Dict[str, Optional[Dict[str, Any]]], Any]:
    """Load database adapter, entity_config, and optional auth instance.

    Returns (database, entity_config, auth_or_none).
    When auth is present, use auth._wiring for migrate data.
    When auth is None (legacy), entity_config["user"] present means skip user migrate.
    """
    try:
        mod = importlib.import_module(config_path)
    except ModuleNotFoundError:
        sys.stderr.write(f"auth101: Config module not found: {config_path}\n")
        sys.stderr.write("Use a dotted path, e.g. myapp.auth_config\n")
        sys.exit(1)
    auth = getattr(mod, "auth", None)
    if auth is not None and hasattr(auth, "_wiring"):
        database = auth._wiring.adapter
        entity_config = auth._wiring.entity_config
        return database, entity_config, auth
    database = getattr(mod, "database", None)
    if database is None:
        sys.stderr.write(
            f"auth101: Config module '{config_path}' must define 'auth' (Auth101) or 'database' (DatabaseAdapter)\n"
        )
        sys.exit(1)
    user_field_mapping = getattr(mod, "user_field_mapping", None)
    if user_field_mapping is not None:
        # Their table: skip user migrate.
        entity_config = {"user": {}}
    else:
        entity_config = {}
    return database, entity_config, None


def _cmd_migrate(config_path: str) -> None:
    """Create tables: user table only when auth101-managed; others when not in config."""
    from .adapters.base import (
        DEFAULT_ACCOUNT_TABLE,
        DEFAULT_SESSION_TABLE,
        DEFAULT_USER_TABLE,
        DEFAULT_VERIFICATION_TABLE,
        normalize_account_field_mapping,
        normalize_field_mapping,
        normalize_session_field_mapping,
        normalize_verification_field_mapping,
    )

    database, entity_config, auth = _load_config(config_path)

    if not database.supports_migrate():
        sys.stderr.write(
            f"auth101: Adapter {type(database).__name__} does not support migrate. "
            "Use your ORM's migration (e.g. manage.py migrate) or an SQL adapter.\n"
        )
        sys.exit(1)

    # User table: run migrate only when auth101 manages it (user=... or neither; not user_field_mapping).
    run_user_migrate = (
        auth._wiring.user_table_managed_by_auth101
        if auth is not None
        else entity_config.get("user") is None
    )
    if run_user_migrate:
        if auth is not None:
            table_name = auth._wiring.resolved_tables["user"]
            mapping = auth._wiring.resolved_mappings["user"]
        else:
            table_name = DEFAULT_USER_TABLE
            mapping = normalize_field_mapping(None)
        database.migrate_user_table(table_name=table_name, field_mapping=mapping)
        print(f"auth101: User table '{table_name}' ensured.")
    else:
        print("auth101: User table is your own (skipped).")

    if entity_config.get("session") is None and hasattr(database, "migrate_sessions_table"):
        table_name = DEFAULT_SESSION_TABLE
        mapping = normalize_session_field_mapping(None)
        database.migrate_sessions_table(table_name=table_name, field_mapping=mapping)
        print(f"auth101: Session table '{table_name}' ensured.")
    elif entity_config.get("session") is not None:
        print("auth101: Session table customized (skipped).")

    if entity_config.get("account") is None and hasattr(database, "migrate_account_table"):
        table_name = DEFAULT_ACCOUNT_TABLE
        mapping = normalize_account_field_mapping(None)
        database.migrate_account_table(table_name=table_name, field_mapping=mapping)
        print(f"auth101: Account table '{table_name}' ensured.")
    elif entity_config.get("account") is not None:
        print("auth101: Account table customized (skipped).")

    if entity_config.get("verification") is None and hasattr(database, "migrate_verification_table"):
        table_name = DEFAULT_VERIFICATION_TABLE
        mapping = normalize_verification_field_mapping(None)
        database.migrate_verification_table(table_name=table_name, field_mapping=mapping)
        print(f"auth101: Verification table '{table_name}' ensured.")
    elif entity_config.get("verification") is not None:
        print("auth101: Verification table customized (skipped).")


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser(prog="auth101", description="Auth101 CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)

    migrate_parser = subparsers.add_parser(
        "migrate",
        help="Create auth tables for non-customized entities (customized = already in your config)",
    )
    migrate_parser.add_argument(
        "--config",
        "-c",
        required=True,
        metavar="MODULE",
        help="Dotted path to config module that defines 'auth' (Auth101) or 'database' (DatabaseAdapter)",
    )

    args = parser.parse_args()
    if args.command == "migrate":
        _cmd_migrate(args.config)


def run_cli() -> None:
    """Entry point for console_scripts."""
    main()


if __name__ == "__main__":
    main()
