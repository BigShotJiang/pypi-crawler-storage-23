"""Email/password authentication service (password in account table)."""

import uuid
from datetime import datetime
from typing import Any, Dict

from ...core.responses import error_response
from ...core.types import VALIDATION_ERROR, USER_EXISTS, INVALID_CREDENTIALS
from ...domain import Account, User
from ...providers.storage.base import AccountStore, UserStore
from ...security.hashing import DEFAULT_PWD_CTX, hash_password, verify_password
from ..sessions.token_issuer import TokenIssuer

CREDENTIAL_PROVIDER_ID = "credential"


class EmailPasswordService:
    """Service for email/password authentication; credentials stored in account table."""

    def __init__(
        self,
        store: UserStore,
        account_store: AccountStore,
        token_issuer: TokenIssuer,
    ) -> None:
        self._store = store
        self._account_store = account_store
        self._token_issuer = token_issuer

    def sign_up(self, email: str, password: str) -> Dict[str, Any]:
        email = email.lower().strip() if email else ""
        if not email or not password:
            return error_response("Email and password are required", VALIDATION_ERROR)

        if self._store.get_user_by_email(email):
            return error_response("User already exists", USER_EXISTS)

        now = datetime.utcnow()
        user = User(
            name="",
            email=email,
            email_verified=False,
            image="",
            is_active=True,
            created_at=now,
            updated_at=now,
        )
        user = self._store.create_user(user)

        account = Account(
            id=str(uuid.uuid4()),
            account_id=email,
            provider_id=CREDENTIAL_PROVIDER_ID,
            user_id=user.id,
            password=hash_password(password, DEFAULT_PWD_CTX),
            created_at=now,
            updated_at=now,
        )
        self._account_store.create_account(account)

        return self._token_issuer.issue_tokens(user)

    def sign_in(self, email: str, password: str) -> Dict[str, Any]:
        email = email.lower().strip() if email else ""
        user = self._store.get_user_by_email(email)
        if not user:
            return error_response("Invalid email or password", INVALID_CREDENTIALS)
        account = self._account_store.get_account_by_user_and_provider(
            user.id, CREDENTIAL_PROVIDER_ID
        )
        if not account or not account.password or not verify_password(
            password, account.password, DEFAULT_PWD_CTX
        ):
            return error_response("Invalid email or password", INVALID_CREDENTIALS)
        return self._token_issuer.issue_tokens(user)
