"""email_password feature - email/password authentication."""
