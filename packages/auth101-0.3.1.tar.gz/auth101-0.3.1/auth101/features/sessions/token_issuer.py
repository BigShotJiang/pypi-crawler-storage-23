"""Token issuance: create session and issue access/refresh tokens for a user."""

import uuid
from datetime import datetime, timedelta
from typing import Any, Dict

from ...core.responses import user_to_dict
from ...domain import User
from ...providers.storage.base import SessionStore
from ...security.tokens import create_access_token, create_refresh_token


class TokenIssuer:
    """Single responsibility: create a new session and issue access + refresh tokens for a user."""

    def __init__(
        self,
        session_store: SessionStore,
        secret: str,
        access_token_expires_in: int,
        refresh_token_expires_in: int,
    ) -> None:
        self._session_store = session_store
        self._secret = secret
        self._access_token_expires_in = access_token_expires_in
        self._refresh_token_expires_in = refresh_token_expires_in

    def issue_tokens(self, user: User) -> Dict[str, Any]:
        """Create a new session and return user + access_token + refresh_token + expires_in."""
        jti = str(uuid.uuid4())
        expires_at = datetime.utcnow() + timedelta(minutes=self._refresh_token_expires_in)
        self._session_store.create_session(user_id=user.id, jti=jti, expires_at=expires_at)

        access_token = create_access_token(
            user_id=user.id,
            secret_key=self._secret,
            email=user.email,
            expires_in_minutes=self._access_token_expires_in,
        )
        refresh_token = create_refresh_token(
            user_id=user.id,
            secret_key=self._secret,
            jti=jti,
            email=user.email,
            expires_in_minutes=self._refresh_token_expires_in,
        )
        expires_in_seconds = self._access_token_expires_in * 60
        return {
            "user": user_to_dict(user),
            "access_token": access_token,
            "refresh_token": refresh_token,
            "expires_in": expires_in_seconds,
        }
