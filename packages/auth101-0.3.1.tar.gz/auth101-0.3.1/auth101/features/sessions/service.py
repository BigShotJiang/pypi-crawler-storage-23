"""Session management service (access/refresh tokens and session table)."""

from datetime import datetime
from typing import Any, Dict, Optional

from ...core.responses import error_response, user_to_dict
from ...core.types import INVALID_TOKEN, SESSION_NOT_FOUND, UNAUTHORIZED, USER_NOT_FOUND
from ...domain import User
from ...providers.storage.base import SessionStore, UserStore
from ...security.tokens import verify_access_token, verify_refresh_token
from .token_issuer import TokenIssuer


class SessionService:
    """Service for session management with access/refresh tokens and stored sessions."""

    def __init__(
        self,
        store: UserStore,
        session_store: SessionStore,
        token_issuer: TokenIssuer,
        secret: str,
    ) -> None:
        self._store = store
        self._session_store = session_store
        self._token_issuer = token_issuer
        self._secret = secret

    def sign_out(self, token: str) -> Dict[str, Any]:
        """Validate an access token and acknowledge sign-out.

        Client should also call revoke_session(refresh_token) to invalidate the session.
        """
        if not verify_access_token(token, self._secret):
            return error_response("Invalid or expired token", INVALID_TOKEN)
        return {"success": True}

    def get_session(self, token: str) -> Dict[str, Any]:
        """Return the user associated with an access token."""
        payload = verify_access_token(token, self._secret)
        if not payload:
            return error_response("Unauthorized", UNAUTHORIZED)

        email = payload.get("email")
        if not email:
            return error_response("Invalid token", INVALID_TOKEN)

        user = self._store.get_user_by_email(email)
        if not user:
            return error_response("User not found", USER_NOT_FOUND)

        return {"user": user_to_dict(user)}

    def verify_token(self, token: str) -> Optional[User]:
        """Verify an access token and return the corresponding User, or None."""
        payload = verify_access_token(token, self._secret)
        if not payload:
            return None
        email = payload.get("email")
        if not email:
            return None
        return self._store.get_user_by_email(email)

    def refresh(self, refresh_token: str) -> Dict[str, Any]:
        """Exchange a valid refresh token for new access and refresh tokens (rotation)."""
        payload = verify_refresh_token(refresh_token, self._secret)
        if not payload:
            return error_response("Invalid or expired refresh token", INVALID_TOKEN)

        jti = payload.get("jti")
        if not jti:
            return error_response("Invalid refresh token", INVALID_TOKEN)

        session = self._session_store.get_session_by_jti(jti)
        if not session:
            return error_response("Session not found or revoked", SESSION_NOT_FOUND)
        if session.expires_at < datetime.utcnow():
            self._session_store.delete_session_by_jti(jti)
            return error_response("Session expired", SESSION_NOT_FOUND)

        email = payload.get("email")
        if not email:
            return error_response("Invalid refresh token", INVALID_TOKEN)
        user = self._store.get_user_by_email(email)
        if not user:
            return error_response("User not found", USER_NOT_FOUND)

        # Rotate: revoke old session, create new session and tokens
        self._session_store.delete_session_by_jti(jti)
        return self._token_issuer.issue_tokens(user)

    def revoke_session(self, refresh_token: str) -> Dict[str, Any]:
        """Revoke the session identified by the refresh token (e.g. on logout)."""
        payload = verify_refresh_token(refresh_token, self._secret)
        if not payload:
            return error_response("Invalid or expired refresh token", INVALID_TOKEN)
        jti = payload.get("jti")
        if not jti:
            return error_response("Invalid refresh token", INVALID_TOKEN)
        self._session_store.delete_session_by_jti(jti)
        return {"success": True}
