"""Core type definitions and constants for Auth101."""

from typing import Literal


ErrorCode = Literal[
    "VALIDATION_ERROR",
    "USER_EXISTS",
    "INVALID_CREDENTIALS",
    "UNAUTHORIZED",
    "INVALID_TOKEN",
    "USER_NOT_FOUND",
    "SESSION_NOT_FOUND",
]

VALIDATION_ERROR: ErrorCode = "VALIDATION_ERROR"
USER_EXISTS: ErrorCode = "USER_EXISTS"
INVALID_CREDENTIALS: ErrorCode = "INVALID_CREDENTIALS"
UNAUTHORIZED: ErrorCode = "UNAUTHORIZED"
INVALID_TOKEN: ErrorCode = "INVALID_TOKEN"
USER_NOT_FOUND: ErrorCode = "USER_NOT_FOUND"
SESSION_NOT_FOUND: ErrorCode = "SESSION_NOT_FOUND"
