"""Base plugin protocol for future extensibility.

This is a stub for future plugin architecture that will allow
custom authentication methods, hooks, and middleware.
"""

from typing import Protocol, runtime_checkable


@runtime_checkable
class Plugin(Protocol):
    """Base protocol for Auth101 plugins.
    
    Future plugins will implement this protocol to extend Auth101
    with custom authentication methods, hooks, and middleware.
    """

    def initialize(self) -> None:
        """Initialize the plugin with the Auth101 instance."""
        ...

    def teardown(self) -> None:
        """Clean up plugin resources."""
        ...
