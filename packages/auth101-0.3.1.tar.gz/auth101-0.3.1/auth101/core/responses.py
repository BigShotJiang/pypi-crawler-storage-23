"""Shared response helpers for Auth101 API responses."""

from typing import Any, Dict

from ..domain import User


def error_response(message: str, code: str) -> Dict[str, Any]:
    """Create a standardized error response."""
    return {"error": {"message": message, "code": code}}


def user_to_dict(user: User) -> Dict[str, Any]:
    """Convert a User entity to a dictionary for API responses."""
    return {
        "id": user.id,
        "name": user.name,
        "email": user.email,
        "email_verified": user.email_verified,
        "image": user.image or "",
        "is_active": user.is_active,
    }
