"""Tests for Auth101."""

import os

import pytest

from auth101 import Auth101
from auth101.adapters import SQLAlchemyAdapter
from auth101.security.tokens import verify_token


def _auth(**kwargs):
    """Default in-memory auth for tests."""
    adapter = SQLAlchemyAdapter("sqlite:///:memory:")
    return Auth101(
        secret=kwargs.get("secret", "secret-key-for-testing-purposes!!"),
        database=adapter,
        **{k: v for k, v in kwargs.items() if k != "secret"},
    )


# ── sign_up ───────────────────────────────────────────────────────────────────

def test_sign_up_success():
    auth = _auth(secret="test-secret-key-32bytes-padding!!")
    result = auth.sign_up("alice@example.com", "hunter2")

    assert "error" not in result
    assert result["user"]["email"] == "alice@example.com"
    assert "access_token" in result
    assert "refresh_token" in result
    assert "expires_in" in result

    payload = verify_token(result["access_token"], "test-secret-key-32bytes-padding!!")
    assert payload is not None
    assert payload["email"] == "alice@example.com"


def test_sign_up_duplicate():
    auth = _auth()
    auth.sign_up("a@b.com", "pass")
    result = auth.sign_up("a@b.com", "pass")

    assert "error" in result
    assert result["error"]["code"] == "USER_EXISTS"


def test_sign_up_missing_fields():
    auth = _auth()
    assert auth.sign_up("", "pass")["error"]["code"] == "VALIDATION_ERROR"
    assert auth.sign_up("a@b.com", "")["error"]["code"] == "VALIDATION_ERROR"


def test_sign_up_email_is_normalised():
    auth = _auth()
    result = auth.sign_up("  Alice@Example.COM  ", "pass")
    assert result["user"]["email"] == "alice@example.com"


# ── sign_in ───────────────────────────────────────────────────────────────────

def test_sign_in_success():
    auth = _auth(secret="test-secret-key-32bytes-padding!!")
    auth.sign_up("bob@example.com", "s3cret")
    result = auth.sign_in("bob@example.com", "s3cret")

    assert "error" not in result
    assert result["user"]["email"] == "bob@example.com"
    assert "access_token" in result
    assert "refresh_token" in result


def test_sign_in_wrong_password():
    auth = _auth()
    auth.sign_up("c@d.com", "right")
    result = auth.sign_in("c@d.com", "wrong")

    assert result["error"]["code"] == "INVALID_CREDENTIALS"


def test_sign_in_unknown_user():
    auth = _auth()
    result = auth.sign_in("nobody@example.com", "pass")
    assert result["error"]["code"] == "INVALID_CREDENTIALS"


# ── sign_out ──────────────────────────────────────────────────────────────────

def test_sign_out_valid_token():
    auth = _auth()
    access_token = auth.sign_up("e@f.com", "pass")["access_token"]
    result = auth.sign_out(access_token)
    assert result == {"success": True}


def test_sign_out_invalid_token():
    auth = _auth()
    result = auth.sign_out("not.a.valid.token")
    assert result["error"]["code"] == "INVALID_TOKEN"


# ── get_session ──────────────────────────────────────────────────────────────

def test_get_session_valid():
    auth = _auth()
    access_token = auth.sign_up("g@h.com", "pass")["access_token"]
    result = auth.get_session(access_token)

    assert "error" not in result
    assert result["user"]["email"] == "g@h.com"


def test_get_session_invalid_token():
    auth = _auth()
    result = auth.get_session("bad.token.here")
    assert result["error"]["code"] == "UNAUTHORIZED"


# ── verify_token ──────────────────────────────────────────────────────────────

def test_verify_token_returns_user():
    auth = _auth()
    access_token = auth.sign_up("i@j.com", "pass")["access_token"]
    user = auth.verify_token(access_token)
    assert user is not None
    assert user.email == "i@j.com"


def test_verify_token_bad_returns_none():
    auth = _auth()
    assert auth.verify_token("garbage") is None


def test_get_session_rejects_refresh_token():
    """Only access tokens are accepted for get_session."""
    auth = _auth()
    result = auth.sign_up("k@l.com", "pass")
    refresh_token = result["refresh_token"]
    session_result = auth.get_session(refresh_token)
    assert "error" in session_result
    assert session_result["error"]["code"] == "UNAUTHORIZED"


# ── refresh & revoke ─────────────────────────────────────────────────────────

def test_refresh_returns_new_tokens():
    auth = _auth()
    auth.sign_up("m@n.com", "pass")
    result = auth.sign_in("m@n.com", "pass")
    refresh_token = result["refresh_token"]
    refresh_result = auth.refresh(refresh_token)
    assert "error" not in refresh_result
    assert refresh_result["user"]["email"] == "m@n.com"
    assert "access_token" in refresh_result
    assert "refresh_token" in refresh_result
    # Rotation: new refresh token is always different (old one revoked)
    assert refresh_result["refresh_token"] != refresh_token
    assert "expires_in" in refresh_result


def test_refresh_after_revoke_fails():
    auth = _auth()
    auth.sign_up("p@q.com", "pass")
    result = auth.sign_in("p@q.com", "pass")
    auth.revoke_session(result["refresh_token"])
    refresh_result = auth.refresh(result["refresh_token"])
    assert "error" in refresh_result
    assert refresh_result["error"]["code"] == "SESSION_NOT_FOUND"


def test_revoke_session_success():
    auth = _auth()
    auth.sign_up("r@s.com", "pass")
    result = auth.sign_in("r@s.com", "pass")
    revoke_result = auth.revoke_session(result["refresh_token"])
    assert revoke_result == {"success": True}


# ── SQL persistence ───────────────────────────────────────────────────────────

def test_sqlite_persistence():
    import tempfile
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as tmp:
        db_path = tmp.name

    try:
        adapter = SQLAlchemyAdapter(f"sqlite:///{db_path}")
        auth = Auth101(secret="secret-key-for-testing-purposes!!", database=adapter)

        result = auth.sign_up("sql@example.com", "pass123")
        assert result["user"]["email"] == "sql@example.com"

        result2 = auth.sign_in("sql@example.com", "pass123")
        assert "access_token" in result2

        auth._wiring.store.engine.dispose()

        # New instance, same file
        adapter2 = SQLAlchemyAdapter(f"sqlite:///{db_path}")
        auth2 = Auth101(secret="secret-key-for-testing-purposes!!", database=adapter2)
        assert auth2.sign_in("sql@example.com", "pass123")["user"]["email"] == "sql@example.com"
        auth2._wiring.store.engine.dispose()
    finally:
        if os.path.exists(db_path):
            try:
                os.unlink(db_path)
            except PermissionError:
                pass


# ── config validation ─────────────────────────────────────────────────────────

def test_secret_required():
    adapter = SQLAlchemyAdapter("sqlite:///:memory:")
    with pytest.raises(ValueError, match="secret"):
        Auth101(secret="", database=adapter)


def test_database_required():
    with pytest.raises(ValueError, match="database"):
        Auth101(secret="secret-key-for-testing-purposes!!", database=None)


def test_cli_migrate_runs():
    """CLI migrate with config module that has database and no mapping runs without error."""
    import sys
    from auth101.cli import main

    orig_argv = sys.argv
    try:
        sys.argv = ["auth101", "migrate", "--config", "tests.migrate_config"]
        main()
    finally:
        sys.argv = orig_argv
