'''
Camera loader
'''

# import os
# import sys
# import platform
# import logging
# import time
# from queue import Queue
# from threading import Thread
# from threading import Lock

# # Open Computer Vision
# try:
#     import cv2
# except ImportError:
#     print('Camera bindings requires "opencv" package.')
#     print('Install it via command:')
#     print('    pip install opencv-python')
#     raise

# # Numerical Python
# try:
#     import numpy as np
# except ImportError:
#     print('Camera bindings requires "numpy" package.')
#     print('Install it via command:')
#     print('    pip install numpy')
#     raise

# try:
#     import h5py
# except ImportError:
#     print('Camera bindings requires "h5py" package.')
#     print('Install it via command:')
#     print('    pip install numpy')
#     raise

# try:
#     import tifffile
# except ImportError:
#     print('Camera bindings requires "tifffile" package.')
#     print('Install it via command:')
#     print('    pip install numpy')
#     raise
