"""Return the current version"""
VERSION = (1, 3, 2)

__version__ = ".".join(map(str, VERSION))