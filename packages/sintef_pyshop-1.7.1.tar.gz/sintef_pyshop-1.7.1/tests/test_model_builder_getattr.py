import pytest

from tests.test_shop_api import ShopApiMock
from pyshop.shopcore.model_builder import (
    ModelBuilderType,
    ModelBuilderObject,
    AttributeBuilderObject,
    AttributeObject,
    ConnectToObjectType,
    ConnectToObject,
)


@pytest.fixture
def api():
    return ShopApiMock()


@pytest.mark.parametrize("builder_factory", [
    lambda api: ModelBuilderType(api),
    lambda api: ModelBuilderObject(api, ModelBuilderType(api), 'reservoir', ['rsv1']),
    lambda api: AttributeBuilderObject(api, 'reservoir', 'rsv1'),
    lambda api: AttributeObject(api, 'reservoir', 'rsv1', 'volume', 'double'),
    lambda api: ConnectToObjectType(api, 'reservoir', 'rsv1', ''),
    lambda api: ConnectToObject(api, 'reservoir', 'rsv1', '', 'plant'),
])
def test_private_attr_raises_attribute_error(api, builder_factory):
    builder = builder_factory(api)
    with pytest.raises(AttributeError):
        _ = builder._private
