"""
Wikipedia MCP Server - A Model Context Protocol server for Wikipedia integration.
"""

__version__ = "2.0.0"
