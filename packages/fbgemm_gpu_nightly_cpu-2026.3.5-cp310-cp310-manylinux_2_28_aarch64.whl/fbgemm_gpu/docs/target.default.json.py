
{
    "version": "2026.3.5",
    "target": "default",
    "variant": "cpu"
}
