from .demoparser2 import *

__doc__ = demoparser2.__doc__
if hasattr(demoparser2, "__all__"):
    __all__ = demoparser2.__all__