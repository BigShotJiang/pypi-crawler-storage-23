{%- if cookiecutter.enable_oauth_google %}
export { GoogleIcon } from "./google-icon";
{%- endif %}
