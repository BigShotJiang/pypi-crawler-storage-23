import { LoginForm } from "@/components/auth";

export default function LoginPage() {
  return <LoginForm />;
}
