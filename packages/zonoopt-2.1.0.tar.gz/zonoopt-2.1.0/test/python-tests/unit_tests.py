import numpy as np
import zonoopt as zono
import scipy.sparse as sp
from pathlib import Path

"""zonoLAB used to generate these unit tests"""

# globals: unit test folder
test_data_folder = Path(__file__).parent.parent / 'test-data'

# unit tests
def test_vrep_2_hz():

    # folder where unit test data resides
    test_folder = test_data_folder / 'vrep_2_hybzono'

    # build hybzono from vrep
    V_polys = []
    V_polys.append(np.array([[5.566, 5.896],
                             [4.044, 5.498],
                             [5.32, 3.909],
                             [5.599, 4.082]]))
    V_polys.append(np.array([[0.049, 6.05],
                             [-0.248, 3.881],
                             [0.617, 3.981]]))
    V_polys.append(np.array([[5.481, 0.911],
                             [4.937, 1.183],
                             [5.199, -1.001]]))
    V_polys.append(np.array([[3.447, 3.207],
                             [2.853, 3.552],
                             [3.341, 1.914],
                             [3.656, 2.397]]))
        
    Z = zono.vrep_2_hybzono(V_polys)

    if Z.is_0_1_form():
        Z.convert_form()

    # expected result
    Gc_expected = np.loadtxt(test_folder / 'Gc.txt', delimiter=' ')
    Gb_expected = np.loadtxt(test_folder / 'Gb.txt', delimiter=' ')
    c_expected = np.loadtxt(test_folder / 'c.txt', delimiter=' ')
    Ac_expected = np.loadtxt(test_folder / 'Ac.txt', delimiter=' ')
    Ab_expected = np.loadtxt(test_folder / 'Ab.txt', delimiter=' ')
    b_expected = np.loadtxt(test_folder / 'b.txt', delimiter=' ')

    # correct equality constraints for normalization
    for i in range(len(b_expected)):
        if np.abs(b_expected[i]-Z.get_b()[i]) > 1e-3:
            Ac_expected[i,:] *= Z.get_b()[i]/b_expected[i]
            Ab_expected[i,:] *= Z.get_b()[i]/b_expected[i]
            b_expected[i] = Z.get_b()[i]

    # compare results
    assert np.allclose(Z.get_Gc().toarray(), Gc_expected)
    assert np.allclose(Z.get_Gb().toarray(), Gb_expected)
    assert np.allclose(Z.get_c(), c_expected)
    assert np.allclose(Z.get_Ac().toarray(), Ac_expected)
    assert np.allclose(Z.get_Ab().toarray(), Ab_expected)
    assert np.allclose(Z.get_b(), b_expected)
    print('Passed: V-rep to Hybzono')

def test_minkowski_sum():

    # folder where unit test data resides
    test_folder = test_data_folder / 'minkowski_sum'

    # build hybzono from vrep
    V_polys = []
    V_polys.append(np.array([[5.566, 5.896],
                             [4.044, 5.498],
                             [5.32, 3.909],
                             [5.599, 4.082]]))
    V_polys.append(np.array([[0.049, 6.05],
                             [-0.248, 3.881],
                             [0.617, 3.981]]))
    V_polys.append(np.array([[5.481, 0.911],
                             [4.937, 1.183],
                             [5.199, -1.001]]))
    V_polys.append(np.array([[3.447, 3.207],
                             [2.853, 3.552],
                             [3.341, 1.914],
                             [3.656, 2.397]]))
        
    Z1 = zono.vrep_2_hybzono(V_polys)

    # zonotope
    G = 0.5*np.array([[np.sqrt(3), 1, np.sqrt(3)],
                        [0.5, 0, -0.5]])
    c = np.array([-2.0, 1.0])
    Z2 = zono.Zono(G,c)

    # minkowski sum
    Z = zono.minkowski_sum(Z1, Z2)
    if Z.is_0_1_form():
        Z.convert_form()

    # expected result
    Gc_expected = np.loadtxt(test_folder / 'Gc.txt', delimiter=' ')
    Gb_expected = np.loadtxt(test_folder / 'Gb.txt', delimiter=' ')
    c_expected = np.loadtxt(test_folder / 'c.txt', delimiter=' ')
    Ac_expected = np.loadtxt(test_folder / 'Ac.txt', delimiter=' ')
    Ab_expected = np.loadtxt(test_folder / 'Ab.txt', delimiter=' ')
    b_expected = np.loadtxt(test_folder / 'b.txt', delimiter=' ')

    # correct equality constraints for normalization
    for i in range(len(b_expected)):
        if np.abs(b_expected[i]-Z.get_b()[i]) > 1e-3:
            Ac_expected[i,:] *= Z.get_b()[i]/b_expected[i]
            Ab_expected[i,:] *= Z.get_b()[i]/b_expected[i]
            b_expected[i] = Z.get_b()[i]

    # compare results
    assert np.allclose(Z.get_Gc().toarray(), Gc_expected)
    assert np.allclose(Z.get_Gb().toarray(), Gb_expected)
    assert np.allclose(Z.get_c(), c_expected)
    assert np.allclose(Z.get_Ac().toarray(), Ac_expected)
    assert np.allclose(Z.get_Ab().toarray(), Ab_expected)
    assert np.allclose(Z.get_b(), b_expected)
    print('Passed: Minkowski Sum')
    
def test_intersection():

    # folder where unit test data resides
    test_folder = test_data_folder / 'intersection'

    # build hybzono from vrep
    V_polys = []
    V_polys.append(np.array([[5.566, 5.896],
                             [4.044, 5.498],
                             [5.32, 3.909],
                             [5.599, 4.082]]))
    V_polys.append(np.array([[0.049, 6.05],
                             [-0.248, 3.881],
                             [0.617, 3.981]]))
    V_polys.append(np.array([[5.481, 0.911],
                             [4.937, 1.183],
                             [5.199, -1.001]]))
    V_polys.append(np.array([[3.447, 3.207],
                             [2.853, 3.552],
                             [3.341, 1.914],
                             [3.656, 2.397]]))
        
    Z1 = zono.vrep_2_hybzono(V_polys)

    # zonotope
    G = 0.5*np.array([[np.sqrt(3), 1, np.sqrt(3)],
                        [0.5, 0, -0.5]])
    c = np.array([-2.0, 1.0])
    Z2 = zono.Zono(sp.csc_matrix(G), c)

    # minkowski sum
    Z3 = zono.minkowski_sum(Z1, Z2)

    # conzono
    G = np.array([[3.0, 0.0, 0.0], 
                  [0.0, 3.0, 0.0]])
    c = np.array([-0.5, 4.5])
    A = np.ones((1, 3))
    b = np.array([1.0])
    Z4 = zono.ConZono(sp.csc_matrix(G), c, sp.csc_matrix(A), b)

    # intersection
    Z = zono.intersection(Z3, Z4)
    if Z.is_0_1_form():
        Z.convert_form()

    # expected result
    Gc_expected = np.loadtxt(test_folder / 'Gc.txt', delimiter=' ')
    Gb_expected = np.loadtxt(test_folder / 'Gb.txt', delimiter=' ')
    c_expected = np.loadtxt(test_folder / 'c.txt', delimiter=' ')
    Ac_expected = np.loadtxt(test_folder / 'Ac.txt', delimiter=' ')
    Ab_expected = np.loadtxt(test_folder / 'Ab.txt', delimiter=' ')
    b_expected = np.loadtxt(test_folder / 'b.txt', delimiter=' ')

    # correct equality constraints for normalization
    for i in range(len(b_expected)):
        if np.abs(b_expected[i]-Z.get_b()[i]) > 1e-3:
            Ac_expected[i,:] *= Z.get_b()[i]/b_expected[i]
            Ab_expected[i,:] *= Z.get_b()[i]/b_expected[i]
            b_expected[i] = Z.get_b()[i]

    # compare results
    assert np.allclose(Z.get_Gc().toarray(), Gc_expected)
    assert np.allclose(Z.get_Gb().toarray(), Gb_expected)
    assert np.allclose(Z.get_c(), c_expected)
    assert np.allclose(Z.get_Ac().toarray(), Ac_expected)
    assert np.allclose(Z.get_Ab().toarray(), Ab_expected)
    assert np.allclose(Z.get_b(), b_expected)
    print('Passed: Intersection')

def test_is_empty():

    # folder where unit test data resides
    test_folder = test_data_folder / 'is_empty'

    # load in feasible conzono
    G = np.loadtxt(test_folder / 'f_G.txt', delimiter=' ')
    c = np.loadtxt(test_folder / 'f_c.txt', delimiter=' ')
    A = np.loadtxt(test_folder / 'f_A.txt', delimiter=' ')
    b = np.loadtxt(test_folder / 'f_b.txt', delimiter=' ')

    Zf = zono.ConZono(sp.csc_matrix(G), c, sp.csc_matrix(A), b)

    # load in infeasible conzono
    G = np.loadtxt(test_folder / 'i_G.txt', delimiter=' ')
    c = np.loadtxt(test_folder / 'i_c.txt', delimiter=' ')
    A = np.loadtxt(test_folder / 'i_A.txt', delimiter=' ')
    b = np.loadtxt(test_folder / 'i_b.txt', delimiter=' ')

    Zi = zono.ConZono(sp.csc_matrix(G), c, sp.csc_matrix(A), b)
    
    # check if empty
    assert not Zf.is_empty()
    assert Zi.is_empty()
    print('Passed: Is Empty')

def test_support():

    # folder where unit test data resides
    test_folder = test_data_folder / 'support'

    # load in conzono
    G = np.loadtxt(test_folder / 'G.txt', delimiter=' ')
    c = np.loadtxt(test_folder / 'c.txt', delimiter=' ')
    A = np.loadtxt(test_folder / 'A.txt', delimiter=' ')
    b = np.loadtxt(test_folder / 'b.txt', delimiter=' ')

    Z = zono.ConZono(sp.csc_matrix(G), c, sp.csc_matrix(A), b)

    # load direction and expected support value
    d = np.loadtxt(test_folder / 'd.txt', delimiter=' ')
    s_expected = np.loadtxt(test_folder / 'sup.txt', delimiter=' ')

    # compute support
    s = Z.support(d)
    
    # compare results
    tol = 5e-2 # tolerance on success
    assert np.abs(s-s_expected)/np.abs(s_expected) < tol
    print('Passed: Support Function')

def test_point_contain():

    # folder where the data resides
    test_folder = test_data_folder / 'point_contain'

    # load in conzono
    G = np.loadtxt(test_folder / 'G.txt', delimiter=' ')
    c = np.loadtxt(test_folder / 'c.txt', delimiter=' ')
    A = np.loadtxt(test_folder / 'A.txt', delimiter=' ')
    b = np.loadtxt(test_folder / 'b.txt', delimiter=' ')

    Z = zono.ConZono(sp.csc_matrix(G), c, sp.csc_matrix(A), b)

    # load point in set
    x_c = np.loadtxt(test_folder / 'x_c.txt', delimiter=' ')

    # load point not in set
    x_n = np.loadtxt(test_folder / 'x_n.txt', delimiter=' ')

    # check correct classification of containment
    assert Z.contains_point(x_c)
    assert not Z.contains_point(x_n)
    print('Passed: Point Containment')

def test_get_leaves():

    # make random conzonos
    np.random.seed(0)

    n_CZs = 20
    n = 10
    nV = 2*n

    CZs = []
    for i in range(n_CZs):
        V = np.random.random((nV, n))
        CZs.append(zono.vrep_2_conzono(V))

    # take union
    U = zono.union_of_many(CZs)

    # minkowski sum
    Z = zono.minkowski_sum(U, U)

    # get number of leaves
    leaves = Z.get_leaves()

    # check number of leaves is correct
    assert len(leaves) == n_CZs**2
    print('Passed: Get Leaves')

def test_safety_verification():

    # System dynamics
    dt = 0.1
    A = np.array([[1., dt],
                  [0., 1.]])
    B = np.array([[0.5*dt**2],
                  [dt]])

    # Initial set: box [-1.0, 1.0] x [-0.1, 0.1]
    X0 = zono.interval_2_zono(zono.Box([-1., -0.1], [1., 0.1]))

    # Input set: box [-0.2, 0.2]
    U = zono.interval_2_zono(zono.Box([-0.2], [0.2]))

    # Disturbance set: affine map of octagon
    W = zono.make_regular_zono_2D(radius=1., n_sides=8)
    W = zono.affine_map(W, np.diag([0.01, 0.05]))

    # Compute reachable set over 10 time steps
    X = X0
    for k in range(10):
        X = zono.affine_map(X, A)
        X = zono.minkowski_sum(X, zono.affine_map(U, B))
        X = zono.minkowski_sum(X, W)

    # Unsafe set
    O = zono.vrep_2_conzono(np.array([[1.3, 0.],
                                      [1.6, 0.8],
                                      [2.0, -0.4],
                                      [2.3, 0.6]]))

    # expect intersection of X and O is empty
    assert zono.intersection(X, O).is_empty()
    print('Passed: Safety Verification')

def test_interval_arithmetic():
    
    np.random.seed(0)

    # constants
    n_dims = 3
    n_samples = 10000
    
    # expression
    f = lambda x: 2*np.tan(x[0])**(-2) + np.cos(x[1]/x[0])/3. + np.sin(x[0] + np.arctan(x[2]))*np.sinh(x[0]) + np.exp(np.arccosh(np.abs(x[1]) + 1)) - np.arccos(x[0])*np.arcsin(x[1])/np.log(x[2]**2)

    # interval expression
    f_int = lambda x: (x[0].tan()**(-2))*2. + (x[1]/x[0]).cos()/3. + (x[0] + x[2].arctan()).sin()*x[0].sinh() + (x[1].abs() + 1).arccosh().exp() - (x[0].arccos()*x[1].arcsin())/(x[2]**2).log()

    def _run_interval_test(x_min, x_max):
        x = zono.Box(x_min*np.ones(n_dims), x_max*np.ones(n_dims)) # box
        x_sample = np.random.uniform(x_min, x_max, (n_samples, n_dims)) # generate random points in interval

        # get bounding interval
        f_bounds = f_int(x)

        # get samples
        f_samples = np.array([f(x_sample[i,:]) for i in range(n_samples)])

        # plot
        # import matplotlib.pyplot as plt
        # fig = plt.hist([fs for fs in f_samples if not np.isnan(fs) and not np.isinf(fs)], bins=100, density=True)
        # print(f'Interval bounds: {f_bounds}')
        # plt.show()

        # check that all samples evaluate to values within the computed interval
        for f_sample in f_samples:
            assert np.isnan(f_sample) or f_bounds.contains(f_sample)

    # Case 1: positive range
    _run_interval_test(0.1, 0.2)
    
    # Case 2: negative range, approaching 0
    _run_interval_test(-0.2, -0.001)

    # Case 3: spanning 0
    _run_interval_test(-1., 1.)

    print('Passed: Interval Arithmetic')


# run the unit tests
test_vrep_2_hz()
test_minkowski_sum()
test_intersection()
test_is_empty()
test_support()
test_point_contain()
test_get_leaves()
test_safety_verification()
test_interval_arithmetic()