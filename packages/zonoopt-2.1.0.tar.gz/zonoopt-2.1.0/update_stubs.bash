stubgen -m zonoopt._core -o python/ --include-docstrings
stubgen -m zonoopt -o python/ --include-docstrings
