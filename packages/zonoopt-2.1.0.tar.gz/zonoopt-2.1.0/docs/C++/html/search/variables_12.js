var searchData=
[
  ['z_0',['z',['../structZonoOpt_1_1WarmStartParams.html#a67c7ba962b1e7dae7fd0a3de2e41dff6',1,'ZonoOpt::WarmStartParams::z'],['../structZonoOpt_1_1OptSolution.html#a487b453e89bf468a8534b1fafdf08565',1,'ZonoOpt::OptSolution::z']]],
  ['zero_5fone_5fform_1',['zero_one_form',['../classZonoOpt_1_1HybZono.html#a4e37404489e8ad6a73586ba545563a63',1,'ZonoOpt::HybZono']]]
];
