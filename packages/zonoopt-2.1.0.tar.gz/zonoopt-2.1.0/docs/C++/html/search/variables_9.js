var searchData=
[
  ['max_5fnodes_0',['max_nodes',['../structZonoOpt_1_1OptSettings.html#ae0316ea3c2a38f4b4197eefb2e09881b',1,'ZonoOpt::OptSettings']]]
];
