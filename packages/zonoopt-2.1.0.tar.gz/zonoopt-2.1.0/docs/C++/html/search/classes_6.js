var searchData=
[
  ['optsettings_0',['OptSettings',['../structZonoOpt_1_1OptSettings.html',1,'ZonoOpt']]],
  ['optsolution_1',['OptSolution',['../structZonoOpt_1_1OptSolution.html',1,'ZonoOpt']]]
];
