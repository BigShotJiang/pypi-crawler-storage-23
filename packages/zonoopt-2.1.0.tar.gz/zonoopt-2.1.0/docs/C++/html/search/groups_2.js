var searchData=
[
  ['operations_0',['Set Operations',['../group__ZonoOpt__SetOperations.html',1,'']]]
];
