var searchData=
[
  ['polish_0',['polish',['../structZonoOpt_1_1OptSettings.html#a08dc026c49076a5d8c1ce8e132a48ee6',1,'ZonoOpt::OptSettings']]],
  ['primal_5fresidual_1',['primal_residual',['../structZonoOpt_1_1OptSolution.html#a9bb49c721a085472a57bfcb3530cd365',1,'ZonoOpt::OptSolution']]]
];
