var searchData=
[
  ['verbose_0',['verbose',['../structZonoOpt_1_1OptSettings.html#a61a37d7f2a52b2a7372448893476b79e',1,'ZonoOpt::OptSettings']]],
  ['verbosity_5finterval_1',['verbosity_interval',['../structZonoOpt_1_1OptSettings.html#aa6e28d1a8ce65bb011eb88bc7d12b588',1,'ZonoOpt::OptSettings']]]
];
