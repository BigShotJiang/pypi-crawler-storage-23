var searchData=
[
  ['radius_0',['radius',['../classZonoOpt_1_1Interval.html#a907d9727912e1b0f5cb6fdba5e2a75a9',1,'ZonoOpt::Interval::radius()'],['../classZonoOpt_1_1Box.html#abb61f47eea2d464b96989d2defd85aeb',1,'ZonoOpt::Box::radius()'],['../classZonoOpt_1_1IntervalMatrix.html#acd7eeaba47e094b31fda22e7f6e9218f',1,'ZonoOpt::IntervalMatrix::radius()']]],
  ['readme_2emd_1',['README.md',['../README_8md.html',1,'']]],
  ['reduce_5forder_2',['reduce_order',['../classZonoOpt_1_1Zono.html#a98480f31374733165d0b0b4c22d82bc9',1,'ZonoOpt::Zono']]],
  ['references_3',['References',['../index.html#autotoc_md6',1,'']]],
  ['remove_5fgenerators_4',['remove_generators',['../classZonoOpt_1_1HybZono.html#a9bd4a75f271f7c974f155659a267e921',1,'ZonoOpt::HybZono']]],
  ['remove_5fredundancy_5',['remove_redundancy',['../classZonoOpt_1_1HybZono.html#a6db0f006ddbe7d66d9fb2aaadca67199',1,'ZonoOpt::HybZono::remove_redundancy()'],['../classZonoOpt_1_1Point.html#a6b1a78851f2767f59d2e4053938988f5',1,'ZonoOpt::Point::remove_redundancy()']]],
  ['rho_6',['rho',['../structZonoOpt_1_1OptSettings.html#aa9daad3982cfea491e0aa34451dc53dd',1,'ZonoOpt::OptSettings']]],
  ['rng_5fseed_7',['rng_seed',['../structZonoOpt_1_1OptSettings.html#a461a2b8cf4bcfa6010ab06b4a00209e3',1,'ZonoOpt::OptSettings']]],
  ['rows_8',['rows',['../classZonoOpt_1_1IntervalMatrix.html#a0bc12d80aa6560a114c9a0560aaf99d8',1,'ZonoOpt::IntervalMatrix']]],
  ['run_5ftime_9',['run_time',['../structZonoOpt_1_1OptSolution.html#a4c924318807a20bd19229fe1d7995de2',1,'ZonoOpt::OptSolution']]]
];
