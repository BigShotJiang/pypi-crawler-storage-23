var searchData=
[
  ['zonoptr_0',['ZonoPtr',['../group__ZonoOpt__Typedefs.html#ga3a3f3cf55efb220d20c4a23c7a34f4d4',1,'ZonoOpt']]]
];
