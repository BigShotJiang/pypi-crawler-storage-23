var searchData=
[
  ['bnbdatastructures_2ehpp_0',['BnbDataStructures.hpp',['../BnbDataStructures_8hpp.html',1,'']]],
  ['branchandbound_2ecpp_1',['BranchAndBound.cpp',['../BranchAndBound_8cpp.html',1,'']]],
  ['branchandbound_2ehpp_2',['BranchAndBound.hpp',['../BranchAndBound_8hpp.html',1,'']]]
];
