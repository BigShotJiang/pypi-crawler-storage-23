var searchData=
[
  ['dual_5fresidual_0',['dual_residual',['../structZonoOpt_1_1OptSolution.html#a0bee6dd906cace0468217522d3f3c827',1,'ZonoOpt::OptSolution']]]
];
