# from dataclasses import dataclass
# from typing import Any, Callable, List, Optional

# @dataclass
# class SlurmScript:
