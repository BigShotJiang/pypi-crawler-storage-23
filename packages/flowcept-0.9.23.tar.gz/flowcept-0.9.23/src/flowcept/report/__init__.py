"""Reporting utilities for Flowcept."""

from flowcept.report.service import generate_report

__all__ = ["generate_report"]
