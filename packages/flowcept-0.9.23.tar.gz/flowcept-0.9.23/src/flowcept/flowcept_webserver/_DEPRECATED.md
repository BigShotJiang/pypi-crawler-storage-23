# Deprecated Webserver Package

This package (`flowcept_webserver`) is legacy and deprecated.

- New REST endpoints are implemented under `flowcept.webservice` (FastAPI).
- Avoid adding new features here.
- Keep this package only for backward compatibility during migration.
