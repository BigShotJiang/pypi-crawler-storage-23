"""Legacy webserver subpackage (deprecated)."""
