from typing import List, Tuple
from abs_auth_rbac_core.rbac.service import RBACService
from abs_auth_rbac_core.models import Users
from abs_exception_core.exceptions import NotFoundError

def get_permission_resources(actions:List[str],module:str,user:Users,rbac_service:RBACService) -> Tuple[List[str],bool]:
    ids = set()
    is_super_admin = False
    if user and rbac_service:
        try:
            is_super_admin = any(role.name == "super_admin" for role in user.roles)
            if not is_super_admin:
                for action in actions:
                    user_policy = rbac_service.enforcer.get_filtered_policy(0,f"user:{user.uuid}","",action,module)
                    role_policy = []
                    for role in user.roles:
                        policy = rbac_service.enforcer.get_filtered_policy(0,f"{role.uuid}","",action,module)
                        if policy:
                            role_policy.extend(policy)

                    combined_policy = user_policy + role_policy

                    for policy in combined_policy:
                        id_data = policy[1].split(":")
                        if len(id_data)==2:
                            ids.add(id_data[1])
                        else:
                            ids.add(id_data[0])
        except NotFoundError:
            raise NotFoundError(f"User with UUID {user.uuid} not found")
    return list(ids), is_super_admin