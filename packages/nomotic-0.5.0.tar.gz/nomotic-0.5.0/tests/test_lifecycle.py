"""Tests for Agent Lifecycle Hooks (v0.6.0 Item 11)."""

import time
from unittest.mock import MagicMock, patch

import pytest

from nomotic.lifecycle import LifecycleContext, LifecycleEvent, LifecycleManager
from nomotic.runtime import GovernanceRuntime, RuntimeConfig
from nomotic.types import Action, AgentContext, TrustProfile, Verdict
from nomotic.webhooks import WEBHOOK_EVENT_TYPES


# ── Helpers ──────────────────────────────────────────────────────────


def _make_context(
    event: LifecycleEvent = LifecycleEvent.BIRTH,
    agent_id: str = "test-agent",
    trust: float = 0.8,
) -> LifecycleContext:
    return LifecycleContext(
        event=event,
        agent_id=agent_id,
        agent_name=agent_id,
        archetype="executor",
        trust_score=trust,
        timestamp=time.time(),
        certificate_id="nmcrt-test123",
        trigger_reason="test trigger",
    )


def _runtime_ctx(agent_id: str = "agent-1", trust: float = 0.5) -> AgentContext:
    return AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id, overall_trust=trust),
    )


def _action(agent_id: str = "agent-1", action_type: str = "read", target: str = "db") -> Action:
    return Action(agent_id=agent_id, action_type=action_type, target=target)


# ── TestLifecycleManager ────────────────────────────────────────────


class TestLifecycleManager:
    def test_register_returns_hook_id(self):
        mgr = LifecycleManager()
        hook_id = mgr.register(LifecycleEvent.BIRTH, lambda ctx: None)
        assert hook_id.startswith("nmhk-")
        assert len(hook_id) > 5

    def test_deregister_removes_hook(self):
        mgr = LifecycleManager()
        hook_id = mgr.register(LifecycleEvent.BIRTH, lambda ctx: None)
        assert mgr.deregister(hook_id) is True
        # Hook should no longer be in the list
        hooks = mgr.list_hooks()
        assert all(h["hook_id"] != hook_id for h in hooks)

    def test_deregister_unknown_returns_false(self):
        mgr = LifecycleManager()
        assert mgr.deregister("nmhk-nonexistent") is False

    def test_trigger_calls_registered_hook(self):
        mgr = LifecycleManager()
        called = []
        mgr.register(LifecycleEvent.BIRTH, lambda ctx: called.append(ctx.event))

        ctx = _make_context(LifecycleEvent.BIRTH)
        mgr.trigger(LifecycleEvent.BIRTH, ctx)

        assert len(called) == 1
        assert called[0] == LifecycleEvent.BIRTH

    def test_trigger_calls_multiple_hooks_in_order(self):
        mgr = LifecycleManager()
        order = []
        mgr.register(LifecycleEvent.DEGRADED, lambda ctx: order.append("first"))
        mgr.register(LifecycleEvent.DEGRADED, lambda ctx: order.append("second"))
        mgr.register(LifecycleEvent.DEGRADED, lambda ctx: order.append("third"))

        ctx = _make_context(LifecycleEvent.DEGRADED)
        mgr.trigger(LifecycleEvent.DEGRADED, ctx)

        assert order == ["first", "second", "third"]

    def test_hook_failure_does_not_prevent_others(self):
        mgr = LifecycleManager()
        called = []

        def failing_hook(ctx):
            raise RuntimeError("hook failed")

        mgr.register(LifecycleEvent.CRITICAL, lambda ctx: called.append("before"))
        mgr.register(LifecycleEvent.CRITICAL, failing_hook)
        mgr.register(LifecycleEvent.CRITICAL, lambda ctx: called.append("after"))

        ctx = _make_context(LifecycleEvent.CRITICAL)
        mgr.trigger(LifecycleEvent.CRITICAL, ctx)

        assert called == ["before", "after"]

    def test_hook_failure_does_not_raise(self):
        mgr = LifecycleManager()

        def failing_hook(ctx):
            raise ValueError("kaboom")

        mgr.register(LifecycleEvent.BIRTH, failing_hook)

        ctx = _make_context(LifecycleEvent.BIRTH)
        # Should not raise
        mgr.trigger(LifecycleEvent.BIRTH, ctx)

    def test_list_hooks_returns_all_registered(self):
        mgr = LifecycleManager()
        id1 = mgr.register(LifecycleEvent.BIRTH, lambda ctx: None)
        id2 = mgr.register(LifecycleEvent.RETIREMENT, lambda ctx: None)
        id3 = mgr.register(LifecycleEvent.BIRTH, lambda ctx: None)

        hooks = mgr.list_hooks()
        hook_ids = {h["hook_id"] for h in hooks}
        assert id1 in hook_ids
        assert id2 in hook_ids
        assert id3 in hook_ids
        assert len(hooks) == 3

    def test_list_hooks_empty_when_none_registered(self):
        mgr = LifecycleManager()
        assert mgr.list_hooks() == []


# ── TestLifecycleEvents ─────────────────────────────────────────────


class TestLifecycleEvents:
    def test_birth_event_fires_after_certificate_issuance(self):
        runtime = GovernanceRuntime()
        fired = []
        runtime.register_lifecycle_hook(
            LifecycleEvent.BIRTH,
            lambda ctx: fired.append(ctx),
        )

        cert = runtime.birth(
            agent_id="birth-agent",
            archetype="executor",
            organization="test-org",
            zone_path="/test",
        )

        assert len(fired) == 1
        assert fired[0].event == LifecycleEvent.BIRTH
        assert fired[0].agent_id == "birth-agent"
        assert fired[0].certificate_id == cert.certificate_id

    def test_retirement_event_fires_at_trust_floor(self):
        config = RuntimeConfig(lifecycle_retirement_trust_floor=0.1)
        runtime = GovernanceRuntime(config=config)

        fired = []
        runtime.register_lifecycle_hook(
            LifecycleEvent.RETIREMENT,
            lambda ctx: fired.append(ctx),
        )

        # Directly test lifecycle transitions with trust below threshold
        ctx = _runtime_ctx("agent-1", trust=0.05)
        runtime._check_lifecycle_transitions("agent-1", ctx)

        assert len(fired) == 1
        assert fired[0].event == LifecycleEvent.RETIREMENT
        assert fired[0].trust_score == 0.05

    def test_degraded_event_fires_at_uahs_threshold(self):
        """DEGRADED fires when UAHS drops below the degraded threshold.

        This requires UAHS to be enabled and the score to be below the
        threshold. Since UAHS requires several evaluations to produce a
        score, we test via the _check_lifecycle_transitions method directly.
        """
        config = RuntimeConfig(
            lifecycle_degraded_threshold=0.5,
            lifecycle_critical_threshold=0.2,
        )
        runtime = GovernanceRuntime(config=config)

        fired = []
        runtime.register_lifecycle_hook(
            LifecycleEvent.DEGRADED,
            lambda ctx: fired.append(ctx),
        )

        # Mock UAHS to return a low score
        mock_score = MagicMock()
        mock_score.overall_health = 0.4  # Below 0.5 threshold
        runtime._ucs_tracker = MagicMock()  # non-None to enable UAHS path
        runtime.get_uahs = MagicMock(return_value=mock_score)

        ctx = _runtime_ctx("agent-1", trust=0.6)
        runtime._check_lifecycle_transitions("agent-1", ctx)

        assert len(fired) == 1
        assert fired[0].event == LifecycleEvent.DEGRADED
        assert fired[0].uahs_score == 0.4

    def test_critical_event_fires_at_critical_threshold(self):
        config = RuntimeConfig(
            lifecycle_degraded_threshold=0.5,
            lifecycle_critical_threshold=0.2,
        )
        runtime = GovernanceRuntime(config=config)

        fired = []
        runtime.register_lifecycle_hook(
            LifecycleEvent.CRITICAL,
            lambda ctx: fired.append(ctx),
        )

        # Mock UAHS to return critically low score
        mock_score = MagicMock()
        mock_score.overall_health = 0.1  # Below 0.2 critical threshold
        runtime._ucs_tracker = MagicMock()
        runtime.get_uahs = MagicMock(return_value=mock_score)

        ctx = _runtime_ctx("agent-1", trust=0.6)
        runtime._check_lifecycle_transitions("agent-1", ctx)

        assert len(fired) == 1
        assert fired[0].event == LifecycleEvent.CRITICAL

    def test_revocation_event_fires_on_revoke(self):
        runtime = GovernanceRuntime()

        # First birth an agent
        cert = runtime.birth(
            agent_id="revoke-agent",
            archetype="executor",
            organization="test-org",
            zone_path="/test",
        )

        fired = []
        runtime.register_lifecycle_hook(
            LifecycleEvent.REVOCATION,
            lambda ctx: fired.append(ctx),
        )

        runtime.revoke("revoke-agent", reason="decommissioned")

        assert len(fired) == 1
        assert fired[0].event == LifecycleEvent.REVOCATION
        assert fired[0].agent_id == "revoke-agent"
        assert fired[0].trigger_reason == "decommissioned"

    def test_no_duplicate_events_for_same_state(self):
        config = RuntimeConfig(lifecycle_retirement_trust_floor=0.1)
        runtime = GovernanceRuntime(config=config)

        fired = []
        runtime.register_lifecycle_hook(
            LifecycleEvent.RETIREMENT,
            lambda ctx: fired.append(ctx),
        )

        # Two transitions at same low trust — should only fire once
        ctx = _runtime_ctx("agent-1", trust=0.05)
        runtime._check_lifecycle_transitions("agent-1", ctx)
        runtime._check_lifecycle_transitions("agent-1", ctx)

        assert len(fired) == 1

    def test_transition_active_to_degraded_to_critical(self):
        config = RuntimeConfig(
            lifecycle_degraded_threshold=0.5,
            lifecycle_critical_threshold=0.2,
        )
        runtime = GovernanceRuntime(config=config)

        events = []
        runtime.register_lifecycle_hook(
            LifecycleEvent.DEGRADED,
            lambda ctx: events.append(("degraded", ctx)),
        )
        runtime.register_lifecycle_hook(
            LifecycleEvent.CRITICAL,
            lambda ctx: events.append(("critical", ctx)),
        )

        # Mock UAHS
        mock_score = MagicMock()
        runtime._ucs_tracker = MagicMock()
        runtime.get_uahs = MagicMock(return_value=mock_score)

        ctx = _runtime_ctx("agent-1", trust=0.6)

        # First: active -> degraded
        mock_score.overall_health = 0.4
        runtime._check_lifecycle_transitions("agent-1", ctx)
        assert len(events) == 1
        assert events[0][0] == "degraded"

        # Second: degraded -> critical
        mock_score.overall_health = 0.1
        runtime._check_lifecycle_transitions("agent-1", ctx)
        assert len(events) == 2
        assert events[1][0] == "critical"


# ── TestWebhookHook ─────────────────────────────────────────────────


class TestWebhookHook:
    def test_register_webhook_hook_returns_id(self):
        mgr = LifecycleManager()
        hook_id = mgr.register_webhook_hook(
            LifecycleEvent.BIRTH,
            url="https://example.com/webhook",
        )
        assert hook_id.startswith("nmhk-")

    def test_webhook_event_types_include_lifecycle_events(self):
        assert "LIFECYCLE_BIRTH" in WEBHOOK_EVENT_TYPES
        assert "LIFECYCLE_DEGRADED" in WEBHOOK_EVENT_TYPES
        assert "LIFECYCLE_CRITICAL" in WEBHOOK_EVENT_TYPES
        assert "LIFECYCLE_RETIREMENT" in WEBHOOK_EVENT_TYPES
        assert "LIFECYCLE_REVOCATION" in WEBHOOK_EVENT_TYPES

    def test_webhook_hook_dispatches_to_dispatcher(self):
        mock_dispatcher = MagicMock()
        mgr = LifecycleManager(webhook_dispatcher=mock_dispatcher)

        mgr.register_webhook_hook(
            LifecycleEvent.BIRTH,
            url="https://example.com/webhook",
        )

        ctx = _make_context(LifecycleEvent.BIRTH)
        mgr.trigger(LifecycleEvent.BIRTH, ctx)

        assert mock_dispatcher.dispatch.called

    def test_webhook_hook_silently_skips_without_dispatcher(self):
        mgr = LifecycleManager(webhook_dispatcher=None)

        mgr.register_webhook_hook(
            LifecycleEvent.BIRTH,
            url="https://example.com/webhook",
        )

        ctx = _make_context(LifecycleEvent.BIRTH)
        # Should not raise even without a dispatcher
        mgr.trigger(LifecycleEvent.BIRTH, ctx)


# ── TestLifecycleContext ────────────────────────────────────────────


class TestLifecycleContext:
    def test_context_to_dict_roundtrip(self):
        ctx = _make_context(
            event=LifecycleEvent.DEGRADED,
            agent_id="roundtrip-agent",
            trust=0.42,
        )
        ctx.uahs_score = 0.35
        ctx.metadata = {"custom_key": "custom_value"}

        d = ctx.to_dict()

        assert d["event"] == "agent.degraded"
        assert d["agent_id"] == "roundtrip-agent"
        assert d["trust_score"] == 0.42
        assert d["uahs_score"] == 0.35
        assert d["metadata"] == {"custom_key": "custom_value"}

    def test_context_contains_required_fields(self):
        ctx = _make_context()
        d = ctx.to_dict()

        required_keys = {
            "event", "agent_id", "agent_name", "archetype",
            "trust_score", "timestamp", "certificate_id",
            "uahs_score", "trigger_reason", "metadata",
        }
        assert required_keys.issubset(set(d.keys()))

    def test_context_metadata_default_empty_dict(self):
        ctx = LifecycleContext(
            event=LifecycleEvent.BIRTH,
            agent_id="test",
            agent_name="test",
            archetype="executor",
            trust_score=0.8,
            timestamp=time.time(),
        )
        assert ctx.metadata == {}

    def test_context_event_value_matches_enum(self):
        for event in LifecycleEvent:
            ctx = _make_context(event=event)
            assert ctx.to_dict()["event"] == event.value


# ── TestRuntimeIntegration ──────────────────────────────────────────


class TestRuntimeIntegration:
    def test_lifecycle_manager_accessible_via_property(self):
        runtime = GovernanceRuntime()
        mgr = runtime.lifecycle_manager
        assert isinstance(mgr, LifecycleManager)

    def test_register_lifecycle_hook_convenience_method(self):
        runtime = GovernanceRuntime()
        called = []
        hook_id = runtime.register_lifecycle_hook(
            LifecycleEvent.BIRTH,
            lambda ctx: called.append(ctx),
            name="test-hook",
        )
        assert hook_id.startswith("nmhk-")

        cert = runtime.birth(
            agent_id="conv-agent",
            archetype="executor",
            organization="test-org",
            zone_path="/test",
        )
        assert len(called) == 1

    def test_lifecycle_disabled_when_config_false(self):
        config = RuntimeConfig(enable_lifecycle_hooks=False)
        runtime = GovernanceRuntime(config=config)

        fired = []
        runtime.register_lifecycle_hook(
            LifecycleEvent.BIRTH,
            lambda ctx: fired.append(ctx),
        )

        cert = runtime.birth(
            agent_id="disabled-agent",
            archetype="executor",
            organization="test-org",
            zone_path="/test",
        )

        # Hook should not fire when lifecycle hooks are disabled
        assert len(fired) == 0

    def test_retirement_threshold_configurable(self):
        # Custom high retirement threshold
        config = RuntimeConfig(lifecycle_retirement_trust_floor=0.3)
        runtime = GovernanceRuntime(config=config)

        fired = []
        runtime.register_lifecycle_hook(
            LifecycleEvent.RETIREMENT,
            lambda ctx: fired.append(ctx),
        )

        # Trust 0.25 is below 0.3 threshold
        ctx = _runtime_ctx("agent-1", trust=0.25)
        runtime._check_lifecycle_transitions("agent-1", ctx)

        assert len(fired) == 1

    def test_degraded_threshold_configurable(self):
        config = RuntimeConfig(lifecycle_degraded_threshold=0.7)
        runtime = GovernanceRuntime(config=config)

        fired = []
        runtime.register_lifecycle_hook(
            LifecycleEvent.DEGRADED,
            lambda ctx: fired.append(ctx),
        )

        mock_score = MagicMock()
        mock_score.overall_health = 0.6  # Below custom 0.7 threshold
        runtime._ucs_tracker = MagicMock()
        runtime.get_uahs = MagicMock(return_value=mock_score)

        ctx = _runtime_ctx("agent-1", trust=0.8)
        runtime._check_lifecycle_transitions("agent-1", ctx)

        assert len(fired) == 1

    def test_revoke_returns_none_for_unknown_agent(self):
        runtime = GovernanceRuntime()
        result = runtime.revoke("nonexistent-agent", reason="test")
        assert result is None

    def test_lifecycle_state_tracked_per_agent(self):
        """Each agent tracks its own lifecycle state independently."""
        config = RuntimeConfig(lifecycle_retirement_trust_floor=0.1)
        runtime = GovernanceRuntime(config=config)

        fired = []
        runtime.register_lifecycle_hook(
            LifecycleEvent.RETIREMENT,
            lambda ctx: fired.append(ctx.agent_id),
        )

        # Agent-1 retires
        ctx1 = _runtime_ctx("agent-1", trust=0.05)
        runtime._check_lifecycle_transitions("agent-1", ctx1)

        # Agent-2 stays active
        ctx2 = _runtime_ctx("agent-2", trust=0.8)
        runtime._check_lifecycle_transitions("agent-2", ctx2)

        assert fired == ["agent-1"]


# ── TestCLI ─────────────────────────────────────────────────────────


class TestCLI:
    def test_lifecycle_hooks_cli_output(self, capsys):
        from nomotic.cli import _cmd_lifecycle
        import argparse

        args = argparse.Namespace(
            lifecycle_command="hooks",
            base_dir=None,
        )
        _cmd_lifecycle(args)

        captured = capsys.readouterr()
        assert "No lifecycle hooks registered" in captured.out

    def test_lifecycle_events_cli_output(self, capsys, tmp_path):
        from nomotic.cli import _cmd_lifecycle
        import argparse

        args = argparse.Namespace(
            lifecycle_command="events",
            agent_id="test-agent",
            base_dir=tmp_path,
        )

        # This will show "No lifecycle events recorded" since
        # there's no audit store data
        _cmd_lifecycle(args)

        captured = capsys.readouterr()
        assert "Lifecycle Events" in captured.out

    def test_lifecycle_no_subcommand_shows_usage(self, capsys):
        from nomotic.cli import _cmd_lifecycle
        import argparse

        args = argparse.Namespace(
            lifecycle_command=None,
            base_dir=None,
        )
        _cmd_lifecycle(args)

        captured = capsys.readouterr()
        assert "Usage:" in captured.out
        assert "hooks" in captured.out
        assert "events" in captured.out


# ── TestEventHistory ─────────────────────────────────────────────────


class TestEventHistory:
    def test_event_history_records_all_events(self):
        mgr = LifecycleManager()

        ctx1 = _make_context(LifecycleEvent.BIRTH, agent_id="agent-1")
        ctx2 = _make_context(LifecycleEvent.DEGRADED, agent_id="agent-1")

        mgr.trigger(LifecycleEvent.BIRTH, ctx1)
        mgr.trigger(LifecycleEvent.DEGRADED, ctx2)

        history = mgr.get_event_history()
        assert len(history) == 2
        assert history[0]["event"] == "agent.birth"
        assert history[1]["event"] == "agent.degraded"

    def test_event_history_filtered_by_agent(self):
        mgr = LifecycleManager()

        ctx1 = _make_context(LifecycleEvent.BIRTH, agent_id="agent-1")
        ctx2 = _make_context(LifecycleEvent.BIRTH, agent_id="agent-2")

        mgr.trigger(LifecycleEvent.BIRTH, ctx1)
        mgr.trigger(LifecycleEvent.BIRTH, ctx2)

        history = mgr.get_event_history(agent_id="agent-1")
        assert len(history) == 1
        assert history[0]["agent_id"] == "agent-1"

    def test_event_history_empty_initially(self):
        mgr = LifecycleManager()
        assert mgr.get_event_history() == []
