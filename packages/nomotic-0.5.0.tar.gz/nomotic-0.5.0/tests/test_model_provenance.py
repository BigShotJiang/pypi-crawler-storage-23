"""Tests for foundation model provenance in agent birth certificates."""

import json
from datetime import datetime, timezone

from nomotic.certificate import AgentCertificate, CertStatus, ModelProvenance
from nomotic.authority import CertificateAuthority
from nomotic.keys import SigningKey
from nomotic.seal import GovernanceSeal, seal_action
from nomotic.store import MemoryCertificateStore
from nomotic.types import AgentContext, GovernanceVerdict, TrustProfile, Verdict


def _make_provenance(**overrides) -> ModelProvenance:
    """Create a ModelProvenance with sensible defaults for testing."""
    defaults = {
        "model_provider": "anthropic",
        "model_name": "claude-sonnet-4-6",
        "model_version": "20250514",
    }
    defaults.update(overrides)
    return ModelProvenance(**defaults)


def _make_cert(**overrides) -> AgentCertificate:
    """Create a certificate with sensible defaults for testing."""
    _sk, vk = SigningKey.generate()
    defaults = {
        "certificate_id": "nmc-test-1234",
        "agent_id": "agent-1",
        "owner": "alice@acme.com",
        "archetype": "customer-experience",
        "organization": "acme-corp",
        "zone_path": "global/us",
        "issued_at": datetime(2024, 1, 1, tzinfo=timezone.utc),
        "trust_score": 0.50,
        "behavioral_age": 0,
        "status": CertStatus.ACTIVE,
        "public_key": vk.to_bytes(),
        "fingerprint": vk.fingerprint(),
        "governance_hash": "abc123",
        "lineage": None,
        "issuer_signature": b"\x00" * 32,
        "expires_at": None,
    }
    defaults.update(overrides)
    return AgentCertificate(**defaults)


def _make_ca():
    """Create a CertificateAuthority for testing."""
    sk, _vk = SigningKey.generate()
    return CertificateAuthority(issuer_id="test-issuer", signing_key=sk)


# ── TestModelProvenance ──────────────────────────────────────────────────


class TestModelProvenance:
    def test_creation_required_fields_only(self):
        mp = ModelProvenance(
            model_provider="anthropic",
            model_name="claude-sonnet-4-6",
            model_version="20250514",
        )
        assert mp.model_provider == "anthropic"
        assert mp.model_name == "claude-sonnet-4-6"
        assert mp.model_version == "20250514"
        assert mp.model_hash is None
        assert mp.fine_tune_id is None
        assert mp.fine_tune_base is None
        assert mp.safety_evaluation_id is None
        assert mp.training_data_summary is None
        assert mp.known_limitations == []
        assert mp.provenance_hash == ""

    def test_creation_all_optional_fields(self):
        mp = ModelProvenance(
            model_provider="anthropic",
            model_name="claude-sonnet-4-6",
            model_version="20250514",
            model_hash="sha256abc",
            fine_tune_id="ft-123",
            fine_tune_base="claude-sonnet-4-6-20250514",
            safety_evaluation_id="mlc-2025-001",
            training_data_summary="Public internet data up to 2025",
            known_limitations=["No real-time data", "Cannot execute code"],
        )
        assert mp.model_hash == "sha256abc"
        assert mp.fine_tune_id == "ft-123"
        assert mp.fine_tune_base == "claude-sonnet-4-6-20250514"
        assert mp.safety_evaluation_id == "mlc-2025-001"
        assert mp.training_data_summary == "Public internet data up to 2025"
        assert mp.known_limitations == ["No real-time data", "Cannot execute code"]

    def test_compute_hash_deterministic(self):
        mp = _make_provenance()
        h1 = mp.compute_hash()
        h2 = mp.compute_hash()
        assert h1 == h2
        assert len(h1) == 64  # SHA-256 hex digest

    def test_compute_hash_changes_with_field(self):
        mp1 = _make_provenance(model_version="20250514")
        mp2 = _make_provenance(model_version="20250601")
        assert mp1.compute_hash() != mp2.compute_hash()

    def test_compute_hash_changes_with_provider(self):
        mp1 = _make_provenance(model_provider="anthropic")
        mp2 = _make_provenance(model_provider="openai")
        assert mp1.compute_hash() != mp2.compute_hash()

    def test_compute_hash_changes_with_name(self):
        mp1 = _make_provenance(model_name="claude-sonnet-4-6")
        mp2 = _make_provenance(model_name="claude-opus-4")
        assert mp1.compute_hash() != mp2.compute_hash()

    def test_compute_hash_excludes_provenance_hash(self):
        mp1 = _make_provenance()
        mp1.provenance_hash = ""
        h1 = mp1.compute_hash()

        mp2 = _make_provenance()
        mp2.provenance_hash = "somehashvalue"
        h2 = mp2.compute_hash()

        assert h1 == h2

    def test_to_dict_from_dict_roundtrip_all_fields(self):
        mp = ModelProvenance(
            model_provider="openai",
            model_name="gpt-4o",
            model_version="2024-08-06",
            model_hash="deadbeef",
            fine_tune_id="ft-abc",
            fine_tune_base="gpt-4o-2024-08-06",
            safety_evaluation_id="mlc-2025-openai-001",
            training_data_summary="Mixed public data",
            known_limitations=["No real-time data", "Rate limited"],
            provenance_hash="abc123",
        )
        d = mp.to_dict()
        restored = ModelProvenance.from_dict(d)
        assert restored.model_provider == mp.model_provider
        assert restored.model_name == mp.model_name
        assert restored.model_version == mp.model_version
        assert restored.model_hash == mp.model_hash
        assert restored.fine_tune_id == mp.fine_tune_id
        assert restored.fine_tune_base == mp.fine_tune_base
        assert restored.safety_evaluation_id == mp.safety_evaluation_id
        assert restored.training_data_summary == mp.training_data_summary
        assert restored.known_limitations == mp.known_limitations
        assert restored.provenance_hash == mp.provenance_hash

    def test_to_dict_from_dict_roundtrip_minimal(self):
        mp = _make_provenance()
        d = mp.to_dict()
        restored = ModelProvenance.from_dict(d)
        assert restored.model_provider == mp.model_provider
        assert restored.model_name == mp.model_name
        assert restored.model_version == mp.model_version
        assert restored.model_hash is None
        assert restored.fine_tune_id is None
        assert restored.known_limitations == []

    def test_from_dict_legacy_missing_optional_fields(self):
        d = {
            "model_provider": "meta",
            "model_name": "llama-3.1-70b",
            "model_version": "v1",
        }
        mp = ModelProvenance.from_dict(d)
        assert mp.model_provider == "meta"
        assert mp.model_hash is None
        assert mp.known_limitations == []
        assert mp.provenance_hash == ""

    def test_to_dict_omits_none_optional_fields(self):
        mp = _make_provenance()
        d = mp.to_dict()
        assert "model_hash" not in d
        assert "fine_tune_id" not in d
        assert "fine_tune_base" not in d
        assert "safety_evaluation_id" not in d
        assert "training_data_summary" not in d

    def test_to_dict_includes_set_optional_fields(self):
        mp = _make_provenance(model_hash="abc", safety_evaluation_id="mlc-1")
        d = mp.to_dict()
        assert d["model_hash"] == "abc"
        assert d["safety_evaluation_id"] == "mlc-1"


# ── TestAgentCertificateWithProvenance ────────────────────────────────


class TestAgentCertificateWithProvenance:
    def test_cert_with_no_provenance_to_dict(self):
        cert = _make_cert(model_provenance=None)
        d = cert.to_dict()
        assert "model_provenance" in d
        assert d["model_provenance"] is None

    def test_cert_with_provenance_to_dict(self):
        mp = _make_provenance()
        mp.provenance_hash = mp.compute_hash()
        cert = _make_cert(model_provenance=mp)
        d = cert.to_dict()
        assert d["model_provenance"] is not None
        assert d["model_provenance"]["model_provider"] == "anthropic"
        assert d["model_provenance"]["provenance_hash"] == mp.provenance_hash

    def test_from_dict_restores_provenance(self):
        mp = _make_provenance(safety_evaluation_id="mlc-test")
        mp.provenance_hash = mp.compute_hash()
        cert = _make_cert(model_provenance=mp)
        d = cert.to_dict()
        restored = AgentCertificate.from_dict(d)
        assert restored.model_provenance is not None
        assert restored.model_provenance.model_provider == "anthropic"
        assert restored.model_provenance.safety_evaluation_id == "mlc-test"
        assert restored.model_provenance.provenance_hash == mp.provenance_hash

    def test_from_dict_with_null_provenance(self):
        cert = _make_cert(model_provenance=None)
        d = cert.to_dict()
        assert d["model_provenance"] is None
        restored = AgentCertificate.from_dict(d)
        assert restored.model_provenance is None

    def test_from_dict_legacy_no_provenance_key(self):
        cert = _make_cert(model_provenance=None)
        d = cert.to_dict()
        del d["model_provenance"]
        restored = AgentCertificate.from_dict(d)
        assert restored.model_provenance is None

    def test_to_signing_bytes_includes_provenance_hash(self):
        mp = _make_provenance()
        mp.provenance_hash = mp.compute_hash()
        cert = _make_cert(model_provenance=mp)
        signing_bytes = cert.to_signing_bytes()
        payload = json.loads(signing_bytes.decode("utf-8"))
        assert "provenance_hash" in payload
        assert payload["provenance_hash"] == mp.provenance_hash

    def test_to_signing_bytes_excludes_provenance_hash_when_none(self):
        cert = _make_cert(model_provenance=None)
        signing_bytes = cert.to_signing_bytes()
        payload = json.loads(signing_bytes.decode("utf-8"))
        assert "provenance_hash" not in payload

    def test_signature_verification_with_provenance(self):
        mp = _make_provenance()
        mp.provenance_hash = mp.compute_hash()
        ca = _make_ca()
        cert, _sk = ca.issue(
            "test-agent", "general-purpose", "acme", "global",
            model_provenance=mp,
        )
        result = ca.verify_certificate(cert)
        assert result.valid

    def test_changing_provenance_hash_breaks_signature(self):
        mp = _make_provenance()
        mp.provenance_hash = mp.compute_hash()
        ca = _make_ca()
        cert, _sk = ca.issue(
            "test-agent", "general-purpose", "acme", "global",
            model_provenance=mp,
        )
        # Tamper with provenance hash
        cert.model_provenance.provenance_hash = "tampered_hash"
        result = ca.verify_certificate(cert)
        assert not result.valid
        assert "invalid issuer signature" in result.issues


# ── TestCertificateAuthorityWithProvenance ────────────────────────────


class TestCertificateAuthorityWithProvenance:
    def test_issue_with_provenance_auto_computes_hash(self):
        ca = _make_ca()
        mp = _make_provenance()
        assert mp.provenance_hash == ""
        cert, _sk = ca.issue(
            "agent-1", "general-purpose", "acme", "global",
            model_provenance=mp,
        )
        assert cert.model_provenance is not None
        assert cert.model_provenance.provenance_hash != ""
        assert cert.model_provenance.provenance_hash == mp.compute_hash()

    def test_issue_with_provenance_preserves_precomputed_hash(self):
        ca = _make_ca()
        mp = _make_provenance()
        mp.provenance_hash = mp.compute_hash()
        original_hash = mp.provenance_hash
        cert, _sk = ca.issue(
            "agent-1", "general-purpose", "acme", "global",
            model_provenance=mp,
        )
        assert cert.model_provenance.provenance_hash == original_hash

    def test_issue_without_provenance_backward_compat(self):
        ca = _make_ca()
        cert, _sk = ca.issue(
            "agent-1", "general-purpose", "acme", "global",
        )
        assert cert.model_provenance is None
        result = ca.verify_certificate(cert)
        assert result.valid

    def test_issued_cert_has_populated_provenance_hash(self):
        ca = _make_ca()
        mp = _make_provenance(
            safety_evaluation_id="mlc-2025-001",
            known_limitations=["No real-time data"],
        )
        cert, _sk = ca.issue(
            "agent-1", "general-purpose", "acme", "global",
            model_provenance=mp,
        )
        assert cert.model_provenance.provenance_hash
        assert len(cert.model_provenance.provenance_hash) == 64

    def test_cert_signature_verifiable_after_issue_with_provenance(self):
        ca = _make_ca()
        mp = _make_provenance()
        cert, _sk = ca.issue(
            "agent-1", "general-purpose", "acme", "global",
            model_provenance=mp,
        )
        result = ca.verify_certificate(cert)
        assert result.valid
        assert result.issues == []


# ── TestGovernanceSealWithProvenance ──────────────────────────────────


def _make_verdict():
    """Create a simple ALLOW verdict for testing."""
    return GovernanceVerdict(
        action_id="act-1",
        verdict=Verdict.ALLOW,
        ucs=0.8,
        tier=1,
        dimension_scores=[],
        vetoed_by=[],
    )


def _make_context(agent_id="agent-1"):
    """Create a simple agent context for testing."""
    return AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id, overall_trust=0.5),
    )


class TestGovernanceSealWithProvenance:
    def test_seal_action_with_provenance_cert(self):
        sk, _vk = SigningKey.generate()
        ca = CertificateAuthority(issuer_id="test", signing_key=sk)
        mp = _make_provenance()
        cert, _agent_sk = ca.issue(
            "agent-1", "general-purpose", "acme", "global",
            model_provenance=mp,
        )
        verdict = _make_verdict()
        context = _make_context()
        seal = seal_action(verdict, context, sk, certificate=cert)
        assert seal is not None
        assert seal.model_provenance_hash == cert.model_provenance.provenance_hash
        assert seal.model_provenance_hash != ""

    def test_seal_action_without_provenance_cert(self):
        sk, _vk = SigningKey.generate()
        ca = CertificateAuthority(issuer_id="test", signing_key=sk)
        cert, _agent_sk = ca.issue(
            "agent-1", "general-purpose", "acme", "global",
        )
        verdict = _make_verdict()
        context = _make_context()
        seal = seal_action(verdict, context, sk, certificate=cert)
        assert seal is not None
        assert seal.model_provenance_hash == ""

    def test_seal_to_dict_includes_model_provenance_hash(self):
        seal = GovernanceSeal(
            seal_id="nms-test",
            action_id="act-1",
            agent_id="agent-1",
            verdict="ALLOW",
            ucs=0.8,
            tier=1,
            dimension_summary={},
            vetoed_by=[],
            agent_owner="alice",
            organization="acme",
            preset="default",
            risk_tier="moderate",
            org_policy_hash="",
            trust_level=0.5,
            reversibility="reversible",
            issued_at=1000.0,
            expires_at=1030.0,
            ttl_seconds=30,
            signature=b"\x00" * 32,
            issuer_fingerprint="test-fp",
            model_provenance_hash="abc123hash",
        )
        d = seal.to_dict()
        assert d["model_provenance_hash"] == "abc123hash"

    def test_seal_from_dict_restores_field(self):
        seal = GovernanceSeal(
            seal_id="nms-test",
            action_id="act-1",
            agent_id="agent-1",
            verdict="ALLOW",
            ucs=0.8,
            tier=1,
            dimension_summary={},
            vetoed_by=[],
            agent_owner="alice",
            organization="acme",
            preset="default",
            risk_tier="moderate",
            org_policy_hash="",
            trust_level=0.5,
            reversibility="reversible",
            issued_at=1000.0,
            expires_at=1030.0,
            ttl_seconds=30,
            signature=b"\x00" * 32,
            issuer_fingerprint="test-fp",
            model_provenance_hash="xyz789",
        )
        d = seal.to_dict()
        restored = GovernanceSeal.from_dict(d)
        assert restored.model_provenance_hash == "xyz789"

    def test_legacy_seal_dict_without_field(self):
        d = {
            "seal_id": "nms-test",
            "action_id": "act-1",
            "agent_id": "agent-1",
            "verdict": "ALLOW",
            "ucs": 0.8,
            "tier": 1,
            "dimension_summary": {},
            "vetoed_by": [],
            "agent_owner": "alice",
            "organization": "acme",
            "preset": "default",
            "risk_tier": "moderate",
            "org_policy_hash": "",
            "trust_level": 0.5,
            "reversibility": "reversible",
            "issued_at": 1000.0,
            "expires_at": 1030.0,
            "ttl_seconds": 30,
            "signature": "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=",
            "issuer_fingerprint": "test-fp",
        }
        seal = GovernanceSeal.from_dict(d)
        assert seal.model_provenance_hash == ""


# ── TestRuntimeBirthWithProvenance ────────────────────────────────────


class TestRuntimeBirthWithProvenance:
    def test_runtime_birth_with_provenance(self):
        from nomotic.runtime import GovernanceRuntime

        rt = GovernanceRuntime()
        mp = _make_provenance()
        cert = rt.birth(
            "agent-prov", "general-purpose", "acme", "global",
            model_provenance=mp,
        )
        assert cert.model_provenance is not None
        assert cert.model_provenance.model_provider == "anthropic"
        assert cert.model_provenance.provenance_hash != ""

    def test_runtime_birth_without_provenance(self):
        from nomotic.runtime import GovernanceRuntime

        rt = GovernanceRuntime()
        cert = rt.birth(
            "agent-no-prov", "general-purpose", "acme", "global",
        )
        assert cert.model_provenance is None


# ── TestModelProvenanceExport ─────────────────────────────────────────


class TestModelProvenanceExport:
    def test_import_from_nomotic(self):
        from nomotic import ModelProvenance as MP
        assert MP is ModelProvenance

    def test_import_from_certificate(self):
        from nomotic.certificate import ModelProvenance as MP
        assert MP is ModelProvenance
