"""Tests for Cross-Workflow Dependency Checking (Item 13, v0.6.0)."""

import hashlib
import threading
import time

import pytest

from nomotic.authority import CertificateAuthority
from nomotic.keys import SigningKey
from nomotic.store import MemoryCertificateStore
from nomotic.runtime import GovernanceRuntime
from nomotic.seal import (
    ChainedSeal,
    DependencyCheckResult,
    WorkflowDependency,
    WorkflowDependencyChecker,
    WorkflowDependencyError,
    WorkflowSealChain,
    verify_workflow_chain,
)
from nomotic.types import (
    Action,
    AgentContext,
    DimensionScore,
    GovernanceVerdict,
    TrustProfile,
    Verdict,
)


# ── Helpers ────────────────────────────────────────────────────────────


def _make_runtime() -> GovernanceRuntime:
    """Create a runtime with a CA and scope configured for testing."""
    sk, _ = SigningKey.generate()
    ca = CertificateAuthority("test", sk, MemoryCertificateStore())
    runtime = GovernanceRuntime()
    runtime.set_certificate_authority(ca)
    scope = runtime.registry.get("scope_compliance")
    scope.configure_agent_scope("workflow-bot", {"*"})
    return runtime


def _make_allow_verdict(
    action_id: str = "test-action",
    agent_id: str = "workflow-bot",
) -> GovernanceVerdict:
    return GovernanceVerdict(
        action_id=action_id,
        verdict=Verdict.ALLOW,
        ucs=0.85,
        tier=2,
        dimension_scores=[
            DimensionScore(dimension_name="scope_compliance", score=0.9, weight=1.0),
        ],
        vetoed_by=[],
        reasoning="All dimensions passed",
    )


def _make_context(agent_id: str = "workflow-bot") -> AgentContext:
    return AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id),
    )


def _build_complete_chain(
    workflow_id: str = "upstream-wf",
    chain_id: str = "nmwc-test-upstream-001",
    agent_id: str = "test-agent",
    completed_at: float | None = None,
) -> WorkflowSealChain:
    """Build a COMPLETE chain with one seal for testing."""
    chain = WorkflowSealChain(
        chain_id=chain_id,
        workflow_id=workflow_id,
        agent_id=agent_id,
        status="COMPLETE",
        completed_at=completed_at or time.time(),
    )
    # Add a single seal so the chain is non-empty
    genesis_hash = hashlib.sha256(chain.chain_id.encode("utf-8")).hexdigest()
    seal_id = "nms-seal-0"
    position_hash = hashlib.sha256(
        f"{genesis_hash}:{seal_id}".encode("utf-8")
    ).hexdigest()
    chain.seals.append(ChainedSeal(
        seal_id=seal_id,
        step_number=1,
        action_id="step-1",
        previous_seal_hash=genesis_hash,
        position_hash=position_hash,
    ))
    chain.chain_hash = chain._compute_chain_hash()
    return chain


# ── TestWorkflowDependency ─────────────────────────────────────────────


class TestWorkflowDependency:
    def test_to_dict_roundtrip(self) -> None:
        dep = WorkflowDependency(
            dependent_workflow_id="wf-b",
            required_workflow_id="wf-a",
            required_status="COMPLETE",
            max_age_seconds=3600.0,
            description="wf-b needs wf-a to finish first",
        )
        d = dep.to_dict()
        restored = WorkflowDependency.from_dict(d)
        assert restored.dependent_workflow_id == dep.dependent_workflow_id
        assert restored.required_workflow_id == dep.required_workflow_id
        assert restored.required_status == dep.required_status
        assert restored.max_age_seconds == dep.max_age_seconds
        assert restored.description == dep.description

    def test_default_required_status_is_complete(self) -> None:
        dep = WorkflowDependency(
            dependent_workflow_id="wf-b",
            required_workflow_id="wf-a",
        )
        assert dep.required_status == "COMPLETE"

    def test_default_max_age_is_none(self) -> None:
        dep = WorkflowDependency(
            dependent_workflow_id="wf-b",
            required_workflow_id="wf-a",
        )
        assert dep.max_age_seconds is None

    def test_to_dict_omits_max_age_when_none(self) -> None:
        dep = WorkflowDependency(
            dependent_workflow_id="wf-b",
            required_workflow_id="wf-a",
        )
        d = dep.to_dict()
        assert "max_age_seconds" not in d

    def test_from_dict_with_defaults(self) -> None:
        d = {
            "dependent_workflow_id": "wf-b",
            "required_workflow_id": "wf-a",
        }
        dep = WorkflowDependency.from_dict(d)
        assert dep.required_status == "COMPLETE"
        assert dep.max_age_seconds is None
        assert dep.description == ""


# ── TestWorkflowDependencyChecker ──────────────────────────────────────


class TestWorkflowDependencyChecker:
    def test_empty_checker_always_satisfied(self) -> None:
        checker = WorkflowDependencyChecker()
        results = checker.check("any-workflow", {})
        assert results == []
        assert checker.all_satisfied("any-workflow", {})

    def test_add_dependency(self) -> None:
        checker = WorkflowDependencyChecker()
        dep = WorkflowDependency(
            dependent_workflow_id="wf-b",
            required_workflow_id="wf-a",
        )
        checker.add_dependency(dep)
        deps = checker.list_dependencies()
        assert len(deps) == 1
        assert deps[0].dependent_workflow_id == "wf-b"
        assert deps[0].required_workflow_id == "wf-a"

    def test_remove_dependency_returns_true(self) -> None:
        checker = WorkflowDependencyChecker()
        dep = WorkflowDependency(
            dependent_workflow_id="wf-b",
            required_workflow_id="wf-a",
        )
        checker.add_dependency(dep)
        assert checker.remove_dependency("wf-b", "wf-a") is True
        assert checker.list_dependencies() == []

    def test_remove_nonexistent_returns_false(self) -> None:
        checker = WorkflowDependencyChecker()
        assert checker.remove_dependency("wf-x", "wf-y") is False

    def test_check_satisfied_when_complete_chain_exists(self) -> None:
        checker = WorkflowDependencyChecker()
        dep = WorkflowDependency(
            dependent_workflow_id="wf-b",
            required_workflow_id="wf-a",
        )
        checker.add_dependency(dep)

        chain = _build_complete_chain(workflow_id="wf-a")
        chains = {chain.chain_id: chain}

        results = checker.check("wf-b", chains)
        assert len(results) == 1
        assert results[0].satisfied is True
        assert results[0].prerequisite_chain_id == chain.chain_id
        assert results[0].prerequisite_chain_status == "COMPLETE"
        assert results[0].prerequisite_completed_at is not None

    def test_check_unsatisfied_when_no_chain(self) -> None:
        checker = WorkflowDependencyChecker()
        dep = WorkflowDependency(
            dependent_workflow_id="wf-b",
            required_workflow_id="wf-a",
        )
        checker.add_dependency(dep)

        results = checker.check("wf-b", {})
        assert len(results) == 1
        assert results[0].satisfied is False
        assert "No COMPLETE chain found" in (results[0].failure_reason or "")
        assert "wf-a" in (results[0].failure_reason or "")

    def test_check_unsatisfied_when_chain_active_not_complete(self) -> None:
        checker = WorkflowDependencyChecker()
        dep = WorkflowDependency(
            dependent_workflow_id="wf-b",
            required_workflow_id="wf-a",
        )
        checker.add_dependency(dep)

        # Create an ACTIVE (not COMPLETE) chain
        chain = WorkflowSealChain(
            chain_id="nmwc-active-chain",
            workflow_id="wf-a",
            agent_id="agent-1",
            status="ACTIVE",
        )
        chains = {chain.chain_id: chain}

        results = checker.check("wf-b", chains)
        assert len(results) == 1
        assert results[0].satisfied is False

    def test_check_max_age_satisfied_when_young_enough(self) -> None:
        checker = WorkflowDependencyChecker()
        dep = WorkflowDependency(
            dependent_workflow_id="wf-b",
            required_workflow_id="wf-a",
            max_age_seconds=3600.0,
        )
        checker.add_dependency(dep)

        # Chain completed just now
        chain = _build_complete_chain(workflow_id="wf-a", completed_at=time.time())
        chains = {chain.chain_id: chain}

        results = checker.check("wf-b", chains)
        assert len(results) == 1
        assert results[0].satisfied is True

    def test_check_max_age_unsatisfied_when_too_old(self) -> None:
        checker = WorkflowDependencyChecker()
        dep = WorkflowDependency(
            dependent_workflow_id="wf-b",
            required_workflow_id="wf-a",
            max_age_seconds=60.0,
        )
        checker.add_dependency(dep)

        # Chain completed 120 seconds ago
        chain = _build_complete_chain(
            workflow_id="wf-a",
            completed_at=time.time() - 120.0,
        )
        chains = {chain.chain_id: chain}

        results = checker.check("wf-b", chains)
        assert len(results) == 1
        assert results[0].satisfied is False
        assert "too old" in (results[0].failure_reason or "")

    def test_all_satisfied_all_pass(self) -> None:
        checker = WorkflowDependencyChecker()
        dep1 = WorkflowDependency(
            dependent_workflow_id="wf-c",
            required_workflow_id="wf-a",
        )
        dep2 = WorkflowDependency(
            dependent_workflow_id="wf-c",
            required_workflow_id="wf-b",
        )
        checker.add_dependency(dep1)
        checker.add_dependency(dep2)

        chain_a = _build_complete_chain(workflow_id="wf-a", chain_id="nmwc-chain-a")
        chain_b = _build_complete_chain(workflow_id="wf-b", chain_id="nmwc-chain-b")
        chains = {chain_a.chain_id: chain_a, chain_b.chain_id: chain_b}

        assert checker.all_satisfied("wf-c", chains) is True

    def test_all_satisfied_one_fails(self) -> None:
        checker = WorkflowDependencyChecker()
        dep1 = WorkflowDependency(
            dependent_workflow_id="wf-c",
            required_workflow_id="wf-a",
        )
        dep2 = WorkflowDependency(
            dependent_workflow_id="wf-c",
            required_workflow_id="wf-b",
        )
        checker.add_dependency(dep1)
        checker.add_dependency(dep2)

        # Only wf-a has a complete chain, wf-b does not
        chain_a = _build_complete_chain(workflow_id="wf-a", chain_id="nmwc-chain-a")
        chains = {chain_a.chain_id: chain_a}

        assert checker.all_satisfied("wf-c", chains) is False

    def test_list_dependencies(self) -> None:
        checker = WorkflowDependencyChecker()
        dep1 = WorkflowDependency(
            dependent_workflow_id="wf-b",
            required_workflow_id="wf-a",
        )
        dep2 = WorkflowDependency(
            dependent_workflow_id="wf-c",
            required_workflow_id="wf-b",
        )
        checker.add_dependency(dep1)
        checker.add_dependency(dep2)

        deps = checker.list_dependencies()
        assert len(deps) == 2
        # Should be a copy, not the internal list
        deps.append(dep1)
        assert len(checker.list_dependencies()) == 2

    def test_thread_safe_concurrent_add(self) -> None:
        checker = WorkflowDependencyChecker()
        n_threads = 10
        n_per_thread = 50
        errors: list[Exception] = []

        def add_deps(thread_idx: int) -> None:
            try:
                for i in range(n_per_thread):
                    dep = WorkflowDependency(
                        dependent_workflow_id=f"wf-{thread_idx}-{i}",
                        required_workflow_id=f"wf-upstream-{thread_idx}-{i}",
                    )
                    checker.add_dependency(dep)
            except Exception as exc:
                errors.append(exc)

        threads = [
            threading.Thread(target=add_deps, args=(t,))
            for t in range(n_threads)
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors
        assert len(checker.list_dependencies()) == n_threads * n_per_thread

    def test_check_no_applicable_rules_returns_empty(self) -> None:
        """If no deps match the workflow_id, check returns empty list."""
        checker = WorkflowDependencyChecker()
        dep = WorkflowDependency(
            dependent_workflow_id="wf-b",
            required_workflow_id="wf-a",
        )
        checker.add_dependency(dep)
        # Check for a different workflow
        results = checker.check("wf-x", {})
        assert results == []

    def test_check_picks_most_recent_chain(self) -> None:
        """When multiple COMPLETE chains exist, uses the newest."""
        checker = WorkflowDependencyChecker()
        dep = WorkflowDependency(
            dependent_workflow_id="wf-b",
            required_workflow_id="wf-a",
            max_age_seconds=120.0,
        )
        checker.add_dependency(dep)

        # Old chain (too old)
        old_chain = _build_complete_chain(
            workflow_id="wf-a",
            chain_id="nmwc-old",
            completed_at=time.time() - 300.0,
        )
        # New chain (recent enough)
        new_chain = _build_complete_chain(
            workflow_id="wf-a",
            chain_id="nmwc-new",
            completed_at=time.time() - 10.0,
        )
        chains = {old_chain.chain_id: old_chain, new_chain.chain_id: new_chain}

        results = checker.check("wf-b", chains)
        assert len(results) == 1
        assert results[0].satisfied is True
        assert results[0].prerequisite_chain_id == "nmwc-new"


# ── TestWorkflowDependencyError ────────────────────────────────────────


class TestWorkflowDependencyError:
    def test_error_contains_workflow_id(self) -> None:
        failure = DependencyCheckResult(
            satisfied=False,
            dependent_workflow_id="wf-b",
            required_workflow_id="wf-a",
            failure_reason="No COMPLETE chain found",
        )
        err = WorkflowDependencyError("wf-b", [failure])
        assert err.workflow_id == "wf-b"

    def test_error_contains_failure_list(self) -> None:
        failure = DependencyCheckResult(
            satisfied=False,
            dependent_workflow_id="wf-b",
            required_workflow_id="wf-a",
            failure_reason="No COMPLETE chain found",
        )
        err = WorkflowDependencyError("wf-b", [failure])
        assert len(err.failures) == 1
        assert err.failures[0] is failure

    def test_error_message_includes_reasons(self) -> None:
        f1 = DependencyCheckResult(
            satisfied=False,
            dependent_workflow_id="wf-c",
            required_workflow_id="wf-a",
            failure_reason="No COMPLETE chain found for wf-a",
        )
        f2 = DependencyCheckResult(
            satisfied=False,
            dependent_workflow_id="wf-c",
            required_workflow_id="wf-b",
            failure_reason="Chain too old",
        )
        err = WorkflowDependencyError("wf-c", [f1, f2])
        msg = str(err)
        assert "wf-c" in msg
        assert "2 unsatisfied" in msg
        assert "No COMPLETE chain found for wf-a" in msg
        assert "Chain too old" in msg

    def test_error_is_exception(self) -> None:
        failure = DependencyCheckResult(
            satisfied=False,
            dependent_workflow_id="wf-b",
            required_workflow_id="wf-a",
            failure_reason="missing",
        )
        err = WorkflowDependencyError("wf-b", [failure])
        assert isinstance(err, Exception)
        with pytest.raises(WorkflowDependencyError):
            raise err


# ── TestDependencyCheckResult ──────────────────────────────────────────


class TestDependencyCheckResult:
    def test_to_dict_satisfied(self) -> None:
        result = DependencyCheckResult(
            satisfied=True,
            dependent_workflow_id="wf-b",
            required_workflow_id="wf-a",
            prerequisite_chain_id="nmwc-123",
            prerequisite_chain_status="COMPLETE",
            prerequisite_completed_at=1000.0,
        )
        d = result.to_dict()
        assert d["satisfied"] is True
        assert d["prerequisite_chain_id"] == "nmwc-123"
        assert "failure_reason" not in d

    def test_to_dict_unsatisfied(self) -> None:
        result = DependencyCheckResult(
            satisfied=False,
            dependent_workflow_id="wf-b",
            required_workflow_id="wf-a",
            failure_reason="missing chain",
        )
        d = result.to_dict()
        assert d["satisfied"] is False
        assert d["failure_reason"] == "missing chain"
        assert "prerequisite_chain_id" not in d


# ── TestRuntimeIntegration ─────────────────────────────────────────────


class TestRuntimeIntegration:
    def test_begin_workflow_sealing_raises_on_unsatisfied_dep(self) -> None:
        runtime = _make_runtime()

        dep = WorkflowDependency(
            dependent_workflow_id="model-training",
            required_workflow_id="data-ingestion",
        )
        runtime.add_workflow_dependency(dep)

        with pytest.raises(WorkflowDependencyError) as exc_info:
            runtime.begin_workflow_sealing("model-training", agent_id="bot-1")

        assert exc_info.value.workflow_id == "model-training"
        assert len(exc_info.value.failures) == 1
        assert "data-ingestion" in str(exc_info.value)

    def test_begin_workflow_sealing_succeeds_when_dep_satisfied(self) -> None:
        runtime = _make_runtime()

        # Register dependency: training depends on ingestion
        dep = WorkflowDependency(
            dependent_workflow_id="model-training",
            required_workflow_id="data-ingestion",
        )
        runtime.add_workflow_dependency(dep)

        # First, complete the upstream workflow
        ingestion_chain = runtime.begin_workflow_sealing(
            "data-ingestion", agent_id="bot-1"
        )
        # Seal a step in it
        verdict = _make_allow_verdict(action_id="ingest-step-1")
        ctx = _make_context()
        seal = runtime.seal(verdict, ctx, workflow_chain=ingestion_chain)
        assert seal is not None
        runtime.complete_workflow_sealing(ingestion_chain.chain_id)

        # Now the downstream workflow should succeed
        training_chain = runtime.begin_workflow_sealing(
            "model-training", agent_id="bot-1"
        )
        assert training_chain is not None
        assert training_chain.workflow_id == "model-training"
        assert training_chain.status == "ACTIVE"

    def test_add_workflow_dependency_auto_creates_checker(self) -> None:
        runtime = _make_runtime()
        assert runtime._workflow_dependency_checker is None

        dep = WorkflowDependency(
            dependent_workflow_id="wf-b",
            required_workflow_id="wf-a",
        )
        runtime.add_workflow_dependency(dep)
        assert runtime._workflow_dependency_checker is not None

    def test_set_workflow_dependency_checker(self) -> None:
        runtime = _make_runtime()
        checker = WorkflowDependencyChecker()
        runtime.set_workflow_dependency_checker(checker)
        assert runtime._workflow_dependency_checker is checker

    def test_no_checker_means_no_dependency_check(self) -> None:
        """Without a checker, begin_workflow_sealing always succeeds."""
        runtime = _make_runtime()
        chain = runtime.begin_workflow_sealing("any-workflow", agent_id="bot")
        assert chain is not None
        assert chain.workflow_id == "any-workflow"

    def test_workflow_with_no_applicable_deps_succeeds(self) -> None:
        """Checker with deps for other workflows doesn't block this one."""
        runtime = _make_runtime()
        dep = WorkflowDependency(
            dependent_workflow_id="wf-b",
            required_workflow_id="wf-a",
        )
        runtime.add_workflow_dependency(dep)

        # Starting wf-c should work (no deps registered for it)
        chain = runtime.begin_workflow_sealing("wf-c", agent_id="bot")
        assert chain is not None


# ── TestCLI ────────────────────────────────────────────────────────────


class TestCLI:
    def test_cli_dependencies_list(self, capsys: pytest.CaptureFixture[str]) -> None:
        from nomotic.cli import main

        main(["workflow", "dependencies", "list"])
        captured = capsys.readouterr()
        assert "No dependency rules registered" in captured.out

    def test_cli_dependencies_check_satisfied(self, capsys: pytest.CaptureFixture[str]) -> None:
        from nomotic.cli import main

        main(["workflow", "dependencies", "check", "my-workflow"])
        captured = capsys.readouterr()
        # With no config, should report no rules registered
        assert "No dependency rules registered" in captured.out

    def test_cli_dependencies_check_unsatisfied(self, capsys: pytest.CaptureFixture[str]) -> None:
        from nomotic.cli import main

        # Without config deps, CLI reports no rules
        main(["workflow", "dependencies", "check", "test-wf"])
        captured = capsys.readouterr()
        assert "No dependency rules registered" in captured.out

    def test_cli_workflow_no_subcommand(self, capsys: pytest.CaptureFixture[str]) -> None:
        from nomotic.cli import main

        with pytest.raises(SystemExit):
            main(["workflow"])
