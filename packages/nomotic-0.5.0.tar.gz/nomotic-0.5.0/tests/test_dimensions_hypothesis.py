"""Property-based tests for governance dimensions using Hypothesis.

These tests verify invariants that must hold across ALL possible inputs,
not just hand-crafted test cases. Catches edge cases in dimension scoring
that unit tests miss.
"""

from __future__ import annotations

import pytest

hypothesis = pytest.importorskip("hypothesis")
from hypothesis import given, settings, assume
from hypothesis import strategies as st

from nomotic.runtime import GovernanceRuntime, RuntimeConfig
from nomotic.types import Action, AgentContext, TrustProfile


# --- Strategies ---

action_types = st.sampled_from([
    "read", "write", "delete", "execute", "query", "update", "create",
    "send_email", "transfer_funds", "modify_config", "access_logs",
    "deploy", "revoke", "escalate", "approve", "export_data",
])

targets = st.sampled_from([
    "customers", "orders", "employee_salaries", "credentials",
    "production_db", "staging_db", "audit_logs", "config_files",
    "user_data", "financial_records", "public_docs",
])

trust_scores = st.floats(min_value=0.0, max_value=1.0, allow_nan=False)


# --- Invariant Tests ---


class TestEvaluationInvariants:
    """Properties that must hold for ANY action evaluated by ANY runtime."""

    @given(action_type=action_types, target=targets)
    @settings(max_examples=200, deadline=2000)
    def test_ucs_always_bounded_0_to_1(self, action_type, target):
        """UCS score must always be in [0, 1] regardless of input."""
        runtime = GovernanceRuntime()
        action = Action(agent_id="hyp-agent", action_type=action_type, target=target)
        context = AgentContext(
            agent_id="hyp-agent",
            trust_profile=TrustProfile(agent_id="hyp-agent", overall_trust=0.5),
        )

        verdict = runtime.evaluate(action, context)
        assert 0.0 <= verdict.ucs <= 1.0, (
            f"UCS {verdict.ucs} out of bounds for {action_type}/{target}"
        )

    @given(action_type=action_types, target=targets)
    @settings(max_examples=200, deadline=2000)
    def test_verdict_is_valid_enum(self, action_type, target):
        """Verdict must be a valid Verdict enum value."""
        runtime = GovernanceRuntime()
        action = Action(agent_id="hyp-agent", action_type=action_type, target=target)
        context = AgentContext(
            agent_id="hyp-agent",
            trust_profile=TrustProfile(agent_id="hyp-agent", overall_trust=0.5),
        )

        verdict = runtime.evaluate(action, context)
        assert verdict.verdict.name in {"ALLOW", "DENY", "MODIFY", "ESCALATE", "SUSPEND"}, (
            f"Invalid verdict '{verdict.verdict}'"
        )

    @given(action_type=action_types, target=targets)
    @settings(max_examples=200, deadline=2000)
    def test_dimension_scores_all_bounded(self, action_type, target):
        """Every individual dimension score must be in [0, 1]."""
        runtime = GovernanceRuntime()
        action = Action(agent_id="hyp-agent", action_type=action_type, target=target)
        context = AgentContext(
            agent_id="hyp-agent",
            trust_profile=TrustProfile(agent_id="hyp-agent", overall_trust=0.5),
        )

        verdict = runtime.evaluate(action, context)
        for ds in verdict.dimension_scores:
            assert 0.0 <= ds.score <= 1.0, (
                f"Dimension '{ds.dimension_name}' score {ds.score} out of bounds"
            )

    @given(action_type=action_types, target=targets)
    @settings(max_examples=100, deadline=2000)
    def test_deny_verdict_has_reason(self, action_type, target):
        """If verdict is DENY, reasoning must be non-empty."""
        runtime = GovernanceRuntime()
        runtime.configure_scope(
            "hyp-agent",
            {"read"},
            actor="test",
            reason="Tight scope for testing",
        )
        action = Action(agent_id="hyp-agent", action_type=action_type, target=target)
        context = AgentContext(
            agent_id="hyp-agent",
            trust_profile=TrustProfile(agent_id="hyp-agent", overall_trust=0.5),
        )

        verdict = runtime.evaluate(action, context)
        if verdict.verdict.name == "DENY":
            assert verdict.reasoning, "DENY verdict must have reasoning"

    @given(action_type=action_types, target=targets)
    @settings(max_examples=100, deadline=2000)
    def test_veto_implies_deny(self, action_type, target):
        """If any dimension vetoed, verdict must be DENY or ESCALATE."""
        runtime = GovernanceRuntime()
        action = Action(agent_id="hyp-agent", action_type=action_type, target=target)
        context = AgentContext(
            agent_id="hyp-agent",
            trust_profile=TrustProfile(agent_id="hyp-agent", overall_trust=0.5),
        )

        verdict = runtime.evaluate(action, context)
        if verdict.vetoed_by:
            assert verdict.verdict.name in {"DENY", "ESCALATE"}, (
                f"Vetoed by {verdict.vetoed_by} but verdict is {verdict.verdict.name}"
            )

    @given(action_type=action_types, target=targets)
    @settings(max_examples=100, deadline=2000)
    def test_tier_is_valid(self, action_type, target):
        """Evaluation tier must be 1, 2, or 3."""
        runtime = GovernanceRuntime()
        action = Action(agent_id="hyp-agent", action_type=action_type, target=target)
        context = AgentContext(
            agent_id="hyp-agent",
            trust_profile=TrustProfile(agent_id="hyp-agent", overall_trust=0.5),
        )

        verdict = runtime.evaluate(action, context)
        assert verdict.tier in {1, 2, 3}, f"Invalid tier {verdict.tier}"


class TestTrustInvariants:
    """Properties that must hold for trust score operations."""

    @given(
        adjustments=st.lists(
            st.floats(min_value=-0.1, max_value=0.1, allow_nan=False),
            min_size=1,
            max_size=100,
        )
    )
    @settings(max_examples=100)
    def test_trust_always_bounded(self, adjustments):
        """Trust score must stay in [0, 1] after any sequence of adjustments."""
        trust = TrustProfile(agent_id="hyp-agent", overall_trust=0.5)
        for adj in adjustments:
            trust.overall_trust = max(0.0, min(1.0, trust.overall_trust + adj))
        assert 0.0 <= trust.overall_trust <= 1.0

    @given(
        initial=trust_scores,
        adjustments=st.lists(
            st.floats(min_value=0.002, max_value=0.1, allow_nan=False),
            min_size=1,
            max_size=50,
        ),
    )
    @settings(max_examples=100)
    def test_trust_monotonic_on_uniform_input(self, initial, adjustments):
        """If all adjustments are positive, trust should never decrease
        (unless already at ceiling)."""
        trust = TrustProfile(agent_id="hyp-agent", overall_trust=initial)
        all_positive = True

        prev = trust.overall_trust
        for adj in adjustments:
            trust.overall_trust = max(0.0, min(1.0, trust.overall_trust + adj))
            curr = trust.overall_trust
            if all_positive:
                assert curr >= prev or abs(curr - 1.0) < 1e-9, (
                    f"Trust decreased ({prev} -> {curr}) on positive adjustment"
                )
            prev = curr


class TestFuzzedActions:
    """Fuzz action strings to ensure no crashes on unexpected input."""

    @given(
        action_type=st.text(min_size=0, max_size=200),
        target=st.text(min_size=0, max_size=200),
    )
    @settings(max_examples=500, deadline=3000)
    def test_no_crash_on_arbitrary_strings(self, action_type, target):
        """Evaluation must never crash, even on garbage input."""
        runtime = GovernanceRuntime()
        action = Action(agent_id="fuzz-agent", action_type=action_type, target=target)
        context = AgentContext(
            agent_id="fuzz-agent",
            trust_profile=TrustProfile(agent_id="fuzz-agent", overall_trust=0.5),
        )

        # Must not raise
        verdict = runtime.evaluate(action, context)
        assert verdict is not None
        assert isinstance(verdict.ucs, float)
