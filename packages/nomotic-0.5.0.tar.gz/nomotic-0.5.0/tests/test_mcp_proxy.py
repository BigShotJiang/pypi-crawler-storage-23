"""Tests for MCP Governance Proxy — adapter layer for MCP tool calls."""

import json
import io
import sys
import threading
import time
from unittest.mock import MagicMock, patch

import pytest

from nomotic.authority import CertificateAuthority
from nomotic.executor import ExecutionResult, GovernedToolExecutor
from nomotic.keys import SigningKey
from nomotic.mcp_proxy import (
    MCPGovernanceProxy,
    MCPHTTPGovernanceProxy,
    _attach_governance_token,
    _build_denial_response,
    _extract_target,
)
from nomotic.sandbox import AgentConfig, save_agent_config
from nomotic.store import FileCertificateStore


def _setup_agent(
    tmp_path,
    agent_id: str = "TestBot",
    actions: list[str] | None = None,
    boundaries: list[str] | None = None,
) -> str:
    """Create a certificate and config for an agent in tmp_path."""
    sk, _vk = SigningKey.generate()
    store = FileCertificateStore(tmp_path)
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)

    cert, _agent_sk = ca.issue(
        agent_id=agent_id,
        archetype="general",
        organization="test-org",
        zone_path="global",
        owner="test-owner",
    )

    if actions is None:
        actions = ["read", "write", "query"]
    config = AgentConfig(
        agent_id=agent_id,
        actions=actions,
        boundaries=boundaries or [],
    )
    save_agent_config(tmp_path, config)
    return cert.certificate_id


# ── _extract_target tests ─────────────────────────────────────────────────


class TestExtractTarget:
    def test_target_key(self):
        assert _extract_target("run", {"target": "server-1"}) == "server-1"

    def test_path_key(self):
        assert _extract_target("read", {"path": "/data/file.csv"}) == "/data/file.csv"

    def test_file_key(self):
        assert _extract_target("open", {"file": "report.pdf"}) == "report.pdf"

    def test_table_key(self):
        assert _extract_target("query", {"table": "customers"}) == "customers"

    def test_url_key(self):
        assert _extract_target("fetch", {"url": "https://example.com"}) == "https://example.com"

    def test_resource_key(self):
        assert _extract_target("access", {"resource": "bucket-3"}) == "bucket-3"

    def test_database_key(self):
        assert _extract_target("connect", {"database": "prod_db"}) == "prod_db"

    def test_uri_key(self):
        assert _extract_target("open", {"uri": "s3://bucket/key"}) == "s3://bucket/key"

    def test_priority_order(self):
        """'target' takes priority over 'path'."""
        assert _extract_target("x", {"path": "/p", "target": "/t"}) == "/t"

    def test_fallback_first_string(self):
        assert _extract_target("search", {"query": "hello"}) == "hello"

    def test_fallback_tool_name_no_string_args(self):
        assert _extract_target("ping", {"count": 5}) == "ping"

    def test_empty_args(self):
        assert _extract_target("noop", {}) == "noop"


# ── _build_denial_response tests ──────────────────────────────────────────


class TestBuildDenialResponse:
    def test_structure(self):
        resp = _build_denial_response(42, "delete_file", "/etc/passwd", "scope violation")
        assert resp["jsonrpc"] == "2.0"
        assert resp["id"] == 42
        assert resp["result"]["isError"] is True
        content = resp["result"]["content"]
        assert len(content) == 1
        assert content[0]["type"] == "text"

    def test_includes_tool_name_and_target(self):
        resp = _build_denial_response(1, "drop_table", "users", "forbidden")
        text = resp["result"]["content"][0]["text"]
        assert "drop_table" in text
        assert "users" in text
        assert "forbidden" in text

    def test_none_request_id(self):
        resp = _build_denial_response(None, "x", "y", "z")
        assert resp["id"] is None

    def test_valid_json_roundtrip(self):
        resp = _build_denial_response(7, "a", "b", "reason")
        serialized = json.dumps(resp)
        deserialized = json.loads(serialized)
        assert deserialized == resp


# ── _attach_governance_token tests ────────────────────────────────────────


class TestAttachGovernanceToken:
    def _make_result(self, **overrides):
        defaults = {
            "allowed": True,
            "verdict": "ALLOW",
            "reason": "",
            "data": None,
            "ucs": 0.95,
            "tier": 2,
            "trust_before": 0.8,
            "trust_after": 0.82,
            "trust_delta": 0.02,
            "dimension_scores": {},
            "vetoed_by": [],
            "action_id": "abc123",
            "duration_ms": 1.5,
        }
        defaults.update(overrides)
        return ExecutionResult(**defaults)

    def test_adds_nomotic_key(self):
        msg = {"jsonrpc": "2.0", "method": "tools/call", "params": {"name": "x"}, "id": 1}
        result = self._make_result()
        forwarded = _attach_governance_token(msg, result)
        assert "_nomotic" in forwarded["params"]
        token = forwarded["params"]["_nomotic"]
        assert token["governance_token"] == "abc123"
        assert token["trust_score"] == 0.82
        assert token["verdict"] == "ALLOW"
        assert "timestamp" in token

    def test_does_not_mutate_original(self):
        msg = {"jsonrpc": "2.0", "method": "tools/call", "params": {"name": "x"}, "id": 1}
        result = self._make_result()
        _attach_governance_token(msg, result)
        assert "_nomotic" not in msg["params"]

    def test_preserves_existing_params(self):
        msg = {
            "jsonrpc": "2.0",
            "method": "tools/call",
            "params": {"name": "read", "arguments": {"path": "/tmp"}},
            "id": 1,
        }
        result = self._make_result()
        forwarded = _attach_governance_token(msg, result)
        assert forwarded["params"]["name"] == "read"
        assert forwarded["params"]["arguments"] == {"path": "/tmp"}


# ── MCPGovernanceProxy._is_tool_call tests ────────────────────────────────


class TestIsToolCall:
    def test_valid_tool_call(self):
        assert MCPGovernanceProxy._is_tool_call(
            {"method": "tools/call", "params": {"name": "read"}}
        )

    def test_tools_list_is_not_tool_call(self):
        assert not MCPGovernanceProxy._is_tool_call(
            {"method": "tools/list", "params": {}}
        )

    def test_initialize_is_not_tool_call(self):
        assert not MCPGovernanceProxy._is_tool_call(
            {"method": "initialize", "params": {}}
        )

    def test_no_params_is_not_tool_call(self):
        assert not MCPGovernanceProxy._is_tool_call(
            {"method": "tools/call"}
        )

    def test_empty_dict(self):
        assert not MCPGovernanceProxy._is_tool_call({})

    def test_notification_without_id(self):
        """Notifications can have method but no id — still treated as tool call if params present."""
        assert MCPGovernanceProxy._is_tool_call(
            {"method": "tools/call", "params": {"name": "x"}}
        )


# ── Integration tests with real governance ────────────────────────────────


class TestProxyGovernance:
    """Test that the proxy correctly delegates governance decisions."""

    def test_allowed_tool_call_forwards(self, tmp_path):
        """An allowed tool call should produce a forwarded message with governance token."""
        _setup_agent(tmp_path, "ProxyBot", actions=["read"])
        proxy = MCPGovernanceProxy(
            agent_id="ProxyBot",
            upstream_command="echo test",
            base_dir=tmp_path,
            test_mode=True,
        )

        # Capture what gets sent to upstream vs client
        upstream_messages = []
        client_messages = []
        proxy._send_to_upstream = lambda msg: upstream_messages.append(msg)
        proxy._send_to_client = lambda msg: client_messages.append(msg)

        message = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "read", "arguments": {"path": "/data/file.csv"}},
        }

        proxy._handle_tool_call(message)

        assert len(upstream_messages) == 1
        assert len(client_messages) == 0
        forwarded = json.loads(upstream_messages[0])
        assert "_nomotic" in forwarded["params"]
        assert forwarded["params"]["_nomotic"]["verdict"] == "ALLOW"

    def test_denied_tool_call_returns_denial(self, tmp_path):
        """A denied tool call should return a denial response to the client."""
        # Agent scoped to "read" only — "delete_all" is out of scope
        _setup_agent(tmp_path, "RestrictedBot", actions=["read"])
        proxy = MCPGovernanceProxy(
            agent_id="RestrictedBot",
            upstream_command="echo test",
            base_dir=tmp_path,
            test_mode=True,
        )

        upstream_messages = []
        client_messages = []
        proxy._send_to_upstream = lambda msg: upstream_messages.append(msg)
        proxy._send_to_client = lambda msg: client_messages.append(msg)

        message = {
            "jsonrpc": "2.0",
            "id": 2,
            "method": "tools/call",
            "params": {"name": "delete_all", "arguments": {"table": "users"}},
        }

        proxy._handle_tool_call(message)

        assert len(upstream_messages) == 0
        assert len(client_messages) == 1
        denial = json.loads(client_messages[0])
        assert denial["jsonrpc"] == "2.0"
        assert denial["id"] == 2
        assert denial["result"]["isError"] is True
        assert "GOVERNANCE DENIED" in denial["result"]["content"][0]["text"]

    def test_non_tool_messages_pass_through(self, tmp_path):
        """Messages that aren't tools/call should be forwarded unchanged."""
        _setup_agent(tmp_path, "PassBot")
        proxy = MCPGovernanceProxy(
            agent_id="PassBot",
            upstream_command="echo test",
            base_dir=tmp_path,
            test_mode=True,
        )

        upstream_messages = []
        proxy._send_to_upstream = lambda msg: upstream_messages.append(msg)

        # Simulate initialize message
        init_msg = {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}}
        stdin_line = json.dumps(init_msg)

        # Manually call the logic that _read_client would use
        message = json.loads(stdin_line)
        if proxy._is_tool_call(message):
            proxy._handle_tool_call(message)
        else:
            proxy._send_to_upstream(json.dumps(message))

        assert len(upstream_messages) == 1
        assert json.loads(upstream_messages[0])["method"] == "initialize"


# ── CLI argument parsing tests ────────────────────────────────────────────


class TestMCPProxyCLI:
    def test_mcp_proxy_parser_exists(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "mcp-proxy",
            "--agent-id", "test-bot",
            "--upstream", "python server.py",
        ])
        assert args.command == "mcp-proxy"
        assert args.agent_id == "test-bot"
        assert args.upstream == "python server.py"
        assert args.upstream_url is None

    def test_mcp_proxy_http_mode(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "mcp-proxy",
            "--agent-id", "test-bot",
            "--upstream-url", "http://localhost:3000",
            "--port", "9000",
        ])
        assert args.upstream_url == "http://localhost:3000"
        assert args.port == 9000
        assert args.upstream is None

    def test_mcp_proxy_defaults(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "mcp-proxy",
            "--agent-id", "bot",
            "--upstream", "cmd",
        ])
        assert args.port == 8421
        assert args.host == "127.0.0.1"
        assert args.test_mode is False
        assert args.log_level == "info"

    def test_mcp_proxy_test_mode_flag(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "mcp-proxy",
            "--agent-id", "bot",
            "--upstream", "cmd",
            "--test-mode",
            "--log-level", "debug",
        ])
        assert args.test_mode is True
        assert args.log_level == "debug"


# ── HTTP proxy unit tests ────────────────────────────────────────────────


class TestHTTPProxy:
    def test_handle_tool_call_http_denied(self, tmp_path):
        """Denied tool call returns denial dict."""
        # Agent scoped to "read" only — "destroy" is out of scope
        _setup_agent(tmp_path, "HTTPBot", actions=["read"])
        proxy = MCPHTTPGovernanceProxy(
            agent_id="HTTPBot",
            upstream_url="http://localhost:9999",
            base_dir=tmp_path,
            test_mode=True,
        )

        message = {
            "jsonrpc": "2.0",
            "id": 5,
            "method": "tools/call",
            "params": {"name": "destroy", "arguments": {"target": "everything"}},
        }

        result = proxy._handle_tool_call_http(message)
        assert result is not None
        assert result["result"]["isError"] is True
        assert "GOVERNANCE DENIED" in result["result"]["content"][0]["text"]

    def test_handle_tool_call_http_allowed(self, tmp_path):
        """Allowed tool call returns None (meaning: forward to upstream)."""
        _setup_agent(tmp_path, "HTTPAllowBot", actions=["read"])
        proxy = MCPHTTPGovernanceProxy(
            agent_id="HTTPAllowBot",
            upstream_url="http://localhost:9999",
            base_dir=tmp_path,
            test_mode=True,
        )

        message = {
            "jsonrpc": "2.0",
            "id": 6,
            "method": "tools/call",
            "params": {"name": "read", "arguments": {"path": "/data"}},
        }

        result = proxy._handle_tool_call_http(message)
        assert result is None
