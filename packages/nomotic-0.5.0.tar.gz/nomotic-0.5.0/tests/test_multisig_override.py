"""Tests for multi-party override authorization.

Covers:
- MultiSigOverridePolicy creation, to_dict/from_dict roundtrip, defaults
- OverrideSignature creation, to_dict/from_dict roundtrip, hash computation
- PendingOverride properties: signature_count, signatures_remaining, is_expired, authorities_signed
- PendingOverride serialization (to_dict/from_dict) with multiple signatures
- GovernanceRuntime multi-sig integration:
  - override() with no policy -> immediate GovernanceOverrideRecord
  - override() with matching policy -> PendingOverride
  - cosign_override() second authority -> threshold met -> COMPLETE
  - cosign_override() same authority twice -> ValueError
  - cosign_override() expired -> ValueError
  - cosign_override() wrong pending_override_id -> ValueError
  - cosign_override() max_same_role_signatures exceeded -> ValueError
  - get_pending_overrides() returns PENDING only
  - get_pending_overrides() auto-expires overrides past deadline
  - _find_applicable_policy() risk_tier no match
  - _find_applicable_policy() zone glob match
  - _find_applicable_policy() is_irreversible filter
  - M=1 edge case: immediately executes
  - Audit records: OVERRIDE_PENDING_CREATED, OVERRIDE_COSIGNED, OVERRIDE_COMPLETE, OVERRIDE_EXPIRED
  - Role check integration: cosign raises PermissionDeniedError
  - Full three-signature flow (M=3)
- Expiration webhooks:
  - OVERRIDE_EXPIRED webhook fired on expiry
  - OVERRIDE_EXPIRING webhook fired within warning window
  - Warning fires only once per override
  - Warning disabled when override_expiry_warning_seconds=0
  - Warning not fired outside window
  - Completed override does not fire OVERRIDE_EXPIRED
  - OVERRIDE_EXPIRED payload contains required fields
  - OVERRIDE_EXPIRING payload contains seconds_remaining
  - New event types in WEBHOOK_EVENT_TYPES
  - _expiry_warned set cleared after expiry
"""

import hashlib
import time
import uuid

import pytest

from nomotic.roles import (
    OverrideRole,
    PermissionDeniedError,
    RoleRegistry,
    _compute_role_hash,
)
from nomotic.runtime import GovernanceRuntime, RuntimeConfig
from nomotic.types import (
    AUDIT_OVERRIDE_COMPLETE,
    AUDIT_OVERRIDE_COSIGNED,
    AUDIT_OVERRIDE_EXPIRED,
    AUDIT_OVERRIDE_PENDING_CREATED,
    Action,
    AgentContext,
    GovernanceOverrideRecord,
    GovernanceVerdict,
    MultiSigOverridePolicy,
    OverrideSignature,
    PendingOverride,
    TrustProfile,
    Verdict,
)


# ── Helpers ──────────────────────────────────────────────────────────────


def _make_policy(**overrides) -> MultiSigOverridePolicy:
    """Create a test multi-sig policy with sensible defaults."""
    defaults = {
        "policy_id": f"nmpol-{uuid.uuid4()}",
        "name": "Test Multi-Sig Policy",
        "required_signatures": 2,
        "eligible_roles": ["nmr-role1", "nmr-role2"],
    }
    defaults.update(overrides)
    return MultiSigOverridePolicy(**defaults)


def _make_role(**overrides) -> OverrideRole:
    """Create a test role with sensible defaults."""
    defaults = {
        "role_id": f"nmr-{uuid.uuid4()}",
        "name": "Test Role",
        "authorities": ["admin@acme.com"],
        "permitted_override_types": ["APPROVE", "REVOKE"],
        "permitted_zones": ["*"],
        "permitted_archetypes": ["*"],
        "permitted_action_types": ["*"],
        "max_risk_tier": "critical",
        "can_override_irreversible": False,
        "created_by": "test@acme.com",
        "created_at": time.time(),
        "role_hash": "",
    }
    defaults.update(overrides)
    if not defaults["role_hash"]:
        defaults["role_hash"] = _compute_role_hash(defaults)
    return OverrideRole(**defaults)


def _ctx(agent_id: str = "agent-1", trust: float = 0.5) -> AgentContext:
    return AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id, overall_trust=trust),
    )


def _action(action_type: str = "read", target: str = "db", agent_id: str = "agent-1") -> Action:
    return Action(agent_id=agent_id, action_type=action_type, target=target)


def _setup_runtime_with_deny(
    *,
    multisig_policy: MultiSigOverridePolicy | None = None,
    role_registry: RoleRegistry | None = None,
) -> tuple[GovernanceRuntime, str]:
    """Create a runtime, evaluate an action to DENY, optionally set up multi-sig.

    Returns (runtime, action_id).
    """
    runtime = GovernanceRuntime(RuntimeConfig(
        deny_threshold=0.3,
        allow_threshold=0.7,
        enable_audit=False,
        enable_fingerprints=False,
    ))
    ctx = _ctx()

    # Configure scope to force a DENY
    scope_dim = runtime.registry.get("scope_compliance")
    scope_dim.configure_agent_scope("agent-1", {"write"})

    action = _action(action_type="read", target="db")
    verdict = runtime.evaluate(action, ctx)

    if multisig_policy is not None:
        runtime.add_multisig_policy(multisig_policy)

    if role_registry is not None:
        runtime.set_role_registry(role_registry)

    return runtime, action.id


# ── TestMultiSigOverridePolicy ──────────────────────────────────────────


class TestMultiSigOverridePolicy:
    def test_creation_defaults(self):
        policy = MultiSigOverridePolicy(
            policy_id="nmpol-test",
            name="Test Policy",
            required_signatures=2,
            eligible_roles=["r1", "r2"],
        )
        assert policy.policy_id == "nmpol-test"
        assert policy.name == "Test Policy"
        assert policy.required_signatures == 2
        assert policy.eligible_roles == ["r1", "r2"]
        assert policy.max_same_role_signatures == 1
        assert policy.applies_to_override_types == ["APPROVE", "REVOKE"]
        assert policy.applies_to_risk_tiers == ["critical", "high"]
        assert policy.applies_to_reversibilities == []
        assert policy.applies_to_zones == ["*"]
        assert policy.authorization_window_seconds == 3600

    def test_to_dict_roundtrip(self):
        policy = _make_policy(
            max_same_role_signatures=3,
            applies_to_reversibilities=["IRREVERSIBLE"],
            authorization_window_seconds=7200,
        )
        d = policy.to_dict()
        restored = MultiSigOverridePolicy.from_dict(d)
        assert restored.policy_id == policy.policy_id
        assert restored.name == policy.name
        assert restored.required_signatures == policy.required_signatures
        assert restored.eligible_roles == policy.eligible_roles
        assert restored.max_same_role_signatures == 3
        assert restored.applies_to_reversibilities == ["IRREVERSIBLE"]
        assert restored.authorization_window_seconds == 7200

    def test_from_dict_defaults(self):
        d = {
            "policy_id": "nmpol-min",
            "name": "Minimal",
            "required_signatures": 1,
            "eligible_roles": ["r1"],
        }
        policy = MultiSigOverridePolicy.from_dict(d)
        assert policy.max_same_role_signatures == 1
        assert policy.applies_to_override_types == ["APPROVE", "REVOKE"]
        assert policy.authorization_window_seconds == 3600


# ── TestOverrideSignature ───────────────────────────────────────────────


class TestOverrideSignature:
    def test_creation_and_roundtrip(self):
        sig = OverrideSignature(
            signature_id="nmosig-test",
            authority="admin@acme.com",
            role_id="nmr-role1",
            reason="Justified",
            signed_at=1000.0,
            signature_hash="abc123",
        )
        d = sig.to_dict()
        restored = OverrideSignature.from_dict(d)
        assert restored.signature_id == sig.signature_id
        assert restored.authority == sig.authority
        assert restored.role_id == sig.role_id
        assert restored.reason == sig.reason
        assert restored.signed_at == sig.signed_at
        assert restored.signature_hash == sig.signature_hash

    def test_compute_hash(self):
        h = OverrideSignature.compute_hash("nmpo-1", "admin@acme.com", "reason", 1000.0)
        expected = hashlib.sha256(
            b"nmpo-1admin@acme.comreason1000.0"
        ).hexdigest()
        assert h == expected

    def test_none_role_id_roundtrip(self):
        sig = OverrideSignature(
            signature_id="nmosig-test",
            authority="admin@acme.com",
            role_id=None,
            reason="Justified",
            signed_at=1000.0,
            signature_hash="abc123",
        )
        d = sig.to_dict()
        assert d["role_id"] is None
        restored = OverrideSignature.from_dict(d)
        assert restored.role_id is None


# ── TestPendingOverride ─────────────────────────────────────────────────


class TestPendingOverride:
    def test_signature_count(self):
        po = PendingOverride(
            override_id="nmpo-test",
            action_id="act-1",
            agent_id="agent-1",
            override_type="APPROVE",
            policy_id="nmpol-1",
            required_signatures=3,
        )
        assert po.signature_count == 0

        po.signatures.append(
            OverrideSignature(
                signature_id="s1", authority="a", role_id=None,
                reason="r", signed_at=1.0, signature_hash="h",
            )
        )
        assert po.signature_count == 1

    def test_signatures_remaining(self):
        po = PendingOverride(
            override_id="nmpo-test",
            action_id="act-1",
            agent_id="agent-1",
            override_type="APPROVE",
            policy_id="nmpol-1",
            required_signatures=2,
        )
        assert po.signatures_remaining == 2

        po.signatures.append(
            OverrideSignature(
                signature_id="s1", authority="a", role_id=None,
                reason="r", signed_at=1.0, signature_hash="h",
            )
        )
        assert po.signatures_remaining == 1

        po.signatures.append(
            OverrideSignature(
                signature_id="s2", authority="b", role_id=None,
                reason="r", signed_at=2.0, signature_hash="h2",
            )
        )
        assert po.signatures_remaining == 0

    def test_is_expired_not_expired(self):
        po = PendingOverride(
            override_id="nmpo-test",
            action_id="act-1",
            agent_id="agent-1",
            override_type="APPROVE",
            policy_id="nmpol-1",
            required_signatures=2,
            expires_at=time.time() + 3600,
        )
        assert not po.is_expired

    def test_is_expired_expired(self):
        po = PendingOverride(
            override_id="nmpo-test",
            action_id="act-1",
            agent_id="agent-1",
            override_type="APPROVE",
            policy_id="nmpol-1",
            required_signatures=2,
            expires_at=time.time() - 1,
        )
        assert po.is_expired

    def test_is_expired_complete_not_considered(self):
        po = PendingOverride(
            override_id="nmpo-test",
            action_id="act-1",
            agent_id="agent-1",
            override_type="APPROVE",
            policy_id="nmpol-1",
            required_signatures=2,
            status="COMPLETE",
            expires_at=time.time() - 1,
        )
        assert not po.is_expired  # status != PENDING

    def test_authorities_signed(self):
        po = PendingOverride(
            override_id="nmpo-test",
            action_id="act-1",
            agent_id="agent-1",
            override_type="APPROVE",
            policy_id="nmpol-1",
            required_signatures=2,
            signatures=[
                OverrideSignature("s1", "alice@acme.com", None, "r", 1.0, "h"),
                OverrideSignature("s2", "bob@acme.com", None, "r", 2.0, "h2"),
            ],
        )
        assert po.authorities_signed == ["alice@acme.com", "bob@acme.com"]


# ── TestPendingOverrideSerialization ────────────────────────────────────


class TestPendingOverrideSerialization:
    def test_roundtrip_with_multiple_signatures(self):
        po = PendingOverride(
            override_id="nmpo-abc123",
            action_id="act-xyz",
            agent_id="agent-1",
            override_type="APPROVE",
            policy_id="nmpol-pol1",
            required_signatures=3,
            signatures=[
                OverrideSignature("s1", "alice@acme.com", "nmr-r1", "reason1", 1000.0, "h1"),
                OverrideSignature("s2", "bob@acme.com", "nmr-r2", "reason2", 2000.0, "h2"),
            ],
            status="PENDING",
            created_at=900.0,
            expires_at=4500.0,
            completed_at=None,
            original_verdict="DENY",
            initial_authority="alice@acme.com",
            initial_reason="reason1",
        )
        d = po.to_dict()
        restored = PendingOverride.from_dict(d)
        assert restored.override_id == po.override_id
        assert restored.action_id == po.action_id
        assert restored.agent_id == po.agent_id
        assert restored.override_type == po.override_type
        assert restored.policy_id == po.policy_id
        assert restored.required_signatures == po.required_signatures
        assert len(restored.signatures) == 2
        assert restored.signatures[0].authority == "alice@acme.com"
        assert restored.signatures[1].authority == "bob@acme.com"
        assert restored.status == "PENDING"
        assert restored.created_at == 900.0
        assert restored.expires_at == 4500.0
        assert restored.completed_at is None
        assert restored.original_verdict == "DENY"
        assert restored.initial_authority == "alice@acme.com"

    def test_roundtrip_completed(self):
        po = PendingOverride(
            override_id="nmpo-done",
            action_id="act-1",
            agent_id="agent-1",
            override_type="REVOKE",
            policy_id="nmpol-1",
            required_signatures=1,
            status="COMPLETE",
            completed_at=5000.0,
        )
        d = po.to_dict()
        restored = PendingOverride.from_dict(d)
        assert restored.status == "COMPLETE"
        assert restored.completed_at == 5000.0


# ── TestMultiSigRuntime ─────────────────────────────────────────────────


class TestMultiSigRuntime:
    """Tests for multi-sig override integration in GovernanceRuntime."""

    def test_override_no_policy_returns_immediate(self):
        """override() with no policy -> returns GovernanceOverrideRecord (immediate)."""
        runtime, action_id = _setup_runtime_with_deny()
        result = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="admin@acme.com",
            reason="Reviewed and approved",
            role_check=False,
        )
        assert isinstance(result, GovernanceOverrideRecord)
        assert result.override_type == "APPROVE"

    def test_override_with_policy_returns_pending(self):
        """override() with matching policy -> returns PendingOverride."""
        policy = _make_policy(
            applies_to_risk_tiers=["critical", "high", "moderate", "low"],
        )
        runtime, action_id = _setup_runtime_with_deny(multisig_policy=policy)
        result = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="admin@acme.com",
            reason="Need multi-sig",
            role_check=False,
        )
        assert isinstance(result, PendingOverride)
        assert result.status == "PENDING"
        assert result.signature_count == 1
        assert result.action_id == action_id
        assert result.override_type == "APPROVE"
        assert result.initial_authority == "admin@acme.com"
        assert result.initial_reason == "Need multi-sig"

    def test_pending_override_has_correct_fields(self):
        """PendingOverride created by override() has correct status and sig count."""
        policy = _make_policy(
            applies_to_risk_tiers=["critical", "high", "moderate", "low"],
        )
        runtime, action_id = _setup_runtime_with_deny(multisig_policy=policy)
        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="first@acme.com",
            reason="First signature",
            role_check=False,
        )
        assert isinstance(pending, PendingOverride)
        assert pending.status == "PENDING"
        assert pending.signature_count == 1
        assert pending.signatures[0].authority == "first@acme.com"
        assert pending.override_id.startswith("nmpo-")
        assert pending.policy_id == policy.policy_id

    def test_cosign_threshold_met_completes(self):
        """cosign_override() with second authority -> threshold met -> COMPLETE."""
        policy = _make_policy(
            required_signatures=2,
            applies_to_risk_tiers=["critical", "high", "moderate", "low"],
        )
        runtime, action_id = _setup_runtime_with_deny(multisig_policy=policy)
        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="first@acme.com",
            reason="First",
            role_check=False,
        )
        assert isinstance(pending, PendingOverride)

        result = runtime.cosign_override(
            pending_override_id=pending.override_id,
            authority="second@acme.com",
            reason="Second",
            role_check=False,
        )
        assert result.status == "COMPLETE"
        assert result.signature_count == 2
        assert result.completed_at is not None

    def test_cosign_same_authority_raises(self):
        """cosign_override() — same authority twice -> raises ValueError."""
        policy = _make_policy(
            required_signatures=3,
            applies_to_risk_tiers=["critical", "high", "moderate", "low"],
        )
        runtime, action_id = _setup_runtime_with_deny(multisig_policy=policy)
        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="admin@acme.com",
            reason="First",
            role_check=False,
        )
        assert isinstance(pending, PendingOverride)

        with pytest.raises(ValueError, match="already signed"):
            runtime.cosign_override(
                pending_override_id=pending.override_id,
                authority="admin@acme.com",
                reason="Duplicate",
                role_check=False,
            )

    def test_cosign_expired_raises(self):
        """cosign_override() — expired override -> raises ValueError."""
        policy = _make_policy(
            required_signatures=2,
            authorization_window_seconds=0,  # Expires immediately
            applies_to_risk_tiers=["critical", "high", "moderate", "low"],
        )
        runtime, action_id = _setup_runtime_with_deny(multisig_policy=policy)
        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="first@acme.com",
            reason="First",
            role_check=False,
        )
        assert isinstance(pending, PendingOverride)

        # Wait a moment for expiry
        time.sleep(0.01)

        with pytest.raises(ValueError, match="expired"):
            runtime.cosign_override(
                pending_override_id=pending.override_id,
                authority="second@acme.com",
                reason="Too late",
                role_check=False,
            )

    def test_cosign_wrong_id_raises(self):
        """cosign_override() — wrong pending_override_id -> raises ValueError."""
        runtime = GovernanceRuntime(RuntimeConfig(
            enable_audit=False, enable_fingerprints=False,
        ))
        with pytest.raises(ValueError, match="not found"):
            runtime.cosign_override(
                pending_override_id="nmpo-does-not-exist",
                authority="admin@acme.com",
                reason="Wrong ID",
                role_check=False,
            )

    def test_cosign_max_same_role_exceeded_raises(self):
        """cosign_override() — max_same_role_signatures exceeded -> raises ValueError."""
        role_id = f"nmr-{uuid.uuid4()}"
        role1 = _make_role(
            role_id=role_id,
            authorities=["first@acme.com", "second@acme.com"],
        )
        registry = RoleRegistry()
        registry.register(role1)

        policy = _make_policy(
            required_signatures=3,
            max_same_role_signatures=1,
            eligible_roles=[role_id],
            applies_to_risk_tiers=["critical", "high", "moderate", "low"],
        )
        runtime, action_id = _setup_runtime_with_deny(
            multisig_policy=policy, role_registry=registry,
        )

        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="first@acme.com",
            reason="First",
            role_check=True,
        )
        assert isinstance(pending, PendingOverride)
        assert pending.signatures[0].role_id == role_id

        with pytest.raises(ValueError, match="Maximum signatures from role"):
            runtime.cosign_override(
                pending_override_id=pending.override_id,
                authority="second@acme.com",
                reason="Second same role",
                role_check=True,
            )

    def test_get_pending_overrides_returns_pending_only(self):
        """get_pending_overrides() -> returns PENDING overrides only."""
        policy = _make_policy(
            required_signatures=2,
            applies_to_risk_tiers=["critical", "high", "moderate", "low"],
        )
        runtime, action_id = _setup_runtime_with_deny(multisig_policy=policy)

        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="first@acme.com",
            reason="First",
            role_check=False,
        )
        assert isinstance(pending, PendingOverride)

        pending_list = runtime.get_pending_overrides()
        assert len(pending_list) == 1
        assert pending_list[0].override_id == pending.override_id

        # Complete it
        runtime.cosign_override(
            pending.override_id, "second@acme.com", "Second", role_check=False,
        )

        # Should now be empty (COMPLETE, not PENDING)
        pending_list = runtime.get_pending_overrides()
        assert len(pending_list) == 0

    def test_get_pending_overrides_auto_expires(self):
        """get_pending_overrides() -> auto-expires overrides past deadline."""
        policy = _make_policy(
            required_signatures=2,
            authorization_window_seconds=0,  # Immediate expiry
            applies_to_risk_tiers=["critical", "high", "moderate", "low"],
        )
        runtime, action_id = _setup_runtime_with_deny(multisig_policy=policy)
        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="first@acme.com",
            reason="First",
            role_check=False,
        )
        assert isinstance(pending, PendingOverride)

        time.sleep(0.01)

        pending_list = runtime.get_pending_overrides()
        assert len(pending_list) == 0
        # The expired one should have been removed
        assert pending.status == "EXPIRED"

    def test_find_applicable_policy_risk_tier_no_match(self):
        """_find_applicable_policy() — risk_tier not in policy -> no match."""
        policy = _make_policy(
            applies_to_risk_tiers=["critical"],
        )
        runtime = GovernanceRuntime(RuntimeConfig(
            enable_audit=False, enable_fingerprints=False,
        ))
        runtime.add_multisig_policy(policy)

        result = runtime._find_applicable_policy("APPROVE", "low", False, "us/east")
        assert result is None

    def test_find_applicable_policy_zone_glob_match(self):
        """_find_applicable_policy() — zone glob match."""
        policy = _make_policy(
            applies_to_zones=["eu/*"],
            applies_to_risk_tiers=["critical"],
        )
        runtime = GovernanceRuntime(RuntimeConfig(
            enable_audit=False, enable_fingerprints=False,
        ))
        runtime.add_multisig_policy(policy)

        assert runtime._find_applicable_policy("APPROVE", "critical", False, "eu/west") is not None
        assert runtime._find_applicable_policy("APPROVE", "critical", False, "us/east") is None

    def test_find_applicable_policy_irreversible_filter(self):
        """_find_applicable_policy() — is_irreversible filter."""
        policy = _make_policy(
            applies_to_reversibilities=["IRREVERSIBLE"],
            applies_to_risk_tiers=["critical"],
        )
        runtime = GovernanceRuntime(RuntimeConfig(
            enable_audit=False, enable_fingerprints=False,
        ))
        runtime.add_multisig_policy(policy)

        # Irreversible should match
        assert runtime._find_applicable_policy("APPROVE", "critical", True, "*") is not None
        # Reversible should not match
        assert runtime._find_applicable_policy("APPROVE", "critical", False, "*") is None

    def test_find_applicable_policy_reversible_filter(self):
        """_find_applicable_policy() — REVERSIBLE filter."""
        policy = _make_policy(
            applies_to_reversibilities=["REVERSIBLE"],
            applies_to_risk_tiers=["critical"],
        )
        runtime = GovernanceRuntime(RuntimeConfig(
            enable_audit=False, enable_fingerprints=False,
        ))
        runtime.add_multisig_policy(policy)

        assert runtime._find_applicable_policy("APPROVE", "critical", False, "*") is not None
        assert runtime._find_applicable_policy("APPROVE", "critical", True, "*") is None

    def test_m1_edge_case_immediately_executes(self):
        """M=1 edge case: override() with M=1 policy -> immediately executes."""
        policy = _make_policy(
            required_signatures=1,
            applies_to_risk_tiers=["critical", "high", "moderate", "low"],
        )
        runtime, action_id = _setup_runtime_with_deny(multisig_policy=policy)

        result = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="admin@acme.com",
            reason="Only one needed",
            role_check=False,
        )
        assert isinstance(result, PendingOverride)
        assert result.status == "COMPLETE"
        assert result.completed_at is not None

    def test_audit_override_pending_created(self, tmp_path):
        """OVERRIDE_PENDING_CREATED audit record written."""
        from nomotic.audit_store import AuditStore

        audit_store = AuditStore(tmp_path)
        policy = _make_policy(
            required_signatures=2,
            applies_to_risk_tiers=["critical", "high", "moderate", "low"],
        )
        runtime, action_id = _setup_runtime_with_deny(multisig_policy=policy)
        runtime.set_audit_store(audit_store)

        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="admin@acme.com",
            reason="Multi-sig needed",
            role_check=False,
        )
        assert isinstance(pending, PendingOverride)

        # Check audit records
        records = audit_store.query_all(pending.agent_id)
        created_records = [r for r in records if r.verdict == AUDIT_OVERRIDE_PENDING_CREATED]
        assert len(created_records) >= 1
        assert created_records[0].parameters["override_id"] == pending.override_id

    def test_audit_override_cosigned(self, tmp_path):
        """OVERRIDE_COSIGNED audit record written on cosign."""
        from nomotic.audit_store import AuditStore

        audit_store = AuditStore(tmp_path)
        policy = _make_policy(
            required_signatures=3,
            applies_to_risk_tiers=["critical", "high", "moderate", "low"],
        )
        runtime, action_id = _setup_runtime_with_deny(multisig_policy=policy)
        runtime.set_audit_store(audit_store)

        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="first@acme.com",
            reason="First",
            role_check=False,
        )
        assert isinstance(pending, PendingOverride)

        runtime.cosign_override(
            pending.override_id, "second@acme.com", "Second", role_check=False,
        )

        records = audit_store.query_all(pending.agent_id)
        cosigned_records = [r for r in records if r.verdict == AUDIT_OVERRIDE_COSIGNED]
        assert len(cosigned_records) >= 1
        assert cosigned_records[0].parameters["signing_authority"] == "second@acme.com"

    def test_audit_override_complete(self, tmp_path):
        """OVERRIDE_COMPLETE audit record written when threshold met."""
        from nomotic.audit_store import AuditStore

        audit_store = AuditStore(tmp_path)
        policy = _make_policy(
            required_signatures=2,
            applies_to_risk_tiers=["critical", "high", "moderate", "low"],
        )
        runtime, action_id = _setup_runtime_with_deny(multisig_policy=policy)
        runtime.set_audit_store(audit_store)

        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="first@acme.com",
            reason="First",
            role_check=False,
        )
        assert isinstance(pending, PendingOverride)

        runtime.cosign_override(
            pending.override_id, "second@acme.com", "Second", role_check=False,
        )

        records = audit_store.query_all(pending.agent_id)
        complete_records = [r for r in records if r.verdict == AUDIT_OVERRIDE_COMPLETE]
        assert len(complete_records) >= 1
        assert complete_records[0].parameters["authorities"] == [
            "first@acme.com", "second@acme.com",
        ]

    def test_audit_override_expired(self, tmp_path):
        """OVERRIDE_EXPIRED audit record written when expired."""
        from nomotic.audit_store import AuditStore

        audit_store = AuditStore(tmp_path)
        policy = _make_policy(
            required_signatures=2,
            authorization_window_seconds=0,
            applies_to_risk_tiers=["critical", "high", "moderate", "low"],
        )
        runtime, action_id = _setup_runtime_with_deny(multisig_policy=policy)
        runtime.set_audit_store(audit_store)

        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="first@acme.com",
            reason="First",
            role_check=False,
        )
        assert isinstance(pending, PendingOverride)

        time.sleep(0.01)

        # Trigger auto-expire
        runtime.get_pending_overrides()

        records = audit_store.query_all(pending.agent_id)
        expired_records = [r for r in records if r.verdict == AUDIT_OVERRIDE_EXPIRED]
        assert len(expired_records) >= 1
        assert expired_records[0].parameters["signatures_at_expiry"] == 1

    def test_cosign_role_check_permission_denied(self):
        """cosign_override() raises PermissionDeniedError when authority lacks permission."""
        role = _make_role(
            authorities=["first@acme.com"],  # Only first is authorized
        )
        registry = RoleRegistry()
        registry.register(role)

        policy = _make_policy(
            required_signatures=2,
            applies_to_risk_tiers=["critical", "high", "moderate", "low"],
        )
        runtime, action_id = _setup_runtime_with_deny(
            multisig_policy=policy, role_registry=registry,
        )

        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="first@acme.com",
            reason="First",
            role_check=True,
        )
        assert isinstance(pending, PendingOverride)

        with pytest.raises(PermissionDeniedError):
            runtime.cosign_override(
                pending_override_id=pending.override_id,
                authority="unauthorized@acme.com",
                reason="Not allowed",
                role_check=True,
            )

    def test_full_three_signature_flow(self):
        """Full three-signature flow (M=3): create pending, cosign twice, verify complete."""
        policy = _make_policy(
            required_signatures=3,
            max_same_role_signatures=3,  # Allow same role for simplicity
            applies_to_risk_tiers=["critical", "high", "moderate", "low"],
        )
        runtime, action_id = _setup_runtime_with_deny(multisig_policy=policy)

        # First signature
        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="first@acme.com",
            reason="Initiated",
            role_check=False,
        )
        assert isinstance(pending, PendingOverride)
        assert pending.status == "PENDING"
        assert pending.signature_count == 1
        assert pending.signatures_remaining == 2

        # Second signature
        result = runtime.cosign_override(
            pending.override_id, "second@acme.com", "Concur", role_check=False,
        )
        assert result.status == "PENDING"
        assert result.signature_count == 2
        assert result.signatures_remaining == 1

        # Third signature — threshold met
        result = runtime.cosign_override(
            pending.override_id, "third@acme.com", "Final approval", role_check=False,
        )
        assert result.status == "COMPLETE"
        assert result.signature_count == 3
        assert result.signatures_remaining == 0
        assert result.completed_at is not None
        assert result.authorities_signed == [
            "first@acme.com", "second@acme.com", "third@acme.com",
        ]

    def test_get_pending_override_returns_none_if_not_found(self):
        """get_pending_override() returns None for unknown ID."""
        runtime = GovernanceRuntime(RuntimeConfig(
            enable_audit=False, enable_fingerprints=False,
        ))
        assert runtime.get_pending_override("nmpo-nonexistent") is None

    def test_get_pending_override_returns_existing(self):
        """get_pending_override() returns existing pending."""
        policy = _make_policy(
            required_signatures=2,
            applies_to_risk_tiers=["critical", "high", "moderate", "low"],
        )
        runtime, action_id = _setup_runtime_with_deny(multisig_policy=policy)

        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="admin@acme.com",
            reason="Pending",
            role_check=False,
        )
        assert isinstance(pending, PendingOverride)

        fetched = runtime.get_pending_override(pending.override_id)
        assert fetched is not None
        assert fetched.override_id == pending.override_id

    def test_cosign_not_pending_status_raises(self):
        """cosign_override() on a COMPLETE override raises ValueError."""
        policy = _make_policy(
            required_signatures=1,
            applies_to_risk_tiers=["critical", "high", "moderate", "low"],
        )
        runtime, action_id = _setup_runtime_with_deny(multisig_policy=policy)

        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="admin@acme.com",
            reason="Only one needed",
            role_check=False,
        )
        assert isinstance(pending, PendingOverride)
        assert pending.status == "COMPLETE"

        with pytest.raises(ValueError, match="not in PENDING state"):
            runtime.cosign_override(
                pending.override_id, "extra@acme.com", "Too late", role_check=False,
            )

    def test_find_applicable_policy_override_type_no_match(self):
        """_find_applicable_policy() — override_type not in policy."""
        policy = _make_policy(
            applies_to_override_types=["REVOKE"],
            applies_to_risk_tiers=["critical"],
        )
        runtime = GovernanceRuntime(RuntimeConfig(
            enable_audit=False, enable_fingerprints=False,
        ))
        runtime.add_multisig_policy(policy)

        assert runtime._find_applicable_policy("APPROVE", "critical", False, "*") is None

    def test_find_applicable_policy_empty_reversibilities_matches_all(self):
        """_find_applicable_policy() — empty reversibilities matches all."""
        policy = _make_policy(
            applies_to_reversibilities=[],
            applies_to_risk_tiers=["critical"],
        )
        runtime = GovernanceRuntime(RuntimeConfig(
            enable_audit=False, enable_fingerprints=False,
        ))
        runtime.add_multisig_policy(policy)

        assert runtime._find_applicable_policy("APPROVE", "critical", True, "*") is not None
        assert runtime._find_applicable_policy("APPROVE", "critical", False, "*") is not None

    def test_add_multisig_policy(self):
        """add_multisig_policy adds policy to the list."""
        runtime = GovernanceRuntime(RuntimeConfig(
            enable_audit=False, enable_fingerprints=False,
        ))
        assert len(runtime._multisig_policies) == 0
        policy = _make_policy()
        runtime.add_multisig_policy(policy)
        assert len(runtime._multisig_policies) == 1
        assert runtime._multisig_policies[0].policy_id == policy.policy_id

    def test_pending_override_expires_at_set_correctly(self):
        """PendingOverride.expires_at is set to created_at + window."""
        policy = _make_policy(
            required_signatures=2,
            authorization_window_seconds=7200,
            applies_to_risk_tiers=["critical", "high", "moderate", "low"],
        )
        runtime, action_id = _setup_runtime_with_deny(multisig_policy=policy)

        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="admin@acme.com",
            reason="Testing window",
            role_check=False,
        )
        assert isinstance(pending, PendingOverride)

        # expires_at should be approximately created_at + 7200
        assert abs((pending.expires_at - pending.created_at) - 7200) < 1.0


# ── TestOverrideExpirationWebhooks ──────────────────────────────────────


class TestOverrideExpirationWebhooks:
    """Tests for OVERRIDE_EXPIRING and OVERRIDE_EXPIRED webhook events."""

    def _setup_runtime_with_webhook_capture(
        self,
        *,
        policy_kwargs=None,
        config_kwargs=None,
    ):
        """Create a runtime with a monkeypatched _dispatch_webhook to capture calls.

        Returns (runtime, action_id, dispatched_events_list).
        """
        cfg_defaults = {
            "deny_threshold": 0.3,
            "allow_threshold": 0.7,
            "enable_audit": False,
            "enable_fingerprints": False,
        }
        if config_kwargs:
            cfg_defaults.update(config_kwargs)
        runtime = GovernanceRuntime(RuntimeConfig(**cfg_defaults))
        ctx = _ctx()

        # Configure scope to force a DENY
        scope_dim = runtime.registry.get("scope_compliance")
        scope_dim.configure_agent_scope("agent-1", {"write"})

        action = _action(action_type="read", target="db")
        runtime.evaluate(action, ctx)

        pol_defaults = {
            "required_signatures": 2,
            "applies_to_risk_tiers": ["critical", "high", "moderate", "low"],
        }
        if policy_kwargs:
            pol_defaults.update(policy_kwargs)
        policy = _make_policy(**pol_defaults)
        runtime.add_multisig_policy(policy)

        # Capture webhook dispatches
        dispatched: list[tuple[str, str, dict]] = []
        original_dispatch = runtime._dispatch_webhook

        def _capture(event_type, agent_id, payload):
            dispatched.append((event_type, agent_id, payload))
            original_dispatch(event_type, agent_id, payload)

        runtime._dispatch_webhook = _capture

        return runtime, action.id, dispatched, policy

    def test_expired_override_fires_override_expired_webhook(self):
        """OVERRIDE_EXPIRED webhook is dispatched when an override expires."""
        runtime, action_id, dispatched, policy = self._setup_runtime_with_webhook_capture(
            policy_kwargs={"authorization_window_seconds": 0},
        )

        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="first@acme.com",
            reason="First",
            role_check=False,
        )
        assert isinstance(pending, PendingOverride)

        time.sleep(0.01)

        # Trigger auto-expire via get_pending_overrides()
        runtime.get_pending_overrides()

        expired_events = [e for e in dispatched if e[0] == "OVERRIDE_EXPIRED"]
        assert len(expired_events) == 1
        assert expired_events[0][2]["pending_id"] == pending.override_id

    def test_override_expiring_fires_within_warning_window(self):
        """OVERRIDE_EXPIRING webhook fires when override is within warning window."""
        runtime, action_id, dispatched, policy = self._setup_runtime_with_webhook_capture(
            policy_kwargs={"authorization_window_seconds": 10},
            config_kwargs={"override_expiry_warning_seconds": 600.0},
        )

        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="first@acme.com",
            reason="First",
            role_check=False,
        )
        assert isinstance(pending, PendingOverride)
        # Override expires in 10s, warning window is 600s, so 10s < 600s → should fire

        runtime.get_pending_overrides()

        expiring_events = [e for e in dispatched if e[0] == "OVERRIDE_EXPIRING"]
        assert len(expiring_events) == 1
        assert expiring_events[0][2]["pending_id"] == pending.override_id

    def test_expiry_warning_only_fires_once_per_override(self):
        """OVERRIDE_EXPIRING webhook fires at most once per override."""
        runtime, action_id, dispatched, policy = self._setup_runtime_with_webhook_capture(
            policy_kwargs={"authorization_window_seconds": 10},
            config_kwargs={"override_expiry_warning_seconds": 600.0},
        )

        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="first@acme.com",
            reason="First",
            role_check=False,
        )
        assert isinstance(pending, PendingOverride)

        # Call get_pending_overrides() multiple times
        runtime.get_pending_overrides()
        runtime.get_pending_overrides()
        runtime.get_pending_overrides()

        expiring_events = [e for e in dispatched if e[0] == "OVERRIDE_EXPIRING"]
        assert len(expiring_events) == 1

    def test_expiry_warning_not_fired_when_disabled_zero(self):
        """OVERRIDE_EXPIRING not fired when override_expiry_warning_seconds=0."""
        runtime, action_id, dispatched, policy = self._setup_runtime_with_webhook_capture(
            policy_kwargs={"authorization_window_seconds": 10},
            config_kwargs={"override_expiry_warning_seconds": 0.0},
        )

        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="first@acme.com",
            reason="First",
            role_check=False,
        )
        assert isinstance(pending, PendingOverride)

        runtime.get_pending_overrides()

        expiring_events = [e for e in dispatched if e[0] == "OVERRIDE_EXPIRING"]
        assert len(expiring_events) == 0

    def test_expiry_warning_not_fired_outside_window(self):
        """OVERRIDE_EXPIRING not fired when time_remaining > warning_seconds."""
        runtime, action_id, dispatched, policy = self._setup_runtime_with_webhook_capture(
            policy_kwargs={"authorization_window_seconds": 3600},
            config_kwargs={"override_expiry_warning_seconds": 60.0},
        )

        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="first@acme.com",
            reason="First",
            role_check=False,
        )
        assert isinstance(pending, PendingOverride)
        # Override expires in 3600s, warning window is 60s → should NOT fire

        runtime.get_pending_overrides()

        expiring_events = [e for e in dispatched if e[0] == "OVERRIDE_EXPIRING"]
        assert len(expiring_events) == 0

    def test_completed_override_does_not_fire_expired_webhook(self):
        """Completed override should not fire OVERRIDE_EXPIRED."""
        runtime, action_id, dispatched, policy = self._setup_runtime_with_webhook_capture(
            policy_kwargs={"authorization_window_seconds": 0, "required_signatures": 1},
        )

        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="admin@acme.com",
            reason="Only one needed",
            role_check=False,
        )
        assert isinstance(pending, PendingOverride)
        # M=1 → immediately COMPLETE
        assert pending.status == "COMPLETE"

        time.sleep(0.01)

        runtime.get_pending_overrides()

        expired_events = [e for e in dispatched if e[0] == "OVERRIDE_EXPIRED"]
        assert len(expired_events) == 0

    def test_override_expired_payload_contains_required_fields(self):
        """OVERRIDE_EXPIRED payload has all required fields."""
        runtime, action_id, dispatched, policy = self._setup_runtime_with_webhook_capture(
            policy_kwargs={"authorization_window_seconds": 0},
        )

        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="first@acme.com",
            reason="First",
            role_check=False,
        )
        assert isinstance(pending, PendingOverride)

        time.sleep(0.01)
        runtime.get_pending_overrides()

        expired_events = [e for e in dispatched if e[0] == "OVERRIDE_EXPIRED"]
        assert len(expired_events) == 1

        payload = expired_events[0][2]
        assert "pending_id" in payload
        assert "action_id" in payload
        assert "agent_id" in payload
        assert "policy_name" in payload
        assert "signatures_collected" in payload
        assert "signatures_required" in payload
        assert "expired_at" in payload
        assert payload["pending_id"] == pending.override_id
        assert payload["action_id"] == pending.action_id
        assert payload["agent_id"] == pending.agent_id
        assert payload["signatures_collected"] == 1
        assert payload["signatures_required"] == 2
        assert payload["policy_name"] == policy.name

    def test_override_expiring_payload_contains_seconds_remaining(self):
        """OVERRIDE_EXPIRING payload has seconds_remaining."""
        runtime, action_id, dispatched, policy = self._setup_runtime_with_webhook_capture(
            policy_kwargs={"authorization_window_seconds": 10},
            config_kwargs={"override_expiry_warning_seconds": 600.0},
        )

        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="first@acme.com",
            reason="First",
            role_check=False,
        )
        assert isinstance(pending, PendingOverride)

        runtime.get_pending_overrides()

        expiring_events = [e for e in dispatched if e[0] == "OVERRIDE_EXPIRING"]
        assert len(expiring_events) == 1

        payload = expiring_events[0][2]
        assert "seconds_remaining" in payload
        assert "pending_id" in payload
        assert "action_id" in payload
        assert "agent_id" in payload
        assert "policy_name" in payload
        assert "signatures_collected" in payload
        assert "signatures_required" in payload
        assert isinstance(payload["seconds_remaining"], int)
        assert payload["seconds_remaining"] >= 0
        assert payload["seconds_remaining"] <= 10
        assert payload["policy_name"] == policy.name

    def test_new_event_types_in_webhook_event_types(self):
        """OVERRIDE_EXPIRING and OVERRIDE_EXPIRED in WEBHOOK_EVENT_TYPES."""
        from nomotic.webhooks import WEBHOOK_EVENT_TYPES

        assert "OVERRIDE_EXPIRING" in WEBHOOK_EVENT_TYPES
        assert "OVERRIDE_EXPIRED" in WEBHOOK_EVENT_TYPES

    def test_expiry_warned_set_cleared_after_expiry(self):
        """_expiry_warned set is cleared for an override after it expires."""
        runtime, action_id, dispatched, policy = self._setup_runtime_with_webhook_capture(
            policy_kwargs={"authorization_window_seconds": 1},
            config_kwargs={"override_expiry_warning_seconds": 600.0},
        )

        pending = runtime.override(
            action_id=action_id,
            override_type="APPROVE",
            authority="first@acme.com",
            reason="First",
            role_check=False,
        )
        assert isinstance(pending, PendingOverride)

        # Trigger warning — override expires in 1s, window is 600s
        runtime.get_pending_overrides()
        assert pending.override_id in runtime._expiry_warned

        # Wait for actual expiry
        time.sleep(1.1)
        runtime.get_pending_overrides()

        # After expiry, the warned set should no longer contain this override
        assert pending.override_id not in runtime._expiry_warned

    def test_cosign_override_triggers_expiry_check(self):
        """cosign_override() also triggers _check_expiry_warnings()."""
        # Create two pending overrides — one about to expire, one being cosigned
        runtime = GovernanceRuntime(RuntimeConfig(
            deny_threshold=0.3,
            allow_threshold=0.7,
            enable_audit=False,
            enable_fingerprints=False,
            override_expiry_warning_seconds=600.0,
        ))
        ctx = _ctx()
        scope_dim = runtime.registry.get("scope_compliance")
        scope_dim.configure_agent_scope("agent-1", {"write"})

        action1 = _action(action_type="read", target="db")
        runtime.evaluate(action1, ctx)

        action2 = Action(agent_id="agent-1", action_type="read", target="db")
        runtime.evaluate(action2, ctx)

        # Two policies with different windows
        policy_short = _make_policy(
            required_signatures=2,
            authorization_window_seconds=5,
            applies_to_risk_tiers=["critical", "high", "moderate", "low"],
        )
        policy_long = _make_policy(
            required_signatures=3,
            authorization_window_seconds=3600,
            applies_to_risk_tiers=["critical", "high", "moderate", "low"],
        )
        runtime.add_multisig_policy(policy_short)
        runtime.add_multisig_policy(policy_long)

        # Capture webhook dispatches
        dispatched: list[tuple[str, str, dict]] = []
        original_dispatch = runtime._dispatch_webhook

        def _capture(event_type, agent_id, payload):
            dispatched.append((event_type, agent_id, payload))
            original_dispatch(event_type, agent_id, payload)

        runtime._dispatch_webhook = _capture

        # Create pending override with short window (5s — within 600s warning)
        pending_short = runtime.override(
            action_id=action1.id,
            override_type="APPROVE",
            authority="first@acme.com",
            reason="Short window",
            role_check=False,
        )
        assert isinstance(pending_short, PendingOverride)

        # Create pending override with long window (3600s — outside 600s warning)
        pending_long = runtime.override(
            action_id=action2.id,
            override_type="APPROVE",
            authority="alpha@acme.com",
            reason="Long window",
            role_check=False,
        )
        assert isinstance(pending_long, PendingOverride)

        # Cosign the long-window override — should trigger expiry check for the short one
        runtime.cosign_override(
            pending_long.override_id, "beta@acme.com", "Second", role_check=False,
        )

        expiring_events = [e for e in dispatched if e[0] == "OVERRIDE_EXPIRING"]
        # Should have warning for the short-window override
        short_warnings = [
            e for e in expiring_events
            if e[2]["pending_id"] == pending_short.override_id
        ]
        assert len(short_warnings) == 1
