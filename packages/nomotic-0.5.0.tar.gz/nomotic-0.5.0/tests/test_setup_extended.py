"""Tests for the extended nomotic setup wizard (compliance, severity, org governance)."""

import json
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from nomotic.cli import main
from nomotic.org_governance import load_org_config


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _run_setup(tmp: str, inputs: list[str], capsys) -> dict:
    """Run nomotic setup with mocked inputs, return parsed config.json."""
    with patch("builtins.input", side_effect=inputs):
        main(["--base-dir", tmp, "setup"])
    config_path = Path(tmp) / "config.json"
    assert config_path.exists(), "config.json not created"
    return json.loads(config_path.read_text(encoding="utf-8"))


def _write_existing_config(tmp: str, extra: dict | None = None) -> None:
    """Write a pre-existing config.json for re-run tests."""
    config = {
        "organization": "acme-corp",
        "owner": "admin@acme.com",
        "default_zone": "global",
    }
    if extra:
        config.update(extra)
    Path(tmp, "config.json").write_text(json.dumps(config), encoding="utf-8")


# ---------------------------------------------------------------------------
# Tests: No compliance (selection 1)
# ---------------------------------------------------------------------------

class TestSetupNoCompliance:
    """Selecting no compliance requirements."""

    def test_no_compliance_standard_severity(self, capsys):
        """Selection 1 for compliance → empty frameworks, standard preset."""
        with tempfile.TemporaryDirectory() as tmp:
            # org, owner, zone, compliance=1, severity=1
            inputs = ["Acme Corp", "admin@acme.com", "global", "1", "1"]
            config = _run_setup(tmp, inputs, capsys)

            assert config["compliance_frameworks"] == []
            assert config["compliance_presets"] == []
            assert config["default_preset"] == "standard"
            assert config["organization"] == "acme-corp"
            assert config["owner"] == "admin@acme.com"
            assert config["default_zone"] == "global"

    def test_no_compliance_defaults(self, capsys):
        """Empty inputs accept all defaults (no compliance, standard severity)."""
        with tempfile.TemporaryDirectory() as tmp:
            # All empty → defaults: org="", owner="", zone=global, compliance=1, severity=1
            inputs = ["TestOrg", "test@test.com", "", "", ""]
            config = _run_setup(tmp, inputs, capsys)

            assert config["compliance_frameworks"] == []
            assert config["compliance_presets"] == []
            assert config["default_preset"] == "standard"


# ---------------------------------------------------------------------------
# Tests: Single compliance framework
# ---------------------------------------------------------------------------

class TestSetupSingleCompliance:
    """Selecting a single compliance framework."""

    def test_hipaa_selected(self, capsys):
        """Selection 3 → HIPAA framework, hipaa_aligned preset."""
        with tempfile.TemporaryDirectory() as tmp:
            # org, owner, zone, compliance=3 (HIPAA), severity=1, org-gov=2 (no)
            inputs = ["Acme Corp", "admin@acme.com", "global", "3", "1", "2"]
            config = _run_setup(tmp, inputs, capsys)

            assert config["compliance_frameworks"] == ["HIPAA"]
            assert config["compliance_presets"] == ["hipaa_aligned"]

    def test_soc2_selected(self, capsys):
        """Selection 2 → SOC2 framework, soc2_aligned preset."""
        with tempfile.TemporaryDirectory() as tmp:
            inputs = ["Acme Corp", "admin@acme.com", "global", "2", "1", "2"]
            config = _run_setup(tmp, inputs, capsys)

            assert config["compliance_frameworks"] == ["SOC2"]
            assert config["compliance_presets"] == ["soc2_aligned"]

    def test_pci_dss_selected(self, capsys):
        """Selection 4 → PCI-DSS framework, pci_dss_aligned preset."""
        with tempfile.TemporaryDirectory() as tmp:
            inputs = ["Acme Corp", "admin@acme.com", "global", "4", "1", "2"]
            config = _run_setup(tmp, inputs, capsys)

            assert config["compliance_frameworks"] == ["PCI-DSS"]
            assert config["compliance_presets"] == ["pci_dss_aligned"]

    def test_iso27001_selected(self, capsys):
        """Selection 5 → ISO27001 framework, iso27001_aligned preset."""
        with tempfile.TemporaryDirectory() as tmp:
            inputs = ["Acme Corp", "admin@acme.com", "global", "5", "1", "2"]
            config = _run_setup(tmp, inputs, capsys)

            assert config["compliance_frameworks"] == ["ISO27001"]
            assert config["compliance_presets"] == ["iso27001_aligned"]

    def test_hipaa_output_shows_preset_in_summary(self, capsys):
        """Output shows HIPAA with hipaa_aligned preset in summary."""
        with tempfile.TemporaryDirectory() as tmp:
            inputs = ["Acme Corp", "admin@acme.com", "global", "3", "1", "2"]
            _run_setup(tmp, inputs, capsys)
            captured = capsys.readouterr()

            assert "HIPAA" in captured.out
            assert "hipaa_aligned" in captured.out
            assert "Setup complete" in captured.out


# ---------------------------------------------------------------------------
# Tests: Severity levels
# ---------------------------------------------------------------------------

class TestSetupSeverity:
    """Selecting different severity levels."""

    def test_strict_severity(self, capsys):
        """Selection 2 → strict preset."""
        with tempfile.TemporaryDirectory() as tmp:
            # org, owner, zone, compliance=1, severity=2
            inputs = ["Acme Corp", "admin@acme.com", "global", "1", "2"]
            config = _run_setup(tmp, inputs, capsys)

            assert config["default_preset"] == "strict"

    def test_ultra_strict_severity(self, capsys):
        """Selection 3 → ultra_strict preset."""
        with tempfile.TemporaryDirectory() as tmp:
            inputs = ["Acme Corp", "admin@acme.com", "global", "1", "3"]
            config = _run_setup(tmp, inputs, capsys)

            assert config["default_preset"] == "ultra_strict"

    def test_strict_shown_in_summary(self, capsys):
        """Strict severity shown in completion output."""
        with tempfile.TemporaryDirectory() as tmp:
            inputs = ["Acme Corp", "admin@acme.com", "global", "1", "2"]
            _run_setup(tmp, inputs, capsys)
            captured = capsys.readouterr()

            assert "strict" in captured.out


# ---------------------------------------------------------------------------
# Tests: Org governance generation
# ---------------------------------------------------------------------------

class TestSetupOrgGovernance:
    """Org governance creation step."""

    def test_org_governance_yes_creates_file(self, capsys):
        """Selecting yes for org governance creates org-governance.yaml."""
        with tempfile.TemporaryDirectory() as tmp:
            # org, owner, zone, compliance=3 (HIPAA), severity=2, org-gov=1 (yes)
            inputs = ["Acme Corp", "admin@acme.com", "global", "3", "2", "1"]
            config = _run_setup(tmp, inputs, capsys)

            org_gov_path = Path(tmp) / "org-governance.yaml"
            assert org_gov_path.exists(), "org-governance.yaml not created"

            # Verify it's loadable
            org_config = load_org_config(org_gov_path)
            assert org_config is not None
            assert org_config.org_name == "acme-corp"

    def test_org_governance_no_skips_file(self, capsys):
        """Selecting no for org governance does not create org-governance.yaml."""
        with tempfile.TemporaryDirectory() as tmp:
            # org, owner, zone, compliance=3 (HIPAA), severity=2, org-gov=2 (no)
            inputs = ["Acme Corp", "admin@acme.com", "global", "3", "2", "2"]
            _run_setup(tmp, inputs, capsys)

            org_gov_path = Path(tmp) / "org-governance.yaml"
            assert not org_gov_path.exists(), "org-governance.yaml should not be created"

    def test_org_governance_default_no(self, capsys):
        """Default for org governance is no (selection 2)."""
        with tempfile.TemporaryDirectory() as tmp:
            # org, owner, zone, compliance=3 (HIPAA), severity=1, org-gov="" (default=2)
            inputs = ["Acme Corp", "admin@acme.com", "global", "3", "1", ""]
            _run_setup(tmp, inputs, capsys)

            org_gov_path = Path(tmp) / "org-governance.yaml"
            assert not org_gov_path.exists()

    def test_org_governance_shows_disclaimer(self, capsys):
        """Generating org governance shows appropriate disclaimer."""
        with tempfile.TemporaryDirectory() as tmp:
            inputs = ["Acme Corp", "admin@acme.com", "global", "3", "1", "1"]
            _run_setup(tmp, inputs, capsys)
            captured = capsys.readouterr()

            assert "hipaa_aligned preset" in captured.out
            assert "HIPAA concerns" in captured.out
            assert "does not constitute" in captured.out

    def test_org_governance_not_asked_without_compliance(self, capsys):
        """Org governance step is skipped when no compliance is selected."""
        with tempfile.TemporaryDirectory() as tmp:
            # Only 5 inputs needed: org, owner, zone, compliance=1, severity=1
            # No org governance question should be asked
            inputs = ["Acme Corp", "admin@acme.com", "global", "1", "1"]
            _run_setup(tmp, inputs, capsys)

            org_gov_path = Path(tmp) / "org-governance.yaml"
            assert not org_gov_path.exists()

    def test_org_governance_yaml_loadable(self, capsys):
        """Generated org-governance.yaml can be loaded by load_org_config."""
        with tempfile.TemporaryDirectory() as tmp:
            inputs = ["Acme Corp", "admin@acme.com", "global", "3", "2", "1"]
            _run_setup(tmp, inputs, capsys)

            org_gov_path = Path(tmp) / "org-governance.yaml"
            org_config = load_org_config(org_gov_path)
            assert org_config is not None
            assert org_config.minimum_allow_threshold > 0
            assert len(org_config.required_vetoes) > 0
            assert len(org_config.minimum_weights) > 0

    def test_org_governance_output_shows_checkmark(self, capsys):
        """Summary shows checkmark for generated org governance."""
        with tempfile.TemporaryDirectory() as tmp:
            inputs = ["Acme Corp", "admin@acme.com", "global", "3", "1", "1"]
            _run_setup(tmp, inputs, capsys)
            captured = capsys.readouterr()

            assert "Org governance:" in captured.out
            assert "\u2713" in captured.out


# ---------------------------------------------------------------------------
# Tests: Multiple frameworks
# ---------------------------------------------------------------------------

class TestSetupMultipleFrameworks:
    """Selecting multiple compliance frameworks."""

    def test_multiple_frameworks_stored(self, capsys):
        """Selection 6 → multiple frameworks, both stored in config."""
        with tempfile.TemporaryDirectory() as tmp:
            # org, owner, zone, compliance=6, multi-select=1,2 (SOC2+HIPAA),
            # severity=1, org-gov=2 (no)
            inputs = ["Acme Corp", "admin@acme.com", "global", "6", "1,2", "1", "2"]
            config = _run_setup(tmp, inputs, capsys)

            assert config["compliance_frameworks"] == ["SOC2", "HIPAA"]
            assert config["compliance_presets"] == ["soc2_aligned", "hipaa_aligned"]

    def test_multiple_all_four(self, capsys):
        """Selecting all four frameworks."""
        with tempfile.TemporaryDirectory() as tmp:
            inputs = ["Acme Corp", "admin@acme.com", "global", "6", "1,2,3,4", "1", "2"]
            config = _run_setup(tmp, inputs, capsys)

            assert len(config["compliance_frameworks"]) == 4
            assert "SOC2" in config["compliance_frameworks"]
            assert "HIPAA" in config["compliance_frameworks"]
            assert "PCI-DSS" in config["compliance_frameworks"]
            assert "ISO27001" in config["compliance_frameworks"]
            assert len(config["compliance_presets"]) == 4

    def test_multiple_with_org_governance(self, capsys):
        """Multiple frameworks with org governance generates merged config."""
        with tempfile.TemporaryDirectory() as tmp:
            # org, owner, zone, compliance=6, multi=1,2, severity=2, org-gov=1
            inputs = ["Acme Corp", "admin@acme.com", "global", "6", "1,2", "2", "1"]
            _run_setup(tmp, inputs, capsys)

            org_gov_path = Path(tmp) / "org-governance.yaml"
            assert org_gov_path.exists()

            org_config = load_org_config(org_gov_path)
            assert org_config is not None
            assert org_config.org_name == "acme-corp"


# ---------------------------------------------------------------------------
# Tests: Re-running setup shows previous selections as defaults
# ---------------------------------------------------------------------------

class TestSetupRerun:
    """Re-running setup preserves and shows previous settings."""

    def test_rerun_preserves_compliance(self, capsys):
        """Re-running setup with HIPAA config shows 3 as default."""
        with tempfile.TemporaryDirectory() as tmp:
            _write_existing_config(tmp, extra={
                "compliance_frameworks": ["HIPAA"],
                "compliance_presets": ["hipaa_aligned"],
                "default_preset": "strict",
            })
            # Accept all defaults (empty inputs)
            # org="", owner="", zone="", compliance="" (default=3), severity="" (default=2),
            # org-gov="" (default=2, no)
            inputs = ["", "", "", "", "", ""]
            config = _run_setup(tmp, inputs, capsys)

            assert config["compliance_frameworks"] == ["HIPAA"]
            assert config["compliance_presets"] == ["hipaa_aligned"]
            assert config["default_preset"] == "strict"

    def test_rerun_preserves_multiple_frameworks(self, capsys):
        """Re-running setup with multiple frameworks defaults to selection 6."""
        with tempfile.TemporaryDirectory() as tmp:
            _write_existing_config(tmp, extra={
                "compliance_frameworks": ["SOC2", "HIPAA"],
                "compliance_presets": ["soc2_aligned", "hipaa_aligned"],
                "default_preset": "standard",
            })
            # Accept all defaults
            inputs = ["", "", "", "", "", "", ""]
            config = _run_setup(tmp, inputs, capsys)

            assert config["compliance_frameworks"] == ["SOC2", "HIPAA"]
            assert config["compliance_presets"] == ["soc2_aligned", "hipaa_aligned"]

    def test_rerun_shows_org_owner_zone_defaults(self, capsys):
        """Re-running setup shows existing org/owner/zone as defaults."""
        with tempfile.TemporaryDirectory() as tmp:
            _write_existing_config(tmp)
            # All empty inputs to accept defaults, no compliance
            inputs = ["", "", "", "", ""]
            config = _run_setup(tmp, inputs, capsys)

            assert config["organization"] == "acme-corp"
            assert config["owner"] == "admin@acme.com"
            assert config["default_zone"] == "global"

    def test_rerun_preserves_retention(self, capsys):
        """Re-running setup preserves existing retention and enforce_unique_names."""
        with tempfile.TemporaryDirectory() as tmp:
            _write_existing_config(tmp, extra={
                "retention": "10y",
                "enforce_unique_names": True,
            })
            inputs = ["", "", "", "", ""]
            config = _run_setup(tmp, inputs, capsys)

            assert config["retention"] == "10y"
            assert config["enforce_unique_names"] is True


# ---------------------------------------------------------------------------
# Tests: Summary output
# ---------------------------------------------------------------------------

class TestSetupOutput:
    """Verify the completion output content."""

    def test_next_steps_in_output(self, capsys):
        """Output includes next steps with nomotic commands."""
        with tempfile.TemporaryDirectory() as tmp:
            inputs = ["Acme Corp", "admin@acme.com", "global", "1", "1"]
            _run_setup(tmp, inputs, capsys)
            captured = capsys.readouterr()

            assert "Next steps:" in captured.out
            assert "nomotic birth" in captured.out
            assert "nomotic validate" in captured.out
            assert "nomotic status" in captured.out

    def test_no_compliance_shows_none(self, capsys):
        """Output shows 'none' for compliance when no framework selected."""
        with tempfile.TemporaryDirectory() as tmp:
            inputs = ["Acme Corp", "admin@acme.com", "global", "1", "1"]
            _run_setup(tmp, inputs, capsys)
            captured = capsys.readouterr()

            assert "Compliance:     none" in captured.out

    def test_compliance_shows_framework_and_preset(self, capsys):
        """Output shows framework label and preset name."""
        with tempfile.TemporaryDirectory() as tmp:
            inputs = ["Acme Corp", "admin@acme.com", "global", "3", "2", "2"]
            _run_setup(tmp, inputs, capsys)
            captured = capsys.readouterr()

            assert "HIPAA" in captured.out
            assert "hipaa_aligned" in captured.out
