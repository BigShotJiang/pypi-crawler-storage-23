"""Tests for the AGICOMPLY integration adapter."""

from __future__ import annotations

import http.client
import io
import json
import os
import urllib.error
import urllib.request
from unittest import mock

import pytest

from nomotic.audit_store import PersistentLogRecord
from nomotic.integrations.agicomply import (
    AGICOMPLYClient,
    AGICOMPLYConfig,
    AGICOMPLYError,
    _build_payload,
)


# ── Helpers ──────────────────────────────────────────────────────────────


def _make_record(**overrides) -> PersistentLogRecord:
    """Build a PersistentLogRecord with sensible defaults."""
    defaults = dict(
        record_id="rec-001",
        timestamp=1700000000.0,  # 2023-11-14T22:13:20Z
        agent_id="TestBot",
        action_type="read",
        action_target="customer_db",
        verdict="ALLOW",
        ucs=0.85,
        tier=2,
        trust_score=0.75,
        trust_delta=0.02,
        trust_trend="rising",
        severity="info",
        justification="Low risk read operation",
        vetoed_by=[],
        dimension_scores={"safety": 0.9, "privacy": 0.8},
        previous_hash="abc123",
        record_hash="def456",
    )
    defaults.update(overrides)
    return PersistentLogRecord(**defaults)


def _mock_urlopen(response_body=None, status=200):
    """Create a mock for urllib.request.urlopen that returns a given body."""
    if response_body is None:
        response_body = {"status": "accepted", "id": "ac-12345"}
    body_bytes = json.dumps(response_body).encode("utf-8")
    mock_resp = mock.MagicMock()
    mock_resp.read.return_value = body_bytes
    mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
    mock_resp.__exit__ = mock.MagicMock(return_value=False)
    mock_resp.status = status
    return mock_resp


# ── Payload transform tests ─────────────────────────────────────────────


class TestBuildPayload:
    """Tests for _build_payload transform."""

    def test_allow_verdict(self):
        record = _make_record(verdict="ALLOW")
        payload = _build_payload(record, "sys-uuid-1")
        assert payload["governance_verdict"]["decision"] == "ALLOW"

    def test_deny_verdict(self):
        record = _make_record(verdict="DENY")
        payload = _build_payload(record, "sys-uuid-1")
        assert payload["governance_verdict"]["decision"] == "DENY"

    def test_escalate_verdict(self):
        record = _make_record(verdict="ESCALATE")
        payload = _build_payload(record, "sys-uuid-1")
        assert payload["governance_verdict"]["decision"] == "ESCALATE"

    def test_dimension_scores_passed_through(self):
        scores = {"safety": 0.95, "privacy": 0.6, "fairness": 0.88}
        record = _make_record(dimension_scores=scores)
        payload = _build_payload(record, "sys-uuid-1")
        assert payload["governance_verdict"]["dimensions"] == scores

    def test_veto_triggered_true(self):
        record = _make_record(vetoed_by=["safety", "privacy"])
        payload = _build_payload(record, "sys-uuid-1")
        assert payload["governance_verdict"]["veto_triggered"] is True
        assert payload["governance_verdict"]["vetoed_by"] == ["safety", "privacy"]

    def test_veto_triggered_false(self):
        record = _make_record(vetoed_by=[])
        payload = _build_payload(record, "sys-uuid-1")
        assert payload["governance_verdict"]["veto_triggered"] is False
        assert payload["governance_verdict"]["vetoed_by"] == []

    def test_trust_delta_calculation(self):
        record = _make_record(trust_score=0.75, trust_delta=0.02)
        payload = _build_payload(record, "sys-uuid-1")
        ts = payload["trust_state"]
        assert ts["updated_score"] == 0.75
        assert ts["delta"] == 0.02
        assert ts["previous_score"] == round(0.75 - 0.02, 4)
        assert ts["trend"] == "rising"

    def test_timestamp_iso_format(self):
        # 2023-11-14T22:13:20Z
        record = _make_record(timestamp=1700000000.0)
        payload = _build_payload(record, "sys-uuid-1")
        assert payload["timestamp"] == "2023-11-14T22:13:20Z"

    def test_hash_chain_fields_present(self):
        record = _make_record(
            record_id="rec-xyz",
            record_hash="hash-current",
            previous_hash="hash-prev",
        )
        payload = _build_payload(record, "sys-uuid-1")
        hc = payload["hash_chain"]
        assert hc["record_id"] == "rec-xyz"
        assert hc["record_hash"] == "hash-current"
        assert hc["previous_hash"] == "hash-prev"

    def test_source_and_system_id(self):
        record = _make_record()
        payload = _build_payload(record, "my-system-uuid")
        assert payload["source"] == "nomotic"
        assert payload["system_id"] == "my-system-uuid"
        assert payload["artifact_type"] == "runtime_governance_log"

    def test_action_fields(self):
        record = _make_record(action_type="write", action_target="logs_table")
        payload = _build_payload(record, "sys-uuid-1")
        assert payload["action"]["type"] == "write"
        assert payload["action"]["target"] == "logs_table"

    def test_agent_id_and_metadata(self):
        record = _make_record(
            agent_id="MyAgent",
            severity="alert",
            justification="High risk detected",
        )
        payload = _build_payload(record, "sys-uuid-1")
        assert payload["agent_id"] == "MyAgent"
        assert payload["severity"] == "alert"
        assert payload["justification"] == "High risk detected"


# ── AGICOMPLYClient.push_record tests ───────────────────────────────────


class TestPushRecord:
    """Tests for AGICOMPLYClient.push_record with mocked HTTP."""

    def _make_client(self, **config_overrides):
        defaults = dict(
            api_url="https://api.agicomply.com",
            api_token="test-token-123",
            system_id="sys-uuid-1",
        )
        defaults.update(config_overrides)
        return AGICOMPLYClient(AGICOMPLYConfig(**defaults))

    @mock.patch("nomotic.integrations.agicomply.urllib.request.urlopen")
    def test_successful_push(self, mock_urlopen_fn):
        mock_urlopen_fn.return_value = _mock_urlopen({"status": "accepted"})
        client = self._make_client()
        result = client.push_record(_make_record())
        assert result == {"status": "accepted"}

    @mock.patch("nomotic.integrations.agicomply.urllib.request.urlopen")
    def test_authorization_header(self, mock_urlopen_fn):
        mock_urlopen_fn.return_value = _mock_urlopen()
        client = self._make_client(api_token="my-secret-token")
        client.push_record(_make_record())
        req = mock_urlopen_fn.call_args[0][0]
        assert req.get_header("Authorization") == "Bearer my-secret-token"

    @mock.patch("nomotic.integrations.agicomply.urllib.request.urlopen")
    def test_content_type_header(self, mock_urlopen_fn):
        mock_urlopen_fn.return_value = _mock_urlopen()
        client = self._make_client()
        client.push_record(_make_record())
        req = mock_urlopen_fn.call_args[0][0]
        assert req.get_header("Content-type") == "application/json"

    @mock.patch("nomotic.integrations.agicomply.urllib.request.urlopen")
    def test_user_agent_header(self, mock_urlopen_fn):
        mock_urlopen_fn.return_value = _mock_urlopen()
        client = self._make_client()
        client.push_record(_make_record())
        req = mock_urlopen_fn.call_args[0][0]
        import nomotic

        assert req.get_header("User-agent") == f"nomotic/{nomotic.__version__}"

    @mock.patch("nomotic.integrations.agicomply.urllib.request.urlopen")
    def test_posts_to_correct_url(self, mock_urlopen_fn):
        mock_urlopen_fn.return_value = _mock_urlopen()
        client = self._make_client(
            api_url="https://sandbox.agicomply.com",
            endpoint="/api/v2/ingest",
        )
        client.push_record(_make_record())
        req = mock_urlopen_fn.call_args[0][0]
        assert req.full_url == "https://sandbox.agicomply.com/api/v2/ingest"

    @mock.patch("nomotic.integrations.agicomply.urllib.request.urlopen")
    def test_http_error_raises_agicomply_error(self, mock_urlopen_fn):
        mock_urlopen_fn.side_effect = urllib.error.HTTPError(
            url="https://api.agicomply.com/api/runtime-governance/ingest",
            code=500,
            msg="Internal Server Error",
            hdrs=http.client.HTTPMessage(),
            fp=io.BytesIO(b""),
        )
        client = self._make_client()
        with pytest.raises(AGICOMPLYError, match="Push failed"):
            client.push_record(_make_record())

    @mock.patch("nomotic.integrations.agicomply.urllib.request.urlopen")
    def test_timeout_raises_agicomply_error(self, mock_urlopen_fn):
        mock_urlopen_fn.side_effect = TimeoutError("timed out")
        client = self._make_client()
        with pytest.raises(AGICOMPLYError, match="Push failed"):
            client.push_record(_make_record())

    @mock.patch("nomotic.integrations.agicomply.urllib.request.urlopen")
    def test_payload_is_valid_json(self, mock_urlopen_fn):
        mock_urlopen_fn.return_value = _mock_urlopen()
        client = self._make_client()
        client.push_record(_make_record())
        req = mock_urlopen_fn.call_args[0][0]
        payload = json.loads(req.data.decode("utf-8"))
        assert payload["source"] == "nomotic"
        assert payload["system_id"] == "sys-uuid-1"


# ── AGICOMPLYClient.push_records tests ──────────────────────────────────


class TestPushRecords:
    """Tests for AGICOMPLYClient.push_records batch method."""

    def _make_client(self):
        config = AGICOMPLYConfig(
            api_url="https://api.agicomply.com",
            api_token="tok",
            system_id="sys-1",
        )
        return AGICOMPLYClient(config)

    @mock.patch("nomotic.integrations.agicomply.urllib.request.urlopen")
    def test_all_delivered(self, mock_urlopen_fn):
        mock_urlopen_fn.return_value = _mock_urlopen()
        client = self._make_client()
        records = [_make_record(record_id=f"r-{i}") for i in range(3)]
        result = client.push_records(records)
        assert result["delivered"] == 3
        assert result["failed"] == 0
        assert result["errors"] == []

    @mock.patch("nomotic.integrations.agicomply.urllib.request.urlopen")
    def test_failed_records_counted(self, mock_urlopen_fn):
        # Second call fails
        mock_urlopen_fn.side_effect = [
            _mock_urlopen(),
            urllib.error.URLError("connection refused"),
            _mock_urlopen(),
        ]
        client = self._make_client()
        records = [_make_record(record_id=f"r-{i}") for i in range(3)]
        result = client.push_records(records)
        assert result["delivered"] == 2
        assert result["failed"] == 1
        assert len(result["errors"]) == 1

    @mock.patch("nomotic.integrations.agicomply.urllib.request.urlopen")
    def test_stop_on_error_true(self, mock_urlopen_fn):
        mock_urlopen_fn.side_effect = [
            _mock_urlopen(),
            urllib.error.URLError("fail"),
            _mock_urlopen(),  # should not be reached
        ]
        client = self._make_client()
        records = [_make_record(record_id=f"r-{i}") for i in range(3)]
        result = client.push_records(records, stop_on_error=True)
        assert result["delivered"] == 1
        assert result["failed"] == 1
        # Third record was never attempted
        assert mock_urlopen_fn.call_count == 2

    @mock.patch("nomotic.integrations.agicomply.urllib.request.urlopen")
    def test_stop_on_error_false_continues(self, mock_urlopen_fn):
        mock_urlopen_fn.side_effect = [
            urllib.error.URLError("fail"),
            _mock_urlopen(),
            _mock_urlopen(),
        ]
        client = self._make_client()
        records = [_make_record(record_id=f"r-{i}") for i in range(3)]
        result = client.push_records(records, stop_on_error=False)
        assert result["delivered"] == 2
        assert result["failed"] == 1
        assert mock_urlopen_fn.call_count == 3

    @mock.patch("nomotic.integrations.agicomply.urllib.request.urlopen")
    def test_returns_correct_summary_dict(self, mock_urlopen_fn):
        mock_urlopen_fn.return_value = _mock_urlopen()
        client = self._make_client()
        records = [_make_record(record_id=f"r-{i}") for i in range(2)]
        result = client.push_records(records)
        assert set(result.keys()) == {"delivered", "failed", "errors"}
        assert isinstance(result["delivered"], int)
        assert isinstance(result["failed"], int)
        assert isinstance(result["errors"], list)


# ── AGICOMPLYConfig.from_env tests ──────────────────────────────────────


class TestConfigFromEnv:
    """Tests for AGICOMPLYConfig.from_env loading from environment."""

    def test_loads_from_env(self):
        env = {
            "AGICOMPLY_API_URL": "https://api.agicomply.com",
            "AGICOMPLY_API_TOKEN": "tok-123",
            "AGICOMPLY_SYSTEM_ID": "uuid-abc",
        }
        with mock.patch.dict(os.environ, env, clear=False):
            config = AGICOMPLYConfig.from_env()
        assert config.api_url == "https://api.agicomply.com"
        assert config.api_token == "tok-123"
        assert config.system_id == "uuid-abc"

    def test_missing_url_raises(self):
        env = {
            "AGICOMPLY_API_TOKEN": "tok",
            "AGICOMPLY_SYSTEM_ID": "uuid",
        }
        with mock.patch.dict(os.environ, env, clear=True):
            with pytest.raises(ValueError, match="AGICOMPLY_API_URL"):
                AGICOMPLYConfig.from_env()

    def test_missing_token_raises(self):
        env = {
            "AGICOMPLY_API_URL": "https://api.agicomply.com",
            "AGICOMPLY_SYSTEM_ID": "uuid",
        }
        with mock.patch.dict(os.environ, env, clear=True):
            with pytest.raises(ValueError, match="AGICOMPLY_API_TOKEN"):
                AGICOMPLYConfig.from_env()

    def test_missing_system_id_raises(self):
        env = {
            "AGICOMPLY_API_URL": "https://api.agicomply.com",
            "AGICOMPLY_API_TOKEN": "tok",
        }
        with mock.patch.dict(os.environ, env, clear=True):
            with pytest.raises(ValueError, match="AGICOMPLY_SYSTEM_ID"):
                AGICOMPLYConfig.from_env()

    def test_trailing_slash_stripped(self):
        env = {
            "AGICOMPLY_API_URL": "https://api.agicomply.com/",
            "AGICOMPLY_API_TOKEN": "tok",
            "AGICOMPLY_SYSTEM_ID": "uuid",
        }
        with mock.patch.dict(os.environ, env, clear=False):
            config = AGICOMPLYConfig.from_env()
        assert config.api_url == "https://api.agicomply.com"


# ── Integration smoke test ──────────────────────────────────────────────


class TestIntegrationSmoke:
    """End-to-end payload validation with a real PersistentLogRecord."""

    def test_full_record_produces_valid_payload(self):
        record = PersistentLogRecord(
            record_id="smoke-001",
            timestamp=1700000000.0,
            agent_id="SmokeAgent",
            action_type="execute",
            action_target="deploy_pipeline",
            verdict="DENY",
            ucs=0.35,
            tier=3,
            trust_score=0.42,
            trust_delta=-0.08,
            trust_trend="declining",
            severity="alert",
            justification="Action exceeds risk tolerance for deployment",
            vetoed_by=["safety", "reversibility"],
            dimension_scores={
                "safety": 0.3,
                "privacy": 0.7,
                "fairness": 0.6,
                "reversibility": 0.2,
            },
            previous_hash="aaa111",
            record_hash="bbb222",
        )
        payload = _build_payload(record, "smoke-system-uuid")

        # All required top-level keys present
        required_keys = {
            "source",
            "system_id",
            "artifact_type",
            "timestamp",
            "action",
            "governance_verdict",
            "trust_state",
            "hash_chain",
            "agent_id",
            "severity",
            "justification",
        }
        assert required_keys.issubset(payload.keys())

        # Action sub-keys
        assert "type" in payload["action"]
        assert "target" in payload["action"]

        # Governance verdict sub-keys
        gv = payload["governance_verdict"]
        assert "decision" in gv
        assert "ucs_score" in gv
        assert "dimensions" in gv
        assert "veto_triggered" in gv
        assert "vetoed_by" in gv
        assert gv["decision"] == "DENY"
        assert gv["veto_triggered"] is True

        # Trust state sub-keys
        ts = payload["trust_state"]
        assert "previous_score" in ts
        assert "updated_score" in ts
        assert "delta" in ts
        assert "trend" in ts
        assert ts["updated_score"] == 0.42
        assert ts["delta"] == -0.08
        assert ts["previous_score"] == round(0.42 - (-0.08), 4)  # 0.5

        # Hash chain sub-keys
        hc = payload["hash_chain"]
        assert hc["record_id"] == "smoke-001"
        assert hc["record_hash"] == "bbb222"
        assert hc["previous_hash"] == "aaa111"

        # Serializable as JSON
        serialized = json.dumps(payload)
        assert isinstance(serialized, str)
        roundtrip = json.loads(serialized)
        assert roundtrip == payload
