"""Tests for Immutable Pre-Execution Record (Item 18)."""

import json
import threading
import time

import pytest

from nomotic.pre_execution import (
    ExecutionOutcome,
    ExecutionSettlementRecord,
    PreExecutionLedger,
    PreExecutionRecord,
)
from nomotic.runtime import GovernanceRuntime, RuntimeConfig
from nomotic.types import Action, AgentContext, TrustProfile, Verdict


# ── Helpers ────────────────────────────────────────────────────────────


def _ctx(agent_id: str = "agent-1", trust: float = 0.5) -> AgentContext:
    return AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id, overall_trust=trust),
    )


def _action(
    agent_id: str = "agent-1",
    action_type: str = "read",
    target: str = "db",
    metadata: dict | None = None,
) -> Action:
    return Action(
        agent_id=agent_id,
        action_type=action_type,
        target=target,
        metadata=metadata or {},
    )


# ── Unit tests: PreExecutionRecord ────────────────────────────────────


def test_write_pre_execution_creates_record(tmp_path):
    """Writing a pre-execution record returns a properly populated record."""
    ledger = PreExecutionLedger(tmp_path)
    record = ledger.write_pre_execution(
        agent_id="agent-1",
        action_id="act-001",
        action_type="read",
        action_target="database",
    )
    assert record.record_id.startswith("nmpe-")
    assert record.agent_id == "agent-1"
    assert record.action_id == "act-001"
    assert record.action_type == "read"
    assert record.action_target == "database"
    assert record.verdict == "ALLOW"
    assert record.record_written_at > 0


def test_pre_execution_record_hash_computed(tmp_path):
    """Record hash is computed and non-empty."""
    ledger = PreExecutionLedger(tmp_path)
    record = ledger.write_pre_execution(
        agent_id="agent-1",
        action_id="act-001",
        action_type="read",
        action_target="db",
    )
    assert record.record_hash.startswith("sha256:")
    assert len(record.record_hash) > 10
    # Hash should be reproducible
    assert record.compute_hash() == record.record_hash


def test_first_record_uses_genesis_hash(tmp_path):
    """First record for an agent links to the genesis hash."""
    import hashlib
    genesis = "sha256:" + hashlib.sha256(b"genesis").hexdigest()

    ledger = PreExecutionLedger(tmp_path)
    record = ledger.write_pre_execution(
        agent_id="agent-1",
        action_id="act-001",
        action_type="read",
        action_target="db",
    )
    assert record.previous_record_hash == genesis


def test_subsequent_record_links_previous(tmp_path):
    """Second record links to first record's hash."""
    ledger = PreExecutionLedger(tmp_path)
    r1 = ledger.write_pre_execution(
        agent_id="agent-1",
        action_id="act-001",
        action_type="read",
        action_target="db",
    )
    r2 = ledger.write_pre_execution(
        agent_id="agent-1",
        action_id="act-002",
        action_type="write",
        action_target="db",
    )
    assert r2.previous_record_hash == r1.record_hash
    assert r2.previous_record_hash != r1.previous_record_hash


def test_chain_integrity_valid(tmp_path):
    """Chain verification succeeds for a valid chain."""
    ledger = PreExecutionLedger(tmp_path)
    for i in range(5):
        ledger.write_pre_execution(
            agent_id="agent-1",
            action_id=f"act-{i:03d}",
            action_type="read",
            action_target="db",
        )
    valid, count, msg = ledger.verify_chain("agent-1")
    assert valid is True
    assert count == 5
    assert "verified" in msg.lower()


def test_chain_integrity_tampered_fails(tmp_path):
    """Chain verification detects tampering."""
    ledger = PreExecutionLedger(tmp_path)
    for i in range(3):
        ledger.write_pre_execution(
            agent_id="agent-1",
            action_id=f"act-{i:03d}",
            action_type="read",
            action_target="db",
        )

    # Tamper with the file: modify the second record
    path = ledger._records_file("agent-1")
    lines = path.read_text().strip().split("\n")
    data = json.loads(lines[1])
    data["action_type"] = "TAMPERED"
    lines[1] = json.dumps(data, separators=(",", ":"))
    path.write_text("\n".join(lines) + "\n")

    valid, count, msg = ledger.verify_chain("agent-1")
    assert valid is False
    assert "TAMPERING" in msg


def test_settle_creates_settlement_record(tmp_path):
    """Settling a pre-execution record creates a settlement."""
    ledger = PreExecutionLedger(tmp_path)
    ledger.write_pre_execution(
        agent_id="agent-1",
        action_id="act-001",
        action_type="read",
        action_target="db",
    )
    settlement = ledger.settle("act-001", ExecutionOutcome.SUCCESS)
    assert settlement.settlement_id.startswith("nmps-")
    assert settlement.action_id == "act-001"
    assert settlement.outcome == ExecutionOutcome.SUCCESS
    assert settlement.settled_at > 0


def test_settle_unknown_action_raises(tmp_path):
    """Settling an unknown action raises KeyError."""
    ledger = PreExecutionLedger(tmp_path)
    with pytest.raises(KeyError, match="No pre-execution record"):
        ledger.settle("nonexistent", ExecutionOutcome.SUCCESS)


def test_settle_already_settled_raises(tmp_path):
    """Double-settling raises RuntimeError."""
    ledger = PreExecutionLedger(tmp_path)
    ledger.write_pre_execution(
        agent_id="agent-1",
        action_id="act-001",
        action_type="read",
        action_target="db",
    )
    ledger.settle("act-001", ExecutionOutcome.SUCCESS)
    with pytest.raises(RuntimeError, match="already settled"):
        ledger.settle("act-001", ExecutionOutcome.FAILURE)


def test_get_unsettled_returns_pending(tmp_path):
    """Unsettled records are returned by get_unsettled."""
    ledger = PreExecutionLedger(tmp_path)
    ledger.write_pre_execution(
        agent_id="agent-1",
        action_id="act-001",
        action_type="read",
        action_target="db",
    )
    ledger.write_pre_execution(
        agent_id="agent-1",
        action_id="act-002",
        action_type="write",
        action_target="db",
    )
    unsettled = ledger.get_unsettled(agent_id="agent-1")
    assert len(unsettled) == 2


def test_get_unsettled_excludes_settled(tmp_path):
    """Settled records are not returned by get_unsettled."""
    ledger = PreExecutionLedger(tmp_path)
    ledger.write_pre_execution(
        agent_id="agent-1",
        action_id="act-001",
        action_type="read",
        action_target="db",
    )
    ledger.write_pre_execution(
        agent_id="agent-1",
        action_id="act-002",
        action_type="write",
        action_target="db",
    )
    ledger.settle("act-001", ExecutionOutcome.SUCCESS)
    unsettled = ledger.get_unsettled(agent_id="agent-1")
    assert len(unsettled) == 1
    assert unsettled[0].action_id == "act-002"


def test_get_record_by_action_id(tmp_path):
    """get_record retrieves a record by action_id."""
    ledger = PreExecutionLedger(tmp_path)
    ledger.write_pre_execution(
        agent_id="agent-1",
        action_id="act-001",
        action_type="read",
        action_target="db",
    )
    record = ledger.get_record("act-001")
    assert record is not None
    assert record.action_id == "act-001"
    assert record.action_type == "read"


def test_get_settlement_by_action_id(tmp_path):
    """get_settlement retrieves a settlement by action_id."""
    ledger = PreExecutionLedger(tmp_path)
    ledger.write_pre_execution(
        agent_id="agent-1",
        action_id="act-001",
        action_type="read",
        action_target="db",
    )
    ledger.settle("act-001", ExecutionOutcome.FAILURE, error_message="oops")
    settlement = ledger.get_settlement("act-001")
    assert settlement is not None
    assert settlement.outcome == ExecutionOutcome.FAILURE
    assert settlement.error_message == "oops"


def test_get_agent_records_limit(tmp_path):
    """get_agent_records respects limit parameter."""
    ledger = PreExecutionLedger(tmp_path)
    for i in range(10):
        ledger.write_pre_execution(
            agent_id="agent-1",
            action_id=f"act-{i:03d}",
            action_type="read",
            action_target="db",
        )
    records = ledger.get_agent_records("agent-1", limit=5)
    assert len(records) == 5
    # Should return the last 5 records
    assert records[0].action_id == "act-005"
    assert records[-1].action_id == "act-009"


def test_persistence_round_trip(tmp_path):
    """Records survive ledger re-creation (read from disk)."""
    ledger1 = PreExecutionLedger(tmp_path)
    ledger1.write_pre_execution(
        agent_id="agent-1",
        action_id="act-001",
        action_type="read",
        action_target="db",
        governance_seal_id="seal-abc",
    )
    ledger1.settle("act-001", ExecutionOutcome.SUCCESS, actual_cost_usd=0.05)

    # Create new ledger instance — reads from disk
    ledger2 = PreExecutionLedger(tmp_path)
    record = ledger2.get_record("act-001")
    assert record is not None
    assert record.action_id == "act-001"
    assert record.governance_seal_id == "seal-abc"

    settlement = ledger2.get_settlement("act-001")
    assert settlement is not None
    assert settlement.outcome == ExecutionOutcome.SUCCESS
    assert settlement.actual_cost_usd == 0.05


def test_thread_safety_concurrent_writes(tmp_path):
    """Concurrent writes from multiple threads don't corrupt data."""
    ledger = PreExecutionLedger(tmp_path)
    errors = []

    def writer(thread_id):
        try:
            for i in range(10):
                ledger.write_pre_execution(
                    agent_id="agent-1",
                    action_id=f"t{thread_id}-act-{i:03d}",
                    action_type="read",
                    action_target="db",
                )
        except Exception as e:
            errors.append(e)

    threads = [threading.Thread(target=writer, args=(t,)) for t in range(5)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert len(errors) == 0
    records = ledger.get_agent_records("agent-1", limit=100)
    assert len(records) == 50
    # Chain should still be valid
    valid, count, msg = ledger.verify_chain("agent-1")
    assert valid is True
    assert count == 50


def test_execution_outcome_enum_values():
    """ExecutionOutcome enum has expected values."""
    assert ExecutionOutcome.SUCCESS.value == "success"
    assert ExecutionOutcome.FAILURE.value == "failure"
    assert ExecutionOutcome.INTERRUPTED.value == "interrupted"
    assert ExecutionOutcome.TIMEOUT.value == "timeout"
    assert ExecutionOutcome.UNKNOWN.value == "unknown"


def test_settlement_record_hash_computed(tmp_path):
    """Settlement record hash is computed and reproducible."""
    ledger = PreExecutionLedger(tmp_path)
    ledger.write_pre_execution(
        agent_id="agent-1",
        action_id="act-001",
        action_type="read",
        action_target="db",
    )
    settlement = ledger.settle("act-001", ExecutionOutcome.SUCCESS)
    assert settlement.settlement_hash.startswith("sha256:")
    assert settlement.compute_hash() == settlement.settlement_hash


# ── Runtime integration tests ──────────────────────────────────────────


def test_runtime_pre_execution_disabled_by_default():
    """Pre-execution ledger is disabled by default."""
    runtime = GovernanceRuntime()
    assert runtime._pre_execution_ledger is None


def test_runtime_pre_execution_writes_on_begin(tmp_path):
    """Runtime writes pre-execution record during begin_execution."""
    config = RuntimeConfig(
        enable_pre_execution_ledger=True,
        pre_execution_base_dir=tmp_path,
    )
    runtime = GovernanceRuntime(config=config)
    assert runtime._pre_execution_ledger is not None

    action = _action()
    ctx = _ctx()

    # Evaluate to get a verdict stored
    verdict = runtime.evaluate(action, ctx)

    # Begin execution — this should write the pre-execution record
    handle = runtime.begin_execution(action, ctx)
    assert handle is not None

    # Verify record was written
    record = runtime._pre_execution_ledger.get_record(action.id)
    assert record is not None
    assert record.agent_id == "agent-1"
    assert record.verdict == "ALLOW"


def test_runtime_pre_execution_settles_on_completion(tmp_path):
    """Runtime settles pre-execution record on complete_execution."""
    config = RuntimeConfig(
        enable_pre_execution_ledger=True,
        pre_execution_base_dir=tmp_path,
    )
    runtime = GovernanceRuntime(config=config)

    action = _action()
    ctx = _ctx()

    verdict = runtime.evaluate(action, ctx)
    handle = runtime.begin_execution(action, ctx)
    runtime.complete_execution(action.id, ctx)

    settlement = runtime._pre_execution_ledger.get_settlement(action.id)
    assert settlement is not None
    assert settlement.outcome == ExecutionOutcome.SUCCESS


def test_runtime_pre_execution_settles_on_interrupt(tmp_path):
    """Runtime settles pre-execution record on interrupt."""
    config = RuntimeConfig(
        enable_pre_execution_ledger=True,
        pre_execution_base_dir=tmp_path,
    )
    runtime = GovernanceRuntime(config=config)

    action = _action()
    ctx = _ctx()

    verdict = runtime.evaluate(action, ctx)
    handle = runtime.begin_execution(action, ctx)
    runtime.interrupt_action(action.id, reason="test interrupt")

    settlement = runtime._pre_execution_ledger.get_settlement(action.id)
    assert settlement is not None
    assert settlement.outcome == ExecutionOutcome.INTERRUPTED
    assert settlement.error_message == "test interrupt"


def test_unsettled_visible_as_anomaly(tmp_path):
    """Unsettled pre-execution records are visible as anomalies."""
    config = RuntimeConfig(
        enable_pre_execution_ledger=True,
        pre_execution_base_dir=tmp_path,
    )
    runtime = GovernanceRuntime(config=config)

    # Create actions but don't complete them
    for i in range(3):
        action = _action(action_type=f"type-{i}", target=f"target-{i}")
        ctx = _ctx()
        runtime.evaluate(action, ctx)
        runtime.begin_execution(action, ctx)

    # All three should be unsettled
    unsettled = runtime._pre_execution_ledger.get_unsettled(agent_id="agent-1")
    assert len(unsettled) == 3


def test_verify_chain_empty_agent(tmp_path):
    """Verifying chain for non-existent agent returns valid with 0 records."""
    ledger = PreExecutionLedger(tmp_path)
    valid, count, msg = ledger.verify_chain("nonexistent-agent")
    assert valid is True
    assert count == 0


def test_pre_execution_record_round_trip():
    """PreExecutionRecord survives to_dict/from_dict round trip."""
    record = PreExecutionRecord(
        record_id="nmpe-test-123",
        agent_id="agent-1",
        action_id="act-001",
        action_type="read",
        action_target="database",
        verdict="ALLOW",
        governance_seal_id="seal-xyz",
        approved_at=1000.0,
        record_written_at=1000.1,
        previous_record_hash="sha256:abc",
        record_hash="sha256:def",
        context_profile_id="cp-123",
        estimated_cost_usd=0.05,
        budget_reservation_id="res-001",
        metadata={"key": "value"},
    )
    d = record.to_dict()
    restored = PreExecutionRecord.from_dict(d)
    assert restored.record_id == record.record_id
    assert restored.agent_id == record.agent_id
    assert restored.action_id == record.action_id
    assert restored.governance_seal_id == record.governance_seal_id
    assert restored.estimated_cost_usd == record.estimated_cost_usd
    assert restored.metadata == record.metadata
    assert restored.record_hash == record.record_hash
