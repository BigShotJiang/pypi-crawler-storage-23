"""Tests for the nomotic status CLI command (formerly 'settings')."""

import json
import tempfile
from pathlib import Path

import pytest

from nomotic.cli import main


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _write_config(tmp: str, org: str = "acme-corp", owner: str = "admin@acme.com",
                  zone: str = "global") -> None:
    """Write a minimal config.json to the temp base dir."""
    config = {
        "organization": org,
        "owner": owner,
        "default_zone": zone,
    }
    Path(tmp, "config.json").write_text(json.dumps(config), encoding="utf-8")


def _write_org_governance(tmp: str) -> None:
    """Write a sample org-governance.yaml to the temp base dir."""
    yaml_content = """\
org_name: "Acme Corp"

minimum_weights:
  scope_compliance: 1.5
  authority_verification: 1.5
  human_override: 2.0
  ethical_alignment: 2.0

required_vetoes:
  - scope_compliance
  - authority_verification
  - human_override

minimum_allow_threshold: 0.70
minimum_deny_threshold: 0.30

trust:
  minimum_violation_decrement: 0.05
  maximum_success_increment: 0.02
"""
    Path(tmp, "org-governance.yaml").write_text(yaml_content, encoding="utf-8")


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestStatusCommand:
    """Tests for 'nomotic status'."""

    def test_status_runs_without_org_config(self, capsys):
        """nomotic status runs without error when no org config exists."""
        with tempfile.TemporaryDirectory() as tmp:
            main(["--base-dir", tmp, "status"])
            captured = capsys.readouterr()
            assert "Nomotic Settings" in captured.out
            assert "Not configured" in captured.out

    def test_status_presets_lists_all_seven(self, capsys):
        """nomotic status --presets lists all 7 presets with correct categories."""
        main(["status", "--presets"])
        captured = capsys.readouterr()
        assert "Available Presets" in captured.out
        # Compliance presets
        assert "soc2_aligned" in captured.out
        assert "hipaa_aligned" in captured.out
        assert "pci_dss_aligned" in captured.out
        assert "iso27001_aligned" in captured.out
        # Severity tiers
        assert "standard" in captured.out
        assert "strict" in captured.out
        assert "ultra_strict" in captured.out
        # Category headings
        assert "Compliance-Aligned:" in captured.out
        assert "Severity Tiers:" in captured.out

    def test_status_presets_includes_disclaimer(self, capsys):
        """nomotic status --presets includes disclaimer under compliance-aligned section."""
        main(["status", "--presets"])
        captured = capsys.readouterr()
        assert "do not constitute compliance" in captured.out

    def test_status_preset_hipaa_shows_details_with_disclaimer(self, capsys):
        """nomotic status --preset hipaa_aligned shows all details with disclaimer."""
        main(["status", "--preset", "hipaa_aligned"])
        captured = capsys.readouterr()
        # Header
        assert "Preset: hipaa_aligned" in captured.out
        assert "HIPAA-Aligned" in captured.out
        assert "HIPAA" in captured.out
        assert "aligned, not certified" in captured.out
        assert "compliance" in captured.out
        # Disclaimer present
        assert "does not constitute" in captured.out
        assert "compliance team" in captured.out
        # Dimension weights
        assert "scope_compliance:" in captured.out
        assert "2.0" in captured.out
        assert "ethical_alignment:" in captured.out
        # Veto dimensions
        assert "Veto Dimensions:" in captured.out
        assert "isolation_integrity" in captured.out
        # Thresholds
        assert "Allow:" in captured.out
        assert "Deny:" in captured.out
        # Trust settings
        assert "Success increment:" in captured.out
        assert "Violation decrement:" in captured.out

    def test_status_preset_strict_no_disclaimer(self, capsys):
        """nomotic status --preset strict shows details WITHOUT disclaimer."""
        main(["status", "--preset", "strict"])
        captured = capsys.readouterr()
        assert "Preset: strict" in captured.out
        assert "severity" in captured.out
        # No disclaimer for severity presets
        assert "does not constitute" not in captured.out
        assert "compliance team" not in captured.out
        # Still has all other sections
        assert "Dimension Weights:" in captured.out
        assert "Thresholds:" in captured.out
        assert "Trust:" in captured.out

    def test_status_preset_invalid_suggests_correction(self, capsys):
        """nomotic status --preset HIPAA gives error suggesting hipaa_aligned."""
        with pytest.raises(SystemExit):
            main(["status", "--preset", "HIPAA"])
        captured = capsys.readouterr()
        assert "Unknown preset 'HIPAA'" in captured.out
        assert "hipaa_aligned" in captured.out
        assert "Available presets:" in captured.out

    def test_status_org_shows_config_when_present(self, capsys):
        """nomotic status --org shows org config when present."""
        with tempfile.TemporaryDirectory() as tmp:
            _write_org_governance(tmp)
            main(["--base-dir", tmp, "status", "--org"])
            captured = capsys.readouterr()
            assert "Org Governance:" in captured.out
            assert "Acme Corp" in captured.out
            assert "scope_compliance:" in captured.out
            assert "1.5" in captured.out
            assert "Required Vetoes:" in captured.out
            assert "Min Allow Threshold:" in captured.out
            assert "Min Deny Threshold:" in captured.out
            assert "Min Violation Cost:" in captured.out
            assert "Max Success Incr:" in captured.out

    def test_status_org_shows_not_configured_when_absent(self, capsys):
        """nomotic status --org shows 'not configured' when absent."""
        with tempfile.TemporaryDirectory() as tmp:
            main(["--base-dir", tmp, "status", "--org"])
            captured = capsys.readouterr()
            assert "Org Governance:" in captured.out
            assert "Not configured" in captured.out

    def test_status_full_with_org_config(self, capsys):
        """nomotic status shows all sections when org config is present."""
        with tempfile.TemporaryDirectory() as tmp:
            _write_config(tmp)
            _write_org_governance(tmp)
            main(["--base-dir", tmp, "status"])
            captured = capsys.readouterr()
            # Installation section
            assert "Installation:" in captured.out
            assert "acme-corp" in captured.out
            assert "admin@acme.com" in captured.out
            assert "global" in captured.out
            # Org section
            assert "Org Governance:" in captured.out
            assert "Acme Corp" in captured.out
            # Presets summary
            assert "Available Presets:" in captured.out
            assert "soc2_aligned" in captured.out

    def test_status_preset_completely_unknown(self, capsys):
        """nomotic status --preset xyz gives error with available list."""
        with pytest.raises(SystemExit):
            main(["status", "--preset", "xyz"])
        captured = capsys.readouterr()
        assert "Unknown preset 'xyz'" in captured.out
        assert "Available presets:" in captured.out
