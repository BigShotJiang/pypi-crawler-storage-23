"""Integration tests for UAHS auto-integration in GovernanceRuntime."""

from __future__ import annotations

import tempfile
import time
from pathlib import Path
from unittest import TestCase
from unittest.mock import patch

from nomotic.audit_store import GovernanceHealthStore
from nomotic.drift import (
    AmbiguityDriftConfig,
    AmbiguityDriftProfile,
    UnifiedAgentHealthScore,
    UnifiedHealthScoreCalculator,
)
from nomotic.runtime import GovernanceRuntime, RuntimeConfig
from nomotic.types import (
    Action,
    AgentContext,
    TrustProfile,
    UAHSConfig,
    Verdict,
)
from nomotic.ucs_tracker import UCSTracker


def _action(
    agent_id: str = "bot",
    action_type: str = "read",
    target: str = "data",
) -> Action:
    return Action(
        agent_id=agent_id,
        action_type=action_type,
        target=target,
        timestamp=time.time(),
    )


def _ctx(agent_id: str = "bot") -> AgentContext:
    return AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id),
    )


def _runtime_with_scope(
    agent_id: str = "bot",
    enable_uahs: bool = False,
    uahs_config: UAHSConfig | None = None,
) -> GovernanceRuntime:
    """Create a runtime with scope configured for an agent."""
    rt = GovernanceRuntime(
        enable_uahs=enable_uahs,
        uahs_config=uahs_config,
    )
    scope = rt.registry.get("scope_compliance")
    scope.configure_agent_scope(agent_id, {"*"})
    return rt


# ── TestUAHSConfig ───────────────────────────────────────────────────


class TestUAHSConfig(TestCase):
    """Tests for UAHSConfig dataclass."""

    def test_default_values(self) -> None:
        cfg = UAHSConfig()
        self.assertEqual(cfg.scoring_interval, 50)
        self.assertTrue(cfg.feedback_enabled)
        self.assertTrue(cfg.health_store_enabled)
        self.assertIsNone(cfg.drift_config)

    def test_custom_values(self) -> None:
        drift_cfg = AmbiguityDriftConfig(window_size=200)
        cfg = UAHSConfig(
            scoring_interval=10,
            feedback_enabled=False,
            health_store_enabled=False,
            drift_config=drift_cfg,
        )
        self.assertEqual(cfg.scoring_interval, 10)
        self.assertFalse(cfg.feedback_enabled)
        self.assertFalse(cfg.health_store_enabled)
        self.assertEqual(cfg.drift_config.window_size, 200)

    def test_to_dict_roundtrip(self) -> None:
        cfg = UAHSConfig(scoring_interval=25, feedback_enabled=False)
        d = cfg.to_dict()
        self.assertEqual(d["scoring_interval"], 25)
        self.assertFalse(d["feedback_enabled"])
        self.assertTrue(d["health_store_enabled"])
        # drift_config is not in to_dict (it's an opaque object)
        self.assertNotIn("drift_config", d)

    def test_to_dict_keys(self) -> None:
        d = UAHSConfig().to_dict()
        self.assertSetEqual(
            set(d.keys()),
            {
                "scoring_interval",
                "feedback_enabled",
                "health_store_enabled",
                "drift_alert_threshold",
                "archetype_thresholds",
                "min_evaluations_before_alert",
            },
        )


# ── TestRuntimeUAHSDisabled ──────────────────────────────────────────


class TestRuntimeUAHSDisabled(TestCase):
    """Default behavior: enable_uahs=False preserves v0.4.0 behavior."""

    def test_default_uahs_disabled(self) -> None:
        rt = GovernanceRuntime()
        self.assertFalse(rt._enable_uahs)

    def test_ucs_tracker_is_none(self) -> None:
        rt = GovernanceRuntime()
        self.assertIsNone(rt._ucs_tracker)

    def test_uahs_calculator_is_none(self) -> None:
        rt = GovernanceRuntime()
        self.assertIsNone(rt._uahs_calculator)

    def test_uahs_feedback_is_none(self) -> None:
        rt = GovernanceRuntime()
        self.assertIsNone(rt._uahs_feedback)

    def test_evaluate_no_uahs_pipeline(self) -> None:
        """evaluate() does not call UAHS pipeline when disabled."""
        rt = _runtime_with_scope("bot", enable_uahs=False)
        with patch.object(rt, "_post_evaluate_uahs") as mock:
            rt.evaluate(_action(), _ctx())
            mock.assert_not_called()

    def test_get_uahs_returns_none(self) -> None:
        rt = GovernanceRuntime()
        self.assertIsNone(rt.get_uahs("bot"))

    def test_get_ambiguity_profile_returns_none(self) -> None:
        rt = GovernanceRuntime()
        self.assertIsNone(rt.get_ambiguity_profile("bot"))

    def test_existing_evaluate_still_works(self) -> None:
        """Existing evaluate() behavior is preserved."""
        rt = _runtime_with_scope("bot", enable_uahs=False)
        verdict = rt.evaluate(_action(), _ctx())
        self.assertIn(verdict.verdict, (Verdict.ALLOW, Verdict.DENY, Verdict.ESCALATE))

    def test_explicit_false_no_init(self) -> None:
        rt = GovernanceRuntime(enable_uahs=False)
        self.assertFalse(rt._enable_uahs)
        self.assertIsNone(rt._ucs_tracker)


# ── TestRuntimeUAHSEnabled ───────────────────────────────────────────


class TestRuntimeUAHSEnabled(TestCase):
    """Tests for GovernanceRuntime with enable_uahs=True."""

    def test_ucs_tracker_initialized(self) -> None:
        rt = GovernanceRuntime(enable_uahs=True)
        self.assertIsNotNone(rt._ucs_tracker)
        self.assertIsInstance(rt._ucs_tracker, UCSTracker)

    def test_calculator_initialized(self) -> None:
        rt = GovernanceRuntime(enable_uahs=True)
        self.assertIsNotNone(rt._uahs_calculator)
        self.assertIsInstance(rt._uahs_calculator, UnifiedHealthScoreCalculator)

    def test_feedback_initialized(self) -> None:
        rt = GovernanceRuntime(enable_uahs=True)
        self.assertIsNotNone(rt._uahs_feedback)

    def test_eval_counts_empty(self) -> None:
        rt = GovernanceRuntime(enable_uahs=True)
        self.assertEqual(rt._uahs_eval_counts, {})

    def test_uahs_computed_after_scoring_interval(self) -> None:
        """After scoring_interval evaluations, UAHS is computed without error."""
        rt = _runtime_with_scope("bot", enable_uahs=True, uahs_config=UAHSConfig(scoring_interval=5))
        for _ in range(5):
            rt.evaluate(_action(), _ctx())
        # Should have triggered UAHS computation — prev_scores populated
        self.assertIn("bot", rt._uahs_prev_scores)

    def test_get_uahs_returns_score_after_evaluations(self) -> None:
        """get_uahs() returns UnifiedAgentHealthScore after enough evaluations."""
        rt = _runtime_with_scope("bot", enable_uahs=True, uahs_config=UAHSConfig(scoring_interval=5))
        for _ in range(5):
            rt.evaluate(_action(), _ctx())
        uahs = rt.get_uahs("bot")
        self.assertIsNotNone(uahs)
        self.assertIsInstance(uahs, UnifiedAgentHealthScore)

    def test_get_uahs_returns_none_before_scoring_interval(self) -> None:
        """get_uahs() returns None for agent that hasn't recorded any evaluations."""
        rt = GovernanceRuntime(enable_uahs=True, uahs_config=UAHSConfig(scoring_interval=50))
        # No evaluations yet — but get_uahs triggers on-demand compute if profile exists
        self.assertIsNone(rt.get_uahs("nonexistent"))

    def test_get_ambiguity_profile_returns_profile(self) -> None:
        """get_ambiguity_profile() returns AmbiguityDriftProfile after evaluations."""
        rt = _runtime_with_scope("bot", enable_uahs=True, uahs_config=UAHSConfig(scoring_interval=5))
        for _ in range(3):
            rt.evaluate(_action(), _ctx())
        profile = rt.get_ambiguity_profile("bot")
        self.assertIsNotNone(profile)
        self.assertIsInstance(profile, AmbiguityDriftProfile)

    def test_get_ambiguity_profile_none_for_unknown_agent(self) -> None:
        rt = GovernanceRuntime(enable_uahs=True)
        self.assertIsNone(rt.get_ambiguity_profile("unknown"))

    def test_custom_scoring_interval(self) -> None:
        """Custom scoring_interval=5 — UAHS computed after 5 evaluations."""
        rt = _runtime_with_scope("bot", enable_uahs=True, uahs_config=UAHSConfig(scoring_interval=5))

        # After 4 evaluations: not yet computed
        for _ in range(4):
            rt.evaluate(_action(), _ctx())
        self.assertNotIn("bot", rt._uahs_prev_scores)

        # 5th evaluation triggers UAHS computation
        rt.evaluate(_action(), _ctx())
        self.assertIn("bot", rt._uahs_prev_scores)

    def test_feedback_enabled_trust_tracking(self) -> None:
        """feedback_enabled=True — feedback manager runs after UAHS computation."""
        rt = _runtime_with_scope(
            "bot",
            enable_uahs=True,
            uahs_config=UAHSConfig(scoring_interval=5, feedback_enabled=True),
        )
        for _ in range(5):
            rt.evaluate(_action(), _ctx())
        # Prev UAHS should be stored for feedback comparison
        self.assertIn("bot", rt._uahs_prev_uahs)

    def test_feedback_disabled_no_prev_uahs_feedback(self) -> None:
        """feedback_enabled=False — trust profile NOT modified by UAHS feedback."""
        rt = _runtime_with_scope(
            "bot",
            enable_uahs=True,
            uahs_config=UAHSConfig(scoring_interval=5, feedback_enabled=False),
        )
        trust_before = rt.trust_calibrator.get_profile("bot").overall_trust
        for _ in range(10):
            rt.evaluate(_action(), _ctx())
        # UAHS still tracks but feedback doesn't modify trust
        self.assertIn("bot", rt._uahs_prev_uahs)

    def test_uahs_exception_does_not_propagate(self) -> None:
        """UAHS exception inside pipeline does NOT propagate to evaluate() callers."""
        rt = _runtime_with_scope("bot", enable_uahs=True, uahs_config=UAHSConfig(scoring_interval=1))

        # Make the calculator raise an exception
        def bad_compute(*args, **kwargs):
            raise RuntimeError("Simulated UAHS failure")

        rt._uahs_calculator.compute = bad_compute

        # Should not raise
        verdict = rt.evaluate(_action(), _ctx())
        self.assertIn(verdict.verdict, (Verdict.ALLOW, Verdict.DENY, Verdict.ESCALATE))

    def test_two_agents_independent_tracking(self) -> None:
        """Two agents evaluated independently — per-agent UAHS tracking."""
        rt = GovernanceRuntime(
            enable_uahs=True,
            uahs_config=UAHSConfig(scoring_interval=3),
        )
        scope = rt.registry.get("scope_compliance")
        scope.configure_agent_scope("alpha", {"*"})
        scope.configure_agent_scope("beta", {"*"})

        # Evaluate alpha 3 times
        for _ in range(3):
            rt.evaluate(
                _action(agent_id="alpha"),
                _ctx(agent_id="alpha"),
            )

        # alpha should have UAHS computed
        self.assertIn("alpha", rt._uahs_prev_scores)
        # beta should not
        self.assertNotIn("beta", rt._uahs_prev_scores)

        # Now evaluate beta 3 times
        for _ in range(3):
            rt.evaluate(
                _action(agent_id="beta"),
                _ctx(agent_id="beta"),
            )
        self.assertIn("beta", rt._uahs_prev_scores)

    def test_uahs_scores_on_every_interval(self) -> None:
        """Scoring happens at each multiple of scoring_interval."""
        rt = _runtime_with_scope(
            "bot",
            enable_uahs=True,
            uahs_config=UAHSConfig(scoring_interval=3),
        )
        for i in range(1, 10):
            rt.evaluate(_action(), _ctx())
            if i % 3 == 0:
                self.assertIn("bot", rt._uahs_prev_scores)

    def test_evaluate_returns_valid_verdict_with_uahs(self) -> None:
        """evaluate() still returns valid verdicts when UAHS is enabled."""
        rt = _runtime_with_scope("bot", enable_uahs=True, uahs_config=UAHSConfig(scoring_interval=1))
        for _ in range(5):
            verdict = rt.evaluate(_action(), _ctx())
            self.assertIsNotNone(verdict)
            self.assertIsNotNone(verdict.ucs)

    def test_uahs_health_status_in_score(self) -> None:
        """Computed UAHS has a health_status field."""
        rt = _runtime_with_scope("bot", enable_uahs=True, uahs_config=UAHSConfig(scoring_interval=3))
        for _ in range(3):
            rt.evaluate(_action(), _ctx())
        uahs = rt.get_uahs("bot")
        self.assertIsNotNone(uahs)
        self.assertIn(
            uahs.health_status,
            ("excellent", "good", "watch", "warning", "critical"),
        )


# ── TestUAHSAutoWire ─────────────────────────────────────────────────


class TestUAHSAutoWire(TestCase):
    """Tests for UAHS auto-wiring edge cases."""

    def test_health_store_initialized_with_audit_store(self) -> None:
        """enable_uahs=True + health_store_enabled=True — health store initialized when audit_store present."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from nomotic.audit_store import AuditStore

            base_dir = Path(tmpdir)
            audit_store = AuditStore(base_dir)

            rt = GovernanceRuntime(
                enable_uahs=True,
                uahs_config=UAHSConfig(health_store_enabled=True),
            )
            rt.set_audit_store(audit_store)
            # Re-init UAHS to pick up the audit store
            rt._init_uahs()
            self.assertIsNotNone(rt._uahs_health_store)
            self.assertIsInstance(rt._uahs_health_store, GovernanceHealthStore)

    def test_health_store_none_without_audit_store(self) -> None:
        """enable_uahs=True + health_store_enabled=True but no audit_store — no crash, store is None."""
        rt = GovernanceRuntime(
            enable_uahs=True,
            uahs_config=UAHSConfig(health_store_enabled=True),
        )
        # No audit store set — health store should be None
        self.assertIsNone(rt._uahs_health_store)

    def test_scoring_interval_one(self) -> None:
        """enable_uahs=True with UAHSConfig(scoring_interval=1) — scores on every evaluation."""
        rt = _runtime_with_scope(
            "bot",
            enable_uahs=True,
            uahs_config=UAHSConfig(scoring_interval=1),
        )
        rt.evaluate(_action(), _ctx())
        self.assertIn("bot", rt._uahs_prev_scores)

    def test_custom_drift_config_passed_to_tracker(self) -> None:
        """Custom drift_config is forwarded to UCSTracker."""
        custom_drift = AmbiguityDriftConfig(window_size=200, band_low=0.20)
        rt = GovernanceRuntime(
            enable_uahs=True,
            uahs_config=UAHSConfig(drift_config=custom_drift),
        )
        # The tracker should use our custom config as default
        self.assertEqual(rt._ucs_tracker._default_config.window_size, 200)
        self.assertEqual(rt._ucs_tracker._default_config.band_low, 0.20)

    def test_health_store_disabled_explicitly(self) -> None:
        """health_store_enabled=False — no health store even with audit store."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from nomotic.audit_store import AuditStore

            base_dir = Path(tmpdir)
            audit_store = AuditStore(base_dir)

            rt = GovernanceRuntime(
                enable_uahs=True,
                uahs_config=UAHSConfig(health_store_enabled=False),
            )
            rt.set_audit_store(audit_store)
            rt._init_uahs()
            self.assertIsNone(rt._uahs_health_store)

    def test_uahs_with_runtime_config(self) -> None:
        """UAHS works alongside RuntimeConfig parameters."""
        config = RuntimeConfig(
            enable_fingerprints=True,
            allow_threshold=0.8,
        )
        rt = GovernanceRuntime(
            config=config,
            enable_uahs=True,
            uahs_config=UAHSConfig(scoring_interval=3),
        )
        self.assertTrue(rt._enable_uahs)
        self.assertIsNotNone(rt._ucs_tracker)
        self.assertEqual(rt.config.allow_threshold, 0.8)

    def test_init_uahs_idempotent(self) -> None:
        """Calling _init_uahs() again doesn't crash."""
        rt = GovernanceRuntime(enable_uahs=True)
        rt._init_uahs()  # Second call
        self.assertIsNotNone(rt._ucs_tracker)


# ── TestUAHSExport ───────────────────────────────────────────────────


class TestUAHSExport(TestCase):
    """Tests for UAHSConfig export."""

    def test_import_from_nomotic(self) -> None:
        """from nomotic import UAHSConfig works."""
        from nomotic import UAHSConfig as Cfg

        self.assertIsNotNone(Cfg)
        cfg = Cfg()
        self.assertEqual(cfg.scoring_interval, 50)

    def test_import_from_types(self) -> None:
        """from nomotic.types import UAHSConfig works."""
        from nomotic.types import UAHSConfig as Cfg

        cfg = Cfg(scoring_interval=10)
        self.assertEqual(cfg.scoring_interval, 10)

    def test_uahsconfig_in_all(self) -> None:
        """UAHSConfig is in nomotic.__all__."""
        import nomotic

        self.assertIn("UAHSConfig", nomotic.__all__)

    def test_uahsconfig_in_types_all(self) -> None:
        """UAHSConfig is in nomotic.types.__all__."""
        from nomotic import types

        self.assertIn("UAHSConfig", types.__all__)


# ── TestUAHSConfigThresholds ─────────────────────────────────────────


class TestUAHSConfigThresholds(TestCase):
    """Tests for new UAHSConfig threshold fields."""

    def test_drift_alert_threshold_default_is_0_3(self) -> None:
        cfg = UAHSConfig()
        self.assertEqual(cfg.drift_alert_threshold, 0.3)

    def test_archetype_thresholds_default_empty(self) -> None:
        cfg = UAHSConfig()
        self.assertEqual(cfg.archetype_thresholds, {})

    def test_min_evaluations_default_is_10(self) -> None:
        cfg = UAHSConfig()
        self.assertEqual(cfg.min_evaluations_before_alert, 10)

    def test_to_dict_includes_new_fields(self) -> None:
        cfg = UAHSConfig(
            drift_alert_threshold=0.2,
            archetype_thresholds={"decision_maker": 0.1},
            min_evaluations_before_alert=5,
        )
        d = cfg.to_dict()
        self.assertIn("drift_alert_threshold", d)
        self.assertEqual(d["drift_alert_threshold"], 0.2)
        self.assertIn("archetype_thresholds", d)
        self.assertEqual(d["archetype_thresholds"], {"decision_maker": 0.1})
        self.assertIn("min_evaluations_before_alert", d)
        self.assertEqual(d["min_evaluations_before_alert"], 5)

    def test_archetype_threshold_overrides_default(self) -> None:
        cfg = UAHSConfig(
            drift_alert_threshold=0.3,
            archetype_thresholds={"executor": 0.45},
        )
        # Executor has its own threshold
        self.assertEqual(cfg.archetype_thresholds.get("executor", cfg.drift_alert_threshold), 0.45)

    def test_archetype_threshold_fallback_when_not_set(self) -> None:
        cfg = UAHSConfig(
            drift_alert_threshold=0.3,
            archetype_thresholds={"executor": 0.45},
        )
        # Unknown archetype falls back to default
        self.assertEqual(cfg.archetype_thresholds.get("unknown", cfg.drift_alert_threshold), 0.3)


# ── TestDriftAlertThreshold ──────────────────────────────────────────


class TestDriftAlertThreshold(TestCase):
    """Tests for threshold-aware drift alert dispatch."""

    def _make_runtime_with_webhook(
        self,
        threshold: float = 0.3,
        archetype_thresholds: dict[str, float] | None = None,
        min_evals: int = 10,
        scoring_interval: int = 1,
    ) -> GovernanceRuntime:
        cfg = UAHSConfig(
            scoring_interval=scoring_interval,
            drift_alert_threshold=threshold,
            archetype_thresholds=archetype_thresholds or {},
            min_evaluations_before_alert=min_evals,
        )
        rt = _runtime_with_scope("bot", enable_uahs=True, uahs_config=cfg)
        return rt

    def test_alert_fires_above_threshold(self) -> None:
        """Drift alarm fires when drift_score > threshold and sufficient evaluations."""
        rt = self._make_runtime_with_webhook(threshold=0.2, min_evals=1)
        # Run enough evaluations to trigger scoring
        for _ in range(2):
            rt.evaluate(_action(), _ctx())

        # Inject a drift_score on the profile
        profile = rt._ucs_tracker.get_profile("bot")
        self.assertIsNotNone(profile)
        profile.drift_score = 0.5  # above threshold of 0.2

        # Capture webhook dispatch
        dispatched = []
        original_dispatch = rt._dispatch_webhook
        def capture(event_type, agent_id, payload):
            dispatched.append((event_type, agent_id, payload))
            original_dispatch(event_type, agent_id, payload)
        rt._dispatch_webhook = capture

        rt.evaluate(_action(), _ctx())
        drift_alarms = [d for d in dispatched if d[0] == "DRIFT_ALARM"]
        self.assertTrue(len(drift_alarms) > 0, "Expected DRIFT_ALARM to fire")

    def test_alert_suppressed_below_threshold(self) -> None:
        """Drift alarm does NOT fire when drift_score <= threshold."""
        rt = self._make_runtime_with_webhook(threshold=0.5, min_evals=1)
        for _ in range(2):
            rt.evaluate(_action(), _ctx())

        profile = rt._ucs_tracker.get_profile("bot")
        self.assertIsNotNone(profile)
        profile.drift_score = 0.3  # below threshold of 0.5

        dispatched = []
        original_dispatch = rt._dispatch_webhook
        def capture(event_type, agent_id, payload):
            dispatched.append((event_type, agent_id, payload))
            original_dispatch(event_type, agent_id, payload)
        rt._dispatch_webhook = capture

        rt.evaluate(_action(), _ctx())
        drift_alarms = [d for d in dispatched if d[0] == "DRIFT_ALARM"]
        self.assertEqual(len(drift_alarms), 0, "DRIFT_ALARM should not fire below threshold")

    def test_alert_suppressed_before_min_evaluations(self) -> None:
        """Drift alarm suppressed when eval count < min_evaluations_before_alert."""
        rt = self._make_runtime_with_webhook(threshold=0.1, min_evals=20)
        for _ in range(3):
            rt.evaluate(_action(), _ctx())

        profile = rt._ucs_tracker.get_profile("bot")
        self.assertIsNotNone(profile)
        profile.drift_score = 0.9  # way above threshold

        dispatched = []
        original_dispatch = rt._dispatch_webhook
        def capture(event_type, agent_id, payload):
            dispatched.append((event_type, agent_id, payload))
            original_dispatch(event_type, agent_id, payload)
        rt._dispatch_webhook = capture

        rt.evaluate(_action(), _ctx())
        drift_alarms = [d for d in dispatched if d[0] == "DRIFT_ALARM"]
        self.assertEqual(len(drift_alarms), 0, "DRIFT_ALARM should be suppressed before min_evaluations")

    def test_alert_fires_after_min_evaluations_reached(self) -> None:
        """Drift alarm fires once eval count >= min_evaluations_before_alert."""
        rt = self._make_runtime_with_webhook(threshold=0.1, min_evals=5)

        # Run 5 evaluations to meet min_evaluations
        for _ in range(5):
            rt.evaluate(_action(), _ctx())

        # Set drift_score above threshold
        profile = rt._ucs_tracker.get_profile("bot")
        self.assertIsNotNone(profile)
        profile.drift_score = 0.5

        dispatched = []
        original_dispatch = rt._dispatch_webhook
        def capture(event_type, agent_id, payload):
            dispatched.append((event_type, agent_id, payload))
            original_dispatch(event_type, agent_id, payload)
        rt._dispatch_webhook = capture

        # 6th evaluation — should fire
        rt.evaluate(_action(), _ctx())
        drift_alarms = [d for d in dispatched if d[0] == "DRIFT_ALARM"]
        self.assertTrue(len(drift_alarms) > 0, "DRIFT_ALARM should fire after min_evaluations")

    def test_per_archetype_threshold_used_when_set(self) -> None:
        """Per-archetype threshold is used instead of default when configured."""
        rt = self._make_runtime_with_webhook(
            threshold=0.9,  # high default — would normally suppress
            archetype_thresholds={"*": 0.1},  # but * archetype has low threshold
            min_evals=1,
        )
        for _ in range(2):
            rt.evaluate(_action(), _ctx())

        profile = rt._ucs_tracker.get_profile("bot")
        self.assertIsNotNone(profile)
        profile.drift_score = 0.5  # above * threshold of 0.1 but below default 0.9

        dispatched = []
        original_dispatch = rt._dispatch_webhook
        def capture(event_type, agent_id, payload):
            dispatched.append((event_type, agent_id, payload))
            original_dispatch(event_type, agent_id, payload)
        rt._dispatch_webhook = capture

        rt.evaluate(_action(), _ctx())
        drift_alarms = [d for d in dispatched if d[0] == "DRIFT_ALARM"]
        self.assertTrue(len(drift_alarms) > 0, "DRIFT_ALARM should fire using per-archetype threshold")


# ── TestResetUAHS ────────────────────────────────────────────────────


class TestResetUAHS(TestCase):
    """Tests for GovernanceRuntime.reset_uahs()."""

    def test_reset_clears_tracker_data(self) -> None:
        """reset_uahs() clears tracker profile data for the agent."""
        rt = _runtime_with_scope(
            "bot", enable_uahs=True, uahs_config=UAHSConfig(scoring_interval=3)
        )
        for _ in range(3):
            rt.evaluate(_action(), _ctx())
        # Verify data exists before reset
        self.assertIsNotNone(rt._ucs_tracker.get_profile("bot"))
        self.assertIn("bot", rt._uahs_prev_scores)

        rt.reset_uahs("bot")

        # Tracker profile should be cleared
        self.assertIsNone(rt._ucs_tracker.get_profile("bot"))
        # Cached scores should be cleared
        self.assertNotIn("bot", rt._uahs_prev_scores)
        self.assertNotIn("bot", rt._uahs_prev_uahs)

    def test_reset_raises_when_uahs_not_enabled(self) -> None:
        """reset_uahs() raises ValueError when UAHS is not enabled."""
        rt = GovernanceRuntime(enable_uahs=False)
        with self.assertRaises(ValueError) as cm:
            rt.reset_uahs("bot")
        self.assertIn("UAHS is not enabled", str(cm.exception))

    def test_reset_resets_evaluation_count(self) -> None:
        """reset_uahs() clears the evaluation count for the agent."""
        rt = _runtime_with_scope(
            "bot", enable_uahs=True, uahs_config=UAHSConfig(scoring_interval=5)
        )
        for _ in range(3):
            rt.evaluate(_action(), _ctx())
        self.assertEqual(rt._uahs_eval_counts.get("bot"), 3)

        rt.reset_uahs("bot")
        self.assertNotIn("bot", rt._uahs_eval_counts)

    def test_agent_starts_fresh_after_reset(self) -> None:
        """After reset, agent accumulates evaluations from zero."""
        rt = _runtime_with_scope(
            "bot", enable_uahs=True, uahs_config=UAHSConfig(scoring_interval=3)
        )
        # Build up history
        for _ in range(6):
            rt.evaluate(_action(), _ctx())
        self.assertIn("bot", rt._uahs_prev_scores)

        rt.reset_uahs("bot")

        # After reset, no UAHS data
        self.assertIsNone(rt.get_uahs("bot"))

        # Re-evaluate — should work fresh
        for _ in range(3):
            rt.evaluate(_action(), _ctx())
        # Now UAHS should be computed again
        self.assertIn("bot", rt._uahs_prev_scores)
        uahs = rt.get_uahs("bot")
        self.assertIsNotNone(uahs)
