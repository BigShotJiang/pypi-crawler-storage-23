"""Tests for human oversight drift detection.

Tests HumanInteractionProfile, HumanDriftCalculator, HumanDriftMonitor,
HumanAuditStore, TeamOversightMetrics, RoutingRecommendation, and
configurable DriftThresholds.
"""

from __future__ import annotations

import tempfile
import time
from pathlib import Path
from unittest import TestCase

from nomotic.human_drift import (
    DriftThresholds,
    HumanAuditStore,
    HumanDriftCalculator,
    HumanDriftMonitor,
    HumanDriftResult,
    HumanInteractionEvent,
    HumanInteractionProfile,
    RoutingRecommendation,
    TeamOversightMetrics,
)


# ── Helpers ────────────────────────────────────────────────────────────


_BASE_TIME = 1700000000.0


def _make_event(
    *,
    duration: float = 30.0,
    decision: str = "approved",
    event_type: str = "approval",
    reviewer_id: str = "reviewer1",
    agent_id: str = "agent1",
    rationale: str = "Looks good",
    context_viewed: bool = True,
    timestamp: float | None = None,
    index: int = 0,
    action_risk: str = "low",
    action_ucs: float = 0.0,
    action_tier: int = 0,
) -> HumanInteractionEvent:
    return HumanInteractionEvent(
        timestamp=timestamp if timestamp is not None else _BASE_TIME + index * 60,
        reviewer_id=reviewer_id,
        agent_id=agent_id,
        action_id=f"action-{index}",
        event_type=event_type,
        decision=decision,
        review_duration_seconds=duration,
        rationale=rationale,
        rationale_depth=len(rationale.split()) if rationale else 0,
        context_viewed=context_viewed,
        modifications=[],
        action_risk=action_risk,
        action_ucs=action_ucs,
        action_tier=action_tier,
    )


def _make_profile(
    *,
    reviewer_id: str = "reviewer1",
    mean_duration: float = 30.0,
    approval_rate: float = 0.7,
    denial_rate: float = 0.2,
    modification_rate: float = 0.05,
    deferral_rate: float = 0.05,
    override_rate: float = 0.05,
    rationale_provided_rate: float = 0.8,
    context_view_rate: float = 0.9,
    mean_rationale_depth: float = 5.0,
    total: int = 200,
    interactions_per_hour: float = 10.0,
    mean_risk_adjusted_score: float = 0.0,
    high_risk_mean_duration: float = 0.0,
    low_risk_mean_duration: float = 0.0,
    high_risk_rationale_rate: float = 0.0,
    high_risk_interactions: int = 0,
    consecutive_approvals: int = 0,
    reviews_last_hour: int = 0,
) -> HumanInteractionProfile:
    return HumanInteractionProfile(
        reviewer_id=reviewer_id,
        mean_review_duration=mean_duration,
        median_review_duration=mean_duration,
        min_review_duration=mean_duration * 0.5,
        max_review_duration=mean_duration * 2.0,
        review_duration_stddev=mean_duration * 0.2,
        approval_rate=approval_rate,
        denial_rate=denial_rate,
        modification_rate=modification_rate,
        deferral_rate=deferral_rate,
        override_rate=override_rate,
        mean_rationale_depth=mean_rationale_depth,
        rationale_provided_rate=rationale_provided_rate,
        context_view_rate=context_view_rate,
        total_interactions=total,
        interactions_per_hour=interactions_per_hour,
        mean_risk_adjusted_score=mean_risk_adjusted_score,
        high_risk_mean_duration=high_risk_mean_duration,
        low_risk_mean_duration=low_risk_mean_duration,
        high_risk_rationale_rate=high_risk_rationale_rate,
        high_risk_interactions=high_risk_interactions,
        consecutive_approvals=consecutive_approvals,
        reviews_last_hour=reviews_last_hour,
        window_start=_BASE_TIME,
        window_end=_BASE_TIME + 3600,
    )


def _make_drift_result(
    *,
    reviewer_id: str = "reviewer1",
    overall_drift: float = 0.5,
    drift_category: str = "moderate",
    timing_drift: float = 0.0,
    decision_drift: float = 0.0,
    engagement_drift: float = 0.0,
    throughput_drift: float = 0.0,
    risk_timing_drift: float = 0.0,
    fatigue_score: float = 0.0,
    alerts: list[str] | None = None,
) -> HumanDriftResult:
    baseline = _make_profile(reviewer_id=reviewer_id)
    recent = _make_profile(reviewer_id=reviewer_id)
    return HumanDriftResult(
        reviewer_id=reviewer_id,
        overall_drift=overall_drift,
        drift_category=drift_category,
        timing_drift=timing_drift,
        decision_drift=decision_drift,
        engagement_drift=engagement_drift,
        throughput_drift=throughput_drift,
        risk_timing_drift=risk_timing_drift,
        fatigue_score=fatigue_score,
        alerts=alerts or [],
        baseline_profile=baseline,
        recent_profile=recent,
    )


# ── Profile tests ─────────────────────────────────────────────────────


class TestHumanInteractionProfile(TestCase):
    def test_from_events(self) -> None:
        events = [_make_event(duration=30, decision="approved", index=i) for i in range(10)]
        events.append(_make_event(duration=30, decision="denied", index=10))
        profile = HumanInteractionProfile.from_events("reviewer1", events)
        self.assertEqual(profile.total_interactions, 11)
        self.assertAlmostEqual(profile.approval_rate, 10 / 11, places=2)

    def test_from_empty_events(self) -> None:
        profile = HumanInteractionProfile.from_events("reviewer1", [])
        self.assertEqual(profile.total_interactions, 0)
        self.assertEqual(profile.approval_rate, 0.0)

    def test_review_duration_stats(self) -> None:
        events = [
            _make_event(duration=10, index=0),
            _make_event(duration=20, index=1),
            _make_event(duration=30, index=2),
        ]
        profile = HumanInteractionProfile.from_events("reviewer1", events)
        self.assertAlmostEqual(profile.mean_review_duration, 20.0, places=1)
        self.assertAlmostEqual(profile.median_review_duration, 20.0, places=1)
        self.assertEqual(profile.min_review_duration, 10.0)
        self.assertEqual(profile.max_review_duration, 30.0)

    def test_rationale_metrics(self) -> None:
        events = [
            _make_event(rationale="Good work here", index=0),
            _make_event(rationale="", index=1),
            _make_event(rationale="Reviewed carefully and approved", index=2),
        ]
        profile = HumanInteractionProfile.from_events("reviewer1", events)
        self.assertAlmostEqual(profile.rationale_provided_rate, 2 / 3, places=2)

    def test_context_view_rate(self) -> None:
        events = [
            _make_event(context_viewed=True, index=0),
            _make_event(context_viewed=False, index=1),
            _make_event(context_viewed=True, index=2),
            _make_event(context_viewed=True, index=3),
        ]
        profile = HumanInteractionProfile.from_events("reviewer1", events)
        self.assertAlmostEqual(profile.context_view_rate, 0.75, places=2)

    def test_override_rate(self) -> None:
        events = [
            _make_event(event_type="approval", index=0),
            _make_event(event_type="override", index=1),
            _make_event(event_type="approval", index=2),
            _make_event(event_type="approval", index=3),
        ]
        profile = HumanInteractionProfile.from_events("reviewer1", events)
        self.assertAlmostEqual(profile.override_rate, 0.25, places=2)

    def test_to_dict_roundtrip(self) -> None:
        events = [_make_event(index=i) for i in range(5)]
        profile = HumanInteractionProfile.from_events("reviewer1", events)
        d = profile.to_dict()
        self.assertEqual(d["reviewer_id"], "reviewer1")
        self.assertEqual(d["total_interactions"], 5)

    def test_risk_stratified_fields(self) -> None:
        events = [
            _make_event(duration=5, action_risk="low", index=0),
            _make_event(duration=5, action_risk="low", index=1),
            _make_event(duration=45, action_risk="high", index=2),
            _make_event(duration=60, action_risk="critical", index=3),
        ]
        profile = HumanInteractionProfile.from_events("reviewer1", events)
        self.assertAlmostEqual(profile.low_risk_mean_duration, 5.0, places=1)
        self.assertAlmostEqual(profile.high_risk_mean_duration, 52.5, places=1)
        self.assertEqual(profile.high_risk_interactions, 2)

    def test_consecutive_approvals(self) -> None:
        events = [
            _make_event(decision="denied", index=0),
            _make_event(decision="approved", index=1),
            _make_event(decision="approved", index=2),
            _make_event(decision="approved", index=3),
        ]
        profile = HumanInteractionProfile.from_events("reviewer1", events)
        self.assertEqual(profile.consecutive_approvals, 3)

    def test_consecutive_approvals_broken_by_denial(self) -> None:
        events = [
            _make_event(decision="approved", index=0),
            _make_event(decision="approved", index=1),
            _make_event(decision="denied", index=2),
            _make_event(decision="approved", index=3),
        ]
        profile = HumanInteractionProfile.from_events("reviewer1", events)
        self.assertEqual(profile.consecutive_approvals, 1)


# ── Calculator tests ───────────────────────────────────────────────────


class TestHumanDriftCalculator(TestCase):
    def test_no_drift(self) -> None:
        baseline = _make_profile(mean_duration=30, approval_rate=0.7)
        recent = _make_profile(mean_duration=28, approval_rate=0.72)
        result = HumanDriftCalculator().calculate(baseline, recent)
        self.assertEqual(result.drift_category, "stable")
        self.assertEqual(len(result.alerts), 0)

    def test_rubber_stamping_detected(self) -> None:
        baseline = _make_profile(
            mean_duration=30, approval_rate=0.7, total=200,
            mean_risk_adjusted_score=0.1,
        )
        recent = _make_profile(
            mean_duration=2, approval_rate=0.99, total=150,
            override_rate=0.0, rationale_provided_rate=0.05,
            context_view_rate=0.1,
            mean_risk_adjusted_score=0.8,
            consecutive_approvals=50,
        )
        result = HumanDriftCalculator().calculate(baseline, recent)
        self.assertIn(result.drift_category, ("severe", "critical"))
        self.assertTrue(any("rubber-stamping" in a for a in result.alerts))

    def test_timing_drop_alert(self) -> None:
        baseline = _make_profile(mean_duration=45)
        recent = _make_profile(mean_duration=3)
        result = HumanDriftCalculator().calculate(baseline, recent)
        self.assertGreater(result.timing_drift, 0.5)
        self.assertTrue(any("duration dropped" in a.lower() for a in result.alerts))

    def test_min_review_duration_alert(self) -> None:
        baseline = _make_profile(mean_duration=45)
        recent = _make_profile(mean_duration=2)
        result = HumanDriftCalculator().calculate(baseline, recent)
        self.assertTrue(any("below" in a.lower() and "minimum" in a.lower() for a in result.alerts))

    def test_zero_overrides_alert(self) -> None:
        baseline = _make_profile(override_rate=0.05, total=200)
        recent = _make_profile(override_rate=0.0, total=150)
        result = HumanDriftCalculator().calculate(baseline, recent)
        self.assertTrue(any("zero overrides" in a.lower() for a in result.alerts))

    def test_rationale_drop(self) -> None:
        baseline = _make_profile(rationale_provided_rate=0.8)
        recent = _make_profile(rationale_provided_rate=0.1)
        result = HumanDriftCalculator().calculate(baseline, recent)
        self.assertGreater(result.engagement_drift, 0.5)

    def test_context_view_drop(self) -> None:
        baseline = _make_profile(context_view_rate=0.9)
        recent = _make_profile(context_view_rate=0.2)
        result = HumanDriftCalculator().calculate(baseline, recent)
        self.assertGreater(result.engagement_drift, 0.5)
        self.assertTrue(any("context viewing" in a.lower() for a in result.alerts))

    def test_throughput_increase_alert(self) -> None:
        baseline = _make_profile(interactions_per_hour=10)
        recent = _make_profile(interactions_per_hour=35)
        result = HumanDriftCalculator().calculate(baseline, recent)
        self.assertGreater(result.throughput_drift, 0)
        self.assertTrue(any("throughput" in a.lower() for a in result.alerts))

    def test_overall_drift_weighting(self) -> None:
        """Overall drift is a weighted combination of components."""
        baseline = _make_profile(mean_duration=30, approval_rate=0.7)
        recent = _make_profile(mean_duration=30, approval_rate=0.7)
        result = HumanDriftCalculator().calculate(baseline, recent)
        self.assertAlmostEqual(result.overall_drift, 0.0, places=2)

    def test_drift_categories(self) -> None:
        calc = HumanDriftCalculator()
        baseline = _make_profile(mean_duration=30, approval_rate=0.7)
        recent = _make_profile(mean_duration=29, approval_rate=0.71)
        result = calc.calculate(baseline, recent)
        self.assertEqual(result.drift_category, "stable")

    def test_to_dict(self) -> None:
        baseline = _make_profile()
        recent = _make_profile(mean_duration=2, approval_rate=0.99)
        result = HumanDriftCalculator().calculate(baseline, recent)
        d = result.to_dict()
        self.assertIn("reviewer_id", d)
        self.assertIn("overall_drift", d)
        self.assertIn("drift_category", d)
        self.assertIn("risk_timing_drift", d)
        self.assertIn("fatigue_score", d)
        self.assertIn("alerts", d)
        self.assertIsInstance(d["alerts"], list)

    def test_result_has_new_fields(self) -> None:
        baseline = _make_profile()
        recent = _make_profile()
        result = HumanDriftCalculator().calculate(baseline, recent)
        self.assertIsInstance(result.risk_timing_drift, float)
        self.assertIsInstance(result.fatigue_score, float)


# ── Risk-weighted scoring tests ────────────────────────────────────────


class TestRiskWeightedScoring(TestCase):
    def test_low_risk_fast_review_low_concern(self) -> None:
        """Fast review on low-risk action = low concern score."""
        event = _make_event(duration=3, action_risk="low")
        self.assertLess(event.risk_adjusted_duration, 0.3)

    def test_high_risk_fast_review_high_concern(self) -> None:
        """Fast review on high-risk action = high concern score."""
        event = _make_event(duration=3, action_risk="high")
        self.assertGreater(event.risk_adjusted_duration, 0.5)

    def test_critical_fast_review_very_high_concern(self) -> None:
        """Fast review on critical action = very high concern."""
        event = _make_event(duration=2, action_risk="critical")
        self.assertGreater(event.risk_adjusted_duration, 1.0)

    def test_instant_review_max_concern(self) -> None:
        """Zero-duration review produces maximum concern for risk level."""
        event = _make_event(duration=0, action_risk="critical")
        self.assertAlmostEqual(event.risk_adjusted_duration, 20.0, places=1)

    def test_long_review_low_concern(self) -> None:
        """60+ second review = minimal concern regardless of risk."""
        event = _make_event(duration=60, action_risk="critical")
        self.assertAlmostEqual(event.risk_adjusted_duration, 0.0, places=1)

    def test_risk_stratified_profile(self) -> None:
        events = [
            _make_event(duration=5, action_risk="low", index=0),
            _make_event(duration=5, action_risk="low", index=1),
            _make_event(duration=45, action_risk="high", index=2),
            _make_event(duration=60, action_risk="critical", index=3),
        ]
        profile = HumanInteractionProfile.from_events("reviewer1", events)
        self.assertLess(profile.low_risk_mean_duration, profile.high_risk_mean_duration)

    def test_risk_weighted_catches_high_risk_fast_approval(self) -> None:
        baseline = _make_profile(high_risk_mean_duration=45)
        recent = _make_profile(high_risk_mean_duration=3, high_risk_interactions=10)
        result = HumanDriftCalculator().calculate(baseline, recent)
        self.assertGreater(result.risk_timing_drift, 0.5)
        self.assertTrue(any("high-risk" in a.lower() for a in result.alerts))

    def test_low_risk_fast_approval_not_alarming(self) -> None:
        """Fast reviews on low-risk items should NOT trigger risk timing alerts."""
        baseline = _make_profile(mean_duration=30, low_risk_mean_duration=15)
        recent = _make_profile(
            mean_duration=5, low_risk_mean_duration=3,
            mean_risk_adjusted_score=0.1,
        )
        result = HumanDriftCalculator().calculate(baseline, recent)
        self.assertLess(result.risk_timing_drift, 0.3)

    def test_high_risk_rationale_gap(self) -> None:
        baseline = _make_profile(high_risk_rationale_rate=0.9, high_risk_interactions=20)
        recent = _make_profile(high_risk_rationale_rate=0.2, high_risk_interactions=10)
        result = HumanDriftCalculator().calculate(baseline, recent)
        self.assertTrue(
            any("high-risk" in a.lower() and "rationale" in a.lower() for a in result.alerts)
        )


# ── Configurable thresholds tests ──────────────────────────────────────


class TestConfigurableThresholds(TestCase):
    def test_custom_approval_threshold(self) -> None:
        """Stricter threshold should fire at lower approval rate."""
        strict = DriftThresholds(approval_rate_alert=0.80)
        baseline = _make_profile(approval_rate=0.7, total=200)
        recent = _make_profile(approval_rate=0.85, total=50)

        # Default: no alert (0.85 < 0.95)
        default_result = HumanDriftCalculator().calculate(baseline, recent)
        self.assertFalse(any("rubber-stamping" in a for a in default_result.alerts))

        # Strict: alert fires (0.85 > 0.80)
        strict_result = HumanDriftCalculator(thresholds=strict).calculate(baseline, recent)
        self.assertTrue(any("rubber-stamping" in a for a in strict_result.alerts))

    def test_custom_high_risk_min_duration(self) -> None:
        strict = DriftThresholds(high_risk_min_duration_seconds=30.0)
        baseline = _make_profile(high_risk_mean_duration=45)
        recent = _make_profile(high_risk_mean_duration=20, high_risk_interactions=10)
        result = HumanDriftCalculator(thresholds=strict).calculate(baseline, recent)
        self.assertTrue(any("high-risk" in a.lower() for a in result.alerts))

    def test_custom_min_review_duration(self) -> None:
        strict = DriftThresholds(min_review_duration_seconds=10.0)
        baseline = _make_profile(mean_duration=30)
        recent = _make_profile(mean_duration=8)
        result = HumanDriftCalculator(thresholds=strict).calculate(baseline, recent)
        self.assertTrue(any("below" in a.lower() and "minimum" in a.lower() for a in result.alerts))

    def test_default_thresholds(self) -> None:
        t = DriftThresholds()
        self.assertEqual(t.min_review_duration_seconds, 3.0)
        self.assertEqual(t.approval_rate_alert, 0.95)
        self.assertEqual(t.fatigue_consecutive_approvals, 40)
        self.assertEqual(t.fatigue_reviews_per_hour, 60)

    def test_monitor_passes_thresholds(self) -> None:
        strict = DriftThresholds(approval_rate_alert=0.80)
        monitor = HumanDriftMonitor(
            baseline_window=10, recent_window=5, thresholds=strict
        )
        # Feed 10 baseline (70% approval)
        decisions = ["approved", "approved", "denied", "approved", "approved",
                     "denied", "approved", "approved", "denied", "approved"]
        for i in range(10):
            monitor.record_event(
                _make_event(decision=decisions[i], index=i)
            )
        # Feed 5 recent (100% approval) — should fire with strict threshold
        for i in range(5):
            result = monitor.record_event(
                _make_event(decision="approved", index=10 + i)
            )
        self.assertIsNotNone(result)


# ── Fatigue detection tests ────────────────────────────────────────────


class TestFatigueDetection(TestCase):
    def test_consecutive_approvals_fatigue(self) -> None:
        baseline = _make_profile(consecutive_approvals=5)
        recent = _make_profile(consecutive_approvals=50)
        result = HumanDriftCalculator().calculate(baseline, recent)
        self.assertGreater(result.fatigue_score, 0.5)
        self.assertTrue(any("consecutive" in a.lower() for a in result.alerts))

    def test_high_throughput_fatigue(self) -> None:
        baseline = _make_profile(reviews_last_hour=10)
        recent = _make_profile(reviews_last_hour=70)
        result = HumanDriftCalculator().calculate(baseline, recent)
        self.assertGreater(result.fatigue_score, 0.5)
        self.assertTrue(any("reviews in the last hour" in a for a in result.alerts))

    def test_no_fatigue_normal_patterns(self) -> None:
        baseline = _make_profile(consecutive_approvals=5, reviews_last_hour=10)
        recent = _make_profile(consecutive_approvals=8, reviews_last_hour=12)
        result = HumanDriftCalculator().calculate(baseline, recent)
        self.assertAlmostEqual(result.fatigue_score, 0.0, places=2)

    def test_fatigue_from_events(self) -> None:
        # All approved in a tight time window
        events = [
            _make_event(decision="approved", index=i, timestamp=_BASE_TIME + i * 30)
            for i in range(50)
        ]
        profile = HumanInteractionProfile.from_events("reviewer1", events)
        self.assertEqual(profile.consecutive_approvals, 50)
        self.assertGreater(profile.reviews_last_hour, 0)


# ── Monitor tests ──────────────────────────────────────────────────────


class TestHumanDriftMonitor(TestCase):
    def test_needs_sufficient_data(self) -> None:
        monitor = HumanDriftMonitor(baseline_window=10, recent_window=5)
        for i in range(5):
            result = monitor.record_event(_make_event(index=i))
            self.assertIsNone(result)

    def test_returns_none_when_no_drift(self) -> None:
        monitor = HumanDriftMonitor(baseline_window=10, recent_window=5)
        decisions = ["approved", "approved", "denied", "approved", "approved"]
        for i in range(15):
            result = monitor.record_event(
                _make_event(
                    duration=30,
                    decision=decisions[i % len(decisions)],
                    rationale="Reviewed carefully",
                    context_viewed=True,
                    index=i,
                )
            )
        self.assertIsNone(result)

    def test_detects_drift_after_baseline(self) -> None:
        monitor = HumanDriftMonitor(baseline_window=20, recent_window=10)
        for i in range(20):
            monitor.record_event(
                _make_event(duration=30, decision="approved", index=i)
            )
        result = None
        for i in range(10):
            result = monitor.record_event(
                _make_event(duration=1.5, decision="approved", index=20 + i)
            )
        self.assertIsNotNone(result)
        self.assertNotEqual(result.drift_category, "stable")

    def test_get_alerts(self) -> None:
        monitor = HumanDriftMonitor(baseline_window=20, recent_window=10)
        for i in range(20):
            monitor.record_event(_make_event(duration=30, index=i))
        for i in range(10):
            monitor.record_event(_make_event(duration=1.5, index=20 + i))
        alerts = monitor.get_alerts()
        self.assertGreater(len(alerts), 0)

    def test_get_profile(self) -> None:
        monitor = HumanDriftMonitor(baseline_window=10, recent_window=5)
        for i in range(15):
            monitor.record_event(_make_event(index=i))
        profile = monitor.get_profile("reviewer1")
        self.assertIsNotNone(profile)
        self.assertEqual(profile.total_interactions, 10)

    def test_get_recent_profile(self) -> None:
        monitor = HumanDriftMonitor(baseline_window=10, recent_window=5)
        for i in range(15):
            monitor.record_event(_make_event(index=i))
        recent = monitor.get_recent_profile("reviewer1")
        self.assertIsNotNone(recent)
        self.assertEqual(recent.total_interactions, 5)

    def test_get_recent_profile_insufficient_data(self) -> None:
        monitor = HumanDriftMonitor(baseline_window=10, recent_window=5)
        for i in range(3):
            monitor.record_event(_make_event(index=i))
        recent = monitor.get_recent_profile("reviewer1")
        self.assertIsNone(recent)

    def test_get_reviewer_ids(self) -> None:
        monitor = HumanDriftMonitor(baseline_window=5, recent_window=3)
        for i in range(5):
            monitor.record_event(_make_event(reviewer_id="alice", index=i))
        for i in range(5):
            monitor.record_event(_make_event(reviewer_id="bob", index=i))
        ids = monitor.get_reviewer_ids()
        self.assertIn("alice", ids)
        self.assertIn("bob", ids)


# ── Team oversight metrics tests ───────────────────────────────────────


class TestTeamOversightMetrics(TestCase):
    def test_single_point_of_failure(self) -> None:
        monitor = HumanDriftMonitor(baseline_window=5, recent_window=3)
        for i in range(80):
            monitor.record_event(_make_event(reviewer_id="A", duration=20, index=i))
        for i in range(20):
            monitor.record_event(_make_event(reviewer_id="B", duration=20, index=i))

        metrics = TeamOversightMetrics(monitor).compute()
        self.assertTrue(metrics["single_point_of_failure"])
        self.assertGreater(metrics["highest_concentration"], 0.7)

    def test_balanced_team(self) -> None:
        monitor = HumanDriftMonitor(baseline_window=5, recent_window=3)
        for reviewer in ["A", "B", "C", "D"]:
            for i in range(25):
                monitor.record_event(_make_event(reviewer_id=reviewer, duration=20, index=i))

        metrics = TeamOversightMetrics(monitor).compute()
        self.assertFalse(metrics["single_point_of_failure"])
        self.assertLess(metrics["highest_concentration"], 0.35)

    def test_empty_team(self) -> None:
        monitor = HumanDriftMonitor(baseline_window=5, recent_window=3)
        metrics = TeamOversightMetrics(monitor).compute()
        self.assertEqual(metrics["total_reviewers"], 0)

    def test_team_metrics_fields(self) -> None:
        monitor = HumanDriftMonitor(baseline_window=5, recent_window=3)
        for i in range(10):
            monitor.record_event(_make_event(reviewer_id="A", index=i))

        metrics = TeamOversightMetrics(monitor).compute()
        self.assertIn("total_reviewers", metrics)
        self.assertIn("profiled_reviewers", metrics)
        self.assertIn("total_reviews", metrics)
        self.assertIn("team_approval_rate", metrics)
        self.assertIn("team_rationale_rate", metrics)
        self.assertIn("active_alerts", metrics)


# ── Routing recommendation tests ───────────────────────────────────────


class TestRoutingRecommendation(TestCase):
    def test_fatigue_recommends_rotation(self) -> None:
        result = _make_drift_result(fatigue_score=0.8)
        rec = RoutingRecommendation.from_drift_result(result)
        self.assertEqual(rec.recommendation, "rotate")
        self.assertEqual(rec.urgency, "high")
        self.assertEqual(rec.suggested_for, "all")

    def test_risk_drift_recommends_reduce_high_risk(self) -> None:
        result = _make_drift_result(risk_timing_drift=0.6, fatigue_score=0.1)
        rec = RoutingRecommendation.from_drift_result(result)
        self.assertEqual(rec.recommendation, "reduce_high_risk")
        self.assertEqual(rec.suggested_for, "high_risk")

    def test_severe_drift_flags_for_admin(self) -> None:
        result = _make_drift_result(
            drift_category="severe", overall_drift=0.6,
            fatigue_score=0.1, risk_timing_drift=0.1,
        )
        rec = RoutingRecommendation.from_drift_result(result)
        self.assertEqual(rec.recommendation, "flag_for_admin")

    def test_stable_recommends_no_change(self) -> None:
        result = _make_drift_result(drift_category="stable", overall_drift=0.05)
        rec = RoutingRecommendation.from_drift_result(result)
        self.assertEqual(rec.recommendation, "no_change")
        self.assertEqual(rec.urgency, "low")

    def test_to_dict(self) -> None:
        result = _make_drift_result(fatigue_score=0.8)
        rec = RoutingRecommendation.from_drift_result(result)
        d = rec.to_dict()
        self.assertIn("recommendation", d)
        self.assertIn("urgency", d)
        self.assertIn("reason", d)
        self.assertIn("suggested_for", d)

    def test_fatigue_takes_priority_over_risk_drift(self) -> None:
        """High fatigue takes priority even when risk drift is also high."""
        result = _make_drift_result(fatigue_score=0.9, risk_timing_drift=0.8)
        rec = RoutingRecommendation.from_drift_result(result)
        self.assertEqual(rec.recommendation, "rotate")


# ── Audit store tests ─────────────────────────────────────────────────


class TestHumanAuditStore(TestCase):
    def test_append_and_query(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            store = HumanAuditStore(Path(tmpdir))
            event = _make_event(index=0)
            store.append(event)
            events = store.query("reviewer1")
            self.assertEqual(len(events), 1)
            self.assertEqual(events[0].reviewer_id, "reviewer1")

    def test_query_all_chronological(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            store = HumanAuditStore(Path(tmpdir))
            for i in range(5):
                store.append(_make_event(index=i))
            events = store.query_all("reviewer1")
            self.assertEqual(len(events), 5)
            for i in range(1, len(events)):
                self.assertGreaterEqual(events[i].timestamp, events[i - 1].timestamp)

    def test_verify_chain_valid(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            store = HumanAuditStore(Path(tmpdir))
            for i in range(3):
                store.append(_make_event(index=i))
            is_valid, count, message = store.verify_chain("reviewer1")
            self.assertTrue(is_valid)
            self.assertEqual(count, 3)
            self.assertIn("verified", message.lower())

    def test_verify_chain_empty(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            store = HumanAuditStore(Path(tmpdir))
            is_valid, count, message = store.verify_chain("nonexistent")
            self.assertTrue(is_valid)
            self.assertEqual(count, 0)

    def test_list_reviewers(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            store = HumanAuditStore(Path(tmpdir))
            store.append(_make_event(reviewer_id="alice", index=0))
            store.append(_make_event(reviewer_id="bob", index=1))
            reviewers = store.list_reviewers()
            self.assertIn("alice", reviewers)
            self.assertIn("bob", reviewers)

    def test_query_limit(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            store = HumanAuditStore(Path(tmpdir))
            for i in range(10):
                store.append(_make_event(index=i))
            events = store.query("reviewer1", limit=3)
            self.assertEqual(len(events), 3)

    def test_query_empty_reviewer(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            store = HumanAuditStore(Path(tmpdir))
            events = store.query("nonexistent")
            self.assertEqual(len(events), 0)

    def test_risk_fields_persist(self) -> None:
        """Risk fields survive serialization roundtrip through audit store."""
        with tempfile.TemporaryDirectory() as tmpdir:
            store = HumanAuditStore(Path(tmpdir))
            event = _make_event(
                index=0, action_risk="high", action_ucs=0.7, action_tier=3
            )
            store.append(event)
            events = store.query("reviewer1")
            self.assertEqual(events[0].action_risk, "high")
            self.assertAlmostEqual(events[0].action_ucs, 0.7)
            self.assertEqual(events[0].action_tier, 3)


# ── Event tests ────────────────────────────────────────────────────────


class TestHumanInteractionEvent(TestCase):
    def test_to_dict(self) -> None:
        event = _make_event(index=0)
        d = event.to_dict()
        self.assertEqual(d["reviewer_id"], "reviewer1")
        self.assertEqual(d["decision"], "approved")

    def test_from_dict_roundtrip(self) -> None:
        event = _make_event(index=0)
        d = event.to_dict()
        restored = HumanInteractionEvent.from_dict(d)
        self.assertEqual(restored.reviewer_id, event.reviewer_id)
        self.assertEqual(restored.decision, event.decision)
        self.assertAlmostEqual(restored.review_duration_seconds, event.review_duration_seconds)

    def test_risk_fields_default(self) -> None:
        event = _make_event(index=0)
        self.assertEqual(event.action_risk, "low")
        self.assertEqual(event.action_ucs, 0.0)
        self.assertEqual(event.action_tier, 0)

    def test_risk_adjusted_duration_property(self) -> None:
        event = _make_event(duration=30, action_risk="high")
        score = event.risk_adjusted_duration
        self.assertIsInstance(score, float)
        self.assertGreaterEqual(score, 0.0)
