"""Tests for Pre-Execution Budget Gate (Item 17)."""

import threading
import time

import pytest

from nomotic.budget_gate import (
    BudgetExhaustedError,
    BudgetGate,
    BudgetGateResult,
    BudgetLimit,
    BudgetReservation,
)
from nomotic.runtime import GovernanceRuntime, RuntimeConfig
from nomotic.types import Action, AgentContext, TrustProfile, Verdict


# ── Helpers ────────────────────────────────────────────────────────────


def _gate(
    daily: float | None = None,
    monthly: float | None = None,
    per_action: float | None = None,
    ttl: int = 3600,
    group_id: str = "g1",
    agents: dict[str, str] | None = None,
) -> BudgetGate:
    """Build a BudgetGate with a single group and optional agent mapping."""
    limit = BudgetLimit(
        group_id=group_id,
        daily_limit_usd=daily,
        monthly_limit_usd=monthly,
        per_action_limit_usd=per_action,
        reservation_ttl_seconds=ttl,
    )
    agent_map = agents or {"agent-1": group_id}
    return BudgetGate(limits=[limit], agent_group_map=agent_map)


def _ctx(agent_id: str = "agent-1", trust: float = 0.5) -> AgentContext:
    return AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id, overall_trust=trust),
    )


def _action(
    action_type: str = "read",
    target: str = "db",
    metadata: dict | None = None,
) -> Action:
    return Action(
        agent_id="agent-1",
        action_type=action_type,
        target=target,
        metadata=metadata or {},
    )


# ── Unit tests: BudgetGate ────────────────────────────────────────────


class TestBudgetGateBasic:
    def test_ungrouped_agent_always_approved(self):
        """An agent not in any group is always approved."""
        gate = BudgetGate(
            limits=[BudgetLimit(group_id="g1", daily_limit_usd=0.01)],
            agent_group_map={},
        )
        result = gate.check_and_reserve("unknown-agent", "a1", 100.0)
        assert result.approved is True
        assert result.reservation is None
        assert result.group_id == ""

    def test_no_limit_for_group_always_approved(self):
        """An agent in a group with no limit configured is always approved."""
        gate = BudgetGate(
            limits=[],
            agent_group_map={"agent-1": "g1"},
        )
        result = gate.check_and_reserve("agent-1", "a1", 100.0)
        assert result.approved is True
        assert result.reservation is None

    def test_per_action_limit_exceeded_denied(self):
        """Per-action cost exceeding limit is denied."""
        gate = _gate(per_action=1.00)
        result = gate.check_and_reserve("agent-1", "a1", 1.50)
        assert result.approved is False
        assert "Per-action cost" in result.denial_reason
        assert "$1.5000" in result.denial_reason

    def test_per_action_limit_within_passes(self):
        """Per-action cost within limit is approved."""
        gate = _gate(per_action=2.00)
        result = gate.check_and_reserve("agent-1", "a1", 1.50)
        assert result.approved is True
        assert result.reservation is not None

    def test_daily_limit_exceeded_denied(self):
        """Daily budget exceeded is denied."""
        gate = _gate(daily=5.00)
        # First reservation: $3
        r1 = gate.check_and_reserve("agent-1", "a1", 3.00)
        assert r1.approved is True
        # Second reservation: $3 would exceed $5 daily
        r2 = gate.check_and_reserve("agent-1", "a2", 3.00)
        assert r2.approved is False
        assert "Daily budget" in r2.denial_reason

    def test_daily_limit_within_passes(self):
        """Daily budget within limit is approved."""
        gate = _gate(daily=10.00)
        result = gate.check_and_reserve("agent-1", "a1", 5.00)
        assert result.approved is True

    def test_monthly_limit_exceeded_denied(self):
        """Monthly budget exceeded is denied."""
        gate = _gate(monthly=5.00)
        r1 = gate.check_and_reserve("agent-1", "a1", 3.00)
        assert r1.approved is True
        r2 = gate.check_and_reserve("agent-1", "a2", 3.00)
        assert r2.approved is False
        assert "Monthly budget" in r2.denial_reason

    def test_monthly_limit_within_passes(self):
        """Monthly budget within limit is approved."""
        gate = _gate(monthly=10.00)
        result = gate.check_and_reserve("agent-1", "a1", 5.00)
        assert result.approved is True


class TestBudgetGateReservations:
    def test_reservations_count_toward_limit(self):
        """Active reservations count toward spend totals."""
        gate = _gate(daily=5.00)
        # Reserve $2
        r1 = gate.check_and_reserve("agent-1", "a1", 2.00)
        assert r1.approved is True
        # Reserve $2 more ($4 total)
        r2 = gate.check_and_reserve("agent-1", "a2", 2.00)
        assert r2.approved is True
        # Reserve $2 more ($6 total > $5 limit)
        r3 = gate.check_and_reserve("agent-1", "a3", 2.00)
        assert r3.approved is False

    def test_reservation_created_on_approval(self):
        """An approved check_and_reserve creates a reservation."""
        gate = _gate(daily=10.00)
        result = gate.check_and_reserve("agent-1", "a1", 1.00)
        assert result.approved is True
        assert result.reservation is not None
        assert result.reservation.reservation_id.startswith("nmbr-")
        assert result.reservation.group_id == "g1"
        assert result.reservation.agent_id == "agent-1"
        assert result.reservation.action_id == "a1"
        assert result.reservation.estimated_cost_usd == 1.00
        assert result.reservation.settled is False

    def test_reservation_not_created_on_denial(self):
        """A denied check_and_reserve does not create a reservation."""
        gate = _gate(daily=0.50)
        result = gate.check_and_reserve("agent-1", "a1", 1.00)
        assert result.approved is False
        assert result.reservation is None
        # No active reservations should exist
        assert len(gate.get_active_reservations()) == 0


class TestBudgetGateSettlement:
    def test_settle_marks_reservation_settled(self):
        """Settling a reservation marks it as settled with actual cost."""
        gate = _gate(daily=10.00)
        result = gate.check_and_reserve("agent-1", "a1", 1.00)
        rid = result.reservation.reservation_id

        gate.settle(rid, 0.75)

        # Should be no active reservations
        active = gate.get_active_reservations()
        assert len(active) == 0

    def test_settle_invalid_reservation_raises(self):
        """Settling a nonexistent reservation raises ValueError."""
        gate = _gate(daily=10.00)
        with pytest.raises(ValueError, match="not found"):
            gate.settle("nmbr-nonexistent", 1.0)

    def test_settle_double_settle_raises(self):
        """Settling an already-settled reservation raises ValueError."""
        gate = _gate(daily=10.00)
        result = gate.check_and_reserve("agent-1", "a1", 1.00)
        rid = result.reservation.reservation_id
        gate.settle(rid, 0.75)
        with pytest.raises(ValueError, match="not found or already settled"):
            gate.settle(rid, 0.75)


class TestBudgetGateExpiration:
    def test_expire_stale_reservations(self):
        """Stale reservations are expired and excluded from spend."""
        gate = _gate(daily=5.00, ttl=1)
        r1 = gate.check_and_reserve("agent-1", "a1", 3.00)
        assert r1.approved is True

        # Force the reservation to expire
        gate._reservations[0].expires_at = time.time() - 1

        expired = gate.expire_stale_reservations()
        assert expired == 1

        # Now the $3 reservation is gone — can reserve again
        r2 = gate.check_and_reserve("agent-1", "a2", 3.00)
        assert r2.approved is True

    def test_stale_reservations_excluded_from_spend(self):
        """Expired reservations are not counted in get_current_spend."""
        gate = _gate(daily=10.00, ttl=1)
        r1 = gate.check_and_reserve("agent-1", "a1", 5.00)
        assert r1.approved is True

        # Force expiry
        gate._reservations[0].expires_at = time.time() - 1

        spend = gate.get_current_spend("g1")
        assert spend["daily_usd"] == 0.0  # Expired reservation doesn't count


class TestBudgetGateDenialReason:
    def test_denial_reason_describes_which_limit(self):
        """Denial reason clearly states which limit was exceeded."""
        gate = _gate(per_action=0.50, daily=100.0, monthly=1000.0)
        result = gate.check_and_reserve("agent-1", "a1", 1.00)
        assert result.approved is False
        assert "Per-action" in result.denial_reason

        gate2 = _gate(daily=0.50)
        result2 = gate2.check_and_reserve("agent-1", "a1", 1.00)
        assert result2.approved is False
        assert "Daily" in result2.denial_reason

        gate3 = _gate(monthly=0.50)
        result3 = gate3.check_and_reserve("agent-1", "a1", 1.00)
        assert result3.approved is False
        assert "Monthly" in result3.denial_reason


class TestBudgetGateThreadSafety:
    def test_thread_safety_concurrent_reservations(self):
        """Concurrent reservations under thread contention respect limits."""
        gate = _gate(daily=10.00)
        results: list[BudgetGateResult] = []
        errors: list[Exception] = []

        def reserve(idx: int) -> None:
            try:
                r = gate.check_and_reserve("agent-1", f"a-{idx}", 1.00)
                results.append(r)
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=reserve, args=(i,)) for i in range(20)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0
        approved = [r for r in results if r.approved]
        denied = [r for r in results if not r.approved]
        # Exactly 10 should be approved ($1 each, $10 limit)
        assert len(approved) == 10
        assert len(denied) == 10


class TestBudgetGateQueries:
    def test_get_active_reservations_excludes_settled(self):
        """get_active_reservations does not include settled ones."""
        gate = _gate(daily=100.00)
        r1 = gate.check_and_reserve("agent-1", "a1", 1.00)
        r2 = gate.check_and_reserve("agent-1", "a2", 1.00)
        gate.settle(r1.reservation.reservation_id, 0.50)

        active = gate.get_active_reservations()
        assert len(active) == 1
        assert active[0].action_id == "a2"

    def test_get_current_spend_includes_reservations(self):
        """get_current_spend includes both actual and reserved amounts."""
        gate = _gate(daily=100.00)
        gate.check_and_reserve("agent-1", "a1", 3.00)
        gate.check_and_reserve("agent-1", "a2", 2.00)

        spend = gate.get_current_spend("g1")
        assert spend["daily_usd"] == pytest.approx(5.00)
        assert spend["monthly_usd"] == pytest.approx(5.00)


class TestBudgetGateResultAndError:
    def test_budget_gate_result_attributes(self):
        """BudgetGateResult has all required attributes."""
        result = BudgetGateResult(
            approved=True,
            group_id="g1",
            agent_id="agent-1",
            action_id="a1",
            estimated_cost_usd=1.50,
            daily_used_usd=3.00,
            daily_limit_usd=10.00,
            monthly_used_usd=15.00,
            monthly_limit_usd=100.00,
            denial_reason=None,
            reservation=None,
        )
        assert result.approved is True
        assert result.group_id == "g1"
        assert result.agent_id == "agent-1"
        assert result.action_id == "a1"
        assert result.estimated_cost_usd == 1.50
        assert result.daily_used_usd == 3.00
        assert result.daily_limit_usd == 10.00
        assert result.monthly_used_usd == 15.00
        assert result.monthly_limit_usd == 100.00
        assert result.denial_reason is None
        assert result.reservation is None

    def test_budget_exhausted_error_attributes(self):
        """BudgetExhaustedError carries the gate result."""
        result = BudgetGateResult(
            approved=False,
            group_id="g1",
            agent_id="agent-1",
            action_id="a1",
            estimated_cost_usd=5.00,
            daily_used_usd=8.00,
            daily_limit_usd=10.00,
            monthly_used_usd=50.00,
            monthly_limit_usd=100.00,
            denial_reason="Daily budget exceeded",
        )
        err = BudgetExhaustedError(result)
        assert err.result is result
        assert err.result.approved is False
        assert "g1" in str(err)
        assert "Daily budget exceeded" in str(err)


class TestBudgetGateConfiguration:
    def test_add_limit_after_init(self):
        """Limits can be added after construction."""
        gate = BudgetGate(agent_group_map={"agent-1": "g1"})
        # No limit yet — approved
        r1 = gate.check_and_reserve("agent-1", "a1", 100.0)
        assert r1.approved is True

        gate.add_limit(BudgetLimit(group_id="g1", daily_limit_usd=5.00))
        r2 = gate.check_and_reserve("agent-1", "a2", 100.0)
        assert r2.approved is False

    def test_assign_agent_to_group(self):
        """Agents can be assigned to groups after construction."""
        gate = BudgetGate(
            limits=[BudgetLimit(group_id="g1", per_action_limit_usd=1.00)],
        )
        # Not in group yet
        r1 = gate.check_and_reserve("agent-2", "a1", 5.00)
        assert r1.approved is True

        gate.assign_agent_to_group("agent-2", "g1")
        r2 = gate.check_and_reserve("agent-2", "a2", 5.00)
        assert r2.approved is False


# ── Runtime integration tests ──────────────────────────────────────────


def _gate_uahs(
    per_action: float = 1.00,
    uahs_enabled: bool = True,
    threshold: float = 0.5,
    reduction: float = 0.20,
    group_id: str = "g1",
    agents: dict[str, str] | None = None,
) -> BudgetGate:
    """Build a BudgetGate with UAHS adjustment fields configured."""
    limit = BudgetLimit(
        group_id=group_id,
        per_action_limit_usd=per_action,
        uahs_adjustment_enabled=uahs_enabled,
        uahs_health_threshold=threshold,
        uahs_reduction_factor=reduction,
    )
    agent_map = agents or {"agent-1": group_id}
    return BudgetGate(limits=[limit], agent_group_map=agent_map)


class TestUAHSBudgetAdjustment:
    def test_adjustment_disabled_by_default(self):
        """UAHS adjustment is disabled by default on BudgetLimit."""
        limit = BudgetLimit(group_id="g1", per_action_limit_usd=1.00)
        assert limit.uahs_adjustment_enabled is False
        gate = BudgetGate(limits=[limit], agent_group_map={"agent-1": "g1"})
        gate.set_uahs_accessor(lambda aid: 0.1)  # Very low health
        result = gate.check_and_reserve("agent-1", "a1", 0.90)
        # Should still be approved since adjustment is disabled
        assert result.approved is True
        assert result.health_adjusted is False

    def test_adjustment_not_applied_when_accessor_not_set(self):
        """Without a UAHS accessor, adjustment is not applied even if enabled."""
        gate = _gate_uahs(per_action=1.00, uahs_enabled=True)
        # No accessor set — _get_effective_per_action_limit returns base
        effective = gate._get_effective_per_action_limit(
            "agent-1",
            BudgetLimit(
                group_id="g1",
                per_action_limit_usd=1.00,
                uahs_adjustment_enabled=True,
            ),
        )
        assert effective == 1.00

    def test_adjustment_not_applied_above_threshold(self):
        """When health >= threshold, per_action_limit is unchanged."""
        gate = _gate_uahs(per_action=1.00, threshold=0.5)
        gate.set_uahs_accessor(lambda aid: 0.7)  # Above threshold
        result = gate.check_and_reserve("agent-1", "a1", 0.95)
        assert result.approved is True
        assert result.health_adjusted is False
        assert result.health_score == 0.7

    def test_adjustment_applied_below_threshold(self):
        """When health < threshold, per_action_limit is reduced."""
        gate = _gate_uahs(per_action=1.00, threshold=0.5, reduction=0.20)
        gate.set_uahs_accessor(lambda aid: 0.3)  # Below threshold
        # Effective limit = 1.00 * 0.80 = 0.80
        # Cost 0.85 > 0.80 → denied
        result = gate.check_and_reserve("agent-1", "a1", 0.85)
        assert result.approved is False
        assert result.health_adjusted is True
        assert "Per-action" in result.denial_reason
        assert "$0.8000" in result.denial_reason

    def test_reduction_factor_applied_correctly(self):
        """Reduction factor math: effective = base * (1 - factor)."""
        gate = _gate_uahs(per_action=0.10, threshold=0.5, reduction=0.20)
        gate.set_uahs_accessor(lambda aid: 0.3)
        limit = gate._limits["g1"]
        effective = gate._get_effective_per_action_limit("agent-1", limit)
        expected = 0.10 * 0.80
        assert abs(effective - expected) < 0.001

    def test_reduction_floored_at_10_percent(self):
        """Reduction floor: effective limit never falls below 10% of original."""
        gate = _gate_uahs(per_action=1.00, threshold=0.5, reduction=0.95)
        gate.set_uahs_accessor(lambda aid: 0.1)  # Very unhealthy
        limit = gate._limits["g1"]
        effective = gate._get_effective_per_action_limit("agent-1", limit)
        # 1.00 * (1 - 0.95) = 0.05, but floor is 1.00 * 0.10 = 0.10
        assert abs(effective - 0.10) < 0.001

    def test_none_health_score_returns_original_limit(self):
        """When accessor returns None, per_action_limit is unchanged."""
        gate = _gate_uahs(per_action=1.00, threshold=0.5)
        gate.set_uahs_accessor(lambda aid: None)
        limit = gate._limits["g1"]
        effective = gate._get_effective_per_action_limit("agent-1", limit)
        assert effective == 1.00

    def test_budget_gate_result_health_adjusted_flag(self):
        """BudgetGateResult.health_adjusted is True when limit was reduced."""
        gate = _gate_uahs(per_action=1.00, threshold=0.5, reduction=0.20)
        gate.set_uahs_accessor(lambda aid: 0.3)
        # Cost 0.75 < effective 0.80 → approved, but health_adjusted=True
        result = gate.check_and_reserve("agent-1", "a1", 0.75)
        assert result.approved is True
        assert result.health_adjusted is True

    def test_budget_gate_result_health_score_populated(self):
        """BudgetGateResult.health_score contains the UAHS score from accessor."""
        gate = _gate_uahs(per_action=1.00, threshold=0.5)
        gate.set_uahs_accessor(lambda aid: 0.42)
        result = gate.check_and_reserve("agent-1", "a1", 0.50)
        assert result.health_score == 0.42

    def test_runtime_wires_uahs_accessor_when_both_enabled(self):
        """GovernanceRuntime wires UAHS accessor into budget gate when both enabled."""
        gate = _gate_uahs(per_action=1.00)
        config = RuntimeConfig(budget_gate=gate)
        runtime = GovernanceRuntime(config, enable_uahs=True)
        # The budget gate should now have a UAHS accessor wired
        assert runtime._budget_gate._uahs_accessor is not None

    def test_runtime_no_wiring_when_uahs_disabled(self):
        """When UAHS is disabled, no accessor is wired into the budget gate."""
        gate = _gate_uahs(per_action=1.00)
        config = RuntimeConfig(budget_gate=gate)
        runtime = GovernanceRuntime(config, enable_uahs=False)
        # No accessor should be wired
        assert runtime._budget_gate._uahs_accessor is None

    def test_custom_threshold_used(self):
        """Custom uahs_health_threshold is respected."""
        gate = _gate_uahs(per_action=1.00, threshold=0.8, reduction=0.20)
        gate.set_uahs_accessor(lambda aid: 0.6)  # Below 0.8 threshold
        limit = gate._limits["g1"]
        effective = gate._get_effective_per_action_limit("agent-1", limit)
        assert abs(effective - 0.80) < 0.001  # 1.00 * (1 - 0.20) = 0.80

        # With health=0.9 (above 0.8 threshold), no reduction
        gate.set_uahs_accessor(lambda aid: 0.9)
        effective2 = gate._get_effective_per_action_limit("agent-1", limit)
        assert effective2 == 1.00


class TestRuntimeBudgetGateIntegration:
    def test_runtime_budget_gate_none_skips_check(self):
        """When budget_gate is None, begin_execution works normally."""
        config = RuntimeConfig()
        assert config.budget_gate is None
        runtime = GovernanceRuntime(config)
        scope = runtime.registry.get("scope_compliance")
        scope.configure_agent_scope("agent-1", {"*"})

        action = _action("read")
        ctx = _ctx()
        verdict = runtime.evaluate(action, ctx)
        assert verdict.verdict == Verdict.ALLOW
        handle = runtime.begin_execution(action, ctx)
        assert not handle.is_interrupted
        runtime.complete_execution(action.id, ctx)

    def test_runtime_budget_gate_blocks_begin_execution(self):
        """When budget is exhausted, begin_execution raises BudgetExhaustedError."""
        gate = _gate(daily=0.50)
        config = RuntimeConfig(budget_gate=gate)
        runtime = GovernanceRuntime(config)
        scope = runtime.registry.get("scope_compliance")
        scope.configure_agent_scope("agent-1", {"*"})

        action = _action("read", metadata={"estimated_cost_usd": 1.00})
        ctx = _ctx()
        verdict = runtime.evaluate(action, ctx)
        assert verdict.verdict == Verdict.ALLOW

        with pytest.raises(BudgetExhaustedError) as exc_info:
            runtime.begin_execution(action, ctx)
        assert exc_info.value.result.approved is False
        assert "Daily budget" in exc_info.value.result.denial_reason

    def test_runtime_budget_gate_settles_on_completion(self):
        """Budget reservation is settled when execution completes."""
        gate = _gate(daily=10.00)
        config = RuntimeConfig(budget_gate=gate)
        runtime = GovernanceRuntime(config)
        scope = runtime.registry.get("scope_compliance")
        scope.configure_agent_scope("agent-1", {"*"})

        action = _action("read", metadata={"estimated_cost_usd": 2.00})
        ctx = _ctx()
        verdict = runtime.evaluate(action, ctx)
        assert verdict.verdict == Verdict.ALLOW

        handle = runtime.begin_execution(action, ctx)
        assert not handle.is_interrupted

        # Verify reservation exists
        active = gate.get_active_reservations()
        assert len(active) == 1
        assert active[0].estimated_cost_usd == 2.00

        # Complete execution with actual cost
        runtime.complete_execution(action.id, ctx, outcome={"actual_cost_usd": 1.50})

        # Reservation should be settled
        active_after = gate.get_active_reservations()
        assert len(active_after) == 0
