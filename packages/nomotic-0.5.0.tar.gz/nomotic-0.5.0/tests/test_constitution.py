"""Tests for the Constitutional Rules Engine (Item 14, v0.5.0).

Minimum 30 test functions covering rule hashing, ruleset signing,
signature verification, all five rule types, engine lifecycle,
runtime integration, and serialisation round-trips.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import tempfile
import time
import uuid
from pathlib import Path
from typing import Any

import pytest

from nomotic.constitution import (
    ConstitutionalEngine,
    ConstitutionalIntegrityError,
    ConstitutionalRule,
    ConstitutionalRuleSet,
    ConstitutionalViolation,
    ConstitutionalViolationError,
    build_default_constitutional_rules,
)
from nomotic.types import Action, AgentContext, TrustProfile


# ── Helpers ──────────────────────────────────────────────────────────────


def _make_key() -> bytes:
    """Generate a 32-byte random key for test signing."""
    return os.urandom(32)


def _make_rule(
    rule_type: str = "deny_always",
    condition: dict[str, Any] | None = None,
    name: str = "test-rule",
) -> ConstitutionalRule:
    """Create a test constitutional rule with computed hash."""
    rule = ConstitutionalRule(
        rule_id=f"nmcr-{uuid.uuid4()}",
        name=name,
        description="A test rule",
        rule_type=rule_type,
        condition=condition or {},
        created_by="test-authority",
        created_at=time.time(),
    )
    rule.rule_hash = rule.compute_hash()
    return rule


def _sign_ruleset(
    rules: list[ConstitutionalRule],
    key: bytes,
    authority: str = "test-ca",
) -> ConstitutionalRuleSet:
    """Sign a list of rules into a ruleset."""
    rs = ConstitutionalRuleSet(
        ruleset_id=f"nmcrs-{uuid.uuid4()}",
        rules=rules,
        signed_by=authority,
        signed_at=time.time(),
        signature="",
    )
    rs.ruleset_hash = rs.compute_ruleset_hash()
    rs.signature = hmac.new(
        key, rs.ruleset_hash.encode("utf-8"), hashlib.sha256,
    ).hexdigest()
    return rs


def _make_action(
    action_type: str = "read",
    target: str = "/data/file.txt",
    metadata: dict[str, Any] | None = None,
) -> Action:
    return Action(
        agent_id="agent-1",
        action_type=action_type,
        target=target,
        metadata=metadata or {},
    )


def _make_context(
    trust: float = 0.5,
    metadata: dict[str, Any] | None = None,
) -> AgentContext:
    return AgentContext(
        agent_id="agent-1",
        trust_profile=TrustProfile(agent_id="agent-1", overall_trust=trust),
        metadata=metadata or {},
    )


# ── Rule Hash Tests ──────────────────────────────────────────────────────


def test_rule_hash_computation():
    """Verify hash is deterministic and changes on field mutation."""
    rule = _make_rule(name="stable-rule")
    h1 = rule.compute_hash()
    h2 = rule.compute_hash()
    assert h1 == h2, "Hash should be deterministic"
    assert len(h1) == 64, "SHA-256 hex should be 64 chars"

    # Mutate a field — hash should change
    rule.name = "mutated-rule"
    h3 = rule.compute_hash()
    assert h3 != h1, "Hash should change when name is mutated"


def test_ruleset_hash_computation():
    """Verify ruleset hash covers all rules."""
    r1 = _make_rule(name="rule-a")
    r2 = _make_rule(name="rule-b")

    key = _make_key()
    rs = _sign_ruleset([r1, r2], key)
    h1 = rs.compute_ruleset_hash()

    # Same rules → same hash
    assert h1 == rs.compute_ruleset_hash()

    # Adding a rule changes the hash
    r3 = _make_rule(name="rule-c")
    rs2 = _sign_ruleset([r1, r2, r3], key)
    assert rs2.compute_ruleset_hash() != h1


# ── Signature Tests ──────────────────────────────────────────────────────


def test_signature_verification_valid():
    """Sign and verify succeeds."""
    key = _make_key()
    r1 = _make_rule()
    rs = _sign_ruleset([r1], key)
    assert rs.verify_signature(key) is True


def test_signature_verification_invalid():
    """Tampered ruleset fails verify."""
    key = _make_key()
    r1 = _make_rule()
    rs = _sign_ruleset([r1], key)

    # Tamper with ruleset_hash
    rs.ruleset_hash = "tampered" + rs.ruleset_hash[8:]
    assert rs.verify_signature(key) is False


# ── deny_always Tests ────────────────────────────────────────────────────


def test_deny_always_action_type_match():
    """deny_always matches on action_type."""
    key = _make_key()
    rule = _make_rule(
        rule_type="deny_always",
        condition={"action_types": ["delete"]},
    )
    rs = _sign_ruleset([rule], key)
    engine = ConstitutionalEngine(ruleset=rs, verify_key_bytes=key)

    action = _make_action(action_type="delete")
    ctx = _make_context()
    violations = engine.evaluate(action, ctx)
    assert len(violations) == 1
    assert violations[0].rule_type == "deny_always"


def test_deny_always_glob_pattern():
    """deny_always supports glob patterns for action_types and targets."""
    key = _make_key()
    rule = _make_rule(
        rule_type="deny_always",
        condition={
            "action_types": ["admin.*"],
            "targets": ["/secret/*"],
        },
    )
    rs = _sign_ruleset([rule], key)
    engine = ConstitutionalEngine(ruleset=rs, verify_key_bytes=key)

    # Matching both
    action = _make_action(action_type="admin.delete", target="/secret/keys")
    violations = engine.evaluate(action, _make_context())
    assert len(violations) == 1

    # No match on target
    action2 = _make_action(action_type="admin.read", target="/public/file")
    violations2 = engine.evaluate(action2, _make_context())
    assert len(violations2) == 0


def test_deny_always_no_match_passes():
    """deny_always does not trigger on non-matching action."""
    key = _make_key()
    rule = _make_rule(
        rule_type="deny_always",
        condition={"action_types": ["delete"]},
    )
    rs = _sign_ruleset([rule], key)
    engine = ConstitutionalEngine(ruleset=rs, verify_key_bytes=key)

    action = _make_action(action_type="read")
    violations = engine.evaluate(action, _make_context())
    assert len(violations) == 0


# ── require_certificate Tests ────────────────────────────────────────────


def test_require_certificate_missing_cert():
    """require_certificate violates when no cert_id in context."""
    key = _make_key()
    rule = _make_rule(
        rule_type="require_certificate",
        condition={"min_trust": 0.0, "required_fields": []},
    )
    rs = _sign_ruleset([rule], key)
    engine = ConstitutionalEngine(ruleset=rs, verify_key_bytes=key)

    # No cert_id in metadata
    action = _make_action()
    ctx = _make_context(metadata={})
    violations = engine.evaluate(action, ctx)
    assert len(violations) == 1
    assert "No agent certificate" in violations[0].reason


def test_require_certificate_trust_below_floor():
    """require_certificate violates when cert trust below min_trust."""
    key = _make_key()
    rule = _make_rule(
        rule_type="require_certificate",
        condition={"min_trust": 0.5, "required_fields": []},
    )
    rs = _sign_ruleset([rule], key)
    engine = ConstitutionalEngine(ruleset=rs, verify_key_bytes=key)

    action = _make_action()
    ctx = _make_context(metadata={"cert_id": "nmc-123", "cert_trust": 0.2})
    violations = engine.evaluate(action, ctx)
    assert len(violations) == 1
    assert "below constitutional minimum" in violations[0].reason


def test_require_certificate_passes():
    """require_certificate passes with valid cert."""
    key = _make_key()
    rule = _make_rule(
        rule_type="require_certificate",
        condition={"min_trust": 0.0, "required_fields": []},
    )
    rs = _sign_ruleset([rule], key)
    engine = ConstitutionalEngine(ruleset=rs, verify_key_bytes=key)

    action = _make_action()
    ctx = _make_context(metadata={"cert_id": "nmc-123", "cert_trust": 0.5})
    violations = engine.evaluate(action, ctx)
    assert len(violations) == 0


# ── trust_floor Tests ────────────────────────────────────────────────────


def test_trust_floor_below_minimum():
    """trust_floor violates when agent trust is below min_trust."""
    key = _make_key()
    rule = _make_rule(
        rule_type="trust_floor",
        condition={"min_trust": 0.3, "applies_to_irreversible": False},
    )
    rs = _sign_ruleset([rule], key)
    engine = ConstitutionalEngine(ruleset=rs, verify_key_bytes=key)

    action = _make_action()
    ctx = _make_context(trust=0.1)
    violations = engine.evaluate(action, ctx)
    assert len(violations) == 1
    assert "below constitutional floor" in violations[0].reason


def test_trust_floor_passes():
    """trust_floor passes when agent trust is above min_trust."""
    key = _make_key()
    rule = _make_rule(
        rule_type="trust_floor",
        condition={"min_trust": 0.3, "applies_to_irreversible": False},
    )
    rs = _sign_ruleset([rule], key)
    engine = ConstitutionalEngine(ruleset=rs, verify_key_bytes=key)

    action = _make_action()
    ctx = _make_context(trust=0.5)
    violations = engine.evaluate(action, ctx)
    assert len(violations) == 0


def test_trust_floor_irreversible_only():
    """trust_floor with applies_to_irreversible=True only checks irreversible."""
    key = _make_key()
    rule = _make_rule(
        rule_type="trust_floor",
        condition={"min_trust": 0.5, "applies_to_irreversible": True},
    )
    rs = _sign_ruleset([rule], key)
    engine = ConstitutionalEngine(ruleset=rs, verify_key_bytes=key)

    # Reversible action — should pass even with low trust
    action = _make_action()
    ctx = _make_context(trust=0.1)
    violations = engine.evaluate(action, ctx)
    assert len(violations) == 0

    # Irreversible action — should violate
    action2 = _make_action(metadata={"irreversible": True})
    violations2 = engine.evaluate(action2, ctx)
    assert len(violations2) == 1


# ── scope_hard_limit Tests ───────────────────────────────────────────────


def test_scope_hard_limit_forbidden_action():
    """scope_hard_limit violates on forbidden action_type."""
    key = _make_key()
    rule = _make_rule(
        rule_type="scope_hard_limit",
        condition={
            "forbidden_action_types": ["shutdown", "format_disk"],
            "forbidden_targets": [],
        },
    )
    rs = _sign_ruleset([rule], key)
    engine = ConstitutionalEngine(ruleset=rs, verify_key_bytes=key)

    action = _make_action(action_type="shutdown")
    violations = engine.evaluate(action, _make_context())
    assert len(violations) == 1
    assert "constitutionally forbidden" in violations[0].reason


def test_scope_hard_limit_forbidden_target_glob():
    """scope_hard_limit violates on forbidden target glob."""
    key = _make_key()
    rule = _make_rule(
        rule_type="scope_hard_limit",
        condition={
            "forbidden_action_types": [],
            "forbidden_targets": ["/system/*", "/root/*"],
        },
    )
    rs = _sign_ruleset([rule], key)
    engine = ConstitutionalEngine(ruleset=rs, verify_key_bytes=key)

    action = _make_action(target="/system/config")
    violations = engine.evaluate(action, _make_context())
    assert len(violations) == 1

    action2 = _make_action(target="/home/user/safe")
    violations2 = engine.evaluate(action2, _make_context())
    assert len(violations2) == 0


def test_scope_hard_limit_passes():
    """scope_hard_limit passes on non-forbidden action/target."""
    key = _make_key()
    rule = _make_rule(
        rule_type="scope_hard_limit",
        condition={
            "forbidden_action_types": ["shutdown"],
            "forbidden_targets": ["/system/*"],
        },
    )
    rs = _sign_ruleset([rule], key)
    engine = ConstitutionalEngine(ruleset=rs, verify_key_bytes=key)

    action = _make_action(action_type="read", target="/data/file.txt")
    violations = engine.evaluate(action, _make_context())
    assert len(violations) == 0


# ── archetype_restriction Tests ──────────────────────────────────────────


def test_archetype_restriction_match():
    """archetype_restriction violates on matching archetype + action."""
    key = _make_key()
    rule = _make_rule(
        rule_type="archetype_restriction",
        condition={
            "archetypes": ["observer"],
            "denied_action_types": ["write", "delete"],
        },
    )
    rs = _sign_ruleset([rule], key)
    engine = ConstitutionalEngine(ruleset=rs, verify_key_bytes=key)

    action = _make_action(action_type="write")
    ctx = _make_context(metadata={"archetype": "observer"})
    violations = engine.evaluate(action, ctx)
    assert len(violations) == 1
    assert "observer" in violations[0].reason


def test_archetype_restriction_different_archetype_passes():
    """archetype_restriction passes for non-matching archetype."""
    key = _make_key()
    rule = _make_rule(
        rule_type="archetype_restriction",
        condition={
            "archetypes": ["observer"],
            "denied_action_types": ["write"],
        },
    )
    rs = _sign_ruleset([rule], key)
    engine = ConstitutionalEngine(ruleset=rs, verify_key_bytes=key)

    action = _make_action(action_type="write")
    ctx = _make_context(metadata={"archetype": "executor"})
    violations = engine.evaluate(action, ctx)
    assert len(violations) == 0


# ── Engine Lifecycle Tests ───────────────────────────────────────────────


def test_multiple_violations_returns_all():
    """Multiple violated rules all appear in the result."""
    key = _make_key()
    r1 = _make_rule(
        rule_type="deny_always",
        condition={"action_types": ["delete"]},
        name="deny-delete",
    )
    r2 = _make_rule(
        rule_type="trust_floor",
        condition={"min_trust": 0.9, "applies_to_irreversible": False},
        name="high-trust-floor",
    )
    rs = _sign_ruleset([r1, r2], key)
    engine = ConstitutionalEngine(ruleset=rs, verify_key_bytes=key)

    action = _make_action(action_type="delete")
    ctx = _make_context(trust=0.5)
    violations = engine.evaluate(action, ctx)
    assert len(violations) == 2
    types = {v.rule_name for v in violations}
    assert "deny-delete" in types
    assert "high-trust-floor" in types


def test_empty_ruleset_returns_no_violations():
    """An empty ruleset produces no violations."""
    key = _make_key()
    rs = _sign_ruleset([], key)
    engine = ConstitutionalEngine(ruleset=rs, verify_key_bytes=key)

    action = _make_action()
    violations = engine.evaluate(action, _make_context())
    assert len(violations) == 0
    assert engine.has_rules() is False
    assert engine.rule_count() == 0


def test_engine_passthrough_mode_no_rules():
    """Engine without ruleset operates in passthrough mode."""
    engine = ConstitutionalEngine()
    assert engine.has_rules() is False
    assert engine.rule_count() == 0

    action = _make_action(action_type="delete")
    violations = engine.evaluate(action, _make_context())
    assert len(violations) == 0


def test_engine_strict_mode_raises_integrity_error():
    """Strict mode raises ConstitutionalIntegrityError on bad signature."""
    key = _make_key()
    r1 = _make_rule()
    rs = _sign_ruleset([r1], key)
    rs.signature = "tampered"

    with pytest.raises(ConstitutionalIntegrityError):
        ConstitutionalEngine(ruleset=rs, verify_key_bytes=key, strict_mode=True)


def test_engine_non_strict_mode_warns(caplog):
    """Non-strict mode logs warning but continues on bad signature."""
    key = _make_key()
    r1 = _make_rule()
    rs = _sign_ruleset([r1], key)
    rs.signature = "tampered"

    import logging
    with caplog.at_level(logging.WARNING):
        engine = ConstitutionalEngine(
            ruleset=rs, verify_key_bytes=key, strict_mode=False,
        )
    assert engine.has_rules() is True


def test_engine_no_verify_key_raises():
    """Providing a ruleset without verify_key raises IntegrityError."""
    key = _make_key()
    r1 = _make_rule()
    rs = _sign_ruleset([r1], key)

    with pytest.raises(ConstitutionalIntegrityError):
        ConstitutionalEngine(ruleset=rs, verify_key_bytes=None)


# ── Runtime Integration Tests ────────────────────────────────────────────


def test_runtime_constitutional_violation_raises():
    """GovernanceRuntime raises ConstitutionalViolationError."""
    from nomotic.runtime import GovernanceRuntime, RuntimeConfig

    key = _make_key()
    rule = _make_rule(
        rule_type="deny_always",
        condition={"action_types": ["destroy"]},
    )
    rs = _sign_ruleset([rule], key)

    runtime = GovernanceRuntime()
    engine = ConstitutionalEngine(ruleset=rs, verify_key_bytes=key)
    runtime.set_constitutional_engine(engine)

    action = _make_action(action_type="destroy")
    ctx = _make_context()

    with pytest.raises(ConstitutionalViolationError) as exc_info:
        runtime.evaluate(action, ctx)
    assert exc_info.value.violation.rule_type == "deny_always"


def test_runtime_constitutional_violation_writes_audit():
    """Constitutional violation writes an audit record."""
    from nomotic.runtime import GovernanceRuntime

    key = _make_key()
    rule = _make_rule(
        rule_type="deny_always",
        condition={"action_types": ["destroy"]},
    )
    rs = _sign_ruleset([rule], key)

    runtime = GovernanceRuntime()
    engine = ConstitutionalEngine(ruleset=rs, verify_key_bytes=key)
    runtime.set_constitutional_engine(engine)

    action = _make_action(action_type="destroy")
    ctx = _make_context()

    with pytest.raises(ConstitutionalViolationError):
        runtime.evaluate(action, ctx)

    # Check audit trail
    trail = runtime.audit_trail
    assert trail is not None
    records = trail.query(agent_id="agent-1")
    assert len(records) >= 1
    constitutional_records = [
        r for r in records
        if r.context_code == "GOVERNANCE.CONSTITUTIONAL_VIOLATION"
    ]
    assert len(constitutional_records) == 1
    assert constitutional_records[0].severity == "critical"
    assert constitutional_records[0].verdict == "DENY"
    assert constitutional_records[0].tier == 0
    assert constitutional_records[0].ucs == 0.0


def test_runtime_no_constitutional_engine_proceeds():
    """Without a constitutional engine, runtime evaluates normally."""
    from nomotic.runtime import GovernanceRuntime

    runtime = GovernanceRuntime()
    assert runtime._constitutional_engine is None

    action = _make_action(action_type="read")
    ctx = _make_context()
    verdict = runtime.evaluate(action, ctx)
    # Should proceed normally and return a verdict
    assert verdict is not None


# ── Builder and Serialisation Tests ──────────────────────────────────────


def test_build_default_constitutional_rules():
    """build_default_constitutional_rules produces a valid signed ruleset."""
    key = _make_key()
    rs = build_default_constitutional_rules(key, authority="test-system")
    assert len(rs.rules) == 2
    assert rs.signed_by == "test-system"
    assert rs.verify_signature(key) is True

    # Check rule types
    types = {r.rule_type for r in rs.rules}
    assert "trust_floor" in types
    assert "require_certificate" in types


def test_from_file_round_trip():
    """Serialise a ruleset to file and load it back."""
    key = _make_key()
    r1 = _make_rule(name="file-test-rule")
    rs = _sign_ruleset([r1], key)

    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".json", delete=False,
    ) as f:
        json.dump(rs.to_dict(), f)
        f.flush()
        path = Path(f.name)

    try:
        loaded = ConstitutionalRuleSet.from_file(path)
        assert loaded.ruleset_id == rs.ruleset_id
        assert len(loaded.rules) == 1
        assert loaded.rules[0].name == "file-test-rule"
        assert loaded.verify_signature(key) is True
    finally:
        path.unlink()


def test_constitutional_violation_error_attributes():
    """ConstitutionalViolationError carries violation details."""
    violation = ConstitutionalViolation(
        rule_id="nmcr-test",
        rule_name="test-rule",
        rule_type="deny_always",
        reason="test reason",
        action_id="act-1",
        agent_id="agent-1",
        evaluated_at=time.time(),
    )
    err = ConstitutionalViolationError(violation)
    assert err.violation is violation
    assert "test-rule" in str(err)
    assert "test reason" in str(err)


def test_ruleset_from_dict_round_trip():
    """ConstitutionalRuleSet round-trips through to_dict / from_dict."""
    key = _make_key()
    r1 = _make_rule(name="round-trip-rule")
    r2 = _make_rule(name="round-trip-rule-2", rule_type="trust_floor",
                     condition={"min_trust": 0.3})
    rs = _sign_ruleset([r1, r2], key)

    d = rs.to_dict()
    rs2 = ConstitutionalRuleSet.from_dict(d)

    assert rs2.ruleset_id == rs.ruleset_id
    assert rs2.signed_by == rs.signed_by
    assert rs2.signature == rs.signature
    assert rs2.ruleset_hash == rs.ruleset_hash
    assert len(rs2.rules) == 2
    assert rs2.rules[0].name == "round-trip-rule"
    assert rs2.rules[1].condition == {"min_trust": 0.3}
    assert rs2.verify_signature(key) is True


def test_rule_type_unknown_treated_as_pass():
    """Unknown rule types do not block — they are treated as pass."""
    key = _make_key()
    rule = _make_rule(
        rule_type="future_rule_type_v3",
        condition={"some_param": "some_value"},
    )
    rs = _sign_ruleset([rule], key)
    engine = ConstitutionalEngine(ruleset=rs, verify_key_bytes=key)

    action = _make_action(action_type="anything")
    violations = engine.evaluate(action, _make_context())
    assert len(violations) == 0


# ── evaluate_passthrough Tests ────────────────────────────────────────────


class TestEvaluatePassthrough:
    """Tests for ConstitutionalEngine.evaluate_passthrough()."""

    def test_evaluate_passthrough_skips_signature_check(self):
        """evaluate_passthrough works even with an unsigned/tampered ruleset."""
        key = _make_key()
        rule = _make_rule(
            rule_type="deny_always",
            condition={"action_types": ["delete"]},
        )
        rs = _sign_ruleset([rule], key)
        # Build engine in passthrough mode then inject ruleset
        # (bypassing signature verification).
        engine = ConstitutionalEngine()
        engine._ruleset = rs
        # Tamper with signature — evaluate_passthrough should still work
        rs.signature = "tampered"

        action = _make_action(action_type="delete")
        ctx = _make_context()
        result = engine.evaluate_passthrough(action, ctx)
        assert result is not None
        assert result.rule_type == "deny_always"

    def test_evaluate_passthrough_returns_none_when_no_match(self):
        """evaluate_passthrough returns None when no rules match."""
        key = _make_key()
        rule = _make_rule(
            rule_type="deny_always",
            condition={"action_types": ["delete"]},
        )
        rs = _sign_ruleset([rule], key)
        engine = ConstitutionalEngine(ruleset=rs, verify_key_bytes=key)

        action = _make_action(action_type="read")
        ctx = _make_context()
        result = engine.evaluate_passthrough(action, ctx)
        assert result is None

    def test_evaluate_passthrough_returns_violation_when_match(self):
        """evaluate_passthrough returns first violation when a rule matches."""
        key = _make_key()
        rule = _make_rule(
            rule_type="trust_floor",
            condition={"min_trust": 0.9, "applies_to_irreversible": False},
            name="high-floor",
        )
        rs = _sign_ruleset([rule], key)
        engine = ConstitutionalEngine(ruleset=rs, verify_key_bytes=key)

        action = _make_action()
        ctx = _make_context(trust=0.1)
        result = engine.evaluate_passthrough(action, ctx)
        assert result is not None
        assert result.rule_name == "high-floor"

    def test_standard_evaluate_still_requires_valid_signature(self):
        """Standard evaluate() still requires valid signature to init engine."""
        key = _make_key()
        rule = _make_rule(
            rule_type="deny_always",
            condition={"action_types": ["delete"]},
        )
        rs = _sign_ruleset([rule], key)
        rs.signature = "tampered"

        with pytest.raises(ConstitutionalIntegrityError):
            ConstitutionalEngine(ruleset=rs, verify_key_bytes=key, strict_mode=True)


# ── ConstitutionalDryRunner Tests ────────────────────────────────────────


class TestConstitutionalDryRunner:
    """Tests for ConstitutionalDryRunner and ConstitutionalDryRunResult."""

    def _make_audit_store(self, tmp_path, records):
        """Create a LogStore with pre-populated records."""
        from nomotic.audit_store import LogStore, PersistentLogRecord

        store = LogStore(tmp_path, "audit")
        for rec in records:
            store.append(rec)
        return store

    def _make_record(
        self,
        agent_id="claims-bot",
        action_type="read",
        action_target="/data/file.txt",
        verdict="ALLOW",
        trust_score=0.5,
        record_id=None,
    ):
        """Create a PersistentLogRecord for testing."""
        from nomotic.audit_store import PersistentLogRecord

        return PersistentLogRecord(
            record_id=record_id or f"r-{uuid.uuid4().hex[:8]}",
            timestamp=time.time(),
            agent_id=agent_id,
            action_type=action_type,
            action_target=action_target,
            verdict=verdict,
            ucs=0.5,
            tier=1,
            trust_score=trust_score,
            trust_delta=0.0,
            trust_trend="stable",
            severity="info",
            justification="test",
        )

    def _make_engine_with_rules(self, rules):
        """Create a signed engine with given rules."""
        key = _make_key()
        rs = _sign_ruleset(rules, key)
        return ConstitutionalEngine(ruleset=rs, verify_key_bytes=key)

    def test_dry_run_no_blocks_when_no_matching_rules(self, tmp_path):
        """Dry-run with no matching rules reports zero blocks."""
        from nomotic.constitution import ConstitutionalDryRunner

        records = [
            self._make_record(action_type="read"),
            self._make_record(action_type="read"),
        ]
        store = self._make_audit_store(tmp_path, records)

        rule = _make_rule(
            rule_type="deny_always",
            condition={"action_types": ["delete"]},
        )
        engine = self._make_engine_with_rules([rule])
        runner = ConstitutionalDryRunner(audit_store=store)
        result = runner.run_with_engine(engine, ruleset_label="test")

        assert result.records_evaluated == 2
        assert result.would_block_count == 0
        assert result.new_blocks_count == 0
        assert result.already_denied_count == 0

    def test_dry_run_blocks_trust_floor_violations(self, tmp_path):
        """Dry-run detects trust floor violations."""
        from nomotic.constitution import ConstitutionalDryRunner

        records = [
            self._make_record(trust_score=0.05, verdict="ALLOW"),
            self._make_record(trust_score=0.8, verdict="ALLOW"),
        ]
        store = self._make_audit_store(tmp_path, records)

        rule = _make_rule(
            rule_type="trust_floor",
            condition={"min_trust": 0.3, "applies_to_irreversible": False},
            name="trust-floor-rule",
        )
        engine = self._make_engine_with_rules([rule])
        runner = ConstitutionalDryRunner(audit_store=store)
        result = runner.run_with_engine(engine, ruleset_label="test")

        assert result.records_evaluated == 2
        assert result.would_block_count == 1
        assert result.new_blocks_count == 1

    def test_dry_run_already_denied_not_counted_as_new(self, tmp_path):
        """Records already DENY are not counted as new blocks."""
        from nomotic.constitution import ConstitutionalDryRunner

        records = [
            self._make_record(action_type="delete", verdict="DENY"),
            self._make_record(action_type="delete", verdict="ALLOW"),
        ]
        store = self._make_audit_store(tmp_path, records)

        rule = _make_rule(
            rule_type="deny_always",
            condition={"action_types": ["delete"]},
        )
        engine = self._make_engine_with_rules([rule])
        runner = ConstitutionalDryRunner(audit_store=store)
        result = runner.run_with_engine(engine, ruleset_label="test")

        assert result.would_block_count == 2
        assert result.already_denied_count == 1
        assert result.new_blocks_count == 1

    def test_dry_run_new_block_counted_correctly(self, tmp_path):
        """new_blocks_count = would_block_count - already_denied_count."""
        from nomotic.constitution import ConstitutionalDryRunner

        records = [
            self._make_record(action_type="delete", verdict="ALLOW"),
            self._make_record(action_type="delete", verdict="ALLOW"),
            self._make_record(action_type="delete", verdict="DENY"),
        ]
        store = self._make_audit_store(tmp_path, records)

        rule = _make_rule(
            rule_type="deny_always",
            condition={"action_types": ["delete"]},
        )
        engine = self._make_engine_with_rules([rule])
        runner = ConstitutionalDryRunner(audit_store=store)
        result = runner.run_with_engine(engine, ruleset_label="test")

        assert result.would_block_count == 3
        assert result.already_denied_count == 1
        assert result.new_blocks_count == 2

    def test_dry_run_agent_filter_applied(self, tmp_path):
        """Dry-run with agent_id filter only evaluates that agent."""
        from nomotic.constitution import ConstitutionalDryRunner

        records = [
            self._make_record(agent_id="agent-a", action_type="delete", verdict="ALLOW"),
            self._make_record(agent_id="agent-b", action_type="delete", verdict="ALLOW"),
        ]
        store = self._make_audit_store(tmp_path, records)

        rule = _make_rule(
            rule_type="deny_always",
            condition={"action_types": ["delete"]},
        )
        engine = self._make_engine_with_rules([rule])
        runner = ConstitutionalDryRunner(audit_store=store)
        result = runner.run_with_engine(
            engine, ruleset_label="test", agent_id="agent-a",
        )

        assert result.records_evaluated == 1
        assert result.would_block_count == 1
        assert result.evaluated_agents == ["agent-a"]

    def test_dry_run_days_filter_applied(self, tmp_path):
        """Dry-run filters records older than `days`."""
        from nomotic.audit_store import LogStore, PersistentLogRecord
        from nomotic.constitution import ConstitutionalDryRunner

        now = time.time()
        old_record = self._make_record(action_type="delete", verdict="ALLOW")
        old_record.timestamp = now - (30 * 86400)  # 30 days ago
        recent_record = self._make_record(action_type="delete", verdict="ALLOW")
        recent_record.timestamp = now - (2 * 86400)  # 2 days ago

        store = LogStore(tmp_path, "audit")
        store.append(old_record)
        store.append(recent_record)

        rule = _make_rule(
            rule_type="deny_always",
            condition={"action_types": ["delete"]},
        )
        engine = self._make_engine_with_rules([rule])
        runner = ConstitutionalDryRunner(audit_store=store)
        result = runner.run_with_engine(
            engine, ruleset_label="test", days=7,
        )

        # Only the recent record should be evaluated
        assert result.records_evaluated == 1
        assert result.would_block_count == 1

    def test_dry_run_max_records_limit_respected(self, tmp_path):
        """Dry-run limits number of records evaluated."""
        from nomotic.constitution import ConstitutionalDryRunner

        records = [
            self._make_record(action_type="delete", verdict="ALLOW")
            for _ in range(10)
        ]
        store = self._make_audit_store(tmp_path, records)

        rule = _make_rule(
            rule_type="deny_always",
            condition={"action_types": ["delete"]},
        )
        engine = self._make_engine_with_rules([rule])
        runner = ConstitutionalDryRunner(audit_store=store)
        result = runner.run_with_engine(
            engine, ruleset_label="test", max_records=3,
        )

        assert result.records_evaluated == 3
        assert result.would_block_count == 3

    def test_dry_run_result_to_dict(self, tmp_path):
        """ConstitutionalDryRunResult.to_dict() returns expected structure."""
        from nomotic.constitution import ConstitutionalDryRunResult

        result = ConstitutionalDryRunResult(
            ruleset_path="/test/path.json",
            ruleset_id="nmcrs-test-123",
            records_evaluated=100,
            would_block_count=5,
            already_denied_count=2,
            new_blocks_count=3,
            would_block=[{"record_id": "r-1", "rule_id": "nmcr-1"}],
            evaluated_agents=["agent-a", "agent-b"],
        )
        d = result.to_dict()
        assert d["ruleset_path"] == "/test/path.json"
        assert d["ruleset_id"] == "nmcrs-test-123"
        assert d["records_evaluated"] == 100
        assert d["would_block_count"] == 5
        assert d["already_denied_count"] == 2
        assert d["new_blocks_count"] == 3
        assert len(d["would_block"]) == 1
        assert d["evaluated_agents"] == ["agent-a", "agent-b"]


# ── CLI Dry-Run Tests ────────────────────────────────────────────────────


class TestCLIDryRun:
    """Tests for the `nomotic constitution dry-run` CLI command."""

    def _make_ruleset_file(self, tmp_path, rules):
        """Create a signed ruleset JSON file."""
        key = _make_key()
        rs = _sign_ruleset(rules, key)
        path = tmp_path / "test-ruleset.json"
        path.write_text(json.dumps(rs.to_dict()))
        return path

    def _make_audit_store_with_records(self, tmp_path, records):
        """Create an audit store with records."""
        from nomotic.audit_store import LogStore

        store_dir = tmp_path / "nomotic-data"
        store_dir.mkdir(exist_ok=True)
        store = LogStore(store_dir, "audit")
        for rec in records:
            store.append(rec)
        return store_dir

    def _make_record(
        self,
        agent_id="claims-bot",
        action_type="read",
        action_target="/data/file.txt",
        verdict="ALLOW",
        trust_score=0.5,
    ):
        from nomotic.audit_store import PersistentLogRecord

        return PersistentLogRecord(
            record_id=f"r-{uuid.uuid4().hex[:8]}",
            timestamp=time.time(),
            agent_id=agent_id,
            action_type=action_type,
            action_target=action_target,
            verdict=verdict,
            ucs=0.5,
            tier=1,
            trust_score=trust_score,
            trust_delta=0.0,
            trust_trend="stable",
            severity="info",
            justification="test",
        )

    def test_cli_dry_run_no_blocks_output(self, tmp_path, capsys):
        """CLI dry-run prints 'Safe to deploy' when no new blocks."""
        from nomotic.constitution import ConstitutionalDryRunner

        records = [
            self._make_record(action_type="read"),
        ]
        store_dir = self._make_audit_store_with_records(tmp_path, records)

        rule = _make_rule(
            rule_type="deny_always",
            condition={"action_types": ["delete"]},
        )
        ruleset_path = self._make_ruleset_file(tmp_path, [rule])

        from nomotic.audit_store import LogStore

        store = LogStore(store_dir, "audit")
        runner = ConstitutionalDryRunner(audit_store=store)
        result = runner.run(ruleset_path=str(ruleset_path))

        assert result.new_blocks_count == 0
        assert result.records_evaluated == 1

    def test_cli_dry_run_with_blocks_output(self, tmp_path):
        """CLI dry-run detects blocks with correct counts."""
        from nomotic.constitution import ConstitutionalDryRunner

        records = [
            self._make_record(action_type="delete", verdict="ALLOW"),
            self._make_record(action_type="delete", verdict="DENY"),
            self._make_record(action_type="read", verdict="ALLOW"),
        ]
        store_dir = self._make_audit_store_with_records(tmp_path, records)

        rule = _make_rule(
            rule_type="deny_always",
            condition={"action_types": ["delete"]},
        )
        ruleset_path = self._make_ruleset_file(tmp_path, [rule])

        from nomotic.audit_store import LogStore

        store = LogStore(store_dir, "audit")
        runner = ConstitutionalDryRunner(audit_store=store)
        result = runner.run(ruleset_path=str(ruleset_path))

        assert result.records_evaluated == 3
        assert result.would_block_count == 2
        assert result.already_denied_count == 1
        assert result.new_blocks_count == 1

    def test_cli_dry_run_with_agent_filter(self, tmp_path):
        """CLI dry-run with --agent filters correctly."""
        from nomotic.constitution import ConstitutionalDryRunner

        records = [
            self._make_record(agent_id="agent-x", action_type="delete", verdict="ALLOW"),
            self._make_record(agent_id="agent-y", action_type="delete", verdict="ALLOW"),
        ]
        store_dir = self._make_audit_store_with_records(tmp_path, records)

        rule = _make_rule(
            rule_type="deny_always",
            condition={"action_types": ["delete"]},
        )
        ruleset_path = self._make_ruleset_file(tmp_path, [rule])

        from nomotic.audit_store import LogStore

        store = LogStore(store_dir, "audit")
        runner = ConstitutionalDryRunner(audit_store=store)
        result = runner.run(
            ruleset_path=str(ruleset_path),
            agent_id="agent-x",
        )

        assert result.records_evaluated == 1
        assert result.would_block_count == 1
        assert result.evaluated_agents == ["agent-x"]
