"""Tests for Workflow Seal Chaining — cryptographic governance continuity."""

import hashlib
import time

import pytest

from nomotic.authority import CertificateAuthority
from nomotic.keys import SigningKey
from nomotic.store import MemoryCertificateStore
from nomotic.runtime import GovernanceRuntime
from nomotic.seal import (
    ChainedSeal,
    WorkflowChainVerification,
    WorkflowSealChain,
    verify_workflow_chain,
)
from nomotic.types import (
    Action,
    AgentContext,
    DimensionScore,
    GovernanceVerdict,
    TrustProfile,
    Verdict,
)


# ── Helpers ────────────────────────────────────────────────────────────


def _make_runtime() -> GovernanceRuntime:
    """Create a runtime with a CA and scope configured for testing."""
    sk, _ = SigningKey.generate()
    ca = CertificateAuthority("test", sk, MemoryCertificateStore())
    runtime = GovernanceRuntime()
    runtime.set_certificate_authority(ca)
    scope = runtime.registry.get("scope_compliance")
    scope.configure_agent_scope("workflow-bot", {"*"})
    return runtime


def _make_allow_verdict(
    action_id: str = "test-action",
    agent_id: str = "workflow-bot",
) -> GovernanceVerdict:
    return GovernanceVerdict(
        action_id=action_id,
        verdict=Verdict.ALLOW,
        ucs=0.85,
        tier=2,
        dimension_scores=[
            DimensionScore(dimension_name="scope_compliance", score=0.9, weight=1.0),
        ],
        vetoed_by=[],
        reasoning="All dimensions passed",
    )


def _make_context(agent_id: str = "workflow-bot") -> AgentContext:
    return AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id),
    )


def _build_chain(n_seals: int = 3) -> WorkflowSealChain:
    """Build a chain with n_seals chained seals (correct hashes)."""
    chain = WorkflowSealChain(
        chain_id="nmwc-test-chain-001",
        workflow_id="test-workflow",
        agent_id="test-agent",
    )
    previous_hash = hashlib.sha256(chain.chain_id.encode("utf-8")).hexdigest()
    for i in range(n_seals):
        seal_id = f"nms-seal-{i}"
        position_hash = hashlib.sha256(
            f"{previous_hash}:{seal_id}".encode("utf-8")
        ).hexdigest()
        chained = ChainedSeal(
            seal_id=seal_id,
            step_number=i + 1,
            action_id=f"action-{i}",
            previous_seal_hash=previous_hash,
            position_hash=position_hash,
        )
        chain.seals.append(chained)
        previous_hash = position_hash
    return chain


# ── TestChainedSeal ────────────────────────────────────────────────────


class TestChainedSeal:
    """Tests for ChainedSeal dataclass."""

    def test_creation(self):
        cs = ChainedSeal(
            seal_id="nms-abc",
            step_number=1,
            action_id="act-001",
            previous_seal_hash="deadbeef",
            position_hash="cafebabe",
        )
        assert cs.seal_id == "nms-abc"
        assert cs.step_number == 1
        assert cs.action_id == "act-001"
        assert cs.previous_seal_hash == "deadbeef"
        assert cs.position_hash == "cafebabe"
        assert cs.added_at > 0

    def test_to_dict(self):
        cs = ChainedSeal(
            seal_id="nms-abc",
            step_number=2,
            action_id="act-002",
            previous_seal_hash="aaa",
            position_hash="bbb",
            added_at=1000.0,
        )
        d = cs.to_dict()
        assert d["seal_id"] == "nms-abc"
        assert d["step_number"] == 2
        assert d["action_id"] == "act-002"
        assert d["previous_seal_hash"] == "aaa"
        assert d["position_hash"] == "bbb"
        assert d["added_at"] == 1000.0

    def test_from_dict(self):
        d = {
            "seal_id": "nms-xyz",
            "step_number": 3,
            "action_id": "act-003",
            "previous_seal_hash": "prev",
            "position_hash": "pos",
            "added_at": 2000.0,
        }
        cs = ChainedSeal.from_dict(d)
        assert cs.seal_id == "nms-xyz"
        assert cs.step_number == 3
        assert cs.added_at == 2000.0

    def test_roundtrip(self):
        original = ChainedSeal(
            seal_id="nms-round",
            step_number=5,
            action_id="act-round",
            previous_seal_hash="phash",
            position_hash="poshash",
            added_at=3000.0,
        )
        restored = ChainedSeal.from_dict(original.to_dict())
        assert restored.seal_id == original.seal_id
        assert restored.step_number == original.step_number
        assert restored.action_id == original.action_id
        assert restored.previous_seal_hash == original.previous_seal_hash
        assert restored.position_hash == original.position_hash
        assert restored.added_at == original.added_at

    def test_from_dict_default_added_at(self):
        d = {
            "seal_id": "nms-no-time",
            "step_number": 1,
            "action_id": "act-x",
            "previous_seal_hash": "p",
            "position_hash": "q",
        }
        cs = ChainedSeal.from_dict(d)
        assert cs.added_at == 0.0


# ── TestWorkflowSealChain ─────────────────────────────────────────────


class TestWorkflowSealChain:
    """Tests for WorkflowSealChain dataclass."""

    def test_creation(self):
        chain = WorkflowSealChain(
            chain_id="nmwc-test",
            workflow_id="wf-001",
            agent_id="bot",
        )
        assert chain.chain_id == "nmwc-test"
        assert chain.workflow_id == "wf-001"
        assert chain.agent_id == "bot"
        assert chain.seals == []
        assert chain.chain_hash == ""
        assert chain.status == "ACTIVE"
        assert chain.completed_at is None

    def test_step_count_empty(self):
        chain = WorkflowSealChain(
            chain_id="nmwc-empty",
            workflow_id="wf",
            agent_id="a",
        )
        assert chain.step_count == 0

    def test_step_count_after_append(self):
        chain = _build_chain(3)
        assert chain.step_count == 3

    def test_latest_seal_id_none_when_empty(self):
        chain = WorkflowSealChain(
            chain_id="nmwc-e",
            workflow_id="wf",
            agent_id="a",
        )
        assert chain.latest_seal_id is None

    def test_latest_seal_id_after_append(self):
        chain = _build_chain(2)
        assert chain.latest_seal_id == "nms-seal-1"

    def test_latest_position_hash_none_when_empty(self):
        chain = WorkflowSealChain(
            chain_id="nmwc-e",
            workflow_id="wf",
            agent_id="a",
        )
        assert chain.latest_position_hash is None

    def test_latest_position_hash_after_append(self):
        chain = _build_chain(1)
        assert chain.latest_position_hash is not None
        assert len(chain.latest_position_hash) == 64  # SHA-256 hex

    def test_compute_chain_hash(self):
        chain = _build_chain(3)
        h = chain._compute_chain_hash()
        expected = hashlib.sha256(
            "nms-seal-0:nms-seal-1:nms-seal-2".encode("utf-8")
        ).hexdigest()
        assert h == expected

    def test_compute_chain_hash_changes_with_seals(self):
        chain2 = _build_chain(2)
        chain3 = _build_chain(3)
        assert chain2._compute_chain_hash() != chain3._compute_chain_hash()

    def test_to_dict(self):
        chain = _build_chain(2)
        chain.status = "COMPLETE"
        chain.completed_at = 5000.0
        chain.chain_hash = chain._compute_chain_hash()
        d = chain.to_dict()
        assert d["chain_id"] == "nmwc-test-chain-001"
        assert d["workflow_id"] == "test-workflow"
        assert d["agent_id"] == "test-agent"
        assert len(d["seals"]) == 2
        assert d["status"] == "COMPLETE"
        assert d["completed_at"] == 5000.0
        assert d["chain_hash"] != ""

    def test_from_dict(self):
        chain = _build_chain(2)
        chain.chain_hash = chain._compute_chain_hash()
        d = chain.to_dict()
        restored = WorkflowSealChain.from_dict(d)
        assert restored.chain_id == chain.chain_id
        assert restored.workflow_id == chain.workflow_id
        assert restored.agent_id == chain.agent_id
        assert len(restored.seals) == 2
        assert restored.chain_hash == chain.chain_hash

    def test_roundtrip(self):
        chain = _build_chain(3)
        chain.status = "COMPLETE"
        chain.completed_at = 6000.0
        chain.chain_hash = chain._compute_chain_hash()
        restored = WorkflowSealChain.from_dict(chain.to_dict())
        assert restored.chain_id == chain.chain_id
        assert restored.step_count == chain.step_count
        assert restored.chain_hash == chain.chain_hash
        assert restored.completed_at == chain.completed_at
        assert restored.status == chain.status

    def test_from_dict_default_status(self):
        d = {
            "chain_id": "nmwc-x",
            "workflow_id": "wf",
            "agent_id": "a",
            "seals": [],
        }
        chain = WorkflowSealChain.from_dict(d)
        # Default is "COMPLETE" when loading from dict (backward compat)
        assert chain.status == "COMPLETE"


# ── TestVerifyWorkflowChain ───────────────────────────────────────────


class TestVerifyWorkflowChain:
    """Tests for verify_workflow_chain() function."""

    def test_empty_chain_intact(self):
        chain = WorkflowSealChain(
            chain_id="nmwc-empty",
            workflow_id="wf",
            agent_id="a",
        )
        result = verify_workflow_chain(chain)
        assert result.intact is True
        assert result.seal_count == 0
        assert result.coverage == "none"
        assert result.broken_at_step is None

    def test_single_seal_active_partial(self):
        chain = _build_chain(1)
        chain.status = "ACTIVE"
        result = verify_workflow_chain(chain)
        assert result.intact is True
        assert result.seal_count == 1
        assert result.coverage == "partial"

    def test_single_seal_complete(self):
        chain = _build_chain(1)
        chain.status = "COMPLETE"
        chain.chain_hash = chain._compute_chain_hash()
        result = verify_workflow_chain(chain)
        assert result.intact is True
        assert result.seal_count == 1
        assert result.coverage == "complete"

    def test_three_seal_chain_intact(self):
        chain = _build_chain(3)
        chain.status = "COMPLETE"
        chain.chain_hash = chain._compute_chain_hash()
        result = verify_workflow_chain(chain)
        assert result.intact is True
        assert result.seal_count == 3
        assert result.coverage == "complete"
        assert result.broken_at_step is None

    def test_tampered_position_hash_step2(self):
        chain = _build_chain(3)
        chain.seals[1].position_hash = "tampered_hash_value"
        result = verify_workflow_chain(chain)
        assert result.intact is False
        assert result.broken_at_step == 2
        assert any("position_hash mismatch" in issue for issue in result.issues)

    def test_tampered_position_hash_step1(self):
        chain = _build_chain(3)
        chain.seals[0].position_hash = "tampered"
        result = verify_workflow_chain(chain)
        assert result.intact is False
        assert result.broken_at_step == 1

    def test_tampered_chain_hash(self):
        chain = _build_chain(3)
        chain.status = "COMPLETE"
        chain.chain_hash = "wrong_chain_hash"
        result = verify_workflow_chain(chain)
        assert result.intact is False
        assert "chain_hash mismatch" in result.issues[0]

    def test_wrong_genesis_hash(self):
        """When genesis hash is wrong but position_hash is self-consistent,
        the genesis mismatch is an issue but position checks still pass.
        To actually break the chain, we leave the original position_hash
        (which was computed with the correct genesis)."""
        chain = _build_chain(1)
        # Tamper genesis hash but don't fix position_hash → position check fails
        chain.seals[0].previous_seal_hash = "wrong_genesis"
        result = verify_workflow_chain(chain)
        assert result.intact is False
        assert any("genesis hash mismatch" in issue or "position_hash mismatch" in issue
                    for issue in result.issues)

    def test_chain_hash_empty_skips_check(self):
        """When chain_hash is empty (ACTIVE chain), hash check is skipped."""
        chain = _build_chain(3)
        chain.chain_hash = ""  # Not finalized yet
        chain.status = "ACTIVE"
        result = verify_workflow_chain(chain)
        assert result.intact is True
        assert result.coverage == "partial"

    def test_coverage_none_when_first_broken(self):
        chain = _build_chain(3)
        chain.seals[0].position_hash = "broken"
        result = verify_workflow_chain(chain)
        assert result.intact is False
        assert result.coverage == "none"

    def test_coverage_partial_when_later_broken(self):
        chain = _build_chain(3)
        chain.seals[2].position_hash = "broken"
        result = verify_workflow_chain(chain)
        assert result.intact is False
        assert result.coverage == "partial"


# ── TestRuntimeWorkflowSealing ────────────────────────────────────────


class TestRuntimeWorkflowSealing:
    """Tests for runtime workflow sealing integration."""

    def test_begin_workflow_sealing_creates_chain(self):
        runtime = _make_runtime()
        chain = runtime.begin_workflow_sealing("wf-001", agent_id="workflow-bot")
        assert chain.chain_id.startswith("nmwc-")
        assert chain.workflow_id == "wf-001"
        assert chain.agent_id == "workflow-bot"
        assert chain.status == "ACTIVE"
        assert chain.step_count == 0

    def test_begin_workflow_sealing_chain_id_format(self):
        runtime = _make_runtime()
        chain = runtime.begin_workflow_sealing("wf-002")
        assert chain.chain_id.startswith("nmwc-")
        assert len(chain.chain_id) > len("nmwc-")

    def test_seal_with_workflow_chain_appends(self):
        runtime = _make_runtime()
        chain = runtime.begin_workflow_sealing("wf-003", agent_id="workflow-bot")
        action = Action(agent_id="workflow-bot", action_type="read", target="data-0")
        ctx = _make_context()
        verdict = runtime.evaluate(action, ctx)
        if verdict.verdict == Verdict.ALLOW:
            seal = runtime.seal(verdict, ctx, workflow_chain=chain)
            assert seal is not None
            assert chain.step_count == 1
            assert chain.seals[0].seal_id == seal.seal_id

    def test_chain_grows_with_each_seal(self):
        runtime = _make_runtime()
        chain = runtime.begin_workflow_sealing("wf-grow", agent_id="workflow-bot")
        sealed = 0
        for i in range(3):
            action = Action(agent_id="workflow-bot", action_type="read", target=f"data-{i}")
            ctx = _make_context()
            verdict = runtime.evaluate(action, ctx)
            if verdict.verdict == Verdict.ALLOW:
                runtime.seal(verdict, ctx, workflow_chain=chain)
                sealed += 1
                assert chain.step_count == sealed

    def test_complete_workflow_sealing_sets_status(self):
        runtime = _make_runtime()
        chain = runtime.begin_workflow_sealing("wf-complete", agent_id="workflow-bot")
        action = Action(agent_id="workflow-bot", action_type="read", target="data")
        ctx = _make_context()
        verdict = runtime.evaluate(action, ctx)
        if verdict.verdict == Verdict.ALLOW:
            runtime.seal(verdict, ctx, workflow_chain=chain)
        completed = runtime.complete_workflow_sealing(chain.chain_id)
        assert completed.status == "COMPLETE"
        assert completed.completed_at is not None
        assert completed.chain_hash != ""

    def test_complete_workflow_sealing_computes_chain_hash(self):
        runtime = _make_runtime()
        chain = runtime.begin_workflow_sealing("wf-hash", agent_id="workflow-bot")
        for i in range(2):
            action = Action(agent_id="workflow-bot", action_type="read", target=f"d-{i}")
            ctx = _make_context()
            verdict = runtime.evaluate(action, ctx)
            if verdict.verdict == Verdict.ALLOW:
                runtime.seal(verdict, ctx, workflow_chain=chain)
        completed = runtime.complete_workflow_sealing(chain.chain_id)
        # chain_hash should match manual computation
        expected = completed._compute_chain_hash()
        assert completed.chain_hash == expected

    def test_get_workflow_chain(self):
        runtime = _make_runtime()
        chain = runtime.begin_workflow_sealing("wf-get", agent_id="workflow-bot")
        retrieved = runtime.get_workflow_chain(chain.chain_id)
        assert retrieved is chain

    def test_get_workflow_chain_none_for_unknown(self):
        runtime = _make_runtime()
        assert runtime.get_workflow_chain("nmwc-nonexistent") is None

    def test_verify_complete_chain(self):
        runtime = _make_runtime()
        chain = runtime.begin_workflow_sealing("wf-verify", agent_id="workflow-bot")
        for i in range(3):
            action = Action(agent_id="workflow-bot", action_type="read", target=f"item-{i}")
            ctx = _make_context()
            verdict = runtime.evaluate(action, ctx)
            if verdict.verdict == Verdict.ALLOW:
                runtime.seal(verdict, ctx, workflow_chain=chain)
        completed = runtime.complete_workflow_sealing(chain.chain_id)
        result = verify_workflow_chain(completed)
        assert result.intact is True
        assert result.coverage == "complete"

    def test_three_step_workflow_all_chained(self):
        runtime = _make_runtime()
        chain = runtime.begin_workflow_sealing("wf-3step", agent_id="workflow-bot")
        seals = []
        for i in range(3):
            action = Action(agent_id="workflow-bot", action_type="read", target=f"step-{i}")
            ctx = _make_context()
            verdict = runtime.evaluate(action, ctx)
            if verdict.verdict == Verdict.ALLOW:
                seal = runtime.seal(verdict, ctx, workflow_chain=chain)
                seals.append(seal)
        assert chain.step_count == len(seals)
        # Each seal should be in the chain
        for i, seal in enumerate(seals):
            assert chain.seals[i].seal_id == seal.seal_id
            assert chain.seals[i].step_number == i + 1

    def test_seal_without_workflow_chain_no_modification(self):
        runtime = _make_runtime()
        chain = runtime.begin_workflow_sealing("wf-no-mod", agent_id="workflow-bot")
        action = Action(agent_id="workflow-bot", action_type="read", target="data")
        ctx = _make_context()
        verdict = runtime.evaluate(action, ctx)
        if verdict.verdict == Verdict.ALLOW:
            # Seal without workflow_chain
            seal = runtime.seal(verdict, ctx)
            assert seal is not None
            # Chain should not be modified
            assert chain.step_count == 0

    def test_complete_workflow_sealing_unknown_raises(self):
        runtime = _make_runtime()
        with pytest.raises(ValueError, match="Workflow chain not found"):
            runtime.complete_workflow_sealing("nmwc-does-not-exist")

    def test_genesis_hash_uses_chain_id(self):
        runtime = _make_runtime()
        chain = runtime.begin_workflow_sealing("wf-genesis", agent_id="workflow-bot")
        action = Action(agent_id="workflow-bot", action_type="read", target="g-0")
        ctx = _make_context()
        verdict = runtime.evaluate(action, ctx)
        if verdict.verdict == Verdict.ALLOW:
            runtime.seal(verdict, ctx, workflow_chain=chain)
            first = chain.seals[0]
            expected_genesis = hashlib.sha256(
                chain.chain_id.encode("utf-8")
            ).hexdigest()
            assert first.previous_seal_hash == expected_genesis

    def test_position_hash_computation(self):
        runtime = _make_runtime()
        chain = runtime.begin_workflow_sealing("wf-pos", agent_id="workflow-bot")
        for i in range(2):
            action = Action(agent_id="workflow-bot", action_type="read", target=f"p-{i}")
            ctx = _make_context()
            verdict = runtime.evaluate(action, ctx)
            if verdict.verdict == Verdict.ALLOW:
                runtime.seal(verdict, ctx, workflow_chain=chain)
        if chain.step_count >= 2:
            second = chain.seals[1]
            expected = hashlib.sha256(
                f"{second.previous_seal_hash}:{second.seal_id}".encode("utf-8")
            ).hexdigest()
            assert second.position_hash == expected

    def test_chain_status_active_before_complete(self):
        runtime = _make_runtime()
        chain = runtime.begin_workflow_sealing("wf-status", agent_id="workflow-bot")
        assert chain.status == "ACTIVE"

    def test_chain_status_complete_after(self):
        runtime = _make_runtime()
        chain = runtime.begin_workflow_sealing("wf-status2", agent_id="workflow-bot")
        runtime.complete_workflow_sealing(chain.chain_id)
        assert chain.status == "COMPLETE"


# ── TestWorkflowChainVerification ─────────────────────────────────────


class TestWorkflowChainVerification:
    """Tests for WorkflowChainVerification dataclass."""

    def test_intact_true_fields(self):
        result = WorkflowChainVerification(
            chain_id="nmwc-ok",
            intact=True,
            seal_count=3,
            broken_at_step=None,
            coverage="complete",
        )
        assert result.intact is True
        assert result.seal_count == 3
        assert result.broken_at_step is None
        assert result.coverage == "complete"
        assert result.issues == []

    def test_broken_at_step_none_when_intact(self):
        result = WorkflowChainVerification(
            chain_id="nmwc-ok",
            intact=True,
            seal_count=2,
            broken_at_step=None,
            coverage="complete",
        )
        assert result.broken_at_step is None

    def test_issues_populated_when_broken(self):
        result = WorkflowChainVerification(
            chain_id="nmwc-bad",
            intact=False,
            seal_count=3,
            broken_at_step=2,
            coverage="partial",
            issues=["Step 2: position_hash mismatch"],
        )
        assert len(result.issues) == 1
        assert "position_hash" in result.issues[0]

    def test_chain_id_preserved(self):
        result = WorkflowChainVerification(
            chain_id="nmwc-specific-id",
            intact=True,
            seal_count=0,
            broken_at_step=None,
            coverage="none",
        )
        assert result.chain_id == "nmwc-specific-id"


# ── TestWorkflowSealChainSerializationRoundtrip ──────────────────────


class TestWorkflowSealChainSerializationRoundtrip:
    """Tests for full serialization roundtrip of workflow chains."""

    def test_full_3_seal_roundtrip(self):
        chain = _build_chain(3)
        chain.status = "COMPLETE"
        chain.completed_at = time.time()
        chain.chain_hash = chain._compute_chain_hash()

        d = chain.to_dict()
        restored = WorkflowSealChain.from_dict(d)

        assert restored.chain_id == chain.chain_id
        assert restored.workflow_id == chain.workflow_id
        assert restored.agent_id == chain.agent_id
        assert restored.status == chain.status
        assert restored.completed_at == chain.completed_at
        assert restored.chain_hash == chain.chain_hash
        assert restored.step_count == 3

        for orig, rest in zip(chain.seals, restored.seals):
            assert rest.seal_id == orig.seal_id
            assert rest.step_number == orig.step_number
            assert rest.action_id == orig.action_id
            assert rest.previous_seal_hash == orig.previous_seal_hash
            assert rest.position_hash == orig.position_hash
            assert rest.added_at == orig.added_at

    def test_verify_still_passes_after_roundtrip(self):
        chain = _build_chain(3)
        chain.status = "COMPLETE"
        chain.chain_hash = chain._compute_chain_hash()

        restored = WorkflowSealChain.from_dict(chain.to_dict())
        result = verify_workflow_chain(restored)
        assert result.intact is True
        assert result.coverage == "complete"

    def test_runtime_chain_roundtrip(self):
        """Full roundtrip through runtime -> dict -> restore -> verify."""
        runtime = _make_runtime()
        chain = runtime.begin_workflow_sealing("wf-rt", agent_id="workflow-bot")
        for i in range(3):
            action = Action(agent_id="workflow-bot", action_type="read", target=f"rt-{i}")
            ctx = _make_context()
            verdict = runtime.evaluate(action, ctx)
            if verdict.verdict == Verdict.ALLOW:
                runtime.seal(verdict, ctx, workflow_chain=chain)
        completed = runtime.complete_workflow_sealing(chain.chain_id)

        # Serialize and restore
        d = completed.to_dict()
        restored = WorkflowSealChain.from_dict(d)

        result = verify_workflow_chain(restored)
        assert result.intact is True
        assert result.coverage == "complete"
        assert result.seal_count == completed.step_count


# ── TestWorkflowSealChainEdgeCases ───────────────────────────────────


class TestWorkflowSealChainEdgeCases:
    """Edge case tests for workflow seal chaining."""

    def test_empty_chain_complete(self):
        """Completing a chain with no seals should still work."""
        runtime = _make_runtime()
        chain = runtime.begin_workflow_sealing("wf-empty", agent_id="workflow-bot")
        completed = runtime.complete_workflow_sealing(chain.chain_id)
        assert completed.status == "COMPLETE"
        assert completed.step_count == 0
        result = verify_workflow_chain(completed)
        assert result.intact is True
        assert result.coverage == "none"

    def test_multiple_chains_independent(self):
        """Multiple workflow chains should be independent."""
        runtime = _make_runtime()
        chain_a = runtime.begin_workflow_sealing("wf-a", agent_id="workflow-bot")
        chain_b = runtime.begin_workflow_sealing("wf-b", agent_id="workflow-bot")

        action = Action(agent_id="workflow-bot", action_type="read", target="x")
        ctx = _make_context()
        verdict = runtime.evaluate(action, ctx)
        if verdict.verdict == Verdict.ALLOW:
            runtime.seal(verdict, ctx, workflow_chain=chain_a)

        assert chain_a.step_count == 1
        assert chain_b.step_count == 0

    def test_deny_verdict_no_chain_append(self):
        """A DENY verdict produces no seal, so chain is not modified."""
        runtime = _make_runtime()
        chain = runtime.begin_workflow_sealing("wf-deny", agent_id="workflow-bot")
        deny_verdict = GovernanceVerdict(
            action_id="deny-act",
            verdict=Verdict.DENY,
            ucs=0.1,
            tier=1,
            vetoed_by=["scope_compliance"],
            reasoning="Denied",
        )
        ctx = _make_context()
        seal = runtime.seal(deny_verdict, ctx, workflow_chain=chain)
        assert seal is None
        assert chain.step_count == 0
