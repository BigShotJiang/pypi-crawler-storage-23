"""Tests for the Pre-Evaluation State Continuity Check (Item 16)."""

import time

import pytest

from nomotic.continuity import (
    ContinuityChecker,
    ContinuityCheckResult,
    ContinuityProbe,
    ContinuityState,
    ContinuityViolationError,
)


# ── Fake infrastructure stubs ────────────────────────────────────────────


class FakeAuditStore:
    """Minimal audit store stub with get_last_hash and query_all."""

    def __init__(self, records: list | None = None, last_hash: str = ""):
        self._records = records or []
        self._last_hash = last_hash

    def get_last_hash(self, agent_id: str) -> str:
        return self._last_hash

    def query_all(self, agent_id: str) -> list:
        return self._records

    def set_last_hash(self, h: str) -> None:
        self._last_hash = h

    def set_records(self, records: list) -> None:
        self._records = records


class FakeCertStore:
    """Minimal cert store stub with list()."""

    def __init__(self, count: int = 0):
        self._items = [object() for _ in range(count)]

    def list(self) -> list:
        return self._items

    def set_count(self, n: int) -> None:
        self._items = [object() for _ in range(n)]


class FakeSealRegistry:
    """Minimal seal registry stub with count_for_agent."""

    def __init__(self, counts: dict | None = None):
        self._counts = counts or {}

    def count_for_agent(self, agent_id: str) -> int:
        return self._counts.get(agent_id, 0)

    def set_count(self, agent_id: str, n: int) -> None:
        self._counts[agent_id] = n


class FakeSealRegistryNoCount:
    """Seal registry without count_for_agent — probe should be skipped."""
    pass


# ── Core probe tests ─────────────────────────────────────────────────────


def test_first_evaluation_always_passes():
    """First check for an agent (no snapshot) should always pass."""
    checker = ContinuityChecker()
    store = FakeAuditStore(records=[1, 2, 3], last_hash="sha256:abc")
    certs = FakeCertStore(count=5)
    seals = FakeSealRegistry({"agent-1": 10})

    result = checker.check("agent-1", audit_store=store, cert_store=certs, seal_registry=seals)
    assert result.passed is True
    assert result.failed_probes == []
    assert result.agent_id == "agent-1"
    assert len(result.probes_run) == 4  # all probes


def test_record_hash_match_passes():
    """Hash match on second check should pass."""
    checker = ContinuityChecker()
    store = FakeAuditStore(records=[1, 2], last_hash="sha256:aaa")

    # First check: establishes snapshot
    checker.check("agent-1", audit_store=store)
    # Second check: same hash → pass
    result = checker.check("agent-1", audit_store=store)
    assert result.passed is True
    assert ContinuityProbe.LAST_RECORD_HASH not in result.failed_probes


def test_record_hash_mismatch_fails():
    """Hash change between checks should fail."""
    checker = ContinuityChecker()
    store = FakeAuditStore(records=[1, 2], last_hash="sha256:aaa")

    checker.check("agent-1", audit_store=store)

    # Tamper: change the last hash
    store.set_last_hash("sha256:bbb")
    result = checker.check("agent-1", audit_store=store)
    assert result.passed is False
    assert ContinuityProbe.LAST_RECORD_HASH in result.failed_probes
    assert any("hash mismatch" in v.lower() for v in result.violations)


def test_record_count_increase_passes():
    """Record count increasing between checks should pass."""
    checker = ContinuityChecker(
        enabled_probes=[ContinuityProbe.RECORD_COUNT_MONOTONE],
    )
    store = FakeAuditStore(records=[1, 2])

    checker.check("agent-1", audit_store=store)

    store.set_records([1, 2, 3])
    result = checker.check("agent-1", audit_store=store)
    assert result.passed is True


def test_record_count_same_passes():
    """Record count staying the same should pass."""
    checker = ContinuityChecker(
        enabled_probes=[ContinuityProbe.RECORD_COUNT_MONOTONE],
    )
    store = FakeAuditStore(records=[1, 2, 3])

    checker.check("agent-1", audit_store=store)
    result = checker.check("agent-1", audit_store=store)
    assert result.passed is True


def test_record_count_decrease_fails():
    """Record count decreasing should fail."""
    checker = ContinuityChecker(
        enabled_probes=[ContinuityProbe.RECORD_COUNT_MONOTONE],
    )
    store = FakeAuditStore(records=[1, 2, 3])

    checker.check("agent-1", audit_store=store)

    store.set_records([1])  # decreased from 3 to 1
    result = checker.check("agent-1", audit_store=store)
    assert result.passed is False
    assert ContinuityProbe.RECORD_COUNT_MONOTONE in result.failed_probes
    assert any("decreased" in v.lower() for v in result.violations)


def test_cert_count_decrease_fails():
    """Certificate count decreasing should fail."""
    checker = ContinuityChecker(
        enabled_probes=[ContinuityProbe.CERT_STORE_CONSISTENCY],
    )
    certs = FakeCertStore(count=5)

    checker.check("agent-1", cert_store=certs)

    certs.set_count(3)
    result = checker.check("agent-1", cert_store=certs)
    assert result.passed is False
    assert ContinuityProbe.CERT_STORE_CONSISTENCY in result.failed_probes


def test_cert_count_increase_passes():
    """Certificate count increasing should pass."""
    checker = ContinuityChecker(
        enabled_probes=[ContinuityProbe.CERT_STORE_CONSISTENCY],
    )
    certs = FakeCertStore(count=5)

    checker.check("agent-1", cert_store=certs)

    certs.set_count(7)
    result = checker.check("agent-1", cert_store=certs)
    assert result.passed is True


def test_seal_count_decrease_fails():
    """Seal count decreasing for an agent should fail."""
    checker = ContinuityChecker(
        enabled_probes=[ContinuityProbe.SEAL_COUNT_MONOTONE],
    )
    seals = FakeSealRegistry({"agent-1": 10})

    checker.check("agent-1", seal_registry=seals)

    seals.set_count("agent-1", 5)
    result = checker.check("agent-1", seal_registry=seals)
    assert result.passed is False
    assert ContinuityProbe.SEAL_COUNT_MONOTONE in result.failed_probes


def test_no_audit_store_skips_hash_probe():
    """When audit_store is None, hash and count probes are skipped."""
    checker = ContinuityChecker()
    result = checker.check("agent-1", audit_store=None)
    assert result.passed is True
    assert ContinuityProbe.LAST_RECORD_HASH not in result.probes_run
    assert ContinuityProbe.RECORD_COUNT_MONOTONE not in result.probes_run


def test_no_cert_store_skips_cert_probe():
    """When cert_store is None, cert probe is skipped."""
    checker = ContinuityChecker(
        enabled_probes=[ContinuityProbe.CERT_STORE_CONSISTENCY],
    )
    result = checker.check("agent-1", cert_store=None)
    assert result.passed is True
    assert ContinuityProbe.CERT_STORE_CONSISTENCY not in result.probes_run


def test_no_seal_registry_skips_seal_probe():
    """When seal_registry is None, seal probe is skipped."""
    checker = ContinuityChecker(
        enabled_probes=[ContinuityProbe.SEAL_COUNT_MONOTONE],
    )
    result = checker.check("agent-1", seal_registry=None)
    assert result.passed is True
    assert ContinuityProbe.SEAL_COUNT_MONOTONE not in result.probes_run


def test_seal_registry_without_count_for_agent_skips():
    """Seal registry without count_for_agent method is skipped."""
    checker = ContinuityChecker(
        enabled_probes=[ContinuityProbe.SEAL_COUNT_MONOTONE],
    )
    result = checker.check("agent-1", seal_registry=FakeSealRegistryNoCount())
    assert result.passed is True
    assert ContinuityProbe.SEAL_COUNT_MONOTONE not in result.probes_run


def test_multiple_probe_failures_all_reported():
    """When multiple probes fail, all are reported."""
    checker = ContinuityChecker()
    store = FakeAuditStore(records=[1, 2, 3], last_hash="sha256:aaa")
    certs = FakeCertStore(count=5)

    checker.check("agent-1", audit_store=store, cert_store=certs)

    # Tamper with multiple things
    store.set_last_hash("sha256:bbb")
    store.set_records([1])  # decreased
    certs.set_count(2)  # decreased

    result = checker.check("agent-1", audit_store=store, cert_store=certs)
    assert result.passed is False
    assert len(result.failed_probes) == 3
    assert ContinuityProbe.LAST_RECORD_HASH in result.failed_probes
    assert ContinuityProbe.RECORD_COUNT_MONOTONE in result.failed_probes
    assert ContinuityProbe.CERT_STORE_CONSISTENCY in result.failed_probes
    assert len(result.violations) == 3


# ── Snapshot management tests ────────────────────────────────────────────


def test_snapshot_not_updated_on_failure():
    """On failure, the snapshot is preserved (not updated with bad state)."""
    checker = ContinuityChecker(
        enabled_probes=[ContinuityProbe.RECORD_COUNT_MONOTONE],
    )
    store = FakeAuditStore(records=[1, 2, 3])

    checker.check("agent-1", audit_store=store)
    snap_before = checker.get_snapshot("agent-1")
    assert snap_before is not None
    assert snap_before.record_count == 3

    store.set_records([1])  # tamper
    result = checker.check("agent-1", audit_store=store)
    assert result.passed is False

    snap_after = checker.get_snapshot("agent-1")
    assert snap_after is not None
    assert snap_after.record_count == 3  # unchanged


def test_snapshot_updated_on_success():
    """On success, the snapshot is updated to reflect new state."""
    checker = ContinuityChecker(
        enabled_probes=[ContinuityProbe.RECORD_COUNT_MONOTONE],
    )
    store = FakeAuditStore(records=[1, 2])

    checker.check("agent-1", audit_store=store)
    assert checker.get_snapshot("agent-1").record_count == 2

    store.set_records([1, 2, 3, 4])
    checker.check("agent-1", audit_store=store)
    assert checker.get_snapshot("agent-1").record_count == 4


def test_update_snapshot_force():
    """update_snapshot() overwrites the cached snapshot."""
    checker = ContinuityChecker()
    store = FakeAuditStore(records=[1, 2, 3], last_hash="sha256:aaa")

    result = checker.check("agent-1", audit_store=store)
    assert checker.get_snapshot("agent-1").record_count == 3

    # Force update with custom result
    store.set_records([1])
    store.set_last_hash("sha256:new")
    result2 = checker.check.__wrapped__ if hasattr(checker.check, "__wrapped__") else None

    # Use update_snapshot with a fresh result
    fresh_result = ContinuityCheckResult(
        passed=False,
        probes_run=[ContinuityProbe.RECORD_COUNT_MONOTONE],
        failed_probes=[ContinuityProbe.RECORD_COUNT_MONOTONE],
        violations=["forced"],
        checked_at=time.time(),
        agent_id="agent-1",
        _last_record_hash="sha256:new",
        _record_count=1,
        _cert_count=0,
        _seal_count=None,
    )
    checker.update_snapshot("agent-1", fresh_result)
    snap = checker.get_snapshot("agent-1")
    assert snap.record_count == 1
    assert snap.last_record_hash == "sha256:new"


def test_clear_snapshot():
    """clear_snapshot() removes the cached snapshot."""
    checker = ContinuityChecker()
    store = FakeAuditStore(records=[1, 2], last_hash="sha256:x")

    checker.check("agent-1", audit_store=store)
    assert checker.get_snapshot("agent-1") is not None

    checker.clear_snapshot("agent-1")
    assert checker.get_snapshot("agent-1") is None


def test_get_snapshot_returns_none_before_first_check():
    """get_snapshot() returns None for agents that haven't been checked."""
    checker = ContinuityChecker()
    assert checker.get_snapshot("never-seen") is None


# ── Strict mode tests ────────────────────────────────────────────────────


def test_strict_mode_raises_on_failure():
    """In strict mode, failures raise ContinuityViolationError."""
    checker = ContinuityChecker(strict_mode=True)
    store = FakeAuditStore(records=[1, 2, 3], last_hash="sha256:aaa")

    checker.check("agent-1", audit_store=store)

    store.set_last_hash("sha256:bbb")
    with pytest.raises(ContinuityViolationError) as exc_info:
        checker.check("agent-1", audit_store=store)

    err = exc_info.value
    assert err.result.passed is False
    assert ContinuityProbe.LAST_RECORD_HASH in err.result.failed_probes
    assert "agent-1" in str(err)


def test_non_strict_mode_returns_result_on_failure():
    """In non-strict mode, failures return a failing result without raising."""
    checker = ContinuityChecker(strict_mode=False)
    store = FakeAuditStore(records=[1, 2, 3], last_hash="sha256:aaa")

    checker.check("agent-1", audit_store=store)

    store.set_last_hash("sha256:bbb")
    result = checker.check("agent-1", audit_store=store)
    assert result.passed is False  # no exception raised


# ── Error attributes test ────────────────────────────────────────────────


def test_continuity_violation_error_attributes():
    """ContinuityViolationError exposes the result and a useful message."""
    result = ContinuityCheckResult(
        passed=False,
        probes_run=[ContinuityProbe.LAST_RECORD_HASH],
        failed_probes=[ContinuityProbe.LAST_RECORD_HASH],
        violations=["hash mismatch"],
        checked_at=time.time(),
        agent_id="test-agent",
    )
    err = ContinuityViolationError(result)
    assert err.result is result
    assert "test-agent" in str(err)
    assert "last_record_hash" in str(err)


# ── Default probes test ──────────────────────────────────────────────────


def test_all_probes_run_by_default():
    """All four probes are enabled by default."""
    checker = ContinuityChecker()
    store = FakeAuditStore(records=[1], last_hash="sha256:x")
    certs = FakeCertStore(count=1)
    seals = FakeSealRegistry({"agent-1": 1})

    result = checker.check(
        "agent-1",
        audit_store=store,
        cert_store=certs,
        seal_registry=seals,
    )
    assert len(result.probes_run) == 4
    assert set(result.probes_run) == set(ContinuityProbe)


# ── Runtime integration tests ────────────────────────────────────────────


def test_runtime_continuity_disabled_by_default():
    """By default, continuity checks are disabled in RuntimeConfig."""
    from nomotic.runtime import GovernanceRuntime, RuntimeConfig

    config = RuntimeConfig()
    assert config.enable_continuity_checks is False

    runtime = GovernanceRuntime(config=config)
    assert runtime._continuity_checker is None


def test_runtime_continuity_enabled_runs_check():
    """When enabled, continuity checker is initialized."""
    from nomotic.runtime import GovernanceRuntime, RuntimeConfig

    config = RuntimeConfig(enable_continuity_checks=True)
    runtime = GovernanceRuntime(config=config)
    assert runtime._continuity_checker is not None


def test_runtime_continuity_failure_returns_deny_verdict():
    """When continuity check fails, runtime returns a DENY verdict."""
    from nomotic.runtime import GovernanceRuntime, RuntimeConfig
    from nomotic.types import Action, AgentContext, TrustProfile, Verdict

    config = RuntimeConfig(
        enable_continuity_checks=True,
        continuity_strict_mode=False,
        continuity_probes=[ContinuityProbe.RECORD_COUNT_MONOTONE],
    )
    runtime = GovernanceRuntime(config=config)

    # Set up a fake audit store
    fake_store = FakeAuditStore(records=[1, 2, 3])
    runtime._persistent_audit_store = fake_store

    action = Action(action_type="read", target="test")
    ctx = AgentContext(
        agent_id="agent-1",
        trust_profile=TrustProfile(agent_id="agent-1"),
    )

    # First evaluation: should pass (establishes snapshot)
    verdict = runtime.evaluate(action, ctx)
    # The verdict here depends on governance evaluation, but continuity passed

    # Now tamper with the store
    fake_store.set_records([1])

    # Second evaluation: continuity should fail → DENY
    action2 = Action(action_type="read", target="test")
    verdict2 = runtime.evaluate(action2, ctx)
    assert verdict2.verdict == Verdict.DENY
    assert verdict2.tier == 0
    assert verdict2.ucs == 0.0
    assert "continuity" in verdict2.reasoning.lower()


def test_update_snapshot_without_result_clears():
    """update_snapshot() without a result clears the snapshot."""
    checker = ContinuityChecker()
    store = FakeAuditStore(records=[1], last_hash="sha256:x")
    checker.check("agent-1", audit_store=store)
    assert checker.get_snapshot("agent-1") is not None

    checker.update_snapshot("agent-1", result=None)
    assert checker.get_snapshot("agent-1") is None

    # Next check should pass (first-check semantics)
    result = checker.check("agent-1", audit_store=store)
    assert result.passed is True
