"""Performance regression tests using pytest-benchmark.

Run: pytest tests/test_perf.py --benchmark-only
These tests fail if governance evaluation exceeds performance targets.
"""

from __future__ import annotations

import pytest

pytest.importorskip("pytest_benchmark")

from nomotic.runtime import GovernanceRuntime, RuntimeConfig
from nomotic.types import Action, AgentContext, TrustProfile


@pytest.fixture
def runtime():
    rt = GovernanceRuntime()
    rt.configure_scope(
        "perf-agent",
        {"read", "write", "query"},
        actor="test",
        reason="perf test",
    )
    rt.configure_boundaries(
        "perf-agent",
        {"customers", "orders"},
        actor="test",
        reason="perf test",
    )
    return rt


@pytest.fixture
def standard_action():
    return Action(agent_id="perf-agent", action_type="read", target="customers")


@pytest.fixture
def standard_context():
    return AgentContext(
        agent_id="perf-agent",
        trust_profile=TrustProfile(agent_id="perf-agent", overall_trust=0.5),
    )


def test_full_evaluation_under_50ms(benchmark, runtime, standard_action, standard_context):
    """Full 14-dimension evaluation must complete in under 50ms."""
    result = benchmark.pedantic(
        runtime.evaluate,
        args=(standard_action, standard_context),
        iterations=100,
        rounds=10,
    )
    assert result.verdict.name in {"ALLOW", "DENY", "MODIFY", "ESCALATE", "SUSPEND"}

    # Assert performance target
    assert benchmark.stats["median"] < 0.050, (
        f"Median evaluation time {benchmark.stats['median']*1000:.1f}ms exceeds 50ms target"
    )


def test_trust_update_under_1ms(benchmark):
    """Trust score update must complete in under 1ms."""
    trust = TrustProfile(agent_id="perf-agent", overall_trust=0.5)

    def adjust():
        trust.overall_trust = min(1.0, trust.overall_trust + 0.001)
        if trust.overall_trust >= 0.99:
            trust.overall_trust = 0.5

    benchmark.pedantic(
        adjust,
        iterations=1000,
        rounds=10,
    )

    assert benchmark.stats["median"] < 0.001


def test_denied_action_under_20ms(benchmark, runtime, standard_context):
    """Denied actions (veto path) should be faster than full evaluation."""
    action = Action(
        agent_id="perf-agent",
        action_type="launch_missiles",
        target="pentagon",
    )

    result = benchmark.pedantic(
        runtime.evaluate,
        args=(action, standard_context),
        iterations=100,
        rounds=10,
    )

    assert result.verdict.name == "DENY"
    assert benchmark.stats["median"] < 0.020
