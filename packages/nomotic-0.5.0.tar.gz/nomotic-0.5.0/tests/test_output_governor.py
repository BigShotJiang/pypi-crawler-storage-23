"""Tests for output_governor.py — Output Validation Governance."""

from __future__ import annotations

import hashlib
import hmac
import io
import json
import time
import uuid
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from nomotic.output_governor import (
    AUDIT_OUTPUT_BLOCKED,
    AUDIT_OUTPUT_ESCALATED,
    AUDIT_OUTPUT_REDACTED,
    OUTPUT_BLOCK,
    OUTPUT_ESCALATE,
    OUTPUT_PASS,
    OUTPUT_REDACT,
    OutputCheckResult,
    OutputGovernor,
    OutputGovernorConfig,
    OutputVerdict,
    RedactionRecord,
)


# ── TestOutputVerdict ────────────────────────────────────────────────


class TestOutputVerdict:
    """Tests for OutputVerdict creation and serialization."""

    def test_creation_basic(self) -> None:
        verdict = OutputVerdict(
            verdict=OUTPUT_PASS,
            output_id="nmout-abc123",
            agent_id="agent-1",
            action_id="act-1",
            seal_id="nms-seal-1",
            checks_performed=["pii_leakage"],
            checks_failed=[],
            check_results=[],
            redactions=[],
            redacted_output=None,
            ucs=0.97,
            reasoning="All output checks passed",
        )
        assert verdict.verdict == OUTPUT_PASS
        assert verdict.output_id == "nmout-abc123"
        assert verdict.agent_id == "agent-1"
        assert verdict.action_id == "act-1"
        assert verdict.seal_id == "nms-seal-1"
        assert verdict.ucs == 0.97

    def test_to_dict_from_dict_roundtrip(self) -> None:
        redaction = RedactionRecord(
            redaction_id="nmred-abc",
            check_name="pii_leakage",
            pattern_matched="test@example.com",
            replacement="[REDACTED-EMAIL]",
            character_count=16,
        )
        check_result = OutputCheckResult(
            check_name="pii_leakage",
            passed=True,
            score=0.5,
            reason="PII detected but redaction mode",
            redactions=[redaction],
        )
        verdict = OutputVerdict(
            verdict=OUTPUT_REDACT,
            output_id="nmout-xyz",
            agent_id="agent-2",
            action_id="act-2",
            seal_id="nms-seal-2",
            checks_performed=["pii_leakage"],
            checks_failed=[],
            check_results=[check_result],
            redactions=[redaction],
            redacted_output="Contact [REDACTED-EMAIL] for details.",
            ucs=0.5,
            reasoning="Output redacted",
            evaluated_at=1700000000.0,
        )
        d = verdict.to_dict()
        restored = OutputVerdict.from_dict(d)
        assert restored.verdict == OUTPUT_REDACT
        assert restored.output_id == "nmout-xyz"
        assert restored.agent_id == "agent-2"
        assert restored.ucs == 0.5
        assert len(restored.redactions) == 1
        assert restored.redactions[0].redaction_id == "nmred-abc"
        assert restored.redacted_output == "Contact [REDACTED-EMAIL] for details."

    def test_redactions_populated_correctly(self) -> None:
        r1 = RedactionRecord(
            redaction_id="nmred-1",
            check_name="pii_leakage",
            pattern_matched="test@example.com",
            replacement="[REDACTED-EMAIL]",
            character_count=16,
        )
        r2 = RedactionRecord(
            redaction_id="nmred-2",
            check_name="pii_leakage",
            pattern_matched="123-45-6789",
            replacement="[REDACTED-SSN]",
            character_count=11,
        )
        verdict = OutputVerdict(
            verdict=OUTPUT_REDACT,
            output_id="nmout-test",
            agent_id="agent-1",
            action_id=None,
            seal_id=None,
            checks_performed=["pii_leakage"],
            checks_failed=[],
            check_results=[],
            redactions=[r1, r2],
            redacted_output="redacted text",
            ucs=0.5,
            reasoning="Redacted",
        )
        assert len(verdict.redactions) == 2
        assert verdict.redactions[0].replacement == "[REDACTED-EMAIL]"
        assert verdict.redactions[1].replacement == "[REDACTED-SSN]"

    def test_checks_failed_reflects_failed_check_names(self) -> None:
        verdict = OutputVerdict(
            verdict=OUTPUT_BLOCK,
            output_id="nmout-test",
            agent_id="agent-1",
            action_id=None,
            seal_id=None,
            checks_performed=["pii_leakage", "scope_consistency"],
            checks_failed=["pii_leakage", "scope_consistency"],
            check_results=[],
            redactions=[],
            redacted_output=None,
            ucs=0.15,
            reasoning="Blocked",
        )
        assert "pii_leakage" in verdict.checks_failed
        assert "scope_consistency" in verdict.checks_failed


# ── TestPIILeakageCheck ──────────────────────────────────────────────


class TestPIILeakageCheck:
    """Tests for the PII leakage check."""

    def setup_method(self) -> None:
        self.gov = OutputGovernor()

    def test_email_detected_medium_sensitivity(self) -> None:
        self.gov.configure_agent("a", pii_sensitivity="medium", block_on_pii_leakage=True)
        verdict = self.gov.evaluate("Contact me at test@example.com", agent_id="a")
        assert verdict.verdict == OUTPUT_BLOCK
        assert "pii_leakage" in verdict.checks_failed

    def test_ssn_detected_low_sensitivity(self) -> None:
        self.gov.configure_agent("a", pii_sensitivity="low", block_on_pii_leakage=True)
        verdict = self.gov.evaluate("SSN is 123-45-6789", agent_id="a")
        assert verdict.verdict == OUTPUT_BLOCK
        assert "pii_leakage" in verdict.checks_failed

    def test_credit_card_detected_low_sensitivity(self) -> None:
        self.gov.configure_agent("a", pii_sensitivity="low", block_on_pii_leakage=True)
        verdict = self.gov.evaluate("Card: 4111-1111-1111-1111", agent_id="a")
        assert verdict.verdict == OUTPUT_BLOCK
        assert "pii_leakage" in verdict.checks_failed

    def test_email_at_low_sensitivity_passes(self) -> None:
        self.gov.configure_agent("a", pii_sensitivity="low", block_on_pii_leakage=True)
        verdict = self.gov.evaluate("Contact me at test@example.com", agent_id="a")
        assert verdict.verdict == OUTPUT_PASS

    def test_block_on_pii_false_redaction_populated(self) -> None:
        self.gov.configure_agent("a", pii_sensitivity="medium", block_on_pii_leakage=False)
        verdict = self.gov.evaluate("Email: test@example.com", agent_id="a")
        # PII found but block_on_pii_leakage=False so check passes with redactions
        assert verdict.verdict == OUTPUT_REDACT
        assert len(verdict.redactions) > 0
        assert verdict.redactions[0].replacement == "[REDACTED-EMAIL]"

    def test_clean_output_passes(self) -> None:
        self.gov.configure_agent("a", pii_sensitivity="medium", block_on_pii_leakage=True)
        verdict = self.gov.evaluate("Hello, this is a clean output.", agent_id="a")
        assert verdict.verdict == OUTPUT_PASS
        pii_result = [cr for cr in verdict.check_results if cr.check_name == "pii_leakage"]
        assert pii_result[0].passed is True
        assert pii_result[0].score == 1.0

    def test_multiple_pii_patterns_multiple_redactions(self) -> None:
        self.gov.configure_agent("a", pii_sensitivity="medium", block_on_pii_leakage=False)
        text = "Email: user@example.com, SSN: 123-45-6789"
        verdict = self.gov.evaluate(text, agent_id="a")
        assert len(verdict.redactions) >= 2
        replacements = {r.replacement for r in verdict.redactions}
        assert "[REDACTED-EMAIL]" in replacements
        assert "[REDACTED-SSN]" in replacements

    def test_redacted_email_replacement_in_output(self) -> None:
        self.gov.configure_agent("a", pii_sensitivity="medium", block_on_pii_leakage=False)
        text = "Send to user@example.com please"
        verdict = self.gov.evaluate(text, agent_id="a")
        assert verdict.verdict == OUTPUT_REDACT
        assert verdict.redacted_output is not None
        assert "[REDACTED-EMAIL]" in verdict.redacted_output
        assert "user@example.com" not in verdict.redacted_output

    def test_high_sensitivity_detects_phone(self) -> None:
        self.gov.configure_agent("a", pii_sensitivity="high", block_on_pii_leakage=True)
        verdict = self.gov.evaluate("Call me at (555) 123-4567", agent_id="a")
        assert verdict.verdict == OUTPUT_BLOCK

    def test_high_sensitivity_detects_nhs(self) -> None:
        self.gov.configure_agent("a", pii_sensitivity="high", block_on_pii_leakage=True)
        verdict = self.gov.evaluate("NHS number: 123 456 7890", agent_id="a")
        assert verdict.verdict == OUTPUT_BLOCK


# ── TestScopeConsistencyCheck ────────────────────────────────────────


class TestScopeConsistencyCheck:
    """Tests for the scope consistency check."""

    def setup_method(self) -> None:
        self.gov = OutputGovernor()

    def test_no_allowed_references_always_passes(self) -> None:
        self.gov.configure_agent("a")
        verdict = self.gov.evaluate("admin/settings and billing/invoices", agent_id="a")
        scope_result = [cr for cr in verdict.check_results if cr.check_name == "scope_consistency"]
        assert scope_result[0].passed is True
        assert scope_result[0].score == 1.0

    def test_output_references_allowed_target_passes(self) -> None:
        self.gov.configure_agent("a", allowed_target_references={"admin", "billing"})
        verdict = self.gov.evaluate("Check admin/settings for config.", agent_id="a")
        scope_result = [cr for cr in verdict.check_results if cr.check_name == "scope_consistency"]
        assert scope_result[0].passed is True

    def test_output_contains_disallowed_reference_fails(self) -> None:
        self.gov.configure_agent("a", allowed_target_references={"user"})
        verdict = self.gov.evaluate("Access admin/billing for the report.", agent_id="a")
        scope_result = [cr for cr in verdict.check_results if cr.check_name == "scope_consistency"]
        assert scope_result[0].passed is False
        assert scope_result[0].score == 0.3

    def test_no_suspicious_patterns_passes(self) -> None:
        self.gov.configure_agent("a", allowed_target_references={"user"})
        verdict = self.gov.evaluate("The user can view their profile.", agent_id="a")
        scope_result = [cr for cr in verdict.check_results if cr.check_name == "scope_consistency"]
        assert scope_result[0].passed is True


# ── TestContentSafetyCheck ───────────────────────────────────────────


class TestContentSafetyCheck:
    """Tests for the content safety check."""

    def setup_method(self) -> None:
        self.gov = OutputGovernor()

    def test_no_categories_configured_passes(self) -> None:
        self.gov.configure_agent("a")
        verdict = self.gov.evaluate("Some text here.", agent_id="a")
        safety_result = [cr for cr in verdict.check_results if cr.check_name == "content_safety"]
        assert safety_result[0].passed is True
        assert safety_result[0].score == 1.0

    def test_configured_category_in_output_fails(self) -> None:
        self.gov.configure_agent("a", content_safety_categories=["violence"])
        verdict = self.gov.evaluate("This contains violence and harm.", agent_id="a")
        safety_result = [cr for cr in verdict.check_results if cr.check_name == "content_safety"]
        assert safety_result[0].passed is False
        assert safety_result[0].score == 0.0

    def test_configured_category_absent_passes(self) -> None:
        self.gov.configure_agent("a", content_safety_categories=["violence"])
        verdict = self.gov.evaluate("The weather is nice today.", agent_id="a")
        safety_result = [cr for cr in verdict.check_results if cr.check_name == "content_safety"]
        assert safety_result[0].passed is True


# ── TestConfidenceCalibrationCheck ───────────────────────────────────


class TestConfidenceCalibrationCheck:
    """Tests for the confidence calibration check."""

    def setup_method(self) -> None:
        self.gov = OutputGovernor()

    def test_clean_hedged_output_passes(self) -> None:
        self.gov.configure_agent(
            "a",
            enabled_checks=["confidence_calibration"],
        )
        verdict = self.gov.evaluate(
            "Based on available information, the result may be approximately 42.",
            agent_id="a",
        )
        cal_result = [cr for cr in verdict.check_results if cr.check_name == "confidence_calibration"]
        assert cal_result[0].passed is True

    def test_i_am_certain_that_fails(self) -> None:
        self.gov.configure_agent(
            "a",
            enabled_checks=["confidence_calibration"],
        )
        verdict = self.gov.evaluate(
            "I am certain that the value is 42.",
            agent_id="a",
        )
        cal_result = [cr for cr in verdict.check_results if cr.check_name == "confidence_calibration"]
        assert cal_result[0].passed is False

    def test_as_of_today_fails_escalates(self) -> None:
        self.gov.configure_agent(
            "a",
            enabled_checks=["confidence_calibration"],
        )
        verdict = self.gov.evaluate(
            "As of today, the stock price is $150.",
            agent_id="a",
        )
        assert verdict.verdict == OUTPUT_ESCALATE
        cal_result = [cr for cr in verdict.check_results if cr.check_name == "confidence_calibration"]
        assert cal_result[0].passed is False


# ── TestOutputGovernorEvaluate ───────────────────────────────────────


class TestOutputGovernorEvaluate:
    """Tests for the main OutputGovernor.evaluate() method."""

    def setup_method(self) -> None:
        self.gov = OutputGovernor()

    def test_all_checks_pass_returns_pass(self) -> None:
        self.gov.configure_agent("a", pii_sensitivity="medium", block_on_pii_leakage=True)
        verdict = self.gov.evaluate("Hello, world.", agent_id="a")
        assert verdict.verdict == OUTPUT_PASS

    def test_pii_detected_block_on_true_returns_block(self) -> None:
        self.gov.configure_agent("a", pii_sensitivity="medium", block_on_pii_leakage=True)
        verdict = self.gov.evaluate("Email: test@example.com", agent_id="a")
        assert verdict.verdict == OUTPUT_BLOCK

    def test_pii_detected_block_on_false_returns_redact(self) -> None:
        self.gov.configure_agent("a", pii_sensitivity="medium", block_on_pii_leakage=False)
        verdict = self.gov.evaluate("Email: test@example.com", agent_id="a")
        assert verdict.verdict == OUTPUT_REDACT

    def test_redacted_output_contains_redacted_email(self) -> None:
        self.gov.configure_agent("a", pii_sensitivity="medium", block_on_pii_leakage=False)
        verdict = self.gov.evaluate("Email: test@example.com", agent_id="a")
        assert verdict.redacted_output is not None
        assert "[REDACTED-EMAIL]" in verdict.redacted_output

    def test_ucs_is_average_of_check_scores(self) -> None:
        # With default 3 checks and clean output, all scores should be 1.0
        self.gov.configure_agent("a")
        verdict = self.gov.evaluate("Clean output.", agent_id="a")
        assert verdict.ucs == 1.0

    def test_output_id_follows_nmout_format(self) -> None:
        self.gov.configure_agent("a")
        verdict = self.gov.evaluate("Hello.", agent_id="a")
        assert verdict.output_id.startswith("nmout-")

    def test_action_id_and_seal_id_passed_through(self) -> None:
        self.gov.configure_agent("a")
        verdict = self.gov.evaluate(
            "Hello.",
            agent_id="a",
            action_id="act-42",
            seal_id="nms-seal-42",
        )
        assert verdict.action_id == "act-42"
        assert verdict.seal_id == "nms-seal-42"

    def test_verdict_listener_called(self) -> None:
        listener = MagicMock()
        self.gov.add_verdict_listener(listener)
        self.gov.configure_agent("a")
        verdict = self.gov.evaluate("Hello.", agent_id="a")
        listener.assert_called_once_with(verdict)

    def test_output_block_written_to_audit_store(self, tmp_path: Path) -> None:
        from nomotic.audit_store import AuditStore

        audit_store = AuditStore(tmp_path)
        gov = OutputGovernor(audit_store=audit_store)
        gov.configure_agent("a", pii_sensitivity="medium", block_on_pii_leakage=True)
        verdict = gov.evaluate("Email: test@example.com", agent_id="a")
        assert verdict.verdict == OUTPUT_BLOCK

        records = audit_store.query("a", limit=10)
        assert len(records) == 1
        assert records[0].action_type == "output_evaluation"
        assert records[0].verdict == "BLOCK"

    def test_custom_validator_called(self) -> None:
        def custom_check(output_text: str, action_id: str | None) -> OutputCheckResult:
            if "forbidden" in output_text.lower():
                return OutputCheckResult(
                    check_name="custom_check",
                    passed=False,
                    score=0.0,
                    reason="Forbidden word found",
                )
            return OutputCheckResult(
                check_name="custom_check",
                passed=True,
                score=1.0,
                reason="OK",
            )

        self.gov.configure_agent("a", custom_validators=[custom_check])
        verdict = self.gov.evaluate("This is forbidden content.", agent_id="a")
        assert verdict.verdict == OUTPUT_BLOCK
        assert "custom_check" in verdict.checks_failed

    def test_unconfigured_agent_uses_default(self) -> None:
        # Don't configure the agent — should still work with defaults
        verdict = self.gov.evaluate("Hello.", agent_id="unknown-agent")
        assert verdict.verdict == OUTPUT_PASS
        assert len(verdict.checks_performed) == 3  # pii, scope, content_safety

    def test_pass_verdict_redacted_output_is_none(self) -> None:
        self.gov.configure_agent("a")
        verdict = self.gov.evaluate("Clean output.", agent_id="a")
        assert verdict.redacted_output is None

    def test_block_verdict_redacted_output_is_none(self) -> None:
        self.gov.configure_agent("a", pii_sensitivity="medium", block_on_pii_leakage=True)
        verdict = self.gov.evaluate("Email: test@example.com", agent_id="a")
        assert verdict.verdict == OUTPUT_BLOCK
        assert verdict.redacted_output is None


# ── TestOutputGovernorConfiguration ──────────────────────────────────


class TestOutputGovernorConfiguration:
    """Tests for OutputGovernor agent configuration."""

    def test_configure_agent_creates_new_config(self) -> None:
        gov = OutputGovernor()
        gov.configure_agent("a", pii_sensitivity="high")
        assert "a" in gov._configs
        assert gov._configs["a"].pii_sensitivity == "high"

    def test_configure_agent_merges_existing(self) -> None:
        gov = OutputGovernor()
        gov.configure_agent("a", pii_sensitivity="high")
        gov.configure_agent("a", block_on_pii_leakage=False)
        # pii_sensitivity should be preserved from first call
        assert gov._configs["a"].pii_sensitivity == "high"
        assert gov._configs["a"].block_on_pii_leakage is False

    def test_unconfigured_agent_default_checks(self) -> None:
        gov = OutputGovernor()
        verdict = gov.evaluate("Hello.", agent_id="test-agent")
        # Default: pii_leakage, scope_consistency, content_safety
        assert len(verdict.checks_performed) == 3
        assert "pii_leakage" in verdict.checks_performed
        assert "scope_consistency" in verdict.checks_performed
        assert "content_safety" in verdict.checks_performed


# ── TestOutputGovernorRuntime ────────────────────────────────────────


class TestOutputGovernorRuntime:
    """Tests for output governor integration with GovernanceRuntime."""

    def test_runtime_output_governor_lazy_initialized(self) -> None:
        from nomotic.runtime import GovernanceRuntime

        runtime = GovernanceRuntime()
        # Access should trigger lazy initialization
        og = runtime.output_governor
        assert og is not None
        # Second access should return same instance
        assert runtime.output_governor is og

    def test_runtime_output_governor_uses_same_audit_store(self, tmp_path: Path) -> None:
        from nomotic.audit_store import AuditStore
        from nomotic.runtime import GovernanceRuntime

        runtime = GovernanceRuntime()
        audit_store = AuditStore(tmp_path)
        runtime.set_audit_store(audit_store)
        og = runtime.output_governor
        assert og._audit_store is audit_store


# ── TestInstructionComplianceCheck ───────────────────────────────────


class TestInstructionComplianceCheck:
    """Tests for the instruction compliance check."""

    def test_no_instruction_set_passes(self) -> None:
        gov = OutputGovernor()
        gov.configure_agent("a", enabled_checks=["instruction_compliance"])
        verdict = gov.evaluate("Whatever text.", agent_id="a")
        result = [cr for cr in verdict.check_results if cr.check_name == "instruction_compliance"]
        assert result[0].passed is True

    def test_instruction_violation_detected(self) -> None:
        gov = OutputGovernor()
        gov.configure_agent(
            "a",
            enabled_checks=["instruction_compliance"],
            instruction_set=["do not reproduce PII"],
        )
        verdict = gov.evaluate("Here is the reproduce PII data.", agent_id="a")
        result = [cr for cr in verdict.check_results if cr.check_name == "instruction_compliance"]
        assert result[0].passed is False

    def test_instruction_compliance_passes_when_compliant(self) -> None:
        gov = OutputGovernor()
        gov.configure_agent(
            "a",
            enabled_checks=["instruction_compliance"],
            instruction_set=["do not reproduce PII"],
        )
        verdict = gov.evaluate("Here is a summary of the data.", agent_id="a")
        result = [cr for cr in verdict.check_results if cr.check_name == "instruction_compliance"]
        assert result[0].passed is True


# ── TestWebhookNotification ──────────────────────────────────────────


class TestWebhookNotification:
    """Tests for webhook notification on non-PASS verdicts."""

    def test_block_triggers_webhook(self) -> None:
        dispatcher = MagicMock()
        gov = OutputGovernor(webhook_dispatcher=dispatcher)
        gov.configure_agent("a", pii_sensitivity="medium", block_on_pii_leakage=True)
        gov.evaluate("Email: test@example.com", agent_id="a")
        dispatcher.dispatch.assert_called_once()
        event = dispatcher.dispatch.call_args[0][0]
        assert event.event_type == AUDIT_OUTPUT_BLOCKED

    def test_pass_does_not_trigger_webhook(self) -> None:
        dispatcher = MagicMock()
        gov = OutputGovernor(webhook_dispatcher=dispatcher)
        gov.configure_agent("a")
        gov.evaluate("Clean output.", agent_id="a")
        dispatcher.dispatch.assert_not_called()

    def test_redact_triggers_webhook(self) -> None:
        dispatcher = MagicMock()
        gov = OutputGovernor(webhook_dispatcher=dispatcher)
        gov.configure_agent("a", pii_sensitivity="medium", block_on_pii_leakage=False)
        gov.evaluate("Email: test@example.com", agent_id="a")
        dispatcher.dispatch.assert_called_once()
        event = dispatcher.dispatch.call_args[0][0]
        assert event.event_type == AUDIT_OUTPUT_REDACTED

    def test_escalate_triggers_webhook(self) -> None:
        dispatcher = MagicMock()
        gov = OutputGovernor(webhook_dispatcher=dispatcher)
        gov.configure_agent("a", enabled_checks=["confidence_calibration"])
        gov.evaluate("I am certain that the earth is flat.", agent_id="a")
        dispatcher.dispatch.assert_called_once()
        event = dispatcher.dispatch.call_args[0][0]
        assert event.event_type == AUDIT_OUTPUT_ESCALATED


# ── TestAuditRecordWriting ───────────────────────────────────────────


class TestAuditRecordWriting:
    """Tests for audit record writing with hash chaining."""

    def test_pass_verdict_writes_info_severity(self, tmp_path: Path) -> None:
        from nomotic.audit_store import AuditStore

        store = AuditStore(tmp_path)
        gov = OutputGovernor(audit_store=store)
        gov.configure_agent("a")
        gov.evaluate("Clean text.", agent_id="a")
        records = store.query("a", limit=5)
        assert len(records) == 1
        assert records[0].severity == "info"

    def test_block_verdict_writes_alert_severity(self, tmp_path: Path) -> None:
        from nomotic.audit_store import AuditStore

        store = AuditStore(tmp_path)
        gov = OutputGovernor(audit_store=store)
        gov.configure_agent("a", pii_sensitivity="medium", block_on_pii_leakage=True)
        gov.evaluate("SSN: 123-45-6789", agent_id="a")
        records = store.query("a", limit=5)
        assert len(records) == 1
        assert records[0].severity == "alert"
        assert records[0].verdict == "BLOCK"

    def test_audit_record_has_output_evaluation_type(self, tmp_path: Path) -> None:
        from nomotic.audit_store import AuditStore

        store = AuditStore(tmp_path)
        gov = OutputGovernor(audit_store=store)
        gov.configure_agent("a")
        gov.evaluate("Hello.", agent_id="a")
        records = store.query("a", limit=5)
        assert records[0].action_type == "output_evaluation"

    def test_audit_record_parameters_contain_output_fields(self, tmp_path: Path) -> None:
        from nomotic.audit_store import AuditStore

        store = AuditStore(tmp_path)
        gov = OutputGovernor(audit_store=store)
        gov.configure_agent("a", pii_sensitivity="medium", block_on_pii_leakage=True)
        gov.evaluate("Email: x@y.com", agent_id="a")
        records = store.query("a", limit=5)
        params = records[0].parameters
        assert params["record_type"] == "OUTPUT_EVALUATION"
        assert "output_id" in params
        assert "checks_failed" in params

    def test_hash_chaining_across_records(self, tmp_path: Path) -> None:
        from nomotic.audit_store import AuditStore

        store = AuditStore(tmp_path)
        gov = OutputGovernor(audit_store=store)
        gov.configure_agent("a")
        gov.evaluate("First output.", agent_id="a")
        gov.evaluate("Second output.", agent_id="a")
        records = store.query("a", limit=5)
        assert len(records) == 2
        # Most recent first in query result
        assert records[0].previous_hash != ""
        assert records[0].record_hash != records[1].record_hash


# ── TestImports ──────────────────────────────────────────────────────


class TestImports:
    """Tests for public API exports."""

    def test_imports_from_nomotic(self) -> None:
        from nomotic import (
            OUTPUT_BLOCK,
            OUTPUT_ESCALATE,
            OUTPUT_PASS,
            OUTPUT_REDACT,
            OutputCheckResult,
            OutputGovernor,
            OutputGovernorConfig,
            OutputVerdict,
            RedactionRecord,
        )
        assert OUTPUT_PASS == "PASS"
        assert OUTPUT_BLOCK == "BLOCK"
        assert OUTPUT_REDACT == "REDACT"
        assert OUTPUT_ESCALATE == "ESCALATE"


# ── TestExternalValidator ────────────────────────────────────────────


def _make_urlopen_response(body: dict) -> MagicMock:
    """Helper: create a mock urlopen response that returns *body* as JSON."""
    raw = json.dumps(body).encode("utf-8")
    resp = MagicMock()
    resp.read.return_value = raw
    resp.__enter__ = MagicMock(return_value=resp)
    resp.__exit__ = MagicMock(return_value=False)
    return resp


class TestExternalValidator:
    """Tests for the external webhook validator integration."""

    def setup_method(self) -> None:
        self.gov = OutputGovernor()

    # ── basic dispatch ───────────────────────────────────────────

    def test_not_called_when_url_not_configured(self) -> None:
        """External validator is skipped when no URL is configured."""
        self.gov.configure_agent("a", enabled_checks=["content_safety"])
        with patch("urllib.request.urlopen") as mock_urlopen:
            verdict = self.gov.evaluate("Hello.", agent_id="a")
        mock_urlopen.assert_not_called()
        assert verdict.verdict == OUTPUT_PASS

    @patch("urllib.request.urlopen")
    def test_called_when_url_configured(self, mock_urlopen: MagicMock) -> None:
        """External validator is called when URL is configured."""
        mock_urlopen.return_value = _make_urlopen_response({"score": 0.9})
        self.gov.configure_agent(
            "a",
            enabled_checks=["content_safety"],
            external_validator_url="https://example.com/validate",
        )
        self.gov.evaluate("Hello.", agent_id="a")
        mock_urlopen.assert_called_once()

    # ── fallback behaviour ───────────────────────────────────────

    @patch("urllib.request.urlopen", side_effect=TimeoutError("timed out"))
    def test_timeout_falls_back_to_builtin(self, mock_urlopen: MagicMock) -> None:
        """On timeout the built-in check result is returned unchanged."""
        self.gov.configure_agent(
            "a",
            enabled_checks=["content_safety"],
            external_validator_url="https://example.com/validate",
        )
        verdict = self.gov.evaluate("Hello.", agent_id="a")
        # Built-in should pass (no categories configured)
        assert verdict.verdict == OUTPUT_PASS
        safety = [cr for cr in verdict.check_results if cr.check_name == "content_safety"]
        assert safety[0].passed is True
        assert "External" not in safety[0].reason

    @patch("urllib.request.urlopen", side_effect=ConnectionError("refused"))
    def test_connection_error_falls_back_to_builtin(self, mock_urlopen: MagicMock) -> None:
        """On connection error the built-in check result is returned."""
        self.gov.configure_agent(
            "a",
            enabled_checks=["content_safety"],
            external_validator_url="https://example.com/validate",
        )
        verdict = self.gov.evaluate("Hello.", agent_id="a")
        assert verdict.verdict == OUTPUT_PASS

    @patch("urllib.request.urlopen")
    def test_malformed_response_falls_back_to_builtin(self, mock_urlopen: MagicMock) -> None:
        """A response without valid JSON falls back to built-in."""
        resp = MagicMock()
        resp.read.return_value = b"not json at all"
        resp.__enter__ = MagicMock(return_value=resp)
        resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = resp
        self.gov.configure_agent(
            "a",
            enabled_checks=["content_safety"],
            external_validator_url="https://example.com/validate",
        )
        verdict = self.gov.evaluate("Hello.", agent_id="a")
        assert verdict.verdict == OUTPUT_PASS

    # ── score blending ───────────────────────────────────────────

    @patch("urllib.request.urlopen")
    def test_external_score_used_at_weight_1_0(self, mock_urlopen: MagicMock) -> None:
        """At weight=1.0 the blended score equals the external score."""
        mock_urlopen.return_value = _make_urlopen_response({"score": 0.8, "reasoning": "ok"})
        self.gov.configure_agent(
            "a",
            enabled_checks=["content_safety"],
            external_validator_url="https://example.com/validate",
            external_validator_weight=1.0,
        )
        verdict = self.gov.evaluate("Hello.", agent_id="a")
        safety = [cr for cr in verdict.check_results if cr.check_name == "content_safety"]
        assert safety[0].score == pytest.approx(0.8)
        assert "External" in safety[0].reason

    @patch("urllib.request.urlopen")
    def test_external_score_blended_at_weight_0_5(self, mock_urlopen: MagicMock) -> None:
        """At weight=0.5 the blended score averages external and built-in."""
        mock_urlopen.return_value = _make_urlopen_response({"score": 0.6})
        self.gov.configure_agent(
            "a",
            enabled_checks=["content_safety"],
            external_validator_url="https://example.com/validate",
            external_validator_weight=0.5,
        )
        verdict = self.gov.evaluate("Hello.", agent_id="a")
        safety = [cr for cr in verdict.check_results if cr.check_name == "content_safety"]
        # built-in = 1.0 (no categories), external = 0.6, weight = 0.5
        expected = 1.0 * 0.5 + 0.6 * 0.5  # 0.8
        assert safety[0].score == pytest.approx(expected)

    # ── HMAC signing ─────────────────────────────────────────────

    @patch("urllib.request.urlopen")
    def test_hmac_header_sent_when_secret_configured(self, mock_urlopen: MagicMock) -> None:
        """X-Nomotic-Signature header is present when a secret is set."""
        mock_urlopen.return_value = _make_urlopen_response({"score": 1.0})
        self.gov.configure_agent(
            "a",
            enabled_checks=["content_safety"],
            external_validator_url="https://example.com/validate",
            external_validator_secret="my-secret",
        )
        self.gov.evaluate("Hello.", agent_id="a")
        # Inspect the Request object passed to urlopen
        req = mock_urlopen.call_args[0][0]
        sig_header = req.get_header("X-nomotic-signature")
        assert sig_header is not None
        assert sig_header.startswith("sha256=")
        # Verify the signature is valid
        expected = hmac.new(
            b"my-secret", req.data, hashlib.sha256
        ).hexdigest()
        assert sig_header == f"sha256={expected}"
        assert req.get_header("X-nomotic-signature-version") == "v1"

    @patch("urllib.request.urlopen")
    def test_no_hmac_header_when_no_secret(self, mock_urlopen: MagicMock) -> None:
        """X-Nomotic-Signature header is absent when no secret is set."""
        mock_urlopen.return_value = _make_urlopen_response({"score": 1.0})
        self.gov.configure_agent(
            "a",
            enabled_checks=["content_safety"],
            external_validator_url="https://example.com/validate",
        )
        self.gov.evaluate("Hello.", agent_id="a")
        req = mock_urlopen.call_args[0][0]
        assert req.get_header("X-nomotic-signature") is None

    # ── pass / block outcomes ────────────────────────────────────

    @patch("urllib.request.urlopen")
    def test_external_low_score_causes_block(self, mock_urlopen: MagicMock) -> None:
        """A low external score (< 0.5) at weight=1.0 blocks the output."""
        mock_urlopen.return_value = _make_urlopen_response({"score": 0.1})
        self.gov.configure_agent(
            "a",
            enabled_checks=["content_safety"],
            external_validator_url="https://example.com/validate",
            external_validator_weight=1.0,
        )
        verdict = self.gov.evaluate("Hello.", agent_id="a")
        assert verdict.verdict == OUTPUT_BLOCK
        safety = [cr for cr in verdict.check_results if cr.check_name == "content_safety"]
        assert safety[0].passed is False

    @patch("urllib.request.urlopen")
    def test_external_high_score_passes_output(self, mock_urlopen: MagicMock) -> None:
        """A high external score passes the output."""
        mock_urlopen.return_value = _make_urlopen_response({"score": 0.95})
        self.gov.configure_agent(
            "a",
            enabled_checks=["content_safety"],
            external_validator_url="https://example.com/validate",
            external_validator_weight=1.0,
        )
        verdict = self.gov.evaluate("Hello.", agent_id="a")
        assert verdict.verdict == OUTPUT_PASS
        safety = [cr for cr in verdict.check_results if cr.check_name == "content_safety"]
        assert safety[0].passed is True

    # ── score clamping ───────────────────────────────────────────

    @patch("urllib.request.urlopen")
    def test_score_clamped_to_0_1_range(self, mock_urlopen: MagicMock) -> None:
        """Scores outside [0, 1] are clamped."""
        mock_urlopen.return_value = _make_urlopen_response({"score": 5.0})
        self.gov.configure_agent(
            "a",
            enabled_checks=["content_safety"],
            external_validator_url="https://example.com/validate",
            external_validator_weight=1.0,
        )
        verdict = self.gov.evaluate("Hello.", agent_id="a")
        safety = [cr for cr in verdict.check_results if cr.check_name == "content_safety"]
        assert safety[0].score <= 1.0

        # Negative score
        mock_urlopen.return_value = _make_urlopen_response({"score": -2.0})
        verdict2 = self.gov.evaluate("Hello.", agent_id="a")
        safety2 = [cr for cr in verdict2.check_results if cr.check_name == "content_safety"]
        assert safety2[0].score >= 0.0
