"""Tests for Certificate Cross-Verification in Governance Seals.

Tests the cryptographic chain: Birth Certificate → Governance Seal → Certificate Store.
"""

import json
import time

import pytest

from nomotic.audit import AuditTrail
from nomotic.authority import CertificateAuthority
from nomotic.certificate import (
    AgentCertificate,
    CertificateStatusError,
    CertStatus,
)
from nomotic.keys import SigningKey, VerifyKey
from nomotic.seal import (
    GovernanceSeal,
    SealVerificationResult,
    seal_action,
    verify_seal,
)
from nomotic.store import MemoryCertificateStore
from nomotic.types import (
    Action,
    AgentContext,
    DimensionScore,
    GovernanceVerdict,
    TrustProfile,
    Verdict,
)


# ── Helpers ────────────────────────────────────────────────────────────


def _make_signing_key() -> tuple[SigningKey, VerifyKey]:
    return SigningKey.generate()


def _make_allow_verdict(
    action_id: str = "test-action-001",
    ucs: float = 0.85,
    tier: int = 2,
    agent_id: str = "test-agent",
) -> GovernanceVerdict:
    return GovernanceVerdict(
        action_id=action_id,
        verdict=Verdict.ALLOW,
        ucs=ucs,
        tier=tier,
        dimension_scores=[
            DimensionScore(dimension_name="scope_compliance", score=0.9, weight=1.0),
            DimensionScore(dimension_name="data_sensitivity", score=0.8, weight=1.0),
        ],
        vetoed_by=[],
        reasoning="All dimensions passed",
        reversibility={"level": "reversible", "confidence": 0.9},
    )


def _make_context(agent_id: str = "test-agent", trust: float = 0.7) -> AgentContext:
    return AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id, overall_trust=trust),
    )


def _make_ca_and_cert(
    agent_id: str = "test-agent",
    owner: str = "test-owner",
    org: str = "test-org",
) -> tuple[CertificateAuthority, AgentCertificate, MemoryCertificateStore]:
    """Create a CA, issue a certificate, and return all three."""
    sk, vk = _make_signing_key()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)
    cert, _agent_sk = ca.issue(
        agent_id=agent_id,
        archetype="general",
        organization=org,
        zone_path="global",
        owner=owner,
    )
    return ca, cert, store


# ── Issuance Tests ───────────────────────────────────────────────────


class TestSealIssuanceWithCert:
    """Tests for seal_action() with certificate binding."""

    def test_seal_with_active_cert_embeds_cert_id(self):
        """Seal issued with ACTIVE certificate embeds correct cert_id."""
        ca, cert, store = _make_ca_and_cert()
        verdict = _make_allow_verdict(agent_id=cert.agent_id)
        context = _make_context(agent_id=cert.agent_id)

        seal = seal_action(verdict, context, ca._signing_key, certificate=cert)

        assert seal is not None
        assert seal.cert_id == cert.certificate_id
        assert seal.cert_fingerprint == cert.fingerprint

    def test_seal_with_active_cert_embeds_cert_fingerprint(self):
        """Seal issued with ACTIVE certificate embeds correct cert_fingerprint."""
        ca, cert, store = _make_ca_and_cert()
        verdict = _make_allow_verdict(agent_id=cert.agent_id)
        context = _make_context(agent_id=cert.agent_id)

        seal = seal_action(verdict, context, ca._signing_key, certificate=cert)

        assert seal is not None
        assert seal.cert_fingerprint.startswith("SHA256:")
        assert seal.cert_fingerprint == cert.fingerprint

    def test_seal_issuance_fails_with_suspended_cert(self):
        """Seal issuance fails with CertificateStatusError when certificate is SUSPENDED."""
        ca, cert, store = _make_ca_and_cert()
        ca.suspend(cert.certificate_id, "test suspension")
        # Re-fetch the updated certificate
        cert = store.get(cert.certificate_id)

        verdict = _make_allow_verdict(agent_id=cert.agent_id)
        context = _make_context(agent_id=cert.agent_id)

        with pytest.raises(CertificateStatusError) as exc_info:
            seal_action(verdict, context, ca._signing_key, certificate=cert)

        assert exc_info.value.status == CertStatus.SUSPENDED
        assert exc_info.value.agent_id == cert.agent_id

    def test_seal_issuance_fails_with_revoked_cert(self):
        """Seal issuance fails with CertificateStatusError when certificate is REVOKED."""
        ca, cert, store = _make_ca_and_cert()
        ca.revoke(cert.certificate_id, "test revocation")
        # Re-fetch the updated certificate (now in revoked store)
        cert = store.get(cert.certificate_id)

        verdict = _make_allow_verdict(agent_id=cert.agent_id)
        context = _make_context(agent_id=cert.agent_id)

        with pytest.raises(CertificateStatusError) as exc_info:
            seal_action(verdict, context, ca._signing_key, certificate=cert)

        assert exc_info.value.status == CertStatus.REVOKED

    def test_seal_issuance_fails_agent_id_mismatch(self):
        """Seal issuance fails when agent_id in certificate doesn't match."""
        ca, cert, store = _make_ca_and_cert(agent_id="agent-A")
        verdict = _make_allow_verdict(agent_id="agent-B")
        context = _make_context(agent_id="agent-B")

        with pytest.raises(ValueError, match="does not match"):
            seal_action(verdict, context, ca._signing_key, certificate=cert)

    def test_cert_fields_in_signed_payload(self):
        """cert_id and cert_fingerprint are included in the signed payload."""
        ca, cert, store = _make_ca_and_cert()
        verdict = _make_allow_verdict(agent_id=cert.agent_id)
        context = _make_context(agent_id=cert.agent_id)

        seal = seal_action(verdict, context, ca._signing_key, certificate=cert)
        assert seal is not None

        # Parse the canonical bytes to verify cert fields are in the signed data
        canonical = seal.canonical_bytes()
        canonical_dict = json.loads(canonical)
        assert "cert_id" in canonical_dict
        assert canonical_dict["cert_id"] == cert.certificate_id
        assert "cert_fingerprint" in canonical_dict
        assert canonical_dict["cert_fingerprint"] == cert.fingerprint

    def test_tampering_cert_id_invalidates_signature(self):
        """Tampering with cert_id after signing invalidates the seal."""
        ca, cert, store = _make_ca_and_cert()
        verdict = _make_allow_verdict(agent_id=cert.agent_id)
        context = _make_context(agent_id=cert.agent_id)

        seal = seal_action(verdict, context, ca._signing_key, certificate=cert)
        assert seal is not None

        # Tamper with cert_id
        seal.cert_id = "nmc-fake-id"
        assert seal.verify(ca._verify_key) is False

    def test_tampering_cert_fingerprint_invalidates_signature(self):
        """Tampering with cert_fingerprint after signing invalidates the seal."""
        ca, cert, store = _make_ca_and_cert()
        verdict = _make_allow_verdict(agent_id=cert.agent_id)
        context = _make_context(agent_id=cert.agent_id)

        seal = seal_action(verdict, context, ca._signing_key, certificate=cert)
        assert seal is not None

        # Tamper with cert_fingerprint
        seal.cert_fingerprint = "SHA256:0000000000000000"
        assert seal.verify(ca._verify_key) is False

    def test_seal_without_cert_has_empty_binding(self):
        """Seal without certificate has empty cert_id and cert_fingerprint."""
        sk, vk = _make_signing_key()
        verdict = _make_allow_verdict()
        context = _make_context()

        seal = seal_action(verdict, context, sk)
        assert seal is not None
        assert seal.cert_id == ""
        assert seal.cert_fingerprint == ""

    def test_seal_auto_lookup_from_store(self):
        """Seal auto-looks up certificate from store when not provided."""
        ca, cert, store = _make_ca_and_cert()
        verdict = _make_allow_verdict(agent_id=cert.agent_id)
        context = _make_context(agent_id=cert.agent_id)

        seal = seal_action(
            verdict, context, ca._signing_key, certificate=None, cert_store=store,
        )
        assert seal is not None
        assert seal.cert_id == cert.certificate_id
        assert seal.cert_fingerprint == cert.fingerprint


# ── Validation Tests ──────────────────────────────────────────────────


class TestSealCrossVerification:
    """Tests for verify_seal() with certificate cross-verification."""

    def test_valid_seal_with_correct_cert_binding(self):
        """Seal with correct certificate binding validates successfully."""
        ca, cert, store = _make_ca_and_cert()
        verdict = _make_allow_verdict(agent_id=cert.agent_id)
        context = _make_context(agent_id=cert.agent_id)

        seal = seal_action(verdict, context, ca._signing_key, certificate=cert)
        assert seal is not None

        result = verify_seal(seal, ca._verify_key, cert_store=store)

        assert result.valid is True
        assert result.cert_verified is True
        assert result.cert_id == cert.certificate_id
        assert result.cert_fingerprint == cert.fingerprint
        assert result.cert_status == "ACTIVE"
        assert result.cross_verify_error is None

    def test_cert_not_found_in_store(self):
        """Seal fails with CERT_NOT_FOUND when certificate not in store."""
        ca, cert, store = _make_ca_and_cert()
        verdict = _make_allow_verdict(agent_id=cert.agent_id)
        context = _make_context(agent_id=cert.agent_id)

        seal = seal_action(verdict, context, ca._signing_key, certificate=cert)
        assert seal is not None

        # Use empty store for verification
        empty_store = MemoryCertificateStore()
        result = verify_seal(seal, ca._verify_key, cert_store=empty_store)

        assert result.valid is False
        assert result.cert_verified is False
        assert result.cross_verify_error == "CERT_NOT_FOUND"

    def test_cert_fingerprint_mismatch(self):
        """Seal fails with CERT_FINGERPRINT_MISMATCH when fingerprint tampered."""
        ca, cert, store = _make_ca_and_cert()
        verdict = _make_allow_verdict(agent_id=cert.agent_id)
        context = _make_context(agent_id=cert.agent_id)

        seal = seal_action(verdict, context, ca._signing_key, certificate=cert)
        assert seal is not None

        # Tamper with the certificate's fingerprint in the store
        stored_cert = store.get(cert.certificate_id)
        stored_cert.fingerprint = "SHA256:tampered"
        store.update(stored_cert)

        result = verify_seal(seal, ca._verify_key, cert_store=store)

        assert result.valid is False
        assert result.cert_verified is False
        assert result.cross_verify_error == "CERT_FINGERPRINT_MISMATCH"

    def test_cert_suspended_after_issuance(self):
        """Seal fails with CERT_NOT_ACTIVE when certificate suspended after issuance."""
        ca, cert, store = _make_ca_and_cert()
        verdict = _make_allow_verdict(agent_id=cert.agent_id)
        context = _make_context(agent_id=cert.agent_id)

        seal = seal_action(verdict, context, ca._signing_key, certificate=cert)
        assert seal is not None

        # Suspend the certificate after seal issuance
        ca.suspend(cert.certificate_id, "post-issuance suspension")

        result = verify_seal(seal, ca._verify_key, cert_store=store)

        assert result.valid is False
        assert result.cert_verified is False
        assert result.cross_verify_error == "CERT_NOT_ACTIVE"
        assert result.cert_status == "SUSPENDED"

    def test_cert_revoked_after_issuance(self):
        """Seal fails with CERT_NOT_ACTIVE when certificate revoked after issuance."""
        ca, cert, store = _make_ca_and_cert()
        verdict = _make_allow_verdict(agent_id=cert.agent_id)
        context = _make_context(agent_id=cert.agent_id)

        seal = seal_action(verdict, context, ca._signing_key, certificate=cert)
        assert seal is not None

        # Revoke the certificate after seal issuance
        ca.revoke(cert.certificate_id, "post-issuance revocation")

        result = verify_seal(seal, ca._verify_key, cert_store=store)

        assert result.valid is False
        assert result.cert_verified is False
        assert result.cross_verify_error == "CERT_NOT_ACTIVE"
        assert result.cert_status == "REVOKED"

    def test_legacy_seal_without_cert_binding(self):
        """Legacy seal without cert_id/cert_fingerprint validates with cert_verified=False."""
        sk, vk = _make_signing_key()
        verdict = _make_allow_verdict()
        context = _make_context()

        seal = seal_action(verdict, context, sk)
        assert seal is not None
        assert seal.cert_id == ""
        assert seal.cert_fingerprint == ""

        store = MemoryCertificateStore()
        result = verify_seal(seal, vk, cert_store=store)

        assert result.valid is True
        assert result.cert_verified is False
        assert result.cross_verify_error is None

    def test_incomplete_binding_only_cert_id(self):
        """Seal with only cert_id (no cert_fingerprint) fails with CERT_BINDING_INCOMPLETE."""
        sk, vk = _make_signing_key()
        verdict = _make_allow_verdict()
        context = _make_context()

        seal = seal_action(verdict, context, sk)
        assert seal is not None

        # Manually set only cert_id and re-sign
        seal.cert_id = "nmc-some-id"
        seal.cert_fingerprint = ""
        seal.signature = sk.sign(seal.canonical_bytes())

        result = verify_seal(seal, vk)
        assert result.valid is False
        assert result.cross_verify_error == "CERT_BINDING_INCOMPLETE"

    def test_incomplete_binding_only_cert_fingerprint(self):
        """Seal with only cert_fingerprint (no cert_id) fails with CERT_BINDING_INCOMPLETE."""
        sk, vk = _make_signing_key()
        verdict = _make_allow_verdict()
        context = _make_context()

        seal = seal_action(verdict, context, sk)
        assert seal is not None

        # Manually set only cert_fingerprint and re-sign
        seal.cert_id = ""
        seal.cert_fingerprint = "SHA256:abcdef"
        seal.signature = sk.sign(seal.canonical_bytes())

        result = verify_seal(seal, vk)
        assert result.valid is False
        assert result.cross_verify_error == "CERT_BINDING_INCOMPLETE"

    def test_expired_seal_fails_verification(self):
        """Expired seal fails before cross-verification is attempted."""
        ca, cert, store = _make_ca_and_cert()
        verdict = _make_allow_verdict(agent_id=cert.agent_id)
        context = _make_context(agent_id=cert.agent_id)

        seal = seal_action(
            verdict, context, ca._signing_key, certificate=cert, ttl_seconds=1,
        )
        assert seal is not None

        # Force expiration
        seal.expires_at = time.time() - 10
        seal.signature = ca._signing_key.sign(seal.canonical_bytes())

        result = verify_seal(seal, ca._verify_key, cert_store=store)
        assert result.valid is False
        assert result.expired is True
        assert result.error == "EXPIRED_SEAL"

    def test_invalid_signature_fails_verification(self):
        """Invalid signature fails before cross-verification is attempted."""
        ca, cert, store = _make_ca_and_cert()
        verdict = _make_allow_verdict(agent_id=cert.agent_id)
        context = _make_context(agent_id=cert.agent_id)

        seal = seal_action(verdict, context, ca._signing_key, certificate=cert)
        assert seal is not None

        # Use a different key for verification
        _other_sk, other_vk = _make_signing_key()
        result = verify_seal(seal, other_vk, cert_store=store)

        assert result.valid is False
        assert result.error == "INVALID_SIGNATURE"

    def test_valid_seal_without_store(self):
        """Seal with cert binding but no store is valid but not cert-verified."""
        ca, cert, store = _make_ca_and_cert()
        verdict = _make_allow_verdict(agent_id=cert.agent_id)
        context = _make_context(agent_id=cert.agent_id)

        seal = seal_action(verdict, context, ca._signing_key, certificate=cert)
        assert seal is not None

        # No cert_store provided
        result = verify_seal(seal, ca._verify_key, cert_store=None)

        assert result.valid is True
        assert result.cert_verified is False
        assert result.cert_id == cert.certificate_id
        assert result.cert_fingerprint == cert.fingerprint


# ── Audit Trail Tests ─────────────────────────────────────────────────


class TestCrossVerificationAudit:
    """Tests for audit trail recording of cross-verification results."""

    def test_successful_cross_verification_audited(self):
        """Successful cross-verification is recorded in audit trail."""
        ca, cert, store = _make_ca_and_cert()
        verdict = _make_allow_verdict(agent_id=cert.agent_id)
        context = _make_context(agent_id=cert.agent_id)

        seal = seal_action(verdict, context, ca._signing_key, certificate=cert)
        assert seal is not None

        trail = AuditTrail()
        result = verify_seal(seal, ca._verify_key, cert_store=store, audit_trail=trail)

        assert result.valid is True
        assert result.cert_verified is True

        records = trail.query(limit=10)
        assert len(records) == 1
        record = records[0]
        assert record.context_code == "SEAL.VERIFY_OK"
        assert record.severity == "info"
        assert record.metadata["cert_verified"] is True
        assert record.metadata["seal_id"] == seal.seal_id

    def test_cross_verification_failure_audited(self):
        """Cross-verification failure is recorded in audit trail with error code."""
        ca, cert, store = _make_ca_and_cert()
        verdict = _make_allow_verdict(agent_id=cert.agent_id)
        context = _make_context(agent_id=cert.agent_id)

        seal = seal_action(verdict, context, ca._signing_key, certificate=cert)
        assert seal is not None

        # Suspend the certificate
        ca.suspend(cert.certificate_id, "audit test")

        trail = AuditTrail()
        result = verify_seal(seal, ca._verify_key, cert_store=store, audit_trail=trail)

        assert result.valid is False

        records = trail.query(limit=10)
        assert len(records) == 1
        record = records[0]
        assert record.context_code == "SEAL.VERIFY_FAIL"
        assert record.severity == "warning"
        assert record.metadata["cross_verify_error"] == "CERT_NOT_ACTIVE"
        assert record.metadata["cert_status"] == "SUSPENDED"

    def test_cert_not_found_audited(self):
        """CERT_NOT_FOUND failure is recorded in audit trail."""
        ca, cert, store = _make_ca_and_cert()
        verdict = _make_allow_verdict(agent_id=cert.agent_id)
        context = _make_context(agent_id=cert.agent_id)

        seal = seal_action(verdict, context, ca._signing_key, certificate=cert)
        assert seal is not None

        empty_store = MemoryCertificateStore()
        trail = AuditTrail()
        result = verify_seal(seal, ca._verify_key, cert_store=empty_store, audit_trail=trail)

        assert result.valid is False
        records = trail.query(limit=10)
        assert len(records) == 1
        assert records[0].metadata["cross_verify_error"] == "CERT_NOT_FOUND"

    def test_fingerprint_mismatch_audited(self):
        """CERT_FINGERPRINT_MISMATCH is recorded in audit trail."""
        ca, cert, store = _make_ca_and_cert()
        verdict = _make_allow_verdict(agent_id=cert.agent_id)
        context = _make_context(agent_id=cert.agent_id)

        seal = seal_action(verdict, context, ca._signing_key, certificate=cert)
        assert seal is not None

        # Tamper with stored cert fingerprint
        stored_cert = store.get(cert.certificate_id)
        stored_cert.fingerprint = "SHA256:tampered"
        store.update(stored_cert)

        trail = AuditTrail()
        result = verify_seal(seal, ca._verify_key, cert_store=store, audit_trail=trail)

        assert result.valid is False
        records = trail.query(limit=10)
        assert len(records) == 1
        assert records[0].metadata["cross_verify_error"] == "CERT_FINGERPRINT_MISMATCH"

    def test_legacy_seal_verification_audited(self):
        """Legacy seal verification (no cert binding) is audited."""
        sk, vk = _make_signing_key()
        verdict = _make_allow_verdict()
        context = _make_context()

        seal = seal_action(verdict, context, sk)
        trail = AuditTrail()

        result = verify_seal(seal, vk, audit_trail=trail)

        assert result.valid is True
        records = trail.query(limit=10)
        assert len(records) == 1
        assert records[0].context_code == "SEAL.VERIFY_OK"
        assert records[0].metadata["cert_verified"] is False


# ── Integration Tests ─────────────────────────────────────────────────


class TestCrossVerificationIntegration:
    """Full-flow integration tests: birth → evaluate → seal → validate."""

    def test_full_flow_birth_to_validation(self):
        """Full flow: birth certificate → seal issuance → seal validation."""
        from nomotic.runtime import GovernanceRuntime

        runtime = GovernanceRuntime()
        agent_id = "integration-agent"

        # Step 1: Birth
        cert = runtime.birth(
            agent_id=agent_id,
            archetype="general",
            organization="test-org",
            zone_path="global",
            owner="test-owner",
        )
        assert cert.status == CertStatus.ACTIVE

        # Step 2: Evaluate
        trust_profile = runtime.get_trust_profile(agent_id)
        context = AgentContext(agent_id=agent_id, trust_profile=trust_profile)
        action = Action(agent_id=agent_id, action_type="read", target="test-db")
        verdict = runtime.evaluate(action, context)

        if verdict.verdict != Verdict.ALLOW:
            pytest.skip("Verdict was not ALLOW for this test configuration")

        # Step 3: Seal with certificate
        seal = runtime.seal(verdict, context, certificate=cert)
        assert seal is not None
        assert seal.cert_id == cert.certificate_id
        assert seal.cert_fingerprint == cert.fingerprint

        # Step 4: Validate with cross-verification
        ca = runtime._ensure_ca()
        result = verify_seal(seal, ca._verify_key, cert_store=ca._store)

        assert result.valid is True
        assert result.cert_verified is True
        assert result.cert_status == "ACTIVE"

    def test_revoke_after_seal_fails_validation(self):
        """Revoke agent after seal issuance → validation fails."""
        from nomotic.runtime import GovernanceRuntime

        runtime = GovernanceRuntime()
        agent_id = "revoke-test-agent"

        cert = runtime.birth(
            agent_id=agent_id,
            archetype="general",
            organization="test-org",
            zone_path="global",
            owner="test-owner",
        )

        trust_profile = runtime.get_trust_profile(agent_id)
        context = AgentContext(agent_id=agent_id, trust_profile=trust_profile)
        action = Action(agent_id=agent_id, action_type="read", target="test")
        verdict = runtime.evaluate(action, context)

        if verdict.verdict != Verdict.ALLOW:
            pytest.skip("Verdict was not ALLOW for this test configuration")

        seal = runtime.seal(verdict, context, certificate=cert)
        assert seal is not None

        # Revoke the certificate AFTER seal issuance
        ca = runtime._ensure_ca()
        ca.revoke(cert.certificate_id, "post-seal revocation")

        # Validation should fail
        result = verify_seal(seal, ca._verify_key, cert_store=ca._store)
        assert result.valid is False
        assert result.cross_verify_error == "CERT_NOT_ACTIVE"
        assert result.cert_status == "REVOKED"

    def test_suspend_after_seal_fails_validation(self):
        """Suspend agent after seal issuance → validation fails."""
        from nomotic.runtime import GovernanceRuntime

        runtime = GovernanceRuntime()
        agent_id = "suspend-test-agent"

        cert = runtime.birth(
            agent_id=agent_id,
            archetype="general",
            organization="test-org",
            zone_path="global",
            owner="test-owner",
        )

        trust_profile = runtime.get_trust_profile(agent_id)
        context = AgentContext(agent_id=agent_id, trust_profile=trust_profile)
        action = Action(agent_id=agent_id, action_type="read", target="test")
        verdict = runtime.evaluate(action, context)

        if verdict.verdict != Verdict.ALLOW:
            pytest.skip("Verdict was not ALLOW for this test configuration")

        seal = runtime.seal(verdict, context, certificate=cert)
        assert seal is not None

        # Suspend the certificate AFTER seal issuance
        ca = runtime._ensure_ca()
        ca.suspend(cert.certificate_id, "post-seal suspension")

        # Validation should fail
        result = verify_seal(seal, ca._verify_key, cert_store=ca._store)
        assert result.valid is False
        assert result.cross_verify_error == "CERT_NOT_ACTIVE"
        assert result.cert_status == "SUSPENDED"


# ── Serialization Backward Compatibility ──────────────────────────────


class TestSerializationCompat:
    """Tests that seals with cert binding serialize/deserialize correctly."""

    def test_to_dict_includes_cert_fields(self):
        """to_dict includes cert_id and cert_fingerprint."""
        ca, cert, store = _make_ca_and_cert()
        verdict = _make_allow_verdict(agent_id=cert.agent_id)
        context = _make_context(agent_id=cert.agent_id)

        seal = seal_action(verdict, context, ca._signing_key, certificate=cert)
        d = seal.to_dict()

        assert d["cert_id"] == cert.certificate_id
        assert d["cert_fingerprint"] == cert.fingerprint

    def test_from_dict_restores_cert_fields(self):
        """from_dict restores cert_id and cert_fingerprint."""
        ca, cert, store = _make_ca_and_cert()
        verdict = _make_allow_verdict(agent_id=cert.agent_id)
        context = _make_context(agent_id=cert.agent_id)

        seal = seal_action(verdict, context, ca._signing_key, certificate=cert)
        d = seal.to_dict()
        restored = GovernanceSeal.from_dict(d)

        assert restored.cert_id == cert.certificate_id
        assert restored.cert_fingerprint == cert.fingerprint
        assert restored.verify(ca._verify_key) is True

    def test_from_dict_without_cert_fields_defaults_empty(self):
        """from_dict without cert fields defaults to empty strings (legacy compat)."""
        sk, vk = _make_signing_key()
        verdict = _make_allow_verdict()
        context = _make_context()

        seal = seal_action(verdict, context, sk)
        d = seal.to_dict()
        # Simulate legacy dict without cert fields
        del d["cert_id"]
        del d["cert_fingerprint"]

        restored = GovernanceSeal.from_dict(d)
        assert restored.cert_id == ""
        assert restored.cert_fingerprint == ""
        assert restored.verify(vk) is True

    def test_compact_roundtrip_with_cert_binding(self):
        """to_compact/from_compact preserves cert binding fields."""
        ca, cert, store = _make_ca_and_cert()
        verdict = _make_allow_verdict(agent_id=cert.agent_id)
        context = _make_context(agent_id=cert.agent_id)

        seal = seal_action(verdict, context, ca._signing_key, certificate=cert)
        compact = seal.to_compact()
        restored = GovernanceSeal.from_compact(compact)

        assert restored.cert_id == cert.certificate_id
        assert restored.cert_fingerprint == cert.fingerprint
        assert restored.verify(ca._verify_key) is True


# ── CertificateStatusError Tests ──────────────────────────────────────


class TestCertificateStatusError:
    """Tests for CertificateStatusError exception."""

    def test_error_message_format(self):
        err = CertificateStatusError("agent-1", CertStatus.SUSPENDED)
        assert "agent-1" in str(err)
        assert "SUSPENDED" in str(err)
        assert "not ACTIVE" in str(err)

    def test_error_attributes(self):
        err = CertificateStatusError("agent-2", CertStatus.REVOKED)
        assert err.agent_id == "agent-2"
        assert err.status == CertStatus.REVOKED

    def test_is_exception(self):
        err = CertificateStatusError("agent-3", CertStatus.SUSPENDED)
        assert isinstance(err, Exception)

    def test_importable_from_init(self):
        """CertificateStatusError is importable from nomotic package."""
        from nomotic import CertificateStatusError as CSE
        assert CSE is CertificateStatusError


# ── SealVerificationResult Tests ──────────────────────────────────────


class TestSealVerificationResult:
    """Tests for SealVerificationResult dataclass."""

    def test_defaults(self):
        """All optional fields have sensible defaults."""
        result = SealVerificationResult(valid=True)
        assert result.valid is True
        assert result.expired is False
        assert result.error == ""
        assert result.cert_verified is False
        assert result.cert_id is None
        assert result.cert_fingerprint is None
        assert result.cert_status is None
        assert result.cross_verify_error is None

    def test_importable_from_init(self):
        """SealVerificationResult is importable from nomotic package."""
        from nomotic import SealVerificationResult as SVR
        assert SVR is SealVerificationResult

    def test_verify_seal_importable_from_init(self):
        """verify_seal is importable from nomotic package."""
        from nomotic import verify_seal as vs
        assert vs is verify_seal
