"""Tests for DelegationChainVisualizer and delegation CLI subcommands."""

import pytest

from nomotic.authority import CertificateAuthority
from nomotic.delegation import (
    DelegationChainVisualizer,
    DelegationDepthConfig,
    DelegationTracker,
)
from nomotic.keys import SigningKey
from nomotic.store import MemoryCertificateStore


# ── Helpers ────────────────────────────────────────────────────────────


def _ca_with_agents(
    *names: str,
    archetype: str = "specialist",
) -> tuple[CertificateAuthority, MemoryCertificateStore]:
    """Create a CA and issue certificates with the given archetype."""
    sk, _vk = SigningKey.generate()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)
    for name in names:
        ca.issue(name, archetype, "acme", "global/us")
    return ca, store


def _tracker_with_chain(
    *agent_names: str,
    cert_store=None,
    depth_config: DelegationDepthConfig | None = None,
) -> DelegationTracker:
    """Create a tracker with a linear delegation chain A→B→C→..."""
    config = depth_config or DelegationDepthConfig(enforce_at_delegation=False)
    tracker = DelegationTracker(cert_store=cert_store, depth_config=config)
    for i in range(len(agent_names) - 1):
        tracker.delegate(agent_names[i], agent_names[i + 1], {"read"}, {"*"})
    return tracker


# ── TestDelegationChainVisualizer (build_tree) ─────────────────────────


class TestDelegationChainVisualizer:
    def test_build_tree_single_agent_no_children(self):
        tracker = DelegationTracker(depth_config=DelegationDepthConfig(enforce_at_delegation=False))
        viz = DelegationChainVisualizer(tracker=tracker)
        tree = viz.build_tree("root-agent")
        assert tree["agent_id"] == "root-agent"
        assert tree["depth"] == 0
        assert tree["children"] == []

    def test_build_tree_with_one_child(self):
        tracker = _tracker_with_chain("root", "child-a")
        viz = DelegationChainVisualizer(tracker=tracker)
        tree = viz.build_tree("root")
        assert tree["agent_id"] == "root"
        assert len(tree["children"]) == 1
        assert tree["children"][0]["agent_id"] == "child-a"

    def test_build_tree_multi_level_three_deep(self):
        tracker = _tracker_with_chain("root", "mid", "leaf")
        viz = DelegationChainVisualizer(tracker=tracker)
        tree = viz.build_tree("root")
        assert tree["depth"] == 0
        mid = tree["children"][0]
        assert mid["agent_id"] == "mid"
        assert mid["depth"] == 1
        leaf = mid["children"][0]
        assert leaf["agent_id"] == "leaf"
        assert leaf["depth"] == 2

    def test_build_tree_depth_field_correct(self):
        tracker = _tracker_with_chain("A", "B", "C", "D")
        viz = DelegationChainVisualizer(tracker=tracker)
        tree = viz.build_tree("A")
        # Walk the chain: A(0) → B(1) → C(2) → D(3)
        node = tree
        for expected_depth in range(4):
            assert node["depth"] == expected_depth
            if node["children"]:
                node = node["children"][0]

    def test_build_tree_exceeds_limit_flagged(self):
        # Default '*' limit is 3, so depth=4 exceeds it
        tracker = _tracker_with_chain("A", "B", "C", "D", "E")
        viz = DelegationChainVisualizer(tracker=tracker)
        tree = viz.build_tree("A")
        # Walk to E at depth 4
        node = tree
        for _ in range(4):
            node = node["children"][0]
        assert node["agent_id"] == "E"
        assert node["depth"] == 4
        assert node["exceeds_limit"] is True

    def test_build_tree_within_limit_not_flagged(self):
        tracker = _tracker_with_chain("A", "B")
        viz = DelegationChainVisualizer(tracker=tracker)
        tree = viz.build_tree("A")
        child = tree["children"][0]
        assert child["exceeds_limit"] is False

    def test_build_tree_archetype_from_cert_store(self):
        _, store = _ca_with_agents("root", "child", archetype="executor")
        tracker = _tracker_with_chain("root", "child", cert_store=store)
        viz = DelegationChainVisualizer(tracker=tracker, cert_store=store)
        tree = viz.build_tree("root")
        assert tree["archetype"] == "executor"
        assert tree["children"][0]["archetype"] == "executor"


# ── TestAsciiRendering ─────────────────────────────────────────────────


class TestAsciiRendering:
    def test_render_ascii_single_agent(self):
        tracker = DelegationTracker(depth_config=DelegationDepthConfig(enforce_at_delegation=False))
        viz = DelegationChainVisualizer(tracker=tracker)
        output = viz.render_ascii("solo-agent", show_depth_limits=False)
        assert "*: solo-agent (depth=0)" in output

    def test_render_ascii_last_child_uses_corner_branch(self):
        tracker = _tracker_with_chain("root", "only-child")
        viz = DelegationChainVisualizer(tracker=tracker)
        output = viz.render_ascii("root", show_depth_limits=False)
        assert "└── *: only-child (depth=1)" in output

    def test_render_ascii_non_last_child_uses_tee_branch(self):
        config = DelegationDepthConfig(enforce_at_delegation=False)
        tracker = DelegationTracker(depth_config=config)
        tracker.delegate("root", "child-a", {"read"}, {"*"})
        tracker.delegate("root", "child-b", {"read"}, {"*"})
        viz = DelegationChainVisualizer(tracker=tracker)
        output = viz.render_ascii("root", show_depth_limits=False)
        assert "├── " in output

    def test_render_ascii_continuation_line_under_tee(self):
        config = DelegationDepthConfig(enforce_at_delegation=False)
        tracker = DelegationTracker(depth_config=config)
        tracker.delegate("root", "child-a", {"read"}, {"*"})
        tracker.delegate("root", "child-b", {"read"}, {"*"})
        tracker.delegate("child-a", "grandchild", {"read"}, {"*"})
        viz = DelegationChainVisualizer(tracker=tracker)
        output = viz.render_ascii("root", show_depth_limits=False)
        # Under ├── child-a there should be a │ continuation line
        assert "│   " in output

    def test_render_ascii_violation_appended(self):
        # '*' limit=3, so depth 4 exceeds
        tracker = _tracker_with_chain("A", "B", "C", "D", "E")
        viz = DelegationChainVisualizer(tracker=tracker)
        output = viz.render_ascii("A", show_depth_limits=False)
        assert "⚠ LIMIT EXCEEDED" in output

    def test_render_ascii_depth_limits_footer_when_flag_set(self):
        tracker = _tracker_with_chain("root", "child")
        viz = DelegationChainVisualizer(tracker=tracker)
        output = viz.render_ascii("root", show_depth_limits=True)
        assert "Depth limits (" in output
        assert "*=3" in output

    def test_render_ascii_no_footer_when_flag_unset(self):
        tracker = _tracker_with_chain("root", "child")
        viz = DelegationChainVisualizer(tracker=tracker)
        output = viz.render_ascii("root", show_depth_limits=False)
        assert "Depth limits" not in output


# ── TestDotRendering ───────────────────────────────────────────────────


class TestDotRendering:
    def test_render_dot_contains_agent_ids(self):
        tracker = _tracker_with_chain("root-agent", "child-agent")
        viz = DelegationChainVisualizer(tracker=tracker)
        dot = viz.render_dot("root-agent")
        assert "root_agent" in dot
        assert "child_agent" in dot

    def test_render_dot_is_valid_digraph_header(self):
        tracker = _tracker_with_chain("A", "B")
        viz = DelegationChainVisualizer(tracker=tracker)
        dot = viz.render_dot("A")
        assert dot.startswith("digraph DelegationChain {")
        assert "rankdir=TB;" in dot
        assert dot.strip().endswith("}")

    def test_render_dot_violation_node_has_red_fill(self):
        # '*' limit=3, depth 4 exceeds
        tracker = _tracker_with_chain("A", "B", "C", "D", "E")
        viz = DelegationChainVisualizer(tracker=tracker)
        dot = viz.render_dot("A")
        assert "fillcolor=red" in dot

    def test_render_dot_at_limit_has_orange_fill(self):
        # '*' limit=3, depth 3 is at limit
        tracker = _tracker_with_chain("A", "B", "C", "D")
        viz = DelegationChainVisualizer(tracker=tracker)
        dot = viz.render_dot("A")
        assert "fillcolor=orange" in dot

    def test_render_dot_within_limit_has_green_fill(self):
        tracker = _tracker_with_chain("A", "B")
        viz = DelegationChainVisualizer(tracker=tracker)
        dot = viz.render_dot("A")
        assert "fillcolor=palegreen" in dot

    def test_render_dot_edge_label(self):
        tracker = _tracker_with_chain("A", "B")
        viz = DelegationChainVisualizer(tracker=tracker)
        dot = viz.render_dot("A")
        assert '[label="delegates"]' in dot


# ── TestFindViolations ─────────────────────────────────────────────────


class TestFindViolations:
    def test_find_violations_empty_when_all_within_limits(self):
        tracker = _tracker_with_chain("A", "B", "C")
        viz = DelegationChainVisualizer(tracker=tracker)
        violations = viz.find_violations("A")
        assert violations == []

    def test_find_violations_single_violation(self):
        # '*' limit=3, depth 4 exceeds
        tracker = _tracker_with_chain("A", "B", "C", "D", "E")
        viz = DelegationChainVisualizer(tracker=tracker)
        violations = viz.find_violations("A")
        assert len(violations) == 1
        assert violations[0]["agent_id"] == "E"
        assert violations[0]["depth"] == 4
        assert violations[0]["limit"] == 3

    def test_find_violations_excess_computed_correctly(self):
        tracker = _tracker_with_chain("A", "B", "C", "D", "E")
        viz = DelegationChainVisualizer(tracker=tracker)
        violations = viz.find_violations("A")
        assert violations[0]["excess"] == 1

    def test_find_violations_multiple_violations(self):
        # '*' limit=3, depths 4 and 5 both exceed
        tracker = _tracker_with_chain("A", "B", "C", "D", "E", "F")
        viz = DelegationChainVisualizer(tracker=tracker)
        violations = viz.find_violations("A")
        assert len(violations) == 2
        ids = {v["agent_id"] for v in violations}
        assert "E" in ids
        assert "F" in ids

    def test_find_violations_custom_config(self):
        config = DelegationDepthConfig(max_depths={"*": 1}, enforce_at_delegation=False)
        tracker = _tracker_with_chain("A", "B", "C", depth_config=config)
        viz = DelegationChainVisualizer(tracker=tracker, depth_config=config)
        violations = viz.find_violations("A")
        assert len(violations) == 1
        assert violations[0]["agent_id"] == "C"
        assert violations[0]["limit"] == 1
        assert violations[0]["depth"] == 2


# ── TestCLI ────────────────────────────────────────────────────────────


class TestCLI:
    def test_cli_visualize_ascii_runs(self, capsys):
        from nomotic.cli import main

        # No delegation data means root-only tree — should not crash
        try:
            main(["delegation", "visualize", "test-agent"])
        except SystemExit as e:
            assert e.code is None or e.code == 0

    def test_cli_visualize_ascii_produces_output(self, capsys):
        from nomotic.cli import main

        try:
            main(["delegation", "visualize", "test-agent"])
        except SystemExit:
            pass
        captured = capsys.readouterr()
        assert "test-agent" in captured.out

    def test_cli_violations_no_violations_message(self, capsys):
        from nomotic.cli import main

        try:
            main(["delegation", "violations", "test-agent"])
        except SystemExit:
            pass
        captured = capsys.readouterr()
        assert "no violations" in captured.out

    def test_cli_delegation_no_subcommand_exits(self, capsys):
        from nomotic.cli import main

        with pytest.raises(SystemExit):
            main(["delegation"])
