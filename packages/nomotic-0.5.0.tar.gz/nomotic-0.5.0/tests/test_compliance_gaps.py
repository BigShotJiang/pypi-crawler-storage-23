"""Tests for the compliance gap analysis module."""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from nomotic.compliance_report import (
    ComplianceReportGenerator,
    ControlMapping,
    FRAMEWORK_MAPPINGS,
    FrameworkMapping,
)
from nomotic.gap_analysis import (
    ComplianceGapAnalyzer,
    ComplianceGapReport,
    ControlGap,
)


# ── Helpers ─────────────────────────────────────────────────────────────


@dataclass
class _FakeRecord:
    """Minimal audit record for testing."""

    timestamp: float = 0.0
    agent_id: str = "test-agent"
    dimension_scores: dict[str, float] = field(default_factory=dict)


class _FakeAuditStore:
    """In-memory audit store for tests."""

    def __init__(self, records: dict[str, list[_FakeRecord]] | None = None):
        self._records = records or {}

    def query_all(self, agent_id: str) -> list[_FakeRecord]:
        return self._records.get(agent_id, [])

    def list_agents(self) -> list[str]:
        return list(self._records.keys())


def _make_framework(
    controls: list[ControlMapping] | None = None,
    framework_id: str = "test-fw",
    framework_name: str = "Test Framework",
) -> FrameworkMapping:
    """Create a simple test framework."""
    if controls is None:
        controls = [
            ControlMapping(
                "CTRL-1", "Control One", "First test control",
                ["scope_compliance", "authority_verification"], "full",
                "Test notes for control one.",
            ),
            ControlMapping(
                "CTRL-2", "Control Two", "Second test control",
                ["ethical_alignment"], "partial",
                "Test notes for control two.",
            ),
            ControlMapping(
                "CTRL-3", "Control Three", "Third test control",
                ["transparency", "human_override"], "full",
                "Test notes for control three.",
            ),
        ]
    return FrameworkMapping(
        framework_id=framework_id,
        framework_name=framework_name,
        version="1.0",
        controls=controls,
    )


def _make_analyzer(
    framework: FrameworkMapping | None = None,
    records: dict[str, list[_FakeRecord]] | None = None,
) -> ComplianceGapAnalyzer:
    """Create an analyzer with a custom framework and fake audit data."""
    fw = framework or _make_framework()
    generator = ComplianceReportGenerator()
    generator.register_custom_framework(fw)
    store = _FakeAuditStore(records)
    return ComplianceGapAnalyzer(generator, store)


# ── TestControlGap ──────────────────────────────────────────────────────


class TestControlGap:
    def test_to_dict_roundtrip(self) -> None:
        gap = ControlGap(
            framework_id="gdpr",
            control_id="Art5-1a",
            control_description="Lawfulness of processing",
            nomotic_dimensions=["ethical_alignment"],
            coverage="full",
            average_dimension_score=0.24,
            score_threshold=0.70,
            is_gap=True,
            gap_severity="critical",
            sample_size=247,
            recommendation="Increase ethical_alignment weight.",
        )
        d = gap.to_dict()
        assert isinstance(d, dict)
        assert d["framework_id"] == "gdpr"
        assert d["control_id"] == "Art5-1a"
        assert d["average_dimension_score"] == 0.24
        assert d["is_gap"] is True
        assert d["gap_severity"] == "critical"
        assert d["sample_size"] == 247
        # Verify JSON-serializable
        json.dumps(d)

    def test_is_gap_below_threshold(self) -> None:
        gap = ControlGap(
            framework_id="test",
            control_id="C1",
            control_description="Test",
            nomotic_dimensions=["scope_compliance"],
            coverage="full",
            average_dimension_score=0.5,
            score_threshold=0.7,
            is_gap=True,
            gap_severity="medium",
            sample_size=10,
            recommendation="Fix it.",
        )
        assert gap.is_gap is True
        assert gap.average_dimension_score < gap.score_threshold

    def test_is_gap_above_threshold(self) -> None:
        gap = ControlGap(
            framework_id="test",
            control_id="C2",
            control_description="Test",
            nomotic_dimensions=["scope_compliance"],
            coverage="full",
            average_dimension_score=0.85,
            score_threshold=0.7,
            is_gap=False,
            gap_severity="low",
            sample_size=10,
            recommendation="All good.",
        )
        assert gap.is_gap is False
        assert gap.average_dimension_score >= gap.score_threshold


# ── TestComplianceGapAnalyzer ───────────────────────────────────────────


class TestComplianceGapAnalyzer:
    def test_analyze_returns_report(self) -> None:
        now = time.time()
        records = {
            "agent-a": [
                _FakeRecord(
                    timestamp=now - 100,
                    agent_id="agent-a",
                    dimension_scores={
                        "scope_compliance": 0.9,
                        "authority_verification": 0.8,
                        "ethical_alignment": 0.6,
                        "transparency": 0.95,
                        "human_override": 0.85,
                    },
                ),
            ],
        }
        analyzer = _make_analyzer(records=records)
        report = analyzer.analyze("test-fw")
        assert isinstance(report, ComplianceGapReport)
        assert report.framework_id == "test-fw"
        assert report.total_controls == 3

    def test_gap_detected_when_score_below_threshold(self) -> None:
        now = time.time()
        records = {
            "agent-a": [
                _FakeRecord(
                    timestamp=now - 100,
                    agent_id="agent-a",
                    dimension_scores={
                        "scope_compliance": 0.9,
                        "authority_verification": 0.8,
                        "ethical_alignment": 0.2,  # Below 0.7
                        "transparency": 0.95,
                        "human_override": 0.85,
                    },
                ),
            ],
        }
        analyzer = _make_analyzer(records=records)
        report = analyzer.analyze("test-fw", gap_threshold=0.7)

        # CTRL-2 maps to ethical_alignment (0.2) — should be a gap
        all_gaps = report.critical_gaps + report.high_gaps + report.medium_gaps + report.low_gaps
        gap_ids = [g.control_id for g in all_gaps]
        assert "CTRL-2" in gap_ids

    def test_no_gap_when_score_above_threshold(self) -> None:
        now = time.time()
        records = {
            "agent-a": [
                _FakeRecord(
                    timestamp=now - 100,
                    agent_id="agent-a",
                    dimension_scores={
                        "scope_compliance": 0.9,
                        "authority_verification": 0.8,
                        "ethical_alignment": 0.85,
                        "transparency": 0.95,
                        "human_override": 0.85,
                    },
                ),
            ],
        }
        analyzer = _make_analyzer(records=records)
        report = analyzer.analyze("test-fw", gap_threshold=0.7)

        # All scores above threshold — no gaps
        assert report.controls_with_gaps == 0
        assert len(report.clean_controls) == 3

    def test_severity_critical_below_0_3(self) -> None:
        analyzer = _make_analyzer()
        assert analyzer._classify_severity(0.1, 0.7) == "critical"
        assert analyzer._classify_severity(0.0, 0.7) == "critical"
        assert analyzer._classify_severity(0.29, 0.7) == "critical"

    def test_severity_high_0_3_to_0_5(self) -> None:
        analyzer = _make_analyzer()
        assert analyzer._classify_severity(0.3, 0.7) == "high"
        assert analyzer._classify_severity(0.4, 0.7) == "high"
        assert analyzer._classify_severity(0.49, 0.7) == "high"

    def test_severity_medium_0_5_to_threshold(self) -> None:
        analyzer = _make_analyzer()
        assert analyzer._classify_severity(0.5, 0.7) == "medium"
        assert analyzer._classify_severity(0.6, 0.7) == "medium"
        assert analyzer._classify_severity(0.69, 0.7) == "medium"

    def test_severity_low_above_threshold(self) -> None:
        analyzer = _make_analyzer()
        assert analyzer._classify_severity(0.7, 0.7) == "low"
        assert analyzer._classify_severity(0.9, 0.7) == "low"

    def test_custom_threshold_changes_gap_detection(self) -> None:
        now = time.time()
        records = {
            "agent-a": [
                _FakeRecord(
                    timestamp=now - 100,
                    agent_id="agent-a",
                    dimension_scores={
                        "scope_compliance": 0.6,
                        "authority_verification": 0.6,
                        "ethical_alignment": 0.6,
                        "transparency": 0.6,
                        "human_override": 0.6,
                    },
                ),
            ],
        }
        analyzer = _make_analyzer(records=records)

        # With 0.7 threshold: 0.6 is below → gaps
        report_high = analyzer.analyze("test-fw", gap_threshold=0.7)
        assert report_high.controls_with_gaps > 0

        # With 0.5 threshold: 0.6 is above → no gaps
        report_low = analyzer.analyze("test-fw", gap_threshold=0.5)
        assert report_low.controls_with_gaps == 0

    def test_agent_filter_applied(self) -> None:
        now = time.time()
        records = {
            "agent-a": [
                _FakeRecord(
                    timestamp=now - 100,
                    agent_id="agent-a",
                    dimension_scores={"scope_compliance": 0.9, "authority_verification": 0.9,
                                      "ethical_alignment": 0.9, "transparency": 0.9,
                                      "human_override": 0.9},
                ),
            ],
            "agent-b": [
                _FakeRecord(
                    timestamp=now - 100,
                    agent_id="agent-b",
                    dimension_scores={"scope_compliance": 0.1, "authority_verification": 0.1,
                                      "ethical_alignment": 0.1, "transparency": 0.1,
                                      "human_override": 0.1},
                ),
            ],
        }
        analyzer = _make_analyzer(records=records)

        # Agent-a has high scores → no gaps
        report_a = analyzer.analyze("test-fw", agent_id="agent-a")
        assert report_a.controls_with_gaps == 0

        # Agent-b has low scores → all gaps
        report_b = analyzer.analyze("test-fw", agent_id="agent-b")
        assert report_b.controls_with_gaps == 3

    def test_days_filter_applied(self) -> None:
        now = time.time()
        records = {
            "agent-a": [
                # Old record — outside 7-day window
                _FakeRecord(
                    timestamp=now - 86400 * 60,
                    agent_id="agent-a",
                    dimension_scores={"scope_compliance": 0.1, "authority_verification": 0.1,
                                      "ethical_alignment": 0.1, "transparency": 0.1,
                                      "human_override": 0.1},
                ),
                # Recent record — within 7-day window
                _FakeRecord(
                    timestamp=now - 100,
                    agent_id="agent-a",
                    dimension_scores={"scope_compliance": 0.9, "authority_verification": 0.9,
                                      "ethical_alignment": 0.9, "transparency": 0.9,
                                      "human_override": 0.9},
                ),
            ],
        }
        analyzer = _make_analyzer(records=records)

        # 7-day window → only recent record (high scores, no gaps)
        report = analyzer.analyze("test-fw", days=7)
        assert report.controls_with_gaps == 0

    def test_recommendation_populated_for_known_dimensions(self) -> None:
        analyzer = _make_analyzer()
        rec = analyzer._get_recommendation(["ethical_alignment"])
        assert "ethical_alignment" in rec
        assert len(rec) > 20

    def test_recommendation_fallback_for_unknown_dimensions(self) -> None:
        analyzer = _make_analyzer()
        rec = analyzer._get_recommendation(["nonexistent_dim"])
        assert "nonexistent_dim" in rec

    def test_unknown_framework_raises(self) -> None:
        analyzer = _make_analyzer()
        with pytest.raises(ValueError, match="Unknown framework"):
            analyzer.analyze("nonexistent-framework")

    def test_empty_audit_store_returns_all_gaps(self) -> None:
        """With no audit data, all dimension averages are 0.0 → all gaps."""
        analyzer = _make_analyzer(records={})
        report = analyzer.analyze("test-fw")
        assert report.controls_with_gaps == 3
        assert report.total_controls == 3

    def test_multiple_records_averaged(self) -> None:
        """Multiple records should be averaged, not summed or last-wins."""
        now = time.time()
        records = {
            "agent-a": [
                _FakeRecord(
                    timestamp=now - 200,
                    agent_id="agent-a",
                    dimension_scores={"ethical_alignment": 0.4},
                ),
                _FakeRecord(
                    timestamp=now - 100,
                    agent_id="agent-a",
                    dimension_scores={"ethical_alignment": 0.8},
                ),
            ],
        }
        # Average = 0.6, which is below 0.7 threshold
        analyzer = _make_analyzer(records=records)
        report = analyzer.analyze("test-fw", gap_threshold=0.7)
        # CTRL-2 maps to ethical_alignment only
        all_gaps = report.critical_gaps + report.high_gaps + report.medium_gaps + report.low_gaps
        ctrl2_gaps = [g for g in all_gaps if g.control_id == "CTRL-2"]
        assert len(ctrl2_gaps) == 1
        assert abs(ctrl2_gaps[0].average_dimension_score - 0.6) < 0.01


# ── TestComplianceGapReport ─────────────────────────────────────────────


class TestComplianceGapReport:
    def test_coverage_percent_calculated(self) -> None:
        now = time.time()
        records = {
            "agent-a": [
                _FakeRecord(
                    timestamp=now - 100,
                    agent_id="agent-a",
                    dimension_scores={
                        "scope_compliance": 0.9,
                        "authority_verification": 0.8,
                        "ethical_alignment": 0.2,  # Gap
                        "transparency": 0.95,
                        "human_override": 0.85,
                    },
                ),
            ],
        }
        analyzer = _make_analyzer(records=records)
        report = analyzer.analyze("test-fw", gap_threshold=0.7)

        # 2 clean controls out of 3 = 66.7%
        assert 60.0 < report.coverage_percent < 70.0

    def test_summary_string_contains_framework_name(self) -> None:
        report = ComplianceGapReport(
            framework_id="gdpr",
            framework_name="GDPR",
            generated_at=time.time(),
            period_days=30,
            agent_id=None,
            gap_threshold=0.7,
            total_controls=9,
            controls_with_gaps=3,
            coverage_percent=66.7,
            critical_gaps=[
                ControlGap("gdpr", "Art5-1a", "Lawfulness", ["ethical_alignment"],
                           "full", 0.24, 0.7, True, "critical", 247, "Fix it"),
            ],
            high_gaps=[],
            medium_gaps=[],
            low_gaps=[],
            clean_controls=[],
        )
        summary = report.summary()
        assert "GDPR" in summary
        assert "30 days" in summary

    def test_summary_no_gaps(self) -> None:
        report = ComplianceGapReport(
            framework_id="test",
            framework_name="Test FW",
            generated_at=time.time(),
            period_days=7,
            agent_id="my-agent",
            gap_threshold=0.7,
            total_controls=5,
            controls_with_gaps=0,
            coverage_percent=100.0,
            critical_gaps=[],
            high_gaps=[],
            medium_gaps=[],
            low_gaps=[],
            clean_controls=[],
        )
        summary = report.summary()
        assert "No gaps detected" in summary
        assert "my-agent" in summary

    def test_critical_gaps_list_populated_correctly(self) -> None:
        now = time.time()
        records = {
            "agent-a": [
                _FakeRecord(
                    timestamp=now - 100,
                    agent_id="agent-a",
                    dimension_scores={
                        "scope_compliance": 0.9,
                        "authority_verification": 0.8,
                        "ethical_alignment": 0.1,  # Critical
                        "transparency": 0.95,
                        "human_override": 0.85,
                    },
                ),
            ],
        }
        analyzer = _make_analyzer(records=records)
        report = analyzer.analyze("test-fw", gap_threshold=0.7)

        assert len(report.critical_gaps) == 1
        assert report.critical_gaps[0].control_id == "CTRL-2"
        assert report.critical_gaps[0].gap_severity == "critical"

    def test_to_dict_serializable(self) -> None:
        report = ComplianceGapReport(
            framework_id="test",
            framework_name="Test",
            generated_at=time.time(),
            period_days=30,
            agent_id=None,
            gap_threshold=0.7,
            total_controls=0,
            controls_with_gaps=0,
            coverage_percent=100.0,
        )
        d = report.to_dict()
        assert isinstance(d, dict)
        # Verify JSON-serializable
        serialized = json.dumps(d)
        assert "test" in serialized


# ── TestCLI ─────────────────────────────────────────────────────────────


class TestCLI:
    def _run_cli(
        self,
        capsys: pytest.CaptureFixture[str],
        records: dict[str, list[_FakeRecord]],
        framework_id: str = "test-fw",
        agent: str | None = None,
        days: int = 30,
        threshold: float = 0.7,
        severity: str | None = None,
    ) -> tuple[str, str]:
        """Helper to invoke _cmd_compliance_gaps with patched dependencies."""
        from nomotic.cli import _cmd_compliance_gaps

        fake_store = _FakeAuditStore(records)
        fw = _make_framework()
        gen = ComplianceReportGenerator()
        gen.register_custom_framework(fw)
        analyzer = ComplianceGapAnalyzer(gen, fake_store)

        args = MagicMock()
        args.framework = framework_id
        args.agent = agent
        args.days = days
        args.threshold = threshold
        args.severity = severity
        args.base_dir = Path("/tmp/nomotic-test-gaps")

        with patch("nomotic.compliance_report.ComplianceReportGenerator", return_value=gen), \
             patch("nomotic.audit_store.LogStore", return_value=fake_store), \
             patch("nomotic.compliance_report.discover_frameworks", return_value={}), \
             patch("nomotic.gap_analysis.ComplianceGapAnalyzer", return_value=analyzer):
            _cmd_compliance_gaps(args)

        return capsys.readouterr()

    def test_cli_gap_analysis_output_format(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Test that the CLI produces expected output structure."""
        from nomotic.cli import _cmd_compliance_gaps

        now = time.time()
        records = {
            "agent-a": [
                _FakeRecord(
                    timestamp=now - 100,
                    agent_id="agent-a",
                    dimension_scores={
                        "scope_compliance": 0.9,
                        "authority_verification": 0.8,
                        "ethical_alignment": 0.2,
                        "transparency": 0.95,
                        "human_override": 0.85,
                    },
                ),
            ],
        }
        fake_store = _FakeAuditStore(records)
        fw = _make_framework()
        gen = ComplianceReportGenerator()
        gen.register_custom_framework(fw)
        analyzer = ComplianceGapAnalyzer(gen, fake_store)

        args = MagicMock()
        args.framework = "test-fw"
        args.agent = None
        args.days = 30
        args.threshold = 0.7
        args.severity = None
        args.base_dir = Path("/tmp/nomotic-test-gaps")

        with patch("nomotic.compliance_report.discover_frameworks", return_value={}):
            # Patch the classes at the source modules so the local imports find them
            with patch("nomotic.audit_store.LogStore", return_value=fake_store), \
                 patch("nomotic.compliance_report.ComplianceReportGenerator", return_value=gen), \
                 patch("nomotic.gap_analysis.ComplianceGapAnalyzer", return_value=analyzer):
                _cmd_compliance_gaps(args)

        captured = capsys.readouterr()
        assert "Compliance Gap Analysis" in captured.out
        assert "Controls analyzed" in captured.out

    def test_cli_severity_filter(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Test that --severity filters the output."""
        from nomotic.cli import _cmd_compliance_gaps

        now = time.time()
        records = {
            "agent-a": [
                _FakeRecord(
                    timestamp=now - 100,
                    agent_id="agent-a",
                    dimension_scores={
                        "scope_compliance": 0.9,
                        "authority_verification": 0.8,
                        "ethical_alignment": 0.1,  # Critical gap
                        "transparency": 0.55,  # Medium gap
                        "human_override": 0.55,  # Medium gap
                    },
                ),
            ],
        }
        fake_store = _FakeAuditStore(records)
        fw = _make_framework()
        gen = ComplianceReportGenerator()
        gen.register_custom_framework(fw)
        analyzer = ComplianceGapAnalyzer(gen, fake_store)

        args = MagicMock()
        args.framework = "test-fw"
        args.agent = None
        args.days = 30
        args.threshold = 0.7
        args.severity = "critical"
        args.base_dir = Path("/tmp/nomotic-test-gaps")

        with patch("nomotic.compliance_report.discover_frameworks", return_value={}), \
             patch("nomotic.audit_store.LogStore", return_value=fake_store), \
             patch("nomotic.compliance_report.ComplianceReportGenerator", return_value=gen), \
             patch("nomotic.gap_analysis.ComplianceGapAnalyzer", return_value=analyzer):
            _cmd_compliance_gaps(args)

        captured = capsys.readouterr()
        assert "CRITICAL" in captured.out
        # Passing controls should NOT appear with severity filter
        assert "PASSING" not in captured.out

    def test_cli_agent_filter(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Test that --agent filters to a specific agent."""
        from nomotic.cli import _cmd_compliance_gaps

        now = time.time()
        records = {
            "claims-bot": [
                _FakeRecord(
                    timestamp=now - 100,
                    agent_id="claims-bot",
                    dimension_scores={
                        "scope_compliance": 0.9,
                        "authority_verification": 0.8,
                        "ethical_alignment": 0.9,
                        "transparency": 0.95,
                        "human_override": 0.85,
                    },
                ),
            ],
        }
        fake_store = _FakeAuditStore(records)
        fw = _make_framework()
        gen = ComplianceReportGenerator()
        gen.register_custom_framework(fw)
        analyzer = ComplianceGapAnalyzer(gen, fake_store)

        args = MagicMock()
        args.framework = "test-fw"
        args.agent = "claims-bot"
        args.days = 30
        args.threshold = 0.7
        args.severity = None
        args.base_dir = Path("/tmp/nomotic-test-gaps")

        with patch("nomotic.compliance_report.discover_frameworks", return_value={}), \
             patch("nomotic.audit_store.LogStore", return_value=fake_store), \
             patch("nomotic.compliance_report.ComplianceReportGenerator", return_value=gen), \
             patch("nomotic.gap_analysis.ComplianceGapAnalyzer", return_value=analyzer), \
             patch("nomotic.cli._resolve_agent", side_effect=SystemExit(1)):
            _cmd_compliance_gaps(args)

        captured = capsys.readouterr()
        assert "claims-bot" in captured.out

    def test_cli_unknown_framework_error_message(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Test that an unknown framework produces a clear error."""
        from nomotic.cli import _cmd_compliance_gaps

        fake_store = _FakeAuditStore({})
        gen = ComplianceReportGenerator()

        args = MagicMock()
        args.framework = "nonexistent-framework"
        args.agent = None
        args.days = 30
        args.threshold = 0.7
        args.severity = None
        args.base_dir = Path("/tmp/nomotic-test-gaps")

        with patch("nomotic.compliance_report.discover_frameworks", return_value={}), \
             patch("nomotic.audit_store.LogStore", return_value=fake_store), \
             patch("nomotic.compliance_report.ComplianceReportGenerator", return_value=gen), \
             pytest.raises(SystemExit):
            _cmd_compliance_gaps(args)

        captured = capsys.readouterr()
        assert "Error" in captured.err


# ── Additional edge-case tests ──────────────────────────────────────────


class TestEdgeCases:
    def test_fleet_wide_aggregates_all_agents(self) -> None:
        """Fleet-wide analysis should aggregate scores from all agents."""
        now = time.time()
        records = {
            "agent-a": [
                _FakeRecord(
                    timestamp=now - 100,
                    agent_id="agent-a",
                    dimension_scores={"ethical_alignment": 0.4},
                ),
            ],
            "agent-b": [
                _FakeRecord(
                    timestamp=now - 100,
                    agent_id="agent-b",
                    dimension_scores={"ethical_alignment": 0.8},
                ),
            ],
        }
        analyzer = _make_analyzer(records=records)
        report = analyzer.analyze("test-fw", agent_id=None)

        # CTRL-2 maps to ethical_alignment; fleet avg = 0.6, below 0.7
        all_gaps = report.critical_gaps + report.high_gaps + report.medium_gaps + report.low_gaps
        ctrl2 = [g for g in all_gaps if g.control_id == "CTRL-2"]
        assert len(ctrl2) == 1
        assert abs(ctrl2[0].average_dimension_score - 0.6) < 0.01

    def test_sample_size_reflects_record_count(self) -> None:
        now = time.time()
        records = {
            "agent-a": [
                _FakeRecord(timestamp=now - 100, agent_id="agent-a",
                            dimension_scores={"scope_compliance": 0.9}),
                _FakeRecord(timestamp=now - 200, agent_id="agent-a",
                            dimension_scores={"scope_compliance": 0.8}),
                _FakeRecord(timestamp=now - 300, agent_id="agent-a",
                            dimension_scores={"scope_compliance": 0.7}),
            ],
        }
        analyzer = _make_analyzer(records=records)
        report = analyzer.analyze("test-fw", agent_id="agent-a")
        # All 3 records within 30-day window
        for gap in report.clean_controls + report.critical_gaps + report.high_gaps + report.medium_gaps:
            assert gap.sample_size == 3

    def test_control_with_no_scored_dimensions_is_gap(self) -> None:
        """If audit records never include a dimension, avg is 0.0 → gap."""
        now = time.time()
        fw = _make_framework(controls=[
            ControlMapping(
                "CTRL-X", "Rare Control", "Uses rare dimension",
                ["stakeholder_impact"], "full", "Notes",
            ),
        ])
        records = {
            "agent-a": [
                _FakeRecord(
                    timestamp=now - 100,
                    agent_id="agent-a",
                    dimension_scores={"scope_compliance": 0.9},  # stakeholder_impact not scored
                ),
            ],
        }
        analyzer = _make_analyzer(framework=fw, records=records)
        report = analyzer.analyze("test-fw")
        assert report.controls_with_gaps == 1

    def test_report_to_dict_has_all_gap_lists(self) -> None:
        report = ComplianceGapReport(
            framework_id="t",
            framework_name="T",
            generated_at=0.0,
            period_days=1,
            agent_id=None,
            gap_threshold=0.7,
            total_controls=0,
            controls_with_gaps=0,
            coverage_percent=100.0,
        )
        d = report.to_dict()
        assert "critical_gaps" in d
        assert "high_gaps" in d
        assert "medium_gaps" in d
        assert "low_gaps" in d
        assert "clean_controls" in d
