"""Tests for governance event webhooks — WebhookConfig, WebhookEvent, WebhookDispatcher."""

from __future__ import annotations

import io
import json
import time
from http.client import HTTPResponse
from unittest import TestCase
from unittest.mock import MagicMock, patch

from nomotic.webhooks import (
    WEBHOOK_EVENT_TYPES,
    WebhookConfig,
    WebhookDispatcher,
    WebhookEvent,
    _RateLimiter,
)


def _make_event(
    event_type: str = "DENY",
    agent_id: str = "agent-1",
    payload: dict | None = None,
) -> WebhookEvent:
    return WebhookEvent(
        event_type=event_type,
        event_id="nme-abc123",
        timestamp=1700000000.0,
        agent_id=agent_id,
        payload=payload or {"action_id": "act-1"},
    )


def _mock_response(status: int = 200) -> MagicMock:
    """Create a mock urllib response as a context manager."""
    resp = MagicMock()
    resp.status = status
    resp.__enter__ = MagicMock(return_value=resp)
    resp.__exit__ = MagicMock(return_value=False)
    return resp


# ── WebhookConfig / from_config ──────────────────────────────────────


class TestWebhookConfigFromConfig(TestCase):
    """WebhookDispatcher.from_config loads webhooks correctly."""

    def test_loads_webhooks_from_config(self) -> None:
        config = {
            "webhooks": [
                {"url": "https://example.com/hook1", "events": ["DENY", "SUSPEND"]},
                {"url": "https://example.com/hook2", "events": ["TRUST_DROP"]},
            ]
        }
        dispatcher = WebhookDispatcher.from_config(config)
        self.assertEqual(len(dispatcher._webhooks), 2)
        self.assertEqual(dispatcher._webhooks[0].url, "https://example.com/hook1")
        self.assertEqual(dispatcher._webhooks[0].events, ["DENY", "SUSPEND"])
        self.assertEqual(dispatcher._webhooks[1].events, ["TRUST_DROP"])

    def test_empty_config_produces_empty_dispatcher(self) -> None:
        dispatcher = WebhookDispatcher.from_config({})
        self.assertEqual(len(dispatcher._webhooks), 0)

    def test_empty_webhooks_list(self) -> None:
        dispatcher = WebhookDispatcher.from_config({"webhooks": []})
        self.assertEqual(len(dispatcher._webhooks), 0)

    def test_invalid_entries_skipped(self) -> None:
        config = {
            "webhooks": [
                "not-a-dict",
                {"events": ["DENY"]},  # missing url
                {"url": "", "events": ["DENY"]},  # empty url
                {"url": "https://valid.com", "events": ["DENY"]},
            ]
        }
        dispatcher = WebhookDispatcher.from_config(config)
        self.assertEqual(len(dispatcher._webhooks), 1)
        self.assertEqual(dispatcher._webhooks[0].url, "https://valid.com")

    def test_custom_fields_loaded(self) -> None:
        config = {
            "webhooks": [
                {
                    "url": "https://example.com",
                    "events": ["DENY"],
                    "timeout_seconds": 10.0,
                    "max_retries": 3,
                    "enabled": False,
                }
            ]
        }
        dispatcher = WebhookDispatcher.from_config(config)
        hook = dispatcher._webhooks[0]
        self.assertEqual(hook.timeout_seconds, 10.0)
        self.assertEqual(hook.max_retries, 3)
        self.assertFalse(hook.enabled)


# ── Event matching ───────────────────────────────────────────────────


class TestEventMatching(TestCase):
    """Events dispatched only to subscribed webhooks."""

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_event_dispatched_to_subscribed_webhook(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response(200)
        hook = WebhookConfig(url="https://example.com", events=["DENY"])
        dispatcher = WebhookDispatcher([hook])
        dispatcher.dispatch(_make_event("DENY"))
        mock_urlopen.assert_called_once()

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_event_not_dispatched_to_unsubscribed_webhook(self, mock_urlopen: MagicMock) -> None:
        hook = WebhookConfig(url="https://example.com", events=["SUSPEND"])
        dispatcher = WebhookDispatcher([hook])
        dispatcher.dispatch(_make_event("DENY"))
        mock_urlopen.assert_not_called()

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_disabled_webhook_skipped(self, mock_urlopen: MagicMock) -> None:
        hook = WebhookConfig(url="https://example.com", events=["DENY"], enabled=False)
        dispatcher = WebhookDispatcher([hook])
        dispatcher.dispatch(_make_event("DENY"))
        mock_urlopen.assert_not_called()

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_multiple_webhooks_matching(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response(200)
        hook1 = WebhookConfig(url="https://a.com", events=["DENY"])
        hook2 = WebhookConfig(url="https://b.com", events=["DENY"])
        hook3 = WebhookConfig(url="https://c.com", events=["SUSPEND"])
        dispatcher = WebhookDispatcher([hook1, hook2, hook3])
        dispatcher.dispatch(_make_event("DENY"))
        self.assertEqual(mock_urlopen.call_count, 2)


# ── Delivery (mock HTTP) ────────────────────────────────────────────


class TestDelivery(TestCase):
    """HTTP delivery with mock urlopen."""

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_successful_delivery_increments_counter(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response(200)
        hook = WebhookConfig(url="https://example.com", events=["DENY"])
        dispatcher = WebhookDispatcher([hook])
        dispatcher.dispatch(_make_event("DENY"))
        self.assertEqual(dispatcher._delivered, 1)
        self.assertEqual(dispatcher._failed, 0)

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_failed_delivery_increments_failed_counter(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.side_effect = Exception("Connection refused")
        hook = WebhookConfig(url="https://example.com", events=["DENY"], max_retries=0)
        dispatcher = WebhookDispatcher([hook])
        dispatcher.dispatch(_make_event("DENY"))
        self.assertEqual(dispatcher._delivered, 0)
        self.assertEqual(dispatcher._failed, 1)

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_retry_on_failure(self, mock_urlopen: MagicMock) -> None:
        """max_retries=1 means 2 total attempts."""
        mock_urlopen.side_effect = Exception("timeout")
        hook = WebhookConfig(url="https://example.com", events=["DENY"], max_retries=1)
        dispatcher = WebhookDispatcher([hook])
        dispatcher.dispatch(_make_event("DENY"))
        self.assertEqual(mock_urlopen.call_count, 2)  # initial + 1 retry
        self.assertEqual(dispatcher._failed, 1)

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_retry_succeeds_on_second_attempt(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.side_effect = [
            Exception("timeout"),
            _mock_response(200),
        ]
        hook = WebhookConfig(url="https://example.com", events=["DENY"], max_retries=1)
        dispatcher = WebhookDispatcher([hook])
        dispatcher.dispatch(_make_event("DENY"))
        self.assertEqual(mock_urlopen.call_count, 2)
        self.assertEqual(dispatcher._delivered, 1)
        self.assertEqual(dispatcher._failed, 0)

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_timeout_passed_to_urlopen(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response(200)
        hook = WebhookConfig(
            url="https://example.com", events=["DENY"], timeout_seconds=3.0
        )
        dispatcher = WebhookDispatcher([hook])
        dispatcher.dispatch(_make_event("DENY"))
        _, kwargs = mock_urlopen.call_args
        self.assertEqual(kwargs["timeout"], 3.0)

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_request_headers_and_payload(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response(200)
        hook = WebhookConfig(url="https://example.com", events=["DENY"])
        dispatcher = WebhookDispatcher([hook])
        event = _make_event("DENY")
        dispatcher.dispatch(event)

        req = mock_urlopen.call_args[0][0]
        self.assertEqual(req.get_method(), "POST")
        self.assertEqual(req.get_header("Content-type"), "application/json")
        self.assertEqual(req.get_header("X-nomotic-event"), "DENY")
        self.assertEqual(req.get_header("X-nomotic-event-id"), "nme-abc123")

        body = json.loads(req.data.decode("utf-8"))
        self.assertEqual(body["event_type"], "DENY")
        self.assertEqual(body["source"], "nomotic")
        self.assertEqual(body["version"], "0.4.0")


# ── Rate limiting ────────────────────────────────────────────────────


class TestRateLimiter(TestCase):
    """_RateLimiter token bucket tests."""

    def test_first_10_events_pass(self) -> None:
        limiter = _RateLimiter(max_per_second=10)
        results = [limiter.allow() for _ in range(10)]
        self.assertTrue(all(results))

    def test_11th_event_blocked(self) -> None:
        limiter = _RateLimiter(max_per_second=10)
        for _ in range(10):
            limiter.allow()
        self.assertFalse(limiter.allow())

    @patch("nomotic.webhooks.time.time")
    def test_events_allowed_after_1_second(self, mock_time: MagicMock) -> None:
        limiter = _RateLimiter(max_per_second=10)
        mock_time.return_value = 1000.0
        for _ in range(10):
            limiter.allow()
        self.assertFalse(limiter.allow())

        # Advance time by 1 second — old tokens expire
        mock_time.return_value = 1001.1
        self.assertTrue(limiter.allow())

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_rate_limit_blocks_excess_dispatches(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response(200)
        hook = WebhookConfig(url="https://example.com", events=["DENY"])
        dispatcher = WebhookDispatcher([hook])

        for _ in range(12):
            dispatcher.dispatch(_make_event("DENY"))

        # Only 10 should go through due to rate limiting
        self.assertEqual(mock_urlopen.call_count, 10)


# ── Event construction ───────────────────────────────────────────────


class TestWebhookEvent(TestCase):
    """WebhookEvent.to_dict() has all required fields."""

    def test_to_dict_has_all_fields(self) -> None:
        event = _make_event("DENY", "agent-42", {"key": "value"})
        d = event.to_dict()
        self.assertEqual(d["event_type"], "DENY")
        self.assertEqual(d["event_id"], "nme-abc123")
        self.assertEqual(d["timestamp"], 1700000000.0)
        self.assertEqual(d["agent_id"], "agent-42")
        self.assertEqual(d["payload"], {"key": "value"})
        self.assertEqual(d["source"], "nomotic")
        self.assertEqual(d["version"], "0.4.0")

    def test_default_empty_payload(self) -> None:
        event = WebhookEvent(
            event_type="SUSPEND",
            event_id="nme-xyz",
            timestamp=0.0,
            agent_id="a",
        )
        self.assertEqual(event.to_dict()["payload"], {})

    def test_all_event_types_are_strings(self) -> None:
        for et in WEBHOOK_EVENT_TYPES:
            self.assertIsInstance(et, str)
        self.assertIn("DENY", WEBHOOK_EVENT_TYPES)
        self.assertIn("SUSPEND", WEBHOOK_EVENT_TYPES)
        self.assertIn("DRIFT_ALERT", WEBHOOK_EVENT_TYPES)
        self.assertIn("TRUST_DROP", WEBHOOK_EVENT_TYPES)
        self.assertIn("OVERRIDE_APPROVE", WEBHOOK_EVENT_TYPES)
        self.assertIn("OVERRIDE_REVOKE", WEBHOOK_EVENT_TYPES)
        self.assertIn("CHAIN_BREAK", WEBHOOK_EVENT_TYPES)
        self.assertIn("LOOP_DETECTED", WEBHOOK_EVENT_TYPES)
        self.assertIn("SEAL_EXPIRED", WEBHOOK_EVENT_TYPES)


# ── Stats ────────────────────────────────────────────────────────────


class TestStats(TestCase):
    """stats() returns correct counts."""

    def test_stats_initial(self) -> None:
        dispatcher = WebhookDispatcher()
        s = dispatcher.stats()
        self.assertEqual(s["delivered"], 0)
        self.assertEqual(s["failed"], 0)
        self.assertEqual(s["webhooks_configured"], 0)
        self.assertEqual(s["last_errors"], [])

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_stats_after_deliveries(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response(200)
        hook = WebhookConfig(url="https://example.com", events=["DENY"])
        dispatcher = WebhookDispatcher([hook])
        dispatcher.dispatch(_make_event("DENY"))
        dispatcher.dispatch(_make_event("DENY"))

        s = dispatcher.stats()
        self.assertEqual(s["delivered"], 2)
        self.assertEqual(s["failed"], 0)
        self.assertEqual(s["webhooks_configured"], 1)

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_last_errors_tracks_failures(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.side_effect = Exception("Connection refused")
        hook = WebhookConfig(
            url="https://example.com", events=["DENY"], max_retries=0
        )
        dispatcher = WebhookDispatcher([hook])
        dispatcher.dispatch(_make_event("DENY"))

        s = dispatcher.stats()
        self.assertEqual(s["failed"], 1)
        self.assertEqual(len(s["last_errors"]), 1)
        self.assertEqual(s["last_errors"][0]["url"], "https://example.com")
        self.assertEqual(s["last_errors"][0]["event_type"], "DENY")
        self.assertIn("Connection refused", s["last_errors"][0]["error"])

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_last_errors_capped_at_10(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.side_effect = Exception("fail")
        hook = WebhookConfig(
            url="https://example.com", events=["DENY"], max_retries=0
        )
        dispatcher = WebhookDispatcher([hook])

        for _ in range(15):
            dispatcher.dispatch(_make_event("DENY"))

        # Only 10 events get through due to rate limiting, but check cap
        s = dispatcher.stats()
        self.assertLessEqual(len(s["last_errors"]), 10)
