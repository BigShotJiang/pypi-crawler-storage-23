"""Tests for compliance evidence bundles."""

import json
import time

import pytest

from nomotic.audit import AuditRecord, AuditTrail, verify_chain
from nomotic.evidence import (
    ControlMapping,
    EvidenceBundle,
    EvidenceBundleGenerator,
    HIPAA_MAPPINGS,
    ISO27001_MAPPINGS,
    PCI_DSS_MAPPINGS,
    SOC2_MAPPINGS,
    SUPPORTED_FRAMEWORKS,
    _compute_bundle_hash,
    get_mappings_for_frameworks,
)
from nomotic.provenance import ProvenanceLog
from nomotic.trust import TrustCalibrator, TrustConfig


# ── Helpers ──────────────────────────────────────────────────────────────


def _make_record(
    *,
    agent_id: str = "agent-1",
    context_code: str = "GOVERNANCE.ALLOW",
    severity: str = "info",
    verdict: str = "ALLOW",
    ucs: float = 0.8,
    tier: int = 2,
    trust_score: float = 0.7,
    timestamp: float | None = None,
    owner_id: str = "owner@acme.com",
    user_id: str = "user-1",
    action_type: str = "read",
    action_target: str = "/api/data",
) -> AuditRecord:
    return AuditRecord(
        record_id=f"rec-{time.time_ns() % 1000000:06d}",
        timestamp=timestamp or time.time(),
        context_code=context_code,
        severity=severity,
        agent_id=agent_id,
        owner_id=owner_id,
        user_id=user_id,
        action_id=f"act-{time.time_ns() % 1000000:06d}",
        action_type=action_type,
        action_target=action_target,
        verdict=verdict,
        ucs=ucs,
        tier=tier,
        trust_score=trust_score,
        trust_trend="stable",
    )


def _populated_trail(n: int = 5, agent_id: str = "agent-1") -> AuditTrail:
    """Create an AuditTrail with n records, hash-chained."""
    trail = AuditTrail()
    for i in range(n):
        trail.append(_make_record(
            agent_id=agent_id,
            timestamp=1700000000.0 + i * 60,
            verdict="ALLOW" if i % 3 != 0 else "DENY",
        ))
    return trail


def _multi_agent_trail() -> AuditTrail:
    """Create an AuditTrail with records from multiple agents."""
    trail = AuditTrail()
    for i in range(3):
        trail.append(_make_record(
            agent_id="agent-a",
            timestamp=1700000000.0 + i * 60,
        ))
    for i in range(2):
        trail.append(_make_record(
            agent_id="agent-b",
            timestamp=1700000200.0 + i * 60,
        ))
    return trail


# ── ControlMapping tests ─────────────────────────────────────────────────


class TestControlMapping:
    def test_soc2_mappings_exist(self):
        assert len(SOC2_MAPPINGS) >= 5
        frameworks = {m.framework for m in SOC2_MAPPINGS}
        assert frameworks == {"SOC2"}

    def test_hipaa_mappings_exist(self):
        assert len(HIPAA_MAPPINGS) >= 4
        frameworks = {m.framework for m in HIPAA_MAPPINGS}
        assert frameworks == {"HIPAA"}

    def test_pci_dss_mappings_exist(self):
        assert len(PCI_DSS_MAPPINGS) >= 4
        frameworks = {m.framework for m in PCI_DSS_MAPPINGS}
        assert frameworks == {"PCI-DSS"}

    def test_iso27001_mappings_exist(self):
        assert len(ISO27001_MAPPINGS) >= 4
        frameworks = {m.framework for m in ISO27001_MAPPINGS}
        assert frameworks == {"ISO27001"}

    def test_to_dict(self):
        m = SOC2_MAPPINGS[0]
        d = m.to_dict()
        assert d["framework"] == "SOC2"
        assert d["control_id"] == "CC6.1"
        assert "nomotic_evidence" in d
        assert isinstance(d["nomotic_evidence"], list)

    def test_all_mappings_have_evidence(self):
        for mapping_list in [SOC2_MAPPINGS, HIPAA_MAPPINGS, PCI_DSS_MAPPINGS, ISO27001_MAPPINGS]:
            for m in mapping_list:
                assert len(m.nomotic_evidence) > 0, (
                    f"{m.framework} {m.control_id} has no evidence mapping"
                )

    def test_get_mappings_all_frameworks(self):
        all_mappings = get_mappings_for_frameworks(None)
        assert len(all_mappings) == (
            len(SOC2_MAPPINGS) + len(HIPAA_MAPPINGS)
            + len(PCI_DSS_MAPPINGS) + len(ISO27001_MAPPINGS)
        )

    def test_get_mappings_single_framework(self):
        soc2 = get_mappings_for_frameworks(["SOC2"])
        assert len(soc2) == len(SOC2_MAPPINGS)
        assert all(m.framework == "SOC2" for m in soc2)

    def test_get_mappings_multiple_frameworks(self):
        mappings = get_mappings_for_frameworks(["SOC2", "HIPAA"])
        assert len(mappings) == len(SOC2_MAPPINGS) + len(HIPAA_MAPPINGS)

    def test_soc2_cc6_1_scope_compliance(self):
        cc61 = [m for m in SOC2_MAPPINGS if m.control_id == "CC6.1"]
        assert len(cc61) == 1
        assert "scope_compliance" in cc61[0].nomotic_evidence

    def test_soc2_cc7_2_monitoring(self):
        cc72 = [m for m in SOC2_MAPPINGS if m.control_id == "CC7.2"]
        assert len(cc72) == 1
        assert "drift_detection" in cc72[0].nomotic_evidence
        assert "audit_trail" in cc72[0].nomotic_evidence

    def test_soc2_cc7_4_incident_response(self):
        cc74 = [m for m in SOC2_MAPPINGS if m.control_id == "CC7.4"]
        assert len(cc74) == 1
        assert "interrupt_authority" in cc74[0].nomotic_evidence

    def test_soc2_cc8_1_change_management(self):
        cc81 = [m for m in SOC2_MAPPINGS if m.control_id == "CC8.1"]
        assert len(cc81) == 1
        assert "config_provenance" in cc81[0].nomotic_evidence

    def test_hipaa_access_control(self):
        ac = [m for m in HIPAA_MAPPINGS if m.control_id == "164.312(a)(1)"]
        assert len(ac) == 1
        assert "scope_compliance" in ac[0].nomotic_evidence

    def test_hipaa_audit_controls(self):
        ac = [m for m in HIPAA_MAPPINGS if m.control_id == "164.312(b)"]
        assert len(ac) == 1
        assert "audit_trail" in ac[0].nomotic_evidence
        assert "hash_chain_verification" in ac[0].nomotic_evidence

    def test_hipaa_integrity(self):
        ic = [m for m in HIPAA_MAPPINGS if m.control_id == "164.312(c)(1)"]
        assert len(ic) == 1
        assert "hash_chain_verification" in ic[0].nomotic_evidence
        assert "tamper_detection" in ic[0].nomotic_evidence

    def test_hipaa_authentication(self):
        auth = [m for m in HIPAA_MAPPINGS if m.control_id == "164.312(d)"]
        assert len(auth) == 1
        assert "certificates" in auth[0].nomotic_evidence

    def test_pci_dss_access_by_need(self):
        req71 = [m for m in PCI_DSS_MAPPINGS if m.control_id == "Req 7.1"]
        assert len(req71) == 1
        assert "scope_compliance" in req71[0].nomotic_evidence

    def test_pci_dss_strong_auth(self):
        req83 = [m for m in PCI_DSS_MAPPINGS if m.control_id == "Req 8.3"]
        assert len(req83) == 1
        assert "certificates" in req83[0].nomotic_evidence

    def test_pci_dss_audit_trails(self):
        req101 = [m for m in PCI_DSS_MAPPINGS if m.control_id == "Req 10.1"]
        assert len(req101) == 1
        assert "audit_trail" in req101[0].nomotic_evidence
        assert "hash_chain_verification" in req101[0].nomotic_evidence

    def test_pci_dss_tamper_protection(self):
        req105 = [m for m in PCI_DSS_MAPPINGS if m.control_id == "Req 10.5"]
        assert len(req105) == 1
        assert "hash_chain_verification" in req105[0].nomotic_evidence
        assert "verify_chain" in req105[0].nomotic_evidence


# ── EvidenceBundle tests ─────────────────────────────────────────────────


class TestEvidenceBundle:
    def test_to_dict_roundtrip(self):
        bundle = EvidenceBundle(
            bundle_id="evb-test1234567890ab",
            created_at="2026-02-17T00:00:00+00:00",
            created_by="test",
            agent_id="agent-1",
            frameworks=["SOC2"],
            record_count=0,
        )
        d = bundle.to_dict()
        restored = EvidenceBundle.from_dict(d)
        assert restored.bundle_id == bundle.bundle_id
        assert restored.agent_id == "agent-1"
        assert restored.frameworks == ["SOC2"]
        assert restored.record_count == 0

    def test_from_dict_defaults(self):
        bundle = EvidenceBundle.from_dict({})
        assert bundle.bundle_id == ""
        assert bundle.agent_id is None
        assert bundle.frameworks == []
        assert bundle.record_count == 0

    def test_time_range_serialization(self):
        bundle = EvidenceBundle(time_range=(100.0, 200.0))
        d = bundle.to_dict()
        assert d["time_range"] == [100.0, 200.0]
        restored = EvidenceBundle.from_dict(d)
        assert restored.time_range == (100.0, 200.0)


# ── EvidenceBundleGenerator tests ────────────────────────────────────────


class TestEvidenceBundleGenerator:
    def test_generate_from_populated_trail(self):
        trail = _populated_trail(10)
        gen = EvidenceBundleGenerator(audit_trail=trail)
        bundle = gen.generate(created_by="test-suite")

        assert bundle.bundle_id.startswith("evb-")
        assert bundle.created_by == "test-suite"
        assert bundle.record_count == 10
        assert len(bundle.audit_records) == 10
        assert bundle.chain_verification["valid"] is True
        assert bundle.bundle_hash != ""
        assert len(bundle.compliance_evidence) > 0

    def test_generate_with_agent_filter(self):
        trail = _multi_agent_trail()
        gen = EvidenceBundleGenerator(audit_trail=trail)
        bundle = gen.generate(agent_id="agent-a")

        assert bundle.agent_id == "agent-a"
        assert bundle.record_count == 3
        assert all(
            r["agent_id"] == "agent-a" for r in bundle.audit_records
        )

    def test_generate_with_time_range(self):
        trail = _populated_trail(10)
        gen = EvidenceBundleGenerator(audit_trail=trail)

        # Records are at 1700000000 + i*60 for i in 0..9
        # Filter to indices 3-7 inclusive (timestamps 1700000180 to 1700000420)
        # That's 5 records: 180, 240, 300, 360, 420
        bundle = gen.generate(
            since=1700000180.0,
            until=1700000420.0,
        )

        assert bundle.record_count == 5
        for r in bundle.audit_records:
            assert r["timestamp"] >= 1700000180.0
            assert r["timestamp"] <= 1700000420.0

    def test_framework_specific_soc2(self):
        trail = _populated_trail(3)
        gen = EvidenceBundleGenerator(audit_trail=trail)
        bundle = gen.generate(frameworks=["SOC2"])

        assert bundle.frameworks == ["SOC2"]
        frameworks_in_evidence = {
            e["framework"] for e in bundle.compliance_evidence
        }
        assert frameworks_in_evidence == {"SOC2"}
        control_ids = {e["control_id"] for e in bundle.compliance_evidence}
        assert "CC6.1" in control_ids
        assert "CC7.2" in control_ids
        assert "CC8.1" in control_ids

    def test_framework_specific_hipaa(self):
        trail = _populated_trail(3)
        gen = EvidenceBundleGenerator(audit_trail=trail)
        bundle = gen.generate(frameworks=["HIPAA"])

        assert bundle.frameworks == ["HIPAA"]
        control_ids = {e["control_id"] for e in bundle.compliance_evidence}
        assert "164.312(a)(1)" in control_ids
        assert "164.312(b)" in control_ids
        assert "164.312(c)(1)" in control_ids
        assert "164.312(d)" in control_ids

    def test_framework_specific_pci_dss(self):
        trail = _populated_trail(3)
        gen = EvidenceBundleGenerator(audit_trail=trail)
        bundle = gen.generate(frameworks=["PCI-DSS"])

        assert bundle.frameworks == ["PCI-DSS"]
        control_ids = {e["control_id"] for e in bundle.compliance_evidence}
        assert "Req 7.1" in control_ids
        assert "Req 8.3" in control_ids
        assert "Req 10.1" in control_ids
        assert "Req 10.5" in control_ids

    def test_framework_specific_iso27001(self):
        trail = _populated_trail(3)
        gen = EvidenceBundleGenerator(audit_trail=trail)
        bundle = gen.generate(frameworks=["ISO27001"])

        assert bundle.frameworks == ["ISO27001"]
        control_ids = {e["control_id"] for e in bundle.compliance_evidence}
        assert "A.9.1" in control_ids
        assert "A.12.4" in control_ids

    def test_bundle_hash_verification(self):
        trail = _populated_trail(5)
        gen = EvidenceBundleGenerator(audit_trail=trail)
        bundle = gen.generate()

        # Verify hash is correct
        bundle_dict = bundle.to_dict()
        recomputed = _compute_bundle_hash(bundle_dict)
        assert bundle.bundle_hash == recomputed

    def test_bundle_hash_tamper_detection(self):
        trail = _populated_trail(5)
        gen = EvidenceBundleGenerator(audit_trail=trail)
        bundle = gen.generate()

        # Tamper with a field
        bundle_dict = bundle.to_dict()
        bundle_dict["record_count"] = 999

        valid, msg = gen.verify_bundle(bundle_dict)
        assert valid is False
        assert "hash mismatch" in msg.lower()

    def test_audit_chain_verification_within_bundle(self):
        trail = _populated_trail(5)
        gen = EvidenceBundleGenerator(audit_trail=trail)
        bundle = gen.generate()

        assert bundle.chain_verification["valid"] is True
        assert bundle.chain_verification["records_verified"] == 5

    def test_json_roundtrip_verify(self):
        trail = _populated_trail(5)
        gen = EvidenceBundleGenerator(audit_trail=trail)
        bundle = gen.generate()

        # Serialize to JSON and back
        json_str = gen.to_json(bundle)
        parsed = json.loads(json_str)

        # Verify from parsed JSON
        valid, msg = gen.verify_bundle(parsed)
        assert valid is True
        assert "verified" in msg.lower()

    def test_empty_trail_bundle(self):
        trail = AuditTrail()
        gen = EvidenceBundleGenerator(audit_trail=trail)
        bundle = gen.generate()

        assert bundle.record_count == 0
        assert len(bundle.audit_records) == 0
        assert bundle.chain_verification["valid"] is True
        assert bundle.bundle_hash != ""

        # Should still be verifiable
        valid, msg = gen.verify_bundle(bundle.to_dict())
        assert valid is True

    def test_multi_agent_bundle_no_filter(self):
        trail = _multi_agent_trail()
        gen = EvidenceBundleGenerator(audit_trail=trail)
        bundle = gen.generate()

        assert bundle.agent_id is None
        assert bundle.record_count == 5  # 3 agent-a + 2 agent-b
        agents = {r["agent_id"] for r in bundle.audit_records}
        assert "agent-a" in agents
        assert "agent-b" in agents

    def test_to_dict(self):
        trail = _populated_trail(3)
        gen = EvidenceBundleGenerator(audit_trail=trail)
        bundle = gen.generate()
        d = gen.to_dict(bundle)
        assert isinstance(d, dict)
        assert d["bundle_id"] == bundle.bundle_id
        assert d["record_count"] == 3

    def test_verify_bundle_no_hash(self):
        gen = EvidenceBundleGenerator()
        valid, msg = gen.verify_bundle({"bundle_hash": ""})
        assert valid is False
        assert "no hash" in msg.lower()

    def test_verify_bundle_record_count_mismatch(self):
        trail = _populated_trail(3)
        gen = EvidenceBundleGenerator(audit_trail=trail)
        bundle = gen.generate()

        # Create a bundle dict with mismatched count but valid hash
        bundle_dict = bundle.to_dict()
        # Modify record_count but keep the same hash — should fail on hash
        bundle_dict["record_count"] = 999
        valid, msg = gen.verify_bundle(bundle_dict)
        assert valid is False

    def test_generate_with_trust_manager(self):
        trail = _populated_trail(3, agent_id="agent-t")
        trust_mgr = TrustCalibrator(TrustConfig())
        # Create a profile so trajectory exists
        trust_mgr.get_profile("agent-t")

        gen = EvidenceBundleGenerator(
            audit_trail=trail,
            trust_manager=trust_mgr,
        )
        bundle = gen.generate(agent_id="agent-t")

        # Trust trajectory should be collected (may be empty if no events)
        assert isinstance(bundle.agent_trust_trajectory, list)

    def test_generate_with_provenance_log(self):
        trail = _populated_trail(3)
        prov = ProvenanceLog()
        prov.record(
            actor="admin@acme.com",
            target_type="scope",
            target_id="agent-1",
            change_type="modify",
            reason="Update scope",
        )
        prov.record(
            actor="admin@acme.com",
            target_type="weight",
            target_id="safety",
            change_type="modify",
            new_value=1.5,
            reason="Increase safety weight",
        )

        gen = EvidenceBundleGenerator(
            audit_trail=trail,
            provenance_log=prov,
        )
        bundle = gen.generate()

        assert len(bundle.config_provenance) == 2
        assert bundle.config_provenance[0]["actor"] == "admin@acme.com"

    def test_sanitization_integration(self):
        """Generate with a mock sanitizer, verify it was applied."""
        trail = AuditTrail()
        rec = _make_record(owner_id="secret@acme.com")
        rec.metadata = {"api_key": "sk-12345"}
        trail.append(rec)

        class MockSanitizer:
            def sanitize_dict(self, d):
                result = dict(d)
                for k, v in result.items():
                    if isinstance(v, str) and "secret" in v:
                        result[k] = "[REDACTED]"
                    if isinstance(v, dict):
                        result[k] = self.sanitize_dict(v)
                return result

        gen = EvidenceBundleGenerator(audit_trail=trail)
        bundle = gen.generate(sanitizer=MockSanitizer())

        # The owner_id should have been sanitized
        assert bundle.audit_records[0]["owner_id"] == "[REDACTED]"

    def test_all_frameworks_default(self):
        trail = _populated_trail(2)
        gen = EvidenceBundleGenerator(audit_trail=trail)
        bundle = gen.generate()

        assert set(bundle.frameworks) == set(SUPPORTED_FRAMEWORKS)
        frameworks_in_evidence = {
            e["framework"] for e in bundle.compliance_evidence
        }
        assert "SOC2" in frameworks_in_evidence
        assert "HIPAA" in frameworks_in_evidence
        assert "PCI-DSS" in frameworks_in_evidence
        assert "ISO27001" in frameworks_in_evidence

    def test_bundle_version(self):
        trail = _populated_trail(1)
        gen = EvidenceBundleGenerator(audit_trail=trail)
        bundle = gen.generate()
        assert bundle.bundle_version == "1.0.0"

    def test_created_at_is_iso8601(self):
        trail = _populated_trail(1)
        gen = EvidenceBundleGenerator(audit_trail=trail)
        bundle = gen.generate()
        # Should be parseable as ISO 8601
        from datetime import datetime
        datetime.fromisoformat(bundle.created_at)

    def test_no_trail_generates_valid_bundle(self):
        gen = EvidenceBundleGenerator()
        bundle = gen.generate()
        assert bundle.record_count == 0
        assert bundle.chain_verification["valid"] is True
        assert bundle.bundle_hash != ""

    def test_chain_verification_included_in_bundle(self):
        trail = _populated_trail(5)
        gen = EvidenceBundleGenerator(audit_trail=trail)
        bundle = gen.generate()
        cv = bundle.chain_verification
        assert "valid" in cv
        assert "message" in cv
        assert "records_verified" in cv
        assert cv["records_verified"] == 5


# ── CLI argument parsing tests ───────────────────────────────────────────


class TestCLIEvidenceArgParsing:
    def test_evidence_generate_args(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "evidence", "generate", "agent-1",
            "--frameworks", "SOC2,HIPAA",
            "--since", "2026-01-01",
            "--output", "bundle.json",
        ])
        assert args.command == "evidence"
        assert args.evidence_command == "generate"
        assert args.identifier == "agent-1"
        assert args.frameworks == "SOC2,HIPAA"
        assert args.since == "2026-01-01"
        assert args.output == "bundle.json"

    def test_evidence_generate_no_agent(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args(["evidence", "generate"])
        assert args.evidence_command == "generate"
        assert args.identifier is None

    def test_evidence_verify_args(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args(["evidence", "verify", "bundle.json"])
        assert args.evidence_command == "verify"
        assert args.bundle_file == "bundle.json"

    def test_evidence_summary_args(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args(["evidence", "summary", "bundle.json"])
        assert args.evidence_command == "summary"
        assert args.bundle_file == "bundle.json"


# ── CLI evidence summary output tests ────────────────────────────────────


class TestCLIEvidenceSummary:
    def test_summary_output(self, capsys, tmp_path):
        """Test that evidence summary prints expected fields."""
        from nomotic.cli import main

        trail = _populated_trail(5)
        gen = EvidenceBundleGenerator(audit_trail=trail)
        bundle = gen.generate(frameworks=["SOC2"])

        bundle_path = tmp_path / "test_bundle.json"
        bundle_path.write_text(gen.to_json(bundle))

        main(["evidence", "summary", str(bundle_path)])
        output = capsys.readouterr().out

        assert "Evidence Bundle Summary" in output
        assert bundle.bundle_id in output
        assert "SOC2" in output
        assert "5" in output  # record count

    def test_verify_output_pass(self, capsys, tmp_path):
        """Test that evidence verify prints PASS for valid bundle."""
        from nomotic.cli import main

        trail = _populated_trail(3)
        gen = EvidenceBundleGenerator(audit_trail=trail)
        bundle = gen.generate()

        bundle_path = tmp_path / "test_bundle.json"
        bundle_path.write_text(gen.to_json(bundle))

        main(["evidence", "verify", str(bundle_path)])
        output = capsys.readouterr().out
        assert "PASS" in output or "verified" in output.lower()

    def test_verify_output_fail(self, capsys, tmp_path):
        """Test that evidence verify prints FAIL for tampered bundle."""
        from nomotic.cli import main

        trail = _populated_trail(3)
        gen = EvidenceBundleGenerator(audit_trail=trail)
        bundle = gen.generate()

        # Tamper with the bundle
        bundle_dict = bundle.to_dict()
        bundle_dict["record_count"] = 999

        bundle_path = tmp_path / "tampered_bundle.json"
        bundle_path.write_text(json.dumps(bundle_dict, indent=2))

        with pytest.raises(SystemExit) as exc_info:
            main(["evidence", "verify", str(bundle_path)])
        assert exc_info.value.code == 1
