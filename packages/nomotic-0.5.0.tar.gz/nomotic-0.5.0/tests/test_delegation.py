"""Tests for multi-agent handoff reporting (delegation)."""

import time

import pytest

from nomotic.authority import CertificateAuthority
from nomotic.certificate import CertStatus
from nomotic.delegation import DelegationRecord, DelegationTracker
from nomotic.keys import SigningKey
from nomotic.store import MemoryCertificateStore


def _ca() -> CertificateAuthority:
    sk, _vk = SigningKey.generate()
    return CertificateAuthority(issuer_id="test-issuer", signing_key=sk)


def _ca_with_agents(*names: str) -> tuple[CertificateAuthority, MemoryCertificateStore]:
    """Create a CA and issue certificates for the given agent names."""
    sk, _vk = SigningKey.generate()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)
    for name in names:
        ca.issue(name, "customer-experience", "acme", "global/us")
    return ca, store


# ── Basic delegation ──────────────────────────────────────────────


class TestBasicDelegation:
    def test_create_delegation(self):
        tracker = DelegationTracker()
        record = tracker.delegate("agent-a", "agent-b", {"read"}, {"customers/*"})
        assert record.from_agent == "agent-a"
        assert record.to_agent == "agent-b"
        assert record.delegated_scope == {"read"}
        assert record.delegated_targets == {"customers/*"}

    def test_delegation_record_fields(self):
        tracker = DelegationTracker()
        record = tracker.delegate(
            "agent-a",
            "agent-b",
            {"read", "write"},
            {"customers/*", "orders/*"},
            authority_basis="certificate",
            seal_id="seal-123",
            metadata={"reason": "load balancing"},
        )
        assert record.authority_basis == "certificate"
        assert record.seal_id == "seal-123"
        assert record.metadata == {"reason": "load balancing"}
        assert record.expires_at is None
        assert isinstance(record.timestamp, float)

    def test_delegation_id_format(self):
        tracker = DelegationTracker()
        record = tracker.delegate("agent-a", "agent-b", {"read"}, {"*"})
        assert record.delegation_id.startswith("nmd-")
        # UUID part should be 36 chars (with hyphens)
        uuid_part = record.delegation_id[4:]
        assert len(uuid_part) == 36

    def test_to_dict_from_dict_roundtrip(self):
        tracker = DelegationTracker()
        record = tracker.delegate(
            "agent-a",
            "agent-b",
            {"read", "write"},
            {"customers/*", "orders/*"},
            authority_basis="human_override",
            seal_id="seal-456",
            expires_at=time.time() + 3600,
            metadata={"reason": "test"},
        )
        d = record.to_dict()
        restored = DelegationRecord.from_dict(d)
        assert restored.delegation_id == record.delegation_id
        assert restored.from_agent == record.from_agent
        assert restored.to_agent == record.to_agent
        assert restored.delegated_scope == record.delegated_scope
        assert restored.delegated_targets == record.delegated_targets
        assert restored.authority_basis == record.authority_basis
        assert restored.seal_id == record.seal_id
        assert restored.expires_at == record.expires_at
        assert restored.metadata == record.metadata

    def test_to_dict_sorts_scope_and_targets(self):
        tracker = DelegationTracker()
        record = tracker.delegate(
            "agent-a", "agent-b",
            {"write", "read", "delete"},
            {"z-target", "a-target"},
        )
        d = record.to_dict()
        assert d["delegated_scope"] == ["delete", "read", "write"]
        assert d["delegated_targets"] == ["a-target", "z-target"]

    def test_default_authority_basis(self):
        tracker = DelegationTracker()
        record = tracker.delegate("agent-a", "agent-b", {"read"}, {"*"})
        assert record.authority_basis == "certificate"


# ── Scope validation with certificates ────────────────────────────


class TestScopeValidation:
    def test_delegation_succeeds_with_valid_certs(self):
        ca, store = _ca_with_agents("agent-a", "agent-b")
        tracker = DelegationTracker(cert_store=store)
        record = tracker.delegate("agent-a", "agent-b", {"read"}, {"*"})
        assert record.from_agent == "agent-a"

    def test_delegating_agent_must_have_active_cert(self):
        ca, store = _ca_with_agents("agent-b")
        tracker = DelegationTracker(cert_store=store)
        with pytest.raises(ValueError, match="Cannot delegating.*agent-a.*no active certificate"):
            tracker.delegate("agent-a", "agent-b", {"read"}, {"*"})

    def test_receiving_agent_must_have_active_cert(self):
        ca, store = _ca_with_agents("agent-a")
        tracker = DelegationTracker(cert_store=store)
        with pytest.raises(ValueError, match="Cannot receiving.*agent-b.*no active certificate"):
            tracker.delegate("agent-a", "agent-b", {"read"}, {"*"})

    def test_suspended_agent_cannot_receive_delegation(self):
        ca, store = _ca_with_agents("agent-a", "agent-b")
        # Suspend agent-b's certificate
        certs = store.list(status=CertStatus.ACTIVE)
        b_cert = [c for c in certs if c.agent_id == "agent-b"][0]
        ca.suspend(b_cert.certificate_id, reason="testing")
        tracker = DelegationTracker(cert_store=store)
        with pytest.raises(ValueError, match="Cannot receiving.*agent-b.*no active certificate"):
            tracker.delegate("agent-a", "agent-b", {"read"}, {"*"})

    def test_no_cert_store_skips_validation(self):
        tracker = DelegationTracker(cert_store=None)
        record = tracker.delegate("agent-a", "agent-b", {"read"}, {"*"})
        assert record.from_agent == "agent-a"


# ── Delegation tracking ──────────────────────────────────────────


class TestDelegationTracking:
    def test_get_active_delegations(self):
        tracker = DelegationTracker()
        tracker.delegate("agent-a", "agent-b", {"read"}, {"*"})
        tracker.delegate("agent-a", "agent-b", {"write"}, {"orders/*"})
        active = tracker.get_active_delegations("agent-b")
        assert len(active) == 2

    def test_get_active_delegations_empty(self):
        tracker = DelegationTracker()
        assert tracker.get_active_delegations("agent-x") == []

    def test_get_delegations_from(self):
        tracker = DelegationTracker()
        tracker.delegate("agent-a", "agent-b", {"read"}, {"*"})
        tracker.delegate("agent-a", "agent-c", {"write"}, {"orders/*"})
        tracker.delegate("agent-b", "agent-c", {"read"}, {"*"})
        from_a = tracker.get_delegations_from("agent-a")
        assert len(from_a) == 2
        assert all(d.from_agent == "agent-a" for d in from_a)

    def test_expired_delegations_are_evicted(self):
        tracker = DelegationTracker()
        # Create an already-expired delegation
        tracker.delegate(
            "agent-a", "agent-b", {"read"}, {"*"},
            expires_at=time.time() - 1,
        )
        # Create a valid delegation
        tracker.delegate("agent-a", "agent-b", {"write"}, {"*"})
        active = tracker.get_active_delegations("agent-b")
        assert len(active) == 1
        assert active[0].delegated_scope == {"write"}

    def test_has_delegated_scope_true(self):
        tracker = DelegationTracker()
        tracker.delegate("agent-a", "agent-b", {"read", "write"}, {"customers/*"})
        assert tracker.has_delegated_scope("agent-b", "read", "customers/123") is True
        assert tracker.has_delegated_scope("agent-b", "write", "customers/456") is True

    def test_has_delegated_scope_false_no_delegation(self):
        tracker = DelegationTracker()
        assert tracker.has_delegated_scope("agent-b", "read", "customers/123") is False

    def test_has_delegated_scope_false_wrong_action(self):
        tracker = DelegationTracker()
        tracker.delegate("agent-a", "agent-b", {"read"}, {"customers/*"})
        assert tracker.has_delegated_scope("agent-b", "delete", "customers/123") is False

    def test_has_delegated_scope_false_wrong_target(self):
        tracker = DelegationTracker()
        tracker.delegate("agent-a", "agent-b", {"read"}, {"customers/*"})
        assert tracker.has_delegated_scope("agent-b", "read", "orders/123") is False

    def test_session_scoped_delegation_never_expires(self):
        tracker = DelegationTracker()
        record = tracker.delegate("agent-a", "agent-b", {"read"}, {"*"})
        assert record.expires_at is None
        assert record.is_expired() is False


# ── Delegation chain ──────────────────────────────────────────────


class TestDelegationChain:
    def test_single_delegation_chain(self):
        tracker = DelegationTracker()
        tracker.delegate("agent-a", "agent-b", {"read"}, {"*"})
        chain = tracker.get_delegation_chain("agent-b")
        assert len(chain) == 1
        assert chain[0].from_agent == "agent-a"
        assert chain[0].to_agent == "agent-b"

    def test_multi_hop_chain(self):
        tracker = DelegationTracker()
        tracker.delegate("agent-a", "agent-b", {"read"}, {"*"})
        tracker.delegate("agent-b", "agent-c", {"read"}, {"*"})
        chain = tracker.get_delegation_chain("agent-c")
        assert len(chain) == 2
        assert chain[0].from_agent == "agent-a"
        assert chain[0].to_agent == "agent-b"
        assert chain[1].from_agent == "agent-b"
        assert chain[1].to_agent == "agent-c"

    def test_chain_stops_at_root(self):
        tracker = DelegationTracker()
        tracker.delegate("agent-a", "agent-b", {"read"}, {"*"})
        chain = tracker.get_delegation_chain("agent-a")
        assert len(chain) == 0

    def test_chain_for_unknown_agent(self):
        tracker = DelegationTracker()
        chain = tracker.get_delegation_chain("agent-x")
        assert len(chain) == 0


# ── Target matching ───────────────────────────────────────────────


class TestTargetMatching:
    def test_exact_match(self):
        tracker = DelegationTracker()
        tracker.delegate("a", "b", {"read"}, {"customers/123"})
        assert tracker.has_delegated_scope("b", "read", "customers/123") is True

    def test_wildcard_matches_everything(self):
        tracker = DelegationTracker()
        tracker.delegate("a", "b", {"read"}, {"*"})
        assert tracker.has_delegated_scope("b", "read", "anything/here") is True
        assert tracker.has_delegated_scope("b", "read", "something_else") is True

    def test_prefix_wildcard_matches_subtree(self):
        tracker = DelegationTracker()
        tracker.delegate("a", "b", {"read"}, {"customers/*"})
        assert tracker.has_delegated_scope("b", "read", "customers/123") is True
        assert tracker.has_delegated_scope("b", "read", "customers/abc/def") is True

    def test_prefix_wildcard_no_match_unrelated(self):
        tracker = DelegationTracker()
        tracker.delegate("a", "b", {"read"}, {"customers/*"})
        assert tracker.has_delegated_scope("b", "read", "orders/123") is False
        assert tracker.has_delegated_scope("b", "read", "custom") is False


# ── DelegationRecord expiration ───────────────────────────────────


class TestDelegationRecordExpiration:
    def test_not_expired_when_no_expiry(self):
        record = DelegationRecord(
            delegation_id="nmd-test",
            from_agent="a",
            to_agent="b",
            delegated_scope={"read"},
            delegated_targets={"*"},
            authority_basis="certificate",
        )
        assert record.is_expired() is False

    def test_not_expired_when_future(self):
        record = DelegationRecord(
            delegation_id="nmd-test",
            from_agent="a",
            to_agent="b",
            delegated_scope={"read"},
            delegated_targets={"*"},
            authority_basis="certificate",
            expires_at=time.time() + 3600,
        )
        assert record.is_expired() is False

    def test_expired_when_past(self):
        record = DelegationRecord(
            delegation_id="nmd-test",
            from_agent="a",
            to_agent="b",
            delegated_scope={"read"},
            delegated_targets={"*"},
            authority_basis="certificate",
            expires_at=time.time() - 1,
        )
        assert record.is_expired() is True


# ── Audit integration ─────────────────────────────────────────────


class TestAuditIntegration:
    def test_delegation_writes_audit_record(self, tmp_path):
        from nomotic.audit_store import LogStore
        from nomotic.runtime import GovernanceRuntime

        runtime = GovernanceRuntime()
        store = LogStore(tmp_path, "audit")
        runtime.set_audit_store(store)

        record = runtime.delegate(
            "agent-a", "agent-b",
            {"read", "write"},
            {"customers/*"},
        )

        # Query audit records for the delegating agent
        records = store.query("agent-a", limit=10)
        assert len(records) == 1
        audit = records[0]
        assert audit.action_type == "delegate"
        assert audit.action_target == "agent-b"
        assert audit.verdict == "ALLOW"
        assert audit.record_id == record.delegation_id
        assert "delegation_id" in audit.parameters
        assert audit.parameters["delegated_scope"] == ["read", "write"]
        assert audit.parameters["delegated_targets"] == ["customers/*"]
        assert audit.parameters["authority_basis"] == "certificate"

    def test_audit_record_has_valid_hash_chain(self, tmp_path):
        from nomotic.audit_store import LogStore
        from nomotic.runtime import GovernanceRuntime

        runtime = GovernanceRuntime()
        store = LogStore(tmp_path, "audit")
        runtime.set_audit_store(store)

        runtime.delegate("agent-a", "agent-b", {"read"}, {"*"})
        runtime.delegate("agent-a", "agent-c", {"write"}, {"orders/*"})

        # Verify hash chain integrity
        is_valid, record_count, error_msg = store.verify_chain("agent-a")
        assert is_valid is True
        assert record_count == 2

    def test_delegation_chain_via_runtime(self):
        from nomotic.runtime import GovernanceRuntime

        runtime = GovernanceRuntime()
        runtime.delegate("agent-a", "agent-b", {"read"}, {"*"})
        runtime.delegate("agent-b", "agent-c", {"read"}, {"*"})

        chain = runtime.get_delegation_chain("agent-c")
        assert len(chain) == 2
        assert chain[0].from_agent == "agent-a"
        assert chain[1].from_agent == "agent-b"

    def test_delegation_without_audit_store(self):
        from nomotic.runtime import GovernanceRuntime

        runtime = GovernanceRuntime()
        # No audit store set — should not raise
        record = runtime.delegate("agent-a", "agent-b", {"read"}, {"*"})
        assert record.delegation_id.startswith("nmd-")


# ── Exports ───────────────────────────────────────────────────────


class TestExports:
    def test_delegation_record_importable(self):
        from nomotic import DelegationRecord
        assert DelegationRecord is not None

    def test_delegation_tracker_importable(self):
        from nomotic import DelegationTracker
        assert DelegationTracker is not None
