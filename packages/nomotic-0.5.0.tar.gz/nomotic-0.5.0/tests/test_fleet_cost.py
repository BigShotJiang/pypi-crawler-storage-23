"""Tests for Fleet Cost Aggregation (Item 12)."""

import calendar
import time
from datetime import datetime, timezone
from unittest.mock import patch

import pytest

from nomotic.audit_store import LogStore, PersistentLogRecord
from nomotic.fleet import (
    AgentCostRecord,
    CostGroup,
    FleetCostAggregator,
    GroupCostSummary,
)


# ── Helpers ────────────────────────────────────────────────────────────


def _write_records(base_dir, agent_id, records):
    """Write audit records for an agent to temp dir."""
    store = LogStore(base_dir, "audit")
    for r in records:
        store.append(PersistentLogRecord(**r))


def _make_record(
    agent_id="test-agent",
    action_type="read",
    verdict="ALLOW",
    trust_score=0.65,
    trust_delta=0.01,
    trust_trend="rising",
    timestamp=None,
    parameters=None,
    **kwargs,
):
    """Build a record dict suitable for PersistentLogRecord."""
    return {
        "record_id": kwargs.get("record_id", f"r-{time.time_ns()}"),
        "timestamp": timestamp or time.time(),
        "agent_id": agent_id,
        "action_type": action_type,
        "action_target": kwargs.get("action_target", "db"),
        "verdict": verdict,
        "ucs": kwargs.get("ucs", 0.85),
        "tier": kwargs.get("tier", 2),
        "trust_score": trust_score,
        "trust_delta": trust_delta,
        "trust_trend": trust_trend,
        "severity": kwargs.get("severity", "info"),
        "justification": kwargs.get("justification", "ok"),
        "parameters": parameters or {},
    }


def _today_ts(hours_ago=0):
    """Return a timestamp hours_ago hours in the past (still today if small)."""
    return time.time() - (hours_ago * 3600)


def _old_ts(days_ago=2):
    """Return a timestamp days_ago days in the past."""
    return time.time() - (days_ago * 86400)


@pytest.fixture
def cost_store(tmp_path):
    """Create a LogStore for cost tests."""
    return LogStore(tmp_path, "audit")


@pytest.fixture
def agg_with_data(tmp_path):
    """Set up agents with cost data and return (FleetCostAggregator, store)."""
    now = time.time()
    # Compute a timestamp that is guaranteed to be after today's UTC midnight.
    # Using time.time() - 1800 fails when the test runs between 00:00-00:30 UTC
    # because 30 min ago would be "yesterday" in UTC.
    utc_midnight = datetime.now(timezone.utc).replace(
        hour=0, minute=0, second=0, microsecond=0
    ).timestamp()
    recent = max(now - 1800, utc_midnight + 60)  # At least 1 min after midnight

    # Agent with cost data
    _write_records(tmp_path, "bot-1", [
        _make_record("bot-1", timestamp=recent, record_id="b1-1",
                     parameters={"cost_usd": 0.0012, "tokens": 150}),
        _make_record("bot-1", timestamp=recent + 10, record_id="b1-2",
                     parameters={"cost_usd": 0.0025, "tokens": 300}),
        _make_record("bot-1", timestamp=recent + 20, record_id="b1-3",
                     parameters={"cost_usd": 0.0008, "tokens": 100}),
    ])

    # Agent with some cost data
    _write_records(tmp_path, "bot-2", [
        _make_record("bot-2", timestamp=recent, record_id="b2-1",
                     parameters={"cost_usd": 0.05, "tokens": 5000}),
        _make_record("bot-2", timestamp=recent + 10, record_id="b2-2",
                     parameters={"cost_usd": 0.03, "tokens": 3000}),
    ])

    # Agent with NO cost data
    _write_records(tmp_path, "bot-3", [
        _make_record("bot-3", timestamp=recent, record_id="b3-1"),
        _make_record("bot-3", timestamp=recent + 10, record_id="b3-2"),
    ])

    store = LogStore(tmp_path, "audit")
    agg = FleetCostAggregator(audit_store=store)
    return agg, store


# ── TestAgentCostRecord ────────────────────────────────────────────────


class TestAgentCostRecord:
    def test_no_cost_data_all_zeros(self, agg_with_data):
        agg, _ = agg_with_data
        rec = agg.get_agent_cost("bot-3")
        assert rec.total_cost_usd == 0.0
        assert rec.total_tokens == 0
        assert rec.cost_today_usd == 0.0
        assert rec.cost_this_month_usd == 0.0
        assert rec.avg_cost_per_action_usd == 0.0
        assert rec.evaluated_actions == 0
        assert rec.last_cost_at is None

    def test_cost_data_totals_correct(self, agg_with_data):
        agg, _ = agg_with_data
        rec = agg.get_agent_cost("bot-1")
        expected_cost = 0.0012 + 0.0025 + 0.0008
        assert abs(rec.total_cost_usd - expected_cost) < 1e-10
        assert rec.total_tokens == 550
        assert rec.evaluated_actions == 3

    def test_cost_today_only_counts_today(self, tmp_path):
        now = time.time()
        yesterday = now - 86400 * 1.5  # 1.5 days ago

        _write_records(tmp_path, "agent-x", [
            _make_record("agent-x", timestamp=yesterday, record_id="old",
                         parameters={"cost_usd": 10.0, "tokens": 1000}),
            _make_record("agent-x", timestamp=now - 60, record_id="new",
                         parameters={"cost_usd": 1.0, "tokens": 100}),
        ])

        store = LogStore(tmp_path, "audit")
        agg = FleetCostAggregator(audit_store=store)
        rec = agg.get_agent_cost("agent-x")
        assert rec.total_cost_usd == 11.0
        assert rec.cost_today_usd == 1.0

    def test_cost_this_month_counts_from_first(self, tmp_path):
        now = time.time()
        # Record from 40 days ago (likely previous month)
        old = now - 86400 * 40

        _write_records(tmp_path, "agent-y", [
            _make_record("agent-y", timestamp=old, record_id="old-m",
                         parameters={"cost_usd": 50.0, "tokens": 5000}),
            _make_record("agent-y", timestamp=now - 60, record_id="new-m",
                         parameters={"cost_usd": 5.0, "tokens": 500}),
        ])

        store = LogStore(tmp_path, "audit")
        agg = FleetCostAggregator(audit_store=store)
        rec = agg.get_agent_cost("agent-y")
        assert rec.total_cost_usd == 55.0
        assert rec.cost_this_month_usd == 5.0

    def test_last_cost_at_is_most_recent(self, agg_with_data):
        agg, _ = agg_with_data
        rec = agg.get_agent_cost("bot-1")
        assert rec.last_cost_at is not None
        # Should be the timestamp of the third record (most recent)
        assert rec.last_cost_at > 0

    def test_avg_cost_per_action(self, agg_with_data):
        agg, _ = agg_with_data
        rec = agg.get_agent_cost("bot-1")
        expected_avg = (0.0012 + 0.0025 + 0.0008) / 3
        assert abs(rec.avg_cost_per_action_usd - expected_avg) < 1e-10

    def test_to_dict_roundtrip(self):
        rec = AgentCostRecord(
            agent_id="test",
            total_cost_usd=1.23,
            total_tokens=456,
            cost_today_usd=0.50,
            cost_this_month_usd=1.00,
            avg_cost_per_action_usd=0.01,
            evaluated_actions=100,
            last_cost_at=1000000.0,
        )
        d = rec.to_dict()
        assert d["agent_id"] == "test"
        assert d["total_cost_usd"] == 1.23
        assert d["total_tokens"] == 456
        assert d["cost_today_usd"] == 0.50
        assert d["cost_this_month_usd"] == 1.00
        assert d["avg_cost_per_action_usd"] == 0.01
        assert d["evaluated_actions"] == 100
        assert d["last_cost_at"] == 1000000.0

    def test_nonexistent_agent_returns_zeros(self, cost_store):
        agg = FleetCostAggregator(audit_store=cost_store)
        rec = agg.get_agent_cost("nonexistent")
        assert rec.agent_id == "nonexistent"
        assert rec.total_cost_usd == 0.0
        assert rec.total_tokens == 0
        assert rec.evaluated_actions == 0


# ── TestCostGroup ──────────────────────────────────────────────────────


class TestCostGroup:
    def test_creation_and_to_dict(self):
        group = CostGroup(
            group_id="prod",
            name="Production",
            agent_ids=["bot-1", "bot-2"],
            daily_budget_usd=10.0,
            monthly_budget_usd=200.0,
        )
        d = group.to_dict()
        assert d["group_id"] == "prod"
        assert d["name"] == "Production"
        assert d["agent_ids"] == ["bot-1", "bot-2"]
        assert d["daily_budget_usd"] == 10.0
        assert d["monthly_budget_usd"] == 200.0

    def test_optional_budget_fields_none(self):
        group = CostGroup(
            group_id="dev",
            name="Dev",
            agent_ids=["bot-a"],
        )
        d = group.to_dict()
        assert d["daily_budget_usd"] is None
        assert d["monthly_budget_usd"] is None

    def test_to_dict_roundtrip_with_budgets(self):
        group = CostGroup(
            group_id="staging",
            name="Staging Agents",
            agent_ids=["s1", "s2", "s3"],
            daily_budget_usd=5.0,
            monthly_budget_usd=100.0,
        )
        d = group.to_dict()
        assert d["group_id"] == "staging"
        assert len(d["agent_ids"]) == 3


# ── TestGroupCostSummary ──────────────────────────────────────────────


class TestGroupCostSummary:
    def test_to_dict_roundtrip(self):
        summary = GroupCostSummary(
            group_id="prod",
            group_name="Production",
            total_cost_usd=100.0,
            cost_today_usd=5.0,
            cost_this_month_usd=50.0,
            projected_daily_usd=10.0,
            projected_monthly_usd=150.0,
            daily_budget_usd=15.0,
            monthly_budget_usd=200.0,
            daily_budget_alert=False,
            monthly_budget_alert=False,
            agent_count=3,
        )
        d = summary.to_dict()
        assert d["group_id"] == "prod"
        assert d["total_cost_usd"] == 100.0
        assert d["daily_budget_alert"] is False
        assert d["monthly_budget_alert"] is False
        assert d["agent_count"] == 3

    def test_daily_budget_alert_true(self):
        summary = GroupCostSummary(
            group_id="g1",
            group_name="G1",
            total_cost_usd=100.0,
            cost_today_usd=8.0,
            cost_this_month_usd=50.0,
            projected_daily_usd=16.0,
            projected_monthly_usd=150.0,
            daily_budget_usd=10.0,
            monthly_budget_usd=200.0,
            daily_budget_alert=True,
            monthly_budget_alert=False,
            agent_count=2,
        )
        assert summary.daily_budget_alert is True

    def test_daily_budget_alert_false_under(self):
        summary = GroupCostSummary(
            group_id="g2",
            group_name="G2",
            total_cost_usd=10.0,
            cost_today_usd=2.0,
            cost_this_month_usd=10.0,
            projected_daily_usd=4.0,
            projected_monthly_usd=30.0,
            daily_budget_usd=10.0,
            monthly_budget_usd=200.0,
            daily_budget_alert=False,
            monthly_budget_alert=False,
            agent_count=1,
        )
        assert summary.daily_budget_alert is False

    def test_monthly_budget_alert_true(self):
        summary = GroupCostSummary(
            group_id="g3",
            group_name="G3",
            total_cost_usd=200.0,
            cost_today_usd=5.0,
            cost_this_month_usd=180.0,
            projected_daily_usd=10.0,
            projected_monthly_usd=250.0,
            daily_budget_usd=15.0,
            monthly_budget_usd=200.0,
            daily_budget_alert=False,
            monthly_budget_alert=True,
            agent_count=2,
        )
        assert summary.monthly_budget_alert is True

    def test_no_budget_both_alerts_false(self):
        summary = GroupCostSummary(
            group_id="g4",
            group_name="G4",
            total_cost_usd=999.0,
            cost_today_usd=99.0,
            cost_this_month_usd=999.0,
            projected_daily_usd=999.0,
            projected_monthly_usd=9999.0,
            daily_budget_usd=None,
            monthly_budget_usd=None,
            daily_budget_alert=False,
            monthly_budget_alert=False,
            agent_count=1,
        )
        assert summary.daily_budget_alert is False
        assert summary.monthly_budget_alert is False


# ── TestFleetCostAggregator ───────────────────────────────────────────


class TestFleetCostAggregator:
    def test_get_agent_cost_no_records_returns_zeros(self, cost_store):
        agg = FleetCostAggregator(audit_store=cost_store)
        rec = agg.get_agent_cost("ghost-agent")
        assert rec.total_cost_usd == 0.0
        assert rec.total_tokens == 0
        assert rec.evaluated_actions == 0

    def test_get_agent_cost_sums_correctly(self, agg_with_data):
        agg, _ = agg_with_data
        rec = agg.get_agent_cost("bot-2")
        assert abs(rec.total_cost_usd - 0.08) < 1e-10
        assert rec.total_tokens == 8000
        assert rec.evaluated_actions == 2

    def test_get_all_costs_sorted_by_total_desc(self, agg_with_data):
        agg, _ = agg_with_data
        all_costs = agg.get_all_costs()
        assert len(all_costs) == 3
        # bot-2 has highest cost (0.08), bot-1 second (0.0045), bot-3 zero
        assert all_costs[0].agent_id == "bot-2"
        assert all_costs[1].agent_id == "bot-1"
        assert all_costs[2].agent_id == "bot-3"
        # Verify descending order
        for i in range(len(all_costs) - 1):
            assert all_costs[i].total_cost_usd >= all_costs[i + 1].total_cost_usd

    def test_fleet_cost_today_sums_all(self, agg_with_data):
        agg, _ = agg_with_data
        total_today = agg.fleet_cost_today()
        # All records are recent (within today)
        expected = 0.0012 + 0.0025 + 0.0008 + 0.05 + 0.03
        assert abs(total_today - expected) < 1e-10

    def test_get_group_cost_unknown_group_raises(self, cost_store):
        agg = FleetCostAggregator(audit_store=cost_store)
        with pytest.raises(ValueError, match="Group not found: unknown"):
            agg.get_group_cost("unknown")

    def test_get_group_cost_valid_group(self, agg_with_data):
        agg, _ = agg_with_data
        group = CostGroup(
            group_id="prod",
            name="Production",
            agent_ids=["bot-1", "bot-2"],
            daily_budget_usd=10.0,
            monthly_budget_usd=200.0,
        )
        agg.add_group(group)
        summary = agg.get_group_cost("prod")
        assert summary.group_id == "prod"
        assert summary.group_name == "Production"
        assert summary.agent_count == 2
        expected_total = 0.0012 + 0.0025 + 0.0008 + 0.05 + 0.03
        assert abs(summary.total_cost_usd - expected_total) < 1e-10
        assert len(summary.agent_records) == 2

    def test_alerts_returns_over_budget_groups(self, agg_with_data):
        agg, _ = agg_with_data
        # Group with very low budget → will alert
        low_budget = CostGroup(
            group_id="tight",
            name="Tight Budget",
            agent_ids=["bot-1", "bot-2"],
            daily_budget_usd=0.001,
            monthly_budget_usd=0.01,
        )
        # Group with high budget → no alert
        high_budget = CostGroup(
            group_id="loose",
            name="Loose Budget",
            agent_ids=["bot-3"],
            daily_budget_usd=1000.0,
            monthly_budget_usd=10000.0,
        )
        agg.add_group(low_budget)
        agg.add_group(high_budget)

        alerts = agg.alerts()
        alert_ids = [a.group_id for a in alerts]
        assert "tight" in alert_ids
        assert "loose" not in alert_ids

    def test_alerts_empty_when_no_thresholds_exceeded(self, agg_with_data):
        agg, _ = agg_with_data
        group = CostGroup(
            group_id="generous",
            name="Generous",
            agent_ids=["bot-1"],
            daily_budget_usd=999999.0,
            monthly_budget_usd=999999.0,
        )
        agg.add_group(group)
        alerts = agg.alerts()
        assert len(alerts) == 0

    def test_add_group_registers_for_queries(self, cost_store):
        agg = FleetCostAggregator(audit_store=cost_store)
        group = CostGroup(
            group_id="new-group",
            name="New Group",
            agent_ids=["agent-a"],
        )
        # Before adding, should raise
        with pytest.raises(ValueError):
            agg.get_group_cost("new-group")

        agg.add_group(group)
        # After adding, should work
        summary = agg.get_group_cost("new-group")
        assert summary.group_id == "new-group"

    def test_constructor_with_groups(self, cost_store):
        groups = [
            CostGroup(group_id="g1", name="Group 1", agent_ids=["a1"]),
            CostGroup(group_id="g2", name="Group 2", agent_ids=["a2"]),
        ]
        agg = FleetCostAggregator(audit_store=cost_store, groups=groups)
        # Both groups should be accessible
        s1 = agg.get_group_cost("g1")
        s2 = agg.get_group_cost("g2")
        assert s1.group_name == "Group 1"
        assert s2.group_name == "Group 2"

    def test_alerts_with_no_budget_set(self, agg_with_data):
        agg, _ = agg_with_data
        group = CostGroup(
            group_id="no-budget",
            name="No Budget",
            agent_ids=["bot-1"],
        )
        agg.add_group(group)
        alerts = agg.alerts()
        # No budget → never alerts
        assert all(a.group_id != "no-budget" for a in alerts)

    def test_fleet_cost_today_empty_store(self, cost_store):
        agg = FleetCostAggregator(audit_store=cost_store)
        assert agg.fleet_cost_today() == 0.0


# ── TestProjections ──────────────────────────────────────────────────


class TestProjections:
    def test_projected_daily_positive_when_cost_today_positive(self, agg_with_data):
        agg, _ = agg_with_data
        group = CostGroup(
            group_id="proj-test",
            name="Projection Test",
            agent_ids=["bot-1"],
        )
        agg.add_group(group)
        summary = agg.get_group_cost("proj-test")
        if summary.cost_today_usd > 0:
            assert summary.projected_daily_usd > 0

    def test_projected_daily_larger_than_current_early_in_day(self, agg_with_data):
        agg, _ = agg_with_data
        group = CostGroup(
            group_id="early-test",
            name="Early Test",
            agent_ids=["bot-1"],
        )
        agg.add_group(group)

        # Mock early in the day (2 hours past midnight)
        now = datetime.now(timezone.utc)
        early_morning = now.replace(hour=2, minute=0, second=0, microsecond=0)

        with patch("nomotic.fleet.datetime") as mock_dt:
            mock_dt.now.return_value = early_morning
            mock_dt.side_effect = lambda *args, **kw: datetime(*args, **kw)
            summary = agg.get_group_cost("early-test")

        if summary.cost_today_usd > 0:
            # Projection should be larger than current cost early in the day
            assert summary.projected_daily_usd >= summary.cost_today_usd

    def test_projected_monthly_positive(self, agg_with_data):
        agg, _ = agg_with_data
        group = CostGroup(
            group_id="month-test",
            name="Month Test",
            agent_ids=["bot-2"],
        )
        agg.add_group(group)
        summary = agg.get_group_cost("month-test")
        if summary.cost_this_month_usd > 0:
            assert summary.projected_monthly_usd > 0

    def test_projection_compute_method(self, cost_store):
        agg = FleetCostAggregator(audit_store=cost_store)
        daily, monthly = agg._compute_projections(5.0, 50.0)
        assert daily >= 5.0  # Projection should be >= current
        assert monthly >= 50.0

    def test_projection_zero_cost(self, cost_store):
        agg = FleetCostAggregator(audit_store=cost_store)
        daily, monthly = agg._compute_projections(0.0, 0.0)
        assert daily == 0.0
        assert monthly == 0.0


# ── TestCostExports ──────────────────────────────────────────────────


class TestCostExports:
    def test_import_from_nomotic(self):
        from nomotic import (
            AgentCostRecord,
            CostGroup,
            FleetCostAggregator,
            GroupCostSummary,
        )
        assert FleetCostAggregator is not None
        assert CostGroup is not None
        assert AgentCostRecord is not None
        assert GroupCostSummary is not None

    def test_import_from_fleet_module(self):
        from nomotic.fleet import (
            AgentCostRecord,
            CostGroup,
            FleetCostAggregator,
            GroupCostSummary,
        )
        assert FleetCostAggregator is not None
        assert CostGroup is not None
        assert AgentCostRecord is not None
        assert GroupCostSummary is not None

    def test_in_fleet_module_all(self):
        from nomotic import fleet
        assert "FleetCostAggregator" in fleet.__all__
        assert "CostGroup" in fleet.__all__
        assert "AgentCostRecord" in fleet.__all__
        assert "GroupCostSummary" in fleet.__all__
