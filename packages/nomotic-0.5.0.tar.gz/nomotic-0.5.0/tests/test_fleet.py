"""Tests for the Fleet Governance API."""

import time

import pytest

from nomotic.audit_store import LogStore, PersistentLogRecord
from nomotic.fleet import (
    AgentFleetRecord,
    FleetDenialRecord,
    FleetGovernor,
    FleetHealthSummary,
)


# ── Helpers ────────────────────────────────────────────────────────────


def _write_records(base_dir, agent_id, records):
    """Write audit records for an agent to temp dir."""
    store = LogStore(base_dir, "audit")
    for r in records:
        store.append(PersistentLogRecord(**r))


def _make_record(
    agent_id="test-agent",
    action_type="read",
    verdict="ALLOW",
    trust_score=0.65,
    trust_delta=0.01,
    trust_trend="rising",
    timestamp=None,
    **kwargs,
):
    """Build a record dict suitable for PersistentLogRecord."""
    return {
        "record_id": kwargs.get("record_id", f"r-{time.time_ns()}"),
        "timestamp": timestamp or time.time(),
        "agent_id": agent_id,
        "action_type": action_type,
        "action_target": kwargs.get("action_target", "db"),
        "verdict": verdict,
        "ucs": kwargs.get("ucs", 0.85),
        "tier": kwargs.get("tier", 2),
        "trust_score": trust_score,
        "trust_delta": trust_delta,
        "trust_trend": trust_trend,
        "severity": kwargs.get("severity", "info"),
        "justification": kwargs.get("justification", "ok"),
    }


def _recent_ts(hours_ago=0):
    """Return a timestamp hours_ago hours in the past."""
    return time.time() - (hours_ago * 3600)


def _old_ts(hours_ago=48):
    """Return a timestamp far enough in the past to be outside the 24h window."""
    return time.time() - (hours_ago * 3600)


def _setup_three_agents(tmp_path):
    """Set up three agents: one healthy, one warning, one critical."""
    now = time.time()
    recent = now - 3600  # 1 hour ago
    old = now - 200000  # ~55 hours ago

    # Healthy agent: high trust, low denial rate, recent activity
    healthy_records = [
        _make_record("healthy-bot", verdict="ALLOW", trust_score=0.80, trust_trend="rising", timestamp=recent, record_id="h1"),
        _make_record("healthy-bot", verdict="ALLOW", trust_score=0.82, trust_trend="rising", timestamp=recent + 1, record_id="h2"),
        _make_record("healthy-bot", verdict="ALLOW", trust_score=0.83, trust_trend="rising", timestamp=recent + 2, record_id="h3"),
        _make_record("healthy-bot", verdict="DENY", trust_score=0.81, trust_trend="stable", timestamp=recent + 3, record_id="h4"),
        _make_record("healthy-bot", verdict="ALLOW", trust_score=0.82, trust_trend="rising", timestamp=recent + 4, record_id="h5"),
    ]

    # Warning agent: trust 0.45, denial rate ~40%
    warning_records = [
        _make_record("warning-bot", verdict="ALLOW", trust_score=0.45, trust_trend="falling", timestamp=recent, record_id="w1"),
        _make_record("warning-bot", verdict="DENY", trust_score=0.43, trust_trend="falling", timestamp=recent + 1, record_id="w2"),
        _make_record("warning-bot", verdict="ALLOW", trust_score=0.44, trust_trend="stable", timestamp=recent + 2, record_id="w3"),
        _make_record("warning-bot", verdict="DENY", trust_score=0.42, trust_trend="falling", timestamp=recent + 3, record_id="w4"),
        _make_record("warning-bot", verdict="ALLOW", trust_score=0.45, trust_trend="stable", timestamp=recent + 4, record_id="w5"),
    ]

    # Critical agent: trust 0.18, high denial rate
    critical_records = [
        _make_record("critical-bot", verdict="DENY", trust_score=0.22, trust_trend="falling", timestamp=recent, record_id="c1"),
        _make_record("critical-bot", verdict="DENY", trust_score=0.20, trust_trend="falling", timestamp=recent + 1, record_id="c2"),
        _make_record("critical-bot", verdict="DENY", trust_score=0.18, trust_trend="falling", timestamp=recent + 2, record_id="c3"),
        _make_record("critical-bot", verdict="ALLOW", trust_score=0.19, trust_trend="falling", timestamp=recent + 3, record_id="c4"),
        _make_record("critical-bot", verdict="DENY", trust_score=0.18, trust_trend="falling", timestamp=recent + 4, record_id="c5"),
    ]

    _write_records(tmp_path, "healthy-bot", healthy_records)
    _write_records(tmp_path, "warning-bot", warning_records)
    _write_records(tmp_path, "critical-bot", critical_records)

    return healthy_records, warning_records, critical_records


@pytest.fixture
def fleet_store(tmp_path):
    """Create a LogStore for fleet tests."""
    return LogStore(tmp_path, "audit")


@pytest.fixture
def fleet_three(tmp_path):
    """Set up three agents and return a FleetGovernor."""
    _setup_three_agents(tmp_path)
    store = LogStore(tmp_path, "audit")
    return FleetGovernor(audit_store=store)


# ── TestFleetHealthSummary ─────────────────────────────────────────────


class TestFleetHealthSummary:
    def test_empty_audit_dir(self, tmp_path):
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        summary = fleet.health_summary()
        assert summary.total_agents == 0
        assert summary.active_agents == 0
        assert summary.critical_agents == 0
        assert summary.warning_agents == 0
        assert summary.healthy_agents == 0
        assert summary.total_evaluations_24h == 0
        assert summary.fleet_denial_rate == 0.0

    def test_three_agents_classifications(self, fleet_three):
        summary = fleet_three.health_summary()
        assert summary.total_agents == 3
        assert summary.critical_agents == 1
        assert summary.warning_agents == 1
        assert summary.healthy_agents == 1

    def test_total_evaluations_24h_counts_only_recent(self, tmp_path):
        now = time.time()
        old = now - 200000  # far past
        recent = now - 3600

        records_old = [
            _make_record("agent-a", timestamp=old, record_id="o1"),
            _make_record("agent-a", timestamp=old + 1, record_id="o2"),
        ]
        records_recent = [
            _make_record("agent-a", timestamp=recent, record_id="r1"),
            _make_record("agent-a", timestamp=recent + 1, record_id="r2"),
            _make_record("agent-a", timestamp=recent + 2, record_id="r3"),
        ]
        _write_records(tmp_path, "agent-a", records_old + records_recent)

        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        summary = fleet.health_summary()
        assert summary.total_evaluations_24h == 3

    def test_fleet_denial_rate_computed_correctly(self, fleet_three):
        summary = fleet_three.health_summary()
        # healthy: 1 deny out of 5 = 0.2
        # warning: 2 deny out of 5 = 0.4
        # critical: 4 deny out of 5 = 0.8
        # total: 7 deny out of 15
        expected = 7 / 15
        assert abs(summary.fleet_denial_rate - expected) < 0.01

    def test_active_agents_excludes_no_recent(self, tmp_path):
        old = time.time() - 200000
        records = [
            _make_record("old-bot", timestamp=old, record_id="x1"),
        ]
        _write_records(tmp_path, "old-bot", records)

        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        summary = fleet.health_summary()
        assert summary.total_agents == 1
        assert summary.active_agents == 0

    def test_computed_at_set(self, tmp_path):
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        before = time.time()
        summary = fleet.health_summary()
        after = time.time()
        assert before <= summary.computed_at <= after


# ── TestTrustDistribution ──────────────────────────────────────────────


class TestTrustDistribution:
    def test_high_trust_band(self, tmp_path):
        _write_records(tmp_path, "high-agent", [
            _make_record("high-agent", trust_score=0.80, record_id="t1"),
        ])
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        dist = fleet.trust_distribution()
        assert dist["high"] == 1
        assert dist["medium"] == 0
        assert dist["low"] == 0
        assert dist["critical"] == 0

    def test_medium_trust_band(self, tmp_path):
        _write_records(tmp_path, "med-agent", [
            _make_record("med-agent", trust_score=0.50, record_id="t1"),
        ])
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        dist = fleet.trust_distribution()
        assert dist["medium"] == 1

    def test_low_trust_band(self, tmp_path):
        _write_records(tmp_path, "low-agent", [
            _make_record("low-agent", trust_score=0.25, record_id="t1"),
        ])
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        dist = fleet.trust_distribution()
        assert dist["low"] == 1

    def test_critical_trust_band(self, tmp_path):
        _write_records(tmp_path, "crit-agent", [
            _make_record("crit-agent", trust_score=0.15, record_id="t1"),
        ])
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        dist = fleet.trust_distribution()
        assert dist["critical"] == 1

    def test_multiple_agents_across_bands(self, fleet_three):
        dist = fleet_three.trust_distribution()
        # healthy-bot: 0.82 → high
        # warning-bot: 0.45 → medium
        # critical-bot: 0.18 → critical
        assert dist["high"] == 1
        assert dist["medium"] == 1
        assert dist["critical"] == 1
        assert dist["low"] == 0

    def test_empty_store(self, tmp_path):
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        dist = fleet.trust_distribution()
        assert dist == {"high": 0, "medium": 0, "low": 0, "critical": 0}

    def test_boundary_0_7(self, tmp_path):
        _write_records(tmp_path, "boundary", [
            _make_record("boundary", trust_score=0.7, record_id="t1"),
        ])
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        dist = fleet.trust_distribution()
        assert dist["high"] == 1

    def test_boundary_0_4(self, tmp_path):
        _write_records(tmp_path, "boundary", [
            _make_record("boundary", trust_score=0.4, record_id="t1"),
        ])
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        dist = fleet.trust_distribution()
        assert dist["medium"] == 1

    def test_boundary_0_2(self, tmp_path):
        _write_records(tmp_path, "boundary", [
            _make_record("boundary", trust_score=0.2, record_id="t1"),
        ])
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        dist = fleet.trust_distribution()
        assert dist["low"] == 1


# ── TestDenialRate ─────────────────────────────────────────────────────


class TestDenialRate:
    def test_all_allow(self, tmp_path):
        recent = time.time() - 3600
        _write_records(tmp_path, "good-agent", [
            _make_record("good-agent", verdict="ALLOW", timestamp=recent, record_id="a1"),
            _make_record("good-agent", verdict="ALLOW", timestamp=recent + 1, record_id="a2"),
        ])
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        assert fleet.denial_rate(agent_id="good-agent") == 0.0

    def test_all_deny(self, tmp_path):
        recent = time.time() - 3600
        _write_records(tmp_path, "bad-agent", [
            _make_record("bad-agent", verdict="DENY", timestamp=recent, record_id="d1"),
            _make_record("bad-agent", verdict="DENY", timestamp=recent + 1, record_id="d2"),
        ])
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        assert fleet.denial_rate(agent_id="bad-agent") == 1.0

    def test_mixed_ratio(self, tmp_path):
        recent = time.time() - 3600
        _write_records(tmp_path, "mix-agent", [
            _make_record("mix-agent", verdict="ALLOW", timestamp=recent, record_id="m1"),
            _make_record("mix-agent", verdict="DENY", timestamp=recent + 1, record_id="m2"),
            _make_record("mix-agent", verdict="ALLOW", timestamp=recent + 2, record_id="m3"),
            _make_record("mix-agent", verdict="DENY", timestamp=recent + 3, record_id="m4"),
        ])
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        assert fleet.denial_rate(agent_id="mix-agent") == 0.5

    def test_no_records_in_window(self, tmp_path):
        old = time.time() - 200000
        _write_records(tmp_path, "old-agent", [
            _make_record("old-agent", verdict="DENY", timestamp=old, record_id="o1"),
        ])
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        assert fleet.denial_rate(agent_id="old-agent") == 0.0

    def test_fleet_wide_rate(self, fleet_three):
        rate = fleet_three.denial_rate(agent_id=None)
        # 7 denials out of 15 records
        assert abs(rate - 7 / 15) < 0.01

    def test_fleet_wide_empty(self, tmp_path):
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        assert fleet.denial_rate() == 0.0


# ── TestAgentsByStatus ─────────────────────────────────────────────────


class TestAgentsByStatus:
    def test_critical_returns_only_critical(self, fleet_three):
        agents = fleet_three.agents_by_status("critical")
        assert len(agents) == 1
        assert agents[0].agent_id == "critical-bot"
        assert agents[0].status == "critical"

    def test_healthy_returns_only_healthy(self, fleet_three):
        agents = fleet_three.agents_by_status("healthy")
        assert len(agents) == 1
        assert agents[0].agent_id == "healthy-bot"
        assert agents[0].status == "healthy"

    def test_warning_returns_only_warning(self, fleet_three):
        agents = fleet_three.agents_by_status("warning")
        assert len(agents) == 1
        assert agents[0].agent_id == "warning-bot"

    def test_sorted_by_last_activity_descending(self, tmp_path):
        now = time.time()
        # Two healthy agents with different last_activity
        _write_records(tmp_path, "early-bot", [
            _make_record("early-bot", trust_score=0.80, timestamp=now - 7200, record_id="e1"),
        ])
        _write_records(tmp_path, "late-bot", [
            _make_record("late-bot", trust_score=0.80, timestamp=now - 3600, record_id="l1"),
        ])
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        agents = fleet.agents_by_status("healthy")
        assert len(agents) == 2
        assert agents[0].agent_id == "late-bot"
        assert agents[1].agent_id == "early-bot"

    def test_critical_agents_alias(self, fleet_three):
        direct = fleet_three.agents_by_status("critical")
        alias = fleet_three.critical_agents()
        assert len(direct) == len(alias)
        assert direct[0].agent_id == alias[0].agent_id

    def test_inactive_status(self, tmp_path):
        old = time.time() - 200000
        _write_records(tmp_path, "old-bot", [
            _make_record("old-bot", trust_score=0.80, timestamp=old, record_id="o1"),
        ])
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        agents = fleet.agents_by_status("inactive")
        assert len(agents) == 1
        assert agents[0].agent_id == "old-bot"


# ── TestTopDeniedActionTypes ───────────────────────────────────────────


class TestTopDeniedActionTypes:
    def test_no_denials(self, tmp_path):
        recent = time.time() - 3600
        _write_records(tmp_path, "good", [
            _make_record("good", verdict="ALLOW", timestamp=recent, record_id="g1"),
        ])
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        assert fleet.top_denied_action_types() == []

    def test_aggregates_across_agents(self, tmp_path):
        recent = time.time() - 3600
        _write_records(tmp_path, "agent-a", [
            _make_record("agent-a", action_type="delete_user", verdict="DENY", timestamp=recent, record_id="a1"),
            _make_record("agent-a", action_type="delete_user", verdict="DENY", timestamp=recent + 1, record_id="a2"),
        ])
        _write_records(tmp_path, "agent-b", [
            _make_record("agent-b", action_type="delete_user", verdict="DENY", timestamp=recent, record_id="b1"),
        ])
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        results = fleet.top_denied_action_types()
        assert len(results) == 1
        assert results[0].action_type == "delete_user"
        assert results[0].deny_count == 3
        assert results[0].agent_count == 2

    def test_top_agent_is_most_denying(self, tmp_path):
        recent = time.time() - 3600
        _write_records(tmp_path, "agent-a", [
            _make_record("agent-a", action_type="export_data", verdict="DENY", timestamp=recent, record_id="a1"),
            _make_record("agent-a", action_type="export_data", verdict="DENY", timestamp=recent + 1, record_id="a2"),
            _make_record("agent-a", action_type="export_data", verdict="DENY", timestamp=recent + 2, record_id="a3"),
        ])
        _write_records(tmp_path, "agent-b", [
            _make_record("agent-b", action_type="export_data", verdict="DENY", timestamp=recent, record_id="b1"),
        ])
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        results = fleet.top_denied_action_types()
        assert results[0].top_agent == "agent-a"

    def test_limit_parameter(self, tmp_path):
        recent = time.time() - 3600
        for i, action in enumerate(["act_a", "act_b", "act_c", "act_d"]):
            _write_records(tmp_path, f"agent-{i}", [
                _make_record(f"agent-{i}", action_type=action, verdict="DENY",
                             timestamp=recent, record_id=f"r{i}"),
            ])
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        results = fleet.top_denied_action_types(limit=2)
        assert len(results) == 2

    def test_sorted_by_deny_count(self, tmp_path):
        recent = time.time() - 3600
        # act_a: 3 denials, act_b: 1 denial
        _write_records(tmp_path, "agent-x", [
            _make_record("agent-x", action_type="act_a", verdict="DENY", timestamp=recent, record_id="r1"),
            _make_record("agent-x", action_type="act_a", verdict="DENY", timestamp=recent + 1, record_id="r2"),
            _make_record("agent-x", action_type="act_a", verdict="DENY", timestamp=recent + 2, record_id="r3"),
            _make_record("agent-x", action_type="act_b", verdict="DENY", timestamp=recent + 3, record_id="r4"),
        ])
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        results = fleet.top_denied_action_types()
        assert results[0].action_type == "act_a"
        assert results[0].deny_count == 3
        assert results[1].action_type == "act_b"
        assert results[1].deny_count == 1


# ── TestGetAgentRecord ─────────────────────────────────────────────────


class TestGetAgentRecord:
    def test_agent_with_records(self, tmp_path):
        recent = time.time() - 3600
        _write_records(tmp_path, "my-agent", [
            _make_record("my-agent", trust_score=0.75, timestamp=recent, record_id="r1"),
        ])
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        record = fleet.get_agent_record("my-agent")
        assert record is not None
        assert record.agent_id == "my-agent"
        assert record.current_trust == 0.75

    def test_unknown_agent(self, tmp_path):
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        assert fleet.get_agent_record("nonexistent") is None

    def test_fields_populated(self, tmp_path):
        now = time.time()
        recent = now - 3600
        _write_records(tmp_path, "detail-bot", [
            _make_record("detail-bot", verdict="ALLOW", trust_score=0.70, trust_trend="rising",
                         timestamp=recent, record_id="r1"),
            _make_record("detail-bot", verdict="DENY", trust_score=0.68, trust_trend="falling",
                         timestamp=recent + 1, record_id="r2"),
        ])
        store = LogStore(tmp_path, "audit")
        fleet = FleetGovernor(audit_store=store)
        record = fleet.get_agent_record("detail-bot")
        assert record is not None
        assert record.total_evaluations == 2
        assert record.evaluations_24h == 2
        assert record.denial_rate == 0.5
        assert record.current_trust == 0.68
        assert record.trust_trend == "falling"
        assert record.last_activity is not None
        assert record.last_activity > recent


# ── TestFleetDataclass ─────────────────────────────────────────────────


class TestFleetDataclass:
    def test_health_summary_to_dict_roundtrip(self):
        summary = FleetHealthSummary(
            total_agents=10,
            active_agents=8,
            critical_agents=2,
            warning_agents=1,
            healthy_agents=5,
            total_evaluations_24h=100,
            fleet_denial_rate=0.15,
            computed_at=1234567890.0,
        )
        d = summary.to_dict()
        assert d["total_agents"] == 10
        assert d["active_agents"] == 8
        assert d["critical_agents"] == 2
        assert d["warning_agents"] == 1
        assert d["healthy_agents"] == 5
        assert d["total_evaluations_24h"] == 100
        assert d["fleet_denial_rate"] == 0.15
        assert d["computed_at"] == 1234567890.0

    def test_agent_fleet_record_to_dict_roundtrip(self):
        record = AgentFleetRecord(
            agent_id="test-bot",
            total_evaluations=50,
            evaluations_24h=10,
            denial_rate=0.2,
            current_trust=0.75,
            trust_trend="rising",
            last_activity=1234567890.0,
            status="healthy",
        )
        d = record.to_dict()
        assert d["agent_id"] == "test-bot"
        assert d["total_evaluations"] == 50
        assert d["evaluations_24h"] == 10
        assert d["denial_rate"] == 0.2
        assert d["current_trust"] == 0.75
        assert d["trust_trend"] == "rising"
        assert d["last_activity"] == 1234567890.0
        assert d["status"] == "healthy"

    def test_fleet_denial_record_to_dict_roundtrip(self):
        record = FleetDenialRecord(
            action_type="delete_user",
            deny_count=42,
            agent_count=7,
            top_agent="bad-bot",
        )
        d = record.to_dict()
        assert d["action_type"] == "delete_user"
        assert d["deny_count"] == 42
        assert d["agent_count"] == 7
        assert d["top_agent"] == "bad-bot"


# ── TestFleetExports ───────────────────────────────────────────────────


class TestFleetExports:
    def test_import_from_nomotic(self):
        from nomotic import (
            AgentFleetRecord,
            FleetDenialRecord,
            FleetGovernor,
            FleetHealthSummary,
        )
        assert FleetGovernor is not None
        assert FleetHealthSummary is not None
        assert AgentFleetRecord is not None
        assert FleetDenialRecord is not None

    def test_import_from_fleet_module(self):
        from nomotic.fleet import (
            AgentFleetRecord,
            FleetDenialRecord,
            FleetGovernor,
            FleetHealthSummary,
        )
        assert FleetGovernor is not None
        assert FleetHealthSummary is not None
        assert AgentFleetRecord is not None
        assert FleetDenialRecord is not None
