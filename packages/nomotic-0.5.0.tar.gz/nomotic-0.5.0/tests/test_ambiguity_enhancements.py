"""Tests for ambiguity drift enhancements: UAHS delta fields, UCSTracker delegation, GovernanceHealthStore."""

from __future__ import annotations

import json
import tempfile
import time
from pathlib import Path
from unittest import TestCase

from nomotic.drift import (
    AUDIT_ALARM_DETECTED,
    AUDIT_BAND_WIDTH_MODIFIED,
    AUDIT_STATUS_BOUNDARY_CROSSED,
    AUDIT_TRUST_CALIBRATION_APPLIED,
    AUDIT_UAHS_COMPUTED,
    AmbiguityDriftConfig,
    AmbiguityDriftObserver,
    AmbiguityDriftProfile,
    FeedbackLoopManager,
    UnifiedAgentHealthScore,
    UnifiedHealthScoreCalculator,
    compute_ambiguity_health_score,
    persist_health_events,
)
from nomotic.audit_store import GovernanceHealthRecord, GovernanceHealthStore
from nomotic.trust import TrustCalibrator, TrustConfig
from nomotic.ucs_tracker import AgentRegistration, UCSTracker


# ── Enhancement 1: Audit event field completeness ─────────────────────


class TestStatusBoundaryCrossedFields(TestCase):
    """1. STATUS_BOUNDARY_CROSSED contains uahs_delta, primary_signal, alarm_active."""

    def test_crossing_event_has_delta_fields(self) -> None:
        flm = FeedbackLoopManager()
        observer = AmbiguityDriftObserver()
        cfg = AmbiguityDriftConfig(window_size=10)
        observer.observe("a1", ucs=0.50, verdict="ALLOW", config=cfg)
        tc = TrustCalibrator(TrustConfig(baseline_trust=0.50))
        tc.get_profile("a1")

        prev = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.80, oversight_score=0.80, ambiguity_score=0.70,
        )
        self.assertEqual(prev.health_status, "good")

        current = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.60, oversight_score=0.60, ambiguity_score=0.60,
        )
        self.assertEqual(current.health_status, "watch")

        events = flm.process("a1", current, prev, observer, tc, confidence=1.0)
        crossing_events = [e for e in events if e["event_type"] == AUDIT_STATUS_BOUNDARY_CROSSED]
        self.assertEqual(len(crossing_events), 1)
        ce = crossing_events[0]
        self.assertIn("uahs_delta", ce)
        self.assertEqual(ce["uahs_delta"], current.unified_score - prev.unified_score)
        self.assertIn("primary_signal", ce)
        self.assertEqual(ce["primary_signal"], current.primary_signal)
        self.assertIn("alarm_active", ce)
        self.assertIsInstance(ce["alarm_active"], bool)


class TestTrustCalibrationPenaltyFields(TestCase):
    """2-3. TRUST_CALIBRATION_APPLIED penalty/recovery events contain new fields."""

    def test_penalty_event_fields(self) -> None:
        flm = FeedbackLoopManager()
        observer = AmbiguityDriftObserver()
        cfg = AmbiguityDriftConfig(window_size=10)
        observer.observe("a1", ucs=0.50, verdict="ALLOW", config=cfg)
        tc = TrustCalibrator(TrustConfig(baseline_trust=0.50))
        tc.get_profile("a1")

        prev = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.80, oversight_score=0.80, ambiguity_score=0.70,
        )
        current = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.60, oversight_score=0.60, ambiguity_score=0.60,
        )
        events = flm.process("a1", current, prev, observer, tc, confidence=1.0)
        trust_events = [e for e in events if e["event_type"] == AUDIT_TRUST_CALIBRATION_APPLIED]
        penalty_events = [e for e in trust_events if e.get("adjustment_type") == "penalty"]
        self.assertTrue(len(penalty_events) > 0)
        pe = penalty_events[0]
        self.assertEqual(pe["uahs_at_trigger"], current.unified_score)
        self.assertEqual(pe["adjustment_type"], "penalty")
        self.assertTrue(pe["confidence_scaled"])

    def test_recovery_event_fields(self) -> None:
        flm = FeedbackLoopManager()
        observer = AmbiguityDriftObserver()
        cfg = AmbiguityDriftConfig(window_size=10)
        observer.observe("a1", ucs=0.50, verdict="ALLOW", config=cfg)
        tc = TrustCalibrator(TrustConfig(baseline_trust=0.50))
        tc.get_profile("a1")

        prev = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.50, oversight_score=0.50, ambiguity_score=0.50,
        )
        # Need +10 points recovery
        current = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.80, oversight_score=0.80, ambiguity_score=0.80,
        )
        self.assertGreaterEqual(current.unified_score - prev.unified_score, 10)

        events = flm.process("a1", current, prev, observer, tc, confidence=1.0)
        trust_events = [e for e in events if e["event_type"] == AUDIT_TRUST_CALIBRATION_APPLIED]
        recovery_events = [e for e in trust_events if e.get("adjustment_type") == "recovery"]
        self.assertTrue(len(recovery_events) > 0)
        re = recovery_events[0]
        self.assertEqual(re["uahs_at_trigger"], current.unified_score)
        self.assertEqual(re["adjustment_type"], "recovery")
        self.assertFalse(re["confidence_scaled"])


class TestBandWidthModifiedFields(TestCase):
    """4-5. BAND_WIDTH_MODIFIED contains uahs_at_modification, prior bands, floor_constraint_applied."""

    def test_narrowing_event_has_band_fields(self) -> None:
        flm = FeedbackLoopManager()
        observer = AmbiguityDriftObserver()
        cfg = AmbiguityDriftConfig(window_size=10, band_low=0.30, band_high=0.70)
        observer.observe("a1", ucs=0.50, verdict="ALLOW", config=cfg)

        prev = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.80, oversight_score=0.80, ambiguity_score=0.70,
        )
        current = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.60, oversight_score=0.60, ambiguity_score=0.60,
        )
        events = flm.process("a1", current, prev, observer, confidence=1.0)
        band_events = [e for e in events if e["event_type"] == AUDIT_BAND_WIDTH_MODIFIED]
        self.assertTrue(len(band_events) > 0)
        be = band_events[0]
        self.assertIn("uahs_at_modification", be)
        self.assertEqual(be["uahs_at_modification"], current.unified_score)
        self.assertIn("prior_band_low", be)
        self.assertIn("prior_band_high", be)
        self.assertAlmostEqual(be["prior_band_low"], 0.30, places=2)
        self.assertAlmostEqual(be["prior_band_high"], 0.70, places=2)
        self.assertIn("floor_constraint_applied", be)
        # With default floor matching band, no constraint applied
        self.assertFalse(be["floor_constraint_applied"])

    def test_floor_constraint_applied_true(self) -> None:
        """5. floor_constraint_applied=True when floor clamps the adjustment."""
        flm = FeedbackLoopManager()
        observer = AmbiguityDriftObserver()
        # Start with band already near the floor constraint
        cfg = AmbiguityDriftConfig(window_size=10, band_low=0.30, band_high=0.70)
        observer.observe("a1", ucs=0.50, verdict="ALLOW", config=cfg)

        prev = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.40, oversight_score=0.40, ambiguity_score=0.40,
        )
        self.assertEqual(prev.health_status, "warning")
        current = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.20, oversight_score=0.20, ambiguity_score=0.20,
        )
        self.assertEqual(current.health_status, "critical")

        # Use tight floor_low=0.30, floor_high=0.70 — adjust_band clamps at floor+0.10 and floor-0.10
        # warning->critical narrowing = 0.04
        # requested_low = 0.30 + 0.04 = 0.34, but floor constraint: min(0.34, 0.30+0.10)=0.34 — passes
        # Use very tight floors to trigger clamping
        events = flm.process(
            "a1", current, prev, observer,
            confidence=1.0, floor_low=0.29, floor_high=0.71,
        )
        band_events = [e for e in events if e["event_type"] == AUDIT_BAND_WIDTH_MODIFIED]
        self.assertTrue(len(band_events) > 0)
        # The floor constraint caps band_low at floor_low + 0.10 = 0.39
        # and band_high at max(requested, floor_high - 0.10) = max(0.66, 0.61) = 0.66
        # So requested_low=0.34 < 0.39 cap, meaning floor DOES apply for low:
        # Actually adjust_band: effective_band_low = min(new_band_low, floor_low + 0.10)
        # = min(0.34, 0.39) = 0.34. And effective_band_high = max(0.66, 0.61) = 0.66
        # That means floor doesn't clamp here. Let me use a tighter scenario.
        # Let me set floor_low=0.33 so floor_low+0.10=0.43 > 0.34 → clamped at floor
        # Actually: adjust_band clamps: effective_band_low = min(new_band_low, floor_low + 0.10)
        # That means it picks the LOWER of (requested, floor+0.10), which is a maximum narrowing check.
        # So if requested_low=0.34 and floor_low+0.10=0.43, then effective = min(0.34, 0.43) = 0.34
        # Hmm, this means floor_low+0.10 is the MAX that band_low can reach.
        # So if requested is 0.34 and limit is 0.43, min gives 0.34 which is below the limit = no clamp.
        # The floor kicks in when requested EXCEEDS the limit.
        # So we need requested_low > floor_low + 0.10.
        # With floor_low=0.20 and band_low=0.30, narrowing=0.04 → requested=0.34 > 0.30 = floor_low+0.10
        # Yes! That triggers the clamp. floor_low=0.20, floor_low+0.10=0.30
        pass

    def test_floor_constraint_detected(self) -> None:
        """5. floor_constraint_applied is True when narrowing exceeds floor limit."""
        flm = FeedbackLoopManager()
        observer = AmbiguityDriftObserver()
        cfg = AmbiguityDriftConfig(window_size=10, band_low=0.30, band_high=0.70)
        observer.observe("a1", ucs=0.50, verdict="ALLOW", config=cfg)

        prev = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.40, oversight_score=0.40, ambiguity_score=0.40,
        )
        self.assertEqual(prev.health_status, "warning")
        current = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.20, oversight_score=0.20, ambiguity_score=0.20,
        )
        self.assertEqual(current.health_status, "critical")

        # floor_low=0.20, so floor_low+0.10 = 0.30 is the max band_low can reach.
        # requested_low = 0.30 + 0.04 = 0.34 > 0.30 → clamped to 0.30
        # floor_high=0.80, so floor_high-0.10 = 0.70 is min band_high can reach.
        # requested_high = 0.70 - 0.04 = 0.66 < 0.70 → clamped to 0.70
        # Both are clamped → floor_constraint_applied = True
        events = flm.process(
            "a1", current, prev, observer,
            confidence=1.0, floor_low=0.20, floor_high=0.80,
        )
        band_events = [e for e in events if e["event_type"] == AUDIT_BAND_WIDTH_MODIFIED]
        self.assertTrue(len(band_events) > 0)
        be = band_events[0]
        self.assertTrue(be["floor_constraint_applied"])


class TestAlarmDetectedEvent(TestCase):
    """6-8. AUDIT_ALARM_DETECTED emitted on False→True edge; get/set alarm event."""

    def _trigger_alarm(self, observer: AmbiguityDriftObserver, agent_id: str = "a1") -> AmbiguityDriftProfile:
        """Produce conditions for compound alarm: rising ambiguity + accept bias + falling override.

        Uses the same proven pattern as test_ambiguity_drift.py:TestCompoundAlarm.
        Phase 1: low ambiguity baseline with out-of-band entries first, then
        in-band DENYs with overrides last (so they remain in buffer during phase 2).
        Phase 2: push in-band ALLOWs with no overrides to shift all three trends.
        """
        cfg = AmbiguityDriftConfig(
            window_size=20, band_low=0.30, band_high=0.70,
            rise_threshold=0.15, fall_threshold=0.15,
            accept_drift_threshold=0.10, baseline_ema_alpha=0.05,
        )
        # Phase 1: establish baseline with low ambiguity rate.
        # Out-of-band first, in-band DENYs with overrides last.
        for i in range(20):
            if i < 16:
                observer.observe(agent_id, ucs=0.10, verdict="DENY",
                                 was_human_override=False, config=cfg)
            else:
                observer.observe(agent_id, ucs=0.50, verdict="DENY",
                                 was_human_override=True, config=cfg)

        # Phase 2: push in-band ALLOWs with no overrides
        for _ in range(10):
            observer.observe(agent_id, ucs=0.50, verdict="ALLOW",
                             was_human_override=False, config=cfg)

        return observer.get_profile(agent_id)

    def test_alarm_emitted_on_edge(self) -> None:
        """6. Alarm event emitted only on False→True transition."""
        observer = AmbiguityDriftObserver()
        self.assertIsNone(observer.get_alarm_event("a1"))

        profile = self._trigger_alarm(observer)
        self.assertTrue(profile.alert)
        alarm_event = observer.get_alarm_event("a1")
        self.assertIsNotNone(alarm_event)
        self.assertEqual(alarm_event["event_type"], AUDIT_ALARM_DETECTED)
        self.assertEqual(alarm_event["agent_id"], "a1")
        self.assertIn("ambiguity_rate_at_detection", alarm_event)
        self.assertIn("resolution_bias_at_detection", alarm_event)
        self.assertIn("human_override_rate_at_detection", alarm_event)
        self.assertIn("alert_reason", alarm_event)
        self.assertIsNone(alarm_event["uahs_delta_at_detection"])

    def test_alarm_not_emitted_when_already_active(self) -> None:
        """6. No duplicate alarm events on repeated recomputes."""
        observer = AmbiguityDriftObserver()
        self._trigger_alarm(observer)
        event1 = observer.get_alarm_event("a1")
        ts1 = event1["timestamp"]

        # Additional observations while alarm is active
        cfg = AmbiguityDriftConfig(window_size=50, band_low=0.30, band_high=0.70)
        for _ in range(10):
            observer.observe("a1", ucs=0.50, verdict="ALLOW", config=cfg)

        event2 = observer.get_alarm_event("a1")
        # Same event (not replaced)
        self.assertEqual(event2["timestamp"], ts1)

    def test_set_alarm_uahs_delta(self) -> None:
        """7. set_alarm_uahs_delta updates the alarm record."""
        observer = AmbiguityDriftObserver()
        self._trigger_alarm(observer)

        observer.set_alarm_uahs_delta("a1", -15)
        alarm = observer.get_alarm_event("a1")
        self.assertEqual(alarm["uahs_delta_at_detection"], -15)

        # Second call should NOT overwrite (already set)
        observer.set_alarm_uahs_delta("a1", -20)
        alarm = observer.get_alarm_event("a1")
        self.assertEqual(alarm["uahs_delta_at_detection"], -15)

    def test_get_alarm_event_none_before_alarm(self) -> None:
        """8. get_alarm_event returns None before alarm fires."""
        observer = AmbiguityDriftObserver()
        self.assertIsNone(observer.get_alarm_event("nonexistent"))
        cfg = AmbiguityDriftConfig(window_size=10)
        observer.observe("a1", ucs=0.50, verdict="ALLOW", config=cfg)
        self.assertIsNone(observer.get_alarm_event("a1"))


class TestToAuditEvent(TestCase):
    """9. UnifiedAgentHealthScore.to_audit_event() includes alarm_mode_weights_active."""

    def test_alarm_mode_active_true(self) -> None:
        score = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.50, oversight_score=0.50, ambiguity_score=0.50,
            behavioral_weight=0.30, oversight_weight=0.25, ambiguity_weight=0.45,
        )
        event = score.to_audit_event()
        self.assertEqual(event["event_type"], AUDIT_UAHS_COMPUTED)
        self.assertTrue(event["alarm_mode_weights_active"])

    def test_alarm_mode_active_false(self) -> None:
        score = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.90, oversight_score=0.90, ambiguity_score=0.90,
        )
        event = score.to_audit_event()
        self.assertFalse(event["alarm_mode_weights_active"])
        self.assertEqual(event["unified_score"], score.unified_score)
        self.assertIn("behavioral_score", event)
        self.assertIn("oversight_score", event)
        self.assertIn("ambiguity_score", event)


# ── Enhancement 2: UCSTracker delegation ──────────────────────────────


class TestRootAgentRegistration(TestCase):
    """10. Root agent registers with no inheritance — band is config default."""

    def test_root_agent_default_band(self) -> None:
        tracker = UCSTracker()
        cfg = AmbiguityDriftConfig(band_low=0.30, band_high=0.70)
        effective = tracker.register_agent(AgentRegistration(
            agent_id="root", config=cfg,
        ))
        self.assertAlmostEqual(effective.band_low, 0.30, places=4)
        self.assertAlmostEqual(effective.band_high, 0.70, places=4)


class TestSubAgentDepth1Inheritance(TestCase):
    """11. Sub-agent at depth=1 inherits narrower band from principal."""

    def test_depth1_band_narrowing(self) -> None:
        tracker = UCSTracker()
        cfg = AmbiguityDriftConfig(band_low=0.30, band_high=0.70)
        tracker.register_agent(AgentRegistration(
            agent_id="root", config=cfg,
        ))

        sub_cfg = AmbiguityDriftConfig(band_low=0.30, band_high=0.70)
        effective = tracker.register_agent(AgentRegistration(
            agent_id="sub-1", config=sub_cfg,
            delegation_depth=1, principal_agent_id="root",
            floor_low=0.25, floor_high=0.75,  # floor_low+0.10=0.35 > 0.32, so no cap
        ))
        # hop_adj = 1 * 0.02 = 0.02
        # inherited_low = 0.30 + 0.02 = 0.32, floor cap = min(0.32, 0.35) = 0.32
        # effective_low = max(0.30, 0.32) = 0.32
        self.assertGreaterEqual(effective.band_low, 0.32 - 1e-9)
        # inherited_high = 0.70 - 0.02 = 0.68
        # effective_high = min(0.70, 0.68) = 0.68
        self.assertLessEqual(effective.band_high, 0.68 + 1e-9)


class TestSubAgentDepth2Inheritance(TestCase):
    """12. Sub-agent at depth=2 applies 0.04 total hop narrowing."""

    def test_depth2_band_narrowing(self) -> None:
        tracker = UCSTracker()
        cfg = AmbiguityDriftConfig(band_low=0.30, band_high=0.70)
        tracker.register_agent(AgentRegistration(
            agent_id="root", config=cfg,
        ))
        tracker.register_agent(AgentRegistration(
            agent_id="sub-1", config=cfg,
            delegation_depth=1, principal_agent_id="root",
            floor_low=0.25, floor_high=0.75,
        ))
        effective = tracker.register_agent(AgentRegistration(
            agent_id="sub-2", config=cfg,
            delegation_depth=2, principal_agent_id="sub-1",
            floor_low=0.30, floor_high=0.70,  # floor_low+0.10=0.40 > 0.36
        ))
        # sub-1's effective config: band_low=0.32, band_high=0.68
        # For sub-2: principal is sub-1, gets config bands from _agent_configs
        # hop_adj = 2 * 0.02 = 0.04
        # inherited_low = 0.32 + 0.04 = 0.36
        # inherited_high = 0.68 - 0.04 = 0.64
        # effective_low = max(0.30, 0.36) = 0.36, floor cap = min(0.36, 0.40) = 0.36
        # effective_high = min(0.70, 0.64) = 0.64
        self.assertGreaterEqual(effective.band_low, 0.36 - 1e-9)
        self.assertLessEqual(effective.band_high, 0.64 + 1e-9)


class TestSubAgentNotWiderThanPrincipal(TestCase):
    """13. Sub-agent band cannot be wider than principal's current band."""

    def test_sub_band_constrained(self) -> None:
        tracker = UCSTracker()
        # Principal with narrow band
        principal_cfg = AmbiguityDriftConfig(band_low=0.40, band_high=0.60)
        tracker.register_agent(AgentRegistration(
            agent_id="root", config=principal_cfg,
        ))
        # Sub-agent tries to have wider band
        sub_cfg = AmbiguityDriftConfig(band_low=0.20, band_high=0.80)
        effective = tracker.register_agent(AgentRegistration(
            agent_id="sub-1", config=sub_cfg,
            delegation_depth=1, principal_agent_id="root",
            floor_low=0.35, floor_high=0.65,  # floor_low+0.10=0.45 > 0.42
        ))
        # inherited_low = 0.40 + 0.02 = 0.42
        # effective_low = max(0.20, 0.42) = 0.42, floor cap = min(0.42, 0.45) = 0.42
        # inherited_high = 0.60 - 0.02 = 0.58
        # effective_high = min(0.80, 0.58) = 0.58
        self.assertGreaterEqual(effective.band_low, 0.42 - 1e-9)
        self.assertLessEqual(effective.band_high, 0.58 + 1e-9)


class TestFloorConstraintDuringInheritance(TestCase):
    """14. Floor constraint respected during inheritance."""

    def test_floor_caps_inheritance(self) -> None:
        tracker = UCSTracker()
        cfg = AmbiguityDriftConfig(band_low=0.30, band_high=0.70)
        tracker.register_agent(AgentRegistration(
            agent_id="root", config=cfg,
        ))
        # Sub with very deep depth — would push band very narrow
        deep_cfg = AmbiguityDriftConfig(band_low=0.30, band_high=0.70)
        effective = tracker.register_agent(AgentRegistration(
            agent_id="deep", config=deep_cfg,
            delegation_depth=10, principal_agent_id="root",
            floor_low=0.20, floor_high=0.80,
        ))
        # hop_adj = 10 * 0.02 = 0.20
        # inherited_low = 0.30 + 0.20 = 0.50
        # effective_low = max(0.30, 0.50) = 0.50
        # But floor constraint: effective_low = min(0.50, 0.20 + 0.10) = min(0.50, 0.30) = 0.30
        self.assertLessEqual(effective.band_low, 0.30 + 1e-9)


class TestDelegationChainBands(TestCase):
    """15. get_delegation_chain_bands returns correct chain for three-level delegation."""

    def test_three_level_chain(self) -> None:
        tracker = UCSTracker()
        cfg = AmbiguityDriftConfig(band_low=0.30, band_high=0.70)
        tracker.register_agent(AgentRegistration(agent_id="root", config=cfg))
        tracker.register_agent(AgentRegistration(
            agent_id="mid", config=cfg, delegation_depth=1, principal_agent_id="root",
            floor_low=0.25, floor_high=0.75,
        ))
        tracker.register_agent(AgentRegistration(
            agent_id="leaf", config=cfg, delegation_depth=2, principal_agent_id="mid",
            floor_low=0.30, floor_high=0.70,
        ))

        chain = tracker.get_delegation_chain_bands("leaf")
        self.assertIn("leaf", chain)
        self.assertIn("mid", chain)
        self.assertIn("root", chain)
        self.assertEqual(len(chain), 3)

        # Root band should be the widest
        root_low, root_high = chain["root"]
        leaf_low, leaf_high = chain["leaf"]
        self.assertLessEqual(root_low, leaf_low + 1e-9)
        self.assertGreaterEqual(root_high, leaf_high - 1e-9)


class TestSubAgentBeforePrincipal(TestCase):
    """16. Sub-agent registered before principal falls back to config defaults."""

    def test_sub_before_principal_uses_own_config(self) -> None:
        tracker = UCSTracker()
        sub_cfg = AmbiguityDriftConfig(band_low=0.35, band_high=0.65)
        # Register sub before principal exists — principal not found
        # Falls back to sub's own config for principal bands
        effective = tracker.register_agent(AgentRegistration(
            agent_id="sub-1", config=sub_cfg,
            delegation_depth=1, principal_agent_id="unknown-root",
            floor_low=0.30, floor_high=0.70,  # floor_low+0.10=0.40 > 0.37
        ))
        # principal_low = 0.35 (own config fallback), principal_high = 0.65
        # hop_adj = 1 * 0.02 = 0.02
        # inherited_low = 0.35 + 0.02 = 0.37
        # effective_low = max(0.35, 0.37) = 0.37, floor cap = min(0.37, 0.40) = 0.37
        self.assertAlmostEqual(effective.band_low, 0.37, places=4)


class TestRecordUsesRegisteredConfig(TestCase):
    """17. record() uses agent's registered config, not default."""

    def test_record_uses_agent_config(self) -> None:
        tracker = UCSTracker()
        custom_cfg = AmbiguityDriftConfig(
            window_size=20, band_low=0.40, band_high=0.60,
        )
        tracker.register_agent(AgentRegistration(
            agent_id="a1", config=custom_cfg,
        ))
        # Record observations — they should use custom band
        for _ in range(10):
            tracker.record("a1", ucs=0.50, verdict="ALLOW")

        profile = tracker.get_profile("a1")
        self.assertIsNotNone(profile)
        self.assertAlmostEqual(profile.band_low, 0.40, places=4)
        self.assertAlmostEqual(profile.band_high, 0.60, places=4)


# ── Enhancement 3: GovernanceHealthStore ──────────────────────────────


class TestHealthStoreHashChain(TestCase):
    """18-19. append_health_event sets hashes; second record chains correctly."""

    def test_hash_chain_fields_set(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            store = GovernanceHealthStore(Path(tmpdir))
            rec1 = GovernanceHealthRecord(
                record_id="r1", timestamp=1.0, agent_id="a1",
                event_type=AUDIT_UAHS_COMPUTED, severity="info",
                uahs_after=80, data={"event_type": AUDIT_UAHS_COMPUTED},
            )
            store.append_health_event(rec1)
            self.assertNotEqual(rec1.record_hash, "")
            self.assertEqual(rec1.previous_hash, "")

            rec2 = GovernanceHealthRecord(
                record_id="r2", timestamp=2.0, agent_id="a1",
                event_type=AUDIT_STATUS_BOUNDARY_CROSSED, severity="alert",
                uahs_before=80, uahs_after=60, uahs_delta=-20,
                data={"event_type": AUDIT_STATUS_BOUNDARY_CROSSED},
            )
            store.append_health_event(rec2)
            self.assertEqual(rec2.previous_hash, rec1.record_hash)
            self.assertNotEqual(rec2.record_hash, "")


class TestVerifyHealthChain(TestCase):
    """20-21. verify_health_chain returns correct results."""

    def test_intact_chain_valid(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            store = GovernanceHealthStore(Path(tmpdir))
            for i in range(5):
                rec = GovernanceHealthRecord(
                    record_id=f"r{i}", timestamp=float(i), agent_id="a1",
                    event_type=AUDIT_UAHS_COMPUTED, severity="info",
                    data={"event_type": AUDIT_UAHS_COMPUTED, "i": i},
                )
                store.append_health_event(rec)
            valid, count, msg = store.verify_health_chain("a1")
            self.assertTrue(valid)
            self.assertEqual(count, 5)
            self.assertEqual(msg, "")

    def test_tampered_chain_detected(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            store = GovernanceHealthStore(Path(tmpdir))
            for i in range(3):
                rec = GovernanceHealthRecord(
                    record_id=f"r{i}", timestamp=float(i), agent_id="a1",
                    event_type=AUDIT_UAHS_COMPUTED, severity="info",
                    data={"event_type": AUDIT_UAHS_COMPUTED, "i": i},
                )
                store.append_health_event(rec)

            # Tamper with the file
            path = store._agent_file("a1")
            lines = path.read_text().strip().split("\n")
            record = json.loads(lines[1])
            record["uahs_after"] = 999
            lines[1] = json.dumps(record, separators=(",", ":"))
            path.write_text("\n".join(lines) + "\n")

            valid, count, msg = store.verify_health_chain("a1")
            self.assertFalse(valid)
            self.assertIn("TAMPERING", msg)


class TestQueryHealth(TestCase):
    """22-23. query_health filters by event_type and returns most recent first."""

    def test_filter_by_event_type(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            store = GovernanceHealthStore(Path(tmpdir))
            store.append_health_event(GovernanceHealthRecord(
                record_id="r1", timestamp=1.0, agent_id="a1",
                event_type=AUDIT_UAHS_COMPUTED, severity="info",
                data={"event_type": AUDIT_UAHS_COMPUTED},
            ))
            store.append_health_event(GovernanceHealthRecord(
                record_id="r2", timestamp=2.0, agent_id="a1",
                event_type=AUDIT_STATUS_BOUNDARY_CROSSED, severity="alert",
                data={"event_type": AUDIT_STATUS_BOUNDARY_CROSSED},
            ))
            store.append_health_event(GovernanceHealthRecord(
                record_id="r3", timestamp=3.0, agent_id="a1",
                event_type=AUDIT_UAHS_COMPUTED, severity="info",
                data={"event_type": AUDIT_UAHS_COMPUTED},
            ))

            results = store.query_health("a1", event_type=AUDIT_UAHS_COMPUTED)
            self.assertEqual(len(results), 2)
            for r in results:
                self.assertEqual(r.event_type, AUDIT_UAHS_COMPUTED)

    def test_most_recent_first(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            store = GovernanceHealthStore(Path(tmpdir))
            for i in range(5):
                store.append_health_event(GovernanceHealthRecord(
                    record_id=f"r{i}", timestamp=float(i), agent_id="a1",
                    event_type=AUDIT_UAHS_COMPUTED, severity="info",
                    data={"event_type": AUDIT_UAHS_COMPUTED},
                ))
            results = store.query_health("a1")
            self.assertEqual(len(results), 5)
            self.assertEqual(results[0].record_id, "r4")
            self.assertEqual(results[-1].record_id, "r0")


class TestPersistHealthEvents(TestCase):
    """24-25. persist_health_events converts dicts with correct uahs_delta and severity."""

    def test_uahs_delta_set_correctly(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            store = GovernanceHealthStore(Path(tmpdir))
            prev = UnifiedAgentHealthScore(
                agent_id="a1", timestamp=time.time(),
                behavioral_score=0.80, oversight_score=0.80, ambiguity_score=0.70,
            )
            current = UnifiedAgentHealthScore(
                agent_id="a1", timestamp=time.time(),
                behavioral_score=0.60, oversight_score=0.60, ambiguity_score=0.60,
            )
            events = [{
                "event_type": AUDIT_STATUS_BOUNDARY_CROSSED,
                "agent_id": "a1",
                "timestamp": time.time(),
            }]
            persist_health_events(events, store, current_uahs=current, prev_uahs=prev)
            records = store.query_health("a1")
            self.assertEqual(len(records), 1)
            rec = records[0]
            self.assertEqual(rec.uahs_before, prev.unified_score)
            self.assertEqual(rec.uahs_after, current.unified_score)
            self.assertEqual(rec.uahs_delta, current.unified_score - prev.unified_score)

    def test_severity_mapping(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            store = GovernanceHealthStore(Path(tmpdir))
            events = [
                {"event_type": AUDIT_UAHS_COMPUTED, "agent_id": "a1", "timestamp": 1.0},
                {"event_type": AUDIT_STATUS_BOUNDARY_CROSSED, "agent_id": "a1", "timestamp": 2.0},
                {"event_type": AUDIT_TRUST_CALIBRATION_APPLIED, "agent_id": "a1", "timestamp": 3.0},
                {"event_type": AUDIT_BAND_WIDTH_MODIFIED, "agent_id": "a1", "timestamp": 4.0},
                {"event_type": AUDIT_ALARM_DETECTED, "agent_id": "a1", "timestamp": 5.0},
            ]
            persist_health_events(events, store)
            records = store.query_health("a1", limit=100)
            severity_by_type = {r.event_type: r.severity for r in records}
            self.assertEqual(severity_by_type[AUDIT_UAHS_COMPUTED], "info")
            self.assertEqual(severity_by_type[AUDIT_STATUS_BOUNDARY_CROSSED], "alert")
            self.assertEqual(severity_by_type[AUDIT_TRUST_CALIBRATION_APPLIED], "warning")
            self.assertEqual(severity_by_type[AUDIT_BAND_WIDTH_MODIFIED], "warning")
            self.assertEqual(severity_by_type[AUDIT_ALARM_DETECTED], "alert")


# ── Integration test ──────────────────────────────────────────────────


class TestFullPipelineIntegration(TestCase):
    """26. Full pipeline: register -> observe -> alarm -> UAHS -> feedback -> persist -> verify."""

    def test_end_to_end(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            store = GovernanceHealthStore(Path(tmpdir))
            tracker = UCSTracker()

            # Register principal and sub-agent
            cfg = AmbiguityDriftConfig(
                window_size=20, band_low=0.30, band_high=0.70,
                rise_threshold=0.15, fall_threshold=0.15,
                accept_drift_threshold=0.10, baseline_ema_alpha=0.05,
            )
            tracker.register_agent(AgentRegistration(
                agent_id="principal", config=cfg,
            ))
            effective_sub = tracker.register_agent(AgentRegistration(
                agent_id="sub-agent", config=cfg,
                delegation_depth=1, principal_agent_id="principal",
                floor_low=0.25, floor_high=0.75,
            ))
            # Sub-agent band should be narrower
            self.assertGreater(effective_sub.band_low, cfg.band_low)
            self.assertLess(effective_sub.band_high, cfg.band_high)

            # Phase 1: baseline with low ambiguity rate
            for i in range(20):
                if i < 16:
                    tracker.record("sub-agent", ucs=0.10, verdict="DENY",
                                   was_human_override=False)
                else:
                    tracker.record("sub-agent", ucs=0.50, verdict="DENY",
                                   was_human_override=True)

            # Phase 2: trigger alarm — in-band ALLOW, no overrides
            for _ in range(10):
                tracker.record("sub-agent", ucs=0.50, verdict="ALLOW",
                               was_human_override=False)

            profile = tracker.get_profile("sub-agent")
            self.assertTrue(profile.alert)

            # Check alarm event was recorded
            alarm_event = tracker.get_observer().get_alarm_event("sub-agent")
            self.assertIsNotNone(alarm_event)

            # Compute UAHS
            calc = UnifiedHealthScoreCalculator()
            prev_score = calc.compute(
                "sub-agent",
                behavioral_drift_score=0.10,
                oversight_degradation_score=0.10,
                ambiguity_profile=AmbiguityDriftProfile(
                    agent_id="sub-agent", window_size=50,
                    ambiguity_rate=0.20, resolution_bias=0.0,
                    human_override_rate_in_band=0.50,
                ),
            )
            current_score = calc.compute(
                "sub-agent",
                behavioral_drift_score=0.30,
                oversight_degradation_score=0.30,
                ambiguity_profile=profile,
                prev_score=prev_score.unified_score,
            )

            # Alarm mode weights should be active since profile.alert is True
            self.assertEqual(current_score.ambiguity_weight, 0.45)
            audit_event = current_score.to_audit_event()
            self.assertTrue(audit_event["alarm_mode_weights_active"])

            # Link UAHS delta to alarm
            uahs_delta = current_score.unified_score - prev_score.unified_score
            tracker.get_observer().set_alarm_uahs_delta("sub-agent", uahs_delta)

            # FeedbackLoopManager processes
            flm = FeedbackLoopManager()
            feedback_events = flm.process(
                "sub-agent", current_score, prev_score,
                tracker.get_observer(),
            )

            # Combine all events
            all_events = [audit_event, alarm_event] + feedback_events

            # Persist
            persist_health_events(all_events, store, current_uahs=current_score, prev_uahs=prev_score)

            # Verify chain integrity
            valid, count, msg = store.verify_health_chain("sub-agent")
            self.assertTrue(valid, f"Chain verification failed: {msg}")
            self.assertGreater(count, 0)

            # Query specific event types
            crossing_records = store.query_health(
                "sub-agent", event_type=AUDIT_STATUS_BOUNDARY_CROSSED,
            )
            # May or may not have crossing depending on score difference
            # But we should have alarm and UAHS events
            alarm_records = store.query_health(
                "sub-agent", event_type=AUDIT_ALARM_DETECTED,
            )
            self.assertEqual(len(alarm_records), 1)
            self.assertEqual(alarm_records[0].severity, "alert")

            uahs_records = store.query_health(
                "sub-agent", event_type=AUDIT_UAHS_COMPUTED,
            )
            self.assertEqual(len(uahs_records), 1)

            # Verify delegation chain
            chain = tracker.get_delegation_chain_bands("sub-agent")
            self.assertIn("sub-agent", chain)
            self.assertIn("principal", chain)
