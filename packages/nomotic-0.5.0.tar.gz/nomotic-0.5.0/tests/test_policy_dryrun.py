"""Tests for Policy Dry-Run Mode — testing policies against audit history."""

import tempfile
import time
from pathlib import Path

import pytest

from nomotic.audit_store import LogStore, PersistentLogRecord
from nomotic.policy import (
    DryRunResult,
    PolicyDryRunner,
    PolicyEngine,
    PolicyLoadError,
    PolicyRule,
    SimulatedOverride,
)
from nomotic.types import Action, AgentContext, TrustProfile


# ── Sample policy YAML content ────────────────────────────────────────

DENY_DELETE_POLICY = """\
rules:
  - name: deny-all-deletes
    when:
      action_type: delete
    then:
      verdict: DENY
      reason: "Deletes blocked in dry-run test"
"""

ESCALATE_WRITE_POLICY = """\
rules:
  - name: escalate-all-writes
    when:
      action_type: write
    then:
      verdict: ESCALATE
      reason: "Writes require human review"
"""

DENY_AND_ESCALATE_POLICY = """\
rules:
  - name: deny-all-deletes
    when:
      action_type: delete
    then:
      verdict: DENY
      reason: "Deletes blocked"
  - name: escalate-all-writes
    when:
      action_type: write
    then:
      verdict: ESCALATE
      reason: "Writes require human review"
"""

MATCH_NOTHING_POLICY = """\
rules:
  - name: deny-nonexistent
    when:
      action_type: nonexistent_action_type_xyz
    then:
      verdict: DENY
      reason: "Matches nothing"
"""

DENY_TARGET_POLICY = """\
rules:
  - name: deny-external
    when:
      target: "external/*"
    then:
      verdict: DENY
      reason: "No external access"
"""


# ── Helpers ──────────────────────────────────────────────────────────

def _write_policy_yaml(base: Path, content: str, name: str = "test.yaml") -> Path:
    policy_file = base / name
    policy_file.write_text(content)
    return policy_file


def _make_record(
    record_id: str,
    agent_id: str = "bot",
    action_type: str = "read",
    action_target: str = "db",
    verdict: str = "ALLOW",
    timestamp: float | None = None,
    parameters: dict | None = None,
) -> PersistentLogRecord:
    return PersistentLogRecord(
        record_id=record_id,
        timestamp=timestamp or time.time(),
        agent_id=agent_id,
        action_type=action_type,
        action_target=action_target,
        verdict=verdict,
        ucs=0.8 if verdict == "ALLOW" else 0.2,
        tier=2,
        trust_score=0.65,
        trust_delta=0.0,
        trust_trend="stable",
        severity="info" if verdict == "ALLOW" else "alert",
        justification="test",
        parameters=parameters or {},
    )


def _populate_store(store: LogStore, records: list[PersistentLogRecord]) -> None:
    for rec in records:
        store.append(rec)


# ── TestDryRunResult ────────────────────────────────────────────────


class TestDryRunResult:
    """Tests for DryRunResult dataclass."""

    def test_to_dict_includes_all_fields(self):
        result = DryRunResult(
            policy_file="test.yaml",
            agent_id="bot",
            records_evaluated=10,
            matched_count=5,
            would_deny=[{"record_id": "r1"}],
            would_escalate=[{"record_id": "r2"}, {"record_id": "r3"}],
            already_denied=2,
            new_denials=1,
            new_escalations=2,
            days_of_data=7,
        )
        d = result.to_dict()
        assert d["policy_file"] == "test.yaml"
        assert d["agent_id"] == "bot"
        assert d["records_evaluated"] == 10
        assert d["matched_count"] == 5
        assert d["would_deny_count"] == 1
        assert d["would_escalate_count"] == 2
        assert d["already_denied"] == 2
        assert d["new_denials"] == 1
        assert d["new_escalations"] == 2
        assert d["days_of_data"] == 7
        assert d["would_deny"] == [{"record_id": "r1"}]
        assert d["would_escalate"] == [{"record_id": "r2"}, {"record_id": "r3"}]

    def test_new_denials_from_would_deny_length(self):
        result = DryRunResult(
            policy_file="x", agent_id=None, records_evaluated=0,
            matched_count=0, would_deny=[{"a": 1}, {"b": 2}],
            would_escalate=[], already_denied=0,
            new_denials=2, new_escalations=0, days_of_data=1,
        )
        assert result.new_denials == len(result.would_deny)

    def test_new_escalations_from_would_escalate_length(self):
        result = DryRunResult(
            policy_file="x", agent_id=None, records_evaluated=0,
            matched_count=0, would_deny=[], would_escalate=[{"a": 1}],
            already_denied=0, new_denials=0, new_escalations=1, days_of_data=1,
        )
        assert result.new_escalations == len(result.would_escalate)

    def test_agent_id_none_for_fleet_wide(self):
        result = DryRunResult(
            policy_file="x", agent_id=None, records_evaluated=0,
            matched_count=0, would_deny=[], would_escalate=[],
            already_denied=0, new_denials=0, new_escalations=0, days_of_data=1,
        )
        assert result.agent_id is None
        assert result.to_dict()["agent_id"] is None


# ── TestPolicyDryRunner ─────────────────────────────────────────────


class TestPolicyDryRunner:
    """Tests for PolicyDryRunner core functionality."""

    @pytest.fixture()
    def setup(self, tmp_path):
        """Create a store with 10 ALLOW + 2 DENY records."""
        store = LogStore(tmp_path, "audit")
        now = time.time()
        records = []
        # 5 delete ALLOW records
        for i in range(5):
            records.append(_make_record(
                f"del-{i}", action_type="delete", verdict="ALLOW",
                timestamp=now - 3600 * (i + 1),
            ))
        # 5 read ALLOW records
        for i in range(5):
            records.append(_make_record(
                f"read-{i}", action_type="read", verdict="ALLOW",
                timestamp=now - 3600 * (i + 1),
            ))
        # 2 DENY records (delete)
        for i in range(2):
            records.append(_make_record(
                f"deny-{i}", action_type="delete", verdict="DENY",
                timestamp=now - 3600 * (i + 1),
            ))
        _populate_store(store, records)
        policy_file = _write_policy_yaml(tmp_path, DENY_DELETE_POLICY)
        return store, policy_file, tmp_path

    def test_run_evaluates_all_records(self, setup):
        store, policy_file, _ = setup
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id="bot", days=7)
        assert result.records_evaluated == 12

    def test_new_denials_for_delete_policy(self, setup):
        store, policy_file, _ = setup
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id="bot", days=7)
        # 5 ALLOW delete records should become new denials
        assert result.new_denials == 5

    def test_already_denied_count(self, setup):
        store, policy_file, _ = setup
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id="bot", days=7)
        assert result.already_denied == 2

    def test_would_deny_list_contents(self, setup):
        store, policy_file, _ = setup
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id="bot", days=7)
        assert len(result.would_deny) == 5
        for entry in result.would_deny:
            assert "record_id" in entry
            assert entry["action_type"] == "delete"
            assert entry["original_verdict"] == "ALLOW"

    def test_matched_count(self, setup):
        store, policy_file, _ = setup
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id="bot", days=7)
        # All delete records (5 ALLOW + 2 DENY) match the deny-all-deletes policy
        assert result.matched_count == 7

    def test_escalate_policy(self, tmp_path):
        """Policy that only escalates → new_escalations > 0, new_denials == 0."""
        store = LogStore(tmp_path, "audit")
        now = time.time()
        records = [
            _make_record("w-0", action_type="write", verdict="ALLOW", timestamp=now - 100),
            _make_record("w-1", action_type="write", verdict="ALLOW", timestamp=now - 200),
            _make_record("r-0", action_type="read", verdict="ALLOW", timestamp=now - 300),
        ]
        _populate_store(store, records)
        policy_file = _write_policy_yaml(tmp_path, ESCALATE_WRITE_POLICY)
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id="bot", days=7)
        assert result.new_escalations == 2
        assert result.new_denials == 0

    def test_agent_id_none_evaluates_all_agents(self, tmp_path):
        """agent_id=None → evaluates all agents in the store."""
        store = LogStore(tmp_path, "audit")
        now = time.time()
        _populate_store(store, [
            _make_record("a-0", agent_id="agent-a", action_type="delete",
                         verdict="ALLOW", timestamp=now - 100),
            _make_record("b-0", agent_id="agent-b", action_type="delete",
                         verdict="ALLOW", timestamp=now - 200),
        ])
        policy_file = _write_policy_yaml(tmp_path, DENY_DELETE_POLICY)
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id=None, days=7)
        assert result.records_evaluated == 2
        assert result.new_denials == 2
        assert result.agent_id is None

    def test_agent_id_filters_to_specific_agent(self, tmp_path):
        """agent_id='specific-agent' → only evaluates that agent's records."""
        store = LogStore(tmp_path, "audit")
        now = time.time()
        _populate_store(store, [
            _make_record("a-0", agent_id="agent-a", action_type="delete",
                         verdict="ALLOW", timestamp=now - 100),
            _make_record("b-0", agent_id="agent-b", action_type="delete",
                         verdict="ALLOW", timestamp=now - 200),
        ])
        policy_file = _write_policy_yaml(tmp_path, DENY_DELETE_POLICY)
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id="agent-a", days=7)
        assert result.records_evaluated == 1
        assert result.new_denials == 1
        deny_ids = [e["record_id"] for e in result.would_deny]
        assert "a-0" in deny_ids

    def test_days_filter(self, tmp_path):
        """days=1 → only records from last 24h."""
        store = LogStore(tmp_path, "audit")
        now = time.time()
        _populate_store(store, [
            _make_record("recent", action_type="delete", verdict="ALLOW",
                         timestamp=now - 3600),  # 1 hour ago
            _make_record("old", action_type="delete", verdict="ALLOW",
                         timestamp=now - 172800),  # 2 days ago
        ])
        policy_file = _write_policy_yaml(tmp_path, DENY_DELETE_POLICY)
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id="bot", days=1)
        assert result.records_evaluated == 1
        assert result.new_denials == 1

    def test_max_records_cap(self, tmp_path):
        """max_records=5 → caps at 5 records regardless of total available."""
        store = LogStore(tmp_path, "audit")
        now = time.time()
        records = [
            _make_record(f"r-{i}", action_type="delete", verdict="ALLOW",
                         timestamp=now - 100 * (10 - i))
            for i in range(10)
        ]
        _populate_store(store, records)
        policy_file = _write_policy_yaml(tmp_path, DENY_DELETE_POLICY)
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id="bot", days=7, max_records=5)
        assert result.records_evaluated == 5

    def test_invalid_policy_file_raises(self, tmp_path):
        """Invalid policy file path → raises exception."""
        store = LogStore(tmp_path, "audit")
        runner = PolicyDryRunner(audit_store=store)
        with pytest.raises(PolicyLoadError, match="not found"):
            runner.run(tmp_path / "nonexistent.yaml", agent_id="bot", days=7)

    def test_policy_matches_nothing(self, tmp_path):
        """Policy that matches nothing → matched_count == 0, new_denials == 0."""
        store = LogStore(tmp_path, "audit")
        now = time.time()
        _populate_store(store, [
            _make_record("r-0", action_type="read", verdict="ALLOW", timestamp=now - 100),
            _make_record("r-1", action_type="write", verdict="ALLOW", timestamp=now - 200),
        ])
        policy_file = _write_policy_yaml(tmp_path, MATCH_NOTHING_POLICY)
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id="bot", days=7)
        assert result.matched_count == 0
        assert result.new_denials == 0
        assert result.new_escalations == 0

    def test_deny_entry_has_policy_name_and_reason(self, tmp_path):
        store = LogStore(tmp_path, "audit")
        now = time.time()
        _populate_store(store, [
            _make_record("del-0", action_type="delete", verdict="ALLOW", timestamp=now - 100),
        ])
        policy_file = _write_policy_yaml(tmp_path, DENY_DELETE_POLICY)
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id="bot", days=7)
        assert len(result.would_deny) == 1
        entry = result.would_deny[0]
        assert entry["policy_name"] == "deny-all-deletes"
        assert entry["policy_reason"] == "Deletes blocked in dry-run test"

    def test_empty_store_returns_zero_results(self, tmp_path):
        store = LogStore(tmp_path, "audit")
        policy_file = _write_policy_yaml(tmp_path, DENY_DELETE_POLICY)
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id="bot", days=7)
        assert result.records_evaluated == 0
        assert result.matched_count == 0
        assert result.new_denials == 0

    def test_multi_rule_policy(self, tmp_path):
        """Policy with both DENY and ESCALATE rules."""
        store = LogStore(tmp_path, "audit")
        now = time.time()
        _populate_store(store, [
            _make_record("del-0", action_type="delete", verdict="ALLOW", timestamp=now - 100),
            _make_record("wr-0", action_type="write", verdict="ALLOW", timestamp=now - 200),
            _make_record("rd-0", action_type="read", verdict="ALLOW", timestamp=now - 300),
        ])
        policy_file = _write_policy_yaml(tmp_path, DENY_AND_ESCALATE_POLICY)
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id="bot", days=7)
        assert result.new_denials == 1
        assert result.new_escalations == 1
        assert result.matched_count == 2

    def test_record_already_escalated_not_counted(self, tmp_path):
        """Records already ESCALATE are not counted as new escalations."""
        store = LogStore(tmp_path, "audit")
        now = time.time()
        _populate_store(store, [
            _make_record("w-0", action_type="write", verdict="ESCALATE", timestamp=now - 100),
        ])
        policy_file = _write_policy_yaml(tmp_path, ESCALATE_WRITE_POLICY)
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id="bot", days=7)
        assert result.new_escalations == 0
        assert result.matched_count == 1

    def test_record_already_denied_not_new_denial(self, tmp_path):
        """Records already DENY are not counted as new denials."""
        store = LogStore(tmp_path, "audit")
        now = time.time()
        _populate_store(store, [
            _make_record("d-0", action_type="delete", verdict="DENY", timestamp=now - 100),
        ])
        policy_file = _write_policy_yaml(tmp_path, DENY_DELETE_POLICY)
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id="bot", days=7)
        assert result.new_denials == 0
        assert result.already_denied == 1
        assert result.matched_count == 1

    def test_wildcard_target_policy(self, tmp_path):
        """Policy with wildcard target matching."""
        store = LogStore(tmp_path, "audit")
        now = time.time()
        _populate_store(store, [
            _make_record("ext-0", action_type="export", action_target="external/s3",
                         verdict="ALLOW", timestamp=now - 100),
            _make_record("int-0", action_type="export", action_target="internal/db",
                         verdict="ALLOW", timestamp=now - 200),
        ])
        policy_file = _write_policy_yaml(tmp_path, DENY_TARGET_POLICY)
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id="bot", days=7)
        assert result.new_denials == 1
        assert result.would_deny[0]["record_id"] == "ext-0"


# ── TestPolicyEngineDryRunMethod ────────────────────────────────────


class TestPolicyEngineDryRunMethod:
    """Tests for PolicyEngine.dry_run() convenience method."""

    def test_dry_run_without_file_path(self, tmp_path):
        """engine.dry_run(audit_store) works without file path."""
        store = LogStore(tmp_path, "audit")
        now = time.time()
        _populate_store(store, [
            _make_record("r-0", action_type="delete", verdict="ALLOW", timestamp=now - 100),
        ])
        engine = PolicyEngine(policy_dirs=[])
        engine.add_policy(PolicyRule(
            name="deny-deletes",
            when={"action_type": "delete"},
            then={"verdict": "DENY", "reason": "No deletes"},
        ))
        result = engine.dry_run(audit_store=store, agent_id="bot", days=7)
        assert isinstance(result, DryRunResult)
        assert result.new_denials == 1

    def test_dry_run_returns_in_memory_label(self, tmp_path):
        """Returns DryRunResult with policy_label='in-memory'."""
        store = LogStore(tmp_path, "audit")
        engine = PolicyEngine(policy_dirs=[])
        engine.add_policy(PolicyRule(
            name="x", when={"action_type": "delete"},
            then={"verdict": "DENY", "reason": "test"},
        ))
        result = engine.dry_run(audit_store=store, agent_id="bot", days=7)
        assert result.policy_file == "in-memory"

    def test_dry_run_with_loaded_file_label(self, tmp_path):
        """Engine loaded from file uses file path as label."""
        store = LogStore(tmp_path, "audit")
        now = time.time()
        _populate_store(store, [
            _make_record("r-0", action_type="delete", verdict="ALLOW", timestamp=now - 100),
        ])
        policy_file = _write_policy_yaml(tmp_path, DENY_DELETE_POLICY)
        engine = PolicyEngine(policy_dirs=[])
        engine.load_file(policy_file)
        result = engine.dry_run(audit_store=store, agent_id="bot", days=7)
        assert str(policy_file) in result.policy_file

    def test_dry_run_passes_days_and_agent(self, tmp_path):
        store = LogStore(tmp_path, "audit")
        now = time.time()
        _populate_store(store, [
            _make_record("r-0", agent_id="a1", action_type="delete",
                         verdict="ALLOW", timestamp=now - 100),
            _make_record("r-1", agent_id="a2", action_type="delete",
                         verdict="ALLOW", timestamp=now - 200),
        ])
        engine = PolicyEngine(policy_dirs=[])
        engine.add_policy(PolicyRule(
            name="deny-deletes", when={"action_type": "delete"},
            then={"verdict": "DENY", "reason": "test"},
        ))
        result = engine.dry_run(audit_store=store, agent_id="a1", days=7)
        assert result.records_evaluated == 1
        assert result.agent_id == "a1"


# ── TestDryRunIntegration ───────────────────────────────────────────


class TestDryRunIntegration:
    """Integration tests for dry-run across multiple agents and scenarios."""

    def test_multi_agent_fleet_wide(self, tmp_path):
        """Records from multiple agents → fleet-wide dry-run aggregates correctly."""
        store = LogStore(tmp_path, "audit")
        now = time.time()
        _populate_store(store, [
            _make_record("a-del", agent_id="agent-a", action_type="delete",
                         verdict="ALLOW", timestamp=now - 100),
            _make_record("b-del", agent_id="agent-b", action_type="delete",
                         verdict="ALLOW", timestamp=now - 200),
            _make_record("c-read", agent_id="agent-c", action_type="read",
                         verdict="ALLOW", timestamp=now - 300),
        ])
        policy_file = _write_policy_yaml(tmp_path, DENY_DELETE_POLICY)
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id=None, days=7)
        assert result.records_evaluated == 3
        assert result.new_denials == 2
        agent_ids_in_denials = {e["agent_id"] for e in result.would_deny}
        assert "agent-a" in agent_ids_in_denials
        assert "agent-b" in agent_ids_in_denials

    def test_old_records_excluded(self, tmp_path):
        """Records older than days threshold → excluded from evaluation."""
        store = LogStore(tmp_path, "audit")
        now = time.time()
        _populate_store(store, [
            _make_record("recent", action_type="delete", verdict="ALLOW",
                         timestamp=now - 3600),
            _make_record("old-8days", action_type="delete", verdict="ALLOW",
                         timestamp=now - 8 * 86400),
        ])
        policy_file = _write_policy_yaml(tmp_path, DENY_DELETE_POLICY)
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id="bot", days=7)
        assert result.records_evaluated == 1
        assert result.new_denials == 1

    def test_escalate_from_allow(self, tmp_path):
        """ESCALATE policy → records that were ALLOW become would_escalate."""
        store = LogStore(tmp_path, "audit")
        now = time.time()
        _populate_store(store, [
            _make_record("w-0", action_type="write", verdict="ALLOW", timestamp=now - 100),
            _make_record("w-1", action_type="write", verdict="ESCALATE", timestamp=now - 200),
        ])
        policy_file = _write_policy_yaml(tmp_path, ESCALATE_WRITE_POLICY)
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id="bot", days=7)
        # w-0 was ALLOW, would become ESCALATE → new escalation
        # w-1 was already ESCALATE → not counted as new
        assert result.new_escalations == 1
        assert result.would_escalate[0]["original_verdict"] == "ALLOW"

    def test_records_already_matching_verdict_not_new(self, tmp_path):
        """Records already matching verdict → not counted as new changes."""
        store = LogStore(tmp_path, "audit")
        now = time.time()
        _populate_store(store, [
            _make_record("d-0", action_type="delete", verdict="DENY", timestamp=now - 100),
            _make_record("d-1", action_type="delete", verdict="DENY", timestamp=now - 200),
            _make_record("d-2", action_type="delete", verdict="ALLOW", timestamp=now - 300),
        ])
        policy_file = _write_policy_yaml(tmp_path, DENY_DELETE_POLICY)
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id="bot", days=7)
        assert result.already_denied == 2
        assert result.new_denials == 1

    def test_max_records_trims_oldest(self, tmp_path):
        """When capping, the most recent records are kept (oldest trimmed)."""
        store = LogStore(tmp_path, "audit")
        now = time.time()
        _populate_store(store, [
            _make_record("oldest", action_type="delete", verdict="ALLOW",
                         timestamp=now - 500),
            _make_record("middle", action_type="delete", verdict="ALLOW",
                         timestamp=now - 300),
            _make_record("newest", action_type="delete", verdict="ALLOW",
                         timestamp=now - 100),
        ])
        policy_file = _write_policy_yaml(tmp_path, DENY_DELETE_POLICY)
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id="bot", days=7, max_records=2)
        assert result.records_evaluated == 2
        # The newest 2 should be kept
        deny_ids = {e["record_id"] for e in result.would_deny}
        assert "newest" in deny_ids
        assert "middle" in deny_ids
        assert "oldest" not in deny_ids

    def test_run_with_engine_method(self, tmp_path):
        """run_with_engine uses provided engine directly."""
        store = LogStore(tmp_path, "audit")
        now = time.time()
        _populate_store(store, [
            _make_record("r-0", action_type="delete", verdict="ALLOW", timestamp=now - 100),
        ])
        engine = PolicyEngine(policy_dirs=[])
        engine.add_policy(PolicyRule(
            name="deny-deletes",
            when={"action_type": "delete"},
            then={"verdict": "DENY", "reason": "test"},
        ))
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run_with_engine(
            engine=engine, agent_id="bot", days=7,
            policy_label="custom-label",
        )
        assert result.policy_file == "custom-label"
        assert result.new_denials == 1

    def test_to_dict_round_trip(self, tmp_path):
        """DryRunResult.to_dict() produces a complete dictionary."""
        store = LogStore(tmp_path, "audit")
        now = time.time()
        _populate_store(store, [
            _make_record("r-0", action_type="delete", verdict="ALLOW", timestamp=now - 100),
        ])
        policy_file = _write_policy_yaml(tmp_path, DENY_DELETE_POLICY)
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id="bot", days=7)
        d = result.to_dict()
        assert isinstance(d, dict)
        assert d["records_evaluated"] == 1
        assert d["new_denials"] == 1
        assert d["would_deny_count"] == 1


# ── TestDryRunExports ───────────────────────────────────────────────


class TestDryRunExports:
    """Tests for public exports."""

    def test_import_from_nomotic(self):
        from nomotic import DryRunResult, PolicyDryRunner
        assert DryRunResult is not None
        assert PolicyDryRunner is not None

    def test_import_from_policy_module(self):
        from nomotic.policy import DryRunResult, PolicyDryRunner
        assert DryRunResult is not None
        assert PolicyDryRunner is not None


# ── TestPolicyEngineMultiRule ───────────────────────────────────────


class TestPolicyEngineMultiRule:
    """Tests for multi-rule YAML loading (rules: list format)."""

    def test_load_multi_rule_yaml(self, tmp_path):
        policy_dir = tmp_path / "policies"
        policy_dir.mkdir()
        (policy_dir / "multi.yaml").write_text(DENY_AND_ESCALATE_POLICY)
        engine = PolicyEngine(policy_dirs=[policy_dir])
        policies = engine.list_policies()
        assert len(policies) == 2
        names = {p.name for p in policies}
        assert "deny-all-deletes" in names
        assert "escalate-all-writes" in names

    def test_load_file_method(self, tmp_path):
        policy_file = _write_policy_yaml(tmp_path, DENY_DELETE_POLICY)
        engine = PolicyEngine(policy_dirs=[])
        engine.load_file(policy_file)
        assert len(engine.list_policies()) == 1
        assert engine.list_policies()[0].name == "deny-all-deletes"

    def test_load_file_nonexistent_raises(self, tmp_path):
        engine = PolicyEngine(policy_dirs=[])
        with pytest.raises(PolicyLoadError, match="not found"):
            engine.load_file(tmp_path / "nope.yaml")


# ── TestSimulatedOverride ──────────────────────────────────────────


class TestSimulatedOverride:
    """Tests for SimulatedOverride dataclass and applies_to logic."""

    def test_applies_to_all_when_empty_lists(self):
        sim = SimulatedOverride(authority="ops")
        assert sim.applies_to("any-agent", "any-action")

    def test_applies_to_specific_agent(self):
        sim = SimulatedOverride(authority="ops", target_agents=["bot-a"])
        assert sim.applies_to("bot-a", "write")

    def test_applies_to_specific_action_type(self):
        sim = SimulatedOverride(authority="ops", action_types=["write"])
        assert sim.applies_to("any-agent", "write")

    def test_not_applies_when_agent_not_in_list(self):
        sim = SimulatedOverride(authority="ops", target_agents=["bot-a"])
        assert not sim.applies_to("bot-b", "write")

    def test_not_applies_when_action_type_not_in_list(self):
        sim = SimulatedOverride(authority="ops", action_types=["write"])
        assert not sim.applies_to("any-agent", "read")

    def test_default_override_type(self):
        sim = SimulatedOverride(authority="ops")
        assert sim.override_type == "ALLOW_ANYWAY"

    def test_custom_override_type(self):
        sim = SimulatedOverride(authority="ops", override_type="ESCALATE_INSTEAD")
        assert sim.override_type == "ESCALATE_INSTEAD"


# ── TestDryRunWithOverrideSim ──────────────────────────────────────


class TestDryRunWithOverrideSim:
    """Tests for override simulation in dry-run evaluation."""

    @pytest.fixture()
    def store_with_mixed_records(self, tmp_path):
        """Create a store with mixed record types for override testing."""
        store = LogStore(tmp_path, "audit")
        now = time.time()
        records = [
            # 3 delete ALLOW records (will be denied by policy)
            _make_record("del-0", agent_id="bot-a", action_type="delete",
                         verdict="ALLOW", timestamp=now - 100),
            _make_record("del-1", agent_id="bot-a", action_type="delete",
                         verdict="ALLOW", timestamp=now - 200),
            _make_record("del-2", agent_id="bot-b", action_type="delete",
                         verdict="ALLOW", timestamp=now - 300),
            # 2 write ALLOW records (will be escalated by policy)
            _make_record("wr-0", agent_id="bot-a", action_type="write",
                         verdict="ALLOW", timestamp=now - 400),
            _make_record("wr-1", agent_id="bot-b", action_type="write",
                         verdict="ALLOW", timestamp=now - 500),
            # 1 read record (not matched by policy)
            _make_record("rd-0", agent_id="bot-a", action_type="read",
                         verdict="ALLOW", timestamp=now - 600),
        ]
        _populate_store(store, records)
        policy_file = _write_policy_yaml(tmp_path, DENY_AND_ESCALATE_POLICY)
        return store, policy_file, tmp_path

    def test_no_sim_override_result_unchanged(self, store_with_mixed_records):
        """Without sim_overrides, override fields default to inactive."""
        store, policy_file, _ = store_with_mixed_records
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id=None, days=7)
        assert result.override_sim_active is False
        assert result.would_override_count == 0
        assert result.would_override_details == []

    def test_sim_override_count_correct(self, store_with_mixed_records):
        """Override sim targeting delete actions counts correct overrides."""
        store, policy_file, _ = store_with_mixed_records
        sim = SimulatedOverride(authority="ops", action_types=["delete"])
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id=None, days=7,
                            sim_overrides=[sim])
        # 3 delete records are ALLOW, policy denies them → 3 overrides
        assert result.would_override_count == 3

    def test_sim_override_does_not_reduce_would_deny_count(self, store_with_mixed_records):
        """Override sim does NOT reduce would_deny — counts reflect policy verdict."""
        store, policy_file, _ = store_with_mixed_records
        sim = SimulatedOverride(authority="ops", action_types=["delete"])
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id=None, days=7,
                            sim_overrides=[sim])
        # would_deny should still reflect all 3 new denials
        assert result.new_denials == 3
        assert len(result.would_deny) == 3

    def test_sim_override_details_populated(self, store_with_mixed_records):
        """Override details contain expected per-record info."""
        store, policy_file, _ = store_with_mixed_records
        sim = SimulatedOverride(authority="ops-team", action_types=["delete"])
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id=None, days=7,
                            sim_overrides=[sim])
        assert len(result.would_override_details) == 3
        for detail in result.would_override_details:
            assert detail["policy_verdict"] == "DENY"
            assert detail["override_type"] == "ALLOW_ANYWAY"
            assert detail["authority"] == "ops-team"
            assert "record_id" in detail
            assert "agent_id" in detail
            assert detail["action_type"] == "delete"

    def test_override_sim_active_flag_set(self, store_with_mixed_records):
        """override_sim_active is True when sim_overrides provided."""
        store, policy_file, _ = store_with_mixed_records
        sim = SimulatedOverride(authority="ops")
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id=None, days=7,
                            sim_overrides=[sim])
        assert result.override_sim_active is True

    def test_sim_override_escalate_instead_type(self, store_with_mixed_records):
        """ESCALATE_INSTEAD override type is recorded correctly."""
        store, policy_file, _ = store_with_mixed_records
        sim = SimulatedOverride(
            authority="ops",
            action_types=["delete"],
            override_type="ESCALATE_INSTEAD",
        )
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id=None, days=7,
                            sim_overrides=[sim])
        for detail in result.would_override_details:
            assert detail["override_type"] == "ESCALATE_INSTEAD"

    def test_multiple_records_multiple_overrides(self, store_with_mixed_records):
        """Multiple overrides: delete override + write override, both apply."""
        store, policy_file, _ = store_with_mixed_records
        sim_delete = SimulatedOverride(authority="ops", action_types=["delete"])
        sim_write = SimulatedOverride(authority="lead", action_types=["write"])
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id=None, days=7,
                            sim_overrides=[sim_delete, sim_write])
        # 3 deletes denied + 2 writes escalated = 5 total overrides
        assert result.would_override_count == 5
        # Check authorities
        authorities = {d["authority"] for d in result.would_override_details}
        assert "ops" in authorities
        assert "lead" in authorities

    def test_sim_override_target_agent_filter(self, store_with_mixed_records):
        """Override scoped to specific agent only counts that agent's records."""
        store, policy_file, _ = store_with_mixed_records
        sim = SimulatedOverride(
            authority="ops",
            target_agents=["bot-a"],
            action_types=["delete"],
        )
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id=None, days=7,
                            sim_overrides=[sim])
        # Only bot-a's 2 delete records should be overridden, not bot-b's 1
        assert result.would_override_count == 2
        for detail in result.would_override_details:
            assert detail["agent_id"] == "bot-a"

    def test_to_dict_includes_override_fields(self, store_with_mixed_records):
        """DryRunResult.to_dict() includes override simulation fields."""
        store, policy_file, _ = store_with_mixed_records
        sim = SimulatedOverride(authority="ops", action_types=["delete"])
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id=None, days=7,
                            sim_overrides=[sim])
        d = result.to_dict()
        assert d["override_sim_active"] is True
        assert d["would_override_count"] == 3
        assert len(d["would_override_details"]) == 3

    def test_engine_dry_run_passes_sim_overrides(self, tmp_path):
        """PolicyEngine.dry_run() correctly passes sim_overrides through."""
        store = LogStore(tmp_path, "audit")
        now = time.time()
        _populate_store(store, [
            _make_record("del-0", action_type="delete", verdict="ALLOW",
                         timestamp=now - 100),
        ])
        engine = PolicyEngine(policy_dirs=[])
        engine.add_policy(PolicyRule(
            name="deny-deletes",
            when={"action_type": "delete"},
            then={"verdict": "DENY", "reason": "test"},
        ))
        sim = SimulatedOverride(authority="ops")
        result = engine.dry_run(
            audit_store=store, agent_id="bot", days=7,
            sim_overrides=[sim],
        )
        assert result.override_sim_active is True
        assert result.would_override_count == 1

    def test_first_matching_override_wins(self, tmp_path):
        """When multiple overrides match, only the first one is used."""
        store = LogStore(tmp_path, "audit")
        now = time.time()
        _populate_store(store, [
            _make_record("del-0", action_type="delete", verdict="ALLOW",
                         timestamp=now - 100),
        ])
        policy_file = _write_policy_yaml(tmp_path, DENY_DELETE_POLICY)
        sim1 = SimulatedOverride(authority="first", override_type="ALLOW_ANYWAY")
        sim2 = SimulatedOverride(authority="second", override_type="ESCALATE_INSTEAD")
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(policy_file, agent_id="bot", days=7,
                            sim_overrides=[sim1, sim2])
        assert result.would_override_count == 1
        assert result.would_override_details[0]["authority"] == "first"
        assert result.would_override_details[0]["override_type"] == "ALLOW_ANYWAY"


# ── TestSimulatedOverrideExport ────────────────────────────────────


class TestSimulatedOverrideExport:
    """Test that SimulatedOverride is properly exported."""

    def test_import_from_nomotic(self):
        from nomotic import SimulatedOverride
        sim = SimulatedOverride(authority="ops")
        assert sim.authority == "ops"

    def test_import_from_policy_module(self):
        from nomotic.policy import SimulatedOverride
        sim = SimulatedOverride(authority="ops", action_types=["write"])
        assert sim.applies_to("any", "write")
        assert not sim.applies_to("any", "read")
