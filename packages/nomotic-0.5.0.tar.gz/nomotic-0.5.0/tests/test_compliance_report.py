"""Tests for the compliance report generator."""

import json
import time
from pathlib import Path
from unittest.mock import patch

import pytest

from nomotic.compliance_report import (
    DISCLAIMER,
    FRAMEWORK_MAPPINGS,
    VALID_DIMENSIONS,
    AgentEvidence,
    ComplianceReport,
    ComplianceReportGenerator,
    ControlMapping,
    ControlReport,
    FrameworkMapping,
    GovernanceLayerMap,
    ReportSummary,
    format_json,
    format_markdown,
)


# ── Framework Mapping Tests ──────────────────────────────────────────────


class TestFrameworkMappings:
    """Validate the hardcoded framework mapping data."""

    @pytest.mark.parametrize("fw_id", list(FRAMEWORK_MAPPINGS.keys()))
    def test_framework_loads(self, fw_id: str) -> None:
        mapping = FRAMEWORK_MAPPINGS[fw_id]
        assert isinstance(mapping, FrameworkMapping)
        assert mapping.framework_id == fw_id
        assert mapping.framework_name
        assert mapping.version

    def test_invalid_framework_not_present(self) -> None:
        assert "invalid" not in FRAMEWORK_MAPPINGS

    @pytest.mark.parametrize("fw_id", list(FRAMEWORK_MAPPINGS.keys()))
    def test_each_framework_has_at_least_3_controls(self, fw_id: str) -> None:
        mapping = FRAMEWORK_MAPPINGS[fw_id]
        assert len(mapping.controls) >= 3, (
            f"{fw_id} has only {len(mapping.controls)} controls"
        )

    @pytest.mark.parametrize("fw_id", list(FRAMEWORK_MAPPINGS.keys()))
    def test_dimension_names_are_valid(self, fw_id: str) -> None:
        mapping = FRAMEWORK_MAPPINGS[fw_id]
        for ctrl in mapping.controls:
            for dim in ctrl.nomotic_dimensions:
                assert dim in VALID_DIMENSIONS, (
                    f"{fw_id}/{ctrl.control_id}: unknown dimension {dim!r}"
                )

    @pytest.mark.parametrize("fw_id", list(FRAMEWORK_MAPPINGS.keys()))
    def test_coverage_values_are_valid(self, fw_id: str) -> None:
        mapping = FRAMEWORK_MAPPINGS[fw_id]
        valid = {"full", "partial", "indirect", "none"}
        for ctrl in mapping.controls:
            assert ctrl.coverage in valid, (
                f"{fw_id}/{ctrl.control_id}: invalid coverage {ctrl.coverage!r}"
            )

    def test_all_eight_frameworks_present(self) -> None:
        expected = {
            "soc2", "hipaa", "eu-ai-act", "iso27001",
            "nist-ai-rmf", "nist-csf-ai", "imda-agentic", "gdpr",
        }
        assert set(FRAMEWORK_MAPPINGS.keys()) == expected

    def test_control_mapping_to_dict(self) -> None:
        cm = ControlMapping(
            "TEST-1", "Test Control", "Description",
            ["scope_compliance"], "full", "Test notes",
        )
        d = cm.to_dict()
        assert d["control_id"] == "TEST-1"
        assert d["nomotic_dimensions"] == ["scope_compliance"]

    def test_framework_mapping_to_dict(self) -> None:
        fm = FRAMEWORK_MAPPINGS["soc2"]
        d = fm.to_dict()
        assert d["framework_id"] == "soc2"
        assert len(d["controls"]) == len(fm.controls)


# ── Report Generation Tests ──────────────────────────────────────────────


class TestReportGeneration:
    """Test ComplianceReportGenerator.generate()."""

    @pytest.mark.parametrize("fw_id", list(FRAMEWORK_MAPPINGS.keys()))
    def test_generate_produces_report(self, fw_id: str, tmp_path: Path) -> None:
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        report = gen.generate(framework=fw_id)
        assert isinstance(report, ComplianceReport)
        assert report.framework_id == fw_id
        assert report.generated_at > 0

    def test_report_includes_disclaimer(self, tmp_path: Path) -> None:
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        report = gen.generate(framework="soc2")
        assert report.disclaimer == DISCLAIMER

    def test_summary_counts_match(self, tmp_path: Path) -> None:
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        report = gen.generate(framework="soc2")
        s = report.summary
        total = s.full_coverage + s.partial_coverage + s.indirect_coverage + s.no_coverage
        assert total == s.total_controls
        assert s.total_controls == len(report.controls)

    def test_coverage_percentage_calculation(self, tmp_path: Path) -> None:
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        report = gen.generate(framework="soc2")
        s = report.summary
        expected = (s.full_coverage + s.partial_coverage) / s.total_controls * 100
        assert abs(s.coverage_percentage - round(expected, 1)) < 0.01

    def test_no_agent_means_no_evidence(self, tmp_path: Path) -> None:
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        report = gen.generate(framework="soc2")
        for cr in report.controls:
            assert cr.evidence is None

    def test_invalid_framework_raises(self, tmp_path: Path) -> None:
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        with pytest.raises(ValueError, match="Unknown framework"):
            gen.generate(framework="invalid")

    def test_layer_map_included_when_requested(self, tmp_path: Path) -> None:
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        report = gen.generate(framework="soc2", include_layer_map=True)
        assert report.layer_map is not None
        assert isinstance(report.layer_map, GovernanceLayerMap)
        assert len(report.layer_map.l5_controls) > 0
        assert len(report.layer_map.l6_outputs) > 0
        assert len(report.layer_map.l1_inputs) > 0
        assert len(report.layer_map.l4_inputs) > 0

    def test_layer_map_omitted_by_default(self, tmp_path: Path) -> None:
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        report = gen.generate(framework="soc2")
        assert report.layer_map is None


# ── Evidence Gathering Tests ─────────────────────────────────────────────


class TestEvidenceGathering:
    """Test evidence gathering from audit trail."""

    def _write_audit_records(
        self, base_dir: Path, agent_id: str, records: list[dict],
    ) -> None:
        """Helper: write mock JSONL audit records."""
        from nomotic.audit_store import AuditStore, PersistentLogRecord

        store = AuditStore(base_dir)
        prev_hash = ""
        for rec_data in records:
            rec = PersistentLogRecord(
                record_id=rec_data.get("record_id", f"rec-{time.time_ns()}"),
                timestamp=rec_data.get("timestamp", time.time()),
                agent_id=agent_id,
                action_type=rec_data.get("action_type", "read"),
                action_target=rec_data.get("action_target", "/api/data"),
                verdict=rec_data.get("verdict", "ALLOW"),
                ucs=rec_data.get("ucs", 0.85),
                tier=rec_data.get("tier", 1),
                trust_score=rec_data.get("trust_score", 0.7),
                trust_delta=rec_data.get("trust_delta", 0.002),
                trust_trend=rec_data.get("trust_trend", "stable"),
                severity=rec_data.get("severity", "info"),
                justification=rec_data.get("justification", "OK"),
                seal_id=rec_data.get("seal_id", ""),
            )
            # Compute hashes
            d = rec.to_dict()
            rec.previous_hash = prev_hash
            rec.record_hash = store.compute_hash(d, prev_hash)
            prev_hash = rec.record_hash
            store.append(rec)

    def test_denial_rate_calculation(self, tmp_path: Path) -> None:
        records = [
            {"verdict": "ALLOW", "trust_score": 0.5},
            {"verdict": "ALLOW", "trust_score": 0.52},
            {"verdict": "DENY", "trust_score": 0.48},
            {"verdict": "ALLOW", "trust_score": 0.50},
            {"verdict": "DENY", "trust_score": 0.46},
        ]
        self._write_audit_records(tmp_path, "test-agent", records)
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        evidence = gen._gather_evidence("test-agent")
        assert evidence.total_actions == 5
        assert evidence.total_denials == 2
        assert abs(evidence.denial_rate - 0.4) < 0.001

    def test_total_actions_count(self, tmp_path: Path) -> None:
        records = [{"verdict": "ALLOW"} for _ in range(10)]
        self._write_audit_records(tmp_path, "test-agent", records)
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        evidence = gen._gather_evidence("test-agent")
        assert evidence.total_actions == 10

    def test_trust_trend_rising(self, tmp_path: Path) -> None:
        records = []
        for i in range(20):
            records.append({
                "trust_score": 0.5 + i * 0.02,
                "trust_delta": 0.02,
            })
        self._write_audit_records(tmp_path, "test-agent", records)
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        evidence = gen._gather_evidence("test-agent")
        assert evidence.trust_trend == "rising"

    def test_trust_trend_falling(self, tmp_path: Path) -> None:
        records = []
        for i in range(20):
            records.append({
                "trust_score": 0.9 - i * 0.02,
                "trust_delta": -0.02,
            })
        self._write_audit_records(tmp_path, "test-agent", records)
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        evidence = gen._gather_evidence("test-agent")
        assert evidence.trust_trend == "falling"

    def test_trust_trend_stable(self, tmp_path: Path) -> None:
        records = [{"trust_score": 0.7} for _ in range(20)]
        self._write_audit_records(tmp_path, "test-agent", records)
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        evidence = gen._gather_evidence("test-agent")
        assert evidence.trust_trend == "stable"

    def test_empty_agent_evidence(self, tmp_path: Path) -> None:
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        evidence = gen._gather_evidence("nonexistent-agent")
        assert evidence.total_actions == 0
        assert evidence.denial_rate == 0.0
        assert evidence.trust_current == 0.5
        assert evidence.trust_trend == "stable"

    def test_sealed_actions_count(self, tmp_path: Path) -> None:
        records = [
            {"seal_id": "nms-abc123"},
            {"seal_id": "nms-def456"},
            {"seal_id": ""},
        ]
        self._write_audit_records(tmp_path, "test-agent", records)
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        evidence = gen._gather_evidence("test-agent")
        assert evidence.sealed_actions == 2

    def test_report_with_agent_evidence(self, tmp_path: Path) -> None:
        records = [
            {"verdict": "ALLOW", "trust_score": 0.8},
            {"verdict": "DENY", "trust_score": 0.75},
            {"verdict": "ALLOW", "trust_score": 0.78},
        ]
        self._write_audit_records(tmp_path, "my-agent", records)
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        report = gen.generate(framework="soc2", agent_id="my-agent")
        for cr in report.controls:
            assert cr.evidence is not None
            assert cr.evidence.total_actions == 3


# ── Output Format Tests ──────────────────────────────────────────────────


class TestOutputFormats:
    """Test Markdown and JSON output formatters."""

    def _make_report(self, tmp_path: Path, **kwargs) -> ComplianceReport:
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        return gen.generate(**{"framework": "soc2", **kwargs})

    def test_format_markdown_produces_string(self, tmp_path: Path) -> None:
        report = self._make_report(tmp_path)
        md = format_markdown(report)
        assert isinstance(md, str)
        assert len(md) > 100

    def test_markdown_contains_framework_name(self, tmp_path: Path) -> None:
        report = self._make_report(tmp_path)
        md = format_markdown(report)
        assert report.framework_name in md

    def test_markdown_contains_disclaimer(self, tmp_path: Path) -> None:
        report = self._make_report(tmp_path)
        md = format_markdown(report)
        assert DISCLAIMER in md

    def test_markdown_contains_control_ids(self, tmp_path: Path) -> None:
        report = self._make_report(tmp_path)
        md = format_markdown(report)
        for cr in report.controls:
            assert cr.mapping.control_id in md

    def test_markdown_contains_coverage_summary(self, tmp_path: Path) -> None:
        report = self._make_report(tmp_path)
        md = format_markdown(report)
        assert "Coverage Summary" in md

    def test_markdown_layer_map_included(self, tmp_path: Path) -> None:
        report = self._make_report(tmp_path, include_layer_map=True)
        md = format_markdown(report)
        assert "Governance Layer Coverage" in md
        assert "Layer 5" in md

    def test_markdown_layer_map_omitted(self, tmp_path: Path) -> None:
        report = self._make_report(tmp_path)
        md = format_markdown(report)
        assert "Governance Layer Coverage" not in md

    def test_markdown_gaps_section(self, tmp_path: Path) -> None:
        report = self._make_report(tmp_path)
        # SOC2 has partial controls so gaps section should exist
        md = format_markdown(report)
        assert "Gaps and Recommendations" in md

    def test_format_json_produces_dict(self, tmp_path: Path) -> None:
        report = self._make_report(tmp_path)
        d = format_json(report)
        assert isinstance(d, dict)
        assert d["framework_id"] == "soc2"

    def test_json_is_serializable(self, tmp_path: Path) -> None:
        report = self._make_report(tmp_path)
        d = format_json(report)
        # Must not raise
        output = json.dumps(d)
        assert isinstance(output, str)

    def test_json_contains_disclaimer(self, tmp_path: Path) -> None:
        report = self._make_report(tmp_path)
        d = format_json(report)
        assert d["disclaimer"] == DISCLAIMER

    def test_json_layer_map_present_when_requested(self, tmp_path: Path) -> None:
        report = self._make_report(tmp_path, include_layer_map=True)
        d = format_json(report)
        assert "layer_map" in d
        assert "l5_controls" in d["layer_map"]

    def test_json_layer_map_absent_when_not_requested(self, tmp_path: Path) -> None:
        report = self._make_report(tmp_path)
        d = format_json(report)
        assert "layer_map" not in d


# ── CLI Tests ────────────────────────────────────────────────────────────


class TestCLI:
    """Test the compliance-report CLI command."""

    def test_cli_soc2_runs(self, tmp_path: Path) -> None:
        from nomotic.cli import main

        main(["--base-dir", str(tmp_path), "compliance-report", "--framework", "soc2"])

    def test_cli_all_frameworks_run(self, tmp_path: Path) -> None:
        from nomotic.cli import main

        frameworks = [
            "soc2", "hipaa", "eu-ai-act", "iso27001",
            "nist-ai-rmf", "nist-csf-ai", "imda-agentic",
        ]
        for fw in frameworks:
            main(["--base-dir", str(tmp_path), "compliance-report", "--framework", fw])

    def test_cli_invalid_framework_rejected(self) -> None:
        from nomotic.cli import main

        with pytest.raises(SystemExit):
            main(["compliance-report", "--framework", "invalid"])

    def test_cli_output_json(self, tmp_path: Path) -> None:
        from nomotic.cli import main

        out = tmp_path / "report.json"
        main([
            "--base-dir", str(tmp_path),
            "compliance-report", "--framework", "soc2",
            "--output", str(out),
        ])
        assert out.exists()
        data = json.loads(out.read_text())
        assert data["framework_id"] == "soc2"
        assert "disclaimer" in data

    def test_cli_output_md(self, tmp_path: Path) -> None:
        from nomotic.cli import main

        out = tmp_path / "report.md"
        main([
            "--base-dir", str(tmp_path),
            "compliance-report", "--framework", "hipaa",
            "--output", str(out),
        ])
        assert out.exists()
        content = out.read_text()
        assert "HIPAA" in content
        assert DISCLAIMER in content

    def test_cli_include_layer_map(self, tmp_path: Path) -> None:
        from nomotic.cli import main

        out = tmp_path / "report.md"
        main([
            "--base-dir", str(tmp_path),
            "compliance-report", "--framework", "soc2",
            "--include-layer-map",
            "--output", str(out),
        ])
        content = out.read_text()
        assert "Governance Layer Coverage" in content


# ── Dataclass Tests ──────────────────────────────────────────────────────


class TestDataclasses:
    """Test dataclass serialization."""

    def test_agent_evidence_to_dict(self) -> None:
        ev = AgentEvidence(
            total_actions=100, total_denials=5, denial_rate=0.05,
            average_ucs=0.9, trust_current=0.8, trust_trend="rising",
            active_alerts=2, sealed_actions=95, last_activity=1000.0,
        )
        d = ev.to_dict()
        assert d["total_actions"] == 100
        assert d["trust_trend"] == "rising"

    def test_governance_layer_map_to_dict(self) -> None:
        lm = GovernanceLayerMap(
            l5_controls=["a"], l6_outputs=["b"],
            l1_inputs=["c"], l4_inputs=["d"],
        )
        d = lm.to_dict()
        assert d["l5_controls"] == ["a"]

    def test_report_summary_to_dict(self) -> None:
        s = ReportSummary(
            total_controls=10, full_coverage=5,
            partial_coverage=3, indirect_coverage=1,
            no_coverage=1, coverage_percentage=80.0,
        )
        d = s.to_dict()
        assert d["total_controls"] == 10
        assert d["coverage_percentage"] == 80.0

    def test_control_report_to_dict_without_evidence(self) -> None:
        cm = ControlMapping(
            "T-1", "Test", "Desc", ["scope_compliance"], "full", "Notes",
        )
        cr = ControlReport(mapping=cm)
        d = cr.to_dict()
        assert "evidence" not in d

    def test_control_report_to_dict_with_evidence(self) -> None:
        cm = ControlMapping(
            "T-1", "Test", "Desc", ["scope_compliance"], "full", "Notes",
        )
        ev = AgentEvidence(
            total_actions=10, total_denials=1, denial_rate=0.1,
            average_ucs=0.85, trust_current=0.7, trust_trend="stable",
            active_alerts=0, sealed_actions=9, last_activity=1000.0,
        )
        cr = ControlReport(mapping=cm, evidence=ev)
        d = cr.to_dict()
        assert "evidence" in d
        assert d["evidence"]["total_actions"] == 10
