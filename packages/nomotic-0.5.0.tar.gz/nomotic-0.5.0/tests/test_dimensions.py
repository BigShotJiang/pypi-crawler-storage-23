"""Tests for the 14 governance dimensions."""

from nomotic.types import Action, ActionRecord, AgentContext, GovernanceVerdict, TrustProfile, Verdict
from nomotic.dimensions import (
    AuthorityVerification,
    BehavioralConsistency,
    CascadingImpact,
    DimensionRegistry,
    EthicalAlignment,
    HumanOverride,
    IncidentDetection,
    IsolationIntegrity,
    PrecedentAlignment,
    ResourceBoundaries,
    ResourceLimits,
    ScopeCompliance,
    StakeholderImpact,
    TemporalCompliance,
    Transparency,
)


def _ctx(agent_id: str = "agent-1", trust: float = 0.5, history=None) -> AgentContext:
    return AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id, overall_trust=trust),
        action_history=history or [],
    )


def _action(action_type: str = "read", target: str = "db", **params) -> Action:
    return Action(agent_id="agent-1", action_type=action_type, target=target, parameters=params)


# --- Scope Compliance ---


class TestScopeCompliance:
    def test_in_scope_allows(self):
        dim = ScopeCompliance()
        dim.configure_agent_scope("agent-1", {"read", "write"})
        score = dim.evaluate(_action("read"), _ctx())
        assert score.score == 1.0
        assert not score.veto

    def test_out_of_scope_vetoes(self):
        dim = ScopeCompliance()
        dim.configure_agent_scope("agent-1", {"read"})
        score = dim.evaluate(_action("delete"), _ctx())
        assert score.score == 0.0
        assert score.veto

    def test_wildcard_allows_all(self):
        dim = ScopeCompliance()
        dim.configure_agent_scope("agent-1", {"*"})
        score = dim.evaluate(_action("anything"), _ctx())
        assert score.score == 1.0

    def test_no_scope_defined_caution(self):
        dim = ScopeCompliance()
        score = dim.evaluate(_action("read"), _ctx())
        assert score.score == 0.5


# --- Authority Verification ---


class TestAuthorityVerification:
    def test_no_checks_moderate_trust(self):
        dim = AuthorityVerification()
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.7

    def test_passing_check(self):
        dim = AuthorityVerification()
        dim.add_authority_check(lambda a, c: True)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0

    def test_failing_check_vetoes(self):
        dim = AuthorityVerification()
        dim.add_authority_check(lambda a, c: False)
        score = dim.evaluate(_action(), _ctx())
        assert score.veto


# --- Resource Boundaries ---


class TestResourceBoundaries:
    def test_within_limits(self):
        dim = ResourceBoundaries(limits=ResourceLimits(max_actions_per_minute=100))
        score = dim.evaluate(_action(), _ctx())
        assert score.score > 0.5
        assert not score.veto

    def test_cost_exceeded_vetoes(self):
        dim = ResourceBoundaries(limits=ResourceLimits(max_cost_per_action=10.0))
        score = dim.evaluate(_action(cost=50.0), _ctx())
        assert score.veto


# --- Behavioral Consistency ---


class TestBehavioralConsistency:
    def test_first_action_establishes_baseline(self):
        dim = BehavioralConsistency()
        score = dim.evaluate(_action("read"), _ctx())
        assert score.score == 0.7

    def test_consistent_action_high_score(self):
        dim = BehavioralConsistency()
        ctx = _ctx()
        dim.evaluate(_action("read"), ctx)
        score = dim.evaluate(_action("read"), ctx)
        assert score.score == 1.0

    def test_novel_action_lower_score(self):
        dim = BehavioralConsistency()
        ctx = _ctx()
        dim.evaluate(_action("read"), ctx)
        score = dim.evaluate(_action("delete"), ctx)
        assert score.score == 0.5


# --- Cascading Impact ---


class TestCascadingImpact:
    def test_high_impact_low_score(self):
        dim = CascadingImpact()
        score = dim.evaluate(_action("delete_all"), _ctx())
        assert score.score <= 0.3

    def test_medium_impact(self):
        dim = CascadingImpact()
        score = dim.evaluate(_action("update_record"), _ctx())
        assert 0.3 < score.score < 0.9

    def test_low_impact(self):
        dim = CascadingImpact()
        score = dim.evaluate(_action("read"), _ctx())
        assert score.score >= 0.9


# --- Stakeholder Impact ---


class TestStakeholderImpact:
    def test_sensitive_target_low_score(self):
        dim = StakeholderImpact()
        dim.mark_sensitive("production_db")
        score = dim.evaluate(_action(target="production_db"), _ctx())
        assert score.score == 0.2

    def test_external_facing_medium_score(self):
        dim = StakeholderImpact()
        score = dim.evaluate(_action(target="customer_records"), _ctx())
        assert score.score == 0.4

    def test_internal_high_score(self):
        dim = StakeholderImpact()
        score = dim.evaluate(_action(target="internal_cache"), _ctx())
        assert score.score == 0.9


# --- Incident Detection ---


class TestIncidentDetection:
    def test_no_patterns_passes(self):
        dim = IncidentDetection()
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0

    def test_repetitive_pattern_detected(self):
        dim = IncidentDetection()
        history = []
        for _ in range(5):
            history.append(
                ActionRecord(
                    action=_action("spam"),
                    verdict=GovernanceVerdict(action_id="x", verdict=Verdict.ALLOW, ucs=0.8),
                )
            )
        ctx = _ctx(history=history)
        score = dim.evaluate(_action("spam"), ctx)
        assert score.score < 0.5

    def test_custom_pattern(self):
        dim = IncidentDetection()
        dim.add_pattern(lambda a, c: 0.05 if "exploit" in a.action_type else None)
        score = dim.evaluate(_action("exploit_vuln"), _ctx())
        assert score.score <= 0.05
        assert score.veto


# --- Isolation Integrity ---


class TestIsolationIntegrity:
    def test_within_boundary(self):
        dim = IsolationIntegrity()
        dim.set_boundaries("agent-1", {"db_a", "db_b"})
        score = dim.evaluate(_action(target="db_a"), _ctx())
        assert score.score == 1.0

    def test_outside_boundary_vetoes(self):
        dim = IsolationIntegrity()
        dim.set_boundaries("agent-1", {"db_a"})
        score = dim.evaluate(_action(target="db_secret"), _ctx())
        assert score.veto

    def test_no_boundaries_caution(self):
        dim = IsolationIntegrity()
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.6


# --- Temporal Compliance ---


class TestTemporalCompliance:
    def test_no_constraints_passes(self):
        dim = TemporalCompliance()
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0

    def test_min_interval_violation(self):
        dim = TemporalCompliance()
        dim.set_min_interval("deploy", 3600)
        ctx = _ctx()
        # First call sets the timestamp
        dim.evaluate(_action("deploy"), ctx)
        # Second call within interval should veto
        score = dim.evaluate(_action("deploy"), ctx)
        assert score.veto


# --- Precedent Alignment ---


class TestPrecedentAlignment:
    def test_no_history(self):
        dim = PrecedentAlignment()
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.8

    def test_consistent_with_precedent(self):
        dim = PrecedentAlignment()
        history = [
            ActionRecord(
                action=_action("read"),
                verdict=GovernanceVerdict(action_id="x", verdict=Verdict.ALLOW, ucs=0.8),
            )
            for _ in range(5)
        ]
        score = dim.evaluate(_action("read"), _ctx(history=history))
        assert score.score >= 0.9

    def test_frequently_denied_type(self):
        dim = PrecedentAlignment()
        history = [
            ActionRecord(
                action=_action("hack"),
                verdict=GovernanceVerdict(action_id="x", verdict=Verdict.DENY, ucs=0.0),
            )
            for _ in range(5)
        ]
        score = dim.evaluate(_action("hack"), _ctx(history=history))
        assert score.score <= 0.3


# --- Transparency ---


class TestTransparency:
    def test_fully_transparent(self):
        dim = Transparency()
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0

    def test_missing_fields_lower_score(self):
        dim = Transparency()
        a = Action()  # Mostly empty
        score = dim.evaluate(a, _ctx())
        assert score.score < 1.0


# --- Human Override ---


class TestHumanOverride:
    def test_no_override_needed(self):
        dim = HumanOverride()
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0

    def test_required_action_vetoes(self):
        dim = HumanOverride()
        dim.require_human_for("deploy")
        score = dim.evaluate(_action("deploy"), _ctx())
        assert score.veto

    def test_approved_action_passes(self):
        dim = HumanOverride()
        dim.require_human_for("deploy")
        action = _action("deploy")
        dim.approve(action.id)
        score = dim.evaluate(action, _ctx())
        assert score.score == 1.0

    def test_low_trust_requires_human(self):
        dim = HumanOverride()
        score = dim.evaluate(_action(), _ctx(trust=0.1))
        assert score.veto


# --- Ethical Alignment ---


class TestEthicalAlignment:
    def test_no_rules_passes(self):
        dim = EthicalAlignment()
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.8

    def test_passing_rule(self):
        dim = EthicalAlignment()
        dim.add_rule(lambda a, c: (True, "ok"))
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0

    def test_failing_rule_vetoes(self):
        dim = EthicalAlignment()
        dim.add_rule(lambda a, c: (False, "violates principle X"))
        score = dim.evaluate(_action(), _ctx())
        assert score.veto
        assert "principle X" in score.reasoning


# --- Registry ---


class TestDimensionRegistry:
    def test_default_has_14_dimensions(self):
        reg = DimensionRegistry.create_default()
        assert len(reg.dimensions) == 14

    def test_evaluate_all_returns_14_scores(self):
        reg = DimensionRegistry.create_default()
        scores = reg.evaluate_all(_action(), _ctx())
        assert len(scores) == 14

    def test_all_dimension_names_unique(self):
        reg = DimensionRegistry.create_default()
        names = [d.name for d in reg.dimensions]
        assert len(names) == len(set(names))


# --- Jurisdictional Compliance ---


from nomotic.dimensions import JurisdictionalCompliance
from nomotic.context_profile import ContextProfile, JurisdictionalContext


def _dim_with_accessor(jctx):
    """Create a JurisdictionalCompliance dimension with a mock accessor returning jctx."""
    dim = JurisdictionalCompliance()
    dim.set_jurisdictional_accessor(lambda _: jctx)
    return dim


class TestJurisdictionalCompliance:
    """Tests for Dimension 14: Jurisdictional Compliance (accessor-based)."""

    # --- Core scoring tests ---

    def test_no_jurisdictional_context_scores_07(self):
        dim = JurisdictionalCompliance()
        # No accessor → returns 0.7
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.7
        assert not score.veto

    def test_compliant_action_scores_1_0(self):
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis="legitimate_interest",
            cross_border_transfer=False,
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0
        assert not score.veto

    def test_cross_border_eu_to_us_no_mechanism_vetoes(self):
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis="consent",
            cross_border_transfer=True,
            transfer_destination_zones=["us/east"],
            transfer_mechanism=None,
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.0
        assert score.veto

    def test_cross_border_eu_to_us_scc_mechanism_scores_0_9(self):
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis="consent",
            cross_border_transfer=True,
            transfer_destination_zones=["us/east"],
            transfer_mechanism="standard_contractual_clauses",
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.9
        assert not score.veto

    def test_gdpr_pii_no_legal_basis_scores_0_3(self):
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis=None,
            cross_border_transfer=False,
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.3
        assert not score.veto
        assert "GDPR" in score.reasoning

    def test_china_data_inference_outside_china_vetoes(self):
        jctx = JurisdictionalContext(
            data_residency_zones=["cn/shanghai"],
            data_classification="pii",
            applicable_regulations=["pipl"],
            agent_operating_zone="us/east",
            model_inference_zone="us/east",
            cross_border_transfer=False,
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.0
        assert score.veto
        assert "prohibited" in score.reasoning

    def test_china_data_inference_inside_china_passes(self):
        jctx = JurisdictionalContext(
            data_residency_zones=["cn/shanghai"],
            data_classification="pii",
            applicable_regulations=["pipl"],
            agent_operating_zone="cn/beijing",
            model_inference_zone="cn/beijing",
            cross_border_transfer=False,
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0
        assert not score.veto

    def test_eu_to_adequate_destination_switzerland_passes(self):
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis="consent",
            cross_border_transfer=True,
            transfer_destination_zones=["ch/zurich"],
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0
        assert not score.veto

    def test_public_data_gdpr_no_legal_basis_passes(self):
        """Public data doesn't trigger the GDPR legal basis check."""
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="public",
            applicable_regulations=["gdpr"],
            legal_basis=None,
            cross_border_transfer=False,
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0
        assert not score.veto

    def test_minimal_context_scores_0_8(self):
        """Empty JurisdictionalContext → score 0.8 (minimal)."""
        jctx = JurisdictionalContext()
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.8
        assert not score.veto

    # --- Configuration tests ---

    def test_weight_default_1_4(self):
        dim = JurisdictionalCompliance()
        assert dim.weight == 1.4

    def test_can_veto_is_true(self):
        dim = JurisdictionalCompliance()
        assert dim.can_veto is True

    def test_name_is_jurisdictional_compliance(self):
        dim = JurisdictionalCompliance()
        assert dim.name == "jurisdictional_compliance"

    # --- Registry integration tests ---

    def test_dimension_14_in_default_registry(self):
        reg = DimensionRegistry.create_default()
        names = [d.name for d in reg.dimensions]
        assert "jurisdictional_compliance" in names

    def test_create_default_returns_14_dimensions(self):
        reg = DimensionRegistry.create_default()
        assert len(reg.dimensions) == 14

    def test_registry_get_jurisdictional_compliance(self):
        reg = DimensionRegistry.create_default()
        dim = reg.get("jurisdictional_compliance")
        assert dim is not None
        assert dim.can_veto is True
        assert dim.name == "jurisdictional_compliance"

    def test_dimension_14_is_last_in_registry(self):
        reg = DimensionRegistry.create_default()
        assert reg.dimensions[-1].name == "jurisdictional_compliance"

    def test_score_includes_weight(self):
        dim = JurisdictionalCompliance()
        score = dim.evaluate(_action(), _ctx())
        assert score.weight == 1.4
