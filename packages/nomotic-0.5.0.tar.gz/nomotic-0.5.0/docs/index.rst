Nomotic Documentation
=====================

Runtime governance framework for agentic AI.

.. toctree::
   :maxdepth: 2
   :caption: Getting Started

   quickstart
   concepts
   tutorial

.. toctree::
   :maxdepth: 2
   :caption: User Guide

   configuration
   dimensions
   architecture

.. toctree::
   :maxdepth: 2
   :caption: API Reference

   api/runtime
   api/executor
   api/evaluator
   api/dimensions
   api/trust
   api/drift
   api/audit
   api/workflow
   api/token
   api/certificate
   api/sdk
   api/integrations

.. toctree::
   :maxdepth: 1
   :caption: Development

   contributing
   changelog
