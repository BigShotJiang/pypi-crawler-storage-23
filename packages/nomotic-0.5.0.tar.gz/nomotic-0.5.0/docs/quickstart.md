# Quickstart

Get up and running with Nomotic in minutes.

## Installation

```bash
pip install nomotic
```

For development:

```bash
git clone https://github.com/nomoticai/nomotic.git
cd nomotic
pip install -e ".[dev]"
```

## Your First Governance Evaluation

```python
from nomotic import (
    Action,
    AgentContext,
    GovernanceRuntime,
    TrustProfile,
    Verdict,
)

# Create the runtime — all 14 dimensions, three evaluation tiers,
# interruption authority, trust calibration, and audit trail are initialized.
runtime = GovernanceRuntime()

# Configure what the agent is allowed to do
runtime.configure_scope(
    agent_id="agent-1",
    scope={"read", "write", "query"},
    actor="admin@acme.com",
    reason="Initial agent deployment",
)

# Create an action the agent wants to perform
action = Action(
    agent_id="agent-1",
    action_type="write",
    target="customer_records",
    parameters={"field": "email", "value": "new@example.com"},
)

# Create the agent's context
context = AgentContext(
    agent_id="agent-1",
    trust_profile=TrustProfile(agent_id="agent-1"),
)

# Evaluate the action through the full governance pipeline
verdict = runtime.evaluate(action, context)

print(f"Verdict: {verdict.verdict.name}")  # ALLOW, DENY, MODIFY, ESCALATE, or SUSPEND
print(f"UCS: {verdict.ucs:.3f}")           # 0.0-1.0 unified confidence
print(f"Tier: {verdict.tier}")             # Which tier decided (1, 2, or 3)
print(f"Time: {verdict.evaluation_time_ms:.1f}ms")
```

## Birth an Agent (CLI)

Create a governed agent with a certificate:

```bash
nomotic birth --name my-agent --role assistant
```

This creates an agent certificate and configures initial governance scope.

## Query the Audit Trail

```bash
nomotic audit my-agent
```

Or programmatically:

```python
from nomotic import AuditStore

store = AuditStore()
records = store.get_records("my-agent")
for record in records:
    print(f"{record.timestamp}: {record.verdict} - {record.action_type}")
```

## Execution with Interruption Rights

For approved actions, the runtime provides execution handles that allow governance to intervene mid-stream:

```python
if verdict.verdict == Verdict.ALLOW:
    handle = runtime.begin_execution(
        action,
        context,
        rollback=lambda: undo_write(action),
    )

    for record in records_to_process:
        if handle.check_interrupt():
            break  # Governance has halted this action
        process(record)

    runtime.complete_execution(action.id, context)
```

## Next Steps

- [Concepts](concepts.md) — Understand the 14 governance dimensions and trust model
- [Configuration](configuration.md) — Tune thresholds, weights, and policies
- [Architecture](architecture.md) — Full architectural design
- [API Reference](api/runtime.rst) — Detailed class and method documentation
