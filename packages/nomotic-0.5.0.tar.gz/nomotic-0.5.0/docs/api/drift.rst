Drift Detection
===============

.. automodule:: nomotic.drift
   :members:
   :show-inheritance:
