Framework Integrations
======================

CrewAI Adapter
--------------

.. automodule:: nomotic.integrations.crewai_adapter
   :members:
   :show-inheritance:

LangGraph Adapter
-----------------

.. automodule:: nomotic.integrations.langgraph_adapter
   :members:
   :show-inheritance:

AutoGen Adapter
---------------

.. automodule:: nomotic.integrations.autogen_adapter
   :members:
   :show-inheritance:
