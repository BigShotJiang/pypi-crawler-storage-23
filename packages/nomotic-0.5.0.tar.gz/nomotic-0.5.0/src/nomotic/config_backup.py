"""Tamper-resistant configuration backups.

Creates signed backups of critical governance configuration artifacts:
- constitutional_ruleset: The signed constitutional rules
- authority_registry:     Governance change authorities
- role_registry:          Override permission roles

Each backup is HMAC-SHA256 signed using a configured secret.
Backups are stored as JSON files in base_dir/backups/<artifact_type>/.
A maximum of N backups per type are retained (oldest pruned first).

Usage:
    mgr = ConfigBackupManager(
        base_dir=Path("~/.nomotic"),
        signing_secret="your-secret-here",
        max_backups_per_type=5,
    )
    # Create backup
    backup = mgr.backup("constitutional_ruleset", ruleset.to_dict())

    # Verify latest
    valid, msg = mgr.verify_latest("constitutional_ruleset")

    # Restore latest verified backup
    content = mgr.restore_latest("constitutional_ruleset")
"""

from __future__ import annotations

import hashlib
import hmac
import json
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import nomotic

__all__ = ["ConfigBackup", "ConfigBackupManager"]


@dataclass
class ConfigBackup:
    """A signed backup of a governance configuration artifact."""

    backup_id: str  # nmbk-<uuid>
    artifact_type: str  # "constitutional_ruleset", "authority_registry", "role_registry"
    created_at: float  # Unix timestamp
    content_hash: str  # SHA-256 of JSON-serialized content
    content: dict[str, Any]  # The artifact
    signature: str  # HMAC-SHA256(content_hash + ":" + str(created_at))
    nomotic_version: str  # nomotic.__version__ at backup time

    def verify(self, signing_secret: str) -> bool:
        """Verify signature. Returns False if tampered."""
        expected = hmac.new(
            signing_secret.encode("utf-8"),
            f"{self.content_hash}:{self.created_at}".encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()
        return hmac.compare_digest(expected, self.signature)

    def to_dict(self) -> dict[str, Any]:
        """Serialize for storage. Content stored inline."""
        return {
            "backup_id": self.backup_id,
            "artifact_type": self.artifact_type,
            "created_at": self.created_at,
            "content_hash": self.content_hash,
            "content": self.content,
            "signature": self.signature,
            "nomotic_version": self.nomotic_version,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> ConfigBackup:
        """Deserialize from stored dict."""
        return cls(
            backup_id=d["backup_id"],
            artifact_type=d["artifact_type"],
            created_at=d["created_at"],
            content_hash=d["content_hash"],
            content=d["content"],
            signature=d["signature"],
            nomotic_version=d["nomotic_version"],
        )


class ConfigBackupManager:
    """Creates, stores, verifies, and restores signed configuration backups."""

    VALID_ARTIFACT_TYPES = frozenset({
        "constitutional_ruleset",
        "authority_registry",
        "role_registry",
    })

    def __init__(
        self,
        base_dir: Path,
        signing_secret: str,
        max_backups_per_type: int = 5,
    ) -> None:
        if not signing_secret:
            raise ValueError(
                "signing_secret is required for ConfigBackupManager. "
                "Set config_backup_signing_secret in RuntimeConfig."
            )
        self._base_dir = Path(base_dir) / "backups"
        self._secret = signing_secret
        self._max = max_backups_per_type
        self._base_dir.mkdir(parents=True, exist_ok=True)

    def backup(
        self,
        artifact_type: str,
        content: dict[str, Any],
    ) -> ConfigBackup:
        """Create and persist a signed backup.

        Raises ValueError for unknown artifact_type.
        Auto-prunes old backups after writing.
        """
        if artifact_type not in self.VALID_ARTIFACT_TYPES:
            raise ValueError(
                f"Unknown artifact_type '{artifact_type}'. "
                f"Valid types: {sorted(self.VALID_ARTIFACT_TYPES)}"
            )

        backup_id = f"nmbk-{uuid.uuid4()}"
        created_at = time.time()
        content_hash = self._compute_content_hash(content)
        signature = self._compute_signature(content_hash, created_at)

        backup = ConfigBackup(
            backup_id=backup_id,
            artifact_type=artifact_type,
            created_at=created_at,
            content_hash=content_hash,
            content=content,
            signature=signature,
            nomotic_version=nomotic.__version__,
        )

        # Persist
        backup_dir = self._backup_dir(artifact_type)
        filename = f"{backup_id}.json"
        filepath = backup_dir / filename
        filepath.write_text(
            json.dumps(backup.to_dict(), indent=2, sort_keys=True),
            encoding="utf-8",
        )

        # Auto-prune
        self.cleanup_old_backups(artifact_type)

        return backup

    def verify_latest(self, artifact_type: str) -> tuple[bool, str]:
        """Verify the most recent backup's signature.

        Returns:
            (True, "Backup verified: nmbk-<id>") on success
            (False, "No backups found") if no backups exist
            (False, "Signature verification failed") if tampered
        """
        backups = self.list_backups(artifact_type)
        if not backups:
            return (False, "No backups found")

        latest = backups[0]
        if latest.verify(self._secret):
            return (True, f"Backup verified: {latest.backup_id}")
        return (False, "Signature verification failed")

    def restore_latest(
        self, artifact_type: str,
    ) -> dict[str, Any] | None:
        """Return content of most recent verified backup.

        Verifies signature before returning. Returns None if:
        - No backups exist
        - Latest backup fails verification
        """
        backups = self.list_backups(artifact_type)
        if not backups:
            return None

        latest = backups[0]
        if not latest.verify(self._secret):
            return None
        return latest.content

    def list_backups(
        self,
        artifact_type: str | None = None,
    ) -> list[ConfigBackup]:
        """List available backups, optionally filtered by type.

        Returns most recent first (sorted by created_at descending).
        """
        backups: list[ConfigBackup] = []
        types = [artifact_type] if artifact_type else sorted(self.VALID_ARTIFACT_TYPES)

        for atype in types:
            backup_dir = self._base_dir / atype
            if not backup_dir.exists():
                continue
            for filepath in backup_dir.glob("nmbk-*.json"):
                try:
                    data = json.loads(filepath.read_text(encoding="utf-8"))
                    backups.append(ConfigBackup.from_dict(data))
                except (json.JSONDecodeError, KeyError, OSError):
                    continue

        backups.sort(key=lambda b: b.created_at, reverse=True)
        return backups

    def cleanup_old_backups(self, artifact_type: str) -> int:
        """Remove old backups beyond max_backups_per_type.

        Keeps the N most recent, deletes the rest.
        Returns count of deleted files.
        """
        backup_dir = self._base_dir / artifact_type
        if not backup_dir.exists():
            return 0

        # Collect all backup files with their timestamps
        entries: list[tuple[float, Path]] = []
        for filepath in backup_dir.glob("nmbk-*.json"):
            try:
                data = json.loads(filepath.read_text(encoding="utf-8"))
                created_at = data.get("created_at", 0.0)
                entries.append((created_at, filepath))
            except (json.JSONDecodeError, KeyError, OSError):
                continue

        # Sort newest first
        entries.sort(key=lambda e: e[0], reverse=True)

        deleted = 0
        for _ts, filepath in entries[self._max:]:
            try:
                filepath.unlink()
                deleted += 1
            except OSError:
                pass

        return deleted

    def _backup_dir(self, artifact_type: str) -> Path:
        d = self._base_dir / artifact_type
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _compute_content_hash(self, content: dict[str, Any]) -> str:
        canonical = json.dumps(
            content, sort_keys=True, separators=(",", ":")
        ).encode("utf-8")
        return hashlib.sha256(canonical).hexdigest()

    def _compute_signature(self, content_hash: str, created_at: float) -> str:
        msg = f"{content_hash}:{created_at}".encode("utf-8")
        return hmac.new(
            self._secret.encode("utf-8"), msg, hashlib.sha256
        ).hexdigest()
