"""Immutable Pre-Execution Record — commitment before execution begins.

After governance approval and before the execution handle is issued, a signed
pre-execution record is written: a commitment that says "governance approved
this action, agent X, at timestamp T, under governance seal S."

Records are:
1. **Immutable** — written once, never modified.
2. **Hash-chained** — linked to the preceding record for the agent.
3. **Seal-linked** — includes the governance seal ID if a seal was issued.
4. **Settlement-aware** — a settlement record completes the pair on finish.

Auditors can verify: for every pre-execution record, there is a settlement
record. Unsettled pre-execution records are visible anomalies.
"""

from __future__ import annotations

import hashlib
import json
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

__all__ = [
    "ExecutionOutcome",
    "ExecutionSettlementRecord",
    "PreExecutionLedger",
    "PreExecutionRecord",
]

_GENESIS_HASH = "sha256:" + hashlib.sha256(b"genesis").hexdigest()


@dataclass
class PreExecutionRecord:
    """Immutable commitment record written before execution begins."""

    record_id: str  # nmpe-<uuid4>
    agent_id: str
    action_id: str
    action_type: str
    action_target: str
    verdict: str  # Always "ALLOW" — only approved actions
    governance_seal_id: str | None  # Seal ID if seal was issued
    approved_at: float  # Unix timestamp of governance approval
    record_written_at: float  # Unix timestamp of this record
    previous_record_hash: str  # Hash of previous record for this agent
    record_hash: str  # SHA-256 of canonical JSON (all fields except record_hash)
    context_profile_id: str | None = None
    estimated_cost_usd: float = 0.0
    budget_reservation_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def compute_hash(self) -> str:
        """Compute SHA-256 hash of canonical JSON (all fields except record_hash)."""
        d = self.to_dict()
        d.pop("record_hash", None)
        canonical = json.dumps(d, sort_keys=True, separators=(",", ":"))
        return "sha256:" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PreExecutionRecord:
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


class ExecutionOutcome(str, Enum):
    SUCCESS = "success"
    FAILURE = "failure"
    INTERRUPTED = "interrupted"
    TIMEOUT = "timeout"
    UNKNOWN = "unknown"  # Settlement written but outcome unclear


@dataclass
class ExecutionSettlementRecord:
    """Written when execution completes — settles a PreExecutionRecord."""

    settlement_id: str  # nmps-<uuid4>
    pre_execution_record_id: str  # Links to PreExecutionRecord.record_id
    agent_id: str
    action_id: str
    outcome: ExecutionOutcome
    settled_at: float
    actual_cost_usd: float = 0.0
    actual_tokens: int = 0
    error_message: str | None = None
    settlement_hash: str = ""  # SHA-256 of canonical JSON

    def compute_hash(self) -> str:
        """Compute SHA-256 hash of canonical JSON (all fields except settlement_hash)."""
        d = self.to_dict()
        d.pop("settlement_hash", None)
        canonical = json.dumps(d, sort_keys=True, separators=(",", ":"))
        return "sha256:" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        # Serialize enum value
        d["outcome"] = self.outcome.value
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ExecutionSettlementRecord:
        d = {k: v for k, v in data.items() if k in cls.__dataclass_fields__}
        if "outcome" in d and isinstance(d["outcome"], str):
            d["outcome"] = ExecutionOutcome(d["outcome"])
        return cls(**d)


class PreExecutionLedger:
    """Append-only ledger of pre-execution and settlement records.

    Thread-safe. Persists to base_dir/pre_execution/ as JSONL files,
    one file per agent: <agent_id>.jsonl for records,
    <agent_id>_settlements.jsonl for settlements.
    """

    def __init__(self, base_dir: Path) -> None:
        self._dir = base_dir / "pre_execution"
        self._dir.mkdir(parents=True, exist_ok=True)
        # Per-agent locks for thread safety
        self._locks: dict[str, threading.Lock] = {}
        self._global_lock = threading.Lock()
        # In-memory indices for fast lookups
        self._records_by_action: dict[str, PreExecutionRecord] = {}
        self._settlements_by_action: dict[str, ExecutionSettlementRecord] = {}

    def _agent_lock(self, agent_id: str) -> threading.Lock:
        """Get or create a per-agent lock."""
        with self._global_lock:
            if agent_id not in self._locks:
                self._locks[agent_id] = threading.Lock()
            return self._locks[agent_id]

    def _safe_name(self, agent_id: str) -> str:
        return agent_id.lower().replace("/", "_").replace("\\", "_")

    def _records_file(self, agent_id: str) -> Path:
        return self._dir / f"{self._safe_name(agent_id)}.jsonl"

    def _settlements_file(self, agent_id: str) -> Path:
        return self._dir / f"{self._safe_name(agent_id)}_settlements.jsonl"

    def _get_last_record_hash(self, agent_id: str) -> str:
        """Read last record hash for chain linking."""
        path = self._records_file(agent_id)
        if not path.exists():
            return _GENESIS_HASH
        last_line = ""
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    last_line = line
        if not last_line:
            return _GENESIS_HASH
        try:
            record = json.loads(last_line)
            return record.get("record_hash", _GENESIS_HASH)
        except json.JSONDecodeError:
            return _GENESIS_HASH

    def write_pre_execution(
        self,
        agent_id: str,
        action_id: str,
        action_type: str,
        action_target: str,
        governance_seal_id: str | None = None,
        approved_at: float | None = None,
        context_profile_id: str | None = None,
        estimated_cost_usd: float = 0.0,
        budget_reservation_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> PreExecutionRecord:
        """Write a new pre-execution record.

        Reads last record for agent to get previous_record_hash.
        Computes record_hash. Appends to agent's JSONL file.
        Thread-safe per agent_id via per-agent lock.
        """
        lock = self._agent_lock(agent_id)
        with lock:
            previous_hash = self._get_last_record_hash(agent_id)
            now = time.time()
            record = PreExecutionRecord(
                record_id=f"nmpe-{uuid.uuid4()}",
                agent_id=agent_id,
                action_id=action_id,
                action_type=action_type,
                action_target=action_target,
                verdict="ALLOW",
                governance_seal_id=governance_seal_id,
                approved_at=approved_at or now,
                record_written_at=now,
                previous_record_hash=previous_hash,
                record_hash="",  # computed below
                context_profile_id=context_profile_id,
                estimated_cost_usd=estimated_cost_usd,
                budget_reservation_id=budget_reservation_id,
                metadata=metadata or {},
            )
            record.record_hash = record.compute_hash()

            # Persist
            line = json.dumps(record.to_dict(), separators=(",", ":"))
            with open(self._records_file(agent_id), "a", encoding="utf-8") as f:
                f.write(line + "\n")

            # Index
            self._records_by_action[action_id] = record
            return record

    def settle(
        self,
        action_id: str,
        outcome: ExecutionOutcome,
        actual_cost_usd: float = 0.0,
        actual_tokens: int = 0,
        error_message: str | None = None,
    ) -> ExecutionSettlementRecord:
        """Write a settlement record for a pre-execution record.

        Looks up PreExecutionRecord by action_id.
        Raises KeyError if no pre-execution record for action_id.
        Raises RuntimeError if already settled.
        """
        pe_record = self.get_record(action_id)
        if pe_record is None:
            raise KeyError(f"No pre-execution record for action_id={action_id}")

        if action_id in self._settlements_by_action:
            raise RuntimeError(
                f"Action {action_id} already settled"
            )

        # Also check on-disk settlements
        existing = self._load_settlement_from_disk(action_id, pe_record.agent_id)
        if existing is not None:
            self._settlements_by_action[action_id] = existing
            raise RuntimeError(
                f"Action {action_id} already settled"
            )

        settlement = ExecutionSettlementRecord(
            settlement_id=f"nmps-{uuid.uuid4()}",
            pre_execution_record_id=pe_record.record_id,
            agent_id=pe_record.agent_id,
            action_id=action_id,
            outcome=outcome,
            settled_at=time.time(),
            actual_cost_usd=actual_cost_usd,
            actual_tokens=actual_tokens,
            error_message=error_message,
        )
        settlement.settlement_hash = settlement.compute_hash()

        # Persist
        lock = self._agent_lock(pe_record.agent_id)
        with lock:
            line = json.dumps(settlement.to_dict(), separators=(",", ":"))
            with open(
                self._settlements_file(pe_record.agent_id), "a", encoding="utf-8"
            ) as f:
                f.write(line + "\n")

        # Index
        self._settlements_by_action[action_id] = settlement
        return settlement

    def _load_settlement_from_disk(
        self, action_id: str, agent_id: str,
    ) -> ExecutionSettlementRecord | None:
        """Check disk for an existing settlement for action_id."""
        path = self._settlements_file(agent_id)
        if not path.exists():
            return None
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    if data.get("action_id") == action_id:
                        return ExecutionSettlementRecord.from_dict(data)
                except (json.JSONDecodeError, TypeError):
                    continue
        return None

    def get_unsettled(
        self,
        agent_id: str | None = None,
    ) -> list[PreExecutionRecord]:
        """Return pre-execution records with no matching settlement."""
        if agent_id is not None:
            records = self.get_agent_records(agent_id, limit=10000)
        else:
            records = self._load_all_records()

        unsettled = []
        for r in records:
            if self.get_settlement(r.action_id) is None:
                unsettled.append(r)
        return unsettled

    def _load_all_records(self) -> list[PreExecutionRecord]:
        """Load all pre-execution records across all agents."""
        all_records: list[PreExecutionRecord] = []
        for path in sorted(self._dir.glob("*.jsonl")):
            if path.name.endswith("_settlements.jsonl"):
                continue
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        data = json.loads(line)
                        rec = PreExecutionRecord.from_dict(data)
                        self._records_by_action[rec.action_id] = rec
                        all_records.append(rec)
                    except (json.JSONDecodeError, TypeError):
                        continue
        return all_records

    def get_record(self, action_id: str) -> PreExecutionRecord | None:
        """Look up a pre-execution record by action_id."""
        if action_id in self._records_by_action:
            return self._records_by_action[action_id]
        # Scan all record files
        for path in sorted(self._dir.glob("*.jsonl")):
            if path.name.endswith("_settlements.jsonl"):
                continue
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        data = json.loads(line)
                        if data.get("action_id") == action_id:
                            rec = PreExecutionRecord.from_dict(data)
                            self._records_by_action[action_id] = rec
                            return rec
                    except (json.JSONDecodeError, TypeError):
                        continue
        return None

    def get_settlement(self, action_id: str) -> ExecutionSettlementRecord | None:
        """Look up a settlement record by action_id."""
        if action_id in self._settlements_by_action:
            return self._settlements_by_action[action_id]
        # Need to find the agent_id first
        pe_record = self.get_record(action_id)
        if pe_record is None:
            return None
        settlement = self._load_settlement_from_disk(action_id, pe_record.agent_id)
        if settlement is not None:
            self._settlements_by_action[action_id] = settlement
        return settlement

    def get_agent_records(
        self,
        agent_id: str,
        limit: int = 100,
    ) -> list[PreExecutionRecord]:
        """Get pre-execution records for a specific agent."""
        path = self._records_file(agent_id)
        if not path.exists():
            return []
        records: list[PreExecutionRecord] = []
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    rec = PreExecutionRecord.from_dict(data)
                    self._records_by_action[rec.action_id] = rec
                    records.append(rec)
                except (json.JSONDecodeError, TypeError):
                    continue
        return records[-limit:]

    def verify_chain(self, agent_id: str) -> tuple[bool, int, str]:
        """Verify hash chain integrity for agent's pre-execution records.

        Returns (is_valid, record_count, message).
        """
        path = self._records_file(agent_id)
        if not path.exists():
            return True, 0, "No records found"

        records: list[PreExecutionRecord] = []
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    records.append(PreExecutionRecord.from_dict(json.loads(line)))
                except (json.JSONDecodeError, TypeError):
                    continue

        if not records:
            return True, 0, "No records found"

        previous_hash = _GENESIS_HASH
        for i, record in enumerate(records):
            # Verify record hash
            expected = record.compute_hash()
            if record.record_hash != expected:
                return False, len(records), (
                    f"TAMPERING DETECTED at record #{i + 1} ({record.record_id}). "
                    f"Expected hash: {expected[:32]}... "
                    f"Actual hash: {record.record_hash[:32]}..."
                )
            # Verify chain link
            if record.previous_record_hash != previous_hash:
                return False, len(records), (
                    f"CHAIN BREAK at record #{i + 1} ({record.record_id}). "
                    f"Previous hash mismatch."
                )
            previous_hash = record.record_hash

        return True, len(records), "Chain integrity verified"
