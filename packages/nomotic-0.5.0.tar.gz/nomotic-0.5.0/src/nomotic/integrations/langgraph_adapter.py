"""LangGraph integration -- governance as a graph node.

Usage:
    from langgraph.graph import StateGraph
    from nomotic.integrations.langgraph_adapter import governance_node

    # Add governance as a node in your graph
    graph = StateGraph(AgentState)
    graph.add_node("think", agent_node)
    graph.add_node("govern", governance_node("claims-bot"))  # one line
    graph.add_node("execute", tool_node)

    # Route: think -> govern -> execute (if allowed) or -> respond (if denied)
    graph.add_edge("think", "govern")
    graph.add_conditional_edges("govern", route_on_governance)
"""

from __future__ import annotations

from typing import Any, Callable


def governance_node(
    agent_id: str,
    *,
    test_mode: bool = False,
    base_dir: str | None = None,
    action_key: str = "pending_action",
    target_key: str = "pending_target",
    result_key: str = "governance_result",
) -> Callable:
    """Create a LangGraph node that evaluates governance.

    The node reads the pending action from the state, evaluates it
    through Nomotic, and writes the governance result back to state.

    Args:
        agent_id: Nomotic agent identity
        test_mode: If True, use simulated trust and testlog
        base_dir: Nomotic config directory (default ~/.nomotic)
        action_key: State key containing the action to evaluate
        target_key: State key containing the target resource
        result_key: State key to write the governance result

    Returns:
        A LangGraph-compatible node function
    """
    from nomotic.executor import GovernedToolExecutor
    from pathlib import Path

    kwargs: dict[str, Any] = {"test_mode": test_mode}
    if base_dir:
        kwargs["base_dir"] = Path(base_dir)

    executor = GovernedToolExecutor.connect(agent_id, **kwargs)

    def node(state: dict[str, Any]) -> dict[str, Any]:
        action = state.get(action_key, "")
        target = state.get(target_key, "")
        params = state.get("pending_params", {})

        result = executor.check(action, target, params)

        return {
            result_key: {
                "allowed": result.allowed,
                "verdict": result.verdict,
                "reason": result.reason,
                "ucs": result.ucs,
                "trust": result.trust_after,
            }
        }

    return node


def route_on_governance(
    state: dict[str, Any], result_key: str = "governance_result"
) -> str:
    """Conditional edge function: route based on governance verdict.

    Returns "execute" if allowed, "denied" if not.
    Use with graph.add_conditional_edges().
    """
    result = state.get(result_key, {})
    if result.get("allowed", False):
        return "execute"
    return "denied"


def govern_langchain_tools(
    agent_id: str,
    tools: list,
    *,
    test_mode: bool = False,
    base_dir: str | None = None,
) -> list:
    """Wrap LangChain tools with Nomotic governance.

    Similar to CrewAI adapter -- wraps each tool's _run method.
    Works with LangChain's BaseTool subclasses.

    Args:
        agent_id: Nomotic agent identity (name or ID)
        tools: List of LangChain BaseTool objects
        test_mode: If True, use simulated trust and testlog
        base_dir: Nomotic config directory (default ~/.nomotic)

    Returns:
        List of governed LangChain Tool objects (same interface, governance added)
    """
    from nomotic.executor import GovernedToolExecutor
    from pathlib import Path

    kwargs: dict[str, Any] = {"test_mode": test_mode}
    if base_dir:
        kwargs["base_dir"] = Path(base_dir)

    executor = GovernedToolExecutor.connect(agent_id, **kwargs)

    governed = []
    for tool in tools:
        governed.append(_wrap_langchain_tool(tool, executor))
    return governed


def _wrap_langchain_tool(tool: Any, executor: Any) -> Any:
    """Wrap a single LangChain tool."""
    original_run = tool._run
    tool_name = tool.name

    def governed_run(query: str, **kwargs: Any) -> str:
        result = executor.execute(
            action=tool_name,
            target=query,
            params=kwargs,
            tool_fn=lambda: original_run(query, **kwargs),
        )
        if result.allowed:
            return result.data
        return f"[GOVERNANCE DENIED] {result.reason}"

    tool._run = governed_run
    return tool
