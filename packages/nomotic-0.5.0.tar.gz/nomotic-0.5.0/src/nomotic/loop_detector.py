"""Loop Detection Monitor — governance-aware repetitive action detection.

Detects when an agent repeatedly requests the same action against the same
target within a session and triggers governance consequences: trust decay
at the warning threshold, interrupt authority at the halt threshold.

This is an interrupt monitor, not a new governance dimension. It tracks
action_type + target pairs within a sliding time window. The agent cannot
ignore the consequences — they are mechanical.

Usage:
    detector = LoopDetector()

    # Register as interrupt monitor
    interrupt_authority.add_monitor(detector.check)

    # Record each action as it's evaluated (before execution)
    event = detector.record_action(action)
    if event and event.level == "warning":
        # Apply trust decay
        ...

    # check() is called by InterruptAuthority.check_monitors()
    # Returns InterruptRequest if halt threshold exceeded
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

from nomotic.types import Action, InterruptRequest, Severity

__all__ = [
    "LoopDetector",
    "LoopDetectorConfig",
    "LoopEvent",
]


@dataclass
class LoopDetectorConfig:
    """Configuration for loop detection thresholds."""

    # How many identical action+target pairs before warning (trust decay)
    warning_threshold: int = 5

    # How many before interrupt (halt)
    halt_threshold: int = 10

    # Time window in seconds — only count actions within this window
    # Actions older than this are evicted from tracking
    window_seconds: float = 120.0

    # Trust penalty per loop warning (applied once per warning-threshold crossing)
    trust_decay_per_warning: float = 0.05

    # Whether near-duplicate targets count as the same target
    # e.g., "users/123" and "users/124" are near-duplicates if target_prefix_match is True
    target_prefix_match: bool = False
    target_prefix_depth: int = 1  # How many path segments to match

    # Exempt action types that are naturally repetitive (e.g., "read", "list")
    exempt_action_types: list[str] = field(
        default_factory=lambda: ["read", "list", "get", "query"]
    )


@dataclass
class LoopRecord:
    """A single tracked action occurrence."""

    action_type: str
    target: str
    timestamp: float


@dataclass
class LoopEvent:
    """Event emitted when a loop threshold is crossed."""

    agent_id: str
    action_type: str
    target: str
    count: int
    level: str  # "warning" or "halt"
    window_seconds: float
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "action_type": self.action_type,
            "target": self.target,
            "count": self.count,
            "level": self.level,
            "window_seconds": self.window_seconds,
            "timestamp": self.timestamp,
        }


class LoopDetector:
    """Detects repetitive action patterns within a session.

    Tracks action_type + target pairs within a sliding time window.
    When repetition exceeds warning_threshold, triggers trust decay.
    When repetition exceeds halt_threshold, produces an InterruptRequest.

    Usage:
        detector = LoopDetector()

        # Register as interrupt monitor
        interrupt_authority.add_monitor(detector.check)

        # Record each action as it's evaluated (before execution)
        detector.record_action(action)

        # check() is called by InterruptAuthority.check_monitors()
        # Returns InterruptRequest if halt threshold exceeded
    """

    def __init__(self, config: LoopDetectorConfig | None = None):
        self._config = config or LoopDetectorConfig()
        # Tracking: agent_id -> list[LoopRecord]
        self._history: dict[str, list[LoopRecord]] = {}
        # Track which agents have already received warning-level trust decay
        # Key: (agent_id, action_key) -> count at last warning
        self._warned: dict[tuple[str, str], int] = {}

    def record_action(self, action: Action) -> LoopEvent | None:
        """Record an action occurrence and check for loop patterns.

        Call this when an action is submitted for governance evaluation,
        BEFORE execution. Returns a LoopEvent if a threshold was crossed,
        or None if the action is normal.

        Args:
            action: The Action being evaluated

        Returns:
            LoopEvent with level="warning" or "halt" if threshold crossed,
            None otherwise
        """
        if action.action_type in self._config.exempt_action_types:
            return None

        agent_id = action.agent_id
        now = time.time()

        # Add to history
        record = LoopRecord(
            action_type=action.action_type,
            target=self._normalize_target(action.target),
            timestamp=now,
        )
        if agent_id not in self._history:
            self._history[agent_id] = []
        self._history[agent_id].append(record)

        # Evict old entries outside the time window
        self._evict(agent_id, now)

        # Count repetitions for this action+target pair
        action_key = self._action_key(action.action_type, action.target)
        count = self._count_repetitions(agent_id, action.action_type, action.target)

        # Check thresholds
        if count >= self._config.halt_threshold:
            return LoopEvent(
                agent_id=agent_id,
                action_type=action.action_type,
                target=action.target,
                count=count,
                level="halt",
                window_seconds=self._config.window_seconds,
            )

        if count >= self._config.warning_threshold:
            # Only emit warning if we haven't already for this count level
            warned_key = (agent_id, action_key)
            last_warned = self._warned.get(warned_key, 0)
            if count > last_warned:
                self._warned[warned_key] = count
                return LoopEvent(
                    agent_id=agent_id,
                    action_type=action.action_type,
                    target=action.target,
                    count=count,
                    level="warning",
                    window_seconds=self._config.window_seconds,
                )

        return None

    def check(self, handle: Any) -> InterruptRequest | None:
        """Interrupt monitor callback for InterruptAuthority.

        Called by InterruptAuthority.check_monitors(handle).
        Checks if the action on this handle has exceeded the halt threshold.

        This is the ENFORCEMENT side. record_action() is the DETECTION side.
        Both are needed — record_action detects and returns events for trust decay,
        check() produces the InterruptRequest that actually halts the agent.
        """
        action = handle.action
        if action.action_type in self._config.exempt_action_types:
            return None

        count = self._count_repetitions(
            handle.agent_id, action.action_type, action.target
        )

        if count >= self._config.halt_threshold:
            return InterruptRequest(
                action_id=action.id,
                reason=(
                    f"Loop detected: {action.action_type} on '{action.target}' "
                    f"repeated {count} times in {self._config.window_seconds}s window "
                    f"(halt threshold: {self._config.halt_threshold})"
                ),
                source="loop_detector",
                severity=Severity.HIGH,
                scope="agent",  # Stop the agent, not just this action
            )

        return None

    def get_repetition_count(self, agent_id: str, action_type: str, target: str) -> int:
        """Get current repetition count for an action+target pair.

        Useful for external reporting and diagnostics.
        """
        self._evict(agent_id, time.time())
        return self._count_repetitions(agent_id, action_type, target)

    def reset(self, agent_id: str | None = None) -> None:
        """Reset tracking for an agent (or all agents)."""
        if agent_id:
            self._history.pop(agent_id, None)
            self._warned = {
                k: v for k, v in self._warned.items() if k[0] != agent_id
            }
        else:
            self._history.clear()
            self._warned.clear()

    def _count_repetitions(self, agent_id: str, action_type: str, target: str) -> int:
        """Count how many times this action+target appears in the current window."""
        normalized_target = self._normalize_target(target)
        records = self._history.get(agent_id, [])
        return sum(
            1
            for r in records
            if r.action_type == action_type
            and self._targets_match(r.target, normalized_target)
        )

    def _normalize_target(self, target: str) -> str:
        """Normalize target for comparison.

        If target_prefix_match is enabled, truncate to prefix_depth segments.
        Otherwise return as-is.
        """
        if not self._config.target_prefix_match or not target:
            return target
        parts = target.strip("/").split("/")
        return "/".join(parts[: self._config.target_prefix_depth])

    def _targets_match(self, a: str, b: str) -> bool:
        """Check if two normalized targets match."""
        return a == b

    def _action_key(self, action_type: str, target: str) -> str:
        """Create a hashable key for action+target pairs."""
        return f"{action_type}::{self._normalize_target(target)}"

    def _evict(self, agent_id: str, now: float) -> None:
        """Remove entries outside the time window."""
        if agent_id not in self._history:
            return
        cutoff = now - self._config.window_seconds
        self._history[agent_id] = [
            r for r in self._history[agent_id] if r.timestamp > cutoff
        ]
        # Clean up warned state for agents with no recent history
        if not self._history[agent_id]:
            self._warned = {
                k: v for k, v in self._warned.items() if k[0] != agent_id
            }
