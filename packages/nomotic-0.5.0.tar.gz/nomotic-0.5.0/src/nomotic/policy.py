"""Policy-as-Code — declarative governance pre-filters.

Policies are evaluated before dimensional evaluation.  If a policy
matches, its verdict (DENY or ESCALATE) takes precedence — dimensional
evaluation is skipped entirely.

Policies can only DENY or ESCALATE.  They CANNOT ALLOW — only dimensional
evaluation can approve an action.  This ensures that the 14-dimension
evaluation remains the authoritative source for approval decisions.

Policy files are loaded from:
  1. ``./nomotic-policies/`` (project-level, higher priority)
  2. ``~/.nomotic/policies/`` (user-level)

JSON (``.json``) is the native policy file format — no extra dependencies.
YAML (``.yaml`` / ``.yml``) is supported when PyYAML is installed.  If a
YAML file is encountered without PyYAML, a ``PolicyLoadError`` is raised.
"""

from __future__ import annotations

import fnmatch
import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from nomotic.types import Action, AgentContext, TrustProfile

__all__ = [
    "DryRunResult",
    "PolicyDryRunner",
    "PolicyEngine",
    "PolicyLoadError",
    "PolicyResult",
    "PolicyRule",
    "SimulatedOverride",
]


class PolicyLoadError(Exception):
    """Raised when a policy file cannot be loaded."""


@dataclass
class PolicyRule:
    """A single governance policy rule."""

    name: str
    description: str = ""
    when: dict[str, Any] = field(default_factory=dict)
    then: dict[str, Any] = field(default_factory=dict)
    enabled: bool = True
    priority: int = 0  # Higher priority rules evaluated first

    def matches(self, action: Action, context: AgentContext) -> bool:
        """Check if this policy matches the given action and context."""
        if not self.when:
            return False
        for key, expected in self.when.items():
            actual = self._resolve_field(key, action, context)
            if not self._compare(actual, expected):
                return False
        return True

    def _resolve_field(
        self, key: str, action: Action, context: AgentContext
    ) -> Any:
        """Resolve a dotted field path to a value.

        Supported fields:
        - action_type -> action.action_type
        - target -> action.target
        - agent_id -> action.agent_id or context.agent_id
        - zone_path -> context.zone_path (via getattr)
        - parameters.* -> action.parameters[*]
        - metadata.* -> action.metadata[*]
        """
        if key == "action_type":
            return action.action_type
        if key == "target":
            return action.target
        if key == "agent_id":
            return action.agent_id or context.agent_id
        if key == "zone_path":
            return getattr(context, "zone_path", "")
        if key.startswith("parameters."):
            param_key = key[len("parameters."):]
            return action.parameters.get(param_key)
        if key.startswith("metadata."):
            meta_key = key[len("metadata."):]
            return action.metadata.get(meta_key)
        return None

    def _compare(self, actual: Any, expected: Any) -> bool:
        """Compare actual value against expected.

        Supports:
        - Exact match: ``"delete"`` matches ``"delete"``
        - Wildcard: ``"production/*"`` matches ``"production/db"``
        - Numeric comparison: ``"> 1000"``, ``"< 50"``, ``">= 100"``
        - List membership: ``["delete", "drop"]`` matches if actual is in list
        """
        if actual is None:
            return False

        # List membership
        if isinstance(expected, list):
            return actual in expected

        # String comparison with operators
        if isinstance(expected, str):
            # Numeric comparison operators
            for op, fn in [
                (">=", lambda a, b: a >= b),
                ("<=", lambda a, b: a <= b),
                (">", lambda a, b: a > b),
                ("<", lambda a, b: a < b),
                ("==", lambda a, b: a == b),
            ]:
                if expected.startswith(op + " "):
                    try:
                        return fn(
                            float(actual),
                            float(expected[len(op) + 1:].strip()),
                        )
                    except (ValueError, TypeError):
                        return False

            # Glob-style wildcard
            if "*" in expected:
                return fnmatch.fnmatch(str(actual), expected)

        # Exact match
        return str(actual) == str(expected)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "when": self.when,
            "then": self.then,
            "enabled": self.enabled,
            "priority": self.priority,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PolicyRule:
        policy_data = data.get("policy", data)
        return cls(
            name=policy_data["name"],
            description=policy_data.get("description", ""),
            when=policy_data.get("when", {}),
            then=policy_data.get("then", {}),
            enabled=policy_data.get("enabled", True),
            priority=policy_data.get("priority", 0),
        )


@dataclass
class PolicyResult:
    """Result of a policy evaluation."""

    matched_policy: str
    verdict: str  # "DENY" or "ESCALATE"
    reason: str
    require_human: bool = False


class PolicyEngine:
    """Loads and evaluates governance policies.

    Policies are loaded from JSON and YAML files in:
      1. ``./nomotic-policies/`` (project-level)
      2. ``~/.nomotic/policies/`` (user-level)

    Project policies take priority over user policies.
    """

    def __init__(self, policy_dirs: list[Path] | None = None) -> None:
        self._policies: list[PolicyRule] = []
        self._policy_path: str = "in-memory"
        if policy_dirs is not None:
            dirs = policy_dirs
        else:
            dirs = [
                Path("./nomotic-policies"),
                Path.home() / ".nomotic" / "policies",
            ]
        for d in dirs:
            self._load_from_dir(d)
        # Sort by priority (highest first)
        self._policies.sort(key=lambda p: p.priority, reverse=True)

    def evaluate(
        self, action: Action, context: AgentContext
    ) -> PolicyResult | None:
        """Evaluate all policies against an action.

        Returns a :class:`PolicyResult` if a policy matched, ``None`` if no
        policies matched (action should proceed to dimensional evaluation).
        """
        for policy in self._policies:
            if not policy.enabled:
                continue
            if policy.matches(action, context):
                return PolicyResult(
                    matched_policy=policy.name,
                    verdict=policy.then.get("verdict", "DENY"),
                    reason=policy.then.get(
                        "reason", f"Policy '{policy.name}' triggered"
                    ),
                    require_human=policy.then.get("require_human", False),
                )
        return None

    def dry_run(
        self,
        audit_store: LogStore,
        agent_id: str | None = None,
        days: int = 7,
        max_records: int = 1000,
        sim_overrides: list[SimulatedOverride] | None = None,
    ) -> DryRunResult:
        """Test this engine's policies against historical audit records.

        Returns what the current policy set would have done differently
        compared to the governance decisions already in the audit trail.
        """
        runner = PolicyDryRunner(audit_store=audit_store)
        policy_label = self._policy_path
        return runner.run_with_engine(
            engine=self,
            agent_id=agent_id,
            days=days,
            max_records=max_records,
            policy_label=policy_label,
            sim_overrides=sim_overrides,
        )

    def add_policy(self, policy: PolicyRule) -> None:
        """Add a policy programmatically."""
        self._policies.append(policy)
        self._policies.sort(key=lambda p: p.priority, reverse=True)

    def list_policies(self) -> list[PolicyRule]:
        """List all loaded policies."""
        return list(self._policies)

    def validate_all(self) -> list[dict[str, str]]:
        """Validate all loaded policies.  Returns list of issues."""
        issues: list[dict[str, str]] = []

        names: set[str] = set()
        for p in self._policies:
            if p.name in names:
                issues.append({
                    "policy": p.name,
                    "issue": "Duplicate policy name",
                })
            names.add(p.name)

            if not p.when:
                issues.append({
                    "policy": p.name,
                    "issue": "No 'when' conditions defined",
                })

            if not p.then:
                issues.append({
                    "policy": p.name,
                    "issue": "No 'then' outcome defined",
                })

            verdict = p.then.get("verdict", "")
            if verdict not in ("DENY", "ESCALATE"):
                issues.append({
                    "policy": p.name,
                    "issue": (
                        f"Invalid verdict '{verdict}'. "
                        "Must be DENY or ESCALATE."
                    ),
                })

        return issues

    def load_file(self, path: Path) -> None:
        """Load policies from a single file (public API for dry-run support)."""
        path = Path(path)
        if not path.exists():
            raise PolicyLoadError(f"Policy file not found: {path}")
        self._policy_path = str(path)
        self._load_file(path)
        self._policies.sort(key=lambda p: p.priority, reverse=True)

    # ── Internal helpers ──────────────────────────────────────────────

    def _load_from_dir(self, directory: Path) -> None:
        """Load policy files (JSON and YAML) from a directory."""
        if not directory.exists():
            return
        for path in sorted(directory.glob("*.json")):
            self._load_file(path)
        for path in sorted(directory.glob("*.yaml")):
            self._load_file(path)
        for path in sorted(directory.glob("*.yml")):
            self._load_file(path)

    def _load_file(self, path: Path) -> None:
        """Load a single policy file.

        JSON files are loaded natively.  YAML files require PyYAML;
        a ``PolicyLoadError`` is raised if PyYAML is not installed.

        Supports both single-rule format (``{"name": ..., "when": ...}``)
        and multi-rule format (``{"rules": [...]}``) for both JSON and YAML.
        """
        suffix = path.suffix.lower()

        if suffix == ".json":
            try:
                text = path.read_text()
                data = json.loads(text)
                if isinstance(data, dict):
                    self._load_rules_from_data(data)
            except Exception:
                pass  # Skip invalid files — validate_all catches structural issues

        elif suffix in (".yaml", ".yml"):
            try:
                import yaml
            except ImportError:
                raise PolicyLoadError(
                    f"YAML policy files require PyYAML: pip install pyyaml. File: {path}"
                )

            try:
                text = path.read_text()
                data = yaml.safe_load(text)
                if isinstance(data, dict):
                    self._load_rules_from_data(data)
            except PolicyLoadError:
                raise
            except Exception:
                pass  # Skip invalid files — validate_all catches structural issues

    def _load_rules_from_data(self, data: dict[str, Any]) -> None:
        """Load rules from parsed data, supporting both single and multi-rule formats."""
        if "rules" in data and isinstance(data["rules"], list):
            for rule_data in data["rules"]:
                if isinstance(rule_data, dict):
                    try:
                        self._policies.append(PolicyRule.from_dict(rule_data))
                    except (KeyError, TypeError):
                        pass
        else:
            self._policies.append(PolicyRule.from_dict(data))


# ── Forward reference import ────────────────────────────────────────
# LogStore is imported here (after PolicyEngine) to avoid circular imports.
from nomotic.audit_store import LogStore  # noqa: E402


@dataclass
class SimulatedOverride:
    """A simulated override applied during policy dry-run.

    Represents a hypothetical "what if this override had been active?"
    Does not create real overrides — simulation only.

    Fields:
        authority:      Who is simulating this override (for audit labeling)
        target_agents:  Agent IDs to simulate override for.
                        Empty list = apply to all agents.
        action_types:   Action types to override.
                        Empty list = apply to all action types.
        override_type:  "ALLOW_ANYWAY" — would allow despite policy denial
                        "ESCALATE_INSTEAD" — would escalate instead of deny
        reason:         Why this override is being simulated
    """

    authority: str
    target_agents: list[str] = field(default_factory=list)
    action_types: list[str] = field(default_factory=list)
    override_type: str = "ALLOW_ANYWAY"
    reason: str = ""

    def applies_to(self, agent_id: str, action_type: str) -> bool:
        """Returns True if this override would apply to the given agent/action."""
        agent_match = (not self.target_agents) or (agent_id in self.target_agents)
        action_match = (not self.action_types) or (action_type in self.action_types)
        return agent_match and action_match


@dataclass
class DryRunResult:
    """Result of evaluating a policy set against historical audit records.

    Shows what the proposed policy would have done differently from
    the governance decisions already recorded in the audit trail.
    """

    policy_file: str  # Path to the policy file tested
    agent_id: str | None  # None if fleet-wide
    records_evaluated: int
    matched_count: int  # Records that matched at least one policy
    would_deny: list[dict[str, Any]]  # Records policy would DENY (not already DENY)
    would_escalate: list[dict[str, Any]]  # Records policy would ESCALATE (not already ESCALATE)
    already_denied: int  # Records that were already DENY in audit trail
    new_denials: int  # Records policy would deny that weren't denied before
    new_escalations: int  # Records policy would escalate that weren't escalated before
    days_of_data: int

    override_sim_active: bool = False
    """Whether a simulated override was applied during this dry-run."""

    would_override_count: int = 0
    """Number of records where the simulated override would have applied.
    These are records that the policy would deny/escalate, but the
    simulated override would allow anyway.
    Note: would_deny and would_escalate counts are NOT reduced — they
    reflect the policy verdict. would_override_count is additive context.
    """

    would_override_details: list[dict] = field(default_factory=list)
    """Per-record details for records affected by the simulated override.
    Each entry: {
        "record_id": str,
        "agent_id": str,
        "action_type": str,
        "policy_verdict": "DENY" | "ESCALATE",
        "override_type": "ALLOW_ANYWAY" | "ESCALATE_INSTEAD",
        "authority": str,
    }
    """

    def to_dict(self) -> dict[str, Any]:
        d = {
            "policy_file": self.policy_file,
            "agent_id": self.agent_id,
            "records_evaluated": self.records_evaluated,
            "matched_count": self.matched_count,
            "would_deny_count": len(self.would_deny),
            "would_escalate_count": len(self.would_escalate),
            "already_denied": self.already_denied,
            "new_denials": self.new_denials,
            "new_escalations": self.new_escalations,
            "days_of_data": self.days_of_data,
            "would_deny": self.would_deny,
            "would_escalate": self.would_escalate,
            "override_sim_active": self.override_sim_active,
            "would_override_count": self.would_override_count,
            "would_override_details": self.would_override_details,
        }
        return d


class PolicyDryRunner:
    """Tests policy files against recorded audit history without live execution.

    Usage:
        runner = PolicyDryRunner(audit_store=store)
        result = runner.run(
            policy_path="./proposed-policies/deny-transfers.yaml",
            agent_id="finance-agent",
            days=7,
        )
        print(f'New denials: {result.new_denials}')
    """

    def __init__(self, audit_store: LogStore) -> None:
        self._store = audit_store

    def run(
        self,
        policy_path: str | Path,
        agent_id: str | None = None,
        days: int = 7,
        max_records: int = 1000,
        sim_overrides: list[SimulatedOverride] | None = None,
    ) -> DryRunResult:
        """Run dry-run by loading a policy file and testing against audit history."""
        policy_path = Path(policy_path)
        if not policy_path.exists():
            raise PolicyLoadError(f"Policy file not found: {policy_path}")

        engine = PolicyEngine(policy_dirs=[])
        engine.load_file(policy_path)

        if not engine.list_policies():
            raise PolicyLoadError(f"No valid policies found in: {policy_path}")

        return self._evaluate(
            engine=engine,
            policy_label=str(policy_path),
            agent_id=agent_id,
            days=days,
            max_records=max_records,
            sim_overrides=sim_overrides,
        )

    def run_with_engine(
        self,
        engine: PolicyEngine,
        agent_id: str | None = None,
        days: int = 7,
        max_records: int = 1000,
        policy_label: str = "in-memory",
        sim_overrides: list[SimulatedOverride] | None = None,
    ) -> DryRunResult:
        """Run dry-run using a pre-loaded PolicyEngine."""
        return self._evaluate(
            engine=engine,
            policy_label=policy_label,
            agent_id=agent_id,
            days=days,
            max_records=max_records,
            sim_overrides=sim_overrides,
        )

    def _evaluate(
        self,
        engine: PolicyEngine,
        policy_label: str,
        agent_id: str | None,
        days: int,
        max_records: int,
        sim_overrides: list[SimulatedOverride] | None = None,
    ) -> DryRunResult:
        """Core evaluation logic shared by run() and run_with_engine()."""
        cutoff = time.time() - days * 86400

        # Determine which agents to scan
        if agent_id is not None:
            agent_ids = [agent_id]
        else:
            agent_ids = self._store.list_agents()

        # Collect records from all agents, filtered by cutoff
        all_records = []
        for aid in agent_ids:
            for record in self._store.query_all(aid):
                if record.timestamp >= cutoff:
                    all_records.append(record)

        # Sort by timestamp ascending, then cap at max_records (trim oldest first)
        all_records.sort(key=lambda r: r.timestamp)
        if len(all_records) > max_records:
            all_records = all_records[-max_records:]

        would_deny: list[dict[str, Any]] = []
        would_escalate: list[dict[str, Any]] = []
        already_denied = 0
        matched_count = 0
        would_override_count = 0
        would_override_details: list[dict] = []

        for record in all_records:
            # Track already-denied records
            if record.verdict == "DENY":
                already_denied += 1

            # Build synthetic Action
            action = Action(
                id=record.record_id,
                agent_id=record.agent_id,
                action_type=record.action_type,
                target=record.action_target,
                parameters=record.parameters or {},
                metadata={"dry_run": True},
            )

            # Build minimal synthetic context
            context = AgentContext(
                agent_id=record.agent_id,
                trust_profile=TrustProfile(
                    agent_id=record.agent_id,
                    overall_trust=record.trust_score,
                ),
            )

            result = engine.evaluate(action, context)
            if result is not None:
                matched_count += 1
                policy_verdict = result.verdict

                if policy_verdict == "DENY" and record.verdict != "DENY":
                    would_deny.append({
                        "record_id": record.record_id,
                        "agent_id": record.agent_id,
                        "action_type": record.action_type,
                        "original_verdict": record.verdict,
                        "policy_name": result.matched_policy,
                        "policy_reason": result.reason,
                    })

                if policy_verdict == "ESCALATE" and record.verdict != "ESCALATE":
                    would_escalate.append({
                        "record_id": record.record_id,
                        "agent_id": record.agent_id,
                        "action_type": record.action_type,
                        "original_verdict": record.verdict,
                        "policy_name": result.matched_policy,
                        "policy_reason": result.reason,
                    })

                # Override simulation: check if any simulated override applies
                if sim_overrides and policy_verdict in ("DENY", "ESCALATE"):
                    for sim in sim_overrides:
                        if sim.applies_to(record.agent_id, record.action_type):
                            would_override_count += 1
                            would_override_details.append({
                                "record_id": record.record_id,
                                "agent_id": record.agent_id,
                                "action_type": record.action_type,
                                "policy_verdict": policy_verdict,
                                "override_type": sim.override_type,
                                "authority": sim.authority,
                            })
                            break  # First matching override wins

        return DryRunResult(
            policy_file=policy_label,
            agent_id=agent_id,
            records_evaluated=len(all_records),
            matched_count=matched_count,
            would_deny=would_deny,
            would_escalate=would_escalate,
            already_denied=already_denied,
            new_denials=len(would_deny),
            new_escalations=len(would_escalate),
            days_of_data=days,
            override_sim_active=bool(sim_overrides),
            would_override_count=would_override_count,
            would_override_details=would_override_details,
        )
