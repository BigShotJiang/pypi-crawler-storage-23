"""AsyncGovernedToolExecutor — async governance wrapper for concurrent agent systems.

Non-blocking variant of GovernedToolExecutor. Uses the same governance pipeline
(runtime, evaluator, dimensions) but wraps blocking operations in asyncio
executors so multiple agents can evaluate concurrently.

Usage:
    from nomotic import AsyncGovernedToolExecutor

    executor = await AsyncGovernedToolExecutor.connect("claims-bot")

    result = await executor.execute(
        action="query_db",
        target="customers",
        tool_fn=lambda: db.execute("SELECT * FROM customers"),
    )

    # Or with an async tool function:
    result = await executor.execute(
        action="query_db",
        target="customers",
        async_tool_fn=my_async_db_query,
    )

    # Concurrent evaluation for multiple agents:
    results = await asyncio.gather(
        executor_a.execute("read", "customers", tool_fn=read_customers),
        executor_b.execute("write", "orders", tool_fn=write_order),
        executor_c.execute("delete", "logs", tool_fn=cleanup_logs),
    )
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any, Callable, Coroutine

from nomotic.executor import ExecutionResult, GovernedToolExecutor
from nomotic.seal import GovernanceSeal

__all__ = [
    "AsyncGovernedToolExecutor",
]


class AsyncGovernedToolExecutor:
    """Async wrapper around GovernedToolExecutor.

    Delegates to the synchronous executor but runs blocking operations
    in a thread pool so multiple agents can evaluate concurrently.

    Design rationale:
    - The 14-dimension evaluation is CPU-bound — making it natively async
      would add complexity with no throughput benefit.
    - ``asyncio.to_thread`` offloads blocking work to the default thread
      pool executor, freeing the event loop for other agents.
    - Trust score reads are kept synchronous (fast, in-memory).
    """

    def __init__(self, sync_executor: GovernedToolExecutor) -> None:
        self._sync = sync_executor

    @classmethod
    async def connect(
        cls,
        agent_id: str,
        *,
        base_dir: Path | None = None,
        test_mode: bool = False,
    ) -> AsyncGovernedToolExecutor:
        """Connect to an agent's governance context (async).

        Runs certificate and config loading in a thread pool.
        """
        sync = await asyncio.to_thread(
            GovernedToolExecutor.connect,
            agent_id,
            base_dir=base_dir,
            test_mode=test_mode,
        )
        return cls(sync)

    async def execute(
        self,
        action: str,
        target: str = "",
        *,
        tool_fn: Callable[[], Any] | None = None,
        async_tool_fn: Callable[[], Coroutine[Any, Any, Any]] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> ExecutionResult:
        """Execute a governed action asynchronously.

        Governance evaluation runs in a thread pool (CPU-bound).
        Tool execution: uses async_tool_fn if provided, otherwise
        runs tool_fn in the thread pool.
        Audit logging runs in a thread pool (file I/O).

        Args:
            action: The action being performed (e.g., "query_db", "write_file")
            target: The target resource (e.g., "customers", "/etc/passwd")
            tool_fn: Synchronous callable to execute if governance allows
            async_tool_fn: Async callable to execute if governance allows
            metadata: Additional context for governance evaluation

        Returns:
            ExecutionResult with verdict, trust changes, and tool output

        Raises:
            ValueError: If neither tool_fn nor async_tool_fn is provided,
                or if both are provided.
        """
        if tool_fn is None and async_tool_fn is None:
            raise ValueError("Provide either tool_fn or async_tool_fn")
        if tool_fn is not None and async_tool_fn is not None:
            raise ValueError("Provide tool_fn or async_tool_fn, not both")

        # Phase 1: Governance evaluation (CPU-bound -> thread pool)
        check_result = await asyncio.to_thread(
            self._sync.check, action, target, metadata=metadata
        )

        if not check_result.allowed:
            # Write audit record for denial (I/O -> thread pool)
            await asyncio.to_thread(
                self._sync._write_denial_record, action, target, check_result
            )
            return check_result

        # Phase 2: Tool execution
        try:
            if async_tool_fn is not None:
                data = await async_tool_fn()
            else:
                data = await asyncio.to_thread(tool_fn)
        except Exception as exc:
            # Write error record (I/O -> thread pool)
            await asyncio.to_thread(
                self._sync._write_error_record,
                action,
                target,
                check_result,
                exc,
            )
            raise

        # Phase 3: Post-execution (trust update + audit -> thread pool)
        final_result = await asyncio.to_thread(
            self._sync._finalize_execution,
            action,
            target,
            check_result,
            data,
        )

        return final_result

    async def check(
        self,
        action: str,
        target: str = "",
        *,
        metadata: dict[str, Any] | None = None,
    ) -> ExecutionResult:
        """Check governance without executing (async)."""
        return await asyncio.to_thread(
            self._sync.check, action, target, metadata=metadata
        )

    async def execute_sealed(
        self,
        action: str,
        target: str = "",
        params: dict[str, Any] | None = None,
        tool_fn: Callable[[], Any] | None = None,
        seal: GovernanceSeal | None = None,
        *,
        timeout: float | None = None,
    ) -> ExecutionResult:
        """Execute a tool using a pre-authorized GovernanceSeal (async).

        Delegates to the sync executor's execute_sealed via asyncio.to_thread.
        """
        return await asyncio.to_thread(
            self._sync.execute_sealed,
            action,
            target,
            params,
            tool_fn,
            seal,
            timeout=timeout,
        )

    @property
    def trust_score(self) -> float:
        """Current trust score (synchronous read, fast)."""
        return self._sync.trust

    @property
    def agent_id(self) -> str:
        return self._sync.agent_id
