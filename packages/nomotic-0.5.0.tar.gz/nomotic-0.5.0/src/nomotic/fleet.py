"""Fleet Governance API.

Provides fleet-level aggregations across all governed agents.
Operates over the audit store — no runtime state required.

All methods are read-only. FleetGovernor never modifies audit records.
Designed for low-frequency polling (dashboard refresh, health checks)
not hot-path evaluation.
"""

from __future__ import annotations

import calendar
import time
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any

from nomotic.audit_store import LogStore

__all__ = [
    "AgentCostRecord",
    "AgentFleetRecord",
    "CostGroup",
    "FleetCostAggregator",
    "FleetDenialRecord",
    "FleetGovernor",
    "FleetHealthSummary",
    "GroupCostSummary",
]


@dataclass
class FleetHealthSummary:
    """Aggregated health across all fleet agents."""

    total_agents: int
    active_agents: int  # Agents with evaluations in the last 24h
    critical_agents: int  # Agents with trust < 0.3 OR denial_rate > 0.5
    warning_agents: int  # Agents with trust 0.3-0.5 OR denial_rate 0.3-0.5
    healthy_agents: int  # All others
    total_evaluations_24h: int  # Evaluations in last 24 hours across all agents
    fleet_denial_rate: float  # Denials / total across all agents, last 24h
    computed_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class AgentFleetRecord:
    """Per-agent summary for fleet view."""

    agent_id: str
    total_evaluations: int
    evaluations_24h: int
    denial_rate: float  # DENY / total, last 24h
    current_trust: float
    trust_trend: str  # "rising" | "falling" | "stable"
    last_activity: float | None  # Unix timestamp of last evaluation
    status: str  # "healthy" | "warning" | "critical" | "inactive"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class FleetDenialRecord:
    """Most denied action types across the fleet."""

    action_type: str
    deny_count: int
    agent_count: int  # How many distinct agents denied this action type
    top_agent: str  # Agent with most denials of this action type

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class FleetGovernor:
    """Fleet-level governance aggregations.

    Args:
        audit_store: LogStore pointed at the audit directory.
                     All queries read from this store.
        lookback_hours: Window for "recent" metrics (default 24).
    """

    def __init__(
        self,
        audit_store: LogStore,
        lookback_hours: int = 24,
    ) -> None:
        self._store = audit_store
        self._lookback_hours = lookback_hours

    def _lookback_cutoff(self) -> float:
        """Return the Unix timestamp for the start of the lookback window."""
        return time.time() - (self._lookback_hours * 3600)

    def _classify_agent(
        self,
        records: list,
        recent_records: list,
    ) -> str:
        """Classify an agent's status based on its records.

        Returns one of: "healthy", "warning", "critical", "inactive".
        """
        if not recent_records:
            return "inactive"

        # Current trust is the last record's trust_score
        current_trust = records[-1].trust_score if records else 0.5

        # Denial rate over recent records
        recent_total = len(recent_records)
        recent_denials = sum(1 for r in recent_records if r.verdict == "DENY")
        denial_rate = recent_denials / recent_total if recent_total > 0 else 0.0

        # Critical: trust < 0.3 OR denial_rate > 0.5
        if current_trust < 0.3 or denial_rate > 0.5:
            return "critical"

        # Warning: trust 0.3-0.5 OR denial_rate 0.3-0.5
        if current_trust <= 0.5 or 0.3 <= denial_rate <= 0.5:
            return "warning"

        return "healthy"

    def _build_agent_record(self, agent_id: str) -> AgentFleetRecord | None:
        """Build an AgentFleetRecord for a single agent."""
        records = self._store.query_all(agent_id)
        if not records:
            return None

        cutoff = self._lookback_cutoff()
        recent = [r for r in records if r.timestamp >= cutoff]

        total_evals = len(records)
        evals_24h = len(recent)
        recent_denials = sum(1 for r in recent if r.verdict == "DENY")
        denial_rate = recent_denials / evals_24h if evals_24h > 0 else 0.0

        current_trust = records[-1].trust_score
        trust_trend = records[-1].trust_trend if records else "stable"
        last_activity = records[-1].timestamp if records else None

        status = self._classify_agent(records, recent)

        return AgentFleetRecord(
            agent_id=agent_id,
            total_evaluations=total_evals,
            evaluations_24h=evals_24h,
            denial_rate=denial_rate,
            current_trust=current_trust,
            trust_trend=trust_trend,
            last_activity=last_activity,
            status=status,
        )

    def health_summary(self) -> FleetHealthSummary:
        """Compute aggregated health summary across all fleet agents."""
        agents = self._store.list_agents()
        cutoff = self._lookback_cutoff()

        total = len(agents)
        active = 0
        critical = 0
        warning = 0
        healthy = 0
        total_evals_24h = 0
        total_denials_24h = 0

        for agent_id in agents:
            records = self._store.query_all(agent_id)
            if not records:
                continue

            recent = [r for r in records if r.timestamp >= cutoff]
            evals_24h = len(recent)
            denials_24h = sum(1 for r in recent if r.verdict == "DENY")

            total_evals_24h += evals_24h
            total_denials_24h += denials_24h

            status = self._classify_agent(records, recent)
            if status == "inactive":
                continue

            active += 1
            if status == "critical":
                critical += 1
            elif status == "warning":
                warning += 1
            else:
                healthy += 1

        fleet_denial_rate = (
            total_denials_24h / total_evals_24h if total_evals_24h > 0 else 0.0
        )

        return FleetHealthSummary(
            total_agents=total,
            active_agents=active,
            critical_agents=critical,
            warning_agents=warning,
            healthy_agents=healthy,
            total_evaluations_24h=total_evals_24h,
            fleet_denial_rate=fleet_denial_rate,
        )

    def trust_distribution(self) -> dict[str, int]:
        """Return counts of agents by trust band."""
        bands: dict[str, int] = {
            "high": 0,
            "medium": 0,
            "low": 0,
            "critical": 0,
        }

        for agent_id in self._store.list_agents():
            records = self._store.query_all(agent_id)
            if not records:
                continue
            trust = records[-1].trust_score
            if trust >= 0.7:
                bands["high"] += 1
            elif trust >= 0.4:
                bands["medium"] += 1
            elif trust >= 0.2:
                bands["low"] += 1
            else:
                bands["critical"] += 1

        return bands

    def denial_rate(self, agent_id: str | None = None) -> float:
        """Compute denial rate within the lookback window.

        If agent_id is provided, returns the rate for that agent.
        If agent_id is None, returns the fleet-wide rate.
        """
        cutoff = self._lookback_cutoff()

        if agent_id is not None:
            records = self._store.query_all(agent_id)
            recent = [r for r in records if r.timestamp >= cutoff]
            if not recent:
                return 0.0
            denials = sum(1 for r in recent if r.verdict == "DENY")
            return denials / len(recent)

        # Fleet-wide
        total = 0
        denials = 0
        for aid in self._store.list_agents():
            records = self._store.query_all(aid)
            recent = [r for r in records if r.timestamp >= cutoff]
            total += len(recent)
            denials += sum(1 for r in recent if r.verdict == "DENY")

        return denials / total if total > 0 else 0.0

    def agents_by_status(self, status: str) -> list[AgentFleetRecord]:
        """Return all agents matching the given status.

        Sorted by last_activity descending.
        """
        result: list[AgentFleetRecord] = []

        for agent_id in self._store.list_agents():
            record = self._build_agent_record(agent_id)
            if record is not None and record.status == status:
                result.append(record)

        result.sort(
            key=lambda r: r.last_activity if r.last_activity is not None else 0.0,
            reverse=True,
        )
        return result

    def top_denied_action_types(self, limit: int = 10) -> list[FleetDenialRecord]:
        """Aggregate DENY records across all agents in the lookback window.

        Groups by action_type, counts denials and distinct agents per type.
        Returns top ``limit`` results sorted by deny_count descending.
        """
        cutoff = self._lookback_cutoff()

        # action_type -> {deny_count, agents: {agent_id: count}}
        action_stats: dict[str, dict[str, Any]] = defaultdict(
            lambda: {"deny_count": 0, "agents": defaultdict(int)}
        )

        for agent_id in self._store.list_agents():
            records = self._store.query_all(agent_id)
            for r in records:
                if r.timestamp >= cutoff and r.verdict == "DENY":
                    stats = action_stats[r.action_type]
                    stats["deny_count"] += 1
                    stats["agents"][agent_id] += 1

        results: list[FleetDenialRecord] = []
        for action_type, stats in action_stats.items():
            agents_map: dict[str, int] = stats["agents"]
            top_agent = max(agents_map, key=agents_map.get)  # type: ignore[arg-type]
            results.append(
                FleetDenialRecord(
                    action_type=action_type,
                    deny_count=stats["deny_count"],
                    agent_count=len(agents_map),
                    top_agent=top_agent,
                )
            )

        results.sort(key=lambda r: r.deny_count, reverse=True)
        return results[:limit]

    def critical_agents(self) -> list[AgentFleetRecord]:
        """Convenience method: return all critical agents."""
        return self.agents_by_status("critical")

    def get_agent_record(self, agent_id: str) -> AgentFleetRecord | None:
        """Return the AgentFleetRecord for a specific agent, or None."""
        return self._build_agent_record(agent_id)


# ── Fleet Cost Aggregation ─────────────────────────────────────────────


@dataclass
class CostGroup:
    """A named group of agents for budget tracking."""

    group_id: str
    name: str
    agent_ids: list[str]
    daily_budget_usd: float | None = None
    monthly_budget_usd: float | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class AgentCostRecord:
    """Per-agent cost aggregation."""

    agent_id: str
    total_cost_usd: float
    total_tokens: int
    cost_today_usd: float
    cost_this_month_usd: float
    avg_cost_per_action_usd: float
    evaluated_actions: int
    last_cost_at: float | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class GroupCostSummary:
    """Cost summary for a named group of agents."""

    group_id: str
    group_name: str
    total_cost_usd: float
    cost_today_usd: float
    cost_this_month_usd: float
    projected_daily_usd: float
    projected_monthly_usd: float
    daily_budget_usd: float | None
    monthly_budget_usd: float | None
    daily_budget_alert: bool
    monthly_budget_alert: bool
    agent_count: int
    agent_records: list[AgentCostRecord] = field(default_factory=list)

    # ── 7-day trend fields ──────────────────────────────────────────
    daily_costs_7d: list[float] = field(default_factory=list)
    """Daily costs for the last 7 days, index 0 = 6 days ago, index 6 = today."""

    moving_average_7d: float = 0.0
    """7-day moving average of daily costs."""

    daily_growth_rate: float = 0.0
    """Average daily growth rate over the 7-day window.
    Positive = accelerating spend. Negative = decelerating.
    e.g. 0.25 means 25% average daily increase.
    Computed only from non-zero-to-nonzero transitions.
    """

    cost_acceleration_alert: bool = False
    """True when daily_growth_rate exceeds the acceleration threshold.
    Default threshold: 0.20 (20% daily growth rate).
    """

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        return d


class FleetCostAggregator:
    """Fleet-level cost tracking and budget advisory.

    Reads cost data from PersistentLogRecord.parameters['cost_usd']
    and parameters['tokens']. Agents that don't set these contribute 0.0.

    Budget thresholds are advisory only — never affects governance decisions.

    Args:
        audit_store: LogStore for reading audit records.
        groups: Optional list of CostGroup configurations.
    """

    def __init__(
        self,
        audit_store: LogStore,
        groups: list[CostGroup] | None = None,
    ) -> None:
        self._store = audit_store
        self._groups: dict[str, CostGroup] = {g.group_id: g for g in (groups or [])}

    def add_group(self, group: CostGroup) -> None:
        """Register a cost group."""
        self._groups[group.group_id] = group

    def get_agent_cost(self, agent_id: str) -> AgentCostRecord:
        """Load all records for an agent and aggregate cost data.

        Returns AgentCostRecord with all fields populated (zeros if no cost data).
        """
        records = self._store.query_all(agent_id)

        now = datetime.now(timezone.utc)
        midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
        month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        midnight_ts = midnight.timestamp()
        month_start_ts = month_start.timestamp()

        total_cost = 0.0
        total_tokens = 0
        cost_today = 0.0
        cost_this_month = 0.0
        evaluated = 0
        last_cost_at: float | None = None

        for r in records:
            cost = r.parameters.get("cost_usd", 0.0)
            tokens = r.parameters.get("tokens", 0)
            if cost > 0 or tokens > 0:
                evaluated += 1
                last_cost_at = r.timestamp
            total_cost += cost
            total_tokens += tokens
            if r.timestamp >= midnight_ts:
                cost_today += cost
            if r.timestamp >= month_start_ts:
                cost_this_month += cost

        avg_cost = total_cost / evaluated if evaluated > 0 else 0.0

        return AgentCostRecord(
            agent_id=agent_id,
            total_cost_usd=total_cost,
            total_tokens=total_tokens,
            cost_today_usd=cost_today,
            cost_this_month_usd=cost_this_month,
            avg_cost_per_action_usd=avg_cost,
            evaluated_actions=evaluated,
            last_cost_at=last_cost_at,
        )

    def _compute_projections(
        self, cost_today: float, cost_this_month: float
    ) -> tuple[float, float]:
        """Compute daily and monthly projections."""
        now = datetime.now(timezone.utc)

        # Daily projection
        midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
        seconds_elapsed = (now - midnight).total_seconds()
        day_fraction = seconds_elapsed / 86400
        projected_daily = (
            cost_today / day_fraction if day_fraction > 0.01 else cost_today
        )

        # Monthly projection
        month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        days_in_month = calendar.monthrange(now.year, now.month)[1]
        month_fraction = (now - month_start).total_seconds() / (days_in_month * 86400)
        projected_monthly = (
            cost_this_month / month_fraction
            if month_fraction > 0.01
            else cost_this_month
        )

        return projected_daily, projected_monthly

    def _sum_cost_for_agent_in_window(
        self, agent_id: str, start: float, end: float
    ) -> float:
        """Sum cost_usd for an agent's records within [start, end) UTC window."""
        records = self._store.query_all(agent_id)
        total = 0.0
        for r in records:
            if start <= r.timestamp < end:
                total += r.parameters.get("cost_usd", 0.0)
        return total

    def _compute_7d_trend(
        self,
        agent_ids: list[str],
        acceleration_threshold: float = 0.20,
    ) -> tuple[list[float], float, float, bool]:
        """Compute 7-day cost trend for a group of agents.

        Returns:
            daily_costs_7d:  List of 7 floats, index 0 = 6 days ago
            moving_average:  Mean of the 7 values
            growth_rate:     Avg daily growth rate (zero-to-zero excluded)
            alert:           True if growth_rate > acceleration_threshold
        """
        today = datetime.now(tz=timezone.utc).date()
        daily_costs: list[float] = []

        for days_back in range(6, -1, -1):
            day = today - timedelta(days=days_back)
            day_start = datetime(
                day.year, day.month, day.day, tzinfo=timezone.utc
            ).timestamp()
            day_end = day_start + 86400.0

            cost = sum(
                self._sum_cost_for_agent_in_window(agent_id, day_start, day_end)
                for agent_id in agent_ids
            )
            daily_costs.append(round(cost, 6))

        moving_avg = (
            sum(daily_costs) / 7 if any(c > 0 for c in daily_costs) else 0.0
        )

        # Compute growth rates (skip zero-to-zero transitions)
        growth_rates: list[float] = []
        for i in range(1, 7):
            prev = daily_costs[i - 1]
            curr = daily_costs[i]
            if prev > 0:
                growth_rates.append((curr - prev) / prev)

        avg_growth = (
            sum(growth_rates) / len(growth_rates) if growth_rates else 0.0
        )
        alert = avg_growth > acceleration_threshold

        return daily_costs, round(moving_avg, 6), round(avg_growth, 4), alert

    def get_group_cost(self, group_id: str) -> GroupCostSummary:
        """Compute cost summary for a named group of agents.

        Raises ValueError if group_id is not registered.
        """
        if group_id not in self._groups:
            raise ValueError(f"Group not found: {group_id}")

        group = self._groups[group_id]
        agent_records: list[AgentCostRecord] = []
        total_cost = 0.0
        cost_today = 0.0
        cost_this_month = 0.0

        for agent_id in group.agent_ids:
            rec = self.get_agent_cost(agent_id)
            agent_records.append(rec)
            total_cost += rec.total_cost_usd
            cost_today += rec.cost_today_usd
            cost_this_month += rec.cost_this_month_usd

        projected_daily, projected_monthly = self._compute_projections(
            cost_today, cost_this_month
        )

        daily_budget_alert = (
            group.daily_budget_usd is not None
            and projected_daily > group.daily_budget_usd
        )
        monthly_budget_alert = (
            group.monthly_budget_usd is not None
            and projected_monthly > group.monthly_budget_usd
        )

        # 7-day trend analysis
        daily_costs, moving_avg, growth_rate, accel_alert = self._compute_7d_trend(
            group.agent_ids,
            acceleration_threshold=0.20,
        )

        return GroupCostSummary(
            group_id=group.group_id,
            group_name=group.name,
            total_cost_usd=total_cost,
            cost_today_usd=cost_today,
            cost_this_month_usd=cost_this_month,
            projected_daily_usd=projected_daily,
            projected_monthly_usd=projected_monthly,
            daily_budget_usd=group.daily_budget_usd,
            monthly_budget_usd=group.monthly_budget_usd,
            daily_budget_alert=daily_budget_alert,
            monthly_budget_alert=monthly_budget_alert,
            agent_count=len(group.agent_ids),
            agent_records=agent_records,
            daily_costs_7d=daily_costs,
            moving_average_7d=moving_avg,
            daily_growth_rate=growth_rate,
            cost_acceleration_alert=accel_alert,
        )

    def get_all_costs(self) -> list[AgentCostRecord]:
        """Return AgentCostRecord for every agent in the audit store.

        Sorted by total_cost_usd descending.
        """
        results: list[AgentCostRecord] = []
        for agent_id in self._store.list_agents():
            results.append(self.get_agent_cost(agent_id))
        results.sort(key=lambda r: r.total_cost_usd, reverse=True)
        return results

    def fleet_cost_today(self) -> float:
        """Sum of cost_today_usd across all agents."""
        total = 0.0
        for agent_id in self._store.list_agents():
            rec = self.get_agent_cost(agent_id)
            total += rec.cost_today_usd
        return total

    def alerts(self) -> list[GroupCostSummary]:
        """Return groups with any active alert:
        - daily_budget_alert
        - monthly_budget_alert
        - cost_acceleration_alert
        """
        result: list[GroupCostSummary] = []
        for group_id in self._groups:
            summary = self.get_group_cost(group_id)
            if (
                summary.daily_budget_alert
                or summary.monthly_budget_alert
                or summary.cost_acceleration_alert
            ):
                result.append(summary)
        return result
