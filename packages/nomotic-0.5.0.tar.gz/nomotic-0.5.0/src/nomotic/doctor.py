"""Nomotic Doctor — governance infrastructure diagnostics.

Provides a single ``run_doctor(base_dir)`` entry-point that checks the health
of a Nomotic installation and returns a structured :class:`DoctorReport`.

The module is independently importable and testable — ``cli.py`` calls it as
a thin dispatcher.
"""

from __future__ import annotations

import hashlib
import json
import platform
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

__all__ = ["DoctorCheck", "DoctorReport", "run_doctor"]


@dataclass
class DoctorCheck:
    """Result of a single health check."""

    category: str  # "Installation", "Configuration", etc.
    name: str  # Short name — shown in report
    status: str  # "ok", "warning", "error"
    message: str  # Human-readable detail
    fix_hint: str = ""  # If non-empty, --fix can attempt this

    def is_ok(self) -> bool:
        return self.status == "ok"

    def is_warning(self) -> bool:
        return self.status == "warning"

    def is_error(self) -> bool:
        return self.status == "error"

    def to_dict(self) -> dict[str, Any]:
        return {
            "category": self.category,
            "name": self.name,
            "status": self.status,
            "message": self.message,
        }


@dataclass
class DoctorReport:
    """Full health report from all checks."""

    checks: list[DoctorCheck] = field(default_factory=list)
    generated_at: float = field(default_factory=time.time)

    @property
    def errors(self) -> list[DoctorCheck]:
        return [c for c in self.checks if c.is_error()]

    @property
    def warnings(self) -> list[DoctorCheck]:
        return [c for c in self.checks if c.is_warning()]

    @property
    def ok(self) -> list[DoctorCheck]:
        return [c for c in self.checks if c.is_ok()]

    @property
    def has_errors(self) -> bool:
        return len(self.errors) > 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "generated_at": self.generated_at,
            "summary": {
                "errors": len(self.errors),
                "warnings": len(self.warnings),
                "ok": len(self.ok),
            },
            "checks": [c.to_dict() for c in self.checks],
        }


def run_doctor(base_dir: Path) -> DoctorReport:
    """Run all health checks and return a DoctorReport."""
    report = DoctorReport()

    _check_installation(report)
    _check_configuration(report, base_dir)
    _check_certificate_store(report, base_dir)
    _check_audit_trail(report, base_dir)
    _check_signing_keys(report, base_dir)
    _check_role_registry(report, base_dir)
    _check_jurisdictional_dimension(report, base_dir)
    _check_model_provenance(report, base_dir)
    _check_delegation_depths(report, base_dir)
    _check_constitutional_engine(report, base_dir)
    _check_authority_registry(report, base_dir)
    _check_config_backups(report, base_dir)

    return report


# ── Check implementations ────────────────────────────────────────────────


def _check_installation(report: DoctorReport) -> None:
    """Check 1: Installation — version, Python, importable package."""

    # Nomotic version
    try:
        import nomotic

        report.checks.append(
            DoctorCheck(
                category="Installation",
                name="Nomotic version",
                status="ok",
                message=f"Nomotic {getattr(nomotic, '__version__', 'unknown')}",
            )
        )
    except ImportError as exc:
        report.checks.append(
            DoctorCheck(
                category="Installation",
                name="Nomotic version",
                status="error",
                message=f"Cannot import nomotic: {exc}",
            )
        )

    # Python version (3.10+ required)
    py_ver = sys.version_info
    if py_ver >= (3, 10):
        report.checks.append(
            DoctorCheck(
                category="Installation",
                name="Python version",
                status="ok",
                message=f"Python {sys.version.split()[0]}",
            )
        )
    else:
        report.checks.append(
            DoctorCheck(
                category="Installation",
                name="Python version",
                status="error",
                message=f"Python {sys.version.split()[0]} — Nomotic requires Python 3.10+",
            )
        )

    # Key dependencies importable
    for dep in ["cryptography", "yaml"]:
        try:
            __import__(dep)
            report.checks.append(
                DoctorCheck(
                    category="Installation",
                    name=f"Dependency: {dep}",
                    status="ok",
                    message=f"{dep} importable",
                )
            )
        except ImportError:
            report.checks.append(
                DoctorCheck(
                    category="Installation",
                    name=f"Dependency: {dep}",
                    status="warning",
                    message=f"{dep} not installed — some features unavailable",
                    fix_hint=f"pip install {dep}",
                )
            )


def _check_configuration(report: DoctorReport, base_dir: Path) -> None:
    """Check 2: Configuration — config.json and issuer setup."""

    config_path = base_dir / "config.json"
    if not config_path.exists():
        report.checks.append(
            DoctorCheck(
                category="Configuration",
                name="config.json",
                status="warning",
                message=f"{config_path} not found — run 'nomotic setup' to initialize",
                fix_hint="nomotic setup",
            )
        )
        return

    try:
        with open(config_path) as f:
            config = json.load(f)
        report.checks.append(
            DoctorCheck(
                category="Configuration",
                name="config.json",
                status="ok",
                message=f"{config_path} valid",
            )
        )
    except (json.JSONDecodeError, OSError) as exc:
        report.checks.append(
            DoctorCheck(
                category="Configuration",
                name="config.json",
                status="error",
                message=f"{config_path} invalid: {exc}",
            )
        )
        return

    # Check for organization name
    org = config.get("organization") or config.get("org")
    if org:
        report.checks.append(
            DoctorCheck(
                category="Configuration",
                name="Organization",
                status="ok",
                message=f"Organization: {org}",
            )
        )
    else:
        report.checks.append(
            DoctorCheck(
                category="Configuration",
                name="Organization",
                status="warning",
                message="No organization configured — set 'organization' in config.json",
            )
        )

    # Check default preset if present
    preset = config.get("default_preset")
    valid_presets = {"permissive", "moderate", "strict", "ultra_strict"}
    if preset:
        if preset in valid_presets:
            report.checks.append(
                DoctorCheck(
                    category="Configuration",
                    name="Default preset",
                    status="ok",
                    message=f"Default preset: {preset}",
                )
            )
        else:
            report.checks.append(
                DoctorCheck(
                    category="Configuration",
                    name="Default preset",
                    status="warning",
                    message=f"Unknown preset '{preset}' — valid: {', '.join(sorted(valid_presets))}",
                )
            )


def _check_certificate_store(report: DoctorReport, base_dir: Path) -> None:
    """Check 3: Certificate store — active/expired/orphaned counts."""

    certs_dir = base_dir / "certs"
    if not certs_dir.exists():
        report.checks.append(
            DoctorCheck(
                category="Certificate Store",
                name="Certs directory",
                status="warning",
                message=f"{certs_dir} does not exist — no certificates issued yet",
            )
        )
        return

    try:
        from nomotic.certificate import CertStatus
        from nomotic.store import FileCertificateStore

        store = FileCertificateStore(base_dir)
        certs = store.list()
        revoked = store.list_revoked()
        all_certs = certs + revoked
    except Exception as exc:
        report.checks.append(
            DoctorCheck(
                category="Certificate Store",
                name="Certs directory",
                status="error",
                message=f"Cannot read certificate store: {exc}",
            )
        )
        return

    counts: dict[str, int] = {}
    expired: list[str] = []

    for cert in all_certs:
        status_name = cert.status.name if cert.status else "UNKNOWN"
        counts[status_name] = counts.get(status_name, 0) + 1

        # Check expiry on ACTIVE certs
        if cert.status == CertStatus.ACTIVE:
            try:
                from datetime import datetime, timezone

                if cert.expires_at:
                    exp = cert.expires_at
                    if not exp.tzinfo:
                        exp = exp.replace(tzinfo=timezone.utc)
                    if exp < datetime.now(timezone.utc):
                        expired.append(cert.certificate_id)
            except (AttributeError, ValueError):
                pass

    total = sum(counts.values())
    active = counts.get("ACTIVE", 0)

    other_parts = ", ".join(
        f"{k.lower()}:{v}" for k, v in sorted(counts.items()) if k != "ACTIVE"
    )
    msg = f"{total} total — active:{active}"
    if other_parts:
        msg += f", {other_parts}"

    report.checks.append(
        DoctorCheck(
            category="Certificate Store",
            name="Certificate counts",
            status="ok",
            message=msg,
        )
    )

    if expired:
        suffix = "..." if len(expired) > 3 else ""
        report.checks.append(
            DoctorCheck(
                category="Certificate Store",
                name="Expired active certificates",
                status="warning",
                message=f"{len(expired)} active certificate(s) past expiry: "
                + ", ".join(expired[:3])
                + suffix,
                fix_hint="nomotic revoke <cert-id> --reason 'expired'",
            )
        )
    else:
        report.checks.append(
            DoctorCheck(
                category="Certificate Store",
                name="Expired active certificates",
                status="ok",
                message="No expired active certificates",
            )
        )

    if active == 0 and total == 0:
        report.checks.append(
            DoctorCheck(
                category="Certificate Store",
                name="Active agents",
                status="warning",
                message="No agents exist — run 'nomotic birth --name <agent>' to create one",
            )
        )


def _check_audit_trail(report: DoctorReport, base_dir: Path) -> None:
    """Check 4: Audit trail — record counts, hash chain integrity, silent agents."""

    audit_dir = base_dir / "audit"
    if not audit_dir.exists():
        report.checks.append(
            DoctorCheck(
                category="Audit Trail",
                name="Audit directory",
                status="warning",
                message="No audit records exist — agents have not been evaluated yet",
            )
        )
        return

    try:
        from nomotic.audit_store import AuditStore

        store = AuditStore(base_dir)
        agents = store.list_agents()
    except Exception as exc:
        report.checks.append(
            DoctorCheck(
                category="Audit Trail",
                name="Audit directory",
                status="error",
                message=f"Cannot read audit store: {exc}",
            )
        )
        return

    total_records = 0
    chain_failures: list[str] = []
    empty_agents: list[str] = []

    for agent_name in agents:
        summary = store.summary(agent_name)
        count = summary.get("total", 0)
        total_records += count

        if count == 0:
            empty_agents.append(agent_name)
            continue

        is_valid, _, message = store.verify_chain(agent_name)
        if not is_valid:
            chain_failures.append(f"{agent_name}: {message}")

    report.checks.append(
        DoctorCheck(
            category="Audit Trail",
            name="Audit records",
            status="ok",
            message=f"{total_records} records across {len(agents)} agent(s)",
        )
    )

    if chain_failures:
        report.checks.append(
            DoctorCheck(
                category="Audit Trail",
                name="Hash chain integrity",
                status="error",
                message=f"CHAIN BREAK detected in {len(chain_failures)} agent(s): "
                + "; ".join(chain_failures[:2]),
            )
        )
    else:
        report.checks.append(
            DoctorCheck(
                category="Audit Trail",
                name="Hash chain integrity",
                status="ok",
                message=f"All {len(agents)} agent audit chain(s) verified",
            )
        )

    if empty_agents:
        report.checks.append(
            DoctorCheck(
                category="Audit Trail",
                name="Silent agents",
                status="warning",
                message=f"{len(empty_agents)} agent(s) have no audit records: "
                + ", ".join(empty_agents[:3]),
            )
        )


def _check_signing_keys(report: DoctorReport, base_dir: Path) -> None:
    """Check 5: Signing keys — issuer key present and loadable."""

    issuer_dir = base_dir / "issuer"
    if not issuer_dir.exists():
        report.checks.append(
            DoctorCheck(
                category="Signing Keys",
                name="Issuer key",
                status="warning",
                message=f"{issuer_dir} not found — run 'nomotic setup' to generate keys",
                fix_hint="nomotic setup",
            )
        )
        return

    key_files = list(issuer_dir.glob("*.key")) + list(issuer_dir.glob("issuer*"))
    # Deduplicate (issuer.key would match both globs)
    key_files = list(dict.fromkeys(key_files))
    if not key_files:
        report.checks.append(
            DoctorCheck(
                category="Signing Keys",
                name="Issuer key",
                status="error",
                message=f"No key file found in {issuer_dir}",
            )
        )
        return

    try:
        from nomotic.keys import SigningKey

        # Try to load the first .key file (prefer issuer.key if present)
        key_path = None
        for kf in key_files:
            if kf.name == "issuer.key":
                key_path = kf
                break
        if key_path is None:
            key_path = key_files[0]

        key_bytes = key_path.read_bytes()
        sk = SigningKey.from_bytes(key_bytes)
        fingerprint = hashlib.sha256(sk.verify_key().to_bytes()).hexdigest()[:16]
        report.checks.append(
            DoctorCheck(
                category="Signing Keys",
                name="Issuer key",
                status="ok",
                message=f"Key present and valid — fingerprint: {fingerprint}...",
            )
        )
    except Exception as exc:
        report.checks.append(
            DoctorCheck(
                category="Signing Keys",
                name="Issuer key",
                status="error",
                message=f"Cannot load issuer key: {exc}",
            )
        )


def _check_role_registry(report: DoctorReport, base_dir: Path) -> None:
    """Check 6: Role registry — presence and validity of roles config."""

    # Search standard locations
    candidates = [
        Path("nomotic-roles.yaml"),
        Path("nomotic-roles.json"),
        base_dir / "roles.yaml",
    ]
    roles_file: Path | None = None
    for c in candidates:
        if c.exists():
            roles_file = c
            break

    if roles_file is None:
        report.checks.append(
            DoctorCheck(
                category="Role Registry",
                name="Roles config",
                status="ok",
                message=(
                    "No role registry configured. Override permissions are not enforced. "
                    "Consider adding nomotic-roles.yaml for production deployments."
                ),
            )
        )
        return

    # Try to load
    try:
        from nomotic.roles import RoleRegistry

        registry = RoleRegistry()
        count = registry.load_from_file(roles_file)

        report.checks.append(
            DoctorCheck(
                category="Role Registry",
                name="Roles config",
                status="ok",
                message=f"{count} role(s) loaded from {roles_file}",
            )
        )

        # Validate roles
        for role in registry.list_roles():
            if role.can_override_irreversible and len(role.authorities) > 3:
                report.checks.append(
                    DoctorCheck(
                        category="Role Registry",
                        name=f"Role: {role.name}",
                        status="warning",
                        message=(
                            f"Role '{role.name}' has can_override_irreversible=true "
                            f"with {len(role.authorities)} authorities — broad override power"
                        ),
                    )
                )

            if (
                role.can_override_irreversible
                and "*" in role.permitted_zones
            ):
                report.checks.append(
                    DoctorCheck(
                        category="Role Registry",
                        name=f"Role: {role.name}",
                        status="warning",
                        message=(
                            f"Role '{role.name}' has global zone access with "
                            f"can_override_irreversible=true — very powerful"
                        ),
                    )
                )

    except Exception as exc:
        report.checks.append(
            DoctorCheck(
                category="Role Registry",
                name="Roles config",
                status="error",
                message=f"Cannot load roles file {roles_file}: {exc}",
            )
        )


def _check_jurisdictional_dimension(report: DoctorReport, base_dir: Path) -> None:
    """Check 7: Jurisdictional dimension — warn if heavily used agents lack context."""

    try:
        from nomotic.audit_store import AuditStore

        store = AuditStore(base_dir)
        # Get all agent IDs from the store
        agents = store.list_agents() if hasattr(store, "list_agents") else []

        if not agents:
            report.checks.append(
                DoctorCheck(
                    category="Jurisdictional Compliance",
                    name="Jurisdictional context",
                    status="ok",
                    message="No agent audit records found; jurisdictional check skipped.",
                )
            )
            return

        for agent_id in agents:
            records = store.query_all(agent_id)
            n = len(records) if records else 0
            if n > 100:
                # Check if any record has jurisdictional context evidence
                has_jctx = any(
                    "jurisdictional" in str(getattr(r, "context_code", ""))
                    for r in records
                ) if records else False
                if not has_jctx:
                    report.checks.append(
                        DoctorCheck(
                            category="Jurisdictional Compliance",
                            name=f"Agent: {agent_id}",
                            status="ok",
                            message=(
                                f"Agent {agent_id} has {n} evaluations but no "
                                f"jurisdictional context configured. Consider adding "
                                f"JurisdictionalContext for regulated data operations."
                            ),
                        )
                    )
    except Exception:
        # Audit store may not exist or have the expected API; skip gracefully
        report.checks.append(
            DoctorCheck(
                category="Jurisdictional Compliance",
                name="Jurisdictional context",
                status="ok",
                message="Jurisdictional check skipped (audit store not available).",
            )
        )


def _check_model_provenance(report: DoctorReport, base_dir: Path) -> None:
    """Check 8: Model provenance — warn if high-risk agents lack provenance."""

    certs_dir = base_dir / "certs"
    if not certs_dir.exists():
        return

    try:
        from nomotic.store import FileCertificateStore
        from nomotic.certificate import CertStatus

        store = FileCertificateStore(base_dir)
        certs = store.list()
    except Exception:
        return

    high_risk_archetypes = {"decision_maker", "gatekeeper"}

    for cert in certs:
        if cert.status != CertStatus.ACTIVE:
            continue

        is_high_risk = (
            cert.archetype in high_risk_archetypes
            or cert.zone_path.endswith("/production")
            or "/production" in cert.zone_path
        )

        mp = getattr(cert, "model_provenance", None)

        if is_high_risk and mp is None:
            report.checks.append(
                DoctorCheck(
                    category="Model Provenance",
                    name=f"Agent: {cert.agent_id}",
                    status="warning",
                    message=(
                        f"Agent {cert.agent_id} ({cert.archetype}) in "
                        f"{cert.zone_path} has no model provenance recorded. "
                        f"Consider adding --model-provider and --model-name at "
                        f"birth time for EU AI Act Article 13 compliance."
                    ),
                )
            )
        elif mp is not None and mp.safety_evaluation_id is None and cert.archetype == "decision_maker":
            report.checks.append(
                DoctorCheck(
                    category="Model Provenance",
                    name=f"Agent: {cert.agent_id}",
                    status="ok",
                    message=(
                        f"Agent {cert.agent_id} has model provenance but no "
                        f"safety_evaluation_id. Consider linking an external "
                        f"safety evaluation for high-risk deployments."
                    ),
                )
            )


def _check_delegation_depths(report: DoctorReport, base_dir: Path) -> None:
    """Check 9: Delegation depths — warn if active chains exceed default limits."""

    from nomotic.delegation import DEFAULT_DELEGATION_DEPTH_LIMITS, DelegationTracker

    # Try to load active delegations from the delegation tracker via audit records
    audit_dir = base_dir / "audit"
    certs_dir = base_dir / "certs"

    # Build an archetype lookup from the cert store if available
    archetype_map: dict[str, str] = {}
    if certs_dir.exists():
        try:
            from nomotic.certificate import CertStatus
            from nomotic.store import FileCertificateStore

            store = FileCertificateStore(base_dir)
            for cert in store.list(status=CertStatus.ACTIVE):
                archetype_map[cert.agent_id] = cert.archetype
        except Exception:
            pass

    if not audit_dir.exists():
        return  # No audit data — nothing to check

    # Scan audit records for delegation entries and reconstruct chains
    try:
        from nomotic.audit_store import AuditStore
        from nomotic.delegation import DelegationDepthConfig

        audit_store = AuditStore(base_dir)
        agents = audit_store.list_agents()

        # Reconstruct a DelegationTracker with enforcement disabled (diagnostic only)
        no_enforce = DelegationDepthConfig(enforce_at_delegation=False)
        tracker = DelegationTracker(depth_config=no_enforce)
        all_agent_ids: set[str] = set()
        for agent_id in agents:
            try:
                records = audit_store.query_all(agent_id)
                for record in records:
                    if getattr(record, "action_type", None) == "delegate":
                        params = getattr(record, "parameters", {}) or {}
                        from_agent = agent_id
                        to_agent = getattr(record, "action_target", None)
                        if to_agent:
                            # Normalize to_agent to lowercase to match store's convention
                            to_agent_lower = to_agent.lower()
                            scope = set(params.get("delegated_scope", []))
                            targets = set(params.get("delegated_targets", []))
                            try:
                                tracker.delegate(
                                    from_agent, to_agent_lower,
                                    scope or {"*"}, targets or {"*"},
                                )
                                all_agent_ids.add(from_agent)
                                all_agent_ids.add(to_agent_lower)
                            except Exception:
                                pass
            except Exception:
                continue

        # Check each agent's delegation depth against archetype limits
        checked: set[str] = set()
        for agent_id in all_agent_ids:
            if agent_id in checked:
                continue
            checked.add(agent_id)
            depth = tracker.get_depth(agent_id)
            if depth == 0:
                continue
            archetype = archetype_map.get(agent_id, "*")
            limit = DEFAULT_DELEGATION_DEPTH_LIMITS.get(
                archetype, DEFAULT_DELEGATION_DEPTH_LIMITS.get("*", 3)
            )
            if depth > limit:
                report.checks.append(
                    DoctorCheck(
                        category="Delegation Depths",
                        name=f"Agent: {agent_id}",
                        status="warning",
                        message=(
                            f"Active delegation chain for {agent_id} is at depth "
                            f"{depth}, exceeding the default limit {limit} for "
                            f"archetype '{archetype}'. Consider configuring explicit "
                            f"depth limits or reviewing delegation structure."
                        ),
                    )
                )

    except Exception:
        # Audit store may not be available — skip gracefully
        pass


def _check_constitutional_engine(report: DoctorReport, base_dir: Path) -> None:
    """Check 10: Constitutional engine — ruleset presence and signature validity."""

    ruleset_path = base_dir / "constitution.json"
    if not ruleset_path.exists():
        report.checks.append(
            DoctorCheck(
                category="Constitutional Engine",
                name="Constitutional ruleset",
                status="warning",
                message=(
                    "No constitutional ruleset configured. "
                    "Consider adding constitution.json for production deployments."
                ),
            )
        )
        return

    try:
        from nomotic.constitution import ConstitutionalRuleSet

        ruleset = ConstitutionalRuleSet.from_file(ruleset_path)
    except Exception as exc:
        report.checks.append(
            DoctorCheck(
                category="Constitutional Engine",
                name="Constitutional ruleset",
                status="error",
                message=f"Cannot load constitutional ruleset: {exc}",
            )
        )
        return

    # Verify signature using issuer key
    try:
        from nomotic.keys import SigningKey

        key_path = base_dir / "issuer" / "issuer.key"
        if key_path.exists():
            sk = SigningKey.from_bytes(key_path.read_bytes())
            vk = sk.verify_key()
            if ruleset.verify_signature(vk.to_bytes()):
                report.checks.append(
                    DoctorCheck(
                        category="Constitutional Engine",
                        name="Constitutional ruleset",
                        status="ok",
                        message=(
                            f"{len(ruleset.rules)} constitutional rule(s) loaded, "
                            f"signature valid (signed by {ruleset.signed_by})"
                        ),
                    )
                )
            else:
                report.checks.append(
                    DoctorCheck(
                        category="Constitutional Engine",
                        name="Constitutional ruleset",
                        status="error",
                        message=(
                            "Constitutional ruleset signature verification FAILED. "
                            "The ruleset may have been tampered with."
                        ),
                    )
                )
        else:
            report.checks.append(
                DoctorCheck(
                    category="Constitutional Engine",
                    name="Constitutional ruleset",
                    status="warning",
                    message=(
                        f"{len(ruleset.rules)} rule(s) loaded but cannot verify "
                        f"signature (no issuer key found)"
                    ),
                )
            )
    except Exception as exc:
        report.checks.append(
            DoctorCheck(
                category="Constitutional Engine",
                name="Constitutional ruleset",
                status="error",
                message=f"Signature verification error: {exc}",
            )
        )


def _check_authority_registry(report: DoctorReport, base_dir: Path) -> None:
    """Check governance authority registry configuration."""
    registry_path = base_dir / "authority_registry.json"

    if not registry_path.exists():
        report.checks.append(
            DoctorCheck(
                category="Authority Registry",
                name="Authority registry",
                status="warning",
                message=(
                    "No authority registry configured — governance has no governance. "
                    "Any caller can reconfigure the system."
                ),
                fix_hint="nomotic authority-registry bootstrap --name <name>",
            )
        )
        return

    try:
        from nomotic.authority_registry import GovernanceAuthorityRegistry

        registry = GovernanceAuthorityRegistry()
        registry.load_from_file(registry_path)
        authorities = registry.list_authorities()

        if not authorities:
            report.checks.append(
                DoctorCheck(
                    category="Authority Registry",
                    name="Authority registry",
                    status="warning",
                    message="Authority registry file exists but contains no authorities",
                    fix_hint="nomotic authority-registry bootstrap --name <name>",
                )
            )
            return

        report.checks.append(
            DoctorCheck(
                category="Authority Registry",
                name="Authority registry",
                status="ok",
                message=f"{len(authorities)} governance authority(ies) registered",
            )
        )

        # Check for expired authorities
        expired = [a for a in authorities if a.is_expired()]
        if expired:
            names = ", ".join(a.name for a in expired)
            report.checks.append(
                DoctorCheck(
                    category="Authority Registry",
                    name="Expired authorities",
                    status="warning",
                    message=f"{len(expired)} expired authority(ies): {names}",
                )
            )

    except Exception as exc:
        report.checks.append(
            DoctorCheck(
                category="Authority Registry",
                name="Authority registry",
                status="error",
                message=f"Failed to load authority registry: {exc}",
            )
        )


def _check_config_backups(report: DoctorReport, base_dir: Path) -> None:
    """Check 12: Configuration backups — presence, freshness, and signature validity."""

    backups_dir = base_dir / "backups"
    if not backups_dir.exists():
        report.checks.append(
            DoctorCheck(
                category="Config Backups",
                name="config_backups",
                status="warning",
                message=(
                    "Config backup manager not configured. "
                    "Enable with RuntimeConfig(enable_config_backups=True, "
                    "config_backup_signing_secret='...')"
                ),
            )
        )
        return

    from nomotic.config_backup import ConfigBackupManager

    for artifact_type in sorted(ConfigBackupManager.VALID_ARTIFACT_TYPES):
        artifact_dir = backups_dir / artifact_type
        if not artifact_dir.exists():
            report.checks.append(
                DoctorCheck(
                    category="Config Backups",
                    name=f"config_backup_{artifact_type}",
                    status="warning",
                    message=f"No backups found for {artifact_type}.",
                )
            )
            continue

        # Load backup files to check
        backup_files = list(artifact_dir.glob("nmbk-*.json"))
        if not backup_files:
            report.checks.append(
                DoctorCheck(
                    category="Config Backups",
                    name=f"config_backup_{artifact_type}",
                    status="warning",
                    message=f"No backups found for {artifact_type}.",
                )
            )
            continue

        # Find the most recent backup
        latest_data = None
        latest_ts = 0.0
        for fp in backup_files:
            try:
                data = json.loads(fp.read_text(encoding="utf-8"))
                ts = data.get("created_at", 0.0)
                if ts > latest_ts:
                    latest_ts = ts
                    latest_data = data
            except (json.JSONDecodeError, OSError):
                continue

        if latest_data is None:
            report.checks.append(
                DoctorCheck(
                    category="Config Backups",
                    name=f"config_backup_{artifact_type}",
                    status="warning",
                    message=f"No backups found for {artifact_type}.",
                )
            )
            continue

        # We can only check structure — we cannot verify HMAC without the secret.
        # But we can check age.
        age_days = (time.time() - latest_ts) / 86400
        backup_id = latest_data.get("backup_id", "unknown")
        n_backups = len(backup_files)

        if age_days > 7:
            report.checks.append(
                DoctorCheck(
                    category="Config Backups",
                    name=f"config_backup_{artifact_type}",
                    status="warning",
                    message=(
                        f"Latest backup for {artifact_type} is "
                        f"{age_days:.1f} days old. Consider refreshing."
                    ),
                )
            )
        else:
            report.checks.append(
                DoctorCheck(
                    category="Config Backups",
                    name=f"config_backup_{artifact_type}",
                    status="ok",
                    message=(
                        f"{artifact_type}: {n_backups} backup(s), "
                        f"latest {backup_id} ({age_days:.1f}d old)."
                    ),
                )
            )
