"""Role-Based Override Permissions.

Scoped override authority for governance decisions. Not every authority
can override every decision. Roles define who can override what, in which
zones, for which agent archetypes, at which risk tiers.

Roles are loaded from a YAML or JSON config file. If no role registry is
configured, override proceeds with a deprecation-style warning — backward
compatible, never a hard failure for unconfigured deployments.

Role ID format: nmr-<uuid4>
"""

from __future__ import annotations

import fnmatch
import hashlib
import json
import threading
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

__all__ = [
    "OverrideRole",
    "PermissionDeniedError",
    "PermissionResult",
    "RoleConfigError",
    "RoleRegistry",
]

_RISK_TIERS = ["low", "moderate", "high", "critical"]


class RoleConfigError(Exception):
    """Raised for invalid role config files (malformed YAML/JSON, missing required fields)."""


@dataclass
class OverrideRole:
    """A role that grants override authority within scoped constraints."""

    role_id: str  # "nmr-<uuid4>"
    name: str  # Human-readable
    authorities: list[str]  # email/user IDs who hold this role
    permitted_override_types: list[str]  # ["APPROVE", "REVOKE"] or subset
    permitted_zones: list[str]  # Zone glob patterns, ["eu/*", "us/*"], ["*"] for all
    permitted_archetypes: list[str]  # Agent archetypes, ["*"] for all
    permitted_action_types: list[str]  # Action types, ["*"] for all
    max_risk_tier: str  # "low" | "moderate" | "high" | "critical"
    can_override_irreversible: bool  # Whether role can approve irreversible denials
    created_by: str
    created_at: float  # Unix timestamp
    role_hash: str  # SHA-256 of canonical JSON for tamper detection

    def to_dict(self) -> dict[str, Any]:
        return {
            "role_id": self.role_id,
            "name": self.name,
            "authorities": self.authorities,
            "permitted_override_types": self.permitted_override_types,
            "permitted_zones": self.permitted_zones,
            "permitted_archetypes": self.permitted_archetypes,
            "permitted_action_types": self.permitted_action_types,
            "max_risk_tier": self.max_risk_tier,
            "can_override_irreversible": self.can_override_irreversible,
            "created_by": self.created_by,
            "created_at": self.created_at,
            "role_hash": self.role_hash,
        }


@dataclass
class PermissionResult:
    """Result of a role-based permission check."""

    permitted: bool
    role_id: str | None  # Which role granted permission (None if denied)
    reason: str  # Human-readable explanation
    authority: str
    override_type: str


class PermissionDeniedError(Exception):
    """Raised when an authority attempts an override they are not permitted to make."""

    def __init__(self, result: PermissionResult):
        self.result = result
        super().__init__(result.reason)


def _glob_match(pattern: str, value: str) -> bool:
    """Match a value against a glob pattern. '*' matches anything."""
    return fnmatch.fnmatch(value, pattern)


def _compute_role_hash(role_dict: dict[str, Any]) -> str:
    """Compute SHA-256 hash of a role dict (excluding role_hash field)."""
    d = {k: v for k, v in role_dict.items() if k != "role_hash"}
    return hashlib.sha256(json.dumps(d, sort_keys=True).encode()).hexdigest()


class RoleRegistry:
    """Thread-safe registry of override roles."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._roles: list[OverrideRole] = []
        self._by_id: dict[str, OverrideRole] = {}

    def register(self, role: OverrideRole) -> None:
        """Add a role to the registry."""
        with self._lock:
            self._roles.append(role)
            self._by_id[role.role_id] = role

    def load_from_file(self, path: str | Path) -> int:
        """Load roles from a YAML or JSON file. Returns count of roles loaded."""
        path = Path(path)
        ext = path.suffix.lower()

        try:
            raw = path.read_text(encoding="utf-8")
        except OSError as exc:
            raise RoleConfigError(f"Cannot read role file: {exc}") from exc

        if ext in (".yaml", ".yml"):
            try:
                import yaml
            except ImportError:
                raise RoleConfigError(
                    "YAML role files require PyYAML: pip install pyyaml"
                )
            try:
                data = yaml.safe_load(raw)
            except Exception as exc:
                raise RoleConfigError(f"Invalid YAML: {exc}") from exc
        elif ext == ".json":
            try:
                data = json.loads(raw)
            except json.JSONDecodeError as exc:
                raise RoleConfigError(f"Invalid JSON: {exc}") from exc
        else:
            raise RoleConfigError(
                f"Unsupported file extension '{ext}' — use .yaml, .yml, or .json"
            )

        if not isinstance(data, dict) or "roles" not in data:
            raise RoleConfigError("Role file must contain a 'roles' key")

        roles_list = data["roles"]
        if not isinstance(roles_list, list):
            raise RoleConfigError("'roles' must be a list")

        required_fields = {"name", "authorities", "permitted_override_types"}
        count = 0

        for entry in roles_list:
            if not isinstance(entry, dict):
                raise RoleConfigError("Each role must be a dict")

            missing = required_fields - set(entry.keys())
            if missing:
                raise RoleConfigError(
                    f"Role missing required field(s): {', '.join(sorted(missing))}"
                )

            role_id = entry.get("role_id") or f"nmr-{uuid.uuid4()}"
            created_at = entry.get("created_at") or time.time()

            role_dict = {
                "role_id": role_id,
                "name": entry["name"],
                "authorities": entry["authorities"],
                "permitted_override_types": entry["permitted_override_types"],
                "permitted_zones": entry.get("permitted_zones", ["*"]),
                "permitted_archetypes": entry.get("permitted_archetypes", ["*"]),
                "permitted_action_types": entry.get("permitted_action_types", ["*"]),
                "max_risk_tier": entry.get("max_risk_tier", "critical"),
                "can_override_irreversible": entry.get("can_override_irreversible", False),
                "created_by": entry.get("created_by", ""),
                "created_at": created_at,
            }

            role_hash = entry.get("role_hash") or _compute_role_hash(role_dict)
            role_dict["role_hash"] = role_hash

            role = OverrideRole(**role_dict)
            self.register(role)
            count += 1

        return count

    def check_permission(
        self,
        authority: str,
        override_type: str,
        action_type: str,
        zone_path: str,
        archetype: str,
        is_irreversible: bool,
        risk_tier: str,
    ) -> PermissionResult:
        """Check if authority is permitted to perform the override.

        Returns the first matching role that grants permission, or a denied
        result if none match.
        """
        with self._lock:
            for role in self._roles:
                # Check authority
                if authority not in role.authorities:
                    continue

                # Check override type
                if override_type not in role.permitted_override_types:
                    continue

                # Check zone
                if not any(
                    _glob_match(pat, zone_path)
                    for pat in role.permitted_zones
                ):
                    continue

                # Check archetype
                if not any(
                    _glob_match(pat, archetype)
                    for pat in role.permitted_archetypes
                ):
                    continue

                # Check action type
                if not any(
                    _glob_match(pat, action_type)
                    for pat in role.permitted_action_types
                ):
                    continue

                # Check risk tier
                try:
                    tier_idx = _RISK_TIERS.index(risk_tier)
                    max_idx = _RISK_TIERS.index(role.max_risk_tier)
                except ValueError:
                    continue
                if tier_idx > max_idx:
                    continue

                # Check irreversible
                if is_irreversible and not role.can_override_irreversible:
                    continue

                # All checks passed
                return PermissionResult(
                    permitted=True,
                    role_id=role.role_id,
                    reason=f"Permitted by role '{role.name}' ({role.role_id})",
                    authority=authority,
                    override_type=override_type,
                )

        # No matching role found
        return PermissionResult(
            permitted=False,
            role_id=None,
            reason=(
                f"No role grants authority '{authority}' permission to "
                f"{override_type} actions of type '{action_type}' in zone '{zone_path}'"
            ),
            authority=authority,
            override_type=override_type,
        )

    def list_roles(self) -> list[OverrideRole]:
        """Return all registered roles."""
        with self._lock:
            return list(self._roles)

    def get_role(self, role_id: str) -> OverrideRole | None:
        """Get a role by ID."""
        with self._lock:
            return self._by_id.get(role_id)

    def has_roles(self) -> bool:
        """True if any roles are registered."""
        with self._lock:
            return len(self._roles) > 0
