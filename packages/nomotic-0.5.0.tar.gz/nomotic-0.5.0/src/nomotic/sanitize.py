"""Data Sanitization Layer — prevents sensitive data from persisting.

Scans and redacts sensitive information in audit trails, reasoning
artifacts, governance tokens, and exports.  Uses pattern matching on
field names and values, plus Shannon entropy detection for high-entropy
strings that may be secrets.

Zero external dependencies — stdlib only (re, hashlib, hmac, math,
collections).
"""

from __future__ import annotations

import hashlib
import hmac
import math
import os
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import Any

__all__ = [
    "SanitizationPolicy",
    "Sanitizer",
    "sanitize_audit_record",
    "sanitize_for_export",
    "sanitize_reasoning_artifact",
]


# ── SanitizationPolicy ───────────────────────────────────────────────


@dataclass
class SanitizationPolicy:
    """Configuration controlling what gets redacted and how.

    Designed for broad, automatic detection of sensitive data across
    all governance artifacts.  Complements :class:`AnonymizationPolicy`
    (which targets per-method attribute hiding).
    """

    enabled: bool = False

    # Regex patterns for known sensitive field names
    sensitive_field_patterns: list[str] = field(default_factory=lambda: [
        r"(?i)password",
        r"(?i)secret",
        r"(?i)api[_-]?key",
        r"(?i)token",
        r"(?i)credential",
        r"(?i)ssn",
        r"(?i)social.security",
        r"(?i)credit.card",
        r"(?i)account.number",
        r"(?i)routing.number",
    ])

    # Regex patterns for known sensitive value formats
    sensitive_value_patterns: list[str] = field(default_factory=lambda: [
        r"(?i)^sk[-_]",
        r"(?i)^ak[-_]",
        r"(?i)^AKIA",
        r"\b\d{3}-\d{2}-\d{4}\b",                        # SSN
        r"\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b",  # credit card
    ])

    # Shannon entropy threshold for flagging high-entropy strings
    entropy_threshold: float = 4.5

    # Minimum string length to check entropy on
    entropy_min_length: int = 16

    # Fields to NEVER sanitize (governance hashes, record IDs)
    preserve_field_patterns: list[str] = field(default_factory=lambda: [
        r".*_hash$",
        r".*_digest$",
        r"record_id$",
        r"action_id$",
        r"agent_id$",
        r"certificate_id$",
        r"^previous_hash$",
        r"^record_hash$",
    ])

    # Redaction format
    redaction_placeholder: str = "[REDACTED]"

    # Whether to use deterministic redaction (same input -> same placeholder)
    deterministic: bool = True

    # HMAC key for deterministic redaction (if None, generated at init)
    hmac_key: bytes | None = None


# ── Sanitizer ─────────────────────────────────────────────────────────


class Sanitizer:
    """Stateful sanitizer that redacts sensitive data from dicts and strings.

    When *deterministic* mode is enabled the same input value always
    produces the same ``[REDACTED:a1b2c3]`` token within a session,
    preserving referential integrity across audit records.
    """

    def __init__(self, policy: SanitizationPolicy) -> None:
        self._policy = policy

        # Compile regexes once
        self._field_res = [re.compile(p) for p in policy.sensitive_field_patterns]
        self._value_res = [re.compile(p) for p in policy.sensitive_value_patterns]
        self._preserve_res = [re.compile(p) for p in policy.preserve_field_patterns]

        # For inline string scanning, build variants without ^ anchors
        self._inline_value_res = [
            re.compile(p.replace("^", "")) for p in policy.sensitive_value_patterns
        ]

        # HMAC key for deterministic redaction
        self._hmac_key = policy.hmac_key or os.urandom(32)

    # ── Public API ────────────────────────────────────────────────

    def sanitize_dict(self, data: dict[str, Any]) -> dict[str, Any]:
        """Deep-walk a dict, redacting sensitive fields and values.

        Returns a new dict — the original is never mutated.
        """
        return self._walk_dict(data)

    def sanitize_string(self, text: str) -> str:
        """Scan free-form text for sensitive patterns and redact inline.

        Uses anchor-stripped variants of the value patterns so that
        matches are found anywhere in the text, not just at the start.
        """
        if not text:
            return text
        result = text
        for pattern in self._inline_value_res:
            result = pattern.sub(lambda m: self.redact(m.group(0)), result)
        return result

    @staticmethod
    def shannon_entropy(s: str) -> float:
        """Calculate Shannon entropy of a string in bits per character."""
        if not s:
            return 0.0
        counts = Counter(s)
        length = len(s)
        entropy = 0.0
        for count in counts.values():
            p = count / length
            if p > 0:
                entropy -= p * math.log2(p)
        return entropy

    def is_sensitive_field(self, field_name: str) -> bool:
        """Return True if *field_name* matches a sensitive-field pattern."""
        # Check preserve list first — preserved fields are never sensitive
        if self._is_preserved_field(field_name):
            return False
        return any(rx.search(field_name) for rx in self._field_res)

    def is_sensitive_value(self, value: str) -> bool:
        """Return True if *value* matches a sensitive-value pattern or
        exceeds the entropy threshold."""
        if any(rx.search(value) for rx in self._value_res):
            return True
        # Entropy check for long strings
        if (
            len(value) >= self._policy.entropy_min_length
            and self.shannon_entropy(value) >= self._policy.entropy_threshold
        ):
            return True
        return False

    def redact(self, value: str) -> str:
        """Produce a redaction token for *value*.

        If deterministic mode is on, the same *value* always produces
        the same ``[REDACTED:a1b2c3]`` token (first 6 hex chars of an
        HMAC-SHA256 digest).  Otherwise returns the plain placeholder.
        """
        if self._policy.deterministic:
            digest = hmac.new(
                self._hmac_key,
                value.encode("utf-8"),
                hashlib.sha256,
            ).hexdigest()[:6]
            return f"[REDACTED:{digest}]"
        return self._policy.redaction_placeholder

    # ── Internal helpers ──────────────────────────────────────────

    def _is_preserved_field(self, field_name: str) -> bool:
        """Return True if the field should never be redacted."""
        return any(rx.search(field_name) for rx in self._preserve_res)

    def _walk_dict(self, data: dict[str, Any]) -> dict[str, Any]:
        """Recursively walk a dict, redacting sensitive entries."""
        result: dict[str, Any] = {}
        for key, value in data.items():
            result[key] = self._sanitize_entry(key, value)
        return result

    def _sanitize_entry(self, key: str, value: Any) -> Any:
        """Sanitize a single key-value pair."""
        # Preserved fields pass through untouched
        if self._is_preserved_field(key):
            return value

        # If the field name is sensitive, redact the entire value
        if self.is_sensitive_field(key):
            if isinstance(value, bool) or value is None:
                return value  # booleans and None pass through
            elif isinstance(value, str):
                return self.redact(value)
            elif isinstance(value, (int, float)):
                return self.redact(str(value))
            elif isinstance(value, dict):
                return self.redact(str(value))
            elif isinstance(value, list):
                return self.redact(str(value))
            else:
                return value

        # Otherwise, recurse into containers or check string values
        if isinstance(value, dict):
            return self._walk_dict(value)
        elif isinstance(value, list):
            return [self._sanitize_list_item(item) for item in value]
        elif isinstance(value, str):
            if self.is_sensitive_value(value):
                return self.redact(value)
            return value
        else:
            return value

    def _sanitize_list_item(self, item: Any) -> Any:
        """Sanitize an item inside a list."""
        if isinstance(item, dict):
            return self._walk_dict(item)
        elif isinstance(item, str):
            if self.is_sensitive_value(item):
                return self.redact(item)
            return item
        elif isinstance(item, list):
            return [self._sanitize_list_item(i) for i in item]
        else:
            return item


# ── Integration wrappers ──────────────────────────────────────────────


def sanitize_audit_record(
    record: Any,
    policy: SanitizationPolicy,
) -> Any:
    """Sanitize an :class:`AuditRecord` in place.

    Redacts sensitive data in:
    - ``metadata`` (which may contain action parameters)
    - ``justification`` text
    - ``action_target`` (if it matches sensitive patterns)

    Returns the same record object (mutated).
    """
    sanitizer = Sanitizer(policy)

    # Metadata (contains action parameters, session info, etc.)
    if record.metadata:
        record.metadata = sanitizer.sanitize_dict(record.metadata)

    # Justification text may reference sensitive data inline
    if record.justification:
        record.justification = sanitizer.sanitize_string(record.justification)

    # Action target might be a sensitive resource path
    if record.action_target and sanitizer.is_sensitive_value(record.action_target):
        record.action_target = sanitizer.redact(record.action_target)

    return record


def sanitize_reasoning_artifact(
    artifact: dict[str, Any],
    policy: SanitizationPolicy,
) -> dict[str, Any]:
    """Sanitize a reasoning artifact dict.

    Redacts sensitive data in:
    - ``task.goal`` (task description)
    - ``reasoning.factors`` (factor descriptions, assessments)
    - ``decision.intended_action.parameters``
    - ``reasoning.narrative``

    Returns a new dict — the original is not mutated.
    """
    sanitizer = Sanitizer(policy)
    result = _deep_copy_dict(artifact)

    # Task section
    if "task" in result:
        task = result["task"]
        if "goal" in task and isinstance(task["goal"], str):
            task["goal"] = sanitizer.sanitize_string(task["goal"])

    # Reasoning section
    if "reasoning" in result:
        reasoning = result["reasoning"]
        if "factors" in reasoning:
            for factor in reasoning["factors"]:
                if isinstance(factor, dict):
                    for fkey in ("description", "assessment", "source"):
                        if fkey in factor and isinstance(factor[fkey], str):
                            factor[fkey] = sanitizer.sanitize_string(factor[fkey])
        if "narrative" in reasoning and isinstance(reasoning["narrative"], str):
            reasoning["narrative"] = sanitizer.sanitize_string(reasoning["narrative"])

    # Decision section
    if "decision" in result:
        decision = result["decision"]
        if "intended_action" in decision:
            ia = decision["intended_action"]
            if "parameters" in ia and isinstance(ia["parameters"], dict):
                ia["parameters"] = sanitizer.sanitize_dict(ia["parameters"])

    return result


def sanitize_for_export(
    data: dict[str, Any] | list[Any] | str,
    policy: SanitizationPolicy,
) -> dict[str, Any] | list[Any] | str:
    """General-purpose sanitizer for any export format.

    Handles dicts, lists of dicts, or plain strings.
    """
    sanitizer = Sanitizer(policy)

    if isinstance(data, dict):
        return sanitizer.sanitize_dict(data)
    elif isinstance(data, list):
        return [
            sanitizer.sanitize_dict(item) if isinstance(item, dict)
            else sanitizer.sanitize_string(item) if isinstance(item, str)
            else item
            for item in data
        ]
    elif isinstance(data, str):
        return sanitizer.sanitize_string(data)
    return data


# ── Helpers ───────────────────────────────────────────────────────────


def _deep_copy_dict(d: dict[str, Any]) -> dict[str, Any]:
    """Simple deep copy for JSON-like dicts (no external deps)."""
    result: dict[str, Any] = {}
    for k, v in d.items():
        if isinstance(v, dict):
            result[k] = _deep_copy_dict(v)
        elif isinstance(v, list):
            result[k] = _deep_copy_list(v)
        else:
            result[k] = v
    return result


def _deep_copy_list(lst: list[Any]) -> list[Any]:
    """Simple deep copy for JSON-like lists."""
    result: list[Any] = []
    for item in lst:
        if isinstance(item, dict):
            result.append(_deep_copy_dict(item))
        elif isinstance(item, list):
            result.append(_deep_copy_list(item))
        else:
            result.append(item)
    return result
