"""Agent Lifecycle Hooks.

Lifecycle hooks fire when agents reach governance milestones:
- BIRTH:      After certificate issuance (agent active and ready)
- DEGRADED:   UAHS drops below warning threshold (0.5 default)
- CRITICAL:   UAHS drops below critical threshold (0.2 default)
- RETIREMENT: Trust falls below 0.1 OR certificate expires
- REVOCATION: Certificate is explicitly revoked

Hooks are callbacks registered per event type. Multiple hooks can be
registered for the same event. Hook failures are isolated — one failing
hook never prevents others from firing.

All lifecycle events are recorded in the audit trail regardless of
whether any hooks are registered.
"""

from __future__ import annotations

import logging
import threading
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable

__all__ = [
    "LifecycleContext",
    "LifecycleEvent",
    "LifecycleHookFn",
    "LifecycleManager",
]

logger = logging.getLogger(__name__)


class LifecycleEvent(str, Enum):
    """Lifecycle milestones for governed agents."""

    BIRTH = "agent.birth"
    DEGRADED = "agent.degraded"
    CRITICAL = "agent.critical"
    RETIREMENT = "agent.retirement"
    REVOCATION = "agent.revocation"


@dataclass
class LifecycleContext:
    """Context passed to all lifecycle hook callbacks.

    Contains the full state of the agent at the moment the event fires.
    """

    event: LifecycleEvent
    agent_id: str
    agent_name: str  # From certificate or agent_id if unavailable
    archetype: str  # From certificate or "unknown"
    trust_score: float  # overall_trust at time of event
    timestamp: float  # Unix timestamp
    certificate_id: str | None = None
    uahs_score: float | None = None  # None if UAHS not enabled
    trigger_reason: str = ""  # Human-readable reason for event
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a plain dictionary."""
        return {
            "event": self.event.value,
            "agent_id": self.agent_id,
            "agent_name": self.agent_name,
            "archetype": self.archetype,
            "trust_score": self.trust_score,
            "timestamp": self.timestamp,
            "certificate_id": self.certificate_id,
            "uahs_score": self.uahs_score,
            "trigger_reason": self.trigger_reason,
            "metadata": dict(self.metadata),
        }


# Type alias for hook callbacks
LifecycleHookFn = Callable[[LifecycleContext], None]


class LifecycleManager:
    """Manages registration and dispatch of agent lifecycle hooks.

    Thread-safe: multiple agents can trigger events concurrently.
    Hook failures are caught, logged, and never re-raised.
    """

    def __init__(
        self,
        webhook_dispatcher: Any = None,  # WebhookDispatcher | None
    ) -> None:
        self._hooks: dict[LifecycleEvent, list[tuple[str, LifecycleHookFn]]] = {
            event: [] for event in LifecycleEvent
        }
        self._dispatcher = webhook_dispatcher
        self._lock = threading.Lock()
        self._event_history: list[dict[str, Any]] = []

    def register(
        self,
        event: LifecycleEvent,
        hook: LifecycleHookFn,
        name: str = "",
    ) -> str:
        """Register a hook callback for an event.

        Returns hook_id (nmhk-<uuid>) for later deregistration.
        """
        hook_id = f"nmhk-{uuid.uuid4().hex[:12]}"
        label = name or (hook.__name__ if hasattr(hook, "__name__") else hook_id)
        with self._lock:
            self._hooks[event].append((hook_id, hook))
        logger.debug("Registered lifecycle hook %s (%s) for %s", hook_id, label, event.value)
        return hook_id

    def deregister(self, hook_id: str) -> bool:
        """Remove a hook by its ID. Returns True if found and removed."""
        with self._lock:
            for event in LifecycleEvent:
                for i, (hid, _) in enumerate(self._hooks[event]):
                    if hid == hook_id:
                        self._hooks[event].pop(i)
                        logger.debug("Deregistered lifecycle hook %s from %s", hook_id, event.value)
                        return True
        return False

    def trigger(
        self,
        event: LifecycleEvent,
        context: LifecycleContext,
    ) -> None:
        """Trigger all hooks for an event.

        Always records in event history first (built-in, cannot be removed).
        Then fires registered hooks in registration order.
        Exceptions from any hook are caught and logged — they never propagate.
        """
        # Built-in: always write audit record
        try:
            self._audit_archive_hook(context)
        except Exception:
            pass

        with self._lock:
            hooks_snapshot = list(self._hooks[event])

        for hook_id, hook_fn in hooks_snapshot:
            try:
                hook_fn(context)
            except Exception as exc:
                logger.warning(
                    "Lifecycle hook %s failed for event %s agent %s: %s",
                    hook_id,
                    event.value,
                    context.agent_id,
                    exc,
                )

    def register_webhook_hook(
        self,
        event: LifecycleEvent,
        url: str,
        secret: str | None = None,
    ) -> str:
        """Register a webhook URL as a lifecycle hook.

        On event trigger, POSTs LifecycleContext.to_dict() to url.
        Uses WebhookDispatcher if available, else silently skips.
        """

        def webhook_fn(ctx: LifecycleContext) -> None:
            if self._dispatcher is not None:
                from nomotic.webhooks import WebhookEvent

                wh_event = WebhookEvent(
                    event_type=f"LIFECYCLE_{event.name}",
                    event_id=f"nme-{uuid.uuid4().hex[:12]}",
                    timestamp=time.time(),
                    agent_id=ctx.agent_id,
                    payload=ctx.to_dict(),
                )
                self._dispatcher.dispatch(wh_event)
            # If no dispatcher, silently skip

        return self.register(event, webhook_fn, name=f"webhook:{url}")

    def list_hooks(self) -> list[dict[str, Any]]:
        """Return list of registered hooks with their event bindings."""
        result = []
        with self._lock:
            for event, hooks in self._hooks.items():
                for hook_id, _ in hooks:
                    result.append({
                        "hook_id": hook_id,
                        "event": event.value,
                    })
        return result

    def get_event_history(self, agent_id: str | None = None) -> list[dict[str, Any]]:
        """Return lifecycle event history, optionally filtered by agent_id."""
        if agent_id is None:
            return list(self._event_history)
        return [e for e in self._event_history if e.get("agent_id") == agent_id]

    def _audit_archive_hook(self, context: LifecycleContext) -> None:
        """Built-in hook: record lifecycle event in internal history.

        Fires for every lifecycle event regardless of registered hooks.
        """
        self._event_history.append(context.to_dict())
