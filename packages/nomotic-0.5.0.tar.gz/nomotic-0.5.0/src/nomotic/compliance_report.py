"""Compliance Report Generator — maps Nomotic governance dimensions to
regulatory framework controls.

Generates compliance mapping documents showing how Nomotic's 14 governance
dimensions align to specific regulatory framework controls. This is the
document you hand to an examiner.

Design principles:
- The report maps Nomotic capabilities to framework controls, not the reverse
- Reports include evidence (action counts, denial rates, trust trajectories)
- Reports identify gaps honestly — controls that Nomotic partially or doesn't address
- Every report includes a disclaimer
- Reports include governance layer coverage summary

Custom framework JSON schema::

    {
      "framework_id": "my-org-ai-policy",
      "name": "My Organization AI Governance Policy",
      "version": "2026-Q1",
      "description": "Internal AI governance controls for our agentic systems",
      "controls": [
        {
          "control_id": "AI-GOV-001",
          "description": "All AI agents must operate within defined action scopes",
          "nomotic_dimensions": ["scope_compliance", "isolation_integrity"],
          "coverage": "full",
          "notes": "Enforced at runtime via ScopeCompliance and IsolationIntegrity"
        }
      ]
    }

Required top-level fields: ``framework_id``, ``name``, ``controls``.
Optional top-level fields: ``version``, ``description``.

Each control requires: ``control_id``, ``description``, ``nomotic_dimensions``,
``coverage``.  Valid coverage values: ``"full"``, ``"partial"``, ``"indirect"``,
``"none"``.  Optional control fields: ``notes``.

Zero external dependencies — stdlib only.
"""

from __future__ import annotations

import json
import time
import warnings
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

__all__ = [
    "AgentEvidence",
    "ComplianceReport",
    "ComplianceReportGenerator",
    "ControlMapping",
    "ControlReport",
    "FrameworkLoadError",
    "FrameworkMapping",
    "GovernanceLayerMap",
    "ReportSummary",
    "discover_frameworks",
    "format_json",
    "format_markdown",
    "load_custom_framework",
    "FRAMEWORK_MAPPINGS",
]

DISCLAIMER = (
    "This report reflects Nomotic's interpretation of governance alignment. "
    "It does not constitute compliance certification."
)

# Valid dimension names — must match DimensionRegistry.create_default()
VALID_DIMENSIONS = frozenset({
    "scope_compliance",
    "authority_verification",
    "resource_boundaries",
    "behavioral_consistency",
    "cascading_impact",
    "stakeholder_impact",
    "incident_detection",
    "isolation_integrity",
    "temporal_compliance",
    "precedent_alignment",
    "transparency",
    "human_override",
    "ethical_alignment",
    "jurisdictional_compliance",
})

VALID_COVERAGE = frozenset({"full", "partial", "indirect", "none"})

# Known dimension names for custom framework validation.
# Mirrors VALID_DIMENSIONS — unknown names emit a warning, not an error.
_KNOWN_DIMENSION_NAMES: frozenset[str] = VALID_DIMENSIONS


# ── Exceptions ──────────────────────────────────────────────────────────


class FrameworkLoadError(Exception):
    """Raised when a custom framework file fails to load or validate."""

    def __init__(self, path: str, reason: str):
        self.path = path
        self.reason = reason
        super().__init__(f"Failed to load framework from {path}: {reason}")


# ── Data Classes ────────────────────────────────────────────────────────


@dataclass(frozen=True)
class ControlMapping:
    """Maps a single compliance framework control to Nomotic dimensions."""

    control_id: str
    control_name: str
    description: str
    nomotic_dimensions: list[str]
    coverage: str  # "full", "partial", "indirect", "none"
    notes: str  # How Nomotic addresses this

    def to_dict(self) -> dict[str, Any]:
        return {
            "control_id": self.control_id,
            "control_name": self.control_name,
            "description": self.description,
            "nomotic_dimensions": list(self.nomotic_dimensions),
            "coverage": self.coverage,
            "notes": self.notes,
        }


@dataclass
class FrameworkMapping:
    """A complete mapping for a regulatory framework."""

    framework_id: str
    framework_name: str
    version: str
    controls: list[ControlMapping]
    description: str = ""

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "framework_id": self.framework_id,
            "framework_name": self.framework_name,
            "version": self.version,
            "controls": [c.to_dict() for c in self.controls],
        }
        if self.description:
            d["description"] = self.description
        return d


@dataclass
class AgentEvidence:
    """Evidence gathered from audit trail for a specific agent."""

    total_actions: int
    total_denials: int
    denial_rate: float
    average_ucs: float
    trust_current: float
    trust_trend: str  # "rising", "stable", "falling"
    active_alerts: int
    sealed_actions: int  # Actions with governance seals
    last_activity: float  # timestamp

    def to_dict(self) -> dict[str, Any]:
        return {
            "total_actions": self.total_actions,
            "total_denials": self.total_denials,
            "denial_rate": self.denial_rate,
            "average_ucs": self.average_ucs,
            "trust_current": self.trust_current,
            "trust_trend": self.trust_trend,
            "active_alerts": self.active_alerts,
            "sealed_actions": self.sealed_actions,
            "last_activity": self.last_activity,
        }


@dataclass
class GovernanceLayerMap:
    """What Nomotic covers as L5, what it feeds to other layers."""

    l5_controls: list[str]  # What Nomotic enforces at runtime
    l6_outputs: list[str]   # What Nomotic provides to outcome monitoring
    l1_inputs: list[str]    # What Nomotic needs from strategic governance
    l4_inputs: list[str]    # What Nomotic needs from model governance

    def to_dict(self) -> dict[str, Any]:
        return {
            "l5_controls": list(self.l5_controls),
            "l6_outputs": list(self.l6_outputs),
            "l1_inputs": list(self.l1_inputs),
            "l4_inputs": list(self.l4_inputs),
        }


@dataclass
class ControlReport:
    """A single control's mapping plus optional agent evidence."""

    mapping: ControlMapping
    evidence: AgentEvidence | None = None  # None if no agent specified

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"mapping": self.mapping.to_dict()}
        if self.evidence is not None:
            d["evidence"] = self.evidence.to_dict()
        return d


@dataclass
class ReportSummary:
    """Aggregate coverage statistics."""

    total_controls: int
    full_coverage: int
    partial_coverage: int
    indirect_coverage: int
    no_coverage: int
    coverage_percentage: float  # (full + partial) / total

    def to_dict(self) -> dict[str, Any]:
        return {
            "total_controls": self.total_controls,
            "full_coverage": self.full_coverage,
            "partial_coverage": self.partial_coverage,
            "indirect_coverage": self.indirect_coverage,
            "no_coverage": self.no_coverage,
            "coverage_percentage": self.coverage_percentage,
        }


@dataclass
class ComplianceReport:
    """A complete compliance mapping report."""

    framework_id: str
    framework_name: str
    generated_at: float
    agent_id: str | None
    controls: list[ControlReport]
    summary: ReportSummary
    layer_map: GovernanceLayerMap | None
    disclaimer: str

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "framework_id": self.framework_id,
            "framework_name": self.framework_name,
            "generated_at": self.generated_at,
            "agent_id": self.agent_id,
            "controls": [c.to_dict() for c in self.controls],
            "summary": self.summary.to_dict(),
            "disclaimer": self.disclaimer,
        }
        if self.layer_map is not None:
            d["layer_map"] = self.layer_map.to_dict()
        return d


# ── Framework Mapping Data ──────────────────────────────────────────────


_SOC2_CONTROLS: list[ControlMapping] = [
    ControlMapping(
        "CC6.1",
        "Logical and Physical Access Controls",
        "The entity implements logical access security to protect against threats",
        ["scope_compliance", "authority_verification", "isolation_integrity"],
        "full",
        "Birth certificates enforce agent identity. Scope compliance restricts "
        "actions to permitted set. Isolation integrity enforces sandbox boundaries.",
    ),
    ControlMapping(
        "CC6.2",
        "Prior to Issuing System Credentials",
        "New logical access credentials are issued based on authorization",
        ["authority_verification"],
        "full",
        "Agent birth certificates are issued by CertificateAuthority with named "
        "human owner. No anonymous agents.",
    ),
    ControlMapping(
        "CC6.3",
        "Registration and Authorization",
        "The entity registers and authorizes new users",
        ["authority_verification", "scope_compliance"],
        "full",
        "Agents must be registered (nomotic birth) with archetype, owner, "
        "organization, and zone.",
    ),
    ControlMapping(
        "CC6.6",
        "Measures Against Threats Outside System Boundaries",
        "The entity implements controls to prevent unauthorized access",
        ["isolation_integrity", "resource_boundaries", "incident_detection"],
        "partial",
        "Proxy mode blocks uncertified agents. Incident detection monitors "
        "anomalies. Network-level access control is outside Nomotic scope.",
    ),
    ControlMapping(
        "CC6.8",
        "Controls Over System Changes",
        "Changes to infrastructure and software are authorized and tested",
        ["behavioral_consistency", "cascading_impact", "precedent_alignment"],
        "partial",
        "Behavioral drift detection identifies when agent behavior changes from "
        "baseline. Nomotic does not govern its own infrastructure changes \u2014 "
        "this is the deployer's responsibility.",
    ),
    ControlMapping(
        "CC7.2",
        "Monitoring of Infrastructure and Software",
        "The entity monitors system components and anomalies",
        ["incident_detection", "behavioral_consistency"],
        "full",
        "Behavioral fingerprinting, drift detection, and anomaly scoring provide "
        "continuous monitoring. OTel and Prometheus exporters deliver telemetry.",
    ),
    ControlMapping(
        "CC7.3",
        "Detection of Unauthorized Activity",
        "The entity detects unauthorized access or use",
        ["scope_compliance", "authority_verification", "incident_detection"],
        "full",
        "Every action is evaluated. Out-of-scope actions are denied. Unauthorized "
        "agents are blocked at proxy layer.",
    ),
    ControlMapping(
        "CC7.4",
        "Response to Security Incidents",
        "The entity responds to identified security incidents",
        ["human_override", "incident_detection"],
        "partial",
        "Interrupt authority can halt agents. Human override can suspend "
        "certificates. Webhook events notify external systems. Incident response "
        "playbooks are outside Nomotic scope.",
    ),
    ControlMapping(
        "CC8.1",
        "Authorization and Approval of Changes",
        "Changes are authorized, designed, developed, configured, documented, and approved",
        ["authority_verification", "transparency"],
        "partial",
        "Governance seals provide signed authorization records. Configuration "
        "provenance tracks change history. Nomotic governs agent actions, not "
        "deployment changes.",
    ),
]

_HIPAA_CONTROLS: list[ControlMapping] = [
    ControlMapping(
        "164.312(a)(1)",
        "Access Control",
        "Implement technical policies and procedures for electronic information systems",
        ["scope_compliance", "authority_verification", "resource_boundaries",
         "isolation_integrity"],
        "full",
        "Scope restricts PHI access to authorized actions. Resource boundaries "
        "enforce data limits. Isolation prevents cross-boundary access.",
    ),
    ControlMapping(
        "164.312(b)",
        "Audit Controls",
        "Implement hardware, software, and procedural mechanisms to record and examine access",
        ["transparency"],
        "full",
        "Hash-chained audit trail records every governance decision. Compliance "
        "evidence bundles package audit data. OTel export provides telemetry.",
    ),
    ControlMapping(
        "164.312(c)(1)",
        "Integrity",
        "Implement policies to protect electronic PHI from improper alteration or destruction",
        ["cascading_impact", "resource_boundaries", "ethical_alignment"],
        "partial",
        "Cascading impact assessment evaluates downstream effects. Irreversibility "
        "enforcement prevents destructive actions without elevated authorization. "
        "Data integrity monitoring is outside Nomotic scope.",
    ),
    ControlMapping(
        "164.312(d)",
        "Person or Entity Authentication",
        "Implement procedures to verify the identity of persons seeking access",
        ["authority_verification"],
        "full",
        "Agent birth certificates provide cryptographic identity with named human "
        "owner chain. Certificate-required proxy mode blocks anonymous agents.",
    ),
    ControlMapping(
        "164.312(e)(1)",
        "Transmission Security",
        "Implement security measures to guard against unauthorized access during transmission",
        ["isolation_integrity"],
        "indirect",
        "Nomotic governs at the application layer. TLS/encryption for data in "
        "transit is outside Nomotic scope but can be verified as part of proxy "
        "health checks.",
    ),
]

_EU_AI_ACT_CONTROLS: list[ControlMapping] = [
    ControlMapping(
        "Art.9",
        "Risk Management System",
        "A risk management system shall be established, implemented, documented and maintained",
        ["cascading_impact", "stakeholder_impact", "incident_detection",
         "ethical_alignment"],
        "partial",
        "14-dimensional evaluation provides continuous risk assessment. Behavioral "
        "drift detection monitors for emerging risks. Risk management documentation "
        "and lifecycle processes are outside Nomotic scope.",
    ),
    ControlMapping(
        "Art.12",
        "Record-Keeping",
        "High-risk AI systems shall allow automatic recording of events (logs)",
        ["transparency"],
        "full",
        "Hash-chained audit trail with governance seals. Every action logged with "
        "verdict, dimensions, trust state, authority chain. Compliance evidence "
        "bundles package records for export.",
    ),
    ControlMapping(
        "Art.13",
        "Transparency",
        "High-risk AI systems shall be designed and developed to ensure transparency",
        ["transparency", "human_override"],
        "partial",
        "Transparency dimension scores action explainability. Governance verdicts "
        "include reasoning. Full dimension-by-dimension scores available. "
        "ModelProvenance in AgentCertificate provides machine-verifiable model "
        "identity, capabilities, and known limitations. Coverage is 'full' when "
        "agent has model_provenance with known_limitations, 'partial' otherwise.",
    ),
    ControlMapping(
        "EUAIA-Art13",
        "Transparency — Model Identity",
        "Users must be informed about AI identity, capabilities, and limitations",
        ["transparency"],
        "full",
        "ModelProvenance in AgentCertificate provides machine-verifiable model "
        "identity including provider, model name, version, safety evaluation ID, "
        "and known limitations. Provenance hash is cryptographically bound to the "
        "certificate signature.",
    ),
    ControlMapping(
        "Art.14",
        "Human Oversight",
        "High-risk AI systems shall be designed to be effectively overseen by natural persons",
        ["human_override", "authority_verification"],
        "full",
        "Named human owner on every agent birth certificate. Interrupt authority "
        "provides mechanical stop capability. Human override dimension gates "
        "sensitive actions. Governance decision override allows humans to approve "
        "or revoke decisions post-hoc.",
    ),
]

_ISO27001_CONTROLS: list[ControlMapping] = [
    ControlMapping(
        "A.5.15",
        "Access Control",
        "Rules to control physical and logical access shall be established",
        ["scope_compliance", "authority_verification", "isolation_integrity"],
        "full",
        "Birth certificates enforce identity. Scope compliance restricts to "
        "permitted actions. Proxy enforces certificate requirements.",
    ),
    ControlMapping(
        "A.5.23",
        "Information Security for Cloud Services",
        "Processes for acquisition, use, management and exit shall include information security",
        ["resource_boundaries", "isolation_integrity"],
        "partial",
        "Resource boundaries govern API access. Isolation integrity enforces "
        "sandboxing. Cloud infrastructure security is outside Nomotic scope.",
    ),
    ControlMapping(
        "A.8.5",
        "Secure Authentication",
        "Secure authentication technologies and procedures shall be established",
        ["authority_verification"],
        "full",
        "Cryptographic agent identity via birth certificates with HMAC-SHA256 signing.",
    ),
    ControlMapping(
        "A.8.15",
        "Logging",
        "Logs that record activities, exceptions, faults and other relevant events shall be produced",
        ["transparency"],
        "full",
        "Hash-chained audit trail. OTel export. SIEM export. Governance seals.",
    ),
    ControlMapping(
        "A.8.16",
        "Monitoring Activities",
        "Networks, systems and applications shall be monitored for anomalous behaviour",
        ["incident_detection", "behavioral_consistency"],
        "full",
        "Behavioral fingerprinting, drift detection, trust trajectory monitoring, "
        "anomaly scoring.",
    ),
]

_NIST_AI_RMF_CONTROLS: list[ControlMapping] = [
    ControlMapping(
        "GOVERN-1",
        "Policies and Processes",
        "Policies, processes, procedures, and practices for AI risk management are in place",
        ["scope_compliance", "authority_verification", "ethical_alignment"],
        "partial",
        "Governance presets encode policies. Org governance enforces organizational "
        "minimums. Policy-as-code support planned. Nomotic provides runtime "
        "enforcement \u2014 policy authoring and approval processes are outside scope.",
    ),
    ControlMapping(
        "MAP-3",
        "AI Risks and Benefits",
        "AI risks and benefits are mapped for all components of the AI system",
        ["cascading_impact", "stakeholder_impact", "ethical_alignment"],
        "partial",
        "14-dimensional evaluation covers impact, stakeholder, and ethical "
        "dimensions. Risk mapping documentation is outside Nomotic scope.",
    ),
    ControlMapping(
        "MEASURE-2",
        "AI Systems are Evaluated",
        "AI systems are evaluated for trustworthy characteristics",
        ["behavioral_consistency", "precedent_alignment", "transparency"],
        "full",
        "Continuous evaluation across 14 dimensions. Trust calibration with 5:1 "
        "asymmetry. Behavioral fingerprinting and drift detection.",
    ),
    ControlMapping(
        "MANAGE-2",
        "Treatment of AI Risks",
        "Strategies to maximize AI benefits and minimize negative impacts are planned",
        ["human_override", "incident_detection"],
        "partial",
        "Interrupt authority provides immediate halt capability. Human override "
        "gates sensitive actions. Governance decision overrides allow post-hoc "
        "correction. Risk mitigation planning is outside Nomotic scope.",
    ),
]

_NIST_CSF_AI_CONTROLS: list[ControlMapping] = [
    ControlMapping(
        "ID.AM-8",
        "AI Asset Management",
        "AI systems are inventoried and managed",
        ["authority_verification"],
        "full",
        "Birth certificates provide complete agent inventory with identity, owner, "
        "archetype, organization, and zone.",
    ),
    ControlMapping(
        "PR.AC-7",
        "AI Access Management",
        "Access to AI systems is managed consistent with risk",
        ["scope_compliance", "authority_verification", "resource_boundaries"],
        "full",
        "Certificate-required proxy mode. Scoped permissions. Risk-scaled "
        "governance via presets.",
    ),
    ControlMapping(
        "DE.CM-9",
        "AI System Monitoring",
        "AI system behavior is monitored for anomalies",
        ["incident_detection", "behavioral_consistency"],
        "full",
        "Behavioral drift detection. Anomaly scoring. Trust trajectory monitoring. "
        "OTel and Prometheus telemetry.",
    ),
]

_IMDA_AGENTIC_CONTROLS: list[ControlMapping] = [
    ControlMapping(
        "IMDA-1",
        "Agent Identity and Accountability",
        "Agentic AI systems should have clear identity and accountability chains",
        ["authority_verification"],
        "full",
        "Agent birth certificates with named human owner, organization, archetype. "
        "Cryptographic identity.",
    ),
    ControlMapping(
        "IMDA-2",
        "Human Oversight",
        "Humans should be able to oversee and intervene in agentic AI operations",
        ["human_override"],
        "full",
        "Interrupt authority. Human override dimension. Governance decision overrides.",
    ),
    ControlMapping(
        "IMDA-3",
        "Safety and Risk Management",
        "Risk-proportionate safeguards for agentic AI deployments",
        ["cascading_impact", "stakeholder_impact", "incident_detection",
         "ethical_alignment"],
        "full",
        "14-dimensional risk evaluation. Irreversibility-aware governance. "
        "Behavioral drift detection. Risk-scaled presets.",
    ),
]


_GDPR_CONTROLS: list[ControlMapping] = [
    ControlMapping(
        "GDPR-Art5-1a",
        "Lawfulness, Fairness and Transparency",
        "Processing shall be lawful, fair and in a transparent manner",
        ["jurisdictional_compliance", "transparency"],
        "full",
        "Jurisdictional compliance dimension evaluates legal basis, data residency, "
        "and cross-border transfer legality. Transparency dimension ensures actions "
        "are auditable and explainable.",
    ),
    ControlMapping(
        "GDPR-Art5-1b",
        "Purpose Limitation",
        "Personal data shall be collected for specified, explicit and legitimate purposes",
        ["scope_compliance", "isolation_integrity"],
        "full",
        "Scope compliance restricts agent actions to authorized purposes. Isolation "
        "integrity ensures data processing boundaries are maintained.",
    ),
    ControlMapping(
        "GDPR-Art5-1c",
        "Data Minimisation",
        "Personal data shall be adequate, relevant and limited to what is necessary",
        ["resource_boundaries", "scope_compliance"],
        "partial",
        "Resource boundaries limit data access. Scope compliance restricts to "
        "necessary actions. Actual data content minimisation is outside Nomotic "
        "scope — Nomotic governs actions, not data selection.",
    ),
    ControlMapping(
        "GDPR-Art5-1d",
        "Accuracy",
        "Personal data shall be accurate and, where necessary, kept up to date",
        ["behavioral_consistency"],
        "indirect",
        "Behavioral consistency detects deviations from expected patterns that "
        "could indicate data quality issues. Direct data accuracy enforcement "
        "is outside Nomotic scope.",
    ),
    ControlMapping(
        "GDPR-Art5-1e",
        "Storage Limitation",
        "Personal data shall be kept for no longer than is necessary",
        ["temporal_compliance"],
        "partial",
        "Temporal compliance enforces time windows and intervals. Data retention "
        "policy enforcement is outside Nomotic scope — Nomotic governs agent "
        "actions, not storage lifecycle.",
    ),
    ControlMapping(
        "GDPR-Art5-1f",
        "Integrity and Confidentiality",
        "Appropriate security of personal data, including protection against "
        "unauthorised or unlawful processing and against accidental loss",
        ["isolation_integrity", "incident_detection"],
        "full",
        "Isolation integrity enforces containment boundaries. Incident detection "
        "monitors for anomalous access patterns and potential breaches. "
        "Governance seals provide tamper-evident authorization records.",
    ),
    ControlMapping(
        "GDPR-Art25",
        "Data Protection by Design and by Default",
        "The controller shall implement appropriate technical and organisational measures "
        "for ensuring that, by default, only personal data which are necessary are processed",
        ["jurisdictional_compliance", "ethical_alignment"],
        "full",
        "Jurisdictional compliance evaluates data protection requirements at every "
        "action. Ethical alignment enforces configured ethical constraints. "
        "14-dimensional governance provides protection-by-design.",
    ),
    ControlMapping(
        "GDPR-Art44",
        "Transfers to Third Countries",
        "Any transfer of personal data to a third country shall take place only "
        "under conditions laid down in this Chapter",
        ["jurisdictional_compliance"],
        "full",
        "Jurisdictional compliance dimension evaluates cross-border transfers "
        "against adequacy decisions, standard contractual clauses, binding "
        "corporate rules, and explicit consent. Non-compliant transfers are vetoed.",
    ),
    ControlMapping(
        "GDPR-Art5-2",
        "Accountability",
        "The controller shall be responsible for, and be able to demonstrate compliance",
        ["transparency"],
        "full",
        "Hash-chained audit trail provides tamper-evident governance records. "
        "Governance seals bind authorization to actions. Compliance evidence "
        "bundles package audit data for regulators.",
    ),
]

FRAMEWORK_MAPPINGS: dict[str, FrameworkMapping] = {
    "soc2": FrameworkMapping(
        framework_id="soc2",
        framework_name="SOC 2 Trust Service Criteria",
        version="2017",
        controls=_SOC2_CONTROLS,
    ),
    "hipaa": FrameworkMapping(
        framework_id="hipaa",
        framework_name="HIPAA Technical Safeguards",
        version="45 CFR 164.312",
        controls=_HIPAA_CONTROLS,
    ),
    "eu-ai-act": FrameworkMapping(
        framework_id="eu-ai-act",
        framework_name="EU AI Act",
        version="2024/1689",
        controls=_EU_AI_ACT_CONTROLS,
    ),
    "iso27001": FrameworkMapping(
        framework_id="iso27001",
        framework_name="ISO/IEC 27001:2022",
        version="2022",
        controls=_ISO27001_CONTROLS,
    ),
    "nist-ai-rmf": FrameworkMapping(
        framework_id="nist-ai-rmf",
        framework_name="NIST AI Risk Management Framework",
        version="AI 100-1",
        controls=_NIST_AI_RMF_CONTROLS,
    ),
    "nist-csf-ai": FrameworkMapping(
        framework_id="nist-csf-ai",
        framework_name="NIST Cybersecurity Framework for AI (IR 8596)",
        version="IR 8596",
        controls=_NIST_CSF_AI_CONTROLS,
    ),
    "imda-agentic": FrameworkMapping(
        framework_id="imda-agentic",
        framework_name="IMDA Model AI Governance Framework for Agentic AI",
        version="1.0",
        controls=_IMDA_AGENTIC_CONTROLS,
    ),
    "gdpr": FrameworkMapping(
        framework_id="gdpr",
        framework_name="EU General Data Protection Regulation (GDPR)",
        version="2016/679",
        controls=_GDPR_CONTROLS,
    ),
}


# ── Custom Framework Loading ────────────────────────────────────────────


def load_custom_framework(path: str | Path) -> FrameworkMapping:
    """Load a custom compliance framework from a JSON file.

    Validates structure and converts to FrameworkMapping.
    Raises FrameworkLoadError on invalid structure.
    """
    path = Path(path)
    str_path = str(path)

    if not path.exists():
        raise FrameworkLoadError(str_path, "File does not exist")

    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise FrameworkLoadError(str_path, f"Cannot read file: {exc}") from exc

    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise FrameworkLoadError(str_path, f"Invalid JSON: {exc}") from exc

    if not isinstance(data, dict):
        raise FrameworkLoadError(str_path, "Top-level value must be a JSON object")

    # Required top-level fields
    for field_name in ("framework_id", "name", "controls"):
        if field_name not in data:
            raise FrameworkLoadError(str_path, f"Missing required field: {field_name!r}")

    controls_raw = data["controls"]
    if not isinstance(controls_raw, list):
        raise FrameworkLoadError(str_path, "'controls' must be a list")
    if len(controls_raw) == 0:
        raise FrameworkLoadError(str_path, "'controls' must be a non-empty list")

    # Validate and convert each control
    controls: list[ControlMapping] = []
    for i, c in enumerate(controls_raw):
        if not isinstance(c, dict):
            raise FrameworkLoadError(str_path, f"controls[{i}] must be an object")

        for req in ("control_id", "description", "nomotic_dimensions", "coverage"):
            if req not in c:
                raise FrameworkLoadError(
                    str_path, f"controls[{i}] missing required field: {req!r}"
                )

        dims = c["nomotic_dimensions"]
        if not isinstance(dims, list):
            raise FrameworkLoadError(
                str_path,
                f"controls[{i}] 'nomotic_dimensions' must be a list of strings",
            )

        coverage = c["coverage"]
        if coverage not in VALID_COVERAGE:
            raise FrameworkLoadError(
                str_path,
                f"controls[{i}] invalid coverage value: {coverage!r}. "
                f"Must be one of: {', '.join(sorted(VALID_COVERAGE))}",
            )

        # Warn on unknown dimension names (don't fail)
        for dim in dims:
            if dim not in _KNOWN_DIMENSION_NAMES:
                warnings.warn(
                    f"Custom framework {str_path}: control {c['control_id']!r} "
                    f"references unknown dimension {dim!r}",
                    stacklevel=2,
                )

        controls.append(
            ControlMapping(
                control_id=c["control_id"],
                control_name=c.get("control_name", c["control_id"]),
                description=c["description"],
                nomotic_dimensions=c["nomotic_dimensions"],
                coverage=coverage,
                notes=c.get("notes", ""),
            )
        )

    return FrameworkMapping(
        framework_id=data["framework_id"],
        framework_name=data["name"],
        version=data.get("version", ""),
        controls=controls,
        description=data.get("description", ""),
    )


def discover_frameworks(
    extra_dirs: list[Path] | None = None,
) -> dict[str, Path]:
    """Find all available framework files.

    Searches:
    1. ~/.nomotic/frameworks/*.json
    2. ./nomotic-frameworks/*.json  (current working directory)
    3. Any directories in extra_dirs

    Returns: dict mapping framework_id -> Path.
    Later entries override earlier ones (extra_dirs take precedence).
    """
    result: dict[str, Path] = {}

    search_dirs: list[Path] = [
        Path.home() / ".nomotic" / "frameworks",
        Path.cwd() / "nomotic-frameworks",
    ]
    if extra_dirs:
        search_dirs.extend(extra_dirs)

    for directory in search_dirs:
        if not directory.is_dir():
            continue
        for json_path in sorted(directory.glob("*.json")):
            try:
                fm = load_custom_framework(json_path)
                result[fm.framework_id] = json_path
            except FrameworkLoadError:
                warnings.warn(
                    f"Skipping invalid framework file: {json_path}",
                    stacklevel=2,
                )

    return result


# ── Report Generator ────────────────────────────────────────────────────


class ComplianceReportGenerator:
    """Generates compliance mapping reports."""

    def __init__(self, base_dir: Path | None = None) -> None:
        self._base_dir = base_dir or Path.home() / ".nomotic"
        self._custom_frameworks: dict[str, FrameworkMapping] = {}

    def register_custom_framework(self, framework: FrameworkMapping) -> None:
        """Register a custom framework.

        Custom frameworks take precedence over built-ins with the same
        ``framework_id``.
        """
        self._custom_frameworks[framework.framework_id] = framework

    def load_frameworks_from_dir(self, directory: str | Path) -> int:
        """Load all ``*.json`` files from *directory* as custom frameworks.

        Files that fail to load are skipped with a warning (not a crash).
        Returns the number of frameworks successfully loaded.
        """
        directory = Path(directory)
        count = 0
        if not directory.is_dir():
            return count
        for json_path in sorted(directory.glob("*.json")):
            try:
                fm = load_custom_framework(json_path)
                self.register_custom_framework(fm)
                count += 1
            except FrameworkLoadError as exc:
                warnings.warn(str(exc), stacklevel=2)
        return count

    def list_frameworks(self) -> dict[str, str]:
        """Return a mapping of framework_id -> display name for all frameworks.

        Built-in frameworks use their ``framework_name`` as display name.
        Custom frameworks are suffixed with ``(custom)``.
        """
        result: dict[str, str] = {}
        for fw_id, fm in FRAMEWORK_MAPPINGS.items():
            result[fw_id] = fm.framework_name
        for fw_id, fm in self._custom_frameworks.items():
            result[fw_id] = f"{fm.framework_name} (custom)"
        return result

    def generate(
        self,
        framework: str,
        agent_id: str | None = None,
        include_layer_map: bool = False,
    ) -> ComplianceReport:
        """Generate a compliance report for the specified framework.

        Args:
            framework: Framework ID (soc2, hipaa, eu-ai-act, iso27001,
                       nist-ai-rmf, nist-csf-ai, imda-agentic)
            agent_id: Optional — include agent-specific evidence
            include_layer_map: Include governance stack coverage summary

        Returns:
            A populated ComplianceReport.

        Raises:
            ValueError: If the framework ID is not recognized.
        """
        # Custom frameworks take precedence over built-ins
        mapping = self._custom_frameworks.get(framework)
        if mapping is None:
            mapping = FRAMEWORK_MAPPINGS.get(framework)
        if mapping is None:
            all_ids = sorted(set(FRAMEWORK_MAPPINGS.keys()) | set(self._custom_frameworks.keys()))
            valid = ", ".join(all_ids)
            raise ValueError(
                f"Unknown framework: {framework!r}. "
                f"Valid frameworks: {valid}"
            )

        # Gather agent evidence if requested
        evidence: AgentEvidence | None = None
        if agent_id is not None:
            evidence = self._gather_evidence(agent_id)

        # Build control reports
        controls: list[ControlReport] = []
        for cm in mapping.controls:
            controls.append(ControlReport(mapping=cm, evidence=evidence))

        # Compute summary
        summary = self._compute_summary(mapping.controls)

        # Build layer map if requested
        layer_map: GovernanceLayerMap | None = None
        if include_layer_map:
            layer_map = self._generate_layer_map()

        return ComplianceReport(
            framework_id=mapping.framework_id,
            framework_name=mapping.framework_name,
            generated_at=time.time(),
            agent_id=agent_id,
            controls=controls,
            summary=summary,
            layer_map=layer_map,
            disclaimer=DISCLAIMER,
        )

    def _gather_evidence(self, agent_id: str) -> AgentEvidence:
        """Gather evidence from audit trail and cost data for an agent."""
        from nomotic.audit_store import AuditStore

        store = AuditStore(self._base_dir)
        records = store.query_all(agent_id)

        if not records:
            return AgentEvidence(
                total_actions=0,
                total_denials=0,
                denial_rate=0.0,
                average_ucs=0.0,
                trust_current=0.5,
                trust_trend="stable",
                active_alerts=0,
                sealed_actions=0,
                last_activity=0.0,
            )

        total = len(records)
        denials = sum(1 for r in records if r.verdict == "DENY")
        denial_rate = denials / total if total > 0 else 0.0
        avg_ucs = sum(r.ucs for r in records) / total if total > 0 else 0.0
        sealed = sum(1 for r in records if getattr(r, "seal_id", "") != "")

        # Trust trend: compare last 20% of records to first 20%
        trust_current = records[-1].trust_score
        trust_trend = self._compute_trust_trend(records)

        # Count active alerts (records with severity "alert")
        active_alerts = sum(1 for r in records if r.severity == "alert")

        return AgentEvidence(
            total_actions=total,
            total_denials=denials,
            denial_rate=round(denial_rate, 4),
            average_ucs=round(avg_ucs, 4),
            trust_current=trust_current,
            trust_trend=trust_trend,
            active_alerts=active_alerts,
            sealed_actions=sealed,
            last_activity=records[-1].timestamp,
        )

    @staticmethod
    def _compute_trust_trend(
        records: list[Any],
    ) -> str:
        """Determine trust trend from a list of records."""
        if len(records) < 2:
            return "stable"
        # Compare average trust of last 20% vs first 20%
        n = max(1, len(records) // 5)
        early = records[:n]
        late = records[-n:]
        early_avg = sum(r.trust_score for r in early) / len(early)
        late_avg = sum(r.trust_score for r in late) / len(late)
        delta = late_avg - early_avg
        if delta > 0.02:
            return "rising"
        elif delta < -0.02:
            return "falling"
        return "stable"

    @staticmethod
    def _compute_summary(controls: list[ControlMapping]) -> ReportSummary:
        """Compute coverage statistics from a list of control mappings."""
        total = len(controls)
        full = sum(1 for c in controls if c.coverage == "full")
        partial = sum(1 for c in controls if c.coverage == "partial")
        indirect = sum(1 for c in controls if c.coverage == "indirect")
        none_ = sum(1 for c in controls if c.coverage == "none")
        pct = ((full + partial) / total * 100) if total > 0 else 0.0
        return ReportSummary(
            total_controls=total,
            full_coverage=full,
            partial_coverage=partial,
            indirect_coverage=indirect,
            no_coverage=none_,
            coverage_percentage=round(pct, 1),
        )

    @staticmethod
    def _generate_layer_map() -> GovernanceLayerMap:
        """Generate governance stack coverage summary."""
        return GovernanceLayerMap(
            l5_controls=[
                "Agent identity and access control via birth certificates",
                "Scoped autonomy and tool permissions",
                "14-dimensional continuous governance evaluation",
                "Trust calibration with asymmetric cost (5:1 violation penalty)",
                "Behavioral fingerprinting and drift detection",
                "Interrupt authority for mechanical agent halt",
                "Human override gating for sensitive actions",
                "Governance seals for cryptographic authorization binding",
                "Certificate lifecycle (issue, suspend, reactivate, revoke)",
                "Proxy-level enforcement for uncertified agent blocking",
            ],
            l6_outputs=[
                "Hash-chained audit trail for tamper-evident record keeping",
                "OpenTelemetry telemetry export (traces, metrics)",
                "Prometheus metrics for governance decision monitoring",
                "SIEM export for security event correlation",
                "Compliance evidence bundles for regulatory packaging",
                "Trust trajectory data for outcome trend analysis",
                "Behavioral drift alerts for anomaly notification",
            ],
            l1_inputs=[
                "Risk tier classification \u2192 maps to preset selection",
                "Organizational governance minimums \u2192 org-governance.yaml",
                "Compliance framework requirements \u2192 compliance preset selection",
                "Ethical guidelines \u2192 ethical alignment dimension configuration",
            ],
            l4_inputs=[
                "Model capability boundaries \u2192 scope configuration",
                "Model risk profile \u2192 archetype and preset selection",
                "Model update notifications \u2192 behavioral baseline reset triggers",
                "Model-specific safety constraints \u2192 dimension rule configuration",
            ],
        )


# ── Output Formatters ───────────────────────────────────────────────────


def format_markdown(report: ComplianceReport) -> str:
    """Format report as Markdown document."""
    lines: list[str] = []

    # Title
    lines.append(f"# Nomotic Compliance Report: {report.framework_name}")
    lines.append("")
    ts = datetime.fromtimestamp(report.generated_at, tz=timezone.utc).isoformat()
    lines.append(f"Generated: {ts}")
    if report.agent_id:
        lines.append(f"Agent: {report.agent_id}")
    lines.append("")

    # Disclaimer
    lines.append(f"> **Disclaimer:** {report.disclaimer}")
    lines.append("")

    # Summary table
    lines.append("## Coverage Summary")
    lines.append("")
    lines.append("| Coverage Level | Controls | Percentage |")
    lines.append("|---------------|----------|------------|")
    s = report.summary
    total = s.total_controls or 1  # prevent division by zero
    lines.append(
        f"| Full          | {s.full_coverage:<8} "
        f"| {s.full_coverage / total * 100:.0f}%{' ' * 8}|"
    )
    lines.append(
        f"| Partial       | {s.partial_coverage:<8} "
        f"| {s.partial_coverage / total * 100:.0f}%{' ' * 8}|"
    )
    lines.append(
        f"| Indirect      | {s.indirect_coverage:<8} "
        f"| {s.indirect_coverage / total * 100:.0f}%{' ' * 8}|"
    )
    lines.append(
        f"| None          | {s.no_coverage:<8} "
        f"| {s.no_coverage / total * 100:.0f}%{' ' * 8}|"
    )
    lines.append("")

    # Control mappings
    lines.append("## Control Mappings")
    lines.append("")

    for cr in report.controls:
        m = cr.mapping
        lines.append(f"### {m.control_id} \u2014 {m.control_name}")
        lines.append(f"**Coverage:** {m.coverage.capitalize()}")
        lines.append(
            f"**Nomotic Dimensions:** {', '.join(m.nomotic_dimensions)}"
        )
        lines.append(f"**How Nomotic Addresses This:** {m.notes}")
        lines.append("")

        if cr.evidence is not None and cr.evidence.total_actions > 0:
            ev = cr.evidence
            lines.append(f"**Agent Evidence ({report.agent_id}):**")
            lines.append(f"- Total actions evaluated: {ev.total_actions:,}")
            lines.append(f"- Denial rate: {ev.denial_rate * 100:.1f}%")
            lines.append(
                f"- Actions with governance seals: {ev.sealed_actions:,}"
            )
            lines.append(
                f"- Current trust: {ev.trust_current:.2f} ({ev.trust_trend})"
            )
            lines.append("")

        lines.append("---")
        lines.append("")

    # Layer map
    if report.layer_map is not None:
        lm = report.layer_map
        lines.append("## Governance Layer Coverage")
        lines.append("")
        lines.append(
            "Nomotic operates as **Layer 5: Runtime System Governance** "
            "in the enterprise AI governance stack."
        )
        lines.append("")

        lines.append("**What Nomotic enforces (L5):**")
        for item in lm.l5_controls:
            lines.append(f"- {item}")
        lines.append("")

        lines.append("**What Nomotic provides to outcome monitoring (L6):**")
        for item in lm.l6_outputs:
            lines.append(f"- {item}")
        lines.append("")

        lines.append("**What Nomotic needs from strategic governance (L1):**")
        for item in lm.l1_inputs:
            lines.append(f"- {item}")
        lines.append("")

        lines.append("**What Nomotic needs from model governance (L4):**")
        for item in lm.l4_inputs:
            lines.append(f"- {item}")
        lines.append("")

    # Gaps and recommendations
    gaps = [
        cr.mapping
        for cr in report.controls
        if cr.mapping.coverage in ("partial", "indirect", "none")
    ]
    if gaps:
        lines.append("## Gaps and Recommendations")
        lines.append("")
        for g in gaps:
            # Extract "outside Nomotic scope" sentences from notes
            scope_notes = [
                s.strip()
                for s in g.notes.split(".")
                if "outside" in s.lower() and "scope" in s.lower()
            ]
            rec = ". ".join(scope_notes) + "." if scope_notes else g.notes
            lines.append(f"- **{g.control_id}**: {rec}")
        lines.append("")

    return "\n".join(lines)


def format_json(report: ComplianceReport) -> dict[str, Any]:
    """Format report as JSON-serializable dict."""
    return report.to_dict()
