"""Cost projection and monitoring for Nomotic agents.

Estimates per-agent cost based on observed execution duration.
This is a monitoring and reporting signal — NOT a governance gate.

Cost is projected, not gated: we estimate, we warn, we do NOT veto on cost.
Advisory thresholds generate alerts, not denials.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

__all__ = [
    "CostProfile",
    "CostTracker",
]


@dataclass
class CostProfile:
    """Estimated cost characteristics for an agent."""

    estimated_cost_per_run: float | None = None  # User-set or auto-estimated
    cost_per_ms: float = 0.0001  # Default: $0.0001/ms = $0.006/min
    currency: str = "USD"

    # Running statistics (updated after each execution)
    total_runs: int = 0
    total_estimated_cost: float = 0.0
    total_execution_ms: float = 0.0
    average_execution_ms: float = 0.0

    # Advisory thresholds (None = no advisory)
    daily_budget_advisory: float | None = None
    monthly_budget_advisory: float | None = None

    def record_execution(self, duration_ms: float) -> float:
        """Record an execution and return the estimated cost for this run.

        Updates running averages. Returns the cost estimate for this execution.
        """
        self.total_runs += 1
        self.total_execution_ms += duration_ms
        self.average_execution_ms = self.total_execution_ms / self.total_runs

        cost = self._estimate_single_run_cost(duration_ms)
        self.total_estimated_cost += cost
        return cost

    def _estimate_single_run_cost(self, duration_ms: float) -> float:
        """Estimate cost for a single execution."""
        if self.estimated_cost_per_run is not None:
            return self.estimated_cost_per_run
        return duration_ms * self.cost_per_ms

    def project_daily(self, runs_today: int | None = None) -> float:
        """Project daily cost based on current run rate.

        If runs_today is provided, uses that count. Otherwise estimates
        from total_runs assuming uniform distribution.
        """
        if self.total_runs == 0:
            return 0.0
        avg_cost = self.total_estimated_cost / self.total_runs
        daily_runs = runs_today if runs_today is not None else self.total_runs
        return avg_cost * daily_runs

    def project_monthly(self, daily_projection: float | None = None) -> float:
        """Project monthly cost. Uses daily_projection * 30 if provided."""
        daily = daily_projection if daily_projection is not None else self.project_daily()
        return daily * 30

    def check_advisories(self, runs_today: int | None = None) -> list[dict[str, Any]]:
        """Check if projected costs exceed advisory thresholds.

        Returns list of advisory alerts (may be empty).
        Each alert: {"type": "daily"|"monthly", "projected": float, "threshold": float}
        """
        alerts: list[dict[str, Any]] = []
        daily = self.project_daily(runs_today)

        if self.daily_budget_advisory is not None and daily > self.daily_budget_advisory:
            alerts.append({
                "type": "daily",
                "projected": round(daily, 2),
                "threshold": self.daily_budget_advisory,
                "currency": self.currency,
            })

        monthly = self.project_monthly(daily)
        if self.monthly_budget_advisory is not None and monthly > self.monthly_budget_advisory:
            alerts.append({
                "type": "monthly",
                "projected": round(monthly, 2),
                "threshold": self.monthly_budget_advisory,
                "currency": self.currency,
            })

        return alerts

    def to_dict(self) -> dict[str, Any]:
        """JSON-serializable representation."""
        return {
            "estimated_cost_per_run": self.estimated_cost_per_run,
            "cost_per_ms": self.cost_per_ms,
            "currency": self.currency,
            "total_runs": self.total_runs,
            "total_estimated_cost": self.total_estimated_cost,
            "total_execution_ms": self.total_execution_ms,
            "average_execution_ms": self.average_execution_ms,
            "daily_budget_advisory": self.daily_budget_advisory,
            "monthly_budget_advisory": self.monthly_budget_advisory,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CostProfile:
        """Reconstruct from a JSON-serializable dict."""
        return cls(
            estimated_cost_per_run=data.get("estimated_cost_per_run"),
            cost_per_ms=data.get("cost_per_ms", 0.0001),
            currency=data.get("currency", "USD"),
            total_runs=data.get("total_runs", 0),
            total_estimated_cost=data.get("total_estimated_cost", 0.0),
            total_execution_ms=data.get("total_execution_ms", 0.0),
            average_execution_ms=data.get("average_execution_ms", 0.0),
            daily_budget_advisory=data.get("daily_budget_advisory"),
            monthly_budget_advisory=data.get("monthly_budget_advisory"),
        )

    def summary(self) -> dict[str, Any]:
        """Human-readable cost summary for CLI display."""
        return {
            "total_runs": self.total_runs,
            "average_cost_per_run": round(
                self.total_estimated_cost / max(self.total_runs, 1), 4
            ),
            "average_execution_ms": round(self.average_execution_ms, 1),
            "total_estimated_cost": round(self.total_estimated_cost, 2),
            "currency": self.currency,
            "daily_projection": round(self.project_daily(), 2),
            "monthly_projection": round(self.project_monthly(), 2),
            "daily_budget_advisory": self.daily_budget_advisory,
            "monthly_budget_advisory": self.monthly_budget_advisory,
        }


class CostTracker:
    """Manages cost profiles for multiple agents.

    Persists to ~/.nomotic/cost/ as JSON files per agent.
    """

    def __init__(self, base_dir: Path | None = None):
        self._base_dir = (base_dir or Path.home() / ".nomotic") / "cost"
        self._base_dir.mkdir(parents=True, exist_ok=True)
        self._profiles: dict[str, CostProfile] = {}

    def get_profile(self, agent_id: str) -> CostProfile:
        """Get or create a cost profile for an agent."""
        if agent_id not in self._profiles:
            self._profiles[agent_id] = self._load_or_create(agent_id)
        return self._profiles[agent_id]

    def record_execution(self, agent_id: str, duration_ms: float) -> float:
        """Record an execution for an agent. Returns estimated cost."""
        profile = self.get_profile(agent_id)
        cost = profile.record_execution(duration_ms)
        self._save(agent_id, profile)
        return cost

    def configure(self, agent_id: str, **kwargs: Any) -> None:
        """Update cost configuration for an agent.

        Accepted kwargs: estimated_cost_per_run, cost_per_ms, currency,
        daily_budget_advisory, monthly_budget_advisory
        """
        profile = self.get_profile(agent_id)
        for key, value in kwargs.items():
            if hasattr(profile, key):
                setattr(profile, key, value)
        self._save(agent_id, profile)

    def _load_or_create(self, agent_id: str) -> CostProfile:
        path = self._agent_path(agent_id)
        if path.exists():
            data = json.loads(path.read_text(encoding="utf-8"))
            return CostProfile.from_dict(data)
        return CostProfile()

    def _save(self, agent_id: str, profile: CostProfile) -> None:
        path = self._agent_path(agent_id)
        path.write_text(
            json.dumps(profile.to_dict(), indent=2),
            encoding="utf-8",
        )

    def _agent_path(self, agent_id: str) -> Path:
        safe_name = agent_id.lower().replace("/", "_").replace("\\", "_")
        return self._base_dir / f"{safe_name}.json"
